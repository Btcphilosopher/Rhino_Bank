# RHINOQUANT ITALIA — DOCUMENTAZIONE METODOLOGICA E FORMULE QUANTITATIVE

## 1. MODELLO DI AMMORTAMENTO FRANCESE E RATEIZZIONE
Ogni mutuo ipotecario residenziale italiano viene modellizzato secondo lo schema di Ammortamento Francese a rata costante $R$:

$$R = P \times \frac{i \times (1+i)^n}{(1+i)^n - 1}$$

Dove:
* $P$: Saldo residuo del capitale ipotecario
* $i$: Tasso d'interesse nominale mensile ($i = \text{Tasso Annuo} / 12$)
* $n$: Durata residua in mesi

## 2. CONVERSIONE CPR IN SMM (SINGLE MONTHLY MORTALITY)
Il tasso annuo di rimborso anticipato (Conditional Prepayment Rate - CPR) viene convertito nella probabilità mensile SMM:

$$\text{SMM} = 1 - (1 - \text{CPR})^{1/12}$$

## 3. FORMULA DELLE PERDITE ATTESE (EXPECTED LOSS)
$$\text{EL} = \text{PD} \times \text{LGD} \times \text{EAD}$$

Dove:
* $\text{PD}$: Probabilità di Default dinamica aggiustata per LTV e Seasoning
* $\text{LGD}$: Loss Given Default (pari a $100\% - \text{Tasso di Recupero Netto}$)
* $\text{EAD}$: Exposure at Default (saldo capitale al momento del default)

## 4. OPTION-ADJUSTED SPREAD (OAS)
$$P = \sum_{t=1}^{T} \frac{\text{CF}_t(s_k)}{(1 + r_t + \text{OAS})^t}$$

Dove $s_k$ rappresenta lo scenario stocastico del percorso dei tassi generato dal motore Monte Carlo.

## 5. VERIFICA DI BILANCIATURA CONTABILE A DOPPIA ENTRATA
$$\text{Opening Balance} + \text{Interest Collections} + \text{Principal Collections} + \text{Recoveries} - \text{Outflows} - \text{Gross Losses} = \text{Closing Balance}$$

Il sistema verifica automaticamente che la discrepanza contabile sia strettamente inferiore a € 0,01 per ogni mensilità.
