/**
 * @file SidebarNav.tsx
 * RHINOQUANT ITALIA - Institutional Quantitative Terminal Sidebar Navigation
 */

import React from 'react';
import {
  LayoutDashboard,
  Database,
  Sliders,
  Layers,
  TrendingDown,
  Calculator,
  Activity,
  Dices,
  PieChart,
  BookOpen,
  FileText,
  Code2,
  Lock
} from 'lucide-react';

interface SidebarNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({ currentTab, setCurrentTab }) => {
  const menuItems = [
    { id: 'overview', label: 'Panoramica SPV', icon: LayoutDashboard, category: 'RICERCA & DASHBOARD' },
    { id: 'universe', label: 'Universo Mutui', icon: Database, category: 'COLLATERALE' },
    { id: 'pool', label: 'Costruttore Pool', icon: Sliders, category: 'COLLATERALE' },
    { id: 'deal', label: 'Strutturazione SPV', icon: Layers, category: 'CARTOLARIZZAZIONE' },
    { id: 'waterfall', label: 'Cascata Incassi', icon: TrendingDown, category: 'CARTOLARIZZAZIONE' },
    { id: 'pricing', label: 'Pricing & OAS', icon: Calculator, category: 'VALUTAZIONE' },
    { id: 'stress', label: 'Stress Test Lab', icon: Activity, category: 'SIMULAZIONE & RISCHIO' },
    { id: 'montecarlo', label: 'Monte Carlo', icon: Dices, category: 'SIMULAZIONE & RISCHIO' },
    { id: 'portfolio', label: 'Analisi Portafoglio', icon: PieChart, category: 'RISCHIO' },
    { id: 'notebook', label: 'Taccuino Ricerca', icon: BookOpen, category: 'AUDIT & DOCUMENTI' },
    { id: 'reports', label: 'Report Istituzionale', icon: FileText, category: 'AUDIT & DOCUMENTI' },
    { id: 'code', label: 'Ispezione Codice / Engine', icon: Code2, category: 'SISTEMA & ARCHITETTURA' },
  ];

  // Group items by category
  const categories = Array.from(new Set(menuItems.map(item => item.category)));

  return (
    <aside className="w-60 bg-[#0c0f17] border-r border-slate-800 text-slate-300 flex flex-col shrink-0 select-none">
      <div className="p-3 border-b border-slate-800/80">
        <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold mb-1">
          OPERAZIONE ATTIVA
        </div>
        <div className="text-xs font-semibold text-blue-300 truncate font-mono">
          RQ ITALIA RMBS 2026-1
        </div>
        <div className="text-[11px] text-slate-400 font-mono mt-0.5">
          Collaterale: € 15,25 MLD
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-2 px-2 space-y-4">
        {categories.map(cat => (
          <div key={cat} className="space-y-1">
            <div className="px-2 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
              {cat}
            </div>
            {menuItems
              .filter(item => item.category === cat)
              .map(item => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentTab(item.id)}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-blue-600/90 text-white font-semibold shadow-sm border border-blue-500/50'
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-300' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
          </div>
        ))}
      </div>

      <div className="p-3 border-t border-slate-800 bg-[#090b12] text-[11px] text-slate-400 space-y-1 font-mono">
        <div className="flex items-center justify-between text-slate-400">
          <span>Tassi: Euribor 3M</span>
          <span className="text-emerald-400 font-semibold">3,25%</span>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>IRS 20Y Benchmark</span>
          <span className="text-blue-400 font-semibold">3,05%</span>
        </div>
        <div className="pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
          <span>Stato Modello:</span>
          <span className="text-amber-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            DETERMINISTICO
          </span>
        </div>
      </div>
    </aside>
  );
};
