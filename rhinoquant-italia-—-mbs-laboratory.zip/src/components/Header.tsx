/**
 * @file Header.tsx
 * RHINOQUANT ITALIA - Top Bar Navigation Header
 * Design: European Institutional Quantitative Terminal (Deep Navy, Steel, Graphite, Gold accent)
 */

import React from 'react';
import { Database, ShieldCheck, Activity, Cpu, RefreshCw, FileText } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  seed: number;
  setSeed: (seed: number) => void;
  reconciled: boolean;
  onResetDemo: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  seed,
  setSeed,
  reconciled,
  onResetDemo
}) => {
  return (
    <header className="bg-[#0f141f] border-b border-slate-800 text-slate-200 px-4 py-2.5 flex items-center justify-between shrink-0 shadow-md">
      {/* Zone 1: Wordmark & Brand Title */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-gradient-to-br from-blue-700 via-indigo-800 to-slate-900 border border-blue-500/30 flex items-center justify-center font-display font-bold text-amber-400 text-base shadow-inner">
          RQ
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-bold tracking-tight text-white text-base">
              RHINOQUANT ITALIA
            </span>
            <span className="text-[10px] font-mono uppercase bg-blue-950/80 text-blue-400 px-1.5 py-0.5 rounded border border-blue-800/50">
              MBS LABORATORY
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-sans tracking-wide">
            RICERCA <span className="text-slate-600">→</span> STRUTTURAZIONE <span className="text-slate-600">→</span> PRICING <span className="text-slate-600">→</span> SIMULAZIONE <span className="text-slate-600">→</span> RISCHIO
          </p>
        </div>
      </div>

      {/* Zone 2: Fast Navigation Links */}
      <nav className="hidden lg:flex items-center gap-1.5 text-xs font-medium">
        {[
          { id: 'overview', label: 'Panoramica' },
          { id: 'universe', label: 'Universo Mutui' },
          { id: 'pool', label: 'Costruttore Pool' },
          { id: 'deal', label: 'Strutturazione' },
          { id: 'waterfall', label: 'Waterfall' },
          { id: 'pricing', label: 'Pricing & OAS' },
          { id: 'stress', label: 'Stress Test' },
          { id: 'montecarlo', label: 'Monte Carlo' },
          { id: 'reports', label: 'Report' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentTab(item.id)}
            className={`px-2.5 py-1 rounded transition-all whitespace-nowrap ${
              currentTab === item.id
                ? 'bg-blue-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Zone 3: Quantitative Controls & System Status */}
      <div className="flex items-center gap-3">
        {/* Seed Selector */}
        <div className="hidden sm:flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs text-slate-300">
          <Cpu className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-[11px] text-slate-400 font-mono">SEED:</span>
          <input
            type="number"
            value={seed}
            onChange={e => setSeed(Number(e.target.value) || 12345)}
            className="w-14 bg-transparent text-right font-mono text-amber-300 font-medium focus:outline-none"
          />
        </div>

        {/* Double Entry Reconciliation Audit Indicator */}
        <div
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono border ${
            reconciled
              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60'
              : 'bg-rose-950/60 text-rose-300 border-rose-800/60'
          }`}
          title="Verifica bilanciatura contabile a doppia entrata dell'operazione"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>BILANCIO: {reconciled ? 'OK (€0,00)' : 'SBILANCIATO'}</span>
        </div>

        {/* Reset Demo Button */}
        <button
          onClick={onResetDemo}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1 rounded text-xs font-medium transition-colors"
          title="Ripristina dataset dimostrativo RQ ITALIA DEMO 01"
        >
          <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
          <span className="hidden sm:inline">DEMO 01</span>
        </button>
      </div>
    </header>
  );
};
