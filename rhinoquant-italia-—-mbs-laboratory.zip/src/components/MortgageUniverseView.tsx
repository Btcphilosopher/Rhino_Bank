/**
 * @file MortgageUniverseView.tsx
 * RHINOQUANT ITALIA - Synthetic Italian Mortgage Universe Data Grid
 */

import React, { useState, useMemo } from 'react';
import { Mortgage } from '../types/mbs';
import { Search, Filter, Eye, ChevronLeft, ChevronRight, X } from 'lucide-react';

interface MortgageUniverseViewProps {
  loans: Mortgage[];
}

export const MortgageUniverseView: React.FC<MortgageUniverseViewProps> = ({ loans }) => {
  const [search, setSearch] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('ALL');
  const [selectedRateType, setSelectedRateType] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [maxLtv, setMaxLtv] = useState<number>(100);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [selectedLoan, setSelectedLoan] = useState<Mortgage | null>(null);

  const pageSize = 20;

  // Filter logic
  const filteredLoans = useMemo(() => {
    return loans.filter(loan => {
      const matchesSearch =
        loan.id.toLowerCase().includes(search.toLowerCase()) ||
        loan.borrowerId.toLowerCase().includes(search.toLowerCase()) ||
        loan.province.toLowerCase().includes(search.toLowerCase());
      
      const matchesRegion = selectedRegion === 'ALL' || loan.region === selectedRegion;
      const matchesRate = selectedRateType === 'ALL' || loan.rateType === selectedRateType;
      const matchesStatus = selectedStatus === 'ALL' || loan.paymentStatus === selectedStatus;
      const matchesLtv = loan.ltv <= maxLtv;

      return matchesSearch && matchesRegion && matchesRate && matchesStatus && matchesLtv;
    });
  }, [loans, search, selectedRegion, selectedRateType, selectedStatus, maxLtv]);

  const totalPages = Math.ceil(filteredLoans.length / pageSize) || 1;
  const paginatedLoans = filteredLoans.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  // Filtered Summary Stats
  const totalFilteredBalance = filteredLoans.reduce((sum, l) => sum + l.currentBalance, 0);
  const avgFilteredLtv = filteredLoans.length ? filteredLoans.reduce((s, l) => s + l.ltv, 0) / filteredLoans.length : 0;
  const avgFilteredRate = filteredLoans.length ? filteredLoans.reduce((s, l) => s + l.interestRate, 0) / filteredLoans.length : 0;

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            UNIVERSO MUTUI IPOTECARI ITALIANI SINTETICI
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Database dei mutui residenziali individuali con caratteristiche di ammortamento, LTV, regione e classe di rischio
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#121826] border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">SELEZIONATI: </span>
            <span className="text-blue-400 font-bold">{filteredLoans.length.toLocaleString('it-IT')}</span>
            <span className="text-slate-500"> / {loans.length.toLocaleString('it-IT')}</span>
          </div>
          <div className="bg-[#121826] border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">CAPITALE: </span>
            <span className="text-emerald-400 font-bold">€ {(totalFilteredBalance / 1e6).toFixed(2)} MLN</span>
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs font-mono">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Cerca ID Mutuo, Codice o Prov..."
            value={search}
            onChange={e => { setSearch(e.target.value); setCurrentPage(1); }}
            className="w-full pl-8 pr-3 py-2 bg-[#0b0e17] border border-slate-800 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Region Filter */}
        <select
          value={selectedRegion}
          onChange={e => { setSelectedRegion(e.target.value); setCurrentPage(1); }}
          className="bg-[#0b0e17] border border-slate-800 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="ALL">Tutte le Regioni Italiane</option>
          <option value="Lombardia">Lombardia</option>
          <option value="Lazio">Lazio</option>
          <option value="Veneto">Veneto</option>
          <option value="Emilia-Romagna">Emilia-Romagna</option>
          <option value="Piemonte">Piemonte</option>
          <option value="Toscana">Toscana</option>
          <option value="Campania">Campania</option>
          <option value="Puglia">Puglia</option>
          <option value="Sicilia">Sicilia</option>
          <option value="Sardegna">Sardegna</option>
        </select>

        {/* Rate Type Filter */}
        <select
          value={selectedRateType}
          onChange={e => { setSelectedRateType(e.target.value); setCurrentPage(1); }}
          className="bg-[#0b0e17] border border-slate-800 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="ALL">Tutti i Tassi (Fisso & Variabile)</option>
          <option value="FISSO">Tasso Fisso</option>
          <option value="VARIABILE">Tasso Variabile</option>
        </select>

        {/* Status Filter */}
        <select
          value={selectedStatus}
          onChange={e => { setSelectedStatus(e.target.value); setCurrentPage(1); }}
          className="bg-[#0b0e17] border border-slate-800 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="ALL">Tutti gli Stati di Pagamento</option>
          <option value="IN_BONIS">In Bonis (Regolare)</option>
          <option value="ARRETRATO_30">Arretrato 30 giorni</option>
          <option value="ARRETRATO_60">Arretrato 60 giorni</option>
          <option value="ARRETRATO_90">Arretrato 90 giorni (Default)</option>
        </select>

        {/* LTV Slider */}
        <div className="flex flex-col justify-center bg-[#0b0e17] border border-slate-800 px-3 py-1 rounded">
          <div className="flex justify-between text-[11px] text-slate-400">
            <span>Max LTV:</span>
            <span className="font-bold text-amber-400">{maxLtv}%</span>
          </div>
          <input
            type="range"
            min="30"
            max="100"
            step="5"
            value={maxLtv}
            onChange={e => { setMaxLtv(Number(e.target.value)); setCurrentPage(1); }}
            className="w-full accent-blue-500 cursor-pointer h-1"
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-3">ID Mutuo</th>
                <th className="py-3 px-3">Regione / Prov</th>
                <th className="py-3 px-3 text-right">Saldo Attuale (€)</th>
                <th className="py-3 px-3 text-center">Tipo Tasso</th>
                <th className="py-3 px-3 text-right">Tasso (%)</th>
                <th className="py-3 px-3 text-right">Rata (€)</th>
                <th className="py-3 px-3 text-right">LTV (%)</th>
                <th className="py-3 px-3 text-right">LTI (%)</th>
                <th className="py-3 px-3 text-center">Rating</th>
                <th className="py-3 px-3 text-center">Stato</th>
                <th className="py-3 px-3 text-center">Azione</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {paginatedLoans.map(loan => (
                <tr key={loan.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-semibold text-blue-300">
                    {loan.id}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">
                    {loan.region} <span className="text-slate-500">({loan.province})</span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-medium text-white">
                    € {loan.currentBalance.toLocaleString('it-IT')}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      loan.rateType === 'FISSO' ? 'bg-indigo-950 text-indigo-300 border border-indigo-800' : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    }`}>
                      {loan.rateType}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-medium text-amber-300">
                    {loan.interestRate.toFixed(2)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200">
                    € {loan.monthlyPayment.toLocaleString('it-IT')}
                  </td>
                  <td className="py-2.5 px-3 text-right font-medium text-blue-300">
                    {loan.ltv}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300">
                    {loan.lti}%
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="font-bold text-slate-300">{loan.creditRating}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      loan.paymentStatus === 'IN_BONIS' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}>
                      {loan.paymentStatus === 'IN_BONIS' ? 'REGOLARE' : loan.paymentStatus}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => setSelectedLoan(loan)}
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 transition-colors"
                      title="Visualizza Dettagli Mutuo"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-3 border-t border-slate-800 bg-[#0b0e17] flex items-center justify-between text-xs font-mono text-slate-400">
          <div>
            Pagina <span className="text-white font-bold">{currentPage}</span> di <span className="text-white font-bold">{totalPages}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded bg-slate-800 disabled:opacity-40 hover:bg-slate-700 text-slate-200"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded bg-slate-800 disabled:opacity-40 hover:bg-slate-700 text-slate-200"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Loan Detail Modal */}
      {selectedLoan && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#121826] border border-slate-800 rounded-lg max-w-xl w-full p-6 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white font-display">
                  SCHEDA DETTAGLIATA MUTUO {selectedLoan.id}
                </h3>
                <p className="text-[11px] text-slate-400">Codice Debitore: {selectedLoan.borrowerId}</p>
              </div>
              <button
                onClick={() => setSelectedLoan(null)}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 bg-[#0b0e17] p-4 rounded border border-slate-800/80">
              <div>
                <span className="text-slate-500">Importo Originario:</span>
                <div className="text-sm font-bold text-white">€ {selectedLoan.originalAmount.toLocaleString('it-IT')}</div>
              </div>
              <div>
                <span className="text-slate-500">Saldo Residuo:</span>
                <div className="text-sm font-bold text-emerald-400">€ {selectedLoan.currentBalance.toLocaleString('it-IT')}</div>
              </div>
              <div>
                <span className="text-slate-500">Tipologia Tasso:</span>
                <div className="text-slate-200">{selectedLoan.rateType} ({selectedLoan.referenceIndex})</div>
              </div>
              <div>
                <span className="text-slate-500">Tasso d'Interesse:</span>
                <div className="text-amber-300 font-bold">{selectedLoan.interestRate.toFixed(2)}% (Spread {selectedLoan.spread}%)</div>
              </div>
              <div>
                <span className="text-slate-500">Rata Mensile:</span>
                <div className="text-slate-200">€ {selectedLoan.monthlyPayment.toLocaleString('it-IT')}</div>
              </div>
              <div>
                <span className="text-slate-500">Ammortamento:</span>
                <div className="text-slate-200">{selectedLoan.amortizationType} (Francese)</div>
              </div>
              <div>
                <span className="text-slate-500">LTV / LTI:</span>
                <div className="text-blue-300">{selectedLoan.ltv}% LTV / {selectedLoan.lti}% LTI</div>
              </div>
              <div>
                <span className="text-slate-500">Valore Immobile Stimato:</span>
                <div className="text-slate-200">€ {selectedLoan.propertyValue.toLocaleString('it-IT')}</div>
              </div>
              <div>
                <span className="text-slate-500">Ubicazione:</span>
                <div className="text-slate-200">{selectedLoan.region} ({selectedLoan.province}) - {selectedLoan.macroZone}</div>
              </div>
              <div>
                <span className="text-slate-500">Anzianità (Seasoning):</span>
                <div className="text-slate-200">{selectedLoan.seasoningMonths} mesi (Residuo: {selectedLoan.remainingTermMonths}m)</div>
              </div>
            </div>

            <div className="p-3 bg-blue-950/40 border border-blue-900/60 rounded text-[11px] text-blue-200">
              Probabilità di Default (PD) annua stimata dal modello: <strong className="text-amber-300">{selectedLoan.annualPD}%</strong>. Tasso di Recupero atteso (Net Recovery): <strong className="text-emerald-300">{selectedLoan.expectedRecoveryRate}%</strong>.
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSelectedLoan(null)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold text-xs transition-colors"
              >
                Chiudi Scheda
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
