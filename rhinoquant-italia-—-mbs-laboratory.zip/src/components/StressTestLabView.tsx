/**
 * @file StressTestLabView.tsx
 * RHINOQUANT ITALIA - Stress Test Laboratory & Tranche Loss Analytics
 */

import React, { useState } from 'react';
import { StressScenario, SecuritisationDeal, Pool } from '../types/mbs';
import { DEMO_STRESS_SCENARIOS } from '../utils/defaultData';
import { runMonthlyWaterfall } from '../utils/waterfallEngine';
import { Activity, Sliders, AlertCircle, ShieldAlert, ArrowDownRight } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface StressTestLabViewProps {
  deal: SecuritisationDeal;
  pool: Pool;
}

export const StressTestLabView: React.FC<StressTestLabViewProps> = ({ deal, pool }) => {
  const [selectedScenario, setSelectedScenario] = useState<StressScenario>(DEMO_STRESS_SCENARIOS[1]); // Recessione
  const [customHpi, setCustomHpi] = useState<number>(selectedScenario.housePriceShockPercent);
  const [customRateShift, setCustomRateShift] = useState<number>(selectedScenario.interestRateShiftBps);
  const [customPdMult, setCustomPdMult] = useState<number>(selectedScenario.pdMultiplier);

  // Active scenario object
  const activeScenario: StressScenario = {
    ...selectedScenario,
    housePriceShockPercent: customHpi,
    interestRateShiftBps: customRateShift,
    pdMultiplier: customPdMult
  };

  // Run waterfall for active scenario
  const flows = runMonthlyWaterfall({
    deal,
    pool,
    monthsCount: 180,
    scenario: activeScenario
  });

  const cumulativeLoss = flows.length > 0 ? flows[flows.length - 1].cumulativeLosses : 0;
  const lossPercent = (cumulativeLoss / deal.initialCollateralBalance) * 100;

  // Calculate loss allocation per tranche (Equity absorbs first -> Junior -> Mezzanine -> Senior)
  let remainingLoss = cumulativeLoss;

  const trancheLosses: Record<string, { lossAllocated: number; lossPercent: number }> = {};

  // Sort tranches Junior to Senior
  const sortedTranchesJuniorFirst = [...deal.tranches].sort((a, b) => a.subordination - b.subordination);

  sortedTranchesJuniorFirst.forEach(t => {
    if (remainingLoss > 0) {
      const lossForThisTranche = Math.min(t.originalPrincipal, remainingLoss);
      trancheLosses[t.id] = {
        lossAllocated: lossForThisTranche,
        lossPercent: (lossForThisTranche / t.originalPrincipal) * 100
      };
      remainingLoss -= lossForThisTranche;
    } else {
      trancheLosses[t.id] = { lossAllocated: 0, lossPercent: 0 };
    }
  });

  const chartData = deal.tranches.map(t => ({
    name: t.name,
    'Capitale Residuo': Math.round((t.originalPrincipal - (trancheLosses[t.id]?.lossAllocated || 0)) / 1e6),
    'Perdita Allocata': Math.round((trancheLosses[t.id]?.lossAllocated || 0) / 1e6)
  }));

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            LABORATORIO STRESS TEST & TRANCHE LOSS ANALYTICS
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Simulazione di scenari di stress macroeconomico, shock immobiliari, impennate dei tassi e propagazione delle perdite
          </p>
        </div>

        <div className="bg-[#121826] border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
          <Activity className="w-4 h-4 text-amber-400" />
          <span className="text-slate-300">PERDITA COLLATERALE CUMULATA: </span>
          <span className="font-bold text-rose-400">€ {cumulativeLoss.toLocaleString('it-IT')} ({lossPercent.toFixed(2)}%)</span>
        </div>
      </div>

      {/* Scenario Presets Selector Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {DEMO_STRESS_SCENARIOS.map(sc => {
          const isSelected = selectedScenario.id === sc.id;
          return (
            <button
              key={sc.id}
              onClick={() => {
                setSelectedScenario(sc);
                setCustomHpi(sc.housePriceShockPercent);
                setCustomRateShift(sc.interestRateShiftBps);
                setCustomPdMult(sc.pdMultiplier);
              }}
              className={`p-3 rounded border text-left transition-all ${
                isSelected
                  ? 'bg-blue-950/80 border-blue-500 text-white shadow-md'
                  : 'bg-[#121826] border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <div className="font-bold text-xs truncate">{sc.name}</div>
              <div className="text-[10px] text-slate-400 mt-1 line-clamp-2">{sc.description}</div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 1 Col: Scenario Sliders */}
        <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2 border-b border-slate-800 pb-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            CONTROLLI SHOCK MACROECONOMICO
          </h2>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Shock Immobiliare (Prezzi Immobili):</span>
              <span className="font-bold text-rose-400">{customHpi}%</span>
            </div>
            <input
              type="range"
              min="-30"
              max="20"
              step="5"
              value={customHpi}
              onChange={e => setCustomHpi(Number(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer h-1.5"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Shift Tassi d'Interesse (bps):</span>
              <span className="font-bold text-amber-400">+{customRateShift} bps</span>
            </div>
            <input
              type="range"
              min="-100"
              max="300"
              step="25"
              value={customRateShift}
              onChange={e => setCustomRateShift(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Moltiplicatore Default (PD):</span>
              <span className="font-bold text-blue-400">{customPdMult}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="4.0"
              step="0.25"
              value={customPdMult}
              onChange={e => setCustomPdMult(Number(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer h-1.5"
            />
          </div>

          <div className="p-3 bg-[#0b0e17] border border-slate-800 rounded text-[11px] text-slate-400 space-y-1">
            <div className="font-bold text-white uppercase">Meccanismo di Protezione delle Tranche</div>
            <p>
              Le perdite vengono assorbite prioritariamente dalla Tranche Equity (0-3%), poi dalla Junior C (3-7%), Mezzanine B (7-15%) e infine Senior A1/A2.
            </p>
          </div>
        </div>

        {/* Right 2 Cols: Loss Allocation Waterfall Chart & Table */}
        <div className="lg:col-span-2 bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-5">
          <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2 border-b border-slate-800 pb-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            PROPAGAZIONE ED ASSORBIMENTO PERDITE PER TRANCHE (€ Mln)
          </h2>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="Capitale Residuo" stackId="a" fill="#3b82f6" />
                <Bar dataKey="Perdita Allocata" stackId="a" fill="#f43f5e" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Loss Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Tranche</th>
                  <th className="py-2.5 px-3 text-right">Nominale (€)</th>
                  <th className="py-2.5 px-3 text-center">Subordinazione</th>
                  <th className="py-2.5 px-3 text-right">Perdita Allocata (€)</th>
                  <th className="py-2.5 px-3 text-right">Write-Down (%)</th>
                  <th className="py-2.5 px-3 text-center">Stato Tranche</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {deal.tranches.map(t => {
                  const loss = trancheLosses[t.id]?.lossAllocated || 0;
                  const lossPct = trancheLosses[t.id]?.lossPercent || 0;
                  return (
                    <tr key={t.id} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-white">{t.name}</td>
                      <td className="py-2.5 px-3 text-right text-slate-300">€ {t.originalPrincipal.toLocaleString('it-IT')}</td>
                      <td className="py-2.5 px-3 text-center text-blue-300">{t.subordination.toFixed(1)}%</td>
                      <td className="py-2.5 px-3 text-right font-bold text-rose-400">
                        € {loss.toLocaleString('it-IT')}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-rose-300">
                        {lossPct.toFixed(2)}%
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          lossPct === 0 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          lossPct < 100 ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}>
                          {lossPct === 0 ? 'INTEGRA' : lossPct < 100 ? 'IMPAIRED' : 'AZZERATA'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
