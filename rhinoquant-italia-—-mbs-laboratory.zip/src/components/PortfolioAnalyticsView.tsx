/**
 * @file PortfolioAnalyticsView.tsx
 * RHINOQUANT ITALIA - Portfolio Analytics & Tranche Portfolio Comparison Workbench
 */

import React from 'react';
import { PieChart, Sliders, ArrowRightLeft } from 'lucide-react';

export const PortfolioAnalyticsView: React.FC = () => {
  const portfolios = [
    {
      id: 'port_a',
      name: 'Portafoglio A — Focus Conservativo Senior',
      composition: '80% Senior A1 / 15% Senior A2 / 5% Mezzanine B',
      yield: '4.15%',
      wal: '3.65 Anni',
      duration: '3.38 Anni',
      expectedLoss: '0.04%',
      spread: '+88 bps',
      concentrationNord: '58.0%',
      var95: '€ 42.000.000',
      ratingMedio: 'AAA / AA+'
    },
    {
      id: 'port_b',
      name: 'Portafoglio B — Bilanciato Mezzanine Risk-Adjusted',
      composition: '40% Senior A2 / 40% Mezzanine B / 20% Junior C',
      yield: '5.28%',
      wal: '5.80 Anni',
      duration: '5.12 Anni',
      expectedLoss: '0.92%',
      spread: '+202 bps',
      concentrationNord: '52.0%',
      var95: '€ 128.000.000',
      ratingMedio: 'AA / A'
    },
    {
      id: 'port_c',
      name: 'Portafoglio C — Rendimento Elevato Junior & Equity',
      composition: '30% Mezzanine B / 50% Junior C / 20% Equity',
      yield: '8.45%',
      wal: '8.10 Anni',
      duration: '7.05 Anni',
      expectedLoss: '4.85%',
      spread: '+520 bps',
      concentrationNord: '45.0%',
      var95: '€ 310.000.000',
      ratingMedio: 'BBB / NR'
    }
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-xl font-display font-bold text-white tracking-wide">
          ANALISI E CONFRONTO DI PORTAFOGLI DI TRANCHE MBS
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Confronto quantitativo neutrale tra strutture di portafoglio senza raccomandazioni arbitrarie (Principii Istituzionali MiFID II)
        </p>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {portfolios.map(p => (
          <div key={p.id} className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="border-b border-slate-800 pb-3">
                <h2 className="text-sm font-bold text-white">{p.name}</h2>
                <span className="text-[10px] text-blue-300">{p.composition}</span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Rendimento Atteso (YTM):</span>
                  <span className="font-bold text-emerald-400 text-sm">{p.yield}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Spread Medio su Euribor:</span>
                  <span className="font-bold text-amber-300">{p.spread}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Vita Media Ponderata (WAL):</span>
                  <span className="text-slate-200">{p.wal}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Modified Duration:</span>
                  <span className="text-slate-200">{p.duration}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Perdita Attesa (Expected Loss):</span>
                  <span className="font-bold text-rose-400">{p.expectedLoss}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Value at Risk (VaR 95%):</span>
                  <span className="text-slate-200">{p.var95}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Esposizione Nord Italia:</span>
                  <span className="text-slate-300">{p.concentrationNord}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Rating Ponderato:</span>
                  <span className="font-bold text-blue-300">{p.ratingMedio}</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#0b0e17] border border-slate-800 rounded text-[11px] text-slate-400">
              Analisi quantitativa condotta tramite simulazione di cassa a 180 mesi. Nessun giudizio di preferenza espresso.
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
