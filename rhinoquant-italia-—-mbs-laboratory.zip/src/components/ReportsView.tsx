/**
 * @file ReportsView.tsx
 * RHINOQUANT ITALIA - Institutional Italian RMBS Research Report Viewer
 */

import React, { useState } from 'react';
import { SecuritisationDeal, Pool, TranchePricing, StressScenario } from '../types/mbs';
import { generateFullReportMarkdown } from '../utils/pdfReportGenerator';
import { FileText, Printer, Download, CheckCircle2 } from 'lucide-react';

interface ReportsViewProps {
  deal: SecuritisationDeal;
  pool: Pool;
  pricingResults: TranchePricing[];
  scenarios: StressScenario[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ deal, pool, pricingResults, scenarios }) => {
  const [copied, setCopied] = useState<boolean>(false);

  const reportMarkdown = generateFullReportMarkdown({
    deal,
    pool,
    pricing: pricingResults,
    scenarios,
    generatedDate: new Date().toISOString().split('T')[0]
  });

  const handlePrint = () => {
    window.print();
  };

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(reportMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto font-mono text-xs">
      {/* Title & Print Bar */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            RAPPORTO DI RICERCA QUANTITATIVA RMBS ISTITUZIONALE
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Documentazione tecnica completa e standardizzata per l'operazione {deal.dealName}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleCopyMarkdown}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded font-medium text-xs flex items-center gap-1.5 transition-colors"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Download className="w-4 h-4 text-blue-400" />}
            {copied ? 'Copiato!' : 'Copia Testo Markdown'}
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md"
          >
            <Printer className="w-4 h-4" />
            Stampa / Salva PDF
          </button>
        </div>
      </div>

      {/* Report Document Box */}
      <div className="bg-white text-slate-900 rounded-lg p-8 shadow-xl font-sans text-sm leading-relaxed max-w-[1000px] mx-auto print:p-0 print:shadow-none print:bg-transparent print:text-black">
        <div className="border-b border-slate-200 pb-6 mb-6 flex justify-between items-start">
          <div>
            <div className="text-xs font-bold text-blue-900 uppercase font-mono tracking-wider">
              RHINOQUANT ITALIA — LABORATOTIO RMBS
            </div>
            <h2 className="text-2xl font-display font-bold text-slate-900 mt-1">
              RAPPORTO DI RICERCA E STRUTTURAZIONE RMBS
            </h2>
            <div className="text-xs text-slate-500 font-mono mt-1">
              Operazione: {deal.dealName} ({deal.id})
            </div>
          </div>
          <div className="text-right text-xs font-mono text-slate-500">
            <div>Data: {new Date().toISOString().split('T')[0]}</div>
            <div>Versione: v2.4.1-ITALIA</div>
          </div>
        </div>

        {/* Markdown Rendered Content */}
        <div className="prose prose-slate max-w-none text-xs leading-relaxed space-y-4">
          <pre className="whitespace-pre-wrap font-sans text-slate-800 text-xs">
            {reportMarkdown}
          </pre>
        </div>
      </div>
    </div>
  );
};
