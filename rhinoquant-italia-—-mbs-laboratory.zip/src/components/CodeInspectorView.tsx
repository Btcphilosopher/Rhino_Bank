/**
 * @file CodeInspectorView.tsx
 * RHINOQUANT ITALIA - Code Inspector for Python, Rust, R, CLI & PostgreSQL Schema
 */

import React, { useState } from 'react';
import { Code2, Terminal, Database, Cpu, FileCode2, Copy, Check } from 'lucide-react';

export const CodeInspectorView: React.FC = () => {
  const [activeFile, setActiveFile] = useState<'python' | 'rust' | 'r' | 'cli' | 'sql' | 'docs'>('python');
  const [copied, setCopied] = useState<boolean>(false);

  const fileContents = {
    python: `# backend/app/main.py
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="RHINOQUANT ITALIA — MBS Laboratory API", version="2.4.1")

class WaterfallRunRequest(BaseModel):
    deal_id: str
    initial_balance: float
    reserve_target: float
    months_count: int = 180
    cpr_percent: float = 5.0

@app.post("/waterfall/run")
def run_waterfall_api(request: WaterfallRunRequest):
    return {
        "status": "OK",
        "months_simulated": request.months_count,
        "reconciliation_status": "PASSED",
        "max_discrepancy_euro": 0.00
    }`,

    rust: `// rust-engine/src/lib.rs
use pyo3::prelude::*;
use rand::prelude::*;
use rand_distr::Normal;

#[pyclass]
pub struct RustWaterfallEngine {
    initial_collateral: f64,
    wac: f64,
}

#[pymethods]
impl RustWaterfallEngine {
    pub fn run_monte_carlo_simulations(&self, runs: usize, seed: u64) -> PyResult<Vec<f64>> {
        let mut rng = StdRng::seed_from_u64(seed);
        let normal = Normal::new(0.0, 1.0).unwrap();
        let mut prices = Vec::with_capacity(runs);
        for _ in 0..runs {
            let z_rate: f64 = rng.sample(normal);
            let price = (100.0 + (z_rate * 0.5)).clamp(70.0, 105.0);
            prices.push(price);
        }
        Ok(prices)
    }
}`,

    r: `# r-analytics/mbs_curves.R
library(survival)

generate_default_curves <- function(ltv_vec, seasoning_months, base_cpr = 0.05) {
  time <- 1:180
  hazard_rates <- sapply(time, function(t) 0.0015 * (t / 24) * exp(-t / 48))
  survival_prob <- cumprod(1 - hazard_rates)
  return(data.frame(Mese = time, SurvivalProb = survival_prob))
}`,

    cli: `#!/usr/bin/env node
// cli/rhinoquant
import { runMonthlyWaterfall } from '../src/utils/waterfallEngine.js';

console.log("RHINOQUANT ITALIA CLI v2.4.1");
const flows = runMonthlyWaterfall({ deal: DEMO_DEAL, pool: DEMO_POOL, monthsCount: 180 });
console.log("[✓] Waterfall bilanciata:", flows[0].reconciliationCheck.isBalanced);`,

    sql: `-- backend/app/domain/db/schema.sql
CREATE TABLE IF NOT EXISTS pools (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    total_current_balance NUMERIC(18, 2) NOT NULL,
    wac NUMERIC(5, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS securitisations (
    id VARCHAR(64) PRIMARY KEY,
    deal_name VARCHAR(255) NOT NULL,
    initial_collateral_balance NUMERIC(18, 2) NOT NULL
);`,

    docs: `# RHINOQUANT ITALIA — DOCUMENTAZIONE METODOLOGICA
1. AMMORTAMENTO FRANCESE: R = P * [i * (1+i)^n] / [(1+i)^n - 1]
2. CONVERSIONE CPR -> SMM: SMM = 1 - (1 - CPR)^(1/12)
3. EXPECTED LOSS: EL = PD * LGD * EAD
4. DOUBLE-ENTRY RECONCILIATION: Opening + Inflows - Outflows - Losses = Closing`
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(fileContents[activeFile]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            ISPEZIONE CODICE SORGENTE & ARCHITETTURA ENGINE
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Visualizzazione dei file del backend Python 3.12, acceleratore Rust PyO3, script R, CLI ed il database PostgreSQL
          </p>
        </div>

        <button
          onClick={handleCopyCode}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded font-medium text-xs flex items-center gap-1.5 transition-colors"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-blue-400" />}
          {copied ? 'Copiato!' : 'Copia Codice'}
        </button>
      </div>

      {/* File Switcher Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-3">
        {[
          { id: 'python', label: 'Python Backend (FastAPI)', icon: FileCode2 },
          { id: 'rust', label: 'Rust Acceleration Engine (PyO3)', icon: Cpu },
          { id: 'r', label: 'R Analytics (Survival Curves)', icon: Code2 },
          { id: 'cli', label: 'CLI Tool (rhinoquant)', icon: Terminal },
          { id: 'sql', label: 'PostgreSQL DB Schema', icon: Database },
          { id: 'docs', label: 'Documentazione Metodologica', icon: FileCode2 }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeFile === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveFile(tab.id as any)}
              className={`px-3 py-1.5 rounded font-mono flex items-center gap-2 transition-all ${
                isActive
                  ? 'bg-blue-600 text-white font-bold shadow-md'
                  : 'bg-[#121826] text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Code Display Area */}
      <div className="bg-[#0b0e17] border border-slate-800 rounded-lg p-5 overflow-x-auto shadow-inner text-slate-300">
        <pre className="text-xs font-mono leading-relaxed text-blue-200">
          {fileContents[activeFile]}
        </pre>
      </div>
    </div>
  );
};
