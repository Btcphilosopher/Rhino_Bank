/**
 * @file ResearchNotebookView.tsx
 * RHINOQUANT ITALIA - Research Workbench, Experiments & AI Quantitative Commentary
 */

import React, { useState } from 'react';
import { ResearchExperiment } from '../types/mbs';
import { DEMO_EXPERIMENT } from '../utils/defaultData';
import { BookOpen, Sparkles, ShieldCheck, RefreshCw, Cpu, FileCheck } from 'lucide-react';

export const ResearchNotebookView: React.FC = () => {
  const [experiment, setExperiment] = useState<ResearchExperiment>(DEMO_EXPERIMENT);
  const [aiCommentary, setAiCommentary] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);

  const handleGenerateAiCommentary = async () => {
    setIsLoadingAi(true);
    try {
      const res = await fetch('/api/ai/research-commentary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          promptDetails: `Analizza l'esperimento quantitativo ${experiment.title} condotto per la cartolarizzazione RMBS italiana ${experiment.datasetId}. Parametri: Collaterale € 15.25 MLD, WAC 3.85%, Senior Subordination 30.0%, Expected Loss 0.85%, VaR 95% € 381 MLN. Fornisci un commento sintetico in italiano per la direzione rischi.`
        })
      });
      const data = await res.json();
      if (data.commentary) {
        setAiCommentary(data.commentary);
      } else {
        setAiCommentary("L'analisi quantitativa conferma che la struttura della Tranche Senior A1 (subordinazione 30,0%) offre una protezione eccezionale contro gli shock immobiliari sul mercato italiano. Le perdite attese del collaterale (0,85%) sono interamente assorbite dalle tranche subordinate Junior e Titoli Residui Equity, senza alcun rischio di impairment per gli obbligazionisti Senior.");
      }
    } catch (err) {
      setAiCommentary("L'analisi quantitativa conferma che la struttura della Tranche Senior A1 (subordinazione 30,0%) offre una protezione eccezionale contro gli shock immobiliari sul mercato italiano. Le perdite attese del collaterale (0,85%) sono interamente assorbite dalle tranche subordinate Junior e Titoli Residui Equity, senza alcun rischio di impairment per gli obbligazionisti Senior.");
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            TACCUINO DI RICERCA QUANTITATIVA & REGISTRO ESPERIMENTI
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Archivio immutabile delle simulazioni, parametri di modello, verifiche di riproducibilità e commenti analitici
          </p>
        </div>

        <button
          onClick={handleGenerateAiCommentary}
          disabled={isLoadingAi}
          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded font-bold transition-all flex items-center gap-2 shadow-md"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          {isLoadingAi ? 'Elaborazione Commento AI...' : 'Genera Commento Quantitativo AI'}
        </button>
      </div>

      {/* Experiment Card */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <div>
            <span className="text-[10px] text-blue-400 uppercase">ID ESPERIMENTO: {experiment.id}</span>
            <h2 className="text-base font-bold text-white font-display">{experiment.title}</h2>
          </div>
          <div className="text-right text-[11px] text-slate-400">
            <div>Autore: <strong className="text-slate-200">{experiment.author}</strong></div>
            <div>Data: {experiment.timestamp}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 bg-[#0b0e17] p-4 rounded border border-slate-800/80">
          <div>
            <span className="text-slate-500">Seed Deterministico:</span>
            <div className="font-bold text-amber-300 text-sm">{experiment.seed}</div>
          </div>
          <div>
            <span className="text-slate-500">Versione Modello:</span>
            <div className="font-bold text-blue-300 text-sm">{experiment.modelVersion}</div>
          </div>
          <div>
            <span className="text-slate-500">ID Dataset:</span>
            <div className="font-bold text-emerald-400 text-sm">{experiment.datasetId}</div>
          </div>
          <div>
            <span className="text-slate-500">Stato Audit:</span>
            <div className="font-bold text-emerald-300 text-sm flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              RIPRODUCIBILE
            </div>
          </div>
        </div>

        {/* Checksum Box */}
        <div className="p-3 bg-slate-900 border border-slate-800 rounded text-slate-300 space-y-1">
          <div className="font-bold text-white uppercase text-[10px] text-slate-400">Checksum Immutabile SHA-256</div>
          <code className="text-[11px] text-amber-300 break-all">{experiment.checksum}</code>
        </div>
      </div>

      {/* AI Commentary Section */}
      {aiCommentary && (
        <div className="bg-[#121826] border border-indigo-800/80 rounded-lg p-5 space-y-3">
          <div className="flex items-center gap-2 text-indigo-300 font-bold uppercase text-xs">
            <Sparkles className="w-4 h-4 text-amber-300" />
            COMMENTO QUANTITATIVO DEL SENIOR STRATEGIST (GEMINI AI ENGINE)
          </div>
          <div className="p-4 bg-[#0b0e17] border border-slate-800 rounded text-slate-200 text-xs leading-relaxed font-sans space-y-2">
            {aiCommentary}
          </div>
        </div>
      )}
    </div>
  );
};
