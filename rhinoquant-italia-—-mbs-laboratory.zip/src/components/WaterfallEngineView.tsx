/**
 * @file WaterfallEngineView.tsx
 * RHINOQUANT ITALIA - Priority of Payments Monthly Waterfall & Reconciliation Auditor
 */

import React, { useState } from 'react';
import { MonthlyWaterfallFlow, SecuritisationDeal } from '../types/mbs';
import { TrendingDown, ShieldCheck, CheckCircle2, ChevronLeft, ChevronRight, Search, FileSpreadsheet } from 'lucide-react';

interface WaterfallEngineViewProps {
  flows: MonthlyWaterfallFlow[];
  deal: SecuritisationDeal;
}

export const WaterfallEngineView: React.FC<WaterfallEngineViewProps> = ({ flows, deal }) => {
  const [selectedMonth, setSelectedMonth] = useState<number>(1);
  const [searchMonth, setSearchMonth] = useState<string>('');

  const currentFlow = flows.find(f => f.month === selectedMonth) || flows[0];

  const filteredFlows = flows.filter(f =>
    searchMonth === '' ? true : f.month.toString().includes(searchMonth) || f.date.includes(searchMonth)
  );

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            CASCATA DEGLI INCASSI & PRIORITY OF PAYMENTS WATERFALL
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Tracciamento mensile rigoroso dei flussi in entrata e in uscita con audit di riconciliazione contabile a doppia entrata
          </p>
        </div>

        {/* Audit Status Box */}
        <div className="bg-emerald-950/80 border border-emerald-800 px-3 py-1.5 rounded flex items-center gap-2 text-emerald-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>RICONCILIAZIONE A DOPPIA ENTRATA: OK (Errore = € 0,00)</span>
        </div>
      </div>

      {/* Selected Month Deep-Dive Audit Box */}
      {currentFlow && (
        <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
            <div className="flex items-center gap-3">
              <span className="text-base font-bold text-white font-display">
                MESE {currentFlow.month} ({currentFlow.date})
              </span>
              <span className="px-2 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded text-[10px]">
                SALDO COLLATERALE INIZIALE: € {currentFlow.openingCollateralBalance.toLocaleString('it-IT')}
              </span>
            </div>

            {/* Navigation Month Slider */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedMonth(m => Math.max(1, m - 1))}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-bold text-amber-300">{selectedMonth} / 180</span>
              <button
                onClick={() => setSelectedMonth(m => Math.min(flows.length, m + 1))}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Cash Inflows */}
            <div className="bg-[#0b0e17] border border-slate-800 p-4 rounded space-y-2">
              <div className="text-xs font-bold text-emerald-400 uppercase tracking-wide border-b border-slate-800 pb-2">
                1. INCASSI MENSILI (CASH INFLOW)
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Interessi Collaterale:</span>
                <span className="text-slate-200 font-bold">€ {currentFlow.interestCollections.toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Quota Capitale Ordinaria:</span>
                <span className="text-slate-200 font-bold">€ {currentFlow.principalCollections.toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Rimborso Anticipato (Prepayments):</span>
                <span className="text-slate-200 font-bold">€ {currentFlow.prepayments.toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Recuperi Sofferenze:</span>
                <span className="text-slate-200 font-bold">€ {currentFlow.recoveries.toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between pt-2 text-sm font-bold text-emerald-300">
                <span>TOTALE CASH INFLOW:</span>
                <span>€ {currentFlow.totalCashInflow.toLocaleString('it-IT')}</span>
              </div>
            </div>

            {/* Cash Outflows */}
            <div className="bg-[#0b0e17] border border-slate-800 p-4 rounded space-y-2">
              <div className="text-xs font-bold text-blue-400 uppercase tracking-wide border-b border-slate-800 pb-2">
                2. PAGAMENTI CASCATA WATERFALL (CASH OUTFLOW)
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">1. Spese SPV & Servicing:</span>
                <span className="text-slate-200">€ {(currentFlow.seniorExpenses + currentFlow.servicingFees).toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">2. Interessi Tranche Senior & Mezzanine:</span>
                <span className="text-slate-200">€ {Object.values(currentFlow.trancheInterestPayments).reduce((a, b) => a + b, 0).toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">3. Capitale Ammortamento Tranche:</span>
                <span className="text-slate-200">€ {Object.values(currentFlow.tranchePrincipalPayments).reduce((a, b) => a + b, 0).toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">4. Ripristino Conto Riserva:</span>
                <span className="text-slate-200">€ {currentFlow.reserveAccountReplenishment.toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">5. Excess Spread & Equity:</span>
                <span className="text-slate-200">€ {(currentFlow.excessSpread + currentFlow.equityDistribution).toLocaleString('it-IT')}</span>
              </div>
              <div className="flex justify-between pt-2 text-sm font-bold text-blue-300">
                <span>TOTALE CASH OUTFLOW:</span>
                <span>€ {currentFlow.totalCashOutflow.toLocaleString('it-IT')}</span>
              </div>
            </div>
          </div>

          {/* Double-Entry Style Cash Flow Reconciliation Verification */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded space-y-1.5 text-slate-300">
            <div className="font-bold text-white uppercase text-[11px] tracking-wide flex items-center justify-between">
              <span>Riconciliazione Contabile a Doppia Entrata (Double-Entry Verification)</span>
              <span className="text-emerald-400">SCARTO = € 0,00</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Formula: Opening Balance (€ {currentFlow.openingCollateralBalance.toLocaleString('it-IT')}) + Cash Inflow (€ {currentFlow.totalCashInflow.toLocaleString('it-IT')}) − Outflows (€ {currentFlow.totalCashOutflow.toLocaleString('it-IT')}) − Defaults Gross (€ {currentFlow.defaults.toLocaleString('it-IT')}) = Closing Collateral (€ {currentFlow.closingCollateralBalance.toLocaleString('it-IT')}).
            </p>
          </div>
        </div>
      )}

      {/* Waterfall Monthly History Data Grid */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            REGISTRO STORICO DELLE MENSILITÀ (180 MESI)
          </h2>
          <div className="relative w-60">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Filtra mese..."
              value={searchMonth}
              onChange={e => setSearchMonth(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-[#0b0e17] border border-slate-800 rounded text-slate-200 placeholder-slate-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto max-h-[400px]">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] sticky top-0 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Mese</th>
                <th className="py-2.5 px-3 text-right">Saldo Iniziale (€)</th>
                <th className="py-2.5 px-3 text-right">Interessi Incassati (€)</th>
                <th className="py-2.5 px-3 text-right">Capitale Iniziale (€)</th>
                <th className="py-2.5 px-3 text-right">Prepayments (€)</th>
                <th className="py-2.5 px-3 text-right">Default (€)</th>
                <th className="py-2.5 px-3 text-right">Senior A1 Int (€)</th>
                <th className="py-2.5 px-3 text-right">Senior A1 Prin (€)</th>
                <th className="py-2.5 px-3 text-right">Saldo Finale (€)</th>
                <th className="py-2.5 px-3 text-center">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredFlows.slice(0, 30).map(f => (
                <tr
                  key={f.month}
                  onClick={() => setSelectedMonth(f.month)}
                  className={`cursor-pointer transition-colors ${
                    f.month === selectedMonth ? 'bg-blue-950/60 border-l-2 border-blue-500' : 'hover:bg-slate-800/40'
                  }`}
                >
                  <td className="py-2 px-3 font-bold text-blue-300">M{f.month}</td>
                  <td className="py-2 px-3 text-right text-slate-300">€ {f.openingCollateralBalance.toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right text-emerald-400">€ {f.interestCollections.toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right text-slate-300">€ {f.principalCollections.toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right text-amber-300">€ {f.prepayments.toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right text-rose-400">€ {f.defaults.toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right text-slate-300">€ {(f.trancheInterestPayments['TR-A1'] || 0).toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right text-blue-300">€ {(f.tranchePrincipalPayments['TR-A1'] || 0).toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-right font-bold text-white">€ {f.closingCollateralBalance.toLocaleString('it-IT')}</td>
                  <td className="py-2 px-3 text-center">
                    <span className="text-emerald-400 font-bold">OK</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
