/**
 * @file MonteCarloView.tsx
 * RHINOQUANT ITALIA - Stochastic Monte Carlo Simulation & Risk Analytics Engine
 */

import React, { useState } from 'react';
import { SecuritisationDeal, Pool, MonteCarloResult } from '../types/mbs';
import { runMonteCarloSimulation } from '../utils/monteCarloEngine';
import { Dices, Play, Cpu, ShieldAlert, BarChart2 } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface MonteCarloViewProps {
  deal: SecuritisationDeal;
  pool: Pool;
}

export const MonteCarloView: React.FC<MonteCarloViewProps> = ({ deal, pool }) => {
  const [simulationsCount, setSimulationsCount] = useState<number>(1000);
  const [seed, setSeed] = useState<number>(42);
  const [mcResult, setMcResult] = useState<MonteCarloResult | null>(() =>
    runMonteCarloSimulation({ deal, pool, simulationsCount: 1000, seed: 42 })
  );
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = runMonteCarloSimulation({ deal, pool, simulationsCount, seed });
      setMcResult(res);
      setIsRunning(false);
    }, 100);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            SIMULAZIONE STOCASTICA MONTE CARLO (1.000+ PERCORSI)
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Generazione stocastica tramite trasformata di Box-Muller per stimare la distribuzione dei prezzi, VaR 95/99% e CVaR (Expected Shortfall)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#121826] border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">TEMPO DI ESECUZIONE: </span>
            <span className="font-bold text-emerald-400">{mcResult ? `${mcResult.executionTimeMs} ms` : '-'}</span>
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={isRunning}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded font-bold transition-colors flex items-center gap-2 shadow-md"
          >
            <Play className="w-4 h-4 fill-white" />
            {isRunning ? 'Calcolo Stocastico...' : 'Lancia Simulazione Monte Carlo'}
          </button>
        </div>
      </div>

      {/* Control Configuration Bar */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="text-slate-400">Numero di Simulazioni Stocastiche:</label>
          <select
            value={simulationsCount}
            onChange={e => setSimulationsCount(Number(e.target.value))}
            className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-amber-300 font-bold mt-1 focus:outline-none"
          >
            <option value="500">500 Percorsi (Rapido)</option>
            <option value="1000">1.000 Percorsi (Istituzionale Standard)</option>
            <option value="2500">2.500 Percorsi (Alta Precisione)</option>
            <option value="5000">5.000 Percorsi (Stress Estremo)</option>
          </select>
        </div>

        <div>
          <label className="text-slate-400">Seed del Generatore Pseudo-Random:</label>
          <input
            type="number"
            value={seed}
            onChange={e => setSeed(Number(e.target.value) || 42)}
            className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-white font-bold mt-1 focus:outline-none"
          />
        </div>

        <div className="flex items-center text-slate-400 text-[11px] pt-4">
          Variabili stocastiche simulate: Tassi d'interesse (Euribor), Prepayment (CPR), Default Rate (PD) e Prezzi delle Abitazioni (HPI).
        </div>
      </div>

      {/* Main Results Grid */}
      {mcResult && (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
              <div className="text-xs text-slate-400 uppercase font-mono">Prezzo Atteso Portafoglio</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                {mcResult.expectedPortfolioPrice.toFixed(2)}%
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                % del Valore Par
              </div>
            </div>

            <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
              <div className="text-xs text-slate-400 uppercase font-mono">Value at Risk 95% (VaR 95%)</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
                € {mcResult.var95Euro.toLocaleString('it-IT')}
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                Rischio Coda 5%: {mcResult.var95Percent.toFixed(2)}%
              </div>
            </div>

            <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
              <div className="text-xs text-slate-400 uppercase font-mono">Expected Shortfall (CVaR 95%)</div>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
                € {mcResult.cvar95Euro.toLocaleString('it-IT')}
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                Perdita media oltre VaR: {mcResult.cvar95Percent.toFixed(2)}%
              </div>
            </div>

            <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
              <div className="text-xs text-slate-400 uppercase font-mono">Perdita Attesa Cumulata</div>
              <div className="text-2xl font-bold font-mono text-blue-400 mt-1">
                € {mcResult.expectedLossEuro.toLocaleString('it-IT')}
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                Expected Loss Rate: {mcResult.expectedLossPercent.toFixed(2)}%
              </div>
            </div>
          </div>

          {/* Price Distribution Histogram Chart & Tranche Impairment Table */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-3">
              <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2 border-b border-slate-800 pb-2">
                <BarChart2 className="w-4 h-4 text-blue-400" />
                DISTRIBUZIONE DI FREQUENZA DEL PREZZO DEL PORTAFOGLIO (% PAR)
              </h2>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mcResult.priceHistogram} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <XAxis dataKey="priceBin" stroke="#64748b" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                    />
                    <Bar dataKey="frequency" name="Conteggio Percorsi" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Tranche Impairment Table */}
            <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
              <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2 border-b border-slate-800 pb-2">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                PROBABILITÀ DI IMPAIRMENT PER TRANCHE
              </h2>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">Tranche</th>
                      <th className="py-2.5 px-3 text-right">Prob. Impairment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {deal.tranches.map(t => {
                      const prob = mcResult.trancheImpairmentProbabilities[t.id] || 0;
                      return (
                        <tr key={t.id} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-3 font-semibold text-white">{t.name}</td>
                          <td className="py-2.5 px-3 text-right font-bold">
                            <span className={`px-2 py-0.5 rounded ${
                              prob < 1 ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800' :
                              prob < 10 ? 'text-amber-300 bg-amber-950/60 border border-amber-800' : 'text-rose-400 bg-rose-950/60 border border-rose-800'
                            }`}>
                              {prob.toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
