/**
 * @file PricingWorkbenchView.tsx
 * RHINOQUANT ITALIA - MBS Pricing Workbench & OAS Engine
 */

import React, { useState } from 'react';
import { TranchePricing, SecuritisationDeal } from '../types/mbs';
import { Calculator, TrendingUp, BarChart2, Zap, HelpCircle } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { DEFAULT_ITALIAN_YIELD_CURVE } from '../utils/mathEngine';

interface PricingWorkbenchViewProps {
  pricingResults: TranchePricing[];
  deal: SecuritisationDeal;
}

export const PricingWorkbenchView: React.FC<PricingWorkbenchViewProps> = ({ pricingResults, deal }) => {
  const [rateShiftBps, setRateShiftBps] = useState<number>(0);

  // Apply rate shift to yield curve for display
  const shiftedYieldCurve = DEFAULT_ITALIAN_YIELD_CURVE.map(pt => ({
    ...pt,
    euriborRate: Number((pt.euriborRate + rateShiftBps / 100).toFixed(2)),
    irsRate: Number((pt.irsRate + rateShiftBps / 100).toFixed(2))
  }));

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            MBS PRICING WORKBENCH & OAS ENGINE
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Valutazione del prezzo, rendimento (YTM), Option-Adjusted Spread (OAS), Duration modificata, Convessità, DV01 e CS01
          </p>
        </div>

        {/* Rate Shift Controller */}
        <div className="bg-[#121826] border border-slate-800 px-3 py-1.5 rounded flex items-center gap-3">
          <span className="text-slate-400">SHIFT CURVA TASSI:</span>
          <select
            value={rateShiftBps}
            onChange={e => setRateShiftBps(Number(e.target.value))}
            className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 text-amber-300 font-bold focus:outline-none"
          >
            <option value="-100">-100 bps (Ribasso Tassi)</option>
            <option value="-50">-50 bps</option>
            <option value="0">0 bps (Curva Nominale)</option>
            <option value="50">+50 bps</option>
            <option value="100">+100 bps (Rialzo Tassi)</option>
            <option value="200">+200 bps (Shock Severo)</option>
          </select>
        </div>
      </div>

      {/* Yield Curves Chart */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-3">
        <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-blue-400" />
          CURVA DEI TASSI DI RIFERIMENTO ITALIANA (EURIBOR vs IRS)
        </h2>
        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={shiftedYieldCurve} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <XAxis dataKey="tenor" stroke="#64748b" tick={{ fontSize: 10 }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 10 }} domain={['dataMin - 0.5', 'dataMax + 0.5']} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                formatter={(val: any) => `${val}%`}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Line type="monotone" dataKey="euriborRate" name="Euribor Curve (%)" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="irsRate" name="IRS Swap Curve (%)" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="riskFreeRate" name="Risk Free BTP Proxy (%)" stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="3 3" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Main Pricing Table */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
        <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2 border-b border-slate-800 pb-3">
          <Calculator className="w-4 h-4 text-amber-400" />
          PROSPETTO DI PRICING & SENSIBILITÀ PER TRANCHE
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Tranche</th>
                <th className="py-2.5 px-3 text-right">Prezzo (% Par)</th>
                <th className="py-2.5 px-3 text-right">YTM (%)</th>
                <th className="py-2.5 px-3 text-right">Discount Margin</th>
                <th className="py-2.5 px-3 text-right">OAS (bps)</th>
                <th className="py-2.5 px-3 text-right">Mod. Duration (Anni)</th>
                <th className="py-2.5 px-3 text-right">Spread Duration</th>
                <th className="py-2.5 px-3 text-right">Convexity</th>
                <th className="py-2.5 px-3 text-right">DV01 (€/bp)</th>
                <th className="py-2.5 px-3 text-right">CS01 (€/bp)</th>
                <th className="py-2.5 px-3 text-right">WAL (Anni)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {pricingResults.map(p => {
                // Apply rate shift adjustment to price
                const adjustedPrice = Math.max(50, p.price - (p.modifiedDuration * (rateShiftBps / 100)));
                return (
                  <tr key={p.trancheId} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-semibold text-white">
                      {p.trancheName}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-amber-300">
                      {adjustedPrice.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold text-emerald-400">
                      {(p.yieldToMaturity + rateShiftBps / 100).toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      +{p.discountMarginBps} bps
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-blue-300">
                      {p.oasBps} bps
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {p.modifiedDuration.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {p.spreadDuration.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-400">
                      {p.convexity.toFixed(4)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-indigo-300 font-medium">
                      € {p.dv01.toLocaleString('it-IT')}
                    </td>
                    <td className="py-2.5 px-3 text-right text-purple-300 font-medium">
                      € {p.cs01.toLocaleString('it-IT')}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {p.wal.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Static Pricing vs OAS Comparison Box */}
      <div className="p-4 bg-[#121826] border border-slate-800 rounded space-y-2 text-slate-300">
        <div className="font-bold text-white uppercase text-[11px] tracking-wide flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" />
          DIFFERENZA TRA PRICING STATICO ED OPTION-ADJUSTED SPREAD (OAS)
        </div>
        <p className="text-[11px] text-slate-400">
          Il <strong>Pricing Statico</strong> calcola il valore attuale attualizzando i flussi deterministici ad una curva deterministica. L'<strong>Option-Adjusted Spread (OAS)</strong> sconta il valore dell'opzione di rimborso anticipato (Prepayment Option) concessa al mutuatario residenziale italiano ex L. 40/2007 (Legge Bersani), isolando il puro premio per il rischio di credito e liquidità.
        </p>
      </div>
    </div>
  );
};
