/**
 * @file DealStructuringView.tsx
 * RHINOQUANT ITALIA - Securitisation SPV Structuring & Tranche Engine View
 */

import React, { useState } from 'react';
import { SecuritisationDeal, Tranche } from '../types/mbs';
import { Layers, Plus, Trash2, Save, ShieldCheck, AlertTriangle } from 'lucide-react';

interface DealStructuringViewProps {
  deal: SecuritisationDeal;
  onUpdateDeal: (updatedDeal: SecuritisationDeal) => void;
}

export const DealStructuringView: React.FC<DealStructuringViewProps> = ({ deal, onUpdateDeal }) => {
  const [tranches, setTranches] = useState<Tranche[]>(deal.tranches);
  const [reserveBalance, setReserveBalance] = useState<number>(deal.reserveAccountBalance);
  const [servicingFee, setServicingFee] = useState<number>(deal.servicingFeeRate);
  const [allocationMode, setAllocationMode] = useState<'SEQUENTIAL' | 'PRO_RATA'>(deal.principalAllocationMode);
  const [saved, setSaved] = useState<boolean>(false);

  const totalTranchePrincipal = tranches.reduce((sum, t) => sum + t.originalPrincipal, 0);
  const totalCollateral = deal.initialCollateralBalance;
  const discrepancy = Math.abs(totalCollateral - totalTranchePrincipal);

  const handleUpdateTranche = (id: string, field: keyof Tranche, value: any) => {
    setTranches(prev =>
      prev.map(t => {
        if (t.id === id) {
          const updated = { ...t, [field]: value };
          if (field === 'originalPrincipal') {
            updated.currentPrincipal = value;
          }
          return updated;
        }
        return t;
      })
    );
  };

  const handleSaveStructure = () => {
    const updatedDeal: SecuritisationDeal = {
      ...deal,
      reserveAccountBalance: reserveBalance,
      reserveAccountTarget: reserveBalance,
      servicingFeeRate: servicingFee,
      principalAllocationMode: allocationMode,
      tranches
    };
    onUpdateDeal(updatedDeal);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            STRUTTURAZIONE DELL'OPERAZIONE SPV & TRANCHE ENGINE
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Definizione dell'architettura di cartolarizzazione, subordinazione, conto di riserva e priorità dei pagamenti
          </p>
        </div>

        {saved && (
          <div className="bg-emerald-950/80 text-emerald-300 border border-emerald-800 px-3 py-1.5 rounded flex items-center gap-2">
            <ShieldCheck className="w-4 h-4" />
            STRUTTURA SPV SALVATA CON SUCCESSO
          </div>
        )}
      </div>

      {/* Validation Banner */}
      <div className={`p-4 rounded border flex items-center justify-between ${
        discrepancy < 1000 ? 'bg-emerald-950/40 border-emerald-800 text-emerald-200' : 'bg-amber-950/40 border-amber-800 text-amber-200'
      }`}>
        <div className="flex items-center gap-2">
          {discrepancy < 1000 ? <ShieldCheck className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-amber-400" />}
          <div>
            <div className="font-bold">BILANCIAMENTO STRUTTURA CARTOLARIZZAZIONE</div>
            <div className="text-[11px] opacity-80">
              Valore Collaterale: € {totalCollateral.toLocaleString('it-IT')} | Somma Tranches: € {totalTranchePrincipal.toLocaleString('it-IT')}
            </div>
          </div>
        </div>
        <div className="text-right font-bold text-sm">
          {discrepancy < 1000 ? 'EQUILIBRIO PERFETTO (100%)' : `Scarto: € ${discrepancy.toLocaleString('it-IT')}`}
        </div>
      </div>

      {/* Global SPV Parameters */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
        <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          PARAMETRI GENERALI SPV & RISERVE
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="text-slate-400">Conto di Riserva Target (€):</label>
            <input
              type="number"
              value={reserveBalance}
              onChange={e => setReserveBalance(Number(e.target.value))}
              className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-white font-bold mt-1 focus:outline-none"
            />
            <span className="text-[10px] text-slate-500">2,5% del Collaterale</span>
          </div>

          <div>
            <label className="text-slate-400">Commissioni Servicing (%):</label>
            <input
              type="number"
              step="0.01"
              value={servicingFee}
              onChange={e => setServicingFee(Number(e.target.value))}
              className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-white font-bold mt-1 focus:outline-none"
            />
            <span className="text-[10px] text-slate-500">Su base annua</span>
          </div>

          <div>
            <label className="text-slate-400">Modalità Ammortamento Capitale:</label>
            <select
              value={allocationMode}
              onChange={e => setAllocationMode(e.target.value as any)}
              className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-blue-300 font-bold mt-1 focus:outline-none"
            >
              <option value="SEQUENTIAL">Sequenziale (Senior First)</option>
              <option value="PRO_RATA">Pro-Rata (Tutte le Tranche)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400">Excess Spread Target (%):</label>
            <div className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-emerald-400 font-bold mt-1">
              1,20% p.a.
            </div>
          </div>
        </div>
      </div>

      {/* Tranches Table Editor */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <h2 className="text-sm font-bold text-white uppercase tracking-wide">
            CONFIGURAZIONE TRANCHE OBBLIGAZIONARIE
          </h2>
          <button
            onClick={handleSaveStructure}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold transition-colors flex items-center gap-1.5 text-xs shadow-md"
          >
            <Save className="w-4 h-4" />
            Salva Struttura SPV
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Nome Tranche</th>
                <th className="py-2.5 px-3 text-right">Valore Nominale (€)</th>
                <th className="py-2.5 px-3 text-center">Subordinazione (%)</th>
                <th className="py-2.5 px-3 text-center">Tipo Coupon</th>
                <th className="py-2.5 px-3 text-center">Spread (bps)</th>
                <th className="py-2.5 px-3 text-center">Rating Target</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {tranches.map(t => (
                <tr key={t.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3">
                    <input
                      type="text"
                      value={t.name}
                      onChange={e => handleUpdateTranche(t.id, 'name', e.target.value)}
                      className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 text-white font-semibold w-56 focus:outline-none"
                    />
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <input
                      type="number"
                      value={t.originalPrincipal}
                      onChange={e => handleUpdateTranche(t.id, 'originalPrincipal', Number(e.target.value))}
                      className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 text-right text-emerald-400 font-bold w-40 focus:outline-none"
                    />
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <input
                      type="number"
                      value={t.subordination}
                      onChange={e => handleUpdateTranche(t.id, 'subordination', Number(e.target.value))}
                      className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 text-center text-blue-300 w-20 focus:outline-none"
                    />
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <select
                      value={t.couponType}
                      onChange={e => handleUpdateTranche(t.id, 'couponType', e.target.value)}
                      className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 text-slate-200 focus:outline-none"
                    >
                      <option value="VARIABILE">VARIABILE</option>
                      <option value="FISSO">FISSO</option>
                    </select>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <input
                      type="number"
                      value={t.spreadBps}
                      onChange={e => handleUpdateTranche(t.id, 'spreadBps', Number(e.target.value))}
                      className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 text-center text-amber-300 font-bold w-24 focus:outline-none"
                    />
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <select
                      value={t.rating}
                      onChange={e => handleUpdateTranche(t.id, 'rating', e.target.value)}
                      className="bg-[#0b0e17] border border-slate-800 rounded px-2 py-1 font-bold text-slate-200 focus:outline-none"
                    >
                      <option value="AAA">AAA</option>
                      <option value="AA">AA</option>
                      <option value="A">A</option>
                      <option value="BBB">BBB</option>
                      <option value="BB">BB</option>
                      <option value="B">B</option>
                      <option value="NR">NR</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
