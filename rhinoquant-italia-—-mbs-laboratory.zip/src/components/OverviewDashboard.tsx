/**
 * @file OverviewDashboard.tsx
 * RHINOQUANT ITALIA - Executive Quantitative Terminal Overview
 */

import React from 'react';
import { Pool, SecuritisationDeal, MonthlyWaterfallFlow, TranchePricing } from '../types/mbs';
import { Layers, ShieldCheck, ArrowRight, TrendingUp, DollarSign, Activity, FileCheck, ArrowUpRight } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';

interface OverviewDashboardProps {
  pool: Pool;
  deal: SecuritisationDeal;
  waterfallFlows: MonthlyWaterfallFlow[];
  pricingResults: TranchePricing[];
  onNavigate: (tab: string) => void;
}

const REGION_COLORS = ['#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4', '#64748b'];

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  pool,
  deal,
  waterfallFlows,
  pricingResults,
  onNavigate
}) => {
  // Chart data for first 24 months cash flows
  const cashFlowChartData = waterfallFlows.slice(0, 24).map(f => ({
    mese: `M${f.month}`,
    Interessi: Math.round(f.interestCollections / 1000000),
    Capitale: Math.round(f.principalCollections / 1000000),
    Prepayments: Math.round(f.prepayments / 1000000),
    Recuperi: Math.round(f.recoveries / 1000000)
  }));

  // Geographic pie data
  const geoPieData = Object.entries(pool.geographicDistribution)
    .filter(([key]) => ['NORD', 'CENTRO', 'SUD', 'ISOLE'].includes(key))
    .map(([name, value]) => ({ name, value }));

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Top Banner / Pipeline Chain Indicator */}
      <div className="bg-[#121826] border border-slate-800 rounded-lg p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-3">
          <div>
            <h1 className="text-xl font-display font-bold text-white tracking-wide">
              {deal.dealName}
            </h1>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Cartolarizzazione Ipotecaria Residenziale Italiana (RMBS) · SPV Veicolo ex L. 130/99
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded text-xs font-mono bg-blue-950/80 text-blue-300 border border-blue-800/60">
              EMISSIONE: 2026-10-03
            </span>
            <span className="px-2.5 py-1 rounded text-xs font-mono bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              DOUBLE-ENTRY RECONCILED
            </span>
          </div>
        </div>

        {/* Workflow Chain Nodes */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-xs font-mono pt-3 border-t border-slate-800">
          {[
            { label: 'MUTUI SINTETICI', val: '100.000 Mutui', step: 'universe' },
            { label: 'POOL COLLATERALE', val: `€ ${(pool.totalCurrentBalance / 1e9).toFixed(2)} MLD`, step: 'pool' },
            { label: 'STRUTTURA SPV', val: `${deal.tranches.length} Tranche`, step: 'deal' },
            { label: 'CASCATA WATERFALL', val: '180 Mensilità', step: 'waterfall' },
            { label: 'PRICING & OAS', val: 'WAC 3.85%', step: 'pricing' },
            { label: 'RISCHIO & MONTE CARLO', val: '1.000 Scenari', step: 'montecarlo' },
          ].map((item, idx) => (
            <button
              key={idx}
              onClick={() => onNavigate(item.step)}
              className="bg-[#0b0e17] hover:bg-slate-800/80 border border-slate-800 p-2 rounded text-left transition-all group"
            >
              <div className="text-[10px] text-slate-400 flex items-center justify-between">
                <span>0{idx + 1}. {item.label}</span>
                <ArrowUpRight className="w-3 h-3 text-slate-400 group-hover:text-blue-400 transition-colors" />
              </div>
              <div className="text-sm font-semibold text-blue-300 mt-1">{item.val}</div>
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase font-mono">Valore Collaterale</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            € {(pool.totalCurrentBalance / 1e9).toFixed(2)} <span className="text-base text-slate-400 font-sans">MLD</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            100.000 Mutui Residenziali
          </div>
        </div>

        <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase font-mono">Tasso Medio Ponderato (WAC)</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            {pool.wac.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Fisso {pool.fixedRatePercentage}% / Var {pool.variableRatePercentage}%
          </div>
        </div>

        <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase font-mono">LTV Medio Ponderato</div>
          <div className="text-2xl font-bold font-mono text-blue-400 mt-1">
            {pool.waLtv.toFixed(1)}%
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            LTI Ponderato: {pool.waLti.toFixed(1)}%
          </div>
        </div>

        <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase font-mono">Vita Media Ponderata (WAL)</div>
          <div className="text-2xl font-bold font-mono text-indigo-400 mt-1">
            {pool.wal.toFixed(2)} <span className="text-base text-slate-400 font-sans">Anni</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            WAM: {pool.wam} mesi ({ (pool.wam/12).toFixed(1) } anni)
          </div>
        </div>

        <div className="bg-[#121826] border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase font-mono">Credit Enhancement Senior</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            30,0%
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Subordinazione + Riserva 2,5%
          </div>
        </div>
      </div>

      {/* Main Content Grid: Tranches Table + Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Tranche Structure & Pricing Table */}
        <div className="lg:col-span-2 bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white uppercase font-mono tracking-wide flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-400" />
                STRUTTURA DELLE TRANCHE & PRICING SPV
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Prospetto delle emissioni obbligazionarie, rating, subordinazione e rendimenti calcolati
              </p>
            </div>
            <button
              onClick={() => onNavigate('pricing')}
              className="text-xs font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1 hover:underline"
            >
              Apri Pricing Workbench <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0b0e17] text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Tranche</th>
                  <th className="py-2.5 px-3 text-right">Valore Nominale (€)</th>
                  <th className="py-2.5 px-3 text-center">Quota</th>
                  <th className="py-2.5 px-3 text-center">Rating</th>
                  <th className="py-2.5 px-3 text-center">Spread</th>
                  <th className="py-2.5 px-3 text-right">Prezzo (% Par)</th>
                  <th className="py-2.5 px-3 text-right">YTM (%)</th>
                  <th className="py-2.5 px-3 text-right">WAL (Anni)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {deal.tranches.map(t => {
                  const pricing = pricingResults.find(p => p.trancheId === t.id);
                  const share = ((t.originalPrincipal / deal.initialCollateralBalance) * 100).toFixed(1);
                  return (
                    <tr key={t.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 font-semibold text-white flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${
                          t.rating === 'AAA' ? 'bg-emerald-400' :
                          t.rating.startsWith('A') ? 'bg-blue-400' :
                          t.rating === 'BBB' ? 'bg-amber-400' : 'bg-rose-500'
                        }`} />
                        {t.name}
                      </td>
                      <td className="py-2.5 px-3 text-right font-medium text-slate-200">
                        € {t.originalPrincipal.toLocaleString('it-IT')}
                      </td>
                      <td className="py-2.5 px-3 text-center text-slate-300">
                        {share}%
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          t.rating === 'AAA' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          t.rating.startsWith('A') ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                          t.rating === 'BBB' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}>
                          {t.rating}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-center text-slate-300">
                        +{t.spreadBps} bps
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-amber-300">
                        {pricing ? `${pricing.price.toFixed(2)}%` : '100.00%'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-semibold text-emerald-400">
                        {pricing ? `${pricing.yieldToMaturity.toFixed(2)}%` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-300">
                        {pricing ? `${pricing.wal.toFixed(2)}` : t.wal}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Cash Flow Waterfall Chart */}
          <div className="pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase">
                Proiezione Incassi Mensili Collaterale (Prime 24 Mensilità - € Mln)
              </h3>
              <button
                onClick={() => onNavigate('waterfall')}
                className="text-xs font-mono text-blue-400 hover:text-blue-300"
              >
                Dettaglio Waterfall →
              </button>
            </div>
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={cashFlowChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="mese" stroke="#64748b" tick={{ fontSize: 10 }} />
                  <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Bar dataKey="Interessi" stackId="a" fill="#3b82f6" />
                  <Bar dataKey="Capitale" stackId="a" fill="#10b981" />
                  <Bar dataKey="Prepayments" stackId="a" fill="#f59e0b" />
                  <Bar dataKey="Recuperi" stackId="a" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Geographic Distribution + Quick Actions */}
        <div className="space-y-6">
          {/* Geographic Slice Card */}
          <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wide">
              DISTRIBUZIONE GEOGRAFICA ITALIA
            </h3>
            <div className="h-48 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={geoPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={70}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {geoPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={REGION_COLORS[index % REGION_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                    formatter={(val: any) => `${val}%`}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-1.5 text-xs font-mono pt-2 border-t border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>Nord Italia (Lombardia, Veneto, ER)</span>
                <span className="font-semibold text-blue-400">52,0%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Centro Italia (Lazio, Toscana)</span>
                <span className="font-semibold text-indigo-400">26,0%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Sud Italia (Campania, Puglia)</span>
                <span className="font-semibold text-purple-400">15,0%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Isole (Sicilia, Sardegna)</span>
                <span className="font-semibold text-pink-400">7,0%</span>
              </div>
            </div>
          </div>

          {/* Quick Actions Panel */}
          <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wide">
              AZIONI RAPIDE E SIMULAZIONI
            </h3>
            <div className="space-y-2">
              <button
                onClick={() => onNavigate('stress')}
                className="w-full bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 p-2.5 rounded text-xs font-mono flex items-center justify-between transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-400" />
                  Esegui Stress Test Lab
                </span>
                <ArrowRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigate('montecarlo')}
                className="w-full bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 p-2.5 rounded text-xs font-mono flex items-center justify-between transition-colors"
              >
                <span className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  Lancia Monte Carlo (1.000 Scenari)
                </span>
                <ArrowRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigate('reports')}
                className="w-full bg-blue-900/60 hover:bg-blue-800/80 text-blue-100 border border-blue-700 p-2.5 rounded text-xs font-mono flex items-center justify-between transition-colors font-semibold"
              >
                <span className="flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-blue-300" />
                  Genera Report Istituzionale completo
                </span>
                <ArrowRight className="w-4 h-4 text-blue-300" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
