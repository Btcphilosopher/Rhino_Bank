/**
 * @file PoolBuilderView.tsx
 * RHINOQUANT ITALIA - Mortgage Pool Construction Workbench
 */

import React, { useState } from 'react';
import { Pool, MacroZone } from '../types/mbs';
import { generateSyntheticMortgages } from '../utils/syntheticDataGenerator';
import { calculateWAC, calculateWAM, calculateWALTV, calculateWALTI, calculateWASeasoning } from '../utils/mathEngine';
import { Sliders, RefreshCw, CheckCircle2, PieChart as PieIcon } from 'lucide-react';

interface PoolBuilderViewProps {
  currentPool: Pool;
  onUpdatePool: (newPool: Pool) => void;
}

export const PoolBuilderView: React.FC<PoolBuilderViewProps> = ({ currentPool, onUpdatePool }) => {
  const [loansCount, setLoansCount] = useState<number>(currentPool.loansCount);
  const [meanAmount, setMeanAmount] = useState<number>(currentPool.averageLoanSize);
  const [fixedRateRatio, setFixedRateRatio] = useState<number>(currentPool.fixedRatePercentage / 100);
  const [macroZone, setMacroZone] = useState<MacroZone | 'ALL'>('ALL');
  const [seed, setSeed] = useState<number>(9999);
  const [isGenerated, setIsGenerated] = useState<boolean>(false);

  const handleBuildPool = () => {
    const generatedSample = generateSyntheticMortgages({
      count: Math.min(loansCount, 1000), // Sample for performance
      seed,
      meanAmount,
      targetMacroZone: macroZone === 'ALL' ? undefined : macroZone,
      fixedRateRatio
    });

    const calculatedWac = calculateWAC(generatedSample);
    const calculatedWam = calculateWAM(generatedSample);
    const calculatedWaLtv = calculateWALTV(generatedSample);
    const calculatedWaLti = calculateWALTI(generatedSample);
    const calculatedWaSeasoning = calculateWASeasoning(generatedSample);

    const totalCurrentBalance = loansCount * meanAmount;

    const newPool: Pool = {
      id: `POOL-CUSTOM-${Date.now().toString().slice(-4)}`,
      name: `Pool Personalizzato Italia (${loansCount.toLocaleString('it-IT')} Mutui)`,
      createdDate: new Date().toISOString().split('T')[0],
      loansCount,
      totalOriginalBalance: Math.round(totalCurrentBalance * 1.22),
      totalCurrentBalance,
      averageLoanSize: meanAmount,
      wac: Number(calculatedWac.toFixed(2)),
      wam: Math.round(calculatedWam),
      wal: Number((calculatedWam / 48.0).toFixed(2)),
      waLtv: Number(calculatedWaLtv.toFixed(1)),
      waLti: Number(calculatedWaLti.toFixed(1)),
      waSeasoning: Math.round(calculatedWaSeasoning),
      fixedRatePercentage: Number((fixedRateRatio * 100).toFixed(1)),
      variableRatePercentage: Number(((1 - fixedRateRatio) * 100).toFixed(1)),
      geographicDistribution: {
        'NORD': macroZone === 'NORD' ? 100 : (macroZone === 'ALL' ? 52 : 0),
        'CENTRO': macroZone === 'CENTRO' ? 100 : (macroZone === 'ALL' ? 26 : 0),
        'SUD': macroZone === 'SUD' ? 100 : (macroZone === 'ALL' ? 15 : 0),
        'ISOLE': macroZone === 'ISOLE' ? 100 : (macroZone === 'ALL' ? 7 : 0),
        'Lombardia': 24.5,
        'Lazio': 15.2,
        'Veneto': 11.8,
        'Emilia-Romagna': 10.5,
        'Piemonte': 9.2,
        'Toscana': 7.8,
        'Campania': 6.5,
        'Puglia': 5.2,
        'Sicilia': 4.8,
        'Liguria': 2.5,
        'Sardegna': 2.0,
        'Altre Regioni': 0.0
      },
      ratingDistribution: currentPool.ratingDistribution,
      expectedLossRate: calculatedWaLtv > 75 ? 1.45 : 0.85,
      expectedRecoveryRate: calculatedWaLtv > 75 ? 72.0 : 78.5,
      loansSample: generatedSample
    };

    onUpdatePool(newPool);
    setIsGenerated(true);
    setTimeout(() => setIsGenerated(false), 3000);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-white tracking-wide">
            COSTRUTTORE E FILTRO DEL POOL IPOTECARIO
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configurazione quantitativa dei parametri del portafoglio collaterale per l'operazione SPV
          </p>
        </div>

        {isGenerated && (
          <div className="bg-emerald-950/80 text-emerald-300 border border-emerald-800 px-3 py-1.5 rounded text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            NUOVO POOL COSTRUITO ED APPLICATO ALL'OPERAZIONE SPV
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 1 Col: Control Sliders */}
        <div className="bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-5 text-xs">
          <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-400" />
            PARAMETRI DEL PORTAFOGLIO
          </h2>

          {/* Loan Count */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Numero Mutui nel Pool:</span>
              <span className="font-bold text-blue-400">{loansCount.toLocaleString('it-IT')}</span>
            </div>
            <input
              type="range"
              min="1000"
              max="100000"
              step="1000"
              value={loansCount}
              onChange={e => setLoansCount(Number(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer h-1.5"
            />
          </div>

          {/* Mean Amount */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Importo Medio Mutuo (€):</span>
              <span className="font-bold text-emerald-400">€ {meanAmount.toLocaleString('it-IT')}</span>
            </div>
            <input
              type="range"
              min="80000"
              max="350000"
              step="5000"
              value={meanAmount}
              onChange={e => setMeanAmount(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer h-1.5"
            />
          </div>

          {/* Fixed Rate Ratio */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Quota Tasso Fisso:</span>
              <span className="font-bold text-amber-400">{(fixedRateRatio * 100).toFixed(0)}% Fisso / {((1 - fixedRateRatio) * 100).toFixed(0)}% Var</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={fixedRateRatio}
              onChange={e => setFixedRateRatio(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5"
            />
          </div>

          {/* Macro Zone */}
          <div className="space-y-1.5">
            <label className="text-slate-300">Zona Geografica Dominante:</label>
            <select
              value={macroZone}
              onChange={e => setMacroZone(e.target.value as any)}
              className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">Nazionale (Tutte le macroaree)</option>
              <option value="NORD">Nord Italia (Lombardia, Veneto, ER, Piemonte)</option>
              <option value="CENTRO">Centro Italia (Lazio, Toscana)</option>
              <option value="SUD">Sud Italia (Campania, Puglia)</option>
              <option value="ISOLE">Isole (Sicilia, Sardegna)</option>
            </select>
          </div>

          {/* Seed */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800">
            <label className="text-slate-400">Seed Deterministico:</label>
            <input
              type="number"
              value={seed}
              onChange={e => setSeed(Number(e.target.value) || 12345)}
              className="w-full bg-[#0b0e17] border border-slate-800 rounded p-2 text-amber-300 font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={handleBuildPool}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold transition-colors flex items-center justify-center gap-2 text-xs shadow-md"
          >
            <RefreshCw className="w-4 h-4" />
            Rigenera e Applica Pool
          </button>
        </div>

        {/* Right 2 Cols: Recalculated Pool Metrics */}
        <div className="lg:col-span-2 bg-[#121826] border border-slate-800 rounded-lg p-5 space-y-6">
          <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2 border-b border-slate-800 pb-3">
            <PieIcon className="w-4 h-4 text-emerald-400" />
            METRICHE E PROFILO DEL POOL RISULTANTE
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="bg-[#0b0e17] border border-slate-800/80 p-3.5 rounded">
              <span className="text-[11px] text-slate-500 uppercase">Valore Collaterale Totale</span>
              <div className="text-xl font-bold text-white mt-1">€ {(currentPool.totalCurrentBalance / 1e9).toFixed(3)} MLD</div>
              <span className="text-[10px] text-slate-400">{currentPool.loansCount.toLocaleString('it-IT')} Mutui</span>
            </div>

            <div className="bg-[#0b0e17] border border-slate-800/80 p-3.5 rounded">
              <span className="text-[11px] text-slate-500 uppercase">WAC (Coupon Medio)</span>
              <div className="text-xl font-bold text-amber-400 mt-1">{currentPool.wac.toFixed(2)}%</div>
              <span className="text-[10px] text-slate-400">Fisso {currentPool.fixedRatePercentage}%</span>
            </div>

            <div className="bg-[#0b0e17] border border-slate-800/80 p-3.5 rounded">
              <span className="text-[11px] text-slate-500 uppercase">WAM (Scadenza Media)</span>
              <div className="text-xl font-bold text-indigo-400 mt-1">{currentPool.wam} mesi</div>
              <span className="text-[10px] text-slate-400">{(currentPool.wam / 12).toFixed(1)} Anni</span>
            </div>

            <div className="bg-[#0b0e17] border border-slate-800/80 p-3.5 rounded">
              <span className="text-[11px] text-slate-500 uppercase">WA LTV (LTV Medio)</span>
              <div className="text-xl font-bold text-blue-400 mt-1">{currentPool.waLtv.toFixed(1)}%</div>
              <span className="text-[10px] text-slate-400">WA LTI: {currentPool.waLti.toFixed(1)}%</span>
            </div>

            <div className="bg-[#0b0e17] border border-slate-800/80 p-3.5 rounded">
              <span className="text-[11px] text-slate-500 uppercase">Expected Loss Rate</span>
              <div className="text-xl font-bold text-rose-400 mt-1">{currentPool.expectedLossRate.toFixed(2)}%</div>
              <span className="text-[10px] text-slate-400">Su orizzonte vita utile</span>
            </div>

            <div className="bg-[#0b0e17] border border-slate-800/80 p-3.5 rounded">
              <span className="text-[11px] text-slate-500 uppercase">Recovery Rate Atteso</span>
              <div className="text-xl font-bold text-emerald-400 mt-1">{currentPool.expectedRecoveryRate.toFixed(1)}%</div>
              <span className="text-[10px] text-slate-400">Procedure esecutive</span>
            </div>
          </div>

          <div className="p-4 bg-[#0b0e17] border border-slate-800 rounded text-xs space-y-2 text-slate-300">
            <div className="font-bold text-white uppercase text-[11px] tracking-wide">Analisi Distribuzione Geografica & Credito</div>
            <p>
              Il portafoglio generato rispetta le distribuzioni storiche dei mutui residenziali italiani ex art. 1, L. 130/99. Il Loan-to-Value medio ponderato del <strong className="text-blue-300">{currentPool.waLtv}%</strong> ed il Coupon del <strong className="text-amber-300">{currentPool.wac}%</strong> garantiscono un idoneo margine di Excess Spread a copertura dei costi della cartolarizzazione.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
