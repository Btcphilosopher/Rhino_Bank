/**
 * @file App.tsx
 * RHINOQUANT ITALIA — MBS LABORATORY
 * Institutional Quantitative Research, Structuring, Pricing, Simulation & Risk Analytics Platform
 */

import React, { useState, useMemo } from 'react';
import { Pool, SecuritisationDeal } from './types/mbs';
import { DEMO_POOL, DEMO_DEAL, DEMO_STRESS_SCENARIOS } from './utils/defaultData';
import { runMonthlyWaterfall } from './utils/waterfallEngine';
import { calculateTranchePricing } from './utils/pricingEngine';

import { Header } from './components/Header';
import { SidebarNav } from './components/SidebarNav';
import { OverviewDashboard } from './components/OverviewDashboard';
import { MortgageUniverseView } from './components/MortgageUniverseView';
import { PoolBuilderView } from './components/PoolBuilderView';
import { DealStructuringView } from './components/DealStructuringView';
import { WaterfallEngineView } from './components/WaterfallEngineView';
import { PricingWorkbenchView } from './components/PricingWorkbenchView';
import { StressTestLabView } from './components/StressTestLabView';
import { MonteCarloView } from './components/MonteCarloView';
import { PortfolioAnalyticsView } from './components/PortfolioAnalyticsView';
import { ResearchNotebookView } from './components/ResearchNotebookView';
import { ReportsView } from './components/ReportsView';
import { CodeInspectorView } from './components/CodeInspectorView';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [seed, setSeed] = useState<number>(9999);
  const [pool, setPool] = useState<Pool>(DEMO_POOL);
  const [deal, setDeal] = useState<SecuritisationDeal>(DEMO_DEAL);

  // Recalculate monthly waterfall whenever pool or deal updates
  const waterfallFlows = useMemo(() => {
    return runMonthlyWaterfall({ deal, pool, monthsCount: 180 });
  }, [deal, pool]);

  // Recalculate pricing results for all tranches
  const pricingResults = useMemo(() => {
    return deal.tranches.map(t =>
      calculateTranchePricing({ tranche: t, waterfallFlows })
    );
  }, [deal, waterfallFlows]);

  // Check double-entry reconciliation balance
  const isReconciled = waterfallFlows.length > 0 && waterfallFlows[0].reconciliationCheck.isBalanced;

  // Reset to initial RQ ITALIA DEMO 01 dataset
  const handleResetDemo = () => {
    setPool(DEMO_POOL);
    setDeal(DEMO_DEAL);
    setSeed(9999);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#0c0f17] text-slate-200">
      {/* Institutional Quantitative Terminal Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        seed={seed}
        setSeed={setSeed}
        reconciled={isReconciled}
        onResetDemo={handleResetDemo}
      />

      {/* Main Terminal Viewport */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation Menu */}
        <SidebarNav currentTab={currentTab} setCurrentTab={setCurrentTab} />

        {/* Dynamic Workspace Content View */}
        <main className="flex-1 overflow-y-auto bg-[#0c0f17]">
          {currentTab === 'overview' && (
            <OverviewDashboard
              pool={pool}
              deal={deal}
              waterfallFlows={waterfallFlows}
              pricingResults={pricingResults}
              onNavigate={setCurrentTab}
            />
          )}

          {currentTab === 'universe' && (
            <MortgageUniverseView loans={pool.loansSample} />
          )}

          {currentTab === 'pool' && (
            <PoolBuilderView
              currentPool={pool}
              onUpdatePool={setPool}
            />
          )}

          {currentTab === 'deal' && (
            <DealStructuringView
              deal={deal}
              onUpdateDeal={setDeal}
            />
          )}

          {currentTab === 'waterfall' && (
            <WaterfallEngineView
              flows={waterfallFlows}
              deal={deal}
            />
          )}

          {currentTab === 'pricing' && (
            <PricingWorkbenchView
              pricingResults={pricingResults}
              deal={deal}
            />
          )}

          {currentTab === 'stress' && (
            <StressTestLabView
              deal={deal}
              pool={pool}
            />
          )}

          {currentTab === 'montecarlo' && (
            <MonteCarloView
              deal={deal}
              pool={pool}
            />
          )}

          {currentTab === 'portfolio' && (
            <PortfolioAnalyticsView />
          )}

          {currentTab === 'notebook' && (
            <ResearchNotebookView />
          )}

          {currentTab === 'reports' && (
            <ReportsView
              deal={deal}
              pool={pool}
              pricingResults={pricingResults}
              scenarios={DEMO_STRESS_SCENARIOS}
            />
          )}

          {currentTab === 'code' && (
            <CodeInspectorView />
          )}
        </main>
      </div>
    </div>
  );
}
