/**
 * @file mbs.ts
 * RHINOQUANT ITALIA - MBS Laboratory Data Types
 * Italian Mortgage-Backed Securities Quantitative Definitions
 */

export type RateType = 'FISSO' | 'VARIABILE';

export type ReferenceIndex = 
  | 'EURIBOR_1M' 
  | 'EURIBOR_3M' 
  | 'EURIBOR_6M' 
  | 'EURIBOR_12M' 
  | 'IRS_10Y' 
  | 'IRS_15Y' 
  | 'IRS_20Y' 
  | 'IRS_30Y';

export type MacroZone = 'NORD' | 'CENTRO' | 'SUD' | 'ISOLE';

export type ItalianRegion = 
  | 'Lombardia'
  | 'Lazio'
  | 'Veneto'
  | 'Emilia-Romagna'
  | 'Piemonte'
  | 'Toscana'
  | 'Liguria'
  | 'Campania'
  | 'Puglia'
  | 'Sicilia'
  | 'Sardegna'
  | 'Altre Regioni';

export type PropertyType = 
  | 'RESIDENZIALE_PRINCIPALE' 
  | 'SECONDA_CASA' 
  | 'APPARTAMENTO' 
  | 'VILLA' 
  | 'INDIPENDENTE';

export type CreditRating = 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC' | 'NR';

export type PaymentStatus = 
  | 'IN_BONIS' 
  | 'ARRETRATO_30' 
  | 'ARRETRATO_60' 
  | 'ARRETRATO_90' 
  | 'DEFAULT' 
  | 'PAST_DUE';

/**
 * Singolo Mutuo Residenziale Italiano
 */
export interface Mortgage {
  id: string; // e.g. "RQ-ITA-000104"
  borrowerId: string;
  originalAmount: number; // Euro
  currentBalance: number; // Euro
  rateType: RateType;
  referenceIndex: ReferenceIndex;
  indexValue: number; // % (e.g. 3.25)
  spread: number; // % (e.g. 1.15)
  interestRate: number; // % (e.g. 4.40)
  originalTermMonths: number; // e.g. 300 (25 anni)
  remainingTermMonths: number; // e.g. 240 (20 anni)
  seasoningMonths: number; // anzianità in mesi
  monthlyPayment: number; // Euro (rata)
  amortizationType: 'FRANCESE';
  paymentFrequency: 'MENSILE';
  ltv: number; // Loan-to-Value %
  lti: number; // Loan-to-Income / DTI %
  borrowerIncome: number; // Euro/anno
  propertyValue: number; // Euro
  propertyType: PropertyType;
  macroZone: MacroZone;
  region: ItalianRegion;
  province: string;
  creditRating: CreditRating;
  paymentStatus: PaymentStatus;
  arrearsAmount: number; // Euro
  annualPD: number; // Probabilità di default annuale %
  annualCPR: number; // Prepayment Rate annuale %
  lgd: number; // Loss Given Default %
  expectedRecoveryRate: number; // %
  recoveryDelayMonths: number; // Mesi previsti per aste/escussione legale
}

/**
 * Portafoglio / Pool Ipotecario
 */
export interface Pool {
  id: string;
  name: string;
  createdDate: string;
  loansCount: number;
  totalOriginalBalance: number;
  totalCurrentBalance: number;
  averageLoanSize: number;
  wac: number; // Weighted Average Coupon (%)
  wam: number; // Weighted Average Maturity (mesi)
  wal: number; // Weighted Average Life (anni)
  waLtv: number; // Weighted Average LTV (%)
  waLti: number; // Weighted Average LTI (%)
  waSeasoning: number; // Weighted Average Seasoning (mesi)
  fixedRatePercentage: number; // %
  variableRatePercentage: number; // %
  geographicDistribution: Record<ItalianRegion | MacroZone, number>; // Euro & %
  ratingDistribution: Record<CreditRating, number>;
  expectedLossRate: number; // %
  expectedRecoveryRate: number; // %
  loansSample: Mortgage[];
}

/**
 * Struttura di una Tranche di Cartolarizzazione
 */
export interface Tranche {
  id: string;
  name: string; // e.g. "Senior A1", "Mezzanine B", "Junior C", "Equity"
  originalPrincipal: number; // Euro
  currentPrincipal: number; // Euro
  attachmentPoint: number; // % (e.g. 15.0%)
  detachmentPoint: number; // % (e.g. 100.0%)
  subordination: number; // % (Credit Enhancement)
  couponType: RateType;
  couponRate: number; // % (e.g. 4.10)
  spreadBps: number; // bps over Euribor
  rating: CreditRating;
  wal: number; // anni
  duration: number; // anni
  modifiedDuration: number; // anni
  convexity: number;
  expectedLoss: number; // %
  cumulativeLossAllocated: number; // Euro
  impairmentProbability: number; // %
}

/**
 * Operazione di Cartolarizzazione (SPV)
 */
export interface SecuritisationDeal {
  id: string;
  dealName: string; // e.g. "RHINOQUANT ITALIA RMBS 2026-1 SPV"
  issueDate: string;
  collateralPoolId: string;
  initialCollateralBalance: number;
  currentCollateralBalance: number;
  reserveAccountBalance: number; // Euro
  reserveAccountTarget: number; // Euro
  liquidityReserve: number; // Euro
  servicingFeeRate: number; // % all'anno (es. 0.15%)
  spvExpensesRate: number; // % all'anno (es. 0.05%)
  overcollateralisation: number; // Euro
  excessSpreadTarget: number; // %
  principalAllocationMode: 'SEQUENTIAL' | 'PRO_RATA';
  tranches: Tranche[];
}

/**
 * Flusso Mensile della Waterfall (Priority of Payments)
 */
export interface MonthlyWaterfallFlow {
  month: number;
  date: string;
  openingCollateralBalance: number;
  interestCollections: number;
  principalCollections: number;
  prepayments: number;
  defaults: number;
  recoveries: number;
  grossLosses: number;
  totalCashInflow: number;
  seniorExpenses: number;
  servicingFees: number;
  trancheInterestPayments: Record<string, number>; // trancheId -> amount
  tranchePrincipalPayments: Record<string, number>; // trancheId -> amount
  reserveAccountReplenishment: number;
  excessSpread: number;
  equityDistribution: number;
  totalCashOutflow: number;
  closingCollateralBalance: number;
  trancheClosingBalances: Record<string, number>;
  cumulativeLosses: number;
  reconciliationCheck: {
    isBalanced: boolean;
    errorMargin: number;
  };
}

/**
 * Risultato del Pricing Engine
 */
export interface TranchePricing {
  trancheId: string;
  trancheName: string;
  price: number; // % del valore nominale (es. 99.85)
  yieldToMaturity: number; // %
  discountMarginBps: number; // bps
  oasBps: number; // Option-Adjusted Spread bps
  duration: number; // anni
  modifiedDuration: number; // anni
  spreadDuration: number; // anni
  convexity: number;
  dv01: number; // Euro / 1 bp shift
  cs01: number; // Euro / 1 bp spread shift
  wal: number; // anni
  discountedCashFlows: Array<{
    month: number;
    date: string;
    interest: number;
    principal: number;
    total: number;
    discountFactor: number;
    presentValue: number;
  }>;
}

/**
 * Scenario di Stress Macroeconomico
 */
export interface StressScenario {
  id: string;
  name: string;
  description: string;
  housePriceShockPercent: number; // e.g. -20%
  interestRateShiftBps: number; // e.g. +250
  pdMultiplier: number; // e.g. 2.5
  lgdMultiplier: number; // e.g. 1.3
  cprMultiplier: number; // e.g. 0.5
  recoveryDelayMonthsDelta: number; // e.g. +12
}

/**
 * Risultato della Simulazione Monte Carlo
 */
export interface MonteCarloResult {
  simulationsCount: number;
  seed: number;
  executionTimeMs: number;
  expectedPortfolioPrice: number;
  var95Euro: number;
  var95Percent: number;
  var99Euro: number;
  var99Percent: number;
  cvar95Euro: number; // Expected Shortfall
  cvar95Percent: number;
  expectedLossEuro: number;
  expectedLossPercent: number;
  priceHistogram: Array<{ priceBin: string; frequency: number }>;
  lossHistogram: Array<{ lossBin: string; frequency: number }>;
  walHistogram: Array<{ walBin: string; frequency: number }>;
  trancheImpairmentProbabilities: Record<string, number>;
}

/**
 * Experimento / Registro di Ricerca
 */
export interface ResearchExperiment {
  id: string;
  title: string;
  timestamp: string;
  author: string;
  seed: number;
  datasetId: string;
  modelVersion: string;
  parameters: Record<string, any>;
  resultsSummary: {
    totalCollateral: number;
    wac: number;
    wal: number;
    seniorYield: number;
    expectedLoss: number;
    var95: number;
  };
  checksum: string;
  notes: string;
}

/**
 * Tracciabilità & Registro Audit
 */
export interface AuditEvent {
  id: string;
  timestamp: string;
  action: string;
  status: 'OK' | 'WARNING' | 'REJECTED';
  details: string;
  reconciliation: {
    openingBalance: number;
    totalInflows: number;
    totalOutflows: number;
    lossesAllocated: number;
    closingBalance: number;
    discrepancyEuro: number;
  };
}

/**
 * Curva dei Tassi di Riferimento Sintetica
 */
export interface YieldCurvePoint {
  tenor: string;
  euriborRate: number; // %
  irsRate: number; // %
  riskFreeRate: number; // %
}
