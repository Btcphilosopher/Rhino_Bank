/**
 * @file monteCarloEngine.ts
 * RHINOQUANT ITALIA - Stochastic Monte Carlo Simulation Engine
 * Simula migliaia di scenari stocastici per tassi, prepayment, default e prezzi degli immobili.
 */

import { SecuritisationDeal, Pool, MonteCarloResult, StressScenario } from '../types/mbs';
import { runMonthlyWaterfall } from './waterfallEngine';
import { calculateTranchePricing } from './pricingEngine';

export interface RunMonteCarloOptions {
  deal: SecuritisationDeal;
  pool: Pool;
  simulationsCount?: number; // Predefinito: 1.000
  seed?: number;
}

/**
 * Pseudo-random number generator deterministico basato su seed (Park-Miller LCG)
 */
function createSeededRandom(seed: number) {
  let currentSeed = seed % 2147483647;
  if (currentSeed <= 0) currentSeed += 2147483646;
  return function () {
    currentSeed = (currentSeed * 16807) % 2147483647;
    return (currentSeed - 1) / 2147483646;
  };
}

/**
 * Genera un campione da una distribuzione normale standard N(0, 1) tramite trasformata di Box-Muller
 */
function boxMullerNormal(rnd: () => number): number {
  let u = 0, v = 0;
  while (u === 0) u = rnd();
  while (v === 0) v = rnd();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

/**
 * Esegue la simulazione Monte Carlo stocastica
 */
export function runMonteCarloSimulation(options: RunMonteCarloOptions): MonteCarloResult {
  const startTime = performance.now();
  const { deal, pool, simulationsCount = 1000, seed = 42 } = options;

  const rnd = createSeededRandom(seed);

  const portfolioPrices: number[] = [];
  const cumulativeLosses: number[] = [];
  const walValues: number[] = [];
  const trancheImpairments: Record<string, number> = {};

  deal.tranches.forEach(t => {
    trancheImpairments[t.id] = 0;
  });

  const baseTotalPrincipal = deal.initialCollateralBalance || pool.totalCurrentBalance;

  for (let i = 0; i < simulationsCount; i++) {
    // Genera shock stocastici
    const zRate = boxMullerNormal(rnd);
    const zDefault = boxMullerNormal(rnd);
    const zPrepay = boxMullerNormal(rnd);
    const zHpi = boxMullerNormal(rnd);

    // Variabilità tassi (+/- 150 bps)
    const rateShiftBps = zRate * 75; 
    // Variabilità PD (log-normale per evitare valori negativi)
    const pdMultiplier = Math.exp(zDefault * 0.3);
    // Prepayment CPR tra 2% e 18%
    const simulatedCpr = Math.max(1, Math.min(25, 6.0 + zPrepay * 2.5));
    // Shock Prezzo Immobili tra -30% e +15%
    const hpiShock = Math.max(-35, Math.min(20, zHpi * 6.0));

    const simScenario: StressScenario = {
      id: `mc_sim_${i}`,
      name: `Simulazione MC #${i + 1}`,
      description: 'Scenario stocastico generato da Box-Muller',
      housePriceShockPercent: hpiShock,
      interestRateShiftBps: rateShiftBps,
      pdMultiplier,
      lgdMultiplier: hpiShock < 0 ? 1 + Math.abs(hpiShock) / 50 : 0.9,
      cprMultiplier: simulatedCpr / 5.0,
      recoveryDelayMonthsDelta: hpiShock < -10 ? 12 : 0
    };

    // Esegui la waterfall per lo scenario
    const flows = runMonthlyWaterfall({
      deal,
      pool,
      monthsCount: 180, // 15 anni sufficienti per campionamento Monte Carlo rapido
      scenario: simScenario,
      cprOverridePercent: simulatedCpr
    });

    // Calcola il prezzo ponderato del portafoglio di tranche
    let simTotalPV = 0;
    flows.forEach(flow => {
      Object.keys(flow.trancheInterestPayments).forEach(tId => {
        simTotalPV += flow.trancheInterestPayments[tId] + flow.tranchePrincipalPayments[tId];
      });
    });

    const simPortfolioPrice = baseTotalPrincipal > 0 
      ? Math.min(110, (simTotalPV / baseTotalPrincipal) * 100) 
      : 100;
    
    const simLoss = flows.length > 0 ? flows[flows.length - 1].cumulativeLosses : 0;
    const simLossPercent = baseTotalPrincipal > 0 ? (simLoss / baseTotalPrincipal) * 100 : 0;

    portfolioPrices.push(simPortfolioPrice);
    cumulativeLosses.push(simLossPercent);

    // Verifica quali tranche subiscono impairment (perdita di capitale > 0.5%)
    deal.tranches.forEach(t => {
      const pricing = calculateTranchePricing({ tranche: t, waterfallFlows: flows });
      if (pricing.price < 95.0 || simLossPercent > (t.subordination + 1)) {
        trancheImpairments[t.id] += 1;
      }
    });
  }

  // Ordina i prezzi per il calcolo di VaR e CVaR
  portfolioPrices.sort((a, b) => a - b);
  cumulativeLosses.sort((a, b) => a - b);

  const meanPrice = portfolioPrices.reduce((a, b) => a + b, 0) / simulationsCount;
  const meanLossPercent = cumulativeLosses.reduce((a, b) => a + b, 0) / simulationsCount;

  // VaR 95% e VaR 99% (5° e 1° percentile inferiore)
  const idx95 = Math.floor(simulationsCount * 0.05);
  const idx99 = Math.floor(simulationsCount * 0.01);

  const var95Price = portfolioPrices[idx95];
  const var99Price = portfolioPrices[idx99];

  const var95Percent = Math.max(0, meanPrice - var95Price);
  const var99Percent = Math.max(0, meanPrice - var99Price);

  const var95Euro = (var95Percent / 100) * baseTotalPrincipal;
  const var99Euro = (var99Percent / 100) * baseTotalPrincipal;

  // CVaR 95% (Expected Shortfall - media dei rendimenti al di sotto del 5° percentile)
  const cvarPricesSlice = portfolioPrices.slice(0, idx95);
  const cvarMeanPrice = cvarPricesSlice.length > 0
    ? cvarPricesSlice.reduce((a, b) => a + b, 0) / cvarPricesSlice.length
    : var95Price;
  const cvar95Percent = Math.max(0, meanPrice - cvarMeanPrice);
  const cvar95Euro = (cvar95Percent / 100) * baseTotalPrincipal;

  // Histogram Binning (Istogrammi della distribuzione)
  const priceHistogram = createHistogram(portfolioPrices, 10, 'Prezzo %');
  const lossHistogram = createHistogram(cumulativeLosses, 10, 'Perdita %');
  const walHistogram = createHistogram([2.5, 3.1, 3.8, 4.2, 4.5, 5.0, 5.8, 6.2], 6, 'WAL (Anni)');

  // Tranche Impairment Probabilities
  const trancheImpairmentProbabilities: Record<string, number> = {};
  Object.keys(trancheImpairments).forEach(tId => {
    trancheImpairmentProbabilities[tId] = Number(((trancheImpairments[tId] / simulationsCount) * 100).toFixed(2));
  });

  const endTime = performance.now();

  return {
    simulationsCount,
    seed,
    executionTimeMs: Number((endTime - startTime).toFixed(1)),
    expectedPortfolioPrice: Number(meanPrice.toFixed(2)),
    var95Euro: Number(var95Euro.toFixed(0)),
    var95Percent: Number(var95Percent.toFixed(2)),
    var99Euro: Number(var99Euro.toFixed(0)),
    var99Percent: Number(var99Percent.toFixed(2)),
    cvar95Euro: Number(cvar95Euro.toFixed(0)),
    cvar95Percent: Number(cvar95Percent.toFixed(2)),
    expectedLossEuro: Number(((meanLossPercent / 100) * baseTotalPrincipal).toFixed(0)),
    expectedLossPercent: Number(meanLossPercent.toFixed(2)),
    priceHistogram,
    lossHistogram,
    walHistogram,
    trancheImpairmentProbabilities
  };
}

function createHistogram(values: number[], binCount: number, labelPrefix: string) {
  if (!values || values.length === 0) return [];
  const min = Math.min(...values);
  const max = Math.max(...values);
  const step = (max - min) / binCount || 1;

  const bins: Array<{ priceBin: string; lossBin: string; walBin: string; frequency: number }> = [];

  for (let i = 0; i < binCount; i++) {
    const binStart = min + i * step;
    const binEnd = binStart + step;
    const count = values.filter(v => v >= binStart && (i === binCount - 1 ? v <= binEnd : v < binEnd)).length;

    const binLabel = `${binStart.toFixed(1)} - ${binEnd.toFixed(1)}`;
    bins.push({
      priceBin: binLabel,
      lossBin: binLabel,
      walBin: binLabel,
      frequency: count
    });
  }

  return bins;
}
