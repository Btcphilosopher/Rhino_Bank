/**
 * @file waterfallEngine.ts
 * RHINOQUANT ITALIA - Priority of Payments & Monthly Waterfall Engine
 * Gestisce l'allocazione dei flussi di cassa, il ripristino delle riserve e la riconciliazione contabile a doppia entrata.
 */

import { SecuritisationDeal, Pool, MonthlyWaterfallFlow, StressScenario, Tranche } from '../types/mbs';
import { cprToSmm, calculateDynamicMonthlyPD, calculateDynamicLGD } from './mathEngine';

export interface RunWaterfallOptions {
  deal: SecuritisationDeal;
  pool: Pool;
  monthsCount?: number; // Predefinito: 360 mesi (30 anni)
  scenario?: StressScenario;
  cprOverridePercent?: number; // CPR personalizzato
  annualPdOverridePercent?: number; // PD personalizzato
}

/**
 * Esegue la simulazione completa della waterfall mensile per l'intera durata dell'operazione.
 */
export function runMonthlyWaterfall(options: RunWaterfallOptions): MonthlyWaterfallFlow[] {
  const { deal, pool, monthsCount = 360, scenario, cprOverridePercent, annualPdOverridePercent } = options;

  let currentCollateralBalance = deal.initialCollateralBalance || pool.totalCurrentBalance;
  let currentReserveBalance = deal.reserveAccountBalance;
  let cumulativeLosses = 0;

  // Clona le tranche per tracciare il capitale residuo e gli interessi
  const tranchesState: Record<string, { currentPrincipal: number; couponRate: number }> = {};
  deal.tranches.forEach(t => {
    tranchesState[t.id] = {
      currentPrincipal: t.originalPrincipal,
      couponRate: t.couponRate
    };
  });

  const flows: MonthlyWaterfallFlow[] = [];

  // Data iniziale dell'operazione
  const startDate = new Date();

  // Precalcola tassi base
  const baseWac = pool.wac;
  const wamMonths = pool.wam || 240;

  for (let month = 1; month <= monthsCount; month++) {
    if (currentCollateralBalance <= 0.01) {
      break;
    }

    const currentDate = new Date(startDate.getFullYear(), startDate.getMonth() + month - 1, 1);
    const dateString = currentDate.toISOString().substring(0, 7); // YYYY-MM

    const openingCollateralBalance = currentCollateralBalance;

    // 1. Calcolo del tasso di interesse mensile del collateral
    const monthlyCouponRate = baseWac / 100 / 12;
    const interestCollections = openingCollateralBalance * monthlyCouponRate;

    // 2. Calcolo della quota capitale teorica dell'ammortamento (Ammortamento Francese sul Pool)
    const remainingTerm = Math.max(1, wamMonths - month + 1);
    const monthlyRate = baseWac / 100 / 12;
    let scheduledPrincipal = 0;
    if (monthlyRate > 0) {
      const factor = Math.pow(1 + monthlyRate, remainingTerm);
      const totalRata = (openingCollateralBalance * monthlyRate * factor) / (factor - 1);
      scheduledPrincipal = Math.max(0, totalRata - interestCollections);
    } else {
      scheduledPrincipal = openingCollateralBalance / remainingTerm;
    }
    scheduledPrincipal = Math.min(openingCollateralBalance, scheduledPrincipal);

    // 3. Prepayment (Rimborso Anticipato)
    const activeCpr = cprOverridePercent !== undefined 
      ? cprOverridePercent 
      : (scenario ? pool.expectedLossRate * scenario.cprMultiplier : 5.0);
    const smm = cprToSmm(activeCpr);
    const balanceAfterScheduled = openingCollateralBalance - scheduledPrincipal;
    const prepayments = Math.min(balanceAfterScheduled, balanceAfterScheduled * smm);

    // 4. Default & Loss Given Default (LGD)
    const basePd = annualPdOverridePercent !== undefined ? annualPdOverridePercent : 1.5;
    const mdr = calculateDynamicMonthlyPD(basePd, pool.waLtv, pool.waSeasoning + month, scenario);
    const balanceAfterPrepayment = balanceAfterScheduled - prepayments;
    const defaults = Math.min(balanceAfterPrepayment, balanceAfterPrepayment * mdr);

    // Dynamic Recovery
    const { lgdPercent } = calculateDynamicLGD(100 - pool.expectedRecoveryRate, pool.waLtv, scenario);
    const grossLosses = defaults * (lgdPercent / 100);
    const recoveries = defaults * ((100 - lgdPercent) / 100);

    const principalCollections = scheduledPrincipal;
    const totalCashInflow = interestCollections + principalCollections + prepayments + recoveries;

    // 5. CASCATA DEI PAGAMENTI (WATERFALL CASH OUTFLOW)
    let remainingCash = totalCashInflow;

    // Step 1: Spese Senior dell'operazione SPV (0.05% per annum)
    const seniorExpenses = Math.min(remainingCash, (openingCollateralBalance * (deal.spvExpensesRate / 100)) / 12);
    remainingCash -= seniorExpenses;

    // Step 2: Commissioni di Servicing (0.15% per annum)
    const servicingFees = Math.min(remainingCash, (openingCollateralBalance * (deal.servicingFeeRate / 100)) / 12);
    remainingCash -= servicingFees;

    // Step 3, 4, 5: Pagamento Interessi Tranche (Senior -> Mezzanine -> Junior)
    const trancheInterestPayments: Record<string, number> = {};
    const tranchePrincipalPayments: Record<string, number> = {};

    // Ordina tranche per grado di subordinazione (Senior prima)
    const sortedTranches = [...deal.tranches].sort((a, b) => b.subordination - a.subordination);

    // Pagamento Interessi
    sortedTranches.forEach(tranche => {
      const trState = tranchesState[tranche.id];
      if (trState.currentPrincipal > 0) {
        const monthlyCoupon = (trState.currentPrincipal * (trState.couponRate / 100)) / 12;
        const paidInterest = Math.min(remainingCash, monthlyCoupon);
        trancheInterestPayments[tranche.id] = paidInterest;
        remainingCash -= paidInterest;
      } else {
        trancheInterestPayments[tranche.id] = 0;
      }
    });

    // Step 6: Allocazione Capitale Tranche (Amortisation)
    const totalPrincipalAvailable = principalCollections + prepayments + recoveries;
    let remainingPrincipalToAllocate = Math.min(remainingCash, totalPrincipalAvailable);

    if (deal.principalAllocationMode === 'SEQUENTIAL') {
      // Ammortamento Sequenziale: prima la tranche Senior più alta fino all'estinzione
      for (const tranche of sortedTranches) {
        const trState = tranchesState[tranche.id];
        if (trState.currentPrincipal > 0 && remainingPrincipalToAllocate > 0) {
          const principalPaid = Math.min(trState.currentPrincipal, remainingPrincipalToAllocate);
          tranchePrincipalPayments[tranche.id] = principalPaid;
          trState.currentPrincipal -= principalPaid;
          remainingPrincipalToAllocate -= principalPaid;
          remainingCash -= principalPaid;
        } else {
          tranchePrincipalPayments[tranche.id] = tranchePrincipalPayments[tranche.id] || 0;
        }
      }
    } else {
      // Ammortamento Pro-Rata
      const totalTranchePrincipal = Object.values(tranchesState).reduce((s, t) => s + t.currentPrincipal, 0);
      for (const tranche of sortedTranches) {
        const trState = tranchesState[tranche.id];
        if (trState.currentPrincipal > 0 && totalTranchePrincipal > 0) {
          const share = trState.currentPrincipal / totalTranchePrincipal;
          const principalPaid = Math.min(trState.currentPrincipal, remainingPrincipalToAllocate * share);
          tranchePrincipalPayments[tranche.id] = principalPaid;
          trState.currentPrincipal -= principalPaid;
          remainingCash -= principalPaid;
        } else {
          tranchePrincipalPayments[tranche.id] = tranchePrincipalPayments[tranche.id] || 0;
        }
      }
    }

    // Step 7: Ripristino Conto di Riserva (Reserve Account Replenishment)
    const reserveDeficit = Math.max(0, deal.reserveAccountTarget - currentReserveBalance);
    const reserveReplenishment = Math.min(remainingCash, reserveDeficit);
    currentReserveBalance += reserveReplenishment;
    remainingCash -= reserveReplenishment;

    // Step 8: Excess Spread & Distribuzione Residui / Equity
    const excessSpread = Math.max(0, remainingCash * 0.4);
    const equityDistribution = Math.max(0, remainingCash - excessSpread);
    remainingCash = 0;

    const totalCashOutflow = seniorExpenses + servicingFees + 
      Object.values(trancheInterestPayments).reduce((a, b) => a + b, 0) +
      Object.values(tranchePrincipalPayments).reduce((a, b) => a + b, 0) +
      reserveReplenishment + excessSpread + equityDistribution;

    // 6. Aggiornamento saldi di chiusura e perdita cumulativa
    cumulativeLosses += grossLosses;
    currentCollateralBalance = Math.max(0, openingCollateralBalance - principalCollections - prepayments - defaults);

    const trancheClosingBalances: Record<string, number> = {};
    deal.tranches.forEach(t => {
      trancheClosingBalances[t.id] = tranchesState[t.id].currentPrincipal;
    });

    // 7. RICONCILIAZIONE CONTABILE A DOPPIA ENTRATA (DOUBLE-ENTRY CASH RECONCILIATION)
    // Formula: Opening + Interest + Principal + Recoveries - Principal Repaid - Interest Paid - Expenses - Reserves - Excess - Equity = 0
    const netCashDiscrepancy = Math.abs(totalCashInflow - totalCashOutflow);

    flows.push({
      month,
      date: dateString,
      openingCollateralBalance,
      interestCollections,
      principalCollections,
      prepayments,
      defaults,
      recoveries,
      grossLosses,
      totalCashInflow,
      seniorExpenses,
      servicingFees,
      trancheInterestPayments,
      tranchePrincipalPayments,
      reserveAccountReplenishment: reserveReplenishment,
      excessSpread,
      equityDistribution,
      totalCashOutflow,
      closingCollateralBalance: currentCollateralBalance,
      trancheClosingBalances,
      cumulativeLosses,
      reconciliationCheck: {
        isBalanced: netCashDiscrepancy < 0.01,
        errorMargin: netCashDiscrepancy
      }
    });
  }

  return flows;
}
