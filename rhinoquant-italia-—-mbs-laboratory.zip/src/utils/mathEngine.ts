/**
 * @file mathEngine.ts
 * RHINOQUANT ITALIA - Mortgage Cash Flow & Financial Math Engine
 * Implementazione dei modelli finanziari quantitativi per mutui residenziali italiani.
 */

import { Mortgage, Pool, StressScenario, YieldCurvePoint } from '../types/mbs';

/**
 * Converts CPR (Conditional Prepayment Rate) to SMM (Single Monthly Mortality)
 * Formula: SMM = 1 - (1 - CPR)^(1/12)
 */
export function cprToSmm(cprPercent: number): number {
  const cprDecimal = Math.max(0, Math.min(100, cprPercent)) / 100;
  return 1 - Math.pow(1 - cprDecimal, 1 / 12);
}

/**
 * Converts Annual PD (Probability of Default) to Monthly Default Rate (MDR)
 * Formula: MDR = 1 - (1 - PD)^(1/12)
 */
export function pdToMdr(annualPdPercent: number): number {
  const pdDecimal = Math.max(0, Math.min(100, annualPdPercent)) / 100;
  return 1 - Math.pow(1 - pdDecimal, 1 / 12);
}

/**
 * Ammortamento Francese: Calcolo della rata mensile costante
 * R = P * [i * (1+i)^n] / [(1+i)^n - 1]
 */
export function calculateFrenchMonthlyPayment(
  principal: number,
  annualInterestRatePercent: number,
  remainingTermMonths: number
): number {
  if (principal <= 0 || remainingTermMonths <= 0) return 0;
  
  const monthlyRate = annualInterestRatePercent / 100 / 12;
  if (monthlyRate === 0) {
    return principal / remainingTermMonths;
  }

  const factor = Math.pow(1 + monthlyRate, remainingTermMonths);
  const payment = (principal * monthlyRate * factor) / (factor - 1);
  return Number.isFinite(payment) ? payment : principal / remainingTermMonths;
}

/**
 * Weighted Average Coupon (WAC)
 */
export function calculateWAC(loans: Mortgage[]): number {
  if (!loans || loans.length === 0) return 0;
  const totalBalance = loans.reduce((sum, l) => sum + l.currentBalance, 0);
  if (totalBalance === 0) return 0;
  const weightedSum = loans.reduce((sum, l) => sum + l.interestRate * l.currentBalance, 0);
  return weightedSum / totalBalance;
}

/**
 * Weighted Average Maturity (WAM) - in mesi
 */
export function calculateWAM(loans: Mortgage[]): number {
  if (!loans || loans.length === 0) return 0;
  const totalBalance = loans.reduce((sum, l) => sum + l.currentBalance, 0);
  if (totalBalance === 0) return 0;
  const weightedSum = loans.reduce((sum, l) => sum + l.remainingTermMonths * l.currentBalance, 0);
  return weightedSum / totalBalance;
}

/**
 * Weighted Average LTV (WA LTV)
 */
export function calculateWALTV(loans: Mortgage[]): number {
  if (!loans || loans.length === 0) return 0;
  const totalBalance = loans.reduce((sum, l) => sum + l.currentBalance, 0);
  if (totalBalance === 0) return 0;
  const weightedSum = loans.reduce((sum, l) => sum + l.ltv * l.currentBalance, 0);
  return weightedSum / totalBalance;
}

/**
 * Weighted Average LTI (WA LTI)
 */
export function calculateWALTI(loans: Mortgage[]): number {
  if (!loans || loans.length === 0) return 0;
  const totalBalance = loans.reduce((sum, l) => sum + l.currentBalance, 0);
  if (totalBalance === 0) return 0;
  const weightedSum = loans.reduce((sum, l) => sum + l.lti * l.currentBalance, 0);
  return weightedSum / totalBalance;
}

/**
 * Weighted Average Seasoning (WA Seasoning) - in mesi
 */
export function calculateWASeasoning(loans: Mortgage[]): number {
  if (!loans || loans.length === 0) return 0;
  const totalBalance = loans.reduce((sum, l) => sum + l.currentBalance, 0);
  if (totalBalance === 0) return 0;
  const weightedSum = loans.reduce((sum, l) => sum + l.seasoningMonths * l.currentBalance, 0);
  return weightedSum / totalBalance;
}

/**
 * Weighted Average Life (WAL) - in anni
 * WAL = Sum(t * Principal_t) / Total_Principal
 */
export function calculateWALFromCashFlows(principalFlows: number[]): number {
  const totalPrincipal = principalFlows.reduce((sum, p) => sum + p, 0);
  if (totalPrincipal === 0) return 0;
  let weightedSumMonths = 0;
  for (let m = 0; m < principalFlows.length; m++) {
    weightedSumMonths += (m + 1) * principalFlows[m];
  }
  return weightedSumMonths / totalPrincipal / 12;
}

/**
 * Modello dinamico di PD (Probabilità di Default)
 * Regola PD in base a LTV, Seasoning, Tassi di interesse e Shock immobiliare
 */
export function calculateDynamicMonthlyPD(
  baseAnnualPd: number,
  ltv: number,
  seasoningMonths: number,
  scenario?: StressScenario
): number {
  let adjustedAnnualPd = baseAnnualPd;

  // LTV multiplier: LTV > 80% increases default probability exponentially in Italian mortgages
  if (ltv > 80) {
    adjustedAnnualPd *= (1 + Math.pow((ltv - 80) / 20, 1.5));
  } else if (ltv < 50) {
    adjustedAnnualPd *= 0.7;
  }

  // Seasoning effect (Inizialmente cresce fino al mese 36, poi diminuisce per l'effetto di accumulo di equity)
  if (seasoningMonths < 12) {
    adjustedAnnualPd *= 0.8; // seasoning iniziale bassi arretrati
  } else if (seasoningMonths >= 12 && seasoningMonths <= 48) {
    adjustedAnnualPd *= 1.25; // picco storico dei default RMBS italiani
  } else if (seasoningMonths > 48) {
    adjustedAnnualPd *= Math.max(0.4, 1 - (seasoningMonths - 48) * 0.01);
  }

  // Application of Macro Scenario
  if (scenario) {
    adjustedAnnualPd *= scenario.pdMultiplier;
  }

  return pdToMdr(Math.min(95, adjustedAnnualPd));
}

/**
 * Modello dinamico di LGD (Loss Given Default) e Recuperi per il mercato italiano
 * Considera il valore dell'immobile, haircut d'asta e tempi di escussione giudiziaria
 */
export function calculateDynamicLGD(
  baseLgd: number,
  ltv: number,
  scenario?: StressScenario
): { lgdPercent: number; netRecoveryRatePercent: number } {
  let adjustedLgd = baseLgd;

  // Se LTV è molto basso, il recupero dall'asta copre gran parte del debito residuo
  if (ltv <= 60) {
    adjustedLgd = Math.min(adjustedLgd, 15);
  } else if (ltv > 85) {
    adjustedLgd = Math.min(95, adjustedLgd * 1.3);
  }

  if (scenario) {
    adjustedLgd *= scenario.lgdMultiplier;
  }

  adjustedLgd = Math.max(5, Math.min(95, adjustedLgd));
  const netRecoveryRatePercent = 100 - adjustedLgd;

  return {
    lgdPercent: adjustedLgd,
    netRecoveryRatePercent
  };
}

/**
 * Curva dei tassi di riferimento italiani (Euribor + IRS)
 */
export const DEFAULT_ITALIAN_YIELD_CURVE: YieldCurvePoint[] = [
  { tenor: '1M', euriborRate: 3.10, irsRate: 2.95, riskFreeRate: 2.80 },
  { tenor: '3M', euriborRate: 3.25, irsRate: 3.05, riskFreeRate: 2.85 },
  { tenor: '6M', euriborRate: 3.35, irsRate: 3.10, riskFreeRate: 2.90 },
  { tenor: '1Y', euriborRate: 3.40, irsRate: 3.15, riskFreeRate: 2.95 },
  { tenor: '2Y', euriborRate: 3.30, irsRate: 3.05, riskFreeRate: 2.85 },
  { tenor: '3Y', euriborRate: 3.15, irsRate: 2.95, riskFreeRate: 2.75 },
  { tenor: '5Y', euriborRate: 3.00, irsRate: 2.85, riskFreeRate: 2.65 },
  { tenor: '7Y', euriborRate: 2.95, irsRate: 2.80, riskFreeRate: 2.60 },
  { tenor: '10Y', euriborRate: 3.05, irsRate: 2.90, riskFreeRate: 2.70 },
  { tenor: '15Y', euriborRate: 3.15, irsRate: 3.00, riskFreeRate: 2.80 },
  { tenor: '20Y', euriborRate: 3.20, irsRate: 3.05, riskFreeRate: 2.85 },
  { tenor: '30Y', euriborRate: 3.25, irsRate: 3.10, riskFreeRate: 2.90 },
];
