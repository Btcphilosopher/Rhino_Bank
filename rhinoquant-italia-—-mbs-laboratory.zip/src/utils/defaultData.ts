/**
 * @file defaultData.ts
 * RHINOQUANT ITALIA - Pre-built Initial Demonstration "RQ ITALIA DEMO 01"
 * Inizializza l'intera catena: MUTUI -> POOL -> CARTOLARIZZAZIONE -> WATERFALL -> TRANCHES -> PRICING -> RISCHIO.
 */

import { Pool, SecuritisationDeal, StressScenario, ResearchExperiment } from '../types/mbs';
import { generateSyntheticMortgages } from './syntheticDataGenerator';
import { runMonthlyWaterfall } from './waterfallEngine';
import { calculateTranchePricing } from './pricingEngine';

const sampleLoans = generateSyntheticMortgages({ count: 250, seed: 9999 });

const totalCollateral = 15250000000; // € 15,25 MLD

export const DEMO_POOL: Pool = {
  id: 'POOL-RQ-ITA-2026-01',
  name: 'Portafoglio Ipotecario Residenziale Italiano Alpha 2026',
  createdDate: '2026-10-01',
  loansCount: 100000,
  totalOriginalBalance: 18500000000,
  totalCurrentBalance: totalCollateral,
  averageLoanSize: 152500,
  wac: 3.85,
  wam: 224, // mesi
  wal: 4.62, // anni
  waLtv: 64.2, // %
  waLti: 28.5, // %
  waSeasoning: 42, // mesi
  fixedRatePercentage: 62.0,
  variableRatePercentage: 38.0,
  geographicDistribution: {
    'NORD': 52.0,
    'CENTRO': 26.0,
    'SUD': 15.0,
    'ISOLE': 7.0,
    'Lombardia': 24.5,
    'Lazio': 15.2,
    'Veneto': 11.8,
    'Emilia-Romagna': 10.5,
    'Piemonte': 9.2,
    'Toscana': 7.8,
    'Campania': 6.5,
    'Puglia': 5.2,
    'Sicilia': 4.8,
    'Liguria': 2.5,
    'Sardegna': 2.0,
    'Altre Regioni': 0.0
  },
  ratingDistribution: {
    'AAA': 45.0,
    'AA': 30.0,
    'A': 15.0,
    'BBB': 7.0,
    'BB': 2.0,
    'B': 0.8,
    'CCC': 0.2,
    'NR': 0.0
  },
  expectedLossRate: 0.85,
  expectedRecoveryRate: 78.5,
  loansSample: sampleLoans
};

export const DEMO_DEAL: SecuritisationDeal = {
  id: 'SPV-RQ-ITA-2026-1',
  dealName: 'RHINOQUANT ITALIA RMBS 2026-1 SPV S.r.l.',
  issueDate: '2026-10-03',
  collateralPoolId: DEMO_POOL.id,
  initialCollateralBalance: totalCollateral,
  currentCollateralBalance: totalCollateral,
  reserveAccountBalance: 381250000, // 2.5%
  reserveAccountTarget: 381250000,
  liquidityReserve: 152500000, // 1.0%
  servicingFeeRate: 0.15,
  spvExpensesRate: 0.05,
  overcollateralisation: 457500000, // 3.0%
  excessSpreadTarget: 1.20,
  principalAllocationMode: 'SEQUENTIAL',
  tranches: [
    {
      id: 'TR-A1',
      name: 'Classe A1 Senior',
      originalPrincipal: 10675000000, // 70.0%
      currentPrincipal: 10675000000,
      attachmentPoint: 30.0,
      detachmentPoint: 100.0,
      subordination: 30.0,
      couponType: 'VARIABILE',
      couponRate: 4.00, // Euribor 3.25 + 0.75%
      spreadBps: 75,
      rating: 'AAA',
      wal: 3.4,
      duration: 3.2,
      modifiedDuration: 3.1,
      convexity: 0.045,
      expectedLoss: 0.02,
      cumulativeLossAllocated: 0,
      impairmentProbability: 0.1
    },
    {
      id: 'TR-A2',
      name: 'Classe A2 Senior Mezzanine',
      originalPrincipal: 2287500000, // 15.0%
      currentPrincipal: 2287500000,
      attachmentPoint: 15.0,
      detachmentPoint: 30.0,
      subordination: 15.0,
      couponType: 'VARIABILE',
      couponRate: 4.35, // Euribor + 110 bps
      spreadBps: 110,
      rating: 'AA',
      wal: 5.2,
      duration: 4.8,
      modifiedDuration: 4.6,
      convexity: 0.062,
      expectedLoss: 0.15,
      cumulativeLossAllocated: 0,
      impairmentProbability: 0.8
    },
    {
      id: 'TR-B',
      name: 'Classe B Mezzanine',
      originalPrincipal: 1220000000, // 8.0%
      currentPrincipal: 1220000000,
      attachmentPoint: 7.0,
      detachmentPoint: 15.0,
      subordination: 7.0,
      couponType: 'VARIABILE',
      couponRate: 5.45, // Euribor + 220 bps
      spreadBps: 220,
      rating: 'A',
      wal: 6.8,
      duration: 6.1,
      modifiedDuration: 5.8,
      convexity: 0.088,
      expectedLoss: 0.85,
      cumulativeLossAllocated: 0,
      impairmentProbability: 3.5
    },
    {
      id: 'TR-C',
      name: 'Classe C Junior',
      originalPrincipal: 610000000, // 4.0%
      currentPrincipal: 610000000,
      attachmentPoint: 3.0,
      detachmentPoint: 7.0,
      subordination: 3.0,
      couponType: 'VARIABILE',
      couponRate: 7.75, // Euribor + 450 bps
      spreadBps: 450,
      rating: 'BBB',
      wal: 8.5,
      duration: 7.2,
      modifiedDuration: 6.8,
      convexity: 0.120,
      expectedLoss: 3.40,
      cumulativeLossAllocated: 0,
      impairmentProbability: 12.8
    },
    {
      id: 'TR-EQ',
      name: 'Titoli Junior Residui / Equity',
      originalPrincipal: 457500000, // 3.0%
      currentPrincipal: 457500000,
      attachmentPoint: 0.0,
      detachmentPoint: 3.0,
      subordination: 0.0,
      couponType: 'VARIABILE',
      couponRate: 11.50,
      spreadBps: 825,
      rating: 'NR',
      wal: 10.2,
      duration: 8.1,
      modifiedDuration: 7.5,
      convexity: 0.180,
      expectedLoss: 18.50,
      cumulativeLossAllocated: 0,
      impairmentProbability: 42.0
    }
  ]
};

export const DEMO_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'SC-BASE',
    name: 'Scenario Base (Macro Nominale)',
    description: 'Nessun aumento significativo dei default. Prepayment costante al 5.0% CPR.',
    housePriceShockPercent: 0,
    interestRateShiftBps: 0,
    pdMultiplier: 1.0,
    lgdMultiplier: 1.0,
    cprMultiplier: 1.0,
    recoveryDelayMonthsDelta: 0
  },
  {
    id: 'SC-RECESSION',
    name: 'Recessione Severa Italia',
    description: 'Contrazione PIL, disoccupazione in aumento. PD moltiplicata per 2.5x, LGD +25%.',
    housePriceShockPercent: -10,
    interestRateShiftBps: +100,
    pdMultiplier: 2.5,
    lgdMultiplier: 1.25,
    cprMultiplier: 0.6,
    recoveryDelayMonthsDelta: 12
  },
  {
    id: 'SC-PROPERTY-SHOCK',
    name: 'Shock Immobiliare (-20%)',
    description: 'Crollo del 20% dei prezzi delle abitazioni residenziali. Aumento LGD al 38%.',
    housePriceShockPercent: -20,
    interestRateShiftBps: +50,
    pdMultiplier: 2.0,
    lgdMultiplier: 1.45,
    cprMultiplier: 0.5,
    recoveryDelayMonthsDelta: 18
  },
  {
    id: 'SC-RATE-SPIKE',
    name: 'Impennata Tassi (+250 bps)',
    description: 'Aumento Euribor a 5.75%. Ripercussione sulle rate dei mutui a tasso variabile.',
    housePriceShockPercent: -5,
    interestRateShiftBps: +250,
    pdMultiplier: 1.8,
    lgdMultiplier: 1.1,
    cprMultiplier: 0.4,
    recoveryDelayMonthsDelta: 6
  },
  {
    id: 'SC-PREPAY-SPEED',
    name: 'Accelerazione Prepayment (18% CPR)',
    description: 'Onda di rinegoziazioni e surroghe. Rischio di estinzione anticipata della tranche Senior.',
    housePriceShockPercent: 0,
    interestRateShiftBps: -100,
    pdMultiplier: 0.8,
    lgdMultiplier: 0.9,
    cprMultiplier: 3.2,
    recoveryDelayMonthsDelta: 0
  }
];

export const DEMO_EXPERIMENT: ResearchExperiment = {
  id: 'EXP-RQ-2026-001',
  title: 'Valutazione della Struttura RMBS e Resilienza delle Tranche Mezzanine',
  timestamp: '2026-10-03 08:15:00',
  author: 'Desk Ricerca Quantitativa Rhinoquant',
  seed: 9999,
  datasetId: 'DATASET-ITA-100K-SYNTHETIC',
  modelVersion: 'v2.4.1-ITALIA-DETERMINISTIC',
  parameters: {
    collateralAmount: 15250000000,
    tranchesCount: 5,
    seniorSubordination: '30.0%',
    defaultModel: 'Dynamic LTV-Seasoning PD',
    prepaymentModel: 'SMM-CPR Burnout'
  },
  resultsSummary: {
    totalCollateral: 15250000000,
    wac: 3.85,
    wal: 4.62,
    seniorYield: 4.08,
    expectedLoss: 0.85,
    var95: 381250000
  },
  checksum: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  notes: 'Analisi condotta con successo. Tutte le verifiche di bilancio a doppia entrata risultano rispettate con scarto nullo.'
};

export const INITIAL_DEMO_WATERFALL = runMonthlyWaterfall({
  deal: DEMO_DEAL,
  pool: DEMO_POOL,
  monthsCount: 180
});

export const INITIAL_DEMO_PRICING = DEMO_DEAL.tranches.map(t => 
  calculateTranchePricing({ tranche: t, waterfallFlows: INITIAL_DEMO_WATERFALL })
);
