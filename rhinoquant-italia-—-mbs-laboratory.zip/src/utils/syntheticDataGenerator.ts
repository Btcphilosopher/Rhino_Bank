/**
 * @file syntheticDataGenerator.ts
 * RHINOQUANT ITALIA - Synthetic Italian Mortgage Universe Generator
 * Genera distribuzioni realistiche e deterministiche per il mercato ipotecario italiano.
 */

import { Mortgage, ItalianRegion, MacroZone, PropertyType, CreditRating, PaymentStatus, ReferenceIndex } from '../types/mbs';

export interface GeneratorOptions {
  count?: number; // Numero di mutui da generare
  seed?: number; // Seed deterministico
  meanAmount?: number; // Importo medio (es. € 145.000)
  targetMacroZone?: MacroZone;
  fixedRateRatio?: number; // e.g. 0.65 (65% Fisso)
}

const REGIONS_BY_MACRO_ZONE: Record<MacroZone, { region: ItalianRegion; provinces: string[]; weight: number }[]> = {
  NORD: [
    { region: 'Lombardia', provinces: ['MI', 'BS', 'BG', 'MB', 'VA', 'CO', 'PV'], weight: 0.35 },
    { region: 'Veneto', provinces: ['VE', 'VR', 'TV', 'PD', 'VI'], weight: 0.20 },
    { region: 'Emilia-Romagna', provinces: ['BO', 'MO', 'PR', 'RE', 'RA'], weight: 0.20 },
    { region: 'Piemonte', provinces: ['TO', 'CN', 'NO', 'AL'], weight: 0.18 },
    { region: 'Liguria', provinces: ['GE', 'SV', 'SP'], weight: 0.07 }
  ],
  CENTRO: [
    { region: 'Lazio', provinces: ['RM', 'LT', 'FR', 'VT'], weight: 0.55 },
    { region: 'Toscana', provinces: ['FI', 'PI', 'LU', 'AR', 'SI'], weight: 0.45 }
  ],
  SUD: [
    { region: 'Campania', provinces: ['NA', 'SA', 'CE'], weight: 0.60 },
    { region: 'Puglia', provinces: ['BA', 'LE', 'TA', 'FG'], weight: 0.40 }
  ],
  ISOLE: [
    { region: 'Sicilia', provinces: ['PA', 'CT', 'ME', 'SR'], weight: 0.70 },
    { region: 'Sardegna', provinces: ['CA', 'SS', 'NU'], weight: 0.30 }
  ]
};

const PROPERTY_TYPES: PropertyType[] = [
  'RESIDENZIALE_PRINCIPALE',
  'RESIDENZIALE_PRINCIPALE',
  'APPARTAMENTO',
  'APPARTAMENTO',
  'SECONDA_CASA',
  'VILLA',
  'INDIPENDENTE'
];

function pseudoRandom(seed: number) {
  let s = seed;
  return function () {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

export function generateSyntheticMortgages(options: GeneratorOptions = {}): Mortgage[] {
  const count = options.count || 1000;
  const seed = options.seed || 12345;
  const meanAmount = options.meanAmount || 155000;
  const fixedRateRatio = options.fixedRateRatio !== undefined ? options.fixedRateRatio : 0.65;

  const rnd = pseudoRandom(seed);

  const mortgages: Mortgage[] = [];

  for (let i = 1; i <= count; i++) {
    const loanId = `RQ-ITA-${String(i).padStart(6, '0')}`;
    const borrowerId = `CF-ITA-${String(Math.floor(rnd() * 899999 + 100000))}`;

    // Distribuzione log-normale approssimata per l'importo originario
    const amountFactor = 0.5 + rnd() * 1.2;
    const originalAmount = Math.round((meanAmount * amountFactor) / 5000) * 5000;

    // LTV distribuzione centrata sul 68%
    const ltv = Math.round(35 + rnd() * 55); // 35% - 90%
    const propertyValue = Math.round(originalAmount / (ltv / 100));

    // Durata originaria tra 15 e 30 anni (180 - 360 mesi)
    const termsChoices = [180, 240, 300, 360];
    const originalTermMonths = termsChoices[Math.floor(rnd() * termsChoices.length)];

    // Anzianità (Seasoning) tra 6 e 96 mesi
    const seasoningMonths = Math.floor(6 + rnd() * 90);
    const remainingTermMonths = Math.max(12, originalTermMonths - seasoningMonths);

    // Saldo residuo attuale basato su seasoning
    const paidRatio = seasoningMonths / originalTermMonths;
    const currentBalance = Math.round(originalAmount * (1 - paidRatio * 0.75));

    // Tasso Fisso vs Variabile
    const isFixed = rnd() < fixedRateRatio;
    const rateType = isFixed ? 'FISSO' : 'VARIABILE';

    let referenceIndex: ReferenceIndex = 'EURIBOR_3M';
    let indexValue = 3.25;
    let spread = Number((0.85 + rnd() * 1.10).toFixed(2));

    if (isFixed) {
      referenceIndex = originalTermMonths >= 300 ? 'IRS_30Y' : 'IRS_20Y';
      indexValue = 3.05;
      spread = Number((0.95 + rnd() * 0.85).toFixed(2));
    }

    const interestRate = Number((indexValue + spread).toFixed(2));

    // Rata Mensile (Ammortamento Francese)
    const monthlyRate = interestRate / 100 / 12;
    const factor = Math.pow(1 + monthlyRate, remainingTermMonths);
    const monthlyPayment = Math.round((currentBalance * monthlyRate * factor) / (factor - 1));

    // Reddito del debitore e LTI / DTI
    const borrowerIncome = Math.round(monthlyPayment * 12 * (2.8 + rnd() * 2.2));
    const lti = Number(((monthlyPayment * 12) / borrowerIncome * 100).toFixed(1));

    // Zona geografica italiana
    const macroZones: MacroZone[] = ['NORD', 'NORD', 'CENTRO', 'SUD', 'ISOLE'];
    const macroZone = options.targetMacroZone || macroZones[Math.floor(rnd() * macroZones.length)];
    const regionObjList = REGIONS_BY_MACRO_ZONE[macroZone];
    const regionObj = regionObjList[Math.floor(rnd() * regionObjList.length)];
    const region = regionObj.region;
    const province = regionObj.provinces[Math.floor(rnd() * regionObj.provinces.length)];

    const propertyType = PROPERTY_TYPES[Math.floor(rnd() * PROPERTY_TYPES.length)];

    // Stato di pagamento & Rating Creditizio
    let paymentStatus: PaymentStatus = 'IN_BONIS';
    let arrearsAmount = 0;
    let creditRating: CreditRating = 'AAA';
    let annualPD = 0.8;

    const riskRoll = rnd();
    if (riskRoll > 0.96) {
      paymentStatus = 'ARRETRATO_90';
      arrearsAmount = monthlyPayment * 3;
      creditRating = 'B';
      annualPD = 8.5;
    } else if (riskRoll > 0.92) {
      paymentStatus = 'ARRETRATO_60';
      arrearsAmount = monthlyPayment * 2;
      creditRating = 'BB';
      annualPD = 4.2;
    } else if (riskRoll > 0.85) {
      paymentStatus = 'ARRETRATO_30';
      arrearsAmount = monthlyPayment;
      creditRating = 'BBB';
      annualPD = 2.4;
    } else if (riskRoll > 0.50) {
      creditRating = 'AA';
      annualPD = 1.1;
    }

    // Recovery & LGD
    const lgd = ltv > 80 ? 32 : 18;
    const expectedRecoveryRate = 100 - lgd;

    mortgages.push({
      id: loanId,
      borrowerId,
      originalAmount,
      currentBalance,
      rateType,
      referenceIndex,
      indexValue,
      spread,
      interestRate,
      originalTermMonths,
      remainingTermMonths,
      seasoningMonths,
      monthlyPayment,
      amortizationType: 'FRANCESE',
      paymentFrequency: 'MENSILE',
      ltv,
      lti,
      borrowerIncome,
      propertyValue,
      propertyType,
      macroZone,
      region,
      province,
      creditRating,
      paymentStatus,
      arrearsAmount,
      annualPD,
      annualCPR: Number((4.0 + rnd() * 5.0).toFixed(1)),
      lgd,
      expectedRecoveryRate,
      recoveryDelayMonths: region === 'Lombardia' || region === 'Emilia-Romagna' ? 24 : 36
    });
  }

  return mortgages;
}
