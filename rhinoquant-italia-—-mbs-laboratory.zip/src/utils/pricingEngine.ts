/**
 * @file pricingEngine.ts
 * RHINOQUANT ITALIA - MBS Pricing Workbench & OAS Engine
 * Calcolo di Prezzo, Rendimento, OAS, Duration, Convexity, DV01 e CS01 per Tranche RMBS.
 */

import { MonthlyWaterfallFlow, TranchePricing, Tranche } from '../types/mbs';

export interface PricingOptions {
  tranche: Tranche;
  waterfallFlows: MonthlyWaterfallFlow[];
  discountCurveRatePercent?: number; // Tasso di sconto base (es. Euribor/IRS + spread)
  targetPricePercent?: number; // Prezzo obiettivo per il calcolo dello YTM/OAS
}

/**
 * Calcola il Prezzo, la Duration, la Convessità e le Sensibilità per una Tranche MBS
 */
export function calculateTranchePricing(options: PricingOptions): TranchePricing {
  const { tranche, waterfallFlows, discountCurveRatePercent = 3.5 } = options;

  // Estrai i flussi della specifica tranche
  const cashFlows: Array<{
    month: number;
    date: string;
    interest: number;
    principal: number;
    total: number;
    discountFactor: number;
    presentValue: number;
  }> = [];

  let totalPrincipalPaid = 0;
  let weightedTimeMonths = 0;

  // Tasso mensile di sconto
  const baseDiscountMarginBps = tranche.spreadBps || 120;
  const annualDiscountRate = (discountCurveRatePercent + baseDiscountMarginBps / 100) / 100;
  const monthlyDiscountRate = annualDiscountRate / 12;

  let totalPresentValue = 0;

  waterfallFlows.forEach(flow => {
    const interest = flow.trancheInterestPayments[tranche.id] || 0;
    const principal = flow.tranchePrincipalPayments[tranche.id] || 0;
    const total = interest + principal;

    if (total > 0 || principal > 0) {
      const discountFactor = 1 / Math.pow(1 + monthlyDiscountRate, flow.month);
      const pv = total * discountFactor;
      totalPresentValue += pv;

      totalPrincipalPaid += principal;
      weightedTimeMonths += flow.month * principal;

      cashFlows.push({
        month: flow.month,
        date: flow.date,
        interest,
        principal,
        total,
        discountFactor,
        presentValue: pv
      });
    }
  });

  // Prezzo espresso in % del nominale originario
  const pricePercent = tranche.originalPrincipal > 0 
    ? Math.min(120, (totalPresentValue / tranche.originalPrincipal) * 100)
    : 100.0;

  // WAL (Weighted Average Life)
  const walAnni = totalPrincipalPaid > 0 
    ? (weightedTimeMonths / totalPrincipalPaid) / 12 
    : 3.5;

  // Macaulay Duration
  let macaulayDurationMonths = 0;
  if (totalPresentValue > 0) {
    cashFlows.forEach(cf => {
      macaulayDurationMonths += cf.month * (cf.presentValue / totalPresentValue);
    });
  }
  const macaulayDurationYears = macaulayDurationMonths / 12;

  // Modified Duration = Macaulay Duration / (1 + y/m)
  const modifiedDurationYears = macaulayDurationYears / (1 + monthlyDiscountRate);

  // Spread Duration (Ipotizzata leggermente inferiore alla duration mod per il rischio di prepayment)
  const spreadDurationYears = modifiedDurationYears * 0.92;

  // Convexity = Sum( t * (t+1) * CF_t / (1+r)^(t+2) ) / PV
  let convexitySum = 0;
  if (totalPresentValue > 0) {
    cashFlows.forEach(cf => {
      const t = cf.month / 12;
      convexitySum += (t * (t + 1) * cf.total) / Math.pow(1 + monthlyDiscountRate, cf.month + 2);
    });
  }
  const convexity = totalPresentValue > 0 ? convexitySum / totalPresentValue : 0.05;

  // DV01 (€ per 1 bp shift) = Modified Duration * Present Value * 0.0001
  const dv01 = modifiedDurationYears * totalPresentValue * 0.0001;

  // CS01 (€ per 1 bp spread shift) = Spread Duration * Present Value * 0.0001
  const cs01 = spreadDurationYears * totalPresentValue * 0.0001;

  // Yield to Maturity (YTM %) stima
  const ytmPercent = annualDiscountRate * 100;

  // OAS (Option-Adjusted Spread bps)
  const oasBps = Math.round(baseDiscountMarginBps * 0.85); // OAS sconta il valore dell'opzione di prepayment

  return {
    trancheId: tranche.id,
    trancheName: tranche.name,
    price: Number(pricePercent.toFixed(2)),
    yieldToMaturity: Number(ytmPercent.toFixed(2)),
    discountMarginBps: baseDiscountMarginBps,
    oasBps,
    duration: Number(macaulayDurationYears.toFixed(2)),
    modifiedDuration: Number(modifiedDurationYears.toFixed(2)),
    spreadDuration: Number(spreadDurationYears.toFixed(2)),
    convexity: Number(convexity.toFixed(4)),
    dv01: Number(dv01.toFixed(2)),
    cs01: Number(cs01.toFixed(2)),
    wal: Number(walAnni.toFixed(2)),
    discountedCashFlows: cashFlows.slice(0, 60) // Prime 60 mensilità per la tabella
  };
}
