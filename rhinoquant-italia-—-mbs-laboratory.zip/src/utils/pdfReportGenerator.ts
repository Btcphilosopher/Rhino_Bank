/**
 * @file pdfReportGenerator.ts
 * RHINOQUANT ITALIA - Institutional RMBS Quantitative Report Generator
 * Genera il "Rapporto di Ricerca MBS" completo in lingua italiana.
 */

import { SecuritisationDeal, Pool, TranchePricing, MonteCarloResult, StressScenario, ResearchExperiment } from '../types/mbs';

export interface ReportData {
  deal: SecuritisationDeal;
  pool: Pool;
  pricing: TranchePricing[];
  monteCarlo?: MonteCarloResult;
  scenarios: StressScenario[];
  experiment?: ResearchExperiment;
  generatedDate: string;
}

export function generateFullReportMarkdown(data: ReportData): string {
  const { deal, pool, pricing, monteCarlo, scenarios, generatedDate } = data;

  return `# RHINOQUANT ITALIA — MBS LABORATORY
## RAPPORTO DI RICERCA QUANTITATIVA E STRUTTURAZIONE RMBS

**Riferimento Operazione:** ${deal.dealName}  
**Identificativo Veicolo (SPV):** ${deal.id}  
**Data del Report:** ${generatedDate}  
**Versione del Modello:** v2.4.1-ITALIA-DETERMINISTIC  
**Origine Dati:** Dati Sintetici di Mercato (Synthetic Italian Mortgage Universe)  
**Checksum Audit:** \`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\`

---

### 1. SINTESI DELL'OPERAZIONE
L'operazione **${deal.dealName}** costituisce una cartolarizzazione ipotecaria residenziale italiana (RMBS - Residential Mortgage-Backed Securities) avente ad oggetto un portafoglio ipotecario sintetico originato nel mercato italiano per un importo nominale complessivo pari a **€ ${deal.initialCollateralBalance.toLocaleString('it-IT')}**.

* **Emittente (SPV):** ${deal.dealName}
* **Valore Collaterale Iniziale:** € ${deal.initialCollateralBalance.toLocaleString('it-IT')}
* **Conto di Riserva (Reserve Account):** € ${deal.reserveAccountBalance.toLocaleString('it-IT')} (2,50% del Collaterale)
* **Riserva di Liquidità:** € ${deal.liquidityReserve.toLocaleString('it-IT')} (1,00%)
* **Overcollateralisation:** € ${deal.overcollateralisation.toLocaleString('it-IT')} (3,00%)
* **Modalità Allocazione Capitale:** ${deal.principalAllocationMode === 'SEQUENTIAL' ? 'Sequenziale (Senior First)' : 'Pro-Rata'}

---

### 2. DESCRITTIVA DEL POOL
Il portafoglio collaterale sintetico comprende un totale di **${pool.loansCount.toLocaleString('it-IT')} mutui residenziali italiani**.

| Metrica Collaterale | Valore Ponderato |
| :--- | :--- |
| **Saldo Totale Attuale** | € ${pool.totalCurrentBalance.toLocaleString('it-IT')} |
| **Importo Medio Mutuo** | € ${pool.averageLoanSize.toLocaleString('it-IT')} |
| **WAC (Weighted Average Coupon)** | ${pool.wac.toFixed(2)}% |
| **WAM (Weighted Average Maturity)** | ${pool.wam} mesi (${(pool.wam / 12).toFixed(1)} anni) |
| **WAL (Weighted Average Life)** | ${pool.wal.toFixed(2)} anni |
| **WA LTV (Loan-to-Value Ponderato)** | ${pool.waLtv.toFixed(1)}% |
| **WA LTI (Loan-to-Income Ponderato)** | ${pool.waLti.toFixed(1)}% |
| **WA Seasoning (Anzianità Ponderata)** | ${pool.waSeasoning} mesi |

---

### 3. CARATTERISTICHE DEI MUTUI
* **Quota Tasso Fisso:** ${pool.fixedRatePercentage.toFixed(1)}% (Indicizzato IRS 20Y/30Y)
* **Quota Tasso Variabile:** ${pool.variableRatePercentage.toFixed(1)}% (Indicizzato Euribor 3M / 6M)
* **Tipologia Ammortamento:** Ammortamento Francese a rate mensili costanti
* **Quality Rating Creditizio Ponderato:** AAA (45%), AA (30%), A (15%), BBB (7%), BB/B (3%)

---

### 4. ANALISI GEOGRAFICA (DISTRIBUZIONE REGIONALE ITALIANA)
Il portafoglio rispetta una distribuzione geografica rappresentativa delle macro-aree economiche italiane:

* **Nord Italia (52.0%):** Lombardia (${pool.geographicDistribution['Lombardia'] || 24.5}%), Veneto (${pool.geographicDistribution['Veneto'] || 11.8}%), Emilia-Romagna (${pool.geographicDistribution['Emilia-Romagna'] || 10.5}%), Piemonte (${pool.geographicDistribution['Piemonte'] || 9.2}%), Liguria (2.5%).
* **Centro Italia (26.0%):** Lazio (${pool.geographicDistribution['Lazio'] || 15.2}%), Toscana (${pool.geographicDistribution['Toscana'] || 7.8}%).
* **Sud Italia (15.0%):** Campania (${pool.geographicDistribution['Campania'] || 6.5}%), Puglia (${pool.geographicDistribution['Puglia'] || 5.2}%).
* **Isole (7.0%):** Sicilia (${pool.geographicDistribution['Sicilia'] || 4.8}%), Sardegna (${pool.geographicDistribution['Sardegna'] || 2.0}%).

---

### 5. PROIEZIONE DEI FLUSSI DI CASSA (CASH FLOW PROJECTION)
I flussi di cassa mensili del portafoglio collaterale vengono proiettati su un orizzonte di 360 mensilità tenendo conto dell'ammortamento contrattuale, delle stime di rimborso anticipato (CPR 5,0%), dei default attesi e dei recuperi derivanti dalle procedure esecutive immobiliari.

---

### 6. STRUTTURA DELLE TRANCHE E CREDIT ENHANCEMENT
L'operazione è suddivisa in 5 tranche obbligazionarie con priorità di pagamento e livelli di subordinazione differenziati:

| Nome Tranche | Valore Nominale (€) | Quota (%) | Coupon / Spread | Rating | Subordinazione (%) |
| :--- | :--- | :--- | :--- | :--- | :--- |
${deal.tranches.map(t => `| **${t.name}** | € ${t.originalPrincipal.toLocaleString('it-IT')} | ${((t.originalPrincipal / deal.initialCollateralBalance) * 100).toFixed(1)}% | Euribor + ${t.spreadBps} bps | ${t.rating} | ${t.subordination.toFixed(1)}% |`).join('\n')}

---

### 7. WATERFALL E PRIORITY OF PAYMENTS
La cascata mensile degli incassi soddisfa rigorosamente l'ordine di priorità istituzionale:
1. Spese di Gestione SPV e Servicing (Senior Expenses)
2. Riserva di Liquidità e Conto di Riserva (Reserve Account Replenishment)
3. Interessi Tranche Senior A1 e A2
4. Interessi Tranche Mezzanine B
5. Interessi Tranche Junior C
6. Allocazione Capitale Tranche (Ammortamento Sequenziale)
7. Excess Spread e Remunerazione Equity

---

### 8. ANALISI DEL CREDIT ENHANCEMENT
Il Credit Enhancement a protezione della Tranche Senior A1 è pari al **30,0%**, costituito da:
* Subordinazione diretta (Tranche A2, B, C, Equity): 27,0%
* Overcollateralisation: 3,0%
* Conto di Riserva dedicato: 2,5%

---

### 9. PRICING E VALUTAZIONE SUL MERCATO (PRICING WORKBENCH)

| Tranche | Prezzo (% Par) | YTM (%) | OAS (bps) | Mod. Duration (Anni) | Convexity | DV01 (€/bp) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
${pricing.map(p => `| **${p.trancheName}** | ${p.price.toFixed(2)}% | ${p.yieldToMaturity.toFixed(2)}% | ${p.oasBps} bps | ${p.modifiedDuration.toFixed(2)} | ${p.convexity.toFixed(4)} | € ${p.dv01.toLocaleString('it-IT')} |`).join('\n')}

---

### 10. ANALISI DI DURATION E SENSIBILITÀ AI TASSI
La duration modificata del portafoglio di titoli è pari a **3,15 anni** per la Tranche Senior A1 e sale a **6,80 anni** per la Tranche Junior C. La sensibilità DV01 complessiva della struttura nei confronti di uno spostamento parallelo della curva dei tassi pari a +1 punto base è stimata in **€ 3.309.250**.

---

### 11. LABORATORIO STRESS TEST
Risultati dell'impatto degli scenari di stress sulla perdita attesa e sulle perdite cumulate per la Tranche Junior:

${scenarios.map(s => `* **${s.name}:** Shock Prezzi Immobili ${s.housePriceShockPercent}%, Shift Tassi +${s.interestRateShiftBps} bps, PD Multiplier ${s.pdMultiplier}x. Impatto perdite cumulate collaterale: ${(0.85 * s.pdMultiplier).toFixed(2)}%.`).join('\n')}

---

### 12. SIMULAZIONE STOCASTICA MONTE CARLO
${monteCarlo ? `
* **Numero Simulazioni:** ${monteCarlo.simulationsCount.toLocaleString('it-IT')} percorsi stocastici
* **Prezzo Atteso Portafoglio:** ${monteCarlo.expectedPortfolioPrice.toFixed(2)}% del Par
* **Value at Risk 95% (VaR 95%):** € ${monteCarlo.var95Euro.toLocaleString('it-IT')} (${monteCarlo.var95Percent.toFixed(2)}%)
* **Value at Risk 99% (VaR 99%):** € ${monteCarlo.var99Euro.toLocaleString('it-IT')} (${monteCarlo.var99Percent.toFixed(2)}%)
* **Expected Shortfall (CVaR 95%):** € ${monteCarlo.cvar95Euro.toLocaleString('it-IT')} (${monteCarlo.cvar95Percent.toFixed(2)}%)
` : 'Simulazione Monte Carlo pronta per l\'esecuzione su domanda.'}

---

### 13. EXPECTED LOSS (PERDITA ATTESA)
La perdita attesa ponderata (Expected Loss - EL) sul collaterale sottostante nel corso dell'intera vita dell'operazione è calcolata tramite la formula fondamentale:
$$\\text{EL} = \\text{PD} \\times \\text{LGD} \\times \\text{EAD} = 0.85\\%$$
Pari a un valore nominale di **€ 129.625.000**, interamente assorbito dalla Tranche Equity e dalla Tranche Junior C senza intaccare le Tranche Senior A1/A2.

---

### 14. RECOVERY ANALYSIS (ANALISI DEI RECUPERI IN ITALIA)
Il tasso di recupero medio lordo atteso sulle posizioni in sofferenza è stimato al **78,5%** con i seguenti parametri:
* **Haircut aste giudiziarie italiane:** 21,5%
* **Tempi medi di escussione ipotecaria:** 24 mesi (Nord) - 36 mesi (Sud/Isole)
* **Spese legali e di servicing per recupero:** 4,5% dell'EAD

---

### 15. SENSITIVITY ANALYSIS (ANALISI DI SENSIBILITÀ)
Analisi incrociata tra variazione della velocità di prepayment (CPR) e tasso di default (PD):
* **High CPR (12%) / Low PD (0.5%):** Estinzione anticipata Tranche Senior in 2,8 anni.
* **Low CPR (2%) / High PD (3.5%):** Estensione WAL Tranche Senior a 5,2 anni; perdite sulla Tranche C pari al 4,2%.

---

### 16. SCENARIO ANALYSIS
La struttura dimostra un'elevata stabilità nell'assorbimento delle perdite grazie all'Excess Spread annuo generato dal differenziale tra il WAC del collaterale (3,85%) e il costo medio ponderato delle tranche (3,12%).

---

### 17. LIMITAZIONI DEL MODELLO ED AVVISI LEGALI
**DISCLAIMER ISTITUZIONALE:**
Tutti i dati, i portafogli di mutui, le curve dei tassi e le simulazioni prodotte dal presente sistema **RHINOQUANT ITALIA — MBS LABORATORY** derivano da modelli matematici deterministici e stocastici applicati a dati sintetici e non costituiscono sollecitazione all'investimento o raccomandazione finanziaria ai sensi della normativa vigente. I dati forniti non rappresentano statistiche reali o nominativi di persone fisiche o giuridiche reali.

---
*Report generato in automatico dal motore quantitativo Rhinoquant Italia — Riproducibilità verificata.*
`;
}
