-- RHINOQUANT ITALIA - PostgreSQL Database Schema
-- Schema per l'archiviazione di portafogli, cartolarizzazioni, waterfall, scenari e risultati di audit.

CREATE TABLE IF NOT EXISTS pools (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    loans_count INT NOT NULL,
    total_original_balance NUMERIC(18, 2) NOT NULL,
    total_current_balance NUMERIC(18, 2) NOT NULL,
    wac NUMERIC(5, 2) NOT NULL,
    wam INT NOT NULL,
    wal NUMERIC(5, 2) NOT NULL,
    wa_ltv NUMERIC(5, 2) NOT NULL,
    fixed_rate_pct NUMERIC(5, 2) NOT NULL,
    variable_rate_pct NUMERIC(5, 2) NOT NULL,
    checksum VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS mortgages (
    id VARCHAR(64) PRIMARY KEY,
    pool_id VARCHAR(64) REFERENCES pools(id) ON DELETE CASCADE,
    borrower_id VARCHAR(64) NOT NULL,
    original_amount NUMERIC(12, 2) NOT NULL,
    current_balance NUMERIC(12, 2) NOT NULL,
    rate_type VARCHAR(16) NOT NULL,
    reference_index VARCHAR(32) NOT NULL,
    interest_rate NUMERIC(5, 2) NOT NULL,
    original_term_months INT NOT NULL,
    remaining_term_months INT NOT NULL,
    seasoning_months INT NOT NULL,
    monthly_payment NUMERIC(10, 2) NOT NULL,
    ltv NUMERIC(5, 2) NOT NULL,
    lti NUMERIC(5, 2) NOT NULL,
    borrower_income NUMERIC(12, 2) NOT NULL,
    property_value NUMERIC(12, 2) NOT NULL,
    macro_zone VARCHAR(16) NOT NULL,
    region VARCHAR(32) NOT NULL,
    credit_rating VARCHAR(8) NOT NULL,
    payment_status VARCHAR(24) NOT NULL,
    annual_pd NUMERIC(5, 2) NOT NULL,
    annual_cpr NUMERIC(5, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS securitisations (
    id VARCHAR(64) PRIMARY KEY,
    deal_name VARCHAR(255) NOT NULL,
    issue_date DATE NOT NULL,
    pool_id VARCHAR(64) REFERENCES pools(id),
    initial_collateral_balance NUMERIC(18, 2) NOT NULL,
    reserve_account_balance NUMERIC(18, 2) NOT NULL,
    liquidity_reserve NUMERIC(18, 2) NOT NULL,
    overcollateralisation NUMERIC(18, 2) NOT NULL,
    principal_mode VARCHAR(16) DEFAULT 'SEQUENTIAL'
);

CREATE TABLE IF NOT EXISTS tranches (
    id VARCHAR(64) PRIMARY KEY,
    deal_id VARCHAR(64) REFERENCES securitisations(id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    original_principal NUMERIC(18, 2) NOT NULL,
    attachment_point NUMERIC(5, 2) NOT NULL,
    detachment_point NUMERIC(5, 2) NOT NULL,
    subordination NUMERIC(5, 2) NOT NULL,
    coupon_rate NUMERIC(5, 2) NOT NULL,
    spread_bps INT NOT NULL,
    rating VARCHAR(8) NOT NULL,
    wal NUMERIC(5, 2) NOT NULL,
    modified_duration NUMERIC(5, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
    id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    action VARCHAR(128) NOT NULL,
    status VARCHAR(16) NOT NULL,
    details TEXT,
    discrepancy_euro NUMERIC(18, 4) DEFAULT 0.0000,
    checksum VARCHAR(64) NOT NULL
);
