/**
 * @file server.ts
 * RHINOQUANT ITALIA - Full-Stack Express Server & API Gateway
 */

import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

import { generateSyntheticMortgages } from './src/utils/syntheticDataGenerator.js';
import { runMonthlyWaterfall } from './src/utils/waterfallEngine.js';
import { calculateTranchePricing } from './src/utils/pricingEngine.js';
import { runMonteCarloSimulation } from './src/utils/monteCarloEngine.js';
import { DEMO_POOL, DEMO_DEAL, DEMO_STRESS_SCENARIOS, INITIAL_DEMO_WATERFALL, INITIAL_DEMO_PRICING } from './src/utils/defaultData.js';
import { generateFullReportMarkdown } from './src/utils/pdfReportGenerator.js';
import { Tranche } from './src/types/mbs.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json({ limit: '50mb' }));

  // Initialize Gemini AI Client for Quantitative Research Summaries if Key exists
  const apiKey = process.env.GEMINI_API_KEY;
  const aiClient = apiKey ? new GoogleGenAI({ apiKey }) : null;

  // 1. API: Genera Mutui Sintetici
  app.post('/api/mortgages/generate', (req: Request, res: Response) => {
    try {
      const { count = 100, seed = 12345, meanAmount = 150000, fixedRateRatio = 0.65 } = req.body;
      const mortgages = generateSyntheticMortgages({ count, seed, meanAmount, fixedRateRatio });
      res.json({
        status: 'OK',
        count: mortgages.length,
        seed,
        mortgagesSample: mortgages.slice(0, 50),
        summary: {
          totalOriginal: mortgages.reduce((s, m) => s + m.originalAmount, 0),
          totalCurrent: mortgages.reduce((s, m) => s + m.currentBalance, 0),
          averageLtv: mortgages.reduce((s, m) => s + m.ltv, 0) / mortgages.length
        }
      });
    } catch (err: any) {
      res.status(500).json({ status: 'ERROR', message: err.message });
    }
  });

  // 2. API: Esegui Waterfall Mensile
  app.post('/api/waterfalls/run', (req: Request, res: Response) => {
    try {
      const { deal = DEMO_DEAL, pool = DEMO_POOL, monthsCount = 180, scenario } = req.body;
      const flows = runMonthlyWaterfall({ deal, pool, monthsCount, scenario });
      res.json({
        status: 'OK',
        monthsExecuted: flows.length,
        flows
      });
    } catch (err: any) {
      res.status(500).json({ status: 'ERROR', message: err.message });
    }
  });

  // 3. API: Calcola Pricing & OAS Workbench
  app.post('/api/pricing/run', (req: Request, res: Response) => {
    try {
      const { deal = DEMO_DEAL, pool = DEMO_POOL, scenario } = req.body;
      const flows = runMonthlyWaterfall({ deal, pool, monthsCount: 180, scenario });
      const pricingResults = deal.tranches.map((t: Tranche) => calculateTranchePricing({ tranche: t, waterfallFlows: flows }));
      res.json({
        status: 'OK',
        pricingResults
      });
    } catch (err: any) {
      res.status(500).json({ status: 'ERROR', message: err.message });
    }
  });

  // 4. API: Esegui Simulazione Monte Carlo
  app.post('/api/monte-carlo/run', (req: Request, res: Response) => {
    try {
      const { deal = DEMO_DEAL, pool = DEMO_POOL, simulationsCount = 1000, seed = 42 } = req.body;
      const mcResult = runMonteCarloSimulation({ deal, pool, simulationsCount, seed });
      res.json({
        status: 'OK',
        result: mcResult
      });
    } catch (err: any) {
      res.status(500).json({ status: 'ERROR', message: err.message });
    }
  });

  // 5. API: Genera Report di Ricerca
  app.get('/api/reports/:id', (req: Request, res: Response) => {
    try {
      const markdown = generateFullReportMarkdown({
        deal: DEMO_DEAL,
        pool: DEMO_POOL,
        pricing: INITIAL_DEMO_PRICING,
        scenarios: DEMO_STRESS_SCENARIOS,
        generatedDate: new Date().toISOString().split('T')[0]
      });
      res.json({ status: 'OK', reportId: req.params.id, markdown });
    } catch (err: any) {
      res.status(500).json({ status: 'ERROR', message: err.message });
    }
  });

  // 6. API: Commento di Ricerca AI via Gemini API
  app.post('/api/ai/research-commentary', async (req: Request, res: Response) => {
    try {
      if (!aiClient) {
        return res.json({
          status: 'DISABLED',
          commentary: 'La chiave API Gemini non è configurata nei segreti del sistema. Vengono utilizzati i commenti quantitativi pre-elaborati.'
        });
      }

      const { promptDetails } = req.body;
      const systemInstruction = `Sei un Senior Quantitative Strategist esperto in Mortgage-Backed Securities (RMBS) nel mercato bancario ed istituzionale italiano. Rispondi esclusivamente in italiano formale, professionale, tecnico e rigoroso, senza toni colloquiali o esagerati. Genera un'analisi quantitativa concisa di 3 paragrafi focalizzata su WAC, WAL, Credit Enhancement e profilo di rischio delle tranche.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: promptDetails || 'Fornisci una sintesi del profilo di rischio e rendimento per un operazione RMBS italiana con WAC 3.85% e Senior Subordination 30%.',
        config: {
          systemInstruction,
          temperature: 0.2
        }
      });

      res.json({
        status: 'OK',
        commentary: response.text
      });
    } catch (err: any) {
      res.status(500).json({ status: 'ERROR', message: err.message });
    }
  });

  // Dev server setup with Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[RHINOQUANT SERVER] Processing engine listening on port ${PORT}`);
  });
}

startServer();
