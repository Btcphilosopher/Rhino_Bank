# RHINOQUANT ITALIA - R Quantitative Analytics & Survival Curves
# Script R per la stima delle curve di default (PD) e Prepayment (CPR) tramite Cox Proportional Hazards

library(survival)
library(ggplot2)

# Modello di Sopravvivenza dei Mutui Italiani
generate_default_curves <- function(ltv_vec, seasoning_months, base_cpr = 0.05) {
  time <- 1:180
  
  # Hazard rate di default basata su LTV e Seasoning
  hazard_rates <- sapply(time, function(t) {
    base_hazard <- 0.0015 * (t / 24) * exp(-t / 48)
    return(base_hazard)
  })
  
  survival_prob <- cumprod(1 - hazard_rates)
  cumulative_default <- 1 - survival_prob
  
  df_results <- data.frame(
    Mese = time,
    HazardRate = hazard_rates,
    SurvivalProb = survival_prob,
    CumulativeDefault = cumulative_default
  )
  
  return(df_results)
}

# Esecuzione e stampa riassuntiva
results <- generate_default_curves(c(65, 80, 95), 42)
cat("--- RHINOQUANT ITALIA - ANALISI DI SOPRAVVIVENZA COMPLETATA ---\n")
cat("Default Cumulato a 60 Mesi:", round(results$CumulativeDefault[60] * 100, 2), "%\n")
cat("Default Cumulato a 120 Mesi:", round(results$CumulativeDefault[120] * 100, 2), "%\n")
