import { IndicatorDefinition, RegionData, InfrastructureProject, BankingExposure, Scenario } from "../types";

export const INDICATOR_DEFINITIONS: IndicatorDefinition[] = [
  {
    id: "gdp_proxy",
    name: "GVA / GDP Proxy Index",
    category: "activity",
    description: "Estimated gross value added proxy based on regional productivity, business turnover, and local economic output indicators.",
    unit: "Index (2016=100)",
    defaultWeight: 0.18,
  },
  {
    id: "employment_rate",
    name: "Employment Rate",
    category: "labor",
    description: "The percentage of working-age residents (aged 16 to 64) currently in active, paid employment.",
    unit: "%",
    defaultWeight: 0.15,
  },
  {
    id: "business_formation",
    name: "New Business Registrations",
    category: "activity",
    description: "New active companies incorporated under Companies House per 10,000 adult inhabitants annually.",
    unit: "per 10k pop",
    defaultWeight: 0.12,
  },
  {
    id: "house_prices",
    name: "Average House Price",
    category: "finance",
    description: "Average residential transaction price reported by HM Land Registry, reflecting household wealth and demand.",
    unit: "£k",
    defaultWeight: 0.10,
  },
  {
    id: "productivity",
    name: "Productivity (GVA/hr)",
    category: "innovation",
    description: "Average economic output generated per hour worked, a core measure of labor efficiency and technological scale.",
    unit: "£/hr",
    defaultWeight: 0.15,
  },
  {
    id: "average_earnings",
    name: "Median Weekly Earnings",
    category: "labor",
    description: "Median gross weekly earnings for full-time employees, showing income strength and living standards.",
    unit: "£/wk",
    defaultWeight: 0.10,
  },
  {
    id: "infra_investment",
    name: "Infrastructure Inflow",
    category: "infrastructure",
    description: "Public and private investment capital successfully deployed into regional energy, transport, and digital networks.",
    unit: "£M",
    defaultWeight: 0.12,
  },
  {
    id: "innovation_score",
    name: "Innovation & R&D Index",
    category: "innovation",
    description: "Combined patent application rate, university research commercialization grants, and high-tech sector cluster density.",
    unit: "Score (0-100)",
    defaultWeight: 0.08,
  }
];

// Helper to generate consistent historical values with structural properties
function generateHistoricalSeries(
  startVal: number,
  growthTrend: number, // yearly trend, e.g. 0.02 (2% growth)
  variance: number, // noise factor
  years: number[] = [2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026]
) {
  let currentVal = startVal;
  return years.map((year, idx) => {
    // 2020: Covid shock (drop for GDP/employment, maybe earnings plateaus, house prices might rise slightly later)
    let shock = 1.0;
    if (year === 2020) shock = 0.91; // 9% drop
    else if (year === 2021) shock = 1.06; // rebound

    // Introduce slight pseudo-randomness based on index for reproducibility
    const hash = Math.sin(year + startVal) * 1000;
    const noise = (hash - Math.floor(hash)) * 2 - 1; // between -1 and 1
    const randomShift = noise * variance;

    currentVal = currentVal * (1 + (idx === 0 ? 0 : growthTrend)) * shock + randomShift;
    
    // Bounds
    if (currentVal < 0) currentVal = 0;

    return {
      year,
      value: parseFloat(currentVal.toFixed(1)),
    };
  });
}

export const YORKSHIRE_REGIONS: RegionData[] = [
  {
    id: "west_yorkshire",
    name: "West Yorkshire",
    counties: [
      {
        id: "wy_county",
        name: "West Yorkshire",
        authorities: [
          {
            id: "leeds",
            name: "Leeds",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.032, 1.2),
              employment_rate: generateHistoricalSeries(74.2, 0.005, 0.4),
              business_formation: generateHistoricalSeries(62.5, 0.041, 1.5),
              house_prices: generateHistoricalSeries(185.0, 0.052, 2.1),
              productivity: generateHistoricalSeries(36.2, 0.018, 0.3),
              average_earnings: generateHistoricalSeries(525.0, 0.038, 5.0),
              infra_investment: generateHistoricalSeries(120.0, 0.065, 8.0),
              innovation_score: generateHistoricalSeries(68.0, 0.022, 1.0),
            },
          },
          {
            id: "bradford",
            name: "Bradford",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.018, 1.5),
              employment_rate: generateHistoricalSeries(68.1, 0.003, 0.6),
              business_formation: generateHistoricalSeries(48.2, 0.025, 1.2),
              house_prices: generateHistoricalSeries(135.0, 0.045, 1.8),
              productivity: generateHistoricalSeries(30.5, 0.012, 0.4),
              average_earnings: generateHistoricalSeries(460.0, 0.031, 4.0),
              infra_investment: generateHistoricalSeries(75.0, 0.042, 6.0),
              innovation_score: generateHistoricalSeries(45.0, 0.015, 0.8),
            },
          },
          {
            id: "wakefield",
            name: "Wakefield",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.028, 1.1),
              employment_rate: generateHistoricalSeries(73.5, 0.006, 0.3),
              business_formation: generateHistoricalSeries(51.0, 0.038, 1.4),
              house_prices: generateHistoricalSeries(148.0, 0.049, 1.9),
              productivity: generateHistoricalSeries(32.8, 0.015, 0.3),
              average_earnings: generateHistoricalSeries(490.0, 0.035, 4.5),
              infra_investment: generateHistoricalSeries(88.0, 0.058, 5.5),
              innovation_score: generateHistoricalSeries(38.0, 0.011, 0.5),
            },
          },
          {
            id: "calderdale",
            name: "Calderdale",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.021, 1.3),
              employment_rate: generateHistoricalSeries(75.0, 0.004, 0.5),
              business_formation: generateHistoricalSeries(45.5, 0.030, 1.0),
              house_prices: generateHistoricalSeries(162.0, 0.048, 2.0),
              productivity: generateHistoricalSeries(31.9, 0.013, 0.3),
              average_earnings: generateHistoricalSeries(485.0, 0.033, 4.2),
              infra_investment: generateHistoricalSeries(42.0, 0.035, 3.5),
              innovation_score: generateHistoricalSeries(48.0, 0.020, 0.9),
            },
          },
          {
            id: "kirklees",
            name: "Kirklees",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.020, 1.4),
              employment_rate: generateHistoricalSeries(72.1, 0.005, 0.4),
              business_formation: generateHistoricalSeries(43.8, 0.022, 1.1),
              house_prices: generateHistoricalSeries(155.0, 0.046, 1.9),
              productivity: generateHistoricalSeries(31.2, 0.011, 0.3),
              average_earnings: generateHistoricalSeries(478.0, 0.032, 4.0),
              infra_investment: generateHistoricalSeries(58.0, 0.045, 4.0),
              innovation_score: generateHistoricalSeries(47.0, 0.018, 0.8),
            },
          },
        ],
      },
    ],
  },
  {
    id: "south_yorkshire",
    name: "South Yorkshire",
    counties: [
      {
        id: "sy_county",
        name: "South Yorkshire",
        authorities: [
          {
            id: "sheffield",
            name: "Sheffield",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.026, 1.3),
              employment_rate: generateHistoricalSeries(71.8, 0.004, 0.4),
              business_formation: generateHistoricalSeries(49.1, 0.032, 1.3),
              house_prices: generateHistoricalSeries(168.0, 0.050, 2.0),
              productivity: generateHistoricalSeries(33.5, 0.016, 0.3),
              average_earnings: generateHistoricalSeries(502.0, 0.036, 4.8),
              infra_investment: generateHistoricalSeries(95.0, 0.062, 7.0),
              innovation_score: generateHistoricalSeries(62.0, 0.025, 1.1),
            },
          },
          {
            id: "rotherham",
            name: "Rotherham",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.024, 1.2),
              employment_rate: generateHistoricalSeries(70.9, 0.005, 0.5),
              business_formation: generateHistoricalSeries(36.4, 0.029, 1.0),
              house_prices: generateHistoricalSeries(132.0, 0.043, 1.6),
              productivity: generateHistoricalSeries(32.4, 0.019, 0.4),
              average_earnings: generateHistoricalSeries(475.0, 0.034, 4.1),
              infra_investment: generateHistoricalSeries(64.0, 0.055, 4.8),
              innovation_score: generateHistoricalSeries(55.0, 0.028, 1.2), // high due to AMRC!
            },
          },
          {
            id: "doncaster",
            name: "Doncaster",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.022, 1.4),
              employment_rate: generateHistoricalSeries(71.2, 0.006, 0.4),
              business_formation: generateHistoricalSeries(39.0, 0.031, 1.1),
              house_prices: generateHistoricalSeries(129.0, 0.044, 1.5),
              productivity: generateHistoricalSeries(30.9, 0.013, 0.3),
              average_earnings: generateHistoricalSeries(472.0, 0.031, 3.9),
              infra_investment: generateHistoricalSeries(78.0, 0.051, 5.0),
              innovation_score: generateHistoricalSeries(35.0, 0.010, 0.4),
            },
          },
          {
            id: "barnsley",
            name: "Barnsley",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.019, 1.2),
              employment_rate: generateHistoricalSeries(72.0, 0.004, 0.4),
              business_formation: generateHistoricalSeries(35.0, 0.026, 0.9),
              house_prices: generateHistoricalSeries(134.0, 0.046, 1.6),
              productivity: generateHistoricalSeries(29.8, 0.012, 0.3),
              average_earnings: generateHistoricalSeries(465.0, 0.033, 4.0),
              infra_investment: generateHistoricalSeries(45.0, 0.040, 3.0),
              innovation_score: generateHistoricalSeries(33.0, 0.012, 0.4),
            },
          },
        ],
      },
    ],
  },
  {
    id: "north_yorkshire",
    name: "North Yorkshire",
    counties: [
      {
        id: "ny_county",
        name: "North Yorkshire",
        authorities: [
          {
            id: "york",
            name: "York",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.029, 1.1),
              employment_rate: generateHistoricalSeries(76.5, 0.003, 0.3),
              business_formation: generateHistoricalSeries(53.2, 0.035, 1.2),
              house_prices: generateHistoricalSeries(245.0, 0.054, 2.5),
              productivity: generateHistoricalSeries(35.1, 0.016, 0.3),
              average_earnings: generateHistoricalSeries(518.0, 0.036, 4.5),
              infra_investment: generateHistoricalSeries(60.0, 0.048, 4.2),
              innovation_score: generateHistoricalSeries(65.0, 0.024, 1.0),
            },
          },
          {
            id: "harrogate",
            name: "Harrogate",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.024, 1.0),
              employment_rate: generateHistoricalSeries(78.2, 0.002, 0.3),
              business_formation: generateHistoricalSeries(58.0, 0.034, 1.4),
              house_prices: generateHistoricalSeries(310.0, 0.058, 3.2),
              productivity: generateHistoricalSeries(34.2, 0.014, 0.3),
              average_earnings: generateHistoricalSeries(560.0, 0.039, 5.2),
              infra_investment: generateHistoricalSeries(38.0, 0.038, 3.0),
              innovation_score: generateHistoricalSeries(46.0, 0.018, 0.7),
            },
          },
          {
            id: "skipton",
            name: "Skipton / Craven",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.016, 1.3),
              employment_rate: generateHistoricalSeries(77.1, 0.003, 0.4),
              business_formation: generateHistoricalSeries(42.0, 0.022, 1.0),
              house_prices: generateHistoricalSeries(225.0, 0.051, 2.2),
              productivity: generateHistoricalSeries(31.0, 0.011, 0.3),
              average_earnings: generateHistoricalSeries(495.0, 0.032, 4.1),
              infra_investment: generateHistoricalSeries(22.0, 0.030, 1.8),
              innovation_score: generateHistoricalSeries(34.0, 0.011, 0.5),
            },
          },
          {
            id: "scarborough",
            name: "Scarborough & Whitby",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.014, 1.5),
              employment_rate: generateHistoricalSeries(70.2, 0.004, 0.6),
              business_formation: generateHistoricalSeries(29.5, 0.018, 0.8),
              house_prices: generateHistoricalSeries(172.0, 0.043, 1.8),
              productivity: generateHistoricalSeries(28.4, 0.010, 0.3),
              average_earnings: generateHistoricalSeries(445.0, 0.028, 3.8),
              infra_investment: generateHistoricalSeries(44.0, 0.060, 4.0), // wind farms connection!
              innovation_score: generateHistoricalSeries(28.0, 0.012, 0.4),
            },
          },
          {
            id: "middlesbrough",
            name: "Middlesbrough",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.018, 1.7),
              employment_rate: generateHistoricalSeries(67.4, 0.005, 0.7),
              business_formation: generateHistoricalSeries(36.1, 0.024, 1.1),
              house_prices: generateHistoricalSeries(122.0, 0.039, 1.4),
              productivity: generateHistoricalSeries(31.8, 0.015, 0.4),
              average_earnings: generateHistoricalSeries(470.0, 0.031, 4.0),
              infra_investment: generateHistoricalSeries(92.0, 0.075, 7.5), // Net Zero Teesside
              innovation_score: generateHistoricalSeries(41.0, 0.019, 0.8),
            },
          },
        ],
      },
    ],
  },
  {
    id: "east_riding_humber",
    name: "East Riding & Humber",
    counties: [
      {
        id: "erh_county",
        name: "East Riding & Humber",
        authorities: [
          {
            id: "hull",
            name: "Hull",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.025, 1.4),
              employment_rate: generateHistoricalSeries(69.8, 0.005, 0.5),
              business_formation: generateHistoricalSeries(38.9, 0.030, 1.2),
              house_prices: generateHistoricalSeries(124.0, 0.042, 1.5),
              productivity: generateHistoricalSeries(31.5, 0.016, 0.3),
              average_earnings: generateHistoricalSeries(478.0, 0.033, 4.2),
              infra_investment: generateHistoricalSeries(115.0, 0.078, 8.5), // Siemens Wind, etc.
              innovation_score: generateHistoricalSeries(46.0, 0.021, 0.9),
            },
          },
          {
            id: "grimsby",
            name: "Grimsby & Immingham",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.021, 1.3),
              employment_rate: generateHistoricalSeries(70.5, 0.004, 0.5),
              business_formation: generateHistoricalSeries(34.2, 0.024, 0.9),
              house_prices: generateHistoricalSeries(128.0, 0.040, 1.4),
              productivity: generateHistoricalSeries(32.0, 0.017, 0.4),
              average_earnings: generateHistoricalSeries(480.0, 0.032, 4.0),
              infra_investment: generateHistoricalSeries(130.0, 0.085, 9.5), // Ports, Offshore Wind, Hydrogen
              innovation_score: generateHistoricalSeries(39.0, 0.017, 0.8),
            },
          },
          {
            id: "scunthorpe",
            name: "Scunthorpe",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.012, 1.8),
              employment_rate: generateHistoricalSeries(71.0, 0.003, 0.6),
              business_formation: generateHistoricalSeries(31.0, 0.018, 0.9),
              house_prices: generateHistoricalSeries(120.0, 0.038, 1.3),
              productivity: generateHistoricalSeries(30.1, 0.008, 0.4),
              average_earnings: generateHistoricalSeries(488.0, 0.029, 3.8),
              infra_investment: generateHistoricalSeries(52.0, 0.045, 4.0), // Steel works transition
              innovation_score: generateHistoricalSeries(30.0, 0.010, 0.5),
            },
          },
          {
            id: "beverley",
            name: "Beverley & East Riding Rural",
            indicators: {
              gdp_proxy: generateHistoricalSeries(100, 0.020, 1.1),
              employment_rate: generateHistoricalSeries(75.8, 0.004, 0.3),
              business_formation: generateHistoricalSeries(45.0, 0.028, 1.1),
              house_prices: generateHistoricalSeries(215.0, 0.052, 2.1),
              productivity: generateHistoricalSeries(32.4, 0.012, 0.3),
              average_earnings: generateHistoricalSeries(512.0, 0.034, 4.3),
              infra_investment: generateHistoricalSeries(48.0, 0.040, 3.2),
              innovation_score: generateHistoricalSeries(42.0, 0.016, 0.7),
            },
          },
        ],
      },
    ],
  },
];

export const INFRASTRUCTURE_PROJECTS: InfrastructureProject[] = [
  {
    id: "proj_tru",
    name: "Transpennine Route Upgrade (TRU)",
    type: "Rail",
    subRegion: "West Yorkshire & North Yorkshire",
    cost: 11500,
    completionYear: 2029,
    status: "Under Construction",
    gdpImpactScore: 9.4,
  },
  {
    id: "proj_humber_zero",
    name: "Humber Zero Green Hydrogen Cluster",
    type: "Hydrogen",
    subRegion: "East Riding & Humber",
    cost: 1200,
    completionYear: 2028,
    status: "Proposed",
    gdpImpactScore: 8.8,
  },
  {
    id: "proj_amrc_ext",
    name: "AMRC Fusion and Advanced Steel Lab",
    type: "Energy",
    subRegion: "South Yorkshire",
    cost: 150,
    completionYear: 2027,
    status: "Under Construction",
    gdpImpactScore: 8.2,
  },
  {
    id: "proj_hull_port",
    name: "Hull East Port Wind Staging Expansion",
    type: "Port",
    subRegion: "East Riding & Humber",
    cost: 320,
    completionYear: 2027,
    status: "Under Construction",
    gdpImpactScore: 8.5,
  },
  {
    id: "proj_leeds_southbank",
    name: "Leeds South Bank Urban Regeneration",
    type: "Regeneration",
    subRegion: "West Yorkshire",
    cost: 450,
    completionYear: 2030,
    status: "Proposed",
    gdpImpactScore: 7.9,
  },
  {
    id: "proj_york_biotech",
    name: "York Bio-Renewables Tech Accelerator",
    type: "Data Centre",
    subRegion: "North Yorkshire",
    cost: 85,
    completionYear: 2026,
    status: "Planned",
    gdpImpactScore: 7.2,
  },
  {
    id: "proj_teesside_nz",
    name: "Net Zero Teesside & CCUS Infrastructure",
    type: "Hydrogen",
    subRegion: "North Yorkshire / Teesside",
    cost: 1500,
    completionYear: 2028,
    status: "Planned",
    gdpImpactScore: 9.0,
  },
  {
    id: "proj_grimsby_dock",
    name: "Grimsby Marine Decarbonisation Port Facility",
    type: "Port",
    subRegion: "East Riding & Humber",
    cost: 95,
    completionYear: 2027,
    status: "Planned",
    gdpImpactScore: 6.8,
  }
];

export const BANK_EXPOSURE: BankingExposure[] = [
  {
    sector: "Advanced Manufacturing",
    exposureAmount: 420.5,
    smeCount: 142,
    riskRating: "Medium",
    defaultRate: 1.8,
    collateralCoverage: 82.5,
  },
  {
    sector: "Commercial Real Estate & Retail",
    exposureAmount: 480.2,
    smeCount: 88,
    riskRating: "High",
    defaultRate: 3.4,
    collateralCoverage: 71.0,
  },
  {
    sector: "Infrastructure & Energy Finance",
    exposureAmount: 550.0,
    smeCount: 14,
    riskRating: "Low",
    defaultRate: 0.6,
    collateralCoverage: 95.0,
  },
  {
    sector: "Maritime & Ports Logistics",
    exposureAmount: 280.4,
    smeCount: 45,
    riskRating: "Low",
    defaultRate: 1.1,
    collateralCoverage: 88.0,
  },
  {
    sector: "SME General Corporate Lending",
    exposureAmount: 310.8,
    smeCount: 654,
    riskRating: "Medium",
    defaultRate: 2.2,
    collateralCoverage: 65.0,
  },
  {
    sector: "Residential Mortgages (Yorkshire-wide)",
    exposureAmount: 850.1,
    smeCount: 0,
    riskRating: "Low",
    defaultRate: 0.8,
    collateralCoverage: 115.2,
  }
];

export const SCENARIOS: Scenario[] = [
  {
    id: "scen_baseline",
    name: "Baseline Economic Standard",
    description: "Current structural weightings with historical trends continuing under standard inflation and moderate infrastructure pipelines.",
    type: "baseline",
    targetGrowthShift: 0.0,
    weights: {
      gdp_proxy: 0.18,
      employment_rate: 0.15,
      business_formation: 0.12,
      house_prices: 0.10,
      productivity: 0.15,
      average_earnings: 0.10,
      infra_investment: 0.12,
      innovation_score: 0.08,
    }
  },
  {
    id: "scen_industrial_push",
    name: "Industrial Decarbonisation Push",
    description: "Aggressively weights infrastructure investment, productivity, and innovation. Simulates high economic expansion in the Humber and South Yorkshire.",
    type: "optimistic",
    targetGrowthShift: 3.5,
    weights: {
      gdp_proxy: 0.15,
      employment_rate: 0.10,
      business_formation: 0.10,
      house_prices: 0.05,
      productivity: 0.25,
      average_earnings: 0.10,
      infra_investment: 0.15,
      innovation_score: 0.10,
    }
  },
  {
    id: "scen_sme_finance",
    name: "SME Commercial Acceleration",
    description: "Focuses on business formation, earnings, and employment, driven by direct Rhino Bank local SME credit expansions.",
    type: "custom",
    targetGrowthShift: 2.1,
    weights: {
      gdp_proxy: 0.15,
      employment_rate: 0.20,
      business_formation: 0.20,
      house_prices: 0.05,
      productivity: 0.10,
      average_earnings: 0.15,
      infra_investment: 0.05,
      innovation_score: 0.10,
    }
  },
  {
    id: "scen_hard_recession",
    name: "De-globalisation & Energy Shock",
    description: "Simulates severe trade shocks affecting ports and manufacturing. House prices decline, unemployment rises, and infrastructure inflows dry up.",
    type: "pessimistic",
    targetGrowthShift: -5.2,
    weights: {
      gdp_proxy: 0.25,
      employment_rate: 0.20,
      business_formation: 0.10,
      house_prices: 0.15,
      productivity: 0.10,
      average_earnings: 0.10,
      infra_investment: 0.05,
      innovation_score: 0.05,
    }
  }
];
