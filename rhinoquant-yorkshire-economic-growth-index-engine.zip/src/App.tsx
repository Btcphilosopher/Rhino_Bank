import React, { useState, useEffect } from "react";
import {
  INDICATOR_DEFINITIONS,
  YORKSHIRE_REGIONS,
  INFRASTRUCTURE_PROJECTS,
  BANK_EXPOSURE,
  SCENARIOS,
} from "./data/yorkshireData";
import { calculateEgiSeries, aggregateIndicators } from "./utils/econometrics";
import GisMap from "./components/GisMap";
import EgiModeler from "./components/EgiModeler";
import RConsole from "./components/RConsole";
import DashboardOverview from "./components/DashboardOverview";
import SectorDashboards from "./components/SectorDashboards";
import BankingDashboard from "./components/BankingDashboard";
import ReportingCentre from "./components/ReportingCentre";
import { Compass, Sliders, Flame, Briefcase, Terminal, FileText, Activity, MapPin, Grid, Layers } from "lucide-react";

export default function App() {
  // 1. Centralized State Management
  const [selectedRegionId, setSelectedRegionId] = useState<string | null>(null);
  const [activeScenarioId, setActiveScenarioId] = useState<string>("scen_baseline");
  const [weights, setWeights] = useState<Record<string, number>>({});
  const [mapMode, setMapMode] = useState<"egi" | "exposure" | "infra">("egi");
  const [activeTab, setActiveTab] = useState<"overview" | "modeler" | "sectors" | "banking" | "console" | "reports">("overview");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Initialize weights based on active scenario
  useEffect(() => {
    const scen = SCENARIOS.find(s => s.id === activeScenarioId);
    if (scen) {
      setWeights({ ...scen.weights });
    }
  }, [activeScenarioId]);

  // Set weights defaults if empty
  useEffect(() => {
    if (Object.keys(weights).length === 0) {
      const initialWeights: Record<string, number> = {};
      INDICATOR_DEFINITIONS.forEach(ind => {
        initialWeights[ind.id] = ind.defaultWeight;
      });
      setWeights(initialWeights);
    }
  }, [weights]);

  // Handle individual weight slider alterations
  const handleWeightChange = (indicatorId: string, val: number) => {
    setActiveScenarioId("custom"); // Flag as custom
    setWeights(prev => ({
      ...prev,
      [indicatorId]: val,
    }));
  };

  const handleResetWeights = () => {
    setActiveScenarioId("scen_baseline");
  };

  // Compile active scenario parameters for growth shift calculations
  const activeScenario = SCENARIOS.find(s => s.id === activeScenarioId) || {
    name: "Custom Weight Allocation",
    targetGrowthShift: 0.0,
  };

  // Pre-calculate EGI scores for all regions to feed into GIS heatmap rendering
  const getRegionScoresMap = () => {
    const scores: Record<string, number> = {};
    YORKSHIRE_REGIONS.forEach(reg => {
      const indicators = aggregateIndicators(YORKSHIRE_REGIONS, reg.id);
      const egiSeries = calculateEgiSeries(indicators, weights, activeScenario.targetGrowthShift);
      const lastPoint = egiSeries[egiSeries.length - 1];
      scores[reg.id] = lastPoint ? lastPoint.value : 100;
    });
    return scores;
  };

  const egiScoresMap = getRegionScoresMap();

  return (
    <div className="min-h-screen bg-[#111111] text-[#EAEAEA] flex flex-row font-sans selection:bg-[#D97706] selection:text-white antialiased">
      
      {/* Left Rail Navigation - Bold Industrial theme */}
      <nav className="w-16 hidden lg:flex flex-col items-center py-6 bg-[#0F0F0F] border-r border-[#333333] z-20 shrink-0 select-none">
        <div className="mb-12">
          <div className="w-10 h-10 bg-white flex items-center justify-center rounded-none font-black text-black text-sm font-sans tracking-tighter">
            RQ
          </div>
        </div>
        <div className="space-y-8 flex-1 flex flex-col items-center">
          <button
            onClick={() => setActiveTab("overview")}
            className={`transition-all duration-200 ${
              activeTab === "overview" ? "text-[#D97706] scale-110" : "text-gray-500 hover:text-white"
            }`}
            title="Executive Overview"
          >
            <Compass className="w-6 h-6" />
          </button>
          
          <button
            onClick={() => setActiveTab("modeler")}
            className={`transition-all duration-200 ${
              activeTab === "modeler" ? "text-[#D97706] scale-110" : "text-gray-500 hover:text-white"
            }`}
            title="EGI Compiler & Scenarios"
          >
            <Sliders className="w-6 h-6" />
          </button>

          <button
            onClick={() => setActiveTab("sectors")}
            className={`transition-all duration-200 ${
              activeTab === "sectors" ? "text-[#D97706] scale-110" : "text-gray-500 hover:text-white"
            }`}
            title="Sector Deep-Dives"
          >
            <Flame className="w-6 h-6" />
          </button>

          <button
            onClick={() => setActiveTab("banking")}
            className={`transition-all duration-200 ${
              activeTab === "banking" ? "text-[#D97706] scale-110" : "text-gray-500 hover:text-white"
            }`}
            title="Lending & Exposures"
          >
            <Briefcase className="w-6 h-6" />
          </button>

          <button
            onClick={() => setActiveTab("console")}
            className={`transition-all duration-200 ${
              activeTab === "console" ? "text-[#D97706] scale-110" : "text-gray-500 hover:text-white"
            }`}
            title="R Econometric Console"
          >
            <Terminal className="w-6 h-6" />
          </button>

          <button
            onClick={() => setActiveTab("reports")}
            className={`transition-all duration-200 ${
              activeTab === "reports" ? "text-[#D97706] scale-110" : "text-gray-500 hover:text-white"
            }`}
            title="Reporting Centre"
          >
            <FileText className="w-6 h-6" />
          </button>
        </div>
        <div className="mt-auto text-[#D97706] font-bold text-[9px] font-mono transform -rotate-90 origin-center mb-10 tracking-widest uppercase">
          V2.0.44
        </div>
      </nav>

      {/* Main Content Area Container with industrial grid backdrop */}
      <div className="flex-1 flex flex-col min-w-0 industrial-grid bg-[#111111]">
        
        {/* 1. Global Platform Header */}
        <header className="bg-[#0F0F0F]/95 backdrop-blur-md border-b border-[#333333] px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 sticky top-0 z-50 shadow-md">
          
          {/* Branding Title */}
          <div className="flex items-center gap-3">
            <div className="bg-[#D97706] text-black font-black p-2 rounded-none flex items-center justify-center font-mono select-none tracking-tighter">
              RQ-Y
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black uppercase tracking-wider text-white font-serif">
                  RhinoQuant Yorkshire
                </h1>
                <span className="text-[9px] font-mono bg-[#D97706]/10 text-[#D97706] border border-[#D97706]/30 px-1.5 py-0.5 uppercase tracking-widest">
                  EGI ENGINE R-v4
                </span>
              </div>
              <p className="text-[10px] text-gray-400 font-mono tracking-wide mt-0.5 uppercase">
                Internal Economic Intelligence Platform • Rhino Bank Credit & Investment Advisory
              </p>
            </div>
          </div>

          {/* Global HUD metrics ticker */}
          <div className="flex items-center gap-6 text-[11px] font-mono text-gray-400 border-l border-dashed border-[#333333] pl-6 h-10 hidden md:flex">
            <div>
              Y-WIDE EGI: <span className="text-[#D97706] font-bold">{(egiScoresMap["west_yorkshire"] ? (Object.values(egiScoresMap).reduce((a, b) => a + b, 0) / 4).toFixed(1) : "108.4")}</span>
            </div>
            <div>
              COORDINATION: <span className="text-white font-semibold">{selectedRegionId ? YORKSHIRE_REGIONS.find(r => r.id === selectedRegionId)?.name : "Yorkshire & Humber"}</span>
            </div>
            <div>
              TICKER: <span className="text-emerald-400">EXPANDING</span>
            </div>
            <div>
              TIME: <span className="text-white">2026-07-26</span>
            </div>
          </div>

        </header>

        {/* 2. Main Platform Grid Body */}
        <div className="flex-grow flex flex-col lg:flex-row min-h-0">
          
          {/* Left Sidepanel: GIS Mapping & Filter Panel (Always visible for fast drill-downs) */}
          <aside className="w-full lg:w-[460px] border-r border-[#333333] bg-[#0F0F0F] flex flex-col gap-5 p-5 shrink-0 select-none">
            
            {/* Spatial Layer Controls */}
            <div>
              <h2 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#D97706]" />
                SPATIAL INTERACTION LAYERS
              </h2>
              <div className="grid grid-cols-3 gap-1.5 border border-[#333333] p-1 bg-[#131313]">
                <button
                  onClick={() => setMapMode("egi")}
                  className={`px-3 py-1.5 text-[10px] font-mono font-semibold transition uppercase rounded-none ${
                    mapMode === "egi"
                      ? "bg-[#D97706] text-black font-bold"
                      : "text-gray-400 hover:text-white hover:bg-[#1A1A1A]"
                  }`}
                >
                  EGI Heatmap
                </button>
                <button
                  onClick={() => setMapMode("exposure")}
                  className={`px-3 py-1.5 text-[10px] font-mono font-semibold transition uppercase rounded-none ${
                    mapMode === "exposure"
                      ? "bg-[#D97706] text-black font-bold"
                      : "text-gray-400 hover:text-white hover:bg-[#1A1A1A]"
                  }`}
                >
                  Bank Exposure
                </button>
                <button
                  onClick={() => setMapMode("infra")}
                  className={`px-3 py-1.5 text-[10px] font-mono font-semibold transition uppercase rounded-none ${
                    mapMode === "infra"
                      ? "bg-[#D97706] text-black font-bold"
                      : "text-gray-400 hover:text-white hover:bg-[#1A1A1A]"
                  }`}
                >
                  Pipelines
                </button>
              </div>
            </div>

            {/* GIS Interactive SVG Map component */}
            <div className="flex-grow">
              <GisMap
                regions={YORKSHIRE_REGIONS}
                selectedRegionId={selectedRegionId}
                onSelectRegion={setSelectedRegionId}
                egiScores={egiScoresMap}
                infrastructureProjects={INFRASTRUCTURE_PROJECTS}
                showProjects={mapMode === "infra"}
                mapMode={mapMode}
              />
            </div>

            {/* Geographical Quick Jump Links */}
            <div className="border border-[#333333] bg-[#131313] p-4">
              <h4 className="text-[11px] font-mono font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#D97706]" />
                QUICK GEOGRAPHIC FILTER
              </h4>
              <div className="grid grid-cols-2 gap-1 text-[10px] font-mono">
                {YORKSHIRE_REGIONS.map(reg => {
                  const isSelected = reg.id === selectedRegionId;
                  return (
                    <button
                      key={reg.id}
                      onClick={() => setSelectedRegionId(isSelected ? null : reg.id)}
                      className={`text-left p-2 border transition ${
                        isSelected
                          ? "border-[#D97706] text-white bg-[#D97706]/15 font-semibold"
                          : "border-[#333333] text-gray-400 hover:text-white hover:bg-[#1A1A1A]"
                      }`}
                    >
                      {reg.name}
                    </button>
                  );
                })}
                {selectedRegionId && (
                  <button
                    onClick={() => setSelectedRegionId(null)}
                    className="col-span-2 text-center p-1.5 border border-dashed border-[#D97706] text-[#D97706] hover:bg-[#D97706]/10 font-bold mt-1"
                  >
                    Clear filter [ Overall Yorkshire ]
                  </button>
                )}
              </div>
            </div>

          </aside>

          {/* Right Content Area: Main Tabs and Analytical Views */}
          <main className="flex-grow bg-[#111111]/80 p-6 flex flex-col gap-6 overflow-x-hidden overflow-y-auto">
            
            {/* Main Module Tabs Header */}
            <div className="flex border-b border-[#333333] gap-1 flex-wrap overflow-x-auto select-none">
              
              <button
                onClick={() => setActiveTab("overview")}
                className={`px-5 py-3 text-xs font-mono font-bold uppercase tracking-wider transition border-b-2 rounded-none flex items-center gap-2 ${
                  activeTab === "overview"
                    ? "border-[#D97706] text-[#D97706] bg-[#1A1A1A]/50"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <Compass className="w-4 h-4" />
                Executive Overview
              </button>

              <button
                onClick={() => setActiveTab("modeler")}
                className={`px-5 py-3 text-xs font-mono font-bold uppercase tracking-wider transition border-b-2 rounded-none flex items-center gap-2 ${
                  activeTab === "modeler"
                    ? "border-[#D97706] text-[#D97706] bg-[#1A1A1A]/50"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <Sliders className="w-4 h-4" />
                EGI Compiler & Scenarios
              </button>

              <button
                onClick={() => setActiveTab("sectors")}
                className={`px-5 py-3 text-xs font-mono font-bold uppercase tracking-wider transition border-b-2 rounded-none flex items-center gap-2 ${
                  activeTab === "sectors"
                    ? "border-[#D97706] text-[#D97706] bg-[#1A1A1A]/50"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <Flame className="w-4 h-4" />
                Sector Deep-Dives
              </button>

              <button
                onClick={() => setActiveTab("banking")}
                className={`px-5 py-3 text-xs font-mono font-bold uppercase tracking-wider transition border-b-2 rounded-none flex items-center gap-2 ${
                  activeTab === "banking"
                    ? "border-[#D97706] text-[#D97706] bg-[#1A1A1A]/50"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <Briefcase className="w-4 h-4" />
                Lending & Exposures
              </button>

              <button
                onClick={() => setActiveTab("console")}
                className={`px-5 py-3 text-xs font-mono font-bold uppercase tracking-wider transition border-b-2 rounded-none flex items-center gap-2 ${
                  activeTab === "console"
                    ? "border-[#D97706] text-[#D97706] bg-[#1A1A1A]/50"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <Terminal className="w-4 h-4" />
                R Econometric Console
              </button>

              <button
                onClick={() => setActiveTab("reports")}
                className={`px-5 py-3 text-xs font-mono font-bold uppercase tracking-wider transition border-b-2 rounded-none flex items-center gap-2 ${
                  activeTab === "reports"
                    ? "border-[#D97706] text-[#D97706] bg-[#1A1A1A]/50"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <FileText className="w-4 h-4" />
                Reporting Centre
              </button>

            </div>

            {/* 3. Render Module Contents based on activeTab */}
            <div className="flex-grow">
              
              {activeTab === "overview" && (
                <DashboardOverview
                  regions={YORKSHIRE_REGIONS}
                  selectedRegionId={selectedRegionId}
                  onSelectRegion={setSelectedRegionId}
                  weights={weights}
                  activeScenarioName={activeScenario.name}
                  activeScenarioShift={activeScenario.targetGrowthShift}
                />
              )}

              {activeTab === "modeler" && (
                <EgiModeler
                  indicators={INDICATOR_DEFINITIONS}
                  weights={weights}
                  onWeightChange={handleWeightChange}
                  onResetWeights={handleResetWeights}
                  scenarios={SCENARIOS}
                  activeScenarioId={activeScenarioId}
                  onSelectScenario={setActiveScenarioId}
                />
              )}

              {activeTab === "sectors" && (
                <SectorDashboards
                  regions={YORKSHIRE_REGIONS}
                  selectedRegionId={selectedRegionId}
                  infrastructureProjects={INFRASTRUCTURE_PROJECTS}
                />
              )}

              {activeTab === "banking" && (
                <BankingDashboard
                  exposure={BANK_EXPOSURE}
                />
              )}

              {activeTab === "console" && (
                <RConsole
                  selectedRegionId={selectedRegionId}
                  currentWeights={weights}
                />
              )}

              {activeTab === "reports" && (
                <ReportingCentre
                  regions={YORKSHIRE_REGIONS}
                  selectedRegionId={selectedRegionId}
                  weights={weights}
                  activeScenarioName={activeScenario.name}
                />
              )}

            </div>

          </main>

        </div>

        {/* 4. Global HUD Footer */}
        <footer className="bg-[#0A0A0A] border-t border-[#333333] px-6 py-3.5 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-gray-500">
          <div>
            DEVELOPMENT LICENSE • PROPRIETARY QUANTITATIVE SOFTWARE ENGINE • RHINO BANK CREDIT INTEL
          </div>
          <div className="flex items-center gap-4 mt-2 sm:mt-0 text-[#D97706]">
            <span>PLATFORM SEID: SE-6031</span>
            <span>COMPILATION: SUCCESSFUL</span>
          </div>
        </footer>

      </div>

    </div>
  );
}
