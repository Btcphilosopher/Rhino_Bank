import React, { useState } from "react";
import { RegionData, IndicatorDefinition, WeightsConfig } from "../types";
import { FileText, Download, CheckCircle, Printer, BookOpen, AlertCircle } from "lucide-react";
import { aggregateIndicators, calculateEgiSeries } from "../utils/econometrics";

interface ReportingCentreProps {
  regions: RegionData[];
  selectedRegionId: string | null;
  weights: Record<string, number>;
  activeScenarioName: string;
}

export default function ReportingCentre({
  regions,
  selectedRegionId,
  weights,
  activeScenarioName,
}: ReportingCentreProps) {
  const [selectedPaper, setSelectedPaper] = useState<"committee" | "bulletin" | "assessment">("committee");
  const [isDownloading, setIsDownloading] = useState<string | null>(null);

  const activeRegionName = selectedRegionId
    ? regions.find(r => r.id === selectedRegionId)?.name || "Selected Region"
    : "Yorkshire & Humber";

  // Aggregate stats for reporting content
  const activeIndicators = aggregateIndicators(regions, selectedRegionId || undefined);
  const activeEgiSeries = calculateEgiSeries(activeIndicators, weights);
  const currentEgiVal = activeEgiSeries[activeEgiSeries.length - 1]?.value || 100;

  // CSV download generator
  const triggerCsvDownload = () => {
    setIsDownloading("csv");
    setTimeout(() => {
      // Build raw CSV content
      let csvContent = "data:text/csv;charset=utf-8,";
      csvContent += "Year,EGI_Composite_Index\n";
      
      activeEgiSeries.forEach(point => {
        csvContent += `${point.year},${point.value}\n`;
      });

      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `RhinoQuant_EGI_${activeRegionName.replace(" ", "_")}_2026.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setIsDownloading(null);
    }, 1000);
  };

  // Brief editorial text blocks matching Goldman Sachs style
  const printPapers = {
    committee: {
      title: "Rhino Bank Regional Investment Committee Paper",
      subtitle: "Capital Allocation & Credit Expansion Mandate - Yorkshire Region",
      reference: "RHQ-IC-2026-07-YORK",
      executiveSummary: `This quantitative brief outlines the macroeconomic criteria governing credit deployment across Yorkshire and the Humber through Q4 2026. Applying our internally computed Economic Growth Index (EGI), which aggregates productivity indices, housing demand, and physical infrastructure inflows, we present regional risk recommendations. The aggregated EGI score of ${currentEgiVal.toFixed(1)} for ${activeRegionName} supports a core lending expansion under the active '${activeScenarioName}' weighting regime. We recommend a capital deployment weighting heavily tilted towards Advanced Engineering and Green Port corridors.`,
      recommendations: [
        "Deploy up to £150M in new senior debt facilities targeting the Humber Hydrogen Corridor.",
        "Authorize local SME credit easing up to £85M in West Yorkshire logistics clusters.",
        "Maintain high-risk collateral buffers of 115% on residential books in highly levered commuter regions (Harrogate/York)."
      ]
    },
    bulletin: {
      title: "Yorkshire & Humber Quarterly Economic Bulletin",
      subtitle: "Secular Structural Trends, Labor Pools, and Regional Divergence",
      reference: "RHQ-QEB-2026-Q2",
      executiveSummary: `The second-quarter economic survey reveals a widening productivity divergence between dense financial/service conglomerates and outlying coastal/agricultural centers. While West Yorkshire, anchored by the Leeds financial district, reports a strong employment density and high median earnings (£560/wk average in Harrogate), the East Riding rural centers and coastal districts report slower asset velocity. To mitigate these geographical spreads, Rhino Bank's strategic advisory board continues to monitor long-term local GVA proxies.`,
      recommendations: [
        "Identify high-tech spinout companies from Leeds and Sheffield Universities for Tier 1 venture-backed lending.",
        "Engage with coastal maritime logistics projects to expand commercial trade letters of credit.",
        "Initiate structural reviews of heavy metal assets in Scunthorpe and Doncaster."
      ]
    },
    assessment: {
      title: "Strategic Infrastructure Decarbonisation Assessment",
      subtitle: "Mega-CapEx Impact Modelling on Local Authority GDP Outflows",
      reference: "RHQ-SIDA-2026",
      executiveSummary: `Our quantitative econometric modeling demonstrates that major capital expenditure into regional rail upgrades (TRU Corridor) and carbon capture (Net Zero Teesside) triggers a highly significant multiplier effect on downstream GVA. OLS regression of composite EGI indexes against infrastructure inflow shows a high regression coefficient (p < 0.001, R² = 0.941), confirming that for every £10M in successfully deployed CapEx, the local economic index experiences a structural lift of 0.8% over a rolling 3-year timeline.`,
      recommendations: [
        "Support senior debt syndications for Transpennine Rail Upgrade completion pipelines.",
        "Partner with local enterprise partnerships (LEPs) to structure green bonds for hydrogen storage.",
        "Coordinate risk exposure buffers to absorb localized labor supply bottlenecks."
      ]
    }
  };

  const paper = printPapers[selectedPaper];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
      
      {/* Paper List & Controls */}
      <div className="border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between stone-border">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
            Publication Desk
          </div>
          <h3 className="text-xl font-bold text-white font-serif mb-4">
            Executive Report Generator
          </h3>
          <p className="text-xs text-gray-400 leading-relaxed mb-6">
            RhinoQuant automatically compiles active econometric indices, weights, and stress tests into institutional briefs suitable for credit board and regional investment committees.
          </p>

          <div className="space-y-3">
            <button
              onClick={() => setSelectedPaper("committee")}
              className={`w-full text-left p-3 border rounded-none transition flex items-center gap-3 ${
                selectedPaper === "committee"
                  ? "border-[#D97706] bg-[#131313]"
                  : "border-[#333333] hover:bg-[#131313]/50"
              }`}
            >
              <FileText className="w-5 h-5 text-[#D97706]" />
              <div>
                <span className="text-xs font-bold text-white block">Investment Committee Paper</span>
                <span className="text-[10px] text-gray-400 font-mono">Ref: RHQ-IC-2026-07</span>
              </div>
            </button>

            <button
              onClick={() => setSelectedPaper("bulletin")}
              className={`w-full text-left p-3 border rounded-none transition flex items-center gap-3 ${
                selectedPaper === "bulletin"
                  ? "border-[#D97706] bg-[#131313]"
                  : "border-[#333333] hover:bg-[#131313]/50"
              }`}
            >
              <BookOpen className="w-5 h-5 text-[#D97706]" />
              <div>
                <span className="text-xs font-bold text-white block">Quarterly Economic Bulletin</span>
                <span className="text-[10px] text-gray-400 font-mono">Ref: RHQ-QEB-2026</span>
              </div>
            </button>

            <button
              onClick={() => setSelectedPaper("assessment")}
              className={`w-full text-left p-3 border rounded-none transition flex items-center gap-3 ${
                selectedPaper === "assessment"
                  ? "border-[#D97706] bg-[#131313]"
                  : "border-[#333333] hover:bg-[#131313]/50"
              }`}
            >
              <AlertCircle className="w-5 h-5 text-[#D97706]" />
              <div>
                <span className="text-xs font-bold text-white block">Decarbonisation Assessment</span>
                <span className="text-[10px] text-gray-400 font-mono">Ref: RHQ-SIDA-2026</span>
              </div>
            </button>
          </div>
        </div>

        {/* Action Triggers */}
        <div className="mt-8 pt-6 border-t border-[#333333] space-y-2.5">
          <button
            onClick={triggerCsvDownload}
            disabled={isDownloading !== null}
            className="w-full bg-[#D97706] hover:bg-[#b25e03] text-black font-mono text-xs font-bold py-2.5 uppercase tracking-wider rounded-none transition flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            {isDownloading === "csv" ? "Generating CSV ledgers..." : "Export EGI Index (.csv)"}
          </button>
          
          <button
            onClick={() => {
              window.print();
            }}
            className="w-full border border-[#333333] hover:border-[#D97706] text-gray-300 hover:text-white font-mono text-xs py-2.5 uppercase tracking-wider rounded-none transition flex items-center justify-center gap-2 bg-[#131313]"
          >
            <Printer className="w-4 h-4" />
            Print Report Sheet
          </button>
        </div>
      </div>

      {/* Rendered Editorial Paper Sheet */}
      <div className="lg:col-span-2 border border-stone-300 bg-white text-gray-900 p-8 rounded-none shadow-2xl flex flex-col justify-between min-h-[560px] font-serif print:border-none print:p-0">
        
        {/* Paper Content */}
        <div>
          {/* Paper Header */}
          <div className="border-b-2 border-gray-900 pb-5 mb-6 text-center lg:text-left">
            <div className="text-[10px] font-mono uppercase tracking-widest text-[#D97706] font-bold">
              RHINO QUANT RESEARCH GROUP • PRIVATE INTERNAL PAPER
            </div>
            <h1 className="text-2xl font-black mt-2 leading-tight">
              {paper.title}
            </h1>
            <p className="text-sm font-sans text-gray-600 mt-1 italic">
              {paper.subtitle}
            </p>
            <div className="flex justify-between items-center text-[10px] font-mono text-gray-500 mt-3 pt-2 border-t border-gray-200">
              <span>REFERENCE: {paper.reference}</span>
              <span>DATE: 2026-07-26</span>
              <span>AUTHORITY: ALL YORKSHIRE</span>
            </div>
          </div>

          {/* Paper Body */}
          <div className="space-y-6">
            
            {/* Section 1: Executive Summary */}
            <div>
              <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-gray-900 mb-2 border-b border-gray-200 pb-1">
                1. EXECUTIVE SUMMARY & MODEL OUTPUTS
              </h3>
              <p className="text-xs leading-relaxed text-gray-800 text-justify">
                {paper.executiveSummary}
              </p>
            </div>

            {/* Section 2: Model State Ledger */}
            <div>
              <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-gray-900 mb-2 border-b border-gray-200 pb-1">
                2. COMPILED EGI STATISTICAL LEDGER
              </h3>
              
              <div className="grid grid-cols-3 gap-4 py-3 bg-gray-50 border border-gray-200 px-4 text-center">
                <div>
                  <span className="text-[9px] font-mono text-gray-500 uppercase block">Selected Region</span>
                  <span className="text-sm font-sans font-bold text-gray-900 block">{activeRegionName}</span>
                </div>
                <div>
                  <span className="text-[9px] font-mono text-gray-500 uppercase block">EGI Composite score</span>
                  <span className="text-sm font-mono font-bold text-[#D97706] block">{currentEgiVal.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[9px] font-mono text-gray-500 uppercase block">Scenario Weights</span>
                  <span className="text-sm font-sans font-bold text-gray-900 block">{activeScenarioName}</span>
                </div>
              </div>
            </div>

            {/* Section 3: Strategic Mandates */}
            <div>
              <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-gray-900 mb-2 border-b border-gray-200 pb-1">
                3. COMMITTE RECOMMENDATIONS & MANDATES
              </h3>
              
              <ul className="space-y-2 text-xs text-gray-800 list-decimal pl-4 leading-relaxed">
                {paper.recommendations.map((rec, i) => (
                  <li key={i} className="pl-1 text-justify">
                    {rec}
                  </li>
                ))}
              </ul>
            </div>

          </div>
        </div>

        {/* Paper Footer */}
        <div className="border-t border-gray-200 pt-5 mt-8 flex justify-between items-center text-[9px] font-mono text-gray-400 print:hidden">
          <div className="flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>CRYPTOGRAPHIC SIGNATURE VALIDATED</span>
          </div>
          <span>RHINO BANK QE-GROUP LMTD • LEEDS HEADQUARTERS</span>
        </div>

      </div>

    </div>
  );
}
