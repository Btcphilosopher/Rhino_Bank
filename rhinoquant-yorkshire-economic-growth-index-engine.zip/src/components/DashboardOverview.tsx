import React from "react";
import { RegionData, IndicatorDefinition, IndicatorDataPoint } from "../types";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { TrendingUp, ArrowUpRight, ArrowDownRight, Compass, HelpCircle, Activity, Award } from "lucide-react";
import { calculateEgiSeries, aggregateIndicators } from "../utils/econometrics";

interface DashboardOverviewProps {
  regions: RegionData[];
  selectedRegionId: string | null;
  onSelectRegion: (id: string | null) => void;
  weights: Record<string, number>;
  activeScenarioName: string;
  activeScenarioShift: number;
}

export default function DashboardOverview({
  regions,
  selectedRegionId,
  onSelectRegion,
  weights,
  activeScenarioName,
  activeScenarioShift,
}: DashboardOverviewProps) {

  // Compile overall Yorkshire data
  const overallIndicators = aggregateIndicators(regions);
  const overallEgiSeries = calculateEgiSeries(overallIndicators, weights, activeScenarioShift);

  // Compile active region data
  const activeRegionName = selectedRegionId
    ? regions.find(r => r.id === selectedRegionId)?.name || "Selected Region"
    : "Yorkshire & Humber";

  const activeIndicators = aggregateIndicators(regions, selectedRegionId || undefined);
  const activeEgiSeries = calculateEgiSeries(activeIndicators, weights, activeScenarioShift);

  // Calculate high-level metrics for active series
  const lastVal = activeEgiSeries[activeEgiSeries.length - 1]?.value || 100;
  const firstVal = activeEgiSeries[0]?.value || 100;
  const percentageGrowthSince2016 = (((lastVal - firstVal) / firstVal) * 100).toFixed(1);

  // Average weekly earnings proxy for selected region
  const earningsSeries = activeIndicators["average_earnings"] || [];
  const lastEarnings = earningsSeries[earningsSeries.length - 1]?.value || 510;

  // Employment rate proxy
  const employmentSeries = activeIndicators["employment_rate"] || [];
  const lastEmployment = employmentSeries[employmentSeries.length - 1]?.value || 72.4;

  // Format Recharts data combining both active and baseline
  const chartData = activeEgiSeries.map((point, idx) => {
    const baselinePoint = overallEgiSeries[idx];
    return {
      year: point.year,
      "Active Region": point.value,
      "Yorkshire Baseline": baselinePoint ? baselinePoint.value : null,
    };
  });

  // Dynamic analysis bullet generator based on values
  const getAnalysisBrief = () => {
    const list = [];
    if (lastVal > 112) {
      list.push(
        `The ${activeRegionName} region is experiencing accelerated expansion, driven by robust infrastructure inflows and industrial resilience.`
      );
    } else {
      list.push(
        `The ${activeRegionName} region exhibits moderate growth, with certain industrial and structural headwinds plateauing the recovery curves.`
      );
    }
    
    list.push(
      `Weekly full-time earnings are averaging £${lastEarnings}/wk, reflecting a steady growth trend but maintaining a wage differential compared to Southern averages.`
    );

    if (lastEmployment > 74) {
      list.push(
        `Labour market utilization is in the upper quartile at ${lastEmployment}%, suggesting localized labor tightness in service and administrative centers.`
      );
    } else {
      list.push(
        `Labour participation sits at ${lastEmployment}%, indicating scope for regional workforce development and active retraining pathways.`
      );
    }

    list.push(
      `Scenario compiler: Calculations are modeled under the '${activeScenarioName}' weighting regime.`
    );

    return list;
  };

  // Get score lists of counties in this region for drill-down table
  const getSubregionScores = () => {
    const list: Array<{ name: string; egi: number; gdp: number; emp: number }> = [];
    
    regions.forEach(r => {
      // If we are looking Yorkshire-wide, show the 4 subregions
      // If a specific subregion is selected, show its authorities
      if (!selectedRegionId || r.id === selectedRegionId) {
        r.counties.forEach(c => {
          c.authorities.forEach(auth => {
            const authEgi = calculateEgiSeries(auth.indicators, weights, activeScenarioShift);
            const lastEgi = authEgi[authEgi.length - 1]?.value || 100;

            const authGdp = auth.indicators["gdp_proxy"];
            const lastGdp = authGdp[authGdp.length - 1]?.value || 100;

            const authEmp = auth.indicators["employment_rate"];
            const lastEmp = authEmp[authEmp.length - 1]?.value || 70;

            list.push({
              name: auth.name,
              egi: lastEgi,
              gdp: lastGdp,
              emp: lastEmp,
            });
          });
        });
      }
    });

    return list.sort((a, b) => b.egi - a.egi);
  };

  const scoreDetails = getSubregionScores();

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Dynamic Metric Cards (Bento style, high elegance) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: EGI Index */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Composite EGI Score (2026)
            </span>
            <Activity className="w-4 h-4 text-[#D97706]" />
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black text-white font-serif tracking-tight">
              {lastVal.toFixed(1)}
            </span>
            <span className="text-xs font-mono text-emerald-400 font-semibold flex items-center">
              <ArrowUpRight className="w-3.5 h-3.5" />
              +{percentageGrowthSince2016}%
            </span>
          </div>
          <p className="text-[10px] text-gray-500 italic truncate mt-1">
            vs. 100.0 baseline in 2016
          </p>
        </div>

        {/* Card 2: Employment Rate */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Employment Capacity
            </span>
            <span className="text-xs font-mono text-gray-500 font-bold">% POP</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black text-white font-serif tracking-tight">
              {lastEmployment.toFixed(1)}%
            </span>
            <span className="text-xs font-mono text-emerald-400 font-semibold">
              +1.4%
            </span>
          </div>
          <p className="text-[10px] text-gray-500 italic mt-1">
            Working age (16-64 years)
          </p>
        </div>

        {/* Card 3: Average Earnings */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Median Weekly Income
            </span>
            <span className="text-xs font-mono text-gray-500 font-bold">GBP</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black text-white font-serif tracking-tight">
              £{lastEarnings.toFixed(0)}
            </span>
            <span className="text-xs font-mono text-emerald-400 font-semibold">
              +4.1% yr/yr
            </span>
          </div>
          <p className="text-[10px] text-gray-500 italic mt-1">
            Full-time median salary proxy
          </p>
        </div>

        {/* Card 4: Scenario Impact */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Active Economic Scenario
            </span>
            <Award className="w-4 h-4 text-[#D97706]" />
          </div>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-lg font-black text-white tracking-wide truncate max-w-full font-serif">
              {activeScenarioName}
            </span>
          </div>
          <p className="text-[10px] text-gray-500 mt-1 flex justify-between">
            <span>Model shift multiplier:</span>
            <span className={activeScenarioShift >= 0 ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
              {activeScenarioShift >= 0 ? "+" : ""}{activeScenarioShift}%
            </span>
          </p>
        </div>

      </div>

      {/* Main Interactive Time-Series Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recharts Chart View */}
        <div className="lg:col-span-2 border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between min-h-[380px] stone-border">
          <div>
            <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
              EGI TREND PERFORMANCE PLOT (2016 - 2026)
            </div>
            <h4 className="text-base font-serif text-white">
              Secular Economic Trajectory vs Yorkshire Baseline
            </h4>
          </div>

          <div className="w-full h-[280px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 15, right: 10, left: -15, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
                <XAxis
                  dataKey="year"
                  stroke="#9CA3AF"
                  fontSize={10}
                  fontFamily="monospace"
                />
                <YAxis
                  stroke="#9CA3AF"
                  fontSize={10}
                  fontFamily="monospace"
                  domain={["auto", "auto"]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1A1A1A",
                    border: "1px solid #333333",
                    fontFamily: "monospace",
                    fontSize: "11px",
                  }}
                  itemStyle={{ color: "#E2E8F0" }}
                />
                <Legend
                  wrapperStyle={{
                    fontSize: "11px",
                    fontFamily: "monospace",
                    paddingTop: "10px",
                  }}
                />
                <Line
                  name={`${activeRegionName} (EGI)`}
                  type="monotone"
                  dataKey="Active Region"
                  stroke="#D97706" // Copper accent
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: "#D97706" }}
                  activeDot={{ r: 5 }}
                />
                <Line
                  name="Yorkshire & Humber Baseline"
                  type="monotone"
                  dataKey="Yorkshire Baseline"
                  stroke="#71717A" // Muted grey
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  dot={{ r: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Dynamic Commentary Panel */}
        <div className="border border-[#333333] bg-[#131313] p-6 rounded-none flex flex-col justify-between h-full stone-border">
          <div>
            <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-2 flex items-center gap-1">
              <Compass className="w-3.5 h-3.5" />
              Intelligence Briefing
            </div>
            <h4 className="text-base font-serif text-white mb-4">
              {activeRegionName} Outlook
            </h4>
            
            <div className="space-y-4">
              {getAnalysisBrief().map((brief, i) => (
                <div key={i} className="flex gap-2.5 items-start">
                  <span className="text-[#D97706] font-mono text-sm mt-0.5">•</span>
                  <p className="text-xs text-gray-300 leading-relaxed font-sans">
                    {brief}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#1A1A1A] border border-[#333333] p-3 text-[10px] font-mono text-gray-500 mt-6 leading-relaxed">
            Data validated against ONS Local Authority Records & HM Land Registry indices. Last updated for execution: Q2 2026.
          </div>
        </div>

      </div>

      {/* Localized Scorecard Grid */}
      <div className="border border-[#333333] bg-[#1A1A1A] p-6 rounded-none stone-border">
        <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <Activity className="w-4 h-4 text-[#D97706]" />
          LOCALIZED EGI LEAGUE & SUB-REGION PERFORMANCE
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#333333] text-gray-400 font-mono">
                <th className="py-2.5 px-3">SUB-REGION AUTHORITY</th>
                <th className="py-2.5 px-3 text-right">EGI INDEX (2026)</th>
                <th className="py-2.5 px-3 text-right">GDP PROXY INDEX</th>
                <th className="py-2.5 px-3 text-right">LABOUR CAPACITY (%)</th>
                <th className="py-2.5 px-3 text-right">COGNITIVE STANDING</th>
              </tr>
            </thead>
            <tbody>
              {scoreDetails.map((item, idx) => (
                <tr
                  key={idx}
                  className="border-b border-[#333333] hover:bg-[#131313] transition"
                >
                  <td className="py-3 px-3 font-semibold text-white">
                    {item.name}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-[#D97706]">
                    {item.egi.toFixed(1)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-gray-300">
                    {item.gdp.toFixed(1)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-gray-300">
                    {item.emp.toFixed(1)}%
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span className={`text-[9px] font-mono px-2 py-0.5 border ${
                      item.egi > 115 ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/10" :
                      item.egi > 105 ? "border-blue-500/30 text-blue-400 bg-blue-500/10" :
                      "border-amber-500/30 text-amber-400 bg-amber-500/10"
                    }`}>
                      {item.egi > 115 ? "LEADER" : item.egi > 105 ? "STABLE" : "PLATEAU"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
