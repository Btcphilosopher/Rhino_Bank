import React, { useState } from "react";
import { RegionData, InfrastructureProject } from "../types";
import { MapPin, Compass, Train, Zap, ShieldAlert, Award } from "lucide-react";

interface GisMapProps {
  regions: RegionData[];
  selectedRegionId: string | null;
  onSelectRegion: (id: string | null) => void;
  egiScores: Record<string, number>; // regionId -> current EGI score
  infrastructureProjects: InfrastructureProject[];
  showProjects: boolean;
  mapMode: "egi" | "exposure" | "infra";
}

export default function GisMap({
  regions,
  selectedRegionId,
  onSelectRegion,
  egiScores,
  infrastructureProjects,
  showProjects,
  mapMode,
}: GisMapProps) {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  // Simplified high-quality regional SVG paths for Yorkshire and Humber
  // Yorkshire is roughly a shield/heart shape.
  // North Yorkshire is the massive top/middle area.
  // West Yorkshire is mid-left.
  // South Yorkshire is bottom-left.
  // East Riding & Humber is mid-right to bottom-right, with the Humber estuary.
  
  const regionPaths = [
    {
      id: "north_yorkshire",
      name: "North Yorkshire",
      path: "M 100,50 L 320,30 L 380,100 L 400,160 L 360,200 L 290,190 L 280,170 L 190,190 L 130,170 L 80,110 Z",
      center: { x: 230, y: 100 },
      baseColor: "bg-[#718096]", // Stone Grey
      colorScale: (score: number) => {
        if (score > 115) return "rgba(217, 119, 6, 0.9)"; // Copper accent
        if (score > 108) return "rgba(217, 119, 6, 0.65)";
        if (score > 102) return "rgba(113, 128, 150, 0.75)";
        return "rgba(113, 128, 150, 0.4)";
      },
      exposureScale: () => "rgba(26, 54, 93, 0.5)", // Navy
    },
    {
      id: "west_yorkshire",
      name: "West Yorkshire",
      path: "M 130,170 L 190,190 L 230,220 L 220,280 L 150,290 L 110,230 L 110,190 Z",
      center: { x: 165, y: 230 },
      baseColor: "bg-[#4A5568]", // Slate Grey
      colorScale: (score: number) => {
        if (score > 115) return "rgba(217, 119, 6, 0.9)";
        if (score > 108) return "rgba(217, 119, 6, 0.75)";
        if (score > 102) return "rgba(74, 85, 104, 0.85)";
        return "rgba(74, 85, 104, 0.5)";
      },
      exposureScale: () => "rgba(26, 54, 93, 0.9)", // Massive exposure in West Yorkshire (Leeds)
    },
    {
      id: "south_yorkshire",
      name: "South Yorkshire",
      path: "M 220,280 L 280,260 L 320,300 L 290,350 L 210,340 L 190,300 L 150,290 Z",
      center: { x: 240, y: 310 },
      baseColor: "bg-[#2D3748]", // Charcoal
      colorScale: (score: number) => {
        if (score > 115) return "rgba(217, 119, 6, 0.9)";
        if (score > 108) return "rgba(217, 119, 6, 0.7)";
        if (score > 102) return "rgba(45, 55, 72, 0.85)";
        return "rgba(45, 55, 72, 0.5)";
      },
      exposureScale: () => "rgba(26, 54, 93, 0.7)",
    },
    {
      id: "east_riding_humber",
      name: "East Riding & Humber",
      path: "M 290,190 L 360,200 L 410,240 L 440,290 L 370,330 L 320,300 L 280,260 L 290,220 Z",
      center: { x: 350, y: 260 },
      baseColor: "bg-[#1A202C]", // Graphite
      colorScale: (score: number) => {
        if (score > 115) return "rgba(217, 119, 6, 0.95)"; // Strong port/wind growth
        if (score > 108) return "rgba(217, 119, 6, 0.75)";
        if (score > 102) return "rgba(26, 32, 44, 0.85)";
        return "rgba(26, 32, 44, 0.5)";
      },
      exposureScale: () => "rgba(26, 54, 93, 0.65)",
    },
  ];

  // Specific city coordinates for marking on the map
  const cityMarkers = [
    { name: "Leeds", x: 175, y: 225, size: 7, type: "major" },
    { name: "Sheffield", x: 235, y: 315, size: 7, type: "major" },
    { name: "York", x: 265, y: 155, size: 6, type: "historic" },
    { name: "Hull", x: 365, y: 255, size: 6, type: "port" },
    { name: "Grimsby", x: 395, y: 295, size: 5, type: "port" },
    { name: "Harrogate", x: 210, y: 140, size: 5, type: "service" },
    { name: "Bradford", x: 145, y: 215, size: 5, type: "industrial" },
    { name: "Middlesbrough", x: 230, y: 45, size: 5, type: "industrial" },
  ];

  // Projects maps to draw line pipelines
  const infrastructureLines = [
    { name: "Transpennine Route Upgrade (TRU)", x1: 145, y1: 215, x2: 265, y2: 155, color: "#D97706" }, // Bradford -> York
    { name: "Humber Energy Pipeline", x1: 365, y1: 255, x2: 395, y2: 295, color: "#4FD1C5" }, // Hull -> Grimsby
  ];

  const getFillColor = (regionId: string) => {
    const isSelected = selectedRegionId === regionId;
    const isHovered = hoveredRegion === regionId;
    const score = egiScores[regionId] || 100;

    if (mapMode === "egi") {
      const scaleColor = regionPaths.find(r => r.id === regionId)?.colorScale(score);
      if (isSelected) return "rgba(217, 119, 6, 1.0)"; // Pure bright copper
      if (isHovered) return "rgba(217, 119, 6, 0.85)";
      return scaleColor;
    } else if (mapMode === "exposure") {
      const scaleColor = regionPaths.find(r => r.id === regionId)?.exposureScale();
      if (isSelected) return "rgba(26, 54, 93, 1.0)"; // Deep velvet blue
      if (isHovered) return "rgba(26, 54, 93, 0.85)";
      return scaleColor;
    } else {
      // Clean architectural grey map
      if (isSelected) return "rgba(113, 128, 150, 0.8)";
      if (isHovered) return "rgba(113, 128, 150, 0.5)";
      return "rgba(45, 55, 72, 0.3)";
    }
  };

  return (
    <div className="relative border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between h-full stone-border animate-fade-in">
      {/* Map Header */}
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] flex items-center gap-1.5 font-bold">
            <Compass className="w-3.5 h-3.5 animate-spin-slow" />
            GIS Spatial Analytics Engine
          </div>
          <h3 className="text-xl font-bold text-white font-serif mt-1">
            {selectedRegionId
              ? regions.find(r => r.id === selectedRegionId)?.name
              : "Yorkshire & Humber Region"}
          </h3>
          <p className="text-xs text-gray-400 mt-1 font-sans">
            {mapMode === "egi" && "Heatmap reflecting aggregate Weighted Economic Growth Index (2016 = 100)"}
            {mapMode === "exposure" && "Lending exposure concentration: darker areas signify higher bank book density"}
            {mapMode === "infra" && "Active mega infrastructure pipelines, corridors and strategic sea-port links"}
          </p>
        </div>
        
        {/* Map Legend */}
        <div className="bg-[#131313] border border-[#333333] px-3 py-2 text-[10px] font-mono text-gray-400 flex flex-col gap-1.5 shadow-md">
          <div className="font-bold text-white border-b border-[#333333] pb-1 mb-1">
            {mapMode === "egi" ? "EGI METRICS" : mapMode === "exposure" ? "LENDING LOANS" : "INFRASTRUCTURE"}
          </div>
          {mapMode === "egi" ? (
            <>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(217,119,6,0.95)] inline-block border border-black"></span>
                <span>High Growth (&gt;115)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(217,119,6,0.65)] inline-block border border-black"></span>
                <span>Moderate Growth (108-115)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(113,128,150,0.75)] inline-block border border-black"></span>
                <span>Stable (102-108)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(113,128,150,0.4)] inline-block border border-black"></span>
                <span>Contraction (&lt;102)</span>
              </div>
            </>
          ) : mapMode === "exposure" ? (
            <>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(26,54,93,0.95)] inline-block border border-black"></span>
                <span>Tier 1 High (&gt;£500M)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(26,54,93,0.65)] inline-block border border-black"></span>
                <span>Tier 2 Mid (£200-500M)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-[rgba(26,54,93,0.35)] inline-block border border-black"></span>
                <span>Tier 3 Low (&lt;£200M)</span>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center gap-1.5">
                <Train className="w-3 h-3 text-[#D97706]" />
                <span>TRU Rail Corridor</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="w-3 h-3 text-cyan-400" />
                <span>Humber Wind & H2</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Award className="w-3 h-3 text-emerald-400" />
                <span>AMRC Nuclear Park</span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* SVG Canvas Map Container */}
      <div className="flex-grow flex items-center justify-center relative min-h-[380px] bg-[#0E0E0E] border border-[#333333] overflow-hidden p-2">
        <svg
          viewBox="0 0 460 380"
          className="w-full max-w-[440px] h-auto max-h-[360px] drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] select-none"
        >
          {/* Subregion Path Shapes */}
          <g>
            {regionPaths.map(r => (
              <path
                key={r.id}
                d={r.path}
                fill={getFillColor(r.id)}
                stroke="#444444"
                strokeWidth={selectedRegionId === r.id ? "2.5" : hoveredRegion === r.id ? "2" : "1.2"}
                className="transition-all duration-300 cursor-pointer hover:opacity-90"
                onClick={() => onSelectRegion(selectedRegionId === r.id ? null : r.id)}
                onMouseEnter={() => setHoveredRegion(r.id)}
                onMouseLeave={() => setHoveredRegion(null)}
              />
            ))}
          </g>

          {/* Infrastructure Pipelines / Corridor Overlays */}
          {mapMode === "infra" && (
            <g>
              {infrastructureLines.map((line, i) => (
                <line
                    key={i}
                    x1={line.x1}
                    y1={line.y1}
                    x2={line.x2}
                    y2={line.y2}
                    stroke={line.color}
                    strokeWidth="3.5"
                    strokeDasharray="4,3"
                    className="animate-pulse"
                />
              ))}
            </g>
          )}

          {/* Infrastructure Projects Hotspots Markers */}
          {showProjects && (
            <g>
              {infrastructureProjects.map(proj => {
                // Approximate location coordinates based on subRegion description
                let px = 200;
                let py = 200;

                if (proj.id === "proj_tru") { px = 200; py = 185; }
                else if (proj.id === "proj_humber_zero") { px = 385; py = 275; }
                else if (proj.id === "proj_amrc_ext") { px = 250; py = 325; }
                else if (proj.id === "proj_hull_port") { px = 365; py = 245; }
                else if (proj.id === "proj_leeds_southbank") { px = 180; py = 235; }
                else if (proj.id === "proj_york_biotech") { px = 265; py = 165; }
                else if (proj.id === "proj_teesside_nz") { px = 235; py = 65; }
                else if (proj.id === "proj_grimsby_dock") { px = 405; py = 285; }

                return (
                  <g key={proj.id} className="cursor-help group">
                    <circle
                      cx={px}
                      cy={py}
                      r="6"
                      fill={proj.type === "Rail" ? "#D97706" : proj.type === "Hydrogen" ? "#4FD1C5" : "#10B981"}
                      className="animate-ping opacity-60"
                    />
                    <circle
                      cx={px}
                      cy={py}
                      r="4"
                      fill={proj.type === "Rail" ? "#D97706" : proj.type === "Hydrogen" ? "#4FD1C5" : "#10B981"}
                      stroke="#FFFFFF"
                      strokeWidth="1"
                    />
                    {/* Tiny tooltip simulator inside SVG */}
                    <title>{`${proj.name} (£${proj.cost}M - ${proj.status})`}</title>
                  </g>
                );
              })}
            </g>
          )}

          {/* City Labels & Core Markers */}
          <g>
            {cityMarkers.map((city, i) => (
              <g key={i}>
                <circle
                  cx={city.x}
                  cy={city.y}
                  r={city.type === "major" ? "3.5" : "2.5"}
                  fill={city.type === "major" ? "#FFFFFF" : "#CBD5E0"}
                  stroke="#1A1A1A"
                  strokeWidth="1.2"
                />
                <text
                  x={city.x + (city.name === "Hull" || city.name === "Grimsby" ? -10 : 7)}
                  y={city.y + 4}
                  fill="#E2E8F0"
                  fontSize="8.5"
                  fontFamily="monospace"
                  textAnchor={city.name === "Hull" || city.name === "Grimsby" ? "end" : "start"}
                  className="font-medium pointer-events-none drop-shadow-[0_1.5px_1.5px_rgba(0,0,0,0.9)]"
                >
                  {city.name}
                </text>
              </g>
            ))}
          </g>

          {/* Centered region indicators for current EGI */}
          {mapMode === "egi" && (
            <g>
              {regionPaths.map(r => {
                const score = egiScores[r.id];
                if (!score) return null;
                return (
                  <g key={`lbl-${r.id}`} className="pointer-events-none">
                    {/* White label backing box */}
                    <rect
                      x={r.center.x - 24}
                      y={r.center.y - 10}
                      width="48"
                      height="15"
                      rx="3"
                      fill="#0E0E0E"
                      fillOpacity="0.85"
                      stroke="#333333"
                      strokeWidth="0.5"
                    />
                    <text
                      x={r.center.x}
                      y={r.center.y + 1}
                      fill="#D97706"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {score.toFixed(1)}
                    </text>
                  </g>
                );
              })}
            </g>
          )}
        </svg>

        {/* Clear Filter HUD overlay */}
        {selectedRegionId && (
          <button
            onClick={() => onSelectRegion(null)}
            className="absolute bottom-4 right-4 bg-[#D97706] hover:bg-[#b25e03] text-black text-[10px] font-mono font-bold px-2 py-1 uppercase tracking-wider rounded-none transition"
          >
            Clear Filter [ Yorkshire-Wide ]
          </button>
        )}
      </div>

      {/* Map Footer HUD */}
      <div className="border-t border-[#333333] pt-3 mt-3 flex justify-between text-[11px] font-mono text-gray-400">
        <div>
          STATUS: <span className="text-emerald-400 font-bold">ONLINE</span>
        </div>
        <div>
          SYS COORDINATES: <span className="text-white">SE 6031 5203 (YORK)</span>
        </div>
        <div>
          GRID SHARDS: <span className="text-[#D97706] font-bold">4 REGIONS</span>
        </div>
      </div>
    </div>
  );
}
