import React from "react";
import { IndicatorDefinition, WeightsConfig, Scenario } from "../types";
import { Sliders, RefreshCw, BarChart4, TrendingUp, HelpCircle } from "lucide-react";

interface EgiModelerProps {
  indicators: IndicatorDefinition[];
  weights: WeightsConfig;
  onWeightChange: (indicatorId: string, value: number) => void;
  onResetWeights: () => void;
  scenarios: Scenario[];
  activeScenarioId: string;
  onSelectScenario: (scenarioId: string) => void;
}

export default function EgiModeler({
  indicators,
  weights,
  onWeightChange,
  onResetWeights,
  scenarios,
  activeScenarioId,
  onSelectScenario,
}: EgiModelerProps) {
  
  // Calculate weight total to show normalized percentages
  const rawTotal = Object.values(weights).reduce((a, b) => a + b, 0);
  const normalizedTotal = rawTotal || 1;

  return (
    <div className="border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between h-full stone-border animate-fade-in">
      {/* Modeler Header */}
      <div>
        <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] flex items-center gap-1.5 mb-1">
          <Sliders className="w-3.5 h-3.5" />
          INDEX COMPILER CORE
        </div>
        <h3 className="text-xl font-bold text-white font-serif">
          EGI Configurator & Scenario Modeler
        </h3>
        <p className="text-xs text-gray-400 mt-1 leading-relaxed">
          The Economic Growth Index is a composite model compiled by combining multiple regional indicators. Adjust relative weights manually or load a pre-calibrated investment scenario.
        </p>
      </div>

      {/* Scenario Selector */}
      <div className="mt-5 border border-[#333333] bg-[#131313] p-4">
        <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-[#D97706]" />
          CHOOSE MACRO INVESTMENT SCENARIO
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {scenarios.map(scen => {
            const isActive = scen.id === activeScenarioId;
            return (
              <button
                key={scen.id}
                onClick={() => onSelectScenario(scen.id)}
                className={`text-left p-3 border rounded-none transition flex flex-col justify-between h-24 ${
                  isActive
                    ? "border-[#D97706] bg-[#1E1B18]"
                    : "border-[#333333] bg-[#1A1A1A] hover:bg-[#1E1B18]/50"
                }`}
              >
                <div className="flex justify-between items-start w-full">
                  <span className={`text-[11px] font-mono font-semibold ${isActive ? "text-[#D97706]" : "text-white"}`}>
                    {scen.name}
                  </span>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 uppercase border ${
                    scen.type === "optimistic" ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/10" :
                    scen.type === "pessimistic" ? "border-red-500/30 text-red-400 bg-red-500/10" :
                    "border-[#333333] text-gray-400 bg-[#0F0F0F]"
                  }`}>
                    {scen.type}
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 leading-tight mt-1 line-clamp-2">
                  {scen.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Manual Sliders */}
      <div className="mt-5 flex-grow">
        <div className="flex justify-between items-center mb-3">
          <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <BarChart4 className="w-4 h-4 text-[#D97706]" />
            CONSTITUENT INDICATOR WEIGHTS
          </h4>
          <button
            onClick={onResetWeights}
            className="text-[10px] font-mono text-gray-400 hover:text-white flex items-center gap-1 transition"
          >
            <RefreshCw className="w-3 h-3" />
            Reset to Baseline
          </button>
        </div>

        <div className="space-y-4 max-h-[290px] overflow-y-auto pr-2 scrollbar-thin">
          {indicators.map(ind => {
            const rawVal = weights[ind.id] !== undefined ? weights[ind.id] : ind.defaultWeight;
            const normPct = ((rawVal / normalizedTotal) * 100).toFixed(1);

            return (
              <div key={ind.id} className="bg-[#111111] border border-[#333333] p-3 flex flex-col gap-1.5">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-semibold text-white tracking-wide">
                      {ind.name}
                    </span>
                    <span className="text-[9px] font-mono text-gray-500 ml-2 uppercase tracking-wide">
                      ({ind.category})
                    </span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-[#D97706]">
                    {normPct}%
                  </span>
                </div>
                
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={rawVal}
                    onChange={(e) => onWeightChange(ind.id, parseFloat(e.target.value))}
                    className="flex-grow accent-[#D97706] h-1 bg-[#222222] outline-none"
                  />
                  <span className="text-[10px] font-mono text-gray-400 w-8 text-right">
                    {rawVal.toFixed(2)}
                  </span>
                </div>
                <div className="text-[9.5px] text-gray-400 italic leading-snug">
                  {ind.description}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* HUD Warning */}
      <div className="border-t border-[#333333] pt-4 mt-5 flex justify-between items-center text-[11px] font-mono">
        <div className="text-gray-400 flex items-center gap-1">
          <HelpCircle className="w-3.5 h-3.5 text-[#D97706]" />
          Relative weight compilation:
        </div>
        <div className="text-white font-bold">
          {rawTotal === 0 ? "⚠️ SET WEIGHTS" : "100% AUTO-NORMALIZED"}
        </div>
      </div>
    </div>
  );
}
