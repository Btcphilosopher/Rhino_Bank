import React, { useState } from "react";
import { RegionData, InfrastructureProject } from "../types";
import { Train, Anchor, Building2, Flame, Wrench, GraduationCap, TrendingUp, HelpCircle } from "lucide-react";

interface SectorDashboardsProps {
  regions: RegionData[];
  selectedRegionId: string | null;
  infrastructureProjects: InfrastructureProject[];
}

export default function SectorDashboards({
  regions,
  selectedRegionId,
  infrastructureProjects,
}: SectorDashboardsProps) {
  const [activeTab, setActiveTab] = useState<"manufacture" | "infra" | "housing" | "labour">("manufacture");
  const [infraMultiplier, setInfraMultiplier] = useState(1.0); // Interactive impact multiplier

  // 1. Calculations & Summaries
  const getSubRegionTitle = () => {
    if (!selectedRegionId) return "Yorkshire & Humber Region";
    return regions.find(r => r.id === selectedRegionId)?.name || "Selected Region";
  };

  // Extract relevant lists of authorities
  const authoritiesList: any[] = [];
  regions.forEach(r => {
    if (!selectedRegionId || r.id === selectedRegionId) {
      r.counties.forEach(c => {
        c.authorities.forEach(auth => {
          authoritiesList.push(auth);
        });
      });
    }
  });

  // Calculate averages for specific sector categories
  const avgEarnings = authoritiesList.reduce((acc, auth) => {
    const series = auth.indicators["average_earnings"] || [];
    const val = series[series.length - 1]?.value || 0;
    return acc + val;
  }, 0) / (authoritiesList.length || 1);

  const avgHousePrice = authoritiesList.reduce((acc, auth) => {
    const series = auth.indicators["house_prices"] || [];
    const val = series[series.length - 1]?.value || 0;
    return acc + val;
  }, 0) / (authoritiesList.length || 1);

  const avgProductivity = authoritiesList.reduce((acc, auth) => {
    const series = auth.indicators["productivity"] || [];
    const val = series[series.length - 1]?.value || 0;
    return acc + val;
  }, 0) / (authoritiesList.length || 1);

  const avgInnovation = authoritiesList.reduce((acc, auth) => {
    const series = auth.indicators["innovation_score"] || [];
    const val = series[series.length - 1]?.value || 0;
    return acc + val;
  }, 0) / (authoritiesList.length || 1);

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Sub-tab Selectors */}
      <div className="flex border border-[#333333] bg-[#1A1A1A] p-1.5 rounded-none flex-wrap gap-1 stone-border">
        <button
          onClick={() => setActiveTab("manufacture")}
          className={`flex-grow md:flex-grow-0 px-5 py-2 text-xs font-mono font-semibold tracking-wider transition uppercase rounded-none flex items-center justify-center gap-2 ${
            activeTab === "manufacture"
              ? "bg-[#D97706] text-black font-bold"
              : "text-gray-400 hover:text-white hover:bg-[#333333]/50"
          }`}
        >
          <Flame className="w-4 h-4" />
          Manufacturing & Engineering
        </button>
        <button
          onClick={() => setActiveTab("infra")}
          className={`flex-grow md:flex-grow-0 px-5 py-2 text-xs font-mono font-semibold tracking-wider transition uppercase rounded-none flex items-center justify-center gap-2 ${
            activeTab === "infra"
              ? "bg-[#D97706] text-black font-bold"
              : "text-gray-400 hover:text-white hover:bg-[#333333]/50"
          }`}
        >
          <Anchor className="w-4 h-4" />
          Infrastructure & Energy
        </button>
        <button
          onClick={() => setActiveTab("housing")}
          className={`flex-grow md:flex-grow-0 px-5 py-2 text-xs font-mono font-semibold tracking-wider transition uppercase rounded-none flex items-center justify-center gap-2 ${
            activeTab === "housing"
              ? "bg-[#D97706] text-black font-bold"
              : "text-gray-400 hover:text-white hover:bg-[#333333]/50"
          }`}
        >
          <Building2 className="w-4 h-4" />
          Housing & Commercial Property
        </button>
        <button
          onClick={() => setActiveTab("labour")}
          className={`flex-grow md:flex-grow-0 px-5 py-2 text-xs font-mono font-semibold tracking-wider transition uppercase rounded-none flex items-center justify-center gap-2 ${
            activeTab === "labour"
              ? "bg-[#D97706] text-black font-bold"
              : "text-gray-400 hover:text-white hover:bg-[#333333]/50"
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          Labour Market & Innovation
        </button>
      </div>

      {/* MANUFACTURING TAB */}
      {activeTab === "manufacture" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          
          {/* Main Context Card */}
          <div className="lg:col-span-2 border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
                Advanced Manufacturing & Heavy Metals
              </div>
              <h3 className="text-xl font-bold text-white font-serif mb-4">
                Steel Heritage & Technological Transition
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed mb-4 font-sans">
                South Yorkshire and the Humber represent the core industrial corridors of Yorkshire, hosting deep-water shipping access, specialized chemical clusters, and advanced steel fabrication. The modern regional economy relies heavily on the technological transition from traditional carbon-intensive forging to lightweight metallurgical casting and offshore wind-assembly components.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="bg-[#111111] border border-[#333333] p-4">
                  <div className="text-[10px] font-mono text-gray-500 uppercase font-semibold">
                    Advanced Engineering GVA Proxy
                  </div>
                  <div className="text-2xl font-black text-[#D97706] font-serif mt-1">
                    £4.25B
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1 leading-relaxed font-sans">
                    Sheffield AMRC cluster, Rotherham advanced metals and glass manufacturing hubs.
                  </p>
                </div>

                <div className="bg-[#111111] border border-[#333333] p-4">
                  <div className="text-[10px] font-mono text-gray-500 uppercase font-semibold">
                    Offshore Wind & Marine Manufacturing
                  </div>
                  <div className="text-2xl font-black text-white font-serif mt-1">
                    £1.82B
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1 leading-relaxed font-sans">
                    Hull Siemens Gamesa turbine facility, Grimsby O&M wind hub, Humber marine transport.
                  </p>
                </div>
              </div>
            </div>

            <div className="border-t border-[#333333] pt-4 mt-6 flex justify-between items-center text-[11px] font-mono text-gray-400">
              <span>ACTIVE SECTOR COVERAGE:</span>
              <span className="text-white font-bold">142 COMPLETED AMRC INTEGRATIONS</span>
            </div>
          </div>

          {/* Subregion specific info */}
          <div className="border border-[#333333] bg-[#131313] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <Wrench className="w-4 h-4 text-[#D97706]" />
                PRODUCTIVITY LEAGUE
              </h4>
              <p className="text-[11px] text-gray-400 leading-relaxed mb-4 font-sans">
                Current labor productivity rankings (GVA per hour worked) for: <strong>{getSubRegionTitle()}</strong>.
              </p>

              <div className="space-y-3">
                {authoritiesList.slice(0, 5).map((auth, idx) => {
                  const series = auth.indicators["productivity"] || [];
                  const val = series[series.length - 1]?.value || 0;
                  return (
                    <div key={idx} className="flex justify-between items-center text-xs pb-2 border-b border-[#333333]">
                      <span className="text-white font-semibold">{auth.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[#D97706] font-bold">£{val.toFixed(1)}/hr</span>
                        <span className="text-[9px] font-mono text-gray-500">GVA</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-[#1A1A1A] border border-[#333333] p-3 text-[10px] font-mono text-gray-500 mt-6 leading-relaxed">
              Industrial productivity is directly correlated with localized capital deployment and heavy machinery automation index scores.
            </div>
          </div>

        </div>
      )}

      {/* INFRASTRUCTURE TAB */}
      {activeTab === "infra" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          
          {/* Rail & Ports Infrastructure list */}
          <div className="lg:col-span-2 border border-[#333333] bg-[#1A1A1A] p-6 rounded-none stone-border">
            <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
              Active Mega Projects & Corridors
            </div>
            <h3 className="text-xl font-bold text-white font-serif mb-4">
              Connectivity Pipelines & Hydrogen Clusters
            </h3>

            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-2 scrollbar-thin">
              {infrastructureProjects.map(proj => {
                const calculatedImpact = (proj.gdpImpactScore * infraMultiplier).toFixed(1);
                return (
                  <div key={proj.id} className="bg-[#111111] border border-[#333333] p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{proj.name}</span>
                        <span className={`text-[9px] font-mono px-2 py-0.5 border ${
                          proj.status === "Under Construction" ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/10" :
                          proj.status === "Planned" ? "border-blue-500/30 text-blue-400 bg-blue-500/10" :
                          "border-amber-500/30 text-amber-400 bg-amber-500/10"
                        }`}>
                          {proj.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-gray-400 mt-1 flex flex-wrap gap-x-4">
                        <span>Type: <strong className="text-gray-300">{proj.type}</strong></span>
                        <span>Region: <strong className="text-gray-300">{proj.subRegion}</strong></span>
                        <span>CapEx Cost: <strong className="text-[#D97706]">£{proj.cost}M</strong></span>
                      </div>
                    </div>

                    <div className="text-right flex md:flex-col items-center md:items-end justify-between w-full md:w-auto border-t md:border-t-0 pt-2 md:pt-0 border-[#333333]">
                      <span className="text-[9px] font-mono text-gray-500 uppercase">Est. EGI Growth Lift</span>
                      <span className="text-lg font-mono font-bold text-[#D97706]">+{calculatedImpact}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Impact Calculator */}
          <div className="border border-[#333333] bg-[#131313] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
                Analytical Sandbox
              </div>
              <h4 className="text-base font-serif text-white mb-4">
                CapEx Efficiency Multiplier
              </h4>
              <p className="text-xs text-gray-300 leading-relaxed mb-4">
                Tweak the infrastructure delivery efficiency index. Lower rates simulate project delay bottlenecks (bureaucracy, supply shortages); higher rates simulate rapid fast-tracking.
              </p>

              {/* Slider widget */}
              <div className="bg-[#1A1A1A] border border-[#333333] p-4 flex flex-col gap-3">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Efficiency Scale</span>
                  <span className="text-[#D97706] font-bold">{(infraMultiplier * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.8"
                  step="0.05"
                  value={infraMultiplier}
                  onChange={(e) => setInfraMultiplier(parseFloat(e.target.value))}
                  className="w-full accent-[#D97706] h-1 bg-[#222222]"
                />
                <div className="text-[10px] text-gray-400 mt-1 text-center">
                  {infraMultiplier < 1.0 ? "⚠️ Delay/Stagnation Scenario active" : "🚀 High CapEx acceleration multiplier active"}
                </div>
              </div>

              <div className="mt-6 space-y-3 text-xs">
                <div className="flex justify-between text-gray-400">
                  <span>Humber Ports Freight Share:</span>
                  <span className="text-white font-mono">18.4% (UK Total)</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Transpennine Corridor Capacity:</span>
                  <span className="text-white font-mono">+120% (by 2029)</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Hydrogen Production Target:</span>
                  <span className="text-white font-mono">10GW (by 2030)</span>
                </div>
              </div>
            </div>

            <div className="bg-[#1A1A1A] border border-[#333333] p-3 text-[10px] font-mono text-gray-500 mt-6 leading-relaxed">
              Connectivity infrastructures reduce transaction costs, thereby accelerating OLS regression correlations on productivity indexes.
            </div>
          </div>

        </div>
      )}

      {/* HOUSING TAB */}
      {activeTab === "housing" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          
          {/* Housing Overview */}
          <div className="lg:col-span-2 border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
                Residential & Commercial Portfolios
              </div>
              <h3 className="text-xl font-bold text-white font-serif mb-4">
                Housing Affordability & Spatial Spreads
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed mb-4 font-sans">
                Yorkshire is characterized by a stark spatial polarization in real estate assets. Commuter suburbs such as Harrogate and affluent historic centers like York command premium residential valuations exceeding £250k–£310k. Conversely, heavy manufacturing centers like Scunthorpe and industrial ports like Hull maintain entry levels under £130k, reflecting substantial structural wage differentials but offering high rental yields for institutional buy-to-let capital.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
                <div className="bg-[#111111] border border-[#333333] p-4 text-center">
                  <span className="text-[9px] font-mono text-gray-500 uppercase block">Affluent Tier Average</span>
                  <span className="text-xl font-bold font-mono text-[#D97706] mt-1 block">£310.0k</span>
                  <span className="text-[10px] text-gray-400 mt-1 block font-sans">Harrogate Borough</span>
                </div>
                <div className="bg-[#111111] border border-[#333333] p-4 text-center">
                  <span className="text-[9px] font-mono text-gray-500 uppercase block">Historic Tier Average</span>
                  <span className="text-xl font-bold font-mono text-white mt-1 block">£245.0k</span>
                  <span className="text-[10px] text-gray-400 mt-1 block font-sans">City of York</span>
                </div>
                <div className="bg-[#111111] border border-[#333333] p-4 text-center">
                  <span className="text-[9px] font-mono text-gray-500 uppercase block">Industrial Tier Average</span>
                  <span className="text-xl font-bold font-mono text-gray-400 mt-1 block">£120.0k</span>
                  <span className="text-[10px] text-gray-400 mt-1 block font-sans">Scunthorpe Works</span>
                </div>
              </div>
            </div>

            <div className="border-t border-[#333333] pt-4 mt-6 flex justify-between items-center text-[11px] font-mono text-gray-400">
              <span>REGIONAL TRANSACTION VOLUMES:</span>
              <span className="text-emerald-400 font-bold">STABLE (+2.4% VOLUME TREND)</span>
            </div>
          </div>

          {/* Valuations Table */}
          <div className="border border-[#333333] bg-[#131313] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-[#D97706]" />
                REGIONAL VALUATIONS
              </h4>
              <p className="text-[11px] text-gray-400 leading-relaxed mb-4 font-sans">
                Estimated average transaction values (HM Land Registry proxy) in: <strong>{getSubRegionTitle()}</strong>.
              </p>

              <div className="space-y-3">
                {authoritiesList.slice(0, 5).map((auth, idx) => {
                  const series = auth.indicators["house_prices"] || [];
                  const val = series[series.length - 1]?.value || 0;
                  return (
                    <div key={idx} className="flex justify-between items-center text-xs pb-2 border-b border-[#333333]">
                      <span className="text-white font-semibold">{auth.name}</span>
                      <span className="font-mono text-[#D97706] font-bold">£{val.toFixed(1)}k</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-[#1A1A1A] border border-[#333333] p-3 text-[10px] font-mono text-gray-500 mt-6 leading-relaxed">
              Residential house prices correlate heavily with full-time median earnings, generating a median multiplier ratio of 4.2x to 5.8x across Yorkshire.
            </div>
          </div>

        </div>
      )}

      {/* LABOUR & INNOVATION */}
      {activeTab === "labour" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          
          {/* Labour overview */}
          <div className="lg:col-span-2 border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
                Skill pools & University Commercialisation
              </div>
              <h3 className="text-xl font-bold text-white font-serif mb-4">
                Research Capital & Knowledge Spillover
              </h3>
              <p className="text-xs text-gray-300 leading-relaxed mb-4 font-sans">
                The Yorkshire and Humber region has a significant academic footprint through elite research hubs such as Leeds University, Sheffield University, and York University. The primary econometric challenge lies in translating academic intellectual capital into regional corporate patent generation, local business startups, and high-value SME growth, reducing the historical talent drainage to London.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="bg-[#111111] border border-[#333333] p-4 flex gap-4 items-center">
                  <GraduationCap className="w-10 h-10 text-[#D97706] shrink-0" />
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 uppercase block">Active Higher-Ed Enrolment</span>
                    <span className="text-lg font-bold text-white font-mono block">124k Students</span>
                    <p className="text-[10px] text-gray-400 mt-0.5 font-sans">Across Russell Group & regional technical academies.</p>
                  </div>
                </div>

                <div className="bg-[#111111] border border-[#333333] p-4 flex gap-4 items-center">
                  <TrendingUp className="w-10 h-10 text-emerald-400 shrink-0" />
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 uppercase block">Patents & Spin-outs</span>
                    <span className="text-lg font-bold text-white font-mono block">312 Registered</span>
                    <p className="text-[10px] text-gray-400 mt-0.5 font-sans">Annual commercializations in biotech, metals, & digital.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-[#333333] pt-4 mt-6 flex justify-between items-center text-[11px] font-mono text-gray-400">
              <span>ACADEMIC DEPLOYMENT METRICS:</span>
              <span className="text-emerald-400 font-bold">HIGH ENGAGEMENT SCALAR (+4.5% TREND)</span>
            </div>
          </div>

          {/* Earnings & Innovation list */}
          <div className="border border-[#333333] bg-[#131313] p-6 rounded-none flex flex-col justify-between stone-border">
            <div>
              <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-[#D97706]" />
                ACADEMIC INNOVATION SCORE
              </h4>
              <p className="text-[11px] text-gray-400 leading-relaxed mb-4 font-sans">
                Research & Innovation indexes (0-100 score) for: <strong>{getSubRegionTitle()}</strong>.
              </p>

              <div className="space-y-3">
                {authoritiesList.slice(0, 5).map((auth, idx) => {
                  const series = auth.indicators["innovation_score"] || [];
                  const val = series[series.length - 1]?.value || 0;
                  return (
                    <div key={idx} className="flex justify-between items-center text-xs pb-2 border-b border-[#333333]">
                      <span className="text-white font-semibold">{auth.name}</span>
                      <span className="font-mono text-[#D97706] font-bold">{val.toFixed(1)} / 100</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-[#1A1A1A] border border-[#333333] p-3 text-[10px] font-mono text-gray-500 mt-6 leading-relaxed">
              Innovation indexes calculate a combined weight of academic spend, corporate R&D tax incentives, and local high-tech employments.
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
