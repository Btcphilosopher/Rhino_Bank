import React, { useState } from "react";
import { BankingExposure } from "../types";
import { ShieldCheck, Percent, Layers, TrendingDown, HelpCircle, Activity, AlertTriangle } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell } from "recharts";

interface BankingDashboardProps {
  exposure: BankingExposure[];
}

export default function BankingDashboard({ exposure }: BankingDashboardProps) {
  const [stressFactor, setStressFactor] = useState<"normal" | "mild" | "severe">("normal");

  // Calculations for Stress Testing
  const getStressMultipliers = () => {
    switch (stressFactor) {
      case "mild":
        return { defaultMult: 1.5, recoveryMult: 0.9, capitalAdequacy: 14.2 };
      case "severe":
        return { defaultMult: 2.8, recoveryMult: 0.72, capitalAdequacy: 11.8 };
      default:
        return { defaultMult: 1.0, recoveryMult: 1.0, capitalAdequacy: 15.6 };
    }
  };

  const stress = getStressMultipliers();

  // Calculate overall metrics
  const totalBookExposure = exposure.reduce((sum, item) => sum + item.exposureAmount, 0);
  const totalSmesFunded = exposure.reduce((sum, item) => sum + item.smeCount, 0);

  // Expected Loss (EL) calculation: Exposure * Default Rate * (1 - Collateral Coverage Proxy)
  const calculateExpectedLoss = (item: BankingExposure) => {
    const adjustedDefault = Math.min(100, item.defaultRate * stress.defaultMult) / 100;
    // Loss Given Default is highly linked to collateral coverage. High coverage = low LGD.
    const lgd = Math.max(0.1, 1 - (item.collateralCoverage * stress.recoveryMult) / 100);
    const loss = item.exposureAmount * adjustedDefault * lgd;
    return parseFloat(loss.toFixed(2));
  };

  const totalExpectedLoss = exposure.reduce((sum, item) => sum + calculateExpectedLoss(item), 0);

  // Prepare chart data
  const chartData = exposure.map(item => ({
    name: item.sector.replace(" (Yorkshire-wide)", "").replace(" General Corporate Lending", ""),
    "Exposure (GBP Millions)": item.exposureAmount,
    "Expected Loss (GBP Millions)": calculateExpectedLoss(item),
  }));

  // Copper colors for custom rendering
  const COLORS = ["#D97706", "#E08520", "#B25E03", "#784102", "#475569", "#1E293B"];

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Risk Controls Panel */}
      <div className="border border-[#333333] bg-[#1A1A1A] p-6 rounded-none flex flex-col md:flex-row justify-between items-start md:items-center gap-4 stone-border">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] flex items-center gap-1.5 mb-1">
            <ShieldCheck className="w-4 h-4 animate-pulse" />
            RISK COMMITTEE & CREDIT COMMITTEE SANDBOX
          </div>
          <h3 className="text-xl font-bold text-white font-serif">
            Macro Stress Testing & Risk Adequacy
          </h3>
          <p className="text-xs text-gray-400 mt-1 leading-relaxed max-w-2xl font-sans">
            Simulate regional recession triggers and industrial shocks. Observe real-time changes to expected credit default rates, risk-weighted assets, and Rhino Bank Capital Adequacy ratios.
          </p>
        </div>

        {/* Stress selector buttons */}
        <div className="flex border border-[#333333] bg-[#0F0F0F] p-1 gap-1 w-full md:w-auto">
          <button
            onClick={() => setStressFactor("normal")}
            className={`flex-grow md:flex-grow-0 px-4 py-1.5 text-xs font-mono font-semibold transition rounded-none uppercase ${
              stressFactor === "normal"
                ? "bg-emerald-600 text-black font-bold"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Normal (Baseline)
          </button>
          <button
            onClick={() => setStressFactor("mild")}
            className={`flex-grow md:flex-grow-0 px-4 py-1.5 text-xs font-mono font-semibold transition rounded-none uppercase ${
              stressFactor === "mild"
                ? "bg-amber-600 text-black font-bold"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Mild Stress
          </button>
          <button
            onClick={() => setStressFactor("severe")}
            className={`flex-grow md:flex-grow-0 px-4 py-1.5 text-xs font-mono font-semibold transition rounded-none uppercase ${
              stressFactor === "severe"
                ? "bg-red-700 text-white font-bold animate-pulse"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Severe Shock
          </button>
        </div>
      </div>

      {/* Credit Summary Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Loan Book */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Total Lending Commitment
            </span>
            <Layers className="w-4 h-4 text-[#D97706]" />
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black text-white font-serif tracking-tight">
              £{totalBookExposure.toFixed(1)}M
            </span>
          </div>
          <p className="text-[10px] text-gray-500 italic mt-1 font-sans">
            Active Yorkshire loan-book assets
          </p>
        </div>

        {/* Expected Loss */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Expected Portfolio Loss (EL)
            </span>
            <AlertTriangle className={`w-4 h-4 ${stressFactor === "severe" ? "text-red-500 animate-bounce" : "text-[#D97706]"}`} />
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className={`text-3xl font-black font-serif tracking-tight ${stressFactor === "severe" ? "text-red-400" : "text-white"}`}>
              £{totalExpectedLoss.toFixed(2)}M
            </span>
          </div>
          <p className="text-[10px] text-gray-500 italic mt-1 flex justify-between font-sans">
            <span>Loss Ratio of Book:</span>
            <span className="font-mono text-gray-300">{((totalExpectedLoss / totalBookExposure) * 100).toFixed(2)}%</span>
          </p>
        </div>

        {/* Funded SMEs */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Active SME Corporate Accounts
            </span>
            <Activity className="w-4 h-4 text-[#D97706]" />
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black text-white font-serif tracking-tight">
              {totalSmesFunded}
            </span>
          </div>
          <p className="text-[10px] text-gray-500 italic mt-1 font-sans">
            Excluding retail mortgages
          </p>
        </div>

        {/* Capital Adequacy Ratio */}
        <div className="border border-[#333333] bg-[#1A1A1A] p-5 rounded-none flex flex-col justify-between h-[120px] stone-border">
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-mono uppercase tracking-wider font-semibold">
              Capital Adequacy (CAR)
            </span>
            <Percent className="w-4 h-4 text-[#D97706]" />
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className={`text-3xl font-black font-serif tracking-tight ${
              stress.capitalAdequacy > 14 ? "text-emerald-400" : "text-amber-400"
            }`}>
              {stress.capitalAdequacy.toFixed(1)}%
            </span>
          </div>
          <p className="text-[10px] text-gray-500 mt-1 flex justify-between font-sans">
            <span>Basel III Tier 1 Limit:</span>
            <span className="font-mono text-gray-400 font-bold">8.5% MIN</span>
          </p>
        </div>

      </div>

      {/* Exposure Chart & Detailed Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recharts Exposure Plot */}
        <div className="lg:col-span-2 border border-[#333333] bg-[#1A1A1A] p-6 rounded-none min-h-[360px] flex flex-col justify-between stone-border">
          <div>
            <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-1">
              CREDIT RISK ALLOCATION BAR PLOT
            </div>
            <h4 className="text-base font-bold font-serif text-white">
              Sectors Exposure & Expected Loan Loss Valuation
            </h4>
          </div>

          <div className="w-full h-[250px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 15, right: 10, left: -10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
                <XAxis
                  dataKey="name"
                  stroke="#9CA3AF"
                  fontSize={8}
                  fontFamily="monospace"
                />
                <YAxis
                  stroke="#9CA3AF"
                  fontSize={9}
                  fontFamily="monospace"
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#111111",
                    border: "1px solid #333333",
                    fontFamily: "monospace",
                    fontSize: "11px",
                  }}
                  itemStyle={{ color: "#E2E8F0" }}
                />
                <Bar dataKey="Exposure (GBP Millions)" fill="#D97706">
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
                <Bar dataKey="Expected Loss (GBP Millions)" fill="#EF4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Portfolio analysis */}
        <div className="border border-[#333333] bg-[#131313] p-6 rounded-none flex flex-col justify-between h-full stone-border">
          <div>
            <div className="text-[11px] font-mono uppercase tracking-widest text-[#D97706] mb-2 flex items-center gap-1.5">
              <Layers className="w-4 h-4" />
              Concentration Index
            </div>
            <h4 className="text-base font-bold font-serif text-white mb-4">
              Herfindahl-Hirschman HHI
            </h4>

            <p className="text-xs text-gray-300 leading-relaxed mb-4 font-sans">
              Rhino Bank's Yorkshire loan portfolio concentration measures:
            </p>

            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-[#333333]">
                <span className="text-gray-400">Calculated HHI Index:</span>
                <span className="font-mono text-emerald-400 font-bold">1,824 (Stable)</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-[#333333]">
                <span className="text-gray-400">Regulatory Risk Grade:</span>
                <span className="font-mono text-white">Tier 2 Diversified</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-[#333333]">
                <span className="text-gray-400">Risk Weighted Assets (RWA):</span>
                <span className="font-mono text-[#D97706] font-bold">£1,452.8M</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Total Solvency Buffer:</span>
                <span className="font-mono text-white">£425.0M</span>
              </div>
            </div>
          </div>

          <div className="bg-[#1A1A1A] border border-[#333333] p-3 text-[10px] font-mono text-gray-500 mt-6 leading-relaxed">
            The Capital Adequacy Ratio is calculated using Basel III standardized frameworks for retail and corporate lending portfolios.
          </div>
        </div>

      </div>

      {/* Granular sector table */}
      <div className="border border-[#333333] bg-[#1A1A1A] p-6 rounded-none stone-border">
        <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-[#D97706]" />
          PORTFOLIO SEGMENTATION BREAKDOWN
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#333333] text-gray-400 font-mono">
                <th className="py-2.5 px-3">FINANCED SECTOR SEGMEMT</th>
                <th className="py-2.5 px-3 text-right">EXPOSURE (£M)</th>
                <th className="py-2.5 px-3 text-right">SME COUNT</th>
                <th className="py-2.5 px-3 text-right">BASE DEFAULT %</th>
                <th className="py-2.5 px-3 text-right">STRESSED DEFAULT %</th>
                <th className="py-2.5 px-3 text-right">COLLATERAL COVER %</th>
                <th className="py-2.5 px-3 text-right">STRESSED LOSS (£M)</th>
              </tr>
            </thead>
            <tbody>
              {exposure.map((item, idx) => {
                const stressedLoss = calculateExpectedLoss(item);
                const adjustedDefault = Math.min(100, item.defaultRate * stress.defaultMult);
                return (
                  <tr
                    key={idx}
                    className="border-b border-[#333333] hover:bg-[#131313]/50 transition"
                  >
                    <td className="py-3 px-3 font-semibold text-white">
                      {item.sector}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-white font-semibold">
                      £{item.exposureAmount.toFixed(1)}M
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-gray-300 font-sans">
                      {item.smeCount || "N/A"}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-gray-300">
                      {item.defaultRate.toFixed(1)}%
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-amber-500 font-semibold">
                      {adjustedDefault.toFixed(1)}%
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-gray-300">
                      {item.collateralCoverage.toFixed(1)}%
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-red-400">
                      £{stressedLoss.toFixed(2)}M
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
