export interface IndicatorDefinition {
  id: string;
  name: string;
  category: "activity" | "infrastructure" | "labor" | "innovation" | "finance";
  description: string;
  unit: string;
  defaultWeight: number; // between 0 and 1
}

export interface IndicatorDataPoint {
  year: number;
  value: number;
}

export interface AuthorityData {
  id: string;
  name: string;
  indicators: Record<string, IndicatorDataPoint[]>;
}

export interface CountyData {
  id: string;
  name: string;
  authorities: AuthorityData[];
}

export interface RegionData {
  id: string;
  name: string;
  counties: CountyData[];
}

export interface WeightsConfig {
  [indicatorId: string]: number; // weight value (0 to 1)
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  weights: WeightsConfig;
  targetGrowthShift: number; // percentage shift, e.g. +5% for infrastructure boost
  type: "baseline" | "custom" | "optimistic" | "pessimistic";
}

export interface ForecastPoint {
  year: number;
  value: number;
  lowerBound: number;
  upperBound: number;
}

export interface ForecastResult {
  indicatorId: string;
  regionId: string;
  modelType: "ARIMA" | "ETS" | "VAR" | "Random Forest" | "XGBoost";
  historical: IndicatorDataPoint[];
  forecast: ForecastPoint[];
  metrics: {
    r2: number;
    rmse: number;
    mape: number;
    aic?: number;
  };
}

export interface BankingExposure {
  sector: string;
  exposureAmount: number; // in GBP Millions
  smeCount: number;
  riskRating: "Low" | "Medium" | "High";
  defaultRate: number; // percentage
  collateralCoverage: number; // percentage
}

export interface InfrastructureProject {
  id: string;
  name: string;
  type: "Rail" | "Road" | "Port" | "Hydrogen" | "Energy" | "Data Centre" | "Regeneration";
  subRegion: string;
  cost: number; // in GBP Millions
  completionYear: number;
  status: "Planned" | "Under Construction" | "Proposed";
  gdpImpactScore: number; // 0 to 10 impact score
}

export interface RConsoleCommand {
  command: string;
  output: string;
  isError?: boolean;
}
