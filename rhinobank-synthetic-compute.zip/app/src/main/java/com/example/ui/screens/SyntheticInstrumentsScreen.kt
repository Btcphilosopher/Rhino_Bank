package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.Black76Engine
import com.example.core.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun SyntheticInstrumentsScreen(
    swaps: List<ComputeSwap>,
    forwards: List<ComputeForwardContract>,
    options: List<ComputeOption>,
    reservations: List<CapacityReservation>,
    notes: List<ComputeLinkedNote>,
    basisList: List<BasisInstrument>,
    modifier: Modifier = Modifier
) {
    var selectedCategoryTab by remember { mutableStateOf(0) }
    val categories = listOf("OPTIONS (BLACK-76)", "SWAPS", "FORWARDS", "RESERVATIONS", "NOTES & BASIS")

    // Interactive Option Pricing Calculator State
    var isCall by remember { mutableStateOf(true) }
    var optionForwardPrice by remember { mutableStateOf(2.55) }
    var optionStrikePrice by remember { mutableStateOf(2.50) }
    var optionExpiryMonths by remember { mutableStateOf(3) }
    var optionVolPercent by remember { mutableStateOf(42.0) }
    var optionRiskFreePercent by remember { mutableStateOf(3.5) }

    val interactiveOptionResult = remember(
        isCall, optionForwardPrice, optionStrikePrice,
        optionExpiryMonths, optionVolPercent, optionRiskFreePercent
    ) {
        Black76Engine.calculateOption(
            isCall = isCall,
            forwardPrice = optionForwardPrice,
            strike = optionStrikePrice,
            timeToExpiryYears = optionExpiryMonths / 12.0,
            volatility = optionVolPercent / 100.0,
            riskFreeRate = optionRiskFreePercent / 100.0
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        item {
            Text(
                text = "SYNTHETIC COMPUTE DERIVATIVES & CONTRACTS",
                style = MaterialTheme.typography.titleMedium,
                color = RbTextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Financial exposure instruments linked to compute capacity indices",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace
            )
        }

        // Section: Category Tab Row
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedCategoryTab,
                containerColor = RbSurface,
                contentColor = RbAccentBlue,
                edgePadding = 0.dp,
                divider = { Divider(color = RbBorderSubtle) },
                modifier = Modifier.border(1.dp, RbBorder, RoundedCornerShape(2.dp))
            ) {
                categories.forEachIndexed { idx, cat ->
                    Tab(
                        selected = selectedCategoryTab == idx,
                        onClick = { selectedCategoryTab = idx },
                        text = {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (selectedCategoryTab == idx) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedCategoryTab == idx) RbAccentBlue else RbTextSecondary
                            )
                        },
                        modifier = Modifier.testTag("synthetic_tab_$idx")
                    )
                }
            }
        }

        when (selectedCategoryTab) {
            0 -> {
                // Interactive Option Pricer via Black-76
                item {
                    Surface(
                        color = RbSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "BLACK-76 COMPUTE OPTION PRICER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RbTextMuted,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )

                                Row {
                                    Button(
                                        onClick = { isCall = true },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isCall) RbAccentBlue else RbSurfaceElevated
                                        ),
                                        shape = RoundedCornerShape(2.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp).testTag("call_toggle_btn")
                                    ) {
                                        Text(text = "CALL", style = MaterialTheme.typography.labelSmall, color = if (isCall) RbBackground else RbTextPrimary)
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Button(
                                        onClick = { isCall = false },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (!isCall) RbAccentBlue else RbSurfaceElevated
                                        ),
                                        shape = RoundedCornerShape(2.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp).testTag("put_toggle_btn")
                                    ) {
                                        Text(text = "PUT", style = MaterialTheme.typography.labelSmall, color = if (!isCall) RbBackground else RbTextPrimary)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "THEORETICAL PREMIUM", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                    Text(
                                        text = String.format(Locale.US, "€%.4f", interactiveOptionResult.priceEur),
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = RbAccentCyan,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Intrinsic: €" + String.format(Locale.US, "%.4f", interactiveOptionResult.intrinsicValueEur) +
                                                " • TimeVal: €" + String.format(Locale.US, "%.4f", interactiveOptionResult.timeValueEur),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RbTextMuted,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "NOTIONAL (100K HRS)", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                    Text(
                                        text = String.format(Locale.US, "€%,d", (interactiveOptionResult.priceEur * 100_000).toInt()),
                                        style = MaterialTheme.typography.titleLarge,
                                        color = RbTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Divider(color = RbBorderSubtle)
                            Spacer(modifier = Modifier.height(10.dp))

                            // Greeks Row
                            Text(text = "ANALYTICAL SENSITIVITIES (GREEKS)", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                GreekBadge(name = "DELTA (Δ)", value = String.format(Locale.US, "%.3f", interactiveOptionResult.delta))
                                GreekBadge(name = "GAMMA (Γ)", value = String.format(Locale.US, "%.4f", interactiveOptionResult.gamma))
                                GreekBadge(name = "VEGA (ν)", value = String.format(Locale.US, "%.4f", interactiveOptionResult.vega))
                                GreekBadge(name = "THETA (θ/d)", value = String.format(Locale.US, "€%.4f", interactiveOptionResult.thetaPerDay))
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Sliders for parameters
                            SliderControl(
                                label = "Underlying Forward Reference F",
                                valueFormatted = String.format(Locale.US, "€%.2f / acc-hr", optionForwardPrice),
                                value = optionForwardPrice.toFloat(),
                                range = 1.0f..5.0f,
                                onValueChange = { optionForwardPrice = it.toDouble() }
                            )

                            SliderControl(
                                label = "Strike Price K",
                                valueFormatted = String.format(Locale.US, "€%.2f / acc-hr", optionStrikePrice),
                                value = optionStrikePrice.toFloat(),
                                range = 1.0f..5.0f,
                                onValueChange = { optionStrikePrice = it.toDouble() }
                            )

                            SliderControl(
                                label = "Time to Expiry T",
                                valueFormatted = "$optionExpiryMonths Months (${optionExpiryMonths * 30}d)",
                                value = optionExpiryMonths.toFloat(),
                                range = 1f..24f,
                                onValueChange = { optionExpiryMonths = it.toInt() }
                            )

                            SliderControl(
                                label = "Implied Volatility σ",
                                valueFormatted = String.format(Locale.US, "%.1f%%", optionVolPercent),
                                value = optionVolPercent.toFloat(),
                                range = 10f..100f,
                                onValueChange = { optionVolPercent = it.toDouble() }
                            )
                        }
                    }
                }
            }

            1 -> {
                // Swaps list
                items(swaps) { swap ->
                    Surface(
                        color = RbSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = swap.swapId, style = MaterialTheme.typography.titleMedium, color = RbAccentBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = if (swap.isPayerFixed) "PAY FIXED / REC FLOAT" else "REC FIXED / PAY FLOAT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RbAccentCyan,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Counterparty: ${swap.counterparty} • Notional: ${String.format(Locale.US, "%,d", swap.notionalHours)} acc-hrs", style = MaterialTheme.typography.bodySmall, color = RbTextSecondary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(text = "FIXED RATE: €" + String.format(Locale.US, "%.2f", swap.fixedRateEur), style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                                    Text(text = "FLOAT REF: €" + String.format(Locale.US, "%.2f", swap.currentFloatingIndexEur), style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "MTM VALUATION", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                    Text(
                                        text = "+€" + String.format(Locale.US, "%,d", swap.netMtmValueEur.toInt()),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = RbPositiveGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Forwards list
                items(forwards) { fwd ->
                    Surface(
                        color = RbSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = fwd.contractId, style = MaterialTheme.typography.titleMedium, color = RbAccentBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = if (fwd.isLong) "LONG DELIVERY" else "SHORT HEDGE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (fwd.isLong) RbPositiveGreen else RbWarningAmber,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Tenor: ${fwd.deliveryTenor.label} • Expiry: ${fwd.deliveryDate} • Offtaker: ${fwd.counterparty}", style = MaterialTheme.typography.bodySmall, color = RbTextSecondary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(text = "STRIKE: €" + String.format(Locale.US, "%.2f", fwd.strikePriceEur), style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                                    Text(text = "CURRENT: €" + String.format(Locale.US, "%.2f", fwd.currentForwardPriceEur), style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "UNREALIZED P&L", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                    Text(
                                        text = "+€" + String.format(Locale.US, "%,d", fwd.unrealizedPnlEur.toInt()),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = RbPositiveGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // Capacity reservations
                items(reservations) { res ->
                    Surface(
                        color = RbSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = res.reservationId, style = MaterialTheme.typography.titleMedium, color = RbAccentBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = res.clusterSpecification, style = MaterialTheme.typography.bodySmall, color = RbTextPrimary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(text = "RESERVATION FEE: €" + String.format(Locale.US, "%.2f", res.reservationFeeEurPerHour) + " / hr", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                                    Text(text = "EXECUTION FEE: €" + String.format(Locale.US, "%.2f", res.executionUsageFeeEurPerHour) + " / hr", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                                    Text(text = "SLA AVAILABILITY: " + String.format(Locale.US, "%.2f%%", res.guaranteedAvailabilitySla), style = MaterialTheme.typography.labelSmall, color = RbPositiveGreen, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "MONTHLY COMMITMENT", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                    Text(text = "€" + String.format(Locale.US, "%,d", res.monthlyTotalCommitmentEur.toInt()), style = MaterialTheme.typography.titleMedium, color = RbTextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }

            4 -> {
                // Notes & Basis
                item {
                    Text(text = "STRUCTURED COMPUTE-LINKED NOTES", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                items(notes) { note ->
                    Surface(
                        color = RbSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = note.title, style = MaterialTheme.typography.titleMedium, color = RbTextPrimary, fontWeight = FontWeight.Bold)
                            Text(text = "Identifier: ${note.noteId} • Maturity: ${note.maturityYears.toInt()}Y • Ref: ${note.benchmarkIndexTicker}", style = MaterialTheme.typography.bodySmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(text = "PARTICIPATION: ${note.participationRatePercent}% (Cap: ${note.capReturnPercent}%)", style = MaterialTheme.typography.labelSmall, color = RbTextSecondary, fontFamily = FontFamily.Monospace)
                                    Text(text = "FLOOR COUPON: ${note.floorCouponPercent}%", style = MaterialTheme.typography.labelSmall, color = RbPositiveGreen, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "VALUATION", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                    Text(text = "€" + String.format(Locale.US, "%,d", note.currentValuationEur.toInt()), style = MaterialTheme.typography.titleMedium, color = RbAccentBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "CROSS-MARKET BASIS SPREADS", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                items(basisList) { b ->
                    Surface(
                        color = RbSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = b.basisId, style = MaterialTheme.typography.titleSmall, color = RbAccentCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = "${b.legA} vs ${b.legB}", style = MaterialTheme.typography.bodySmall, color = RbTextSecondary)
                                Text(text = "Mean Spread: €${b.historicalMeanSpreadEur} • Z-Score: ${b.zScore}", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "SPREAD", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                                Text(text = String.format(Locale.US, "€%.2f", b.spreadEur), style = MaterialTheme.typography.titleMedium, color = RbTextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = "${b.spreadBps.toInt()} bps", style = MaterialTheme.typography.labelSmall, color = RbAccentBlue, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GreekBadge(name: String, value: String) {
    Column(
        modifier = Modifier
            .background(RbSurfaceElevated, RoundedCornerShape(2.dp))
            .border(1.dp, RbBorderSubtle, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = name, style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, style = MaterialTheme.typography.labelMedium, color = RbTextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SliderControl(
    label: String,
    valueFormatted: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = RbTextSecondary)
            Text(text = valueFormatted, style = MaterialTheme.typography.labelSmall, color = RbAccentCyan, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = RbAccentBlue, activeTrackColor = RbAccentBlue, inactiveTrackColor = RbBorder)
        )
    }
}
