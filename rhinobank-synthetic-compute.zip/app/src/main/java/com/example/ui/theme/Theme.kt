package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RhinoDarkColorScheme = darkColorScheme(
    primary = RbAccentBlue,
    onPrimary = RbBackground,
    primaryContainer = RbSurfaceElevated,
    onPrimaryContainer = RbTextPrimary,
    secondary = RbAccentCyan,
    onSecondary = RbBackground,
    secondaryContainer = RbSurfaceVariant,
    onSecondaryContainer = RbTextPrimary,
    tertiary = RbHighlightPurple,
    onTertiary = RbBackground,
    background = RbBackground,
    onBackground = RbTextPrimary,
    surface = RbSurface,
    onSurface = RbTextPrimary,
    surfaceVariant = RbSurfaceVariant,
    onSurfaceVariant = RbTextSecondary,
    outline = RbBorder,
    outlineVariant = RbBorderSubtle,
    error = RbNegativeRed,
    onError = RbTextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Preserve institutional terminal identity
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = RhinoDarkColorScheme,
        typography = Typography,
        content = content
    )
}
