package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.RiskEngine
import com.example.core.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun RiskAndStressScreen(
    swaps: List<ComputeSwap>,
    forwards: List<ComputeForwardContract>,
    options: List<ComputeOption>,
    reservations: List<CapacityReservation>,
    selectedScenarioId: String? = null,
    modifier: Modifier = Modifier
) {
    val portfolioRisk = remember(swaps, forwards, options, reservations) {
        RiskEngine.calculatePortfolioRisk(swaps, forwards, options, reservations)
    }

    val scenarios = remember(portfolioRisk) {
        RiskEngine.evaluateStressScenarios(portfolioRisk)
    }

    var activeScenarioId by remember(selectedScenarioId) {
        mutableStateOf(selectedScenarioId ?: scenarios.first().id)
    }

    val activeScenario = scenarios.find { it.id == activeScenarioId } ?: scenarios.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        item {
            Text(
                text = "PORTFOLIO QUANTITATIVE RISK & VALUE AT RISK (VaR)",
                style = MaterialTheme.typography.titleMedium,
                color = RbTextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Multi-factor delta exposure and institutional stress testing framework",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace
            )
        }

        // Section: Exposure & Value at Risk Ledger
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "AGGREGATE PORTFOLIO EXPOSURE",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "GROSS NOTIONAL", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = "€" + String.format(Locale.US, "%,d", portfolioRisk.grossNotionalEur.toInt()),
                                style = MaterialTheme.typography.titleLarge,
                                color = RbTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "NET MARKET VALUE", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = "+€" + String.format(Locale.US, "%,d", portfolioRisk.totalMarketValueEur.toInt()),
                                style = MaterialTheme.typography.titleLarge,
                                color = RbPositiveGreen,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = RbBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        RiskBox(label = "1D 95% VaR", value = "€" + String.format(Locale.US, "%,d", portfolioRisk.var95DailyEur.toInt()), color = RbWarningAmber)
                        RiskBox(label = "1D 99% VaR", value = "€" + String.format(Locale.US, "%,d", portfolioRisk.var99DailyEur.toInt()), color = RbNegativeRed)
                        RiskBox(label = "EXPECTED SHORTFALL", value = "€" + String.format(Locale.US, "%,d", portfolioRisk.expectedShortfall99Eur.toInt()), color = RbNegativeRed)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = RbBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Factor sensitivities
                    Text(text = "FACTOR DELTA SENSITIVITIES", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SensitivityPill(label = "Δ COMPUTE (+1%)", value = "+€" + String.format(Locale.US, "%,d", portfolioRisk.dvComputePrice1PctEur.toInt()))
                        SensitivityPill(label = "Δ POWER (+€10)", value = "-€" + String.format(Locale.US, "%,d", kotlin.math.abs(portfolioRisk.dvPowerPrice10EurMwh.toInt())))
                        SensitivityPill(label = "Δ RATES (+100BP)", value = "-€" + String.format(Locale.US, "%,d", kotlin.math.abs(portfolioRisk.dvRates100BpsEur.toInt())))
                    }
                }
            }
        }

        // Section: Active Scenario Detail Card
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (activeScenario.severityLevel == "Extreme") RbNegativeRed else RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "${activeScenario.id}: ${activeScenario.name}", style = MaterialTheme.typography.titleMedium, color = RbTextPrimary, fontWeight = FontWeight.Bold)
                            Text(text = "Severity: ${activeScenario.severityLevel}", style = MaterialTheme.typography.labelSmall, color = if (activeScenario.severityLevel == "Extreme") RbNegativeRed else RbWarningAmber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "PORTFOLIO P&L SHOCK", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            val isPos = activeScenario.portfolioPnlImpactEur >= 0
                            Text(
                                text = (if (isPos) "+€" else "-€") + String.format(Locale.US, "%,d", kotlin.math.abs(activeScenario.portfolioPnlImpactEur.toInt())),
                                style = MaterialTheme.typography.titleLarge,
                                color = if (isPos) RbPositiveGreen else RbNegativeRed,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = activeScenario.description, style = MaterialTheme.typography.bodySmall, color = RbTextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ShockParam(name = "COMPUTE SHOCK", value = String.format(Locale.US, "%+.0f%%", activeScenario.computePriceShockPercent))
                        ShockParam(name = "POWER SHOCK", value = String.format(Locale.US, "%+.0f%%", activeScenario.powerPriceShockPercent))
                        ShockParam(name = "UTILIZATION", value = String.format(Locale.US, "%+.0f pp", activeScenario.utilizationShockPercentPoints))
                        ShockParam(name = "POST-STRESS DSCR", value = String.format(Locale.US, "%.2fx", activeScenario.dscrPostStress))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = RbSurfaceElevated,
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "RISK DESK MEMORANDUM: ${activeScenario.riskCommentary}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextPrimary,
                            modifier = Modifier.padding(8.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Section: Stress Scenario Catalog
        item {
            Text(
                text = "INSTITUTIONAL STRESS TEST SCENARIO LIBRARY (9 SCENARIOS)",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(scenarios) { sc ->
            val isSelected = sc.id == activeScenarioId
            Surface(
                color = if (isSelected) RbSurfaceElevated else RbSurface,
                shape = RoundedCornerShape(2.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) RbAccentBlue else RbBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { activeScenarioId = sc.id }
                    .testTag("scenario_card_${sc.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = sc.id, style = MaterialTheme.typography.labelMedium, color = RbAccentBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = sc.name, style = MaterialTheme.typography.bodySmall, color = RbTextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                        Text(text = "Severity: ${sc.severityLevel} • P&L: ${String.format(Locale.US, "%+.1f%%", sc.pnlImpactPercent)}", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                    }
                    val isGain = sc.portfolioPnlImpactEur >= 0
                    Text(
                        text = (if (isGain) "+€" else "-€") + String.format(Locale.US, "%,d", kotlin.math.abs(sc.portfolioPnlImpactEur.toInt())),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isGain) RbPositiveGreen else RbNegativeRed,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun RiskBox(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, style = MaterialTheme.typography.labelMedium, color = color, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SensitivityPill(label: String, value: String) {
    Surface(
        color = RbSurfaceElevated,
        shape = RoundedCornerShape(2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle)
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text(text = value, style = MaterialTheme.typography.labelSmall, color = RbTextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun ShockParam(name: String, value: String) {
    Column {
        Text(text = name, style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, style = MaterialTheme.typography.labelSmall, color = RbAccentCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
