package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.PricingEngine
import com.example.core.model.ComputeInstrument
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun PricingEngineScreen(
    currentInstrument: ComputeInstrument,
    modifier: Modifier = Modifier
) {
    // Interactive Model Inputs State
    var hardwareCapex by remember(currentInstrument) { mutableStateOf(currentInstrument.hardwareClass.referenceCapexEur) }
    var usefulLifeMonths by remember { mutableStateOf(36) }
    var annualCostOfCapital by remember { mutableStateOf(7.5) }
    var utilizationPercent by remember { mutableStateOf(82.0) }
    var powerPriceMwh by remember(currentInstrument) { mutableStateOf(currentInstrument.region.avgPowerPriceEurMwh) }
    var pueFacility by remember(currentInstrument) { mutableStateOf(currentInstrument.region.avgPue) }
    var targetMarginPercent by remember { mutableStateOf(20.0) }
    var useAnnuityCapitalRecovery by remember { mutableStateOf(true) }

    val inputs = remember(
        hardwareCapex, usefulLifeMonths, annualCostOfCapital,
        utilizationPercent, powerPriceMwh, pueFacility, targetMarginPercent,
        currentInstrument
    ) {
        PricingEngine.CostModelInputs(
            hardwareCapexEur = hardwareCapex,
            usefulLifeMonths = usefulLifeMonths,
            annualCostOfCapitalPercent = annualCostOfCapital,
            capacityUtilizationPercent = utilizationPercent,
            electricityTariffEurMwh = powerPriceMwh,
            pueFacility = pueFacility,
            powerConsumptionKw = currentInstrument.hardwareClass.tdpKw,
            targetOperatingMarginPercent = targetMarginPercent
        )
    }

    val breakdown = remember(inputs, currentInstrument.referenceSpotPriceEur) {
        PricingEngine.evaluateCostModel(inputs, currentInstrument.referenceSpotPriceEur)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BOTTOM-UP COMPUTE COST PRICER",
                        style = MaterialTheme.typography.titleMedium,
                        color = RbTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentInstrument.ticker} • ${currentInstrument.region.cityName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbAccentCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    color = RbSurfaceElevated,
                    shape = RoundedCornerShape(2.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder)
                ) {
                    Text(
                        text = if (useAnnuityCapitalRecovery) "METHOD: CAPITAL RECOVERY (CRF)" else "METHOD: STRAIGHT-LINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Section: Outputs Summary Card
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "MODEL VALUATION & COST DECOMPOSITION",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "MARGINAL OPERATING COST", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = String.format(Locale.US, "€%.3f", breakdown.marginalOperatingCostPerHourEur),
                                style = MaterialTheme.typography.titleLarge,
                                color = RbPositiveGreen,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(text = "Per active hour", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "FULLY ALLOCATED COST", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = String.format(Locale.US, "€%.3f", breakdown.fullyAllocatedCostPerHourEur),
                                style = MaterialTheme.typography.titleLarge,
                                color = RbTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(text = "Per billable hour", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = RbBorderSubtle, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "RECOMMENDED PRICE (+${targetMarginPercent.toInt()}% EBIT)", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = String.format(Locale.US, "€%.2f", breakdown.recommendedPriceCostPlusEur),
                                style = MaterialTheme.typography.titleMedium,
                                color = RbAccentBlue,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "BREAKEVEN UTILIZATION", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = String.format(Locale.US, "%.1f%%", breakdown.breakevenUtilizationAtRefPricePercent),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (breakdown.breakevenUtilizationAtRefPricePercent > 85.0) RbWarningAmber else RbAccentCyan,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Section: Unit Cost Component Decomposition Table
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "BOTTOM-UP COMPONENT BREAKDOWN (€ / BILLABLE ACC-HR)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    CostLineItem(
                        name = "Hardware Capital Recovery (CRF)",
                        amountEur = breakdown.capitalRecoveryPerHourEur,
                        percentOfTotal = (breakdown.capitalRecoveryPerHourEur / breakdown.fullyAllocatedCostPerHourEur) * 100.0,
                        color = RbAccentBlue
                    )
                    CostLineItem(
                        name = "Power & Cooling (PUE ${String.format(Locale.US, "%.2f", pueFacility)})",
                        amountEur = breakdown.powerCostPerHourEur,
                        percentOfTotal = (breakdown.powerCostPerHourEur / breakdown.fullyAllocatedCostPerHourEur) * 100.0,
                        color = RbPositiveGreen
                    )
                    CostLineItem(
                        name = "Facility & Colocation Space",
                        amountEur = breakdown.facilityCoolingPerHourEur,
                        percentOfTotal = (breakdown.facilityCoolingPerHourEur / breakdown.fullyAllocatedCostPerHourEur) * 100.0,
                        color = RbAccentCyan
                    )
                    CostLineItem(
                        name = "High-Speed Interconnect / Transit",
                        amountEur = breakdown.networkPerHourEur,
                        percentOfTotal = (breakdown.networkPerHourEur / breakdown.fullyAllocatedCostPerHourEur) * 100.0,
                        color = RbHighlightPurple
                    )
                    CostLineItem(
                        name = "Site Operations & Staffing",
                        amountEur = breakdown.operationsPerHourEur,
                        percentOfTotal = (breakdown.operationsPerHourEur / breakdown.fullyAllocatedCostPerHourEur) * 100.0,
                        color = RbTextSecondary
                    )
                }
            }
        }

        // Section: Interactive Parameter Sliders
        item {
            Text(
                text = "SENSITIVITY & UNDERWRITING ASSUMPTIONS",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Capex slider
                    SliderSetting(
                        label = "Hardware Capex Unit Acquisition",
                        valueFormatted = String.format(Locale.US, "€%,d", hardwareCapex.toInt()),
                        value = hardwareCapex.toFloat(),
                        range = 5000f..50000f,
                        onValueChange = { hardwareCapex = it.toDouble() },
                        testTag = "slider_capex"
                    )

                    // Lifespan slider
                    SliderSetting(
                        label = "Useful Economic Life",
                        valueFormatted = "$usefulLifeMonths Months",
                        value = usefulLifeMonths.toFloat(),
                        range = 12f..60f,
                        onValueChange = { usefulLifeMonths = it.toInt() },
                        testTag = "slider_lifespan"
                    )

                    // Utilization slider
                    SliderSetting(
                        label = "Capacity Utilization Assumption",
                        valueFormatted = String.format(Locale.US, "%.1f%%", utilizationPercent),
                        value = utilizationPercent.toFloat(),
                        range = 40f..98f,
                        onValueChange = { utilizationPercent = it.toDouble() },
                        testTag = "slider_utilization"
                    )

                    // Power Tariff slider
                    SliderSetting(
                        label = "Electricity Tariff (${currentInstrument.region.code})",
                        valueFormatted = String.format(Locale.US, "€%.0f / MWh", powerPriceMwh),
                        value = powerPriceMwh.toFloat(),
                        range = 40f..250f,
                        onValueChange = { powerPriceMwh = it.toDouble() },
                        testTag = "slider_power"
                    )

                    // Facility PUE
                    SliderSetting(
                        label = "Facility PUE (Thermodynamic efficiency)",
                        valueFormatted = String.format(Locale.US, "%.2f", pueFacility),
                        value = pueFacility.toFloat(),
                        range = 1.05f..1.60f,
                        onValueChange = { pueFacility = it.toDouble() },
                        testTag = "slider_pue"
                    )

                    // Margin
                    SliderSetting(
                        label = "Target Contract Margin",
                        valueFormatted = String.format(Locale.US, "%.0f%%", targetMarginPercent),
                        value = targetMarginPercent.toFloat(),
                        range = 0f..50f,
                        onValueChange = { targetMarginPercent = it.toDouble() },
                        testTag = "slider_margin"
                    )
                }
            }
        }
    }
}

@Composable
private fun CostLineItem(
    name: String,
    amountEur: Double,
    percentOfTotal: Double,
    color: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = name, style = MaterialTheme.typography.bodySmall, color = RbTextPrimary)
            LinearProgressIndicator(
                progress = { (percentOfTotal / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(4.dp),
                color = color,
                trackColor = RbSurfaceElevated,
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
            Text(
                text = String.format(Locale.US, "€%.3f", amountEur),
                style = MaterialTheme.typography.labelSmall,
                color = RbTextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = String.format(Locale.US, "(%.1f%%)", percentOfTotal),
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun SliderSetting(
    label: String,
    valueFormatted: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = RbTextSecondary)
            Text(
                text = valueFormatted,
                style = MaterialTheme.typography.labelSmall,
                color = RbAccentCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = RbAccentBlue,
                activeTrackColor = RbAccentBlue,
                inactiveTrackColor = RbBorder
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
