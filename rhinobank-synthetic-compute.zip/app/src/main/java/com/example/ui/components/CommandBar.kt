package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.CommandParser
import com.example.ui.theme.*

@Composable
fun CommandBar(
    onCommandExecute: (CommandParser.CommandResult) -> Unit,
    modifier: Modifier = Modifier
) {
    var commandText by remember { mutableStateOf("") }
    val quickChips = listOf(
        "PRICE RB-GPU-H100-1H-LON",
        "MARKET GPU LONDON",
        "CURVE COMPUTE GPU",
        "STRESS SCEN-02",
        "INFRA DATA-CENTRE",
        "HELP"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(RbBackground)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // Command input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RbSurfaceVariant, RoundedCornerShape(4.dp))
                .border(1.dp, RbBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 10.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RB-SC >",
                style = MaterialTheme.typography.labelMedium,
                color = RbAccentCyan,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.width(8.dp))

            TextField(
                value = commandText,
                onValueChange = { commandText = it },
                placeholder = {
                    Text(
                        text = "Enter terminal command (e.g. PRICE, CURVE, STRESS, HELP)...",
                        style = MaterialTheme.typography.bodySmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = {
                        if (commandText.isNotBlank()) {
                            val result = CommandParser.parse(commandText)
                            onCommandExecute(result)
                            commandText = ""
                        }
                    }
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedTextColor = RbTextPrimary,
                    unfocusedTextColor = RbTextPrimary,
                    cursorColor = RbAccentBlue,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                textStyle = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier
                    .weight(1f)
                    .testTag("command_input")
            )

            IconButton(
                onClick = {
                    if (commandText.isNotBlank()) {
                        val result = CommandParser.parse(commandText)
                        onCommandExecute(result)
                        commandText = ""
                    }
                },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("command_submit_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Execute Command",
                    tint = RbAccentBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Quick Suggestion Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickChips.forEach { chipText ->
                Surface(
                    color = RbSurfaceElevated,
                    shape = RoundedCornerShape(2.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle),
                    onClick = {
                        val result = CommandParser.parse(chipText)
                        onCommandExecute(result)
                    },
                    modifier = Modifier.testTag("chip_${chipText.replace(" ", "_")}")
                ) {
                    Text(
                        text = chipText,
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
