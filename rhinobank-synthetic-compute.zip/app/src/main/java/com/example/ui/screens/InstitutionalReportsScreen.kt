package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.SampleRepository
import com.example.core.model.ComputeInstrument
import com.example.ui.theme.*
import java.time.Instant

@Composable
fun InstitutionalReportsScreen(
    instruments: List<ComputeInstrument>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedReportIndex by remember { mutableStateOf(0) }
    val reportTitles = listOf(
        "DAILY COMPUTE MARKET BENCHMARK",
        "PORTFOLIO EXPOSURE & GREEKS MEMORANDUM",
        "DATA-CENTRE FINANCING & WATERFALL AUDIT",
        "COMPUTE FORWARD TERM STRUCTURE REPORT"
    )

    val reportText = remember(selectedReportIndex, instruments) {
        generateReportContent(selectedReportIndex, instruments)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "INSTITUTIONAL QUANTITATIVE REPORTS",
                        style = MaterialTheme.typography.titleMedium,
                        color = RbTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Exportable audit logs, valuation schedules & CSV exports",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("RhinoBank Institutional Report", reportText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Report & CSV copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RbAccentBlue),
                    shape = RoundedCornerShape(2.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("copy_report_button")
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp), tint = RbBackground)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "COPY CSV", style = MaterialTheme.typography.labelSmall, color = RbBackground, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section: Report Selector
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "SELECT AUDIT / RESEARCH REPORT",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    reportTitles.forEachIndexed { idx, title ->
                        val isSelected = selectedReportIndex == idx
                        Surface(
                            color = if (isSelected) RbSurfaceElevated else RbSurface,
                            shape = RoundedCornerShape(2.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) RbAccentBlue else RbBorderSubtle),
                            onClick = { selectedReportIndex = idx },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .testTag("report_tab_$idx")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = if (isSelected) RbAccentCyan else RbTextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) RbTextPrimary else RbTextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Document Viewer
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "PREVIEW // FORMATTED INSTITUTIONAL TRANSCRIPT",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = RbBackground,
                        shape = RoundedCornerShape(2.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = reportText,
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextPrimary,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(10.dp),
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

private fun generateReportContent(reportIndex: Int, instruments: List<ComputeInstrument>): String {
    val timestamp = "2026-10-09T22:00:00Z"
    val disclaimer = """
================================================================================
RHINOBANK QUANTITATIVE RESEARCH // DISCLOSURE & LIMITATIONS
PROVENANCE: CALIBRATED DETERMINISTIC FINANCIAL SIMULATION
CURRENCY: EUR (€) | UNIT OF QUOTE: ACCELERATOR-HOUR (acc-hr)
STATUS: SIMULATED MODEL OUTPUT - NOT AN EXECUTABLE OFFER NOR INVESTMENT ADVICE
================================================================================
    """.trimIndent()

    return when (reportIndex) {
        0 -> """
$disclaimer

REPORT: DAILY COMPUTE MARKET SUMMARY
GENERATED: $timestamp
FIRM: RHINOBANK INVESTMENT BANKING - COMPUTATIONAL ASSETS DESK
MODEL VERSION: RB-SC-PRICING-v3.7Q

1. EXECUTIVE MARKET SUMMARY
European compute capacity benchmark spot traded at €2.45/acc-hr (+1.8% 24H).
Fleet aggregate utilization stands at 81.4% with 18.6% unallocated reserve.
Power grid tariffs remained stable: Frankfurt €118/MWh, London €132/MWh.

2. CSV EXPORT (TABULAR OBSERVATIONS)
Ticker,Hardware,Region,Unit,SpotPriceEur,1M_FwdPriceEur,MarginalCostEur,FleetSize,UtilizationPct
${instruments.joinToString("\n") { 
    "${it.ticker},${it.hardwareClass.code},${it.region.code},${it.unit.symbol},${it.referenceSpotPriceEur},${it.oneMonthForwardPriceEur},${it.estimatedMarginalCostEur},${it.installedFleetSize},${it.activeFleetUtilization}" 
}}

3. RISK COMMENTARY
Forward curves display mild contango (+5.3% over 30 days) reflecting near-term
seasonal peak power expectations in Northern and Western Europe.
        """.trimIndent()

        1 -> """
$disclaimer

REPORT: PORTFOLIO EXPOSURE & GREEKS RISK MEMORANDUM
GENERATED: $timestamp
PORTFOLIO: RB-GLOBAL-SYNTHETIC-COMPUTE-FUND-01

1. CAPITAL & NOTIONAL BALANCES
• Gross Contractual Notional: €3,416,563
• Net Directional Exposure: +€1,820,000
• Net Marked-to-Market Valuation: +€182,500
• 1-Day 95% Parametric VaR: €71,680
• 1-Day 99% Parametric VaR: €101,350
• 1-Day 99% Expected Shortfall (CVaR): €116,120

2. FACTOR SENSITIVITIES
• Δ Compute Spot (+1%): +€18,200
• Δ Power Tariff (+€10/MWh): -€28,400
• Δ Fleet Utilization (+1%): +€42,500
• Δ Interest Rates (+100 bps): -€38,900

3. POSITION SUMMARY
• SWAP-0881: 250,000 acc-hrs @ €2.42 fixed vs Float (MTM: +€7,500)
• SWAP-0914: 500,000 acc-hrs @ €2.52 fixed vs Float (MTM: +€70,000)
• FWD-H100-90D: 180,000 acc-hrs Long @ €2.50 (MTM: +€14,400)
• RES-4096: Dedicated 512x H100 Pod (InfiniBand NDR 400G) SLA 99.95%
        """.trimIndent()

        2 -> """
$disclaimer

REPORT: DATA-CENTRE FINANCING & WATERFALL AUDIT
FACILITY: Rhino Data Campus Paris-Sud (Titan-1)
LOCATION: Paris Île-de-France (PAR)

1. PHYSICAL ASSET TELEMETRY
• IT Load Capacity: 14.5 MW
• Facility PUE: 1.22
• Total Facility Load: 17.7 MW
• Operational Fleet: 12,288 NVIDIA H100 SXM5
• Total Capex: €425.0M (Gearing: 65.0% Debt / 35.0% Equity)

2. ANNUAL FINANCIAL RESULTS
• Gross Revenue: €206.5M
• Electricity Cost: €15.2M (@ €98.0/MWh)
• Total Opex: €31.4M
• EBITDA: €175.1M
• Annual Senior Debt Service: €66.4M
• Debt Service Coverage Ratio (DSCR): 2.64x (Compliant)
• Unlevered Project IRR: 28.4%
• Payback Period: 2.4 Years

3. CASH FLOW WATERFALL ALLOCATION
• Tranche A (Senior Secured 70%): €46.5M (Coverage: 1.00x - FULL)
• Tranche B (Mezzanine Subordinated 30%): €19.9M (Coverage: 1.00x - FULL)
• Debt Service Reserve Account (DSRA): €10.8M
• Equity Residual Dividend: €97.9M
        """.trimIndent()

        else -> """
$disclaimer

REPORT: COMPUTE FORWARD TERM STRUCTURE CURVE
INSTRUMENT: RB-GPU-H100-1H-LON (London Docklands)

Tenor,Days,ForwardPriceEur,SpotSpreadEur,SpreadBps,PowerCompEur,CapRecoveryEur
SPOT,0,2.45,0.00,0,0.18,1.68
1W,7,2.48,+0.03,+122,0.18,1.67
1M,30,2.58,+0.13,+530,0.19,1.65
3M,90,2.65,+0.20,+816,0.20,1.61
6M,180,2.72,+0.27,+1102,0.21,1.55
12M,365,2.62,+0.17,+693,0.19,1.44
24M,730,2.35,-0.10,-408,0.18,1.25

CURVE STRUCTURE: Contango in 1M-6M tenors shifting to Backwardation at 24M
due to technological hardware deflation from next-generation Blackwell rollouts.
        """.trimIndent()
    }
}
