package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ComputeInstrument
import com.example.core.model.DeliveryRegion
import com.example.core.model.RegionalSupplyDemand
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MarketOverviewScreen(
    instruments: List<ComputeInstrument>,
    supplyDemands: List<RegionalSupplyDemand>,
    selectedRegion: DeliveryRegion,
    onRegionSelect: (DeliveryRegion) -> Unit,
    onInstrumentSelect: (ComputeInstrument) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentRegionalData = supplyDemands.find { it.region == selectedRegion } ?: supplyDemands.first()
    val filteredInstruments = instruments.filter { it.region == selectedRegion }
        .ifEmpty { instruments }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        // Section: Top Institutional KPI Cards
        item {
            Text(
                text = "GLOBAL COMPUTE CAPACITY BENCHMARKS",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "REF GPU SPOT INDEX",
                    value = "€2.45",
                    unit = "/ acc-hr",
                    subtext = "+1.8% (24H)",
                    subtextColor = RbPositiveGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "30D FORWARD INDEX",
                    value = "€2.58",
                    unit = "/ acc-hr",
                    subtext = "+5.3% contango",
                    subtextColor = RbAccentBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "MARGINAL COST",
                    value = "€1.74",
                    unit = "/ acc-hr",
                    subtext = "Power: €0.18/hr",
                    subtextColor = RbTextSecondary,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "FLEET UTILIZATION",
                    value = String.format(Locale.US, "%.1f%%", currentRegionalData.currentUtilizationRate),
                    unit = " active",
                    subtext = "${currentRegionalData.unallocatedAvailable} free GPUs",
                    subtextColor = RbAccentCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section: Delivery Region Selector
        item {
            Text(
                text = "SELECT DELIVERY REGION",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DeliveryRegion.values().forEach { region ->
                    val isSelected = region == selectedRegion
                    Surface(
                        color = if (isSelected) RbAccentBlue else RbSurfaceElevated,
                        shape = RoundedCornerShape(2.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) RbAccentBlue else RbBorderSubtle
                        ),
                        modifier = Modifier
                            .clickable { onRegionSelect(region) }
                            .testTag("region_chip_${region.code}")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = region.code,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isSelected) RbBackground else RbTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${region.avgPowerPriceEurMwh.toInt()} €/MWh",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) RbBackground else RbTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Section: Regional Supply & Demand Ledger
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "REGIONAL CAPACITY LEDGER: ${selectedRegion.cityName} (${selectedRegion.code})",
                            style = MaterialTheme.typography.titleMedium,
                            color = RbTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = RbSurfaceVariant,
                            shape = RoundedCornerShape(2.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle)
                        ) {
                            Text(
                                text = selectedRegion.connectivityRank,
                                style = MaterialTheme.typography.labelSmall,
                                color = RbAccentCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LedgerMetric(label = "INSTALLED", value = "${currentRegionalData.installedAccelerators}")
                        LedgerMetric(label = "RESERVED", value = "${currentRegionalData.contractuallyReserved}")
                        LedgerMetric(label = "UTILIZED", value = "${currentRegionalData.activeUtilized}")
                        LedgerMetric(label = "AVAILABLE", value = "${currentRegionalData.unallocatedAvailable}", highlight = true)
                        LedgerMetric(label = "+30D PIPELINE", value = "+${currentRegionalData.plannedAdditions30d}")
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = RbBorderSubtle, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "GRID POWER: ${currentRegionalData.averagePowerCostEurMwh} €/MWh  |  PUE: ${selectedRegion.avgPue}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "CARBON-FREE: ${currentRegionalData.carbonFreeEnergySharePercent.toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbPositiveGreen,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section: Active Traded Compute Contracts Tape
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STANDARDISED COMPUTE CONTRACTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RbTextMuted,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${filteredInstruments.size} CONTRACTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RbTextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        items(filteredInstruments) { inst ->
            InstrumentCard(
                instrument = inst,
                onClick = { onInstrumentSelect(inst) }
            )
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    unit: String,
    subtext: String,
    subtextColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = RbSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    color = RbTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = unit,
                    style = MaterialTheme.typography.labelSmall,
                    color = RbTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 2.dp, start = 2.dp)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtext,
                style = MaterialTheme.typography.labelSmall,
                color = subtextColor,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun LedgerMetric(label: String, value: String, highlight: Boolean = false) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = RbTextMuted,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = if (highlight) RbAccentCyan else RbTextPrimary,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun InstrumentCard(
    instrument: ComputeInstrument,
    onClick: () -> Unit
) {
    Surface(
        color = RbSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("instrument_card_${instrument.ticker}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = instrument.ticker,
                        style = MaterialTheme.typography.titleMedium,
                        color = RbAccentBlue,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = RbSurfaceVariant,
                        shape = RoundedCornerShape(2.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle)
                    ) {
                        Text(
                            text = instrument.region.code,
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextSecondary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${instrument.hardwareClass.displayName} • ${instrument.unit.symbol}",
                    style = MaterialTheme.typography.bodySmall,
                    color = RbTextSecondary
                )
                Text(
                    text = "Fleet: ${instrument.installedFleetSize} units • SLA ${instrument.slaAvailabilityPercent}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = RbTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format(Locale.US, "€%.2f", instrument.referenceSpotPriceEur),
                    style = MaterialTheme.typography.titleMedium,
                    color = RbTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "1M FWD: " + String.format(Locale.US, "€%.2f", instrument.oneMonthForwardPriceEur),
                    style = MaterialTheme.typography.labelSmall,
                    color = RbAccentCyan,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "MC: " + String.format(Locale.US, "€%.2f", instrument.estimatedMarginalCostEur),
                    style = MaterialTheme.typography.labelSmall,
                    color = RbTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
