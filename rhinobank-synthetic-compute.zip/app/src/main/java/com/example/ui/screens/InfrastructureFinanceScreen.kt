package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.InfrastructureEngine
import com.example.core.model.InfrastructureProject
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun InfrastructureFinanceScreen(
    baseProject: InfrastructureProject,
    modifier: Modifier = Modifier
) {
    // Interactive Infrastructure Adjustments
    var totalCapexMillions by remember { mutableStateOf(baseProject.totalCapexMillionsEur) }
    var itLoadMw by remember { mutableStateOf(baseProject.itLoadCapacityMw) }
    var pue by remember { mutableStateOf(baseProject.facilityPue) }
    var debtRatioPercent by remember { mutableStateOf(baseProject.debtRatioPercent) }
    var interestRatePercent by remember { mutableStateOf(baseProject.debtInterestRatePercent) }
    var targetComputePrice by remember { mutableStateOf(baseProject.targetComputePriceEurPerHour) }
    var utilizationPercent by remember { mutableStateOf(baseProject.assumedUtilizationPercent) }

    val currentProject = remember(
        totalCapexMillions, itLoadMw, pue, debtRatioPercent,
        interestRatePercent, targetComputePrice, utilizationPercent, baseProject
    ) {
        baseProject.copy(
            totalCapexMillionsEur = totalCapexMillions,
            itLoadCapacityMw = itLoadMw,
            facilityPue = pue,
            debtRatioPercent = debtRatioPercent,
            debtInterestRatePercent = interestRatePercent,
            targetComputePriceEurPerHour = targetComputePrice,
            assumedUtilizationPercent = utilizationPercent
        )
    }

    val (metrics, waterfall) = remember(currentProject) {
        InfrastructureEngine.evaluateInfrastructure(currentProject)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DATA-CENTRE INFRASTRUCTURE FINANCE",
                        style = MaterialTheme.typography.titleMedium,
                        color = RbTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentProject.facilityName} • ${currentProject.region.cityName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbAccentCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    color = RbSurfaceElevated,
                    shape = RoundedCornerShape(2.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder)
                ) {
                    Text(
                        text = "PUE ${String.format(Locale.US, "%.2f", metrics.totalPowerLoadMw / currentProject.itLoadCapacityMw)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Section: Primary Infrastructure Underwriting KPIs
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "PROJECT RETURN & DEBT COVERAGE (DSCR)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "DEBT SERVICE COVERAGE (DSCR)", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            val dscrColor = if (metrics.debtServiceCoverageRatio >= 1.40) RbPositiveGreen else if (metrics.debtServiceCoverageRatio >= 1.15) RbWarningAmber else RbNegativeRed
                            Text(
                                text = String.format(Locale.US, "%.2fx", metrics.debtServiceCoverageRatio),
                                style = MaterialTheme.typography.headlineMedium,
                                color = dscrColor,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(text = "Covenant Minimum: 1.25x", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "PROJECT IRR (UNLEVERED)", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(
                                text = String.format(Locale.US, "%.1f%%", metrics.projectIrrPercent),
                                style = MaterialTheme.typography.headlineMedium,
                                color = RbAccentBlue,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(text = "NPV: €" + String.format(Locale.US, "%.1fM", metrics.projectNpvMillionsEur), style = MaterialTheme.typography.labelSmall, color = RbAccentCyan, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = RbBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        InfraMetricItem(label = "TOTAL FACILITY LOAD", value = String.format(Locale.US, "%.1f MW", metrics.totalPowerLoadMw))
                        InfraMetricItem(label = "ANNUAL EBITDA", value = String.format(Locale.US, "€%.1fM", metrics.annualEbitdaMillionsEur))
                        InfraMetricItem(label = "BREAKEVEN COMPUTE", value = String.format(Locale.US, "€%.2f / hr", metrics.breakevenComputePriceEurPerHour))
                        InfraMetricItem(label = "PAYBACK PERIOD", value = String.format(Locale.US, "%.1f Yrs", metrics.paybackPeriodYears))
                    }
                }
            }
        }

        // Section: Structured Cash Flow Waterfall
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "SYNTHETIC SECURITISATION CASH FLOW WATERFALL",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Available Operating Cash Flow: €" + String.format(Locale.US, "%.2fM / year", waterfall.availableOperatingCashMillionsEur),
                        style = MaterialTheme.typography.labelSmall,
                        color = RbAccentCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Tranche A
                    WaterfallTrancheCard(
                        title = waterfall.seniorTranche.name,
                        targetMillions = waterfall.seniorTranche.principalTargetMillionsEur,
                        couponPercent = waterfall.seniorTranche.couponRatePercent,
                        coverage = waterfall.seniorTranche.coverageMultiple,
                        status = waterfall.seniorTranche.status,
                        color = RbAccentBlue
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tranche B
                    WaterfallTrancheCard(
                        title = waterfall.mezzanineTranche.name,
                        targetMillions = waterfall.mezzanineTranche.principalTargetMillionsEur,
                        couponPercent = waterfall.mezzanineTranche.couponRatePercent,
                        coverage = waterfall.mezzanineTranche.coverageMultiple,
                        status = waterfall.mezzanineTranche.status,
                        color = RbAccentCyan
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Reserve & Equity Residual
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "DEBT SERVICE RESERVE (DSRA)", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(text = "€" + String.format(Locale.US, "%.2fM", waterfall.reserveAccountFundingMillionsEur), style = MaterialTheme.typography.labelMedium, color = RbWarningAmber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "JUNIOR EQUITY RESIDUAL DIVIDEND", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                            Text(text = "€" + String.format(Locale.US, "%.2fM / yr", waterfall.equityResidualMillionsEur), style = MaterialTheme.typography.labelMedium, color = RbPositiveGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section: Underwriting Adjustment Sliders
        item {
            Text(
                text = "FACILITY FINANCING & LOAD ADJUSTMENTS",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SliderRow(
                        label = "Total Project Capex",
                        valueFormatted = String.format(Locale.US, "€%.0fM", totalCapexMillions),
                        value = totalCapexMillions.toFloat(),
                        range = 100f..800f,
                        onValueChange = { totalCapexMillions = it.toDouble() }
                    )

                    SliderRow(
                        label = "IT Load Capacity",
                        valueFormatted = String.format(Locale.US, "%.1f MW", itLoadMw),
                        value = itLoadMw.toFloat(),
                        range = 5f..40f,
                        onValueChange = { itLoadMw = it.toDouble() }
                    )

                    SliderRow(
                        label = "Debt Gearing (LTV)",
                        valueFormatted = String.format(Locale.US, "%.0f%%", debtRatioPercent),
                        value = debtRatioPercent.toFloat(),
                        range = 20f..85f,
                        onValueChange = { debtRatioPercent = it.toDouble() }
                    )

                    SliderRow(
                        label = "Senior Debt Cost",
                        valueFormatted = String.format(Locale.US, "%.2f%%", interestRatePercent),
                        value = interestRatePercent.toFloat(),
                        range = 3f..12f,
                        onValueChange = { interestRatePercent = it.toDouble() }
                    )

                    SliderRow(
                        label = "Target Compute Price",
                        valueFormatted = String.format(Locale.US, "€%.2f / acc-hr", targetComputePrice),
                        value = targetComputePrice.toFloat(),
                        range = 1.20f..4.00f,
                        onValueChange = { targetComputePrice = it.toDouble() }
                    )
                }
            }
        }
    }
}

@Composable
private fun InfraMetricItem(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, style = MaterialTheme.typography.labelMedium, color = RbTextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun WaterfallTrancheCard(
    title: String,
    targetMillions: Double,
    couponPercent: Double,
    coverage: Double,
    status: String,
    color: androidx.compose.ui.graphics.Color
) {
    Surface(
        color = RbSurfaceElevated,
        shape = RoundedCornerShape(2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = title, style = MaterialTheme.typography.bodySmall, color = color, fontWeight = FontWeight.Bold)
                Text(text = status, style = MaterialTheme.typography.labelSmall, color = if (coverage >= 1.0) RbPositiveGreen else RbNegativeRed, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Principal: €" + String.format(Locale.US, "%.1fM", targetMillions) + " • Coupon: " + String.format(Locale.US, "%.2f%%", couponPercent), style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                Text(text = "Coverage: " + String.format(Locale.US, "%.2fx", coverage), style = MaterialTheme.typography.labelSmall, color = RbTextPrimary, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueFormatted: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = RbTextSecondary)
            Text(text = valueFormatted, style = MaterialTheme.typography.labelSmall, color = RbAccentCyan, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = RbAccentBlue, activeTrackColor = RbAccentBlue, inactiveTrackColor = RbBorder)
        )
    }
}
