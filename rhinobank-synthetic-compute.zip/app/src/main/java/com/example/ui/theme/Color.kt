package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RhinoBank Institutional Dark Terminal Palette
val RbBackground = Color(0xFF090D14)
val RbSurface = Color(0xFF0F1722)
val RbSurfaceVariant = Color(0xFF16202E)
val RbSurfaceElevated = Color(0xFF1E2B3D)
val RbBorder = Color(0xFF243347)
val RbBorderSubtle = Color(0xFF1B2838)

val RbTextPrimary = Color(0xFFF0F6FC)
val RbTextSecondary = Color(0xFF8B949E)
val RbTextMuted = Color(0xFF5A6575)

val RbAccentBlue = Color(0xFF388BFD)
val RbAccentCyan = Color(0xFF39C5BB)
val RbPositiveGreen = Color(0xFF2EA043)
val RbNegativeRed = Color(0xFFF85149)
val RbWarningAmber = Color(0xFFD29922)
val RbHighlightPurple = Color(0xFFA371F7)

// Legacy compatibility
val Purple80 = RbAccentBlue
val PurpleGrey80 = RbSurfaceVariant
val Pink80 = RbAccentCyan
val Purple40 = RbAccentBlue
val PurpleGrey40 = RbSurface
val Pink40 = RbAccentCyan
