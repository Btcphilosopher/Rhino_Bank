package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.ForwardCurveEngine
import com.example.core.model.ComputeInstrument
import com.example.core.model.ForwardPoint
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ForwardCurvesScreen(
    currentInstrument: ComputeInstrument,
    allInstruments: List<ComputeInstrument>,
    onInstrumentChange: (ComputeInstrument) -> Unit,
    modifier: Modifier = Modifier
) {
    var powerAdjustmentPercent by remember { mutableStateOf(0.0) }
    var techDeflationAnnualPercent by remember { mutableStateOf(-14.0) }

    val curve = remember(currentInstrument, powerAdjustmentPercent, techDeflationAnnualPercent) {
        ForwardCurveEngine.constructCurve(
            instrument = currentInstrument,
            powerForwardAdjustmentPercent = powerAdjustmentPercent,
            technologicalDeflationAnnualPercent = techDeflationAnnualPercent
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RbBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 10.dp)
    ) {
        // Section: Header & Instrument Switcher
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COMPUTE FORWARD TERM STRUCTURE",
                        style = MaterialTheme.typography.titleMedium,
                        color = RbTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${curve.ticker} • ${curve.region.cityName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbAccentCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    color = RbSurfaceElevated,
                    shape = RoundedCornerShape(2.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder)
                ) {
                    Text(
                        text = curve.curveStructure,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (curve.curveStructure.contains("Contango")) RbAccentBlue else RbWarningAmber,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Section: Instrument Selector Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                allInstruments.forEach { inst ->
                    val isSelected = inst.ticker == currentInstrument.ticker
                    Surface(
                        color = if (isSelected) RbAccentBlue else RbSurfaceElevated,
                        shape = RoundedCornerShape(2.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) RbAccentBlue else RbBorderSubtle),
                        onClick = { onInstrumentChange(inst) },
                        modifier = Modifier.testTag("curve_chip_${inst.ticker}")
                    ) {
                        Text(
                            text = inst.ticker,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) RbBackground else RbTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Section: Forward Curve Canvas Chart
        item {
            Surface(
                color = RbSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RbBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "CALIBRATED FORWARD CURVE & 95% CONFIDENCE INTERVAL",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "EUR / ACC-HR",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    ForwardCurveCanvas(points = curve.points, spotPrice = curve.spotPriceEur)

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(RbAccentBlue))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Forward Price", style = MaterialTheme.typography.labelSmall, color = RbTextSecondary)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(RbAccentCyan.copy(alpha = 0.4f)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "95% Confidence Band", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(RbPositiveGreen))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Power Basis Floor", style = MaterialTheme.typography.labelSmall, color = RbTextMuted)
                        }
                    }
                }
            }
        }

        // Section: Tenor Points Ledger Table
        item {
            Text(
                text = "TENOR TERM STRUCTURE LEDGER",
                style = MaterialTheme.typography.labelSmall,
                color = RbTextMuted,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(curve.points) { pt ->
            TenorPointRow(point = pt, spotPrice = curve.spotPriceEur)
        }
    }
}

@Composable
private fun ForwardCurveCanvas(
    points: List<ForwardPoint>,
    spotPrice: Double
) {
    val prices = points.map { it.forwardPriceEur }
    val uppers = points.map { it.confidenceUpperEur }
    val lowers = points.map { it.confidenceLowerEur }
    val powers = points.map { it.powerComponentEur }

    val minVal = (lowers + powers).minOrNull()?.minus(0.20)?.coerceAtLeast(0.0) ?: 0.5
    val maxVal = (uppers + prices).maxOrNull()?.plus(0.20) ?: 4.0
    val range = maxVal - minVal

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .background(RbSurfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            .border(1.dp, RbBorderSubtle, RoundedCornerShape(2.dp))
    ) {
        val w = size.width
        val h = size.height
        val padX = 24.dp.toPx()
        val padY = 20.dp.toPx()
        val chartW = w - padX * 2
        val chartH = h - padY * 2

        if (points.isEmpty()) return@Canvas

        // Draw horizontal grid lines
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = padY + (chartH / gridLines) * i
            drawLine(
                color = RbBorder.copy(alpha = 0.5f),
                start = Offset(padX, y),
                end = Offset(w - padX, y),
                strokeWidth = 1f
            )
        }

        val stepX = chartW / (points.size - 1).coerceAtLeast(1)

        // 1. Shaded Confidence Interval Path
        val bandPath = Path()
        points.forEachIndexed { i, pt ->
            val x = padX + i * stepX
            val yUpper = padY + chartH - ((pt.confidenceUpperEur - minVal) / range * chartH).toFloat()
            if (i == 0) bandPath.moveTo(x, yUpper) else bandPath.lineTo(x, yUpper)
        }
        for (i in points.indices.reversed()) {
            val x = padX + i * stepX
            val yLower = padY + chartH - ((points[i].confidenceLowerEur - minVal) / range * chartH).toFloat()
            bandPath.lineTo(x, yLower)
        }
        bandPath.close()
        drawPath(path = bandPath, color = RbAccentCyan.copy(alpha = 0.12f))

        // 2. Power Component Line
        val powerPath = Path()
        points.forEachIndexed { i, pt ->
            val x = padX + i * stepX
            val yPower = padY + chartH - ((pt.powerComponentEur - minVal) / range * chartH).toFloat()
            if (i == 0) powerPath.moveTo(x, yPower) else powerPath.lineTo(x, yPower)
        }
        drawPath(path = powerPath, color = RbPositiveGreen.copy(alpha = 0.8f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))

        // 3. Forward Price Main Curve
        val curvePath = Path()
        points.forEachIndexed { i, pt ->
            val x = padX + i * stepX
            val yFwd = padY + chartH - ((pt.forwardPriceEur - minVal) / range * chartH).toFloat()
            if (i == 0) curvePath.moveTo(x, yFwd) else curvePath.lineTo(x, yFwd)
        }
        drawPath(path = curvePath, color = RbAccentBlue, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

        // 4. Point markers
        points.forEachIndexed { i, pt ->
            val x = padX + i * stepX
            val yFwd = padY + chartH - ((pt.forwardPriceEur - minVal) / range * chartH).toFloat()
            drawCircle(color = RbAccentBlue, radius = 4.dp.toPx(), center = Offset(x, yFwd))
            drawCircle(color = RbBackground, radius = 2.dp.toPx(), center = Offset(x, yFwd))
        }
    }
}

@Composable
private fun TenorPointRow(
    point: ForwardPoint,
    spotPrice: Double
) {
    Surface(
        color = RbSurface,
        shape = RoundedCornerShape(2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RbBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = point.tenor.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = RbTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${point.tenor.daysToExpiry}d)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "Power: €" + String.format(Locale.US, "%.2f", point.powerComponentEur) +
                            " • CapRec: €" + String.format(Locale.US, "%.2f", point.capitalRecoveryComponentEur),
                    style = MaterialTheme.typography.labelSmall,
                    color = RbTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format(Locale.US, "€%.3f", point.forwardPriceEur),
                    style = MaterialTheme.typography.titleMedium,
                    color = RbAccentBlue,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                val isPositive = point.spotSpreadEur >= 0.0
                Text(
                    text = (if (isPositive) "+" else "") + String.format(Locale.US, "€%.2f (%.0f bps)", point.spotSpreadEur, point.spotSpreadBps),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isPositive) RbPositiveGreen else RbNegativeRed,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
