package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.data.SampleRepository
import com.example.ui.theme.*

@Composable
fun TerminalTopBar(
    onResetSimulation: () -> Unit = {},
    onShowEnvironmentInfo: () -> Unit = {}
) {
    Surface(
        color = RbSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = RbBorderSubtle)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Primary status bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Logo and terminal identifier
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.rb_logo),
                        contentDescription = "RhinoBank Logo",
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "RHINOBANK",
                                style = MaterialTheme.typography.titleMedium,
                                color = RbTextPrimary,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SYNTHETIC COMPUTE",
                                style = MaterialTheme.typography.labelMedium,
                                color = RbAccentCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "RB-SC // TERMINAL v3.7Q",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Right: Environment badge & quick actions
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Feed Status indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(RbSurfaceVariant, RoundedCornerShape(4.dp))
                            .border(1.dp, RbBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(RbPositiveGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "FEED: CALIBRATED",
                            style = MaterialTheme.typography.labelSmall,
                            color = RbPositiveGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onResetSimulation,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("reset_simulation_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Demo Data",
                            tint = RbTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onShowEnvironmentInfo,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("environment_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Environment Metadata",
                            tint = RbAccentBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Secondary telemetry metadata strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Environment banner
                Text(
                    text = "[${SampleRepository.environmentLabel}]",
                    style = MaterialTheme.typography.labelSmall,
                    color = RbWarningAmber,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )

                // Timestamp & currency
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "TS: 2026-10-09 22:00 UTC",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "BASE: EUR (€)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
