package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.SampleRepository
import com.example.core.engine.CommandParser
import com.example.core.model.ComputeInstrument
import com.example.core.model.DeliveryRegion
import com.example.ui.components.CommandBar
import com.example.ui.components.TerminalTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                RhinoBankTerminalApp()
            }
        }
    }
}

data class NavWorkspace(
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RhinoBankTerminalApp() {
    // Navigation State
    var currentWorkspaceIndex by remember { mutableStateOf(0) }
    var selectedRegion by remember { mutableStateOf(DeliveryRegion.LONDON) }
    var currentInstrument by remember { mutableStateOf(SampleRepository.defaultInstruments.first()) }
    var selectedStressScenarioId by remember { mutableStateOf<String?>(null) }

    // Dialog State
    var showEnvironmentDialog by remember { mutableStateOf(false) }
    var activeCommandInfo by remember { mutableStateOf<CommandParser.CommandResult.Information?>(null) }
    var activeCommandError by remember { mutableStateOf<CommandParser.CommandResult.Error?>(null) }

    val workspaces = listOf(
        NavWorkspace("MARKETS", Icons.Default.Analytics, "nav_markets"),
        NavWorkspace("PRICER", Icons.Default.Calculate, "nav_pricer"),
        NavWorkspace("CURVES", Icons.AutoMirrored.Filled.TrendingUp, "nav_curves"),
        NavWorkspace("SYNTHETIC", Icons.Default.AccountBalance, "nav_synthetic"),
        NavWorkspace("INFRA", Icons.Default.Domain, "nav_infra"),
        NavWorkspace("RISK", Icons.Default.Shield, "nav_risk"),
        NavWorkspace("REPORTS", Icons.Default.Description, "nav_reports")
    )

    // BackHandler: return to Markets if on another screen
    BackHandler(enabled = currentWorkspaceIndex != 0) {
        currentWorkspaceIndex = 0
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)) {
                TerminalTopBar(
                    onResetSimulation = {
                        selectedRegion = DeliveryRegion.LONDON
                        currentInstrument = SampleRepository.defaultInstruments.first()
                        selectedStressScenarioId = null
                    },
                    onShowEnvironmentInfo = {
                        showEnvironmentDialog = true
                    }
                )
                CommandBar(
                    onCommandExecute = { result ->
                        when (result) {
                            is CommandParser.CommandResult.NavigateWorkspace -> {
                                currentWorkspaceIndex = result.workspaceIndex
                                if (result.targetTicker != null) {
                                    val match = SampleRepository.defaultInstruments.find {
                                        it.ticker.contains(result.targetTicker, ignoreCase = true)
                                    }
                                    if (match != null) currentInstrument = match
                                }
                                if (result.contextData != null && result.workspaceIndex == 5) {
                                    selectedStressScenarioId = result.contextData
                                }
                                if (result.contextData != null && result.workspaceIndex == 0) {
                                    val reg = DeliveryRegion.values().find {
                                        it.code.equals(result.contextData, ignoreCase = true) ||
                                                it.cityName.contains(result.contextData, ignoreCase = true)
                                    }
                                    if (reg != null) selectedRegion = reg
                                }
                            }
                            is CommandParser.CommandResult.Information -> {
                                activeCommandInfo = result
                            }
                            is CommandParser.CommandResult.Error -> {
                                activeCommandError = result
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = RbSurface,
                contentColor = RbAccentBlue,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(width = 1.dp, color = RbBorderSubtle)
            ) {
                workspaces.forEachIndexed { index, ws ->
                    val isSelected = currentWorkspaceIndex == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentWorkspaceIndex = index },
                        icon = {
                            Icon(
                                imageVector = ws.icon,
                                contentDescription = ws.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = ws.title,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 9.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RbAccentBlue,
                            selectedTextColor = RbAccentBlue,
                            unselectedIconColor = RbTextMuted,
                            unselectedTextColor = RbTextMuted,
                            indicatorColor = RbSurfaceElevated
                        ),
                        modifier = Modifier.testTag(ws.testTag)
                    )
                }
            }
        },
        containerColor = RbBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentWorkspaceIndex) {
                0 -> MarketOverviewScreen(
                    instruments = SampleRepository.defaultInstruments,
                    supplyDemands = SampleRepository.regionalSupplyDemands,
                    selectedRegion = selectedRegion,
                    onRegionSelect = { selectedRegion = it },
                    onInstrumentSelect = {
                        currentInstrument = it
                        currentWorkspaceIndex = 1
                    }
                )

                1 -> PricingEngineScreen(
                    currentInstrument = currentInstrument
                )

                2 -> ForwardCurvesScreen(
                    currentInstrument = currentInstrument,
                    allInstruments = SampleRepository.defaultInstruments,
                    onInstrumentChange = { currentInstrument = it }
                )

                3 -> SyntheticInstrumentsScreen(
                    swaps = SampleRepository.sampleSwaps,
                    forwards = SampleRepository.sampleForwards,
                    options = SampleRepository.sampleOptions,
                    reservations = SampleRepository.sampleReservations,
                    notes = SampleRepository.sampleNotes,
                    basisList = SampleRepository.sampleBasis
                )

                4 -> InfrastructureFinanceScreen(
                    baseProject = SampleRepository.sampleInfrastructureProject
                )

                5 -> RiskAndStressScreen(
                    swaps = SampleRepository.sampleSwaps,
                    forwards = SampleRepository.sampleForwards,
                    options = SampleRepository.sampleOptions,
                    reservations = SampleRepository.sampleReservations,
                    selectedScenarioId = selectedStressScenarioId
                )

                6 -> InstitutionalReportsScreen(
                    instruments = SampleRepository.defaultInstruments
                )
            }
        }
    }

    // Modal: Environment & Institutional Metadata Dialog
    if (showEnvironmentDialog) {
        AlertDialog(
            onDismissRequest = { showEnvironmentDialog = false },
            confirmButton = {
                TextButton(onClick = { showEnvironmentDialog = false }) {
                    Text(text = "DISMISS", color = RbAccentBlue, fontFamily = FontFamily.Monospace)
                }
            },
            title = {
                Text(
                    text = "RHINOBANK TERMINAL METADATA",
                    style = MaterialTheme.typography.titleMedium,
                    color = RbTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "ENVIRONMENT: ${SampleRepository.environmentLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbWarningAmber,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "PROVENANCE: Deterministic multi-factor calibrated demo dataset for Q4 2026. Spot prices, grid power rates, forward carry and capital recovery curves represent a calibrated simulation model for institutional risk and computational asset valuation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = RbTextSecondary
                    )
                    Divider(color = RbBorderSubtle)
                    Text(
                        text = "DISCLAIMER: This terminal application delivers quantitative financial analytics for computational capacity. Outputs are simulated model estimates and do not constitute an offer, executable order or regulated banking advice.",
                        style = MaterialTheme.typography.labelSmall,
                        color = RbTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            containerColor = RbSurface,
            shape = RoundedCornerShape(4.dp)
        )
    }

    // Modal: Command Result Information
    activeCommandInfo?.let { info ->
        AlertDialog(
            onDismissRequest = { activeCommandInfo = null },
            confirmButton = {
                TextButton(onClick = { activeCommandInfo = null }) {
                    Text(text = "CLOSE", color = RbAccentBlue, fontFamily = FontFamily.Monospace)
                }
            },
            title = {
                Text(
                    text = info.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = RbTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            },
            text = {
                Text(
                    text = info.content,
                    style = MaterialTheme.typography.bodySmall,
                    color = RbTextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            },
            containerColor = RbSurface,
            shape = RoundedCornerShape(4.dp)
        )
    }

    // Modal: Command Error Feedback
    activeCommandError?.let { err ->
        AlertDialog(
            onDismissRequest = { activeCommandError = null },
            confirmButton = {
                TextButton(onClick = { activeCommandError = null }) {
                    Text(text = "OK", color = RbAccentBlue, fontFamily = FontFamily.Monospace)
                }
            },
            title = {
                Text(
                    text = "COMMAND ERROR",
                    style = MaterialTheme.typography.titleMedium,
                    color = RbNegativeRed,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            },
            text = {
                Column {
                    Text(text = err.message, style = MaterialTheme.typography.bodySmall, color = RbTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Suggested syntax:", style = MaterialTheme.typography.labelSmall, color = RbTextMuted, fontFamily = FontFamily.Monospace)
                    err.suggestions.forEach { sug ->
                        Text(text = "• $sug", style = MaterialTheme.typography.labelSmall, color = RbAccentCyan, fontFamily = FontFamily.Monospace)
                    }
                }
            },
            containerColor = RbSurface,
            shape = RoundedCornerShape(4.dp)
        )
    }
}
