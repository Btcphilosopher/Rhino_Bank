package com.example.core.model

/**
 * Portfolio aggregate risk measures.
 */
data class PortfolioRiskMetrics(
    val grossNotionalEur: Double,
    val netNotionalEur: Double,
    val totalMarketValueEur: Double,
    val var95DailyEur: Double,
    val var99DailyEur: Double,
    val expectedShortfall99Eur: Double,
    // Factor sensitivities (delta)
    val dvComputePrice1PctEur: Double,   // Sensitivity to 1% move in spot/forward compute price
    val dvPowerPrice10EurMwh: Double,     // Sensitivity to +€10/MWh power shock
    val dvUtilization1PctEur: Double,     // Sensitivity to 1% utilization variation
    val dvRates100BpsEur: Double,         // Sensitivity to 100 bps rate hike
    // Concentration
    val topRegionExposurePercent: Pair<DeliveryRegion, Double>,
    val topHardwareExposurePercent: Pair<HardwareClass, Double>
)

/**
 * Institutional stress testing scenario definition & valuation.
 */
data class StressScenario(
    val id: String,
    val name: String,
    val description: String,
    val severityLevel: String, // "Moderate" or "Severe" or "Extreme"
    val computePriceShockPercent: Double,
    val powerPriceShockPercent: Double,
    val utilizationShockPercentPoints: Double,
    val interestRateShockBps: Double,
    val outageCapacityShockPercent: Double,
    val counterpartyDefaultHaircutPercent: Double,
    // Evaluated P&L and liquidity impacts
    val portfolioPnlImpactEur: Double,
    val pnlImpactPercent: Double,
    val dscrPostStress: Double,
    val liquidityBufferDrainEur: Double,
    val riskCommentary: String
)
