package com.example.core.engine

import com.example.core.model.*
import kotlin.math.max
import kotlin.math.pow

/**
 * Data-center infrastructure finance and cash flow securitisation engine.
 */
object InfrastructureEngine {

    fun evaluateInfrastructure(project: InfrastructureProject): Pair<InfrastructureFinancialMetrics, CashFlowWaterfall> {
        val totalPowerLoadMw = project.itLoadCapacityMw * project.facilityPue
        val hoursInYear = 8760.0

        // Annual electricity in MWh
        val annualPowerConsumptionMwh = totalPowerLoadMw * hoursInYear
        val annualElectricityCostEur = annualPowerConsumptionMwh * project.electricityTariffEurMwh
        val annualElectricityCostMillions = annualElectricityCostEur / 1_000_000.0

        // Operational capacity hours
        val totalCapacityHours = project.acceleratorCount * hoursInYear
        val effectiveUtil = project.assumedUtilizationPercent / 100.0
        val billableHours = totalCapacityHours * 0.999 * effectiveUtil

        val annualGrossRevenueEur = billableHours * project.targetComputePriceEurPerHour
        val annualGrossRevenueMillions = annualGrossRevenueEur / 1_000_000.0

        // Non-power operational expenses: maintenance, staffing, campus connectivity (~3.5% of Capex/yr)
        val fixedOpexMillions = project.totalCapexMillionsEur * 0.038
        val annualOperatingCostMillions = annualElectricityCostMillions + fixedOpexMillions
        val annualEbitdaMillions = annualGrossRevenueMillions - annualOperatingCostMillions

        // Debt service calculation
        val debtPrincipalMillions = project.totalCapexMillionsEur * (project.debtRatioPercent / 100.0)
        val r = project.debtInterestRatePercent / 100.0
        val n = project.debtTenorYears.toDouble()

        val annualDebtServiceMillions: Double = if (r > 0.0 && debtPrincipalMillions > 0.0) {
            val annuityFactor = (r * (1.0 + r).pow(n)) / ((1.0 + r).pow(n) - 1.0)
            debtPrincipalMillions * annuityFactor
        } else {
            debtPrincipalMillions / max(1.0, n)
        }

        val dscr = if (annualDebtServiceMillions > 0.001) {
            annualEbitdaMillions / annualDebtServiceMillions
        } else {
            99.0
        }

        // Breakeven compute price
        val requiredRevenueForBreakevenMillions = annualOperatingCostMillions + annualDebtServiceMillions
        val breakevenPrice = (requiredRevenueForBreakevenMillions * 1_000_000.0) / max(1.0, billableHours)

        // Breakeven utilization at target price
        val revenuePerHourAt100Util = totalCapacityHours * 0.999 * project.targetComputePriceEurPerHour / 1_000_000.0
        val breakevenUtil = (requiredRevenueForBreakevenMillions / max(0.01, revenuePerHourAt100Util)) * 100.0

        // NPV and IRR calculation over useful life
        val life = project.usefulEconomicLifeYears
        val discountRate = 0.085 // 8.5% hurdle
        var npvMillions = -project.totalCapexMillionsEur
        val cashFlows = mutableListOf<Double>()
        cashFlows.add(-project.totalCapexMillionsEur)

        for (year in 1..life) {
            val cf = annualEbitdaMillions - annualDebtServiceMillions
            cashFlows.add(cf)
            npvMillions += cf / (1.0 + discountRate).pow(year)
        }

        // Project IRR approximation
        var irr = calculateIrr(cashFlows)

        // Payback period
        var cumulative = -project.totalCapexMillionsEur
        var paybackYears = life.toDouble()
        for (year in 1..life) {
            cumulative += annualEbitdaMillions
            if (cumulative >= 0.0) {
                paybackYears = year - (cumulative / annualEbitdaMillions)
                break
            }
        }

        val metrics = InfrastructureFinancialMetrics(
            totalPowerLoadMw = totalPowerLoadMw,
            annualPowerConsumptionMwh = annualPowerConsumptionMwh,
            annualElectricityCostMillionsEur = annualElectricityCostMillions,
            annualGrossRevenueMillionsEur = annualGrossRevenueMillions,
            annualOperatingCostMillionsEur = annualOperatingCostMillions,
            annualEbitdaMillionsEur = annualEbitdaMillions,
            annualDebtServiceMillionsEur = annualDebtServiceMillions,
            debtServiceCoverageRatio = dscr,
            breakevenComputePriceEurPerHour = breakevenPrice,
            breakevenUtilizationPercent = breakevenUtil.coerceIn(0.0, 100.0),
            projectNpvMillionsEur = npvMillions,
            projectIrrPercent = irr * 100.0,
            paybackPeriodYears = paybackYears.coerceIn(0.5, life.toDouble())
        )

        // Cash Flow Waterfall simulation
        val waterfall = evaluateWaterfall(annualEbitdaMillions, debtPrincipalMillions, r)

        return Pair(metrics, waterfall)
    }

    private fun evaluateWaterfall(
        availableEbitdaMillions: Double,
        seniorDebtPrincipalMillions: Double,
        seniorRate: Double
    ): CashFlowWaterfall {
        val availableCash = max(0.0, availableEbitdaMillions)

        // Senior tranche (70% of total debt)
        val seniorTargetInterest = (seniorDebtPrincipalMillions * 0.70) * seniorRate
        val seniorTargetPrincipal = (seniorDebtPrincipalMillions * 0.70) / 5.0
        val seniorTotalTarget = seniorTargetInterest + seniorTargetPrincipal
        val seniorAllocated = availableCash.coerceAtMost(seniorTotalTarget)
        val seniorCoverage = if (seniorTotalTarget > 0) seniorAllocated / seniorTotalTarget else 1.0

        val remainingAfterSenior = max(0.0, availableCash - seniorAllocated)

        // Mezzanine tranche (30% of total debt, higher coupon)
        val mezzRate = seniorRate + 0.045
        val mezzTargetInterest = (seniorDebtPrincipalMillions * 0.30) * mezzRate
        val mezzTargetPrincipal = (seniorDebtPrincipalMillions * 0.30) / 7.0
        val mezzTotalTarget = mezzTargetInterest + mezzTargetPrincipal
        val mezzAllocated = remainingAfterSenior.coerceAtMost(mezzTotalTarget)
        val mezzCoverage = if (mezzTotalTarget > 0) mezzAllocated / mezzTotalTarget else 1.0

        val remainingAfterMezz = max(0.0, remainingAfterSenior - mezzAllocated)

        // Reserve account funding (5% of cash)
        val reserveAllocation = remainingAfterMezz * 0.10
        val equityResidual = max(0.0, remainingAfterMezz - reserveAllocation)

        val seniorTranche = WaterfallTranche(
            name = "Tranche A (Senior Secured)",
            seniorityRank = 1,
            principalTargetMillionsEur = seniorDebtPrincipalMillions * 0.70,
            couponRatePercent = seniorRate * 100.0,
            allocatedInterestMillionsEur = seniorTargetInterest.coerceAtMost(seniorAllocated),
            allocatedPrincipalMillionsEur = (seniorAllocated - seniorTargetInterest).coerceAtLeast(0.0),
            coverageMultiple = seniorCoverage,
            status = if (seniorCoverage >= 1.0) "Fully Covered" else "Shortfall"
        )

        val mezzTranche = WaterfallTranche(
            name = "Tranche B (Mezzanine Subordinated)",
            seniorityRank = 2,
            principalTargetMillionsEur = seniorDebtPrincipalMillions * 0.30,
            couponRatePercent = mezzRate * 100.0,
            allocatedInterestMillionsEur = mezzTargetInterest.coerceAtMost(mezzAllocated),
            allocatedPrincipalMillionsEur = (mezzAllocated - mezzTargetInterest).coerceAtLeast(0.0),
            coverageMultiple = mezzCoverage,
            status = if (mezzCoverage >= 1.0) "Fully Covered" else "Shortfall"
        )

        return CashFlowWaterfall(
            availableOperatingCashMillionsEur = availableCash,
            seniorTranche = seniorTranche,
            mezzanineTranche = mezzTranche,
            equityResidualMillionsEur = equityResidual,
            reserveAccountFundingMillionsEur = reserveAllocation
        )
    }

    private fun calculateIrr(cashFlows: List<Double>): Double {
        var rate = 0.12
        for (iter in 0..40) {
            var npv = 0.0
            var dNpv = 0.0
            for (t in cashFlows.indices) {
                val cf = cashFlows[t]
                val denom = (1.0 + rate).pow(t)
                npv += cf / denom
                if (t > 0) {
                    dNpv -= t * cf / (1.0 + rate).pow(t + 1)
                }
            }
            if (kotlin.math.abs(npv) < 1e-5 || kotlin.math.abs(dNpv) < 1e-7) break
            rate -= npv / dNpv
            if (rate <= -0.99) rate = -0.90
        }
        return rate.coerceIn(-0.50, 1.00)
    }
}
