package com.example.core.model

import java.time.Instant

/**
 * Forward curve delivery tenors.
 */
enum class ForwardTenor(val code: String, val daysToExpiry: Int, val label: String) {
    SPOT("SPOT", 0, "Spot (T+0)"),
    ONE_WEEK("1W", 7, "1 Week"),
    ONE_MONTH("1M", 30, "1 Month"),
    THREE_MONTH("3M", 90, "3 Months"),
    SIX_MONTH("6M", 180, "6 Months"),
    TWELVE_MONTH("12M", 365, "12 Months"),
    TWENTY_FOUR_MONTH("24M", 730, "24 Months")
}

/**
 * Evaluated point along the compute forward term structure.
 */
data class ForwardPoint(
    val tenor: ForwardTenor,
    val forwardPriceEur: Double,
    val spotSpreadEur: Double,
    val spotSpreadBps: Double,
    val annualizedSlopePercent: Double,
    val powerComponentEur: Double,
    val capitalRecoveryComponentEur: Double,
    val riskPremiumEur: Double,
    val confidenceLowerEur: Double,
    val confidenceUpperEur: Double
)

/**
 * Comprehensive term structure forward curve for a specific hardware & region.
 */
data class ComputeForwardCurve(
    val ticker: String,
    val hardwareClass: HardwareClass,
    val region: DeliveryRegion,
    val spotPriceEur: Double,
    val points: List<ForwardPoint>,
    val curveStructure: String, // "Contango" vs "Backwardation" vs "Mixed"
    val timestamp: Instant = Instant.now()
)

/**
 * Regional supply and demand balance for compute capacity.
 */
data class RegionalSupplyDemand(
    val region: DeliveryRegion,
    val installedAccelerators: Int,
    val operationalAccelerators: Int,
    val contractuallyReserved: Int,
    val activeUtilized: Int,
    val unallocatedAvailable: Int,
    val plannedAdditions30d: Int,
    val currentUtilizationRate: Double,
    val averagePowerCostEurMwh: Double,
    val carbonFreeEnergySharePercent: Double
)
