package com.example.core.engine

import com.example.core.model.*
import kotlin.math.exp
import kotlin.math.max

/**
 * Forward curve term structure construction engine.
 * Calibrates spot compute capacity against technological depreciation,
 * energy forward expectations, fleet expansion, and delivery risk premiums.
 */
object ForwardCurveEngine {

    fun constructCurve(
        instrument: ComputeInstrument,
        powerForwardAdjustmentPercent: Double = 0.0,
        technologicalDeflationAnnualPercent: Double = -14.0 // E.g. next-gen chips decrease old chip value
    ): ComputeForwardCurve {
        val spotPrice = instrument.referenceSpotPriceEur
        val region = instrument.region
        val hardware = instrument.hardwareClass

        val points = ForwardTenor.values().map { tenor ->
            val days = tenor.daysToExpiry
            val years = days / 365.25

            // Forward power component based on regional electricity expectations
            val basePowerPerHr = (hardware.tdpKw * region.avgPue * (region.avgPowerPriceEurMwh / 1000.0))
            // Seasonal / forward shift in energy prices
            val powerShift = 1.0 + (powerForwardAdjustmentPercent / 100.0) * (days / 180.0).coerceIn(-1.0, 1.0)
            val fwdPower = basePowerPerHr * powerShift

            // Technological obsolescence drift: old hardware becomes cheaper per hour as Blackwell / next-gen ramps
            val techDiscount = exp((technologicalDeflationAnnualPercent / 100.0) * years)

            // Term delivery risk premium (institutional certainty premium for forward lock-in)
            val termPremium = if (days > 0) 0.06 * (days / 365.0) else 0.0

            // Base capital recovery component discounted by tech evolution
            val baseCapitalComp = max(0.50, (spotPrice - basePowerPerHr))
            val fwdCapitalComp = baseCapitalComp * techDiscount

            val forwardPrice = max(fwdPower + 0.20, fwdPower + fwdCapitalComp + termPremium)
            val spreadEur = forwardPrice - spotPrice
            val spreadBps = if (spotPrice > 0) (spreadEur / spotPrice) * 10000.0 else 0.0
            val annualizedSlope = if (years > 0) (spreadEur / spotPrice) / years * 100.0 else 0.0

            // 95% Confidence band from historical spot volatility (~35% vol)
            val sigma = 0.35
            val stdDev = spotPrice * sigma * kotlin.math.sqrt(max(0.01, years))
            val lowerBand = max(0.40, forwardPrice - 1.96 * stdDev * 0.4)
            val upperBand = forwardPrice + 1.96 * stdDev * 0.4

            ForwardPoint(
                tenor = tenor,
                forwardPriceEur = forwardPrice,
                spotSpreadEur = spreadEur,
                spotSpreadBps = spreadBps,
                annualizedSlopePercent = annualizedSlope,
                powerComponentEur = fwdPower,
                capitalRecoveryComponentEur = fwdCapitalComp,
                riskPremiumEur = termPremium,
                confidenceLowerEur = lowerBand,
                confidenceUpperEur = upperBand
            )
        }

        // Determine curve structure:
        val oneYearPoint = points.find { it.tenor == ForwardTenor.TWELVE_MONTH }?.forwardPriceEur ?: spotPrice
        val structure = when {
            oneYearPoint > spotPrice + 0.08 -> "Contango (Forward Premium)"
            oneYearPoint < spotPrice - 0.08 -> "Backwardation (Near-term Scarcity)"
            else -> "Flat / Balanced Term Structure"
        }

        return ComputeForwardCurve(
            ticker = instrument.ticker,
            hardwareClass = hardware,
            region = region,
            spotPriceEur = spotPrice,
            points = points,
            curveStructure = structure
        )
    }
}
