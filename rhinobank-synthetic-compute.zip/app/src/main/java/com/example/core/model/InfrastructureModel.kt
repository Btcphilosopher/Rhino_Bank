package com.example.core.model

/**
 * Data-center infrastructure financial model.
 */
data class InfrastructureProject(
    val projectId: String,
    val facilityName: String,
    val region: DeliveryRegion,
    val itLoadCapacityMw: Double,
    val facilityPue: Double,
    val acceleratorCount: Int,
    val hardwareClass: HardwareClass,
    val totalCapexMillionsEur: Double,
    val debtRatioPercent: Double,
    val debtInterestRatePercent: Double,
    val debtTenorYears: Int,
    val electricityTariffEurMwh: Double,
    val targetComputePriceEurPerHour: Double,
    val assumedUtilizationPercent: Double,
    val usefulEconomicLifeYears: Int = 4
)

/**
 * Evaluated financial metrics for an infrastructure facility.
 */
data class InfrastructureFinancialMetrics(
    val totalPowerLoadMw: Double,
    val annualPowerConsumptionMwh: Double,
    val annualElectricityCostMillionsEur: Double,
    val annualGrossRevenueMillionsEur: Double,
    val annualOperatingCostMillionsEur: Double,
    val annualEbitdaMillionsEur: Double,
    val annualDebtServiceMillionsEur: Double,
    val debtServiceCoverageRatio: Double, // DSCR
    val breakevenComputePriceEurPerHour: Double,
    val breakevenUtilizationPercent: Double,
    val projectNpvMillionsEur: Double,
    val projectIrrPercent: Double,
    val paybackPeriodYears: Double
)

/**
 * Tranche of cash flow securitisation waterfall.
 */
data class WaterfallTranche(
    val name: String,
    val seniorityRank: Int,
    val principalTargetMillionsEur: Double,
    val couponRatePercent: Double,
    val allocatedInterestMillionsEur: Double,
    val allocatedPrincipalMillionsEur: Double,
    val coverageMultiple: Double,
    val status: String // "Fully Covered", "Shortfall", "Distressed"
)

/**
 * Multi-tranche cash flow waterfall outcome.
 */
data class CashFlowWaterfall(
    val availableOperatingCashMillionsEur: Double,
    val seniorTranche: WaterfallTranche,
    val mezzanineTranche: WaterfallTranche,
    val equityResidualMillionsEur: Double,
    val reserveAccountFundingMillionsEur: Double
)
