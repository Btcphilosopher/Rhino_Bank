package com.example.core.engine

/**
 * Institutional Terminal Command Parser.
 * Safely parses and routes institutional commands within the RhinoBank RB-SC terminal environment.
 */
object CommandParser {

    sealed class CommandResult {
        data class NavigateWorkspace(
            val workspaceIndex: Int,
            val message: String,
            val targetTicker: String? = null,
            val contextData: String? = null
        ) : CommandResult()

        data class Information(
            val title: String,
            val content: String,
            val isSuccess: Boolean = true
        ) : CommandResult()

        data class Error(
            val message: String,
            val suggestions: List<String>
        ) : CommandResult()
    }

    val availableSuggestions = listOf(
        "MARKET GPU LONDON",
        "MARKET GPU FRANKFURT",
        "PRICE RB-GPU-H100-1H-LON",
        "CURVE COMPUTE GPU",
        "FORWARD GPU 30D",
        "RISK PORTFOLIO",
        "STRESS ENERGY +20",
        "STRESS SCEN-02",
        "INFRA DATA-CENTRE",
        "SWAP PRICER",
        "OPTION BLACK76",
        "REPORT COMPUTE-EXPOSURE",
        "REPORT MARKET-SUMMARY",
        "HELP"
    )

    fun parse(input: String): CommandResult {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return CommandResult.Error(
                message = "Command cannot be empty.",
                suggestions = availableSuggestions.take(4)
            )
        }

        val tokens = trimmed.split("\\s+".toRegex())
        val verb = tokens[0].uppercase()

        return when (verb) {
            "HELP" -> {
                CommandResult.Information(
                    title = "RB-SC COMMAND TERMINAL REFERENCE",
                    content = """
                        Supported Commands:
                        • MARKET [GPU|CPU] [LONDON|FRANKFURT|PARIS|AMSTERDAM|DUBLIN|STOCKHOLM]
                        • PRICE [TICKER] (e.g. PRICE RB-GPU-H100-1H-LON)
                        • CURVE COMPUTE [GPU|A100|B200]
                        • FORWARD [GPU|A100] [30D|90D|180D|365D]
                        • SYNTHETIC [SWAP|OPTION|FORWARD|RESERVATION]
                        • INFRA [DATA-CENTRE|FINANCE|WATERFALL]
                        • RISK [PORTFOLIO|SENSITIVITIES]
                        • STRESS [SCEN-01..09 | ENERGY +20 | DEMAND -20]
                        • REPORT [COMPUTE-EXPOSURE | MARKET-SUMMARY | WATERFALL]
                    """.trimIndent()
                )
            }

            "MARKET" -> {
                val region = if (tokens.size > 2) tokens[2].uppercase() else null
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 0,
                    message = "Routing to Market Overview" + (if (region != null) " [$region]" else ""),
                    contextData = region
                )
            }

            "PRICE" -> {
                val ticker = if (tokens.size > 1) tokens[1].uppercase() else "RB-GPU-H100-1H-LON"
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 1,
                    message = "Loaded Fundamental Cost Pricer for $ticker",
                    targetTicker = ticker
                )
            }

            "CURVE" -> {
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 2,
                    message = "Routing to Compute Forward Term Structure Curves",
                    targetTicker = if (tokens.size > 2) tokens[2] else "H100"
                )
            }

            "FORWARD" -> {
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 2,
                    message = "Loaded Forward Delivery Analysis",
                    contextData = if (tokens.size > 2) tokens[2] else "30D"
                )
            }

            "SYNTHETIC", "SWAP", "OPTION" -> {
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 3,
                    message = "Routing to Synthetic Instruments & Derivatives Workspace"
                )
            }

            "INFRA", "DATACENTRE", "DATA-CENTRE" -> {
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 4,
                    message = "Routing to Data-Centre Infrastructure Finance & Cash Flow Waterfall"
                )
            }

            "RISK" -> {
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 5,
                    message = "Routing to Portfolio Quantitative Risk & Factor Sensitivities"
                )
            }

            "STRESS" -> {
                val scenarioId = if (tokens.size > 1) tokens[1].uppercase() else "SCEN-02"
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 5,
                    message = "Loaded Stress Testing Suite [$scenarioId]",
                    contextData = scenarioId
                )
            }

            "REPORT" -> {
                val reportType = if (tokens.size > 1) tokens[1].uppercase() else "ALL"
                CommandResult.NavigateWorkspace(
                    workspaceIndex = 6,
                    message = "Generating Institutional Report [$reportType]",
                    contextData = reportType
                )
            }

            else -> {
                val matches = availableSuggestions.filter { it.contains(verb, ignoreCase = true) }
                CommandResult.Error(
                    message = "Unrecognised command '$verb'. Type 'HELP' to inspect command syntax.",
                    suggestions = if (matches.isNotEmpty()) matches else availableSuggestions.take(4)
                )
            }
        }
    }
}
