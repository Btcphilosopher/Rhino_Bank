package com.example.core.engine

import kotlin.math.*

/**
 * Institutional Black-76 valuation engine for options on forward contracts.
 * Adheres to standard derivatives pricing conventions with accurate normal CDF and analytical Greeks.
 */
object Black76Engine {

    private const val INV_SQRT_2PI = 0.3989422804014327

    /**
     * Standard normal probability density function N'(x).
     */
    fun normalPdf(x: Double): Double {
        return INV_SQRT_2PI * exp(-0.5 * x * x)
    }

    /**
     * High-precision Abramowitz & Stegun (7.1.26 / 26.2.17) approximation for cumulative standard normal distribution N(x).
     * Absolute error < 7.5e-8 everywhere.
     */
    fun normalCdf(x: Double): Double {
        if (x < -10.0) return 0.0
        if (x > 10.0) return 1.0

        val absX = abs(x)
        val p = 0.2316419
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429

        val t = 1.0 / (1.0 + p * absX)
        val poly = t * (b1 + t * (b2 + t * (b3 + t * (b4 + t * b5))))
        val nPrime = normalPdf(absX)
        val cdf = 1.0 - nPrime * poly

        return if (x >= 0.0) cdf else 1.0 - cdf
    }

    data class OptionResult(
        val priceEur: Double,
        val intrinsicValueEur: Double,
        val timeValueEur: Double,
        val delta: Double,
        val gamma: Double,
        val vega: Double,
        val thetaPerDay: Double,
        val discountFactor: Double,
        val d1: Double,
        val d2: Double
    )

    /**
     * Price a European option on a compute forward contract using Black-76.
     *
     * @param isCall True for Call, False for Put
     * @param forwardPrice Current forward reference price F (€/acc-hr)
     * @param strike Strike price K (€/acc-hr)
     * @param timeToExpiryYears Time to expiry T in years
     * @param volatility Annualized volatility sigma (e.g. 0.45 for 45%)
     * @param riskFreeRate Annualized risk-free discount rate r (e.g. 0.035 for 3.5%)
     */
    fun calculateOption(
        isCall: Boolean,
        forwardPrice: Double,
        strike: Double,
        timeToExpiryYears: Double,
        volatility: Double,
        riskFreeRate: Double
    ): OptionResult {
        val f = max(0.0001, forwardPrice)
        val k = max(0.0001, strike)
        val t = max(0.00001, timeToExpiryYears)
        val vol = max(0.001, volatility)
        val r = riskFreeRate

        val discountFactor = exp(-r * t)
        val sqrtT = sqrt(t)
        val d1 = (ln(f / k) + 0.5 * vol * vol * t) / (vol * sqrtT)
        val d2 = d1 - vol * sqrtT

        val nd1 = normalCdf(d1)
        val nd2 = normalCdf(d2)
        val nMinusD1 = normalCdf(-d1)
        val nMinusD2 = normalCdf(-d2)
        val nPrimeD1 = normalPdf(d1)

        val price: Double
        val delta: Double
        val intrinsic: Double

        if (isCall) {
            price = discountFactor * (f * nd1 - k * nd2)
            delta = discountFactor * nd1
            intrinsic = max(0.0, f - k) * discountFactor
        } else {
            price = discountFactor * (k * nMinusD2 - f * nMinusD1)
            delta = -discountFactor * nMinusD1
            intrinsic = max(0.0, k - f) * discountFactor
        }

        val clampedPrice = max(0.0, price)
        val timeVal = max(0.0, clampedPrice - intrinsic)
        val gamma = (discountFactor * nPrimeD1) / (f * vol * sqrtT)
        val vega = f * discountFactor * nPrimeD1 * sqrtT

        // Theta calculation
        val thetaYearly: Double
        if (isCall) {
            thetaYearly = -(f * discountFactor * nPrimeD1 * vol) / (2.0 * sqrtT) -
                    r * discountFactor * (f * nd1 - k * nd2)
        } else {
            thetaYearly = -(f * discountFactor * nPrimeD1 * vol) / (2.0 * sqrtT) +
                    r * discountFactor * (k * nMinusD2 - f * nMinusD1)
        }
        val thetaPerDay = thetaYearly / 365.0

        return OptionResult(
            priceEur = clampedPrice,
            intrinsicValueEur = intrinsic,
            timeValueEur = timeVal,
            delta = delta,
            gamma = gamma,
            vega = vega,
            thetaPerDay = thetaPerDay,
            discountFactor = discountFactor,
            d1 = d1,
            d2 = d2
        )
    }
}
