package com.example.core.engine

import kotlin.math.max
import kotlin.math.pow

/**
 * Fundamental bottom-up quantitative pricing engine for compute capacity.
 * Decomposes hardware amortisation, thermodynamic cooling, power tariffs, and networking overhead.
 */
object PricingEngine {

    data class CostModelInputs(
        val hardwareCapexEur: Double = 32000.0,       // Unit purchase price (e.g. H100 SXM5)
        val usefulLifeMonths: Int = 36,               // Economic lifespan
        val residualValuePercent: Double = 10.0,      // Terminal salvage value %
        val annualCostOfCapitalPercent: Double = 7.5, // WACC / Financing hurdle
        val powerConsumptionKw: Double = 0.70,        // TDP + board draw
        val pueFacility: Double = 1.25,               // Power Usage Effectiveness
        val electricityTariffEurMwh: Double = 118.0,  // Regional power cost
        val facilityAndCoolingFixedEurMonth: Double = 45.0, // Colocation space & overhead
        val networkInterconnectEurMonth: Double = 25.0,     // High-speed InfiniBand/transit
        val operationsStaffingEurMonth: Double = 18.0,      // Maintenance & support staff
        val uptimeAvailabilityPercent: Double = 99.95,      // SLA uptime
        val capacityUtilizationPercent: Double = 82.0,      // Expected workload factor
        val targetOperatingMarginPercent: Double = 20.0     // Target EBIT margin
    )

    data class CostBreakdown(
        val powerCostPerHourEur: Double,
        val capitalRecoveryPerHourEur: Double,
        val straightLineDepreciationPerHourEur: Double,
        val financingCarryPerHourEur: Double,
        val facilityCoolingPerHourEur: Double,
        val networkPerHourEur: Double,
        val operationsPerHourEur: Double,
        val marginalOperatingCostPerHourEur: Double,
        val fullyAllocatedCostPerHourEur: Double,
        val recommendedPriceCostPlusEur: Double,
        val monthlyBillableHours: Double,
        val breakevenUtilizationAtRefPricePercent: Double
    )

    /**
     * Compute bottom-up cost breakdown and pricing recommendations.
     */
    fun evaluateCostModel(inputs: CostModelInputs, marketRefPriceEur: Double = 2.40): CostBreakdown {
        val totalHoursInMonth = 730.0
        val effectiveAvailability = inputs.uptimeAvailabilityPercent / 100.0
        val effectiveUtil = max(0.01, inputs.capacityUtilizationPercent / 100.0)

        // Billable hours per accelerator per month
        val billableHours = totalHoursInMonth * effectiveAvailability * effectiveUtil

        // Thermodynamic power calculation:
        // kW * PUE gives total facility load per accelerator.
        // Multiply by (EUR / MWh) / 1000 to get EUR per active hour.
        val totalKwPerGpu = inputs.powerConsumptionKw * inputs.pueFacility
        val powerCostPerHour = (totalKwPerGpu * (inputs.electricityTariffEurMwh / 1000.0))

        // Capital recovery via monthly annuity factor
        val monthlyRate = (inputs.annualCostOfCapitalPercent / 100.0) / 12.0
        val n = inputs.usefulLifeMonths.toDouble()
        val depreciableBase = inputs.hardwareCapexEur * (1.0 - inputs.residualValuePercent / 100.0)

        val capitalRecoveryMonthly: Double = if (monthlyRate > 0.0) {
            val factor = (monthlyRate * (1.0 + monthlyRate).pow(n)) / ((1.0 + monthlyRate).pow(n) - 1.0)
            depreciableBase * factor
        } else {
            depreciableBase / n
        }

        val straightLineMonthly = depreciableBase / n
        val financingMonthly = capitalRecoveryMonthly - straightLineMonthly

        val capitalRecoveryPerHour = capitalRecoveryMonthly / billableHours
        val straightLinePerHour = straightLineMonthly / billableHours
        val financingPerHour = financingMonthly / billableHours

        val facilityPerHour = inputs.facilityAndCoolingFixedEurMonth / billableHours
        val networkPerHour = inputs.networkInterconnectEurMonth / billableHours
        val operationsPerHour = inputs.operationsStaffingEurMonth / billableHours

        // Marginal operating cost = short-run variable cost to run an additional accelerator-hour
        val marginalOperatingCost = powerCostPerHour + (networkPerHour * 0.3) + (operationsPerHour * 0.2)

        // Fully allocated cost per billable hour
        val fullyAllocatedCost = capitalRecoveryPerHour + powerCostPerHour +
                facilityPerHour + networkPerHour + operationsPerHour

        // Cost-plus price
        val marginFactor = 1.0 + (inputs.targetOperatingMarginPercent / 100.0)
        val recommendedPrice = fullyAllocatedCost * marginFactor

        // Breakeven utilization at reference price
        val fixedMonthlyCost = capitalRecoveryMonthly + inputs.facilityAndCoolingFixedEurMonth +
                inputs.networkInterconnectEurMonth + inputs.operationsStaffingEurMonth
        val marginOverPower = marketRefPriceEur - powerCostPerHour
        val breakevenHoursNeeded = if (marginOverPower > 0.001) fixedMonthlyCost / marginOverPower else 9999.0
        val breakevenUtil = (breakevenHoursNeeded / (totalHoursInMonth * effectiveAvailability)) * 100.0

        return CostBreakdown(
            powerCostPerHourEur = powerCostPerHour,
            capitalRecoveryPerHourEur = capitalRecoveryPerHour,
            straightLineDepreciationPerHourEur = straightLinePerHour,
            financingCarryPerHourEur = financingPerHour,
            facilityCoolingPerHourEur = facilityPerHour,
            networkPerHourEur = networkPerHour,
            operationsPerHourEur = operationsPerHour,
            marginalOperatingCostPerHourEur = marginalOperatingCost,
            fullyAllocatedCostPerHourEur = fullyAllocatedCost,
            recommendedPriceCostPlusEur = recommendedPrice,
            monthlyBillableHours = billableHours,
            breakevenUtilizationAtRefPricePercent = breakevenUtil.coerceIn(0.0, 100.0)
        )
    }
}
