package com.example.core.data

import com.example.core.engine.Black76Engine
import com.example.core.engine.ForwardCurveEngine
import com.example.core.engine.InfrastructureEngine
import com.example.core.engine.PricingEngine
import com.example.core.engine.RiskEngine
import com.example.core.model.*
import java.time.Instant
import java.time.LocalDate

/**
 * Deterministic Calibrated Repository for RhinoBank Synthetic Compute terminal.
 * Provides realistic, internally consistent quantitative compute capacity market data.
 */
object SampleRepository {

    val datasetTimestamp: Instant = Instant.parse("2026-10-09T22:00:00Z")
    const val environmentLabel = "SIMULATION: CALIBRATED DETERMINISTIC ENGINE"
    const val currencyCode = "EUR (€)"

    val defaultInstruments: List<ComputeInstrument> = listOf(
        ComputeInstrument(
            ticker = "RB-GPU-H100-1H-LON",
            name = "H100 SXM5 80GB 1-Hour London Delivery",
            hardwareClass = HardwareClass.H100_SXM5,
            region = DeliveryRegion.LONDON,
            unit = ComputeCapacityUnit.ACCELERATOR_HOUR,
            benchmarkScore = 1979.0,
            slaAvailabilityPercent = 99.95,
            referenceSpotPriceEur = 2.45,
            oneMonthForwardPriceEur = 2.58,
            estimatedMarginalCostEur = 1.74,
            installedFleetSize = 8192,
            activeFleetUtilization = 81.4
        ),
        ComputeInstrument(
            ticker = "RB-GPU-H100-1H-FRA",
            name = "H100 SXM5 80GB 1-Hour Frankfurt Delivery",
            hardwareClass = HardwareClass.H100_SXM5,
            region = DeliveryRegion.FRANKFURT,
            unit = ComputeCapacityUnit.ACCELERATOR_HOUR,
            benchmarkScore = 1979.0,
            slaAvailabilityPercent = 99.95,
            referenceSpotPriceEur = 2.38,
            oneMonthForwardPriceEur = 2.50,
            estimatedMarginalCostEur = 1.68,
            installedFleetSize = 12288,
            activeFleetUtilization = 79.2
        ),
        ComputeInstrument(
            ticker = "RB-GPU-H100-1H-STO",
            name = "H100 SXM5 80GB 1-Hour Stockholm Hydro",
            hardwareClass = HardwareClass.H100_SXM5,
            region = DeliveryRegion.STOCKHOLM,
            unit = ComputeCapacityUnit.ACCELERATOR_HOUR,
            benchmarkScore = 1979.0,
            slaAvailabilityPercent = 99.90,
            referenceSpotPriceEur = 2.15,
            oneMonthForwardPriceEur = 2.24,
            estimatedMarginalCostEur = 1.48,
            installedFleetSize = 6144,
            activeFleetUtilization = 88.0
        ),
        ComputeInstrument(
            ticker = "RB-GPU-A100-1H-AMS",
            name = "A100 SXM4 80GB 1-Hour Amsterdam Delivery",
            hardwareClass = HardwareClass.A100_SXM4,
            region = DeliveryRegion.AMSTERDAM,
            unit = ComputeCapacityUnit.ACCELERATOR_HOUR,
            benchmarkScore = 624.0,
            slaAvailabilityPercent = 99.90,
            referenceSpotPriceEur = 1.15,
            oneMonthForwardPriceEur = 1.12,
            estimatedMarginalCostEur = 0.88,
            installedFleetSize = 16384,
            activeFleetUtilization = 72.5
        ),
        ComputeInstrument(
            ticker = "RB-GPU-B200-1H-IAD",
            name = "B200 NVL 192GB 1-Hour Virginia Delivery",
            hardwareClass = HardwareClass.B200_NVL,
            region = DeliveryRegion.NORTHERN_VIRGINIA,
            unit = ComputeCapacityUnit.ACCELERATOR_HOUR,
            benchmarkScore = 4500.0,
            slaAvailabilityPercent = 99.98,
            referenceSpotPriceEur = 4.20,
            oneMonthForwardPriceEur = 4.45,
            estimatedMarginalCostEur = 2.85,
            installedFleetSize = 4096,
            activeFleetUtilization = 94.6
        ),
        ComputeInstrument(
            ticker = "RB-CPU-EPYC-1H-PAR",
            name = "EPYC 9654 96-Core 1-Hour Paris Delivery",
            hardwareClass = HardwareClass.EPYC_9654,
            region = DeliveryRegion.PARIS,
            unit = ComputeCapacityUnit.CORE_HOUR,
            benchmarkScore = 110.0,
            slaAvailabilityPercent = 99.99,
            referenceSpotPriceEur = 0.42,
            oneMonthForwardPriceEur = 0.43,
            estimatedMarginalCostEur = 0.28,
            installedFleetSize = 32768,
            activeFleetUtilization = 66.8
        )
    )

    val regionalSupplyDemands: List<RegionalSupplyDemand> = listOf(
        RegionalSupplyDemand(
            region = DeliveryRegion.FRANKFURT,
            installedAccelerators = 24500,
            operationalAccelerators = 23800,
            contractuallyReserved = 16200,
            activeUtilized = 18850,
            unallocatedAvailable = 4950,
            plannedAdditions30d = 3200,
            currentUtilizationRate = 79.2,
            averagePowerCostEurMwh = 118.0,
            carbonFreeEnergySharePercent = 64.0
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.LONDON,
            installedAccelerators = 18200,
            operationalAccelerators = 17800,
            contractuallyReserved = 12900,
            activeUtilized = 14490,
            unallocatedAvailable = 3310,
            plannedAdditions30d = 2048,
            currentUtilizationRate = 81.4,
            averagePowerCostEurMwh = 132.0,
            carbonFreeEnergySharePercent = 52.0
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.STOCKHOLM,
            installedAccelerators = 14000,
            operationalAccelerators = 13850,
            contractuallyReserved = 10800,
            activeUtilized = 12190,
            unallocatedAvailable = 1660,
            plannedAdditions30d = 4096,
            currentUtilizationRate = 88.0,
            averagePowerCostEurMwh = 62.0,
            carbonFreeEnergySharePercent = 98.0
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.AMSTERDAM,
            installedAccelerators = 21000,
            operationalAccelerators = 20400,
            contractuallyReserved = 13500,
            activeUtilized = 15500,
            unallocatedAvailable = 4900,
            plannedAdditions30d = 1024,
            currentUtilizationRate = 76.0,
            averagePowerCostEurMwh = 112.0,
            carbonFreeEnergySharePercent = 58.0
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.PARIS,
            installedAccelerators = 16400,
            operationalAccelerators = 16100,
            contractuallyReserved = 11200,
            activeUtilized = 12200,
            unallocatedAvailable = 3900,
            plannedAdditions30d = 2048,
            currentUtilizationRate = 75.8,
            averagePowerCostEurMwh = 98.0,
            carbonFreeEnergySharePercent = 92.0 // Nuclear base
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.DUBLIN,
            installedAccelerators = 28000,
            operationalAccelerators = 27100,
            contractuallyReserved = 21000,
            activeUtilized = 22760,
            unallocatedAvailable = 4340,
            plannedAdditions30d = 1500,
            currentUtilizationRate = 84.0,
            averagePowerCostEurMwh = 125.0,
            carbonFreeEnergySharePercent = 46.0
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.SINGAPORE,
            installedAccelerators = 11500,
            operationalAccelerators = 11200,
            contractuallyReserved = 9100,
            activeUtilized = 10200,
            unallocatedAvailable = 1000,
            plannedAdditions30d = 512,
            currentUtilizationRate = 91.1,
            averagePowerCostEurMwh = 165.0,
            carbonFreeEnergySharePercent = 12.0
        ),
        RegionalSupplyDemand(
            region = DeliveryRegion.NORTHERN_VIRGINIA,
            installedAccelerators = 68000,
            operationalAccelerators = 66500,
            contractuallyReserved = 54000,
            activeUtilized = 59850,
            unallocatedAvailable = 6650,
            plannedAdditions30d = 8192,
            currentUtilizationRate = 90.0,
            averagePowerCostEurMwh = 88.0,
            carbonFreeEnergySharePercent = 44.0
        )
    )

    val sampleSwaps: List<ComputeSwap> = listOf(
        ComputeSwap(
            swapId = "SWAP-2026-0881",
            instrumentTicker = "RB-GPU-H100-1H-LON",
            counterparty = "Cortex Quant Fund UK",
            notionalHours = 250_000,
            fixedRateEur = 2.42,
            currentFloatingIndexEur = 2.45,
            startDate = LocalDate.of(2026, 9, 1),
            maturityDate = LocalDate.of(2027, 2, 28),
            settlementFrequency = "Monthly",
            isPayerFixed = true, // We pay fixed, receive floating -> Profiting as floating rises
            netMtmValueEur = 7_500.0,
            nextSettlementCashflowEur = 7_500.0
        ),
        ComputeSwap(
            swapId = "SWAP-2026-0914",
            instrumentTicker = "RB-GPU-H100-1H-FRA",
            counterparty = "Bavaria Auto Research GmbH",
            notionalHours = 500_000,
            fixedRateEur = 2.52,
            currentFloatingIndexEur = 2.38,
            startDate = LocalDate.of(2026, 8, 1),
            maturityDate = LocalDate.of(2027, 7, 31),
            settlementFrequency = "Monthly",
            isPayerFixed = false, // We receive fixed, pay floating -> Profiting as floating is lower
            netMtmValueEur = 70_000.0,
            nextSettlementCashflowEur = 70_000.0
        )
    )

    val sampleForwards: List<ComputeForwardContract> = listOf(
        ComputeForwardContract(
            contractId = "FWD-2026-H100-90D",
            instrumentTicker = "RB-GPU-H100-1H-LON",
            counterparty = "Apex LLM Labs",
            notionalHours = 180_000,
            strikePriceEur = 2.50,
            currentForwardPriceEur = 2.58,
            deliveryTenor = ForwardTenor.THREE_MONTH,
            deliveryDate = LocalDate.of(2027, 1, 15),
            isLong = true,
            unrealizedPnlEur = 14_400.0,
            collateralHeldEur = 45_000.0
        ),
        ComputeForwardContract(
            contractId = "FWD-2026-A100-180D",
            instrumentTicker = "RB-GPU-A100-1H-AMS",
            counterparty = "Nordic BioInformatics",
            notionalHours = 320_000,
            strikePriceEur = 1.18,
            currentForwardPriceEur = 1.10,
            deliveryTenor = ForwardTenor.SIX_MONTH,
            deliveryDate = LocalDate.of(2027, 4, 15),
            isLong = false, // Short hedge
            unrealizedPnlEur = 25_600.0,
            collateralHeldEur = 38_000.0
        )
    )

    val sampleReservations: List<CapacityReservation> = listOf(
        CapacityReservation(
            reservationId = "RES-CLUST-4096",
            clusterSpecification = "Dedicated 512x H100 Pod (InfiniBand NDR 400G)",
            committedAccelerators = 512,
            reservationFeeEurPerHour = 0.45,
            executionUsageFeeEurPerHour = 1.95,
            guaranteedAvailabilitySla = 99.95,
            takeOrPayMinimumPercent = 80.0,
            currentUtilisationPercent = 88.5,
            monthlyTotalCommitmentEur = 896_563.0,
            penaltyCreditIfOutageEur = 18_500.0
        )
    )

    val sampleOptions: List<ComputeOption> by lazy {
        val fwdPrice = 2.55
        val strike = 2.50
        val t = 0.25 // 3 months
        val vol = 0.42
        val r = 0.035

        val callRes = Black76Engine.calculateOption(
            isCall = true,
            forwardPrice = fwdPrice,
            strike = strike,
            timeToExpiryYears = t,
            volatility = vol,
            riskFreeRate = r
        )

        val putRes = Black76Engine.calculateOption(
            isCall = false,
            forwardPrice = fwdPrice,
            strike = 2.40,
            timeToExpiryYears = t,
            volatility = vol,
            riskFreeRate = r
        )

        listOf(
            ComputeOption(
                optionId = "OPT-CALL-H100-Q1",
                underlyingTicker = "RB-GPU-H100-1H-LON",
                isCall = true,
                forwardPriceEur = fwdPrice,
                strikePriceEur = strike,
                timeToExpiryYears = t,
                volatilitySigma = vol,
                riskFreeRate = r,
                notionalHours = 200_000,
                theoreticalPremiumEur = callRes.priceEur,
                intrinsicValueEur = callRes.intrinsicValueEur,
                timeValueEur = callRes.timeValueEur,
                delta = callRes.delta,
                gamma = callRes.gamma,
                vega = callRes.vega,
                theta = callRes.thetaPerDay
            ),
            ComputeOption(
                optionId = "OPT-PUT-H100-FLOOR",
                underlyingTicker = "RB-GPU-H100-1H-LON",
                isCall = false,
                forwardPriceEur = fwdPrice,
                strikePriceEur = 2.40,
                timeToExpiryYears = t,
                volatilitySigma = vol,
                riskFreeRate = r,
                notionalHours = 150_000,
                theoreticalPremiumEur = putRes.priceEur,
                intrinsicValueEur = putRes.intrinsicValueEur,
                timeValueEur = putRes.timeValueEur,
                delta = putRes.delta,
                gamma = putRes.gamma,
                vega = putRes.vega,
                theta = putRes.thetaPerDay
            )
        )
    }

    val sampleNotes: List<ComputeLinkedNote> = listOf(
        ComputeLinkedNote(
            noteId = "CLN-RHINO-2028-A",
            title = "RhinoBank 3Y Compute Benchmark Yield-Enhanced Note",
            notionalPrincipalEur = 10_000_000.0,
            maturityYears = 3.0,
            benchmarkIndexTicker = "RB-GPU-INDEX",
            participationRatePercent = 85.0,
            floorCouponPercent = 3.25,
            capReturnPercent = 14.50,
            currentValuationEur = 10_420_000.0,
            simulatedExpectedYieldPercent = 7.15
        )
    )

    val sampleBasis: List<BasisInstrument> = listOf(
        BasisInstrument(
            basisId = "BASIS-LON-FRA",
            legA = "RB-GPU-H100-1H-LON",
            legB = "RB-GPU-H100-1H-FRA",
            legAPriceEur = 2.45,
            legBPriceEur = 2.38,
            spreadEur = 0.07,
            spreadBps = 294.0,
            historicalMeanSpreadEur = 0.05,
            zScore = 1.15
        ),
        BasisInstrument(
            basisId = "BASIS-H100-A100",
            legA = "RB-GPU-H100-1H-LON",
            legB = "RB-GPU-A100-1H-AMS",
            legAPriceEur = 2.45,
            legBPriceEur = 1.15,
            spreadEur = 1.30,
            spreadBps = 11304.0,
            historicalMeanSpreadEur = 1.25,
            zScore = 0.62
        )
    )

    val sampleInfrastructureProject: InfrastructureProject = InfrastructureProject(
        projectId = "INFRA-RHO-PARIS-01",
        facilityName = "Rhino Data Campus Paris-Sud (Titan-1)",
        region = DeliveryRegion.PARIS,
        itLoadCapacityMw = 14.5,
        facilityPue = 1.22,
        acceleratorCount = 12288,
        hardwareClass = HardwareClass.H100_SXM5,
        totalCapexMillionsEur = 425.0,
        debtRatioPercent = 65.0,
        debtInterestRatePercent = 6.25,
        debtTenorYears = 5,
        electricityTariffEurMwh = 98.0,
        targetComputePriceEurPerHour = 2.35,
        assumedUtilizationPercent = 82.0,
        usefulEconomicLifeYears = 4
    )
}
