package com.example.core.model

import java.time.LocalDate

/**
 * Synthetic Compute Price Swap (Fixed-vs-Floating).
 */
data class ComputeSwap(
    val swapId: String,
    val instrumentTicker: String,
    val counterparty: String,
    val notionalHours: Long,
    val fixedRateEur: Double,
    val currentFloatingIndexEur: Double,
    val startDate: LocalDate,
    val maturityDate: LocalDate,
    val settlementFrequency: String, // "Monthly" or "Quarterly"
    val isPayerFixed: Boolean,
    val netMtmValueEur: Double,
    val nextSettlementCashflowEur: Double
)

/**
 * Standard Compute Forward Contract.
 */
data class ComputeForwardContract(
    val contractId: String,
    val instrumentTicker: String,
    val counterparty: String,
    val notionalHours: Long,
    val strikePriceEur: Double,
    val currentForwardPriceEur: Double,
    val deliveryTenor: ForwardTenor,
    val deliveryDate: LocalDate,
    val isLong: Boolean,
    val unrealizedPnlEur: Double,
    val collateralHeldEur: Double
)

/**
 * Capacity Reservation Contract (Take-or-pay structured capacity).
 */
data class CapacityReservation(
    val reservationId: String,
    val clusterSpecification: String,
    val committedAccelerators: Int,
    val reservationFeeEurPerHour: Double,
    val executionUsageFeeEurPerHour: Double,
    val guaranteedAvailabilitySla: Double,
    val takeOrPayMinimumPercent: Double,
    val currentUtilisationPercent: Double,
    val monthlyTotalCommitmentEur: Double,
    val penaltyCreditIfOutageEur: Double
)

/**
 * European Option on Compute Forward (Black-76 Valuation).
 */
data class ComputeOption(
    val optionId: String,
    val underlyingTicker: String,
    val isCall: Boolean,
    val forwardPriceEur: Double,
    val strikePriceEur: Double,
    val timeToExpiryYears: Double,
    val volatilitySigma: Double,
    val riskFreeRate: Double,
    val notionalHours: Long,
    val theoreticalPremiumEur: Double,
    val intrinsicValueEur: Double,
    val timeValueEur: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double
)

/**
 * Structured Compute-Linked Note.
 */
data class ComputeLinkedNote(
    val noteId: String,
    val title: String,
    val notionalPrincipalEur: Double,
    val maturityYears: Double,
    val benchmarkIndexTicker: String,
    val participationRatePercent: Double,
    val floorCouponPercent: Double,
    val capReturnPercent: Double,
    val currentValuationEur: Double,
    val simulatedExpectedYieldPercent: Double
)

/**
 * Cross-Region or Cross-Hardware Basis Instrument.
 */
data class BasisInstrument(
    val basisId: String,
    val legA: String,
    val legB: String,
    val legAPriceEur: Double,
    val legBPriceEur: Double,
    val spreadEur: Double,
    val spreadBps: Double,
    val historicalMeanSpreadEur: Double,
    val zScore: Double
)
