package com.example.core.model

import java.time.Instant

/**
 * Standard hardware classification for institutional compute capacity contracts.
 */
enum class HardwareClass(
    val code: String,
    val displayName: String,
    val architecture: String,
    val memoryGb: Int,
    val tdpKw: Double,
    val referenceCapexEur: Double,
    val benchmarkTflopsFp16: Double
) {
    H100_SXM5(
        code = "H100",
        displayName = "NVIDIA H100 SXM5",
        architecture = "Hopper 4nm",
        memoryGb = 80,
        tdpKw = 0.70,
        referenceCapexEur = 32000.0,
        benchmarkTflopsFp16 = 1979.0
    ),
    A100_SXM4(
        code = "A100",
        displayName = "NVIDIA A100 SXM4",
        architecture = "Ampere 7nm",
        memoryGb = 80,
        tdpKw = 0.40,
        referenceCapexEur = 14500.0,
        benchmarkTflopsFp16 = 624.0
    ),
    B200_NVL(
        code = "B200",
        displayName = "NVIDIA B200 NVL",
        architecture = "Blackwell 4NP",
        memoryGb = 192,
        tdpKw = 1.00,
        referenceCapexEur = 46000.0,
        benchmarkTflopsFp16 = 4500.0
    ),
    L40S_PCIE(
        code = "L40S",
        displayName = "NVIDIA L40S PCIe",
        architecture = "Ada Lovelace",
        memoryGb = 48,
        tdpKw = 0.35,
        referenceCapexEur = 9200.0,
        benchmarkTflopsFp16 = 733.0
    ),
    EPYC_9654(
        code = "EPYC96",
        displayName = "AMD EPYC 9654 96-Core",
        architecture = "Zen 4 x86-64",
        memoryGb = 384,
        tdpKw = 0.40,
        referenceCapexEur = 11800.0,
        benchmarkTflopsFp16 = 110.0
    )
}

/**
 * Standardised regions for compute delivery and infrastructure financing.
 */
enum class DeliveryRegion(
    val code: String,
    val cityName: String,
    val avgPowerPriceEurMwh: Double,
    val avgPue: Double,
    val carbonIntensityGCoe: Int,
    val connectivityRank: String
) {
    FRANKFURT("FRA", "Frankfurt am Main", 118.0, 1.22, 340, "Tier 1 Hub"),
    LONDON("LON", "London Docklands", 132.0, 1.25, 210, "Tier 1 Hub"),
    AMSTERDAM("AMS", "Amsterdam Schiphol", 112.0, 1.18, 290, "Tier 1 Hub"),
    PARIS("PAR", "Paris Île-de-France", 98.0, 1.24, 65, "Tier 1 Hub"),
    DUBLIN("DUB", "Dublin Grange Castle", 125.0, 1.20, 280, "Tier 1 Hub"),
    STOCKHOLM("STO", "Stockholm Kista", 62.0, 1.12, 25, "Hydro Low-Cost"),
    SINGAPORE("SIN", "Singapore Jurong", 165.0, 1.34, 420, "APAC Hub"),
    NORTHERN_VIRGINIA("IAD", "Northern Virginia", 88.0, 1.20, 310, "US East Mega")
}

/**
 * Unit of compute capacity contract settlement.
 */
enum class ComputeCapacityUnit(val symbol: String, val description: String) {
    ACCELERATOR_HOUR("acc-hr", "1 Hour usable accelerator time"),
    CORE_HOUR("core-hr", "1 Hour usable x86-64 core time"),
    CLUSTER_DAY_8X("8x-day", "1 Day dedicated 8-GPU interconnect pod"),
    CLUSTER_MONTH_64X("64x-mo", "1 Month dedicated 64-GPU training fabric")
}

/**
 * Contract data provenance and verification state.
 */
enum class DataFeedState(val label: String) {
    LIVE_VERIFIED("LIVE VERIFIED"),
    SIMULATED("SIMULATED"),
    CALIBRATED("CALIBRATED"),
    MODELLED("MODELLED"),
    STALE("STALE / CACHED")
}

/**
 * Concrete compute delivery contract definition.
 */
data class ComputeInstrument(
    val ticker: String,
    val name: String,
    val hardwareClass: HardwareClass,
    val region: DeliveryRegion,
    val unit: ComputeCapacityUnit,
    val benchmarkScore: Double,
    val slaAvailabilityPercent: Double = 99.95,
    val deliveryWindowHours: Int = 1,
    val referenceSpotPriceEur: Double,
    val oneMonthForwardPriceEur: Double,
    val estimatedMarginalCostEur: Double,
    val installedFleetSize: Int,
    val activeFleetUtilization: Double,
    val feedState: DataFeedState = DataFeedState.CALIBRATED,
    val lastUpdated: Instant = Instant.now()
)
