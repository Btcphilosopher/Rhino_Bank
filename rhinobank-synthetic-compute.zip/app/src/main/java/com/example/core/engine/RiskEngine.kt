package com.example.core.engine

import com.example.core.model.*
import kotlin.math.sqrt

/**
 * Institutional risk and scenario stress-testing engine.
 */
object RiskEngine {

    fun calculatePortfolioRisk(
        swaps: List<ComputeSwap>,
        forwards: List<ComputeForwardContract>,
        options: List<ComputeOption>,
        reservations: List<CapacityReservation>,
        spotPriceEur: Double = 2.40
    ): PortfolioRiskMetrics {
        var grossNotional = 0.0
        var netNotional = 0.0
        var totalMarketValue = 0.0

        // Swaps
        swaps.forEach { s ->
            val notionalValue = s.notionalHours * s.fixedRateEur
            grossNotional += notionalValue
            netNotional += if (s.isPayerFixed) notionalValue else -notionalValue
            totalMarketValue += s.netMtmValueEur
        }

        // Forwards
        forwards.forEach { f ->
            val notionalValue = f.notionalHours * f.strikePriceEur
            grossNotional += notionalValue
            netNotional += if (f.isLong) notionalValue else -notionalValue
            totalMarketValue += f.unrealizedPnlEur
        }

        // Options
        options.forEach { o ->
            val notionalValue = o.notionalHours * o.strikePriceEur
            grossNotional += notionalValue
            val optVal = o.theoreticalPremiumEur * o.notionalHours
            totalMarketValue += optVal
            val deltaNotional = o.delta * o.notionalHours * o.forwardPriceEur
            netNotional += if (o.isCall) deltaNotional else -deltaNotional
        }

        // Reservations
        reservations.forEach { r ->
            grossNotional += r.monthlyTotalCommitmentEur
            totalMarketValue += (r.currentUtilisationPercent / 100.0) * r.monthlyTotalCommitmentEur
        }

        // Parametric VaR assuming annualized volatility of 38%
        val dailyVol = 0.38 / sqrt(252.0)
        val portfolioStdDev = kotlin.math.abs(netNotional) * dailyVol
        val var95 = 1.645 * portfolioStdDev
        val var99 = 2.326 * portfolioStdDev
        val expectedShortfall99 = 2.665 * portfolioStdDev // CVaR for standard normal

        // Sensitivities
        val dvCompute = netNotional * 0.01 // 1% change in compute price
        val dvPower = -28_400.0            // Direct exposure to +€10/MWh power increase across active workloads
        val dvUtil = 42_500.0              // Exposure to +1% utilization increase
        val dvRates = -38_900.0            // Exposure to +100 bps rate increase

        return PortfolioRiskMetrics(
            grossNotionalEur = grossNotional,
            netNotionalEur = netNotional,
            totalMarketValueEur = totalMarketValue,
            var95DailyEur = var95,
            var99DailyEur = var99,
            expectedShortfall99Eur = expectedShortfall99,
            dvComputePrice1PctEur = dvCompute,
            dvPowerPrice10EurMwh = dvPower,
            dvUtilization1PctEur = dvUtil,
            dvRates100BpsEur = dvRates,
            topRegionExposurePercent = Pair(DeliveryRegion.FRANKFURT, 42.5),
            topHardwareExposurePercent = Pair(HardwareClass.H100_SXM5, 68.0)
        )
    }

    /**
     * Calibrate the 9 required institutional stress scenarios against portfolio positions.
     */
    fun evaluateStressScenarios(portfolioRisk: PortfolioRiskMetrics, baseDscr: Double = 2.15): List<StressScenario> {
        val net = portfolioRisk.netNotionalEur
        val gross = portfolioRisk.grossNotionalEur

        return listOf(
            StressScenario(
                id = "SCEN-01",
                name = "AI Demand Surge",
                description = "Rapid enterprise LLM adoption drives acute near-term GPU shortage; spot prices jump and utilization saturates.",
                severityLevel = "Moderate",
                computePriceShockPercent = 35.0,
                powerPriceShockPercent = 5.0,
                utilizationShockPercentPoints = 14.0,
                interestRateShockBps = 0.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 0.0,
                portfolioPnlImpactEur = net * 0.35 + 42_500.0 * 14.0,
                pnlImpactPercent = 18.4,
                dscrPostStress = baseDscr * 1.45,
                liquidityBufferDrainEur = 0.0,
                riskCommentary = "Long capacity positions and reservations generate windfall margins; unhedged short forwards face margin calls."
            ),
            StressScenario(
                id = "SCEN-02",
                name = "European Power Shock",
                description = "Geopolitical gas disruption drives NordPool and German peak power prices higher, squeezing host margins.",
                severityLevel = "Severe",
                computePriceShockPercent = 8.0,
                powerPriceShockPercent = 65.0,
                utilizationShockPercentPoints = -3.0,
                interestRateShockBps = 50.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 0.0,
                portfolioPnlImpactEur = -kotlin.math.abs(portfolioRisk.dvPowerPrice10EurMwh * 6.5),
                pnlImpactPercent = -9.2,
                dscrPostStress = (baseDscr * 0.72).coerceAtLeast(0.85),
                liquidityBufferDrainEur = 480_000.0,
                riskCommentary = "Fixed-rate compute sales suffer severe margin compression due to unhedged floating electricity tariff pass-through."
            ),
            StressScenario(
                id = "SCEN-03",
                name = "Hardware Obsolescence Wave",
                description = "Next-gen architecture (B200/Rubin) scales faster than expected; older H100 and A100 forward curves reprice sharply downward.",
                severityLevel = "Severe",
                computePriceShockPercent = -28.0,
                powerPriceShockPercent = 0.0,
                utilizationShockPercentPoints = -8.0,
                interestRateShockBps = 0.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 0.0,
                portfolioPnlImpactEur = net * -0.28 - 250_000.0,
                pnlImpactPercent = -14.8,
                dscrPostStress = (baseDscr * 0.78).coerceAtLeast(0.95),
                liquidityBufferDrainEur = 620_000.0,
                riskCommentary = "Terminal equipment value deteriorates; refinancing requires equity cure or accelerated debt amortisation."
            ),
            StressScenario(
                id = "SCEN-04",
                name = "Macro Demand Contraction",
                description = "Tech venture funding cools; AI enterprise proof-of-concepts decrease; uncommitted cluster capacity sits idle.",
                severityLevel = "Severe",
                computePriceShockPercent = -20.0,
                powerPriceShockPercent = -10.0,
                utilizationShockPercentPoints = -22.0,
                interestRateShockBps = -50.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 5.0,
                portfolioPnlImpactEur = net * -0.20 - (42_500.0 * 22.0),
                pnlImpactPercent = -19.5,
                dscrPostStress = (baseDscr * 0.65).coerceAtLeast(0.75),
                liquidityBufferDrainEur = 890_000.0,
                riskCommentary = "High operating leverage causes fixed colocation and financing overheads to erode cash buffers."
            ),
            StressScenario(
                id = "SCEN-05",
                name = "Capital Markets Funding Shock",
                description = "Central banks raise policy rates or credit spreads widen by +300 bps; floating rate debt service escalates.",
                severityLevel = "Moderate",
                computePriceShockPercent = 0.0,
                powerPriceShockPercent = 0.0,
                utilizationShockPercentPoints = -2.0,
                interestRateShockBps = 300.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 0.0,
                portfolioPnlImpactEur = portfolioRisk.dvRates100BpsEur * 3.0,
                pnlImpactPercent = -6.1,
                dscrPostStress = (baseDscr * 0.76).coerceAtLeast(1.05),
                liquidityBufferDrainEur = 340_000.0,
                riskCommentary = "Senior debt service rises significantly; triggers Mezzanine tranche cash flow diversion covenants."
            ),
            StressScenario(
                id = "SCEN-06",
                name = "Campus Infrastructure Outage",
                description = "Substation transformer fault knocks 30% of cluster offline for 72 hours; SLA non-delivery penalties trigger.",
                severityLevel = "Moderate",
                computePriceShockPercent = 12.0,
                powerPriceShockPercent = 0.0,
                utilizationShockPercentPoints = -30.0,
                interestRateShockBps = 0.0,
                outageCapacityShockPercent = 30.0,
                counterpartyDefaultHaircutPercent = 0.0,
                portfolioPnlImpactEur = -540_000.0,
                pnlImpactPercent = -5.8,
                dscrPostStress = (baseDscr * 0.88),
                liquidityBufferDrainEur = 540_000.0,
                riskCommentary = "Contractual availability credit penalties offset peak spot market spikes."
            ),
            StressScenario(
                id = "SCEN-07",
                name = "Tier-1 Offtaker Default",
                description = "Major AI anchor tenant defaults on long-term capacity reservation contract; receivables write-off.",
                severityLevel = "Severe",
                computePriceShockPercent = -10.0,
                powerPriceShockPercent = 0.0,
                utilizationShockPercentPoints = -18.0,
                interestRateShockBps = 0.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 100.0,
                portfolioPnlImpactEur = -(gross * 0.18),
                pnlImpactPercent = -16.2,
                dscrPostStress = (baseDscr * 0.62).coerceAtLeast(0.70),
                liquidityBufferDrainEur = 1_150_000.0,
                riskCommentary = "Requires emergency remarketing of unassigned cluster capacity into spot liquidity pools."
            ),
            StressScenario(
                id = "SCEN-08",
                name = "Regional Grid Basis Divergence",
                description = "London-Frankfurt transmission bottleneck creates €50/MWh spread in power and €0.40/acc-hr compute divergence.",
                severityLevel = "Moderate",
                computePriceShockPercent = 15.0,
                powerPriceShockPercent = 30.0,
                utilizationShockPercentPoints = 0.0,
                interestRateShockBps = 0.0,
                outageCapacityShockPercent = 0.0,
                counterpartyDefaultHaircutPercent = 0.0,
                portfolioPnlImpactEur = -210_000.0,
                pnlImpactPercent = -3.4,
                dscrPostStress = baseDscr * 0.94,
                liquidityBufferDrainEur = 180_000.0,
                riskCommentary = "Cross-region calendar and location basis spreads widen beyond historical 3-sigma bands."
            ),
            StressScenario(
                id = "SCEN-09",
                name = "Combined Systemic Crisis",
                description = "Compound event: concurrent demand contraction (-25%), power surge (+50%), and rating agency downgrade (+250 bps).",
                severityLevel = "Extreme",
                computePriceShockPercent = -25.0,
                powerPriceShockPercent = 50.0,
                utilizationShockPercentPoints = -25.0,
                interestRateShockBps = 250.0,
                outageCapacityShockPercent = 10.0,
                counterpartyDefaultHaircutPercent = 15.0,
                portfolioPnlImpactEur = -(gross * 0.32),
                pnlImpactPercent = -31.5,
                dscrPostStress = 0.68,
                liquidityBufferDrainEur = 2_450_000.0,
                riskCommentary = "Severe capital distress: DSCR breaches minimum 1.10x threshold; reserve account fully depleted; equity distribution suspended."
            )
        )
    }
}
