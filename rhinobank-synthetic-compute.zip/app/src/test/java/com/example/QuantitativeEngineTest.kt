package com.example

import com.example.core.data.SampleRepository
import com.example.core.engine.*
import com.example.core.model.HardwareClass
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs
import kotlin.math.exp

/**
 * Quantitative validation tests for RhinoBank Synthetic Compute financial engines.
 */
class QuantitativeEngineTest {

    @Test
    fun testNormalCdfAndPdfProperties() {
        val cdf0 = Black76Engine.normalCdf(0.0)
        assertEquals("N(0) must equal 0.5", 0.5, cdf0, 1e-6)

        val cdfNegInf = Black76Engine.normalCdf(-10.0)
        assertTrue("N(-10) must be near 0", cdfNegInf < 1e-6)

        val cdfPosInf = Black76Engine.normalCdf(10.0)
        assertTrue("N(+10) must be near 1", cdfPosInf > 0.999999)

        val pdf0 = Black76Engine.normalPdf(0.0)
        assertEquals("N'(0) must equal 1/sqrt(2pi) approx 0.3989", 0.398942, pdf0, 1e-4)
    }

    @Test
    fun testBlack76PutCallParityOnForwards() {
        // Forward Put-Call Parity: C - P = e^(-rT) * (F - K)
        val f = 2.50
        val k = 2.40
        val t = 0.5
        val vol = 0.35
        val r = 0.04

        val call = Black76Engine.calculateOption(isCall = true, forwardPrice = f, strike = k, timeToExpiryYears = t, volatility = vol, riskFreeRate = r)
        val put = Black76Engine.calculateOption(isCall = false, forwardPrice = f, strike = k, timeToExpiryYears = t, volatility = vol, riskFreeRate = r)

        val disc = exp(-r * t)
        val expectedDifference = disc * (f - k)
        val actualDifference = call.priceEur - put.priceEur

        assertEquals("Forward Put-Call parity must hold", expectedDifference, actualDifference, 1e-4)
    }

    @Test
    fun testOptionSensitivitiesGreeks() {
        val f = 2.50
        val k = 2.50
        val t = 0.25
        val vol = 0.40
        val r = 0.035

        val call = Black76Engine.calculateOption(isCall = true, forwardPrice = f, strike = k, timeToExpiryYears = t, volatility = vol, riskFreeRate = r)
        val put = Black76Engine.calculateOption(isCall = false, forwardPrice = f, strike = k, timeToExpiryYears = t, volatility = vol, riskFreeRate = r)

        // Delta
        assertTrue("Call delta must be positive and <= 1", call.delta in 0.0..1.0)
        assertTrue("Put delta must be negative and >= -1", put.delta in -1.0..0.0)

        // Gamma and Vega must be positive
        assertTrue("Gamma must be strictly positive", call.gamma > 0.0)
        assertTrue("Vega must be strictly positive", call.vega > 0.0)
        assertEquals("Call and Put Gamma must be identical", call.gamma, put.gamma, 1e-6)
        assertEquals("Call and Put Vega must be identical", call.vega, put.vega, 1e-6)
    }

    @Test
    fun testFundamentalCostModelPowerAndUtilization() {
        val baseInputs = PricingEngine.CostModelInputs(
            hardwareCapexEur = 32000.0,
            powerConsumptionKw = 0.70,
            pueFacility = 1.25,
            electricityTariffEurMwh = 100.0,
            capacityUtilizationPercent = 80.0
        )

        val baseEval = PricingEngine.evaluateCostModel(baseInputs)

        // Power cost check: 0.70 kW * 1.25 PUE * 100 EUR / 1000 = 0.0875 EUR/hr
        val expectedPower = 0.70 * 1.25 * (100.0 / 1000.0)
        assertEquals("Thermodynamic power calculation per hour must match kW * PUE * Tariff / 1000", expectedPower, baseEval.powerCostPerHourEur, 1e-6)

        // Higher electricity tariff must strictly increase power expenditure
        val highPowerInputs = baseInputs.copy(electricityTariffEurMwh = 150.0)
        val highPowerEval = PricingEngine.evaluateCostModel(highPowerInputs)
        assertTrue("Higher power tariff must increase power cost", highPowerEval.powerCostPerHourEur > baseEval.powerCostPerHourEur)

        // Lower utilization must strictly increase fully allocated cost per billable hour
        val lowUtilInputs = baseInputs.copy(capacityUtilizationPercent = 50.0)
        val lowUtilEval = PricingEngine.evaluateCostModel(lowUtilInputs)
        assertTrue("Lower utilization must increase fully allocated cost per billable hour", lowUtilEval.fullyAllocatedCostPerHourEur > baseEval.fullyAllocatedCostPerHourEur)

        // Capital recovery must be higher than straight-line depreciation when WACC > 0
        assertTrue("Capital recovery with financing carry must exceed straight-line depreciation", baseEval.capitalRecoveryPerHourEur > baseEval.straightLineDepreciationPerHourEur)
    }

    @Test
    fun testForwardCurveTermStructure() {
        val instrument = SampleRepository.defaultInstruments.first()
        val curve = ForwardCurveEngine.constructCurve(instrument)

        assertEquals("Must generate 7 tenor points", 7, curve.points.size)
        assertEquals("Spot spread at T=0 must be 0", 0.0, curve.points[0].spotSpreadEur, 1e-6)

        // Ensure confidence bounds envelope the forward price
        curve.points.forEach { pt ->
            assertTrue("Upper confidence bound must exceed forward price", pt.confidenceUpperEur >= pt.forwardPriceEur)
            assertTrue("Lower confidence bound must be below forward price", pt.confidenceLowerEur <= pt.forwardPriceEur)
        }
    }

    @Test
    fun testInfrastructureEbitdaAndWaterfallConservation() {
        val project = SampleRepository.sampleInfrastructureProject
        val (metrics, waterfall) = InfrastructureEngine.evaluateInfrastructure(project)

        // EBITDA = Revenue - Opex
        val expectedEbitda = metrics.annualGrossRevenueMillionsEur - metrics.annualOperatingCostMillionsEur
        assertEquals("EBITDA must equal Revenue - Operating Cost", expectedEbitda, metrics.annualEbitdaMillionsEur, 1e-4)

        // DSCR = EBITDA / Debt Service
        val expectedDscr = metrics.annualEbitdaMillionsEur / metrics.annualDebtServiceMillionsEur
        assertEquals("DSCR must equal EBITDA / Debt Service", expectedDscr, metrics.debtServiceCoverageRatio, 1e-4)

        // Cash flow conservation: allocated cash in waterfall cannot exceed available operating cash
        val totalDistributed = waterfall.seniorTranche.allocatedInterestMillionsEur +
                waterfall.seniorTranche.allocatedPrincipalMillionsEur +
                waterfall.mezzanineTranche.allocatedInterestMillionsEur +
                waterfall.mezzanineTranche.allocatedPrincipalMillionsEur +
                waterfall.reserveAccountFundingMillionsEur +
                waterfall.equityResidualMillionsEur

        assertTrue("Waterfall must not distribute more cash than available", totalDistributed <= waterfall.availableOperatingCashMillionsEur + 1e-4)
    }

    @Test
    fun testRiskVaRAndSensitivities() {
        val risk = RiskEngine.calculatePortfolioRisk(
            swaps = SampleRepository.sampleSwaps,
            forwards = SampleRepository.sampleForwards,
            options = SampleRepository.sampleOptions,
            reservations = SampleRepository.sampleReservations
        )

        assertTrue("Gross notional must be >= 0", risk.grossNotionalEur > 0)
        assertTrue("99% VaR must exceed 95% VaR", risk.var99DailyEur > risk.var95DailyEur)
        assertTrue("Expected Shortfall (CVaR) must exceed 99% VaR", risk.expectedShortfall99Eur > risk.var99DailyEur)

        val scenarios = RiskEngine.evaluateStressScenarios(risk)
        assertEquals("Must calibrate all 9 institutional stress scenarios", 9, scenarios.size)
    }

    @Test
    fun testCommandParserRouting() {
        val helpResult = CommandParser.parse("HELP")
        assertTrue("HELP command must return Information", helpResult is CommandParser.CommandResult.Information)

        val marketResult = CommandParser.parse("MARKET GPU LONDON")
        assertTrue("MARKET command must navigate to workspace 0", marketResult is CommandParser.CommandResult.NavigateWorkspace && marketResult.workspaceIndex == 0)

        val priceResult = CommandParser.parse("PRICE RB-GPU-H100-1H-LON")
        assertTrue("PRICE command must navigate to workspace 1 with ticker", priceResult is CommandParser.CommandResult.NavigateWorkspace && priceResult.workspaceIndex == 1)

        val stressResult = CommandParser.parse("STRESS SCEN-02")
        assertTrue("STRESS command must navigate to risk workspace 5", stressResult is CommandParser.CommandResult.NavigateWorkspace && stressResult.workspaceIndex == 5)

        val invalidResult = CommandParser.parse("UNKNOWN_TOKEN_FOOBAR")
        assertTrue("Invalid command must return Error with suggestions", invalidResult is CommandParser.CommandResult.Error && invalidResult.suggestions.isNotEmpty())
    }
}
