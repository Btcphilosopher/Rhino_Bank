# RHINOBANK SYNTHETIC COMPUTE (RB-SC)
**Terminal Identifier:** `RB-SC`  
**Application ID:** `com.rhinobank.syntheticcompute`  
**Parent Brand:** RhinoBank Quantitative Financial Infrastructure

---

## Executive Mission & System Architecture

**RhinoBank Synthetic Compute** is an institutional-grade financial engineering terminal for Android that treats high-performance compute capacity as a measurable, bankable, tradable and risk-managed financial commodity.

Rather than treating compute as an undifferentiated cloud metric, the terminal implements typed contract specifications across hardware architectures, delivery regions, power baselines, thermodynamic cooling overheads, and financial delivery terms.

### Key Terminal Workspaces

1. **Markets (`MARKETS`)**:
   - Spot and forward benchmarks for standardised compute instruments (e.g. `RB-GPU-H100-1H-LON`).
   - Regional supply & demand balance across 8 global hubs (Frankfurt, London, Amsterdam, Paris, Dublin, Stockholm, Singapore, Northern Virginia).
   - Real-time grid power basis (€/MWh) and thermodynamic PUE tracking.

2. **Pricer (`PRICER`)**:
   - Bottom-up fundamental cost decomposition:
     $$C_{\mathrm{unit}} = \frac{C_{\mathrm{hardware}} + C_{\mathrm{power}} + C_{\mathrm{cooling}} + C_{\mathrm{facility}} + C_{\mathrm{network}} + C_{\mathrm{operations}} + C_{\mathrm{financing}} + C_{\mathrm{other}}}{Q_{\mathrm{billable}}}$$
   - Annuity Capital Recovery Factor (CRF) vs straight-line depreciation.
   - Marginal operating cost vs fully allocated cost per billable hour.
   - Breakeven utilization at prevailing market spot prices.

3. **Curves (`CURVES`)**:
   - Compute forward curve term structure across 7 delivery tenors (Spot, 1W, 1M, 3M, 6M, 12M, 24M).
   - High-precision Canvas chart rendering 95% confidence bands and power basis floors.
   - Contango vs backwardation classification driven by technological hardware deflation and seasonal energy expectations.

4. **Synthetic (`SYNTHETIC`)**:
   - Fixed-vs-floating compute price swaps with mark-to-market valuations.
   - Forward delivery contracts with counterparty collateral tracking.
   - Analytical Black-76 European Option pricer with Delta, Gamma, Vega and Theta sensitivities.
   - Take-or-pay capacity reservation contracts with SLA availability credits.
   - Compute-linked structured notes and cross-market basis spreads (London vs Frankfurt, H100 vs A100).

5. **Infrastructure Finance (`INFRA`)**:
   - Multi-megawatt data campus physical load modeling (IT load MW, facility load MW, PUE).
   - Capex underwriting, debt service coverage ratio (DSCR), project IRR, and NPV.
   - Cash flow securitisation waterfall: Tranche A (Senior Secured), Tranche B (Mezzanine), Debt Service Reserve Account (DSRA), and junior equity residual dividends.

6. **Risk & Stress Testing (`RISK`)**:
   - Aggregate gross and net contractual notional exposure.
   - 1-Day 95% and 99% Parametric Value at Risk (VaR) and Expected Shortfall (CVaR).
   - Factor delta sensitivities: $\Delta$ Compute Price, $\Delta$ Power Tariff, $\Delta$ Fleet Utilization, $\Delta$ Interest Rates.
   - 9 Institutional Stress Scenarios:
     1. AI Demand Surge
     2. European Power Shock
     3. Hardware Obsolescence Wave
     4. Macro Demand Contraction
     5. Capital Markets Funding Shock
     6. Campus Infrastructure Outage
     7. Tier-1 Offtaker Default
     8. Regional Grid Basis Divergence
     9. Combined Systemic Crisis

7. **Reports (`REPORTS`)**:
   - Institutional transcripts with complete provenance disclaimers, model versioning, and CSV exports ready for clipboard integration.

---

## Terminal Command Language

The built-in `RB-SC >` terminal command bar accepts structured commands:
- `HELP`: Displays full command syntax manual.
- `MARKET [GPU|CPU] [REGION]`: Quick navigation to regional capacity ledger.
- `PRICE [TICKER]`: Loads fundamental cost breakdown for instrument.
- `CURVE COMPUTE [CLASS]`: Displays forward term structure curves.
- `SYNTHETIC [SWAP|OPTION]`: Opens derivatives and Black-76 pricer.
- `INFRA DATA-CENTRE`: Navigates to campus financing & waterfall analysis.
- `STRESS [SCENARIO_ID]`: Triggers stress test evaluation (e.g. `STRESS SCEN-02`).
- `REPORT [TYPE]`: Generates audit transcript and CSV export.

---

## Provenance & Calibrated Deterministic Engine

The application runs in **CALIBRATED SIMULATION MODE**, powered by a deterministic multi-factor model calibrated to Q4 2026 compute and energy markets. It operates completely offline with no simulated fake network delays, providing immediate analytical recalculation upon parameter adjustments.
