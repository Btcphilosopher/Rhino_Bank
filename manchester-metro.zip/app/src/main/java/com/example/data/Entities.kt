package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ticketType: String,
    val zones: String,
    val price: Double,
    val purchaseTime: Long,
    val expiryTime: Long,
    val qrCodeData: String,
    val status: String // "Active", "Expired", "Not Activated"
)

@Entity(tableName = "favorite_journeys")
data class FavoriteJourney(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val startName: String,
    val endName: String,
    val modes: String, // Comma-separated list of modes: e.g. "Tram,Bus"
    val durationMinutes: Int
)

@Entity(tableName = "recent_searches")
data class RecentSearch(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromName: String,
    val toName: String,
    val timestamp: Long
)

@Entity(tableName = "alerts")
data class Alert(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val route: String,
    val mode: String, // "Tram", "Bus", "Rail"
    val severity: String, // "Severe", "Minor", "Good Service"
    val description: String,
    val timestamp: Long
)

@Entity(tableName = "taxi_bookings")
data class TaxiBooking(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val pickup: String,
    val destination: String,
    val fare: Double,
    val driverName: String,
    val vehicleInfo: String,
    val status: String, // "Requested", "En Route", "Arrived", "Completed"
    val etaMinutes: Int,
    val timestamp: Long
)
