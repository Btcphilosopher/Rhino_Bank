package com.example.data

import kotlinx.coroutines.flow.Flow

class MetroRepository(private val metroDao: MetroDao) {
    // Tickets
    val allTickets: Flow<List<Ticket>> = metroDao.getAllTickets()

    suspend fun insertTicket(ticket: Ticket): Long {
        return metroDao.insertTicket(ticket)
    }

    suspend fun updateTicket(ticket: Ticket) {
        metroDao.updateTicket(ticket)
    }

    // Favorite Journeys
    val allFavorites: Flow<List<FavoriteJourney>> = metroDao.getAllFavorites()

    suspend fun insertFavorite(favorite: FavoriteJourney) {
        metroDao.insertFavorite(favorite)
    }

    suspend fun deleteFavorite(id: Int) {
        metroDao.deleteFavorite(id)
    }

    // Recent Searches
    val recentSearches: Flow<List<RecentSearch>> = metroDao.getRecentSearches()

    suspend fun insertRecentSearch(search: RecentSearch) {
        metroDao.insertRecentSearch(search)
    }

    suspend fun clearRecentSearches() {
        metroDao.clearRecentSearches()
    }

    // Service Alerts
    val allAlerts: Flow<List<Alert>> = metroDao.getAllAlerts()

    suspend fun insertAlert(alert: Alert) {
        metroDao.insertAlert(alert)
    }

    suspend fun deleteAlert(id: Int) {
        metroDao.deleteAlert(id)
    }

    suspend fun clearAllAlerts() {
        metroDao.clearAllAlerts()
    }

    // Taxi Bookings
    val allTaxiBookings: Flow<List<TaxiBooking>> = metroDao.getAllTaxiBookings()

    suspend fun insertTaxiBooking(booking: TaxiBooking): Long {
        return metroDao.insertTaxiBooking(booking)
    }

    suspend fun updateTaxiBooking(booking: TaxiBooking) {
        metroDao.updateTaxiBooking(booking)
    }

    // Setup default data helper (e.g. for service alerts and favorites on first run)
    suspend fun seedInitialDataIfEmpty(currentAlertsCount: Int) {
        if (currentAlertsCount == 0) {
            // Seed alerts
            val initialAlerts = listOf(
                Alert(
                    route = "Metrolink Bury Line",
                    mode = "Tram",
                    severity = "Severe",
                    description = "Major delays due to a signal failure at Radcliffe. Passengers should use bus services 135 or 524.",
                    timestamp = System.currentTimeMillis() - 10 * 60000 // 10m ago
                ),
                Alert(
                    route = "Bee Network 135",
                    mode = "Bus",
                    severity = "Minor",
                    description = "Delays up to 15 minutes due to heavy traffic on Bury New Road near Heaton Park.",
                    timestamp = System.currentTimeMillis() - 30 * 60000 // 30m ago
                ),
                Alert(
                    route = "National Rail (Manchester Piccadilly to Airport)",
                    mode = "Rail",
                    severity = "Good Service",
                    description = "Trains are running normally with minor delays expected on evening services.",
                    timestamp = System.currentTimeMillis() - 2 * 3600000 // 2h ago
                ),
                Alert(
                    route = "Metrolink Airport Line",
                    mode = "Tram",
                    severity = "Minor",
                    description = "Slight delays of 5 minutes due to an earlier medical emergency at Sale Water Park.",
                    timestamp = System.currentTimeMillis() - 40 * 60000
                )
            )
            for (alert in initialAlerts) {
                metroDao.insertAlert(alert)
            }

            // Seed some default favorites
            val initialFavorites = listOf(
                FavoriteJourney(
                    startName = "Manchester Piccadilly",
                    endName = "MediaCityUK",
                    modes = "Tram",
                    durationMinutes = 24
                ),
                FavoriteJourney(
                    startName = "Northern Quarter",
                    endName = "Trafford Centre",
                    modes = "Bus",
                    durationMinutes = 35
                )
            )
            for (fav in initialFavorites) {
                metroDao.insertFavorite(fav)
            }
        }
    }
}
