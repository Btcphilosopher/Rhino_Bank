package com.example.data

import kotlin.math.roundToInt

data class StationInfo(
    val name: String,
    val mode: String, // "Tram", "Rail", "Bus"
    val line: String,
    val hasAccessibility: Boolean,
    val hasParking: Boolean,
    val hasCycleStorage: Boolean,
    val hasToilets: Boolean,
    val hasRetail: Boolean,
    val hasWifi: Boolean,
    val latitude: Double,
    val longitude: Double,
    val nearbyAttractions: List<String>,
    val description: String
)

data class Departure(
    val line: String,
    val destination: String,
    val expectedInMinutes: Int,
    val platform: String,
    val status: String, // "On Time", "Delayed", "Cancelled"
    val occupancy: String // "Low", "Medium", "High"
)

data class JourneyStep(
    val mode: String, // "Walk", "Tram", "Bus", "Rail", "Taxi"
    val lineName: String,
    val from: String,
    val to: String,
    val durationMinutes: Int,
    val details: String
)

data class Journey(
    val modes: List<String>,
    val steps: List<JourneyStep>,
    val totalDurationMinutes: Int,
    val totalPrice: Double,
    val co2SavingKg: Double,
    val isAccessible: Boolean,
    val label: String // "Fastest", "Cheapest", "Fewest Changes", "Least Walking"
)

data class Destination(
    val name: String,
    val category: String, // "Culture", "Shopping", "Sports", "Airport", "Nightlife"
    val description: String,
    val howToGetThere: String,
    val suggestedItinerary: List<String>
)

object StaticData {
    val STATIONS = listOf(
        StationInfo(
            name = "Manchester Piccadilly",
            mode = "Rail",
            line = "Mainline Station",
            hasAccessibility = true,
            hasParking = true,
            hasCycleStorage = true,
            hasToilets = true,
            hasRetail = true,
            hasWifi = true,
            latitude = 53.4774,
            longitude = -2.2312,
            nearbyAttractions = listOf("Northern Quarter", "Canal Street", "Mayfield Depot"),
            description = "The principal railway station in Manchester, connecting the city to London, Birmingham, and the South, as well as local rail and Metrolink connections."
        ),
        StationInfo(
            name = "Manchester Victoria",
            mode = "Rail",
            line = "Mainline & Metrolink",
            hasAccessibility = true,
            hasParking = false,
            hasCycleStorage = true,
            hasToilets = true,
            hasRetail = true,
            hasWifi = true,
            latitude = 53.4873,
            longitude = -2.2423,
            nearbyAttractions = listOf("Manchester Cathedral", "AO Arena", "Printworks"),
            description = "A major northern railway terminus combined with a crucial Metrolink interchange, situated beneath the AO Arena."
        ),
        StationInfo(
            name = "Deansgate-Castlefield",
            mode = "Tram",
            line = "Metrolink (All Lines)",
            hasAccessibility = true,
            hasParking = false,
            hasCycleStorage = true,
            hasToilets = false,
            hasRetail = false,
            hasWifi = false,
            latitude = 53.4746,
            longitude = -2.2514,
            nearbyAttractions = listOf("Science and Industry Museum", "Castlefield Bowl", "Deansgate Locks"),
            description = "A beautiful elevated Metrolink stop featuring glass-clad walls and planters, linking directly with Deansgate railway station."
        ),
        StationInfo(
            name = "St Peter's Square",
            mode = "Tram",
            line = "Metrolink Interchange",
            hasAccessibility = true,
            hasParking = false,
            hasCycleStorage = false,
            hasToilets = false,
            hasRetail = true,
            hasWifi = true,
            latitude = 53.4781,
            longitude = -2.2441,
            nearbyAttractions = listOf("Central Library", "Manchester Town Hall", "Albert Square"),
            description = "The central hub of the Metrolink network, boasting 4 platforms in a spacious urban plaza with dramatic glass canopies."
        ),
        StationInfo(
            name = "MediaCityUK",
            mode = "Tram",
            line = "Metrolink Eccles Line",
            hasAccessibility = true,
            hasParking = true,
            hasCycleStorage = true,
            hasToilets = true,
            hasRetail = true,
            hasWifi = true,
            latitude = 53.4722,
            longitude = -2.2987,
            nearbyAttractions = listOf("BBC North", "ITV Studios", "The Lowry", "Imperial War Museum North"),
            description = "A vibrant waterfront destination that serves as the creative, digital, and media hub of the North, home to BBC and ITV."
        ),
        StationInfo(
            name = "Shudehill Interchange",
            mode = "Bus",
            line = "Bee Network Hub",
            hasAccessibility = true,
            hasParking = true,
            hasCycleStorage = true,
            hasToilets = true,
            hasRetail = true,
            hasWifi = true,
            latitude = 53.4849,
            longitude = -2.2389,
            nearbyAttractions = listOf("Arndale Centre", "Northern Quarter", "National Football Museum"),
            description = "A modern bus station and Metrolink stop on the edge of the Northern Quarter, facilitating local and regional coach services."
        ),
        StationInfo(
            name = "Manchester Airport",
            mode = "Rail",
            line = "Airport Interchange",
            hasAccessibility = true,
            hasParking = true,
            hasCycleStorage = true,
            hasToilets = true,
            hasRetail = true,
            hasWifi = true,
            latitude = 53.3621,
            longitude = -2.2714,
            nearbyAttractions = listOf("Airport Terminal 1, 2, 3", "Runway Visitor Park"),
            description = "A comprehensive transport hub integrating trains, Metrolink trams, and regional buses directly into the airport terminals."
        ),
        StationInfo(
            name = "Etihad Campus",
            mode = "Tram",
            line = "Metrolink Ashton Line",
            hasAccessibility = true,
            hasParking = true,
            hasCycleStorage = true,
            hasToilets = false,
            hasRetail = false,
            hasWifi = false,
            latitude = 53.4831,
            longitude = -2.2003,
            nearbyAttractions = listOf("Etihad Stadium", "Co-op Live Arena", "Manchester Regional Arena"),
            description = "The dedicated transport link for Manchester City's sport complex and the state-of-the-art Co-op Live Arena."
        ),
        StationInfo(
            name = "Old Trafford",
            mode = "Tram",
            line = "Metrolink Altrincham Line",
            hasAccessibility = true,
            hasParking = false,
            hasCycleStorage = true,
            hasToilets = false,
            hasRetail = false,
            hasWifi = false,
            latitude = 53.4566,
            longitude = -2.2858,
            nearbyAttractions = listOf("Old Trafford Football Stadium", "Old Trafford Cricket Ground"),
            description = "A historic station serving Manchester United FC and Lancashire County Cricket Club, bustling with sport history."
        )
    )

    val DESTINATIONS = listOf(
        Destination(
            name = "MediaCityUK",
            category = "Culture",
            description = "Waterfront media destination housing the BBC, ITV, and stunning docks.",
            howToGetThere = "Take the Metrolink Blue Line directly to MediaCityUK or bus 50 from Piccadilly.",
            suggestedItinerary = listOf(
                "Board the Metrolink Blue Line at St Peter's Square",
                "Ride through Salford Quays overlooking the historic canal locks",
                "Alight directly at MediaCityUK station outside BBC Dock House"
            )
        ),
        Destination(
            name = "Northern Quarter",
            category = "Nightlife",
            description = "The creative heart of Manchester, packed with independent bars, music venues, and street art.",
            howToGetThere = "A 5-minute walk from Piccadilly or Victoria, or take buses 112, 118 to Thomas Street.",
            suggestedItinerary = listOf(
                "Walk from Manchester Piccadilly up Newton Street",
                "Explore Afflecks Palace, an iconic multi-story indie bazaar",
                "Grab a brick-fired pizza on Stevenson Square"
            )
        ),
        Destination(
            name = "Etihad Campus",
            category = "Sports",
            description = "Home to Manchester City Football Club and the state-of-the-art Co-op Live Arena.",
            howToGetThere = "Take the Metrolink Ashton Line to Etihad Campus from Piccadilly (10 minutes).",
            suggestedItinerary = listOf(
                "Board the Metrolink Ashton Line at Piccadilly Platform 4",
                "Travel past Holt Town and Velopark",
                "Arrive at Etihad Campus, a 2-minute walk to the Stadium"
            )
        ),
        Destination(
            name = "Old Trafford",
            category = "Sports",
            description = "The legendary 'Theatre of Dreams' home of Manchester United, and the Lancashire Cricket Ground.",
            howToGetThere = "Take the Metrolink Altrincham Line from St Peter's Square directly to Old Trafford.",
            suggestedItinerary = listOf(
                "Take Metrolink Altrincham Line from St Peter's Square",
                "Get off at Old Trafford Metrolink Stop",
                "Walk down Warwick Road past the supporter murals directly to the East Stand"
            )
        ),
        Destination(
            name = "Trafford Centre",
            category = "Shopping",
            description = "A monumental, late-baroque styled shopping and leisure mall with countless dining and retail options.",
            howToGetThere = "Take the Metrolink Trafford Park Line (Red Line) directly to the Trafford Centre.",
            suggestedItinerary = listOf(
                "Board the Red Line Metrolink at Cornbrook",
                "Enjoy the scenic route alongside the Manchester Ship Canal",
                "Alight at Trafford Centre station under the giant glass dome"
            )
        ),
        Destination(
            name = "Manchester Airport",
            category = "Airport",
            description = "The primary international gateway to the North of England, connecting Greater Manchester to the world.",
            howToGetThere = "Direct trains from Piccadilly (15 minutes) or Metrolink Airport Line (45 minutes).",
            suggestedItinerary = listOf(
                "Take the TransPennine Express or Northern Rail direct service from Piccadilly",
                "Arrive directly at the Airport Station interchange",
                "Walk through the Skylink directly to Terminal 1 or 2"
            )
        )
    )

    fun getLiveDepartures(stationName: String): List<Departure> {
        val hash = stationName.hashCode().absoluteValue
        val statusList = listOf("On Time", "On Time", "Delayed 2m", "On Time", "Delayed 5m")
        val occupancyList = listOf("Low", "Medium", "Medium", "High", "Low")
        
        return when {
            stationName.contains("Piccadilly") -> listOf(
                Departure("Airport Express", "Manchester Airport", 4, "Platform 14", "On Time", "Medium"),
                Departure("Metrolink Blue Line", "MediaCityUK", 6, "Platform 1", "On Time", "High"),
                Departure("TransPennine", "Leeds", 9, "Platform 3", "Delayed 4m", "High"),
                Departure("Metrolink Purple Line", "Altrincham", 11, "Platform 2", "On Time", "Low")
            )
            stationName.contains("Victoria") -> listOf(
                Departure("Metrolink Yellow Line", "Bury", 2, "Platform B", "On Time", "Medium"),
                Departure("Northern Rail", "Blackpool North", 5, "Platform 5", "Delayed 3m", "Low"),
                Departure("Metrolink Green Line", "East Didsbury", 7, "Platform C", "On Time", "High"),
                Departure("TransPennine", "Liverpool Lime St", 12, "Platform 3", "On Time", "Medium")
            )
            stationName.contains("MediaCity") -> listOf(
                Departure("Metrolink Blue Line", "Manchester Piccadilly", 3, "Platform 1", "On Time", "Low"),
                Departure("Metrolink Blue Line", "Etihad Campus", 15, "Platform 1", "On Time", "Medium")
            )
            stationName.contains("St Peter") -> listOf(
                Departure("Metrolink Green Line", "Altrincham", 1, "Platform 2", "On Time", "High"),
                Departure("Metrolink Yellow Line", "Bury", 3, "Platform 1", "On Time", "High"),
                Departure("Metrolink Pink Line", "Shaw & Crompton", 5, "Platform 3", "On Time", "Medium"),
                Departure("Metrolink Red Line", "Trafford Centre", 8, "Platform 4", "Delayed 2m", "Medium")
            )
            else -> {
                // Generate semi-random departures based on hash
                val modes = listOf("Metrolink", "Bee Bus", "Northern")
                val dests = listOf("Manchester Piccadilly", "Manchester Victoria", "Bury", "Altrincham", "Stockport", "Rochdale")
                List(4) { i ->
                    val index = (hash + i) % dests.size
                    val mode = modes[(hash + i) % modes.size]
                    val dest = dests[index]
                    val time = i * 4 + ((hash + i) % 5) + 1
                    val plat = "Platform " + ((hash + i) % 4 + 1)
                    val status = statusList[(hash + i) % statusList.size]
                    val occupancy = occupancyList[(hash + i) % occupancyList.size]
                    Departure("$mode Line", dest, time, plat, status, occupancy)
                }
            }
        }
    }

    private val Int.absoluteValue: Int
        get() = if (this < 0) -this else this

    fun generateJourneys(from: String, to: String, isAccessible: Boolean = false): List<Journey> {
        val cleanFrom = from.trim()
        val cleanTo = to.trim()
        
        if (cleanFrom.isEmpty() || cleanTo.isEmpty()) return emptyList()

        // We will generate 3 options: Fastest, Cheapest, Eco-Friendly (least walking)
        val journey1 = Journey(
            modes = listOf("Tram", "Walk"),
            steps = listOf(
                JourneyStep(
                    mode = "Walk",
                    lineName = "Walking",
                    from = cleanFrom,
                    to = "Nearest Tram Stop",
                    durationMinutes = 4,
                    details = "Walk 300m north-west towards the Metrolink platforms."
                ),
                JourneyStep(
                    mode = "Tram",
                    lineName = "Metrolink Purple Line",
                    from = "Nearest Tram Stop",
                    to = "Exchange Square",
                    durationMinutes = 15,
                    details = "Board tram towards Bury. Service runs every 6 minutes."
                ),
                JourneyStep(
                    mode = "Walk",
                    lineName = "Walking",
                    from = "Exchange Square",
                    to = cleanTo,
                    durationMinutes = 3,
                    details = "Walk 150m south. Destination is on your left."
                )
            ),
            totalDurationMinutes = 22,
            totalPrice = 2.80,
            co2SavingKg = 1.4,
            isAccessible = true,
            label = "Fastest Route"
        )

        val journey2 = Journey(
            modes = listOf("Bus"),
            steps = listOf(
                JourneyStep(
                    mode = "Bus",
                    lineName = "Bee Network 135",
                    from = cleanFrom,
                    to = cleanTo,
                    durationMinutes = 32,
                    details = "Board Bee Network 135 at Stand C. Ride 12 stops. Low-emission electric bus."
                )
            ),
            totalDurationMinutes = 32,
            totalPrice = 2.00, // Capped flat single fare in Manchester!
            co2SavingKg = 1.9,
            isAccessible = true,
            label = "Cheapest (Bee Capped)"
        )

        val journey3 = Journey(
            modes = listOf("Taxi"),
            steps = listOf(
                JourneyStep(
                    mode = "Taxi",
                    lineName = "Licensed Manchester Hackney",
                    from = cleanFrom,
                    to = cleanTo,
                    durationMinutes = 14,
                    details = "Direct ride via black cab. Travel in comfort through city center congestion."
                )
            ),
            totalDurationMinutes = 14,
            totalPrice = 12.50,
            co2SavingKg = 0.2,
            isAccessible = isAccessible, // Hackneys are wheelchair accessible!
            label = "Direct Taxi"
        )

        val journeys = listOf(journey1, journey2, journey3)
        return if (isAccessible) {
            journeys.filter { it.isAccessible }
        } else {
            journeys
        }
    }
}
