package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {
    // Tickets
    @Query("SELECT * FROM tickets ORDER BY purchaseTime DESC")
    fun getAllTickets(): Flow<List<Ticket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: Ticket): Long

    @Update
    suspend fun updateTicket(ticket: Ticket)

    // Favorite Journeys
    @Query("SELECT * FROM favorite_journeys ORDER BY id DESC")
    fun getAllFavorites(): Flow<List<FavoriteJourney>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteJourney)

    @Query("DELETE FROM favorite_journeys WHERE id = :id")
    suspend fun deleteFavorite(id: Int)

    // Recent Searches
    @Query("SELECT * FROM recent_searches ORDER BY timestamp DESC LIMIT 10")
    fun getRecentSearches(): Flow<List<RecentSearch>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentSearch(search: RecentSearch)

    @Query("DELETE FROM recent_searches")
    suspend fun clearRecentSearches()

    // Service Alerts
    @Query("SELECT * FROM alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<Alert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: Alert)

    @Query("DELETE FROM alerts WHERE id = :id")
    suspend fun deleteAlert(id: Int)

    @Query("DELETE FROM alerts")
    suspend fun clearAllAlerts()

    // Taxi Bookings
    @Query("SELECT * FROM taxi_bookings ORDER BY timestamp DESC")
    fun getAllTaxiBookings(): Flow<List<TaxiBooking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTaxiBooking(booking: TaxiBooking): Long

    @Update
    suspend fun updateTaxiBooking(booking: TaxiBooking)
}
