package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GraphiteBlack = Color(0xFF0F0F10)
val SteelGrey = Color(0xFF1A1A1C)
val LightSteel = Color(0xFF252527)
val ManchesterRed = Color(0xFFC8102E)
val DeepNavy = Color(0xFF0F0F10)
val RainWhite = Color(0xFFF5F5F5)
val Copper = Color(0xFFB87333)
val CanalBlue = Color(0xFF00529B)
val SoftAmber = Color(0xFFF3D03E)
val MutedGrey = Color(0xFF8E9299)
val GlassGrey = Color(0x0DFFFFFF)
val GlassRed = Color(0x33C8102E)
