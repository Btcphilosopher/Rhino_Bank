package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Ticket
import com.example.ui.MetroViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(viewModel: MetroViewModel) {
    val dbTickets by viewModel.tickets.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var activeSubTab by remember { mutableStateOf(0) } // 0: Ticket Wallet, 1: Purchase Pass

    // Purchase Form State
    var selectedType by remember { mutableStateOf("1-Day AnyBus & Tram") }
    var selectedZones by remember { mutableStateOf("Zones 1-4") }
    var showPaymentSheet by remember { mutableStateOf(false) }
    var paymentInProgress by remember { mutableStateOf(false) }
    var paymentSuccess by remember { mutableStateOf(false) }

    // Card Input States
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }

    // Selected active ticket for scanning overlay
    var scanningTicket by remember { mutableStateOf<Ticket?>(null) }
    var scanValidationSuccess by remember { mutableStateOf(false) }
    var showInvoiceTicket by remember { mutableStateOf<Ticket?>(null) }

    val ticketPrices = mapOf(
        "Single Ride RideCapped" to 2.00,
        "1-Day AnyBus & Tram" to 4.80,
        "7-Day Metrolink System" to 21.00,
        "Monthly All-Network" to 75.00,
        "Student All-Network Pass" to 54.00,
        "Senior Concession Pass" to 2.40
    )

    val calculatedPrice = (ticketPrices[selectedType] ?: 4.80) * when (selectedZones) {
        "Zones 1-2" -> 0.8
        "Zones 1-3" -> 0.9
        else -> 1.0 // Zones 1-4
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DIGITAL TICKETING PLATFORM",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MutedGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "OnePass Wallet",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = RainWhite,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Custom Tab Switcher (Wallet vs Purchase)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SteelGrey)
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeSubTab == 0) LightSteel else Color.Transparent)
                            .clickable { activeSubTab = 0 }
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Wallet,
                                contentDescription = null,
                                tint = if (activeSubTab == 0) ManchesterRed else MutedGrey,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "My Wallet (${dbTickets.size})",
                                color = if (activeSubTab == 0) RainWhite else MutedGrey,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeSubTab == 1) LightSteel else Color.Transparent)
                            .clickable { activeSubTab = 1 }
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.ConfirmationNumber,
                                contentDescription = null,
                                tint = if (activeSubTab == 1) ManchesterRed else MutedGrey,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Buy Bee Passes",
                                color = if (activeSubTab == 1) RainWhite else MutedGrey,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Tabs Content
            if (activeSubTab == 0) {
                // WALLET VIEW
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("wallet_list"),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (dbTickets.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 40.dp)
                                    .background(SteelGrey, RoundedCornerShape(12.dp))
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Outlined.ConfirmationNumber,
                                        contentDescription = "No tickets",
                                        tint = MutedGrey,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        "Your mobile wallet is empty",
                                        color = RainWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Buy single, day, or system-wide passes under the 'Buy Bee Passes' tab.",
                                        color = MutedGrey,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        items(dbTickets) { ticket ->
                            WalletTicketCard(
                                ticket = ticket,
                                onScanClick = {
                                    scanningTicket = ticket
                                    scanValidationSuccess = false
                                },
                                onInvoiceClick = { showInvoiceTicket = ticket }
                            )
                        }
                    }
                }
            } else {
                // PURCHASE PASS VIEW
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("purchase_form"),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 90.dp)
                ) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SteelGrey, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Text("SELECT PASS TYPE", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))

                            ticketPrices.keys.forEach { type ->
                                val isSelected = selectedType == type
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) LightSteel else Color.Transparent)
                                        .clickable { selectedType = type }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedType = type },
                                            colors = RadioButtonDefaults.colors(selectedColor = ManchesterRed)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(type, color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(
                                                text = if (type.contains("Capped")) "Capped flat city single fare" else "Valid on Metrolink + Buses",
                                                color = MutedGrey,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                    Text(
                                        "£${String.format("%.2f", ticketPrices[type])}",
                                        color = if (isSelected) ManchesterRed else RainWhite,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp
                                    )
                                }
                                Divider(color = GraphiteBlack, thickness = 1.dp)
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text("CHOOSE VALIDITY ZONES", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Zones 1-2", "Zones 1-3", "Zones 1-4").forEach { zone ->
                                    val isSelected = selectedZones == zone
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) ManchesterRed else LightSteel)
                                            .clickable { selectedZones = zone }
                                            .padding(10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            zone,
                                            color = if (isSelected) RainWhite else MutedGrey,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // Price and pay Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("TOTAL M3 FARE (CAPPED)", color = MutedGrey, fontSize = 10.sp)
                                    Text(
                                        "£${String.format("%.2f", calculatedPrice)}",
                                        color = SoftAmber,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 24.sp
                                    )
                                }

                                Button(
                                    onClick = {
                                        showPaymentSheet = true
                                        paymentSuccess = false
                                        paymentInProgress = false
                                        cardNumber = ""
                                        cardExpiry = ""
                                        cardCvv = ""
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ManchesterRed),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.CreditCard, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Pay Securely", color = RainWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // SCANNING OVERLAY SHEET
        scanningTicket?.let { ticket ->
            LaunchedEffect(scanningTicket) {
                // Simulate scan validation scanning animation
                delay(3000)
                scanValidationSuccess = true
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .clickable { scanningTicket = null }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SteelGrey),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("BEE NETWORK VALIDATOR", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { scanningTicket = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = RainWhite)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(ticket.ticketType, color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(ticket.zones, color = Copper, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(20.dp))

                        // Custom drawn high fidelity QR Code block
                        Box(
                            modifier = Modifier
                                .size(200.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                                val sizeVal = size.width
                                val step = sizeVal / 10
                                // Draw mock stylized high quality QR dots
                                for (i in 0 until 10) {
                                    for (j in 0 until 10) {
                                        // Specific patterns for corner anchors and semi-random noise
                                        val isAnchor = (i < 3 && j < 3) || (i > 6 && j < 3) || (i < 3 && j > 6)
                                        val rawHash = (i * 31 + j * 17).hashCode()
                                        val hash = if (rawHash < 0) -rawHash else rawHash
                                        val drawDot = isAnchor || (hash % 3 == 0)
                                        if (drawDot) {
                                            drawRect(
                                                color = GraphiteBlack,
                                                topLeft = Offset(i * step, j * step),
                                                size = Size(step * 0.9f, step * 0.9f)
                                            )
                                        }
                                    }
                                }
                            }

                            // Scanning bar moving down
                            if (!scanValidationSuccess) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .background(ManchesterRed)
                                        .align(Alignment.Center)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        if (!scanValidationSuccess) {
                            CircularProgressIndicator(color = SoftAmber, strokeWidth = 3.dp, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Hold ticket near the gates reader...", color = MutedGrey, fontSize = 12.sp)
                        } else {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Valid", tint = Color.Green, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("SCAN SUCCESSFUL", color = Color.Green, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text("VALID FOR TRAVEL ON ALL GREATER MANCHESTER PUBLIC TRANSIT", color = RainWhite, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }

        // TAXI RECEIPT / INVOICE OVERLAY
        showInvoiceTicket?.let { ticket ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .clickable { showInvoiceTicket = null }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = RainWhite),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("TAX INVOICE / RECEIPT", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            IconButton(onClick = { showInvoiceTicket = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                            }
                        }

                        Divider(color = Color.LightGray, thickness = 1.dp)

                        Spacer(modifier = Modifier.height(10.dp))

                        Text("MANCHESTER METRO MaaS", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Transport for Greater Manchester (TfGM)", color = Color.Gray, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Item Purchased:", color = Color.Gray, fontSize = 11.sp)
                        Text(ticket.ticketType, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Validity: " + ticket.zones, color = Color.DarkGray, fontSize = 12.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Transaction ID:", color = Color.Gray, fontSize = 11.sp)
                                Text(ticket.qrCodeData, color = Color.Black, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Date / Time:", color = Color.Gray, fontSize = 11.sp)
                                val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                                Text(sdf.format(Date(ticket.purchaseTime)), color = Color.Black, fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Divider(color = Color.LightGray, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Paid (VAT Incl.):", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("£${String.format("%.2f", ticket.price)}", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Yellow.copy(alpha = 0.2f))
                                .border(1.dp, Color.Yellow)
                                .padding(10.dp)
                        ) {
                            Text(
                                "Bee Network Capped Guarantee: You will never be charged more than the daily maximum capping rate for matching zones traveled.",
                                color = Color.DarkGray,
                                fontSize = 10.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // PAYMENTS CREDIT CARD SIMULATOR SHEET
        if (showPaymentSheet) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .clickable { showPaymentSheet = false }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SteelGrey),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "SECURE CARD PAYMENT (MaaS Pay)",
                            color = MutedGrey,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Double sided Credit Card graphics
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(ManchesterRed, Copper),
                                        start = Offset(0f, 0f),
                                        end = Offset(400f, 400f)
                                    )
                                )
                                .padding(16.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = RainWhite, modifier = Modifier.size(24.dp))
                                    Text("OnePass Pay", color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }

                                Text(
                                    text = if (cardNumber.isEmpty()) "•••• •••• •••• ••••" else cardNumber.chunked(4).joinToString(" "),
                                    color = RainWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 2.sp
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("CARD HOLDER", color = MutedGrey, fontSize = 8.sp)
                                        Text("M. METRO USER", color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("EXPIRES", color = MutedGrey, fontSize = 8.sp)
                                        Text(if (cardExpiry.isEmpty()) "MM/YY" else cardExpiry, color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (!paymentInProgress && !paymentSuccess) {
                            // Inputs form
                            OutlinedTextField(
                                value = cardNumber,
                                onValueChange = { if (it.length <= 16) cardNumber = it },
                                placeholder = { Text("Enter Card Number", color = MutedGrey) },
                                label = { Text("Card Number", color = RainWhite) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ManchesterRed,
                                    unfocusedBorderColor = LightSteel,
                                    focusedTextColor = RainWhite,
                                    unfocusedTextColor = RainWhite
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = cardExpiry,
                                    onValueChange = { if (it.length <= 5) cardExpiry = it },
                                    placeholder = { Text("MM/YY", color = MutedGrey) },
                                    label = { Text("Expiry Date", color = RainWhite) },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ManchesterRed,
                                        unfocusedBorderColor = LightSteel,
                                        focusedTextColor = RainWhite,
                                        unfocusedTextColor = RainWhite
                                    )
                                )

                                OutlinedTextField(
                                    value = cardCvv,
                                    onValueChange = { if (it.length <= 3) cardCvv = it },
                                    placeholder = { Text("123", color = MutedGrey) },
                                    label = { Text("CVV", color = RainWhite) },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ManchesterRed,
                                        unfocusedBorderColor = LightSteel,
                                        focusedTextColor = RainWhite,
                                        unfocusedTextColor = RainWhite
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Button(
                                onClick = {
                                    paymentInProgress = true
                                    // Start secure pay simulation
                                    val currentCardNo = cardNumber
                                    val currentExpiry = cardExpiry
                                    val currentCvv = cardCvv
                                    val payType = selectedType
                                    val payZones = selectedZones
                                    val payPrice = calculatedPrice

                                    coroutineScope.launch {
                                        delay(3000)
                                        paymentInProgress = false
                                        paymentSuccess = true
                                        // Save ticket to Room database!
                                        viewModel.buyTicket(payType, payZones, payPrice)
                                        delay(1500)
                                        showPaymentSheet = false
                                        activeSubTab = 0 // return to wallet to view new ticket!
                                    }
                                },
                                enabled = cardNumber.length >= 12 && cardExpiry.length >= 4 && cardCvv.length >= 3,
                                colors = ButtonDefaults.buttonColors(containerColor = ManchesterRed),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Pay Securely £${String.format("%.2f", calculatedPrice)}", fontWeight = FontWeight.Bold, color = RainWhite)
                            }
                        } else if (paymentInProgress) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 30.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ManchesterRed)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text("Verifying with Greater Manchester bank node...", color = MutedGrey, fontSize = 13.sp)
                                Text("Securing payment portal...", color = MutedGrey, fontSize = 11.sp)
                            }
                        } else {
                            // Payment success tick!
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 30.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = Color.Green, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(14.dp))
                                Text("TICKET SECURED", color = Color.Green, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                                Text("Added to OnePass digital wallet", color = RainWhite, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WalletTicketCard(
    ticket: Ticket,
    onScanClick: () -> Unit,
    onInvoiceClick: () -> Unit
) {
    val df = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    val remainingTimeMillis = ticket.expiryTime - System.currentTimeMillis()
    val isExpired = remainingTimeMillis <= 0

    val remainingHours = (remainingTimeMillis / 3600000).toInt()
    val remainingMins = ((remainingTimeMillis % 3600000) / 60000).toInt()

    Card(
        colors = CardDefaults.cardColors(containerColor = SteelGrey),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isExpired) Color.Gray else ManchesterRed.copy(alpha = 0.4f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = ticket.ticketType,
                        color = RainWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = ticket.zones,
                        color = Copper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isExpired) Color.Gray.copy(alpha = 0.2f) else Color.Green.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isExpired) "EXPIRED" else "ACTIVE",
                        color = if (isExpired) Color.Gray else Color.Green,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("PURCHASE TIME", color = MutedGrey, fontSize = 9.sp)
                    Text(df.format(Date(ticket.purchaseTime)), color = RainWhite, fontSize = 11.sp)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (isExpired) "VALID UNTIL" else "REMAINING TIME",
                        color = MutedGrey,
                        fontSize = 9.sp
                    )
                    Text(
                        text = if (isExpired) df.format(Date(ticket.expiryTime))
                        else "${remainingHours}h ${remainingMins}m",
                        color = if (isExpired) MutedGrey else SoftAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onInvoiceClick,
                    colors = ButtonDefaults.buttonColors(containerColor = LightSteel),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = "Invoice", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Invoice", fontSize = 11.sp, color = RainWhite)
                }

                Button(
                    onClick = onScanClick,
                    enabled = !isExpired,
                    colors = ButtonDefaults.buttonColors(containerColor = ManchesterRed),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1.5f)
                ) {
                    Icon(Icons.Default.QrCode, contentDescription = "Scan Pass", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Scan & Open Gates", fontSize = 11.sp, color = RainWhite, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
