package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StaticData
import com.example.ui.MetroViewModel
import com.example.ui.SimulatedVehicle
import com.example.ui.theme.*

@Composable
fun MapScreen(viewModel: MetroViewModel) {
    val vehicles by viewModel.mapVehicles.collectAsState()
    val filterTram by viewModel.filterTram.collectAsState()
    val filterBus by viewModel.filterBus.collectAsState()
    val filterRail by viewModel.filterRail.collectAsState()

    var selectedVehicleId by remember { mutableStateOf<String?>(null) }
    val selectedVehicle = vehicles.find { it.id == selectedVehicleId }

    // Map Pan/Zoom States (for high-fidelity interactivity)
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    var scale by remember { mutableStateOf(1f) }

    // Constants to project GPS coordinates into a clean coordinate grid on Canvas
    // Center of Manchester: approx 53.4808° N, -2.2426° W
    val centerLat = 53.4808
    val centerLng = -2.2426
    val zoomFactor = 1200f // Scaling factor for projection

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
    ) {
        // Dynamic Canvas GIS Map
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("gis_canvas_map")
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 3.0f)
                        offsetX += pan.x
                        offsetY += pan.y
                    }
                }
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerX = canvasWidth / 2f + offsetX
            val centerY = canvasHeight / 2f + offsetY

            // Projection helper function
            fun project(lat: Double, lng: Double): Offset {
                // Latitudes decrease as you go down on screen, longitudes increase as you go right
                val x = centerX + ((lng - centerLng) * zoomFactor * scale).toFloat()
                val y = centerY - ((lat - centerLat) * zoomFactor * scale * 1.6f).toFloat() // 1.6 aspect ratio correction
                return Offset(x, y)
            }

            // Draw Dark Steel Grid Lines
            val gridSpacing = 80f * scale
            val gridStartLeft = offsetX % gridSpacing
            val gridStartTop = offsetY % gridSpacing

            var x = gridStartLeft
            while (x < canvasWidth) {
                drawLine(
                    color = LightSteel.copy(alpha = 0.25f),
                    start = Offset(x, 0f),
                    end = Offset(x, canvasHeight),
                    strokeWidth = 1f
                )
                x += gridSpacing
            }

            var y = gridStartTop
            while (y < canvasHeight) {
                drawLine(
                    color = LightSteel.copy(alpha = 0.25f),
                    start = Offset(0f, y),
                    end = Offset(canvasWidth, y),
                    strokeWidth = 1f
                )
                y += gridSpacing
            }

            // Draw River Irwell & Canal network overlay (Canal Blue!)
            val canalPath = listOf(
                Pair(53.4920, -2.2680), Pair(53.4830, -2.2590),
                Pair(53.4790, -2.2540), Pair(53.4730, -2.2510),
                Pair(53.4650, -2.2610), Pair(53.4600, -2.2750)
            )
            for (i in 0 until canalPath.size - 1) {
                val p1 = project(canalPath[i].first, canalPath[i].second)
                val p2 = project(canalPath[i + 1].first, canalPath[i + 1].second)
                drawLine(
                    color = CanalBlue.copy(alpha = 0.35f),
                    start = p1,
                    end = p2,
                    strokeWidth = 18f * scale
                )
            }

            // Draw transit lines / routes
            // Tram Route: Bury line to Piccadilly
            if (filterTram) {
                val tramPath = listOf(
                    Pair(53.4873, -2.2423), Pair(53.4849, -2.2389),
                    Pair(53.4781, -2.2441), Pair(53.4774, -2.2312)
                )
                for (i in 0 until tramPath.size - 1) {
                    val p1 = project(tramPath[i].first, tramPath[i].second)
                    val p2 = project(tramPath[i + 1].first, tramPath[i + 1].second)
                    drawLine(
                        color = ManchesterRed.copy(alpha = 0.6f),
                        start = p1,
                        end = p2,
                        strokeWidth = 6f * scale
                    )
                }
            }

            // Rail Line: Airport to Victoria
            if (filterRail) {
                val railPath = listOf(
                    Pair(53.3621, -2.2714), Pair(53.4746, -2.2514),
                    Pair(53.4774, -2.2312), Pair(53.4873, -2.2423)
                )
                for (i in 0 until railPath.size - 1) {
                    val p1 = project(railPath[i].first, railPath[i].second)
                    val p2 = project(railPath[i + 1].first, railPath[i + 1].second)
                    drawLine(
                        color = CanalBlue.copy(alpha = 0.6f),
                        start = p1,
                        end = p2,
                        strokeWidth = 5f * scale
                    )
                }
            }

            // Draw Stations (Stops) clearly
            StaticData.STATIONS.forEach { station ->
                val pos = project(station.latitude, station.longitude)
                // Draw glow outer circle
                drawCircle(
                    color = when (station.mode) {
                        "Tram" -> ManchesterRed.copy(alpha = 0.2f)
                        "Rail" -> CanalBlue.copy(alpha = 0.2f)
                        else -> SoftAmber.copy(alpha = 0.2f)
                    },
                    center = pos,
                    radius = 16f * scale
                )
                // Draw solid station dot
                drawCircle(
                    color = when (station.mode) {
                        "Tram" -> ManchesterRed
                        "Rail" -> CanalBlue
                        else -> SoftAmber
                    },
                    center = pos,
                    radius = 6f * scale
                )
            }

            // Draw simulated moving vehicles (filter based on toggles)
            vehicles.forEach { vehicle ->
                val showVehicle = when (vehicle.mode) {
                    "Tram" -> filterTram
                    "Bus" -> filterBus
                    "Rail" -> filterRail
                    else -> true
                }

                if (showVehicle) {
                    val pos = project(vehicle.latitude, vehicle.longitude)
                    val isSelected = vehicle.id == selectedVehicleId

                    // Draw selection highlight ring
                    if (isSelected) {
                        drawCircle(
                            color = Color.Green.copy(alpha = 0.4f),
                            center = pos,
                            radius = 24f * scale
                        )
                    }

                    // Draw solid vehicle hub
                    drawCircle(
                        color = when (vehicle.mode) {
                            "Tram" -> ManchesterRed
                            "Bus" -> SoftAmber
                            else -> CanalBlue
                        },
                        center = pos,
                        radius = 11f * scale
                    )

                    // Inner core white dot
                    drawCircle(
                        color = RainWhite,
                        center = pos,
                        radius = 4f * scale
                    )
                }
            }
        }

        // Overlay 1: Interactive Screen Mode Toggles (Floating Layer)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .background(SteelGrey.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                .border(1.dp, LightSteel, RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text(
                "MAP FILTERS",
                color = MutedGrey,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            MapFilterRow("Metrolink Trams", ManchesterRed, filterTram) {
                viewModel.setMapFilter(!filterTram, filterBus, filterRail)
            }
            MapFilterRow("Bee Buses", SoftAmber, filterBus) {
                viewModel.setMapFilter(filterTram, !filterBus, filterRail)
            }
            MapFilterRow("National Rail", CanalBlue, filterRail) {
                viewModel.setMapFilter(filterTram, filterBus, !filterRail)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = LightSteel, thickness = 1.dp)
            Spacer(modifier = Modifier.height(4.dp))

            Text(
                "Pinch to zoom • Drag to pan",
                color = MutedGrey,
                fontSize = 9.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Overlay 2: Vehicle Directory / selector List (Left Floating Layer)
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .background(SteelGrey.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                .border(1.dp, LightSteel, RoundedCornerShape(12.dp))
                .width(170.dp)
                .padding(10.dp)
        ) {
            Text(
                "LIVE MASS FLEET",
                color = MutedGrey,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            vehicles.forEach { vehicle ->
                val isSelected = vehicle.id == selectedVehicleId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) LightSteel else Color.Transparent)
                        .clickable {
                            selectedVehicleId = if (isSelected) null else vehicle.id
                        }
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(
                                when (vehicle.mode) {
                                    "Tram" -> ManchesterRed
                                    "Bus" -> SoftAmber
                                    else -> CanalBlue
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = vehicle.name,
                        color = if (isSelected) RainWhite else MutedGrey,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }

        // Overlay 3: Selected Vehicle GPS / Telemetry Telemetry Overlay
        AnimatedVisibility(
            visible = selectedVehicle != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp, vertical = 24.dp)
        ) {
            selectedVehicle?.let { vehicle ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SteelGrey),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.Green.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        when (vehicle.mode) {
                                            "Tram" -> ManchesterRed.copy(alpha = 0.15f)
                                            "Bus" -> SoftAmber.copy(alpha = 0.15f)
                                            else -> CanalBlue.copy(alpha = 0.15f)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (vehicle.mode) {
                                        "Tram" -> Icons.Default.Tram
                                        "Bus" -> Icons.Default.DirectionsBus
                                        else -> Icons.Default.Train
                                    },
                                    contentDescription = null,
                                    tint = when (vehicle.mode) {
                                        "Tram" -> ManchesterRed
                                        "Bus" -> SoftAmber
                                        else -> CanalBlue
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = vehicle.name,
                                    color = RainWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Status: Operational • Connected to TfGM Mesh",
                                    color = Color.Green,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "GPS TELEMETRY",
                                color = MutedGrey,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = String.format("%.4f° N", vehicle.latitude),
                                color = RainWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = String.format("%.4f° W", vehicle.longitude),
                                color = RainWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MapFilterRow(
    label: String,
    dotColor: Color,
    isActive: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .clickable(onClick = onToggle)
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(if (isActive) dotColor else Color.Gray)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            label,
            color = if (isActive) RainWhite else Color.Gray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
