package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Alert
import com.example.data.StaticData
import com.example.ui.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(viewModel: MetroViewModel) {
    val alerts by viewModel.alerts.collectAsState()
    val adminMsg by viewModel.adminCustomMessage.collectAsState()

    var activeMoreTab by remember { mutableStateOf(0) } // 0: Discover, 1: Admin Alert, 2: Analytics

    // Admin state options
    var adminRoute by remember { mutableStateOf("Metrolink Bury Line") }
    var adminMode by remember { mutableStateOf("Tram") }
    var adminSeverity by remember { mutableStateOf("Severe") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
            .testTag("more_screen_scroll"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Main Header
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DISCOVER & OPERATIONS PORTAL",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MutedGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "Metro Station Hub",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = RainWhite,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Custom Tab Switcher (Discover, Admin, Analytics)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SteelGrey)
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeMoreTab == 0) LightSteel else Color.Transparent)
                            .clickable { activeMoreTab = 0 }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Discover",
                            color = if (activeMoreTab == 0) RainWhite else MutedGrey,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeMoreTab == 1) LightSteel else Color.Transparent)
                            .clickable { activeMoreTab = 1 }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Operator",
                            color = if (activeMoreTab == 1) RainWhite else MutedGrey,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeMoreTab == 2) LightSteel else Color.Transparent)
                            .clickable { activeMoreTab = 2 }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Analytics",
                            color = if (activeMoreTab == 2) RainWhite else MutedGrey,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Sub Tabs Content
        when (activeMoreTab) {
            0 -> {
                // DISCOVER TAB
                item {
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        Text(
                            text = "MANCHESTER FUTURISM",
                            color = Copper,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Greater Manchester's unified transit framework is designed around city-spanning canal networks, brick industrial warehouses and modern zero-emission Bee Network transport systems.",
                            color = MutedGrey,
                            fontSize = 12.sp,
                            lineHeight = 16.sp,
                            textAlign = TextAlign.Justify
                        )
                    }
                }

                item {
                    Text(
                        text = "POPULAR CITY DESTINATIONS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MutedGrey,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }

                items(StaticData.DESTINATIONS) { destination ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SteelGrey),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = destination.name,
                                    color = RainWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(CanalBlue.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        destination.category.uppercase(),
                                        color = CanalBlue,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = destination.description,
                                color = MutedGrey,
                                fontSize = 12.sp,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "How to reach there: ${destination.howToGetThere}",
                                color = Copper,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "SUGGESTED ITINERARY:",
                                color = RainWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                            destination.suggestedItinerary.forEachIndexed { idx, step ->
                                Row(
                                    modifier = Modifier.padding(vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ArrowRight, contentDescription = null, tint = ManchesterRed, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(step, color = MutedGrey, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // ADMIN OPERATOR TAB
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .background(SteelGrey, RoundedCornerShape(12.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "PUBLISH NEW SERVICE DELAY",
                            color = RainWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Inject real-time disruption status updates into home board",
                            color = MutedGrey,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Select Transit Route:", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Metrolink Bury Line", "Bee Network 135", "Airport Express Rail").forEach { route ->
                                val isSelected = adminRoute == route
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) ManchesterRed else LightSteel)
                                        .clickable {
                                            adminRoute = route
                                            adminMode = when (route) {
                                                "Metrolink Bury Line" -> "Tram"
                                                "Bee Network 135" -> "Bus"
                                                else -> "Rail"
                                            }
                                        }
                                        .padding(6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        route.take(13) + "...",
                                        color = if (isSelected) RainWhite else MutedGrey,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Select Severity:", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Severe", "Minor", "Good Service").forEach { sev ->
                                val isSelected = adminSeverity == sev
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) ManchesterRed else LightSteel)
                                        .clickable { adminSeverity = sev }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        sev,
                                        color = if (isSelected) RainWhite else MutedGrey,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Announcement Message", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = adminMsg,
                            onValueChange = { viewModel.setAdminMessage(it) },
                            placeholder = { Text("E.g. Signal failure at Victoria platforms. Expect minor delays of 10 mins.", color = MutedGrey) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ManchesterRed,
                                unfocusedBorderColor = LightSteel,
                                focusedTextColor = RainWhite,
                                unfocusedTextColor = RainWhite
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.publishAdminAlert(adminRoute, adminMode, adminSeverity)
                            },
                            enabled = adminMsg.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = ManchesterRed),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Publish, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Publish Disruption Alert", fontWeight = FontWeight.Bold, color = RainWhite)
                        }
                    }
                }

                item {
                    Text(
                        text = "MANAGE CURRENT ALERTS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MutedGrey,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }

                items(alerts) { alert ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .background(SteelGrey, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(alert.route, color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(alert.description, color = MutedGrey, fontSize = 11.sp, maxLines = 1)
                        }

                        IconButton(onClick = { viewModel.deleteAlert(alert.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ManchesterRed)
                        }
                    }
                }
            }

            2 -> {
                // MAAS ANALYTICS DASHBOARD WITH HIGH FIDELITY CANVAS DRAWN CHARTS
                item {
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SteelGrey),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "WEEKLY TICKETS REVENUE",
                                    color = MutedGrey,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Total Revenue: £24,850.20",
                                    color = Color.Green,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Custom Canvas Weekly Bar Chart
                                Canvas(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp)
                                ) {
                                    val barWidth = 30.dp.toPx()
                                    val spacing = 20.dp.toPx()
                                    val maxVal = 5000f
                                    val data = listOf(2800f, 3400f, 4100f, 4850f, 3900f, 2900f, 2100f)
                                    val days = listOf("M", "T", "W", "T", "F", "S", "S")

                                    data.forEachIndexed { i, value ->
                                        val x = i * (barWidth + spacing) + spacing
                                        val barHeight = (value / maxVal) * size.height
                                        val y = size.height - barHeight

                                        // Draw shadow container
                                        drawRect(
                                            color = LightSteel.copy(alpha = 0.3f),
                                            topLeft = Offset(x, 0f),
                                            size = Size(barWidth, size.height)
                                        )

                                        // Draw filled revenue bar
                                        drawRect(
                                            color = ManchesterRed,
                                            topLeft = Offset(x, y),
                                            size = Size(barWidth, barHeight)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
                                        Text(day, color = MutedGrey, fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Passenger Transport Modes Proportional Donut Chart
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SteelGrey),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "M3 PASSENGER TRANSPORT SPLIT",
                                    color = MutedGrey,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Custom canvas donut pie chart
                                    Canvas(
                                        modifier = Modifier
                                            .size(110.dp)
                                            .weight(1f)
                                    ) {
                                        val strokeWidth = 16.dp.toPx()
                                        // Angles representing percentages: Tram: 45%, Bus: 30%, Rail: 15%, Taxi: 10%
                                        drawArc(
                                            color = ManchesterRed,
                                            startAngle = 0f,
                                            sweepAngle = 162f, // 45%
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            color = SoftAmber,
                                            startAngle = 162f,
                                            sweepAngle = 108f, // 30%
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            color = CanalBlue,
                                            startAngle = 270f,
                                            sweepAngle = 54f, // 15%
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            color = Copper,
                                            startAngle = 324f,
                                            sweepAngle = 36f, // 10%
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    // Custom Legend
                                    Column(
                                        modifier = Modifier.weight(1.2f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        LegendRow("Metrolink Tram (45%)", ManchesterRed)
                                        LegendRow("Bee Buses (30%)", SoftAmber)
                                        LegendRow("National Rail (15%)", CanalBlue)
                                        LegendRow("Hackney Taxi (10%)", Copper)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Hourly Passenger Density Density Chart
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SteelGrey),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "DAILY HOURLY PASSENGER VOLUME (PEAK DENSITY)",
                                    color = MutedGrey,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                // Custom canvas line-chart representing peak morning/evening rushes
                                Canvas(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(110.dp)
                                ) {
                                    val points = listOf(
                                        Offset(20f, size.height * 0.9f),
                                        Offset(80f, size.height * 0.4f), // Rush hour 1
                                        Offset(140f, size.height * 0.2f),
                                        Offset(200f, size.height * 0.7f),
                                        Offset(260f, size.height * 0.8f),
                                        Offset(320f, size.height * 0.3f), // Rush hour 2
                                        Offset(380f, size.height * 0.15f),
                                        Offset(440f, size.height * 0.6f),
                                        Offset(500f, size.height * 0.95f)
                                    )

                                    // Draw path line
                                    for (i in 0 until points.size - 1) {
                                        drawLine(
                                            color = CanalBlue,
                                            start = points[i],
                                            end = points[i + 1],
                                            strokeWidth = 3.dp.toPx(),
                                            cap = StrokeCap.Round
                                        )
                                        drawCircle(
                                            color = SoftAmber,
                                            center = points[i],
                                            radius = 4f
                                        )
                                    }
                                    drawCircle(
                                        color = SoftAmber,
                                        center = points.last(),
                                        radius = 4f
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    listOf("06:00", "09:00", "12:00", "15:00", "18:00", "21:00").forEach { hr ->
                                        Text(hr, color = MutedGrey, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LegendRow(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, color = RainWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
