package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.Alert
import com.example.data.FavoriteJourney
import com.example.data.StaticData
import com.example.data.StationInfo
import com.example.ui.MetroViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(viewModel: MetroViewModel) {
    val alerts by viewModel.alerts.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()
    val departures by viewModel.departuresList.collectAsState()

    var showStationSelector by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
            .testTag("home_screen_scroll"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Hero Section with Image Background
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_manchester_futurism),
                    contentDescription = "Manchester Futurism Metrolink Tram",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Overlay Gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, GraphiteBlack),
                                startY = 100f
                            )
                        )
                )

                // Editorial Content over Hero
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = buildAnnotatedString {
                            withStyle(style = SpanStyle(color = RainWhite)) {
                                append("Manchester ")
                            }
                            withStyle(style = SpanStyle(color = ManchesterRed)) {
                                append("Metro")
                            }
                        },
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-0.5).sp
                        )
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = "ONE CITY. ONE JOURNEY.",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Copper,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "•",
                            color = MutedGrey
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = "Weather Icon",
                            tint = CanalBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "14°C • Rain White",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MutedGrey)
                        )
                    }
                }
            }
        }

        // Live Alerts Carousel Widget
        if (alerts.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(
                        text = "DISRUPTION ALERTS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Copper,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(alerts) { alert ->
                            AlertCard(alert)
                        }
                    }
                }
            }
        }

        // Quick Actions Row
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "QUICK METRO SERVICE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MutedGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickActionCard(
                        title = "Buy Day Pass",
                        subtitle = "Zones 1-4 Flat",
                        icon = Icons.Outlined.QrCodeScanner,
                        color = ManchesterRed,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.setTab(2) // Tickets Screen
                    }
                    QuickActionCard(
                        title = "Book Taxi",
                        subtitle = "Hackney / Private",
                        icon = Icons.Outlined.LocalTaxi,
                        color = CanalBlue,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.setTab(1) // Planner/Taxi tab
                        viewModel.setTaxiPickup("Manchester Piccadilly")
                    }
                }
            }
        }

        // Selected Station Live departures Board
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "LIVE DEPARTURES BOARD",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MutedGrey,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { showStationSelector = !showStationSelector }
                                .padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Train,
                                contentDescription = "Station icon",
                                tint = ManchesterRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedStation?.name ?: "Select Station",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = RainWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (showStationSelector) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Dropdown indicator",
                                tint = RainWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = showStationSelector) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .background(SteelGrey, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "Select Transit Station:",
                            style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(bottom = 4.dp, start = 8.dp)
                        )
                        StaticData.STATIONS.forEach { station ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectStation(station)
                                        showStationSelector = false
                                    }
                                    .padding(horizontal = 8.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (station.mode) {
                                        "Tram" -> Icons.Default.Tram
                                        "Rail" -> Icons.Default.Train
                                        else -> Icons.Default.DirectionsBus
                                    },
                                    contentDescription = station.mode,
                                    tint = if (station.name == selectedStation?.name) ManchesterRed else MutedGrey,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = station.name,
                                    color = if (station.name == selectedStation?.name) RainWhite else MutedGrey,
                                    fontWeight = if (station.name == selectedStation?.name) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Departures Scoreboard
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SteelGrey, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    if (departures.isEmpty()) {
                        Text(
                            text = "No departures scheduled currently.",
                            color = MutedGrey,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 20.dp)
                        )
                    } else {
                        departures.forEachIndexed { index, dep ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                if (dep.line.contains("Metrolink") || dep.line.contains("Tram")) ManchesterRed
                                                else if (dep.line.contains("Bee")) SoftAmber
                                                else CanalBlue
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = dep.destination,
                                            color = RainWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = "${dep.line} • ${dep.platform}",
                                            color = MutedGrey,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    // Occupancy indicator
                                    Icon(
                                        imageVector = Icons.Default.Groups,
                                        contentDescription = "Occupancy: ${dep.occupancy}",
                                        tint = when (dep.occupancy) {
                                            "Low" -> Color.Green
                                            "Medium" -> SoftAmber
                                            else -> ManchesterRed
                                        },
                                        modifier = Modifier
                                            .size(16.dp)
                                            .padding(end = 4.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = if (dep.expectedInMinutes == 0) "NOW" else "${dep.expectedInMinutes}m",
                                            color = if (dep.expectedInMinutes <= 2) SoftAmber else RainWhite,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 16.sp
                                        )
                                        Text(
                                            text = dep.status,
                                            color = if (dep.status == "On Time") Color.Green else SoftAmber,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            if (index < departures.size - 1) {
                                Divider(color = LightSteel, thickness = 1.dp)
                            }
                        }
                    }
                }
            }
        }

        // Favorite Journeys Widget
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(
                    text = "FAVOURITE ROUTE SHORTCUTS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MutedGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (favorites.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SteelGrey, RoundedCornerShape(12.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.FavoriteBorder,
                                contentDescription = "Empty favorites",
                                tint = MutedGrey,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Save journeys in the Planner to show them here.",
                                color = MutedGrey,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    favorites.forEach { fav ->
                        FavoriteRouteCard(fav) {
                            viewModel.setTab(1) // Planner tab
                            viewModel.setFromInput(fav.startName)
                            viewModel.setToInput(fav.endName)
                            viewModel.searchJourneys()
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AlertCard(alert: Alert) {
    val df = SimpleDateFormat("HH:mm", Locale.getDefault())
    val formattedTime = df.format(Date(alert.timestamp))

    Card(
        colors = CardDefaults.cardColors(containerColor = DeepNavy),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .width(260.dp)
            .height(115.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (alert.severity == "Severe") Icons.Default.Warning else Icons.Default.Info,
                        contentDescription = "Alert Level",
                        tint = if (alert.severity == "Severe") ManchesterRed else SoftAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = alert.route,
                        color = RainWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
                Text(
                    text = formattedTime,
                    color = MutedGrey,
                    fontSize = 10.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = alert.description,
                color = MutedGrey,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                maxLines = 4
            )
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SteelGrey),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .height(85.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = RainWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = subtitle,
                    color = MutedGrey,
                    fontSize = 12.sp
                )
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
fun FavoriteRouteCard(fav: FavoriteJourney, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SteelGrey),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Favorite icon",
                    tint = Copper,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = fav.startName,
                            color = RainWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "to",
                            tint = MutedGrey,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = fav.endName,
                            color = RainWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Text(
                        text = "Modes: ${fav.modes} • Est. ${fav.durationMinutes} mins",
                        color = MutedGrey,
                        fontSize = 11.sp
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "Search route",
                tint = RainWhite,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
