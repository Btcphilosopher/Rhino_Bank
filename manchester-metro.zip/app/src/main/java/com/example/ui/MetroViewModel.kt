package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MetroViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: MetroRepository

    // Database-backed states
    val tickets: StateFlow<List<Ticket>>
    val favorites: StateFlow<List<FavoriteJourney>>
    val recentSearches: StateFlow<List<RecentSearch>>
    val alerts: StateFlow<List<Alert>>
    val taxiBookings: StateFlow<List<TaxiBooking>>

    // UI Interactive States
    private val _currentTab = MutableStateFlow(0) // 0: Home, 1: Planner, 2: Tickets, 3: Live Map, 4: More/Admin
    val currentTab = _currentTab.asStateFlow()

    private val _selectedStation = MutableStateFlow<StationInfo?>(StaticData.STATIONS.first())
    val selectedStation = _selectedStation.asStateFlow()

    private val _selectedDestination = MutableStateFlow<Destination?>(null)
    val selectedDestination = _selectedDestination.asStateFlow()

    // Planner UI States
    private val _fromInput = MutableStateFlow("")
    val fromInput = _fromInput.asStateFlow()

    private val _toInput = MutableStateFlow("")
    val toInput = _toInput.asStateFlow()

    private val _isAccessiblePlanner = MutableStateFlow(false)
    val isAccessiblePlanner = _isAccessiblePlanner.asStateFlow()

    private val _journeyResults = MutableStateFlow<List<Journey>>(emptyList())
    val journeyResults = _journeyResults.asStateFlow()

    private val _selectedJourney = MutableStateFlow<Journey?>(null)
    val selectedJourney = _selectedJourney.asStateFlow()

    // Taxi Booking UI States
    private val _activeBooking = MutableStateFlow<TaxiBooking?>(null)
    val activeBooking = _activeBooking.asStateFlow()

    private val _taxiPickupInput = MutableStateFlow("")
    val taxiPickupInput = _taxiPickupInput.asStateFlow()

    private val _taxiDestInput = MutableStateFlow("")
    val taxiDestInput = _taxiDestInput.asStateFlow()

    private val _selectedTaxiClass = MutableStateFlow("Hackney Carriage") // "Hackney Carriage", "Electric EV", "Premium Black"
    val selectedTaxiClass = _selectedTaxiClass.asStateFlow()

    // Simulation & Live Tickers
    private val _departuresList = MutableStateFlow<List<Departure>>(emptyList())
    val departuresList = _departuresList.asStateFlow()

    // Live Map Vehicles (Simulation coordinates)
    private val _mapVehicles = MutableStateFlow<List<SimulatedVehicle>>(emptyList())
    val mapVehicles = _mapVehicles.asStateFlow()

    // Map Filters
    private val _filterTram = MutableStateFlow(true)
    val filterTram = _filterTram.asStateFlow()

    private val _filterBus = MutableStateFlow(true)
    val filterBus = _filterBus.asStateFlow()

    private val _filterRail = MutableStateFlow(true)
    val filterRail = _filterRail.asStateFlow()

    // Admin Custom Data
    private val _adminCustomMessage = MutableStateFlow("")
    val adminCustomMessage = _adminCustomMessage.asStateFlow()

    private var departuresJob: Job? = null
    private var taxiSimulationJob: Job? = null
    private var mapSimulationJob: Job? = null

    init {
        val database = MetroDatabase.getDatabase(application)
        val dao = database.metroDao()
        repository = MetroRepository(dao)

        tickets = repository.allTickets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        favorites = repository.allFavorites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        recentSearches = repository.recentSearches.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        alerts = repository.allAlerts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        taxiBookings = repository.allTaxiBookings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Seed initial alerts/favorites if none exist
        viewModelScope.launch {
            // Wait briefly for flow to collect
            delay(500)
            repository.seedInitialDataIfEmpty(alerts.value.size)
            refreshLiveDepartures()
        }

        // Start tickers
        startDeparturesTicker()
        startMapVehicleSimulation()
    }

    fun setTab(index: Int) {
        _currentTab.value = index
    }

    fun selectStation(station: StationInfo) {
        _selectedStation.value = station
        refreshLiveDepartures()
    }

    fun selectDestination(destination: Destination?) {
        _selectedDestination.value = destination
    }

    // Planner Functions
    fun setFromInput(value: String) {
        _fromInput.value = value
    }

    fun setToInput(value: String) {
        _toInput.value = value
    }

    fun setAccessiblePlanner(value: Boolean) {
        _isAccessiblePlanner.value = value
    }

    fun searchJourneys() {
        if (_fromInput.value.isNotBlank() && _toInput.value.isNotBlank()) {
            _journeyResults.value = StaticData.generateJourneys(
                from = _fromInput.value,
                to = _toInput.value,
                isAccessible = _isAccessiblePlanner.value
            )
            // Add to recent search
            viewModelScope.launch {
                repository.insertRecentSearch(
                    RecentSearch(
                        fromName = _fromInput.value,
                        toName = _toInput.value,
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun clearPlanner() {
        _fromInput.value = ""
        _toInput.value = ""
        _journeyResults.value = emptyList()
        _selectedJourney.value = null
    }

    fun selectJourney(journey: Journey?) {
        _selectedJourney.value = journey
    }

    fun saveFavoriteJourney(start: String, end: String, modes: String, duration: Int) {
        viewModelScope.launch {
            repository.insertFavorite(
                FavoriteJourney(
                    startName = start,
                    endName = end,
                    modes = modes,
                    durationMinutes = duration
                )
            )
        }
    }

    fun deleteFavoriteJourney(id: Int) {
        viewModelScope.launch {
            repository.deleteFavorite(id)
        }
    }

    // Ticketing / Payments
    fun buyTicket(ticketType: String, zones: String, price: Double) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val expiryDuration = when {
                ticketType.contains("Single") -> 3 * 3600000L // 3 hours
                ticketType.contains("Day") -> 24 * 3600000L // 1 day
                ticketType.contains("Weekly") -> 7 * 24 * 3600000L // 7 days
                ticketType.contains("Monthly") -> 30 * 24 * 3600000L // 30 days
                else -> 24 * 3600000L
            }
            val qrData = "MAN-METRO-${UUID.randomUUID().toString().take(8).uppercase()}"
            val newTicket = Ticket(
                ticketType = ticketType,
                zones = zones,
                price = price,
                purchaseTime = now,
                expiryTime = now + expiryDuration,
                qrCodeData = qrData,
                status = "Active"
            )
            repository.insertTicket(newTicket)
        }
    }

    fun setTicketStatus(ticket: Ticket, newStatus: String) {
        viewModelScope.launch {
            repository.updateTicket(ticket.copy(status = newStatus))
        }
    }

    // Taxi Functions
    fun setTaxiPickup(value: String) {
        _taxiPickupInput.value = value
    }

    fun setTaxiDest(value: String) {
        _taxiDestInput.value = value
    }

    fun setTaxiClass(value: String) {
        _selectedTaxiClass.value = value
    }

    fun bookTaxi() {
        if (_taxiPickupInput.value.isBlank() || _taxiDestInput.value.isBlank()) return

        val fare = when (_selectedTaxiClass.value) {
            "Electric EV" -> 14.50
            "Premium Black" -> 19.00
            else -> 11.20 // Hackney Carriage
        }

        val drivers = listOf("Mark", "Sarah", "Dave", "Aisha", "Paul")
        val vehicles = listOf("Black Cab #412", "Tesla Model 3 - EV #21", "Black Cab #105", "Nissan Leaf - EV #66", "Mercedes Vito #98")
        val randomIdx = (0..4).random()

        val booking = TaxiBooking(
            pickup = _taxiPickupInput.value,
            destination = _taxiDestInput.value,
            fare = fare,
            driverName = drivers[randomIdx],
            vehicleInfo = vehicles[randomIdx],
            status = "Requested",
            etaMinutes = 5,
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            val id = repository.insertTaxiBooking(booking)
            val insertedBooking = booking.copy(id = id.toInt())
            _activeBooking.value = insertedBooking
            startTaxiSimulation(insertedBooking)
        }
    }

    private fun startTaxiSimulation(booking: TaxiBooking) {
        taxiSimulationJob?.cancel()
        taxiSimulationJob = viewModelScope.launch {
            // Requested -> En Route (4 mins)
            delay(4000)
            var current = booking.copy(status = "En Route", etaMinutes = 4)
            _activeBooking.value = current
            repository.updateTaxiBooking(current)

            // En Route (2 mins)
            delay(4000)
            current = current.copy(etaMinutes = 2)
            _activeBooking.value = current
            repository.updateTaxiBooking(current)

            // Arrived
            delay(4000)
            current = current.copy(status = "Arrived", etaMinutes = 0)
            _activeBooking.value = current
            repository.updateTaxiBooking(current)

            // Completed
            delay(5000)
            current = current.copy(status = "Completed")
            _activeBooking.value = current
            repository.updateTaxiBooking(current)
            delay(2000)
            // clear active UI state
            _activeBooking.value = null
            _taxiPickupInput.value = ""
            _taxiDestInput.value = ""
        }
    }

    fun cancelTaxi() {
        _activeBooking.value?.let { booking ->
            viewModelScope.launch {
                val cancelled = booking.copy(status = "Cancelled")
                repository.updateTaxiBooking(cancelled)
                _activeBooking.value = null
                taxiSimulationJob?.cancel()
            }
        }
    }

    // Admin controls
    fun setAdminMessage(value: String) {
        _adminCustomMessage.value = value
    }

    fun publishAdminAlert(route: String, mode: String, severity: String) {
        if (_adminCustomMessage.value.isBlank()) return
        viewModelScope.launch {
            repository.insertAlert(
                Alert(
                    route = route,
                    mode = mode,
                    severity = severity,
                    description = _adminCustomMessage.value,
                    timestamp = System.currentTimeMillis()
                )
            )
            _adminCustomMessage.value = ""
        }
    }

    fun deleteAlert(id: Int) {
        viewModelScope.launch {
            repository.deleteAlert(id)
        }
    }

    // Live Departures Ticker Simulation
    private fun startDeparturesTicker() {
        departuresJob?.cancel()
        departuresJob = viewModelScope.launch {
            while (true) {
                delay(15000) // update every 15 seconds
                refreshLiveDepartures()
            }
        }
    }

    private fun refreshLiveDepartures() {
        val station = _selectedStation.value ?: return
        _departuresList.value = StaticData.getLiveDepartures(station.name)
    }

    // Interactive GIS Map Vehicles simulation
    fun setMapFilter(tram: Boolean, bus: Boolean, rail: Boolean) {
        _filterTram.value = tram
        _filterBus.value = bus
        _filterRail.value = rail
    }

    private fun startMapVehicleSimulation() {
        mapSimulationJob?.cancel()

        // Generate base routes
        val routes = listOf(
            // Tram: Piccadilly to Altrincham
            listOf(Pair(53.4774, -2.2312), Pair(53.4781, -2.2441), Pair(53.4746, -2.2514), Pair(53.4566, -2.2858)),
            // Tram: Bury to Victoria
            listOf(Pair(53.4873, -2.2423), Pair(53.4849, -2.2389), Pair(53.4781, -2.2441)),
            // Bus: MediaCity to Shudehill
            listOf(Pair(53.4722, -2.2987), Pair(53.4746, -2.2514), Pair(53.4849, -2.2389)),
            // Rail: Airport to Piccadilly
            listOf(Pair(53.3621, -2.2714), Pair(53.4774, -2.2312))
        )

        val vehicles = mutableListOf(
            SimulatedVehicle("T1", "Metrolink Red Line", "Tram", routes[0].first().first, routes[0].first().second, routes[0], 0, 1),
            SimulatedVehicle("T2", "Metrolink Purple Line", "Tram", routes[1].first().first, routes[1].first().second, routes[1], 0, 1),
            SimulatedVehicle("B1", "Bee Network 135", "Bus", routes[2].first().first, routes[2].first().second, routes[2], 0, 1),
            SimulatedVehicle("R1", "Airport Express Train", "Rail", routes[3].first().first, routes[3].first().second, routes[3], 0, 1)
        )

        _mapVehicles.value = vehicles

        mapSimulationJob = viewModelScope.launch {
            while (true) {
                delay(2000) // Update position every 2 seconds
                val updated = _mapVehicles.value.map { vehicle ->
                    val path = vehicle.path
                    val currentIdx = vehicle.pathIndex
                    val nextIdx = vehicle.targetIndex

                    val p1 = path[currentIdx]
                    val p2 = path[nextIdx]

                    // Interpolate step
                    val stepFraction = 0.25
                    val latDiff = p2.first - p1.first
                    val lngDiff = p2.second - p1.second

                    val currentLat = vehicle.latitude + latDiff * stepFraction
                    val currentLng = vehicle.longitude + lngDiff * stepFraction

                    // Check if close enough to target
                    val distance = Math.hypot(currentLat - p2.first, currentLng - p2.second)
                    if (distance < 0.005) {
                        // Advance index
                        val nextPathIdx = (currentIdx + 1) % path.size
                        val nextTargetIdx = (nextPathIdx + 1) % path.size
                        vehicle.copy(
                            latitude = path[nextPathIdx].first,
                            longitude = path[nextPathIdx].second,
                            pathIndex = nextPathIdx,
                            targetIndex = nextTargetIdx
                        )
                    } else {
                        vehicle.copy(latitude = currentLat, longitude = currentLng)
                    }
                }
                _mapVehicles.value = updated
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        departuresJob?.cancel()
        taxiSimulationJob?.cancel()
        mapSimulationJob?.cancel()
    }
}

data class SimulatedVehicle(
    val id: String,
    val name: String,
    val mode: String, // "Tram", "Bus", "Rail"
    val latitude: Double,
    val longitude: Double,
    val path: List<Pair<Double, Double>>,
    val pathIndex: Int,
    val targetIndex: Int
)

class MetroViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MetroViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MetroViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
