package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ManchesterRed,
    secondary = CanalBlue,
    tertiary = Copper,
    background = GraphiteBlack,
    surface = SteelGrey,
    onPrimary = RainWhite,
    onSecondary = RainWhite,
    onTertiary = RainWhite,
    onBackground = RainWhite,
    onSurface = RainWhite,
    surfaceVariant = LightSteel,
    onSurfaceVariant = RainWhite,
    outline = MutedGrey
)

private val LightColorScheme = lightColorScheme(
    primary = ManchesterRed,
    secondary = CanalBlue,
    tertiary = Copper,
    background = Color(0xFFF0F1F4),
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF1E2024),
    onSurface = Color(0xFF1E2024),
    surfaceVariant = Color(0xFFE2E4E8),
    onSurfaceVariant = Color(0xFF1E2024),
    outline = Color(0xFF7E8188)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We can support both, but default to our sleek Dark mode for Manchester Futurism vibe if set
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
