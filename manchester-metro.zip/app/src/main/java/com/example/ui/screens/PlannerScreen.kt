package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Journey
import com.example.data.StaticData
import com.example.ui.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(viewModel: MetroViewModel) {
    val fromInput by viewModel.fromInput.collectAsState()
    val toInput by viewModel.toInput.collectAsState()
    val isAccessible by viewModel.isAccessiblePlanner.collectAsState()
    val results by viewModel.journeyResults.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()

    // Taxi Booking States
    val activeBooking by viewModel.activeBooking.collectAsState()
    val taxiPickup by viewModel.taxiPickupInput.collectAsState()
    val taxiDest by viewModel.taxiDestInput.collectAsState()
    val selectedTaxiClass by viewModel.selectedTaxiClass.collectAsState()

    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
            .testTag("planner_screen_scroll"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // App Header
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "MAAS JOURNEY PLANNER",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MutedGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "Multimodal Routing",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = RainWhite,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (activeBooking == null) {
            // Standard Journey Planner Inputs
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .background(SteelGrey, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    // From Input Row
                    Text(
                        text = "From Origin Station",
                        color = MutedGrey,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = fromInput,
                        onValueChange = {
                            viewModel.setFromInput(it)
                            showFromDropdown = true
                        },
                        placeholder = { Text("Search station...", color = MutedGrey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ManchesterRed,
                            unfocusedBorderColor = LightSteel,
                            focusedTextColor = RainWhite,
                            unfocusedTextColor = RainWhite
                        ),
                        trailingIcon = {
                            IconButton(onClick = { showFromDropdown = !showFromDropdown }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "toggle list", tint = RainWhite)
                            }
                        }
                    )

                    // Origin dropdown
                    if (showFromDropdown) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(LightSteel, RoundedCornerShape(8.dp))
                                .padding(4.dp)
                        ) {
                            StaticData.STATIONS.forEach { station ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.setFromInput(station.name)
                                            showFromDropdown = false
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Place, contentDescription = null, tint = ManchesterRed, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(station.name, color = RainWhite, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // To Input Row
                    Text(
                        text = "To Destination Station",
                        color = MutedGrey,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = toInput,
                        onValueChange = {
                            viewModel.setToInput(it)
                            showToDropdown = true
                        },
                        placeholder = { Text("Search destination...", color = MutedGrey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ManchesterRed,
                            unfocusedBorderColor = LightSteel,
                            focusedTextColor = RainWhite,
                            unfocusedTextColor = RainWhite
                        ),
                        trailingIcon = {
                            IconButton(onClick = { showToDropdown = !showToDropdown }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "toggle list", tint = RainWhite)
                            }
                        }
                    )

                    // Destination dropdown
                    if (showToDropdown) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(LightSteel, RoundedCornerShape(8.dp))
                                .padding(4.dp)
                        ) {
                            StaticData.STATIONS.forEach { station ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.setToInput(station.name)
                                            showToDropdown = false
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Place, contentDescription = null, tint = ManchesterRed, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(station.name, color = RainWhite, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Accessibility Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Accessible, contentDescription = "Accessible transit", tint = CanalBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Step-Free Routing", color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Filter accessible trams/buses/cabs", color = MutedGrey, fontSize = 11.sp)
                            }
                        }
                        Switch(
                            checked = isAccessible,
                            onCheckedChange = { viewModel.setAccessiblePlanner(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = RainWhite,
                                checkedTrackColor = CanalBlue,
                                uncheckedThumbColor = MutedGrey,
                                uncheckedTrackColor = LightSteel
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.clearPlanner() },
                            colors = ButtonDefaults.buttonColors(containerColor = LightSteel),
                            modifier = Modifier.weight(0.4f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Clear", color = RainWhite)
                        }

                        Button(
                            onClick = { viewModel.searchJourneys() },
                            colors = ButtonDefaults.buttonColors(containerColor = ManchesterRed),
                            modifier = Modifier.weight(0.6f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Find Route", color = RainWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Results Heading
            if (results.isNotEmpty()) {
                item {
                    Text(
                        text = "RECOMMENDED MULTIMODAL JOURNEYS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MutedGrey,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }

                items(results) { journey ->
                    JourneyItemRow(
                        journey = journey,
                        isSelected = selectedJourney == journey,
                        onSelect = { viewModel.selectJourney(journey) },
                        onSaveFavorite = {
                            val modeStr = journey.modes.joinToString(",")
                            viewModel.saveFavoriteJourney(
                                start = fromInput,
                                end = toInput,
                                modes = modeStr,
                                duration = journey.totalDurationMinutes
                            )
                        },
                        onBuyTicket = {
                            viewModel.setTab(2) // Tickets wallet tab
                            viewModel.buyTicket(
                                ticketType = "1-Day Multi-Modal",
                                zones = "All Zones 1-4",
                                price = journey.totalPrice
                            )
                        },
                        onBookTaxi = {
                            viewModel.setTaxiPickup(fromInput)
                            viewModel.setTaxiDest(toInput)
                            viewModel.setTaxiClass("Hackney Carriage")
                            viewModel.bookTaxi()
                        }
                    )
                }
            } else if (fromInput.isNotBlank() && toInput.isNotBlank()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .background(SteelGrey, RoundedCornerShape(12.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Tap 'Find Route' to calculate optimized Bee Network options.",
                            color = MutedGrey,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Standalone Taxi Booking Widget (Shortcuts)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .background(SteelGrey, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.LocalTaxi, contentDescription = null, tint = CanalBlue, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Direct MaaS Taxi Dispatch", color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Integrate licensed local drivers instantly", color = MutedGrey, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Pickup Location", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = taxiPickup,
                        onValueChange = { viewModel.setTaxiPickup(it) },
                        placeholder = { Text("E.g. Manchester Piccadilly", color = MutedGrey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CanalBlue,
                            unfocusedBorderColor = LightSteel,
                            focusedTextColor = RainWhite,
                            unfocusedTextColor = RainWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Drop-off Location", color = MutedGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = taxiDest,
                        onValueChange = { viewModel.setTaxiDest(it) },
                        placeholder = { Text("E.g. Salford Quays", color = MutedGrey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CanalBlue,
                            unfocusedBorderColor = LightSteel,
                            focusedTextColor = RainWhite,
                            unfocusedTextColor = RainWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Taxi class selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Hackney Carriage", "Electric EV", "Premium Black").forEach { tClass ->
                            val isSelected = selectedTaxiClass == tClass
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) CanalBlue else LightSteel)
                                    .clickable { viewModel.setTaxiClass(tClass) }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = tClass,
                                    color = if (isSelected) RainWhite else MutedGrey,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.bookTaxi() },
                        enabled = taxiPickup.isNotBlank() && taxiDest.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = CanalBlue),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Book Licensed Driver", fontWeight = FontWeight.Bold, color = RainWhite)
                    }
                }
            }
        } else {
            // Active Taxi Tracking Simulation Screen
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .background(SteelGrey, RoundedCornerShape(16.dp))
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsCar,
                        contentDescription = "Car en route",
                        tint = CanalBlue,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "YOUR RIDE IS BEING TRACKED",
                        style = MaterialTheme.typography.labelSmall.copy(color = CanalBlue, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    )
                    Text(
                        text = activeBooking?.status ?: "",
                        style = MaterialTheme.typography.headlineMedium.copy(color = RainWhite, fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LightSteel, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("DRIVER DETAILS", color = MutedGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(activeBooking?.driverName ?: "", color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(activeBooking?.vehicleInfo ?: "", color = MutedGrey, fontSize = 12.sp)
                        }
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(CanalBlue.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                activeBooking?.driverName?.take(1) ?: "D",
                                color = CanalBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("PICKUP", color = MutedGrey, fontSize = 10.sp)
                            Text(activeBooking?.pickup ?: "", color = RainWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("EST. FARE", color = MutedGrey, fontSize = 10.sp)
                            Text("£${String.format("%.2f", activeBooking?.fare)}", color = Color.Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress simulation status line
                    val progress = when (activeBooking?.status) {
                        "Requested" -> 0.15f
                        "En Route" -> if (activeBooking?.etaMinutes == 4) 0.5f else 0.8f
                        "Arrived" -> 0.95f
                        "Completed" -> 1.0f
                        else -> 0.0f
                    }

                    LinearProgressIndicator(
                        progress = progress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = CanalBlue,
                        trackColor = LightSteel
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = when (activeBooking?.status) {
                            "Requested" -> "Connecting with nearest local hackney operator..."
                            "En Route" -> "Driver is navigating towards pickup point. ETA: ${activeBooking?.etaMinutes}m"
                            "Arrived" -> "Your licensed driver has arrived! Meet them at pickup zone."
                            else -> "Journey completed! Thank you for using MaaS."
                        },
                        color = MutedGrey,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    if (activeBooking?.status != "Completed") {
                        Button(
                            onClick = { viewModel.cancelTaxi() },
                            colors = ButtonDefaults.buttonColors(containerColor = ManchesterRed),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cancel Booking", color = RainWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JourneyItemRow(
    journey: Journey,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onSaveFavorite: () -> Unit,
    onBuyTicket: () -> Unit,
    onBookTaxi: () -> Unit
) {
    var favoriteSaved by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = SteelGrey),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable(onClick = onSelect)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            when (journey.label) {
                                "Fastest Route" -> ManchesterRed.copy(alpha = 0.2f)
                                "Direct Taxi" -> CanalBlue.copy(alpha = 0.2f)
                                else -> Copper.copy(alpha = 0.2f)
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = journey.label.uppercase(),
                        color = when (journey.label) {
                            "Fastest Route" -> ManchesterRed
                            "Direct Taxi" -> CanalBlue
                            else -> Copper
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Eco, contentDescription = "CO2", tint = Color.Green, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("${journey.co2SavingKg}kg CO₂ saved", color = Color.Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Modes icon row & total time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    journey.modes.forEachIndexed { i, m ->
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(15.dp))
                                .background(LightSteel),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (m) {
                                    "Tram" -> Icons.Default.Tram
                                    "Bus" -> Icons.Default.DirectionsBus
                                    "Rail" -> Icons.Default.Train
                                    "Taxi" -> Icons.Default.LocalTaxi
                                    else -> Icons.Default.DirectionsWalk
                                },
                                contentDescription = m,
                                tint = RainWhite,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        if (i < journey.modes.size - 1) {
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MutedGrey, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${journey.totalDurationMinutes} MINS",
                        color = RainWhite,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Est. Fare: £${String.format("%.2f", journey.totalPrice)}",
                        color = SoftAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Expanded details
            AnimatedVisibility(visible = isSelected) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                ) {
                    Divider(color = LightSteel, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "ITINERARY BREAKDOWN:",
                        color = MutedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    journey.steps.forEachIndexed { sIndex, step ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = when (step.mode) {
                                    "Walk" -> Icons.Default.DirectionsWalk
                                    "Tram" -> Icons.Default.Tram
                                    "Bus" -> Icons.Default.DirectionsBus
                                    "Rail" -> Icons.Default.Train
                                    else -> Icons.Default.LocalTaxi
                                },
                                contentDescription = null,
                                tint = if (step.mode == "Tram") ManchesterRed else if (step.mode == "Walk") MutedGrey else CanalBlue,
                                modifier = Modifier
                                    .size(18.dp)
                                    .padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${step.from} ➔ ${step.to}",
                                    color = RainWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "${step.lineName} (${step.durationMinutes}m) • ${step.details}",
                                    color = MutedGrey,
                                    fontSize = 11.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onSaveFavorite()
                                favoriteSaved = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (favoriteSaved) Color.Green else LightSteel),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(
                                imageVector = if (favoriteSaved) Icons.Default.Check else Icons.Default.Favorite,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (favoriteSaved) "Saved" else "Favorite", fontSize = 11.sp, color = RainWhite)
                        }

                        Button(
                            onClick = {
                                if (journey.label.contains("Taxi")) {
                                    onBookTaxi()
                                } else {
                                    onBuyTicket()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (journey.label.contains("Taxi")) CanalBlue else ManchesterRed),
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(
                                imageVector = if (journey.label.contains("Taxi")) Icons.Default.Bolt else Icons.Default.ConfirmationNumber,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (journey.label.contains("Taxi")) "Request Cab" else "Get Bee Pass",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RainWhite
                            )
                        }
                    }
                }
            }
        }
    }
}
