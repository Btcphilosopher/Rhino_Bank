/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from "react";
import { 
  BarChart3, 
  TrendingUp, 
  Percent, 
  ShieldAlert, 
  DollarSign, 
  Activity, 
  FileText, 
  Layers, 
  Download, 
  BookOpen, 
  Settings2, 
  Coins, 
  Copy, 
  Check, 
  RotateCcw, 
  HelpCircle, 
  Briefcase, 
  LineChart as LucideLineChart, 
  Sliders, 
  Database,
  ArrowRight,
  Info
} from "lucide-react";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  ReferenceLine 
} from "recharts";
import { motion, AnimatePresence } from "motion/react";

import { CurrencyExposure, SimulationParameters, ParityMetric, HedgingResultPoint, VarResult, MarketRegimePoint, StressScenario } from "./types";
import { 
  generateSyntheticHistory, 
  computeExposures, 
  calculateParityMetrics, 
  classifyRegimes, 
  computeParametricVar, 
  computeHistoricalVar, 
  runMonteCarloVar, 
  getCovarianceMatrix, 
  runHedgingSimulation, 
  calculateStressTestLosses,
  randomNormal
} from "./utils/mathEngine";
import { rScriptsCollection } from "./utils/rSourceCode";

// Default currency exposures setup (Millions)
const DEFAULT_EXPOSURES: CurrencyExposure[] = [
  {
    currency: "EUR",
    symbol: "€",
    spotRate: 1.0850,
    interestRate: 0.0400, // 4.00% ECB
    transactionReceivables: 25.0,
    transactionPayables: 10.0,
    translationAssets: 150.0,
    translationLiabilities: 40.0,
    economicRevenue: 65.0,
    economicCost: 20.0,
    netTransactionLocal: 0,
    netTranslationLocal: 0,
    netEconomicLocal: 0,
    totalNetUSD: 0
  },
  {
    currency: "GBP",
    symbol: "£",
    spotRate: 1.2650,
    interestRate: 0.0525, // 5.25% BoE
    transactionReceivables: 12.0,
    transactionPayables: 18.0,
    translationAssets: 95.0,
    translationLiabilities: 35.0,
    economicRevenue: 40.0,
    economicCost: 15.0,
    netTransactionLocal: 0,
    netTranslationLocal: 0,
    netEconomicLocal: 0,
    totalNetUSD: 0
  },
  {
    currency: "JPY",
    symbol: "¥",
    spotRate: 0.00645, // direct quote JPY/USD (~155 JPY per USD)
    interestRate: 0.0025, // 0.25% BoJ
    transactionReceivables: 800.0,
    transactionPayables: 2500.0,
    translationAssets: 3000.0,
    translationLiabilities: 800.0,
    economicRevenue: 5000.0,
    economicCost: 1200.0,
    netTransactionLocal: 0,
    netTranslationLocal: 0,
    netEconomicLocal: 0,
    totalNetUSD: 0
  }
];

const STRESS_SCENARIOS: StressScenario[] = [
  {
    id: "scen_1",
    name: "2008 Safe Haven Unwind",
    description: "Global liquidity crunch. Massive panic flight. EUR collapses (-15%), GBP collapses (-18%), but safe-haven JPY surges (+20% in direct USD value) because of massive carry trade unwinds.",
    shocks: { EUR: -0.15, GBP: -0.18, JPY: 0.20 }
  },
  {
    id: "scen_2",
    name: "Tariff War / Trump Rate Hike Shock",
    description: "Sudden escalation in trade restrictions and resurgent Federal Reserve rate hikes driving massive safe-haven dollar accumulation. General decline across European and Asian counterparties.",
    shocks: { EUR: -0.10, GBP: -0.10, JPY: -0.12 }
  },
  {
    id: "scen_3",
    name: "Emerging Markets Collapse (Risk-Off)",
    description: "Crisis in developing currencies triggers systemic contagion. Extreme flight to liquid USD cash structures. EUR and GBP pull back mildly, while funding squeeze hammers the yen.",
    shocks: { EUR: -0.05, GBP: -0.05, JPY: -0.25 }
  },
  {
    id: "scen_4",
    name: "Central Bank Policy Divergence",
    description: "Federal Reserve aggressively hikes USD policy rates by 1.5% while ECB and BoE cut. Volatile yield-spread adjustments, leading to general deprecation in foreign currency assets.",
    shocks: { EUR: -0.08, GBP: -0.06, JPY: -0.15 }
  }
];

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<"dashboard" | "stochastic" | "parity" | "hedging" | "stress" | "rScripts" | "guide">("dashboard");
  
  // Market & Simulation States
  const [simulationParams, setSimulationParams] = useState<SimulationParameters>({
    stochasticModel: "GBM",
    steps: 10,
    pathsCount: 1000,
    confidenceLevel: 0.95,
    usdInterestRate: 0.0525, // 5.25%
    ouTheta: 0.20,
    spots: { EUR: 1.0850, GBP: 1.2650, JPY: 0.00645 },
    volatilities: { EUR: 0.082, GBP: 0.095, JPY: 0.124 }
  });
  
  const [currencyExposures, setCurrencyExposures] = useState<CurrencyExposure[]>(DEFAULT_EXPOSURES);
  
  // State for R script explorer
  const [selectedRScriptIdx, setSelectedRScriptIdx] = useState<number>(0);
  const [copiedStatus, setCopiedStatus] = useState<boolean>(false);
  
  // State for Hedging inputs
  const [selectedHedgeCurrency, setSelectedHedgeCurrency] = useState<"EUR" | "GBP" | "JPY">("EUR");
  const [hedgingExposureVal, setHedgingExposureVal] = useState<number>(25.0); // local MM
  const [currentHedgeRatio, setCurrentHedgeRatio] = useState<number>(0.75); // 75%
  
  // Generate active historical return sets
  const historicalData = useMemo(() => {
    return generateSyntheticHistory(simulationParams.spots, simulationParams.volatilities);
  }, [simulationParams.spots, simulationParams.volatilities]);
  
  // Retrieve daily covariance matrix
  const covarianceMatrix = useMemo(() => {
    return getCovarianceMatrix(historicalData.returnHistory);
  }, [historicalData]);
  
  // Perform real-time exposures calculations
  const aggregatedExposures = useMemo(() => {
    return computeExposures(currencyExposures, simulationParams.spots);
  }, [currencyExposures, simulationParams.spots]);
  
  const netExposuresUSDMap = useMemo(() => {
    const map: Record<string, number> = {};
    aggregatedExposures.forEach(e => {
      map[e.currency] = e.totalNetUSD;
    });
    return map;
  }, [aggregatedExposures]);
  
  const totalPortfolioUSDNet = useMemo(() => {
    return aggregatedExposures.reduce((sum, e) => sum + e.totalNetUSD, 0);
  }, [aggregatedExposures]);
  
  // Interest Parity deviations calculation
  const parityMetrics = useMemo(() => {
    return calculateParityMetrics(aggregatedExposures, simulationParams.usdInterestRate, simulationParams.spots);
  }, [aggregatedExposures, simulationParams.usdInterestRate, simulationParams.spots]);
  
  // Volatility Regime historical detection
  const regimeDataset = useMemo(() => {
    // Generate simple portfolio mock returns
    const portfolioDailyReturns: number[] = [];
    const days = historicalData.dates.length;
    for (let d = 0; d < days; d++) {
      let r = 0;
      aggregatedExposures.forEach(e => {
        const share = Math.abs(e.totalNetUSD) / (Math.abs(totalPortfolioUSDNet) || 1);
        r += share * (historicalData.returnHistory[e.currency]?.[d] || 0.0);
      });
      portfolioDailyReturns.push(r);
    }
    
    return classifyRegimes(portfolioDailyReturns, historicalData.dates);
  }, [historicalData, aggregatedExposures, totalPortfolioUSDNet]);
  
  const activeRegime = useMemo(() => {
    if (regimeDataset.length === 0) return "Low Volatility Stable";
    return regimeDataset[regimeDataset.length - 1].regime;
  }, [regimeDataset]);
  
  // Execute Monte Carlo VaR projections (memoized to run smoothly on state adjustments)
  const mcResults = useMemo(() => {
    return runMonteCarloVar(
      netExposuresUSDMap,
      simulationParams.volatilities,
      simulationParams.confidenceLevel,
      simulationParams.stochasticModel,
      simulationParams.ouTheta,
      simulationParams.steps,
      simulationParams.pathsCount
    );
  }, [
    netExposuresUSDMap, 
    simulationParams.volatilities, 
    simulationParams.confidenceLevel, 
    simulationParams.stochasticModel, 
    simulationParams.ouTheta, 
    simulationParams.steps, 
    simulationParams.pathsCount
  ]);
  
  // Compute Parametric & Historical VaR benchmarks
  const varCalculationsBench = useMemo(() => {
    const pVar = computeParametricVar(
      netExposuresUSDMap,
      covarianceMatrix,
      simulationParams.confidenceLevel,
      simulationParams.steps
    );
    
    const hVar = computeHistoricalVar(
      netExposuresUSDMap,
      historicalData.returnHistory,
      simulationParams.confidenceLevel,
      simulationParams.steps
    );
    
    return {
      parametric: pVar,
      historical: hVar
    };
  }, [netExposuresUSDMap, covarianceMatrix, historicalData, simulationParams.confidenceLevel, simulationParams.steps]);
  
  // Backtest Hedging Strategy outcomes
  const hedgingSimData = useMemo(() => {
    const spots = historicalData.spotHistory[selectedHedgeCurrency];
    const spotsNormalized = spots.map(s => s / spots[0]); // normalize sequence to evaluate P&L trace
    
    // Theoretical forward premium based on rate spreads
    const baseSpot = simulationParams.spots[selectedHedgeCurrency];
    const foreignRate = currencyExposures.find(e => e.currency === selectedHedgeCurrency)?.interestRate || 0.05;
    const rd = simulationParams.usdInterestRate;
    const durationFraction = 90 / 360; // 3 month
    
    const forwardPrice = baseSpot * (1 + rd * durationFraction) / (1 + foreignRate * durationFraction);
    const forwardPointsNormalized = forwardPrice / baseSpot;
    
    const fwdsNormalized = spotsNormalized.map(st => st * (forwardPointsNormalized / spotsNormalized[0]));
    
    return runHedgingSimulation(
      spotsNormalized,
      fwdsNormalized,
      hedgingExposureVal * baseSpot, // exposure size in USD terms
      currentHedgeRatio
    );
  }, [historicalData, selectedHedgeCurrency, hedgingExposureVal, currentHedgeRatio, simulationParams.spots, simulationParams.usdInterestRate, currencyExposures]);
  
  // Compute Macro Stress portfolios impacts
  const stressLossSummaries = useMemo(() => {
    return STRESS_SCENARIOS.map(sc => {
      const stats = calculateStressTestLosses(netExposuresUSDMap, sc);
      return {
        id: sc.id,
        name: sc.name,
        description: sc.description,
        totalLossUSD: stats.portfolioSumUSD,
        itemized: stats.itemized
      };
    });
  }, [netExposuresUSDMap]);

  // Adjust spot rates in global simulations
  const handleSpotAdjust = (currency: string, val: number) => {
    setSimulationParams(prev => ({
      ...prev,
      spots: { ...prev.spots, [currency]: val }
    }));
  };
  
  // Adjust volatilities in global simulations
  const handleVolAdjust = (currency: string, val: number) => {
    setSimulationParams(prev => ({
      ...prev,
      volatilities: { ...prev.volatilities, [currency]: val }
    }));
  };
  
  // Adjust exposure sizes in the ledger
  const handleExpLocalAdjust = (currency: string, type: "receivables" | "payables" | "assets" | "liabilities" | "revenue" | "cost", val: number) => {
    setCurrencyExposures(prev => {
      return prev.map(e => {
        if (e.currency === currency) {
          const updated = { ...e };
          if (type === "receivables") updated.transactionReceivables = val;
          if (type === "payables") updated.transactionPayables = val;
          if (type === "assets") updated.translationAssets = val;
          if (type === "liabilities") updated.translationLiabilities = val;
          if (type === "revenue") updated.economicRevenue = val;
          if (type === "cost") updated.economicCost = val;
          return updated;
        }
        return e;
      });
    });
  };
  
  const handleCopyCode = (codeTxt: string) => {
    navigator.clipboard.writeText(codeTxt);
    setCopiedStatus(true);
    setTimeout(() => setCopiedStatus(false), 2000);
  };
  
  // Quick asset exposure summary to render small lists
  const formatUSD = (val: number) => {
    return (val >= 0 ? "+" : "") + val.toFixed(2) + "M USD";
  };
  
  const formatUSDSimple = (val: number) => {
    return (val >= 0 ? "" : "-") + "$" + Math.abs(val).toFixed(2) + "M";
  };

  // Build the Spaghetti trace lines for Recharts
  const spaghettiPlotData = useMemo(() => {
    const list: Array<Record<string, number>> = [];
    for (let step = 0; step <= 10; step++) {
      const row: Record<string, number> = { name: step };
      // Spaghetti project paths
      for (let pathIdx = 0; pathIdx < 10; pathIdx++) {
        row[`EUR_P${pathIdx}`] = mcResults.pathsEUR[step][pathIdx] || 1.0;
        row[`GBP_P${pathIdx}`] = mcResults.pathsGBP[step][pathIdx] || 1.0;
        row[`JPY_P${pathIdx}`] = mcResults.pathsJPY[step][pathIdx] || 1.0;
      }
      list.push(row);
    }
    return list;
  }, [mcResults]);

  // Build the Value-at-Risk histogram bins for Recharts
  const lossHistogramData = useMemo(() => {
    const losses = mcResults.scenariosLosses;
    const n = losses.length;
    const min = losses[0];
    const max = losses[n - 1];
    const binCount = 35;
    const step = (max - min) / binCount;
    
    const bins: Array<{ binStart: number; binCenter: string; count: number }> = [];
    for (let i = 0; i < binCount; i++) {
      const bMin = min + i * step;
      const bMax = bMin + step;
      const center = ((bMin + bMax) / 2).toFixed(2);
      bins.push({
        binStart: bMin,
        binCenter: center + "M",
        count: 0
      });
    }
    
    losses.forEach(l => {
      let assigned = false;
      for (let i = 0; i < binCount; i++) {
        const bMin = bins[i].binStart;
        const bMax = bMin + step;
        if (l >= bMin && l <= bMax) {
          bins[i].count++;
          assigned = true;
          break;
        }
      }
      if (!assigned) {
        bins[binCount - 1].count++;
      }
    });
    
    return bins;
  }, [mcResults]);

  return (
    <div className="min-h-screen bg-[#050505] text-[#e0e0e0] font-sans selection:bg-[#F27D26]/20 selection:text-[#F27D26]" id="main-risk-engine-container">
      {/* Header Bar */}
      <header className="bg-[#0a0a0a] text-[#e0e0e0] border-b border-[#222] sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-9 h-9 bg-[#F27D26] rounded flex items-center justify-center font-bold font-mono text-black text-xl shadow-[0_0_12px_rgba(242,125,38,0.2)]">
              R
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-serif italic tracking-tight uppercase text-white">
                  Currency Risk <span className="text-[#666] font-sans text-xs align-middle ml-2 tracking-widest uppercase font-semibold">QUANT ENGINE v4.2</span>
                </h1>
              </div>
              <p className="font-sans text-xs text-[#666] tracking-wide">
                Institutional FX Exposure, Interest Parity deviations, Monte Carlo VaR &amp; Derivative Hedging Simulator
              </p>
            </div>
          </div>
          
          {/* Active Status Ribbon */}
          <div className="flex items-center gap-4 bg-[#050505] px-4 py-2 border border-[#222] rounded text-xs font-mono">
            <div className="flex flex-col">
              <span className="text-[10px] text-[#555] uppercase font-semibold">USD Rate (3M SOFR)</span>
              <span className="text-[#F27D26] font-bold">{(simulationParams.usdInterestRate * 100).toFixed(2)}%</span>
            </div>
            <div className="h-8 w-[1px] bg-[#222]"></div>
            <div className="flex flex-col">
              <span className="text-[10px] text-[#555] uppercase font-semibold">Vol Regime</span>
              <span className="text-[#00FF00] font-bold flex items-center gap-1">
                <span className="h-1.5 w-1.5 bg-[#00FF00] rounded-full shadow-[0_0_6px_#00FF00] animate-pulse"></span>
                {activeRegime.toUpperCase()}
              </span>
            </div>
            <div className="h-8 w-[1px] bg-[#222]"></div>
            <div className="flex flex-col">
              <span className="text-[10px] text-[#555] uppercase font-semibold">Base Currency</span>
              <span className="text-white font-bold select-none">USD ($)</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* LEFT COLUMN: Input Parameters Controller */}
        <div className="lg:col-span-1 bg-[#0a0a0a] border border-[#222] rounded-lg overflow-hidden" id="risk-parameters-sidebar">
          <div className="p-4 bg-[#0a0a0a] border-b border-[#222] flex items-center justify-between">
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-[#e0e0e0] flex items-center gap-1.5">
              <Settings2 className="h-4 w-4 text-[#F27D26]" />
              Real-time Calibration
            </span>
            <button 
              onClick={() => {
                setSimulationParams({
                  stochasticModel: "GBM",
                  steps: 10,
                  pathsCount: 1000,
                  confidenceLevel: 0.95,
                  usdInterestRate: 0.0525,
                  ouTheta: 0.20,
                  spots: { EUR: 1.0850, GBP: 1.2650, JPY: 0.00645 },
                  volatilities: { EUR: 0.082, GBP: 0.095, JPY: 0.124 }
                });
                setCurrencyExposures(DEFAULT_EXPOSURES);
              }}
              title="Reset configuration parameters"
              className="p-1 text-[#666] hover:text-white hover:bg-[#1a1a1a] rounded transition"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          </div>
          
          <div className="p-4 space-y-5">
            {/* Base Parameters */}
            <div>
              <label className="block text-[10px] font-semibold text-[#888] uppercase tracking-widest mb-3 font-mono flex items-center gap-1.5">
                <Sliders className="h-3.5 w-3.5 text-[#F27D26]" />
                Scenario Settings
              </label>
              
              <div className="space-y-4">
                {/* 3M USD rate */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#888]">USD Repo Funding Rate</span>
                    <span className="font-mono font-bold text-[#F27D26]">{(simulationParams.usdInterestRate * 100).toFixed(2)}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.01" 
                    max="0.10" 
                    step="0.0025" 
                    value={simulationParams.usdInterestRate}
                    onChange={(e) => setSimulationParams(prev => ({ ...prev, usdInterestRate: parseFloat(e.target.value) }))}
                    className="w-full h-1 bg-[#1a1a1a] rounded appearance-none cursor-pointer accent-[#F27D26]"
                  />
                </div>

                {/* Horizon steps */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#888] font-mono">Risk Horizon T</span>
                    <span className="font-mono font-bold text-[#F27D26]">{simulationParams.steps} Days</span>
                  </div>
                  <input 
                    type="range" 
                    min="1" 
                    max="60" 
                    step="1" 
                    value={simulationParams.steps}
                    onChange={(e) => setSimulationParams(prev => ({ ...prev, steps: parseInt(e.target.value) }))}
                    className="w-full h-1 bg-[#1a1a1a] rounded appearance-none cursor-pointer accent-[#F27D26]"
                  />
                  <span className="text-[10px] text-[#555] font-mono block mt-1">Typically 10-day holding for Basel regulatory VaR</span>
                </div>

                {/* Stochastic Model */}
                <div>
                  <span className="text-[10px] text-[#888] font-mono block mb-1.5 uppercase tracking-wider">Stochastic Model family</span>
                  <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#050505] border border-[#222] rounded">
                    <button
                      onClick={() => setSimulationParams(prev => ({ ...prev, stochasticModel: "GBM" }))}
                      className={`text-xs py-1 rounded font-medium transition ${simulationParams.stochasticModel === "GBM" ? "bg-[#F27D26] text-black font-bold" : "text-[#555] hover:text-[#e0e0e0]"}`}
                    >
                      Brownian Motion
                    </button>
                    <button
                      onClick={() => setSimulationParams(prev => ({ ...prev, stochasticModel: "OU" }))}
                      className={`text-xs py-1 rounded font-medium transition ${simulationParams.stochasticModel === "OU" ? "bg-[#F27D26] text-black font-bold" : "text-[#555] hover:text-[#e0e0e0]"}`}
                    >
                      Ornstein-Uhlenbeck
                    </button>
                  </div>
                </div>

                {simulationParams.stochasticModel === "OU" && (
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-[#888]">Mean Reversion (theta)</span>
                      <span className="font-mono font-bold text-[#F27D26]">{simulationParams.ouTheta.toFixed(2)}</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.05" 
                      max="1.5" 
                      step="0.05" 
                      value={simulationParams.ouTheta}
                      onChange={(e) => setSimulationParams(prev => ({ ...prev, ouTheta: parseFloat(e.target.value) }))}
                      className="w-full h-1 bg-[#1a1a1a] rounded appearance-none cursor-pointer accent-[#F27D26]"
                    />
                  </div>
                )}

                {/* Confidence level */}
                <div>
                  <span className="text-[10px] text-[#888] font-mono block mb-1.5 uppercase tracking-wider">Confidence Level (α)</span>
                  <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#050505] border border-[#222] rounded">
                    <button
                      onClick={() => setSimulationParams(prev => ({ ...prev, confidenceLevel: 0.95 }))}
                      className={`text-xs py-1 rounded font-mono font-bold transition ${simulationParams.confidenceLevel === 0.95 ? "bg-[#F27D26] text-black font-bold" : "text-[#555] hover:text-[#e0e0e0]"}`}
                    >
                      95% VaR
                    </button>
                    <button
                      onClick={() => setSimulationParams(prev => ({ ...prev, confidenceLevel: 0.99 }))}
                      className={`text-xs py-1 rounded font-mono font-bold transition ${simulationParams.confidenceLevel === 0.99 ? "bg-[#F27D26] text-black font-bold" : "text-[#555] hover:text-[#e0e0e0]"}`}
                    >
                      99% VaR
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <hr className="border-[#222]" />

            {/* Currency calibrations */}
            <div>
              <label className="block text-[10px] font-semibold text-[#888] uppercase tracking-widest mb-3 font-mono flex items-center gap-1.5">
                <Coins className="h-3.5 w-3.5 text-[#F27D26]" />
                Asset Volatility Calibration
              </label>
              
              <div className="space-y-4">
                {currencyExposures.map(c => {
                  const spot = simulationParams.spots[c.currency];
                  const vol = simulationParams.volatilities[c.currency];
                  return (
                    <div key={c.currency} className="space-y-1 bg-[#050505] p-2.5 rounded border border-[#222]">
                      <div className="flex justify-between items-center text-xs font-bold text-[#e0e0e0]">
                        <span>{c.currency}/USD Quote</span>
                        <span className="font-mono text-[9px] text-[#888] bg-[#1a1a1a] border border-[#222] px-1 py-0.5 rounded">
                          Ir: {(c.interestRate * 100).toFixed(2)}%
                        </span>
                      </div>
                      
                      {/* Spot input */}
                      <div className="grid grid-cols-2 gap-2 items-center pt-1.5">
                        <span className="text-[11px] text-[#888] font-mono">Spot Rate</span>
                        <input
                          type="number"
                          step={c.currency === "JPY" ? "0.00005" : "0.005"}
                          className="font-mono text-xs border border-[#333] rounded p-1 text-right w-full bg-[#050505] text-[#F27D26] font-bold outline-none focus:border-[#F27D26]"
                          value={spot}
                          onChange={(e) => handleSpotAdjust(c.currency, parseFloat(e.target.value) || 0)}
                        />
                      </div>

                      {/* Vol slider */}
                      <div className="pt-1">
                        <div className="flex justify-between text-[11px] text-[#888]">
                          <span className="font-mono text-[10px]">Proj Volatility</span>
                          <span className="font-mono font-semibold text-[#F27D26]">{(vol * 100).toFixed(1)}%</span>
                        </div>
                        <input 
                          type="range" 
                          min="0.02" 
                          max="0.30" 
                          step="0.005" 
                          value={vol}
                          onChange={(e) => handleVolAdjust(c.currency, parseFloat(e.target.value))}
                          className="w-full h-1 bg-[#222] rounded appearance-none cursor-pointer accent-[#F27D26]"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <hr className="border-[#222]" />

            {/* Ingestion & Export metrics */}
            <div className="space-y-2 text-xs">
              <span className="font-mono text-[10px] text-[#555] uppercase font-semibold tracking-wider">Workspace Outputs</span>
              <div className="p-3 bg-[#050505] text-[#888] rounded border border-[#222] font-mono flex flex-col gap-2">
                <div className="flex justify-between">
                  <span>Aligned Tensors</span>
                  <span className="text-white font-bold">120 obs</span>
                </div>
                <div className="flex justify-between">
                  <span>Est Correlation (EUR/GBP)</span>
                  <span className="text-[#00FF00] font-bold">+0.485</span>
                </div>
                <div className="flex justify-between">
                  <span>Est Correlation (EUR/JPY)</span>
                  <span className="text-red-500 font-bold">-0.162</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Interactive Tabs Dashboard */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Main Navigation tabs */}
          <nav className="flex flex-wrap border-b border-[#222] gap-1" id="engine-navigation-row">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-medium text-xs rounded-t-md transition ${activeTab === "dashboard" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-semibold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <Briefcase className="h-3.5 w-3.5" />
              Exposure &amp; VaR
            </button>
            <button
              onClick={() => setActiveTab("stochastic")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-medium text-xs rounded-t-md transition ${activeTab === "stochastic" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-semibold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <TrendingUp className="h-3.5 w-3.5" />
              Stochastic Paths
            </button>
            <button
              onClick={() => setActiveTab("parity")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-medium text-xs rounded-t-md transition ${activeTab === "parity" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-semibold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <Percent className="h-3.5 w-3.5" />
              Parity Deviations
            </button>
            <button
              onClick={() => setActiveTab("hedging")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-medium text-xs rounded-t-md transition ${activeTab === "hedging" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-semibold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <Coins className="h-3.5 w-3.5" />
              Hedge Simulator
            </button>
            <button
              onClick={() => setActiveTab("stress")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-medium text-xs rounded-t-md transition ${activeTab === "stress" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-semibold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <ShieldAlert className="h-3.5 w-3.5" />
              Stress Shock Testing
            </button>
            <button
              onClick={() => setActiveTab("rScripts")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-mono text-xs rounded-t-md transition ${activeTab === "rScripts" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-bold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <Database className="h-3.5 w-3.5" />
              R-Files Code
            </button>
            <button
              onClick={() => setActiveTab("guide")}
              className={`flex items-center gap-1.5 px-4 py-2.5 font-sans font-medium text-xs rounded-t-md transition ${activeTab === "guide" ? "bg-[#0a0a0a] border-t border-x border-[#222] text-white border-t-[#F27D26] shadow-sm font-semibold" : "text-[#888] hover:text-[#e0e0e0] hover:bg-[#0a0a0a]/40"}`}
            >
              <BookOpen className="h-3.5 w-3.5" />
              Quant Theory Guide
            </button>
          </nav>

          {/* MAIN CANVAS AREA */}
          <div className="bg-[#0a0a0a] border border-[#222] rounded-lg shadow-sm p-4 md:p-6 min-h-[500px]">
            
            {/* TAB 1: EXPOSURES & RISK VALUE AT RISK */}
            {activeTab === "dashboard" && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#222] pb-4 gap-4">
                  <div>
                    <h2 className="text-lg font-bold text-white">FX Exposure Ledgers &amp; VaR Dashboard</h2>
                    <p className="text-xs text-[#888]">Decomposes structural asset balances into transaction, translation, and economic operation risks.</p>
                  </div>
                  
                  {/* Total Value Summary Badge */}
                  <div className="p-3 bg-[#050505] border border-[#222] rounded text-white font-mono flex items-center gap-4">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-[#888] block tracking-normal">Consolidated Portfolio</span>
                      <span className="text-lg font-extrabold text-[#F27D26] flex items-center">
                        <DollarSign className="h-4.5 w-4.5 text-[#F27D26]" />
                        {Math.abs(totalPortfolioUSDNet).toFixed(2)}M
                        <span className="text-xs text-white font-normal ml-1">USD {totalPortfolioUSDNet >= 0 ? "Net Long" : "Net Short"}</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Sub-exposures Table ledger */}
                <div className="overflow-x-auto border border-[#222] rounded">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#050505] border-b border-[#222] font-mono text-[#888] uppercase tracking-wide">
                        <th className="p-3">Currency Pair</th>
                        <th className="p-3 text-right">Spot (USD)</th>
                        <th className="p-3 text-right">Transaction Net</th>
                        <th className="p-3 text-right">Translation Net</th>
                        <th className="p-3 text-right">Economic Net</th>
                        <th className="p-3 text-right bg-[#1a1a1a]/30 text-white font-bold font-sans border-l border-[#222]">USD Net Exposure</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#222]">
                      {aggregatedExposures.map(e => {
                        const original = currencyExposures.find(o => o.currency === e.currency)!;
                        return (
                          <tr key={e.currency} className="hover:bg-[#050505] transition">
                            <td className="p-3 font-semibold text-white flex items-center gap-2">
                              <span className="h-6 w-6 rounded-full bg-[#1a1a1a] border border-[#222] text-xs font-bold text-[#e0e0e0] flex items-center justify-center select-none shadow">
                                {e.symbol}
                              </span>
                              {e.currency}/USD
                            </td>
                            <td className="p-3 text-right font-mono text-[#e0e0e0]">
                              {e.spotRate.toFixed(e.currency === "JPY" ? 5 : 4)}
                            </td>
                            
                            {/* Transaction */}
                            <td className="p-3 text-right font-mono">
                              <div className="flex flex-col">
                                <span className={e.netTransactionLocal >= 0 ? "text-[#00FF00] font-bold" : "text-red-500 font-bold"}>
                                  {e.symbol}{Math.abs(e.netTransactionLocal).toFixed(1)}M
                                </span>
                                <span className="text-[10px] text-[#555]">
                                  Rec: {original.transactionReceivables} / Pay: {original.transactionPayables}
                                </span>
                              </div>
                            </td>
                            
                            {/* Translation */}
                            <td className="p-3 text-right font-mono">
                              <div className="flex flex-col">
                                <span className={e.netTranslationLocal >= 0 ? "text-[#00FF00]" : "text-red-500"}>
                                  {e.symbol}{Math.abs(e.netTranslationLocal).toFixed(1)}M
                                </span>
                                <span className="text-[10px] text-[#555]">
                                  Ast: {original.translationAssets} / Lia: {original.translationLiabilities}
                                </span>
                              </div>
                            </td>

                            {/* Economic */}
                            <td className="p-3 text-right font-mono">
                              <div className="flex flex-col">
                                <span className={e.netEconomicLocal >= 0 ? "text-[#00FF00]" : "text-red-500"}>
                                  {e.symbol}{Math.abs(e.netEconomicLocal).toFixed(1)}M
                                </span>
                                <span className="text-[10px] text-[#555]">
                                  Rev: {original.economicRevenue} / Cst: {original.economicCost}
                                </span>
                              </div>
                            </td>
                            
                            {/* Consolidated Total Net in USD Millions */}
                            <td className="p-3 text-right font-mono font-bold bg-[#050505] text-[#F27D26] border-l border-[#222]">
                              <div className="text-right">
                                {formatUSD(e.totalNetUSD)}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Adjust Exposure Quick Forms */}
                <div className="bg-[#050505] p-4 border border-[#222] rounded">
                  <h3 className="text-xs font-bold font-mono uppercase text-[#888] mb-3 flex items-center gap-1.5">
                    <Sliders className="h-3.5 w-3.5 text-[#F27D26]" />
                    Modify Local Ledger Exposures (Millions)
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {currencyExposures.map(c => (
                      <div key={c.currency} className="bg-[#0a0a0a] border border-[#222] rounded p-3 text-xs space-y-2">
                        <span className="font-bold text-[#e0e0e0] font-mono block border-b border-[#222] pb-1">{c.currency} Exposure Channels</span>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-[#888] font-mono text-[11px]">Tx Receivables</span>
                          <input 
                            type="number" 
                            className="p-1 bg-[#050505] border border-[#333] rounded text-right w-16 font-mono text-[#F27D26] outline-none focus:border-[#F27D26]"
                            value={c.transactionReceivables}
                            onChange={(e) => handleExpLocalAdjust(c.currency, "receivables", parseFloat(e.target.value) || 0)}
                          />
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[#888] font-mono text-[11px]">Tx Payables</span>
                          <input 
                            type="number" 
                            className="p-1 bg-[#050505] border border-[#333] rounded text-right w-16 font-mono text-[#F27D26] outline-none focus:border-[#F27D26]"
                            value={c.transactionPayables}
                            onChange={(e) => handleExpLocalAdjust(c.currency, "payables", parseFloat(e.target.value) || 0)}
                          />
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-[#888] font-mono text-[11px]">Translation Assets</span>
                          <input 
                            type="number" 
                            className="p-1 bg-[#050505] border border-[#333] rounded text-right w-16 font-mono text-[#F27D26] outline-none focus:border-[#F27D26]"
                            value={c.translationAssets}
                            onChange={(e) => handleExpLocalAdjust(c.currency, "assets", parseFloat(e.target.value) || 0)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Risk VaR & CVaR Benchmark Engines Card Grid */}
                <div>
                  <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-1.5">
                    <BarChart3 className="h-4 w-4 text-[#F27D26]" />
                    FX Portfolio Risk Quantification ({simulationParams.steps}-day holding period)
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Method 1: Parametric */}
                    <div className="bg-[#050505] border border-[#222] rounded p-4 relative overflow-hidden">
                      <div className="absolute right-0 top-0 h-16 w-16 bg-[#0a0a0a]/50 rounded-bl-full flex items-center justify-center pointer-events-none border-l border-b border-[#222]/20">
                        <span className="text-[#555] font-mono font-bold text-xs">PARA</span>
                      </div>
                      <span className="text-[10px] bg-[#1a1a1a] text-[#888] font-mono font-extrabold px-1.5 py-0.5 rounded tracking-wide uppercase border border-[#222]">
                        Parametric Covariance
                      </span>
                      <h4 className="font-sans font-semibold text-white mt-2 text-sm">
                        Analytical Normal Engine
                      </h4>
                      <p className="text-[11px] text-[#888] pb-3">Derives log-normal loss limits from empirical correlations daily covariance.</p>
                      
                      <div className="space-y-2 border-t border-[#222] pt-3">
                        <div className="flex justify-between items-end">
                          <span className="text-xs text-[#888]">Value-at-Risk ({(simulationParams.confidenceLevel*100)}%)</span>
                          <span className="font-mono text-sm font-extrabold text-red-400">
                            {formatUSDSimple(varCalculationsBench.parametric.varValue)}
                          </span>
                        </div>
                        <div className="flex justify-between items-end">
                          <span className="text-xs text-[#888]">Expected Shortfall (CVaR)</span>
                          <span className="font-mono text-sm font-extrabold text-[#F27D26]">
                            {formatUSDSimple(varCalculationsBench.parametric.cvarValue)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Method 2: Historical */}
                    <div className="bg-[#050505] border border-[#222] rounded p-4 relative overflow-hidden">
                      <div className="absolute right-0 top-0 h-16 w-16 bg-[#0a0a0a]/50 rounded-bl-full flex items-center justify-center pointer-events-none border-l border-b border-[#222]/20">
                        <span className="text-[#555] font-mono font-bold text-xs">HIST</span>
                      </div>
                      <span className="text-[10px] bg-[#1a1a1a] text-[#888] font-mono font-extrabold px-1.5 py-0.5 rounded tracking-wide uppercase border border-[#222]">
                        Historical Bootstrap
                      </span>
                      <h4 className="font-sans font-semibold text-white mt-2 text-sm">
                        Empirical Re-run Engine
                      </h4>
                      <p className="text-[11px] text-[#888] pb-3">Bootstrap simulates returns using the actual 120-day historical window distribution.</p>
                      
                      <div className="space-y-2 border-t border-[#222] pt-3">
                        <div className="flex justify-between items-end">
                          <span className="text-xs text-[#888]">Value-at-Risk ({(simulationParams.confidenceLevel*100)}%)</span>
                          <span className="font-mono text-sm font-extrabold text-red-400">
                            {formatUSDSimple(varCalculationsBench.historical.varValue)}
                          </span>
                        </div>
                        <div className="flex justify-between items-end">
                          <span className="text-xs text-[#888]">Expected Shortfall (CVaR)</span>
                          <span className="font-mono text-sm font-extrabold text-[#F27D26]">
                            {formatUSDSimple(varCalculationsBench.historical.cvarValue)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Method 3: Monte Carlo */}
                    <div className="bg-[#050505] border border-[#F27D26]/40 rounded p-4 relative overflow-hidden">
                      <div className="absolute right-0 top-0 h-16 w-16 bg-[#F27D26]/10 rounded-bl-full flex items-center justify-center pointer-events-none border-l border-b border-[#F27D26]/10">
                        <span className="text-[#F27D26]/50 font-mono font-bold text-xs">M-C</span>
                      </div>
                      <span className="text-[10px] bg-[#F27D26]/10 text-[#F27D26] font-mono font-extrabold px-1.5 py-0.5 rounded tracking-wide uppercase border border-[#F27D26]/20">
                        Monte Carlo (Projected)
                      </span>
                      <h4 className="font-sans font-semibold text-[#e0e0e0] mt-2 text-sm">
                        Stochastic Path Simulator
                      </h4>
                      <p className="text-[11px] text-[#888] pb-3">Projects {simulationParams.pathsCount} randomized path matrices on the {simulationParams.stochasticModel} curve.</p>
                      
                      <div className="space-y-2 border-t border-[#F27D26]/30 pt-3">
                        <div className="flex justify-between items-end">
                          <span className="text-xs text-[#888]">Value-at-Risk ({(simulationParams.confidenceLevel*100)}%)</span>
                          <span className="font-mono text-base font-black text-red-400">
                            {formatUSDSimple(mcResults.varValue)}
                          </span>
                        </div>
                        <div className="flex justify-between items-end">
                          <span className="text-xs text-[#888]">Expected Shortfall (CVaR)</span>
                          <span className="font-mono text-sm font-extrabold text-[#F27D26]">
                            {formatUSDSimple(mcResults.cvarValue)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dashboard bottom explanation warning */}
                <div className="flex gap-2.5 p-3.5 bg-[#050505] border border-[#222] rounded text-xs leading-normal font-sans text-[#888]">
                  <Info className="h-5 w-5 text-[#F27D26] shrink-0" />
                  <div>
                    <span className="font-bold text-white block mb-0.5">Quant Analyst Interpretation Ledger</span>
                    Because the portfolio total position contains a massive long EUR value ($\approx$ +134M Net USD) but short positions in GBP and JPY exposures, the consolidated VaR depends heavily on correlation offsets. High volatilities in EUR/USD will significantly drive tail risk, while the negative correlation offset of JPY serves as an incremental safe-haven hedge. 
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 2: STOCHASTIC MODELS PATHS PLOTTINGS */}
            {activeTab === "stochastic" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-bold text-white">Multi-Path Stochastic FX Simulations</h2>
                  <p className="text-xs text-[#888]">
                    Calculates paths dynamically under {simulationParams.stochasticModel === "GBM" ? "Geometric Brownian Motion (GBM)" : "Ornstein-Uhlenbeck (Pegged Reverting)"} assumptions.
                  </p>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  {/* spaghetti paths visualization */}
                  <div className="xl:col-span-2 border border-[#222] rounded p-4 min-h-[300px] bg-[#050505]">
                    <h3 className="text-xs font-bold font-mono text-[#888] uppercase tracking-wide mb-3">
                      Stochastic Spaghetti Projections Trace (EUR Normalized to 1.0)
                    </h3>
                    
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={spaghettiPlotData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                          <CartesianGrid stroke="#1a1a1a" strokeDasharray="3 3" />
                          <XAxis dataKey="name" stroke="#555" fontSize={9} label={{ value: "Risk Horizon Days", position: "insideBottom", offset: -2, fill: "#888" }} />
                          <YAxis stroke="#555" fontSize={9} domain={['auto', 'auto']} label={{ value: "Relative asset price s_t/s_0", angle: -90, position: "insideLeft", offset: 10, fill: "#888" }} />
                          <Tooltip labelFormatter={(v) => `Simulation step: ${v}`} contentStyle={{ fontSize: "11px", backgroundColor: "#0a0a0a", borderColor: "#222", color: "#e0e0e0" }} />
                          
                          {/* Render Spaghetti Lines */}
                          {Array.from({ length: 10 }).map((_, idx) => (
                            <Line 
                              key={`eur_p${idx}`}
                              type="monotone" 
                              dataKey={`EUR_P${idx}`} 
                              stroke={idx === 0 ? "#F27D26" : "#222"} 
                              strokeWidth={idx === 0 ? 2 : 0.8}
                              dot={false}
                              activeDot={false}
                            />
                          ))}
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <span className="text-[10px] text-[#555] font-mono mt-2 block">
                      * Highlights path #0 in orange to denote random sample trajectory. Path horizon is sliced across daily discrete increments.
                    </span>
                  </div>

                  {/* loss distribution histogram */}
                  <div className="border border-[#222] rounded p-4 bg-[#050505]">
                    <h3 className="text-xs font-bold font-mono text-[#888] uppercase tracking-wide mb-3">
                      Path P&amp;L Tail Distribution (Loss Matrix)
                    </h3>
                    
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={lossHistogramData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                          <CartesianGrid stroke="#1a1a1a" strokeDasharray="3 3" />
                          <XAxis dataKey="binCenter" stroke="#555" fontSize={8} />
                          <YAxis stroke="#555" fontSize={9} />
                          <Tooltip contentStyle={{ fontSize: "11px", backgroundColor: "#0a0a0a", borderColor: "#222", color: "#e0e0e0" }} />
                          <Bar dataKey="count" fill="#F27D26" opacity={0.8} radius={[2, 2, 0, 0]} name="Paths frequency" />
                          
                          <ReferenceLine x={(mcResults.varValue * -1).toFixed(2) + "M"} stroke="#FF5555" strokeWidth={1.5} label={{ value: "VaR", position: "top", fill: "#ef4444", fontSize: 9 }} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-2 text-xs pt-1 border-t border-[#222]">
                      <div className="flex justify-between font-mono">
                        <span className="text-[#888]">Total Paths Run</span>
                        <span className="font-bold text-white">{simulationParams.pathsCount}</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-[#888]">Worst Case Path Loss</span>
                        <span className="font-bold text-red-500">
                          ${mcResults.scenariosLosses[mcResults.scenariosLosses.length - 1].toFixed(2)}M
                        </span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-[#888]">Best Case Path Profit</span>
                        <span className="font-bold text-[#00FF00]">
                          ${Math.abs(mcResults.scenariosLosses[0]).toFixed(2)}M
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 3: INTEREST TIME PARITY DETS CIP & UIP */}
            {activeTab === "parity" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-bold text-white">Amortization of Interest Rate Parities (CIP / UIP)</h2>
                  <p className="text-xs text-[#888]">Detects deviations between market forward quotes and CIP theoretical pricing, identifying shadow premiums.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {parityMetrics.map(pm => {
                    const isStress = pm.stressLevel !== "Low (Stable)";
                    return (
                      <div key={pm.currency} className="bg-[#050505] border border-[#222] rounded p-4 space-y-4">
                        <div className="flex items-center justify-between border-b border-[#222] pb-2">
                          <span className="font-sans font-bold text-base text-white">{pm.currency}/USD Suite</span>
                          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${isStress ? "bg-red-500/10 text-red-400 border-red-500/20" : "bg-green-500/10 text-green-300 border-green-500/20"}`}>
                            {pm.stressLevel}
                          </span>
                        </div>
                        
                        {/* CIP block */}
                        <div>
                          <span className="text-[10px] uppercase font-bold text-[#888] font-mono tracking-wider block mb-2">Covered Interest Parity (3M)</span>
                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between">
                              <span className="text-[#888]">Actual Market Spot</span>
                              <span className="font-mono text-[#e0e0e0]">{pm.actualSpot.toFixed(pm.currency === "JPY" ? 5 : 4)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-[#888]">CIP Theoretical Forward</span>
                              <span className="font-mono text-[#e0e0e0]">{pm.theoreticalForward.toFixed(pm.currency === "JPY" ? 5 : 4)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-[#888]">Actual Market Forward</span>
                              <span className="font-mono text-white font-semibold">{pm.actualForward.toFixed(pm.currency === "JPY" ? 5 : 4)}</span>
                            </div>
                            
                            <hr className="border-[#222] my-1" />
                            
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-[#888]">Shadow Funding Basis</span>
                              <span className="font-mono font-extrabold text-[#F27D26]">
                                {pm.impliedBasisSpreadBps.toFixed(2)} bps
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* UIP block */}
                        <div className="bg-[#0a0a0a] p-2.5 rounded border border-[#222]">
                          <span className="text-[10px] uppercase font-bold text-[#888] font-mono tracking-wider block mb-1.5">Uncovered Interest Parity (60D Fama)</span>
                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between">
                              <span className="text-[#888]">Fama Empirical Beta (β)</span>
                              <span className="font-mono font-bold text-red-400">{pm.uipBeta.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-[#888]">Parity Condition holds?</span>
                              <span className="font-mono font-bold text-red-500">FALSE (β ≠ 1.0)</span>
                            </div>
                          </div>
                          <span className="text-[9px] text-[#555] font-sans block mt-1.5 leading-normal">
                            * Negative beta indicates a severe failure of UIP (Forward Premium Puzzle). Investing in high-yield currencies yields systematic carry returns.
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="p-4 bg-[#050505] border border-[#222] rounded">
                  <h3 className="font-sans font-bold text-white text-sm mb-1.5 flex items-center gap-1.5">
                    <HelpCircle className="h-4 w-4 text-[#F27D26]" />
                    How to Interpret Parity Deviations &amp; Basis Spreads
                  </h3>
                  <div className="text-xs leading-normal font-sans text-[#888] space-y-2">
                    <p>
                      <strong>Covered Interest Parity (CIP)</strong> is a mathematical identity that must theoretically hold to prevent risk-free arbitrage. In practice, however, **Cross-Currency Basis Spreads** reappear. If the JPY/USD basis is highly negative (e.g., -40 basis points), it implies that synthetic US dollar borrowing via FX swaps is significantly more expensive than standard cash US cash markets. This premium reflects structural dollar deficits in offshore balance sheets, regulatory balance-sheet constraints, and capital market frictions.
                    </p>
                    <p>
                      <strong>Uncovered Interest Parity (UIP)</strong> suggests that currencies with high interest rates should depreciate to offset the interest yield advantage. However, empirical studies show that carry and spot returns are negatively correlated (&beta;_Fama &lt; 0). This constitutes the <strong>Forward Premium Puzzle</strong>, which institutional macro managers exploit to collect systematic carry risk-premiums under stable volatility regimes.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 4: HEDGING STRATEGY BACKTESTING SIMULATOR */}
            {activeTab === "hedging" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#222] pb-4 gap-4">
                  <div>
                    <h2 className="text-lg font-bold text-white">FX Derivative Hedging Simulation</h2>
                    <p className="text-xs text-[#888]">Backtests derivative strategies (Forwards) comparing locked results to dynamic rolling hedges.</p>
                  </div>
                  
                  {/* Select currency for simulator */}
                  <div className="flex gap-2">
                    {["EUR", "GBP", "JPY"].map(cur => (
                      <button
                        key={cur}
                        onClick={() => {
                          setSelectedHedgeCurrency(cur as any);
                          const matched = currencyExposures.find(e => e.currency === cur)!;
                          setHedgingExposureVal(Math.abs(matched.transactionReceivables - matched.transactionPayables) || 10.0);
                        }}
                        className={`px-3 py-1.5 border rounded text-xs transition font-mono ${selectedHedgeCurrency === cur ? "bg-[#F27D26] text-black border-[#F27D26] font-bold shadow-[0_0_8px_rgba(242,125,38,0.2)]" : "bg-[#050505] text-[#888] hover:bg-[#111] border-[#222]"}`}
                      >
                        {cur}/USD Simulation
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
                  
                  {/* controls sub-panel */}
                  <div className="bg-[#050505] border border-[#222] rounded p-4 space-y-4 text-xs lg:col-span-1">
                    <span className="font-mono text-[10px] text-[#888] font-bold uppercase tracking-wide block">Hedge Parameters</span>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-[#888]">Hedged Exposure Size</span>
                        <span className="font-mono font-bold text-white">{hedgingExposureVal.toFixed(1)}M {selectedHedgeCurrency}</span>
                      </div>
                      <input 
                        type="number" 
                        value={hedgingExposureVal}
                        onChange={(e) => setHedgingExposureVal(parseFloat(e.target.value) || 0)}
                        className="w-full p-1 bg-[#050505] border border-[#333] rounded text-right font-mono text-xs text-[#F27D26] outline-none focus:border-[#F27D26]"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-[#888]">Target Hedge Ratio</span>
                        <span className="font-mono font-bold text-[#F27D26]">{(currentHedgeRatio * 100).toFixed(0)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0.10" 
                        max="1.0" 
                        step="0.05" 
                        value={currentHedgeRatio}
                        onChange={(e) => setCurrentHedgeRatio(parseFloat(e.target.value))}
                        className="w-full h-1 bg-[#1a1a1a] rounded appearance-none cursor-pointer accent-[#F27D26]"
                      />
                    </div>

                    {/* statistics readout */}
                    <div className="pt-3 border-t border-[#222] space-y-2">
                      <span className="font-mono text-[10px] text-[#555] font-semibold uppercase tracking-wider block">Performance Log</span>
                      <div className="space-y-1.5 font-mono text-[11px]">
                        <div className="flex justify-between">
                          <span className="text-[#888]">Unhedged Volatility</span>
                          <span className="text-[#e0e0e0] font-semibold">${hedgingSimData.metrics.volatilityUnhedged.toFixed(3)}M</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#888]">100% Locked Volatility</span>
                          <span className="text-[#e0e0e0] font-semibold">${hedgingSimData.metrics.volatilityFull.toFixed(3)}M</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#888]">Hedged Volatility</span>
                          <span className="text-[#F27D26] font-bold">${hedgingSimData.metrics.volatilityPartial.toFixed(3)}M</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* visualization charts */}
                  <div className="lg:col-span-3 space-y-4">
                    <div className="border border-[#222] rounded p-4 bg-[#050505]">
                      <h3 className="text-xs font-bold font-mono text-[#888] uppercase tracking-wide mb-3">
                        Cumulative Backtest Strategy Asset P&amp;L (USD Millions)
                      </h3>
                      
                      <div className="h-60">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={hedgingSimData.data} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                            <CartesianGrid stroke="#1a1a1a" strokeDasharray="3 3" />
                            <XAxis dataKey="step" stroke="#555" fontSize={9} label={{ value: "Backtest Days", position: "insideBottom", offset: -3, fill: "#888" }} />
                            <YAxis stroke="#555" fontSize={9} label={{ fill: "#888" }} />
                            <Tooltip contentStyle={{ fontSize: "11px", backgroundColor: "#0a0a0a", borderColor: "#222", color: "#e0e0e0" }} />
                            <Legend verticalAlign="top" height={36} iconSize={10} wrapperStyle={{ fontSize: "11px" }} />
                            <Line type="monotone" dataKey="pnlUnhedged" stroke="#FF5555" name="1. Unhedged P&L" dot={false} strokeWidth={1.5} />
                            <Line type="monotone" dataKey="pnlFullHedge" stroke="#00FF00" name="2. 100% Locked Forward" dot={false} strokeWidth={1.5} />
                            <Line type="monotone" dataKey="pnlPartialHedge" stroke="#F27D26" name={`3. Partially Hedged (${(currentHedgeRatio*100)}%)`} dot={false} strokeWidth={2} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* performance dashboards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 border border-green-500/10 bg-green-500/5 rounded">
                        <span className="text-[10px] uppercase font-bold text-green-400 font-mono tracking-wider block">Full Lock Effectiveness</span>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xs text-[#888]">Hedge Effectiveness Ratio (HER)</span>
                          <span className="font-mono text-lg font-black text-green-300">
                            {hedgingSimData.metrics.herFull.toFixed(3)}
                          </span>
                        </div>
                        <p className="text-[10px] text-[#555] mt-1">
                          HER = 1.00 indicates zero volatility leakage. Flat locks secure 100% of underlying cash-flows but completely sacrifice positive upside.
                        </p>
                      </div>

                      <div className="p-4 border border-[#F27D26]/10 bg-[#F27D26]/5 rounded">
                        <span className="text-[10px] uppercase font-bold text-[#F27D26] font-mono tracking-wider block">Partial Hedge Volatility Reduction</span>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xs text-[#888]">Portfolio Variance Deflated</span>
                          <span className="font-mono text-lg font-black text-[#F27D26]">
                            {hedgingSimData.metrics.volReductionPartialPct.toFixed(1)}%
                          </span>
                        </div>
                        <p className="text-[10px] text-[#555] mt-1">
                          Mitigates structural downshifts while keeping {(100 - currentHedgeRatio * 100).toFixed(0)}% of potential macro currency appreciation.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 5: MACRO STRESS SHOCK TESTERS */}
            {activeTab === "stress" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-bold text-white">Macro Stress Scenario Analysis</h2>
                  <p className="text-xs text-[#888]">Propagates systemic economic crises and historical shocks across consolidated currency net exposures.</p>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  {/* scen detail selectors */}
                  <div className="space-y-4 xl:col-span-1">
                    <span className="font-mono text-[10px] text-[#555] font-bold uppercase tracking-wider block">Crisis Environments Menu</span>
                    
                    <div className="space-y-3">
                      {stressLossSummaries.map(sc => {
                        const isSevere = sc.totalLossUSD > 10.0;
                        return (
                          <div 
                            key={sc.id} 
                            className="p-3 border border-[#222] rounded hover:border-[#F27D26]/40 transition cursor-default bg-[#050505]"
                          >
                            <div className="flex justify-between items-start mb-1 gap-2">
                              <span className="font-semibold text-[#e0e0e0] text-xs">{sc.name}</span>
                              <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border shrink-0 ${isSevere ? "bg-red-500/10 text-red-400 border-red-500/20 font-extrabold" : "bg-[#F27D26]/15 text-[#F27D26] border-[#F27D26]/20"}`}>
                                {isSevere ? "SEVERE THREAT" : "ELEVATED"}
                              </span>
                            </div>
                            <p className="text-[10px] text-[#888] leading-normal mb-2">{sc.description}</p>
                            <div className="flex justify-between items-baseline pt-2 border-t border-[#222] font-mono text-xs">
                              <span className="text-[#555]">Net Portfolio Loss</span>
                              <span className="font-extrabold text-red-400">
                                {formatUSDSimple(sc.totalLossUSD)}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* granular table representation */}
                  <div className="xl:col-span-2 border border-[#222] rounded p-4 space-y-4 bg-[#050505]">
                    <h3 className="text-xs font-bold font-mono text-[#888] uppercase tracking-wide">
                      Granular Shock Impact Decomposition (USD Millions)
                    </h3>
                    
                    <div className="space-y-4">
                      {stressLossSummaries.map(sc => (
                        <div key={sc.id} className="bg-[#0a0a0a] p-3 rounded border border-[#222] text-xs">
                          <span className="font-bold text-white font-mono block mb-2">{sc.name} Itemized Losses</span>
                          
                          <div className="grid grid-cols-3 gap-2 text-center text-[10px] pb-1.5 border-b border-[#222] text-[#555] font-semibold font-mono uppercase">
                            <span>Currency Position</span>
                            <span>Applied Shock (%)</span>
                            <span>Asset P&amp;L impact</span>
                          </div>
                          <div className="divide-y divide-[#222]">
                            {sc.itemized.map(it => {
                              const shockVal = STRESS_SCENARIOS.find(s => s.id === sc.id)?.shocks[it.currency] || 0;
                              return (
                                <div key={it.currency} className="grid grid-cols-3 gap-2 py-2 text-center font-mono align-middle font-bold">
                                  <span className="text-[#888]">{it.currency}/USD</span>
                                  <span className={shockVal >= 0 ? "text-green-400" : "text-red-400"}>
                                    {(shockVal * 100).toFixed(0)}%
                                  </span>
                                  <span className={it.lossUSD >= 0 ? "text-red-400" : "text-[#00FF00]"}>
                                    {it.lossUSD >= 0 ? "-" : "+"}${Math.abs(it.lossUSD).toFixed(2)}M
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
                   {/* TAB 6: R MODULAR ENGINE CODE VIEW & COPY-PASTE */}
            {activeTab === "rScripts" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6 animate-fade-in"
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#222] pb-4 gap-4">
                  <div>
                    <h2 className="text-lg font-bold text-white">Production R Workspace &amp; SDK</h2>
                    <p className="text-xs text-[#888]">Review, explore, and copy the actual quantitative modular R scripts written inside the workspace directories.</p>
                  </div>
                  
                  {/* copy code button */}
                  <button
                    onClick={() => handleCopyCode(rScriptsCollection[selectedRScriptIdx].code)}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-[#1a1a1a] border border-[#333] text-[#e0e0e0] hover:border-[#F27D26] hover:text-[#F27D26] transition text-xs font-medium rounded shadow-sm"
                  >
                    {copiedStatus ? (
                      <>
                        <Check className="h-4 w-4 text-green-400" />
                        Code Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 text-[#F27D26]" />
                        Copy Raw R Script
                      </>
                    )}
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
                  
                  {/* script index */}
                  <div className="lg:col-span-1 space-y-2">
                    <span className="font-mono text-[10px] text-[#555] font-bold uppercase tracking-wider block">Script Directory Module</span>
                    
                    <div className="space-y-1.5 font-mono text-xs">
                      {rScriptsCollection.map((script, idx) => (
                        <button
                          key={script.filename}
                          onClick={() => setSelectedRScriptIdx(idx)}
                          className={`w-full text-left p-2.5 rounded border transition flex flex-col ${selectedRScriptIdx === idx ? "bg-[#0a0a0a] text-[#F27D26] border-[#F27D26]/40 shadow" : "bg-[#050505] text-[#888] hover:bg-[#0a0a0a] hover:text-white border-[#222]"}`}
                        >
                          <span className="font-bold">{script.filename}</span>
                          <span className="text-[10px] text-[#555] font-sans truncate block w-full mt-0.5">{script.path}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* source code viewport */}
                  <div className="lg:col-span-3 space-y-4">
                    <div className="p-3 bg-[#0a0a0a] border border-[#222] rounded text-xs leading-normal">
                      <span className="font-bold text-white block mb-1">Module Description</span>
                      <p className="text-[#888] font-sans">{rScriptsCollection[selectedRScriptIdx].description}</p>
                    </div>

                    <div className="rounded overflow-hidden border border-[#222] bg-[#050505] shadow-inner relative">
                      <div className="bg-[#0a0a0a] px-4 py-2 border-b border-[#222] font-mono text-[10px] text-[#555] flex items-center justify-between">
                        <span>R-CODE COMPANION CORE // {rScriptsCollection[selectedRScriptIdx].filename}</span>
                        <span className="h-2 w-2 rounded-full bg-[#F27D26]"></span>
                      </div>
                      
                      <pre className="p-4 md:p-6 text-[#e0e0e0] font-mono text-xs leading-relaxed overflow-x-auto max-h-[480px]">
                        <code>{rScriptsCollection[selectedRScriptIdx].code}</code>
                      </pre>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 7: QUANT THEORY & CASE STUDY GUIDE */}
            {activeTab === "guide" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-6 text-xs md:text-sm leading-relaxed max-w-4xl"
              >
                <div>
                  <h2 className="text-lg font-bold text-white">FX Quantitative Risk Theory Guide</h2>
                  <p className="text-xs text-[#888]">Comprehensive summary of mathematical equations, limits of GARCH engines, and institutional case studies.</p>
                </div>

                <div className="space-y-6 font-sans text-[#888]">
                  <section className="space-y-2">
                    <h3 className="font-bold text-white border-b border-[#222] pb-1 text-sm flex items-center gap-1.5">
                      <span className="h-5 w-5 bg-[#1a1a1a] text-[#F27D26] border border-[#222] text-[11px] font-bold rounded-full flex items-center justify-center">1</span>
                      Covered Interest Parity (CIP) Deviations (Basis Spread Risk)
                    </h3>
                    <p>
                      The standard Covered Interest Parity (CIP) holds that forward exchange premiums should perfectly offset nominal interest differentials between currencies:
                    </p>
                    <div className="p-3 bg-[#0a0a0a] border border-[#222] rounded font-mono text-[#F27D26] text-center select-all">
                      F = S * (1 + r_domestic * t) / (1 + r_foreign * t)
                    </div>
                    <p>
                      If a difference remains, arbitrageurs should step in, borrow the cheap currency, hedge it via forwards, and make risk-free profit. However, since the 2008 financial crisis, the **Cross-Currency Basis Spread ($\Delta$)** has emerged as a permanent market fixture. It tracks the premium or discount demanded to swap foreign currencies for physical cash dollars. A negative JPY/USD basis means offshore banks are paying extreme surcharges to secure synthetic dollar lines. Under stress (e.g. quarter-end balance sheet window-dressing), this basis widens, indicating systemic offshore funding bottlenecks.
                    </p>
                  </section>

                  <section className="space-y-2">
                    <h3 className="font-bold text-white border-b border-[#222] pb-1 text-sm flex items-center gap-1.5">
                      <span className="h-5 w-5 bg-[#1a1a1a] text-[#F27D26] border border-[#222] text-[11px] font-bold rounded-full flex items-center justify-center">2</span>
                      Uncovered Interest Parity (UIP) &amp; Forward Premium Puzzle
                    </h3>
                    <p>
                      Unlike CIP, Uncovered Interest Parity is an expectational hypothesis: high-yield interest currencies are expected to depreciate exactly to the level where expected total cross-border returns are equalized. Empirically, regressions of Spot Changes on interest differentials yields the Fama Regression puzzle:
                    </p>
                    <div className="p-3 bg-[#0a0a0a] border border-[#222] rounded font-mono text-[#F27D26] text-center select-all">
                      ln(S_(t+k) / S_t) = alpha + beta * (r_d - r_f) + epsilon
                    </div>
                    <p>
                      Under efficiency, we expect $\beta = 1.0$. However, international macro tests consistently find $\beta &lt; 0$. This implies high-interest currencies *appreciate* or remain flat over time, leading to massive carry trade rewards. But these rewards are compensated by extreme skewness—carry trade profiles are described as \&quot;climbing the stairs and taking foreign elevators down\&quot; during risk-off asset corrections.
                    </p>
                  </section>

                  <section className="space-y-2">
                    <h3 className="font-bold text-white border-b border-[#222] pb-1 text-sm flex items-center gap-1.5">
                      <span className="h-5 w-5 bg-[#1a1a1a] text-[#F27D26] border border-[#222] text-[11px] font-bold rounded-full flex items-center justify-center">3</span>
                      Evaluating Value-at-Risk (VaR) &amp; Expected Shortfall (CVaR)
                    </h3>
                    <p>
                      <strong>Value-at-Risk (VaR)</strong> represents the maximum potential loss over a holding horizon (T days) at a given confidence limit ($\alpha$). For example, a 10-day 95% VaR of \$5M USD indicates that there is a 5% chance of the cash portfolio suffering a loss *greater than* \$5M over a 10-day trading window.
                    </p>
                    <p>
                      <strong>Expected Shortfall (CVaR)</strong> is mathematically superior as it is coherent (respects sub-additivity). It answers the critical tail failure query: *\&quot;If we experience an extreme day exceeding our VaR limit, what is the expected average loss of that catastrophe?\&quot;*
                    </p>
                    <p>
                      The normal parametric method assumes Gaussian returns, frequently underestimating fat tail events. The historic bootstrap preserves true historical fat tails but assumes the future mirrors the immediate past. Cholesky Monte Carlo simulations generate paths that align with historical correlations and covariance, accommodating regime shifting shocks.
                    </p>
                  </section>

                  <section className="space-y-2">
                    <h3 className="font-bold text-white border-b border-[#222] pb-1 text-sm flex items-center gap-1.5">
                      <span className="h-5 w-5 bg-[#1a1a1a] text-[#F27D26] border border-[#222] text-[11px] font-bold rounded-full flex items-center justify-center">4</span>
                      Corporate Treasury Use-Cases
                    </h3>
                    <ul className="list-disc list-inside space-y-1.5 pl-2 text-[#888]">
                      <li>
                        <strong>Exposure Minimization:</strong> Consolidating translation and transaction channels across foreign subsidiaries to establish unified net net hedging requirements.
                      </li>
                      <li>
                        <strong>Cost-Efficient Hedging:</strong> Adjusting hedge ratios (e.g., dynamic 75%) based on active volatility regimes. Stable low-vol regimes require less hedging premium, while high-vol, wide-basis regimes require locking forwards or buying protective puts.
                      </li>
                      <li>
                        <strong>Funding Sourcing Optimization:</strong> Looking at cross-currency basis spreads to raise capital in cheap foreign paper (e.g. Samurai bonds in JPY) and swap it back to USD synthetically at negative bases.
                      </li>
                    </ul>
                  </section>
                </div>
              </motion.div>
            )}

          </div>

        </div>

        {/* Footer Bar */}
        <footer className="border-t border-[#222] bg-[#050505] py-8 mt-12 text-xs text-center font-mono text-[#555]">
          <p className="tracking-wide">
            Currency Risk Analytics Engine © 2026 AI Studio Institutional Risk Systems. Developed in modular R and React.
          </p>
          <p className="text-[10.5px] mt-1.5 text-[#333]">
            Quant mathematical algorithms adhere strictly to IAS 39 / IFRS 9 hedge accounting qualification boundaries.
          </p>
        </footer>

      </div>
    </div>
  );
}
