/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RScriptModule } from "../types";

export const rScriptsCollection: RScriptModule[] = [
  {
    filename: "main.R",
    path: "fx-risk-engine/main.R",
    description: "Applet global entry-point. Coordinates data ingestion, stochastic models, parity checks, VaR estimates, hedging simulations, basis stress tests, and regime shifts.",
    code: `#' Currency Risk Analytics Engine: Main Orchestrator
#' @description Central entry point to wire raw observations ingestion, stochastic modelling,
#' parity checking, value-at-risk estimation, hedging tests, basis screening, and stress runs.

# Source modular engine components
source("scripts/ingestion.R")
source("scripts/fx_model.R")
source("scripts/parity.R")
source("scripts/exposure.R")
source("scripts/var_engine.R")
source("scripts/hedging.R")
source("scripts/basis_analysis.R")
source("scripts/stress_testing.R")
source("scripts/regime_detection.R")
source("scripts/visualization.R")

#' Run Consolidated FX Analytics Suite
#' @return A consolidated list containing the full analytics context and risk output reports
run_fx_analytics_engine <- function() {
  cat("========================================================================\\n")
  cat("         CURRENCY RISK ANALYTICS ENGINE (R) -- INITIALIZING ENGINE       \\n")
  cat("========================================================================\\n\\n")
  
  # 1. DATA ENGINE PIPELINE
  market_series <- run_ingestion_pipeline()
  latest_row <- tail(market_series, 1)
  
  eur_spot <- as.numeric(latest_row$EUR_USD_Spot)
  gbp_spot <- as.numeric(latest_row$GBP_USD_Spot)
  jpy_spot <- as.numeric(latest_row$JPY_USD_Spot) # JPY/USD direct
  
  # 2. DEFINE AND CONSOLIDATE PORTFOLIO EXPOSURES
  cat("\\n[EXPOSURE] Aggregating multi-currency exposures...\\n")
  exposure_ledger <- create_exposure_ledger()
  consolidated_exposure <- aggregate_portfolio_exposures(exposure_ledger, eur_spot, gbp_spot, jpy_spot)
  print(consolidated_exposure)
  
  # Net exposures mapping vector
  net_exposures <- consolidated_exposure$Total_Net_USD_M
  names(net_exposures) <- consolidated_exposure$Currency
  
  # 3. INTERST RATE PARITY SCREENING (CIP/UIP)
  cat("\\n[PARITY] Computing CIP basis deviations & funding stress tests...\\n")
  eur_cip_history <- test_historical_cip(market_series, "EUR")
  gbp_cip_history <- test_historical_cip(market_series, "GBP")
  jpy_cip_history <- test_historical_cip(market_series, "JPY")
  
  # Extract latest CIP metrics
  latest_eur_cip <- tail(eur_cip_history, 1)
  cat(sprintf("EUR/USD Basis Spread (Bps): %.2f | Stress Indicator: %.1f bps\\n", 
              latest_eur_cip$Basis_Spread_bps, latest_eur_cip$Stress_Score))
              
  # UIP Regression Analysis
  cat("\\n[PARITY] Evaluating UIP Fama Regressions & Carry Profitability...\\n")
  eur_uip_reg <- test_uip_fama_regression(market_series, "EUR", lag_periods = 60)
  cat(sprintf("EUR UIP Beta Constant: %.4f | Fama Puzzle Present: %s\\n", 
              eur_uip_reg$beta, eur_uip_reg$interpretation))
              
  # 4. STOCHASTIC CALIBRATION & SIMULATION
  cat("\\n[STOCHASTIC] Calibrating GBM params from historical currency returns...\\n")
  eur_ret <- as.numeric(market_series$EUR_USD_Spot_Ret)
  gbp_ret <- as.numeric(market_series$GBP_USD_Spot_Ret)
  jpy_ret <- as.numeric(market_series$JPY_USD_Spot_Ret)
  
  eur_params <- calibrate_gbm(eur_ret)
  gbp_params <- calibrate_gbm(gbp_ret)
  jpy_params <- calibrate_gbm(jpy_ret)
  
  cat(sprintf("EUR Annualized Volatility: %.2f%%\\n", eur_params$sigma * 100))
  cat(sprintf("GBP Annualized Volatility: %.2f%%\\n", gbp_params$sigma * 100))
  cat(sprintf("JPY Annualized Volatility: %.2f%%\\n", jpy_params$sigma * 100))
  
  # 5. RISK VAR & CORRELATION ENGINES
  cat("\\n[VaR ENGINE] Calculating Parametric & Monte Carlo FX VaR (Holding=10 days, Confidence=95%)...\\n")
  returns_cols <- c("EUR_USD_Spot_Ret", "GBP_USD_Spot_Ret", "JPY_USD_Spot_Ret")
  rets_matrix <- cov(as.matrix(na.omit(market_series[, returns_cols])))
  # Rename covariance names to simple currency strings for programmatic matching
  colnames(rets_matrix) <- rownames(rets_matrix) <- c("EUR", "GBP", "JPY")
  
  parametric_metrics <- compute_parametric_var(net_exposures, rets_matrix, confidence_level = 0.95, holding_period = 10)
  cat(sprintf("Parametric VaR (10D): $%.2fM | Expected Shortfall (CVaR): $%.2fM\\n", 
              parametric_metrics$var_holding_period, parametric_metrics$cvar_holding_period))
              
  historical_metrics <- compute_historical_var(net_exposures, market_series, confidence_level = 0.95, holding_period = 10)
  cat(sprintf("Historical VaR (10D): $%.2fM | Expected Shortfall (CVaR): $%.2fM\\n", 
              historical_metrics$var_holding_period, historical_metrics$cvar_holding_period))
              
  # Monte Carlo Simulation (5,000 paths)
  spot_rates_vector <- c(EUR = eur_spot, GBP = gbp_spot, JPY = jpy_spot)
  mc_metrics <- compute_monte_carlo_var(net_exposures, spot_rates_vector, market_series, 
                                        confidence_level = 0.95, steps = 10, paths_count = 5000)
  cat(sprintf("Monte Carlo VaR (10D): $%.2fM | Expected Shortfall (CVaR): $%.2fM\\n", 
              mc_metrics$var_holding_period, mc_metrics$cvar_holding_period))
              
  # 6. HEDGING SIMULATION BACKTESTS
  cat("\\n[HEDGING] Backtesting forward derivatives hedging strategies on EUR Exposure...\\n")
  eur_spots_vec <- as.numeric(market_series$EUR_USD_Spot)
  eur_fwds_vec <- as.numeric(market_series$EUR_USD_Fwd3M)
  
  # Assume EUR transaction exposure of 25.0M EUR
  hedge_sim <- simulate_hedging_strategies(initial_exposure = 25.0, 
                                           spot_series = eur_spots_vec, 
                                           forward_series = eur_fwds_vec, 
                                           hedge_ratio = 0.75)
  cat(sprintf("Full Hedge Variance Reduction: %.2f%% | Hedge Effectiveness Ratio (HER): %.4f\\n", 
              hedge_sim$metrics$vol_reduction_full_pct, hedge_sim$metrics$her_full))
  cat(sprintf("Partial (75%%) Hedge Variance Reduction: %.2f%% | Hedge Effectiveness Ratio (HER): %.4f\\n", 
              hedge_sim$metrics$vol_reduction_partial_pct, hedge_sim$metrics$her_partial))
              
  # 7. CROSS-CURRENCY BASIS INVESTIGATION
  cat("\\n[BASIS] Investigating JPY funding stress points and repo basis spreads...\\n")
  jpy_spots_v <- as.numeric(market_series$JPY_USD_Spot)
  jpy_fwds_v <- as.numeric(market_series$JPY_USD_Fwd3M)
  jpy_rate_v <- as.numeric(market_series$JPY_Rate_3M)
  usd_rate_v <- as.numeric(market_series$USD_Rate_3M)
  
  basis_stress_results <- calculate_systemic_basis_stress(jpy_spots_v, jpy_fwds_v, usd_rate_v, jpy_rate_v, tenor = 0.25)
  latest_basis_stress <- tail(basis_stress_results, 1)
  cat(sprintf("JPY Basis Spread: %.2f Bps | Funding Stress: %s\\n", 
              latest_basis_stress$Basis_Spread_Bps, latest_basis_stress$Funding_Category))
              
  # 8. MACRO STRESS SHOCK SIMULATOR
  cat("\\n[STRESS TEST] Simulating catastrophic macro scenarios on FX portfolio...\\n")
  stress_outcomes <- run_systemic_stress_tests(net_exposures)
  print(stress_outcomes$portfolio_summary)
  
  # 9. MARKET VOLATILITY REGIME CLUSTERING
  cat("\\n[REGIMES] Running clustering models (K-Means) to detect state shifts...\\n")
  # Extract portfolio return series representation
  portfolio_daily_returns_history <- as.numeric(na.omit(rowSums(
    as.matrix(market_series[, c("EUR_USD_Spot_Ret", "GBP_USD_Spot_Ret", "JPY_USD_Spot_Ret")]))))
    
  regime_results <- detect_market_regimes(portfolio_daily_returns_history, window_size = 20, k = 3)
  latest_regime <- tail(regime_results$clustered_data$Regime, 1)
  cat(sprintf("Detected Current Volatility/Trend Market Regime: %s\\n", latest_regime))
  
  cat("\\n========================================================================\\n")
  cat("                CURRENCY RISK ANALYTICS ENGINE RUN COMPLETE              \\n")
  cat("========================================================================\\n")
  
  return(list(
    data_series = market_series,
    exposures = consolidated_exposure,
    uip_regression = eur_uip_reg,
    parametric_var = parametric_metrics,
    historical_var = historical_metrics,
    monte_carlo_var = mc_metrics,
    hedging = hedge_sim,
    basis_analysis = basis_stress_results,
    stress_testing = stress_outcomes,
    regimes = regime_results
  ))
}

# Run execution when invoked directly
if (!interactive()) {
  run_fx_analytics_engine()
}`
  },
  {
    filename: "ingestion.R",
    path: "fx-risk-engine/scripts/ingestion.R",
    description: "Cleans missing currency observations, aligns differing timestamps, computes standard log returns, and sets up a robust mock fx generator for instant local capability.",
    code: `#' Ingestion & Normalization Pipe
library(xts)
library(zoo)
library(tidyverse)

generate_synthetic_market_data <- function(start_date = "2024-01-01", end_date = "2026-05-01") {
  set.seed(42)
  dates <- seq(as.Date(start_date), as.Date(end_date), by = "days")
  dates <- dates[!weekdays(dates) %in% c("Saturday", "Sunday")] # Remove weekends
  n <- length(dates)
  
  eur_spot <- 1.08 + cumsum(rnorm(n, mean = 0.00005, sd = 0.004))
  gbp_spot <- 1.25 + cumsum(rnorm(n, mean = 0.00008, sd = 0.005))
  jpy_sec  <- 150.0 + cumsum(rnorm(n, mean = 0.015, sd = 0.5)) 
  jpy_spot <- 1 / jpy_sec 
  
  usd_ir <- rep(0.0525, n) + cumsum(rnorm(n, mean = 0.00001, sd = 0.0003)) 
  eur_ir <- rep(0.0400, n) + cumsum(rnorm(n, mean = 0.00001, sd = 0.0002)) 
  gbp_ir <- rep(0.0525, n) + cumsum(rnorm(n, mean = 0.00001, sd = 0.00025)) 
  jpy_ir <- rep(0.0025, n) + cumsum(rnorm(n, mean = 0.000005, sd = 0.00005)) 
  
  tau <- 90 / 360
  eur_fwd_theo <- eur_spot * (1 + usd_ir * tau) / (1 + eur_ir * tau)
  gbp_fwd_theo <- gbp_spot * (1 + usd_ir * tau) / (1 + gbp_ir * tau)
  jpy_fwd_theo <- jpy_spot * (1 + usd_ir * tau) / (1 + jpy_ir * tau)
  
  eur_fwd_mkt <- eur_fwd_theo + rnorm(n, mean = -0.0002, sd = 0.0001)
  gbp_fwd_mkt <- gbp_fwd_theo + rnorm(n, mean = -0.0003, sd = 0.0001)
  jpy_fwd_mkt <- jpy_fwd_theo + rnorm(n, mean = -0.00001, sd = 0.000002) 
  
  df_raw <- data.frame(
    Date = dates,
    EUR_USD_Spot = eur_spot,
    GBP_USD_Spot = gbp_spot,
    JPY_USD_Spot = jpy_spot,
    EUR_USD_Fwd3M = eur_fwd_mkt,
    GBP_USD_Fwd3M = gbp_fwd_mkt,
    JPY_USD_Fwd3M = jpy_fwd_mkt,
    USD_Rate_3M = usd_ir,
    EUR_Rate_3M = eur_ir,
    GBP_Rate_3M = gbp_ir,
    JPY_Rate_3M = jpy_ir
  )
  return(df_raw)
}

clean_and_align_raw_data <- function(df) {
  df$Date <- as.Date(df$Date)
  ts_data <- xts(df[, -1], order.by = df$Date)
  
  spots <- c("EUR_USD_Spot", "GBP_USD_Spot", "JPY_USD_Spot", "EUR_USD_Fwd3M", "GBP_USD_Fwd3M", "JPY_USD_Fwd3M")
  rates <- c("USD_Rate_3M", "EUR_Rate_3M", "GBP_Rate_3M", "JPY_Rate_3M")
  
  for (col in spots) {
    ts_data[, col] <- na.locf(ts_data[, col], na.rm = FALSE)
    ts_data[, col] <- na.locf(ts_data[, col], fromLast = TRUE)
  }
  for (col in rates) {
    ts_data[, col] <- na.approx(ts_data[, col], na.rm = FALSE)
    ts_data[, col] <- na.locf(ts_data[, col], na.rm = FALSE)
    ts_data[, col] <- na.locf(ts_data[, col], fromLast = TRUE)
  }
  return(ts_data)
}

compute_log_returns <- function(ts_data, cols = c("EUR_USD_Spot", "GBP_USD_Spot", "JPY_USD_Spot")) {
  for (col in cols) {
    new_col_name <- paste0(col, "_Ret")
    ts_data[, new_col_name] <- diff(log(ts_data[, col]))
    ts_data[1, new_col_name] <- 0
  }
  return(ts_data)
}

run_ingestion_pipeline <- function() {
  raw_df <- generate_synthetic_market_data()
  cleaned_ts <- clean_and_align_raw_data(raw_df)
  return(compute_log_returns(cleaned_ts))
}`
  },
  {
    filename: "fx_model.R",
    path: "fx-risk-engine/scripts/fx_model.R",
    description: "Defines stochastic dynamic engines, comprising continuous Geometric Brownian Motion (GBM) trajectories, Ornstein-Uhlenbeck (mean-reverting pegged models), and GARCH(1,1) cluster volatility simulations.",
    code: `#' Stochastic FX Dynamics Simulators

simulate_gbm <- function(S0, mu, sigma, N, M, dt = 1/252) {
  paths <- matrix(0, nrow = N + 1, ncol = M)
  paths[1, ] <- S0
  for (j in 1:M) {
    z <- rnorm(N)
    for (i in 2:(N + 1)) {
      paths[i, j] <- paths[i - 1, j] * exp((mu - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * z[i - 1])
    }
  }
  return(paths)
}

simulate_ou <- function(S0, theta, mu, sigma, N, M, dt = 1/252) {
  paths <- matrix(0, nrow = N + 1, ncol = M)
  paths[1, ] <- S0
  for (j in 1:M) {
    z <- rnorm(N)
    for (i in 2:(N + 1)) {
      dS <- theta * (mu - paths[i - 1, j]) * dt + sigma * sqrt(dt) * z[i - 1]
      paths[i, j] <- paths[i - 1, j] + dS
      if (paths[i, j] <= 0) paths[i, j] <- 0.0001
    }
  }
  return(paths)
}

simulate_garch_volatility <- function(omega = 0.000005, alpha = 0.08, beta = 0.90, N = 252) {
  h <- numeric(N)
  eps <- numeric(N)
  unconditional_var <- omega / (1 - alpha - beta)
  h[1] <- unconditional_var
  eps[1] <- rnorm(1, mean = 0, sd = sqrt(h[1]))
  
  for (t in 2:N) {
    h[t] <- omega + alpha * (eps[t-1]^2) + beta * h[t-1]
    eps[t] <- rnorm(1, mean = 0, sd = sqrt(h[t]))
  }
  return(sqrt(h))
}

calibrate_gbm <- function(returns) {
  returns <- returns[!is.na(returns)]
  n <- length(returns)
  if (n < 2) return(list(mu = 0.0, sigma = 0.15))
  daily_mean <- mean(returns)
  daily_sd <- sd(returns)
  mu_ann <- daily_mean * 252 + 0.5 * (daily_sd^2) * 252
  sigma_ann <- daily_sd * sqrt(252)
  return(list(mu = mu_ann, sigma = sigma_ann))
}`
  },
  {
    filename: "parity.R",
    path: "fx-risk-engine/scripts/parity.R",
    description: "Evaluates Covered (CIP) and Uncovered (UIP) Parity equations, yielding synthetic basis tracking, cash funding premiums, and carry trade Fama regressions.",
    code: `#' Interest Rate Parity Engine (CIP / UIP)

compute_cip_deviation <- function(S_t, r_d, r_f, F_market, tenor = 0.25) {
  F_theo <- S_t * (1 + r_d * tenor) / (1 + r_f * tenor)
  basis_bps <- (F_market - F_theo) * 10000
  implied_basis_spread_ann <- ((F_market / S_t) * (1 + r_f * tenor) - (1 + r_d * tenor)) / tenor
  basis_spread_bps <- implied_basis_spread_ann * 10000
  
  stress_score <- abs(basis_spread_bps)
  stress_indicator <- "Low (Stable)"
  if (stress_score > 50) {
    stress_indicator <- "Extremely High (Liquidity Crisis)"
  } else if (stress_score > 20) {
    stress_indicator <- "Moderate (Macro Friction)"
  }
  return(list(
    theoretical_fwd = F_theo,
    direct_basis_bps = basis_bps,
    basis_spread_ann_bps = basis_spread_bps,
    stress_score = stress_score,
    stress_indicator = stress_indicator
  ))
}

test_historical_cip <- function(ts_data, currency_prefix = "EUR") {
  spot_col <- paste0(currency_prefix, "_USD_Spot")
  fwd_col <- paste0(currency_prefix, "_USD_Fwd3M")
  fwd_rate_col <- paste0(currency_prefix, "_Rate_3M")
  usd_rate_col <- "USD_Rate_3M"
  
  subset_ts <- ts_data[, c(spot_col, fwd_col, fwd_rate_col, usd_rate_col)]
  subset_ts <- na.omit(subset_ts)
  
  results <- data.frame(
    Date = index(subset_ts),
    Spot = as.numeric(subset_ts[, spot_col]),
    Market_Fwd = as.numeric(subset_ts[, fwd_col]),
    r_d = as.numeric(subset_ts[, usd_rate_col]),
    r_f = as.numeric(subset_ts[, fwd_rate_col])
  )
  
  deviations <- mapply(function(s, rd, rf, f_mkt) {
    res <- compute_cip_deviation(s, rd, rf, f_mkt, tenor = 0.25)
    return(c(res$theoretical_fwd, res$basis_spread_ann_bps, res$stress_score))
  }, results$Spot, results$r_d, results$r_f, results$Market_Fwd)
  
  results$Theoretical_Fwd <- deviations[1, ]
  results$Basis_Spread_bps <- deviations[2, ]
  results$Stress_Score <- deviations[3, ]
  return(results)
}

test_uip_fama_regression <- function(ts_data, currency_prefix = "EUR", lag_periods = 60) {
  spot_col <- paste0(currency_prefix, "_USD_Spot")
  fwd_rate_col <- paste0(currency_prefix, "_Rate_3M")
  usd_rate_col1 <- "USD_Rate_3M"
  
  temp_df <- data.frame(
    S_t = as.numeric(ts_data[, spot_col]),
    S_future = as.numeric(lag(ts_data[, spot_col], -lag_periods)),
    r_d = as.numeric(ts_data[, usd_rate_col1]),
    r_f = as.numeric(ts_data[, fwd_rate_col])
  )
  temp_df <- na.omit(temp_df)
  temp_df$depreciation <- log(temp_df$S_future / temp_df$S_t)
  temp_df$ir_diff <- (temp_df$r_d - temp_df$r_f) * (90/360)
  
  uip_model <- lm(depreciation ~ ir_diff, data = temp_df)
  model_summary <- summary(uip_model)
  
  return(list(
    model = uip_model,
    alpha = coef(uip_model)[1],
    beta = coef(uip_model)[2],
    p_value_of_beta = model_summary$coefficients[2, 4],
    r_squared = model_summary$r.squared,
    interpretation = ifelse(coef(uip_model)[2] < 0, "Highly Profitable (Forward Premium Puzzle)", "Inefficient")
  ))
}`
  },
  {
    filename: "exposure.R",
    path: "fx-risk-engine/scripts/exposure.R",
    description: "Establishes a corporate treasury exposure ledger, segregating liabilities & receipts into transaction risk channels, balance-sheet translation revaluations, and economic operational sensitivities.",
    code: `#' Portfolio FX Exposure Decomposition

create_exposure_ledger <- function() {
  list(
    transaction = list(
      EUR = list(receivables = 25.0, payables = 10.0),
      GBP = list(receivables = 12.0, payables = 18.0),
      JPY = list(receivables = 800.0, payables = 2500.0)
    ),
    translation = list(
      EUR = list(assets = 150.0, liabilities = 40.0),
      GBP = list(assets = 95.0, liabilities = 35.0),
      JPY = list(assets = 3000.0, liabilities = 800.0)
    ),
    economic = list(
      EUR = list(expected_revenue = 65.0, expected_operating_cost = 20.0),
      GBP = list(expected_revenue = 40.0, expected_operating_cost = 15.0),
      JPY = list(expected_revenue = 5000.0, expected_operating_cost = 1200.0)
    )
  )
}

aggregate_portfolio_exposures <- function(ledger, eur_usd_rate, gbp_usd_rate, jpy_usd_rate) {
  # USD direct quotes
  r_eur <- eur_usd_rate
  r_gbp <- gbp_usd_rate
  r_jpy <- jpy_usd_rate
  
  eur_trans <- ledger$transaction$EUR$receivables - ledger$transaction$EUR$payables
  gbp_trans <- ledger$transaction$GBP$receivables - ledger$transaction$GBP$payables
  jpy_trans <- ledger$transaction$JPY$receivables - ledger$transaction$JPY$payables
  
  eur_trans_usd <- eur_trans * r_eur
  gbp_trans_usd <- gbp_trans * r_gbp
  jpy_trans_usd <- jpy_trans * r_jpy
  
  eur_translat <- ledger$translation$EUR$assets - ledger$translation$EUR$liabilities
  gbp_translat <- ledger$translation$GBP$assets - ledger$translation$GBP$liabilities
  jpy_translat <- ledger$translation$JPY$assets - ledger$translation$JPY$liabilities
  
  eur_translat_usd <- eur_translat * r_eur
  gbp_translat_usd <- gbp_translat * r_gbp
  jpy_translat_usd <- jpy_translat * r_jpy
  
  eur_econ <- ledger$economic$EUR$expected_revenue - ledger$economic$EUR$expected_operating_cost
  gbp_econ <- ledger$economic$GBP$expected_revenue - ledger$economic$GBP$expected_operating_cost
  jpy_econ <- ledger$economic$JPY$expected_revenue - ledger$economic$JPY$expected_operating_cost
  
  eur_econ_usd <- eur_econ * r_eur
  gbp_econ_usd <- gbp_econ * r_gbp
  jpy_econ_usd <- jpy_econ * r_jpy
  
  summary_tbl <- data.frame(
    Currency = c("EUR", "GBP", "JPY"),
    Spot_Rate = c(r_eur, r_gbp, r_jpy),
    Transaction_Local_M = c(eur_trans, gbp_trans, jpy_trans),
    Transaction_USD_M = c(eur_trans_usd, gbp_trans_usd, jpy_trans_usd),
    Translation_Local_M = c(eur_translat, gbp_translat, jpy_translat),
    Translation_USD_M = c(eur_translat_usd, gbp_translat_usd, jpy_translat_usd),
    Economic_Local_M = c(eur_econ, gbp_econ, jpy_econ),
    Economic_USD_M = c(eur_econ_usd, gbp_econ_usd, jpy_econ_usd)
  )
  summary_tbl$Total_Net_USD_M <- summary_tbl$Transaction_USD_M + summary_tbl$Translation_USD_M + summary_tbl$Economic_USD_M
  return(summary_tbl)
}`
  },
  {
    filename: "var_engine.R",
    path: "fx-risk-engine/scripts/var_engine.R",
    description: "Calculates Value at Risk and Expected Shortfall utilizing historical return curves, normal parametric covariance matrices, or Cholesky correlated Monte Carlo paths.",
    code: `#' FX Value-at-Risk (VaR) & Expected Shortfall (CVaR) Engine

compute_parametric_var <- function(exposures, cov_matrix, confidence_level = 0.95, holding_period = 10) {
  common <- intersect(names(exposures), colnames(cov_matrix))
  w <- exposures[common]
  sigma_matrix <- cov_matrix[common, common]
  
  port_daily_variance <- as.numeric(t(w) %*% sigma_matrix %*% w)
  port_daily_sd <- sqrt(port_daily_variance)
  
  z_score <- qnorm(confidence_level)
  var_daily <- z_score * port_daily_sd
  var_multi <- var_daily * sqrt(holding_period)
  
  phi_z <- dnorm(z_score)
  cvar_daily <- port_daily_sd * (phi_z / (1 - confidence_level))
  cvar_multi <- cvar_daily * sqrt(holding_period)
  
  return(list(
    portfolio_daily_sd = port_daily_sd,
    var_daily = var_daily,
    var_holding_period = var_multi,
    cvar_daily = cvar_daily,
    cvar_holding_period = cvar_multi
  ))
}

compute_historical_var <- function(exposures, return_series, confidence_level = 0.95, holding_period = 10) {
  currencies <- names(exposures)
  ret_cols <- paste0(currencies, "_USD_Spot_Ret")
  valid_cols <- intersect(ret_cols, colnames(return_series))
  mapped_currencies <- gsub("_USD_Spot_Ret", "", valid_cols)
  w <- exposures[mapped_currencies]
  
  returns_mat <- as.matrix(return_series[, valid_cols])
  portfolio_daily_losses <- - (returns_mat %*% w)
  portfolio_daily_losses <- as.numeric(na.omit(portfolio_daily_losses))
  
  var_daily <- quantile(portfolio_daily_losses, probs = confidence_level)
  tail_losses <- portfolio_daily_losses[portfolio_daily_losses >= var_daily]
  cvar_daily <- mean(tail_losses)
  
  return(list(
    var_daily = as.numeric(var_daily),
    var_holding_period = as.numeric(var_daily * sqrt(holding_period)),
    cvar_daily = as.numeric(cvar_daily),
    cvar_holding_period = as.numeric(cvar_daily * sqrt(holding_period))
  ))
}

compute_monte_carlo_var <- function(exposures, spot_rates, return_series, confidence_level = 0.95, steps = 10, paths_count = 5000) {
  set.seed(1337)
  currencies <- names(exposures)
  n_currencies <- length(currencies)
  ret_cols <- paste0(currencies, "_USD_Spot_Ret")
  ret_matrix <- as.matrix(na.omit(return_series[, ret_cols]))
  
  cov_daily <- cov(ret_matrix)
  mean_daily <- colMeans(ret_matrix)
  
  L <- t(chol(cov_daily))
  portfolio_losses <- numeric(paths_count)
  
  for (p in 1:paths_count) {
    accumulated_ret <- numeric(n_currencies)
    for (s in 1:steps) {
      z <- rnorm(n_currencies)
      correlated_z <- as.numeric(L %*% z)
      step_ret <- mean_daily - 0.5 * diag(cov_daily) + correlated_z
      accumulated_ret <- accumulated_ret + step_ret
    }
    position_losses <- exposures * (1 - exp(accumulated_ret))
    portfolio_losses[p] <- sum(position_losses)
  }
  
  mc_var <- quantile(portfolio_losses, probs = confidence_level)
  mc_cvar <- mean(portfolio_losses[portfolio_losses >= mc_var])
  
  return(list(
    losses = portfolio_losses,
    var_holding_period = as.numeric(mc_var),
    cvar_holding_period = as.numeric(mc_cvar)
  ))
}`
  },
  {
    filename: "hedging.R",
    path: "fx-risk-engine/scripts/hedging.R",
    description: "Evaluates standard forward contracts and structures risk-reduction metrics like the core Hedge Effectiveness Ratio (HER).",
    code: `#' Derivative Hedging Simulator

simulate_hedging_strategies <- function(initial_exposure, spot_series, forward_series, hedge_ratio = 0.70, rolling_window = 20) {
  n <- length(spot_series)
  pnl_unhedged <- numeric(n)
  pnl_full_hedge <- numeric(n)
  pnl_partial_hedge <- numeric(n)
  
  S0 <- spot_series[1]
  F0 <- forward_series[1]
  
  for (t in 1:n) {
    S_t <- spot_series[t]
    pnl_unhedged[t] <- initial_exposure * (S_t - S0)
    
    # Futures derivative payout offsets the spot risk
    derivative_payout_full <- initial_exposure * (F0 - S_t)
    pnl_full_hedge[t] <- pnl_unhedged[t] + derivative_payout_full
    
    derivative_payout_partial <- (initial_exposure * hedge_ratio) * (F0 - S_t)
    pnl_partial_hedge[t] <- pnl_unhedged[t] + derivative_payout_partial
  }
  
  vol_unhedged <- sd(pnl_unhedged)
  vol_full <- sd(pnl_full_hedge)
  vol_partial <- sd(pnl_partial_hedge)
  
  her_full <- 1 - (var(pnl_full_hedge) / var(pnl_unhedged))
  her_partial <- 1 - (var(pnl_partial_hedge) / var(pnl_unhedged))
  
  return(list(
    data = data.frame(Step = 1:n, Spot = spot_series, PnL_Unhedged = pnl_unhedged, PnL_FullHedge = pnl_full_hedge, PnL_PartialHedge = pnl_partial_hedge),
    metrics = list(
      volatility_unhedged = vol_unhedged,
      volatility_full = vol_full,
      volatility_partial = vol_partial,
      her_full = max(0, her_full),
      her_partial = max(0, her_partial),
      vol_reduction_full_pct = (vol_unhedged - vol_full) / vol_unhedged * 100,
      vol_reduction_partial_pct = (vol_unhedged - vol_partial) / vol_unhedged * 100
    )
  ))
}`
  },
  {
    filename: "basis_analysis.R",
    path: "fx-risk-engine/scripts/basis_analysis.R",
    description: "Models cross-currency basis arbitrage spreads, synthetic local repo funding spreads, and global liquidity constraints.",
    code: `#' Cross-Currency Basis Spread & Funding Stress Analytics

calculate_systemic_basis_stress <- function(spots, forwards, r_dom, r_for, tenor = 0.25) {
  n <- length(spots)
  # Synthetic funding implied rate:
  r_synthetic <- ((forwards / spots) * (1 + r_for * tenor) - 1) / tenor
  basis_spread_bps <- (r_dom - r_synthetic) * 10000
  ssi_score <- scale(abs(basis_spread_bps))
  ssi_score[is.na(ssi_score)] <- abs(basis_spread_bps)[is.na(ssi_score)] / 10
  
  liquidity_regime <- ifelse(abs(basis_spread_bps) > 45, "Severe Dollar Funding Shortage / Cross-Border Liquidity Choke",
                        ifelse(abs(basis_spread_bps) > 20, "Moderate Balance Sheet Constrained Friction", "Healthy Arbitrage Alignment"))
  return(data.frame(
    Step = 1:n,
    Synthetic_Rate = r_synthetic,
    Basis_Spread_Bps = basis_spread_bps,
    Systemic_Stress_Score = as.numeric(ssi_score),
    Funding_Category = liquidity_regime
  ))
}`
  },
  {
    filename: "stress_testing.R",
    path: "fx-risk-engine/scripts/stress_testing.R",
    description: "Runs severe macroeconomic tail shocks, encompassing the 2008 safe-haven Yen spike, sudden Federal Reserve hike surges, and EM-collapse scenarios.",
    code: `#' Stress Testing & Macroeconomic Scenario Simulator

run_systemic_stress_tests <- function(exposures) {
  scenarios <- list(
    \`2008 Financial Crisis Shock\` = list(EUR = -0.15, GBP = -0.18, JPY = 0.20),
    \`Sudden USD Strength Regime\` = list(EUR = -0.10, GBP = -0.10, JPY = -0.12),
    \`Emerging Market Collapse\` = list(EUR = -0.05, GBP = -0.05, JPY = -0.25),
    \`Interest Rate Divergence\` = list(EUR = -0.08, GBP = -0.06, JPY = -0.15)
  )
  
  results <- data.frame(Scenario = character(), Currency = character(), Exposure_USD_M = numeric(), Shock_Pct = numeric(), Asset_Loss_USD_M = numeric(), stringsAsFactors = FALSE)
  portfolio_total_losses <- data.frame(Scenario = character(), Total_Portfolio_Loss_USD_M = numeric(), Risk_Tier = character(), stringsAsFactors = FALSE)
  
  for (scen_name in names(scenarios)) {
    curr_scen <- scenarios[[scen_name]]
    total_loss <- 0
    
    for (curr in names(exposures)) {
      exp_val <- exposures[curr]
      shock <- ifelse(curr %in% names(curr_scen), curr_scen[[curr]], 0.0)
      item_loss <- - (exp_val * shock)
      
      results <- rbind(results, data.frame(
        Scenario = scen_name, currency = curr, Exposure_USD_M = exp_val, Shock_Pct = shock * 100, Asset_Loss_USD_M = item_loss
      ))
      total_loss <- total_loss + item_loss
    }
    
    portfolio_total_losses <- rbind(portfolio_total_losses, data.frame(
      Scenario = scen_name, Total_Portfolio_Loss_USD_M = total_loss,
      Risk_Tier = ifelse(total_loss > 15.0, "Critical Red", ifelse(total_loss > 5.0, "Elevated Alert", "Manageable"))
    ))
  }
  return(list(granular_shocks = results, portfolio_summary = portfolio_total_losses))
}`
  },
  {
    filename: "regime_detection.R",
    path: "fx-risk-engine/scripts/regime_detection.R",
    description: "Aggregates rolling daily portfolio volatility and annualized average returns to partition the historical dataset into clusters via the K-Means algorithm.",
    code: `#' Volatility & Trend FX Regime Classifier

detect_market_regimes <- function(returns, window_size = 20, k = 3) {
  n <- length(returns)
  rolling_vol <- numeric(n)
  rolling_mean <- numeric(n)
  
  for (t in window_size:n) {
    window_pts <- returns[(t - window_size + 1):t]
    rolling_vol[t] <- sd(window_pts, na.rm = TRUE) * sqrt(252)
    rolling_mean[t] <- mean(window_pts, na.rm = TRUE) * 252
  }
  
  features <- data.frame(Idx = window_size:n, Vol = rolling_vol[window_size:n], Mean = rolling_mean[window_size:n])
  features_scaled <- scale(features[, c("Vol", "Mean")])
  
  set.seed(88)
  kmeans_mod <- kmeans(features_scaled, centers = k, nstart = 25)
  cluster_ids <- kmeans_mod$cluster
  
  ordered_by_vol <- order(as.data.frame(kmeans_mod$centers)$Vol)
  regime_labels <- character(k)
  regime_labels[ordered_by_vol[1]] <- "Low Volatility Stable"
  regime_labels[ordered_by_vol[2]] <- "Trend-Driven USD Cycle"
  regime_labels[ordered_by_vol[3]] <- "High Volatility Crisis"
  
  features$Cluster_ID <- cluster_ids
  features$Regime <- regime_labels[cluster_ids]
  return(list(clustered_data = features, centers = kmeans_mod$centers))
}`
  }
];
