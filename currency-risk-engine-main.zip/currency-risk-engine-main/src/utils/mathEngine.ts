/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CurrencyExposure, SimulationParameters, ParityMetric, HedgingResultPoint, HedgingMetrics, VarResult, MarketRegimePoint, StressScenario } from "../types";

// Standard normal sampler (Box-Muller transform)
export function randomNormal(mean = 0, sd = 1): number {
  let u = 0, v = 0;
  while(u === 0) u = Math.random(); 
  while(v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return num * sd + mean;
}

// Generate Cholesky factor matrix for correlated normal variables
// For 3 dimensions (EUR, GBP, JPY): returns lower triangular L
export function getCholeskyFactorEURGBP_JPY(corr_eur_gbp: number, corr_eur_jpy: number, corr_gbp_jpy: number): number[][] {
  const L = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1]
  ];
  
  // EUR/GBP
  L[0][0] = 1.0;
  
  L[1][0] = corr_eur_gbp;
  L[1][1] = Math.sqrt(Math.max(0, 1.0 - corr_eur_gbp * corr_eur_gbp));
  
  L[2][0] = corr_eur_jpy;
  L[2][1] = (corr_gbp_jpy - L[2][0] * L[1][0]) / L[1][1];
  L[2][2] = Math.sqrt(Math.max(0, 1.0 - L[2][0] * L[2][0] - L[2][1] * L[2][1]));
  
  return L;
}

// Generate synthetic historical daily log returns and asset spot price sequences (120 days)
export function generateSyntheticHistory(
  spots: Record<string, number>,
  vols: Record<string, number>
): {
  dates: string[];
  spotHistory: Record<string, number[]>;
  returnHistory: Record<string, number[]>;
} {
  const length = 120;
  const curs = ["EUR", "GBP", "JPY"];
  const spotHistory: Record<string, number[]> = { EUR: [], GBP: [], JPY: [] };
  const returnHistory: Record<string, number[]> = { EUR: [], GBP: [], JPY: [] };
  
  // Correlations
  const corr = {
    EUR_GBP: 0.45,
    EUR_JPY: -0.15,
    GBP_JPY: -0.10
  };
  
  const L = getCholeskyFactorEURGBP_JPY(corr.EUR_GBP, corr.EUR_JPY, corr.GBP_JPY);
  
  // Starting values
  const currentSpots = { ...spots };
  
  // Initialize histories
  curs.forEach(c => {
    spotHistory[c].push(currentSpots[c]);
    returnHistory[c].push(0.0);
  });
  
  const dt = 1 / 252;
  
  for (let i = 1; i < length; i++) {
    const z = [randomNormal(), randomNormal(), randomNormal()];
    const corr_z = [
      L[0][0] * z[0],
      L[1][0] * z[0] + L[1][1] * z[1],
      L[2][0] * z[0] + L[2][1] * z[1] + L[2][2] * z[2]
    ];
    
    curs.forEach((c, index) => {
      const vol = vols[c];
      const drift = -0.01; // subtle USD strength trend
      const ret = (drift - 0.5 * vol * vol) * dt + vol * Math.sqrt(dt) * corr_z[index];
      const prevSpot = spotHistory[c][spotHistory[c].length - 1];
      const nextSpot = prevSpot * Math.exp(ret);
      
      spotHistory[c].push(nextSpot);
      returnHistory[c].push(ret);
    });
  }
  
  // Generate dates
  const dates: string[] = [];
  const baseDate = new Date(2026, 0, 1);
  for (let i = 0; i < length; i++) {
    const d = new Date(baseDate.getTime() + i * 24 * 3600 * 1000);
    dates.push(d.toISOString().split("T")[0]);
  }
  
  return { dates, spotHistory, returnHistory };
}

// Compute exposures in USD terms
export function computeExposures(exposures: CurrencyExposure[], spots: Record<string, number>): CurrencyExposure[] {
  return exposures.map(exp => {
    const s = spots[exp.currency];
    const isJPY = exp.currency === "JPY";
    
    // Compute positions in local units based on direct quotes (symbol costs S USD)
    // For EUR/GBP, quote is S USD per EUR or GBP, so local values are directly in currency units.
    // Let's keep a standard transaction, translation & economic calculation:
    const netTransactionLocal = exp.transactionReceivables - exp.transactionPayables;
    const netTranslationLocal = exp.translationAssets - exp.translationLiabilities;
    const netEconomicLocal = exp.economicRevenue - exp.economicCost;
    
    // Exposure in USD Millions: Local Net * Spot
    // (Ensure JPY is handled uniformly. Since JPY in our structure is standard direct quote JPY/USD e.g. 0.00645 USD, Local Unit * Spot = USD asset)
    const transUSD = netTransactionLocal * s;
    const translatUSD = netTranslationLocal * s;
    const econUSD = netEconomicLocal * s;
    const totalNetUSD = transUSD + translatUSD + econUSD;
    
    return {
      ...exp,
      spotRate: s,
      netTransactionLocal,
      netTranslationLocal,
      netEconomicLocal,
      totalNetUSD
    };
  });
}

// Interest Rate Parity calculations
export function calculateParityMetrics(
  exposures: CurrencyExposure[],
  usdRate: number,
  spots: Record<string, number>
): ParityMetric[] {
  // Tenor = 3M = 90 / 360 = 0.25
  const tenor = 0.25;
  
  return exposures.map(exp => {
    const s = spots[exp.currency];
    const rd = usdRate;
    const rf = exp.interestRate;
    
    // Theoretical CIP forward rate: F_theo = S_t * (1 + r_d * t) / (1 + r_f * t)
    const theoreticalForward = s * (1 + rd * tenor) / (1 + rf * tenor);
    
    // Add a systematic basis premium for actual forward quote:
    // Safe-haven JPY: synthetic dollar borrowing creates expensive forward points
    let deviationBps = 0;
    if (exp.currency === "JPY") {
      deviationBps = -15.4; // standard persistent negative basis
    } else if (exp.currency === "EUR") {
      deviationBps = -4.2;
    } else if (exp.currency === "GBP") {
      deviationBps = 2.1;
    }
    
    const actualForward = theoreticalForward + (deviationBps / 10000);
    
    // Implied Basis Spread (bps annualized)
    // Basis = [ln(F_mkt / S) - (r_d - r_f) * t] * 10000 / t
    const impliedBasisSpreadBps = ((actualForward - theoreticalForward) / theoreticalForward) * 10000 / tenor;
    
    const absSpread = Math.abs(impliedBasisSpreadBps);
    let stressLevel: "Low (Stable)" | "Moderate" | "Severe Stress" = "Low (Stable)";
    if (absSpread > 40) {
      stressLevel = "Severe Stress";
    } else if (absSpread > 15) {
      stressLevel = "Moderate";
    }
    
    // Historical UIP Fama Regression simulated beta coefficient
    // EUR historically has negative beta (Forward Premium Puzzle)
    let uipBeta = 1.0;
    if (exp.currency === "EUR") {
      uipBeta = -0.85; // highly negative carry returns
    } else if (exp.currency === "GBP") {
      uipBeta = -0.42;
    } else if (exp.currency === "JPY") {
      uipBeta = -1.25; // severe failures
    }
    
    return {
      currency: exp.currency,
      actualSpot: s,
      domesticRate: rd,
      foreignRate: rf,
      actualForward,
      theoreticalForward,
      deviationBps,
      impliedBasisSpreadBps,
      stressLevel,
      uipBeta,
      uipHolds: Math.abs(uipBeta - 1.0) < 0.2
    };
  });
}

// Volatility Regime Classifier
export function classifyRegimes(
  returns: number[],
  dates: string[]
): MarketRegimePoint[] {
  const windowSize = 20;
  const outPoints: MarketRegimePoint[] = [];
  
  for (let i = windowSize; i < returns.length; i++) {
    const subset = returns.slice(i - windowSize + 1, i + 1);
    
    // Calculate daily deviation and mean
    const mean = subset.reduce((a, b) => a + b, 0) / windowSize;
    const variance = subset.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / (windowSize - 1);
    const dailySd = Math.sqrt(variance);
    
    const annVol = dailySd * Math.sqrt(252);
    const annMean = mean * 252;
    
    // Heuristic Multi-Criteria Regime Classification
    let regime: MarketRegimePoint["regime"] = "Low Volatility Stable";
    if (annVol > 0.16) {
      regime = "High Volatility Crisis";
    } else if (annVol > 0.11) {
      regime = "Trend-Driven USD Cycle";
    } else if (Math.abs(annMean) < 0.01 && annVol > 0.05) {
      regime = "Liquidity Stress";
    }
    
    outPoints.push({
      day: i - windowSize + 1,
      volatility: annVol * 100, // as %
      meanReturn: annMean * 100, // as %
      regime
    });
  }
  
  return outPoints;
}

// Compute parametric covariance-based Portfolio VaR (10D)
export function computeParametricVar(
  w: Record<string, number>, // weights / exposures (m USD)
  covDaily: Record<string, Record<string, number>>,
  confidenceLevel: 0.95 | 0.99,
  holdingPeriod = 10
): { varValue: number; cvarValue: number } {
  const keys = Object.keys(w);
  let pVar = 0.0;
  
  // calculate w^T * Sigma * w
  for (const c1 of keys) {
    for (const c2 of keys) {
      const exp1 = w[c1];
      const exp2 = w[c2];
      const covariance = covDaily[c1]?.[c2] || 0.0;
      pVar += exp1 * exp2 * covariance;
    }
  }
  
  const pSd = Math.sqrt(Math.max(0, pVar));
  const z = confidenceLevel === 0.95 ? 1.64485 : 2.32635;
  const dailyVar = z * pSd;
  const holdingVar = dailyVar * Math.sqrt(holdingPeriod);
  
  // Expected Shortfall closed-form for normal model
  const phiZ = (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * z * z);
  const dailyCvar = pSd * (phiZ / (1 - confidenceLevel));
  const holdingCvar = dailyCvar * Math.sqrt(holdingPeriod);
  
  return {
    varValue: holdingVar,
    cvarValue: holdingCvar
  };
}

// Compute bootstrap historical simulated VaR
export function computeHistoricalVar(
  w: Record<string, number>,
  returnHistory: Record<string, number[]>,
  confidenceLevel: 0.95 | 0.99,
  holdingPeriod = 10
): { varValue: number; cvarValue: number } {
  const currencies = Object.keys(w);
  const nDays = returnHistory[currencies[0]]?.length || 0;
  
  const dailyLosses: number[] = [];
  
  for (let d = 0; d < nDays; d++) {
    let dayLoss = 0;
    for (const c of currencies) {
      const r = returnHistory[c]?.[d] || 0.0;
      // positive return is profit, negative return is loss
      // individual loss = exposure * (1 - e^r) ~ exposure * (-r)
      dayLoss += w[c] * (1 - Math.exp(r));
    }
    dailyLosses.push(dayLoss);
  }
  
  // Sort losses low to high
  dailyLosses.sort((a, b) => a - b);
  
  const index = Math.floor(confidenceLevel * dailyLosses.length);
  const dailyVar = dailyLosses[index] || 0;
  const holdingVar = dailyVar * Math.sqrt(holdingPeriod);
  
  // Expected Shortfall (CVaR)
  const tailLosses = dailyLosses.slice(index);
  const dailyCvar = tailLosses.length > 0 ? (tailLosses.reduce((a, b) => a + b, 0) / tailLosses.length) : dailyVar;
  const holdingCvar = dailyCvar * Math.sqrt(holdingPeriod);
  
  return {
    varValue: holdingVar,
    cvarValue: holdingCvar
  };
}

// Compute high-fidelity Monte Carlo simulation (paths & risk distributions)
export function runMonteCarloVar(
  w: Record<string, number>,
  vols: Record<string, number>,
  confidenceLevel: 0.95 | 0.99,
  stochasticModel: "GBM" | "OU",
  ouTheta = 0.20,
  horizon = 10,
  numPaths = 500
): {
  varValue: number;
  cvarValue: number;
  pathsEUR: number[][];
  pathsGBP: number[][];
  pathsJPY: number[][];
  scenariosLosses: number[];
} {
  const curs = ["EUR", "GBP", "JPY"];
  // Set correlations
  const corr = { EUR_GBP: 0.45, EUR_JPY: -0.15, GBP_JPY: -0.10 };
  const L = getCholeskyFactorEURGBP_JPY(corr.EUR_GBP, corr.EUR_JPY, corr.GBP_JPY);
  
  const dt = 1 / 252;
  const dt_step = horizon / 10 / 252; // slice the horizon in 10 simulation sub-steps
  
  const pathsEUR: number[][] = Array.from({ length: 11 }, () => []);
  const pathsGBP: number[][] = Array.from({ length: 11 }, () => []);
  const pathsJPY: number[][] = Array.from({ length: 11 }, () => []);
  
  const scenarioLosses: number[] = [];
  
  // Initial points (normalized to 1.0)
  for (let s = 0; s <= 10; s++) {
    pathsEUR[s].push(1.0);
    pathsGBP[s].push(1.0);
    pathsJPY[s].push(1.0);
  }
  
  for (let p = 0; p < numPaths; p++) {
    let currentRetEUR = 0;
    let currentRetGBP = 0;
    let currentRetJPY = 0;
    
    // Accumulate shocks over 10 steps representing the risk horizon
    for (let step = 1; step <= 10; step++) {
      const z = [randomNormal(), randomNormal(), randomNormal()];
      const corr_z = [
        L[0][0] * z[0],
        L[1][0] * z[0] + L[1][1] * z[1],
        L[2][0] * z[0] + L[2][1] * z[1] + L[2][2] * z[2]
      ];
      
      if (stochasticModel === "GBM") {
        // EUR step
        const drEUR = (-0.5 * vols.EUR * vols.EUR) * dt_step + vols.EUR * Math.sqrt(dt_step) * corr_z[0];
        currentRetEUR += drEUR;
        // GBP step
        const drGBP = (-0.5 * vols.GBP * vols.GBP) * dt_step + vols.GBP * Math.sqrt(dt_step) * corr_z[1];
        currentRetGBP += drGBP;
        // JPY step
        const drJPY = (-0.5 * vols.JPY * vols.JPY) * dt_step + vols.JPY * Math.sqrt(dt_step) * corr_z[2];
        currentRetJPY += drJPY;
      } else {
        // Ornstein-Uhlenbeck (mean-reverting around 1.0 relative value)
        // dS = theta * (1.0 - S_{t-1}) * dt + sigma * dW
        const curEUR = Math.exp(currentRetEUR);
        const curGBP = Math.exp(currentRetGBP);
        const curJPY = Math.exp(currentRetJPY);
        
        const dEUR = ouTheta * (1.0 - curEUR) * dt_step + vols.EUR * Math.sqrt(dt_step) * corr_z[0];
        const dGBP = ouTheta * (1.0 - curGBP) * dt_step + vols.GBP * Math.sqrt(dt_step) * corr_z[1];
        const dJPY = ouTheta * (1.0 - curJPY) * dt_step + vols.JPY * Math.sqrt(dt_step) * corr_z[2];
        
        currentRetEUR = Math.log(Math.max(0.1, curEUR + dEUR));
        currentRetGBP = Math.log(Math.max(0.1, curGBP + dGBP));
        currentRetJPY = Math.log(Math.max(0.1, curJPY + dJPY));
      }
      
      // Store trace paths for the first 15 lines of plotting
      if (p < 15) {
        pathsEUR[step].push(Math.exp(currentRetEUR));
        pathsGBP[step].push(Math.exp(currentRetGBP));
        pathsJPY[step].push(Math.exp(currentRetJPY));
      }
    }
    
    // Compute total net P&L loss for this simulation path
    // Loss_i = Weighted_USD_Exposure * (1 - e^accumulated_return)
    const lossEUR = w.EUR * (1 - Math.exp(currentRetEUR));
    const lossGBP = w.GBP * (1 - Math.exp(currentRetGBP));
    const lossJPY = w.JPY * (1 - Math.exp(currentRetJPY));
    
    const finalPathLoss = lossEUR + lossGBP + lossJPY;
    scenarioLosses.push(finalPathLoss);
  }
  
  // Sort simulated losses
  scenarioLosses.sort((a, b) => a - b);
  const varIndex = Math.floor(confidenceLevel * scenarioLosses.length);
  const varValue = scenarioLosses[varIndex] || 0.0;
  
  // Expected Shortfall (CVaR)
  const tail = scenarioLosses.slice(varIndex);
  const cvarValue = tail.length > 0 ? (tail.reduce((a, b) => a + b, 0) / tail.length) : varValue;
  
  return {
    varValue,
    cvarValue,
    pathsEUR,
    pathsGBP,
    pathsJPY,
    scenariosLosses: scenarioLosses
  };
}

// Compute covariance of historical return arrays
export function getCovarianceMatrix(
  returnHistory: Record<string, number[]>
): Record<string, Record<string, number>> {
  const curs = ["EUR", "GBP", "JPY"];
  const n = returnHistory.EUR?.length || 0;
  
  const cov: Record<string, Record<string, number>> = {};
  
  curs.forEach(c1 => {
    cov[c1] = {};
    const mean1 = returnHistory[c1].reduce((a, b) => a + b, 0) / n;
    
    curs.forEach(c2 => {
      const mean2 = returnHistory[c2].reduce((a, b) => a + b, 0) / n;
      let sumProducts = 0;
      for (let i = 0; i < n; i++) {
        sumProducts += (returnHistory[c1][i] - mean1) * (returnHistory[c2][i] - mean2);
      }
      cov[c1][c2] = sumProducts / (n - 1);
    });
  });
  
  return cov;
}

// Evaluate derivative hedging backtests P&L lines
export function runHedgingSimulation(
  spotHistory: number[],
  forwardHistory: number[],
  initialExposureEUR: number,
  hedgeRatio: number
): { data: HedgingResultPoint[]; metrics: HedgingMetrics } {
  const n = spotHistory.length;
  const listPoints: HedgingResultPoint[] = [];
  
  const S0 = spotHistory[0];
  const F0 = forwardHistory[0];
  
  const pnlUnhedgedArr: number[] = [];
  const pnlFullArr: number[] = [];
  const pnlPartialArr: number[] = [];
  
  for (let t = 0; t < n; t++) {
    const St = spotHistory[t];
    
    // P&L = original_exposure * (S_t - S_0)
    const pnlUnhedged = initialExposureEUR * (St - S0);
    
    // Full Hedge locks in F0 forward rate:
    // P&L_hedged = exposure * (St - S0) + exposure * (F0 - St) = exposure * (F0 - S0)
    const pnlFullHedge = initialExposureEUR * (S0 * -1 + F0); // completely flat fixed locked value
    
    // Partial Hedge ratio (static hedge policy)
    const pnlPartialHedge = pnlUnhedged + (initialExposureEUR * hedgeRatio) * (F0 - St);
    
    pnlUnhedgedArr.push(pnlUnhedged);
    pnlFullArr.push(pnlFullHedge);
    pnlPartialArr.push(pnlPartialHedge);
    
    listPoints.push({
      step: t + 1,
      spot: St,
      marketForward: F0,
      pnlUnhedged,
      pnlFullHedge,
      pnlPartialHedge
    });
  }
  
  // Calculate Standard Deviations (volatilities)
  const volUnhedged = getStandardDeviation(pnlUnhedgedArr);
  const volFull = getStandardDeviation(pnlFullArr);
  const volPartial = getStandardDeviation(pnlPartialArr);
  
  // Hedge Effectiveness Ratio = 1 - Var(Hedged) / Var(Unhedged)
  const varUnhedged = volUnhedged * volUnhedged;
  const herFull = varUnhedged > 0 ? (1 - (volFull * volFull) / varUnhedged) : 0;
  const herPartial = varUnhedged > 0 ? (1 - (volPartial * volPartial) / varUnhedged) : 0;
  
  // Percentage Volatility Reductions
  const volReductionFullPct = volUnhedged > 0 ? ((volUnhedged - volFull) / volUnhedged) * 100 : 0;
  const volReductionPartialPct = volUnhedged > 0 ? ((volUnhedged - volPartial) / volUnhedged) * 100 : 0;
  
  return {
    data: listPoints,
    metrics: {
      volatilityUnhedged: volUnhedged,
      volatilityFull: volFull,
      volatilityPartial: volPartial,
      herFull: Math.max(0, herFull),
      herPartial: Math.max(0, herPartial),
      volReductionFullPct,
      volReductionPartialPct
    }
  };
}

function getStandardDeviation(arr: number[]): number {
  if (arr.length <= 1) return 0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  const sqDiffSum = arr.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0);
  return Math.sqrt(sqDiffSum / (arr.length - 1));
}

// Compute granular stress test losses
export function calculateStressTestLosses(
  w: Record<string, number>,
  scenario: StressScenario
): { portfolioSumUSD: number; itemized: Array<{ currency: string; lossUSD: number }> } {
  let portfolioSumUSD = 0;
  const itemized: Array<{ currency: string; lossUSD: number }> = [];
  
  Object.keys(w).forEach(curr => {
    const shockPct = scenario.shocks[curr] || 0;
    const exposure = w[curr];
    
    // Loss USD: - (exposure * shockPct)
    // If currency devalues (shockPct < 0, e.g. -15%), a long position (exposure > 0) loses money
    // Loss = - (exposure * -0.15) = +exposure * 0.15 Millions lost
    const lossUSD = - (exposure * shockPct);
    portfolioSumUSD += lossUSD;
    itemized.push({ currency: curr, lossUSD });
  });
  
  return { portfolioSumUSD, itemized };
}
