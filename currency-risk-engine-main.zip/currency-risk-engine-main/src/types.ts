/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CurrencyExposure {
  currency: string;
  symbol: string;
  spotRate: number;      // USD per 1 unit of Foreign Currency (direct quote)
  interestRate: number;  // Annual foreign interest rate (e.g. 0.04 for 4.00%)
  
  // Exposure Channels (in USD Millions)
  transactionReceivables: number;
  transactionPayables: number;
  translationAssets: number;
  translationLiabilities: number;
  economicRevenue: number;
  economicCost: number;
  
  // Calculated summaries
  netTransactionLocal: number;
  netTranslationLocal: number;
  netEconomicLocal: number;
  totalNetUSD: number;
}

export interface SimulationParameters {
  stochasticModel: "GBM" | "OU";
  steps: number;          // Risk horizon (days, default 10)
  pathsCount: number;     // Number of paths (default 100)
  confidenceLevel: 0.95 | 0.99;
  usdInterestRate: number; // e.g. 0.0525 (5.25%)
  
  // OU Parameters
  ouTheta: number;        // Speed of mean reversion
  
  // Custom spot adjusters
  spots: Record<string, number>;
  volatilities: Record<string, number>; // Annualized volatilities
}

export interface ParityMetric {
  currency: string;
  actualSpot: number;
  domesticRate: number;
  foreignRate: number;
  actualForward: number; // 3M forward rate
  theoreticalForward: number;
  deviationBps: number;
  impliedBasisSpreadBps: number;
  stressLevel: "Low (Stable)" | "Moderate" | "Severe Stress";
  uipBeta: number;
  uipHolds: boolean;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  shocks: Record<string, number>; // Currency code -> spot rate change % (e.g. -0.15 for -15% EUR drop)
}

export interface HedgingResultPoint {
  step: number;
  spot: number;
  marketForward: number;
  pnlUnhedged: number;
  pnlFullHedge: number;
  pnlPartialHedge: number;
}

export interface HedgingMetrics {
  volatilityUnhedged: number;
  volatilityFull: number;
  volatilityPartial: number;
  herFull: number;
  herPartial: number;
  volReductionFullPct: number;
  volReductionPartialPct: number;
}

export interface VarResult {
  parametricVar: number;
  parametricCvar: number;
  historicalVar: number;
  historicalCvar: number;
  monteCarloVar: number;
  monteCarloCvar: number;
  mcLosses: number[];
}

export interface MarketRegimePoint {
  day: number;
  volatility: number;
  meanReturn: number;
  regime: "Low Volatility Stable" | "Trend-Driven USD Cycle" | "High Volatility Crisis" | "Liquidity Stress";
}

export interface RScriptModule {
  filename: string;
  path: string;
  description: string;
  code: string;
}
