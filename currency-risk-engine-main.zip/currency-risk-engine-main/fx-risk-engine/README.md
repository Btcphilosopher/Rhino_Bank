# Currency Risk Analytics Engine (R)
### "FX Risk, Parity Deviation & Hedging Intelligence System"

An institutional-grade, modular quantitative system built in **R** to model foreign exchange (FX) exposure risk, interest rate parity deviations, stochastic exchange rate dynamics, value-at-risk (VaR/CVaR), derivative hedging strategies, and volatility regimes.

---

## 🧾 Project Structure

```
fx-risk-engine/
│
├── data/                             # Synthetic or ingested market CSV files
│   ├── fx_spot_rates.csv
│   └── bond_yields.csv
│
├── scripts/
│   ├── ingestion.R                   # Ingestion, cleaning, timestamp alignment, return calculation
│   ├── fx_model.R                    # GBM, Ornstein-Uhlenbeck simulators, GARCH parameterizer
│   ├── parity.R                      # Covered (CIP) & Uncovered (UIP) Interest Parity test suite
│   ├── exposure.R                    # Portfolio transaction, translation, and economic exposure aggregator
│   ├── var_engine.R                  # Historical, Parametric, and Monte Carlo VaR & Expected Shortfall
│   ├── hedging.R                     # Forward and Swap simulator (unhedged vs hedged P&L, HER)
│   ├── basis_analysis.R              # Cross-currency basis spread calculator & systemic funding stress indicator
│   ├── stress_testing.R              # FX shock propagation (2008 Crisis, EM Meltdown, USD Regime Shifts)
│   ├── regime_detection.R            # K-means & volatility-threshold GARCH regime classifiers
│   └── visualization.R               # Production-grade ggplot2 / plotly visualization templates
│
├── main.R                            # Global execution entry-point (backtest loop & orchestrator)
└── README.md                         # Quantitative documentation and instructions
```

---

## ⚙️ Requirements & Installation

To run this analytics system, you must have an active **R installation** (v4.0.0 or higher recommended) with the following package dependencies.

Install dependencies in R:
```R
install.packages(c("tidyverse", "quantmod", "xts", "zoo", "PerformanceAnalytics", 
                   "deSolve", "tseries", "mclust", "plotly"))
```

---

## 🧠 Core Quantitative Methodologies

### 1. Stochastic FX Models
- **Geometric Brownian Motion (GBM):**
  $$dS_t = \mu S_t dt + \sigma S_t dW_t$$
  Models a standard independent log-normal expansion suitable for short-term path projections.
- **Ornstein–Uhlenbeck (OU) Process:**
  $$dS_t = \theta (\mu - S_t) dt + \sigma dW_t$$
  Accounts for mean-reverting currency dynamics, often typical of pegged regimes, currency corridors, or long-term fair-value bounds.

### 2. Interest Rate Parities & Deviations
- **Covered Interest Parity (CIP):**
  $$F_t^{CIP} = S_t \times \frac{1 + r_{domestic, t} \cdot \tau}{1 + r_{foreign, t} \cdot \tau}$$
  Deviations represent cross-currency basis spreads ($\Delta_t$), reflecting synthetic dollar funding premiums, balance sheet constraints, or systemic credit risk.
- **Uncovered Interest Parity (UIP):**
  $$E[S_{t+\tau}] = S_t \frac{1 + r_{domestic} \cdot \tau}{1 + r_{foreign} \cdot \tau}$$
  Tested using the standard Fama regression $r_{\Delta s, t} = \alpha + \beta(r_d - r_f)_t + \epsilon_t$. UIP fails systematically due to the forward premium puzzle, yielding positive returns on carry trade strategies ($\beta < 1$, often negative).

### 3. High-Fidelity Risk Metrics
- **Value-at-Risk (VaR):** Computed at 95% and 99% confidence intervals using:
  - *Parametric Method:* Analytical derivation utilizing portfolio covariance matrices.
  - *Historical Bootstrap:* Resampling actual empirical returns.
  - *Monte Carlo:* 10,000-path stochastic forward pricing using GBM or OU processes.
- **Expected Shortfall (CVaR):** Calculates the average loss expected *given* that the loss exceeds the VaR threshold:
  $$CVaR_{\alpha} = E[L \mid L \ge VaR_{\alpha}]$$

### 4. Hedging Strategy Backtesting
Simulates forwards and swaps over custom tenors, evaluating:
- **Hedge Effectiveness Ratio (HER):**
  $$HER = 1 - \frac{\text{Variance}(P\&L_{\text{hedged}})}{\text{Variance}(P\&L_{\text{unhedged}})}$$
- **Total Portfolio Volatility Reduction (%)**

---

## 🚀 Quick Start (Running the Engine)

1. Navigate to the `fx-risk-engine/` directory in R or RStudio.
2. Ingest the required market data or run the synthetic generator.
3. Source and execute the main controller:
   ```R
   source("main.R")
   results <- run_fx_analytics_engine()
   ```
4. This script will sequentially execute the pipeline, perform Monte Carlo simulations, generate risk distributions, compute CIP basis spreads, evaluate hedging under stress, and output a detailed CSV report plus high-impact visual plots.
