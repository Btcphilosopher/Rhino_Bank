#' Currency Risk Analytics Engine: Main Orchestrator
#' @description Central entry point to wire raw observations ingestion, stochastic modelling,
#' parity checking, value-at-risk estimation, hedging tests, basis screening, and stress runs.

# Source modular engine components
source("scripts/ingestion.R")
source("scripts/fx_model.R")
source("scripts/parity.R")
source("scripts/exposure.R")
source("scripts/var_engine.R")
source("scripts/hedging.R")
source("scripts/basis_analysis.R")
source("scripts/stress_testing.R")
source("scripts/regime_detection.R")
source("scripts/visualization.R")

#' Run Consolidated FX Analytics Suite
#' @return A consolidated list containing the full analytics context and risk output reports
run_fx_analytics_engine <- function() {
  cat("========================================================================\n")
  cat("         CURRENCY RISK ANALYTICS ENGINE (R) -- INITIALIZING ENGINE       \n")
  cat("========================================================================\n\n")
  
  # 1. DATA ENGINE PIPELINE
  market_series <- run_ingestion_pipeline()
  latest_row <- tail(market_series, 1)
  
  eur_spot <- as.numeric(latest_row$EUR_USD_Spot)
  gbp_spot <- as.numeric(latest_row$GBP_USD_Spot)
  jpy_spot <- as.numeric(latest_row$JPY_USD_Spot) # JPY/USD direct
  
  # 2. DEFINE AND CONSOLIDATE PORTFOLIO EXPOSURES
  cat("\n[EXPOSURE] Aggregating multi-currency exposures...\n")
  exposure_ledger <- create_exposure_ledger()
  consolidated_exposure <- aggregate_portfolio_exposures(exposure_ledger, eur_spot, gbp_spot, jpy_spot)
  print(consolidated_exposure)
  
  # Net exposures mapping vector
  net_exposures <- consolidated_exposure$Total_Net_USD_M
  names(net_exposures) <- consolidated_exposure$Currency
  
  # 3. INTERST RATE PARITY SCREENING (CIP/UIP)
  cat("\n[PARITY] Computing CIP basis deviations & funding stress tests...\n")
  eur_cip_history <- test_historical_cip(market_series, "EUR")
  gbp_cip_history <- test_historical_cip(market_series, "GBP")
  jpy_cip_history <- test_historical_cip(market_series, "JPY")
  
  # Extract latest CIP metrics
  latest_eur_cip <- tail(eur_cip_history, 1)
  cat(sprintf("EUR/USD Basis Spread (Bps): %.2f | Stress Indicator: %.1f bps\n", 
              latest_eur_cip$Basis_Spread_bps, latest_eur_cip$Stress_Score))
              
  # UIP Regression Analysis
  cat("\n[PARITY] Evaluating UIP Fama Regressions & Carry Profitability...\n")
  eur_uip_reg <- test_uip_fama_regression(market_series, "EUR", lag_periods = 60)
  cat(sprintf("EUR UIP Beta Constant: %.4f | Fama Puzzle Present: %s\n", 
              eur_uip_reg$beta, eur_uip_reg$interpretation))
              
  # 4. STOCHASTIC CALIBRATION & SIMULATION
  cat("\n[STOCHASTIC] Calibrating GBM params from historical currency returns...\n")
  eur_ret <- as.numeric(market_series$EUR_USD_Spot_Ret)
  gbp_ret <- as.numeric(market_series$GBP_USD_Spot_Ret)
  jpy_ret <- as.numeric(market_series$JPY_USD_Spot_Ret)
  
  eur_params <- calibrate_gbm(eur_ret)
  gbp_params <- calibrate_gbm(gbp_ret)
  jpy_params <- calibrate_gbm(jpy_ret)
  
  cat(sprintf("EUR Annualized Volatility: %.2f%%\n", eur_params$sigma * 100))
  cat(sprintf("GBP Annualized Volatility: %.2f%%\n", gbp_params$sigma * 100))
  cat(sprintf("JPY Annualized Volatility: %.2f%%\n", jpy_params$sigma * 100))
  
  # 5. RISK VAR & CORRELATION ENGINES
  cat("\n[VaR ENGINE] Calculating Parametric & Monte Carlo FX VaR (Holding=10 days, Confidence=95%)...\n")
  returns_cols <- c("EUR_USD_Spot_Ret", "GBP_USD_Spot_Ret", "JPY_USD_Spot_Ret")
  rets_matrix <- cov(as.matrix(na.omit(market_series[, returns_cols])))
  # Rename covariance names to simple currency strings for programmatic matching
  colnames(rets_matrix) <- rownames(rets_matrix) <- c("EUR", "GBP", "JPY")
  
  parametric_metrics <- compute_parametric_var(net_exposures, rets_matrix, confidence_level = 0.95, holding_period = 10)
  cat(sprintf("Parametric VaR (10D): $%.2fM | Expected Shortfall (CVaR): $%.2fM\n", 
              parametric_metrics$var_holding_period, parametric_metrics$cvar_holding_period))
              
  historical_metrics <- compute_historical_var(net_exposures, market_series, confidence_level = 0.95, holding_period = 10)
  cat(sprintf("Historical VaR (10D): $%.2fM | Expected Shortfall (CVaR): $%.2fM\n", 
              historical_metrics$var_holding_period, historical_metrics$cvar_holding_period))
              
  # Monte Carlo Simulation (5,000 paths)
  spot_rates_vector <- c(EUR = eur_spot, GBP = gbp_spot, JPY = jpy_spot)
  mc_metrics <- compute_monte_carlo_var(net_exposures, spot_rates_vector, market_series, 
                                        confidence_level = 0.95, steps = 10, paths_count = 5000)
  cat(sprintf("Monte Carlo VaR (10D): $%.2fM | Expected Shortfall (CVaR): $%.2fM\n", 
              mc_metrics$var_holding_period, mc_metrics$cvar_holding_period))
              
  # 6. HEDGING SIMULATION BACKTESTS
  cat("\n[HEDGING] Backtesting forward derivatives hedging strategies on EUR Exposure...\n")
  eur_spots_vec <- as.numeric(market_series$EUR_USD_Spot)
  eur_fwds_vec <- as.numeric(market_series$EUR_USD_Fwd3M)
  
  # Assume EUR transaction exposure of 25.0M EUR
  hedge_sim <- simulate_hedging_strategies(initial_exposure = 25.0, 
                                           spot_series = eur_spots_vec, 
                                           forward_series = eur_fwds_vec, 
                                           hedge_ratio = 0.75)
  cat(sprintf("Full Hedge Variance Reduction: %.2f%% | Hedge Effectiveness Ratio (HER): %.4f\n", 
              hedge_sim$metrics$vol_reduction_full_pct, hedge_sim$metrics$her_full))
  cat(sprintf("Partial (75%%) Hedge Variance Reduction: %.2f%% | Hedge Effectiveness Ratio (HER): %.4f\n", 
              hedge_sim$metrics$vol_reduction_partial_pct, hedge_sim$metrics$her_partial))
              
  # 7. CROSS-CURRENCY BASIS INVESTIGATION
  cat("\n[BASIS] Investigating JPY funding stress points and repo basis spreads...\n")
  jpy_spots_v <- as.numeric(market_series$JPY_USD_Spot)
  jpy_fwds_v <- as.numeric(market_series$JPY_USD_Fwd3M)
  jpy_rate_v <- as.numeric(market_series$JPY_Rate_3M)
  usd_rate_v <- as.numeric(market_series$USD_Rate_3M)
  
  basis_stress_results <- calculate_systemic_basis_stress(jpy_spots_v, jpy_fwds_v, usd_rate_v, jpy_rate_v, tenor = 0.25)
  latest_basis_stress <- tail(basis_stress_results, 1)
  cat(sprintf("JPY Basis Spread: %.2f Bps | Funding Stress: %s\n", 
              latest_basis_stress$Basis_Spread_Bps, latest_basis_stress$Funding_Category))
              
  # 8. MACRO STRESS SHOCK SIMULATOR
  cat("\n[STRESS TEST] Simulating catastrophic macro scenarios on FX portfolio...\n")
  stress_outcomes <- run_systemic_stress_tests(net_exposures)
  print(stress_outcomes$portfolio_summary)
  
  # 9. MARKET VOLATILITY REGIME CLUSTERING
  cat("\n[REGIMES] Running clustering models (K-Means) to detect state shifts...\n")
  # Extract portfolio return series representation
  portfolio_daily_returns_history <- as.numeric(na.omit(rowSums(
    as.matrix(market_series[, c("EUR_USD_Spot_Ret", "GBP_USD_Spot_Ret", "JPY_USD_Spot_Ret")]))))
    
  regime_results <- detect_market_regimes(portfolio_daily_returns_history, window_size = 20, k = 3)
  latest_regime <- tail(regime_results$clustered_data$Regime, 1)
  cat(sprintf("Detected Current Volatility/Trend Market Regime: %s\n", latest_regime))
  
  cat("\n========================================================================\n")
  cat("                CURRENCY RISK ANALYTICS ENGINE RUN COMPLETE              \n")
  cat("========================================================================\n")
  
  return(list(
    data_series = market_series,
    exposures = consolidated_exposure,
    uip_regression = eur_uip_reg,
    parametric_var = parametric_metrics,
    historical_var = historical_metrics,
    monte_carlo_var = mc_metrics,
    hedging = hedge_sim,
    basis_analysis = basis_stress_results,
    stress_testing = stress_outcomes,
    regimes = regime_results
  ))
}

# Run execution when invoked directly
if (!interactive()) {
  run_fx_analytics_engine()
}
