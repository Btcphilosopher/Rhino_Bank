#' Stochastic FX Dynamics Simulators
#' @description Implements Geometric Brownian Motion (GBM) and mean-reverting
#' Ornstein-Uhlenbeck (OU) simulators for exchange rates, accommodating volatility clustering.

#' Simulate Geometric Brownian Motion (GBM) Paths
#' @param S0 Initial spot exchange rate
#' @param mu Daily drift rate (annual drift / 252)
#' @param sigma Daily volatility (annual vol / sqrt(252))
#' @param N Number of steps (days)
#' @param M Number of simulation paths
#' @param dt Elapsed time increment (default 1 / 252 for daily)
#' @return A matrix of dimension (N+1) x M containing the simulated price paths
simulate_gbm <- function(S0, mu, sigma, N, M, dt = 1/252) {
  paths <- matrix(0, nrow = N + 1, ncol = M)
  paths[1, ] <- S0
  
  for (j in 1:M) {
    # dS = mu * S * dt + sigma * S * dW
    # S_t = S_{t-1} * exp((mu - 0.5 * sigma^2)*dt + sigma * sqrt(dt)*Z)
    z <- rnorm(N)
    for (i in 2:(N + 1)) {
      paths[i, j] <- paths[i - 1, j] * exp((mu - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * z[i - 1])
    }
  }
  return(paths)
}

#' Simulate Ornstein-Uhlenbeck Process Paths (Mean Reverting)
#' @param S0 Initial spot exchange rate
#' @param theta Speed of mean reversion
#' @param mu Long-term mean rate (equilibrium level)
#' @param sigma Volatility parameter
#' @param N Number of steps (days)
#' @param M Number of simulation paths
#' @param dt Elapsed time increment (default 1 / 252)
#' @return A matrix of dimension (N+1) x M containing the simulated price paths
simulate_ou <- function(S0, theta, mu, sigma, N, M, dt = 1/252) {
  paths <- matrix(0, nrow = N + 1, ncol = M)
  paths[1, ] <- S0
  
  for (j in 1:M) {
    z <- rnorm(N)
    for (i in 2:(N + 1)) {
      # dS_t = theta * (mu - S_{t-1}) * dt + sigma * sqrt(dt) * Z_t
      # Explicit Euler-Maruyama discretization
      dS <- theta * (mu - paths[i - 1, j]) * dt + sigma * sqrt(dt) * z[i - 1]
      paths[i, j] <- paths[i - 1, j] + dS
      if (paths[i, j] <= 0) paths[i, j] <- 0.0001 # Absorb boundary at zero
    }
  }
  return(paths)
}

#' Volatility Clustering Simulation (Simulating GARCH-like behavior)
#' @description Simulates a return series where daily variance depends on past squared returns
#' and past variances (GARCH 1,1).
#' @param omega Constant variance source
#' @param alpha ARCH parameter (shock reaction)
#' @param beta GARCH parameter (volatility persistence)
#' @param N Number of steps
#' @return A vector of conditional standard deviations of length N
simulate_garch_volatility <- function(omega = 0.000005, alpha = 0.08, beta = 0.90, N = 252) {
  h <- numeric(N)
  eps <- numeric(N)
  
  # Initialize with long-term average variance
  unconditional_var <- omega / (1 - alpha - beta)
  h[1] <- unconditional_var
  eps[1] <- rnorm(1, mean = 0, sd = sqrt(h[1]))
  
  for (t in 2:N) {
    # h_t = omega + alpha * eps_{t-1}^2 + beta * h_{t-1}
    h[t] <- omega + alpha * (eps[t-1]^2) + beta * h[t-1]
    eps[t] <- rnorm(1, mean = 0, sd = sqrt(h[t]))
  }
  
  return(sqrt(h))
}

#' Calibrate GBM Parameters from Historical Data
#' @param returns Vector of daily log returns for a currency
#' @return A list containing annualised drift (mu) and annualised volatility (sigma)
calibrate_gbm <- function(returns) {
  # Clean potential NAs
  returns <- returns[!is.na(returns)]
  
  # Count observations
  n <- length(returns)
  if (n < 2) return(list(mu = 0.0, sigma = 0.15))
  
  daily_mean <- mean(returns)
  daily_sd <- sd(returns)
  
  # Annualize assuming 252 trading days
  mu_ann <- daily_mean * 252 + 0.5 * (daily_sd^2) * 252
  sigma_ann <- daily_sd * sqrt(252)
  
  return(list(mu = mu_ann, sigma = sigma_ann))
}
