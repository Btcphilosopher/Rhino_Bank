#' Ingestion & Normalization Pipe
#' @description Handles raw FX spot and forward market data, handles missing values,
#' aligns multiple time series, and computes log returns. Includes a fully realistic synthetic data generator.
#' @import xts zoo tidyverse

library(xts)
library(zoo)
library(tidyverse)

#' Generate Synthetic FX and Interest Rate Data for Testing
#' @param start_date Date sequence start
#' @param end_date Date sequence end
#' @return A list containing an xts object of market parameters and interest rates
generate_synthetic_market_data <- function(start_date = "2024-01-01", end_date = "2026-05-01") {
  set.seed(42)
  dates <- seq(as.Date(start_date), as.Date(end_date), by = "days")
  dates <- dates[!weekdays(dates) %in% c("Saturday", "Sunday")] # Remove weekends
  n <- length(dates)
  
  # Base Spot Rates (quoted as USD per 1 unit of foreign, i.e. Direct Quote where USD is domestic)
  # EUR (approx 1.08), GBP (approx 1.25), JPY (USD/JPY approx 155 -> direct JPY/USD is 1/155 approx 0.00645)
  eur_spot <- 1.08 + cumsum(rnorm(n, mean = 0.00005, sd = 0.004))
  gbp_spot <- 1.25 + cumsum(rnorm(n, mean = 0.00008, sd = 0.005))
  jpy_sec  <- 150.0 + cumsum(rnorm(n, mean = 0.015, sd = 0.5)) # USD/JPY
  jpy_spot <- 1 / jpy_sec # JPY/USD direct quote
  
  # Set Interest Rates (annualised)
  usd_ir <- rep(0.0525, n) + cumsum(rnorm(n, mean = 0.00001, sd = 0.0003)) # 5.25% fed funds
  eur_ir <- rep(0.0400, n) + cumsum(rnorm(n, mean = 0.00001, sd = 0.0002)) # 4.00% ECB
  gbp_ir <- rep(0.0525, n) + cumsum(rnorm(n, mean = 0.00001, sd = 0.00025)) # 5.25% BoE
  jpy_ir <- rep(0.0025, n) + cumsum(rnorm(n, mean = 0.000005, sd = 0.00005)) # 0.25% BoJ
  
  # Create actual market forward points (which deviate from pure CIP theory based on demand)
  # 3M (90 days) forward rate
  tau <- 90 / 360
  eur_fwd_theo <- eur_spot * (1 + usd_ir * tau) / (1 + eur_ir * tau)
  gbp_fwd_theo <- gbp_spot * (1 + usd_ir * tau) / (1 + gbp_ir * tau)
  jpy_fwd_theo <- jpy_spot * (1 + usd_ir * tau) / (1 + jpy_ir * tau)
  
  # Add liquidity/balance-sheet basis deviations to generate realistic market forward rates
  eur_fwd_mkt <- eur_fwd_theo + rnorm(n, mean = -0.0002, sd = 0.0001)
  gbp_fwd_mkt <- gbp_fwd_theo + rnorm(n, mean = -0.0003, sd = 0.0001)
  jpy_fwd_mkt <- jpy_fwd_theo + rnorm(n, mean = -0.00001, sd = 0.000002) # JPY basis is usually negative in dollar terms
  
  # Combine into a single dataframe
  df_raw <- data.frame(
    Date = dates,
    EUR_USD_Spot = eur_spot,
    GBP_USD_Spot = gbp_spot,
    JPY_USD_Spot = jpy_spot,
    EUR_USD_Fwd3M = eur_fwd_mkt,
    GBP_USD_Fwd3M = gbp_fwd_mkt,
    JPY_USD_Fwd3M = jpy_fwd_mkt,
    USD_Rate_3M = usd_ir,
    EUR_Rate_3M = eur_ir,
    GBP_Rate_3M = gbp_ir,
    JPY_Rate_3M = jpy_ir
  )
  
  # Simulate some random missing values to test our cleaning pipeline
  df_with_na <- df_raw
  df_with_na[sample(1:n, round(n * 0.02)), "EUR_USD_Spot"] <- NA
  df_with_na[sample(1:n, round(n * 0.02)), "GBP_USD_Spot"] <- NA
  df_with_na[sample(1:n, round(n * 0.02)), "USD_Rate_3M"] <- NA
  
  return(df_with_na)
}

#' Ingest, Clean, and Align Multiple FX Series
#' @param df Input data frame containing Date column
#' @return A cleaned xts time-series object
clean_and_align_raw_data <- function(df) {
  # Convert Date to Date class if not already
  df$Date <- as.Date(df$Date)
  
  # Create xts object
  ts_data <- xts(df[, -1], order.by = df$Date)
  
  # 1. Clean missing values using Last Observation Carried Forward (LOCF) for asset rates,
  # and linear interpolation for yield parameters
  spots <- c("EUR_USD_Spot", "GBP_USD_Spot", "JPY_USD_Spot", "EUR_USD_Fwd3M", "GBP_USD_Fwd3M", "JPY_USD_Fwd3M")
  rates <- c("USD_Rate_3M", "EUR_Rate_3M", "GBP_Rate_3M", "JPY_Rate_3M")
  
  for (col in spots) {
    ts_data[, col] <- na.locf(ts_data[, col], na.rm = FALSE)
    ts_data[, col] <- na.locf(ts_data[, col], fromLast = TRUE) # Backfill boundary conditions
  }
  
  for (col in rates) {
    ts_data[, col] <- na.approx(ts_data[, col], na.rm = FALSE)
    ts_data[, col] <- na.locf(ts_data[, col], na.rm = FALSE)
    ts_data[, col] <- na.locf(ts_data[, col], fromLast = TRUE)
  }
  
  return(ts_data)
}

#' Compute Log Returns for a list of Columns in an xts Object
#' @param ts_data Cleared xts object
#' @param cols Vector of column names
#' @return The original xts object augmented with log returns (_Ret后缀)
compute_log_returns <- function(ts_data, cols = c("EUR_USD_Spot", "GBP_USD_Spot", "JPY_USD_Spot")) {
  for (col in cols) {
    new_col_name <- paste0(col, "_Ret")
    # Log Returns: ln(S_t / S_{t-1})
    ts_data[, new_col_name] <- diff(log(ts_data[, col]))
    # Replace the initial NA return with 0 to prevent downstream computational failure
    ts_data[1, new_col_name] <- 0
  }
  return(ts_data)
}

#' Master Data Pipeline Wrapper
#' @return An aligned xts dataset containing cleaned rates and returns
run_ingestion_pipeline <- function() {
  cat("[INGESTION] Fetching raw market data...\n")
  raw_df <- generate_synthetic_market_data()
  
  cat("[INGESTION] Cleaning missing rows & interpolating curves...\n")
  cleaned_ts <- clean_and_align_raw_data(raw_df)
  
  cat("[INGESTION] Calculating log returns...\n")
  final_ts <- compute_log_returns(cleaned_ts)
  
  return(final_ts)
}
