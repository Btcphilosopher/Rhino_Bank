#' Portfolio FX Exposure Decomposition
#' @description Structure and consolidate corporate exposure profiles across transaction,
#' translation, and long-term economic risk segments.

#' Define Corporate FX Exposures Struct
#' @description Creates an aggregated exposure ledger representing international commercial flows.
#' @return A nested nested list containing transaction, translation, and economic items
create_exposure_ledger <- function() {
  # Value estimates in Millions of USD/foreign base values
  ledger <- list(
    # Transaction Risk: highly liquid short-term receivables/payables
    transaction = list(
      EUR = list(receivables = 25.0, payables = 10.0), # Net +15.0M EUR
      GBP = list(receivables = 12.0, payables = 18.0), # Net -6.0M GBP
      JPY = list(receivables = 800.0, payables = 2500.0) # Net -1700.0M JPY (approx -11M USD)
    ),
    # Translation Risk: balance sheet equity in foreign subsidiaries (denominated in local currencies)
    translation = list(
      EUR = list(assets = 150.0, liabilities = 40.0), # Net +110.0M EUR subsidiary equity
      GBP = list(assets = 95.0, liabilities = 35.0), # Net +60.0M GBP subsidiary equity
      JPY = list(assets = 3000.0, liabilities = 800.0) # Net +2200.0M JPY (approx +14.2M USD equity)
    ),
    # Economic Risk: long-term cash flow sensitivity (e.g. forecasted sales next 2 years)
    economic = list(
      EUR = list(expected_revenue = 65.0, expected_operating_cost = 20.0), # Net +45M EUR
      GBP = list(expected_revenue = 40.0, expected_operating_cost = 15.0), # Net +25M GBP
      JPY = list(expected_revenue = 5000.0, expected_operating_cost = 1200.0) # Net +3800M JPY
    )
  )
  return(ledger)
}

#' Consolidated FX Exposure Ledger into USD Equivalents
#' @param ledger Exposure ledger from `create_exposure_ledger()`
#' @param rates Vector of spot exchange rates (EUR/USD, GBP/USD, JPY/USD [where JPY is direct USD/JPY so JPY/USD is 1/S])
#' @return A neat data frame summarizing net USD exposures across channels
aggregate_portfolio_exposures <- function(ledger, eur_usd_rate, gbp_usd_rate, jpy_usd_rate) {
  # Extract Spot rates (direct quotes: USD per 1 unit of foreign)
  r_eur <- eur_usd_rate
  r_gbp <- gbp_usd_rate
  r_jpy <- jpy_usd_rate # JPY rate in USD terms (direct quote, e.g. 0.00645)
  
  # Compute Net Positions in original currencies (Millions)
  eur_trans <- ledger$transaction$EUR$receivables - ledger$transaction$EUR$payables
  gbp_trans <- ledger$transaction$GBP$receivables - ledger$transaction$GBP$payables
  jpy_trans <- ledger$transaction$JPY$receivables - ledger$transaction$JPY$payables
  
  eur_trans_usd <- eur_trans * r_eur
  gbp_trans_usd <- gbp_trans * r_gbp
  jpy_trans_usd <- jpy_trans * r_jpy
  
  # Translation net equity position
  eur_translat <- ledger$translation$EUR$assets - ledger$translation$EUR$liabilities
  gbp_translat <- ledger$translation$GBP$assets - ledger$translation$GBP$liabilities
  jpy_translat <- ledger$translation$JPY$assets - ledger$translation$JPY$liabilities
  
  eur_translat_usd <- eur_translat * r_eur
  gbp_translat_usd <- gbp_translat * r_gbp
  jpy_translat_usd <- jpy_translat * r_jpy
  
  # Economic long-term Operating position
  eur_econ <- ledger$economic$EUR$expected_revenue - ledger$economic$EUR$expected_operating_cost
  gbp_econ <- ledger$economic$GBP$expected_revenue - ledger$economic$GBP$expected_operating_cost
  jpy_econ <- ledger$economic$JPY$expected_revenue - ledger$economic$JPY$expected_operating_cost
  
  eur_econ_usd <- eur_econ * r_eur
  gbp_econ_usd <- gbp_econ * r_gbp
  jpy_econ_usd <- jpy_econ * r_jpy
  
  # Aggregate summary
  summary_tbl <- data.frame(
    Currency = c("EUR", "GBP", "JPY"),
    Spot_Rate = c(r_eur, r_gbp, r_jpy),
    Transaction_Local_M = c(eur_trans, gbp_trans, jpy_trans),
    Transaction_USD_M = c(eur_trans_usd, gbp_trans_usd, jpy_trans_usd),
    Translation_Local_M = c(eur_translat, gbp_translat, jpy_translat),
    Translation_USD_M = c(eur_translat_usd, gbp_translat_usd, jpy_translat_usd),
    Economic_Local_M = c(eur_econ, gbp_econ, jpy_econ),
    Economic_USD_M = c(eur_econ_usd, gbp_econ_usd, jpy_econ_usd)
  )
  
  # Compute total net currency exposure (Transaction + Translation + Economic)
  summary_tbl$Total_Net_USD_M <- summary_tbl$Transaction_USD_M + 
                                  summary_tbl$Translation_USD_M + 
                                  summary_tbl$Economic_USD_M
                                  
  return(summary_tbl)
}
