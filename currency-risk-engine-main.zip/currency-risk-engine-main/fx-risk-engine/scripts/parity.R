#' Interest Rate Parity Engine (CIP / UIP)
#' @description Implements Covered Interest Parity (CIP) and Uncovered Interest Parity (UIP)
#' diagnostic frameworks, assessing market efficiency, basis spreads, and currency carry returns.

#' Compute Covered Interest Parity (CIP) Arbitrage Deviations
#' @param S_t Spot rate (direct quoting: USD per unit of foreign currency)
#' @param r_d Domestic risk-free rate (USD rate, annualized)
#' @param r_f Foreign risk-free rate (annualized)
#' @param F_market Market forward rate
#' @param tenor Tenor of the contract in years (e.g. 90/360 = 0.25)
#' @return A list containing the theoretical CIP forward rate, the basis spread, and a stress level label
compute_cip_deviation <- function(S_t, r_d, r_f, F_market, tenor = 0.25) {
  # Theoretical CIP Forward: F = S * (1 + r_d * tenor) / (1 + r_f * tenor)
  # (Standard money-market convention for short-term rate contracts)
  F_theo <- S_t * (1 + r_d * tenor) / (1 + r_f * tenor)
  
  # Arbitrage basis deviation (represented in basis points)
  # Positive indicates market forward is overpricing foreign currency relative to theory.
  # Negative basis indicates expensive synthetic USD borrowing (or JPY-basis stress).
  basis_bps <- (F_market - F_theo) * 10000
  
  # Cross-currency basis spread in annual interest rate terms
  # Basis = [(F_market / S_t) * (1 + r_f * tenor) - (1 + r_d * tenor)] / tenor
  implied_basis_spread_ann <- ((F_market / S_t) * (1 + r_f * tenor) - (1 + r_d * tenor)) / tenor
  basis_spread_bps <- implied_basis_spread_ann * 10000
  
  # Determine stress indicator category
  stress_score <- abs(basis_spread_bps)
  stress_indicator <- "Low (Stable)"
  if (stress_score > 50) {
    stress_indicator <- "Extremely High (Liquidity Crisis)"
  } else if (stress_score > 20) {
    stress_indicator</span> In the context of R scripting and code quality, we avoid multi-line split characters inside string definitions. Let's make sure this code is super clean. Let's rewrite the parity file content explicitly with compact, robust syntax.    stress_indicator <- "Moderate (Macro Divergence/Friction)"
  }
  
  return(list(
    theoretical_fwd = F_theo,
    direct_basis_bps = basis_bps,
    basis_spread_ann_bps = basis_spread_bps,
    stress_score = stress_score,
    stress_indicator = stress_indicator
  ))
}

#' Run CIP Time-Series Diagnostic
#' @param ts_data An xts object from normalisation pipeline
#' @param currency_prefix "EUR", "GBP", or "JPY"
#' @return A data frame of historical basis deviations
test_historical_cip <- function(ts_data, currency_prefix = "EUR") {
  spot_col <- paste0(currency_prefix, "_USD_Spot")
  fwd_col <- paste0(currency_prefix, "_USD_Fwd3M")
  fwd_rate_col <- paste0(currency_prefix, "_Rate_3M")
  usd_rate_col <- "USD_Rate_3M"
  
  # Filter required columns
  valid_cols <- c(spot_col, fwd_col, fwd_rate_col, usd_rate_col)
  subset_ts <- ts_data[, valid_cols]
  subset_ts <- na.omit(subset_ts)
  
  dates <- index(subset_ts)
  n <- length(dates)
  
  results <- data.frame(
    Date = dates,
    Spot = as.numeric(subset_ts[, spot_col]),
    Market_Fwd = as.numeric(subset_ts[, fwd_col]),
    r_d = as.numeric(subset_ts[, usd_rate_col]),
    r_f = as.numeric(subset_ts[, fwd_rate_col])
  )
  
  # Map deviations
  deviations <- mapply(function(s, rd, rf, f_mkt) {
    res <- compute_cip_deviation(s, rd, rf, f_mkt, tenor = 0.25)
    return(c(res$theoretical_fwd, res$basis_spread_ann_bps, res$stress_score))
  }, results$Spot, results$r_d, results$r_f, results$Market_Fwd)
  
  results$Theoretical_Fwd <- deviations[1, ]
  results$Basis_Spread_bps <- deviations[2, ]
  results$Stress_Score <- deviations[3, ]
  
  return(results)
}

#' Test Uncovered Interest Parity (UIP) via Fama Regression
#' @description Runs regression: ln(S_{t+k} / S_t) = alpha + beta * (r_d - r_f) + epsilon
#' Under strict UIP, alpha = 0, beta = 1.
#' @param ts_data Cleared xts dataset
#' @param currency_prefix "EUR", "GBP", or "JPY"
#' @param lag_periods Days corresponding to forward contract maturity (e.g., 60 trading days for 3M fwd)
#' @return A summary of the UIP regression model
test_uip_fama_regression <- function(ts_data, currency_prefix = "EUR", lag_periods = 60) {
  spot_col <- paste0(currency_prefix, "_USD_Spot")
  fwd_rate_col <- paste0(currency_prefix, "_Rate_3M")
  usd_rate_col <- "USD_Rate_3M"
  
  # Align current spot, lagged spot, and interest rate differential
  temp_df <- data.frame(
    S_t = as.numeric(ts_data[, spot_col]),
    S_future = as.numeric(lag(ts_data[, spot_col], -lag_periods)), # S_{t+k}
    r_d = as.numeric(ts_data[, usd_rate_col]),
    r_f = as.numeric(ts_data[, fwd_rate_col])
  )
  temp_df <- na.omit(temp_df)
  
  # Compute realized future depreciation/appreciation
  temp_df$depreciation <- log(temp_df$S_future / temp_df$S_t)
  
  # Compute daily interest rate differential annualized (multiplied by tenor)
  # Tenor k = 90 / 360
  temp_df$ir_diff <- (temp_df$r_d - temp_df$r_f) * (90/360)
  
  # Run structural Fama linear model
  uip_model <- lm(depreciation ~ ir_diff, data = temp_df)
  model_summary <- summary(uip_model)
  
  # Extract statistics
  alpha <- coef(uip_model)[1]
  beta <- coef(uip_model)[2]
  p_val_beta <- model_summary$coefficients[2, 4]
  r_squared <- model_summary$r.squared
  
  # Under CIP/UIP, forward rate behaves as mathematical expectation.
  # If beta is negative, carriage trade is highly profitable (the Forward Premium Puzzle).
  carry_trade_profitability <- if (beta < 0) "Highly Profitable (Forward Premium Puzzle)" else "Unprofitable/Inefficient"
  
  return(list(
    model = uip_model,
    alpha = alpha,
    beta = beta,
    p_value_of_beta = p_val_beta,
    r_squared = r_squared,
    uip_holds = (p_val_beta > 0.05 && abs(beta - 1) < 0.2), # Statistically beta is close to 1
    interpretation = carry_trade_profitability
  ))
}
