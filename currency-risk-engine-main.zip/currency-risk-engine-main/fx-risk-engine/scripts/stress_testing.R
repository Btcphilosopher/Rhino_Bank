#' Stress Testing & Macroeconomic Scenario Simulator
#' @description Simulates extreme macro stress regimes and calculates portfolio-level tail losses.

#' Execute FX Exposure Stress Tests
#' @param exposures Vector of net exposures in Millions USD (labels matching currencies, e.g., "EUR", "GBP", "JPY")
#' @return A data frame containing stress test scenarios, currency shifts, and portfolio outcomes
run_systemic_stress_tests <- function(exposures) {
  # Scenarios definition: percentage changes in foreign currency values relative to USD
  # Positive means foreign appreciates (positive return for long position),
  # Negative means foreign depreciates (negative return for long position).
  scenarios <- list(
    `2008 Financial Crisis Shock` = list(
      EUR = -0.15, # EUR crashes
      GBP = -0.18, # GBP crashes
      JPY = 0.20   # JPY rallies strongly (safe haven unwind)
    ),
    `Sudden USD Strength Regime` = list(
      EUR = -0.10,
      GBP = -0.10,
      JPY = -0.12
    ),
    `Emerging Market / Risk Off Crisis` = list(
      EUR = -0.05,
      GBP = -0.05,
      JPY = -0.25 # Carry trade unwind or massive Yen dump if flight to USD is extreme
    ),
    `Interest Rate Divergence (Fed Hikes)` = list(
      EUR = -0.08,
      GBP = -0.06,
      JPY = -0.15
    )
  )
  
  results <- data.frame(
    Scenario = character(),
    Currency = character(),
    Exposure_USD_M = numeric(),
    Shock_Pct = numeric(),
    Asset_Loss_USD_M = numeric(),
    stringsAsFactors = FALSE
  )
  
  portfolio_total_losses <- data.frame(
    Scenario = character(),
    Total_Portfolio_Loss_USD_M = numeric(),
    Risk_Tier = character(),
    stringsAsFactors = FALSE
  )
  
  for (scen_name in names(scenarios)) {
    curr_scen <- scenarios[[scen_name]]
    total_loss <- 0
    
    for (curr in names(exposures)) {
      exp_val <- exposures[curr]
      # Defaults to static 0 if currency not defined in scenario
      shock <- ifelse(curr %in% names(curr_scen), curr_scen[[curr]], 0.0)
      
      # Loss calculation: exposure * shock
      # Negative loss means a physical reduction in USD portfolio value (a dollar loss)
      pnl_impact <- exp_val * shock
      
      # We represent results as loss (so positive number means loss)
      item_loss <- -pnl_impact
      
      results <- rbind(results, data.frame(
        Scenario = scen_name,
        Currency = curr,
        Exposure_USD_M = exp_val,
        Shock_Pct = shock * 100,
        Asset_Loss_USD_M = item_loss
      ))
      
      total_loss <- total_loss + item_loss
    }
    
    risk_label <- ifelse(total_loss > 15.0, "Critical Red",
                    ifelse(total_loss > 5.0, "Elevated Alert", "Manageable Range"))
                    
    portfolio_total_losses <- rbind(portfolio_total_losses, data.frame(
      Scenario = scen_name,
      Total_Portfolio_Loss_USD_M = total_loss,
      Risk_Tier = risk_label
    ))
  }
  
  return(list(
    granular_shocks = results,
    portfolio_summary = portfolio_total_losses
  ))
}
