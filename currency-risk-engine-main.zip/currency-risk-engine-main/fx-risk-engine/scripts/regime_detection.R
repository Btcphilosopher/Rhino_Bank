#' Volatility & Trend FX Regime Classifier
#' @description Applies quantitative clustering algorithms (K-Means) and rolling
#' volatility thresholds to classify active currency market regimes.

#' Classify Market Regimes using K-Means Clustering on Rolling Historical Data
#' @param returns Vector of portfolios or individual currency daily log returns
#' @param window_size Lookback loop to compute rolling statistics (e.g. 20 trading days = 1 Month)
#' @param k Number of target regimes (typically 3 or 4)
#' @return A list containing structured regime assignments, features data, and diagnostic metrics
detect_market_regimes <- function(returns, window_size = 20, k = 3) {
  n <- length(returns)
  if (n < (window_size + 10)) {
    stop("[REGIME DETECTION] Return history insufficient to compute rolling parameters.")
  }
  
  # Compute rolling annualized volatility & rolling annualized mean return
  rolling_vol <- numeric(n)
  rolling_mean <- numeric(n)
  
  for (t in window_size:n) {
    window_pts <- returns[(t - window_size + 1):t]
    rolling_vol[t] <- sd(window_pts, na.rm = TRUE) * sqrt(252)
    rolling_mean[t] <- mean(window_pts, na.rm = TRUE) * 252
  }
  
  # Align features vectors starting from window bounds
  features <- data.frame(
    Idx = window_size:n,
    Vol = rolling_vol[window_size:n],
    Mean = rolling_mean[window_size:n]
  )
  features_scaled <- scale(features[, c("Vol", "Mean")])
  
  # Run k-means clustering to segment regimes
  set.seed(88)
  kmeans_mod <- kmeans(features_scaled, centers = k, nstart = 25)
  cluster_ids <- kmeans_mod$cluster
  
  # Label the clusters based on their average volatility & mean return profiles
  cluster_centers <- as.data.frame(kmeans_mod$centers)
  cluster_centers$Original_Cluster <- 1:k
  
  # Rank centers by Volatility to assign human labels:
  # Lowest volatility is "Low Vol / Rangebound"
  # Highest volatility is "High Vol / Crisis"
  # Intermediate is "Trend-Driven Cycle"
  ordered_by_vol <- order(cluster_centers$Vol)
  
  regime_mapping <- numeric(k)
  regime_labels <- character(k)
  
  regime_labels[ordered_by_vol[1]] <- "Low Volatility Stable"
  if (k == 3) {
    regime_labels[ordered_by_vol[2]] <- "Trend-Driven USD Cycle"
    regime_labels[ordered_by_vol[3]] <- "High Volatility Crisis"
  } else if (k == 4) {
    # If four clusters requested, split intermediates or classify specifically
    regime_labels[ordered_by_vol[2]] <- "Trend-Driven USD Cycle"
    regime_labels[ordered_by_vol[3]] <- "Liquidity Stress Regime"
    regime_labels[ordered_by_vol[4]] <- "High Volatility Crisis"
  }
  
  # Map features data frame with regime assignments
  features$Cluster_ID <- cluster_ids
  features$Regime <- regime_labels[cluster_ids]
  
  return(list(
    clustered_data = features,
    centers = cluster_centers,
    regime_definitions = data.frame(Cluster_ID = 1:k, Derived_Regime = regime_labels)
  ))
}
