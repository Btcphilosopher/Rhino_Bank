#' FX Value-at-Risk (VaR) & Expected Shortfall (CVaR) Engine
#' @description Computes multi-level portfolio FX risk under Historical, Parametric,
#' and Monte Carlo (stochastic path projection) methodologies.

#' Compute Parametric Portfolio FX VaR
#' @param exposures Vector of net USD exposures per currency (e.g., c(EUR = 10, GBP = -5, JPY = -3))
#' @param cov_matrix Covariance matrix of daily log returns
#' @param confidence_level (0.95 or 0.99)
#' @param holding_period Holding period in days (e.g. 10 day VaR)
#' @return A list containing daily and multi-day Parametric VaR and CVaR (assuming normal distribution)
compute_parametric_var <- function(exposures, cov_matrix, confidence_level = 0.95, holding_period = 10) {
  # Align exposures vector with covariance names
  names_exp <- names(exposures)
  names_cov <- colnames(cov_matrix)
  common <- intersect(names_exp, names_cov)
  
  if (length(common) == 0) {
    stop("[VaR ENGINE] Exposure currency labels do not match covariance matrix column names.")
  }
  
  w <- exposures[common]
  sigma_matrix <- cov_matrix[common, common]
  
  # Portfolio Variance: w^T * Sigma * w
  port_daily_variance <- as.numeric(t(w) %*% sigma_matrix %*% w)
  port_daily_sd <- sqrt(port_daily_variance)
  
  # Standard normal inverse quantile
  z_score <- qnorm(confidence_level)
  
  # Daily VaR (USD Millions)
  var_daily <- z_score * port_daily_sd
  
  # Multi-period VaR under the Square Root of Time rule
  var_multi <- var_daily * sqrt(holding_period)
  
  # Closed-form Expected Shortfall (CVaR) for Normal distribution:
  # CVaR = w_p * [ (1 / (1 - alpha)) * phi(z_alpha) * daily_sd ]
  # where phi is standard normal PDF
  phi_z <- dnorm(z_score)
  cvar_daily <- port_daily_sd * (phi_z / (1 - confidence_level))
  cvar_multi <- cvar_daily * sqrt(holding_period)
  
  return(list(
    portfolio_daily_sd = port_daily_sd,
    var_daily = var_daily,
    var_holding_period = var_multi,
    cvar_daily = cvar_daily,
    cvar_holding_period = cvar_multi,
    holding_period = holding_period,
    confidence_level = confidence_level
  ))
}

#' Compute Historical Simulation VaR and CVaR
#' @param exposures Vector of net USD exposures per currency
#' @param return_series An xts object containing daily log-return columns
#' @param confidence_level (0.95 or 0.99)
#' @param holding_period Holding period in days (scale daily metrics by sqrt(t))
#' @return A list containing daily and multi-day Historical VaR and CVaR
compute_historical_var <- function(exposures, return_series, confidence_level = 0.95, holding_period = 10) {
  currencies <- names(exposures)
  
  # Filter returns belonging to exposures
  ret_cols <- paste0(currencies, "_USD_Spot_Ret")
  valid_ret_cols <- intersect(ret_cols, colnames(return_series))
  
  if (length(valid_ret_cols) == 0) {
    stop("[VaR ENGINE] Return matrix does not contain returns matching designated exposures.")
  }
  
  # Extract names corresponding to returns
  mapped_currencies <- gsub("_USD_Spot_Ret", "", valid_ret_cols)
  w <- exposures[mapped_currencies]
  
  # Extracted daily returns
  returns_mat <- as.matrix(return_series[, valid_ret_cols])
  
  # Generate synthetic historical losses on today's portfolio: loss = -R_p = -sum(weight_i * return_i)
  # (Remember positive returns -> profit, negative returns -> loss)
  portfolio_daily_returns <- returns_mat %*% w
  portfolio_daily_losses <- -portfolio_daily_returns
  
  # Exclude potential NA values
  portfolio_daily_losses <- as.numeric(na.omit(portfolio_daily_losses))
  
  # VaR is the empirical quantile at confidence level alpha
  var_daily <- quantile(portfolio_daily_losses, probs = confidence_level)
  var_multi <- var_daily * sqrt(holding_period)
  
  # Expected Shortfall (CVaR) represents average of losses exceeding the VaR value
  tail_losses <- portfolio_daily_losses[portfolio_daily_losses >= var_daily]
  cvar_daily <- mean(tail_losses)
  cvar_multi <- cvar_daily * sqrt(holding_period)
  
  return(list(
    var_daily = as.numeric(var_daily),
    var_holding_period = as.numeric(var_multi),
    cvar_daily = as.numeric(cvar_daily),
    cvar_holding_period = as.numeric(cvar_multi),
    holding_period = holding_period,
    confidence_level = confidence_level
  ))
}

#' Compute Monte Carlo Simulated VaR and CVaR
#' @description Project currency paths via Geometric Brownian Motion (GBM) utilizing empirical
#' correlation structures, and evaluate final portfolio value.
#' @param exposures Net exposures vector in Millions USD
#' @param spot_rates Starting spot rates for simulating currencies
#' @param return_series Historical returns series to extract covariance & correlations
#' @param confidence_level (0.95 or 0.99)
#' @param steps Risk horizon in days (e.g. 10 days)
#' @param paths_count Total simulated iterations (default 10000)
#' @return A list containing Monte Carlo simulated portfolio final valuations, loss vector, VaR, and CVaR
compute_monte_carlo_var <- function(exposures, spot_rates, return_series, confidence_level = 0.95, steps = 10, paths_count = 5000) {
  set.seed(1337)
  currencies <- names(exposures)
  n_currencies <- length(currencies)
  
  # Select currency returns
  ret_cols <- paste0(currencies, "_USD_Spot_Ret")
  ret_matrix <- as.matrix(na.omit(return_series[, ret_cols]))
  
  # Compute daily covariance matrix
  cov_daily <- cov(ret_matrix)
  
  # Compute daily mean returns (drift components)
  mean_daily <- colMeans(ret_matrix)
  
  # Cholesky Decomposition of Covariance: Sigma = L * L^T  for multi-variable normal generation
  # Using pivot=TRUE helps with near semi-definite structures
  L <- t(chol(cov_daily))
  
  # Log return projections matrix
  portfolio_losses <- numeric(paths_count)
  
  # Simulate the multi-step horizon for each path
  for (p in 1:paths_count) {
    # Cumulative random shock vector spanning path duration
    path_returns <- numeric(n_currencies)
    names(path_returns) <- currencies
    
    # Step-by-step path returns update with correlation
    accumulated_ret <- numeric(n_currencies)
    for (s in 1:steps) {
      z <- rnorm(n_currencies)
      correlated_z <- as.numeric(L %*% z)
      
      # Step return = drift - 0.5 * sigma^2 + correlated shock
      # (Approximate daily GBM return vector step)
      step_ret <- mean_daily - 0.5 * diag(cov_daily) + correlated_z
      accumulated_ret <- accumulated_ret + step_ret
    }
    
    # Portfolio value impact
    # End Value of each position: S_T = S_0 * exp(accumulated_return)
    # Position Loss = original_value - discounted_final_value
    # Since exposures are already in USD, we apply the currency rate return directly:
    # Loss_i = Exposure_USD_i * (1 - exp(accumulated_return_i))
    position_losses <- exposures * (1 - exp(accumulated_ret))
    portfolio_losses[p] <- sum(position_losses)
  }
  
  # Extract VaR & Expected Shortfall (CVaR) percentiles from simulated loss distribution
  mc_var <- quantile(portfolio_losses, probs = confidence_level)
  mc_tail <- portfolio_losses[portfolio_losses >= mc_var]
  mc_cvar <- mean(mc_tail)
  
  return(list(
    losses = portfolio_losses,
    var_holding_period = as.numeric(mc_var),
    cvar_holding_period = as.numeric(mc_cvar),
    holding_period = steps,
    confidence_level = confidence_level
  ))
}
