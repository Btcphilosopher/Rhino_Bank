#' Cross-Currency Basis Spread & Funding Stress Analytics
#' @description Computes systemic currency basis spreads to identify structural funding stress,
#' local liquidity demands, and shadow funding premiums in global cash pools.

#' Compute Cross-Currency Basis Curve Points
#' @param spots Vector of spot exchange rates
#' @param forwards Vector of actual market forwards
#' @param r_dom Domestic funding interest rates (annual USD Libor/SOFR equivalent)
#' @param r_for Foreign funding interest rates (annual EURIBOR/TONAR counterpart)
#' @param tenor Maturity tenor fraction (e.g. 0.25 for 3 Months)
#' @return A data frame containing basis spreads and normalized systemic stress indices
calculate_systemic_basis_stress <- function(spots, forwards, r_dom, r_for, tenor = 0.25) {
  n <- length(spots)
  
  # Implied USD Repo funding rate from CIP synthetic borrowing:
  # r_synthetic = [(F_market / S) * (1 + r_foreign * tenor) - 1] / tenor
  r_synthetic <- ((forwards / spots) * (1 + r_for * tenor) - 1) / tenor
  
  # Basis spread = r_domestic - r_synthetic
  # Expressed in basis points (1 basis point = 0.0001 or 0.01% in interest rate terms)
  basis_spread_bps <- (r_dom - r_synthetic) * 10000
  
  # Systemic Stress Index (SSI)
  # A standardized score mapping the magnitude of basis widening to liquidity strain indicators.
  # Based on absolute deviation from historical parity bounds
  ssi_score <- scale(abs(basis_spread_bps))
  # In case vector length is 1 or scale returns NA
  ssi_score[is.na(ssi_score)] <- abs(basis_spread_bps)[is.na(ssi_score)] / 10 # heuristic benchmark
  
  # Classify liquidity environment
  liquidity_regime <- ifelse(abs(basis_spread_bps) > 45, "Severe Dollar Funding Shortage / Cross-Border Liquidity Choke",
                        ifelse(abs(basis_spread_bps) > 20, "Moderate Balance Sheet Constrianed Friction", "Healthy Arbitrage Alignment"))
  
  results <- data.frame(
    Step = 1:n,
     r_synthetic = r_synthetic,
    Basis_Spread_Bps = basis_spread_bps,
    Systemic_Stress_Score = as.numeric(ssi_score),
    Funding_Category = liquidity_regime
  )
  
  return(results)
}
