#' Production-Grade FX Risk Visualizations Templates
#' @description Harnesses ggplot2 and plotly graphics to generate rich institutional-grade
#' risk plots. Includes plotting modules for spots, forwards, VaR histograms, and hedges.

library(ggplot2)

#' Plot Histograms of Portfolio Returns with VaR & CVaR lines
#' @param losses Vector of simulated losses (millions USD)
#' @param var_val Calculated Value at Risk threshold
#' @param cvar_val Calculated Expected Shortfall (CVaR) threshold
#' @param confidence_level (0.95 or 0.99)
#' @return A ggplot object
plot_value_at_risk_distribution <- function(losses, var_val, cvar_val, confidence_level = 0.95) {
  df <- data.frame(Loss = losses)
  
  p <- ggplot(df, aes(x = Loss)) +
    geom_histogram(bins = 60, fill = "#1e293b", color = "#475569", alpha = 0.85) +
    geom_vline(aes(xintercept = var_val, color = "Value at Risk (VaR)"), linetype = "dashed", size = 1.1) +
    geom_vline(aes(xintercept = cvar_val, color = "Expected Shortfall (CVaR)"), linetype = "solid", size = 1.1) +
    scale_color_manual(name = "Risk Thresholds", values = c("Value at Risk (VaR)" = "#f43f5e", "Expected Shortfall (CVaR)" = "#b91c1c")) +
    labs(
      title = paste0("Monte Carlo Portfolio Loss Distribution (", confidence_level * 100, "% Confidence)"),
      subtitle = "Red dashed/solid thresholds denote extreme portfolio-level value at risk and tail bounds.",
      x = "Simulated Portfolio Loss (USD Millions)",
      y = "Simulation Paths Density / Frequency"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 14, color = "#0f172a"),
      legend.position = "bottom"
    )
    
  return(p)
}

#' Plot Hedged vs Unhedged Accumulative P&L Curves
#' @param df Data frame with columns PnL_Unhedged, PnL_FullHedge, PnL_PartialHedge
#' @return A ggplot object
plot_hedging_curves <- function(df) {
  # Reshape data into long format for ggplot
  df_long <- pivot_longer(df, cols = starts_with("PnL_"), names_to = "Strategy", values_to = "PnL")
  df_long$Strategy <- gsub("PnL_", "", df_long$Strategy)
  
  p <- ggplot(df_long, aes(x = Step, y = PnL, color = Strategy)) +
    geom_line(size = 1) +
    scale_color_manual(name = "Hedging Strategy", 
                       values = c("Unhedged" = "#f43f5e", "FullHedge" = "#10b981", "PartialHedge" = "#2563eb")) +
    labs(
      title = "Currency Hedging Strategy Simulation Comparison",
      subtitle = "P&L tracking comparing unhedged exposure, 100% full forward lock, and a partial/dynamic hedge policy.",
      x = "Timeline Backtest Horizon (Days)",
      y = "Cumulative Strategy P&L (USD Millions)"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 14, color = "#0f172a"),
      legend.position = "bottom"
    )
    
  return(p)
}

#' Plot Interest Parity Deviation & Basis Spread Time-Series
#' @param results_df CIP results data frame from `test_historical_cip`
#' @param currency_prefix Currency being plotted (e.g., "EUR")
#' @return A ggplot object
plot_cip_deviations <- function(results_df, currency_prefix = "EUR") {
  p <- ggplot(results_df, aes(x = Date, y = Basis_Spread_bps)) +
    geom_line(color = "#4f46e5", size = 0.8) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
    labs(
      title = paste0(currency_prefix, "/USD Covered Interest Parity (CIP) Deviations"),
      subtitle = "Fluctuations capture shadow funding costs, repo pressures, and currency-basis deviations.",
      x = "Query Horizon Timeline",
      y = "Basis Spread Premium (Basis Points)"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 14, color = "#0f172a")
    )
  
  return(p)
}
