#' Derivative Hedging Simulator
#' @description Simulates derivative-based hedging policies, quantifying hedged
#' vs unhedged P&L paths, determining Hedge Effectiveness Ratios (HER),
#' and plotting variance reduction.

#' Simulate Hedging of a Future Exposure
#' @description Backtests 3 primary treasury hedging setups: No Hedge, Full Hedge, and Partial/Dynamic Rolling Hedge.
#' @param initial_exposure Size of original foreign currency exposure (local units, e.g. 10.0M EUR)
#' @param spot_series Historical spot rates (vector or class numeric)
#' @param forward_series Historical actual market forward rates (vector or class numeric)
#' @param hedge_ratio Proportion of exposure hedged (e.g. 1.0 for Full, 0.60 for Partial)
#' @param rolling_window Re-hedging adjustment frequency (days)
#' @return A data frame containing cumulative P&L under different hedging setups
simulate_hedging_strategies <- function(initial_exposure, spot_series, forward_series, hedge_ratio = 0.70, rolling_window = 20) {
  n <- length(spot_series)
  if (n != length(forward_series)) {
    stop("[HEDGING ENGINE] Length mismatch: spot and forward curve series must align.")
  }
  
  # Tracks value of unhedged and hedged portfolios
  pnl_unhedged <- numeric(n)
  pnl_full_hedge <- numeric(n)
  pnl_partial_hedge <- numeric(n)
  
  # Starting spot rate
  S0 <- spot_series[1]
  F0 <- forward_series[1]
  
  # Initial baseline USD value
  v_base0 <- initial_exposure * S0
  
  # Loop to evaluate historical path
  for (t in 1:n) {
    S_t <- spot_series[t]
    
    # Unhedged Port P&L (USD): exposure * (S_t - S_0)
    pnl_unhedged[t] <- initial_exposure * (S_t - S0)
    
    # 100% Fully Hedged Port P&L:
    # Locked in rate S_forward = F_0. The actual derivative payout is initial_exposure * (F0 - S_t)
    # Total P&L = Spot P&L + Derivative P&L = exposure*(S_t - S0) + exposure*(F0 - S_t) = exposure*(F0 - S0)
    # Reflects locking in the initial forward premium/discount.
    derivative_payout_full <- initial_exposure * (F0 - S_t)
    pnl_full_hedge[t] <- pnl_unhedged[t] + derivative_payout_full
    
    # Partial Hedging Strategy (Static blend based on hedge_ratio)
    derivative_payout_partial <- (initial_exposure * hedge_ratio) * (F0 - S_t)
    pnl_partial_hedge[t] <- pnl_unhedged[t] + derivative_payout_partial
  }
  
  # Calculate statistics
  vol_unhedged <- sd(pnl_unhedged)
  vol_full <- sd(pnl_full_hedge)
  vol_partial <- sd(pnl_partial_hedge)
  
  # Hedge Effectiveness Ratio (HER): 1 - Var(Hedged_P&L) / Var(Unhedged_P&L)
  her_full <- 1 - (var(pnl_full_hedge) / var(pnl_unhedged))
  her_partial <- 1 - (var(pnl_partial_hedge) / var(pnl_unhedged))
  
  # Volatility reduction %
  vol_red_full <- (vol_unhedged - vol_full) / vol_unhedged * 100
  vol_red_partial <- (vol_unhedged - vol_partial) / vol_unhedged * 100
  
  results_df <- data.frame(
    Step = 1:n,
    Spot = spot_series,
    Market_Forward = forward_series,
    PnL_Unhedged = pnl_unhedged,
    PnL_FullHedge = pnl_full_hedge,
    PnL_PartialHedge = pnl_partial_hedge
  )
  
  metrics <- list(
    volatility_unhedged = vol_unhedged,
    volatility_full = vol_full,
    volatility_partial = vol_partial,
    her_full = max(0, her_full),
    her_partial = max(0, her_partial),
    vol_reduction_full_pct = vol_red_full,
    vol_reduction_partial_pct = vol_red_partial
  )
  
  return(list(data = results_df, metrics = metrics))
}
