/**
 * RhinoQuant Synthetic Interest Rate Engine - Core Types
 * Typed financial domain models for multi-market rate construction,
 * conventions, adjustments, validation and governance.
 */

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF';

export type Tenor = 'ON' | '1W' | '1M' | '3M' | '6M' | '1Y' | '2Y' | '5Y';

export type DayCountConvention = 'ACT/360' | 'ACT/365F' | '30/360' | 'ACT/ACT';

export type CompoundingBasis = 'Simple' | 'CompoundedDaily' | 'Annual' | 'SemiAnnual' | 'Continuous';

export type EconomicPurpose =
  | 'OVERNIGHT_FUNDING'
  | 'TERM_FUNDING'
  | 'UNSECURED_BANK_FUNDING'
  | 'CARRY_IMPLIED_FINANCING'
  | 'STRUCTURED_CREDIT_FINANCING'
  | 'CROSS_CURRENCY_FUNDING'
  | 'COMMERCIAL_RECEIVABLES';

export type MarketCategory =
  | 'OVERNIGHT_BENCHMARK'
  | 'TERM_OIS'
  | 'REPO_SECURED'
  | 'UNSECURED_WHOLESALE'
  | 'CP_CD'
  | 'FX_FORWARD_CIP'
  | 'CROSS_CURRENCY_BASIS'
  | 'CREDIT_SPREAD'
  | 'STRUCTURED_CREDIT'
  | 'COMMODITY_BOND_CARRY';

export interface MarketObservation {
  id: string;
  symbol: string;
  name: string;
  category: MarketCategory;
  currency: Currency;
  tenor: Tenor;
  tenorDays: number;
  rawRateOrPrice: number;
  unit: 'PERCENT' | 'POINTS' | 'SPREAD_BPS' | 'PRICE';
  dayCount: DayCountConvention;
  compounding: CompoundingBasis;
  collateralType: 'SECURED_GOVT' | 'SECURED_CORP' | 'UNSECURED' | 'STRUCTURED';
  creditQuality: 'RISK_FREE' | 'AAA' | 'AA' | 'A' | 'BBB' | 'SUB_IG';
  observationTime: string;
  provider: string;
  qualityScore: number; // 0 - 100
  bid?: number;
  ask?: number;
  volumeMillionsUSD?: number;
  isSimulated: boolean;
  notes?: string;
}

export interface NormalisationAdjustment {
  sourceConvention: string;
  targetConvention: string;
  dayCountDeltaBps: number;
  compoundingDeltaBps: number;
  creditRiskBps: number;
  liquidityRiskBps: number;
  collateralEffectBps: number;
  currencyBasisBps: number;
  termPremiumBps: number;
  transactionCostBps: number;
  isObserved: boolean;
  modelRationale: string;
}

export interface NormalisedObservation {
  observationId: string;
  symbol: string;
  name: string;
  category: MarketCategory;
  rawRate: number;
  transformedAnnualRate: number; // In percent e.g. 5.12
  adjustments: NormalisationAdjustment;
  netAdjustedRate: number; // In percent
  weight: number; // 0 to 1
  effectiveContribution: number; // In percent
  eligible: boolean;
  exclusionReason?: string;
  dataQualityScore: number;
  observationTime: string;
}

export interface RateBridgeStep {
  stepIndex: number;
  label: string;
  category: 'BASE' | 'CONVENTION' | 'COLLATERAL' | 'CREDIT' | 'LIQUIDITY' | 'CURRENCY' | 'TERM' | 'COST' | 'OUTPUT';
  deltaBps: number;
  cumulativeRatePercent: number;
  isObserved: boolean;
  sourceDescription: string;
}

export interface ValidationCheckResult {
  id: string;
  name: string;
  category: 'INTEGRITY' | 'CONCENTRATION' | 'RESIDUAL' | 'STALENESS' | 'OUTLIER' | 'BENCHMARK';
  status: 'PASS' | 'WARNING' | 'FAIL';
  threshold: string;
  observedValue: string;
  detail: string;
}

export interface SyntheticRateDefinition {
  id: string;
  version: string;
  name: string;
  purpose: EconomicPurpose;
  targetCurrency: Currency;
  targetTenor: Tenor;
  targetDayCount: DayCountConvention;
  targetCompounding: CompoundingBasis;
  constructionMethod:
    | 'WEIGHTED_VOLUME'
    | 'INVERSE_VARIANCE'
    | 'RISK_ADJUSTED_SPREAD'
    | 'FORWARD_CURVE_BOOTSTRAP'
    | 'SOLVER_IRR'
    | 'ROBUST_HUBER_COMPOSITE';
  selectedInstrumentIds: string[];
  manualWeights?: Record<string, number>;
  creditSpreadOverrideBps?: number;
  liquidityPremiumOverrideBps?: number;
  collateralHaircutPct?: number;
  status: 'DRAFT' | 'APPROVED' | 'PUBLISHED' | 'REJECTED';
  author: string;
  approvedBy?: string;
  governanceNotes: string;
}

export interface RateConstructionResult {
  definitionId: string;
  definitionName: string;
  purpose: EconomicPurpose;
  targetCurrency: Currency;
  targetTenor: Tenor;
  outputRatePercent: number;
  outputDiscountFactor: number;
  benchmarkComparison: {
    benchmarkName: string;
    benchmarkRatePercent: number;
    spreadBps: number;
  };
  components: NormalisedObservation[];
  rateBridge: RateBridgeStep[];
  validationChecks: ValidationCheckResult[];
  overallValidationPassed: boolean;
  dataQualityIndex: number; // 0 - 100
  herfindahlIndex: number; // HHI for source concentration
  timestamp: string;
  executionHash: string;
  warnings: string[];
  limitations: string[];
}

export interface YieldCurvePoint {
  tenor: Tenor;
  days: number;
  yearFraction: number;
  syntheticRatePercent: number;
  discountFactor: number;
  forwardRatePercent: number;
  benchmarkRatePercent: number;
  basisSpreadBps: number;
  isInterpolated?: boolean;
}

export interface CDOTranche {
  id: string;
  name: string;
  tier: 'SENIOR_AAA' | 'MEZZANINE_BBB' | 'SUBORDINATED_BB' | 'EQUITY_FIRST_LOSS';
  attachmentPoint: number; // e.g. 0.15 (15%)
  detachmentPoint: number; // e.g. 1.00 (100%)
  thickness: number;
  notionalMillions: number;
  contractualCouponBps: number;
  marketPricePct: number;
  subordinationPct: number;
  expectedLossPct: number;
  contractualYieldPercent: number;
  expectedCashFlowYieldPercent: number;
  marketImpliedYieldPercent: number;
  riskAdjustedFundingSpreadBps: number;
}

export interface CDOPool {
  id: string;
  name: string;
  assetClass: 'CORPORATE_LOANS' | 'TRADE_RECEIVABLES' | 'COMMERCIAL_REAL_ESTATE' | 'SUPPLY_CHAIN_INVOICES';
  totalNotionalMillions: number;
  assetCount: number;
  weightedAverageCouponPct: number;
  weightedAverageMaturityYears: number;
  annualDefaultProbabilityPct: number;
  recoveryRatePct: number;
  assetCorrelationPct: number;
  prepaymentCPR: number;
  servicingFeeBps: number;
  tranches: CDOTranche[];
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  fundingShockBps: number;
  creditSpreadMultiplier: number;
  defaultProbabilityShockMultiplier: number;
  fxBasisDislocationBps: number;
  liquidityFreezeBps: number;
}
