/**
 * Financial Conventions and Day-Count Arithmetic
 * Implements precise institutional interest rate conversions, day-count fractions,
 * and compounding transformation logic.
 */

import { DayCountConvention, CompoundingBasis, Tenor } from './types';

/**
 * Standard business days / calendar days per tenor
 */
export function tenorToCalendarDays(tenor: Tenor): number {
  switch (tenor) {
    case 'ON':
      return 1;
    case '1W':
      return 7;
    case '1M':
      return 30;
    case '3M':
      return 90;
    case '6M':
      return 180;
    case '1Y':
      return 360;
    case '2Y':
      return 720;
    case '5Y':
      return 1800;
    default:
      return 90;
  }
}

/**
 * Calculate accrual year fraction \tau based on day-count convention
 */
export function calculateYearFraction(
  days: number,
  convention: DayCountConvention
): number {
  switch (convention) {
    case 'ACT/360':
      return days / 360.0;
    case 'ACT/365F':
      return days / 365.0;
    case '30/360':
      return days / 360.0;
    case 'ACT/ACT':
      return days / 365.25;
    default:
      return days / 360.0;
  }
}

/**
 * Calculate Present Value factor (Discount Factor) from annual simple rate r
 */
export function simpleRateToDiscountFactor(rateAnnual: number, yearFraction: number): number {
  return 1.0 / (1.0 + rateAnnual * yearFraction);
}

/**
 * Convert a rate from source (dayCount1, compounding1) to target (dayCount2, compounding2)
 * using the discount factor invariant: P(0, \tau) must be preserved.
 *
 * @param rateAnnual Source rate expressed as decimal (e.g. 0.05 for 5%)
 * @param days Tenor in calendar days
 * @param sourceDayCount Source day-count convention
 * @param sourceCompounding Source compounding convention
 * @param targetDayCount Target day-count convention
 * @param targetCompounding Target compounding convention
 * @returns Converted rate as decimal (e.g. 0.0506)
 */
export function normaliseInterestRate(
  rateAnnual: number,
  days: number,
  sourceDayCount: DayCountConvention,
  sourceCompounding: CompoundingBasis,
  targetDayCount: DayCountConvention,
  targetCompounding: CompoundingBasis
): number {
  const tauSource = calculateYearFraction(days, sourceDayCount);
  const tauTarget = calculateYearFraction(days, targetDayCount);

  if (tauSource <= 0 || tauTarget <= 0) return rateAnnual;

  // 1. Compute implied Future Value factor FV / PV for the period
  let fvFactor: number;

  switch (sourceCompounding) {
    case 'Simple':
      fvFactor = 1.0 + rateAnnual * tauSource;
      break;
    case 'CompoundedDaily':
      fvFactor = Math.pow(1.0 + (rateAnnual / 360.0), 360.0 * tauSource);
      break;
    case 'Annual':
      fvFactor = Math.pow(1.0 + rateAnnual, tauSource);
      break;
    case 'SemiAnnual':
      fvFactor = Math.pow(1.0 + rateAnnual / 2.0, 2.0 * tauSource);
      break;
    case 'Continuous':
      fvFactor = Math.exp(rateAnnual * tauSource);
      break;
    default:
      fvFactor = 1.0 + rateAnnual * tauSource;
  }

  // 2. Derive target rate equating fvFactor under target conventions
  let targetRate: number;

  switch (targetCompounding) {
    case 'Simple':
      targetRate = (fvFactor - 1.0) / tauTarget;
      break;
    case 'CompoundedDaily':
      targetRate = 360.0 * (Math.pow(fvFactor, 1.0 / (360.0 * tauTarget)) - 1.0);
      break;
    case 'Annual':
      targetRate = Math.pow(fvFactor, 1.0 / tauTarget) - 1.0;
      break;
    case 'SemiAnnual':
      targetRate = 2.0 * (Math.pow(fvFactor, 1.0 / (2.0 * tauTarget)) - 1.0);
      break;
    case 'Continuous':
      targetRate = Math.log(fvFactor) / tauTarget;
      break;
    default:
      targetRate = (fvFactor - 1.0) / tauTarget;
  }

  return targetRate;
}

/**
 * Compound overnight rate observations over a sequence of days with weekend weights
 * Standard ISDA / SOFR Compounding formula:
 * R_comp = [ \prod_{i=1}^{d_b} (1 + r_i * n_i / 360) - 1 ] * (360 / N)
 *
 * @param dailyRates Daily overnight fixings as decimals (e.g., [0.0485, 0.0486, ...])
 * @param dayWeights Days accrued per fixing (e.g. 1 for weekdays, 3 for Friday fixing over weekend)
 * @param basis Annual denominator (usually 360 for USD SOFR/EUR €STR, 365 for GBP SONIA)
 */
export function compoundOvernightRates(
  dailyRates: number[],
  dayWeights: number[],
  basis: number = 360
): { compoundedRateAnnual: number; totalDays: number; growthFactor: number } {
  let product = 1.0;
  let totalDays = 0;

  for (let i = 0; i < dailyRates.length; i++) {
    const r = dailyRates[i];
    const n = dayWeights[i] ?? 1;
    product *= 1.0 + (r * n) / basis;
    totalDays += n;
  }

  if (totalDays === 0) return { compoundedRateAnnual: 0, totalDays: 0, growthFactor: 1.0 };

  const compoundedRateAnnual = (product - 1.0) * (basis / totalDays);
  return { compoundedRateAnnual, totalDays, growthFactor: product };
}

/**
 * Standard forward rate formula between T1 and T2:
 * F(T1, T2) = [ P(0, T1) / P(0, T2) - 1 ] / alpha(T1, T2)
 */
export function calculateForwardRate(
  dfT1: number,
  dfT2: number,
  accrualAlpha: number
): number {
  if (dfT2 <= 0 || accrualAlpha <= 0) return 0;
  return (dfT1 / dfT2 - 1.0) / accrualAlpha;
}
