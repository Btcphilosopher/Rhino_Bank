/**
 * RhinoQuant Synthetic Interest Rate Engine
 * Main Institutional Application Entry Point
 * Implements full 10-screen navigation, deterministic calculation loop,
 * real-time stress testing, and governance audit trail.
 */

import React, { useState, useMemo } from 'react';
import {
  INITIAL_MARKET_OBSERVATIONS,
  INITIAL_RATE_DEFINITIONS,
  PREDEFINED_SCENARIOS,
} from './engine/mockMarketData';
import {
  SyntheticRateDefinition,
  MarketObservation,
  RateConstructionResult,
  StressScenario,
} from './engine/types';
import { constructSyntheticRate } from './engine/rateEngines';

// Components
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { OverviewDesk } from './components/OverviewDesk';
import { WorkbenchDesk } from './components/WorkbenchDesk';
import { OvernightFundingDesk } from './components/OvernightFundingDesk';
import { CarryFXDesk } from './components/CarryFXDesk';
import { StructuredCreditDesk } from './components/StructuredCreditDesk';
import { SyntheticCurveDesk } from './components/SyntheticCurveDesk';
import { RateBridgeDesk } from './components/RateBridgeDesk';
import { StressLabDesk } from './components/StressLabDesk';
import { ValidationDesk } from './components/ValidationDesk';
import { ApiMonitorDesk } from './components/ApiMonitorDesk';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<string>('overview');
  const [allObservations, setAllObservations] = useState<MarketObservation[]>(INITIAL_MARKET_OBSERVATIONS);
  const [allDefinitions, setAllDefinitions] = useState<SyntheticRateDefinition[]>(INITIAL_RATE_DEFINITIONS);
  const [selectedDefinitionId, setSelectedDefinitionId] = useState<string>('DEF_WHOLESALE_FUNDING_3M');
  const [activeScenario, setActiveScenario] = useState<StressScenario>(PREDEFINED_SCENARIOS[0]);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Published releases history
  const [publishedHistory, setPublishedHistory] = useState([
    {
      timestamp: '2026-10-18 08:30:15 UTC',
      rateName: 'Short-Term Wholesale Funding Composite',
      version: 'v2.1',
      ratePercent: 5.0482,
      hash: '0x4a9f82d1c7e09b33a521ef',
      status: 'APPROVED & PUBLISHED',
    },
    {
      timestamp: '2026-10-18 08:00:22 UTC',
      rateName: 'Overnight Funding Multi-Market Composite',
      version: 'v3.0',
      ratePercent: 4.8450,
      hash: '0x88c219fe3391d4e082acbb',
      status: 'APPROVED & PUBLISHED',
    },
    {
      timestamp: '2026-10-17 17:00:00 UTC',
      rateName: 'Cross-Currency FX Swap Implied Funding Composite',
      version: 'v1.4',
      ratePercent: 4.9215,
      hash: '0x10b77da4928fe89a24ec01',
      status: 'APPROVED & PUBLISHED',
    },
  ]);

  // Current selected definition
  const currentDefinition = useMemo(() => {
    return allDefinitions.find((d) => d.id === selectedDefinitionId) ?? allDefinitions[0];
  }, [allDefinitions, selectedDefinitionId]);

  // Calculate current active rate result
  const currentRateResult: RateConstructionResult = useMemo(() => {
    return constructSyntheticRate(currentDefinition, allObservations, activeScenario);
  }, [currentDefinition, allObservations, activeScenario]);

  // Calculate all published rates for overview and stress testing
  const allPublishedRates = useMemo(() => {
    return allDefinitions.map((def) => ({
      def,
      res: constructSyntheticRate(def, allObservations, activeScenario),
    }));
  }, [allDefinitions, allObservations, activeScenario]);

  // Handler to refresh all calculations
  const handleRefreshAll = () => {
    setIsCalculating(true);
    setTimeout(() => {
      setIsCalculating(false);
      showNotification('All 10 market pricing models and curves re-anchored successfully.');
    }, 400);
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Handler to update definition in state
  const handleUpdateDefinition = (updated: SyntheticRateDefinition) => {
    setAllDefinitions((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  };

  // Handler to save new version
  const handleSaveNewVersion = () => {
    const currentVersionNum = parseFloat(currentDefinition.version.replace('v', '')) || 1.0;
    const nextVersion = `v${(currentVersionNum + 0.1).toFixed(1)}`;
    const updated = {
      ...currentDefinition,
      version: nextVersion,
      status: 'APPROVED' as const,
    };
    handleUpdateDefinition(updated);
    showNotification(`New methodology version ${nextVersion} saved.`);
  };

  // Handler to publish rate
  const handlePublishRate = () => {
    const updated = {
      ...currentDefinition,
      status: 'PUBLISHED' as const,
    };
    handleUpdateDefinition(updated);

    // Record in history
    setPublishedHistory((prev) => [
      {
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
        rateName: currentDefinition.name,
        version: currentDefinition.version,
        ratePercent: currentRateResult.outputRatePercent,
        hash: currentRateResult.executionHash,
        status: 'APPROVED & PUBLISHED',
      },
      ...prev,
    ]);

    showNotification(
      `Published ${currentDefinition.name} at ${currentRateResult.outputRatePercent.toFixed(4)}% with audit hash ${currentRateResult.executionHash}.`
    );
  };

  // Handler to add custom observation
  const handleAddObservation = (newObs: MarketObservation) => {
    setAllObservations((prev) => [newObs, ...prev]);
    showNotification(`Injected market observation ${newObs.symbol} (${newObs.rawRateOrPrice}%).`);
  };

  // Active exceptions count for sidebar badge
  const unresolvedExceptionsCount = currentRateResult.validationChecks.filter(
    (c) => c.status === 'WARNING' || c.status === 'FAIL'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none overflow-hidden">
      {/* Top Header */}
      <Header
        activeScreen={activeScreen}
        onNavigate={setActiveScreen}
        onRefreshAll={handleRefreshAll}
        isCalculating={isCalculating}
        publishedCount={allDefinitions.filter((d) => d.status === 'PUBLISHED').length}
        activeScenarioName={activeScenario.name.split(' ')[0]}
      />

      {/* Main Workspace Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Institutional Sidebar */}
        <Sidebar
          activeScreen={activeScreen}
          onNavigate={setActiveScreen}
          unresolvedExceptionsCount={unresolvedExceptionsCount}
        />

        {/* Dynamic Content Viewport */}
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {activeScreen === 'overview' && (
            <OverviewDesk
              publishedRates={allPublishedRates}
              onSelectRate={setSelectedDefinitionId}
              onNavigate={setActiveScreen}
              activeScenario={activeScenario}
              onSelectScenario={(scId) => {
                const sc = PREDEFINED_SCENARIOS.find((s) => s.id === scId);
                if (sc) setActiveScenario(sc);
              }}
              availableScenarios={PREDEFINED_SCENARIOS}
            />
          )}

          {activeScreen === 'workbench' && (
            <WorkbenchDesk
              currentDefinition={currentDefinition}
              allDefinitions={allDefinitions}
              allObservations={allObservations}
              rateResult={currentRateResult}
              onUpdateDefinition={handleUpdateDefinition}
              onSelectDefinition={setSelectedDefinitionId}
              onPublishRate={handlePublishRate}
              onSaveNewVersion={handleSaveNewVersion}
              onNavigate={setActiveScreen}
            />
          )}

          {activeScreen === 'overnight' && (
            <OvernightFundingDesk
              overnightObservations={allObservations.filter(
                (o) => o.category === 'OVERNIGHT_BENCHMARK' || o.category === 'REPO_SECURED'
              )}
            />
          )}

          {activeScreen === 'carry' && <CarryFXDesk />}

          {activeScreen === 'cdo' && <StructuredCreditDesk />}

          {activeScreen === 'curve' && (
            <SyntheticCurveDesk
              baseSyntheticRatePct={currentRateResult.outputRatePercent}
              currency={currentDefinition.targetCurrency}
              activeScenario={activeScenario}
            />
          )}

          {activeScreen === 'bridge' && (
            <RateBridgeDesk
              rateResult={currentRateResult}
              currentDefinition={currentDefinition}
            />
          )}

          {activeScreen === 'stress' && (
            <StressLabDesk
              activeScenario={activeScenario}
              onUpdateScenario={setActiveScenario}
              publishedRates={allPublishedRates}
            />
          )}

          {activeScreen === 'validation' && (
            <ValidationDesk
              rateResult={currentRateResult}
              currentDefinition={currentDefinition}
              publishedHistory={publishedHistory}
            />
          )}

          {activeScreen === 'monitor' && (
            <ApiMonitorDesk
              observations={allObservations}
              onAddObservation={handleAddObservation}
            />
          )}
        </main>
      </div>

      {/* Floating Institutional Status Toast */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500/50 text-white px-4 py-2.5 rounded-lg shadow-2xl flex items-center gap-3 text-xs font-mono animate-in fade-in duration-200">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>{notification}</span>
        </div>
      )}
    </div>
  );
}
