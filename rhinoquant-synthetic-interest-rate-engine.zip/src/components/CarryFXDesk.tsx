/**
 * RhinoQuant Carry & FX Implied Financing Desk
 * Covered Interest Parity (CIP) calculation, FX swap-implied funding,
 * cross-currency basis decomposition, and asset carry strategies.
 */

import React, { useState } from 'react';
import {
  calculateFXImpliedRate,
  calculateAssetCarryRate,
  CIPCalculationResult,
} from '../engine/rateEngines';
import { TrendingUp, ArrowRight, ShieldAlert, DollarSign, CheckCircle2 } from 'lucide-react';

export const CarryFXDesk: React.FC = () => {
  // FX CIP Inputs
  const [currencyPair, setCurrencyPair] = useState<'EURUSD' | 'USDJPY' | 'GBPUSD'>('EURUSD');
  const [spotPrice, setSpotPrice] = useState<number>(1.0850);
  const [forwardPrice, setForwardPrice] = useState<number>(1.0895);
  const [foreignRatePct, setForeignRatePct] = useState<number>(3.15); // EUR €STR
  const [tenorDays, setTenorDays] = useState<number>(90); // 3M
  const [bidAskSpreadPips, setBidAskSpreadPips] = useState<number>(2.5);
  const [collateralHaircutPct, setCollateralHaircutPct] = useState<number>(5.0);

  // Asset Carry Inputs
  const [assetName, setAssetName] = useState<'GOLD' | 'CRUDE' | 'TREASURY_NOTE'>('GOLD');
  const [assetSpot, setAssetSpot] = useState<number>(2680.0);
  const [assetForward, setAssetForward] = useState<number>(2712.5);
  const [assetYieldPct, setAssetYieldPct] = useState<number>(0.0); // Gold lease rate
  const [assetStoragePct, setAssetStoragePct] = useState<number>(0.25); // Gold vault storage

  // Presets for Currency Pairs
  const handlePairChange = (pair: 'EURUSD' | 'USDJPY' | 'GBPUSD') => {
    setCurrencyPair(pair);
    if (pair === 'EURUSD') {
      setSpotPrice(1.0850);
      setForwardPrice(1.0895);
      setForeignRatePct(3.15);
      setTenorDays(90);
    } else if (pair === 'USDJPY') {
      setSpotPrice(152.40);
      setForwardPrice(150.85);
      setForeignRatePct(0.24); // JPY TONA
      setTenorDays(90);
    } else if (pair === 'GBPUSD') {
      setSpotPrice(1.2980);
      setForwardPrice(1.2995);
      setForeignRatePct(4.70); // GBP SONIA
      setTenorDays(90);
    }
  };

  // Run CIP Calculation
  const cipResult: CIPCalculationResult = calculateFXImpliedRate(
    spotPrice,
    forwardPrice,
    foreignRatePct,
    tenorDays,
    'ACT/360',
    'ACT/360',
    bidAskSpreadPips,
    collateralHaircutPct / 100.0
  );

  // Run Asset Carry Calculation
  const assetCarryResult = calculateAssetCarryRate(
    assetSpot,
    assetForward,
    tenorDays,
    assetYieldPct,
    assetStoragePct
  );

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Carry Trade & Implied Financing Desk
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              CIP & Forward Points
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Derive synthetic interest rates from forward-spot pricing relationships, cross-currency basis, and execution frictions.
          </p>
        </div>

        {/* Currency Pair Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded">
          <button
            onClick={() => handlePairChange('EURUSD')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              currencyPair === 'EURUSD'
                ? 'bg-cyan-600 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            EUR/USD
          </button>
          <button
            onClick={() => handlePairChange('USDJPY')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              currencyPair === 'USDJPY'
                ? 'bg-cyan-600 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            USD/JPY
          </button>
          <button
            onClick={() => handlePairChange('GBPUSD')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              currencyPair === 'GBPUSD'
                ? 'bg-cyan-600 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            GBP/USD
          </button>
        </div>
      </div>

      {/* Main Grid: FX CIP Calculator on Left, Asset Carry on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Module 1: FX Swap Implied USD Funding Rate */}
        <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                FX Swap Implied Funding Rate (CIP)
              </h2>
            </div>
            <span className="text-xs font-mono text-cyan-300 font-bold">{currencyPair} 3M</span>
          </div>

          {/* Implied Result Banner */}
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 grid grid-cols-2 gap-3">
            <div>
              <span className="text-[10px] font-mono text-slate-400">SYNTHETIC USD FUNDING RATE</span>
              <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums mt-1">
                {cipResult.domesticImpliedRatePercent.toFixed(4)}%
              </div>
              <span className="text-[10px] text-slate-400">
                Forward-implied borrowing cost
              </span>
            </div>

            <div>
              <span className="text-[10px] font-mono text-slate-400">CIP DEVIATION (BASIS)</span>
              <div className="text-xl font-bold font-mono text-amber-400 tabular-nums mt-1">
                {cipResult.coveredInterestParityDeviationBps.toFixed(1)} bps
              </div>
              <span className="text-[10px] text-slate-400">
                Cross-currency basis distortion
              </span>
            </div>
          </div>

          {/* Interactive Inputs */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Spot Price (S)</label>
              <input
                type="number"
                step="0.0001"
                value={spotPrice}
                onChange={(e) => setSpotPrice(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Forward Price (F)</label>
              <input
                type="number"
                step="0.0001"
                value={forwardPrice}
                onChange={(e) => setForwardPrice(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Foreign Benchmark Rate (r_f)</label>
              <input
                type="number"
                step="0.01"
                value={foreignRatePct}
                onChange={(e) => setForeignRatePct(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
              <span className="text-[10px] text-slate-400">e.g. €STR 3.15%</span>
            </div>
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Tenor Days (τ)</label>
              <input
                type="number"
                value={tenorDays}
                onChange={(e) => setTenorDays(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
              <span className="text-[10px] text-slate-400">90 days (ACT/360)</span>
            </div>
          </div>

          {/* Execution Friction Breakdown */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <span className="text-[11px] font-mono font-semibold text-slate-300">
              Institutional Execution Friction & Arbitrage Feasibility
            </span>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                <span className="text-slate-400">Bid-Ask Drag:</span>
                <span className="font-mono text-slate-200">
                  {((bidAskSpreadPips * 0.0001 / spotPrice) * (360 / tenorDays) * 10000).toFixed(1)} bps
                </span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                <span className="text-slate-400">Haircut Financing:</span>
                <span className="font-mono text-slate-200">
                  {(collateralHaircutPct * 0.25).toFixed(1)} bps
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800 text-xs">
              <span className="text-slate-300 font-medium">Arbitrage Execution Feasibility:</span>
              <span
                className={`font-mono font-bold px-2 py-0.5 rounded text-[10px] ${
                  cipResult.arbitrageFeasibility === 'FEASIBLE'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}
              >
                {cipResult.arbitrageFeasibility.replace(/_/g, ' ')}
              </span>
            </div>
          </div>
        </div>

        {/* Module 2: Commodity & Bond Carry Financing */}
        <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-cyan-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Asset Carry & Forward Pricing Engine
              </h2>
            </div>
            <span className="text-xs font-mono text-slate-400">F = S·[1 + (r + u - y)·τ]</span>
          </div>

          {/* Implied Result Banner */}
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 grid grid-cols-2 gap-3">
            <div>
              <span className="text-[10px] font-mono text-slate-400">IMPLIED FINANCING RATE</span>
              <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums mt-1">
                {assetCarryResult.impliedFinancingRatePercent.toFixed(4)}%
              </div>
              <span className="text-[10px] text-slate-400">
                Cost of funds implied by forward curve
              </span>
            </div>

            <div>
              <span className="text-[10px] font-mono text-slate-400">ANNUALIZED ROLL YIELD</span>
              <div className="text-xl font-bold font-mono text-white tabular-nums mt-1">
                {assetCarryResult.annualizedRollReturnPercent.toFixed(2)}%
              </div>
              <span className="text-[10px] text-slate-400">
                Forward premium / Contango slope
              </span>
            </div>
          </div>

          {/* Asset Selector */}
          <div className="flex items-center gap-2">
            {[
              { id: 'GOLD', label: 'Gold (XAU/USD)', spot: 2680.0, fwd: 2712.5, y: 0.0, u: 0.25 },
              { id: 'CRUDE', label: 'Crude Oil (WTI)', spot: 74.5, fwd: 75.3, y: 0.0, u: 1.2 },
              { id: 'TREASURY_NOTE', label: 'UST 10Y Note Forward', spot: 98.2, fwd: 99.4, y: 4.15, u: 0.0 },
            ].map((a) => (
              <button
                key={a.id}
                onClick={() => {
                  setAssetName(a.id as any);
                  setAssetSpot(a.spot);
                  setAssetForward(a.fwd);
                  setAssetYieldPct(a.y);
                  setAssetStoragePct(a.u);
                }}
                className={`flex-1 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                  assetName === a.id
                    ? 'bg-slate-800 text-cyan-300 font-bold border border-slate-700'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {a.label.split(' ')[0]}
              </button>
            ))}
          </div>

          {/* Interactive Inputs */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Asset Spot Price (S)</label>
              <input
                type="number"
                value={assetSpot}
                onChange={(e) => setAssetSpot(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Forward / Futures Price (F)</label>
              <input
                type="number"
                value={assetForward}
                onChange={(e) => setAssetForward(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Yield / Coupon / Convenience (y)</label>
              <input
                type="number"
                step="0.05"
                value={assetYieldPct}
                onChange={(e) => setAssetYieldPct(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Storage / Borrow Cost (u)</label>
              <input
                type="number"
                step="0.05"
                value={assetStoragePct}
                onChange={(e) => setAssetStoragePct(Number(e.target.value))}
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
              />
            </div>
          </div>

          <div className="p-3 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
            <span className="text-cyan-400 font-semibold block mb-0.5">Economic Interpretation:</span>
            A forward-implied rate reflects the return earned by buying the physical asset, hedging via forward sale, and paying carrying costs. In an institutional framework, this rate is not risk-free: it absorbs balance-sheet balance capacity and warehouse risk.
          </div>
        </div>
      </div>
    </div>
  );
};
