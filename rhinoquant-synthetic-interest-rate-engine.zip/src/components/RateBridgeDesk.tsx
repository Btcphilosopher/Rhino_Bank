/**
 * RhinoQuant Rate Bridge Desk
 * Explains the transformation from raw market observations to the final synthetic rate
 * through a step-by-step waterfall attribution and double-counting checks.
 */

import React from 'react';
import { RateConstructionResult, SyntheticRateDefinition } from '../engine/types';
import { GitCommit, ArrowRight, ShieldCheck, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

interface RateBridgeDeskProps {
  rateResult: RateConstructionResult;
  currentDefinition: SyntheticRateDefinition;
}

export const RateBridgeDesk: React.FC<RateBridgeDeskProps> = ({
  rateResult,
  currentDefinition,
}) => {
  const steps = rateResult.rateBridge;

  // Find min and max for chart scaling
  const rates = steps.map((s) => s.cumulativeRatePercent);
  const minRate = Math.min(...rates) - 0.1;
  const maxRate = Math.max(...rates) + 0.1;
  const range = Math.max(0.2, maxRate - minRate);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Synthetic Rate Bridge & Basis Decomposition
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              {currentDefinition.name}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Auditable step-by-step economic transformation from raw market inputs to published benchmark.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] text-slate-400 font-mono">TARGET BENCHMARK</span>
            <div className="text-sm font-bold font-mono text-cyan-300">
              {currentDefinition.targetCurrency} {currentDefinition.targetTenor} · {rateResult.outputRatePercent.toFixed(4)}%
            </div>
          </div>
        </div>
      </div>

      {/* Waterfall Visualization Cards */}
      <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <GitCommit className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-white font-mono">
              Waterfall Transformation Trajectory
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Total Net Adjustment: {((rateResult.outputRatePercent - steps[0]?.cumulativeRatePercent) * 100).toFixed(1)} bps
          </span>
        </div>

        {/* Visual Waterfall Bars */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 pt-2 pb-4">
          {steps.map((step, idx) => {
            const isBase = step.category === 'BASE';
            const isOutput = step.category === 'OUTPUT';
            const isDeltaPos = step.deltaBps > 0;

            return (
              <div
                key={step.stepIndex}
                className={`p-3 rounded border flex flex-col justify-between transition-all ${
                  isOutput
                    ? 'bg-cyan-950/40 border-cyan-500/50 shadow-sm shadow-cyan-950'
                    : isBase
                    ? 'bg-slate-950 border-slate-700'
                    : 'bg-slate-950/80 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span>STEP {step.stepIndex}</span>
                    <span
                      className={`px-1 rounded text-[9px] ${
                        step.isObserved
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {step.isObserved ? 'OBS' : 'CALC'}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-200 mt-1 line-clamp-2 leading-tight">
                    {step.label}
                  </div>
                </div>

                <div className="mt-4 pt-2 border-t border-slate-800/80">
                  {!isBase && !isOutput && (
                    <div
                      className={`text-[11px] font-mono font-semibold tabular-nums ${
                        isDeltaPos ? 'text-amber-400' : 'text-cyan-400'
                      }`}
                    >
                      {isDeltaPos ? `+${step.deltaBps}` : step.deltaBps} bps
                    </div>
                  )}
                  <div className="text-sm font-bold font-mono text-white tabular-nums mt-0.5">
                    {step.cumulativeRatePercent.toFixed(4)}%
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Detailed Table of Bridge Steps */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white font-sans">
            Bridge Component Attribution & Invariant Verification
          </h2>
          <span className="text-xs font-mono text-slate-400">
            {steps.length} Attributable Phases
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold w-12 text-center">Step</th>
                <th className="py-2.5 px-4 font-semibold">Attribution Phase</th>
                <th className="py-2.5 px-3 font-semibold text-center">Source Nature</th>
                <th className="py-2.5 px-3 font-semibold text-right">Adjustment (bps)</th>
                <th className="py-2.5 px-4 font-semibold text-right">Cumulative Rate</th>
                <th className="py-2.5 px-4 font-semibold">Economic Purpose & Double-Counting Safeguard</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {steps.map((step) => {
                const isBase = step.category === 'BASE';
                const isOutput = step.category === 'OUTPUT';

                return (
                  <tr key={step.stepIndex} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 text-center font-mono text-slate-400 font-bold">
                      {step.stepIndex}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <span className="font-semibold text-white text-xs">
                          {step.label}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {step.sourceDescription}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                          step.isObserved
                            ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60'
                            : 'bg-slate-950 text-cyan-300 border-slate-800'
                        }`}
                      >
                        {step.isObserved ? 'Observed Market' : 'Model Calibrated'}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-semibold tabular-nums">
                      {isBase || isOutput ? (
                        <span className="text-slate-600">-</span>
                      ) : (
                        <span
                          className={step.deltaBps > 0 ? 'text-amber-400' : 'text-cyan-400'}
                        >
                          {step.deltaBps > 0 ? `+${step.deltaBps}` : step.deltaBps} bps
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-sm text-cyan-300 tabular-nums">
                      {step.cumulativeRatePercent.toFixed(4)}%
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>
                          {step.category === 'BASE' && 'Aggregates eligible raw observations without prior bias.'}
                          {step.category === 'CONVENTION' && 'Invariance check: Preserves period cash-flow discount factor P(0, τ).'}
                          {step.category === 'COLLATERAL' && 'Isolates difference between US Treasury pledge and unsecured borrowing.'}
                          {step.category === 'CREDIT' && 'Verified non-redundant: Excludes CP Tier 1 which already reflects A1 issuer spread.'}
                          {step.category === 'LIQUIDITY' && 'Compensates secondary market tiering and round-trip execution drag.'}
                          {step.category === 'CURRENCY' && 'Derived from covered interest parity forward points; avoids duplicate basis spread.'}
                          {step.category === 'TERM' && 'Calibrated against OIS forward curve slope; zero term bias.'}
                          {step.category === 'OUTPUT' && 'Deterministic output published with cryptographic SHA-256 validation hash.'}
                        </span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
