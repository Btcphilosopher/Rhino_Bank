/**
 * RhinoQuant Structured Credit & CDO Financing Desk
 * Asset pool cash-flow waterfall, tranche subordination, expected loss allocation,
 * and translation into risk-adjusted synthetic financing rates.
 */

import React, { useState } from 'react';
import { CDOPool, CDOTranche } from '../engine/types';
import { SAMPLE_CDO_POOLS } from '../engine/mockMarketData';
import { evaluateCDOPoolAndTranches } from '../engine/rateEngines';
import { Layers, ShieldCheck, AlertTriangle, ArrowRight, BarChart3, Info } from 'lucide-react';

export const StructuredCreditDesk: React.FC = () => {
  const [selectedPoolId, setSelectedPoolId] = useState<string>('POOL_US_CORP_LOANS');
  const [pdShockMultiplier, setPdShockMultiplier] = useState<number>(1.0);
  const [recoveryRateOverride, setRecoveryRateOverride] = useState<number>(65);

  const basePool = SAMPLE_CDO_POOLS.find((p) => p.id === selectedPoolId) ?? SAMPLE_CDO_POOLS[0];

  // Apply overrides to pool
  const currentPool: CDOPool = {
    ...basePool,
    recoveryRatePct: recoveryRateOverride,
  };

  // Evaluate tranches
  const evaluatedTranches: CDOTranche[] = evaluateCDOPoolAndTranches(currentPool, {
    defaultProbabilityShockMultiplier: pdShockMultiplier,
  });

  const poolLossPct =
    (currentPool.annualDefaultProbabilityPct *
      pdShockMultiplier *
      (1.0 - recoveryRateOverride / 100.0) *
      currentPool.weightedAverageMaturityYears).toFixed(2);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Structured Credit & CDO Rate Desk
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              Waterfall & Loss Allocation
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Derive institutional financing rates from asset-backed pools, tranche subordination, and expected cash-flow loss distributions.
          </p>
        </div>

        {/* Pool Selector */}
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded px-2.5 py-1">
          <span className="text-[11px] font-mono text-slate-400">Underlying Pool:</span>
          <select
            value={selectedPoolId}
            onChange={(e) => {
              setSelectedPoolId(e.target.value);
              const p = SAMPLE_CDO_POOLS.find((x) => x.id === e.target.value);
              if (p) setRecoveryRateOverride(p.recoveryRatePct);
            }}
            className="bg-transparent text-xs text-cyan-300 font-semibold focus:outline-none cursor-pointer"
          >
            {SAMPLE_CDO_POOLS.map((pool) => (
              <option key={pool.id} value={pool.id} className="bg-slate-900 text-white">
                {pool.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Pool Health & Collateral Metrics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800">
        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Pool Notional</span>
          <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
            ${currentPool.totalNotionalMillions}M
          </div>
          <span className="text-[10px] text-slate-400">{currentPool.assetCount} loans / assets</span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Weighted Avg Coupon (WAC)</span>
          <div className="text-xl font-bold font-mono text-cyan-300 mt-1 tabular-nums">
            {currentPool.weightedAverageCouponPct.toFixed(2)}%
          </div>
          <span className="text-[10px] text-slate-400">Servicing fee: {currentPool.servicingFeeBps} bps</span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Annual Default Rate (PD)</span>
          <div className="text-xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            {(currentPool.annualDefaultProbabilityPct * pdShockMultiplier).toFixed(2)}%
          </div>
          <span className="text-[10px] text-slate-400">Stress multiplier: {pdShockMultiplier.toFixed(1)}x</span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Recovery Rate (RR)</span>
          <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
            {recoveryRateOverride}%
          </div>
          <span className="text-[10px] text-slate-400">Senior secured collateral</span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Cumulative Pool Expected Loss</span>
          <div className="text-xl font-bold font-mono text-rose-400 mt-1 tabular-nums">
            {poolLossPct}%
          </div>
          <span className="text-[10px] text-slate-400">Over {currentPool.weightedAverageMaturityYears} yrs WAM</span>
        </div>
      </div>

      {/* Interactive Controls Strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-lg bg-slate-900/60 border border-slate-800">
        <div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300">Default Probability Stress Multiplier:</span>
            <span className="font-mono text-cyan-300 font-bold">{pdShockMultiplier.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min={0.5}
            max={3.5}
            step={0.1}
            value={pdShockMultiplier}
            onChange={(e) => setPdShockMultiplier(Number(e.target.value))}
            className="w-full mt-2 accent-cyan-500 cursor-pointer"
          />
          <span className="text-[10px] text-slate-400">Simulate credit cycle downturn on the collateral pool.</span>
        </div>

        <div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300">Collateral Recovery Rate:</span>
            <span className="font-mono text-cyan-300 font-bold">{recoveryRateOverride}%</span>
          </div>
          <input
            type="range"
            min={30}
            max={90}
            step={5}
            value={recoveryRateOverride}
            onChange={(e) => setRecoveryRateOverride(Number(e.target.value))}
            className="w-full mt-2 accent-cyan-500 cursor-pointer"
          />
          <span className="text-[10px] text-slate-400">Post-default salvage value upon collateral liquidation.</span>
        </div>
      </div>

      {/* Tranche Capital Structure & Yield Table */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-white font-sans">
              Capital Structure Waterfall & Rate Decomposition
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {evaluatedTranches.length} Structured Tranches
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold">Tranche Class</th>
                <th className="py-2.5 px-3 font-semibold text-right">Notional</th>
                <th className="py-2.5 px-3 font-semibold text-center">Attachment - Detachment</th>
                <th className="py-2.5 px-3 font-semibold text-right">Subordination</th>
                <th className="py-2.5 px-3 font-semibold text-right">Expected Loss</th>
                <th className="py-2.5 px-3 font-semibold text-right">Contractual Yield</th>
                <th className="py-2.5 px-3 font-semibold text-right">Expected Cash-Flow Yield</th>
                <th className="py-2.5 px-3 font-semibold text-right">Market Implied Yield</th>
                <th className="py-2.5 px-4 font-semibold text-right">Funding Spread</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {evaluatedTranches.map((t) => {
                const isSenior = t.tier === 'SENIOR_AAA';
                const isEquity = t.tier === 'EQUITY_FIRST_LOSS';

                return (
                  <tr
                    key={t.id}
                    className={`transition-colors ${
                      isSenior
                        ? 'bg-cyan-950/20 hover:bg-cyan-900/30'
                        : isEquity
                        ? 'bg-rose-950/10 hover:bg-rose-900/20'
                        : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white text-xs">{t.name}</span>
                        {isSenior && (
                          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                            AAA
                          </span>
                        )}
                        {isEquity && (
                          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800">
                            FIRST-LOSS
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-slate-300 tabular-nums">
                      ${t.notionalMillions}M
                    </td>

                    <td className="py-3 px-3 text-center font-mono text-slate-400">
                      {(t.attachmentPoint * 100).toFixed(0)}% – {(t.detachmentPoint * 100).toFixed(0)}%
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-emerald-400 font-bold tabular-nums">
                      {t.subordinationPct.toFixed(1)}%
                    </td>

                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      <span className={t.expectedLossPct > 5 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                        {t.expectedLossPct.toFixed(2)}%
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-slate-300 tabular-nums">
                      {t.contractualYieldPercent.toFixed(2)}%
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-bold text-cyan-300 tabular-nums">
                      {t.expectedCashFlowYieldPercent.toFixed(2)}%
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-slate-200 tabular-nums">
                      {t.marketImpliedYieldPercent.toFixed(2)}%
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-amber-400 tabular-nums">
                      +{t.riskAdjustedFundingSpreadBps} bps
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Institutional Explanatory Box on Structured Credit Rates */}
      <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-2 text-xs text-slate-300 leading-relaxed">
        <div className="flex items-center gap-2 text-cyan-400 font-mono font-semibold uppercase">
          <Info className="w-4 h-4" />
          <span>Institutional Methodology Directive — Why Tranche Yields Differ from Vanilla Benchmarks</span>
        </div>
        <p>
          A CDO tranche yield is <strong>not</strong> an unencumbered interest rate benchmark. It embeds structural credit subordination, recovery lag, rating migration risk, and asset correlation. In the RhinoQuant engine, structured credit contributes to a synthetic financing rate only through the <strong>Senior Class A tranche</strong> after deducting the annualized expected pool loss and backing out servicing overheads.
        </p>
      </div>
    </div>
  );
};
