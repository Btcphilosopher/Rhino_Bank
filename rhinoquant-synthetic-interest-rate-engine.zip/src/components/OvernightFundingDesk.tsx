/**
 * RhinoQuant Overnight & Short-Term Funding Desk
 * Compounded overnight rates, daily accruals with weekend weighting,
 * secured-vs-unsecured funding basis, and legacy LIBOR fallback analysis.
 */

import React, { useState } from 'react';
import { compoundOvernightRates } from '../engine/conventions';
import { MarketObservation } from '../engine/types';
import { Clock, ShieldCheck, ArrowRight, Info, Calendar, Sparkles } from 'lucide-react';

interface OvernightFundingDeskProps {
  overnightObservations: MarketObservation[];
}

export const OvernightFundingDesk: React.FC<OvernightFundingDeskProps> = ({
  overnightObservations,
}) => {
  const [compoundingPeriodDays, setCompoundingPeriodDays] = useState<number>(30);
  const [baseOvernightRatePct, setBaseOvernightRatePct] = useState<number>(4.85);
  const [volatilityBps, setVolatilityBps] = useState<number>(4);

  // Generate synthetic sequence of daily fixings with weekend accruals
  const dailyFixings = React.useMemo(() => {
    const fixings: { dayIndex: number; dateStr: string; ratePct: number; daysAccrued: number; dayOfWeek: string }[] = [];
    let currentDate = new Date(2026, 9, 1); // Oct 1, 2026

    for (let i = 1; i <= compoundingPeriodDays; i++) {
      const dayOfWeekNum = currentDate.getDay(); // 0 is Sun, 5 is Fri, 6 is Sat
      const isFriday = dayOfWeekNum === 5;
      const daysAccrued = isFriday ? 3 : 1; // 3 days for Friday over weekend

      // Slight deterministic micro-variation
      const pseudoNoise = (Math.sin(i * 1.7) * volatilityBps) / 100.0;
      const ratePct = Number((baseOvernightRatePct + pseudoNoise).toFixed(4));

      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      fixings.push({
        dayIndex: i,
        dateStr: currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        dayOfWeek: dayNames[dayOfWeekNum],
        ratePct,
        daysAccrued,
      });

      // Advance date
      currentDate.setDate(currentDate.getDate() + (isFriday ? 3 : 1));
    }
    return fixings;
  }, [compoundingPeriodDays, baseOvernightRatePct, volatilityBps]);

  // Compute compounded rate
  const ratesArray = dailyFixings.map((f) => f.ratePct / 100.0);
  const weightsArray = dailyFixings.map((f) => f.daysAccrued);
  const compoundingResult = compoundOvernightRates(ratesArray, weightsArray, 360);
  const compoundedAnnualRatePct = compoundingResult.compoundedRateAnnual * 100.0;

  // Simple average for comparison
  const simpleAveragePct =
    dailyFixings.reduce((acc, f) => acc + f.ratePct * f.daysAccrued, 0) /
    compoundingResult.totalDays;

  // Compounding effect in bps
  const compoundingBonusBps = (compoundedAnnualRatePct - simpleAveragePct) * 100.0;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Overnight & Money Market Funding Desk
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              OIS & Repo Architecture
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Official benchmark observations, weekend-weighted daily compounding, and secured-unsecured funding basis.
          </p>
        </div>
      </div>

      {/* Global Overnight Benchmark Cards */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        {overnightObservations.map((obs) => (
          <div
            key={obs.id}
            className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>{obs.currency}</span>
                <span className="text-cyan-400">{obs.symbol.split('.')[0]}</span>
              </div>
              <div className="text-xs font-semibold text-slate-200 mt-1 truncate" title={obs.name}>
                {obs.name.split('(')[0]}
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800">
              <div className="text-lg font-bold font-mono text-white tabular-nums">
                {obs.rawRateOrPrice.toFixed(2)}%
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                <span>{obs.collateralType === 'SECURED_GOVT' ? 'Secured' : 'Unsecured'}</span>
                <span>{obs.dayCount}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Compounding Engine Interactive Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Column */}
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Daily Compounding Simulator
            </h2>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Observation Tenor:</span>
              <span className="font-mono text-cyan-300 font-bold">{compoundingPeriodDays} Business Days</span>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {[30, 60, 90].map((d) => (
                <button
                  key={d}
                  onClick={() => setCompoundingPeriodDays(d)}
                  className={`py-1 text-xs rounded font-mono transition-colors cursor-pointer ${
                    compoundingPeriodDays === d
                      ? 'bg-cyan-600 text-white font-bold'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {d} Days
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Mean Overnight Fixing:</span>
              <span className="font-mono text-cyan-300 font-bold">{baseOvernightRatePct.toFixed(2)}%</span>
            </div>
            <input
              type="range"
              min={3.0}
              max={6.5}
              step={0.05}
              value={baseOvernightRatePct}
              onChange={(e) => setBaseOvernightRatePct(Number(e.target.value))}
              className="w-full mt-2 accent-cyan-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Fixing Volatility:</span>
              <span className="font-mono text-cyan-300 font-bold">{volatilityBps} bps</span>
            </div>
            <input
              type="range"
              min={0}
              max={15}
              step={1}
              value={volatilityBps}
              onChange={(e) => setVolatilityBps(Number(e.target.value))}
              className="w-full mt-2 accent-cyan-500 cursor-pointer"
            />
          </div>

          {/* Result Highlight Box */}
          <div className="p-3 rounded bg-slate-950 border border-slate-800 space-y-2 font-mono">
            <div className="text-[10px] text-slate-400 uppercase">Compounding Results</div>
            <div className="flex items-baseline justify-between">
              <span className="text-xs text-slate-300">Compounded Annual:</span>
              <span className="text-base font-bold text-cyan-300 tabular-nums">
                {compoundedAnnualRatePct.toFixed(4)}%
              </span>
            </div>
            <div className="flex items-baseline justify-between text-xs text-slate-400">
              <span>Simple Period Avg:</span>
              <span className="tabular-nums text-slate-300">{simpleAveragePct.toFixed(4)}%</span>
            </div>
            <div className="flex items-baseline justify-between text-xs text-slate-400">
              <span>Compounding Premium:</span>
              <span className="tabular-nums text-emerald-400 font-semibold">
                +{compoundingBonusBps.toFixed(2)} bps
              </span>
            </div>
            <div className="flex items-baseline justify-between text-xs text-slate-400">
              <span>Total Calendar Days:</span>
              <span className="tabular-nums text-slate-300">{compoundingResult.totalDays} days</span>
            </div>
          </div>
        </div>

        {/* Daily Fixings Schedule Ledger */}
        <div className="lg:col-span-2 p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Daily Fixings & Weekend Accrual Schedule
              </h2>
              <span className="text-[10px] text-slate-400 font-mono">
                Friday Fixings weighted n_i = 3
              </span>
            </div>

            <div className="mt-3 max-h-72 overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-mono text-[10px]">
                    <th className="py-2 px-3">Day #</th>
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-3 text-center">Day of Week</th>
                    <th className="py-2 px-3 text-right">Fixing Rate</th>
                    <th className="py-2 px-3 text-center">Accrual Weight (n_i)</th>
                    <th className="py-2 px-3 text-right">Effective Daily Factor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {dailyFixings.slice(0, 15).map((fix) => {
                    const factor = 1.0 + (fix.ratePct / 100.0) * (fix.daysAccrued / 360.0);
                    return (
                      <tr key={fix.dayIndex} className="hover:bg-slate-800/40">
                        <td className="py-1.5 px-3 text-slate-400">#{fix.dayIndex}</td>
                        <td className="py-1.5 px-3 text-white font-medium">{fix.dateStr}</td>
                        <td className="py-1.5 px-3 text-center">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] ${
                              fix.dayOfWeek === 'Fri'
                                ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                : 'text-slate-400'
                            }`}
                          >
                            {fix.dayOfWeek}
                          </span>
                        </td>
                        <td className="py-1.5 px-3 text-right font-bold text-cyan-300 tabular-nums">
                          {fix.ratePct.toFixed(4)}%
                        </td>
                        <td className="py-1.5 px-3 text-center text-slate-300 tabular-nums">
                          {fix.daysAccrued} {fix.daysAccrued > 1 ? 'days' : 'day'}
                        </td>
                        <td className="py-1.5 px-3 text-right text-slate-400 tabular-nums">
                          {factor.toFixed(8)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {dailyFixings.length > 15 && (
              <div className="text-[10px] text-slate-400 text-center py-2 border-t border-slate-800 mt-2 font-mono">
                Showing first 15 fixings of {dailyFixings.length} total period fixings.
              </div>
            )}
          </div>

          {/* Secured vs Unsecured Spread Highlight */}
          <div className="mt-4 p-3 rounded bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="text-slate-300">
                <strong>Secured-to-Unsecured Spread:</strong> EFFR (4.83%) vs SOFR (4.85%) = <strong>-2.0 bps</strong>.
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              Legacy USD LIBOR 3M Fallback: SOFR 3M + <strong>26.161 bps</strong> (ISDA 2020 protocol)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
