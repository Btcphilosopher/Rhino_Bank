/**
 * RhinoQuant Top Navigation Header
 * Strictly follows Universal Frontend Design Constitution:
 * - Clean 1-row, 3-zone contract
 * - Single-element Brand wordmark
 * - Concise single-line navigation
 * - Single primary CTA
 */

import React from 'react';
import { Layers, RefreshCw, ShieldCheck, Activity } from 'lucide-react';

interface HeaderProps {
  activeScreen: string;
  onNavigate: (screenId: string) => void;
  onRefreshAll: () => void;
  isCalculating: boolean;
  publishedCount: number;
  activeScenarioName: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeScreen,
  onNavigate,
  onRefreshAll,
  isCalculating,
  publishedCount,
  activeScenarioName,
}) => {
  return (
    <header className="h-14 border-b border-slate-800 bg-slate-950 px-6 flex items-center justify-between gap-8 shrink-0 select-none z-30">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded bg-cyan-600 flex items-center justify-center text-white font-bold tracking-wider text-sm shadow-sm shadow-cyan-900/50">
          RQ
        </div>
        <div className="flex flex-col">
          <span className="text-base font-bold tracking-tight text-white font-sans whitespace-nowrap">
            RhinoQuant
          </span>
          <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase">
            Synthetic Rate Engine
          </span>
        </div>
      </div>

      {/* Zone 2: 4-5 clean single-line text navigation links */}
      <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => onNavigate('overview')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'overview' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => onNavigate('workbench')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'workbench' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Rate Composition
        </button>
        <button
          onClick={() => onNavigate('overnight')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'overnight' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Overnight & Repo
        </button>
        <button
          onClick={() => onNavigate('carry')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'carry' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Carry & FX CIP
        </button>
        <button
          onClick={() => onNavigate('cdo')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'cdo' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Structured Credit
        </button>
        <button
          onClick={() => onNavigate('curve')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'curve' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Yield Curve
        </button>
        <button
          onClick={() => onNavigate('bridge')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'bridge' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Rate Bridge
        </button>
        <button
          onClick={() => onNavigate('stress')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeScreen === 'stress' ? 'text-cyan-400 font-semibold border-b border-cyan-400' : ''
          }`}
        >
          Stress Lab
        </button>
      </nav>

      {/* Zone 3: Primary Action & Context info */}
      <div className="flex items-center gap-4 shrink-0">
        <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-400 font-mono">
          <span className="text-slate-500">Scenario:</span>
          <span className="text-slate-200 font-semibold">{activeScenarioName}</span>
          <span className="text-slate-600">·</span>
          <span className="text-slate-500">Published:</span>
          <span className="text-cyan-300 font-semibold tabular-nums">{publishedCount} Rates</span>
        </div>

        <button
          onClick={onRefreshAll}
          disabled={isCalculating}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 rounded transition-all cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isCalculating ? 'animate-spin text-cyan-400' : 'text-slate-400'}`} />
          <span>{isCalculating ? 'Recalculating...' : 'Recalculate All'}</span>
        </button>
      </div>
    </header>
  );
};
