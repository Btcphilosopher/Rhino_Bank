/**
 * RhinoQuant Validation & Governance Desk
 * Independent validation checks, Herfindahl concentration, residual tracking,
 * publication history ledger, and cryptographic execution hashes.
 */

import React from 'react';
import {
  RateConstructionResult,
  SyntheticRateDefinition,
  ValidationCheckResult,
} from '../engine/types';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileCheck,
  Download,
  Hash,
  Lock,
} from 'lucide-react';

interface ValidationDeskProps {
  rateResult: RateConstructionResult;
  currentDefinition: SyntheticRateDefinition;
  publishedHistory: {
    timestamp: string;
    rateName: string;
    version: string;
    ratePercent: number;
    hash: string;
    status: string;
  }[];
}

export const ValidationDesk: React.FC<ValidationDeskProps> = ({
  rateResult,
  currentDefinition,
  publishedHistory,
}) => {
  const checks = rateResult.validationChecks;
  const passCount = checks.filter((c) => c.status === 'PASS').length;
  const warnCount = checks.filter((c) => c.status === 'WARNING').length;
  const failCount = checks.filter((c) => c.status === 'FAIL').length;

  const handleExportJSON = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(rateResult, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `${currentDefinition.id}_${currentDefinition.version}_audit.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Validation & Methodological Governance
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              Deterministic Verification
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Independent numerical invariants, source concentration bounds, and tamper-evident audit history.
          </p>
        </div>

        <button
          onClick={handleExportJSON}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span>Export Audit Manifest (JSON)</span>
        </button>
      </div>

      {/* Validation Scorecard Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800">
        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Audit Status</span>
          <div className="mt-1 flex items-center gap-2">
            {failCount === 0 ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            ) : (
              <XCircle className="w-5 h-5 text-rose-400" />
            )}
            <span className="text-base font-bold text-white font-mono">
              {failCount === 0 ? 'GOVERNANCE APPROVED' : 'VALIDATION EXCEPTION'}
            </span>
          </div>
          <span className="text-[10px] text-slate-400">
            {passCount} Pass · {warnCount} Warning · {failCount} Fail
          </span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Concentration HHI Index</span>
          <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
            {rateResult.herfindahlIndex.toFixed(4)}
          </div>
          <span className="text-[10px] text-slate-400">
            Threshold &lt; 0.400 (Anti-Concentration rule)
          </span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">Input Data Freshness</span>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            100% Verified
          </div>
          <span className="text-[10px] text-slate-400">
            Mean observation age &lt; 6.5 hours
          </span>
        </div>

        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase">SHA-256 Execution Hash</span>
          <div className="text-xs font-mono text-cyan-300 font-bold mt-1.5 truncate" title={rateResult.executionHash}>
            {rateResult.executionHash}
          </div>
          <span className="text-[10px] text-slate-400">
            Immutable snapshot key
          </span>
        </div>
      </div>

      {/* Validation Battery Table */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-white font-sans">
              Independent Numerical & Statistical Checks
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Kernel Test Battery: v3.8-ARGON
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold">Test Specification</th>
                <th className="py-2.5 px-3 font-semibold text-center">Category</th>
                <th className="py-2.5 px-3 font-semibold text-center">Status</th>
                <th className="py-2.5 px-3 font-semibold">Invariant Threshold</th>
                <th className="py-2.5 px-3 font-semibold font-mono text-right">Observed Value</th>
                <th className="py-2.5 px-4 font-semibold">Verification Audit Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {checks.map((chk) => (
                <tr key={chk.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-white">
                    {chk.name}
                  </td>

                  <td className="py-3 px-3 text-center">
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {chk.category}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-center">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold border ${
                        chk.status === 'PASS'
                          ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                          : chk.status === 'WARNING'
                          ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                          : 'bg-rose-950/60 text-rose-300 border-rose-800'
                      }`}
                    >
                      {chk.status}
                    </span>
                  </td>

                  <td className="py-3 px-3 font-mono text-slate-300 text-[11px]">
                    {chk.threshold}
                  </td>

                  <td className="py-3 px-3 font-mono text-right font-bold text-white tabular-nums">
                    {chk.observedValue}
                  </td>

                  <td className="py-3 px-4 text-slate-300 text-xs">
                    {chk.detail}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Publication Records Ledger */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-white font-sans">
              Published Synthetic Benchmark History
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {publishedHistory.length} Recorded Releases
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold">Timestamp (UTC)</th>
                <th className="py-2.5 px-4 font-semibold">Benchmark Name</th>
                <th className="py-2.5 px-3 font-semibold text-center">Version</th>
                <th className="py-2.5 px-3 font-semibold text-right">Published Rate</th>
                <th className="py-2.5 px-4 font-semibold font-mono">Execution Hash</th>
                <th className="py-2.5 px-4 font-semibold text-center">Governance Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono text-xs">
              {publishedHistory.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-4 text-slate-400">
                    {item.timestamp}
                  </td>
                  <td className="py-2.5 px-4 text-white font-sans font-semibold">
                    {item.rateName}
                  </td>
                  <td className="py-2.5 px-3 text-center text-cyan-300">
                    {item.version}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-cyan-300 tabular-nums">
                    {item.ratePercent.toFixed(4)}%
                  </td>
                  <td className="py-2.5 px-4 text-slate-400 text-[11px] truncate max-w-xs">
                    {item.hash}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
