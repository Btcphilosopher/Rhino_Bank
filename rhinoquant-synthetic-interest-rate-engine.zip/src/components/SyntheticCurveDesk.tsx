/**
 * RhinoQuant Synthetic Yield Curve Builder
 * Multi-tenor term structure bootstrapping, discount factor derivation,
 * instantaneous/discrete forward extraction, and interactive visual analytics.
 */

import React, { useState } from 'react';
import { YieldCurvePoint, Currency, StressScenario } from '../engine/types';
import { constructSyntheticCurve } from '../engine/rateEngines';
import { LineChart, ArrowRight, Layers, Sliders, Info } from 'lucide-react';

interface SyntheticCurveDeskProps {
  baseSyntheticRatePct: number;
  currency: Currency;
  activeScenario?: StressScenario;
}

export const SyntheticCurveDesk: React.FC<SyntheticCurveDeskProps> = ({
  baseSyntheticRatePct,
  currency,
  activeScenario,
}) => {
  const [selectedView, setSelectedView] = useState<'SPOT' | 'FORWARD' | 'DISCOUNT' | 'SPREAD'>('SPOT');
  const [hoveredPoint, setHoveredPoint] = useState<YieldCurvePoint | null>(null);

  const curvePoints: YieldCurvePoint[] = React.useMemo(() => {
    return constructSyntheticCurve(baseSyntheticRatePct, currency, activeScenario);
  }, [baseSyntheticRatePct, currency, activeScenario]);

  // SVG Chart Geometry
  const width = 800;
  const height = 300;
  const padding = { top: 30, right: 30, bottom: 40, left: 60 };

  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  // Determine min & max depending on selected view
  let valuesSynthetic: number[] = [];
  let valuesBenchmark: number[] = [];

  if (selectedView === 'SPOT') {
    valuesSynthetic = curvePoints.map((p) => p.syntheticRatePercent);
    valuesBenchmark = curvePoints.map((p) => p.benchmarkRatePercent);
  } else if (selectedView === 'FORWARD') {
    valuesSynthetic = curvePoints.map((p) => p.forwardRatePercent);
    valuesBenchmark = curvePoints.map((p) => p.benchmarkRatePercent);
  } else if (selectedView === 'DISCOUNT') {
    valuesSynthetic = curvePoints.map((p) => p.discountFactor);
    valuesBenchmark = curvePoints.map((p) => p.discountFactor); // same scale
  } else {
    // SPREAD
    valuesSynthetic = curvePoints.map((p) => p.basisSpreadBps);
    valuesBenchmark = curvePoints.map(() => 0);
  }

  const allVals = [...valuesSynthetic, ...valuesBenchmark];
  const minVal = Math.min(...allVals);
  const maxVal = Math.max(...allVals);
  const valRange = Math.max(0.1, maxVal - minVal);
  const yMin = minVal - valRange * 0.1;
  const yMax = maxVal + valRange * 0.1;

  const getX = (index: number) => padding.left + (index / (curvePoints.length - 1)) * chartW;
  const getY = (val: number) => padding.top + chartH - ((val - yMin) / (yMax - yMin)) * chartH;

  // Generate SVG paths
  const syntheticPath = curvePoints
    .map((p, i) => {
      const val =
        selectedView === 'SPOT'
          ? p.syntheticRatePercent
          : selectedView === 'FORWARD'
          ? p.forwardRatePercent
          : selectedView === 'DISCOUNT'
          ? p.discountFactor
          : p.basisSpreadBps;
      const x = getX(i);
      const y = getY(val);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    })
    .join(' ');

  const benchmarkPath = curvePoints
    .map((p, i) => {
      const val =
        selectedView === 'SPOT'
          ? p.benchmarkRatePercent
          : selectedView === 'FORWARD'
          ? p.benchmarkRatePercent
          : selectedView === 'DISCOUNT'
          ? p.discountFactor
          : 0;
      const x = getX(i);
      const y = getY(val);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    })
    .join(' ');

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Synthetic Yield Curve & Term Structure
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              {currency} Multi-Tenor Bootstrap
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Construct continuous discount curves P(0, T), forward rates F(T_1, T_2), and benchmark spread tracking.
          </p>
        </div>

        {/* View Mode Segmented Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded">
          <button
            onClick={() => setSelectedView('SPOT')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              selectedView === 'SPOT' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Zero Curve
          </button>
          <button
            onClick={() => setSelectedView('FORWARD')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              selectedView === 'FORWARD' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Forward Curve
          </button>
          <button
            onClick={() => setSelectedView('DISCOUNT')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              selectedView === 'DISCOUNT' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Discount Factor
          </button>
          <button
            onClick={() => setSelectedView('SPREAD')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
              selectedView === 'SPREAD' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Basis Spread (bps)
          </button>
        </div>
      </div>

      {/* Interactive SVG Chart Container */}
      <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="w-3 h-0.5 bg-cyan-400 inline-block" />
              <span className="text-white font-semibold">Synthetic Term Curve</span>
            </div>
            {selectedView !== 'SPREAD' && (
              <div className="flex items-center gap-2">
                <span className="w-3 h-0.5 bg-slate-500 border-dashed inline-block" />
                <span className="text-slate-400">Reference Benchmark Curve</span>
              </div>
            )}
          </div>

          {hoveredPoint && (
            <div className="text-xs font-mono text-cyan-300">
              Tenor: <strong className="text-white">{hoveredPoint.tenor}</strong> ({hoveredPoint.days}d) ·
              Rate: <strong className="text-cyan-300">{hoveredPoint.syntheticRatePercent.toFixed(4)}%</strong> ·
              DF: <strong className="text-slate-300">{hoveredPoint.discountFactor.toFixed(6)}</strong> ·
              Fwd: <strong className="text-emerald-400">{hoveredPoint.forwardRatePercent.toFixed(4)}%</strong>
            </div>
          )}
        </div>

        {/* SVG Drawing Canvas */}
        <div className="w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full h-72 select-none"
          >
            {/* Horizontal Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1.0].map((frac, idx) => {
              const y = padding.top + chartH * frac;
              const val = yMax - frac * (yMax - yMin);
              return (
                <g key={idx}>
                  <line
                    x1={padding.left}
                    y1={y}
                    x2={width - padding.right}
                    y2={y}
                    stroke="#1e293b"
                    strokeWidth="1"
                  />
                  <text
                    x={padding.left - 8}
                    y={y + 3}
                    textAnchor="end"
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="JetBrains Mono"
                  >
                    {selectedView === 'DISCOUNT' ? val.toFixed(4) : selectedView === 'SPREAD' ? `${Math.round(val)}` : `${val.toFixed(2)}%`}
                  </text>
                </g>
              );
            })}

            {/* Benchmark Path */}
            {selectedView !== 'SPREAD' && (
              <path
                d={benchmarkPath}
                fill="none"
                stroke="#475569"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />
            )}

            {/* Synthetic Path */}
            <path
              d={syntheticPath}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2.5"
            />

            {/* Data Points */}
            {curvePoints.map((p, i) => {
              const val =
                selectedView === 'SPOT'
                  ? p.syntheticRatePercent
                  : selectedView === 'FORWARD'
                  ? p.forwardRatePercent
                  : selectedView === 'DISCOUNT'
                  ? p.discountFactor
                  : p.basisSpreadBps;
              const x = getX(i);
              const y = getY(val);
              const isHovered = hoveredPoint?.tenor === p.tenor;

              return (
                <g
                  key={p.tenor}
                  className="cursor-pointer group"
                  onMouseEnter={() => setHoveredPoint(p)}
                  onMouseLeave={() => setHoveredPoint(null)}
                >
                  {/* Vertical guide */}
                  <line
                    x1={x}
                    y1={padding.top}
                    x2={x}
                    y2={padding.top + chartH}
                    stroke={isHovered ? '#0891b2' : '#0f172a'}
                    strokeWidth={isHovered ? '1.5' : '1'}
                    strokeDasharray="2 2"
                  />

                  {/* Benchmark Circle */}
                  {selectedView !== 'SPREAD' && (
                    <circle
                      cx={x}
                      cy={getY(
                        selectedView === 'SPOT'
                          ? p.benchmarkRatePercent
                          : selectedView === 'FORWARD'
                          ? p.benchmarkRatePercent
                          : p.discountFactor
                      )}
                      r="3"
                      fill="#64748b"
                    />
                  )}

                  {/* Synthetic Circle */}
                  <circle
                    cx={x}
                    cy={y}
                    r={isHovered ? '6' : '4'}
                    fill={isHovered ? '#22d3ee' : '#0891b2'}
                    stroke="#020617"
                    strokeWidth="2"
                    className="transition-all"
                  />

                  {/* X-axis Tenor label */}
                  <text
                    x={x}
                    y={padding.top + chartH + 18}
                    textAnchor="middle"
                    fill={isHovered ? '#38bdf8' : '#94a3b8'}
                    fontSize="11"
                    fontFamily="JetBrains Mono"
                    fontWeight={isHovered ? 'bold' : 'normal'}
                  >
                    {p.tenor}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Tenor Point Breakdown Table */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white font-sans">
            Curve Pillar Term Structure Ledger
          </h2>
          <span className="text-xs font-mono text-slate-400">
            Interpolation: Monotone Convex Spline
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold">Tenor</th>
                <th className="py-2.5 px-3 font-semibold text-right">Calendar Days</th>
                <th className="py-2.5 px-3 font-semibold text-right">Year Fraction (τ)</th>
                <th className="py-2.5 px-3 font-semibold text-right">Synthetic Rate</th>
                <th className="py-2.5 px-3 font-semibold text-right">Discount Factor P(0, τ)</th>
                <th className="py-2.5 px-3 font-semibold text-right">Implied Forward Rate</th>
                <th className="py-2.5 px-3 font-semibold text-right">Benchmark Rate</th>
                <th className="py-2.5 px-4 font-semibold text-right">Basis Spread</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              {curvePoints.map((p) => (
                <tr
                  key={p.tenor}
                  className="hover:bg-slate-800/40 transition-colors"
                  onMouseEnter={() => setHoveredPoint(p)}
                  onMouseLeave={() => setHoveredPoint(null)}
                >
                  <td className="py-2.5 px-4 font-bold text-white">
                    {p.tenor}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {p.days}d
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 tabular-nums">
                    {p.yearFraction.toFixed(4)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-cyan-300 tabular-nums">
                    {p.syntheticRatePercent.toFixed(4)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200 tabular-nums">
                    {p.discountFactor.toFixed(6)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold tabular-nums">
                    {p.forwardRatePercent.toFixed(4)}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 tabular-nums">
                    {p.benchmarkRatePercent.toFixed(2)}%
                  </td>
                  <td className="py-2.5 px-4 text-right font-bold text-amber-400 tabular-nums">
                    {p.basisSpreadBps > 0 ? `+${p.basisSpreadBps}` : p.basisSpreadBps} bps
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
