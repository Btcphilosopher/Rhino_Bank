/**
 * RhinoQuant API & Market Data Monitor
 * Live status of connected feeds, latency diagnostics, observation freshness,
 * and manual quotation overrides.
 */

import React, { useState } from 'react';
import { MarketObservation } from '../engine/types';
import { Server, Activity, PlusCircle, CheckCircle2, Clock, ShieldCheck, Database } from 'lucide-react';

interface ApiMonitorDeskProps {
  observations: MarketObservation[];
  onAddObservation: (obs: MarketObservation) => void;
}

export const ApiMonitorDesk: React.FC<ApiMonitorDeskProps> = ({
  observations,
  onAddObservation,
}) => {
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newSymbol, setNewSymbol] = useState<string>('USDCP.TIER2.3M');
  const [newName, setNewName] = useState<string>('Commercial Paper Tier-2 3M');
  const [newRate, setNewRate] = useState<number>(5.35);
  const [newVolume, setNewVolume] = useState<number>(12000);

  const dataProviders = [
    { name: 'Federal Reserve Bank of NY', protocol: 'REST / H.15', latencyMs: 24, status: 'NOMINAL', items: 3 },
    { name: 'European Central Bank (ECB)', protocol: 'SDMX REST', latencyMs: 38, status: 'NOMINAL', items: 1 },
    { name: 'Bank of England', protocol: 'JSON API', latencyMs: 31, status: 'NOMINAL', items: 1 },
    { name: 'Bank of Japan', protocol: 'BOJ Time-Series', latencyMs: 65, status: 'NOMINAL', items: 1 },
    { name: 'CME Group / BrokerTec', protocol: 'FIX 4.4 DropCopy', latencyMs: 12, status: 'NOMINAL', items: 4 },
    { name: 'DTCC / BNY Mellon', protocol: 'MQ Native', latencyMs: 18, status: 'NOMINAL', items: 1 },
    { name: 'Tradeweb Dealer Consensus', protocol: 'WebSocket Streaming', latencyMs: 15, status: 'NOMINAL', items: 2 },
    { name: 'EBS Spot & Forward Desk', protocol: 'FIX 5.0 SP2', latencyMs: 14, status: 'NOMINAL', items: 2 },
    { name: 'Markit CDS Composite', protocol: 'REST Batch', latencyMs: 42, status: 'NOMINAL', items: 1 },
    { name: 'Intex Structured Credit', protocol: 'CDO Analytics RPC', latencyMs: 55, status: 'NOMINAL', items: 1 },
  ];

  const handleCreateObservation = (e: React.FormEvent) => {
    e.preventDefault();
    const newObs: MarketObservation = {
      id: `OBS_CUSTOM_${Date.now()}`,
      symbol: newSymbol,
      name: newName,
      category: 'CP_CD',
      currency: 'USD',
      tenor: '3M',
      tenorDays: 90,
      rawRateOrPrice: newRate,
      unit: 'PERCENT',
      dayCount: 'ACT/360',
      compounding: 'Simple',
      collateralType: 'UNSECURED',
      creditQuality: 'BBB',
      observationTime: new Date().toISOString(),
      provider: 'RhinoQuant Trader Manual Ingestion',
      qualityScore: 88,
      volumeMillionsUSD: newVolume,
      isSimulated: true,
      notes: 'Custom money market observation injected for sensitivity run.',
    };
    onAddObservation(newObs);
    setShowAddModal(false);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              API Feeds & Market Data Monitor
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              Low-Latency Ingestion
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time feed telemetry, socket connectivity, observation timestamps, and manual quote injection.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors cursor-pointer shadow-sm shadow-cyan-900/50"
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>Inject Custom Observation</span>
        </button>
      </div>

      {/* Provider Connectivity Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
        {dataProviders.map((p, idx) => (
          <div
            key={idx}
            className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span className="truncate max-w-[120px]">{p.protocol}</span>
                <span className="text-emerald-400 font-bold">{p.status}</span>
              </div>
              <div className="text-xs font-semibold text-white mt-1 line-clamp-1" title={p.name}>
                {p.name}
              </div>
            </div>

            <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] font-mono text-slate-400">
              <span>{p.items} feeds</span>
              <span className="text-cyan-400 font-semibold">{p.latencyMs}ms</span>
            </div>
          </div>
        ))}
      </div>

      {/* Connected Market Ingestion Ledger */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-white font-sans">
              Ingested Market Observations Feed Ledger
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {observations.length} Registered Live Fixings
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold">Symbol & Name</th>
                <th className="py-2.5 px-3 font-semibold text-center">Currency / Tenor</th>
                <th className="py-2.5 px-3 font-semibold text-right">Raw Rate / Quote</th>
                <th className="py-2.5 px-3 font-semibold text-center">Collateral</th>
                <th className="py-2.5 px-3 font-semibold">Authorized Source Provider</th>
                <th className="py-2.5 px-3 font-semibold text-right">Volume (USD)</th>
                <th className="py-2.5 px-4 font-semibold text-center">Quality Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {observations.map((obs) => (
                <tr key={obs.id} className="hover:bg-slate-800/40 transition-colors font-mono">
                  <td className="py-2.5 px-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-xs">{obs.symbol}</span>
                        {obs.isSimulated && (
                          <span className="text-[9px] px-1 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800">
                            MANUAL
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 font-sans truncate max-w-sm">
                        {obs.name}
                      </span>
                    </div>
                  </td>

                  <td className="py-2.5 px-3 text-center text-cyan-300">
                    {obs.currency} {obs.tenor}
                  </td>

                  <td className="py-2.5 px-3 text-right font-bold text-white tabular-nums">
                    {obs.rawRateOrPrice.toFixed(4)}%
                  </td>

                  <td className="py-2.5 px-3 text-center text-slate-400 text-[10px]">
                    {obs.collateralType}
                  </td>

                  <td className="py-2.5 px-3 text-slate-300 text-xs font-sans">
                    {obs.provider}
                  </td>

                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {obs.volumeMillionsUSD ? `$${obs.volumeMillionsUSD.toLocaleString()}M` : '-'}
                  </td>

                  <td className="py-2.5 px-4 text-center">
                    <span className="text-emerald-400 font-bold tabular-nums">
                      {obs.qualityScore}/100
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Observation Ingestion Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg max-w-md w-full p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white font-sans">
                Inject Custom Observation
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-xs font-mono cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateObservation} className="space-y-3">
              <div>
                <label className="text-[10px] font-mono text-slate-400 uppercase">Symbol</label>
                <input
                  type="text"
                  value={newSymbol}
                  onChange={(e) => setNewSymbol(e.target.value)}
                  className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-mono text-slate-400 uppercase">Instrument Description</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-sans"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase">Rate (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newRate}
                    onChange={(e) => setNewRate(Number(e.target.value))}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 uppercase">Volume ($M)</label>
                  <input
                    type="number"
                    value={newVolume}
                    onChange={(e) => setNewVolume(Number(e.target.value))}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors cursor-pointer"
                >
                  Save & Ingest
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
