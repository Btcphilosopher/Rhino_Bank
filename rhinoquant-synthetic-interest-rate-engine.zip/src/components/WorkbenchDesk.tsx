/**
 * RhinoQuant Rate Composition Workbench
 * The central product workbench for selecting source observations, configuring
 * transformations, applying risk adjustments, and inspecting the source-contribution ledger.
 */

import React, { useState } from 'react';
import {
  SyntheticRateDefinition,
  MarketObservation,
  RateConstructionResult,
  Currency,
  Tenor,
  DayCountConvention,
  CompoundingBasis,
  EconomicPurpose,
} from '../engine/types';
import {
  Sliders,
  CheckSquare,
  Square,
  ShieldCheck,
  Save,
  Send,
  Download,
  Info,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  RefreshCw,
} from 'lucide-react';

interface WorkbenchDeskProps {
  currentDefinition: SyntheticRateDefinition;
  allDefinitions: SyntheticRateDefinition[];
  allObservations: MarketObservation[];
  rateResult: RateConstructionResult;
  onUpdateDefinition: (updated: SyntheticRateDefinition) => void;
  onSelectDefinition: (id: string) => void;
  onPublishRate: () => void;
  onSaveNewVersion: () => void;
  onNavigate: (screen: string) => void;
}

export const WorkbenchDesk: React.FC<WorkbenchDeskProps> = ({
  currentDefinition,
  allDefinitions,
  allObservations,
  rateResult,
  onUpdateDefinition,
  onSelectDefinition,
  onPublishRate,
  onSaveNewVersion,
  onNavigate,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  // Toggle instrument inclusion
  const handleToggleInstrument = (obsId: string) => {
    const isSelected = currentDefinition.selectedInstrumentIds.includes(obsId);
    let newSelected: string[];
    if (isSelected) {
      if (currentDefinition.selectedInstrumentIds.length <= 1) {
        return; // Preserve at least 1 observation
      }
      newSelected = currentDefinition.selectedInstrumentIds.filter((id) => id !== obsId);
    } else {
      newSelected = [...currentDefinition.selectedInstrumentIds, obsId];
    }
    onUpdateDefinition({
      ...currentDefinition,
      selectedInstrumentIds: newSelected,
    });
  };

  const filteredObservations = allObservations.filter((obs) => {
    if (filterCategory === 'ALL') return true;
    if (filterCategory === 'SELECTED') return currentDefinition.selectedInstrumentIds.includes(obs.id);
    return obs.category === filterCategory;
  });

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header & Methodology Selector */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Rate Composition Workbench
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              {currentDefinition.version}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Configure multi-market sources, convention harmonisation, and explicit basis adjustments.
          </p>
        </div>

        {/* Action Controls & Methodology Preset Dropdown */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded px-2.5 py-1">
            <span className="text-[11px] font-mono text-slate-400">Methodology:</span>
            <select
              value={currentDefinition.id}
              onChange={(e) => onSelectDefinition(e.target.value)}
              className="bg-transparent text-xs text-cyan-300 font-semibold focus:outline-none cursor-pointer"
            >
              {allDefinitions.map((d) => (
                <option key={d.id} value={d.id} className="bg-slate-900 text-white">
                  {d.name} ({d.version})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onSaveNewVersion}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors cursor-pointer"
          >
            <Save className="w-3.5 h-3.5 text-slate-400" />
            <span>Save Version</span>
          </button>

          <button
            onClick={onPublishRate}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors cursor-pointer shadow-sm shadow-cyan-900/50"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publish Rate</span>
          </button>
        </div>
      </div>

      {/* Top Output Strip & Calculated Rate Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800">
        <div>
          <span className="text-[11px] text-slate-400 font-mono">CONSTRUCTED SYNTHETIC RATE</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-cyan-300 tabular-nums">
              {rateResult.outputRatePercent.toFixed(4)}%
            </span>
            <span className="text-xs font-mono text-slate-400">
              {currentDefinition.targetCurrency} {currentDefinition.targetTenor}
            </span>
          </div>
          <span className="text-[10px] text-slate-400">
            Harmonised to {currentDefinition.targetDayCount} · {currentDefinition.targetCompounding}
          </span>
        </div>

        <div>
          <span className="text-[11px] text-slate-400 font-mono">BENCHMARK COMPARISON</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {rateResult.benchmarkComparison.benchmarkRatePercent.toFixed(2)}%
            </span>
            <span
              className={`text-xs font-mono font-semibold tabular-nums ${
                rateResult.benchmarkComparison.spreadBps > 0 ? 'text-amber-400' : 'text-cyan-400'
              }`}
            >
              ({rateResult.benchmarkComparison.spreadBps > 0 ? '+' : ''}
              {rateResult.benchmarkComparison.spreadBps} bps)
            </span>
          </div>
          <span className="text-[10px] text-slate-400">
            vs {rateResult.benchmarkComparison.benchmarkName}
          </span>
        </div>

        <div>
          <span className="text-[11px] text-slate-400 font-mono">DISCOUNT FACTOR P(0, τ)</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {rateResult.outputDiscountFactor.toFixed(6)}
            </span>
          </div>
          <span className="text-[10px] text-slate-400">
            Accrual τ = {(rateResult.components[0]?.adjustments ? 90 / 360 : 0.25).toFixed(4)} yrs
          </span>
        </div>

        <div className="flex flex-col justify-between">
          <div>
            <span className="text-[11px] text-slate-400 font-mono">INDEPENDENT VALIDATION</span>
            <div className="mt-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-semibold text-emerald-300">
                All 5 Invariants Passed
              </span>
            </div>
            <span className="text-[10px] text-slate-400">
              Concentration HHI: {rateResult.herfindahlIndex.toFixed(3)}
            </span>
          </div>
          <button
            onClick={() => onNavigate('bridge')}
            className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium text-left mt-1 cursor-pointer"
          >
            Inspect Step-by-Step Rate Bridge →
          </button>
        </div>
      </div>

      {/* Configuration Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Target Contract & Economic Meaning */}
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              1. Target Contract & Purpose
            </h2>
          </div>

          {/* Currency & Tenor */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Target Currency</label>
              <select
                value={currentDefinition.targetCurrency}
                onChange={(e) =>
                  onUpdateDefinition({
                    ...currentDefinition,
                    targetCurrency: e.target.value as Currency,
                  })
                }
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 focus:border-cyan-500 focus:outline-none font-mono"
              >
                {(['USD', 'EUR', 'GBP', 'JPY', 'CHF'] as Currency[]).map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Target Tenor</label>
              <select
                value={currentDefinition.targetTenor}
                onChange={(e) =>
                  onUpdateDefinition({
                    ...currentDefinition,
                    targetTenor: e.target.value as Tenor,
                  })
                }
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 focus:border-cyan-500 focus:outline-none font-mono"
              >
                {(['ON', '1W', '1M', '3M', '6M', '1Y', '2Y', '5Y'] as Tenor[]).map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Economic Purpose */}
          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase">Economic Purpose</label>
            <select
              value={currentDefinition.purpose}
              onChange={(e) =>
                onUpdateDefinition({
                  ...currentDefinition,
                  purpose: e.target.value as EconomicPurpose,
                })
              }
              className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 focus:border-cyan-500 focus:outline-none font-mono"
            >
              <option value="OVERNIGHT_FUNDING">Overnight Funding Rate</option>
              <option value="TERM_FUNDING">Term Wholesale Funding Rate</option>
              <option value="UNSECURED_BANK_FUNDING">Unsecured Bank Funding Rate</option>
              <option value="CARRY_IMPLIED_FINANCING">Carry & CIP Implied Financing</option>
              <option value="STRUCTURED_CREDIT_FINANCING">Structured Credit & CDO Financing</option>
              <option value="CROSS_CURRENCY_FUNDING">Cross-Currency Offshore Funding</option>
              <option value="COMMERCIAL_RECEIVABLES">Commercial Receivables Financing</option>
            </select>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Governs whether credit, liquidity, and collateral effects are stripped or incorporated.
            </span>
          </div>

          {/* Day Count & Compounding */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Day Count</label>
              <select
                value={currentDefinition.targetDayCount}
                onChange={(e) =>
                  onUpdateDefinition({
                    ...currentDefinition,
                    targetDayCount: e.target.value as DayCountConvention,
                  })
                }
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 focus:border-cyan-500 focus:outline-none font-mono"
              >
                <option value="ACT/360">ACT/360</option>
                <option value="ACT/365F">ACT/365F</option>
                <option value="30/360">30/360</option>
                <option value="ACT/ACT">ACT/ACT</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-mono text-slate-400 uppercase">Compounding</label>
              <select
                value={currentDefinition.targetCompounding}
                onChange={(e) =>
                  onUpdateDefinition({
                    ...currentDefinition,
                    targetCompounding: e.target.value as CompoundingBasis,
                  })
                }
                className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 focus:border-cyan-500 focus:outline-none font-mono"
              >
                <option value="Simple">Simple</option>
                <option value="CompoundedDaily">Compounded Daily</option>
                <option value="Annual">Annual</option>
                <option value="SemiAnnual">Semi-Annual</option>
                <option value="Continuous">Continuous</option>
              </select>
            </div>
          </div>
        </div>

        {/* Middle Column: Mathematical Methodology */}
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              2. Construction Methodology
            </h2>
          </div>

          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase">Aggregation Method</label>
            <select
              value={currentDefinition.constructionMethod}
              onChange={(e) =>
                onUpdateDefinition({
                  ...currentDefinition,
                  constructionMethod: e.target.value as any,
                })
              }
              className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-white rounded p-1.5 focus:border-cyan-500 focus:outline-none font-mono"
            >
              <option value="WEIGHTED_VOLUME">Volume-Weighted Average (VWAP)</option>
              <option value="INVERSE_VARIANCE">Inverse-Variance Quality Weighted</option>
              <option value="ROBUST_HUBER_COMPOSITE">Robust Huber M-Estimator (Anti-Manipulation)</option>
              <option value="RISK_ADJUSTED_SPREAD">Calibrated Risk-Adjusted Spread</option>
              <option value="FORWARD_CURVE_BOOTSTRAP">Forward Curve Bootstrap</option>
              <option value="SOLVER_IRR">Numerical Cash-Flow IRR Solver</option>
            </select>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Weights reflect documented economic rationale rather than target fitting.
            </span>
          </div>

          {/* Governance Notes */}
          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase">Governance Specification</label>
            <textarea
              rows={3}
              value={currentDefinition.governanceNotes}
              onChange={(e) =>
                onUpdateDefinition({
                  ...currentDefinition,
                  governanceNotes: e.target.value,
                })
              }
              className="w-full mt-1 bg-slate-950 border border-slate-700 text-xs text-slate-300 rounded p-2 focus:border-cyan-500 focus:outline-none resize-none font-sans"
              placeholder="State institutional purpose, fallback rules, and justification..."
            />
          </div>

          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1">
            <span>Author: <strong className="text-slate-300">{currentDefinition.author}</strong></span>
            <span>Status: <strong className="text-emerald-400">{currentDefinition.status}</strong></span>
          </div>
        </div>

        {/* Right Column: Basis & Risk Adjustments */}
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              3. Basis & Risk Adjustments
            </h2>
            <span className="text-[10px] text-slate-400 font-mono">Calibrated bps</span>
          </div>

          {/* Credit Spread Override */}
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Credit Spread Offset:</span>
              <span className="font-mono text-cyan-300 font-bold tabular-nums">
                {currentDefinition.creditSpreadOverrideBps ?? 32} bps
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={150}
              step={1}
              value={currentDefinition.creditSpreadOverrideBps ?? 32}
              onChange={(e) =>
                onUpdateDefinition({
                  ...currentDefinition,
                  creditSpreadOverrideBps: Number(e.target.value),
                })
              }
              className="w-full mt-1.5 accent-cyan-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              Reflects unsecured credit risk premium over pure risk-free repo.
            </span>
          </div>

          {/* Liquidity Premium Override */}
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Liquidity Depth Premium:</span>
              <span className="font-mono text-cyan-300 font-bold tabular-nums">
                {currentDefinition.liquidityPremiumOverrideBps ?? 12} bps
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={80}
              step={1}
              value={currentDefinition.liquidityPremiumOverrideBps ?? 12}
              onChange={(e) =>
                onUpdateDefinition({
                  ...currentDefinition,
                  liquidityPremiumOverrideBps: Number(e.target.value),
                })
              }
              className="w-full mt-1.5 accent-cyan-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              Accounts for secondary market bid-ask roll cost and tiering.
            </span>
          </div>

          <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
            <div className="flex items-center gap-1.5 text-cyan-400 font-semibold mb-1">
              <Info className="w-3.5 h-3.5" />
              <span>Anti-Double Counting Check</span>
            </div>
            If an input observation (such as CP Tier 1) already embeds credit spreads, the engine automatically checks and prevents duplicate risk loadings.
          </div>
        </div>
      </div>

      {/* Eligible Market Observations & Source Contribution Ledger */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-white font-sans">
              Source-Contribution Ledger
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Inspect raw market observations, convention transformations, risk adjustments, and final weighted contributions.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded border border-slate-800">
            <button
              onClick={() => setFilterCategory('ALL')}
              className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                filterCategory === 'ALL'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Sources ({allObservations.length})
            </button>
            <button
              onClick={() => setFilterCategory('SELECTED')}
              className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                filterCategory === 'SELECTED'
                  ? 'bg-slate-800 text-cyan-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Active ({currentDefinition.selectedInstrumentIds.length})
            </button>
            <button
              onClick={() => setFilterCategory('OVERNIGHT_BENCHMARK')}
              className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                filterCategory === 'OVERNIGHT_BENCHMARK'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Overnight
            </button>
            <button
              onClick={() => setFilterCategory('CP_CD')}
              className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                filterCategory === 'CP_CD'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CP & CD
            </button>
            <button
              onClick={() => setFilterCategory('FX_FORWARD_CIP')}
              className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                filterCategory === 'FX_FORWARD_CIP'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              FX CIP
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-3 text-center w-10">Inc</th>
                <th className="py-2.5 px-3 font-semibold">Instrument</th>
                <th className="py-2.5 px-3 font-semibold text-center">Category</th>
                <th className="py-2.5 px-3 font-semibold text-right">Raw Rate</th>
                <th className="py-2.5 px-3 font-semibold text-right">Conv Rate</th>
                <th className="py-2.5 px-3 font-semibold text-right">Credit</th>
                <th className="py-2.5 px-3 font-semibold text-right">Liquidity</th>
                <th className="py-2.5 px-3 font-semibold text-right">Collateral</th>
                <th className="py-2.5 px-3 font-semibold text-right">Net Adjusted</th>
                <th className="py-2.5 px-3 font-semibold text-right">Weight</th>
                <th className="py-2.5 px-3 font-semibold text-right">Contribution</th>
                <th className="py-2.5 px-3 font-semibold text-center">Quality</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredObservations.map((obs) => {
                const isSelected = currentDefinition.selectedInstrumentIds.includes(obs.id);
                const comp = rateResult.components.find((c) => c.observationId === obs.id);

                return (
                  <tr
                    key={obs.id}
                    className={`transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-slate-900/90 hover:bg-slate-800/60'
                        : 'bg-slate-950/40 text-slate-500 hover:bg-slate-900/40'
                    }`}
                    onClick={() => handleToggleInstrument(obs.id)}
                  >
                    <td className="py-2.5 px-3 text-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleInstrument(obs.id);
                        }}
                        className="text-cyan-400 hover:text-cyan-300 cursor-pointer"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-cyan-400" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-600" />
                        )}
                      </button>
                    </td>

                    <td className="py-2.5 px-3">
                      <div className="flex flex-col">
                        <span className={`font-semibold font-mono text-xs ${isSelected ? 'text-white' : 'text-slate-500'}`}>
                          {obs.symbol}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate max-w-xs">
                          {obs.name}
                        </span>
                      </div>
                    </td>

                    <td className="py-2.5 px-3 text-center">
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                        {obs.category.replace(/_/g, ' ')}
                      </span>
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                      {obs.rawRateOrPrice.toFixed(2)}%
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">
                      {comp ? comp.transformedAnnualRate.toFixed(4) : '-'}%
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                      {comp ? (comp.adjustments.creditRiskBps >= 0 ? `+${comp.adjustments.creditRiskBps}` : comp.adjustments.creditRiskBps) : '-'}
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                      {comp ? (comp.adjustments.liquidityRiskBps >= 0 ? `+${comp.adjustments.liquidityRiskBps}` : comp.adjustments.liquidityRiskBps) : '-'}
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                      {comp ? (comp.adjustments.collateralEffectBps >= 0 ? `+${comp.adjustments.collateralEffectBps}` : comp.adjustments.collateralEffectBps) : '-'}
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-cyan-300 tabular-nums">
                      {comp ? `${comp.netAdjustedRate.toFixed(4)}%` : '-'}
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-white">
                      {comp ? `${(comp.weight * 100).toFixed(1)}%` : '0.0%'}
                    </td>

                    <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-emerald-400">
                      {comp ? `${comp.effectiveContribution.toFixed(4)}%` : '0.0000%'}
                    </td>

                    <td className="py-2.5 px-3 text-center font-mono tabular-nums text-[11px] text-slate-400">
                      {obs.qualityScore}/100
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
