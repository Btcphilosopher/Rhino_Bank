/**
 * RhinoQuant Institutional Left Sidebar Navigation
 * High-density, dark graphite aesthetic with clean icons and crisp active state.
 */

import React from 'react';
import {
  LayoutDashboard,
  Cpu,
  Clock,
  TrendingUp,
  Layers,
  LineChart,
  GitCommit,
  Flame,
  ShieldCheck,
  Server,
  FileCheck,
  ExternalLink,
} from 'lucide-react';

interface SidebarProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
  unresolvedExceptionsCount: number;
}

interface NavItem {
  id: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  badgeCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeScreen,
  onNavigate,
  unresolvedExceptionsCount,
}) => {
  const navSections: { sectionTitle: string; items: NavItem[] }[] = [
    {
      sectionTitle: 'SYNTHETIC PRICING',
      items: [
        {
          id: 'overview',
          label: 'Executive Overview',
          description: 'Published rates & benchmarks',
          icon: LayoutDashboard,
        },
        {
          id: 'workbench',
          label: 'Composition Workbench',
          description: 'Multi-market rate synthesizer',
          icon: Cpu,
        },
        {
          id: 'bridge',
          label: 'Rate Bridge',
          description: 'Step-by-step risk attribution',
          icon: GitCommit,
        },
        {
          id: 'curve',
          label: 'Synthetic Yield Curve',
          description: 'Bootstrapping & forward curves',
          icon: LineChart,
        },
      ],
    },
    {
      sectionTitle: 'UNDERLYING DESKS',
      items: [
        {
          id: 'overnight',
          label: 'Overnight & Wholesale',
          description: 'SOFR/ESTR & GC repo compounding',
          icon: Clock,
        },
        {
          id: 'carry',
          label: 'Carry & FX Implied CIP',
          description: 'Covered interest parity & basis',
          icon: TrendingUp,
        },
        {
          id: 'cdo',
          label: 'Structured Credit & CDO',
          description: 'Tranche waterfalls & cash flows',
          icon: Layers,
        },
      ],
    },
    {
      sectionTitle: 'RISK & GOVERNANCE',
      items: [
        {
          id: 'stress',
          label: 'Scenario & Stress Lab',
          description: 'Funding squeeze & basis shocks',
          icon: Flame,
        },
        {
          id: 'validation',
          label: 'Validation & Audit',
          description: 'Concentration & integrity checks',
          icon: ShieldCheck,
          badgeCount: unresolvedExceptionsCount,
        },
        {
          id: 'monitor',
          label: 'Market Feeds & Feasibility',
          description: 'Observation freshness & feeds',
          icon: Server,
        },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col shrink-0 select-none overflow-y-auto">
      {/* Navigation List */}
      <div className="py-4 px-3 space-y-6 flex-1">
        {navSections.map((sec, sIdx) => (
          <div key={sIdx} className="space-y-1">
            <div className="px-2 pb-1 text-[10px] font-mono font-semibold tracking-wider text-slate-400 uppercase">
              {sec.sectionTitle}
            </div>
            {sec.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded text-left transition-colors cursor-pointer group ${
                    isActive
                      ? 'bg-slate-900 border border-slate-700 text-cyan-300'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'
                      }`}
                    />
                    <div className="flex flex-col min-w-0">
                      <span className={`text-xs font-semibold leading-tight truncate ${isActive ? 'text-white' : 'text-slate-300'}`}>
                        {item.label}
                      </span>
                      <span className="text-[10px] text-slate-400 truncate leading-tight">
                        {item.description}
                      </span>
                    </div>
                  </div>

                  {item.badgeCount !== undefined && item.badgeCount > 0 && (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/80 tabular-nums shrink-0">
                      {item.badgeCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Institutional Metadata Footer */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/90 text-[11px] text-slate-400 space-y-1">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] text-slate-400">MATH KERNEL</span>
          <span className="font-mono text-[10px] text-cyan-400">v3.8-ARGON</span>
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-400">
          <span>Engine Status</span>
          <span className="text-emerald-400 font-mono">NOMINAL</span>
        </div>
      </div>
    </aside>
  );
};
