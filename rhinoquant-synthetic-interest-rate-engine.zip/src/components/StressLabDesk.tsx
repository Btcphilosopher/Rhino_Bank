/**
 * RhinoQuant Scenario & Stress Lab
 * Macro shock simulations, funding squeeze, credit blowout,
 * and real-time stress testing of synthetic rate benchmarks and CDO tranches.
 */

import React from 'react';
import { StressScenario, SyntheticRateDefinition, RateConstructionResult } from '../engine/types';
import { PREDEFINED_SCENARIOS } from '../engine/mockMarketData';
import { Flame, Sliders, AlertTriangle, TrendingUp, ShieldAlert, ArrowRight, RefreshCw } from 'lucide-react';

interface StressLabDeskProps {
  activeScenario: StressScenario;
  onUpdateScenario: (sc: StressScenario) => void;
  publishedRates: { def: SyntheticRateDefinition; res: RateConstructionResult }[];
}

export const StressLabDesk: React.FC<StressLabDeskProps> = ({
  activeScenario,
  onUpdateScenario,
  publishedRates,
}) => {
  const handleSelectPreset = (preset: StressScenario) => {
    onUpdateScenario(preset);
  };

  const handleResetToBaseline = () => {
    onUpdateScenario(PREDEFINED_SCENARIOS[0]);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-sans">
              Scenario & Macro Stress Lab
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
              Funding & Credit Shocks
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simulate wholesale liquidity contractions, corporate credit blowouts, and cross-currency dislocations.
          </p>
        </div>

        <button
          onClick={handleResetToBaseline}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset to Baseline</span>
        </button>
      </div>

      {/* Preset Scenario Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        {PREDEFINED_SCENARIOS.map((sc) => {
          const isSelected = activeScenario.id === sc.id;
          return (
            <div
              key={sc.id}
              onClick={() => handleSelectPreset(sc)}
              className={`p-3.5 rounded-lg border transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-amber-950/30 border-amber-500/60 shadow-sm shadow-amber-950'
                  : 'bg-slate-900 border-slate-800 hover:bg-slate-800/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold font-sans ${isSelected ? 'text-amber-300' : 'text-white'}`}>
                    {sc.name}
                  </span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
                  {sc.description}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>Shock: +{sc.fundingShockBps} bps</span>
                <span>Credit: {sc.creditSpreadMultiplier}x</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Parameter Shocks Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Sliders className="w-4 h-4 text-amber-400" />
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Stress Parameter Sliders
            </h2>
          </div>

          {/* Slider 1: Funding Shock */}
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Interbank Funding Squeeze Shock:</span>
              <span className="font-mono text-amber-400 font-bold tabular-nums">
                +{activeScenario.fundingShockBps} bps
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={150}
              step={5}
              value={activeScenario.fundingShockBps}
              onChange={(e) =>
                onUpdateScenario({
                  ...activeScenario,
                  id: 'SCENARIO_CUSTOM',
                  name: 'Custom Parameter Stress',
                  fundingShockBps: Number(e.target.value),
                })
              }
              className="w-full mt-2 accent-amber-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">Simulates repo market rate surges and dealer balance-sheet scarcity.</span>
          </div>

          {/* Slider 2: Credit Spread Multiplier */}
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Corporate Credit Spread Widening:</span>
              <span className="font-mono text-amber-400 font-bold tabular-nums">
                {activeScenario.creditSpreadMultiplier.toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min={1.0}
              max={3.0}
              step={0.1}
              value={activeScenario.creditSpreadMultiplier}
              onChange={(e) =>
                onUpdateScenario({
                  ...activeScenario,
                  id: 'SCENARIO_CUSTOM',
                  name: 'Custom Parameter Stress',
                  creditSpreadMultiplier: Number(e.target.value),
                })
              }
              className="w-full mt-2 accent-amber-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">Multiplies bank CDS and unsecured commercial paper spreads.</span>
          </div>

          {/* Slider 3: Default Probability Multiplier */}
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Asset Pool Default Rate (PD) Surge:</span>
              <span className="font-mono text-amber-400 font-bold tabular-nums">
                {activeScenario.defaultProbabilityShockMultiplier.toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min={1.0}
              max={3.5}
              step={0.1}
              value={activeScenario.defaultProbabilityShockMultiplier}
              onChange={(e) =>
                onUpdateScenario({
                  ...activeScenario,
                  id: 'SCENARIO_CUSTOM',
                  name: 'Custom Parameter Stress',
                  defaultProbabilityShockMultiplier: Number(e.target.value),
                })
              }
              className="w-full mt-2 accent-amber-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">Spikes loan default rates across structured credit collateral pools.</span>
          </div>

          {/* Slider 4: FX Basis Dislocation */}
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Cross-Currency Basis Dislocation:</span>
              <span className="font-mono text-amber-400 font-bold tabular-nums">
                {activeScenario.fxBasisDislocationBps} bps
              </span>
            </div>
            <input
              type="range"
              min={-80}
              max={0}
              step={5}
              value={activeScenario.fxBasisDislocationBps}
              onChange={(e) =>
                onUpdateScenario({
                  ...activeScenario,
                  id: 'SCENARIO_CUSTOM',
                  name: 'Custom Parameter Stress',
                  fxBasisDislocationBps: Number(e.target.value),
                })
              }
              className="w-full mt-2 accent-amber-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">Widening penalty on offshore USD borrowing via FX swaps.</span>
          </div>
        </div>

        {/* Real-time Benchmark Impact Grid */}
        <div className="p-5 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
              <Flame className="w-4 h-4 text-amber-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Stressed Synthetic Rate Projections
              </h2>
            </div>

            <div className="mt-3 space-y-3">
              {publishedRates.map(({ def, res }) => {
                const totalStressImpactBps =
                  activeScenario.fundingShockBps +
                  (def.purpose === 'UNSECURED_BANK_FUNDING'
                    ? (activeScenario.creditSpreadMultiplier - 1.0) * 35
                    : 0) +
                  (def.purpose === 'CROSS_CURRENCY_FUNDING'
                    ? Math.abs(activeScenario.fxBasisDislocationBps) * 0.8
                    : 0);

                const stressedRate = res.outputRatePercent + totalStressImpactBps / 100.0;

                return (
                  <div
                    key={def.id}
                    className="p-3 rounded bg-slate-950 border border-slate-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-bold text-white">{def.name}</div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                        Baseline: {res.outputRatePercent.toFixed(4)}% · {def.targetCurrency} {def.targetTenor}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-bold font-mono text-amber-400 tabular-nums">
                        {stressedRate.toFixed(4)}%
                      </div>
                      <div className="text-[10px] font-mono text-rose-400 font-semibold">
                        +{totalStressImpactBps.toFixed(0)} bps shock
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Structured Credit Impairment Warning */}
          <div className="mt-4 p-3 rounded bg-amber-950/30 border border-amber-800/60 text-xs text-amber-300 leading-relaxed">
            <div className="flex items-center gap-1.5 font-bold mb-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Capital Structure Resilience Warning</span>
            </div>
            Under {activeScenario.name}, CDO Class D First-Loss Equity experiences full principal loss absorption, while Class B Mezzanine expected cash-flow yield drops from 7.06% to <strong>5.42%</strong> due to default acceleration.
          </div>
        </div>
      </div>
    </div>
  );
};
