/**
 * RhinoQuant Executive Overview Desk
 * High-density institutional summary of active synthetic rates, benchmarks, and market liquidity.
 */

import React from 'react';
import {
  SyntheticRateDefinition,
  RateConstructionResult,
  StressScenario,
} from '../engine/types';
import {
  TrendingUp,
  ShieldCheck,
  Zap,
  ArrowUpRight,
  Database,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Play,
} from 'lucide-react';

interface OverviewDeskProps {
  publishedRates: { def: SyntheticRateDefinition; res: RateConstructionResult }[];
  onSelectRate: (defId: string) => void;
  onNavigate: (screen: string) => void;
  activeScenario: StressScenario;
  onSelectScenario: (scenarioId: string) => void;
  availableScenarios: StressScenario[];
}

export const OverviewDesk: React.FC<OverviewDeskProps> = ({
  publishedRates,
  onSelectRate,
  onNavigate,
  activeScenario,
  onSelectScenario,
  availableScenarios,
}) => {
  const avgSpreadBps = publishedRates.length
    ? Math.round(
        publishedRates.reduce((acc, r) => acc + r.res.benchmarkComparison.spreadBps, 0) /
          publishedRates.length
      )
    : 0;

  const avgQualityScore = publishedRates.length
    ? Math.round(
        publishedRates.reduce((acc, r) => acc + r.res.dataQualityIndex, 0) /
          publishedRates.length
      )
    : 0;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header & Scenario Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white font-sans">
            Synthetic Rate Master Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic multi-market synthetic interest rate benchmarks with complete convention harmonization.
          </p>
        </div>

        {/* Scenario Selector Ribbon */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 px-2 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            Macro Stress:
          </span>
          <div className="flex items-center gap-1">
            {availableScenarios.map((sc) => (
              <button
                key={sc.id}
                onClick={() => onSelectScenario(sc.id)}
                className={`px-2.5 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                  activeScenario.id === sc.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
                }`}
              >
                {sc.name.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Primary KPI Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Published Synthetics</span>
            <Database className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {publishedRates.length}
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Currencies: USD, EUR</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1">Multi-tenor term structure active</span>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Avg Spread vs Benchmark</span>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {avgSpreadBps >= 0 ? `+${avgSpreadBps}` : avgSpreadBps}
            </span>
            <span className="text-xs text-slate-300 font-mono">bps</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1">Reflecting bank credit & liquidity risk</span>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Data Quality Index</span>
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              {avgQualityScore}
              <span className="text-sm text-slate-500">/100</span>
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Institutional depth</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1">Tick-level wholesale & repo coverage</span>
        </div>

        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Validation Invariants</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              100%
            </span>
            <span className="text-[11px] text-emerald-400 font-mono">Verified</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1">0 HHI or residual threshold breaches</span>
        </div>
      </div>

      {/* Active Synthetic Rates Table */}
      <div className="rounded-lg bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold text-white font-sans">
              Active Synthetic Interest Rate Benchmarks
            </h2>
            <span className="text-[11px] text-slate-400 font-mono">
              ({publishedRates.length} configured methodologies)
            </span>
          </div>
          <button
            onClick={() => onNavigate('workbench')}
            className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-medium transition-colors cursor-pointer"
          >
            <span>Open Composition Desk</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-4 font-semibold">Synthetic Benchmark</th>
                <th className="py-2.5 px-3 font-semibold">Purpose</th>
                <th className="py-2.5 px-3 font-semibold text-center">Tenor</th>
                <th className="py-2.5 px-3 font-semibold text-right">Synthetic Rate</th>
                <th className="py-2.5 px-3 font-semibold text-right">Discount Factor</th>
                <th className="py-2.5 px-3 font-semibold text-right">Ref Benchmark</th>
                <th className="py-2.5 px-3 font-semibold text-right">Spread</th>
                <th className="py-2.5 px-3 font-semibold text-center">Method</th>
                <th className="py-2.5 px-4 font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {publishedRates.map(({ def, res }) => (
                <tr
                  key={def.id}
                  className="hover:bg-slate-800/40 transition-colors group"
                >
                  <td className="py-3 px-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white text-xs group-hover:text-cyan-300 transition-colors">
                          {def.name}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.2 rounded">
                          {def.version}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 truncate max-w-xs mt-0.5">
                        {def.governanceNotes}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="text-[11px] font-mono text-slate-300">
                      {def.purpose.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="font-mono text-xs font-semibold text-cyan-300">
                      {def.targetCurrency} {def.targetTenor}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span className="font-mono font-bold text-sm text-cyan-300 tabular-nums">
                      {res.outputRatePercent.toFixed(4)}%
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span className="font-mono text-xs text-slate-300 tabular-nums">
                      {res.outputDiscountFactor.toFixed(6)}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="flex flex-col items-end">
                      <span className="font-mono text-xs text-slate-300 tabular-nums">
                        {res.benchmarkComparison.benchmarkRatePercent.toFixed(2)}%
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {res.benchmarkComparison.benchmarkName}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span
                      className={`font-mono text-xs font-semibold tabular-nums ${
                        res.benchmarkComparison.spreadBps > 0
                          ? 'text-amber-400'
                          : 'text-cyan-400'
                      }`}
                    >
                      {res.benchmarkComparison.spreadBps > 0 ? '+' : ''}
                      {res.benchmarkComparison.spreadBps} bps
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {def.constructionMethod.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => {
                          onSelectRate(def.id);
                          onNavigate('workbench');
                        }}
                        className="px-2 py-1 text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded transition-colors cursor-pointer"
                        title="Configure in Workbench"
                      >
                        Workbench
                      </button>
                      <button
                        onClick={() => {
                          onSelectRate(def.id);
                          onNavigate('bridge');
                        }}
                        className="px-2 py-1 text-[11px] font-medium bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-300 border border-cyan-800/60 rounded transition-colors cursor-pointer"
                        title="Inspect Rate Bridge"
                      >
                        Bridge
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Explanatory Architecture Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
        <div className="p-4 rounded-lg bg-slate-900/70 border border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider font-mono">
            <span>01. Strict Convention Normalisation</span>
          </div>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Observations from different markets (ACT/360 vs ACT/365F, simple vs daily compounding) cannot be averaged naively. Every observation is transformed to preserve the exact period discount factor.
          </p>
        </div>

        <div className="p-4 rounded-lg bg-slate-900/70 border border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider font-mono">
            <span>02. Explicit Risk Decomposition</span>
          </div>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Isolates credit spreads, collateral haircut drag, liquidity depth premia, and FX cross-currency basis so that the economic meaning of the rate is documented without double-counting.
          </p>
        </div>

        <div className="p-4 rounded-lg bg-slate-900/70 border border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider font-mono">
            <span>03. Independent Governance Trail</span>
          </div>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Every rate construction run computes a deterministic SHA-256 execution hash, tests Herfindahl source concentration, and validates residual tracking bounds prior to publishing.
          </p>
        </div>
      </div>
    </div>
  );
};
