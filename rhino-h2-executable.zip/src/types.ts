export enum Role {
  PRODUCER = "PRODUCER",
  INDUSTRIAL_BUYER = "INDUSTRIAL_BUYER",
  TRADER = "TRADER",
  UTILITY = "UTILITY",
  STORAGE_OPERATOR = "STORAGE_OPERATOR",
  FUND = "FUND",
  BROKER = "BROKER",
  MARKET_ADMINISTRATOR = "MARKET_ADMINISTRATOR",
  RISK = "RISK"
}

export enum OrderType {
  LIMIT = "LIMIT",
  MARKET = "MARKET",
  IOC = "IOC",
  FOK = "FOK",
  GTC = "GTC",
  GTD = "GTD",
  ICEBERG = "ICEBERG"
}

export enum Side {
  BUY = "BUY",
  SELL = "SELL"
}

export enum OrderStatus {
  CREATED = "CREATED",
  VALIDATING = "VALIDATING",
  REJECTED = "REJECTED",
  ACCEPTED = "ACCEPTED",
  RESTING = "RESTING",
  PARTIALLY_FILLED = "PARTIALLY_FILLED",
  FILLED = "FILLED",
  CANCEL_PENDING = "CANCEL_PENDING",
  CANCELLED = "CANCELLED",
  EXPIRED = "EXPIRED"
}

export enum TradeStatus {
  EXECUTED = "EXECUTED",
  CONFIRMED = "CONFIRMED",
  CLEARED = "CLEARED",
  NOMINATED = "NOMINATED",
  DELIVERY_PENDING = "DELIVERY_PENDING",
  DELIVERED = "DELIVERED",
  SETTLED = "SETTLED",
  CLOSED = "CLOSED"
}

export enum CertificateState {
  ISSUED = "ISSUED",
  HELD = "HELD",
  ALLOCATED = "ALLOCATED",
  TRANSFERRED = "TRANSFERRED",
  RETIRED = "RETIRED"
}

export enum MarketSession {
  OPEN = "OPEN",
  HALTED = "HALTED",
  CLOSED = "CLOSED",
  AUCTION = "AUCTION"
}

export enum NominationStatus {
  REQUIRED = "REQUIRED",
  SUBMITTED = "SUBMITTED",
  ACCEPTED = "ACCEPTED",
  REJECTED = "REJECTED",
  AMENDED = "AMENDED"
}

export enum DeliveryStatus {
  NOMINATED = "NOMINATED",
  SCHEDULED = "SCHEDULED",
  IN_TRANSIT = "IN_TRANSIT",
  AT_HUB = "AT_HUB",
  MEASURED = "MEASURED",
  QUALITY_CHECKED = "QUALITY_CHECKED",
  ACCEPTED = "ACCEPTED",
  REJECTED = "REJECTED"
}

export enum MarginCallStatus {
  OPEN = "OPEN",
  PARTIALLY_MET = "PARTIALLY_MET",
  MET = "MET",
  DEFAULT = "DEFAULT"
}

export interface SpotHydrogenContract {
  contract_id: string;
  product_id: string;
  market_id: string;
  delivery_point: string;
  delivery_start: string; // ISO String
  delivery_end: string;   // ISO String
  quantity: number;       // in kg
  minimum_quantity: number;
  quality_specification: {
    purity: number;        // e.g. 99.99 (% purity)
    moisture: number;      // e.g. 5 (ppm)
    oxygen: number;        // e.g. 2 (ppm)
    pressure: number;      // e.g. 30 (bar)
    temperature: number;   // e.g. 15 (°C)
    carbon_intensity: number; // kg CO2e / kg H2
  };
  certification_requirement: string; // e.g. "GO_RENEWABLE" or "LOW_CARBON"
  pressure_requirement: number;      // bar
  price_unit: "EUR/kg" | "EUR/MWh";
  currency: "EUR";
  settlement_method: "PHYSICAL" | "FINANCIAL";
  delivery_tolerance: number; // percentage (e.g. 1.5%)
}

export interface Product {
  product_id: string;
  name: string;
  delivery_point: string;
  certification_type: "RENEWABLE" | "LOW_CARBON";
  energy_content_mwh_per_kg: number; // e.g. 0.03333 MWh / kg
}

export interface Participant {
  id: string;
  name: string;
  role: Role;
  trading_enabled: boolean;
  cash_balance: number; // in EUR cents (to avoid float errors)
  credit_limit: number; // in EUR cents
  collateral_balance: number; // in EUR cents
  initial_margin: number;     // in EUR cents
  variation_margin: number;   // in EUR cents
  max_order_quantity: number; // max kg per order
  max_notional: number;       // max EUR cents per order
  max_position: number;       // max net position kg
  max_delivery: number;       // max physical delivery obligation kg
}

export interface Order {
  order_id: string;
  client_order_id: string;
  participant_id: string;
  market_id: string;
  product_id: string;
  side: Side;
  order_type: OrderType;
  quantity: number;           // Original quantity (kg)
  visible_quantity?: number;  // For Iceberg orders
  total_iceberg_quantity?: number; // Total quantity for Iceberg
  price: number;              // Limit price (EUR/kg) - represented as number (e.g. 5.75)
  priceCents: number;         // Price in cents for exact math
  delivery_point: string;
  delivery_window: "DAY-AHEAD" | "NEXT-DAY" | "INTRADAY" | "WEEK-AHEAD";
  time_in_force: "GTC" | "IOC" | "FOK" | "GTD";
  expire_time?: string;
  status: OrderStatus;
  filled_quantity: number;    // Accumulated filled quantity (kg)
  cancelled_quantity: number;  // Accumulated cancelled quantity (kg)
  timestamp: string;          // ISO Date
  sequence_number: number;
}

export interface Execution {
  execution_id: string;
  trade_id: string;
  buy_order_id: string;
  sell_order_id: string;
  buyer_id: string;
  seller_id: string;
  product_id: string;
  quantity: number; // kg
  price: number;    // EUR/kg
  priceCents: number;
  currency: "EUR";
  delivery_point: string;
  delivery_window: string;
  timestamp: string;
  execution_sequence: number;
  fee: number; // EUR cents
  market_id: string;
}

export interface Trade {
  trade_id: string;
  timestamp: string;
  market_id: string;
  product_id: string;
  side: Side; // Side relative to the viewing participant or the aggressor
  buy_order_id: string;
  sell_order_id: string;
  buyer_id: string;
  seller_id: string;
  quantity: number; // kg
  price: number;    // EUR/kg
  notional: number; // EUR cents
  fees: number;     // EUR cents
  status: TradeStatus;
  delivery_point: string;
  delivery_window: string;
  nomination_id?: string;
  delivery_id?: string;
  certificate_id?: string;
  settlement_id?: string;
}

export interface Position {
  participant_id: string;
  product_id: string;
  delivery_window: string;
  long_qty: number;  // kg
  short_qty: number; // kg
  net_qty: number;   // kg (positive for long, negative for short)
  avg_price: number; // EUR/kg
  market_price: number; // EUR/kg
  unrealized_pnl: number; // EUR cents
  realized_pnl: number;   // EUR cents
  physical_status: string;
}

export interface Nomination {
  nomination_id: string;
  trade_id: string;
  participant_id: string;
  side: Side;
  quantity: number; // kg
  time: string; // ISO string
  location: string;
  quality_spec: {
    purity: number;
    moisture: number;
    pressure: number;
  };
  transport_route: string;
  storage_facility: string;
  status: NominationStatus;
}

export interface PhysicalDelivery {
  delivery_id: string;
  trade_id: string;
  shipper_id: string;
  receiver_id: string;
  quantity_contracted: number; // kg
  quantity_measured?: number;   // kg
  delivery_point: string;
  status: DeliveryStatus;
  purity_measured?: number;
  moisture_measured?: number;
  pressure_measured?: number;
  quality_check_passed?: boolean;
  tolerance_adjustment_cents?: number;
}

export interface Certificate {
  certificate_id: string;
  product_id: string;
  original_owner_id: string;
  current_owner_id: string;
  quantity: number; // kg equivalent
  certification_type: "RENEWABLE" | "LOW_CARBON";
  carbon_intensity: number; // kg CO2e/kg H2
  issuance_date: string;
  state: CertificateState;
}

export interface DoubleEntryLedgerRow {
  entry_id: string;
  timestamp: string;
  trade_id?: string;
  participant_id: string;
  account_name: "CASH_RECEIVABLE" | "CASH_PAYABLE" | "HYDROGEN_RECEIVABLE" | "HYDROGEN_DELIVERABLE" | "COLLATERAL" | "FEES_PAYABLE" | "CASH_BALANCE" | "INVENTORY";
  debit: number;  // in EUR cents / kg units
  credit: number; // in EUR cents / kg units
  description: string;
}

export interface MarginCall {
  id: string;
  participant_id: string;
  timestamp: string;
  exposure_cents: number;
  collateral_cents: number;
  margin_required_cents: number;
  call_amount_cents: number;
  status: MarginCallStatus;
}

export interface Ticker {
  market_id: string;
  product_id: string;
  last: number;
  bid: number;
  ask: number;
  mid: number;
  vwap: number;
  high: number;
  low: number;
  open: number;
  volume: number;
  number_of_trades: number;
  order_book_depth: {
    bids_sum: number;
    asks_sum: number;
  };
}

export interface MarketSurveillanceAlert {
  alert_id: string;
  timestamp: string;
  market_id: string;
  participant_id: string;
  type: "SELF_TRADING" | "WASH_TRADING" | "ABNORMAL_CANCELLATION" | "HIGH_ORDER_TO_TRADE" | "PRICE_MANIPULATION" | "UNUSUAL_VOLUME";
  severity: "INFO" | "WARNING" | "CRITICAL";
  description: string;
  details: string;
}

export interface AuditEvent {
  event_id: string;
  timestamp: string;
  operator_id: string;
  action: string;
  details: string;
}

export interface MarketReplayState {
  is_replaying: boolean;
  speed: 1 | 10 | 100 | 1000;
  current_timestamp: string;
  progress_percentage: number;
}
