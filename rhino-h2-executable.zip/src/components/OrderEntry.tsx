import React, { useState, useEffect } from "react";
import { Order, OrderType, Side, Participant, Product } from "../types";

interface OrderEntryProps {
  productId: string;
  products: Product[];
  participants: Participant[];
  onSubmitOrder: (orderData: any) => void;
  isSimulationActive: boolean;
  onToggleSimulation: (active: boolean) => void;
  onRunDemo: (demoId: number) => void;
}

export default function OrderEntry({
  productId,
  products,
  participants,
  onSubmitOrder,
  isSimulationActive,
  onToggleSimulation,
  onRunDemo
}: OrderEntryProps) {
  // Order ticket state
  const [selectedPartId, setSelectedPartId] = useState("");
  const [side, setSide] = useState<Side>(Side.BUY);
  const [orderType, setOrderType] = useState<OrderType>(OrderType.LIMIT);
  const [qty, setQty] = useState<number>(100000);
  const [price, setPrice] = useState<number>(5.75);
  const [visibleQty, setVisibleQty] = useState<number>(20000);
  const [deliveryWindow, setDeliveryWindow] = useState<"DAY-AHEAD" | "NEXT-DAY" | "INTRADAY" | "WEEK-AHEAD">("DAY-AHEAD");
  const [tif, setTif] = useState<"GTC" | "IOC" | "FOK" | "GTD">("GTC");

  // Confirmation view state
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Initialize selected participant
  useEffect(() => {
    if (participants.length > 0 && !selectedPartId) {
      setSelectedPartId(participants[0].id);
    }
  }, [participants, selectedPartId]);

  const currentProduct = products.find(p => p.product_id === productId);
  const currentPart = participants.find(p => p.id === selectedPartId);

  // Pre-trade estimations
  const calculatedNotional = qty * price;
  const estimatedFees = calculatedNotional * 0.0003; // 0.03%
  const marginRequired = currentPart?.role !== "PRODUCER" ? calculatedNotional * 0.10 : 0;
  const buyingPower = currentPart ? (currentPart.cash_balance + currentPart.credit_limit) / 100 : 0;

  const handlePreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfirmation(true);
  };

  const handleConfirmSubmit = () => {
    onSubmitOrder({
      participant_id: selectedPartId,
      market_id: productId,
      product_id: productId,
      side,
      order_type: orderType,
      quantity: qty,
      price: orderType === OrderType.MARKET ? 0 : price,
      delivery_point: currentProduct?.delivery_point || "NORTH SEA HUB",
      delivery_window: deliveryWindow,
      time_in_force: orderType === OrderType.MARKET || orderType === OrderType.IOC ? "IOC" : orderType === OrderType.FOK ? "FOK" : tif,
      visible_quantity: orderType === OrderType.ICEBERG ? visibleQty : undefined,
      total_iceberg_quantity: orderType === OrderType.ICEBERG ? qty : undefined
    });
    setShowConfirmation(false);
  };

  return (
    <div className="flex flex-col gap-4">
      {/* 1. ORDER TICKET */}
      <div id="order-entry-panel" className="bg-[#111111] border border-[#2b2b2b] p-4 flex flex-col relative min-h-[460px]">
        <div className="flex items-center justify-between mb-3 border-b border-[#1f1f1f] pb-1.5">
          <span className="text-[12px] uppercase font-semibold text-[#8a8a8a] tracking-wider">Institutional Trading Ticket</span>
          <span className="text-[9px] text-[#e3b341] font-mono uppercase bg-[#241f15] px-1.5 border border-[#3e3420]">
            H2 Spot
          </span>
        </div>

        {!showConfirmation ? (
          <form onSubmit={handlePreSubmit} className="flex flex-col gap-3 text-[11px] flex-1">
            {/* Participant selector */}
            <div className="flex flex-col gap-1">
              <label className="text-[#888] font-mono uppercase text-[9px]">Trading Participant Desk</label>
              <select
                value={selectedPartId}
                onChange={(e) => setSelectedPartId(e.target.value)}
                className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1.5 font-mono focus:outline-none focus:border-[#444] rounded-none w-full"
              >
                {participants.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name.substring(0, 24)} ({p.role})
                  </option>
                ))}
              </select>
            </div>

            {/* BUY / SELL Side Selector */}
            <div className="grid grid-cols-2 gap-2 mt-1">
              <button
                type="button"
                onClick={() => setSide(Side.BUY)}
                className={`py-2 text-[11px] uppercase font-mono font-semibold transition-all rounded-none border ${
                  side === Side.BUY
                    ? "bg-[#183421] text-[#2ebd59] border-[#2ebd59]"
                    : "bg-[#141414] text-[#888] border-[#222] hover:border-[#333]"
                }`}
              >
                BUY
              </button>
              <button
                type="button"
                onClick={() => setSide(Side.SELL)}
                className={`py-2 text-[11px] uppercase font-mono font-semibold transition-all rounded-none border ${
                  side === Side.SELL
                    ? "bg-[#381a1a] text-[#ff5f5f] border-[#ff5f5f]"
                    : "bg-[#141414] text-[#888] border-[#222] hover:border-[#333]"
                }`}
              >
                SELL
              </button>
            </div>

            {/* Order Type & Window */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col gap-1">
                <label className="text-[#888] font-mono uppercase text-[9px]">Order Type</label>
                <select
                  value={orderType}
                  onChange={(e) => setOrderType(e.target.value as OrderType)}
                  className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none rounded-none"
                >
                  <option value={OrderType.LIMIT}>LIMIT</option>
                  <option value={OrderType.MARKET}>MARKET</option>
                  <option value={OrderType.IOC}>IOC</option>
                  <option value={OrderType.FOK}>FOK</option>
                  <option value={OrderType.GTC}>GTC</option>
                  <option value={OrderType.ICEBERG}>ICEBERG</option>
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[#888] font-mono uppercase text-[9px]">Delivery Window</label>
                <select
                  value={deliveryWindow}
                  onChange={(e) => setDeliveryWindow(e.target.value as any)}
                  className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none rounded-none"
                >
                  <option value="DAY-AHEAD">DAY-AHEAD</option>
                  <option value="NEXT-DAY">NEXT-DAY</option>
                  <option value="INTRADAY">INTRADAY</option>
                  <option value="WEEK-AHEAD">WEEK-AHEAD</option>
                </select>
              </div>
            </div>

            {/* Quantity & Price */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col gap-1">
                <label className="text-[#888] font-mono uppercase text-[9px]">Quantity (kg)</label>
                <input
                  type="number"
                  value={qty}
                  min={1000}
                  step={1000}
                  onChange={(e) => setQty(Math.max(1000, Number(e.target.value)))}
                  className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none rounded-none"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[#888] font-mono uppercase text-[9px]">Price (EUR/kg)</label>
                <input
                  type="number"
                  value={price}
                  step={0.01}
                  disabled={orderType === OrderType.MARKET}
                  onChange={(e) => setPrice(Math.max(0.01, Number(e.target.value)))}
                  className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none rounded-none disabled:opacity-30"
                />
              </div>
            </div>

            {/* Iceberg display size */}
            {orderType === OrderType.ICEBERG && (
              <div className="flex flex-col gap-1">
                <label className="text-[#888] font-mono uppercase text-[9px]">Visible Size (kg)</label>
                <input
                  type="number"
                  value={visibleQty}
                  onChange={(e) => setVisibleQty(Math.min(qty, Number(e.target.value)))}
                  className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none rounded-none"
                />
              </div>
            )}

            {/* Financial Calculations panel */}
            <div className="bg-[#151515] p-3 border border-[#1f1f1f] flex flex-col gap-1.5 mt-1 text-[10px] font-mono">
              <div className="flex items-center justify-between">
                <span className="text-[#666]">NOTIONAL VALUE:</span>
                <span className="text-[#fff]">€{calculatedNotional.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#666]">ESTIMATED FEES:</span>
                <span className="text-[#fff]">€{estimatedFees.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#666]">INITIAL MARGIN:</span>
                <span className="text-[#fff]">
                  {marginRequired > 0 ? `€${marginRequired.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "N/A (PHYSICAL)"}
                </span>
              </div>
              <div className="flex items-center justify-between border-t border-[#252525] pt-1.5">
                <span className="text-[#888]">BUYING CAPACITY:</span>
                <span className="text-[#e3b341]">€{buyingPower.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            </div>

            <button
              type="submit"
              className={`w-full py-2.5 mt-auto text-[11px] font-mono font-bold tracking-wider rounded-none transition-all uppercase cursor-pointer ${
                side === Side.BUY
                  ? "bg-[#2ebd59] text-[#111] hover:bg-[#3ce56e]"
                  : "bg-[#ff5f5f] text-[#111] hover:bg-[#ff8c8c]"
              }`}
            >
              Submit Order Ticket
            </button>
          </form>
        ) : (
          /* PRE-TRADE CONFIRMATION LAYOUT */
          <div className="flex flex-col flex-1 text-[11px] font-mono gap-4 justify-between">
            <div className="bg-[#241c1c] border border-[#ff5f5f] border-dashed p-3 text-center text-[#ff8c8c]">
              <span className="font-bold text-[12px] block mb-1 uppercase">Pre-Trade Execution Confirmation</span>
              Confirm matching parameters before transmitting to the central limit order book.
            </div>

            <div className="flex flex-col gap-2.5 bg-[#151515] p-4 border border-[#222]">
              <div className="flex justify-between border-b border-[#252525] pb-1.5">
                <span className="text-[#888]">BUY / SELL</span>
                <span className={`font-bold ${side === Side.BUY ? "text-[#2ebd59]" : "text-[#ff5f5f]"}`}>{side}</span>
              </div>
              <div className="flex justify-between border-b border-[#252525] pb-1.5">
                <span className="text-[#888]">PRODUCT</span>
                <span className="text-[#fff] truncate w-[160px] text-right">{currentProduct?.name}</span>
              </div>
              <div className="flex justify-between border-b border-[#252525] pb-1.5">
                <span className="text-[#888]">QUANTITY</span>
                <span className="text-[#fff]">{qty.toLocaleString()} kg</span>
              </div>
              <div className="flex justify-between border-b border-[#252525] pb-1.5">
                <span className="text-[#888]">PRICE</span>
                <span className="text-[#fff]">{orderType === OrderType.MARKET ? "MARKET PRICE" : `${price.toFixed(2)} EUR/kg`}</span>
              </div>
              <div className="flex justify-between border-b border-[#252525] pb-1.5">
                <span className="text-[#888]">NOTIONAL</span>
                <span className="text-[#fff]">€{calculatedNotional.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between border-b border-[#252525] pb-1.5">
                <span className="text-[#888]">DELIVERY POINT</span>
                <span className="text-[#fff]">{currentProduct?.delivery_point}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888]">TOTAL FEES</span>
                <span className="text-[#fff]">€{estimatedFees.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-auto">
              <button
                onClick={() => setShowConfirmation(false)}
                className="py-2 bg-[#2b2b2b] text-[#aaa] hover:bg-[#3a3a3a] font-mono cursor-pointer"
              >
                Abort Ticket
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="py-2 bg-[#e3b341] text-[#111] hover:bg-[#ffd264] font-bold font-mono cursor-pointer"
              >
                Confirm Match
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 2. SIMULATION & MASTER DEMOS */}
      <div className="bg-[#111111] border border-[#2b2b2b] p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-[#1f1f1f] pb-1.5">
          <span className="text-[12px] uppercase font-semibold text-[#8a8a8a] tracking-wider">Simulation Controller</span>
          <button
            onClick={() => onToggleSimulation(!isSimulationActive)}
            className={`text-[10px] px-2 py-0.5 font-mono border cursor-pointer ${
              isSimulationActive 
                ? "bg-[#183421] text-[#2ebd59] border-[#2ebd59]" 
                : "bg-[#2b2b2b] text-[#aaa] border-[#444]"
            }`}
          >
            {isSimulationActive ? "SIMULATOR ACTIVE" : "SIMULATOR PAUSED"}
          </button>
        </div>

        <p className="text-[10px] text-[#777] leading-relaxed">
          Verify matching mechanics and clearing workflows using the 6 pre-programmed deterministic demonstration scenarios:
        </p>

        {/* Demo trigger buttons */}
        <div className="grid grid-cols-2 gap-1.5 mt-1">
          <button
            onClick={() => onRunDemo(1)}
            className="text-[9px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#ccc] py-1.5 hover:bg-[#252525] hover:border-[#444] font-mono text-left pl-2 cursor-pointer"
          >
            <span className="text-[#2ebd59] font-bold block">1. MASTER CROSS</span>
            Execute 500k & 300k trades
          </button>
          <button
            onClick={() => onRunDemo(2)}
            className="text-[9px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#ccc] py-1.5 hover:bg-[#252525] hover:border-[#444] font-mono text-left pl-2 cursor-pointer"
          >
            <span className="text-[#2ebd59] font-bold block">2. RESTING MATCH</span>
            Resting order pricing rule
          </button>
          <button
            onClick={() => onRunDemo(3)}
            className="text-[9px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#ccc] py-1.5 hover:bg-[#252525] hover:border-[#444] font-mono text-left pl-2 cursor-pointer"
          >
            <span className="text-[#2ebd59] font-bold block">3. MARKET ORDER</span>
            Eat depth & calculate VWAP
          </button>
          <button
            onClick={() => onRunDemo(4)}
            className="text-[9px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#ccc] py-1.5 hover:bg-[#252525] hover:border-[#444] font-mono text-left pl-2 cursor-pointer"
          >
            <span className="text-[#ff5f5f] font-bold block">4. FILL-OR-KILL</span>
            Total execution check
          </button>
          <button
            onClick={() => onRunDemo(5)}
            className="text-[9px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#ccc] py-1.5 hover:bg-[#252525] hover:border-[#444] font-mono text-left pl-2 cursor-pointer"
          >
            <span className="text-[#ff5f5f] font-bold block">5. IMMED-OR-CANCEL</span>
            Partial match & cancel
          </button>
          <button
            onClick={() => onRunDemo(6)}
            className="text-[9px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#ccc] py-1.5 hover:bg-[#252525] hover:border-[#444] font-mono text-left pl-2 cursor-pointer"
          >
            <span className="text-[#ff5f5f] font-bold block">6. PRODUCER OUTAGE</span>
            Collapse supply & alert
          </button>
        </div>
      </div>
    </div>
  );
}
