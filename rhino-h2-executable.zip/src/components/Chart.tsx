import React from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import { Trade } from "../types";

interface ChartProps {
  productId: string;
  trades: Trade[];
}

export default function Chart({ productId, trades }: ChartProps) {
  // Filter trades for this product, sort ascending by timestamp
  const chartData = trades
    .filter(t => t.product_id === productId)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map(t => ({
      time: new Date(t.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      price: t.price,
      quantity: t.quantity
    }));

  // Safe fallback if no trades exist
  const data = chartData.length > 0 ? chartData : [
    { time: "09:00:00", price: 5.75, quantity: 0 },
    { time: "10:00:00", price: 5.78, quantity: 0 },
    { time: "11:00:00", price: 5.72, quantity: 0 }
  ];

  const currentPrice = data[data.length - 1]?.price || 0;

  return (
    <div id="market-chart" className="flex flex-col bg-[#111111] border border-[#2b2b2b] rounded-none p-4 h-[340px]">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-[12px] uppercase font-semibold text-[#8a8a8a] tracking-wider">Spot Price Discoverability Curve</span>
          <span className="text-[10px] bg-[#1a2d21] text-[#2ebd59] px-1.5 py-0.5 font-mono border border-[#23442f]">T+0 Physical</span>
        </div>
        <div className="text-right">
          <span className="text-[18px] font-mono font-semibold text-[#f4f4f4]">{currentPrice.toFixed(2)}</span>
          <span className="text-[10px] text-[#8a8a8a] ml-1">EUR/kg</span>
        </div>
      </div>

      {/* Main Area Chart for Spot Price */}
      <div className="flex-1 min-h-0 w-full mb-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#2ebd59" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="#2ebd59" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#1c1c1c" vertical={false} />
            <XAxis 
              dataKey="time" 
              stroke="#555" 
              tick={{ fill: "#888", fontSize: 9, fontFamily: "monospace" }} 
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              domain={["auto", "auto"]} 
              stroke="#555" 
              tick={{ fill: "#888", fontSize: 9, fontFamily: "monospace" }} 
              axisLine={false}
              tickLine={false}
              orientation="right"
            />
            <Tooltip 
              contentStyle={{ backgroundColor: "#1a1a1a", borderColor: "#333", borderRadius: 0 }}
              labelStyle={{ color: "#aaa", fontSize: 10, fontFamily: "monospace" }}
              itemStyle={{ color: "#2ebd59", fontSize: 11, fontFamily: "monospace" }}
            />
            <Area 
              type="monotone" 
              dataKey="price" 
              stroke="#2ebd59" 
              strokeWidth={1.5}
              fillOpacity={1} 
              fill="url(#priceGrad)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Secondary Bar Chart for Daily Match Volumes */}
      <div className="h-[60px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 0, right: 5, left: -20, bottom: 5 }}>
            <XAxis dataKey="time" hide />
            <YAxis hide />
            <Tooltip 
              contentStyle={{ backgroundColor: "#1a1a1a", borderColor: "#333", borderRadius: 0 }}
              itemStyle={{ color: "#e3b341", fontSize: 11, fontFamily: "monospace" }}
            />
            <Bar dataKey="quantity" fill="#2b2b2b" maxBarSize={20} radius={0} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
