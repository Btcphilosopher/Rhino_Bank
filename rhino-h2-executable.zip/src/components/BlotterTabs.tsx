import React, { useState } from "react";
import {
  Order,
  Trade,
  Position,
  PhysicalDelivery,
  Nomination,
  Certificate,
  DoubleEntryLedgerRow,
  MarginCall,
  MarketSurveillanceAlert,
  AuditEvent,
  Side,
  OrderStatus,
  TradeStatus,
  DeliveryStatus,
  MarginCallStatus,
  MarketSession
} from "../types";
import { 
  FileText, 
  RefreshCw, 
  ShieldAlert, 
  Settings, 
  MapPin, 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle, 
  Cpu, 
  ArrowRight,
  Database,
  Briefcase
} from "lucide-react";

interface BlotterTabsProps {
  productId: string;
  orders: Order[];
  trades: Trade[];
  positions: Position[];
  deliveries: PhysicalDelivery[];
  nominations: Nomination[];
  certificates: Certificate[];
  ledgerEntries: DoubleEntryLedgerRow[];
  marginCalls: MarginCall[];
  alerts: MarketSurveillanceAlert[];
  auditEvents: AuditEvent[];
  participants: any[];
  onCancelOrder: (orderId: string) => void;
  onStepDelivery: (deliveryId: string, measured?: number, purity?: number) => void;
  onDepositCollateral: (participantId: string, amountCents: number) => void;
  onClearAlert: (alertId: string) => void;
  onUpdateSession: (marketId: string, session: string) => void;
  onUpdateExecutionRule: (marketId: string, rule: string) => void;
}

export default function BlotterTabs({
  productId,
  orders,
  trades,
  positions,
  deliveries,
  nominations,
  certificates,
  ledgerEntries,
  marginCalls,
  alerts,
  auditEvents,
  participants,
  onCancelOrder,
  onStepDelivery,
  onDepositCollateral,
  onClearAlert,
  onUpdateSession,
  onUpdateExecutionRule
}: BlotterTabsProps) {
  const [activeTab, setActiveTab] = useState<"orders" | "trades" | "positions" | "deliveries" | "risk" | "admin">("orders");
  const [selectedTradeId, setSelectedTradeId] = useState<string | null>(null);

  // Deposit collateral helper state
  const [depositAmt, setDepositAmt] = useState<string>("5000000"); // €50,000 cents
  const [depositPart, setDepositPart] = useState<string>("");

  // Filter orders and positions for active product view
  const myOrders = orders.filter(o => o.market_id === productId).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  const productTrades = trades.filter(t => t.product_id === productId).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Currently clicked trade details for Physical / Financial Life Cycle Linkage
  const activeTrade = trades.find(t => t.trade_id === selectedTradeId);
  const activeTradeDelivery = activeTrade ? deliveries.find(d => d.trade_id === activeTrade.trade_id) : null;
  const activeTradeNominations = activeTrade ? nominations.filter(n => n.trade_id === activeTrade.trade_id) : [];
  const activeTradeCerts = activeTrade ? certificates.filter(c => c.product_id === activeTrade.product_id && (c.current_owner_id === activeTrade.buyer_id || c.current_owner_id === activeTrade.seller_id)) : [];
  const activeTradeLedger = activeTrade ? ledgerEntries.filter(l => l.trade_id === activeTrade.trade_id) : [];

  return (
    <div id="bottom-terminal-blotter" className="bg-[#111111] border border-[#2b2b2b] flex flex-col h-[400px]">
      {/* Blotter Tab Selectors */}
      <div className="flex border-b border-[#2b2b2b] bg-[#161616] text-[11px] font-mono select-none">
        {(["orders", "trades", "positions", "deliveries", "risk", "admin"] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2.5 uppercase font-semibold transition-all border-r border-[#2b2b2b] cursor-pointer ${
              activeTab === tab
                ? "bg-[#111111] text-[#e3b341] border-b-2 border-b-[#e3b341]"
                : "text-[#888] hover:bg-[#1a1a1a] hover:text-[#bbb]"
            }`}
          >
            {tab === "risk" ? "Risk & Collateral" : tab === "admin" ? "Market Administration" : tab}
            {tab === "risk" && alerts.length > 0 && (
              <span className="ml-1.5 px-1 py-0.2 bg-[#3a1a1a] text-[#ff5f5f] border border-[#ff5f5f] text-[9px] font-bold">
                {alerts.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab Panels */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4 text-[11px] font-mono">
        
        {/* TAB 1: ORDERS */}
        {activeTab === "orders" && (
          <div className="flex flex-col gap-3">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[#8a8a8a] uppercase font-semibold">Active Rested & Closed Orders</span>
              <span className="text-[10px] text-[#555]">Sorted: Newest Received First</span>
            </div>
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2b2b2b] text-[#555] text-[10px] uppercase">
                  <th className="pb-1.5 pl-1">Order ID</th>
                  <th className="pb-1.5">Participant</th>
                  <th className="pb-1.5">Side</th>
                  <th className="pb-1.5">Type</th>
                  <th className="pb-1.5 text-right">Qty (kg)</th>
                  <th className="pb-1.5 text-right">Price</th>
                  <th className="pb-1.5 text-right">Filled %</th>
                  <th className="pb-1.5">Status</th>
                  <th className="pb-1.5 pr-1 text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {myOrders.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="text-center py-6 text-[#555] italic">No active or resting orders logged for this market</td>
                  </tr>
                ) : (
                  myOrders.slice(0, 30).map((ord, idx) => {
                    const fillPct = ord.quantity > 0 ? (ord.filled_quantity / ord.quantity) * 100 : 0;
                    const canCancel = ord.status === OrderStatus.RESTING || ord.status === OrderStatus.PARTIALLY_FILLED;
                    
                    return (
                      <tr key={`ord-${idx}`} className="border-b border-[#181818] hover:bg-[#151515] items-center">
                        <td className="py-2 pl-1 font-semibold text-[#8a8a8a]">{ord.order_id}</td>
                        <td className="py-2 text-[#aaa] truncate max-w-[120px]">{ord.participant_id}</td>
                        <td className={`py-2 font-bold ${ord.side === Side.BUY ? "text-[#2ebd59]" : "text-[#ff5f5f]"}`}>
                          {ord.side}
                        </td>
                        <td className="py-2 text-[#aaa]">{ord.order_type}</td>
                        <td className="py-2 text-right text-[#fff]">{ord.quantity.toLocaleString()}</td>
                        <td className="py-2 text-right text-[#fff]">
                          {ord.order_type === "MARKET" ? "MARKET" : ord.price.toFixed(2)}
                        </td>
                        <td className="py-2 text-right">
                          <span className="text-[#e3b341] font-bold">{Math.round(fillPct)}%</span>
                        </td>
                        <td className="py-2">
                          <span className={`px-1 py-0.2 text-[9px] font-bold border ${
                            ord.status === OrderStatus.FILLED ? "bg-[#183421] text-[#2ebd59] border-[#2ebd59]" :
                            ord.status === OrderStatus.RESTING ? "bg-[#252010] text-[#e3b341] border-[#e3b341]" :
                            ord.status === OrderStatus.CANCELLED ? "bg-[#2b2b2b] text-[#888] border-[#444]" :
                            ord.status === OrderStatus.REJECTED ? "bg-[#3a1a1a] text-[#ff5f5f] border-[#ff5f5f]" :
                            "bg-[#252525] text-[#ccc] border-[#333]"
                          }`}>
                            {ord.status}
                          </span>
                        </td>
                        <td className="py-2 text-right pr-1">
                          {canCancel ? (
                            <button
                              onClick={() => onCancelOrder(ord.order_id)}
                              className="px-2 py-0.5 border border-[#ff5f5f] text-[#ff5f5f] bg-[#221010] hover:bg-[#ff5f5f] hover:text-[#111] text-[9px] font-mono uppercase font-bold cursor-pointer"
                            >
                              Cancel
                            </button>
                          ) : (
                            <span className="text-[#444] text-[9px]">-</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 2: TRADES & PHYSICAL FINANCIAL LIFECYCLE LINK */}
        {activeTab === "trades" && (
          <div className="grid grid-cols-5 gap-4">
            {/* Left Col: Trades Blotter */}
            <div className="col-span-2 flex flex-col gap-3 border-r border-[#2b2b2b] pr-4 h-[330px] overflow-y-auto">
              <span className="text-[#8a8a8a] uppercase font-semibold">Trade Ledger</span>
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#2b2b2b] text-[#555] text-[10px] uppercase">
                    <th className="pb-1">Trade ID</th>
                    <th className="pb-1 text-right">Price</th>
                    <th className="pb-1 text-right">Qty</th>
                    <th className="pb-1">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {productTrades.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center py-6 text-[#555] italic">No transaction records logged</td>
                    </tr>
                  ) : (
                    productTrades.slice(0, 30).map((t, idx) => {
                      const isSelected = selectedTradeId === t.trade_id;
                      return (
                        <tr
                          key={`trade-${idx}`}
                          onClick={() => setSelectedTradeId(t.trade_id)}
                          className={`border-b border-[#181818] cursor-pointer transition-all ${
                            isSelected ? "bg-[#252010] border-l-2 border-l-[#e3b341] pl-2" : "hover:bg-[#151515]"
                          }`}
                        >
                          <td className="py-2 pl-1 font-semibold text-[#aaa]">{t.trade_id}</td>
                          <td className="py-2 text-right font-mono font-bold text-[#fff]">{t.price.toFixed(2)}</td>
                          <td className="py-2 text-right text-[#aaa]">{t.quantity.toLocaleString()}</td>
                          <td className="py-2 pr-1">
                            <span className={`px-1 py-0.2 text-[8px] font-bold border uppercase ${
                              t.status === TradeStatus.SETTLED ? "border-[#2ebd59] text-[#2ebd59]" : "border-[#e3b341] text-[#e3b341]"
                            }`}>
                              {t.status}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Right Col: Interactive Traceability Graph */}
            <div className="col-span-3 flex flex-col gap-2 bg-[#0c0c0c] border border-[#222] p-4 rounded-none h-[330px] overflow-y-auto">
              {activeTrade ? (
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between border-b border-[#222] pb-1.5 items-center">
                    <span className="text-[#e3b341] uppercase font-bold text-[12px] tracking-wide">
                      H2-X Physical-Financial Lifecycle Traceability
                    </span>
                    <span className="text-[9px] text-[#888] font-mono">ID: {activeTrade.trade_id}</span>
                  </div>

                  {/* Horizontal visual pipeline diagram */}
                  <div className="flex items-center gap-1 overflow-x-auto py-2 border-b border-[#1c1c1c]">
                    {[
                      { label: "Order", state: "FILLED", active: true },
                      { label: "Execution", state: "MATCHED", active: true },
                      { label: "Trade", state: activeTrade.status, active: true },
                      { label: "Clearing", state: "MARGIN_OK", active: true },
                      { label: "Delivery", state: activeTradeDelivery?.status || "NOMINATED", active: !!activeTradeDelivery },
                      { label: "Settle", state: activeTrade.status === "SETTLED" ? "PAID" : "PENDING", active: activeTrade.status === "SETTLED" }
                    ].map((step, idx, arr) => (
                      <React.Fragment key={`step-${idx}`}>
                        <div className="flex flex-col items-center min-w-[70px] bg-[#141414] border border-[#2b2b2b] p-1.5">
                          <span className="text-[8px] uppercase text-[#666] tracking-wider">{step.label}</span>
                          <span className={`text-[9px] font-bold truncate mt-0.5 ${step.active ? "text-[#2ebd59]" : "text-[#e3b341]"}`}>
                            {step.state}
                          </span>
                        </div>
                        {idx < arr.length - 1 && <ArrowRight size={10} className="text-[#444] shrink-0" />}
                      </React.Fragment>
                    ))}
                  </div>

                  {/* Flow Traceability details mapping */}
                  <div className="grid grid-cols-2 gap-3 text-[10px]">
                    {/* Buyer side accounting ledger DR/CR */}
                    <div className="border border-[#222] p-2 bg-[#121212] flex flex-col gap-1.5">
                      <span className="text-[#2ebd59] uppercase font-bold text-[9px] border-b border-[#1c1c1c] pb-0.5">
                        Double-Entry Ledger Postings
                      </span>
                      {activeTradeLedger.map((row, i) => (
                        <div key={i} className="flex flex-col border-b border-[#181818] pb-1 last:border-0 font-mono">
                          <span className="text-[#888]">{row.account_name}</span>
                          <div className="flex justify-between">
                            <span>DEBIT: {row.debit > 0 ? (row.debit >= 1000 ? row.debit.toLocaleString() : `€${(row.debit / 100).toFixed(2)}`) : "-"}</span>
                            <span>CREDIT: {row.credit > 0 ? (row.credit >= 1000 ? row.credit.toLocaleString() : `€${(row.credit / 100).toFixed(2)}`) : "-"}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Physical Operational Delivery Details */}
                    <div className="border border-[#222] p-2 bg-[#121212] flex flex-col gap-1.5">
                      <span className="text-[#e3b341] uppercase font-bold text-[9px] border-b border-[#1c1c1c] pb-0.5">
                        Physical Delivery Obligations
                      </span>
                      <div className="flex justify-between">
                        <span className="text-[#888]">Hub Point:</span>
                        <span>{activeTrade.delivery_point}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#888]">Window:</span>
                        <span>{activeTrade.delivery_window}</span>
                      </div>
                      {activeTradeDelivery ? (
                        <>
                          <div className="flex justify-between">
                            <span className="text-[#888]">Delivery Status:</span>
                            <span className="font-bold text-[#e3b341]">{activeTradeDelivery.status}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#888]">Variance Measured:</span>
                            <span>
                              {activeTradeDelivery.quantity_measured 
                                ? `${activeTradeDelivery.quantity_measured.toLocaleString()} kg (Δ ${(activeTradeDelivery.quantity_measured - activeTradeDelivery.quantity_contracted).toLocaleString()})`
                                : "Awaiting Metering"
                              }
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#888]">Purity Spec:</span>
                            <span>{activeTradeDelivery.purity_measured ? `${activeTradeDelivery.purity_measured}%` : "Awaiting QA"}</span>
                          </div>
                        </>
                      ) : (
                        <div className="text-[#555] italic text-center py-2">No delivery scheduled</div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center flex-1 text-[#444] italic gap-2 text-center py-12">
                  <Database size={24} className="text-[#2b2b2b]" />
                  <span>Select a trade from the blotter ledger to analyze its complete financial and physical lifecycle link traceability.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: POSITIONS & BALANCES */}
        {activeTab === "positions" && (
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <span className="text-[#8a8a8a] uppercase font-semibold">Institutional Portfolio Positions & Asset Balances</span>
              <span className="text-[10px] text-[#555]">Real-time Mark-to-Market revaluations</span>
            </div>
            
            <div className="grid grid-cols-4 gap-4 mb-2">
              {participants.slice(0, 4).map((part, i) => (
                <div key={i} className="bg-[#141414] border border-[#2b2b2b] p-3 flex flex-col gap-1.5 font-mono">
                  <span className="text-[10px] text-[#e3b341] font-bold truncate uppercase">{part.name}</span>
                  <div className="flex justify-between text-[11px] text-[#888] border-b border-[#222] pb-1">
                    <span>Cash Liquidity:</span>
                    <span className="text-[#fff] font-bold">€{(part.cash_balance / 100).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#888]">
                    <span>Collateral:</span>
                    <span className="text-[#2ebd59] font-bold">€{(part.collateral_balance / 100).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              ))}
            </div>

            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2b2b2b] text-[#555] text-[10px] uppercase">
                  <th className="pb-1.5 pl-1">Participant</th>
                  <th className="pb-1.5">Product ID</th>
                  <th className="pb-1.5 text-right">Long Qty (kg)</th>
                  <th className="pb-1.5 text-right">Short Qty (kg)</th>
                  <th className="pb-1.5 text-right">Net Position</th>
                  <th className="pb-1.5 text-right">Avg Price (EUR/kg)</th>
                  <th className="pb-1.5 text-right">Unrealized P&L</th>
                </tr>
              </thead>
              <tbody>
                {positions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-6 text-[#555] italic">No active portfolio positions held yet</td>
                  </tr>
                ) : (
                  positions.slice(0, 30).map((pos, idx) => {
                    const isLong = pos.net_qty > 0;
                    return (
                      <tr key={`pos-${idx}`} className="border-b border-[#181818] hover:bg-[#151515]">
                        <td className="py-2 pl-1 font-semibold text-[#aaa]">{pos.participant_id}</td>
                        <td className="py-2 text-[#aaa]">{pos.product_id}</td>
                        <td className="py-2 text-right text-[#aaa]">{pos.long_qty.toLocaleString()}</td>
                        <td className="py-2 text-right text-[#aaa]">{pos.short_qty.toLocaleString()}</td>
                        <td className={`py-2 text-right font-bold ${isLong ? "text-[#2ebd59]" : pos.net_qty < 0 ? "text-[#ff5f5f]" : "text-[#aaa]"}`}>
                          {pos.net_qty.toLocaleString()} kg
                        </td>
                        <td className="py-2 text-right text-[#fff]">{pos.avg_price.toFixed(4)}</td>
                        <td className={`py-2 text-right font-bold ${pos.unrealized_pnl >= 0 ? "text-[#2ebd59]" : "text-[#ff5f5f]"}`}>
                          €{(pos.unrealized_pnl / 100).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 4: PHYSICAL DELIVERIES */}
        {activeTab === "deliveries" && (
          <div className="flex flex-col gap-3">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[#8a8a8a] uppercase font-semibold">Physical Delivery Pipeline</span>
              <span className="text-[10px] text-[#e3b341]">Click operational buttons to advance steps dynamically</span>
            </div>
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2b2b2b] text-[#555] text-[10px] uppercase">
                  <th className="pb-1.5 pl-1">Delivery ID</th>
                  <th className="pb-1.5">Trade Link</th>
                  <th className="pb-1.5">Seller (Shipper)</th>
                  <th className="pb-1.5">Buyer (Receiver)</th>
                  <th className="pb-1.5 text-right">Contracted Qty</th>
                  <th className="pb-1.5 text-right">Measured Qty</th>
                  <th className="pb-1.5 text-center">Quality Checks</th>
                  <th className="pb-1.5">Pipeline Status</th>
                  <th className="pb-1.5 pr-1 text-right">Advance Operations</th>
                </tr>
              </thead>
              <tbody>
                {deliveries.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="text-center py-6 text-[#555] italic">No physical deliveries generated yet</td>
                  </tr>
                ) : (
                  deliveries.slice(0, 30).map((del, idx) => {
                    const isSettled = del.status === DeliveryStatus.ACCEPTED || del.status === DeliveryStatus.REJECTED;
                    
                    return (
                      <tr key={`del-${idx}`} className="border-b border-[#181818] hover:bg-[#151515] items-center">
                        <td className="py-2.5 pl-1 font-semibold text-[#aaa]">{del.delivery_id}</td>
                        <td className="py-2.5 text-[#e3b341]">{del.trade_id}</td>
                        <td className="py-2.5 text-[#aaa] truncate max-w-[100px]">{del.shipper_id}</td>
                        <td className="py-2.5 text-[#aaa] truncate max-w-[100px]">{del.receiver_id}</td>
                        <td className="py-2.5 text-right text-[#fff]">{del.quantity_contracted.toLocaleString()} kg</td>
                        <td className="py-2.5 text-right font-bold text-[#fff]">
                          {del.quantity_measured ? `${del.quantity_measured.toLocaleString()} kg` : "-"}
                        </td>
                        <td className="py-2.5 text-center">
                          {del.purity_measured ? (
                            <div className="flex flex-col text-[10px]">
                              <span className={del.quality_check_passed ? "text-[#2ebd59] font-bold" : "text-[#ff5f5f] font-bold"}>
                                Purity: {del.purity_measured}%
                              </span>
                              <span className="text-[#888] text-[8px]">Moist: {del.moisture_measured?.toFixed(1)} ppm</span>
                            </div>
                          ) : (
                            <span className="text-[#555] italic">Pending QA</span>
                          )}
                        </td>
                        <td className="py-2.5">
                          <span className={`px-1.5 py-0.5 text-[9px] font-bold border uppercase ${
                            del.status === DeliveryStatus.NOMINATED ? "bg-[#1d1d1d] text-[#888] border-[#333]" :
                            del.status === DeliveryStatus.ACCEPTED ? "bg-[#183421] text-[#2ebd59] border-[#2ebd59]" :
                            del.status === DeliveryStatus.MEASURED ? "bg-[#252010] text-[#e3b341] border-[#e3b341]" :
                            "bg-[#241f10] text-[#e3b341] border-[#c09734]"
                          }`}>
                            {del.status}
                          </span>
                        </td>
                        <td className="py-2.5 text-right pr-1">
                          {!isSettled ? (
                            <button
                              onClick={() => onStepDelivery(del.delivery_id)}
                              className="px-2.5 py-1 bg-[#1a2d21] border border-[#23442f] text-[#2ebd59] hover:bg-[#2ebd59] hover:text-[#111] font-mono text-[9px] uppercase font-bold cursor-pointer"
                            >
                              {del.status === DeliveryStatus.NOMINATED ? "Schedule Flow" :
                               del.status === DeliveryStatus.SCHEDULED ? "Dispatch" :
                               del.status === DeliveryStatus.IN_TRANSIT ? "Measure Flow" :
                               del.status === DeliveryStatus.AT_HUB ? "Run Metering" :
                               del.status === DeliveryStatus.MEASURED ? "QA checks" :
                               del.status === DeliveryStatus.QUALITY_CHECKED ? "Accept Flow" :
                               "Settle Cash"}
                            </button>
                          ) : (
                            <div className="text-[#2ebd59] font-bold text-[10px] flex items-center justify-end gap-1">
                              <CheckCircle size={10} /> Complete
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 5: RISK, COLLATERAL, SURVEILLANCE */}
        {activeTab === "risk" && (
          <div className="grid grid-cols-2 gap-4">
            {/* Left side: Margin details & deposit collateral */}
            <div className="flex flex-col gap-3 border-r border-[#2b2b2b] pr-4 h-[330px] overflow-y-auto">
              <span className="text-[#8a8a8a] uppercase font-semibold">Clearing, Margins & Exposure Accounts</span>
              
              <div className="flex gap-2 mb-2">
                <div className="flex-1 flex flex-col gap-1">
                  <label className="text-[#666] uppercase text-[9px]">Select Participant</label>
                  <select
                    value={depositPart}
                    onChange={(e) => setDepositPart(e.target.value)}
                    className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none"
                  >
                    <option value="">-- Choose Account --</option>
                    {participants.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>
                <div className="w-[100px] flex flex-col gap-1">
                  <label className="text-[#666] uppercase text-[9px]">Amt (Cents)</label>
                  <input
                    type="number"
                    value={depositAmt}
                    onChange={(e) => setDepositAmt(e.target.value)}
                    className="bg-[#161616] text-[#e8e8e8] border border-[#2b2b2b] px-2 py-1 font-mono focus:outline-none"
                  />
                </div>
                <button
                  onClick={() => {
                    if (depositPart) {
                      onDepositCollateral(depositPart, Number(depositAmt));
                    }
                  }}
                  className="px-3.5 mt-auto bg-[#e3b341] text-[#111] hover:bg-[#ffd264] font-bold text-[10px] uppercase font-mono py-1.5 cursor-pointer"
                >
                  Post Collateral
                </button>
              </div>

              {/* Active margin calls */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[#888] font-bold text-[10px] uppercase">Active Margin Demands</span>
                {marginCalls.length === 0 ? (
                  <div className="text-[#444] italic">No active collateral margin defaults</div>
                ) : (
                  marginCalls.map((call, i) => {
                    const p = participants.find(part => part.id === call.participant_id);
                    return (
                      <div key={i} className="bg-[#241a1a] border border-[#ff5f5f] p-2 flex justify-between items-center">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-bold text-[#fff] text-[10px]">{p?.name || call.participant_id}</span>
                          <span className="text-[#ff8c8c] text-[9px]">Exposure: €{(call.exposure_cents / 100).toLocaleString()} | Call: €{(call.call_amount_cents / 100).toLocaleString()}</span>
                        </div>
                        <span className={`px-1.5 py-0.5 text-[8px] font-bold border uppercase ${
                          call.status === MarginCallStatus.MET ? "border-[#2ebd59] text-[#2ebd59]" : "border-[#ff5f5f] text-[#ff5f5f]"
                        }`}>
                          {call.status}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Right side: Surveillance alarms log */}
            <div className="flex flex-col gap-3 h-[330px] overflow-y-auto">
              <span className="text-[#8a8a8a] uppercase font-semibold flex items-center gap-1.5 text-[#ff5f5f]">
                <ShieldAlert size={12} /> Live Market Surveillance Surveillance Feed
              </span>

              {alerts.length === 0 ? (
                <div className="flex flex-col items-center justify-center flex-1 text-[#444] py-8 italic border border-dashed border-[#222]">
                  <CheckCircle size={16} className="text-[#2b2b2b] mb-1" />
                  <span>No price manipulations or self-trading alerts raised</span>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {alerts.map((alert, idx) => (
                    <div key={idx} className="bg-[#1a1111] border border-[#3a1a1a] p-2.5 flex justify-between items-start">
                      <div className="flex flex-col gap-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[#ff5f5f] font-bold text-[10px] uppercase tracking-wider">{alert.type}</span>
                          <span className="bg-[#ff5f5f] text-[#111] font-bold text-[8px] px-1">{alert.severity}</span>
                          <span className="text-[#555] text-[9px]">{new Date(alert.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <p className="text-[#ccc] text-[10px]">{alert.description}</p>
                        <p className="text-[#888] text-[9px] leading-tight">{alert.details}</p>
                      </div>
                      <button
                        onClick={() => onClearAlert(alert.alert_id)}
                        className="px-1.5 py-0.5 border border-[#444] text-[#888] hover:border-[#aaa] hover:text-[#fff] text-[8px] uppercase cursor-pointer"
                      >
                        Dismiss
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 6: MARKET ADMINISTRATOR PANEL */}
        {activeTab === "admin" && (
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-3 border-r border-[#2b2b2b] pr-4 h-[330px] overflow-y-auto">
              <span className="text-[#8a8a8a] uppercase font-semibold flex items-center gap-1">
                <Settings size={12} /> Administrative Market Controls
              </span>

              <div className="bg-[#141414] border border-[#2b2b2b] p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[#aaa]">H2 Spot Market Status:</span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => onUpdateSession(productId, MarketSession.OPEN)}
                      className="px-2 py-1 bg-[#1a2d21] text-[#2ebd59] border border-[#23442f] text-[9px] font-bold uppercase cursor-pointer"
                    >
                      Open Market
                    </button>
                    <button
                      onClick={() => onUpdateSession(productId, MarketSession.HALTED)}
                      className="px-2 py-1 bg-[#3a1a1a] text-[#ff5f5f] border border-[#5a1a1a] text-[9px] font-bold uppercase cursor-pointer"
                    >
                      Halt Market
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-[#1f1f1f] pt-2.5">
                  <span className="text-[#aaa]">Matching Engine Price Rule:</span>
                  <select
                    onChange={(e) => onUpdateExecutionRule(productId, e.target.value)}
                    className="bg-[#161616] text-[#fff] border border-[#2b2b2b] px-2 py-0.5 font-mono focus:outline-none text-[10px]"
                  >
                    <option value="RESTING">RESTING ORDER PRICE</option>
                    <option value="AGGRESSOR">AGGRESSOR PRICE</option>
                    <option value="MIDPOINT">MIDPOINT</option>
                  </select>
                </div>
              </div>

              {/* Tickers list */}
              <div className="flex flex-col gap-1.5 mt-2">
                <span className="text-[#888] font-bold uppercase text-[9px]">Hub Products Registry</span>
                <div className="flex flex-col gap-1 bg-[#141414] p-2 border border-[#2b2b2b] font-mono text-[9px]">
                  <div className="flex justify-between border-b border-[#222] pb-1 font-bold">
                    <span>Product</span>
                    <span>Point</span>
                    <span>Spec Cert</span>
                  </div>
                  <div className="flex justify-between text-[#888]">
                    <span>RHINO-H2-NS-REN</span>
                    <span>NORTH SEA HUB</span>
                    <span>RENEWABLE (99.99%)</span>
                  </div>
                  <div className="flex justify-between text-[#888]">
                    <span>RHINO-H2-NS-LC</span>
                    <span>NORTH SEA HUB</span>
                    <span>LOW CARBON (99.95%)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Administrative audit logs */}
            <div className="flex flex-col gap-2 h-[330px] overflow-y-auto">
              <span className="text-[#8a8a8a] uppercase font-semibold">Administrative Audit Log</span>
              <div className="flex flex-col gap-1.5">
                {auditEvents.slice(0, 30).map((evt, idx) => (
                  <div key={idx} className="bg-[#141414] border border-[#222] p-2 font-mono text-[9px]">
                    <div className="flex justify-between font-bold border-b border-[#1f1f1f] pb-0.5 text-[#e3b341]">
                      <span>{evt.action}</span>
                      <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-[#888] mt-1 flex justify-between">
                      <span>Operator: {evt.operator_id}</span>
                      <span>ID: {evt.event_id}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
