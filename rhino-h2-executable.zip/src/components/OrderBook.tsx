import React from "react";
import { Order, Side } from "../types";

interface OrderBookProps {
  productId: string;
  orders: Order[];
  tickerLast?: number;
  tickerBid?: number;
  tickerAsk?: number;
}

export default function OrderBook({ productId, orders, tickerLast, tickerBid, tickerAsk }: OrderBookProps) {
  // Filter and aggregate active orders
  const activeOrders = orders.filter(
    o => o.product_id === productId && (o.status === "RESTING" || o.status === "PARTIALLY_FILLED")
  );

  // Separate bids & asks
  const bids = activeOrders.filter(o => o.side === Side.BUY);
  const asks = activeOrders.filter(o => o.side === Side.SELL);

  // Group by price, aggregate sizes
  const bidMap: { [price: number]: number } = {};
  bids.forEach(b => {
    bidMap[b.price] = (bidMap[b.price] || 0) + (b.quantity - b.filled_quantity);
  });

  const askMap: { [price: number]: number } = {};
  asks.forEach(a => {
    askMap[a.price] = (askMap[a.price] || 0) + (a.quantity - a.filled_quantity);
  });

  // Sort prices
  const sortedBidPrices = Object.keys(bidMap)
    .map(Number)
    .sort((a, b) => b - a); // highest bids first

  const sortedAskPrices = Object.keys(askMap)
    .map(Number)
    .sort((a, b) => b - a); // highest asks first (sorted descending to display top-down)

  // Mid and Spread calculations
  const bestBid = sortedBidPrices[0] || 0;
  // Lowest asks are at the end of descending list
  const sortedAsksAsc = [...sortedAskPrices].sort((a, b) => a - b);
  const bestAsk = sortedAsksAsc[0] || 0;
  const spread = bestBid && bestAsk ? Math.round((bestAsk - bestBid) * 100) / 100 : 0;
  const mid = bestBid && bestAsk ? Math.round(((bestBid + bestAsk) / 2) * 100) / 100 : (tickerLast || 5.75);

  // Accumulate depth values for visual background bars
  let bidCumulative = 0;
  const bidRows = sortedBidPrices.slice(0, 8).map(price => {
    const size = bidMap[price];
    bidCumulative += size;
    return { price, size, cumulative: bidCumulative };
  });

  let askCumulative = 0;
  // For Asks, we want the lowest asks closest to mid, but listed ascending
  const askRows = sortedAsksAsc.slice(0, 8).map(price => {
    const size = askMap[price];
    askCumulative += size;
    return { price, size, cumulative: askCumulative };
  }).reverse(); // Reverse so higher prices are at the top and lowest ask sits right above bid section

  const maxCumulative = Math.max(bidCumulative, askCumulative) || 1;

  return (
    <div id="central-order-book" className="flex flex-col bg-[#111111] border border-[#2b2b2b] rounded-none p-4 h-[350px]">
      <div className="flex items-center justify-between mb-3 border-b border-[#1f1f1f] pb-1.5">
        <span className="text-[12px] uppercase font-semibold text-[#8a8a8a] tracking-wider">Central Limit Order Book</span>
        <span className="text-[10px] text-[#8a8a8a] font-mono">Price-Time Priority</span>
      </div>

      {/* Column Headers */}
      <div className="grid grid-cols-4 text-[10px] text-[#555] font-mono uppercase tracking-wider mb-1 px-1 text-center">
        <span className="text-left">Bid Size</span>
        <span className="text-right">Price</span>
        <span className="text-right">Price</span>
        <span className="text-right">Ask Size</span>
      </div>

      {/* Scrolling Book Ladder */}
      <div className="flex-1 min-h-0 overflow-y-auto font-mono text-[11px] select-none text-center">
        {/* Ask Rows (Sellers) */}
        {askRows.length === 0 ? (
          <div className="text-center py-2 text-[#444] italic border-b border-dashed border-[#1f1f1f]">No active offers</div>
        ) : (
          askRows.map((row, idx) => {
            const widthPct = Math.min(100, (row.cumulative / maxCumulative) * 100);
            return (
              <div 
                key={`ask-${idx}`} 
                className="grid grid-cols-4 py-1 border-b border-[#151515] hover:bg-[#1a1616] relative items-center"
              >
                {/* Visual Depth bar */}
                <div 
                  className="absolute right-0 top-0 bottom-0 bg-[#3a1a1a] opacity-15"
                  style={{ width: `${widthPct}%` }}
                />
                
                <span className="text-[#444] text-left z-10">-</span>
                <span className="text-[#444] text-right z-10">-</span>
                <span className="text-[#ff5f5f] text-right font-semibold z-10">{row.price.toFixed(2)}</span>
                <span className="text-[#f4f4f4] text-right font-medium z-10 pr-1">{row.size.toLocaleString()}</span>
              </div>
            );
          })
        )}

        {/* Spread / Mid-Market Bar */}
        <div className="grid grid-cols-4 py-1.5 my-1.5 bg-[#161616] border-y border-[#212121] text-[11px] font-mono font-medium z-10">
          <span className="text-[#888] text-left pl-1">MID: {mid.toFixed(2)}</span>
          <span className="text-right text-[#888] font-semibold col-span-2">
            SPREAD: {spread > 0 ? `${spread.toFixed(2)} EUR` : "0.00"}
          </span>
          <span className="text-[#888] text-right pr-1">LAST: {(tickerLast || mid).toFixed(2)}</span>
        </div>

        {/* Bid Rows (Buyers) */}
        {bidRows.length === 0 ? (
          <div className="text-center py-2 text-[#444] italic">No active bids</div>
        ) : (
          bidRows.map((row, idx) => {
            const widthPct = Math.min(100, (row.cumulative / maxCumulative) * 100);
            return (
              <div 
                key={`bid-${idx}`} 
                className="grid grid-cols-4 py-1 border-b border-[#151515] hover:bg-[#151a16] relative items-center"
              >
                {/* Visual Depth bar */}
                <div 
                  className="absolute left-0 top-0 bottom-0 bg-[#163a21] opacity-15"
                  style={{ width: `${widthPct}%` }}
                />

                <span className="text-[#f4f4f4] text-left font-medium z-10 pl-1">{row.size.toLocaleString()}</span>
                <span className="text-[#2ebd59] text-right font-semibold z-10">{row.price.toFixed(2)}</span>
                <span className="text-[#444] text-right z-10">-</span>
                <span className="text-[#444] text-right z-10 pr-1">-</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
