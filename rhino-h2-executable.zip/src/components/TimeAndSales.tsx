import React from "react";
import { Trade, Participant } from "../types";

interface TimeAndSalesProps {
  productId: string;
  trades: Trade[];
  participants: Participant[];
}

export default function TimeAndSales({ productId, trades, participants }: TimeAndSalesProps) {
  // Sort trades descending by time (newest first)
  const productTrades = trades
    .filter(t => t.product_id === productId)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Helper to get descriptive role/type for participant
  const getParticipantType = (id: string): string => {
    const p = participants.find(part => part.id === id);
    return p ? p.role : "TRADER";
  };

  return (
    <div id="time-and-sales" className="flex flex-col bg-[#111111] border border-[#2b2b2b] rounded-none p-4 h-[350px]">
      <div className="flex items-center justify-between mb-3 border-b border-[#1f1f1f] pb-1.5">
        <span className="text-[12px] uppercase font-semibold text-[#8a8a8a] tracking-wider">Time & Sales (Live Tape)</span>
        <span className="text-[10px] bg-[#221d12] text-[#e3b341] px-1.5 py-0.5 font-mono border border-[#443821]">Streaming</span>
      </div>

      {/* Grid Headers */}
      <div className="grid grid-cols-6 text-[10px] text-[#555] font-mono uppercase tracking-wider mb-2 px-1 text-center">
        <span className="text-left">Time</span>
        <span className="text-right">Price</span>
        <span className="text-right">Qty (kg)</span>
        <span className="text-center col-span-2">Match Side</span>
        <span className="text-right">Trade ID</span>
      </div>

      {/* Tape list */}
      <div className="flex-1 min-h-0 overflow-y-auto font-mono text-[11px] select-none text-center">
        {productTrades.length === 0 ? (
          <div className="text-center py-8 text-[#444] italic">No executions logged</div>
        ) : (
          productTrades.slice(0, 30).map((trade, idx) => {
            const timeStr = new Date(trade.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
            const isBuyAggressor = trade.side === "BUY";
            
            return (
              <div 
                key={`tape-${idx}`} 
                className="grid grid-cols-6 py-1 border-b border-[#151515] hover:bg-[#151515] items-center"
              >
                <span className="text-left text-[#888]">{timeStr}</span>
                <span className={`text-right font-semibold ${isBuyAggressor ? 'text-[#2ebd59]' : 'text-[#ff5f5f]'}`}>
                  {trade.price.toFixed(2)}
                </span>
                <span className="text-right text-[#f4f4f4]">{trade.quantity.toLocaleString()}</span>
                <span className="text-[#8a8a8a] text-[10px] text-right truncate pl-1">
                  {getParticipantType(trade.buyer_id)}
                </span>
                <span className="text-[#555] text-center text-[10px] font-sans">→</span>
                <span className="text-[#8a8a8a] text-[10px] text-left truncate">
                  {getParticipantType(trade.seller_id)}
                </span>
                <span className="text-right text-[#888] text-[9px]">{trade.trade_id}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
