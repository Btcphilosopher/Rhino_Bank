import {
  Role,
  OrderType,
  Side,
  OrderStatus,
  TradeStatus,
  CertificateState,
  MarketSession,
  NominationStatus,
  DeliveryStatus,
  MarginCallStatus,
  SpotHydrogenContract,
  Product,
  Participant,
  Order,
  Execution,
  Trade,
  Position,
  Nomination,
  PhysicalDelivery,
  Certificate,
  DoubleEntryLedgerRow,
  MarginCall,
  Ticker,
  MarketSurveillanceAlert,
  AuditEvent
} from "./types";

// Helper to generate IDs
function genId(prefix: string): string {
  return `${prefix}-${Math.floor(100000 + Math.random() * 900000)}`;
}

export class ExchangeEngine {
  public markets: { id: string; name: string; session: MarketSession; executionRule: "RESTING" | "AGGRESSOR" | "MIDPOINT"; circuitBreakerThreshold: number }[] = [];
  public products: Product[] = [];
  public participants: Participant[] = [];
  public orders: Order[] = [];
  public executions: Execution[] = [];
  public trades: Trade[] = [];
  public positions: Position[] = [];
  public nominations: Nomination[] = [];
  public deliveries: PhysicalDelivery[] = [];
  public certificates: Certificate[] = [];
  public ledgerEntries: DoubleEntryLedgerRow[] = [];
  public marginCalls: MarginCall[] = [];
  public alerts: MarketSurveillanceAlert[] = [];
  public auditEvents: AuditEvent[] = [];
  
  // Sequence counters
  private orderSequence = 1000;
  private execSequence = 5000;
  private ledgerSequence = 8000;

  // Active Simulation toggle
  public isSimulationActive = true;
  public simulationSpeed: 1 | 10 | 100 | 1000 = 1;

  // In-memory inventory tracking for participants (kg)
  public inventories: Map<string, { [productId: string]: number }> = new Map();

  constructor() {
    this.initializeMarketsAndProducts();
    this.initializeParticipants();
    this.initializeInventoryAndCertificates();
    this.seedHistoricalTrades();
  }

  private initializeMarketsAndProducts() {
    // 5 Delivery point hubs
    const hubs = [
      "NORTH SEA HUB",
      "ROTTERDAM H2 HUB",
      "RHINE H2 HUB",
      "GERMAN NORTH H2 HUB",
      "UK EAST COAST H2 HUB"
    ];

    // 5 separate products
    this.products = [
      { product_id: "RHINO-H2-NS-REN", name: "RHINO H2 NORTH SEA RENEWABLE", delivery_point: hubs[0], certification_type: "RENEWABLE", energy_content_mwh_per_kg: 0.0333 },
      { product_id: "RHINO-H2-NS-LC", name: "RHINO H2 NORTH SEA LOW CARBON", delivery_point: hubs[0], certification_type: "LOW_CARBON", energy_content_mwh_per_kg: 0.0333 },
      { product_id: "RHINO-H2-NL-REN", name: "RHINO H2 NETHERLANDS RENEWABLE", delivery_point: hubs[1], certification_type: "RENEWABLE", energy_content_mwh_per_kg: 0.0333 },
      { product_id: "RHINO-H2-DE-REN", name: "RHINO H2 GERMANY RENEWABLE", delivery_point: hubs[3], certification_type: "RENEWABLE", energy_content_mwh_per_kg: 0.0333 },
      { product_id: "RHINO-H2-UK-REN", name: "RHINO H2 UK RENEWABLE", delivery_point: hubs[4], certification_type: "RENEWABLE", energy_content_mwh_per_kg: 0.0333 }
    ];

    // Establish markets
    this.markets = this.products.map(p => ({
      id: p.product_id,
      name: p.name,
      session: MarketSession.OPEN,
      executionRule: "RESTING",
      circuitBreakerThreshold: 0.15 // 15% price movement limits
    }));
  }

  private initializeParticipants() {
    // 30 participants
    const roles = [
      { name: "ELLAN VANNIN HYDROGEN FUND", role: Role.FUND, cash: 50000000000, credit: 10000000000 }, // €500m cash, €100m credit
      { name: "AURORA HYDROGEN PRODUCER", role: Role.PRODUCER, cash: 10000000000, credit: 5000000000 },
      { name: "EUROPEAN CHEMICAL WORKS", role: Role.INDUSTRIAL_BUYER, cash: 8000000000, credit: 4000000000 },
      { name: "ROTTERDAM MUNICIPAL UTILITY", role: Role.UTILITY, cash: 15000000000, credit: 10000000000 },
      { name: "NORTH SEA STORAGE CORP", role: Role.STORAGE_OPERATOR, cash: 5000000000, credit: 3000000000 },
      { name: "RHINE COMMODITY TRADERS", role: Role.TRADER, cash: 2000000000, credit: 2000000000 },
      { name: "VANGUARD ENERGY FUND", role: Role.FUND, cash: 10000000000, credit: 5000000000 },
      { name: "NORDIC GREEN FUELS", role: Role.PRODUCER, cash: 9000000000, credit: 3000000000 },
      { name: "HAMBURG STEELWORKS AG", role: Role.INDUSTRIAL_BUYER, cash: 12000000000, credit: 8000000000 },
      { name: "GLOBAL BROKING LTD", role: Role.BROKER, cash: 1000000000, credit: 1000000000 },
      // Generic participants to fill list up to 30
      ...Array.from({ length: 20 }, (_, i) => {
        const idNum = i + 11;
        const rolePool = [Role.TRADER, Role.PRODUCER, Role.INDUSTRIAL_BUYER, Role.UTILITY];
        const selectedRole = rolePool[i % rolePool.length];
        return {
          name: `PARTICIPANT_${idNum}_${selectedRole}`,
          role: selectedRole,
          cash: 3000000000, // €30m
          credit: 1500000000 // €15m
        };
      })
    ];

    this.participants = roles.map((r, i) => {
      const id = r.name.toLowerCase().replace(/\s+/g, "_");
      return {
        id,
        name: r.name,
        role: r.role,
        trading_enabled: true,
        cash_balance: r.cash,
        credit_limit: r.credit,
        collateral_balance: Math.floor(r.cash * 0.1), // 10% cash deposited as collateral initially
        initial_margin: 0,
        variation_margin: 0,
        max_order_quantity: 5000000, // 5m kg max order
        max_notional: 3000000000,   // €30m max notional
        max_position: 10000000,     // 10m kg max position
        max_delivery: 10000000      // 10m kg max delivery
      };
    });
  }

  private initializeInventoryAndCertificates() {
    this.participants.forEach(p => {
      const isProducer = p.role === Role.PRODUCER;
      const h2_inventory: { [productId: string]: number } = {};
      
      this.products.forEach(prod => {
        // Producers and storage operators start with physical inventory
        let quantity = 0;
        if (isProducer) {
          quantity = 5000000 + Math.floor(Math.random() * 5000000); // 5m-10m kg physical inventory
        } else if (p.role === Role.STORAGE_OPERATOR) {
          quantity = 10000000;
        } else if (p.role === Role.FUND) {
          quantity = 0; // Funds don't start with physical inventory
        } else {
          quantity = 1000000; // Utilities and buyers hold some baseline
        }
        h2_inventory[prod.product_id] = quantity;

        // Generate certificates for renewable products
        if (prod.certification_type === "RENEWABLE" && quantity > 0) {
          const certCount = Math.floor(quantity / 1000000); // Create certificates in 1,000,000 kg blocks
          for (let c = 0; c < certCount; c++) {
            const certId = genId("CERT");
            this.certificates.push({
              certificate_id: certId,
              product_id: prod.product_id,
              original_owner_id: p.id,
              current_owner_id: p.id,
              quantity: 1000000,
              certification_type: "RENEWABLE",
              carbon_intensity: 0.12 + Math.random() * 0.2, // low intensity CO2/kg
              issuance_date: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
              state: CertificateState.HELD
            });
          }
        }
      });
      this.inventories.set(p.id, h2_inventory);
    });
  }

  private seedHistoricalTrades() {
    // Populate some historical orders and matched executions for realistic starting charts
    const basePrices: { [productId: string]: number } = {
      "RHINO-H2-NS-REN": 5.75,
      "RHINO-H2-NS-LC": 4.10,
      "RHINO-H2-NL-REN": 5.85,
      "RHINO-H2-DE-REN": 5.95,
      "RHINO-H2-UK-REN": 5.65
    };

    const producers = this.participants.filter(p => p.role === Role.PRODUCER);
    const buyers = this.participants.filter(p => p.role === Role.INDUSTRIAL_BUYER || p.role === Role.FUND || p.role === Role.UTILITY);

    this.products.forEach(prod => {
      const basePrice = basePrices[prod.product_id];
      // Seed 20 historical trades over the last 24 hours
      for (let i = 0; i < 20; i++) {
        const timeOffset = (20 - i) * 1.2 * 3600 * 1000; // staggered hours ago
        const tradeTime = new Date(Date.now() - timeOffset).toISOString();
        const randBuyer = buyers[i % buyers.length];
        const randSeller = producers[i % producers.length];
        const qty = 50000 + Math.floor(Math.random() * 150000); // 50k to 200k kg
        const priceDev = (Math.sin(i / 3) * 0.15) + (Math.random() * 0.05 - 0.025);
        const finalPrice = Math.round((basePrice + priceDev) * 100) / 100;
        const priceCents = Math.round(finalPrice * 100);
        const notional = qty * priceCents;
        const tradeId = `RHX-${new Date(tradeTime).toISOString().substring(0, 10).replace(/-/g, "")}-${String(i + 1).padStart(6, "0")}`;

        const trade: Trade = {
          trade_id: tradeId,
          timestamp: tradeTime,
          market_id: prod.product_id,
          product_id: prod.product_id,
          side: Side.BUY,
          buy_order_id: genId("ORD"),
          sell_order_id: genId("ORD"),
          buyer_id: randBuyer.id,
          seller_id: randSeller.id,
          quantity: qty,
          price: finalPrice,
          notional: notional,
          fees: Math.floor(notional * 0.0006), // 0.06% combined fees
          status: TradeStatus.SETTLED, // historic are already settled
          delivery_point: prod.delivery_point,
          delivery_window: "DAY-AHEAD"
        };
        this.trades.push(trade);

        // Adjust participant cash balance synthetically to reflect seed trading
        randBuyer.cash_balance -= (notional + trade.fees);
        randSeller.cash_balance += (notional - trade.fees);
        
        // Update synthetic positions
        this.updatePositionInState(randBuyer.id, prod.product_id, qty, finalPrice, Side.BUY);
        this.updatePositionInState(randSeller.id, prod.product_id, qty, finalPrice, Side.SELL);
      }

      // Add a couple of active resting limit orders to start books as non-empty
      const pBestBid = basePrice - 0.05;
      const pBestAsk = basePrice + 0.05;

      // Rest buy orders
      buyers.slice(0, 2).forEach((b, k) => {
        const oId = genId("ORD");
        const price = Math.round((pBestBid - k * 0.05) * 100) / 100;
        this.orders.push({
          order_id: oId,
          client_order_id: genId("CL"),
          participant_id: b.id,
          market_id: prod.product_id,
          product_id: prod.product_id,
          side: Side.BUY,
          order_type: OrderType.LIMIT,
          quantity: 200000 - k * 50000,
          price: price,
          priceCents: Math.round(price * 100),
          delivery_point: prod.delivery_point,
          delivery_window: "DAY-AHEAD",
          time_in_force: "GTC",
          status: OrderStatus.RESTING,
          filled_quantity: 0,
          cancelled_quantity: 0,
          timestamp: new Date().toISOString(),
          sequence_number: ++this.orderSequence
        });
      });

      // Rest sell orders
      producers.slice(0, 2).forEach((s, k) => {
        const oId = genId("ORD");
        const price = Math.round((pBestAsk + k * 0.05) * 100) / 100;
        this.orders.push({
          order_id: oId,
          client_order_id: genId("CL"),
          participant_id: s.id,
          market_id: prod.product_id,
          product_id: prod.product_id,
          side: Side.SELL,
          order_type: OrderType.LIMIT,
          quantity: 250000 - k * 40000,
          price: price,
          priceCents: Math.round(price * 100),
          delivery_point: prod.delivery_point,
          delivery_window: "DAY-AHEAD",
          time_in_force: "GTC",
          status: OrderStatus.RESTING,
          filled_quantity: 0,
          cancelled_quantity: 0,
          timestamp: new Date().toISOString(),
          sequence_number: ++this.orderSequence
        });
      });
    });
  }

  // Pre-Trade Risk check
  public checkPreTradeRisk(order: Order, participant: Participant): { passed: boolean; reason?: string } {
    if (!participant.trading_enabled) {
      return { passed: false, reason: "TRADING_DISABLED_FOR_PARTICIPANT" };
    }

    const market = this.markets.find(m => m.id === order.market_id);
    if (!market || market.session === MarketSession.HALTED) {
      return { passed: false, reason: "MARKET_IS_HALTED" };
    }

    // Limit check
    if (order.quantity > participant.max_order_quantity) {
      return { passed: false, reason: "EXCEEDS_MAX_ORDER_QUANTITY" };
    }

    const estNotional = order.quantity * order.priceCents;
    if (estNotional > participant.max_notional) {
      return { passed: false, reason: "EXCEEDS_MAX_NOTIONAL_LIMIT" };
    }

    // Buying power validation for BIDs
    if (order.side === Side.BUY) {
      const activeRestingNotional = this.orders
        .filter(o => o.participant_id === participant.id && o.side === Side.BUY && o.status === OrderStatus.RESTING)
        .reduce((sum, o) => sum + (o.quantity - o.filled_quantity) * o.priceCents, 0);

      const requiredPower = estNotional + activeRestingNotional;
      const totalCapacity = participant.cash_balance + participant.credit_limit;

      if (requiredPower > totalCapacity) {
        return { passed: false, reason: "INSUFFICIENT_BUYING_POWER" };
      }
    }

    // Physical Inventory Validation for ASKs (unless configured as speculative/short-allowed)
    if (order.side === Side.SELL) {
      const isSpeculativeRole = participant.role === Role.FUND || participant.role === Role.TRADER;
      if (!isSpeculativeRole) {
        const inv = this.inventories.get(participant.id);
        const currentQty = inv ? (inv[order.product_id] || 0) : 0;
        
        const restingSellQty = this.orders
          .filter(o => o.participant_id === participant.id && o.side === Side.SELL && o.status === OrderStatus.RESTING && o.product_id === order.product_id)
          .reduce((sum, o) => sum + (o.quantity - o.filled_quantity), 0);

        if (restingSellQty + order.quantity > currentQty) {
          return { passed: false, reason: "INSUFFICIENT_PHYSICAL_INVENTORY" };
        }
      }

      // Check certificate eligibility if certified
      const product = this.products.find(p => p.product_id === order.product_id);
      if (product && product.certification_type === "RENEWABLE") {
        const totalHeldCertQty = this.certificates
          .filter(c => c.current_owner_id === participant.id && c.product_id === order.product_id && c.state === CertificateState.HELD)
          .reduce((sum, c) => sum + c.quantity, 0);

        const activeRestingCertQty = this.orders
          .filter(o => o.participant_id === participant.id && o.side === Side.SELL && o.status === OrderStatus.RESTING && o.product_id === order.product_id)
          .reduce((sum, o) => sum + (o.quantity - o.filled_quantity), 0);

        if (activeRestingCertQty + order.quantity > totalHeldCertQty) {
          return { passed: false, reason: "INSUFFICIENT_RENEWABLE_CERTIFICATES" };
        }
      }
    }

    return { passed: true };
  }

  // Handle Order Submission
  public submitOrder(orderParams: Omit<Order, "order_id" | "status" | "filled_quantity" | "cancelled_quantity" | "timestamp" | "sequence_number">): Order {
    const participant = this.participants.find(p => p.id === orderParams.participant_id);
    if (!participant) {
      throw new Error(`Participant ${orderParams.participant_id} not found`);
    }

    const order: Order = {
      ...orderParams,
      order_id: genId("ORD"),
      status: OrderStatus.CREATED,
      filled_quantity: 0,
      cancelled_quantity: 0,
      timestamp: new Date().toISOString(),
      sequence_number: ++this.orderSequence
    };

    // Pre-trade risk validations
    const riskCheck = this.checkPreTradeRisk(order, participant);
    if (!riskCheck.passed) {
      order.status = OrderStatus.REJECTED;
      this.orders.push(order);
      this.logAuditEvent("RISK_GATEWAY", `Order ${order.order_id} rejected. Reason: ${riskCheck.reason}`);
      return order;
    }

    order.status = OrderStatus.ACCEPTED;
    this.orders.push(order);

    // Matching Engine hot-path
    this.processMatching(order);

    return order;
  }

  // Cancel Order
  public cancelOrder(orderId: string, operatorId: string): boolean {
    const order = this.orders.find(o => o.order_id === orderId);
    if (!order) return false;

    if (order.status !== OrderStatus.RESTING && order.status !== OrderStatus.PARTIALLY_FILLED) {
      return false;
    }

    const prevStatus = order.status;
    order.status = OrderStatus.CANCELLED;
    order.cancelled_quantity = order.quantity - order.filled_quantity;

    this.logAuditEvent(operatorId, `Cancelled order ${order.order_id} (${order.cancelled_quantity} kg remaining)`);
    return true;
  }

  // Matching algorithm
  private processMatching(incomingOrder: Order) {
    const market = this.markets.find(m => m.id === incomingOrder.market_id);
    const executionRule = market ? market.executionRule : "RESTING";

    // FOK pre-execution check
    if (incomingOrder.order_type === OrderType.FOK) {
      const opposingOrders = this.getSortedOppositeBook(incomingOrder.market_id, incomingOrder.side);
      let totalAvailable = 0;
      for (const opp of opposingOrders) {
        if (incomingOrder.side === Side.BUY && opp.priceCents > incomingOrder.priceCents) break;
        if (incomingOrder.side === Side.SELL && opp.priceCents < incomingOrder.priceCents) break;
        totalAvailable += (opp.quantity - opp.filled_quantity);
      }
      if (totalAvailable < incomingOrder.quantity) {
        incomingOrder.status = OrderStatus.CANCELLED;
        incomingOrder.cancelled_quantity = incomingOrder.quantity;
        this.logAuditEvent("MATCHING_ENGINE", `FOK order ${incomingOrder.order_id} cancelled: Insufficient volume to fill entire order.`);
        return;
      }
    }

    let oppositeBook = this.getSortedOppositeBook(incomingOrder.market_id, incomingOrder.side);

    while (incomingOrder.filled_quantity < incomingOrder.quantity && oppositeBook.length > 0) {
      const bestOpposite = oppositeBook[0];

      // Match Conditions
      let priceMatches = false;
      if (incomingOrder.order_type === OrderType.MARKET) {
        priceMatches = true; // market orders execute against best prices unconditionally
      } else if (incomingOrder.side === Side.BUY) {
        priceMatches = incomingOrder.priceCents >= bestOpposite.priceCents;
      } else {
        priceMatches = incomingOrder.priceCents <= bestOpposite.priceCents;
      }

      if (!priceMatches) break; // order is out of marketable bounds

      // Calculate Exec Quantity
      const incomingRemaining = incomingOrder.quantity - incomingOrder.filled_quantity;
      const oppositeRemaining = bestOpposite.quantity - bestOpposite.filled_quantity;
      const fillQty = Math.min(incomingRemaining, oppositeRemaining);

      // Determine Execution Price
      let executionPrice = bestOpposite.price; // RESTING (Default)
      if (executionRule === "AGGRESSOR") {
        executionPrice = incomingOrder.order_type === OrderType.MARKET ? bestOpposite.price : incomingOrder.price;
      } else if (executionRule === "MIDPOINT") {
        executionPrice = incomingOrder.order_type === OrderType.MARKET ? bestOpposite.price : (incomingOrder.price + bestOpposite.price) / 2;
      }
      
      const executionPriceCents = Math.round(executionPrice * 100);

      // Perform trade execution
      const tradeId = genId("TRD");
      const execId = genId("EXEC");
      const sequence = ++this.execSequence;

      const feeRate = 0.0003; // 0.03% broker fee
      const matchNotional = fillQty * executionPriceCents;
      const feeCents = Math.floor(matchNotional * feeRate);

      const buyerId = incomingOrder.side === Side.BUY ? incomingOrder.participant_id : bestOpposite.participant_id;
      const sellerId = incomingOrder.side === Side.SELL ? incomingOrder.participant_id : bestOpposite.participant_id;

      const execution: Execution = {
        execution_id: execId,
        trade_id: tradeId,
        buy_order_id: incomingOrder.side === Side.BUY ? incomingOrder.order_id : bestOpposite.order_id,
        sell_order_id: incomingOrder.side === Side.SELL ? incomingOrder.order_id : bestOpposite.order_id,
        buyer_id: buyerId,
        seller_id: sellerId,
        product_id: incomingOrder.product_id,
        quantity: fillQty,
        price: executionPrice,
        priceCents: executionPriceCents,
        currency: "EUR",
        delivery_point: incomingOrder.delivery_point,
        delivery_window: incomingOrder.delivery_window,
        timestamp: new Date().toISOString(),
        execution_sequence: sequence,
        fee: feeCents,
        market_id: incomingOrder.market_id
      };
      this.executions.push(execution);

      // Create synthetic trade object
      const trade: Trade = {
        trade_id: tradeId,
        timestamp: execution.timestamp,
        market_id: incomingOrder.market_id,
        product_id: incomingOrder.product_id,
        side: incomingOrder.side,
        buy_order_id: execution.buy_order_id,
        sell_order_id: execution.sell_order_id,
        buyer_id: buyerId,
        seller_id: sellerId,
        quantity: fillQty,
        price: executionPrice,
        notional: matchNotional,
        fees: feeCents,
        status: TradeStatus.EXECUTED,
        delivery_point: incomingOrder.delivery_point,
        delivery_window: incomingOrder.delivery_window
      };
      this.trades.push(trade);

      // Update Order States
      incomingOrder.filled_quantity += fillQty;
      bestOpposite.filled_quantity += fillQty;

      incomingOrder.status = incomingOrder.filled_quantity === incomingOrder.quantity ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED;
      bestOpposite.status = bestOpposite.filled_quantity === bestOpposite.quantity ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED;

      // Double-Entry Ledger Posting for Clearing/Financial Position
      this.postDoubleEntryLedger(trade, executionPriceCents);

      // Downstream Trade Processing: Position, Nominations, Deliveries, Certificates
      this.processPostTrade(trade);

      // Refresh list to see if best resting order is cleared
      oppositeBook = this.getSortedOppositeBook(incomingOrder.market_id, incomingOrder.side);
    }

    // Post-match state cleanup for incoming order
    if (incomingOrder.filled_quantity < incomingOrder.quantity) {
      if (incomingOrder.order_type === OrderType.IOC || incomingOrder.order_type === OrderType.MARKET) {
        incomingOrder.status = OrderStatus.CANCELLED;
        incomingOrder.cancelled_quantity = incomingOrder.quantity - incomingOrder.filled_quantity;
        this.logAuditEvent("MATCHING_ENGINE", `IOC/MARKET remainder for order ${incomingOrder.order_id} cancelled.`);
      } else {
        // GTC / GTD remain in book
        incomingOrder.status = incomingOrder.filled_quantity > 0 ? OrderStatus.PARTIALLY_FILLED : OrderStatus.RESTING;
      }
    }
  }

  // Get opposing book sorted strictly by Price-Time Priority
  private getSortedOppositeBook(marketId: string, side: Side): Order[] {
    const oppSide = side === Side.BUY ? Side.SELL : Side.BUY;
    return this.orders
      .filter(o => o.market_id === marketId && o.side === oppSide && (o.status === OrderStatus.RESTING || o.status === OrderStatus.PARTIALLY_FILLED))
      .sort((a, b) => {
        if (oppSide === Side.SELL) {
          // Asks: lowest price first
          if (a.priceCents !== b.priceCents) {
            return a.priceCents - b.priceCents;
          }
        } else {
          // Bids: highest price first
          if (a.priceCents !== b.priceCents) {
            return b.priceCents - a.priceCents;
          }
        }
        // Time priority
        return a.sequence_number - b.sequence_number;
      });
  }

  // Double-Entry accounting engine (Invariant: Total Debits = Total Credits)
  private postDoubleEntryLedger(trade: Trade, priceCents: number) {
    const buyerId = trade.buyer_id;
    const sellerId = trade.seller_id;
    const notional = trade.notional;
    const qty = trade.quantity;

    // Row IDs
    const r1 = genId("ENT");
    const r2 = genId("ENT");
    const r3 = genId("ENT");
    const r4 = genId("ENT");

    // Buyer:
    // DR: Hydrogen Receivable (Asset increase)
    // CR: Cash Payable (Liability increase)
    this.ledgerEntries.push({
      entry_id: r1,
      timestamp: new Date().toISOString(),
      trade_id: trade.trade_id,
      participant_id: buyerId,
      account_name: "HYDROGEN_RECEIVABLE",
      debit: qty,
      credit: 0,
      description: `DR Trade ${trade.trade_id} Hydrogen entitlement`
    });
    this.ledgerEntries.push({
      entry_id: r2,
      timestamp: new Date().toISOString(),
      trade_id: trade.trade_id,
      participant_id: buyerId,
      account_name: "CASH_PAYABLE",
      debit: 0,
      credit: notional,
      description: `CR Trade ${trade.trade_id} Cash payable obligation`
    });

    // Seller:
    // DR: Cash Receivable (Asset increase)
    // CR: Hydrogen Deliverable (Liability increase)
    this.ledgerEntries.push({
      entry_id: r3,
      timestamp: new Date().toISOString(),
      trade_id: trade.trade_id,
      participant_id: sellerId,
      account_name: "CASH_RECEIVABLE",
      debit: notional,
      credit: 0,
      description: `DR Trade ${trade.trade_id} Cash receivable right`
    });
    this.ledgerEntries.push({
      entry_id: r4,
      timestamp: new Date().toISOString(),
      trade_id: trade.trade_id,
      participant_id: sellerId,
      account_name: "HYDROGEN_DELIVERABLE",
      debit: 0,
      credit: qty,
      description: `CR Trade ${trade.trade_id} Physical hydrogen delivery obligation`
    });

    // Deduct cash from balances
    const buyer = this.participants.find(p => p.id === buyerId);
    if (buyer) {
      buyer.cash_balance -= (notional + trade.fees);
    }
    const seller = this.participants.find(p => p.id === sellerId);
    if (seller) {
      seller.cash_balance += (notional - trade.fees);
    }
  }

  // Position, physical delivery, nominations, certificates
  private processPostTrade(trade: Trade) {
    const buyerId = trade.buyer_id;
    const sellerId = trade.seller_id;
    const qty = trade.quantity;

    // 1. Update synthetic positions
    this.updatePositionInState(buyerId, trade.product_id, qty, trade.price, Side.BUY);
    this.updatePositionInState(sellerId, trade.product_id, qty, trade.price, Side.SELL);

    // 2. Clear Trade & Move to NOMINATION step
    trade.status = TradeStatus.CONFIRMED;

    // 3. Create Certificates allocation if product is Renewable
    const product = this.products.find(p => p.product_id === trade.product_id);
    if (product && product.certification_type === "RENEWABLE") {
      const sellerCerts = this.certificates.filter(c => c.current_owner_id === sellerId && c.product_id === trade.product_id && c.state === CertificateState.HELD);
      
      let allocatedQty = 0;
      for (const cert of sellerCerts) {
        if (allocatedQty >= qty) break;
        cert.state = CertificateState.ALLOCATED;
        allocatedQty += cert.quantity;
        trade.certificate_id = cert.certificate_id; // map first allocated cert for tracking
      }
    }

    // 4. Create nomination structures
    const bNomId = genId("NOM");
    const sNomId = genId("NOM");
    this.nominations.push({
      nomination_id: bNomId,
      trade_id: trade.trade_id,
      participant_id: buyerId,
      side: Side.BUY,
      quantity: qty,
      time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(), // tomorrow
      location: trade.delivery_point,
      quality_spec: { purity: 99.99, moisture: 5, pressure: 30 },
      transport_route: "NORTH-SEA-PIPELINE-MAIN",
      storage_facility: "ROTTERDAM-CAVERN-ALPHA",
      status: NominationStatus.REQUIRED
    });

    this.nominations.push({
      nomination_id: sNomId,
      trade_id: trade.trade_id,
      participant_id: sellerId,
      side: Side.SELL,
      quantity: qty,
      time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      location: trade.delivery_point,
      quality_spec: { purity: 99.99, moisture: 5, pressure: 30 },
      transport_route: "NORTH-SEA-PIPELINE-MAIN",
      storage_facility: "ROTTERDAM-CAVERN-ALPHA",
      status: NominationStatus.REQUIRED
    });

    // 5. Create physical delivery tracking
    const delId = genId("DEL");
    const delivery: PhysicalDelivery = {
      delivery_id: delId,
      trade_id: trade.trade_id,
      shipper_id: sellerId,
      receiver_id: buyerId,
      quantity_contracted: qty,
      delivery_point: trade.delivery_point,
      status: DeliveryStatus.NOMINATED
    };
    this.deliveries.push(delivery);
    trade.delivery_id = delId;

    // 6. Clearing margin re-evaluations
    this.recalculateMargins(buyerId);
    this.recalculateMargins(sellerId);

    // 7. Surveillance and wash trade monitoring
    this.runMarketSurveillance(trade);
  }

  // Recalculate margins and generate calls if necessary
  public recalculateMargins(participantId: string) {
    const p = this.participants.find(part => part.id === participantId);
    if (!p) return;

    // Calculate gross exposure (value of all open positions + open resting bids)
    const activeRestingNotional = this.orders
      .filter(o => o.participant_id === participantId && o.side === Side.BUY && o.status === OrderStatus.RESTING)
      .reduce((sum, o) => sum + (o.quantity - o.filled_quantity) * o.priceCents, 0);

    const positionsVal = this.positions
      .filter(pos => pos.participant_id === participantId)
      .reduce((sum, pos) => sum + Math.abs(pos.net_qty) * Math.round(pos.avg_price * 100), 0);

    const grossExposure = activeRestingNotional + positionsVal;
    
    // Initial margin = 10% of gross exposure
    const requiredMargin = Math.floor(grossExposure * 0.10);
    p.initial_margin = requiredMargin;

    // If initial margin requirement exceeds collateral balance, emit a synthetic Margin Call
    if (requiredMargin > p.collateral_balance) {
      const callAmt = requiredMargin - p.collateral_balance;
      const marginCall: MarginCall = {
        id: genId("MC"),
        participant_id: participantId,
        timestamp: new Date().toISOString(),
        exposure_cents: grossExposure,
        collateral_cents: p.collateral_balance,
        margin_required_cents: requiredMargin,
        call_amount_cents: callAmt,
        status: MarginCallStatus.OPEN
      };
      this.marginCalls.push(marginCall);
      this.logAuditEvent("CLEARING_HOUSE", `MARGIN CALL issued for ${p.name}: €${(callAmt / 100).toFixed(2)} collateral required.`);
    }
  }

  // Handle Collateral Deposit
  public depositCollateral(participantId: string, amountCents: number): boolean {
    const p = this.participants.find(part => part.id === participantId);
    if (!p || p.cash_balance < amountCents) return false;

    p.cash_balance -= amountCents;
    p.collateral_balance += amountCents;

    // Met margin calls
    const openCalls = this.marginCalls.filter(m => m.participant_id === participantId && m.status === MarginCallStatus.OPEN);
    openCalls.forEach(call => {
      if (p.collateral_balance >= call.margin_required_cents) {
        call.status = MarginCallStatus.MET;
      }
    });

    this.recalculateMargins(participantId);
    this.logAuditEvent(participantId, `Deposited €${(amountCents / 100).toFixed(2)} to Collateral Account.`);
    return true;
  }

  // Progress Delivery step by step to settlement
  public progressDelivery(deliveryId: string, customMeasuredQty?: number, customPurity?: number): PhysicalDelivery {
    const del = this.deliveries.find(d => d.delivery_id === deliveryId);
    if (!del) throw new Error("Delivery not found");

    const trade = this.trades.find(t => t.trade_id === del.trade_id);
    if (!trade) throw new Error("Trade not found for delivery");

    const buyer = this.participants.find(p => p.id === del.receiver_id);
    const seller = this.participants.find(p => p.id === del.shipper_id);

    if (del.status === DeliveryStatus.NOMINATED) {
      del.status = DeliveryStatus.SCHEDULED;
      
      // Auto-submit and accept nominations
      const tradeNoms = this.nominations.filter(n => n.trade_id === del.trade_id);
      tradeNoms.forEach(n => n.status = NominationStatus.ACCEPTED);

    } else if (del.status === DeliveryStatus.SCHEDULED) {
      del.status = DeliveryStatus.IN_TRANSIT;
    } else if (del.status === DeliveryStatus.IN_TRANSIT) {
      del.status = DeliveryStatus.AT_HUB;
    } else if (del.status === DeliveryStatus.AT_HUB) {
      del.status = DeliveryStatus.MEASURED;
      
      // Perform synthetic metering
      // Contracted vs Measured variance
      const variance = Math.random() * 0.02 - 0.01; // +/- 1% variance
      const measured = customMeasuredQty ?? Math.round(del.quantity_contracted * (1 + variance));
      del.quantity_measured = measured;

    } else if (del.status === DeliveryStatus.MEASURED) {
      del.status = DeliveryStatus.QUALITY_CHECKED;

      // Quality metering
      const purity = customPurity ?? (99.98 + Math.random() * 0.02); // close to 99.99 contract spec
      del.purity_measured = Math.round(purity * 100) / 100;
      del.moisture_measured = 4.8 + Math.random() * 0.4;
      del.pressure_measured = 29.5 + Math.random() * 1.0;

      // Check specifications tolerances
      const specPassed = purity >= 99.95; // strict tolerance
      del.quality_check_passed = specPassed;

      if (!specPassed) {
        this.logAuditEvent("QUALITY_METERING", `QUALITY EXCEPTION raised on delivery ${del.delivery_id}. Purity below threshold: ${purity}%`);
      }

    } else if (del.status === DeliveryStatus.QUALITY_CHECKED) {
      del.status = DeliveryStatus.ACCEPTED;
      trade.status = TradeStatus.DELIVERED;

      // Transfer inventory physically in ledger
      const measuredQty = del.quantity_measured || del.quantity_contracted;
      if (seller) {
        const pinv = this.inventories.get(seller.id);
        if (pinv && pinv[trade.product_id] !== undefined) {
          pinv[trade.product_id] = Math.max(0, pinv[trade.product_id] - measuredQty);
        }
      }
      if (buyer) {
        const pinv = this.inventories.get(buyer.id);
        if (pinv && pinv[trade.product_id] !== undefined) {
          pinv[trade.product_id] += measuredQty;
        }
      }

      // Transfer certificates from allocated to transferred
      const allocatedCerts = this.certificates.filter(c => c.current_owner_id === trade.seller_id && c.product_id === trade.product_id && c.state === CertificateState.ALLOCATED);
      allocatedCerts.forEach(c => {
        c.current_owner_id = trade.buyer_id;
        c.state = CertificateState.TRANSFERRED;
      });

    } else if (del.status === DeliveryStatus.ACCEPTED) {
      // Final settlement
      del.status = DeliveryStatus.ACCEPTED; // terminal state
      trade.status = TradeStatus.SETTLED;

      // Adjust cash based on variance shortfall
      const diffQty = (del.quantity_measured ?? del.quantity_contracted) - del.quantity_contracted;
      if (diffQty !== 0 && buyer && seller) {
        const priceCents = Math.round(trade.price * 100);
        const adjCents = diffQty * priceCents;
        del.tolerance_adjustment_cents = adjCents;

        if (adjCents < 0) {
          // Shortfall: seller refunds buyer
          seller.cash_balance += adjCents; // adj is negative, so decreases cash
          buyer.cash_balance -= adjCents;  // decreases cash payable or refunds
        } else {
          // Overage: buyer pays seller more
          buyer.cash_balance -= adjCents;
          seller.cash_balance += adjCents;
        }
      }

      this.logAuditEvent("CLEARING_HOUSE", `Trade ${trade.trade_id} physical settlement finalized. All accounts cleared.`);
    }

    return del;
  }

  // Update Positions
  private updatePositionInState(participantId: string, productId: string, qty: number, price: number, side: Side) {
    let pos = this.positions.find(p => p.participant_id === participantId && p.product_id === productId);

    if (!pos) {
      pos = {
        participant_id: participantId,
        product_id: productId,
        delivery_window: "DAY-AHEAD",
        long_qty: 0,
        short_qty: 0,
        net_qty: 0,
        avg_price: 0,
        market_price: price,
        unrealized_pnl: 0,
        realized_pnl: 0,
        physical_status: "NOMINATED"
      };
      this.positions.push(pos);
    }

    const priceCents = Math.round(price * 100);

    if (side === Side.BUY) {
      pos.long_qty += qty;
      pos.net_qty += qty;
      // Recalculate average entry price
      const totalCostCents = (pos.long_qty - qty) * Math.round(pos.avg_price * 100) + qty * priceCents;
      pos.avg_price = Math.round((totalCostCents / pos.long_qty) * 100) / 10000;
    } else {
      pos.short_qty += qty;
      pos.net_qty -= qty;
      const totalSellsCents = (pos.short_qty - qty) * Math.round(pos.avg_price * 100) + qty * priceCents;
      pos.avg_price = Math.round((totalSellsCents / pos.short_qty) * 100) / 10000;
    }

    // Mark to market
    pos.market_price = price;
    pos.unrealized_pnl = Math.floor(pos.net_qty * (priceCents - pos.avg_price * 100));
  }

  // Surveillance algorithms
  private runMarketSurveillance(trade: Trade) {
    // 1. Self trading check
    if (trade.buyer_id === trade.seller_id) {
      this.alerts.push({
        alert_id: genId("ALR"),
        timestamp: new Date().toISOString(),
        market_id: trade.market_id,
        participant_id: trade.buyer_id,
        type: "SELF_TRADING",
        severity: "WARNING",
        description: `Self-trading detected on trade ${trade.trade_id}`,
        details: `Participant ${trade.buyer_id} matched buy/sell order internally. Notional: €${(trade.notional / 100).toFixed(2)}`
      });
    }

    // 2. Wash trading check
    const last30s = this.trades.filter(t => t.buyer_id === trade.buyer_id && t.seller_id === trade.seller_id && t.product_id === trade.product_id && t.price === trade.price && t.trade_id !== trade.trade_id && (Date.now() - new Date(t.timestamp).getTime() < 30000));
    if (last30s.length >= 2) {
      this.alerts.push({
        alert_id: genId("ALR"),
        timestamp: new Date().toISOString(),
        market_id: trade.market_id,
        participant_id: trade.buyer_id,
        type: "WASH_TRADING",
        severity: "CRITICAL",
        description: `High-frequency wash trading pattern detected`,
        details: `Repeated trades between ${trade.buyer_id} and ${trade.seller_id} on product ${trade.product_id} at price €${trade.price}`
      });
    }
  }

  // Set market session status
  public updateMarketSession(marketId: string, session: MarketSession, operatorId: string) {
    const market = this.markets.find(m => m.id === marketId);
    if (market) {
      const old = market.session;
      market.session = session;
      this.logAuditEvent(operatorId, `Market ${marketId} session changed from ${old} to ${session}`);
    }
  }

  // Execute Demonstration Scenarios
  public executeDemo(demoId: number) {
    this.logAuditEvent("DEMO_CONTROLLER", `Initializing Demonstration Scenario ${demoId}`);

    // Reset relevant order states
    this.orders = this.orders.filter(o => o.status !== OrderStatus.RESTING && o.status !== OrderStatus.PARTIALLY_FILLED);

    const prodId = "RHINO-H2-NS-REN";
    const prod = this.products.find(p => p.product_id === prodId)!;

    if (demoId === 1) {
      // PRODUCER A: SELL 1,000,000 kg @ €5.70
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "aurora_hydrogen_producer",
        market_id: prodId,
        product_id: prodId,
        side: Side.SELL,
        order_type: OrderType.LIMIT,
        quantity: 1000000,
        price: 5.70,
        priceCents: 570,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });

      // FUND A (ELLAN VANNIN): BUY 500,000 kg @ €5.80
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "ellan_vannin_hydrogen_fund",
        market_id: prodId,
        product_id: prodId,
        side: Side.BUY,
        order_type: OrderType.LIMIT,
        quantity: 500000,
        price: 5.80,
        priceCents: 580,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });

      // INDUSTRIAL BUYER (EUROPEAN CHEMICAL): BUY 300,000 kg @ €5.75
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "european_chemical_works",
        market_id: prodId,
        product_id: prodId,
        side: Side.BUY,
        order_type: OrderType.LIMIT,
        quantity: 300000,
        price: 5.75,
        priceCents: 575,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });

    } else if (demoId === 2) {
      // Fund rests limit order: BUY 1,000,000 kg @ €5.65
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "ellan_vannin_hydrogen_fund",
        market_id: prodId,
        product_id: prodId,
        side: Side.BUY,
        order_type: OrderType.LIMIT,
        quantity: 1000000,
        price: 5.65,
        priceCents: 565,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });

      // Producer submits sell crossing: SELL 400,000 kg @ €5.60
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "aurora_hydrogen_producer",
        market_id: prodId,
        product_id: prodId,
        side: Side.SELL,
        order_type: OrderType.LIMIT,
        quantity: 400000,
        price: 5.60,
        priceCents: 560,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });

    } else if (demoId === 3) {
      // Populates sells first to build depth:
      // 500,000 @ €5.70
      // 700,000 @ €5.75
      // 1,000,000 @ €5.80
      const seller = "aurora_hydrogen_producer";
      this.submitOrder({ client_order_id: genId("CL"), participant_id: seller, market_id: prodId, product_id: prodId, side: Side.SELL, order_type: OrderType.LIMIT, quantity: 500000, price: 5.70, priceCents: 570, delivery_point: prod.delivery_point, delivery_window: "DAY-AHEAD", time_in_force: "GTC" });
      this.submitOrder({ client_order_id: genId("CL"), participant_id: seller, market_id: prodId, product_id: prodId, side: Side.SELL, order_type: OrderType.LIMIT, quantity: 700000, price: 5.75, priceCents: 575, delivery_point: prod.delivery_point, delivery_window: "DAY-AHEAD", time_in_force: "GTC" });
      this.submitOrder({ client_order_id: genId("CL"), participant_id: seller, market_id: prodId, product_id: prodId, side: Side.SELL, order_type: OrderType.LIMIT, quantity: 1000000, price: 5.80, priceCents: 580, delivery_point: prod.delivery_point, delivery_window: "DAY-AHEAD", time_in_force: "GTC" });

      // Market buy: 2,000,000 kg
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "ellan_vannin_hydrogen_fund",
        market_id: prodId,
        product_id: prodId,
        side: Side.BUY,
        order_type: OrderType.MARKET,
        quantity: 2000000,
        price: 0,
        priceCents: 0,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "IOC"
      });

    } else if (demoId === 4) {
      // 4.5m available
      const seller = "aurora_hydrogen_producer";
      this.submitOrder({ client_order_id: genId("CL"), participant_id: seller, market_id: prodId, product_id: prodId, side: Side.SELL, order_type: OrderType.LIMIT, quantity: 4500000, price: 5.70, priceCents: 570, delivery_point: prod.delivery_point, delivery_window: "DAY-AHEAD", time_in_force: "GTC" });

      // FOK buy 5,000,000 (shoud fail and cancel completely)
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "ellan_vannin_hydrogen_fund",
        market_id: prodId,
        product_id: prodId,
        side: Side.BUY,
        order_type: OrderType.FOK,
        quantity: 5000000,
        price: 5.75,
        priceCents: 575,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "FOK"
      });

    } else if (demoId === 5) {
      // 4.5m available
      const seller = "aurora_hydrogen_producer";
      this.submitOrder({ client_order_id: genId("CL"), participant_id: seller, market_id: prodId, product_id: prodId, side: Side.SELL, order_type: OrderType.LIMIT, quantity: 4500000, price: 5.70, priceCents: 570, delivery_point: prod.delivery_point, delivery_window: "DAY-AHEAD", time_in_force: "GTC" });

      // IOC BUY 5,000,000 (fills 4.5m, cancels remainder)
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: "ellan_vannin_hydrogen_fund",
        market_id: prodId,
        product_id: prodId,
        side: Side.BUY,
        order_type: OrderType.IOC,
        quantity: 5000000,
        price: 5.75,
        priceCents: 575,
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "IOC"
      });

    } else if (demoId === 6) {
      // Producer outage: cancels any large seller orders, collapses supply, alerts surveillance, collapses positions
      const largeSellers = this.orders.filter(o => o.participant_id === "aurora_hydrogen_producer" && o.side === Side.SELL && (o.status === OrderStatus.RESTING || o.status === OrderStatus.PARTIALLY_FILLED));
      largeSellers.forEach(o => this.cancelOrder(o.order_id, "SYSTEM_WATCHDOG"));

      this.alerts.push({
        alert_id: genId("ALR"),
        timestamp: new Date().toISOString(),
        market_id: prodId,
        participant_id: "aurora_hydrogen_producer",
        type: "UNUSUAL_VOLUME",
        severity: "CRITICAL",
        description: `PRODUCER OUTAGE DETECTED: Aurora production halted`,
        details: `Abnormal withdrawal of 5,000,000 kg supply allocation. Order book depth collapsed, price impact critical.`
      });
    }
  }

  // Background random simulator of trading flow
  public performSimulationStep() {
    if (!this.isSimulationActive) return;

    // Pick random product and participant
    const prod = this.products[Math.floor(Math.random() * this.products.length)];
    
    // Choose passive trading participant
    const nonDemoParticipants = this.participants.filter(p => p.id !== "ellan_vannin_hydrogen_fund" && p.id !== "aurora_hydrogen_producer" && p.role !== Role.MARKET_ADMINISTRATOR);
    const buyerPart = nonDemoParticipants.find(p => p.role === Role.INDUSTRIAL_BUYER || p.role === Role.UTILITY || p.role === Role.TRADER);
    const sellerPart = nonDemoParticipants.find(p => p.role === Role.PRODUCER || p.role === Role.STORAGE_OPERATOR || p.role === Role.TRADER);

    const basePrices: { [productId: string]: number } = {
      "RHINO-H2-NS-REN": 5.75,
      "RHINO-H2-NS-LC": 4.10,
      "RHINO-H2-NL-REN": 5.85,
      "RHINO-H2-DE-REN": 5.95,
      "RHINO-H2-UK-REN": 5.65
    };

    const basePrice = basePrices[prod.product_id] || 5.50;

    // 50% chance of buy quote, 50% chance of sell quote
    if (Math.random() > 0.5 && buyerPart) {
      const priceOffset = (Math.random() * 0.12 - 0.08); // Bid around fair value
      const price = Math.round((basePrice + priceOffset) * 100) / 100;
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: buyerPart.id,
        market_id: prod.product_id,
        product_id: prod.product_id,
        side: Side.BUY,
        order_type: OrderType.LIMIT,
        quantity: 10000 + Math.floor(Math.random() * 90000), // 10k-100k kg
        price: price,
        priceCents: Math.round(price * 100),
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });
    } else if (sellerPart) {
      const priceOffset = (Math.random() * 0.12 - 0.04); // Ask around fair value
      const price = Math.round((basePrice + priceOffset) * 100) / 100;
      this.submitOrder({
        client_order_id: genId("CL"),
        participant_id: sellerPart.id,
        market_id: prod.product_id,
        product_id: prod.product_id,
        side: Side.SELL,
        order_type: OrderType.LIMIT,
        quantity: 15000 + Math.floor(Math.random() * 85000),
        price: price,
        priceCents: Math.round(price * 100),
        delivery_point: prod.delivery_point,
        delivery_window: "DAY-AHEAD",
        time_in_force: "GTC"
      });
    }

    // Auto progress scheduled deliveries to simulate real operations lifecycle ticking
    if (Math.random() > 0.7 && this.deliveries.length > 0) {
      const pendingDels = this.deliveries.filter(d => d.status !== DeliveryStatus.ACCEPTED && d.status !== DeliveryStatus.REJECTED);
      if (pendingDels.length > 0) {
        const d = pendingDels[Math.floor(Math.random() * pendingDels.length)];
        this.progressDelivery(d.delivery_id);
      }
    }
  }

  private logAuditEvent(operator: string, action: string) {
    this.auditEvents.unshift({
      event_id: genId("AUD"),
      timestamp: new Date().toISOString(),
      operator_id: operator,
      action: action.substring(0, 50),
      details: action
    });
  }

  // Get current tickers for all markets
  public getTickers(): Ticker[] {
    return this.products.map(prod => {
      const trades = this.trades.filter(t => t.product_id === prod.product_id);
      const orders = this.orders.filter(o => o.product_id === prod.product_id && (o.status === OrderStatus.RESTING || o.status === OrderStatus.PARTIALLY_FILLED));
      
      const bids = orders.filter(o => o.side === Side.BUY).sort((a, b) => b.priceCents - a.priceCents);
      const asks = orders.filter(o => o.side === Side.SELL).sort((a, b) => a.priceCents - b.priceCents);

      const bidPrice = bids[0]?.price ?? 0;
      const askPrice = asks[0]?.price ?? 0;
      const lastTrade = trades[trades.length - 1];

      // Volume & high/low for last 24h
      const last24h = trades.filter(t => Date.now() - new Date(t.timestamp).getTime() < 24 * 3600 * 1000);
      const prices = last24h.map(t => t.price);
      const high = prices.length > 0 ? Math.max(...prices) : (lastTrade?.price ?? bidPrice ?? askPrice);
      const low = prices.length > 0 ? Math.min(...prices) : (lastTrade?.price ?? bidPrice ?? askPrice);
      const totalVol = last24h.reduce((sum, t) => sum + t.quantity, 0);
      const open = prices.length > 0 ? prices[0] : (lastTrade?.price ?? 5.75);

      // VWAP calculation
      const totalNotional = last24h.reduce((sum, t) => sum + t.notional, 0);
      const vwap = totalVol > 0 ? Math.round((totalNotional / totalVol) * 100) / 10000 : (lastTrade?.price ?? 5.75);

      return {
        market_id: prod.product_id,
        product_id: prod.product_id,
        last: lastTrade?.price ?? vwap,
        bid: bidPrice,
        ask: askPrice,
        mid: bidPrice && askPrice ? Math.round(((bidPrice + askPrice) / 2) * 100) / 100 : (lastTrade?.price ?? vwap),
        vwap: vwap,
        high: high,
        low: low,
        open: open,
        volume: totalVol,
        number_of_trades: last24h.length,
        order_book_depth: {
          bids_sum: bids.reduce((sum, o) => sum + (o.quantity - o.filled_quantity), 0),
          asks_sum: asks.reduce((sum, o) => sum + (o.quantity - o.filled_quantity), 0)
        }
      };
    });
  }
}
