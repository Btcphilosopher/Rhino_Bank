import React, { useState, useEffect } from "react";
import { 
  Activity, 
  Clock, 
  HelpCircle, 
  Server, 
  Terminal, 
  UserCheck, 
  Globe, 
  Database 
} from "lucide-react";
import {
  Order,
  Trade,
  Position,
  PhysicalDelivery,
  Nomination,
  Certificate,
  DoubleEntryLedgerRow,
  MarginCall,
  MarketSurveillanceAlert,
  AuditEvent,
  Ticker,
  Product,
  Participant
} from "./types";

import Chart from "./components/Chart";
import OrderBook from "./components/OrderBook";
import TimeAndSales from "./components/TimeAndSales";
import OrderEntry from "./components/OrderEntry";
import BlotterTabs from "./components/BlotterTabs";

export default function App() {
  // Application lists
  const [markets, setMarkets] = useState<any[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [executions, setExecutions] = useState<any[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [nominations, setNominations] = useState<Nomination[]>([]);
  const [deliveries, setDeliveries] = useState<PhysicalDelivery[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [ledgerEntries, setLedgerEntries] = useState<DoubleEntryLedgerRow[]>([]);
  const [marginCalls, setMarginCalls] = useState<MarginCall[]>([]);
  const [alerts, setAlerts] = useState<MarketSurveillanceAlert[]>([]);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>([]);
  const [tickers, setTickers] = useState<Ticker[]>([]);
  
  // UI States
  const [selectedProductId, setSelectedProductId] = useState<string>("RHINO-H2-NS-REN");
  const [isSimulationActive, setIsSimulationActive] = useState<boolean>(true);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [exchangeClock, setExchangeClock] = useState<string>("");

  // Fetch complete state from backend
  const fetchState = async () => {
    try {
      const res = await fetch("/api/state");
      const data = await res.json();
      setMarkets(data.markets || []);
      setProducts(data.products || []);
      setParticipants(data.participants || []);
      setOrders(data.orders || []);
      setExecutions(data.executions || []);
      setTrades(data.trades || []);
      setPositions(data.positions || []);
      setNominations(data.nominations || []);
      setDeliveries(data.deliveries || []);
      setCertificates(data.certificates || []);
      setLedgerEntries(data.ledgerEntries || []);
      setMarginCalls(data.marginCalls || []);
      setAlerts(data.alerts || []);
      setAuditEvents(data.auditEvents || []);
      setTickers(data.tickers || []);
      setIsSimulationActive(data.isSimulationActive);
      setIsConnected(true);
    } catch (err) {
      console.error("Error fetching state:", err);
      setIsConnected(false);
    }
  };

  // Connect SSE real-time stream
  useEffect(() => {
    fetchState();

    // Exchange clock runner (deterministic sequence display)
    const clockInterval = setInterval(() => {
      setExchangeClock(new Date().toISOString());
    }, 1000);

    const sse = new EventSource("/api/stream");
    
    sse.onopen = () => {
      setIsConnected(true);
    };

    sse.onmessage = (event) => {
      try {
        const update = JSON.parse(event.data);
        // Refresh state optimistically on SSE update signals
        fetchState();
      } catch (err) {
        console.error("Error processing SSE message:", err);
      }
    };

    sse.onerror = () => {
      setIsConnected(false);
    };

    return () => {
      sse.close();
      clearInterval(clockInterval);
    };
  }, []);

  // --- API Action Triggers ---

  const handleSubmitOrder = async (orderData: any) => {
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData)
      });
      const data = await res.json();
      if (!data.success) {
        alert(`Order Rejected: ${data.error || "Pre-trade risk gateway block."}`);
      }
    } catch (err) {
      console.error("Submit order failed:", err);
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      await fetch(`/api/orders/${orderId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ operator_id: "TRADING_DESK" })
      });
    } catch (err) {
      console.error("Cancel order failed:", err);
    }
  };

  const handleStepDelivery = async (deliveryId: string) => {
    try {
      await fetch(`/api/deliveries/${deliveryId}/step`, {
        method: "POST"
      });
    } catch (err) {
      console.error("Progress delivery failed:", err);
    }
  };

  const handleDepositCollateral = async (participantId: string, amountCents: number) => {
    try {
      const res = await fetch("/api/collateral/deposit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participant_id: participantId, amount_cents: amountCents })
      });
      const data = await res.json();
      if (!data.success) {
        alert(data.error || "Collateral transaction rejected.");
      }
    } catch (err) {
      console.error("Deposit collateral failed:", err);
    }
  };

  const handleClearAlert = async (alertId: string) => {
    try {
      await fetch("/api/risk/clear-alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ alert_id: alertId })
      });
    } catch (err) {
      console.error("Clear alert failed:", err);
    }
  };

  const handleUpdateSession = async (marketId: string, session: string) => {
    try {
      await fetch("/api/admin/set-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ market_id: marketId, session, operator_id: "EXCHANGE_OPERATIONS" })
      });
    } catch (err) {
      console.error("Set session failed:", err);
    }
  };

  const handleUpdateExecutionRule = async (marketId: string, rule: string) => {
    try {
      await fetch("/api/admin/configure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ market_id: marketId, rule })
      });
    } catch (err) {
      console.error("Update pricing rule failed:", err);
    }
  };

  const handleRunDemo = async (demoId: number) => {
    try {
      await fetch("/api/simulation/demo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ demoId })
      });
    } catch (err) {
      console.error("Run demo failed:", err);
    }
  };

  const handleToggleSimulation = async (active: boolean) => {
    try {
      const res = await fetch("/api/simulation/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active })
      });
      const data = await res.json();
      setIsSimulationActive(data.isSimulationActive);
    } catch (err) {
      console.error("Toggle simulation failed:", err);
    }
  };

  const selectedTicker = tickers.find(t => t.product_id === selectedProductId);
  const activeProduct = products.find(p => p.product_id === selectedProductId);

  // Total daily exchange stats
  const totalExecVol = tickers.reduce((sum, t) => sum + t.volume, 0);
  const totalExecCount = tickers.reduce((sum, t) => sum + t.number_of_trades, 0);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f4f4f4] flex flex-col font-sans select-none antialiased selection:bg-[#e3b341] selection:text-[#111]">
      
      {/* 1. INSTITUTIONAL TOP STEWARDS BAR */}
      <header className="bg-[#111111] border-b border-[#2b2b2b] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-6 w-2.5 bg-[#e3b341]" />
          <div className="flex flex-col">
            <h1 className="text-[14px] uppercase font-bold tracking-widest text-[#f4f4f4] leading-none">
              RHINO H2 EXECUTABLE
            </h1>
            <span className="text-[8.5px] font-mono tracking-widest text-[#888] uppercase mt-1">
              Institutional Hydrogen Spot Exchange • Codename: RHINO H2-X
            </span>
          </div>
        </div>

        {/* Global stats ticking */}
        <div className="flex items-center gap-6 text-[10px] font-mono">
          <div className="flex items-center gap-1.5">
            <Clock size={11} className="text-[#888]" />
            <span className="text-[#888]">EXCHANGE TIME:</span>
            <span className="text-[#fff]">{exchangeClock.substring(11, 19)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Activity size={11} className="text-[#888]" />
            <span className="text-[#888]">24H VOL:</span>
            <span className="text-[#2ebd59] font-bold">{totalExecVol.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Terminal size={11} className="text-[#888]" />
            <span className="text-[#888]">MATCHES:</span>
            <span className="text-[#e3b341] font-bold">{totalExecCount}</span>
          </div>
          <div className="flex items-center gap-1.5 border-l border-[#222] pl-6">
            <div className={`h-2 w-2 rounded-full ${isConnected ? "bg-[#2ebd59]" : "bg-[#ff5f5f]"}`} />
            <span className="text-[#888]">ENGINE:</span>
            <span className="text-[#fff]">{isConnected ? "SYNCHRONIZED" : "STALE"}</span>
          </div>
        </div>
      </header>

      {/* 2. CORE WORKSPACE GRID */}
      <main className="flex-1 grid grid-cols-12 gap-4 p-4 min-h-0">
        
        {/* Left Side: Markets Channels & Ticker Lists */}
        <div className="col-span-3 flex flex-col gap-3 bg-[#111111] border border-[#2b2b2b] p-4 h-[710px] overflow-y-auto">
          <span className="text-[12px] uppercase font-semibold text-[#8a8a8a] tracking-wider border-b border-[#1f1f1f] pb-1.5 mb-1 flex items-center gap-1.5">
            <Globe size={12} className="text-[#888]" /> Spot Market Hubs
          </span>
          <div className="flex flex-col gap-2">
            {products.map(prod => {
              const tick = tickers.find(t => t.product_id === prod.product_id);
              const isSelected = selectedProductId === prod.product_id;
              
              return (
                <div
                  key={prod.product_id}
                  onClick={() => setSelectedProductId(prod.product_id)}
                  className={`p-3 border transition-all cursor-pointer flex flex-col gap-1.5 rounded-none ${
                    isSelected
                      ? "bg-[#1f1a10] border-[#e3b341]"
                      : "bg-[#141414] border-[#222] hover:border-[#444]"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-[11px] font-bold text-[#f4f4f4] truncate max-w-[170px]">
                      {prod.name}
                    </span>
                    <span className="text-[8px] bg-[#1a1a1a] px-1 py-0.2 border border-[#333] text-[#888] font-mono">
                      {prod.product_id.split("-").pop()}
                    </span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-[#888]">Last Cleared:</span>
                    <span className="text-[#fff] font-bold">
                      {tick && tick.last > 0 ? `${tick.last.toFixed(2)} EUR/kg` : "Awaiting Trade"}
                    </span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono border-t border-[#1a1a1a] pt-1">
                    <span className="text-[#555]">Spread: {tick && tick.bid && tick.ask ? `${(tick.ask - tick.bid).toFixed(2)}` : "-"}</span>
                    <span className="text-[#555]">24h Vol: {tick ? tick.volume.toLocaleString() : "0"} kg</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-[#141414] border border-[#222] p-3 text-[10px] leading-relaxed mt-auto font-mono text-[#666]">
            <span className="text-[#e3b341] font-bold block mb-1 uppercase text-[11px] flex items-center gap-1">
              <Database size={11} /> Real Matching Engine
            </span>
            Hydrogen Spot contracts are clearing-house validated. Every matched execution triggers atomic cash ledger double-entry and schedules physical pipelining with certified GO certificates.
          </div>
        </div>

        {/* Center: Dynamic Charts, Order Books and Live Tape */}
        <div className="col-span-6 flex flex-col gap-4">
          {/* Top Row: Price discoveries graph */}
          <Chart productId={selectedProductId} trades={trades} />

          {/* Bottom Row: Order book and Live execution tape side-by-side */}
          <div className="grid grid-cols-2 gap-4">
            <OrderBook 
              productId={selectedProductId} 
              orders={orders} 
              tickerLast={selectedTicker?.last}
              tickerBid={selectedTicker?.bid}
              tickerAsk={selectedTicker?.ask}
            />
            <TimeAndSales 
              productId={selectedProductId} 
              trades={trades} 
              participants={participants} 
            />
          </div>
        </div>

        {/* Right Side: Order Ticket Panel & Demonstrator */}
        <div className="col-span-3">
          <OrderEntry
            productId={selectedProductId}
            products={products}
            participants={participants}
            onSubmitOrder={handleSubmitOrder}
            isSimulationActive={isSimulationActive}
            onToggleSimulation={handleToggleSimulation}
            onRunDemo={handleRunDemo}
          />
        </div>

      </main>

      {/* 3. MULTI-TAB TRADING LEDGER & BLOTTER */}
      <footer className="mt-auto px-4 pb-4">
        <BlotterTabs
          productId={selectedProductId}
          orders={orders}
          trades={trades}
          positions={positions}
          deliveries={deliveries}
          nominations={nominations}
          certificates={certificates}
          ledgerEntries={ledgerEntries}
          marginCalls={marginCalls}
          alerts={alerts}
          auditEvents={auditEvents}
          participants={participants}
          onCancelOrder={handleCancelOrder}
          onStepDelivery={handleStepDelivery}
          onDepositCollateral={handleDepositCollateral}
          onClearAlert={handleClearAlert}
          onUpdateSession={handleUpdateSession}
          onUpdateExecutionRule={handleUpdateExecutionRule}
        />
      </footer>
    </div>
  );
}
