import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { ExchangeEngine } from "./src/engine";
import { Side, OrderType, MarketSession } from "./src/types";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Instantiate the Exchange Engine
  const engine = new ExchangeEngine();

  // Active SSE Clients to stream events real-time
  let sseClients: any[] = [];

  // Broadcast helper to trigger instant UI updates
  function broadcastUpdate(type: string, payload?: any) {
    const data = JSON.stringify({ type, timestamp: new Date().toISOString(), payload });
    sseClients.forEach(client => {
      client.write(`data: ${data}\n\n`);
    });
  }

  // Set simulation loop to run every 3 seconds to keep order book alive
  setInterval(() => {
    if (engine.isSimulationActive) {
      engine.performSimulationStep();
      broadcastUpdate("SIMULATION_TICK", { tickers: engine.getTickers() });
    }
  }, 3000);

  // --- API ROUTING ---

  // SSE Stream Endpoint
  app.get("/api/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    sseClients.push(res);

    req.on("close", () => {
      sseClients = sseClients.filter(client => client !== res);
    });
  });

  // Get full state
  app.get("/api/state", (req, res) => {
    res.json({
      markets: engine.markets,
      products: engine.products,
      participants: engine.participants,
      orders: engine.orders,
      executions: engine.executions,
      trades: engine.trades,
      positions: engine.positions,
      nominations: engine.nominations,
      deliveries: engine.deliveries,
      certificates: engine.certificates,
      ledgerEntries: engine.ledgerEntries,
      marginCalls: engine.marginCalls,
      alerts: engine.alerts,
      auditEvents: engine.auditEvents,
      tickers: engine.getTickers(),
      isSimulationActive: engine.isSimulationActive
    });
  });

  // Submit new order
  app.post("/api/orders", (req, res) => {
    const { client_order_id, participant_id, market_id, product_id, side, order_type, quantity, price, delivery_point, delivery_window, time_in_force } = req.body;

    try {
      const order = engine.submitOrder({
        client_order_id: client_order_id || `CL-${Date.now()}`,
        participant_id,
        market_id,
        product_id,
        side: side as Side,
        order_type: order_type as OrderType,
        quantity: Number(quantity),
        price: Number(price),
        priceCents: Math.round(Number(price) * 100),
        delivery_point,
        delivery_window: delivery_window || "DAY-AHEAD",
        time_in_force: time_in_force || "GTC"
      });

      broadcastUpdate("ORDER_PROCESSED", { order, tickers: engine.getTickers() });
      res.json({ success: true, order });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Cancel order
  app.delete("/api/orders/:id", (req, res) => {
    const orderId = req.params.id;
    const { operator_id } = req.body;
    const cancelled = engine.cancelOrder(orderId, operator_id || "SYSTEM");

    if (cancelled) {
      broadcastUpdate("ORDER_CANCELLED", { orderId, tickers: engine.getTickers() });
      res.json({ success: true });
    } else {
      res.status(400).json({ success: false, error: "Order cannot be cancelled" });
    }
  });

  // Get single order book details
  app.get("/api/orderbook", (req, res) => {
    const marketId = req.query.market_id as string;
    if (!marketId) {
      res.status(400).json({ error: "Missing market_id parameter" });
      return;
    }

    const activeOrders = engine.orders.filter(
      o => o.market_id === marketId && (o.status === "RESTING" || o.status === "PARTIALLY_FILLED")
    );

    const bids = activeOrders
      .filter(o => o.side === Side.BUY)
      .sort((a, b) => b.priceCents - a.priceCents || a.sequence_number - b.sequence_number)
      .map(o => ({ order_id: o.order_id, price: o.price, quantity: o.quantity - o.filled_quantity, participant_id: o.participant_id }));

    const asks = activeOrders
      .filter(o => o.side === Side.SELL)
      .sort((a, b) => a.priceCents - b.priceCents || a.sequence_number - b.sequence_number)
      .map(o => ({ order_id: o.order_id, price: o.price, quantity: o.quantity - o.filled_quantity, participant_id: o.participant_id }));

    res.json({ bids, asks });
  });

  // Fetch lists
  app.get("/api/trades", (req, res) => res.json(engine.trades));
  app.get("/api/positions", (req, res) => res.json(engine.positions));
  app.get("/api/markets", (req, res) => res.json(engine.markets));
  app.get("/api/deliveries", (req, res) => res.json(engine.deliveries));
  app.get("/api/risk", (req, res) => res.json({ alerts: engine.alerts, marginCalls: engine.marginCalls }));
  app.get("/api/market-data", (req, res) => res.json(engine.getTickers()));

  // Admin and configuration endpoints
  app.post("/api/admin/set-session", (req, res) => {
    const { market_id, session, operator_id } = req.body;
    engine.updateMarketSession(market_id, session as MarketSession, operator_id || "ADMIN");
    broadcastUpdate("MARKET_SESSION_CHANGED", { market_id, session });
    res.json({ success: true });
  });

  app.post("/api/admin/configure", (req, res) => {
    const { market_id, rule } = req.body;
    const market = engine.markets.find(m => m.id === market_id);
    if (market) {
      market.executionRule = rule;
      broadcastUpdate("MARKET_CONFIG_CHANGED", { market_id, rule });
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Market not found" });
    }
  });

  // Collateral deposit
  app.post("/api/collateral/deposit", (req, res) => {
    const { participant_id, amount_cents } = req.body;
    const success = engine.depositCollateral(participant_id, Number(amount_cents));
    if (success) {
      broadcastUpdate("COLLATERAL_DEPOSITED", { participant_id });
      res.json({ success: true });
    } else {
      res.status(400).json({ error: "Insufficient cash balance or invalid participant" });
    }
  });

  // Progress Delivery steps
  app.post("/api/deliveries/:id/step", (req, res) => {
    const deliveryId = req.params.id;
    const { custom_measured_qty, custom_purity } = req.body;

    try {
      const del = engine.progressDelivery(deliveryId, custom_measured_qty, custom_purity);
      broadcastUpdate("DELIVERY_PROGRESSED", { delivery: del });
      res.json({ success: true, delivery: del });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Clear surveillance alerts
  app.post("/api/risk/clear-alert", (req, res) => {
    const { alert_id } = req.body;
    engine.alerts = engine.alerts.filter(a => a.alert_id !== alert_id);
    broadcastUpdate("ALERTS_UPDATED");
    res.json({ success: true });
  });

  // Simulation controls
  app.post("/api/simulation/toggle", (req, res) => {
    const { active } = req.body;
    engine.isSimulationActive = !!active;
    broadcastUpdate("SIMULATION_STATE_CHANGED", { active: engine.isSimulationActive });
    res.json({ success: true, isSimulationActive: engine.isSimulationActive });
  });

  // Execute explicit Demo Scenario
  app.post("/api/simulation/demo", (req, res) => {
    const { demoId } = req.body;
    engine.executeDemo(Number(demoId));
    broadcastUpdate("DEMO_EXECUTED", { demoId, tickers: engine.getTickers() });
    res.json({ success: true });
  });

  // Vite static middleware for SPA frontend client
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RHINO H2 exchange engine server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
