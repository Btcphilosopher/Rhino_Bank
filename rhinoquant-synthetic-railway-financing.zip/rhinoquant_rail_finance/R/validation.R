#' Financial Identity and Balance Sheet Validation Engine
#'
#' @description Verifies financial accounting identities, debt amortisation balance
#' reconciliation, discount factor monotonicity, and cash waterfall conservation of funds.
#' @param cashflows_dt data.table containing cashflows.
#' @param debt_schedule_dt data.table containing debt schedule.
#' @return A list with validation flags and reconciliation tolerances.
#' @export
validate_project_assumptions <- function(cashflows_dt = NULL, debt_schedule_dt = NULL) {
  checks <- list()
  
  # Identity 1: Cash flow conservation: EBITDA = Revenue - OPEX
  if (!is.null(cashflows_dt)) {
    reconciled_ebitda <- abs((cashflows_dt$gross_revenue_m - cashflows_dt$operating_costs_m) - cashflows_dt$ebitda_m) < 0.05
    checks$ebitda_identity_valid <- all(reconciled_ebitda)
  }
  
  # Identity 2: Debt Balance roll-forward: Opening - Principal = Closing
  if (!is.null(debt_schedule_dt)) {
    reconciled_bal <- abs((debt_schedule_dt$opening_balance_m - debt_schedule_dt$principal_m) - debt_schedule_dt$closing_balance_m) < 0.05
    checks$debt_balance_rollforward_valid <- all(reconciled_bal)
    
    # Final balance must be zero at maturity
    checks$debt_fully_amortised <- (tail(debt_schedule_dt$closing_balance_m, 1) < 0.1)
  }
  
  checks$all_identities_pass <- all(unlist(checks))
  checks$validation_timestamp <- Sys.time()
  checks$audit_model_version <- "RHINO-V1.0.0-PROD-VALIDATED"
  
  return(checks)
}

#' Economic Impact and Wider Policy Value Added
#'
#' @description Models direct construction GVA, indirect supply-chain multiplier,
#' passenger travel time savings, and carbon emissions reduction benefits.
#' @param route_km Numeric. Length of route.
#' @param annual_pax_m Numeric. Annual passenger volume in millions.
#' @param base_capex_m Numeric. Total construction capital investment.
#' @param time_saved_min_per_trip Numeric. Average journey minutes saved versus road/air.
#' @param value_of_time_eur_hr Numeric. Department of Transport standard value of time (e.g. 28.5 EUR/hr).
#' @param co2_saved_kg_per_pax Numeric. Net kg CO2 avoided per rail journey vs road/air counterfactual.
#' @param carbon_price_eur_tonne Numeric. Social cost of carbon (e.g. 95 EUR / tonne).
#' @return A list of economic benefit measures.
#' @export
calculate_economic_impact <- function(route_km = 340,
                                      annual_pax_m = 14.5,
                                      base_capex_m = 8450,
                                      time_saved_min_per_trip = 65,
                                      value_of_time_eur_hr = 28.5,
                                      co2_saved_kg_per_pax = 34.0,
                                      carbon_price_eur_tonne = 95.0) {
  # Direct & Indirect GVA (Leontief Type II Multiplier 1.85x typical for European Rail Civil Works)
  direct_gva_m <- base_capex_m * 0.42
  indirect_induced_gva_m <- direct_gva_m * 0.85
  total_gva_m <- direct_gva_m + indirect_induced_gva_m
  
  # Employment created (Direct job-years per million EUR spent: approx 11.2)
  direct_job_years <- round(base_capex_m * 11.2)
  
  # Annual User Benefits: Travel Time Savings
  total_hours_saved_m <- (annual_pax_m * 1e6 * (time_saved_min_per_trip / 60)) / 1e6
  annual_time_benefit_m <- total_hours_saved_m * value_of_time_eur_hr
  
  # Annual Environmental Benefits: Decarbonisation
  annual_co2_tonnes_avoided <- (annual_pax_m * 1e6 * co2_saved_kg_per_pax) / 1000
  annual_carbon_benefit_m <- (annual_co2_tonnes_avoided * carbon_price_eur_tonne) / 1e6
  
  list(
    total_gva_economic_m = round(total_gva_m, 1),
    direct_job_years = direct_job_years,
    annual_passenger_hours_saved_m = round(total_hours_saved_m, 2),
    annual_user_time_benefit_m = round(annual_time_benefit_m, 2),
    annual_co2_abated_tonnes = round(annual_co2_tonnes_avoided, 0),
    annual_carbon_social_value_m = round(annual_carbon_benefit_m, 2),
    note = "Economic evaluation separated from SPV commercial cash flows; no double-counting with farebox revenues."
  )
}
