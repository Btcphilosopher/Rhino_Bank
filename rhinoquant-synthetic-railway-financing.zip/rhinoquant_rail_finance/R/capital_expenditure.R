#' Railway Capacity and Headway Engine
#'
#' @description Calculates theoretical and practical railway line capacity
#' from physical signalling headways, junction margins, dwell times, and fleet sizing.
#' @param signalling_category Character. E.g. "ETCS Level 2 with ATO", "CBTC GoA4", "3-Aspect Colour Light"
#' @param avg_speed_kmh Numeric. Commercial average operating speed.
#' @param min_station_dwell_sec Numeric. Minimum dwell time at stations.
#' @param junction_margin_sec Numeric. Buffer margin for junction interlocking.
#' @param track_pairs Integer. Number of running track pairs (1 = double track, 2 = 4-track).
#' @return A list with theoretical headway, maximum trains per hour per direction (tph), and fleet requirements.
#' @export
calculate_capacity_headway <- function(signalling_category = "ETCS Level 2 with ATO",
                                       avg_speed_kmh = 240,
                                       min_station_dwell_sec = 120,
                                       junction_margin_sec = 45,
                                       track_pairs = 1) {
  # Signalling technical minimum headway in seconds
  sig_min_sec <- switch(signalling_category,
    "CBTC GoA4 Driverless" = 75,
    "ETCS Level 2 with ATO" = 120,
    "ETCS Level 1" = 180,
    "4-Aspect Colour Light" = 150,
    "3-Aspect Colour Light" = 210,
    150
  )
  
  # Practical headway accounting for terminal/station dwell and junction buffer
  practical_headway_sec <- max(sig_min_sec, min_station_dwell_sec + junction_margin_sec)
  
  # Max train paths per hour per direction
  tph_single_pair <- floor(3600 / practical_headway_sec * 0.85) # 85% UIC 406 utilization rule
  total_tph <- tph_single_pair * track_pairs
  
  list(
    signalling_min_headway_sec = sig_min_sec,
    practical_headway_sec = practical_headway_sec,
    uic406_practical_tph_per_direction = total_tph,
    daily_capacity_trains = total_tph * 18 * 2 # 18 operational hours, bi-directional
  )
}

#' Capital Expenditure and Construction Profile
#'
#' @description Models phased construction capital expenditure, cost escalation,
#' delay distribution, and capitalised interest during construction (IDC).
#' @param base_capex_m Numeric. Base unescalated capital cost in millions.
#' @param duration_years Integer. Construction period in years.
#' @param contingency_pct Numeric. Contingency buffer percentage (e.g. 0.15 = 15%).
#' @param real_cost_escalation_pct Numeric. Real cost escalation per year.
#' @param general_inflation_pct Numeric. Inflation indexation.
#' @param construction_debt_rate Numeric. Interest rate charged on capex borrowing.
#' @param debt_funding_ratio Numeric. Fraction of capex funded by senior debt.
#' @return A data.table containing annual capex drawdowns, escalated costs, and IDC.
#' @export
calculate_capex_profile <- function(base_capex_m,
                                    duration_years = 5,
                                    contingency_pct = 0.15,
                                    real_cost_escalation_pct = 0.02,
                                    general_inflation_pct = 0.025,
                                    construction_debt_rate = 0.05,
                                    debt_funding_ratio = 0.70) {
  # Standard S-Curve distribution weights for railway infrastructure
  s_curve_weights <- if (duration_years == 4) {
    c(0.12, 0.35, 0.38, 0.15)
  } else if (duration_years == 5) {
    c(0.08, 0.22, 0.35, 0.25, 0.10)
  } else if (duration_years == 6) {
    c(0.06, 0.16, 0.28, 0.28, 0.16, 0.06)
  } else if (duration_years == 7) {
    c(0.05, 0.12, 0.22, 0.26, 0.20, 0.11, 0.04)
  } else {
    rep(1 / duration_years, duration_years)
  }
  
  contingency_m <- base_capex_m * contingency_pct
  total_base_and_contingency <- base_capex_m + contingency_m
  
  dt <- data.table::data.table(
    year = 1:duration_years,
    s_curve_weight = s_curve_weights,
    base_capex = base_capex_m * s_curve_weights,
    contingency = contingency_m * s_curve_weights
  )
  
  dt[, nominal_escalation_factor := (1 + real_cost_escalation_pct + general_inflation_pct)^(year - 1)]
  dt[, escalated_capex := (base_capex + contingency) * nominal_escalation_factor]
  
  # Debt drawdown and Interest During Construction (IDC)
  dt[, debt_drawn := escalated_capex * debt_funding_ratio]
  dt[, equity_drawn := escalated_capex * (1 - debt_funding_ratio)]
  
  cumulative_debt <- 0
  idc_vector <- numeric(duration_years)
  for (i in 1:duration_years) {
    mid_year_balance <- cumulative_debt + (dt$debt_drawn[i] / 2)
    idc_vector[i] <- mid_year_balance * construction_debt_rate
    cumulative_debt <- cumulative_debt + dt$debt_drawn[i] + idc_vector[i]
  }
  dt[, interest_during_construction := idc_vector]
  dt[, total_funding_need := escalated_capex + interest_during_construction]
  
  return(dt)
}
