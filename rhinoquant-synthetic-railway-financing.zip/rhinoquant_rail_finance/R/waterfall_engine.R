#' Synthetic Structured Waterfall and Tranche Allocation Engine
#'
#' @description Models senior, mezzanine, and first-loss equity tranches,
#' applying sequential or pro-rata principal allocation, revenue shortfall absorption,
#' and performance covenant triggers.
#' @param gross_inflow_m Numeric. Cash flow inflow in millions for the period.
#' @param senior_notional_m Numeric. Senior tranche debt notional.
#' @param mezz_notional_m Numeric. Mezzanine debt notional.
#' @param first_loss_notional_m Numeric. First-loss / equity tranche notional.
#' @param senior_coupon_rate Numeric. Senior tranche interest rate.
#' @param mezz_coupon_rate Numeric. Mezzanine tranche interest rate.
#' @param reserve_topup_m Numeric. Liquidity reserve account requirement.
#' @return A list detailing allocation to senior, mezzanine, reserve, and first-loss tranche.
#' @export
calculate_waterfall_allocation <- function(gross_inflow_m,
                                           senior_notional_m = 500,
                                           mezz_notional_m = 150,
                                           first_loss_notional_m = 100,
                                           senior_coupon_rate = 0.045,
                                           mezz_coupon_rate = 0.075,
                                           reserve_topup_m = 10) {
  senior_interest_due <- senior_notional_m * senior_coupon_rate
  mezz_interest_due <- mezz_notional_m * mezz_coupon_rate
  
  rem_cash <- gross_inflow_m
  
  # Step 1: Senior Interest
  senior_interest_paid <- min(rem_cash, senior_interest_due)
  rem_cash <- rem_cash - senior_interest_paid
  senior_shortfall <- senior_interest_due - senior_interest_paid
  
  # Step 2: Mezzanine Interest
  mezz_interest_paid <- min(rem_cash, mezz_interest_due)
  rem_cash <- rem_cash - mezz_interest_paid
  mezz_shortfall <- mezz_interest_due - mezz_interest_paid
  
  # Step 3: Debt Service Reserve Account (DSRA) Top-up
  reserve_funded <- min(rem_cash, reserve_topup_m)
  rem_cash <- rem_cash - reserve_funded
  
  # Step 4: First-loss Residual Distribution (Equity / Synthetic First Loss)
  equity_distribution <- rem_cash
  
  # Shortfall absorbed by first-loss equity notional if cash insufficient for debt service
  total_shortfall <- senior_shortfall + mezz_shortfall
  first_loss_impairment <- min(first_loss_notional_m, total_shortfall)
  
  list(
    gross_inflow_m = gross_inflow_m,
    senior_interest_paid = senior_interest_paid,
    senior_shortfall = senior_shortfall,
    mezz_interest_paid = mezz_interest_paid,
    mezz_shortfall = mezz_shortfall,
    reserve_funded = reserve_funded,
    equity_distribution = equity_distribution,
    first_loss_impairment = first_loss_impairment,
    is_senior_impaired = (senior_shortfall > 0)
  )
}

#' Monte Carlo Infrastructure Risk Simulation Engine
#'
#' @description Performs stochastic simulations across correlated construction cost overruns,
#' revenue shortfalls, interest rate shocks, and delay distributions.
#' @param n_sims Integer. Number of Monte Carlo simulation runs (e.g. 5000).
#' @param base_capex_m Numeric. Base capital cost in millions.
#' @param base_cfads_annual Numeric. Base annual CFADS.
#' @param debt_service_annual Numeric. Annual scheduled debt service.
#' @param capex_volatility Numeric. Standard deviation of construction cost overrun (e.g. 0.18).
#' @param revenue_volatility Numeric. Volatility of operational revenues (e.g. 0.12).
#' @param rate_volatility_bps Numeric. Standard deviation of interest rate shocks in bps.
#' @return A list containing NPV distribution percentiles, breach probabilities, and CVaR 95%.
#' @export
run_monte_carlo_simulation <- function(n_sims = 2000,
                                       base_capex_m = 6500,
                                       base_cfads_annual = 360,
                                       debt_service_annual = 250,
                                       capex_volatility = 0.18,
                                       revenue_volatility = 0.14,
                                       rate_volatility_bps = 75) {
  set.seed(42)
  
  # Simulating correlated shocks using standard normal draws
  z1 <- stats::rnorm(n_sims)
  z2 <- 0.45 * z1 + sqrt(1 - 0.45^2) * stats::rnorm(n_sims) # Correlation between macro cost and revenue
  
  # Log-normal capex overrun multipliers
  sim_capex <- base_capex_m * exp(capex_volatility * z1 - 0.5 * capex_volatility^2)
  
  # Revenue multipliers
  sim_cfads <- base_cfads_annual * exp(revenue_volatility * z2 - 0.5 * revenue_volatility^2)
  
  # Simulated DSCR
  sim_dscr <- sim_cfads / debt_service_annual
  
  # 25-year discounted cash flows at 6.0% hurdle
  r <- 0.06
  pv_factor <- (1 - (1 + r)^(-25)) / r
  sim_project_npv <- (sim_cfads * pv_factor) - sim_capex
  
  # DSCR Breach condition (< 1.20x covenant)
  breach_count <- sum(sim_dscr < 1.20)
  breach_prob <- breach_count / n_sims
  
  # Value at Risk and Conditional VaR (Expected Shortfall) at 95%
  q05_npv <- stats::quantile(sim_project_npv, 0.05)
  cvar_95 <- mean(sim_project_npv[sim_project_npv <= q05_npv])
  
  list(
    n_simulations = n_sims,
    mean_npv_m = round(mean(sim_project_npv), 2),
    median_npv_m = round(stats::median(sim_project_npv), 2),
    p10_npv_m = round(stats::quantile(sim_project_npv, 0.10), 2),
    p90_npv_m = round(stats::quantile(sim_project_npv, 0.90), 2),
    var_95_npv_m = round(q05_npv, 2),
    cvar_95_npv_m = round(cvar_95, 2),
    dscr_breach_probability = round(breach_prob, 4),
    mean_dscr = round(mean(sim_dscr), 3),
    min_dscr = round(min(sim_dscr), 3)
  )
}
