#' Project Cash Flow and Waterfall Engine
#'
#' @description Computes full operational cash flows, EBITDA, CFADS, tax,
#' debt service, reserve accounts, and distributions over concession lifecycle.
#' @param ops_years Integer. Operating duration in years (e.g. 30).
#' @param initial_revenue_m Numeric. Starting annual revenue in millions.
#' @param initial_opex_m Numeric. Starting annual opex in millions.
#' @param rev_growth_pct Numeric. Long-term annual revenue growth rate.
#' @param opex_inflation_pct Numeric. Annual opex cost escalation.
#' @param tax_rate Numeric. Corporate income tax rate (e.g. 0.25).
#' @param lifecycle_renewal_interval Integer. Years between major track/rolling stock overhauls.
#' @param lifecycle_renewal_cost_m Numeric. Major periodic renewal cost.
#' @return A data.table containing annual revenue, opex, EBITDA, tax, CFADS.
#' @export
calculate_project_cashflows <- function(ops_years = 30,
                                        initial_revenue_m = 480,
                                        initial_opex_m = 175,
                                        rev_growth_pct = 0.025,
                                        opex_inflation_pct = 0.022,
                                        tax_rate = 0.25,
                                        lifecycle_renewal_interval = 10,
                                        lifecycle_renewal_cost_m = 150) {
  years <- 1:ops_years
  
  revenue <- initial_revenue_m * ((1 + rev_growth_pct)^(years - 1))
  opex <- initial_opex_m * ((1 + opex_inflation_pct)^(years - 1))
  ebitda <- revenue - opex
  
  # Major lifecycle periodic renewals (track renewals, signalling upgrades, pantograph catenary)
  renewals <- numeric(ops_years)
  for (y in seq(lifecycle_renewal_interval, ops_years, by = lifecycle_renewal_interval)) {
    renewals[y] <- lifecycle_renewal_cost_m * ((1 + opex_inflation_pct)^(y - 1))
  }
  
  # Approximate tax liability on taxable earnings after renewal expensing / depreciation
  taxable_income <- pmax(0, ebitda - renewals * 0.5)
  tax <- taxable_income * tax_rate
  
  # Cash Flow Available for Debt Service (CFADS)
  cfads <- ebitda - tax - renewals
  
  dt <- data.table::data.table(
    operating_year = years,
    gross_revenue_m = round(revenue, 2),
    operating_costs_m = round(opex, 2),
    ebitda_m = round(ebitda, 2),
    major_renewals_m = round(renewals, 2),
    corporate_tax_m = round(tax, 2),
    cfads_m = round(cfads, 2)
  )
  
  return(dt)
}

#' Project Finance Debt Scheduling and DSCR Sculpting Engine
#'
#' @description Computes senior debt amortisation schedules under sculpted target DSCR or annuity repayment.
#' @param total_debt_m Numeric. Initial debt principal to amortise.
#' @param cfads_vector Numeric vector. Annual Cash Flow Available for Debt Service.
#' @param tenor_years Integer. Debt maturity in years.
#' @param interest_rate Numeric. Annual fixed or hedged interest rate.
#' @param target_dscr Numeric. Target debt service coverage ratio for sculpted repayment.
#' @return A data.table containing opening balance, interest, principal, debt service, DSCR, LLCR.
#' @export
calculate_debt_schedule <- function(total_debt_m,
                                    cfads_vector,
                                    tenor_years = 22,
                                    interest_rate = 0.048,
                                    target_dscr = 1.35) {
  n <- min(tenor_years, length(cfads_vector))
  cfads <- cfads_vector[1:n]
  
  # Target-DSCR sculpted debt sizing:
  # Sculpted Debt Service_t = CFADS_t / Target_DSCR
  # Principal_t = Debt Service_t - Interest_t
  opening_bal <- numeric(n)
  interest <- numeric(n)
  principal <- numeric(n)
  debt_service <- numeric(n)
  closing_bal <- numeric(n)
  dscr <- numeric(n)
  
  curr_balance <- total_debt_m
  for (t in 1:n) {
    opening_bal[t] <- curr_balance
    interest[t] <- curr_balance * interest_rate
    
    # Sculpted target debt service capped to avoid negative amortisation
    ideal_ds <- cfads[t] / target_dscr
    calc_principal <- ideal_ds - interest[t]
    
    # Handle end of tenor payoff
    if (t == n || calc_principal >= curr_balance) {
      principal[t] <- curr_balance
      debt_service[t] <- principal[t] + interest[t]
      curr_balance <- 0
    } else {
      principal[t] <- max(0, calc_principal)
      debt_service[t] <- principal[t] + interest[t]
      curr_balance <- curr_balance - principal[t]
    }
    closing_bal[t] <- curr_balance
    dscr[t] <- ifelse(debt_service[t] > 0, cfads[t] / debt_service[t], NA)
  }
  
  # Calculate Loan Life Coverage Ratio (LLCR)
  # LLCR_t = NPV(CFADS from t to Tenor at interest rate) / Opening_Debt_t
  llcr <- numeric(n)
  for (t in 1:n) {
    remaining_years <- (t:n) - t + 1
    disc_factors <- (1 + interest_rate)^(-remaining_years)
    npv_cfads <- sum(cfads[t:n] * disc_factors)
    llcr[t] <- ifelse(opening_bal[t] > 0, npv_cfads / opening_bal[t], NA)
  }
  
  dt <- data.table::data.table(
    year = 1:n,
    cfads_m = round(cfads, 2),
    opening_balance_m = round(opening_bal, 2),
    interest_m = round(interest, 2),
    principal_m = round(principal, 2),
    debt_service_m = round(debt_service, 2),
    closing_balance_m = round(closing_bal, 2),
    dscr = round(dscr, 3),
    llcr = round(llcr, 3)
  )
  
  return(dt)
}
