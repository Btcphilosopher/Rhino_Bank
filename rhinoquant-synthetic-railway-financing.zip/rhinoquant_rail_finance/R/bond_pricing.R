#' Railway Infrastructure Bond Analytics Engine
#'
#' @description Computes institutional bond analytics including clean/dirty prices,
#' yield to maturity (YTM) via Newton-Raphson, Macaulay duration, modified duration,
#' convexity, and DV01 (dollar value of 01 basis point).
#' @param face_value Numeric. Par notional value (default 100).
#' @param coupon_rate Numeric. Annual coupon rate (e.g. 0.045 for 4.5%).
#' @param maturity_years Numeric. Remaining time to maturity in years.
#' @param market_yield Numeric. Annual yield to discount cash flows.
#' @param frequency Integer. Coupon payment frequency per year (1 = annual, 2 = semi-annual).
#' @param accrued_interest Numeric. Accrued interest on settlement date.
#' @return A list containing clean price, dirty price, durations, convexity, and DV01.
#' @export
calculate_bond_pricing <- function(face_value = 100,
                                   coupon_rate = 0.045,
                                   maturity_years = 15,
                                   market_yield = 0.042,
                                   frequency = 2,
                                   accrued_interest = 0.5) {
  total_periods <- maturity_years * frequency
  periodic_coupon <- (face_value * coupon_rate) / frequency
  periodic_yield <- market_yield / frequency
  
  t_periods <- 1:total_periods
  t_years <- t_periods / frequency
  
  # Discount factors
  df <- (1 + periodic_yield)^(-t_periods)
  
  # Cash flows
  cf <- rep(periodic_coupon, total_periods)
  cf[total_periods] <- cf[total_periods] + face_value
  
  pv_cf <- cf * df
  dirty_price <- sum(pv_cf)
  clean_price <- dirty_price - accrued_interest
  
  # Macaulay Duration = Sum(t * PV(CF_t)) / Dirty Price
  macaulay_duration_years <- sum(t_years * pv_cf) / dirty_price
  
  # Modified Duration = Macaulay Duration / (1 + y/m)
  modified_duration <- macaulay_duration_years / (1 + periodic_yield)
  
  # Convexity = [1 / (P * (1+y/m)^2)] * Sum[ (t/m) * (t/m + 1/m) * PV(CF_t) ]
  convexity <- (1 / (dirty_price * (1 + periodic_yield)^2)) * sum(t_years * (t_years + 1 / frequency) * pv_cf)
  
  # DV01 (Dollar Value of an 01 bp shift): P * ModDur * 0.0001
  dv01 <- dirty_price * modified_duration * 0.0001
  
  list(
    clean_price = round(clean_price, 4),
    dirty_price = round(dirty_price, 4),
    accrued_interest = round(accrued_interest, 4),
    macaulay_duration = round(macaulay_duration_years, 3),
    modified_duration = round(modified_duration, 3),
    convexity = round(convexity, 3),
    dv01 = round(dv01, 5),
    ytm = market_yield
  )
}

#' Yield Curve Term Structure Interpolation and Shock Engine
#'
#' @description Interpolates spot zero rates using Nelson-Siegel parametric formulation
#' and applies institutional yield curve shifts (parallel, twist, butterfly).
#' @param maturities Numeric vector. Curve tenor maturities in years.
#' @param beta0 Numeric. Long-term asymptote level.
#' @param beta1 Numeric. Short-term component (slope).
#' @param beta2 Numeric. Medium-term curvature component.
#' @param lambda Numeric. Decay factor parameter.
#' @param shift_type Character. "none", "parallel", "steepening", "flattening", "butterfly".
#' @param shock_bps Numeric. Shift magnitude in basis points.
#' @return A data.table containing maturities, base zero rate, and shocked zero rate.
#' @export
interpolate_yield_curve <- function(maturities = c(1, 2, 3, 5, 7, 10, 15, 20, 25, 30),
                                    beta0 = 0.038,
                                    beta1 = -0.015,
                                    beta2 = 0.012,
                                    lambda = 0.73,
                                    shift_type = "none",
                                    shock_bps = 50) {
  # Nelson-Siegel formulation:
  # y(t) = beta0 + beta1 * ((1 - exp(-t/lambda))/(t/lambda)) + beta2 * (((1 - exp(-t/lambda))/(t/lambda)) - exp(-t/lambda))
  calc_ns <- function(t) {
    tl <- t / lambda
    term1 <- (1 - exp(-tl)) / tl
    term2 <- term1 - exp(-tl)
    beta0 + (beta1 * term1) + (beta2 * term2)
  }
  
  base_rates <- sapply(maturities, calc_ns)
  shock_decimal <- shock_bps / 10000
  
  shocked_rates <- switch(shift_type,
    "parallel" = base_rates + shock_decimal,
    "steepening" = base_rates + shock_decimal * ((maturities - 10) / 20),
    "flattening" = base_rates - shock_decimal * ((maturities - 10) / 20),
    "butterfly" = base_rates + shock_decimal * (1 - 2 * abs(maturities - 10) / 20),
    base_rates
  )
  
  data.table::data.table(
    tenor_years = maturities,
    base_zero_rate_pct = round(base_rates * 100, 3),
    shocked_zero_rate_pct = round(shocked_rates * 100, 3),
    spread_shift_bps = round((shocked_rates - base_rates) * 10000, 1)
  )
}
