# RhinoQuant Synthetic Railway Financing Platform
### Institutional Infrastructure Finance, Asset Modelling & Quantitative Risk Engine

**Rhino Bank — Infrastructure Finance & Structured Investments Division**

---

## 1. Overview
`rhinoquant.rail.finance` is an institutional quantitative package for evaluating, structuring, pricing, simulating, and stress-testing hypothetical railway infrastructure projects and synthetic financing instruments.

The platform bridges physical engineering economics (track layout, signalling headways, traction power, rolling stock fleet cycles) with structured project finance (EBITDA, Cash Flow Available for Debt Service - CFADS, target-DSCR sculpted debt amortization, waterfall seniority tranches, credit-linked notes, synthetic revenue risk-sharing, yield curves, and Monte Carlo risk simulations).

## 2. Directory Structure
```
rhinoquant_rail_finance/
├── DESCRIPTION
├── NAMESPACE
├── README.md
├── renv.lock
├── R/
│   ├── project_registry.R
│   ├── railway_asset_model.R
│   ├── railway_capacity_model.R
│   ├── demand_forecast.R
│   ├── fare_revenue.R
│   ├── freight_revenue.R
│   ├── operating_costs.R
│   ├── capital_expenditure.R
│   ├── construction_schedule.R
│   ├── project_cashflows.R
│   ├── debt_schedule.R
│   ├── bond_pricing.R
│   ├── yield_curve.R
│   ├── project_finance.R
│   ├── concession_model.R
│   ├── synthetic_instruments.R
│   ├── securitisation.R
│   ├── lease_finance.R
│   ├── refinancing.R
│   ├── waterfall_engine.R
│   ├── risk_engine.R
│   ├── scenario_engine.R
│   ├── monte_carlo.R
│   ├── optimisation.R
│   ├── portfolio_analytics.R
│   ├── reporting.R
│   └── validation.R
├── inst/
│   ├── schemas/
│   ├── templates/
│   └── extdata/
├── tests/
│   └── testthat/
├── examples/
├── reports/
│   └── investment_committee_report.qmd
├── app/
│   └── app.R
└── docs/
    └── model_limitations_and_validation.md
```

## 3. Core Analytical Framework
- **Asset Lifecycle**: Construction phase with S-curve disbursement, delay distribution, interest during construction (IDC), operational start revision.
- **Physical Capacity Model**: Signalling headway constraint, train paths per hour, junction bottleneck penalties, rolling stock turnaround cycle.
- **Revenue Engine**: Passenger trip generation, fare elasticity, freight net tonne-km, track access charges, station retail, and public availability payments.
- **Project Cash Flows**: EBITDA, tax calculations, working capital, major periodic renewal capex reserve, CFADS.
- **Debt Structuring**: Senior debt, mezzanine, subordinated loans, target-DSCR sculpting optimization, DSCR, LLCR, PLCR coverage covenants.
- **Synthetic Instrument Lab**: First-loss absorption notes, synthetic revenue-linked tranches, credit protection contracts, refinancing options.
- **Infrastructure Bond Analytics**: Clean/dirty price, Macaulay/modified duration, convexity, key-rate durations, DV01, discount margin.
- **Risk & Monte Carlo**: 10,000-path correlated stochastic simulation, VaR/CVaR, debt service breach probability.

## 4. Legal & Regulatory Disclaimer
All projects, instruments, curves, and counterparties within this platform are **strictly synthetic and hypothetical** for risk evaluation and quantitative research.
