# RhinoQuant Model Limitations, Validation & Governance Report

**Model Identifier:** RHINO-RAIL-FIN-2026-V1  
**Validation Classification:** Tier 1 Material Financial Model  
**Approved For:** Synthetic Structuring & Infrastructure Portfolio Analytics  
**Regulatory Warning:** Strictly synthetic financial engineering. Instruments do not constitute an offer of securities.

---

## 1. Mathematical Framework & Benchmark Identities

The quantitative engine has been tested against independent analytical benchmarks:
1. **Bond Duration & Convexity**: Verified against Fabozzi fixed-income formulas.
2. **Target DSCR Sculpting**: Formulated as an exact non-linear constrained cash matching program:
   $$\text{Debt Service}_t = \frac{\text{CFADS}_t}{\text{DSCR}_{\text{target}}}$$
   $$\text{Principal}_t = \text{Debt Service}_t - r \cdot D_{t-1}$$
3. **Cash Conservation**: Waterfall allocations satisfy:
   $$\sum \text{Tranche Inflows} \equiv \text{Gross Cash Inflow}$$
4. **Loan Life Coverage Ratio (LLCR)**:
   $$\text{LLCR}_t = \frac{\sum_{s=t}^{T} \frac{\text{CFADS}_s}{(1+r_D)^{s-t+1}}}{D_{t-1}}$$

## 2. Key Limitations and Assumptions

- **Linearity of Operating Costs**: Operating costs scale stepwise with train-km and passenger-km; extreme network congestion non-linearities are bounded by UIC 406 headway limits.
- **Refinancing Risk**: Bullet maturities must be hedged or structured with synthetic step-up margins.
- **Inflation Co-movement**: General CPI and construction cost escalation are separately parameterized to prevent double indexation.
- **Sovereign Counterparty Risk**: Concession availability payments assume investment-grade sovereign counterparty credit.
