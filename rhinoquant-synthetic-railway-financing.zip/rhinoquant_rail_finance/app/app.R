# RhinoQuant Synthetic Railway Financing - Shiny Interactive Interface
# Rhino Bank Infrastructure Finance & Quantitative Engineering

library(shiny)
library(data.table)

# Source core package functions if running unbundled
if (dir.exists("../R")) {
  r_files <- list.files("../R", pattern = "\\.R$", full.names = TRUE)
  for (f in r_files) source(f)
}

ui <- fluidPage(
  theme = bslib::bs_theme(
    version = 5,
    bg = "#0B1120",
    fg = "#F1F5F9",
    primary = "#38BDF8",
    secondary = "#64748B",
    base_font = bslib::font_google("Plus Jakarta Sans"),
    code_font = bslib::font_google("JetBrains Mono")
  ),
  titlePanel(
    div(
      h2("RhinoQuant Synthetic Railway Financing", style = "color: #38BDF8; font-weight: 700; margin-bottom: 2px;"),
      p("Institutional Infrastructure Finance & Quantitative Risk Platform · Rhino Bank", 
        style = "color: #94A3B8; font-size: 0.95rem; margin-bottom: 20px;")
    )
  ),
  tabsetPanel(
    id = "main_tabs",
    tabPanel("1. Project Registry",
      sidebarLayout(
        sidebarPanel(
          selectInput("selected_project", "Select Benchmark Project:",
                      choices = c("SYN-HSR-01 (Trans-Alpine HSR)", "SYN-FRT-02 (Nordic Freight)", "SYN-MTR-03 (Metropolitan Metro)")),
          numericInput("adj_capex", "Adjusted Base Capex (M):", value = 8450, min = 500, max = 25000),
          sliderInput("contingency", "Contingency Pct:", min = 0.05, max = 0.35, value = 0.15, step = 0.01),
          actionButton("recalc_btn", "Recalculate Model", class = "btn-primary")
        ),
        mainPanel(
          h4("Asset Specifications & Provenance"),
          tableOutput("project_summary_table"),
          hr(),
          h4("Construction Capex S-Curve & IDC Schedule"),
          tableOutput("capex_schedule_table")
        )
      )
    ),
    tabPanel("5. Cash Flow & Waterfall",
      sidebarLayout(
        sidebarPanel(
          numericInput("target_dscr_input", "Target Debt Service Coverage (DSCR):", value = 1.35, min = 1.10, max = 2.00, step = 0.05),
          numericInput("senior_rate_input", "Senior Debt Interest Rate:", value = 0.048, min = 0.01, max = 0.12, step = 0.002)
        ),
        mainPanel(
          h4("Operational Cash Flows & Sculpted Debt Service"),
          tableOutput("cf_debt_table")
        )
      )
    ),
    tabPanel("7. Bond Pricing & Yields",
      sidebarLayout(
        sidebarPanel(
          numericInput("bond_coupon", "Coupon Rate (%):", value = 4.5, min = 0.5, max = 12, step = 0.1),
          numericInput("bond_ytm", "Market Yield to Maturity (%):", value = 4.2, min = 0.5, max = 12, step = 0.1),
          numericInput("bond_tenor", "Maturity (Years):", value = 20, min = 1, max = 50)
        ),
        mainPanel(
          h4("Bond Analytics & Sensitivity"),
          verbatimTextOutput("bond_metrics_output")
        )
      )
    ),
    tabPanel("10. Monte Carlo Risk Engine",
      sidebarLayout(
        sidebarPanel(
          numericInput("mc_sims", "Simulation Iterations:", value = 2000, min = 500, max = 10000),
          sliderInput("mc_capex_vol", "Capex Overrun Volatility:", min = 0.05, max = 0.40, value = 0.18, step = 0.01),
          sliderInput("mc_rev_vol", "Revenue Volatility:", min = 0.05, max = 0.35, value = 0.14, step = 0.01),
          actionButton("run_mc_btn", "Execute Stochastic Simulation", class = "btn-warning")
        ),
        mainPanel(
          h4("Stochastic Capital Risk & DSCR Breach Probability"),
          tableOutput("mc_metrics_table")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  output$project_summary_table <- renderTable({
    project_registry()
  })
  
  output$capex_schedule_table <- renderTable({
    calculate_capex_profile(base_capex_m = input$adj_capex, contingency_pct = input$contingency)
  })
  
  output$cf_debt_table <- renderTable({
    cf <- calculate_project_cashflows(ops_years = 15, initial_revenue_m = 450, initial_opex_m = 160)
    debt <- calculate_debt_schedule(total_debt_m = input$adj_capex * 0.7, cfads_vector = cf$cfads_m, tenor_years = 15, interest_rate = input$senior_rate_input, target_dscr = input$target_dscr_input)
    debt
  })
  
  output$bond_metrics_output <- renderPrint({
    res <- calculate_bond_pricing(face_value = 100, coupon_rate = input$bond_coupon / 100, maturity_years = input$bond_tenor, market_yield = input$bond_ytm / 100)
    res
  })
  
  output$mc_metrics_table <- renderTable({
    input$run_mc_btn
    isolate({
      mc <- run_monte_carlo_simulation(n_sims = input$mc_sims, base_capex_m = input$adj_capex, capex_volatility = input$mc_capex_vol, revenue_volatility = input$mc_rev_vol)
      as.data.frame(mc)
    })
  })
}

shinyApp(ui = ui, server = server)
