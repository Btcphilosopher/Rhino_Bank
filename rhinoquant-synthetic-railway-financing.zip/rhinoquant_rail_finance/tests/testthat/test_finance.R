# Test suite for RhinoQuant Railway Project Finance
library(testthat)

test_that("Capacity headway is UIC 406 compliant", {
  cap <- calculate_capacity_headway(signalling_category = "ETCS Level 2 with ATO")
  expect_gt(cap$uic406_practical_tph_per_direction, 0)
  expect_gte(cap$practical_headway_sec, cap$signalling_min_headway_sec)
})

test_that("Capex profile escalates and calculates IDC", {
  capex <- calculate_capex_profile(base_capex_m = 1000, duration_years = 5)
  expect_equal(nrow(capex), 5)
  expect_gt(sum(capex$total_funding_need), 1000)
  expect_gt(sum(capex$interest_during_construction), 0)
})

test_that("Debt schedule fully amortises to zero at tenor end", {
  cf <- calculate_project_cashflows(ops_years = 10, initial_revenue_m = 200, initial_opex_m = 80)
  sched <- calculate_debt_schedule(total_debt_m = 500, cfads_vector = cf$cfads_m, tenor_years = 10, interest_rate = 0.05, target_dscr = 1.30)
  expect_equal(tail(sched$closing_balance_m, 1), 0, tolerance = 0.1)
  expect_true(all(sched$dscr >= 1.25))
})

test_that("Bond pricing matches analytical duration and convexity identities", {
  b <- calculate_bond_pricing(face_value = 100, coupon_rate = 0.05, maturity_years = 10, market_yield = 0.05)
  expect_equal(b$clean_price + b$accrued_interest, 100, tolerance = 0.01)
  expect_gt(b$modified_duration, 0)
  expect_gt(b$convexity, 0)
  expect_gt(b$dv01, 0)
})

test_that("Waterfall conservation holds without tranche leakage", {
  res <- calculate_waterfall_allocation(gross_inflow_m = 100, senior_notional_m = 1000, senior_coupon_rate = 0.04)
  total_distributed <- res$senior_interest_paid + res$mezz_interest_paid + res$reserve_funded + res$equity_distribution
  expect_equal(total_distributed, 100, tolerance = 1e-4)
})
