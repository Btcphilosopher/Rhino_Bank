/**
 * RhinoQuant Synthetic Railway Financing
 * Quantitative Finance & Infrastructure Asset Data Models
 */

export type RailwayType = 
  | 'High-Speed Rail'
  | 'Conventional Passenger Rail'
  | 'Urban Metro System'
  | 'Commuter & Regional Rail'
  | 'Freight Corridor'
  | 'Cross-Border Tunnel & Bridge';

export type SignallingCategory =
  | 'ETCS Level 2 with ATO'
  | 'ETCS Level 1'
  | 'CBTC GoA4 Driverless'
  | '4-Aspect Colour Light'
  | '3-Aspect Colour Light';

export interface RailwayProject {
  id: string;
  name: string;
  country: string;
  currency: 'EUR' | 'GBP' | 'USD' | 'CHF';
  railwayType: RailwayType;
  routeLengthKm: number;
  stationsCount: number;
  trackConfig: string;
  designSpeedKmh: number;
  passengerCapacityAnnual: number;
  freightCapacityAnnualTonnes: number;
  trainFleetSize: number;
  plannedFrequencyTph: number;
  constructionStartYear: number;
  constructionDurationYears: number;
  operationalStartYear: number;
  concessionYears: number;
  assetLifeYears: number;
  electrificationStatus: string;
  signallingCategory: SignallingCategory;
  baseCapexM: number;
  contingencyPct: number;
  realCostEscalationPct: number;
  generalInflationPct: number;
  constructionDebtRate: number;
  debtFundingRatio: number;
  seniorDebtRate: number;
  debtTenorYears: number;
  targetDscr: number;
  initialRevenueM: number;
  revenueGrowthPct: number;
  initialOpexM: number;
  opexInflationPct: number;
  taxRate: number;
  renewalIntervalYears: number;
  renewalCostM: number;
  // Passenger specific
  fareYieldPerPkm: number;
  avgTripLengthKm: number;
  initialAnnualPaxM: number;
  paxGrowthRate: number;
  // Freight specific
  freightTariffPerNtkm: number;
  initialAnnualFreightTonnesM: number;
  freightGrowthRate: number;
  // Economic parameters
  timeSavedMinPerTrip: number;
  valueOfTimeEurHr: number;
  co2SavedKgPerPax: number;
  provenance: string;
}

export interface CapexYear {
  year: number;
  calendarYear: number;
  sCurveWeight: number;
  baseCapex: number;
  contingency: number;
  escalatedCapex: number;
  debtDrawn: number;
  equityDrawn: number;
  idc: number; // Interest during construction
  totalFundingNeed: number;
}

export interface CashFlowYear {
  year: number;
  calendarYear: number;
  passengerRevenue: number;
  freightRevenue: number;
  commercialRevenue: number;
  availabilityPayments: number;
  grossRevenue: number;
  operatingCosts: number;
  ebitda: number;
  majorRenewals: number;
  corporateTax: number;
  cfads: number; // Cash Flow Available for Debt Service
  debtService: number;
  fcfe: number; // Free cash flow to equity
  cashBalance: number;
  dscr: number;
  llcr: number;
}

export interface DebtScheduleYear {
  year: number;
  calendarYear: number;
  openingBalance: number;
  cfads: number;
  interestPaid: number;
  principalPaid: number;
  totalDebtService: number;
  closingBalance: number;
  dscr: number;
  llcr: number;
  dsraBalance: number;
}

export interface BondAnalytics {
  faceValue: number;
  couponRate: number;
  maturityYears: number;
  marketYield: number;
  frequency: number;
  accruedInterest: number;
  cleanPrice: number;
  dirtyPrice: number;
  macaulayDuration: number;
  modifiedDuration: number;
  convexity: number;
  dv01: number;
  spreadBps: number;
  keyRate2y: number;
  keyRate5y: number;
  keyRate10y: number;
  keyRate20y: number;
  keyRate30y: number;
}

export interface SyntheticInstrument {
  id: string;
  name: string;
  type: 
    | 'Credit-Linked Note (CLN)'
    | 'Synthetic Revenue Note'
    | 'First-Loss Absorption Tranche'
    | 'Cost-Overrun Guarantee'
    | 'Refinancing Step-Up Contract';
  referenceProject: string;
  notionalM: number;
  currency: string;
  tenorYears: number;
  attachmentPct: number;
  detachmentPct: number;
  couponSpreadBps: number;
  referenceIndex: string;
  triggerEvent: string;
  lossAllocationMechanism: string;
  seniority: 'Senior' | 'Mezzanine' | 'First-Loss Equity';
  counterparty: string;
  collateralRequirement: string;
  settlementType: 'Cash Settled' | 'Physical Delivery';
  terminationFeeM: number;
  governingLaw: string;
}

export interface WaterfallTranche {
  name: string;
  seniorityOrder: number;
  notionalM: number;
  couponRatePct: number;
  cashDueM: number;
  cashPaidM: number;
  shortfallM: number;
  lossImpairmentM: number;
  closingBalanceM: number;
}

export interface YieldCurvePoint {
  tenorYears: number;
  baseYieldPct: number;
  shockedYieldPct: number;
  spreadBps: number;
  forwardRatePct: number;
}

export interface MonteCarloResult {
  nSimulations: number;
  meanNpvM: number;
  medianNpvM: number;
  p10NpvM: number;
  p90NpvM: number;
  var95M: number;
  cvar95M: number; // Expected Shortfall
  dscrBreachProbabilityPct: number;
  equityNpvNegativeProbPct: number;
  meanDscr: number;
  minDscr: number;
  distributionBins: { binStart: number; binEnd: number; count: number }[];
}

export interface EconomicImpactResult {
  directGvaM: number;
  indirectGvaM: number;
  totalGvaM: number;
  directJobYears: number;
  annualPassengerHoursSavedM: number;
  annualUserTimeBenefitM: number;
  annualCo2TonnesAvoided: number;
  annualCarbonSocialValueM: number;
  benefitCostRatio: number;
}

export interface ModelAuditStatus {
  version: string;
  validationStatus: 'DEVELOPMENT' | 'VALIDATED' | 'PROD-APPROVED';
  timestamp: string;
  ebitdaIdentityVerified: boolean;
  debtRollForwardVerified: boolean;
  waterfallConservationVerified: boolean;
  discountFactorMonotonicityVerified: boolean;
  uic406CapacityVerified: boolean;
}
