import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  subtext?: string;
  status?: 'nominal' | 'warning' | 'alert' | 'neutral';
  kicker?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  unit,
  subtext,
  status = 'neutral',
  kicker
}) => {
  const statusColor = {
    nominal: 'text-emerald-400',
    warning: 'text-amber-400',
    alert: 'text-rose-400',
    neutral: 'text-sky-400'
  }[status];

  return (
    <div className="bg-[#111A2E] border border-slate-800/80 rounded-lg p-4 flex flex-col justify-between transition-colors hover:border-slate-700">
      <div>
        {kicker && (
          <div className="text-[11px] font-medium tracking-wide uppercase text-slate-400 mb-1">
            {kicker}
          </div>
        )}
        <div className="text-xs font-medium text-slate-400">{label}</div>
        <div className="mt-1 flex items-baseline gap-1.5">
          <span className={`text-2xl font-bold font-mono tracking-tight ${statusColor} tabular-nums`}>
            {value}
          </span>
          {unit && <span className="text-xs text-slate-400 font-normal">{unit}</span>}
        </div>
      </div>
      {subtext && (
        <div className="mt-2 pt-2 border-t border-slate-800/60 text-[11px] text-slate-400 flex items-center justify-between">
          <span>{subtext}</span>
        </div>
      )}
    </div>
  );
};
