import React from 'react';

interface LineSeries {
  name: string;
  color: string;
  data: { x: number | string; y: number }[];
  dashed?: boolean;
}

interface SvgLineChartProps {
  series: LineSeries[];
  height?: number;
  yUnit?: string;
  xLabel?: string;
  yLabel?: string;
  title?: string;
}

export const SvgLineChart: React.FC<SvgLineChartProps> = ({
  series,
  height = 240,
  yUnit = '',
  title
}) => {
  if (!series.length || !series[0].data.length) return null;

  const padding = { top: 20, right: 30, bottom: 35, left: 55 };
  const width = 640;

  // Determine global min and max Y
  let minY = Infinity;
  let maxY = -Infinity;

  series.forEach(s => {
    s.data.forEach(p => {
      if (p.y < minY) minY = p.y;
      if (p.y > maxY) maxY = p.y;
    });
  });

  if (minY === maxY) {
    minY = Math.min(0, minY - 1);
    maxY = maxY + 1;
  }

  // Round bounds slightly for neat gridlines
  const yRange = maxY - minY;
  const plotW = width - padding.left - padding.right;
  const plotH = height - padding.top - padding.bottom;

  const pointsCount = series[0].data.length;
  const getX = (idx: number) => padding.left + (idx / Math.max(1, pointsCount - 1)) * plotW;
  const getY = (val: number) => padding.top + plotH - ((val - minY) / (yRange || 1)) * plotH;

  const yTicks = [minY, minY + yRange * 0.33, minY + yRange * 0.66, maxY];

  return (
    <div className="w-full bg-[#0D1527] border border-slate-800/80 rounded-lg p-3">
      {title && (
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-300">{title}</span>
          <div className="flex items-center gap-3">
            {series.map(s => (
              <div key={s.name} className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <span className="w-3 h-0.5 rounded-full" style={{ backgroundColor: s.color }} />
                <span>{s.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
        {/* Horizontal grid lines */}
        {yTicks.map((val, i) => {
          const y = getY(val);
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="#1E293B"
                strokeDasharray="2,2"
              />
              <text
                x={padding.left - 8}
                y={y + 3.5}
                textAnchor="end"
                className="text-[10px] fill-slate-400 font-mono"
              >
                {val.toFixed(1)}
                {yUnit}
              </text>
            </g>
          );
        })}

        {/* X Axis labels */}
        {series[0].data.map((p, idx) => {
          if (idx % Math.ceil(pointsCount / 8) !== 0 && idx !== pointsCount - 1) return null;
          const x = getX(idx);
          return (
            <text
              key={idx}
              x={x}
              y={height - 10}
              textAnchor="middle"
              className="text-[10px] fill-slate-400 font-mono"
            >
              {p.x}
            </text>
          );
        })}

        {/* Series Paths */}
        {series.map((s, sIdx) => {
          const pathD = s.data.reduce((acc, p, idx) => {
            const x = getX(idx);
            const y = getY(p.y);
            return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
          }, '');

          return (
            <g key={sIdx}>
              <path
                d={pathD}
                fill="none"
                stroke={s.color}
                strokeWidth={2}
                strokeDasharray={s.dashed ? '4,4' : undefined}
              />
              {s.data.map((p, idx) => {
                if (pointsCount > 25 && idx % 3 !== 0) return null;
                return (
                  <circle
                    key={idx}
                    cx={getX(idx)}
                    cy={getY(p.y)}
                    r={3}
                    fill="#0B1120"
                    stroke={s.color}
                    strokeWidth={1.5}
                  />
                );
              })}
            </g>
          );
        })}
      </svg>
    </div>
  );
};

interface BarChartProps {
  data: { label: string | number; value1: number; value2?: number }[];
  label1: string;
  label2?: string;
  height?: number;
  yUnit?: string;
  title?: string;
}

export const SvgBarChart: React.FC<BarChartProps> = ({
  data,
  label1,
  label2,
  height = 240,
  yUnit = '',
  title
}) => {
  if (!data.length) return null;

  const padding = { top: 20, right: 25, bottom: 35, left: 55 };
  const width = 640;
  const plotW = width - padding.left - padding.right;
  const plotH = height - padding.top - padding.bottom;

  let maxVal = 0;
  data.forEach(d => {
    if (d.value1 > maxVal) maxVal = d.value1;
    if (d.value2 && d.value2 > maxVal) maxVal = d.value2;
  });
  maxVal = Math.max(10, maxVal * 1.15);

  const barGroupWidth = plotW / data.length;
  const barWidth = label2 ? barGroupWidth * 0.38 : barGroupWidth * 0.65;

  return (
    <div className="w-full bg-[#0D1527] border border-slate-800/80 rounded-lg p-3">
      {title && (
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-300">{title}</span>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <span className="w-3 h-2 rounded bg-sky-500" />
              <span>{label1}</span>
            </div>
            {label2 && (
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <span className="w-3 h-2 rounded bg-emerald-500" />
                <span>{label2}</span>
              </div>
            )}
          </div>
        </div>
      )}
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
        {/* Horizontal grid lines */}
        {[0, maxVal * 0.33, maxVal * 0.66, maxVal].map((val, i) => {
          const y = padding.top + plotH - (val / maxVal) * plotH;
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="#1E293B"
                strokeDasharray="2,2"
              />
              <text
                x={padding.left - 8}
                y={y + 3.5}
                textAnchor="end"
                className="text-[10px] fill-slate-400 font-mono"
              >
                {Math.round(val)}
                {yUnit}
              </text>
            </g>
          );
        })}

        {/* Bars */}
        {data.map((d, i) => {
          const groupX = padding.left + i * barGroupWidth;
          const h1 = (d.value1 / maxVal) * plotH;
          const y1 = padding.top + plotH - h1;

          return (
            <g key={i}>
              <rect
                x={groupX + 4}
                y={y1}
                width={barWidth}
                height={h1}
                fill="#38BDF8"
                rx={1.5}
              />
              {label2 && d.value2 !== undefined && (
                <rect
                  x={groupX + 4 + barWidth + 2}
                  y={padding.top + plotH - (d.value2 / maxVal) * plotH}
                  width={barWidth}
                  height={(d.value2 / maxVal) * plotH}
                  fill="#10B981"
                  rx={1.5}
                />
              )}
              {i % Math.ceil(data.length / 8) === 0 && (
                <text
                  x={groupX + barGroupWidth / 2}
                  y={height - 10}
                  textAnchor="middle"
                  className="text-[10px] fill-slate-400 font-mono"
                >
                  {d.label}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};
