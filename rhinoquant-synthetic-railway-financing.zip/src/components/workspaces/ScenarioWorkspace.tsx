import React from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateCapexProfile, calculateProjectCashflows } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { Columns, Check, AlertTriangle, TrendingUp, DollarSign } from 'lucide-react';

interface ScenarioWorkspaceProps {
  project: RailwayProject;
}

export const ScenarioWorkspace: React.FC<ScenarioWorkspaceProps> = ({ project }) => {
  // Scenario 1: Base Case
  const baseCapex = calculateCapexProfile(project, 0);
  const baseCf = calculateProjectCashflows(project, baseCapex.peakDebtBalance, 1.0, 1.0);

  // Scenario 2: Construction Cost Overrun (+25%) & 24 Months Delay
  const projectOverrun: RailwayProject = {
    ...project,
    baseCapexM: project.baseCapexM * 1.25,
    contingencyPct: 0.25
  };
  const delayCapex = calculateCapexProfile(projectOverrun, 24);
  const delayCf = calculateProjectCashflows(projectOverrun, delayCapex.peakDebtBalance, 0.95, 1.10);

  // Scenario 3: Macro Stagflation (-20% Passenger Demand, +25% OPEX, +150 bps Interest Rate)
  const stagflationCapex = calculateCapexProfile(
    { ...project, constructionDebtRate: project.constructionDebtRate + 0.015 },
    6
  );
  const stagflationCf = calculateProjectCashflows(
    { ...project, seniorDebtRate: project.seniorDebtRate + 0.015 },
    stagflationCapex.peakDebtBalance,
    0.80,
    1.25
  );

  // Scenario 4: Accelerated Modal Shift (+25% Traffic Demand, +10% Yield)
  const boomCapex = calculateCapexProfile(project, 0);
  const boomCf = calculateProjectCashflows(project, boomCapex.peakDebtBalance, 1.25, 1.05);

  const scenarios = [
    {
      name: '1. Base Concession Case',
      desc: 'Central planning case with UIC 406 headway and target DSCR debt sculpting.',
      capex: baseCapex.totalFundingNeed,
      idc: baseCapex.totalIdc,
      projectIrr: baseCf.projectIrrPct,
      equityIrr: baseCf.equityIrrPct,
      npv: baseCf.projectNpvM,
      minDscr: baseCf.minDscr,
      status: 'nominal'
    },
    {
      name: '2. Capex Overrun & 2-Yr Delay',
      desc: '+25% Capex budget overrun, +24 months delay in civil works, and deferred revenue start.',
      capex: delayCapex.totalFundingNeed,
      idc: delayCapex.totalIdc,
      projectIrr: delayCf.projectIrrPct,
      equityIrr: delayCf.equityIrrPct,
      npv: delayCf.projectNpvM,
      minDscr: delayCf.minDscr,
      status: 'alert'
    },
    {
      name: '3. Macro Stagflation Stress',
      desc: 'High inflation (+25% OPEX), +150 bps financing rates, and -20% passenger demand.',
      capex: stagflationCapex.totalFundingNeed,
      idc: stagflationCapex.totalIdc,
      projectIrr: stagflationCf.projectIrrPct,
      equityIrr: stagflationCf.equityIrrPct,
      npv: stagflationCf.projectNpvM,
      minDscr: stagflationCf.minDscr,
      status: 'warning'
    },
    {
      name: '4. Green Modal Shift Boom',
      desc: '+25% Passenger modal shift from short-haul aviation, high fare resilience.',
      capex: boomCapex.totalFundingNeed,
      idc: boomCapex.totalIdc,
      projectIrr: boomCf.projectIrrPct,
      equityIrr: boomCf.equityIrrPct,
      npv: boomCf.projectNpvM,
      minDscr: boomCf.minDscr,
      status: 'nominal'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          13. Deterministic Scenario Comparison & Stress Matrix
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Side-by-side analytical comparison of base case against delay, stagflation, and decarbonisation scenarios.
        </p>
      </div>

      {/* Scenario Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {scenarios.map((s, idx) => (
          <div
            key={idx}
            className="bg-[#0E1626] border border-slate-800 rounded-lg p-4 flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">{s.name}</span>
                <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                  s.status === 'alert' ? 'bg-rose-500/20 text-rose-300' :
                  s.status === 'warning' ? 'bg-amber-500/20 text-amber-300' :
                  'bg-emerald-500/20 text-emerald-300'
                }`}>
                  {s.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{s.desc}</p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Capex:</span>
                <span className="text-slate-200">€{s.capex.toLocaleString()}M</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Project IRR:</span>
                <span className={s.projectIrr < 6.0 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {s.projectIrr.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Equity IRR:</span>
                <span className={s.equityIrr < 9.5 ? 'text-rose-400 font-bold' : 'text-sky-400 font-bold'}>
                  {s.equityIrr.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Min DSCR:</span>
                <span className={s.minDscr < 1.20 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {s.minDscr.toFixed(2)}x
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Detailed Side-by-Side Comparison Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 bg-[#111A2E]">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Multi-Scenario Financial KPI Matrix
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0B1120] text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-3.5 py-2.5">Financial Metric</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-sky-400">1. Base Case</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-rose-400">2. Capex Overrun + Delay</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-amber-400">3. Stagflation</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-emerald-400">4. Modal Shift Boom</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              <tr className="hover:bg-slate-800/20">
                <td className="px-3.5 py-2 text-slate-300 font-sans">Total Funding Requirement (Capex + IDC)</td>
                <td className="px-3.5 py-2 text-right text-slate-200">€{baseCapex.totalFundingNeed.toLocaleString()}M</td>
                <td className="px-3.5 py-2 text-right text-rose-400 font-semibold">€{delayCapex.totalFundingNeed.toLocaleString()}M</td>
                <td className="px-3.5 py-2 text-right text-amber-400">€{stagflationCapex.totalFundingNeed.toLocaleString()}M</td>
                <td className="px-3.5 py-2 text-right text-emerald-400">€{boomCapex.totalFundingNeed.toLocaleString()}M</td>
              </tr>
              <tr className="hover:bg-slate-800/20">
                <td className="px-3.5 py-2 text-slate-300 font-sans">Interest During Construction (IDC)</td>
                <td className="px-3.5 py-2 text-right text-slate-400">€{baseCapex.totalIdc.toLocaleString()}M</td>
                <td className="px-3.5 py-2 text-right text-rose-400">€{delayCapex.totalIdc.toLocaleString()}M</td>
                <td className="px-3.5 py-2 text-right text-amber-400">€{stagflationCapex.totalIdc.toLocaleString()}M</td>
                <td className="px-3.5 py-2 text-right text-slate-400">€{boomCapex.totalIdc.toLocaleString()}M</td>
              </tr>
              <tr className="hover:bg-slate-800/20">
                <td className="px-3.5 py-2 text-slate-300 font-sans">Unlevered Project IRR (6% Hurdle)</td>
                <td className="px-3.5 py-2 text-right text-emerald-400 font-bold">{baseCf.projectIrrPct.toFixed(2)}%</td>
                <td className="px-3.5 py-2 text-right text-rose-400 font-bold">{delayCf.projectIrrPct.toFixed(2)}%</td>
                <td className="px-3.5 py-2 text-right text-amber-400 font-bold">{stagflationCf.projectIrrPct.toFixed(2)}%</td>
                <td className="px-3.5 py-2 text-right text-emerald-400 font-bold">{boomCf.projectIrrPct.toFixed(2)}%</td>
              </tr>
              <tr className="hover:bg-slate-800/20">
                <td className="px-3.5 py-2 text-slate-300 font-sans">Levered Equity IRR (9.5% Hurdle)</td>
                <td className="px-3.5 py-2 text-right text-sky-400 font-bold">{baseCf.equityIrrPct.toFixed(2)}%</td>
                <td className="px-3.5 py-2 text-right text-rose-400 font-bold">{delayCf.equityIrrPct.toFixed(2)}%</td>
                <td className="px-3.5 py-2 text-right text-amber-400 font-bold">{stagflationCf.equityIrrPct.toFixed(2)}%</td>
                <td className="px-3.5 py-2 text-right text-emerald-400 font-bold">{boomCf.equityIrrPct.toFixed(2)}%</td>
              </tr>
              <tr className="hover:bg-slate-800/20">
                <td className="px-3.5 py-2 text-slate-300 font-sans">Minimum DSCR Covenant (1.20x Threshold)</td>
                <td className="px-3.5 py-2 text-right text-emerald-400">{baseCf.minDscr.toFixed(2)}x</td>
                <td className="px-3.5 py-2 text-right text-rose-400 font-bold">{delayCf.minDscr.toFixed(2)}x</td>
                <td className="px-3.5 py-2 text-right text-amber-400 font-bold">{stagflationCf.minDscr.toFixed(2)}x</td>
                <td className="px-3.5 py-2 text-right text-emerald-400 font-bold">{boomCf.minDscr.toFixed(2)}x</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
