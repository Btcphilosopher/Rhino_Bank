import React, { useState } from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateWaterfall } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { Layers, ShieldCheck, AlertOctagon, CheckCircle2 } from 'lucide-react';

interface WaterfallWorkspaceProps {
  project: RailwayProject;
}

export const WaterfallWorkspace: React.FC<WaterfallWorkspaceProps> = ({ project }) => {
  const [cashInflowM, setCashInflowM] = useState(75);
  const [seniorNotionalM, setSeniorNotionalM] = useState(600);
  const [mezzNotionalM, setMezzNotionalM] = useState(180);
  const [firstLossNotionalM, setFirstLossNotionalM] = useState(120);
  const [seniorCouponPct, setSeniorCouponPct] = useState(4.85);
  const [mezzCouponPct, setMezzCouponPct] = useState(7.50);
  const [reserveTargetM, setReserveTargetM] = useState(25);

  const waterfall = calculateWaterfall(
    cashInflowM,
    seniorNotionalM,
    mezzNotionalM,
    firstLossNotionalM,
    seniorCouponPct,
    mezzCouponPct,
    reserveTargetM
  );

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          9. Structured Cash Flow Waterfall & Tranche Impairment Analysis
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Priority of payments, credit loss absorption, liquidity reserve replenishment, and mathematical cash conservation.
        </p>
      </div>

      {/* Waterfall KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Period Inflow"
          label="Gross Cash Available"
          value={`${project.currency} ${cashInflowM.toFixed(1)}M`}
          unit="Inflow"
          subtext="Available for waterfall distribution"
          status="nominal"
        />
        <MetricCard
          kicker="Conservation Check"
          label="Fund Conservation"
          value={waterfall.conservationVerified ? '100.0% RECONCILED' : 'LEAKAGE DETECTED'}
          unit={`(Sum: €${waterfall.totalDistributedM}M)`}
          subtext="Inflows == Outflows identity verified"
          status={waterfall.conservationVerified ? 'nominal' : 'alert'}
        />
        <MetricCard
          kicker="Senior Tranche Health"
          label="Class A Senior Coverage"
          value={waterfall.isSeniorImpaired ? 'IMPAIRED' : 'FULL PAYMENT'}
          unit={waterfall.isSeniorImpaired ? 'Shortfall active' : '100% Satisfied'}
          subtext={`Due: €${waterfall.tranches[0].cashDueM}M · Paid: €${waterfall.tranches[0].cashPaidM}M`}
          status={waterfall.isSeniorImpaired ? 'alert' : 'nominal'}
        />
        <MetricCard
          kicker="First-Loss Equity"
          label="First-Loss Impairment"
          value={`€${waterfall.firstLossImpairmentM.toFixed(1)}M`}
          unit="Impairment"
          subtext={`Residual Equity Cash: €${waterfall.tranches[3].cashPaidM}M`}
          status={waterfall.firstLossImpairmentM > 0 ? 'warning' : 'nominal'}
        />
      </div>

      {/* Dynamic Cash Inflow Stress Simulator */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Interactive Cash Flow Waterfall Stress Shock
          </h3>
          <span className="text-xs font-mono text-sky-400">
            Current Gross Inflow: {project.currency} {cashInflowM.toFixed(1)}M
          </span>
        </div>
        <input
          type="range"
          min={10}
          max={120}
          step={2.5}
          value={cashInflowM}
          onChange={e => setCashInflowM(Number(e.target.value))}
          className="w-full accent-sky-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
        />
        <div className="flex justify-between text-[11px] text-slate-400 font-mono">
          <span>€10M (Severe Default Distress)</span>
          <span>€45M (Mezzanine Impairment)</span>
          <span>€80M (Healthy Target Distribution)</span>
          <span>€120M (Full Equity Upside)</span>
        </div>
      </div>

      {/* Tranche Allocation Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-[#111A2E]">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Priority of Payments & Loss Absorption Schedule
          </span>
          <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Zero Tranche Leakage
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0B1120] text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-3.5 py-2.5">Priority</th>
                <th className="px-3.5 py-2.5">Tranche Name</th>
                <th className="px-3.5 py-2.5 text-right">Notional</th>
                <th className="px-3.5 py-2.5 text-right">Rate %</th>
                <th className="px-3.5 py-2.5 text-right font-semibold text-slate-200">Cash Due</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-sky-400">Cash Paid</th>
                <th className="px-3.5 py-2.5 text-right text-rose-400">Shortfall</th>
                <th className="px-3.5 py-2.5 text-right text-amber-400">Loss Absorbed</th>
                <th className="px-3.5 py-2.5 text-right font-mono text-slate-200">Ending Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {waterfall.tranches.map(t => (
                <tr key={t.seniorityOrder} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-3.5 py-2 text-slate-400">Step {t.seniorityOrder}</td>
                  <td className="px-3.5 py-2 font-medium text-slate-200">{t.name}</td>
                  <td className="px-3.5 py-2 text-right text-slate-300 tabular-nums">{t.notionalM.toLocaleString()}M</td>
                  <td className="px-3.5 py-2 text-right text-slate-400 tabular-nums">
                    {t.couponRatePct > 0 ? `${t.couponRatePct.toFixed(2)}%` : '—'}
                  </td>
                  <td className="px-3.5 py-2 text-right font-semibold text-slate-200 tabular-nums">{t.cashDueM.toFixed(1)}M</td>
                  <td className="px-3.5 py-2 text-right font-bold text-sky-400 tabular-nums">{t.cashPaidM.toFixed(1)}M</td>
                  <td className={`px-3.5 py-2 text-right font-bold tabular-nums ${
                    t.shortfallM > 0 ? 'text-rose-400' : 'text-slate-400'
                  }`}>
                    {t.shortfallM > 0 ? `${t.shortfallM.toFixed(1)}M` : '€0.0M'}
                  </td>
                  <td className={`px-3.5 py-2 text-right font-bold tabular-nums ${
                    t.lossImpairmentM > 0 ? 'text-amber-400' : 'text-slate-400'
                  }`}>
                    {t.lossImpairmentM > 0 ? `-${t.lossImpairmentM.toFixed(1)}M` : '€0.0M'}
                  </td>
                  <td className="px-3.5 py-2 text-right text-slate-200 tabular-nums">{t.closingBalanceM.toFixed(1)}M</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
