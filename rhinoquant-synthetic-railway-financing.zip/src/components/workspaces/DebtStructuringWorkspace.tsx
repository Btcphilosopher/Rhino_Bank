import React, { useState } from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateCapexProfile, calculateProjectCashflows } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgBarChart } from '../ui/ChartSvg';
import { Coins, ShieldCheck, Scale, Zap } from 'lucide-react';

interface DebtStructuringWorkspaceProps {
  project: RailwayProject;
  onUpdateProject: (p: RailwayProject) => void;
}

export const DebtStructuringWorkspace: React.FC<DebtStructuringWorkspaceProps> = ({
  project,
  onUpdateProject
}) => {
  const { peakDebtBalance } = calculateCapexProfile(project);
  const { debtSchedule, minDscr, avgDscr } = calculateProjectCashflows(project, peakDebtBalance);

  const initialDebtM = peakDebtBalance;
  const initialEquityM = peakDebtBalance * ((1 - project.debtFundingRatio) / project.debtFundingRatio);
  const totalCapexM = initialDebtM + initialEquityM;

  const debtBarData = debtSchedule.map(d => ({
    label: `Y${d.year}`,
    value1: d.principalPaid,
    value2: d.interestPaid
  }));

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          6. Project-Finance Debt Structuring & Target DSCR Sculpting Engine
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Senior secured facilities, target-DSCR sculpting optimization, DSRA liquidity reserve, LLCR & PLCR tracking.
        </p>
      </div>

      {/* Debt Sizing Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Senior Tranche"
          label="Senior Debt Facility Principal"
          value={`${project.currency} ${(initialDebtM / 1000).toFixed(2)}B`}
          unit={`(${initialDebtM.toLocaleString()}M)`}
          subtext={`Gearing: ${(project.debtFundingRatio * 100).toFixed(0)}% of Capex`}
          status="nominal"
        />
        <MetricCard
          kicker="Sculpting Program"
          label="Target DSCR Optimization"
          value={`${project.targetDscr.toFixed(2)}x`}
          unit={`(Actual Min: ${minDscr.toFixed(2)}x)`}
          subtext={`Avg DSCR: ${avgDscr.toFixed(2)}x over tenor`}
          status="nominal"
        />
        <MetricCard
          kicker="Tenor & Pricing"
          label="Debt Tenor & Coupon Rate"
          value={`${project.debtTenorYears} Years`}
          unit={`@ ${(project.seniorDebtRate * 100).toFixed(2)}%`}
          subtext={`Full amortisation by ${project.operationalStartYear + project.debtTenorYears}`}
        />
        <MetricCard
          kicker="Liquidity Cushion"
          label="Debt Service Reserve (DSRA)"
          value={`${project.currency} ${debtSchedule[0]?.dsraBalance.toLocaleString()}M`}
          unit="6-Mo Reserve"
          subtext="Standby Letter of Credit or Cash"
          status="nominal"
        />
      </div>

      {/* Sculpting Parameters & Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-sky-400" />
              <span>Target DSCR Solver Controls</span>
            </h3>
            <span className="text-[11px] text-emerald-400 font-mono">FEASIBLE SOLUTION</span>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Target DSCR Constraint</span>
                <span className="font-mono text-slate-200 font-bold">{project.targetDscr.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min={1.15}
                max={1.60}
                step={0.01}
                value={project.targetDscr}
                onChange={e => onUpdateProject({ ...project, targetDscr: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                Formula: Debt Service = CFADS / Target DSCR
              </span>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Senior Debt Tenor</span>
                <span className="font-mono text-slate-200 font-bold">{project.debtTenorYears} Years</span>
              </div>
              <input
                type="range"
                min={10}
                max={30}
                step={1}
                value={project.debtTenorYears}
                onChange={e => onUpdateProject({ ...project, debtTenorYears: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Interest Rate</span>
                <span className="font-mono text-slate-200 font-bold">{(project.seniorDebtRate * 100).toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={0.025}
                max={0.090}
                step={0.0025}
                value={project.seniorDebtRate}
                onChange={e => onUpdateProject({ ...project, seniorDebtRate: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 text-[11px] text-slate-400">
              <span className="font-semibold text-slate-300">Sculpting Mechanics: </span>
              Under target-DSCR debt sculpting, principal payments vary dynamically with seasonal and ramp-up traffic volumes, ensuring loan repayment is perfectly matched to projected cash generation.
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <SvgBarChart
            title={`Annual Sculpted Debt Service Breakdown (${project.currency} M)`}
            data={debtBarData}
            label1="Principal Repayment"
            label2="Interest Payment"
            yUnit="M"
          />
        </div>
      </div>

      {/* Debt Schedule Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-[#111A2E]">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Amortisation Roll-forward & Covenant Coverage Ratios
          </span>
          <span className="text-[11px] text-slate-400">
            Closing Balance at Maturity: €0.00M (Zero Refinancing Balloon)
          </span>
        </div>
        <div className="overflow-x-auto max-h-[380px]">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0B1120] text-slate-400 font-medium border-b border-slate-800 sticky top-0 z-10">
              <tr>
                <th className="px-3.5 py-2">Year</th>
                <th className="px-3.5 py-2 text-right">Opening Balance</th>
                <th className="px-3.5 py-2 text-right">CFADS</th>
                <th className="px-3.5 py-2 text-right text-rose-400">Interest</th>
                <th className="px-3.5 py-2 text-right text-sky-400">Principal</th>
                <th className="px-3.5 py-2 text-right font-bold text-amber-400">Total Debt Service</th>
                <th className="px-3.5 py-2 text-right">Closing Balance</th>
                <th className="px-3.5 py-2 text-right font-bold text-emerald-400">DSCR</th>
                <th className="px-3.5 py-2 text-right font-bold text-slate-200">LLCR</th>
                <th className="px-3.5 py-2 text-right text-slate-400">DSRA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {debtSchedule.map(d => (
                <tr key={d.year} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-3.5 py-2 text-slate-300">Year {d.year}</td>
                  <td className="px-3.5 py-2 text-right text-slate-300 tabular-nums">{d.openingBalance.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right text-emerald-400 tabular-nums">{d.cfads.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right text-rose-400 tabular-nums">{d.interestPaid.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right text-sky-400 tabular-nums">{d.principalPaid.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right font-bold text-amber-400 tabular-nums">
                    {d.totalDebtService.toLocaleString()}
                  </td>
                  <td className="px-3.5 py-2 text-right text-slate-300 tabular-nums">{d.closingBalance.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right font-bold text-emerald-400 tabular-nums">{d.dscr.toFixed(2)}x</td>
                  <td className="px-3.5 py-2 text-right font-bold text-slate-200 tabular-nums">{d.llcr.toFixed(2)}x</td>
                  <td className="px-3.5 py-2 text-right text-slate-400 tabular-nums">{d.dsraBalance.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
