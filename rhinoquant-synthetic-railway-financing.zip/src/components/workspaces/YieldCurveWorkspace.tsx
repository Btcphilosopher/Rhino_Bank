import React, { useState } from 'react';
import { calculateYieldCurve } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgLineChart } from '../ui/ChartSvg';
import { GitBranch, Sliders, TrendingUp, Zap } from 'lucide-react';

export const YieldCurveWorkspace: React.FC = () => {
  const [shiftType, setShiftType] = useState<'none' | 'parallel' | 'steepening' | 'flattening' | 'butterfly'>('none');
  const [shockBps, setShockBps] = useState(50);
  const [beta0, setBeta0] = useState(0.038); // Asymptote level 3.8%
  const [beta1, setBeta1] = useState(-0.015); // Slope
  const [beta2, setBeta2] = useState(0.012); // Curvature
  const [lambda, setLambda] = useState(0.73);

  const curvePoints = calculateYieldCurve(shiftType, shockBps, beta0, beta1, beta2, lambda);

  const chartSeries = [
    {
      name: 'Base Term Structure',
      color: '#38BDF8',
      data: curvePoints.map(p => ({ x: `${p.tenorYears}y`, y: p.baseYieldPct }))
    },
    {
      name: `Shocked Yield (${shiftType.toUpperCase()})`,
      color: '#F59E0B',
      data: curvePoints.map(p => ({ x: `${p.tenorYears}y`, y: p.shockedYieldPct })),
      dashed: true
    },
    {
      name: '1-Year Forward Rate',
      color: '#10B981',
      data: curvePoints.map(p => ({ x: `${p.tenorYears}y`, y: p.forwardRatePct }))
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            11. Yield Curve Workbench & Term Structure Modeling
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Nelson-Siegel parametric zero curves, forward rate curves, and macro yield shocks.
          </p>
        </div>

        {/* Shock Scenario Selector */}
        <div className="flex items-center gap-3 bg-[#111A2E] border border-slate-800 rounded p-2 text-xs">
          <span className="text-slate-400">Yield Shock:</span>
          <select
            value={shiftType}
            onChange={e => setShiftType(e.target.value as any)}
            className="bg-[#0B1120] border border-slate-700 text-slate-200 rounded px-2.5 py-1 font-mono"
          >
            <option value="none">Base Flat Curve (0 bps)</option>
            <option value="parallel">Parallel Shift (+{shockBps} bps)</option>
            <option value="steepening">Bear Steepener (+{shockBps} bps Long)</option>
            <option value="flattening">Inverted Flattener (-{shockBps} bps Long)</option>
            <option value="butterfly">Butterfly Twist (Humped)</option>
          </select>
        </div>
      </div>

      {/* Curve Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Short End"
          label="2-Year Benchmark Zero Rate"
          value={`${curvePoints.find(p => p.tenorYears === 2)?.shockedYieldPct.toFixed(2)}%`}
          unit={`(Base: ${curvePoints.find(p => p.tenorYears === 2)?.baseYieldPct.toFixed(2)}%)`}
          subtext="Money market and commercial paper"
        />
        <MetricCard
          kicker="Belly Tenor"
          label="10-Year Benchmark Rate"
          value={`${curvePoints.find(p => p.tenorYears === 10)?.shockedYieldPct.toFixed(2)}%`}
          unit={`(Base: ${curvePoints.find(p => p.tenorYears === 10)?.baseYieldPct.toFixed(2)}%)`}
          subtext="Infrastructure bond benchmark"
          status="nominal"
        />
        <MetricCard
          kicker="Long End"
          label="30-Year Concession Rate"
          value={`${curvePoints.find(p => p.tenorYears === 30)?.shockedYieldPct.toFixed(2)}%`}
          unit={`(Base: ${curvePoints.find(p => p.tenorYears === 30)?.baseYieldPct.toFixed(2)}%)`}
          subtext="Ultra-long project debt tenor"
        />
        <MetricCard
          kicker="Curve Slope"
          label="2s10s Term Spread"
          value={`${(
            (curvePoints.find(p => p.tenorYears === 10)?.shockedYieldPct || 0) -
            (curvePoints.find(p => p.tenorYears === 2)?.shockedYieldPct || 0)
          ).toFixed(2)}%`}
          unit="Slope (10Y - 2Y)"
          subtext="Monetary policy term premium"
          status="nominal"
        />
      </div>

      {/* Yield Curve Graph and Parametric Knobs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-sky-400" />
            <span>Nelson-Siegel Parameters</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>β0: Long-Term Level Asymptote</span>
                <span className="font-mono text-slate-200 font-bold">{(beta0 * 100).toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={0.015}
                max={0.070}
                step={0.001}
                value={beta0}
                onChange={e => setBeta0(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>β1: Short-Term Slope Parameter</span>
                <span className="font-mono text-slate-200 font-bold">{(beta1 * 100).toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={-0.040}
                max={0.020}
                step={0.001}
                value={beta1}
                onChange={e => setBeta1(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>β2: Medium-Term Curvature</span>
                <span className="font-mono text-slate-200 font-bold">{(beta2 * 100).toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={-0.030}
                max={0.040}
                step={0.001}
                value={beta2}
                onChange={e => setBeta2(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Shock Magnitude (Basis Points)</span>
                <span className="font-mono text-slate-200 font-bold">{shockBps} bps</span>
              </div>
              <input
                type="range"
                min={10}
                max={250}
                step={10}
                value={shockBps}
                onChange={e => setShockBps(Number(e.target.value))}
                className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <SvgLineChart
            title="Nelson-Siegel Zero-Coupon Spot & 1-Year Forward Yield Curves (%)"
            series={chartSeries}
            yUnit="%"
          />
        </div>
      </div>
    </div>
  );
};
