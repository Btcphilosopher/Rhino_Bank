import React from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateEconomicImpact } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { Globe2, Clock, Leaf, Users, ShieldAlert } from 'lucide-react';

interface EconomicImpactWorkspaceProps {
  project: RailwayProject;
}

export const EconomicImpactWorkspace: React.FC<EconomicImpactWorkspaceProps> = ({ project }) => {
  const econ = calculateEconomicImpact(project);

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          14. Economic Impact & Public Policy Interface (CBA Analysis)
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Wider socio-economic appraisal: Direct & indirect GVA, job creation, passenger time savings, and carbon abatement.
        </p>
      </div>

      {/* Economic KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Value Added Multiplier"
          label="Total Economic GVA"
          value={`€${(econ.totalGvaM / 1000).toFixed(2)}B`}
          unit={`(Leontief Type II)`}
          subtext={`Direct: €${econ.directGvaM.toLocaleString()}M · Indirect: €${econ.indirectGvaM.toLocaleString()}M`}
          status="nominal"
        />
        <MetricCard
          kicker="Labour Market"
          label="Direct Job-Years Created"
          value={`${econ.directJobYears.toLocaleString()}`}
          unit="Job-Years"
          subtext="Engineering, construction & supply chain"
          status="nominal"
        />
        <MetricCard
          kicker="User Productivity"
          label="Annual Travel Time Saved"
          value={`${econ.annualPassengerHoursSavedM.toFixed(1)}M hrs`}
          unit={`/ year`}
          subtext={`Social Value: €${econ.annualUserTimeBenefitM.toFixed(1)}M/yr`}
        />
        <MetricCard
          kicker="Environmental Social Value"
          label="CO2 Abatement Benefit"
          value={`${(econ.annualCo2TonnesAvoided / 1000).toFixed(0)}k Tonnes`}
          unit={`CO2 / yr`}
          subtext={`Carbon Value: €${econ.annualCarbonSocialValueM.toFixed(1)}M/yr (@ €95/t)`}
          status="nominal"
        />
      </div>

      {/* Benefit-Cost Ratio Card & Public Policy Memo */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-sky-400" />
              <span>Public Appraisal Ratio</span>
            </h3>
            <span className="text-xs text-emerald-400 font-mono">SOCIAL DISCOUNT 3.5%</span>
          </div>

          <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-center space-y-1">
            <div className="text-[11px] text-emerald-400 uppercase font-semibold tracking-wider">
              Socio-Economic Benefit-Cost Ratio (BCR)
            </div>
            <div className="text-3xl font-extrabold font-mono text-emerald-300">
              {econ.benefitCostRatio.toFixed(2)} : 1
            </div>
            <div className="text-xs text-slate-300 pt-1">
              "High Value for Money" under standard Treasury & EU appraisal guidelines.
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Average Time Saved:</span>
              <span className="font-mono text-slate-200">{project.timeSavedMinPerTrip} minutes / trip</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Value of Time (VOT):</span>
              <span className="font-mono text-slate-200">€{project.valueOfTimeEurHr.toFixed(2)} / hour</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">CO2 Saved vs Road/Air:</span>
              <span className="font-mono text-slate-200">{project.co2SavedKgPerPax} kg / passenger</span>
            </div>
          </div>
        </div>

        {/* Methodology & Anti-Double-Counting Guardrail */}
        <div className="lg:col-span-2 bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>RhinoQuant Methodological Guardrail: Anti-Double Counting</span>
          </h3>

          <div className="p-4 bg-[#111A2E] border border-slate-800/80 rounded space-y-3 text-xs leading-relaxed text-slate-300">
            <p>
              In accordance with Rhino Bank quantitative governance, <strong className="text-amber-300">economic welfare benefits are strictly segregated from commercial SPV project finance cash flows</strong>.
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-slate-400 text-[11px]">
              <li>
                <strong className="text-slate-200">Gross Output vs GVA:</strong> Gross supply-chain expenditure is not aggregated with GVA to avoid gross sales double-counting.
              </li>
              <li>
                <strong className="text-slate-200">Passenger Time Savings:</strong> Consumer surplus time savings belong to the traveling public and are not treated as cash available for debt service (CFADS).
              </li>
              <li>
                <strong className="text-slate-200">Property Value Uplift:</strong> Land value uplift is treated as a capitalisation of accessibility time savings, not as an additive distinct benefit.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
