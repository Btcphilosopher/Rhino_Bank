import React, { useState } from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateBondPricing } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgLineChart } from '../ui/ChartSvg';
import { ReceiptText, TrendingUp, Sliders, DollarSign } from 'lucide-react';

interface BondPricingWorkspaceProps {
  project: RailwayProject;
}

export const BondPricingWorkspace: React.FC<BondPricingWorkspaceProps> = ({ project }) => {
  const [couponPct, setCouponPct] = useState(4.85);
  const [marketYieldPct, setMarketYieldPct] = useState(4.60);
  const [maturityYrs, setMaturityYrs] = useState(24);
  const [freq, setFreq] = useState(2); // Semi-annual

  const bond = calculateBondPricing(
    100,
    couponPct / 100,
    maturityYrs,
    marketYieldPct / 100,
    freq,
    0.65
  );

  // Generate Price-Yield Curve for yields from 2.0% to 8.0%
  const yieldRange = [2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0];
  const priceYieldCurve = yieldRange.map(y => {
    const b = calculateBondPricing(100, couponPct / 100, maturityYrs, y / 100, freq, 0.65);
    return { x: `${y.toFixed(1)}%`, y: b.dirtyPrice };
  });

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          7. Infrastructure Bond Pricing & Sensitivity Engine
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Analytical fixed-income analytics: Clean & dirty pricing, Macaulay/modified duration, convexity, DV01, key-rate durations.
        </p>
      </div>

      {/* Bond Analytics KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Valuation"
          label="Dirty & Clean Price"
          value={`${bond.dirtyPrice.toFixed(2)}`}
          unit={`(Clean: ${bond.cleanPrice.toFixed(2)})`}
          subtext={`Accrued Interest: ${bond.accruedInterest.toFixed(2)} pts`}
          status={bond.dirtyPrice >= 100 ? 'nominal' : 'warning'}
        />
        <MetricCard
          kicker="Interest Rate Sensitivity"
          label="Modified Duration"
          value={`${bond.modifiedDuration.toFixed(2)}y`}
          unit={`(Macaulay: ${bond.macaulayDuration.toFixed(2)}y)`}
          subtext={`% price change per 100 bps shift`}
        />
        <MetricCard
          kicker="Curvature & Gamma"
          label="Convexity Measure"
          value={`${bond.convexity.toFixed(1)}`}
          unit="pts"
          subtext="Second-order price cushion"
          status="nominal"
        />
        <MetricCard
          kicker="Dollar Value of 01 bp"
          label="DV01 Sensitivity"
          value={`€${(bond.dv01 * 100).toFixed(2)}`}
          unit="per €100k notional"
          subtext={`Credit Spread: +${bond.spreadBps} bps vs Bund`}
        />
      </div>

      {/* Inputs and Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-sky-400" />
              <span>Bond Contract Parameters</span>
            </h3>
            <span className="text-[11px] text-sky-400 font-mono">SENIOR SECURED</span>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Annual Coupon Rate</span>
                <span className="font-mono text-slate-200 font-bold">{couponPct.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={1.5}
                max={9.0}
                step={0.05}
                value={couponPct}
                onChange={e => setCouponPct(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Market Yield to Maturity (YTM)</span>
                <span className="font-mono text-slate-200 font-bold">{marketYieldPct.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={1.5}
                max={9.0}
                step={0.05}
                value={marketYieldPct}
                onChange={e => setMarketYieldPct(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Maturity Tenor</span>
                <span className="font-mono text-slate-200 font-bold">{maturityYrs} Years</span>
              </div>
              <input
                type="range"
                min={5}
                max={40}
                step={1}
                value={maturityYrs}
                onChange={e => setMaturityYrs(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Coupon Payment Frequency</label>
              <select
                value={freq}
                onChange={e => setFreq(Number(e.target.value))}
                className="w-full bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-2.5 py-1.5"
              >
                <option value={1}>Annual (1 coupon / year)</option>
                <option value={2}>Semi-Annual (2 coupons / year - Market Standard)</option>
                <option value={4}>Quarterly (4 coupons / year)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Price-Yield Curve Chart */}
        <div className="lg:col-span-2">
          <SvgLineChart
            title="Non-linear Price-Yield Profile & Convexity Tangent"
            series={[
              {
                name: 'Synthetic Bond Price vs Market Yield',
                color: '#38BDF8',
                data: priceYieldCurve
              }
            ]}
            yUnit=" pts"
          />
        </div>
      </div>

      {/* Key-Rate Duration Decomposition Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">
          Key-Rate Duration Decomposition (Curve Shift Sensitivities)
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
          <div className="p-3 bg-[#111A2E] border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 block">2-Year Tenor</span>
            <span className="text-base font-bold font-mono text-sky-400">{bond.keyRate2y.toFixed(2)}y</span>
          </div>
          <div className="p-3 bg-[#111A2E] border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 block">5-Year Tenor</span>
            <span className="text-base font-bold font-mono text-sky-400">{bond.keyRate5y.toFixed(2)}y</span>
          </div>
          <div className="p-3 bg-[#111A2E] border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 block">10-Year Tenor</span>
            <span className="text-base font-bold font-mono text-sky-400">{bond.keyRate10y.toFixed(2)}y</span>
          </div>
          <div className="p-3 bg-[#111A2E] border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 block">20-Year Tenor</span>
            <span className="text-base font-bold font-mono text-sky-400">{bond.keyRate20y.toFixed(2)}y</span>
          </div>
          <div className="p-3 bg-[#111A2E] border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 block">30-Year Tenor</span>
            <span className="text-base font-bold font-mono text-sky-400">{bond.keyRate30y.toFixed(2)}y</span>
          </div>
        </div>
      </div>
    </div>
  );
};
