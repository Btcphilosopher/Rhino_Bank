import React from 'react';
import { RailwayProject } from '../../types/finance';
import {
  calculateCapexProfile,
  calculateProjectCashflows,
  validateProjectModel,
  calculateEconomicImpact
} from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { FileCheck, CheckCircle2, Download, ShieldCheck, Printer } from 'lucide-react';

interface ReportingWorkspaceProps {
  project: RailwayProject;
  onExportPack: () => void;
}

export const ReportingWorkspace: React.FC<ReportingWorkspaceProps> = ({
  project,
  onExportPack
}) => {
  const { totalFundingNeed, peakDebtBalance } = calculateCapexProfile(project);
  const {
    cashflows,
    debtSchedule,
    projectIrrPct,
    equityIrrPct,
    projectNpvM,
    equityNpvM,
    minDscr,
    avgDscr
  } = calculateProjectCashflows(project, peakDebtBalance);

  const audit = validateProjectModel(cashflows, debtSchedule);
  const econ = calculateEconomicImpact(project);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            15. Reporting, Governance & Model Audit Trail
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Formal Investment Committee memorandum, financial identity validations, and regulatory model inventory.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
          <button
            onClick={onExportPack}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 rounded transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Financial Pack (JSON/CSV)</span>
          </button>
        </div>
      </div>

      {/* Model Audit Validation Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Model Inventory"
          label="Governance Approval State"
          value={audit.validationStatus}
          unit="Tier 1 Model"
          subtext={`Version: ${audit.version}`}
          status="nominal"
        />
        <MetricCard
          kicker="Accounting Integrity"
          label="EBITDA Identity Check"
          value={audit.ebitdaIdentityVerified ? '100% RECONCILED' : 'DISCREPANCY'}
          unit="Tolerance < 0.05"
          subtext="Revenue - OPEX === EBITDA"
          status={audit.ebitdaIdentityVerified ? 'nominal' : 'alert'}
        />
        <MetricCard
          kicker="Debt Amortisation"
          label="Balance Roll-Forward"
          value={audit.debtRollForwardVerified ? '100% BALANCED' : 'IMBALANCE'}
          unit="Opening - Principal === Closing"
          subtext="Zero balance at maturity verified"
          status={audit.debtRollForwardVerified ? 'nominal' : 'alert'}
        />
        <MetricCard
          kicker="Verification Log"
          label="Audit Verification Timestamp"
          value={new Date().toLocaleDateString()}
          unit={new Date().toLocaleTimeString()}
          subtext="Deterministic computation engine"
        />
      </div>

      {/* Investment Committee Memorandum Paper View */}
      <div className="bg-[#0D1424] border border-slate-700/80 rounded-lg p-8 space-y-6 text-slate-200 font-sans shadow-xl">
        <div className="border-b border-slate-700 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-widest text-sky-400">
              Rhino Bank · Infrastructure Finance Division · Credit & Investment Committee
            </div>
            <h1 className="text-xl font-bold text-white mt-1">
              FINANCIAL EVALUATION MEMORANDUM: {project.name.toUpperCase()}
            </h1>
            <div className="text-xs text-slate-400 mt-1">
              Project Code: <span className="font-mono text-slate-200">{project.id}</span> · Reference Model: Synthetic Railway Project Finance Engine
            </div>
          </div>
          <div className="text-right">
            <span className="inline-block px-3 py-1 bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-xs font-mono font-bold rounded">
              APPROVED FOR STRUCTURING
            </span>
          </div>
        </div>

        {/* Section 1: Executive Summary */}
        <div className="space-y-3 text-xs leading-relaxed">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-1 uppercase tracking-wide text-sky-300">
            1. Executive Financing Summary
          </h3>
          <p className="text-slate-300">
            RhinoQuant has structured the project finance facility for the <strong>{project.name}</strong>, comprising a <strong>{project.routeLengthKm} km</strong> railway corridor engineered for <strong>{project.designSpeedKmh} km/h</strong> operational speeds under <strong>{project.signallingCategory}</strong>.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-[#111A2E] rounded border border-slate-800 font-mono text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">Total Capital Need</span>
              <span className="text-base font-bold text-white">{project.currency} {totalFundingNeed.toLocaleString()}M</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Senior Debt (Gearing)</span>
              <span className="text-base font-bold text-sky-400">{project.currency} {peakDebtBalance.toLocaleString()}M ({(project.debtFundingRatio * 100).toFixed(0)}%)</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Unlevered Project IRR</span>
              <span className="text-base font-bold text-emerald-400">{projectIrrPct.toFixed(2)}%</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Sponsor Equity IRR</span>
              <span className="text-base font-bold text-sky-300">{equityIrrPct.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        {/* Section 2: Credit Metrics */}
        <div className="space-y-3 text-xs leading-relaxed">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-1 uppercase tracking-wide text-sky-300">
            2. Debt Covenants & Amortisation Profile
          </h3>
          <p className="text-slate-300">
            The senior debt facility of <strong>{project.currency} {peakDebtBalance.toLocaleString()}M</strong> is structured under target-DSCR sculpting at <strong>{project.targetDscr.toFixed(2)}x</strong> over a <strong>{project.debtTenorYears}-year</strong> tenor at a fixed interest rate of <strong>{(project.seniorDebtRate * 100).toFixed(2)}%</strong>. The minimum operational DSCR is <strong>{minDscr.toFixed(2)}x</strong>, providing adequate headroom above the 1.20x default covenant threshold.
          </p>
        </div>

        {/* Section 3: Socio-Economic Impact */}
        <div className="space-y-3 text-xs leading-relaxed">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-1 uppercase tracking-wide text-sky-300">
            3. Socio-Economic Cost-Benefit Evaluation (CBA)
          </h3>
          <p className="text-slate-300">
            Under Treasury / EU CBA guidelines, the corridor generates <strong>€{(econ.totalGvaM / 1000).toFixed(2)}B</strong> in direct & indirect Gross Value Added, supports <strong>{econ.directJobYears.toLocaleString()} job-years</strong>, and delivers <strong>{econ.annualPassengerHoursSavedM.toFixed(1)}M hours</strong> in annual passenger time savings, yielding an economic Benefit-Cost Ratio of <strong>{econ.benefitCostRatio.toFixed(2)} : 1</strong>.
          </p>
        </div>

        {/* Committee Sign-off */}
        <div className="pt-6 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400 font-mono">
          <div>Rhino Bank Infrastructure & Structured Debt Committee · Strictly Confidential</div>
          <div>Audited & Validated: RHINO-RAIL-FIN-V1.0.0</div>
        </div>
      </div>
    </div>
  );
};
