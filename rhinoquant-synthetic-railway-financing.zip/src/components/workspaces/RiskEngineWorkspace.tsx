import React, { useState } from 'react';
import { RailwayProject } from '../../types/finance';
import { runMonteCarlo, calculateCapexProfile } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgBarChart } from '../ui/ChartSvg';
import { ShieldAlert, Play, RefreshCw, AlertTriangle } from 'lucide-react';

interface RiskEngineWorkspaceProps {
  project: RailwayProject;
}

export const RiskEngineWorkspace: React.FC<RiskEngineWorkspaceProps> = ({ project }) => {
  const [capexVol, setCapexVol] = useState(0.18);
  const [revVol, setRevVol] = useState(0.14);
  const [nSims, setNSims] = useState(2500);
  const [simSeed, setSimSeed] = useState(1);

  const { totalFundingNeed, peakDebtBalance } = calculateCapexProfile(project);
  const baseCfads = project.initialRevenueM * 0.72 - project.initialOpexM;
  const annualDebtService = peakDebtBalance / project.debtTenorYears + peakDebtBalance * project.seniorDebtRate * 0.55;

  const mc = runMonteCarlo(
    totalFundingNeed,
    baseCfads,
    annualDebtService,
    capexVol,
    revVol,
    nSims
  );

  const histogramData = mc.distributionBins.map(b => ({
    label: `${b.binStart}`,
    value1: b.count
  }));

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            10. Stochastic Risk Engine & Monte Carlo Simulation
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Correlated multi-factor Monte Carlo: Construction overrun, traffic demand shocks, Value at Risk (VaR), and CVaR.
          </p>
        </div>
        <button
          onClick={() => setSimSeed(s => s + 1)}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 rounded transition-colors flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Rerun Simulation ({nSims.toLocaleString()} Paths)</span>
        </button>
      </div>

      {/* Risk Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Downside Risk (95%)"
          label="Value at Risk (VaR 95%)"
          value={`€${mc.var95M.toLocaleString()}M`}
          unit="NPV"
          subtext={`P10: €${mc.p10NpvM.toLocaleString()}M · P90: €${mc.p90NpvM.toLocaleString()}M`}
          status={mc.var95M < 0 ? 'alert' : 'warning'}
        />
        <MetricCard
          kicker="Tail Loss Severity"
          label="Conditional VaR (CVaR 95%)"
          value={`€${mc.cvar95M.toLocaleString()}M`}
          unit="Expected Shortfall"
          subtext="Mean loss beyond 95th percentile"
          status="alert"
        />
        <MetricCard
          kicker="Covenant Vulnerability"
          label="DSCR Breach Probability"
          value={`${mc.dscrBreachProbabilityPct.toFixed(1)}%`}
          unit="P(DSCR < 1.20x)"
          subtext={`Mean DSCR: ${mc.meanDscr.toFixed(2)}x · Min: ${mc.minDscr.toFixed(2)}x`}
          status={mc.dscrBreachProbabilityPct > 5 ? 'alert' : 'nominal'}
        />
        <MetricCard
          kicker="Equity Impairment"
          label="Negative Equity NPV Risk"
          value={`${mc.equityNpvNegativeProbPct.toFixed(1)}%`}
          unit="Probability"
          subtext={`Median Project NPV: €${mc.medianNpvM.toLocaleString()}M`}
          status={mc.equityNpvNegativeProbPct > 10 ? 'warning' : 'nominal'}
        />
      </div>

      {/* Simulation Controls & Histogram */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-sky-400" />
            <span>Stochastic Volatility Calibration</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Capex Overrun Volatility (Std Dev)</span>
                <span className="font-mono text-slate-200 font-bold">{(capexVol * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min={0.05}
                max={0.35}
                step={0.01}
                value={capexVol}
                onChange={e => setCapexVol(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Passenger Revenue Volatility (Std Dev)</span>
                <span className="font-mono text-slate-200 font-bold">{(revVol * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min={0.05}
                max={0.30}
                step={0.01}
                value={revVol}
                onChange={e => setRevVol(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Simulation Iteration Count</span>
                <span className="font-mono text-slate-200 font-bold">{nSims.toLocaleString()}</span>
              </div>
              <select
                value={nSims}
                onChange={e => setNSims(Number(e.target.value))}
                className="w-full bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-2.5 py-1.5 font-mono"
              >
                <option value={1000}>1,000 Iterations (Fast Prototyping)</option>
                <option value={2500}>2,500 Iterations (Recommended Benchmark)</option>
                <option value={5000}>5,000 Iterations (Production Precision)</option>
              </select>
            </div>

            <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded text-[11px] text-slate-400 leading-relaxed">
              <span className="font-semibold text-slate-300">Methodology Governance: </span>
              Correlated bivariate shocks are sampled via Box-Muller normal transforms with empirical cross-correlation ρ = 0.42 between infrastructure construction cost inflation and passenger demand cycles.
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <SvgBarChart
            title={`Simulated Project Net Present Value (NPV) Frequency Distribution (€ Millions)`}
            data={histogramData}
            label1="Path Frequency"
            yUnit=""
          />
        </div>
      </div>
    </div>
  );
};
