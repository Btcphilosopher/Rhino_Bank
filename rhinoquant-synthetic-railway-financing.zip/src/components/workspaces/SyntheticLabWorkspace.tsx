import React, { useState } from 'react';
import { RailwayProject, SyntheticInstrument } from '../../types/finance';
import { MetricCard } from '../ui/MetricCard';
import { FlaskConical, Layers, Shield, FileText, CheckCircle2 } from 'lucide-react';

interface SyntheticLabWorkspaceProps {
  project: RailwayProject;
}

const DEFAULT_INSTRUMENTS: SyntheticInstrument[] = [
  {
    id: 'SYN-CLN-01',
    name: 'Trans-Alpine Railway Infrastructure Credit-Linked Note',
    type: 'Credit-Linked Note (CLN)',
    referenceProject: 'SYN-HSR-01 (Trans-Alpine HSR)',
    notionalM: 250,
    currency: 'EUR',
    tenorYears: 10,
    attachmentPct: 0.15,
    detachmentPct: 0.35,
    couponSpreadBps: 265,
    referenceIndex: 'EURIBOR 6M + 265 bps',
    triggerEvent: 'Concession SPV Payment Failure or Debt Rescheduling (>60 days grace)',
    lossAllocationMechanism: 'Sequential write-down of notional upon confirmed credit event',
    seniority: 'Mezzanine',
    counterparty: 'Rhino Bank Special Purpose Vehicle (Synthetic Issuer)',
    collateralRequirement: '100% Eligible High Quality Liquid Assets (OAT / Bunds)',
    settlementType: 'Cash Settled',
    terminationFeeM: 5.0,
    governingLaw: 'English Law / ISDA 2014 Credit Derivatives Definitions'
  },
  {
    id: 'SYN-REV-02',
    name: 'Passenger Traffic Volume Synthetic Revenue Tranche',
    type: 'Synthetic Revenue Note',
    referenceProject: 'SYN-HSR-01 (Trans-Alpine HSR)',
    notionalM: 150,
    currency: 'EUR',
    tenorYears: 7,
    attachmentPct: 0.0,
    detachmentPct: 0.15,
    couponSpreadBps: 420,
    referenceIndex: 'Passenger-Km Volume Index (Base 2,900M pkm)',
    triggerEvent: 'Annual passenger-km drops below 80% of base target (Volume < 2,320M pkm)',
    lossAllocationMechanism: 'Pro-rata coupon reduction proportional to traffic volume deficit',
    seniority: 'First-Loss Equity',
    counterparty: 'Infrastructure Pension Fund Consortium',
    collateralRequirement: 'Segregated Tri-Party Repo Account',
    settlementType: 'Cash Settled',
    terminationFeeM: 2.5,
    governingLaw: 'Swiss Commercial Code / Rhino Standard Structured Terms'
  },
  {
    id: 'SYN-OVR-03',
    name: 'Tunnelling & Civil Works Cost-Overrun Participation Facility',
    type: 'Cost-Overrun Guarantee',
    referenceProject: 'SYN-HSR-01 (Trans-Alpine HSR)',
    notionalM: 300,
    currency: 'EUR',
    tenorYears: 6,
    attachmentPct: 0.15,
    detachmentPct: 0.30,
    couponSpreadBps: 340,
    referenceIndex: 'Independent Engineer Certified Capex Expenditure Index',
    triggerEvent: 'Cumulative certified capex exceeds base budget by >15% (€1,267M)',
    lossAllocationMechanism: 'Mandatory subordinated liquidity loan injection at Euribor + 450 bps',
    seniority: 'Mezzanine',
    counterparty: 'European Infrastructure Debt Fund',
    collateralRequirement: 'Irrevocable Standby Letter of Credit',
    settlementType: 'Physical Delivery',
    terminationFeeM: 7.5,
    governingLaw: 'Luxembourg Law (Securitisation Act 2004)'
  }
];

export const SyntheticLabWorkspace: React.FC<SyntheticLabWorkspaceProps> = ({ project }) => {
  const [selectedInstId, setSelectedInstId] = useState('SYN-CLN-01');
  const [instruments, setInstruments] = useState<SyntheticInstrument[]>(DEFAULT_INSTRUMENTS);

  const activeInst = instruments.find(i => i.id === selectedInstId) || instruments[0];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            8. Synthetic Railway Instrument Structuring Laboratory
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Design and evaluate hypothetical credit-linked notes, synthetic revenue tranches, and overrun participation facilities.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400">Select Instrument:</label>
          <select
            value={selectedInstId}
            onChange={e => setSelectedInstId(e.target.value)}
            className="bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-3 py-1.5 focus:outline-none focus:border-sky-500 font-mono"
          >
            {instruments.map(i => (
              <option key={i.id} value={i.id}>
                {i.id} - {i.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Synthetic Exposure"
          label="Notional & Currency"
          value={`${activeInst.currency} ${activeInst.notionalM}M`}
          unit={`Tenor: ${activeInst.tenorYears}y`}
          subtext={`Tranche: ${activeInst.seniority}`}
          status="nominal"
        />
        <MetricCard
          kicker="Yield Compensation"
          label="Coupon Margin / Spread"
          value={`+${activeInst.couponSpreadBps} bps`}
          unit={`over ${activeInst.referenceIndex.split(' ')[0]}`}
          subtext={`Pricing Spread to Risk-Free`}
        />
        <MetricCard
          kicker="Loss Attachment"
          label="Tranche Attachment Window"
          value={`${(activeInst.attachmentPct * 100).toFixed(0)}% – ${(activeInst.detachmentPct * 100).toFixed(0)}%`}
          unit="of Capital"
          subtext={`Thickness: ${((activeInst.detachmentPct - activeInst.attachmentPct) * 100).toFixed(0)}%`}
          status="warning"
        />
        <MetricCard
          kicker="Collateral Model"
          label="Settlement & Collateral"
          value={activeInst.settlementType}
          unit="Convention"
          subtext={activeInst.collateralRequirement.slice(0, 32) + '...'}
        />
      </div>

      {/* Detailed Term Sheet Specifications */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-sky-400" />
                <span>{activeInst.name}</span>
              </h3>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Instrument Class: <span className="text-sky-300 font-mono">{activeInst.type}</span> · Reference: {activeInst.referenceProject}
              </div>
            </div>
            <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded text-[11px] font-mono">
              HYPOTHETICAL / SYNTHETIC
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 bg-[#111A2E] rounded border border-slate-800/80">
              <div>
                <span className="text-slate-400 block text-[11px]">Seniority & Subordination</span>
                <span className="font-semibold text-slate-200">{activeInst.seniority} Tranche</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Benchmark Reference Index</span>
                <span className="font-semibold text-slate-200 font-mono">{activeInst.referenceIndex}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Counterparty & Issuer</span>
                <span className="font-semibold text-slate-200">{activeInst.counterparty}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Governing Jurisdiction</span>
                <span className="font-semibold text-slate-200">{activeInst.governingLaw}</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded space-y-1.5">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span>Trigger Event Condition:</span>
              </span>
              <p className="text-slate-400 leading-relaxed font-mono text-[11px]">
                {activeInst.triggerEvent}
              </p>
            </div>

            <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded space-y-1.5">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                <span>Loss & Shortfall Allocation Mechanism:</span>
              </span>
              <p className="text-slate-400 leading-relaxed font-mono text-[11px]">
                {activeInst.lossAllocationMechanism}
              </p>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer & Regulatory Warning */}
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>RhinoQuant Legal Boundary</span>
          </h3>

          <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-md text-[11px] text-amber-300/90 leading-relaxed space-y-2">
            <div className="font-bold uppercase tracking-wide">Mandatory Regulatory Notice:</div>
            <p>
              This synthetic exposure represents a contractual derivative claim referenced to physical railway metrics. It does NOT constitute a direct legal claim, ownership interest, mortgage, or lien upon the physical permanent way, locomotives, or sovereign concessions.
            </p>
            <p>
              Instruments are designed strictly for internal balance-sheet risk simulation and cannot be marketed or traded without ISDA master documentation, regulatory capital approval, and documented legal enforceability.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
