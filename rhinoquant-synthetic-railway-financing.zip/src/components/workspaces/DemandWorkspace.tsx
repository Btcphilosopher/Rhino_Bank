import React from 'react';
import { RailwayProject } from '../../types/finance';
import { MetricCard } from '../ui/MetricCard';
import { TrendingUp, Users, Package, Store, Award } from 'lucide-react';

interface DemandWorkspaceProps {
  project: RailwayProject;
  onUpdateProject: (p: RailwayProject) => void;
}

export const DemandWorkspace: React.FC<DemandWorkspaceProps> = ({
  project,
  onUpdateProject
}) => {
  const paxKmAnnualM = project.initialAnnualPaxM * project.avgTripLengthKm;
  const annualFareRevenueM = paxKmAnnualM * project.fareYieldPerPkm;

  const annualFreightRevenueM =
    project.initialAnnualFreightTonnesM > 0
      ? project.initialAnnualFreightTonnesM * 400 * project.freightTariffPerNtkm
      : 0;

  const commercialTrackAccessM = project.initialRevenueM * 0.12;
  const availabilityPaymentsM = project.initialRevenueM * 0.08;
  const totalModelledGrossRevenueM =
    annualFareRevenueM + annualFreightRevenueM + commercialTrackAccessM + availabilityPaymentsM;

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          4. Passenger & Freight Demand and Operating Revenue
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Explicit operational demand models: Passenger-km yield, freight NTKM tariffs, commercial access, availability payments.
        </p>
      </div>

      {/* KPI Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Passenger Demand"
          label="Passenger Volume & Yield"
          value={`${project.initialAnnualPaxM.toFixed(1)}M Pax`}
          unit={`@ €${project.fareYieldPerPkm.toFixed(3)}/pkm`}
          subtext={`Avg Trip: ${project.avgTripLengthKm} km · ${paxKmAnnualM.toFixed(0)}M pkm/yr`}
          status="nominal"
        />
        <MetricCard
          kicker="Freight Haulage"
          label="Freight Cargo Tonnage"
          value={
            project.initialAnnualFreightTonnesM > 0
              ? `${project.initialAnnualFreightTonnesM.toFixed(1)}M Tonnes`
              : 'N/A (Pax Exclusive)'
          }
          unit={project.initialAnnualFreightTonnesM > 0 ? `@ €${project.freightTariffPerNtkm.toFixed(3)}/ntkm` : ''}
          subtext={project.initialAnnualFreightTonnesM > 0 ? 'Heavy axle load corridor' : 'No freight allocation'}
        />
        <MetricCard
          kicker="Farebox & Haulage"
          label="Direct Traffic Revenues"
          value={`${project.currency} ${(annualFareRevenueM + annualFreightRevenueM).toFixed(1)}M`}
          unit="/ year"
          subtext={`Pax: ${annualFareRevenueM.toFixed(1)}M · Frt: ${annualFreightRevenueM.toFixed(1)}M`}
        />
        <MetricCard
          kicker="All-in Gross Inflows"
          label="Opening Year Gross Inflows"
          value={`${project.currency} ${totalModelledGrossRevenueM.toFixed(1)}M`}
          unit="/ year"
          subtext={`Incl. Track Access & Availability`}
          status="nominal"
        />
      </div>

      {/* Detailed Revenue Stream Parameter Tuning */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Passenger Fare Economics */}
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-sky-400" />
              <span>Passenger Traffic & Elasticity</span>
            </h3>
            <span className="text-xs text-sky-400 font-mono">
              Growth: {(project.paxGrowthRate * 100).toFixed(1)}% p.a.
            </span>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Initial Annual Passengers (Millions)</span>
                <span className="font-mono text-slate-200 font-bold">{project.initialAnnualPaxM.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min={0.5}
                max={150}
                step={0.5}
                value={project.initialAnnualPaxM}
                onChange={e => onUpdateProject({ ...project, initialAnnualPaxM: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Average Passenger Journey Length (km)</span>
                <span className="font-mono text-slate-200 font-bold">{project.avgTripLengthKm} km</span>
              </div>
              <input
                type="range"
                min={5}
                max={project.routeLengthKm}
                step={1}
                value={project.avgTripLengthKm}
                onChange={e => onUpdateProject({ ...project, avgTripLengthKm: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Fare Yield ({project.currency} per passenger-km)</span>
                <span className="font-mono text-slate-200 font-bold">{project.currency} {project.fareYieldPerPkm.toFixed(3)}</span>
              </div>
              <input
                type="range"
                min={0.05}
                max={0.80}
                step={0.005}
                value={project.fareYieldPerPkm}
                onChange={e => onUpdateProject({ ...project, fareYieldPerPkm: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 text-[11px] text-slate-400">
              <span className="font-semibold text-slate-300">Revenue Distinction: </span>
              Concession operator farebox revenue is strictly segregated from track access charges levied on third-party open-access train operating companies.
            </div>
          </div>
        </div>

        {/* Freight, Ancillary & Availability Support */}
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-400" />
              <span>Freight, Access Charges & Sovereign Support</span>
            </h3>
            <span className="text-xs text-emerald-400 font-mono">
              Non-Fare: {project.currency} {(commercialTrackAccessM + availabilityPaymentsM).toFixed(1)}M
            </span>
          </div>

          <div className="space-y-4 text-xs">
            {project.freightCapacityAnnualTonnes > 0 && (
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Contracted Freight Volume (Million Tonnes)</span>
                  <span className="font-mono text-slate-200 font-bold">{project.initialAnnualFreightTonnesM.toFixed(1)}M</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={45}
                  step={0.5}
                  value={project.initialAnnualFreightTonnesM}
                  onChange={e => onUpdateProject({ ...project, initialAnnualFreightTonnesM: Number(e.target.value) })}
                  className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded">
                <div className="flex items-center gap-2 text-slate-300 font-medium">
                  <Store className="w-3.5 h-3.5 text-amber-400" />
                  <span>Station Retail & Access</span>
                </div>
                <div className="mt-2 text-lg font-bold font-mono text-white">
                  {project.currency} {commercialTrackAccessM.toFixed(1)}M
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Fibre optics & concourse retail
                </div>
              </div>

              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded">
                <div className="flex items-center gap-2 text-slate-300 font-medium">
                  <Award className="w-3.5 h-3.5 text-sky-400" />
                  <span>Availability Payments</span>
                </div>
                <div className="mt-2 text-lg font-bold font-mono text-white">
                  {project.currency} {availabilityPaymentsM.toFixed(1)}M
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Sovereign performance floor
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 text-[11px] text-slate-400">
              <span className="font-semibold text-slate-300">Capacity Bottleneck Constraint: </span>
              When traffic demand exceeds UIC 406 line capacity limits, peak hour ticket pricing yields surge automatically to reflect scarcity rents while unaccommodated volume spills to secondary services.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
