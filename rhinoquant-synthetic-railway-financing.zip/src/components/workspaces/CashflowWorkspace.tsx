import React, { useState } from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateCapexProfile, calculateProjectCashflows } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgLineChart } from '../ui/ChartSvg';
import { Banknote, Percent, TrendingUp, Layers } from 'lucide-react';

interface CashflowWorkspaceProps {
  project: RailwayProject;
}

export const CashflowWorkspace: React.FC<CashflowWorkspaceProps> = ({ project }) => {
  const [revStress, setRevStress] = useState(1.0);
  const [opexStress, setOpexStress] = useState(1.0);

  const { peakDebtBalance } = calculateCapexProfile(project);
  const {
    cashflows,
    projectIrrPct,
    equityIrrPct,
    projectNpvM,
    equityNpvM,
    minDscr,
    avgDscr
  } = calculateProjectCashflows(project, peakDebtBalance, revStress, opexStress);

  const cashflowChartSeries = [
    {
      name: 'Gross Revenues',
      color: '#38BDF8',
      data: cashflows.slice(0, 20).map(c => ({ x: `Y${c.year}`, y: c.grossRevenue }))
    },
    {
      name: 'Operating Expenses',
      color: '#F43F5E',
      data: cashflows.slice(0, 20).map(c => ({ x: `Y${c.year}`, y: c.operatingCosts })),
      dashed: true
    },
    {
      name: 'CFADS (Cash for Debt Service)',
      color: '#10B981',
      data: cashflows.slice(0, 20).map(c => ({ x: `Y${c.year}`, y: c.cfads }))
    },
    {
      name: 'Debt Service',
      color: '#F59E0B',
      data: cashflows.slice(0, 20).map(c => ({ x: `Y${c.year}`, y: c.debtService }))
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            5. Project Cash Flow & Financial Model (CFADS Engine)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Transparent annual project-finance accounting: EBITDA, renewals, corporate tax, CFADS, FCFE, IRR & NPV.
          </p>
        </div>

        {/* Real-time Stress Sliders */}
        <div className="flex items-center gap-4 bg-[#111A2E] border border-slate-800 rounded p-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Revenue Stress:</span>
            <select
              value={revStress}
              onChange={e => setRevStress(Number(e.target.value))}
              className="bg-[#0B1120] border border-slate-700 text-slate-200 rounded px-2 py-1 font-mono"
            >
              <option value={1.15}>+15% Bull Case</option>
              <option value={1.0}>100% Base Forecast</option>
              <option value={0.9}>-10% Mild Drop</option>
              <option value={0.8}>-20% Traffic Shock</option>
              <option value={0.7}>-30% Severe Depression</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400">OPEX Stress:</span>
            <select
              value={opexStress}
              onChange={e => setOpexStress(Number(e.target.value))}
              className="bg-[#0B1120] border border-slate-700 text-slate-200 rounded px-2 py-1 font-mono"
            >
              <option value={0.95}>-5% Efficiency</option>
              <option value={1.0}>100% Base OPEX</option>
              <option value={1.15}>+15% Energy Spike</option>
              <option value={1.30}>+30% Severe Inflation</option>
            </select>
          </div>
        </div>
      </div>

      {/* Financial Return KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Unlevered Project Return"
          label="Project IRR & NPV (6%)"
          value={`${projectIrrPct.toFixed(2)}%`}
          unit={`NPV: ${project.currency} ${projectNpvM.toLocaleString()}M`}
          subtext="Unlevered pre-debt return"
          status={projectIrrPct >= 6.0 ? 'nominal' : 'warning'}
        />
        <MetricCard
          kicker="Sponsor Equity Return"
          label="Levered Equity IRR & NPV (9.5%)"
          value={`${equityIrrPct.toFixed(2)}%`}
          unit={`NPV: ${project.currency} ${equityNpvM.toLocaleString()}M`}
          subtext="Return to equity holders after debt"
          status={equityIrrPct >= 9.5 ? 'nominal' : 'alert'}
        />
        <MetricCard
          kicker="Debt Safety Metric"
          label="Minimum DSCR in Ops"
          value={`${minDscr.toFixed(2)}x`}
          unit={`(Target: ${project.targetDscr.toFixed(2)}x)`}
          subtext={`Average DSCR: ${avgDscr.toFixed(2)}x`}
          status={minDscr >= 1.25 ? 'nominal' : minDscr >= 1.10 ? 'warning' : 'alert'}
        />
        <MetricCard
          kicker="Opening CFADS"
          label="Year 1 Cash for Debt Service"
          value={`${project.currency} ${cashflows[0]?.cfads.toLocaleString()}M`}
          unit={`/ ${cashflows[0]?.debtService.toLocaleString()}M DS`}
          subtext={`First-Year DSCR: ${cashflows[0]?.dscr.toFixed(2)}x`}
          status="nominal"
        />
      </div>

      {/* Trajectory Chart */}
      <SvgLineChart
        title={`Annual Cash Flow Waterfall Evolution (${project.currency} Millions)`}
        series={cashflowChartSeries}
        yUnit="M"
      />

      {/* Complete Financial Cash Flow Statement Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-[#111A2E]">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Comprehensive Annual Concession Cash Flow Statement
          </span>
          <span className="text-[11px] text-slate-400">
            Discount Rates: Project 6.0% · Equity 9.5%
          </span>
        </div>
        <div className="overflow-x-auto max-h-[460px]">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0B1120] text-slate-400 font-medium border-b border-slate-800 sticky top-0 z-10">
              <tr>
                <th className="px-3 py-2">Year</th>
                <th className="px-3 py-2">Cal</th>
                <th className="px-3 py-2 text-right">Gross Rev</th>
                <th className="px-3 py-2 text-right">OPEX</th>
                <th className="px-3 py-2 text-right font-semibold text-slate-200">EBITDA</th>
                <th className="px-3 py-2 text-right text-rose-400">Renewals</th>
                <th className="px-3 py-2 text-right text-slate-400">Tax</th>
                <th className="px-3 py-2 text-right font-bold text-emerald-400">CFADS</th>
                <th className="px-3 py-2 text-right text-amber-400">Debt Svc</th>
                <th className="px-3 py-2 text-right text-sky-400">FCFE</th>
                <th className="px-3 py-2 text-right font-mono text-slate-200">DSCR</th>
                <th className="px-3 py-2 text-right font-mono text-slate-300">LLCR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {cashflows.map(c => (
                <tr key={c.year} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-3 py-2 text-slate-300">Year {c.year}</td>
                  <td className="px-3 py-2 text-slate-400">{c.calendarYear}</td>
                  <td className="px-3 py-2 text-right text-slate-200 tabular-nums">{c.grossRevenue.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right text-slate-400 tabular-nums">{c.operatingCosts.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right font-semibold text-slate-200 tabular-nums">{c.ebitda.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right text-rose-400 tabular-nums">
                    {c.majorRenewals > 0 ? `-${c.majorRenewals.toLocaleString()}` : '—'}
                  </td>
                  <td className="px-3 py-2 text-right text-slate-400 tabular-nums">{c.corporateTax.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right font-bold text-emerald-400 tabular-nums">
                    {c.cfads.toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-right text-amber-400 tabular-nums">
                    {c.debtService > 0 ? c.debtService.toLocaleString() : '—'}
                  </td>
                  <td className="px-3 py-2 text-right text-sky-400 tabular-nums">{c.fcfe.toLocaleString()}</td>
                  <td className={`px-3 py-2 text-right font-bold tabular-nums ${
                    c.dscr === 0 ? 'text-slate-400' : c.dscr < 1.20 ? 'text-rose-400' : 'text-emerald-400'
                  }`}>
                    {c.dscr > 0 ? `${c.dscr.toFixed(2)}x` : '—'}
                  </td>
                  <td className="px-3 py-2 text-right text-slate-300 tabular-nums">
                    {c.llcr > 0 ? `${c.llcr.toFixed(2)}x` : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
