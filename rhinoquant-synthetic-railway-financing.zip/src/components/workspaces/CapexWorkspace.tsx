import React, { useState } from 'react';
import { RailwayProject } from '../../types/finance';
import { calculateCapexProfile } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgBarChart, SvgLineChart } from '../ui/ChartSvg';
import { HardHat, Clock, AlertTriangle } from 'lucide-react';

interface CapexWorkspaceProps {
  project: RailwayProject;
  onUpdateProject: (p: RailwayProject) => void;
}

export const CapexWorkspace: React.FC<CapexWorkspaceProps> = ({
  project,
  onUpdateProject
}) => {
  const [delayMonths, setDelayMonths] = useState(0);

  const {
    schedule,
    totalFundingNeed,
    totalEscalatedCapex,
    totalIdc,
    peakDebtBalance
  } = calculateCapexProfile(project, delayMonths);

  const capexBarData = schedule.map(s => ({
    label: `Y${s.year}`,
    value1: s.escalatedCapex,
    value2: s.idc
  }));

  const cumulativeDebtCurve = schedule.reduce<{ x: string; y: number }[]>((acc, s, i) => {
    const prev = i > 0 ? acc[i - 1].y : 0;
    acc.push({ x: `Y${s.year}`, y: prev + s.debtDrawn + s.idc });
    return acc;
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            3. Capital Expenditure & Construction Risk Schedule
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            S-Curve disbursement, cost escalation vs. CPI, capitalised Interest During Construction (IDC).
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Simulate Schedule Delay:</span>
          </div>
          <select
            value={delayMonths}
            onChange={e => setDelayMonths(Number(e.target.value))}
            className="bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-3 py-1.5 font-mono"
          >
            <option value={0}>On Schedule (0 mo)</option>
            <option value={12}>+12 Months Delay</option>
            <option value={24}>+24 Months Delay</option>
            <option value={36}>+36 Months Severe Delay</option>
          </select>
        </div>
      </div>

      {/* Capex KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Total Funding Need"
          label="All-in Funding Requirement"
          value={`${project.currency} ${(totalFundingNeed / 1000).toFixed(2)}B`}
          unit={`(Escalated + IDC)`}
          subtext={`Base: ${project.currency} ${(project.baseCapexM / 1000).toFixed(2)}B`}
          status={delayMonths > 0 ? 'warning' : 'nominal'}
        />
        <MetricCard
          kicker="Financing Burden"
          label="Capitalised Interest (IDC)"
          value={`${project.currency} ${totalIdc.toLocaleString()}M`}
          unit={`@ ${(project.constructionDebtRate * 100).toFixed(1)}% p.a.`}
          subtext={`Cumulative interest during build`}
          status={delayMonths > 0 ? 'alert' : 'neutral'}
        />
        <MetricCard
          kicker="Credit Exposure"
          label="Peak Debt Balance at COD"
          value={`${project.currency} ${peakDebtBalance.toLocaleString()}M`}
          unit="at Commercial Ops Date"
          subtext={`Senior Gearing: ${(project.debtFundingRatio * 100).toFixed(0)}%`}
        />
        <MetricCard
          kicker="Schedule Timeline"
          label="Commercial Operational Start"
          value={`${project.operationalStartYear + Math.ceil(delayMonths / 12)}`}
          unit={delayMonths > 0 ? `(+${delayMonths}m delay)` : 'Target COD'}
          subtext={`Asset Life: ${project.assetLifeYears} yrs`}
          status={delayMonths > 0 ? 'warning' : 'nominal'}
        />
      </div>

      {/* Visual Charts: Phased Disbursements & Debt Trajectory */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SvgBarChart
          title={`Annual Phased Disbursement (${project.currency} M)`}
          data={capexBarData}
          label1="Escalated Capex"
          label2="Interest During Construction (IDC)"
          yUnit="M"
        />

        <SvgLineChart
          title={`Cumulative Senior Debt Facility Balance (${project.currency} M)`}
          series={[
            {
              name: 'Senior Capex Facility Drawdown',
              color: '#38BDF8',
              data: cumulativeDebtCurve
            }
          ]}
          yUnit="M"
        />
      </div>

      {/* Capex Phasing Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-[#111A2E]">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Work Package Phasing & Capital Drawdowns
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            Annual Escalation: {((project.realCostEscalationPct + project.generalInflationPct) * 100).toFixed(1)}%
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0B1120] text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-3.5 py-2.5">Year</th>
                <th className="px-3.5 py-2.5">Calendar</th>
                <th className="px-3.5 py-2.5 text-right">S-Curve %</th>
                <th className="px-3.5 py-2.5 text-right">Base Capex</th>
                <th className="px-3.5 py-2.5 text-right">Contingency</th>
                <th className="px-3.5 py-2.5 text-right font-semibold text-slate-200">Escalated Capex</th>
                <th className="px-3.5 py-2.5 text-right text-sky-400">Debt Drawn</th>
                <th className="px-3.5 py-2.5 text-right text-emerald-400">Equity Drawn</th>
                <th className="px-3.5 py-2.5 text-right text-amber-400">Accrued IDC</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-white">Total Funding</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {schedule.map(s => (
                <tr key={s.year} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-3.5 py-2 text-slate-300">Year {s.year}</td>
                  <td className="px-3.5 py-2 text-slate-400">{s.calendarYear}</td>
                  <td className="px-3.5 py-2 text-right text-slate-400 tabular-nums">
                    {(s.sCurveWeight * 100).toFixed(1)}%
                  </td>
                  <td className="px-3.5 py-2 text-right text-slate-300 tabular-nums">{s.baseCapex.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right text-slate-400 tabular-nums">{s.contingency.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right font-semibold text-slate-200 tabular-nums">
                    {s.escalatedCapex.toLocaleString()}
                  </td>
                  <td className="px-3.5 py-2 text-right text-sky-400 tabular-nums">{s.debtDrawn.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right text-emerald-400 tabular-nums">{s.equityDrawn.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right text-amber-400 tabular-nums">{s.idc.toLocaleString()}</td>
                  <td className="px-3.5 py-2 text-right font-bold text-white tabular-nums">
                    {s.totalFundingNeed.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
