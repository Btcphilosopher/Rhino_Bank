import React from 'react';
import { RailwayProject } from '../../types/finance';
import { MetricCard } from '../ui/MetricCard';
import { MapPin, Gauge, Layers, Calendar, Landmark } from 'lucide-react';

interface ProjectRegistryWorkspaceProps {
  projects: RailwayProject[];
  selectedProjectId: string;
  onSelectProject: (id: string) => void;
  onUpdateProject: (updated: RailwayProject) => void;
}

export const ProjectRegistryWorkspace: React.FC<ProjectRegistryWorkspaceProps> = ({
  projects,
  selectedProjectId,
  onSelectProject,
  onUpdateProject
}) => {
  const activeProject = projects.find(p => p.id === selectedProjectId) || projects[0];

  return (
    <div className="space-y-6">
      {/* Header and selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            1. Project Registry & Asset Specifications
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional portfolio of synthetic and benchmark railway infrastructure concessions.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 whitespace-nowrap">Switch Asset:</label>
          <select
            value={selectedProjectId}
            onChange={e => onSelectProject(e.target.value)}
            className="bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-3 py-1.5 focus:outline-none focus:border-sky-500"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>
                {p.id} - {p.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Overview Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Capital Scale"
          label="Base Capital Cost"
          value={`${activeProject.currency} ${(activeProject.baseCapexM / 1000).toFixed(2)}B`}
          unit={`(${activeProject.baseCapexM.toLocaleString()}M)`}
          subtext={`Contingency Buffer: ${(activeProject.contingencyPct * 100).toFixed(0)}%`}
        />
        <MetricCard
          kicker="Infrastructure"
          label="Route Length & Speed"
          value={`${activeProject.routeLengthKm} km`}
          unit={`@ ${activeProject.designSpeedKmh} km/h`}
          subtext={`${activeProject.stationsCount} Stations · ${activeProject.trackConfig.split(' ')[0]}`}
        />
        <MetricCard
          kicker="Concession Tenor"
          label="Lifecycle Duration"
          value={`${activeProject.concessionYears} Years`}
          unit={`Concession`}
          subtext={`Asset Life: ${activeProject.assetLifeYears} yrs · Ops from ${activeProject.operationalStartYear}`}
        />
        <MetricCard
          kicker="Financing Structure"
          label="Gearing & Debt Target"
          value={`${(activeProject.debtFundingRatio * 100).toFixed(0)}% Debt`}
          unit={`/ ${(100 - activeProject.debtFundingRatio * 100).toFixed(0)}% Eq`}
          subtext={`Target DSCR: ${activeProject.targetDscr.toFixed(2)}x · Tenor: ${activeProject.debtTenorYears}y`}
        />
      </div>

      {/* Main Asset Data Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Asset Identity and Provenance */}
        <div className="lg:col-span-2 bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Landmark className="w-4 h-4 text-sky-400" />
                <span>{activeProject.name}</span>
              </h3>
              <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {activeProject.country}
                </span>
                <span>·</span>
                <span>{activeProject.railwayType}</span>
                <span>·</span>
                <span className="text-amber-400/90 font-mono">SYNTHETIC MODEL</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">Track Layout</span>
              <span className="font-medium text-slate-200">{activeProject.trackConfig}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Electrification</span>
              <span className="font-medium text-slate-200">{activeProject.electrificationStatus}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Signalling Category</span>
              <span className="font-medium text-slate-200">{activeProject.signallingCategory}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Fleet Size</span>
              <span className="font-medium text-slate-200 font-mono">{activeProject.trainFleetSize} Trainsets</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Annual Capacity</span>
              <span className="font-medium text-slate-200 font-mono">
                {activeProject.passengerCapacityAnnual > 0
                  ? `${(activeProject.passengerCapacityAnnual / 1e6).toFixed(1)}M Pax`
                  : `${(activeProject.freightCapacityAnnualTonnes / 1e6).toFixed(1)}M Tonnes`}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Service Frequency</span>
              <span className="font-medium text-slate-200 font-mono">{activeProject.plannedFrequencyTph} tph (peak)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-900/60 rounded border border-slate-800/80 text-[11px] text-slate-400">
            <span className="font-semibold text-slate-300">Data Provenance & Audit: </span>
            {activeProject.provenance}. All parameters are calibrated against representative international high-speed and heavy freight standard UIC specifications.
          </div>
        </div>

        {/* Right Column: Interactive Parameter Tuning */}
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-sky-400" />
            <span>Interactive Parameters</span>
          </h3>

          <div className="space-y-3.5 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Base Capex ({activeProject.currency} M)</span>
                <span className="font-mono text-slate-200 font-bold">{activeProject.baseCapexM}</span>
              </div>
              <input
                type="range"
                min={2000}
                max={15000}
                step={100}
                value={activeProject.baseCapexM}
                onChange={e => onUpdateProject({ ...activeProject, baseCapexM: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Contingency Pct</span>
                <span className="font-mono text-slate-200 font-bold">{(activeProject.contingencyPct * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min={0.05}
                max={0.30}
                step={0.01}
                value={activeProject.contingencyPct}
                onChange={e => onUpdateProject({ ...activeProject, contingencyPct: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Debt Gearing</span>
                <span className="font-mono text-slate-200 font-bold">{(activeProject.debtFundingRatio * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min={0.40}
                max={0.85}
                step={0.05}
                value={activeProject.debtFundingRatio}
                onChange={e => onUpdateProject({ ...activeProject, debtFundingRatio: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Target DSCR</span>
                <span className="font-mono text-slate-200 font-bold">{activeProject.targetDscr.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min={1.15}
                max={1.80}
                step={0.05}
                value={activeProject.targetDscr}
                onChange={e => onUpdateProject({ ...activeProject, targetDscr: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Senior Debt Interest Rate</span>
                <span className="font-mono text-slate-200 font-bold">{(activeProject.seniorDebtRate * 100).toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={0.025}
                max={0.090}
                step={0.0025}
                value={activeProject.seniorDebtRate}
                onChange={e => onUpdateProject({ ...activeProject, seniorDebtRate: Number(e.target.value) })}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
