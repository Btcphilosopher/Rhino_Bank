import React, { useState } from 'react';
import { RailwayProject, SignallingCategory } from '../../types/finance';
import { calculateCapacity } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { Cpu, ShieldCheck, Activity, Zap } from 'lucide-react';

interface EngineeringWorkspaceProps {
  project: RailwayProject;
  onUpdateProject: (p: RailwayProject) => void;
}

export const EngineeringWorkspace: React.FC<EngineeringWorkspaceProps> = ({
  project,
  onUpdateProject
}) => {
  const [dwellSec, setDwellSec] = useState(120);
  const [junctionBufferSec, setJunctionBufferSec] = useState(45);
  const [trackPairs, setTrackPairs] = useState(1);

  const capacity = calculateCapacity(
    project.signallingCategory,
    dwellSec,
    junctionBufferSec,
    trackPairs
  );

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          2. Railway Engineering & Operational Capacity Engine
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Physics and signalling constraints: Headway margins, UIC 406 utilization, rolling stock turnaround.
        </p>
      </div>

      {/* Engineering KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Signalling Limit"
          label="Min Technical Headway"
          value={`${capacity.minHeadwaySec}s`}
          unit={`(@ ${project.signallingCategory.split(' ')[0]})`}
          subtext="Safety overlap & block clearance"
          status="nominal"
        />
        <MetricCard
          kicker="Practical Constraint"
          label="Operational Headway"
          value={`${capacity.practicalHeadwaySec}s`}
          unit={`(incl. ${dwellSec}s dwell)`}
          subtext={`Junction Margin: ${junctionBufferSec}s`}
        />
        <MetricCard
          kicker="Line Capacity (UIC 406)"
          label="Practical Train Paths"
          value={`${capacity.tphPerDirection} tph`}
          unit="/ direction"
          subtext={`85% UIC 406 Peak Utilization`}
          status="nominal"
        />
        <MetricCard
          kicker="Daily System Throughput"
          label="Max Daily Train Paths"
          value={`${capacity.dailyTrainPaths}`}
          unit="trains / day"
          subtext={`Annualized: ${(capacity.annualTrainPaths / 1000).toFixed(1)}k paths/yr`}
        />
      </div>

      {/* Detailed Technical Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-sky-400" />
              <span>Signalling, Power & Fleet Configuration</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Speed: {project.designSpeedKmh} km/h
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Signalling & Train Control System</label>
              <select
                value={project.signallingCategory}
                onChange={e => onUpdateProject({ ...project, signallingCategory: e.target.value as SignallingCategory })}
                className="w-full bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-3 py-2 focus:outline-none focus:border-sky-500"
              >
                <option value="ETCS Level 2 with ATO">ETCS Level 2 with ATO (High-Speed Standard)</option>
                <option value="CBTC GoA4 Driverless">CBTC GoA4 Driverless (Ultra-High Frequency Metro)</option>
                <option value="ETCS Level 1">ETCS Level 1 (Interoperable Freight)</option>
                <option value="4-Aspect Colour Light">4-Aspect Colour Light (Legacy Conventional)</option>
                <option value="3-Aspect Colour Light">3-Aspect Colour Light (Branch Line)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Electrification System</label>
              <input
                type="text"
                value={project.electrificationStatus}
                onChange={e => onUpdateProject({ ...project, electrificationStatus: e.target.value })}
                className="w-full bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-3 py-2 font-mono"
              />
            </div>
          </div>

          <div className="p-3.5 bg-slate-900/70 border border-slate-800/80 rounded space-y-2 text-xs">
            <div className="font-semibold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Capacity Model Rationale (UIC 406 Methodology)</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              As mandated by RhinoQuant standards, infrastructure capacity is not inferred simply from route length. Capacity depends explicitly on block signalling overlaps, terminal station dwell times ({dwellSec}s), interlocking route setting, and speed differential between passenger and freight consists.
            </p>
          </div>
        </div>

        {/* Headway & Margins Tuning */}
        <div className="bg-[#0E1626] border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            <span>Operational Margins</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Station Dwell Time</span>
                <span className="font-mono text-slate-200 font-bold">{dwellSec} seconds</span>
              </div>
              <input
                type="range"
                min={45}
                max={240}
                step={5}
                value={dwellSec}
                onChange={e => setDwellSec(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Junction Buffer Margin</span>
                <span className="font-mono text-slate-200 font-bold">{junctionBufferSec} seconds</span>
              </div>
              <input
                type="range"
                min={20}
                max={90}
                step={5}
                value={junctionBufferSec}
                onChange={e => setJunctionBufferSec(Number(e.target.value))}
                className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Running Track Pairs</span>
                <span className="font-mono text-slate-200 font-bold">
                  {trackPairs === 1 ? '1 Pair (Double Track)' : `${trackPairs} Pairs (4-Track Corridor)`}
                </span>
              </div>
              <select
                value={trackPairs}
                onChange={e => setTrackPairs(Number(e.target.value))}
                className="w-full bg-[#111A2E] border border-slate-700 text-xs text-slate-200 rounded px-2.5 py-1.5"
              >
                <option value={1}>1 Pair (Double Track)</option>
                <option value={2}>2 Pairs (Quad Track Express/Local)</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
