import React from 'react';
import { RailwayProject } from '../../types/finance';
import { BENCHMARK_PROJECTS, calculateProjectCashflows, calculateCapexProfile } from '../../engine/railway_engine';
import { MetricCard } from '../ui/MetricCard';
import { SvgBarChart } from '../ui/ChartSvg';
import { Briefcase, PieChart, Layers, Globe } from 'lucide-react';

export const PortfolioWorkspace: React.FC = () => {
  // Aggregate statistics across all benchmark assets
  const projectStats = BENCHMARK_PROJECTS.map(p => {
    const { totalFundingNeed, peakDebtBalance } = calculateCapexProfile(p);
    const { projectIrrPct, equityIrrPct, projectNpvM, minDscr } = calculateProjectCashflows(p, peakDebtBalance);
    return {
      project: p,
      totalCapex: totalFundingNeed,
      debt: peakDebtBalance,
      equity: totalFundingNeed - peakDebtBalance,
      projectIrr: projectIrrPct,
      equityIrr: equityIrrPct,
      npv: projectNpvM,
      minDscr
    };
  });

  const totalPortfolioCapex = projectStats.reduce((sum, s) => sum + s.totalCapex, 0);
  const totalPortfolioDebt = projectStats.reduce((sum, s) => sum + s.debt, 0);
  const totalPortfolioEquity = projectStats.reduce((sum, s) => sum + s.equity, 0);
  const weightedProjectIrr =
    projectStats.reduce((sum, s) => sum + s.projectIrr * s.totalCapex, 0) / totalPortfolioCapex;
  const weightedEquityIrr =
    projectStats.reduce((sum, s) => sum + s.equityIrr * s.equity, 0) / totalPortfolioEquity;

  const allocationChartData = projectStats.map(s => ({
    label: s.project.id,
    value1: s.debt,
    value2: s.equity
  }));

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white tracking-tight">
          12. Portfolio Analytics & Cross-Asset Aggregation
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Rhino Bank multi-asset infrastructure portfolio: Capital commitments, weighted IRRs, and sector concentrations.
        </p>
      </div>

      {/* Aggregate KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <MetricCard
          kicker="Portfolio Commitment"
          label="Total Infrastructure Capex"
          value={`€${(totalPortfolioCapex / 1000).toFixed(2)}B`}
          unit={`(Across ${BENCHMARK_PROJECTS.length} Assets)`}
          subtext={`Senior Debt: €${(totalPortfolioDebt / 1000).toFixed(2)}B`}
          status="nominal"
        />
        <MetricCard
          kicker="Weighted Asset Return"
          label="Portfolio Unlevered IRR"
          value={`${weightedProjectIrr.toFixed(2)}%`}
          unit="Weighted Project IRR"
          subtext="Capital-weighted unlevered baseline"
          status="nominal"
        />
        <MetricCard
          kicker="Weighted Sponsor Return"
          label="Portfolio Levered Equity IRR"
          value={`${weightedEquityIrr.toFixed(2)}%`}
          unit="Weighted Equity IRR"
          subtext={`Total Sponsor Equity: €${(totalPortfolioEquity / 1000).toFixed(2)}B`}
          status="nominal"
        />
        <MetricCard
          kicker="Portfolio Diversification"
          label="Asset Classes & Jurisdictions"
          value="4 Concessions"
          unit="HSR, Frt, Metro, Subsea"
          subtext="EUR / GBP / Cross-Border"
        />
      </div>

      {/* Allocation Chart */}
      <SvgBarChart
        title="Asset-Level Capital Structure (Senior Debt vs Equity Commitment in € Millions)"
        data={allocationChartData}
        label1="Senior Debt Facility"
        label2="Sponsor Equity Commitment"
        yUnit="M"
      />

      {/* Portfolio Table */}
      <div className="bg-[#0E1626] border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-[#111A2E]">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Holdings Inventory & Performance Comparison
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            Rhino Bank Infrastructure Portfolio
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0B1120] text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-3.5 py-2.5">Asset Code</th>
                <th className="px-3.5 py-2.5">Asset Name</th>
                <th className="px-3.5 py-2.5">Railway Type</th>
                <th className="px-3.5 py-2.5 text-right">All-in Capex</th>
                <th className="px-3.5 py-2.5 text-right text-sky-400">Senior Debt</th>
                <th className="px-3.5 py-2.5 text-right text-emerald-400">Equity</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-slate-200">Project IRR</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-sky-300">Equity IRR</th>
                <th className="px-3.5 py-2.5 text-right font-bold text-emerald-400">Min DSCR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {projectStats.map(s => (
                <tr key={s.project.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-3.5 py-2 text-sky-400 font-semibold">{s.project.id}</td>
                  <td className="px-3.5 py-2 font-medium text-slate-200 font-sans">{s.project.name}</td>
                  <td className="px-3.5 py-2 text-slate-400 font-sans">{s.project.railwayType}</td>
                  <td className="px-3.5 py-2 text-right text-slate-300 tabular-nums">{s.totalCapex.toLocaleString()}M</td>
                  <td className="px-3.5 py-2 text-right text-sky-400 tabular-nums">{s.debt.toLocaleString()}M</td>
                  <td className="px-3.5 py-2 text-right text-emerald-400 tabular-nums">{s.equity.toLocaleString()}M</td>
                  <td className="px-3.5 py-2 text-right font-bold text-slate-200 tabular-nums">{s.projectIrr.toFixed(2)}%</td>
                  <td className="px-3.5 py-2 text-right font-bold text-sky-300 tabular-nums">{s.equityIrr.toFixed(2)}%</td>
                  <td className="px-3.5 py-2 text-right font-bold text-emerald-400 tabular-nums">{s.minDscr.toFixed(2)}x</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
