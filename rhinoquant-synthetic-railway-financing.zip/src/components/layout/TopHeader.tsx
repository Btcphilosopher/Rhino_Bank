import React from 'react';
import { Download } from 'lucide-react';

interface TopHeaderProps {
  onExport: () => void;
  onNavigateSection: (section: string) => void;
  activeSection: string;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  onExport,
  onNavigateSection,
  activeSection
}) => {
  return (
    <header className="h-14 border-b border-slate-800 bg-[#0B1120] px-6 flex items-center justify-between gap-8 shrink-0 select-none sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2 shrink-0">
        <a
          href="#"
          className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-sm bg-sky-500 inline-block"></span>
          <span>RhinoQuant</span>
          <span className="text-xs font-mono font-normal text-slate-400">/ SYNTHETIC RAIL FINANCE</span>
        </a>
      </div>

      {/* Zone 2: 4–5 clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => onNavigateSection('project')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 ${
            activeSection === 'project' ? 'text-sky-400 font-semibold' : ''
          }`}
        >
          Asset Registry
        </button>
        <button
          onClick={() => onNavigateSection('cashflow')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 ${
            activeSection === 'cashflow' ? 'text-sky-400 font-semibold' : ''
          }`}
        >
          Project Finance
        </button>
        <button
          onClick={() => onNavigateSection('structuring')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 ${
            activeSection === 'structuring' ? 'text-sky-400 font-semibold' : ''
          }`}
        >
          Synthetic Structuring
        </button>
        <button
          onClick={() => onNavigateSection('risk')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 ${
            activeSection === 'risk' ? 'text-sky-400 font-semibold' : ''
          }`}
        >
          Risk & Scenarios
        </button>
        <button
          onClick={() => onNavigateSection('audit')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 ${
            activeSection === 'audit' ? 'text-sky-400 font-semibold' : ''
          }`}
        >
          Model Audit
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onExport}
          className="px-3.5 py-1.5 text-xs font-medium text-slate-900 bg-sky-400 hover:bg-sky-300 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 font-sans"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Model Pack</span>
        </button>
      </div>
    </header>
  );
};
