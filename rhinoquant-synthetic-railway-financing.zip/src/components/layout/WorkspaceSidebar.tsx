import React from 'react';
import {
  FolderKanban,
  Sliders,
  HardHat,
  TrendingUp,
  Banknote,
  Coins,
  ReceiptText,
  FlaskConical,
  Layers,
  ShieldAlert,
  GitBranch,
  Briefcase,
  Columns,
  Globe2,
  FileCheck
} from 'lucide-react';

export interface WorkspaceItem {
  id: number;
  key: string;
  label: string;
  group: 'Core Asset' | 'Project Finance' | 'Structured Instruments' | 'Risk & Scenarios' | 'Governance';
  icon: React.ComponentType<{ className?: string }>;
}

export const WORKSPACES: WorkspaceItem[] = [
  { id: 1, key: 'registry', label: '1. Project Registry', group: 'Core Asset', icon: FolderKanban },
  { id: 2, key: 'engineering', label: '2. Railway Engineering', group: 'Core Asset', icon: Sliders },
  { id: 3, key: 'capex', label: '3. Construction Cost Model', group: 'Core Asset', icon: HardHat },
  { id: 4, key: 'demand', label: '4. Demand & Revenue', group: 'Core Asset', icon: TrendingUp },
  { id: 5, key: 'cashflow', label: '5. Project Cash Flow', group: 'Project Finance', icon: Banknote },
  { id: 6, key: 'debt', label: '6. Debt Structuring', group: 'Project Finance', icon: Coins },
  { id: 7, key: 'bonds', label: '7. Bond Pricing', group: 'Structured Instruments', icon: ReceiptText },
  { id: 8, key: 'synthetic', label: '8. Synthetic Instrument Lab', group: 'Structured Instruments', icon: FlaskConical },
  { id: 9, key: 'waterfall', label: '9. Waterfall & Tranches', group: 'Structured Instruments', icon: Layers },
  { id: 10, key: 'risk', label: '10. Risk & Stress Testing', group: 'Risk & Scenarios', icon: ShieldAlert },
  { id: 11, key: 'yield', label: '11. Yield Curve Workbench', group: 'Structured Instruments', icon: GitBranch },
  { id: 12, key: 'portfolio', label: '12. Portfolio Analytics', group: 'Risk & Scenarios', icon: Briefcase },
  { id: 13, key: 'scenarios', label: '13. Scenario Comparison', group: 'Risk & Scenarios', icon: Columns },
  { id: 14, key: 'economic', label: '14. Economic Impact', group: 'Core Asset', icon: Globe2 },
  { id: 15, key: 'reporting', label: '15. Reporting & Audit', group: 'Governance', icon: FileCheck }
];

interface WorkspaceSidebarProps {
  activeWorkspace: number;
  onSelectWorkspace: (id: number) => void;
  selectedProjectName: string;
}

export const WorkspaceSidebar: React.FC<WorkspaceSidebarProps> = ({
  activeWorkspace,
  onSelectWorkspace,
  selectedProjectName
}) => {
  return (
    <aside className="w-64 bg-[#0A0F1D] border-r border-slate-800/80 flex flex-col shrink-0 overflow-y-auto">
      {/* Active Project Card Indicator */}
      <div className="p-3.5 border-b border-slate-800/70 bg-[#0E1626]">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          Active Concession Model
        </div>
        <div className="text-xs font-bold text-slate-200 truncate mt-0.5">
          {selectedProjectName}
        </div>
      </div>

      {/* Workspaces list */}
      <div className="p-2 space-y-1">
        {WORKSPACES.map(ws => {
          const Icon = ws.icon;
          const isActive = ws.id === activeWorkspace;
          return (
            <button
              key={ws.id}
              onClick={() => onSelectWorkspace(ws.id)}
              className={`w-full text-left px-2.5 py-2 rounded-md text-xs font-medium flex items-center gap-2.5 transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-sky-500/15 text-sky-300 font-semibold border-l-2 border-sky-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
              <span className="truncate">{ws.label}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-auto p-3 border-t border-slate-800/60 text-[11px] text-slate-400">
        <div className="flex items-center justify-between">
          <span>Engine Status</span>
          <span className="text-emerald-400 font-mono">CALCULATED</span>
        </div>
        <div className="text-[10px] text-slate-400 mt-1">
          Zero Hardcoding · Deterministic & MC
        </div>
      </div>
    </aside>
  );
};
