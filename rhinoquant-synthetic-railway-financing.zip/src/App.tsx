/**
 * RhinoQuant Synthetic Railway Financing
 * Institutional Infrastructure Finance, Asset Modelling and Quantitative Risk Platform
 * Rhino Bank - Infrastructure Finance & Structured Investments Division
 */

import React, { useState } from 'react';
import { RailwayProject } from './types/finance';
import { BENCHMARK_PROJECTS, calculateCapexProfile, calculateProjectCashflows, calculateBondPricing, calculateEconomicImpact, validateProjectModel } from './engine/railway_engine';
import { TopHeader } from './components/layout/TopHeader';
import { WorkspaceSidebar, WORKSPACES } from './components/layout/WorkspaceSidebar';
import { ProjectRegistryWorkspace } from './components/workspaces/ProjectRegistryWorkspace';
import { EngineeringWorkspace } from './components/workspaces/EngineeringWorkspace';
import { CapexWorkspace } from './components/workspaces/CapexWorkspace';
import { DemandWorkspace } from './components/workspaces/DemandWorkspace';
import { CashflowWorkspace } from './components/workspaces/CashflowWorkspace';
import { DebtStructuringWorkspace } from './components/workspaces/DebtStructuringWorkspace';
import { BondPricingWorkspace } from './components/workspaces/BondPricingWorkspace';
import { SyntheticLabWorkspace } from './components/workspaces/SyntheticLabWorkspace';
import { WaterfallWorkspace } from './components/workspaces/WaterfallWorkspace';
import { RiskEngineWorkspace } from './components/workspaces/RiskEngineWorkspace';
import { YieldCurveWorkspace } from './components/workspaces/YieldCurveWorkspace';
import { PortfolioWorkspace } from './components/workspaces/PortfolioWorkspace';
import { ScenarioWorkspace } from './components/workspaces/ScenarioWorkspace';
import { EconomicImpactWorkspace } from './components/workspaces/EconomicImpactWorkspace';
import { ReportingWorkspace } from './components/workspaces/ReportingWorkspace';

export default function App() {
  const [projects, setProjects] = useState<RailwayProject[]>(BENCHMARK_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('SYN-HSR-01');
  const [activeWorkspace, setActiveWorkspace] = useState<number>(1);
  const [activeSection, setActiveSection] = useState<string>('project');

  const activeProject = projects.find(p => p.id === selectedProjectId) || projects[0];

  const handleUpdateProject = (updated: RailwayProject) => {
    setProjects(prev => prev.map(p => (p.id === updated.id ? updated : p)));
  };

  const handleNavigateSection = (section: string) => {
    setActiveSection(section);
    if (section === 'project') setActiveWorkspace(1);
    else if (section === 'cashflow') setActiveWorkspace(5);
    else if (section === 'structuring') setActiveWorkspace(8);
    else if (section === 'risk') setActiveWorkspace(10);
    else if (section === 'audit') setActiveWorkspace(15);
  };

  const handleExportModelPack = () => {
    const { schedule, totalFundingNeed, peakDebtBalance } = calculateCapexProfile(activeProject);
    const { cashflows, debtSchedule, projectIrrPct, equityIrrPct, projectNpvM, equityNpvM } =
      calculateProjectCashflows(activeProject, peakDebtBalance);
    const bond = calculateBondPricing(100, activeProject.seniorDebtRate, activeProject.debtTenorYears);
    const econ = calculateEconomicImpact(activeProject);
    const audit = validateProjectModel(cashflows, debtSchedule);

    const exportData = {
      metadata: {
        platform: 'RhinoQuant Synthetic Railway Financing Platform',
        institution: 'Rhino Bank Infrastructure Finance Division',
        modelVersion: 'RHINO-FIN-V1.0.0-PROD',
        exportTimestamp: new Date().toISOString(),
        provenance: activeProject.provenance
      },
      project: activeProject,
      capex: {
        totalFundingNeed,
        peakDebtBalance,
        phasedSchedule: schedule
      },
      financialReturns: {
        unleveredProjectIrrPct: projectIrrPct,
        unleveredProjectNpvM: projectNpvM,
        leveredEquityIrrPct: equityIrrPct,
        leveredEquityNpvM: equityNpvM
      },
      annualCashflows: cashflows,
      debtAmortisationSchedule: debtSchedule,
      bondPricing: bond,
      socioEconomicImpact: econ,
      auditVerification: audit
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RhinoQuant_${activeProject.id}_Financial_Model_Pack.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#0B1120] text-slate-100 flex flex-col antialiased">
      {/* Top Header strictly conforming to 3-zone Top Bar Contract */}
      <TopHeader
        activeSection={activeSection}
        onNavigateSection={handleNavigateSection}
        onExport={handleExportModelPack}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left 15-Workspaces Navigation Sidebar */}
        <WorkspaceSidebar
          activeWorkspace={activeWorkspace}
          onSelectWorkspace={id => {
            setActiveWorkspace(id);
            if (id <= 4 || id === 14) setActiveSection('project');
            else if (id === 5 || id === 6) setActiveSection('cashflow');
            else if (id >= 7 && id <= 9 || id === 11) setActiveSection('structuring');
            else if (id === 10 || id === 12 || id === 13) setActiveSection('risk');
            else if (id === 15) setActiveSection('audit');
          }}
          selectedProjectName={`${activeProject.id} · ${activeProject.name}`}
        />

        {/* Content Canvas */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-[#090D18]">
          <div className="max-w-7xl mx-auto">
            {activeWorkspace === 1 && (
              <ProjectRegistryWorkspace
                projects={projects}
                selectedProjectId={selectedProjectId}
                onSelectProject={setSelectedProjectId}
                onUpdateProject={handleUpdateProject}
              />
            )}
            {activeWorkspace === 2 && (
              <EngineeringWorkspace
                project={activeProject}
                onUpdateProject={handleUpdateProject}
              />
            )}
            {activeWorkspace === 3 && (
              <CapexWorkspace
                project={activeProject}
                onUpdateProject={handleUpdateProject}
              />
            )}
            {activeWorkspace === 4 && (
              <DemandWorkspace
                project={activeProject}
                onUpdateProject={handleUpdateProject}
              />
            )}
            {activeWorkspace === 5 && (
              <CashflowWorkspace project={activeProject} />
            )}
            {activeWorkspace === 6 && (
              <DebtStructuringWorkspace
                project={activeProject}
                onUpdateProject={handleUpdateProject}
              />
            )}
            {activeWorkspace === 7 && (
              <BondPricingWorkspace project={activeProject} />
            )}
            {activeWorkspace === 8 && (
              <SyntheticLabWorkspace project={activeProject} />
            )}
            {activeWorkspace === 9 && (
              <WaterfallWorkspace project={activeProject} />
            )}
            {activeWorkspace === 10 && (
              <RiskEngineWorkspace project={activeProject} />
            )}
            {activeWorkspace === 11 && (
              <YieldCurveWorkspace />
            )}
            {activeWorkspace === 12 && (
              <PortfolioWorkspace />
            )}
            {activeWorkspace === 13 && (
              <ScenarioWorkspace project={activeProject} />
            )}
            {activeWorkspace === 14 && (
              <EconomicImpactWorkspace project={activeProject} />
            )}
            {activeWorkspace === 15 && (
              <ReportingWorkspace
                project={activeProject}
                onExportPack={handleExportModelPack}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
