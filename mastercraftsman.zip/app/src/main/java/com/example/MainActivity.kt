package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MastercraftTheme
import com.example.ui.theme.BritishGreen
import com.example.ui.theme.SlateSeparator
import com.example.ui.theme.CharcoalIron
import com.example.ui.viewmodel.MastercraftViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MastercraftTheme {
                val viewModel: MastercraftViewModel = viewModel()
                MastercraftAppContent(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MastercraftAppContent(viewModel: MastercraftViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeJob by viewModel.activeJob.collectAsState()
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val navigationItems = listOf(
        Triple("today", "Today", Icons.Default.CalendarToday),
        Triple("jobs", "Contracts", Icons.Default.Work),
        Triple("survey", "Survey Mode", Icons.Default.Search),
        Triple("site", "Site Journal", Icons.Default.MenuBook),
        Triple("ai_assistant", "AI Bench", Icons.Default.SmartToy)
    )

    val drawerItems = listOf(
        Triple("estimate", "Estimator & Quotes", Icons.Default.Calculate),
        Triple("materials", "Material Yard & Depots", Icons.Default.Construction),
        Triple("accounts", "Accounts & Staged Bills", Icons.Default.ReceiptLong),
        Triple("profile", "Qualifications Passport", Icons.Default.Person)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFFF8F6F1),
                modifier = Modifier.width(300.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MASTERCRAFTSMAN YARD",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Edward Harcourt",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text("Harcourt Restoration • York", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = SlateSeparator)
                    Spacer(modifier = Modifier.height(16.dp))

                    drawerItems.forEach { item ->
                        NavigationDrawerItem(
                            label = { Text(item.second, style = MaterialTheme.typography.titleMedium) },
                            icon = { Icon(imageVector = item.third, contentDescription = null) },
                            selected = currentScreen == item.first,
                            onClick = {
                                viewModel.navigateTo(item.first)
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = Color(0xFFECE6DA),
                                selectedIconColor = BritishGreen,
                                selectedTextColor = BritishGreen
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(vertical = 4.dp).testTag("drawer_item_${item.first}")
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "VERIFIED TRADES OPERATING SYSTEM v3.5",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "MASTERCRAFTSMAN",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.25.sp
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("btn_trigger_menu_drawer")
                        ) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu Drawer", tint = BritishGreen)
                        }
                    },
                    actions = {
                        // Quick Active Job tag
                        activeJob?.let { job ->
                            Box(
                                modifier = Modifier
                                    .padding(end = 12.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color(0xFFEDE8DF))
                                    .clickable { viewModel.navigateTo("jobs") }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = job.jobNumber,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color(0xFFEDE8DF)
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFFEDE8DF),
                    tonalElevation = 8.dp
                ) {
                    navigationItems.forEach { item ->
                        val isSelected = currentScreen == item.first || 
                            (item.first == "jobs" && currentScreen == "job_detail")
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(item.first) },
                            icon = { Icon(imageVector = item.third, contentDescription = item.second) },
                            label = { Text(item.second, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = BritishGreen,
                                indicatorColor = BritishGreen,
                                unselectedIconColor = CharcoalIron,
                                unselectedTextColor = CharcoalIron
                            ),
                            modifier = Modifier.testTag("nav_tab_${item.first}")
                        )
                    }
                }
            },
            contentWindowInsets = WindowInsets.safeDrawing,
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    "today" -> TodayScreen(viewModel = viewModel)
                    "jobs" -> JobsScreen(
                        viewModel = viewModel,
                        subScreen = "list",
                        onNavigateBack = { viewModel.navigateBack() }
                    )
                    "job_detail" -> JobsScreen(
                        viewModel = viewModel,
                        subScreen = "detail",
                        onNavigateBack = { viewModel.navigateBack() }
                    )
                    "survey" -> SurveyScreen(viewModel = viewModel)
                    "estimate" -> EstimateScreen(viewModel = viewModel, onNavigateBack = { viewModel.navigateBack() })
                    "materials" -> MaterialsScreen(viewModel = viewModel, onNavigateBack = { viewModel.navigateBack() })
                    "site" -> SiteDiaryScreen(viewModel = viewModel, onNavigateBack = { viewModel.navigateBack() })
                    "accounts" -> AccountsScreen(viewModel = viewModel, onNavigateBack = { viewModel.navigateBack() })
                    "profile" -> ProfileScreen(viewModel = viewModel, onNavigateBack = { viewModel.navigateBack() })
                    "ai_assistant" -> AiAssistantScreen(viewModel = viewModel, onNavigateBack = { viewModel.navigateBack() })
                    else -> TodayScreen(viewModel = viewModel)
                }
            }
        }
    }
}
