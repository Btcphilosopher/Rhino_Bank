package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.MaterialProductEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun MaterialsScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val materials by viewModel.allMaterials.collectAsState()
    val activeJob by viewModel.activeJob.collectAsState()

    var activeTab by remember { mutableStateOf("STONE") } // STONE, BRICK, MORTAR, SUPPLIER, ORDER

    // Quote Request State
    var showRequestForm by remember { mutableStateOf(false) }
    var reqMaterial by remember { mutableStateOf("Yorkshire Sandstone") }
    var reqQty by remember { mutableStateOf("18.4 tonnes") }
    var reqSupplier by remember { mutableStateOf("Yorkshire Stone Ltd") }
    var reqDate by remember { mutableStateOf("20 October 2026") }
    var quoteStatusMsg by remember { mutableStateOf("") }

    val suppliers = listOf(
        Pair("Yorkshire Stone Ltd", "Leeds Depot • Sells Yorkshire Sandstone & River Sand • Staged terms: 30 days"),
        Pair("Bath Stone Quarrying Ltd", "Wiltshire Depot • Sells Honey Bath Limestone • Trade terms"),
        Pair("Albion Stone Plc", "Dorset Depot • Sells White Portland Limestone • 6-sides sawn blocks"),
        Pair("The Lime Centre", "Winchester • NHL Lime Binders, Putties, Mixes • Nationwide delivery"),
        Pair("British Clayworks Co", "Leicestershire • Handmade Facing Clay Bricks • Bespoke imperial moulders")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "MATERIAL YARD",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = "Resource Schedules",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Heritage Provenance • British Minerals • Trade Suppliers",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TabButton(text = "Stone", isSelected = activeTab == "STONE", onClick = { activeTab = "STONE" })
            TabButton(text = "Brick", isSelected = activeTab == "BRICK", onClick = { activeTab = "BRICK" })
            TabButton(text = "Mortars", isSelected = activeTab == "MORTAR", onClick = { activeTab = "MORTAR" })
            TabButton(text = "Depots", isSelected = activeTab == "SUPPLIER", onClick = { activeTab = "SUPPLIER" })
            TabButton(text = "Orders", isSelected = activeTab == "ORDER", onClick = { activeTab = "ORDER" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "STONE", "BRICK", "MORTAR" -> {
                    val filterCategory = when (activeTab) {
                        "STONE" -> "Natural Stone"
                        "BRICK" -> "Brick"
                        else -> "Mortar"
                    }
                    val filteredMaterials = materials.filter { it.category == filterCategory }

                    if (filteredMaterials.isEmpty()) {
                        item {
                            Text("No minerals cataloged. Generating sample minerals...", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                        }
                    } else {
                        items(filteredMaterials) { mat ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("material_item_${mat.id}"),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.dp, SlateSeparator)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(mat.category.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                                            Text(mat.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                        }
                                        Text(
                                            text = "£${mat.pricePerUnit}/${mat.unitType}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(mat.description, style = MaterialTheme.typography.bodyMedium, color = CharcoalIron)
                                    
                                    if (mat.origin.isNotEmpty() || mat.colour.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Divider(color = SlateSeparator)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        MineralDetailRow(label = "Provenance Source", value = mat.origin)
                                        MineralDetailRow(label = "Mineral Colour", value = mat.colour)
                                        MineralDetailRow(label = "Texture Type", value = mat.texture)
                                        MineralDetailRow(label = "Density Limit", value = mat.density)
                                        MineralDetailRow(label = "Depot Supplier", value = mat.supplierName)
                                    }
                                }
                            }
                        }
                    }
                }

                "SUPPLIER" -> {
                    // Suppliers List
                    items(suppliers) { sup ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(sup.first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(sup.second, style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = SlateSeparator)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Trading Terms", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                                    Text("Approved Trade Account", style = MaterialTheme.typography.labelSmall, color = BritishGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                "ORDER" -> {
                    // Material Quotes Requests Tab
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("DEPOT QUOTE REQUESTS", style = MaterialTheme.typography.labelLarge)
                                    Button(
                                        onClick = { showRequestForm = !showRequestForm },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(2.dp),
                                        modifier = Modifier.testTag("btn_trigger_request_form")
                                    ) {
                                        Icon(imageVector = if (showRequestForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (showRequestForm) "Close" else "New Request", style = MaterialTheme.typography.labelMedium)
                                    }
                                }

                                if (showRequestForm) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = reqMaterial, onValueChange = { reqMaterial = it }, label = { Text("Material Name") }, modifier = Modifier.fillMaxWidth().testTag("req_mat_input"))
                                        OutlinedTextField(value = reqQty, onValueChange = { reqQty = it }, label = { Text("Quantity Needed (tonnes/bags/units)") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = reqSupplier, onValueChange = { reqSupplier = it }, label = { Text("Depot Supplier") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = reqDate, onValueChange = { reqDate = it }, label = { Text("Required on Site Date") }, modifier = Modifier.fillMaxWidth())
                                        
                                        Button(
                                            onClick = {
                                                if (reqMaterial.isNotBlank() && reqQty.isNotBlank()) {
                                                    quoteStatusMsg = "PENDING DEPOT RESPONSE: Quote request for $reqQty of $reqMaterial has been generated and queued for ${reqSupplier}."
                                                    showRequestForm = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("btn_send_request")
                                        ) {
                                            Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Transmit Quote Request")
                                        }
                                    }
                                }

                                if (quoteStatusMsg.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, BritishGreen, RoundedCornerShape(2.dp))
                                            .background(Color(0xFFE2F0D9))
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            Text("ORDER STATUS TRANSMITTED", style = MaterialTheme.typography.labelSmall, color = BritishGreen, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(quoteStatusMsg, style = MaterialTheme.typography.bodyMedium, color = CharcoalIron)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Active seeded order request for display
                                Text("TRANSMISSION LOG", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column {
                                        Text("18.4 Tonnes Yorkshire Sandstone", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text("To: Yorkshire Stone Ltd • Job: ${activeJob?.name ?: "Whitby"}", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                        Text("Required: 20 October 2026 • Delivery: Site Flatbed", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(Color(0xFFE2F0D9))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("TRANSMITTED", style = MaterialTheme.typography.labelSmall, color = BritishGreen)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MineralDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = SteelGrey)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = CharcoalIron)
    }
}
