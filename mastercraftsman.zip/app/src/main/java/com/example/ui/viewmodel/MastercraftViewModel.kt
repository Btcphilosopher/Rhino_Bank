package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.RetrofitClient
import com.example.data.database.*
import com.example.data.repository.MastercraftRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MastercraftViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MastercraftRepository
    
    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = MastercraftRepository(database.mastercraftDao())
    }

    // Navigation State
    private val _currentScreen = MutableStateFlow("today") // today, jobs, job_detail, survey, estimate, materials, drawings, site, accounts, profile, ai_assistant, banker, dry_stone
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _navigationStack = MutableStateFlow<List<String>>(listOf("today"))
    
    fun navigateTo(screen: String) {
        _currentScreen.value = screen
        val currentStack = _navigationStack.value.toMutableList()
        currentStack.add(screen)
        _navigationStack.value = currentStack
    }

    fun navigateBack() {
        val currentStack = _navigationStack.value.toMutableList()
        if (currentStack.size > 1) {
            currentStack.removeAt(currentStack.lastIndex)
            _navigationStack.value = currentStack
            _currentScreen.value = currentStack.last()
        } else {
            _currentScreen.value = "today"
        }
    }

    // Selected Job Context
    private val _selectedJobId = MutableStateFlow<Long?>(1L) // Default to first seeded job (Whitby Manor)
    val selectedJobId: StateFlow<Long?> = _selectedJobId.asStateFlow()

    fun selectJob(jobId: Long) {
        _selectedJobId.value = jobId
    }

    // Data Streams
    val allJobs: StateFlow<List<JobEntity>> = repository.allJobs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeJob: StateFlow<JobEntity?> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getJobById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allMaterials: StateFlow<List<MaterialProductEntity>> = repository.allMaterials
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTools: StateFlow<List<ToolEntity>> = repository.allTools
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDefects: StateFlow<List<DefectEntity>> = repository.allDefects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allComponents: StateFlow<List<WorkshopComponentEntity>> = repository.allComponents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allInvoices: StateFlow<List<InvoiceEntity>> = repository.allInvoices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Job-Specific Streams
    val jobSurveys: StateFlow<List<SurveyEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getSurveysForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobMeasurements: StateFlow<List<MeasurementEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getMeasurementsForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobDiaries: StateFlow<List<SiteDiaryEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getDiariesForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobDefects: StateFlow<List<DefectEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getDefectsForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobInvoices: StateFlow<List<InvoiceEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getInvoicesForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobVariations: StateFlow<List<VariationEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getVariationsForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobComponents: StateFlow<List<WorkshopComponentEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getComponentsForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobDrawings: StateFlow<List<DrawingEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getDrawingsForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobTimesheets: StateFlow<List<TimesheetEntity>> = _selectedJobId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getTimesheetsForJob(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // Action Handlers
    fun createJob(
        name: String, client: String, site: String, type: String, value: Double,
        start: String, end: String, notes: String, contact: String, architect: String, siteContact: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val count = allJobs.value.size + 1
            val num = "JOB-2026-${String.format("%04d", count)}"
            val newJob = JobEntity(
                jobNumber = num,
                name = name,
                clientName = client,
                siteAddress = site,
                contractValue = value,
                costToDate = 0.0,
                status = "LEAD",
                startDate = start,
                targetCompletion = end,
                progressPercent = 0,
                projectType = type,
                notes = notes,
                clientContact = contact,
                architectName = architect,
                siteContact = siteContact
            )
            val id = repository.insertJob(newJob)
            _selectedJobId.value = id
        }
    }

    fun updateJobStatus(jobId: Long, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val job = repository.getJobByIdSync(jobId)
            if (job != null) {
                repository.updateJob(job.copy(status = newStatus))
            }
        }
    }

    fun updateJobProgress(jobId: Long, progress: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val job = repository.getJobByIdSync(jobId)
            if (job != null) {
                repository.updateJob(job.copy(progressPercent = progress))
            }
        }
    }

    fun addSiteSurvey(weather: String, notes: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val todayStr = SimpleDateFormat("dd MMMM yyyy", Locale.UK).format(Date())
            repository.insertSurvey(
                SurveyEntity(
                    jobId = jobId,
                    weather = weather,
                    surveyDate = todayStr,
                    notes = notes
                )
            )
        }
    }

    fun addMeasurement(label: String, length: Double, height: Double, thickness: Double, type: String, qty: Double, matCost: Double, labCost: Double, notes: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val meas = MeasurementEntity(
                jobId = jobId,
                label = label,
                length = length,
                height = height,
                thickness = thickness,
                quantity = qty,
                type = type,
                calculatedMaterialCost = matCost,
                calculatedLabourCost = labCost,
                notes = notes
            )
            repository.insertMeasurement(meas)
            
            // Update cost to date on active job
            val job = repository.getJobByIdSync(jobId)
            if (job != null) {
                repository.updateJob(job.copy(costToDate = job.costToDate + matCost + labCost))
            }
        }
    }

    fun deleteMeasurement(measurement: MeasurementEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMeasurement(measurement)
            val job = repository.getJobByIdSync(measurement.jobId)
            if (job != null) {
                val updatedCost = maxOf(0.0, job.costToDate - (measurement.calculatedMaterialCost + measurement.calculatedLabourCost))
                repository.updateJob(job.copy(costToDate = updatedCost))
            }
        }
    }

    fun addSiteDiary(weather: String, crew: Int, hours: Int, completed: String, delivered: String, issues: String, notes: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val todayStr = SimpleDateFormat("dd MMMM yyyy", Locale.UK).format(Date())
            repository.insertSiteDiary(
                SiteDiaryEntity(
                    jobId = jobId,
                    date = todayStr,
                    weather = weather,
                    crewCount = crew,
                    hoursWorked = hours,
                    workCompleted = completed,
                    materialsDelivered = delivered,
                    issues = issues,
                    notes = notes
                )
            )
        }
    }

    fun addDefect(title: String, location: String, priority: String, action: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val num = "D-${String.format("%03d", allDefects.value.size + 1)}"
            repository.insertDefect(
                DefectEntity(
                    jobId = jobId,
                    defectNumber = num,
                    title = title,
                    location = location,
                    priority = priority,
                    status = "OPEN",
                    actionRequired = action
                )
            )
        }
    }

    fun updateDefectStatus(defect: DefectEntity, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertDefect(defect.copy(status = newStatus))
        }
    }

    fun addTimesheet(worker: String, role: String, hours: Double, task: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.UK).format(Date())
            repository.insertTimesheet(
                TimesheetEntity(
                    workerName = worker,
                    role = role,
                    date = todayStr,
                    jobId = jobId,
                    hours = hours,
                    taskCompleted = task
                )
            )
        }
    }

    fun addTool(name: String, serial: String, condition: String, location: String, notes: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertTool(
                ToolEntity(
                    name = name,
                    serialNumber = serial,
                    lastCheckedDate = SimpleDateFormat("dd MMMM yyyy", Locale.UK).format(Date()),
                    condition = condition,
                    location = location,
                    notes = notes
                )
            )
        }
    }

    fun checkTool(tool: ToolEntity, condition: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertTool(
                tool.copy(
                    lastCheckedDate = SimpleDateFormat("dd MMMM yyyy", Locale.UK).format(Date()),
                    condition = condition
                )
            )
        }
    }

    fun addInvoice(desc: String, net: Double, dateStr: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val num = "INV-2026-${String.format("%04d", allInvoices.value.size + 1)}"
            val vat = net * 0.20 // 20% standard UK VAT
            repository.insertInvoice(
                InvoiceEntity(
                    invoiceNumber = num,
                    jobId = jobId,
                    description = desc,
                    netAmount = net,
                    vatAmount = vat,
                    totalAmount = net + vat,
                    status = "SENT",
                    date = dateStr
                )
            )
        }
    }

    fun payInvoice(invoice: InvoiceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertInvoice(invoice.copy(status = "PAID"))
        }
    }

    fun addVariation(desc: String, cost: Double) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val num = "V-${String.format("%03d", jobVariations.value.size + 1)}"
            repository.insertVariation(
                VariationEntity(
                    jobId = jobId,
                    variationNumber = num,
                    description = desc,
                    cost = cost,
                    status = "SUBMITTED"
                )
            )
        }
    }

    fun approveVariation(variation: VariationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertVariation(variation.copy(status = "APPROVED"))
            // Update cost and value
            val job = repository.getJobByIdSync(variation.jobId)
            if (job != null) {
                repository.updateJob(job.copy(contractValue = job.contractValue + variation.cost))
            }
        }
    }

    fun addComponent(name: String, stone: String, dims: String, craftsman: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val num = "C-${String.format("%03d", allComponents.value.size + 1)}"
            repository.insertComponent(
                WorkshopComponentEntity(
                    jobId = jobId,
                    componentNumber = num,
                    name = name,
                    stoneType = stone,
                    dimensions = dims,
                    status = "TEMPLATE",
                    craftsmanName = craftsman,
                    hoursSpent = 0.0
                )
            )
        }
    }

    fun updateComponentStatus(component: WorkshopComponentEntity, newStatus: String, hoursToAdd: Double = 0.0) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertComponent(
                component.copy(
                    status = newStatus,
                    hoursSpent = component.hoursSpent + hoursToAdd
                )
            )
        }
    }

    fun addDrawing(num: String, title: String, author: String, rev: String) {
        val jobId = _selectedJobId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertDrawing(
                DrawingEntity(
                    jobId = jobId,
                    drawingNumber = num,
                    title = title,
                    revision = rev,
                    author = author,
                    status = "Current",
                    date = SimpleDateFormat("dd MMMM yyyy", Locale.UK).format(Date())
                )
            )
        }
    }


    // -------------------------------------------------------------
    // ONLINE/OFFLINE CHATBOT STATE (MASTERCRAFT AI)
    // -------------------------------------------------------------
    private val _aiMessages = MutableStateFlow<List<Pair<String, Boolean>>>(listOf( // Text, isUser
        Pair("Good day Edward. I am Mastercraft AI. I can assist with job summaries, quote drafts, site diary formatting, or UK construction risk assessments. How can I assist you on the bench today?", false)
    ))
    val aiMessages: StateFlow<List<Pair<String, Boolean>>> = _aiMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    fun sendAiMessage(message: String) {
        if (message.isBlank()) return
        
        val currentList = _aiMessages.value.toMutableList()
        currentList.add(Pair(message, true))
        _aiMessages.value = currentList
        
        _isAiLoading.value = true
        
        viewModelScope.launch(Dispatchers.IO) {
            val systemPrompt = """
                You are Mastercraft AI, an expert, restrained British digital workbench assistant for skilled masonry and building trades (stonemasons, bricklayers, heritage restorers).
                Your tone is highly professional, technical, direct, respectful, and rooted in traditional British craftsmanship.
                Do NOT use excessive emojis or exclamation points.
                Focus on:
                - UK Building Regulations (e.g., British Standard BS 8221 on cleaning/conservation, BS 5628 on structural masonry design).
                - Proper historic binders: NHL (Natural Hydraulic Lime) 2.0, 3.5, 5.0, hot lime, or putty lime. Explicitly discourage modern Portland cement on pre-1919 historic fabric as it causes moisture retention and spalling.
                - Traditional craft jargon: banker stone, dress, point, plumb, level, hearting, throughstones, sills, quoins, templates.
                
                SAFETY MANDATE: Always state that calculations are estimates and must be verified physically on site. Never independently certify structural stability, safety checklists, or historic conservation consents. Make the user aware of HSE regulations (COSHH regarding crystalline silica dust while cutting sandstone, manual handling, scaffold inspection).
            """.trimIndent()
            
            val activeJobInfo = activeJob.value?.let {
                "We are currently working on project ${it.name} (${it.projectType}), client: ${it.clientName}, spec notes: ${it.notes}."
            } ?: "No job is currently selected."
            
            val fullPrompt = "Context: $activeJobInfo\n\nUser Question: $message"
            
            val response = RetrofitClient.askGemini(fullPrompt, systemPrompt)
            
            launch(Dispatchers.Main) {
                _isAiLoading.value = false
                val updatedList = _aiMessages.value.toMutableList()
                updatedList.add(Pair(response, false))
                _aiMessages.value = updatedList
            }
        }
    }

    fun clearAiConversation() {
        _aiMessages.value = listOf(
            Pair("Good day Edward. Conversation reset. How can I assist you on the bench today?", false)
        )
    }


    // -------------------------------------------------------------
    // WALL & ESTIMATING CALCULATORS (OFFLINE ENGINE)
    // -------------------------------------------------------------
    
    // Core inputs
    var calcLength = MutableStateFlow(18.4)
    var calcHeight = MutableStateFlow(1.2)
    var calcThickness = MutableStateFlow(215) // mm
    var calcWaste = MutableStateFlow(10) // percent
    
    // Outputs for Wall Calculator
    val wallArea = combine(calcLength, calcHeight) { len, hgt -> len * hgt }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 22.08)

    val wallVolume = combine(wallArea, calcThickness) { area, thick -> area * (thick / 1000.0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 4.75)

    // Brickwork Outputs
    val brickCount = combine(wallArea, calcWaste) { area, waste ->
        // Standard brick running bond requires ~60 bricks per m2 for single skin (102.5mm), or ~120 for double skin (215mm)
        val factor = if (calcThickness.value > 150) 120 else 60
        val baseCount = area * factor
        val wasteFactor = 1.0 + (waste / 100.0)
        (baseCount * wasteFactor).toInt()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2914)

    val brickMortarVolume = wallVolume.map { vol ->
        // Mortar is roughly 20-25% of the total brickwork volume
        vol * 0.22
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.045)

    val brickLabourEstimate = wallArea.map { area ->
        // Average bricklayer lays ~1 m2 of double skin (120 bricks) in 1.2 hours
        val multiplier = if (calcThickness.value > 150) 1.25 else 0.75
        area * multiplier
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 27.6)

    // Natural Stone Outputs
    val stoneVolume = wallVolume.map { vol -> vol }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 4.75)
    
    val stoneMassTonnes = stoneVolume.map { vol ->
        // Density of sandstone is roughly 2.3 tonnes per m3
        vol * 2.35
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 11.16)

    val stoneLabourEstimate = wallArea.map { area ->
        // Stonemasonry is highly detailed. Standard dry stone or coursed wall takes ~2.5 hours per m2
        area * 2.5
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 55.2)

    // Repointing Calculator Outputs
    var jointWidth = MutableStateFlow(10) // mm
    var jointDepth = MutableStateFlow(20) // mm

    val repointMortarVolume = combine(wallArea, jointWidth, jointDepth, calcWaste) { area, width, depth, waste ->
        // Formula: joint area fraction * depth. Approx: 0.015 m3 of mortar per m2 for standard bricks
        val baseMortarPerM2 = 0.015
        val scaleFactor = (width / 10.0) * (depth / 20.0)
        val baseVolume = area * baseMortarPerM2 * scaleFactor
        baseVolume * (1.0 + (waste / 100.0))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.36)

    val repointLabourEstimate = wallArea.map { area ->
        // Repointing raking out + filling takes ~0.75 hours per m2
        area * 0.75
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 16.5)

    // Financial estimations
    val estimatedMaterialCost = combine(stoneMassTonnes, brickCount, _currentScreen) { tonnes, bricks, screen ->
        if (screen.contains("brick")) {
            bricks * 0.95 // 95p per facing brick
        } else {
            tonnes * 185.0 // £185 per tonne sandstone
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2064.6)

    val estimatedLabourCost = combine(stoneLabourEstimate, brickLabourEstimate, _currentScreen) { stoneHrs, brickHrs, screen ->
        val hours = if (screen.contains("brick")) brickHrs else stoneHrs
        hours * 30.0 // Standard composite crew rate of £30/hour
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1656.0)

    val estimatedTotalCost = combine(estimatedMaterialCost, estimatedLabourCost) { mat, lab ->
        mat + lab
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 3720.6)
}
