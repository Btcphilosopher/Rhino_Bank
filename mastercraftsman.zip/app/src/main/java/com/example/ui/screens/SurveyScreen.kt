package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.DefectEntity
import com.example.data.database.SurveyEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurveyScreen(
    viewModel: MastercraftViewModel,
    modifier: Modifier = Modifier
) {
    val activeJob by viewModel.activeJob.collectAsState()
    val surveys by viewModel.jobSurveys.collectAsState()
    val defects by viewModel.jobDefects.collectAsState()

    // Calculator state
    val length by viewModel.calcLength.collectAsState()
    val height by viewModel.calcHeight.collectAsState()
    val thickness by viewModel.calcThickness.collectAsState()
    val waste by viewModel.calcWaste.collectAsState()

    val area by viewModel.wallArea.collectAsState()
    val volume by viewModel.wallVolume.collectAsState()
    val bricks by viewModel.brickCount.collectAsState()
    val tonnes by viewModel.stoneMassTonnes.collectAsState()
    val estMatCost by viewModel.estimatedMaterialCost.collectAsState()
    val estLabCost by viewModel.estimatedLabourCost.collectAsState()
    val estTotal by viewModel.estimatedTotalCost.collectAsState()
    val brickMortarVolume by viewModel.brickMortarVolume.collectAsState()
    val brickLabourEstimate by viewModel.brickLabourEstimate.collectAsState()
    val stoneLabourEstimate by viewModel.stoneLabourEstimate.collectAsState()

    var activeTab by remember { mutableStateOf("SURVEY") } // SURVEY, WALL_CALC, BRICK_CALC

    var showAddSurvey by remember { mutableStateOf(false) }
    var surveyWeather by remember { mutableStateOf("Dry / Sun") }
    var surveyNotes by remember { mutableStateOf("") }

    var showAddDefect by remember { mutableStateOf(false) }
    var defectTitle by remember { mutableStateOf("") }
    var defectLoc by remember { mutableStateOf("") }
    var defectPriority by remember { mutableStateOf("High") }
    var defectAction by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SURVEY & CALCULATE",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = activeJob?.name ?: "No Job Selected",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Digital Site Notebook • Verified Estimator",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TabButton(text = "Notebook & Defects", isSelected = activeTab == "SURVEY", onClick = { activeTab = "SURVEY" })
            TabButton(text = "Wall Calculator", isSelected = activeTab == "WALL_CALC", onClick = { activeTab = "WALL_CALC" })
            TabButton(text = "Brick & Stone", isSelected = activeTab == "BRICK_CALC", onClick = { activeTab = "BRICK_CALC" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "SURVEY" -> {
                    // Site Surveys Section
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("SITE SURVEY RECORDS", style = MaterialTheme.typography.labelLarge)
                                    Button(
                                        onClick = { showAddSurvey = !showAddSurvey },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(2.dp)
                                    ) {
                                        Icon(imageVector = if (showAddSurvey) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (showAddSurvey) "Close" else "Log Survey", style = MaterialTheme.typography.labelMedium)
                                    }
                                }

                                if (showAddSurvey) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = surveyWeather, onValueChange = { surveyWeather = it }, label = { Text("Weather Conditions") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = surveyNotes, onValueChange = { surveyNotes = it }, label = { Text("Survey Observations & Measurements") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                                        Button(
                                            onClick = {
                                                if (surveyNotes.isNotBlank()) {
                                                    viewModel.addSiteSurvey(surveyWeather, surveyNotes)
                                                    surveyNotes = ""
                                                    showAddSurvey = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Save Survey Record")
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                if (surveys.isEmpty()) {
                                    Text("No surveys logged yet. Click 'Log Survey' on site.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    surveys.forEach { survey ->
                                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text(text = survey.surveyDate, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Text(text = "Weather: ${survey.weather}", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(text = survey.notes, style = MaterialTheme.typography.bodyLarge, color = CharcoalIron)
                                            Divider(color = SlateSeparator, modifier = Modifier.padding(top = 8.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Defect Register Section
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("DEFECT REGISTER & CONSERVATION SNAGS", style = MaterialTheme.typography.labelLarge)
                                    IconButton(onClick = { showAddDefect = !showAddDefect }) {
                                        Icon(imageVector = if (showAddDefect) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                                    }
                                }

                                if (showAddDefect) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = defectTitle, onValueChange = { defectTitle = it }, label = { Text("Defect Title (e.g. Cracked Lintels)") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = defectLoc, onValueChange = { defectLoc = it }, label = { Text("Exact Facade Location") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = defectAction, onValueChange = { defectAction = it }, label = { Text("Recommended Remedial Action") }, modifier = Modifier.fillMaxWidth())
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text("Priority:")
                                            listOf("High", "Medium", "Low").forEach { p ->
                                                val sel = defectPriority == p
                                                Box(
                                                    modifier = Modifier
                                                        .border(1.dp, if (sel) MaterialTheme.colorScheme.primary else SlateSeparator, RoundedCornerShape(2.dp))
                                                        .background(if (sel) Color(0xFFECE6DA) else Color.Transparent)
                                                        .clickable { defectPriority = p }
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(p, style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                        }
                                        Button(
                                            onClick = {
                                                if (defectTitle.isNotBlank() && defectLoc.isNotBlank()) {
                                                    viewModel.addDefect(defectTitle, defectLoc, defectPriority, defectAction)
                                                    defectTitle = ""
                                                    defectLoc = ""
                                                    defectAction = ""
                                                    showAddDefect = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Log Defect")
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                if (defects.isEmpty()) {
                                    Text("No defects currently logged for this site.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    defects.forEach { defect ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(text = "[${defect.defectNumber}]", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(text = defect.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                }
                                                Text(text = "Location: ${defect.location}", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                                Text(text = "Remedy: ${defect.actionRequired}", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(horizontalAlignment = Alignment.End) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(2.dp))
                                                        .background(if (defect.priority == "High") BrickRed else SteelGrey)
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(defect.priority, style = MaterialTheme.typography.labelSmall, color = Color.White)
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (defect.status == "OPEN" || defect.status == "PLANNED") {
                                                    Button(
                                                        onClick = { viewModel.updateDefectStatus(defect, "CLOSED") },
                                                        colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                                        shape = RoundedCornerShape(2.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Text("Close Out", fontSize = 11.sp)
                                                    }
                                                } else {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(imageVector = Icons.Outlined.Check, contentDescription = null, tint = BritishGreen, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(2.dp))
                                                        Text("CLOSED", style = MaterialTheme.typography.labelSmall, color = BritishGreen)
                                                    }
                                                }
                                            }
                                        }
                                        Divider(color = SlateSeparator)
                                    }
                                }
                            }
                        }
                    }
                }

                "WALL_CALC" -> {
                    // WALL QUANTITY CALCULATOR
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("INTERACTIVE WALL DESIGN", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(12.dp))

                                // Technical Canvas Diagram
                                TechnicalWallElevation(
                                    widthVal = length,
                                    heightVal = height,
                                    thicknessVal = thickness.toDouble()
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // Sliders/Inputs for calculator
                                NumericSliderInput(
                                    label = "Wall Length (m)",
                                    value = length,
                                    range = 1f..100f,
                                    onValueChange = { viewModel.calcLength.value = String.format("%.1f", it).toDouble() }
                                )

                                NumericSliderInput(
                                    label = "Wall Height (m)",
                                    value = height,
                                    range = 0.5f..10f,
                                    onValueChange = { viewModel.calcHeight.value = String.format("%.1f", it).toDouble() }
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Text("Wall Thickness (mm)", style = MaterialTheme.typography.titleMedium)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ThicknessButton(text = "Single Skin (102mm)", value = 102, selected = thickness == 102, onClick = { viewModel.calcThickness.value = 102 })
                                    ThicknessButton(text = "Double Skin (215mm)", value = 215, selected = thickness == 215, onClick = { viewModel.calcThickness.value = 215 })
                                    ThicknessButton(text = "Foundation (328mm)", value = 328, selected = thickness == 328, onClick = { viewModel.calcThickness.value = 328 })
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text("Waste Allowance (%)", style = MaterialTheme.typography.titleMedium)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(5, 10, 15).forEach { w ->
                                        val sel = waste == w
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .border(1.dp, if (sel) MaterialTheme.colorScheme.primary else SlateSeparator, RoundedCornerShape(2.dp))
                                                .background(if (sel) Color(0xFFECE6DA) else Color.Transparent)
                                                .clickable { viewModel.calcWaste.value = w }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("$w%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Calculated Guides Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("GEOMETRIC GUIDES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(8.dp))
                                CalcResultRow(label = "Calculated Surface Area", value = "${String.format("%.2f", area)} m²")
                                CalcResultRow(label = "Calculated Solid Volume", value = "${String.format("%.3f", volume)} m³")
                                CalcResultRow(label = "Thickness", value = "$thickness mm")
                                CalcResultRow(label = "Waste Factor Included", value = "+$waste%")
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "ESTIMATE ONLY — VERIFY PHYSICALLY ON SITE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                "BRICK_CALC" -> {
                    // BRICK & STONE SPECIFIC CALCULATORS
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("BRICKWORK ESTIMATION", style = MaterialTheme.typography.titleLarge)
                                Spacer(modifier = Modifier.height(8.dp))
                                CalcResultRow(label = "Target Surface Area", value = "${String.format("%.2f", area)} m²")
                                CalcResultRow(label = "Total Facing Bricks Required", value = "$bricks units", highlight = true)
                                CalcResultRow(label = "Mortar Quantity Estimate", value = "${String.format("%.2f", brickMortarVolume)} m³")
                                CalcResultRow(label = "Labour Construction Time", value = "${String.format("%.1f", brickLabourEstimate)} Hours")
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Based on standard UK brick (215 x 102.5 x 65mm) in half-brick running bond with 10mm joints.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SteelGrey
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("NATURAL STONE WALLING", style = MaterialTheme.typography.titleLarge)
                                Spacer(modifier = Modifier.height(8.dp))
                                CalcResultRow(label = "Target Volume", value = "${String.format("%.3f", volume)} m³")
                                CalcResultRow(label = "Sandstone Weight Required", value = "${String.format("%.2f", tonnes)} Tonnes", highlight = true)
                                CalcResultRow(label = "Labour Construction Time", value = "${String.format("%.1f", stoneLabourEstimate)} Hours")
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Based on Yorkshire Sandstone solid walling density of 2350 kg/m³ with irregular coursed ashlar laying assumptions.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SteelGrey
                                )
                            }
                        }
                    }

                    // Repointing Section
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("REPOINTING CALCULATOR", style = MaterialTheme.typography.titleLarge)
                                Spacer(modifier = Modifier.height(8.dp))
                                val repointVol by viewModel.repointMortarVolume.collectAsState()
                                val repointLab by viewModel.repointLabourEstimate.collectAsState()
                                CalcResultRow(label = "Surface Area to Joint", value = "${String.format("%.2f", area)} m²")
                                CalcResultRow(label = "Joint Width x Depth Assumptions", value = "10mm x 20mm")
                                CalcResultRow(label = "Approx. Joint Mortar Needed", value = "${String.format("%.3f", repointVol)} m³", highlight = true)
                                CalcResultRow(label = "Labour Repoint Time", value = "${String.format("%.1f", repointLab)} Hours")
                            }
                        }
                    }

                    // Save as Job Measurement Button
                    item {
                        Button(
                            onClick = {
                                viewModel.addMeasurement(
                                    label = "Site Survey Calc (${length}m x ${height}m)",
                                    length = length,
                                    height = height,
                                    thickness = thickness.toDouble(),
                                    type = "wall_calc",
                                    qty = area,
                                    matCost = estMatCost,
                                    labCost = estLabCost,
                                    notes = "Generated from wall calculator at $waste% waste allowance."
                                )
                                viewModel.navigateTo("jobs")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_save_calc_measurement")
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save Calculation to Active Contract", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(2.dp))
            .background(if (isSelected) BritishGreen else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else CharcoalIron
        )
    }
}

@Composable
fun ThicknessButton(
    text: String,
    value: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .border(1.dp, if (selected) MaterialTheme.colorScheme.primary else SlateSeparator, RoundedCornerShape(2.dp))
            .background(if (selected) Color(0xFFECE6DA) else Color.Transparent)
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selected) MaterialTheme.colorScheme.primary else CharcoalIron)
    }
}

@Composable
fun NumericSliderInput(
    label: String,
    value: Double,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.titleMedium)
            Text("${String.format("%.1f", value)}m", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = SlateSeparator
            )
        )
    }
}

@Composable
fun CalcResultRow(
    label: String,
    value: String,
    highlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
        Text(
            text = value,
            style = if (highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = if (highlight) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onBackground
        )
    }
    Divider(color = SlateSeparator, thickness = 0.5.dp)
}

@Composable
fun TechnicalWallElevation(
    widthVal: Double,
    heightVal: Double,
    thicknessVal: Double
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .border(1.dp, SlateSeparator)
            .background(Color(0xFFEDE8DF)) // Aged paper colour
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val padding = 30f
            val canvasW = size.width - (padding * 2)
            val canvasH = size.height - (padding * 2)

            // Draw technical grid background lines
            val gridStep = 20f
            for (x in 0..size.width.toInt() step gridStep.toInt()) {
                drawLine(
                    color = Color(0x1F1C2826),
                    start = Offset(x.toFloat(), 0f),
                    end = Offset(x.toFloat(), size.height),
                    strokeWidth = 0.5f
                )
            }
            for (y in 0..size.height.toInt() step gridStep.toInt()) {
                drawLine(
                    color = Color(0x1F1C2826),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat()),
                    strokeWidth = 0.5f
                )
            }

            // Draw Wall Block base
            val wallW = canvasW * 0.85f
            val wallH = canvasH * 0.70f
            val wallX = padding + (canvasW - wallW) / 2
            val wallY = padding + (canvasH - wallH)

            // Draw brick courses
            val rowsCount = 8
            val colsCount = 10
            val blockW = wallW / colsCount
            val blockH = wallH / rowsCount

            for (r in 0 until rowsCount) {
                val rowOffset = if (r % 2 == 0) blockW / 2 else 0f
                for (c in 0..colsCount) {
                    val x = wallX + (c * blockW) - rowOffset
                    if (x >= wallX && (x + blockW) <= (wallX + wallW)) {
                        drawRect(
                            color = Color(0x14AB3526), // brick tint
                            topLeft = Offset(x, wallY + (r * blockH)),
                            size = Size(blockW - 1f, blockH - 1f)
                        )
                        // Outline
                        drawRect(
                            color = Color(0xFF535D5A),
                            topLeft = Offset(x, wallY + (r * blockH)),
                            size = Size(blockW - 1f, blockH - 1f),
                            style = Stroke(0.8f)
                        )
                    }
                }
            }

            // Outer Technical boundary
            drawRect(
                color = Color(0xFF1E2422),
                topLeft = Offset(wallX, wallY),
                size = Size(wallW, wallH),
                style = Stroke(1.5f)
            )

            // Dimension line for Length (Bottom)
            val dimY = wallY + wallH + 15f
            drawLine(
                color = Color(0xFFAB3526),
                start = Offset(wallX, dimY),
                end = Offset(wallX + wallW, dimY),
                strokeWidth = 1f
            )
            // Left tick
            drawLine(color = Color(0xFFAB3526), start = Offset(wallX, dimY - 5f), end = Offset(wallX, dimY + 5f), strokeWidth = 1.2f)
            // Right tick
            drawLine(color = Color(0xFFAB3526), start = Offset(wallX + wallW, dimY - 5f), end = Offset(wallX + wallW, dimY + 5f), strokeWidth = 1.2f)

            // Dimension line for Height (Left)
            val dimX = wallX - 15f
            drawLine(
                color = Color(0xFFAB3526),
                start = Offset(dimX, wallY),
                end = Offset(dimX, wallY + wallH),
                strokeWidth = 1f
            )
            // Top tick
            drawLine(color = Color(0xFFAB3526), start = Offset(dimX - 5f, wallY), end = Offset(dimX + 5f, wallY), strokeWidth = 1.2f)
            // Bottom tick
            drawLine(color = Color(0xFFAB3526), start = Offset(dimX - 5f, wallY + wallH), end = Offset(dimX + 5f, wallY + wallH), strokeWidth = 1.2f)
        }

        // Labels overlaid
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 12.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Text(
                text = "${String.format("%.1f", widthVal)}m Length",
                style = MaterialTheme.typography.labelSmall,
                color = BrickRed,
                fontWeight = FontWeight.Bold
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 2.dp, top = 20.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "${String.format("%.1f", heightVal)}m\nHeight",
                style = MaterialTheme.typography.labelSmall,
                color = BrickRed,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                lineHeight = 11.sp
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            Text(
                text = "SCHEMATIC ESTIMATE\nTHICKNESS: ${thicknessVal.toInt()}mm",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                fontSize = 9.sp,
                lineHeight = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
