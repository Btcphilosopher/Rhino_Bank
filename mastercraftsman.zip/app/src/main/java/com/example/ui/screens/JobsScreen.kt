package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobsScreen(
    viewModel: MastercraftViewModel,
    subScreen: String = "list", // "list", "new", "detail"
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val jobs by viewModel.allJobs.collectAsState()
    val activeJob by viewModel.activeJob.collectAsState()
    var localSubScreen by remember { mutableStateOf(subScreen) }

    BackHandler {
        if (localSubScreen != "list") {
            localSubScreen = "list"
        } else {
            onNavigateBack()
        }
    }

    when (localSubScreen) {
        "new" -> NewJobForm(
            onCancel = { localSubScreen = "list" },
            onCreate = { name, client, site, type, valStr, start, end, notes, contact, arch, sContact ->
                viewModel.createJob(
                    name = name,
                    client = client,
                    site = site,
                    type = type,
                    value = valStr.toDoubleOrNull() ?: 0.0,
                    start = start,
                    end = end,
                    notes = notes,
                    contact = contact,
                    architect = arch,
                    siteContact = sContact
                )
                localSubScreen = "list"
            }
        )
        "detail" -> JobDetailScreen(
            viewModel = viewModel,
            job = activeJob,
            onBack = { localSubScreen = "list" }
        )
        else -> JobListScreen(
            jobs = jobs,
            activeJob = activeJob,
            onSelectJob = { job ->
                viewModel.selectJob(job.id)
                localSubScreen = "detail"
            },
            onAddNewJob = { localSubScreen = "new" }
        )
    }
}

@Composable
fun JobListScreen(
    jobs: List<JobEntity>,
    activeJob: JobEntity?,
    onSelectJob: (JobEntity) -> Unit,
    onAddNewJob: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    val filters = listOf("ALL", "ON SITE", "AWARDED", "LEAD", "COMPLETE")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "REGISTER",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
                Text(
                    text = "Building Contracts",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            Button(
                onClick = onAddNewJob,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("btn_new_job")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Job", style = MaterialTheme.typography.labelLarge)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Filters scroll
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { filter ->
                val isSelected = selectedFilter == filter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFECE6DA))
                        .clickable { selectedFilter = filter }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = filter,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        val filteredJobs = if (selectedFilter == "ALL") jobs else jobs.filter { it.status == selectedFilter }

        if (filteredJobs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No jobs found for filter: $selectedFilter",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SteelGrey
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredJobs) { job ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectJob(job) }
                            .testTag("job_item_${job.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(4.dp),
                        border = BorderStroke(1.dp, SlateSeparator)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = job.jobNumber,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                    Text(
                                        text = job.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(if (job.status == "ON SITE") BritishGreen else SteelGrey)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = job.status,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Client: ${job.clientName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SteelGrey
                            )
                            Text(
                                text = "Site: ${job.siteAddress}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SteelGrey
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Contract: £${String.format("%,.2f", job.contractValue)}",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(
                                    text = "Progress: ${job.progressPercent}%",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewJobForm(
    onCancel: () -> Unit,
    onCreate: (String, String, String, String, String, String, String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var client by remember { mutableStateOf("") }
    var site by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("HERITAGE RESTORATION") }
    var value by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("2026-09-25") }
    var end by remember { mutableStateOf("2026-12-15") }
    var notes by remember { mutableStateOf("") }
    var clientContact by remember { mutableStateOf("") }
    var architect by remember { mutableStateOf("") }
    var siteContact by remember { mutableStateOf("") }

    val projectTypes = listOf(
        "HERITAGE RESTORATION", "STONE WALL", "BRICK WALL", "STONE REPAIR", 
        "BRICK REPAIR", "DRY STONE WALL", "STONE PAVING", "CHIMNEY", "GARDEN WALL"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "NEW CONTRACT",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
                Text(
                    text = "Specify Project",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Project Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_job_name")
            )
        }

        item {
            OutlinedTextField(
                value = client,
                onValueChange = { client = it },
                label = { Text("Client Name") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = site,
                onValueChange = { site = it },
                label = { Text("Site Address") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Text("Project Type", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            var expanded by remember { mutableStateOf(false) }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateSeparator, RoundedCornerShape(4.dp))
                    .clickable { expanded = true }
                    .padding(12.dp)
            ) {
                Text(type, style = MaterialTheme.typography.bodyLarge)
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    projectTypes.forEach { pt ->
                        DropdownMenuItem(
                            text = { Text(pt) },
                            onClick = {
                                type = pt
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                label = { Text("Estimated Contract Value (£)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = start,
                    onValueChange = { start = it },
                    label = { Text("Start Date") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = end,
                    onValueChange = { end = it },
                    label = { Text("Target Completion") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            OutlinedTextField(
                value = clientContact,
                onValueChange = { clientContact = it },
                label = { Text("Client Contact Info") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = architect,
                onValueChange = { architect = it },
                label = { Text("Architect / Specifier") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = siteContact,
                onValueChange = { siteContact = it },
                label = { Text("Site Manager Contact") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Initial Scope Specifications") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onCancel) {
                    Text("Cancel", color = SteelGrey)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (name.isNotBlank() && client.isNotBlank()) {
                            onCreate(name, client, site, type, value, start, end, notes, clientContact, architect, siteContact)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("btn_create_job")
                ) {
                    Text("Create Job")
                }
            }
        }
    }
}

@Composable
fun JobDetailScreen(
    viewModel: MastercraftViewModel,
    job: JobEntity?,
    onBack: () -> Unit
) {
    if (job == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Job details not found.")
        }
        return
    }

    val drawings by viewModel.jobDrawings.collectAsState()
    val defects by viewModel.jobDefects.collectAsState()
    val variations by viewModel.jobVariations.collectAsState()
    val components by viewModel.jobComponents.collectAsState()

    var statusExpanded by remember { mutableStateOf(false) }
    val statuses = listOf("LEAD", "SURVEY", "ESTIMATING", "QUOTED", "AWARDED", "PLANNED", "ON SITE", "PAUSED", "SNAGGING", "COMPLETE")

    var showAddVariation by remember { mutableStateOf(false) }
    var variationDesc by remember { mutableStateOf("") }
    var variationCost by remember { mutableStateOf("") }

    var showAddDrawing by remember { mutableStateOf(false) }
    var drawingNum by remember { mutableStateOf("") }
    var drawingTitle by remember { mutableStateOf("") }
    var drawingAuthor by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Technical Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier
                        .clickable { onBack() }
                        .padding(8.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "CONTRACT ${job.jobNumber}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Text(
                        text = job.name,
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Quick Stats row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailStat(label = "Value", value = "£${String.format("%,.0f", job.contractValue)}", modifier = Modifier.weight(1f))
                DetailStat(label = "Cost to Date", value = "£${String.format("%,.0f", job.costToDate)}", modifier = Modifier.weight(1f))
                DetailStat(label = "Progress", value = "${job.progressPercent}%", modifier = Modifier.weight(1f))
            }
        }

        // Job Status Dropdown Editor
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, SlateSeparator)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("CONTRACT WORKFLOW STATUS", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box {
                        Button(
                            onClick = { statusExpanded = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFECE6DA), contentColor = CharcoalIron),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(job.status, fontWeight = FontWeight.Bold)
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                            statuses.forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st) },
                                    onClick = {
                                        viewModel.updateJobStatus(job.id, st)
                                        statusExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Contacts Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, SlateSeparator)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PROJECT DIRECTORY", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(10.dp))
                    ContactLine(label = "Client Contact", name = job.clientContact)
                    ContactLine(label = "Architect", name = if (job.architectName.isEmpty()) "None specified" else job.architectName)
                    ContactLine(label = "Site Contact", name = if (job.siteContact.isEmpty()) "None specified" else job.siteContact)
                    ContactLine(label = "Address", name = job.siteAddress)
                }
            }
        }

        // Scope Specs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, SlateSeparator)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("INITIAL SPECIFICATION SUMMARY", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = job.notes,
                        style = MaterialTheme.typography.bodyLarge,
                        color = SteelGrey
                    )
                }
            }
        }

        // Drawings Register
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, SlateSeparator)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DRAWING REGISTER", style = MaterialTheme.typography.labelLarge)
                        IconButton(onClick = { showAddDrawing = !showAddDrawing }) {
                            Icon(imageVector = if (showAddDrawing) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                        }
                    }

                    if (showAddDrawing) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            OutlinedTextField(value = drawingNum, onValueChange = { drawingNum = it }, label = { Text("Drawing Number (e.g. A-302)") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = drawingTitle, onValueChange = { drawingTitle = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = drawingAuthor, onValueChange = { drawingAuthor = it }, label = { Text("Author") }, modifier = Modifier.fillMaxWidth())
                            Button(
                                onClick = {
                                    if (drawingNum.isNotBlank() && drawingTitle.isNotBlank()) {
                                        viewModel.addDrawing(drawingNum, drawingTitle, drawingAuthor, "A")
                                        drawingNum = ""
                                        drawingTitle = ""
                                        drawingAuthor = ""
                                        showAddDrawing = false
                                    }
                                },
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Add Drawing")
                            }
                        }
                    }

                    if (drawings.isEmpty()) {
                        Text("No technical drawings uploaded.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                    } else {
                        drawings.forEach { drawing ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${drawing.drawingNumber} (Rev ${drawing.revision})",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = drawing.title, style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                    Text(text = "By ${drawing.author} • ${drawing.date}", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(Color(0xFFE2F0D9))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("CURRENT", style = MaterialTheme.typography.labelSmall, color = BritishGreen)
                                }
                            }
                            Divider(color = SlateSeparator)
                        }
                    }
                }
            }
        }

        // Variations Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, SlateSeparator)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CONTRACT VARIATIONS", style = MaterialTheme.typography.labelLarge)
                        IconButton(onClick = { showAddVariation = !showAddVariation }) {
                            Icon(imageVector = if (showAddVariation) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                        }
                    }

                    if (showAddVariation) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            OutlinedTextField(
                                value = variationDesc,
                                onValueChange = { variationDesc = it },
                                label = { Text("Variation Description") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = variationCost,
                                onValueChange = { variationCost = it },
                                label = { Text("Additional Cost (£)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    if (variationDesc.isNotBlank() && variationCost.isNotBlank()) {
                                        viewModel.addVariation(variationDesc, variationCost.toDoubleOrNull() ?: 0.0)
                                        variationDesc = ""
                                        variationCost = ""
                                        showAddVariation = false
                                    }
                                },
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Submit Variation")
                            }
                        }
                    }

                    if (variations.isEmpty()) {
                        Text("No contract variations recorded.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                    } else {
                        variations.forEach { variation ->
                            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Variation ${variation.variationNumber}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(text = variation.description, style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                        Text(text = "Amount: £${String.format("%,.2f", variation.cost)}", style = MaterialTheme.typography.labelMedium)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (variation.status == "SUBMITTED") {
                                        Button(
                                            onClick = { viewModel.approveVariation(variation) },
                                            colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                            shape = RoundedCornerShape(2.dp)
                                        ) {
                                            Text("Approve")
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(if (variation.status == "APPROVED") Color(0xFFE2F0D9) else Color(0xFFF2DEDE))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = variation.status,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (variation.status == "APPROVED") BritishGreen else BrickRed
                                            )
                                        }
                                    }
                                }
                                Divider(color = SlateSeparator, modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailStat(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, SlateSeparator),
        shape = RoundedCornerShape(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = SteelGrey)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun ContactLine(label: String, name: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = SteelGrey,
            modifier = Modifier.width(110.dp)
        )
        Text(
            text = name,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )
    }
}
