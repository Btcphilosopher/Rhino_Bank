package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.InvoiceEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun AccountsScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeJob by viewModel.activeJob.collectAsState()
    val invoices by viewModel.allInvoices.collectAsState()

    var activeTab by remember { mutableStateOf("INVOICES") } // INVOICES, CASHFLOW, PROFITABILITY

    var showAddInvoice by remember { mutableStateOf(false) }
    var invDesc by remember { mutableStateOf("Stage 1 Milestone - mobilization & raking out") }
    var invNet by remember { mutableStateOf("12500") }

    // Aggregate statistics
    val totalRevenue = invoices.filter { it.status == "PAID" }.sumOf { it.netAmount }
    val outstanding = invoices.filter { it.status == "SENT" || it.status == "OVERDUE" }.sumOf { it.totalAmount }
    val totalVat = invoices.filter { it.status == "PAID" }.sumOf { it.vatAmount }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ACCOUNTS & CASHFLOW",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = "Business Office",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Staged Valuations • Standard VAT Ledgers • Contract Margins",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TabButton(text = "Staged Invoices", isSelected = activeTab == "INVOICES", onClick = { activeTab = "INVOICES" })
            TabButton(text = "Cashflow Overview", isSelected = activeTab == "CASHFLOW", onClick = { activeTab = "CASHFLOW" })
            TabButton(text = "Job Profitability", isSelected = activeTab == "PROFITABILITY", onClick = { activeTab = "PROFITABILITY" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "INVOICES" -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("STAGED BILLING RECORD", style = MaterialTheme.typography.labelLarge)
                                    Button(
                                        onClick = { showAddInvoice = !showAddInvoice },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(2.dp),
                                        modifier = Modifier.testTag("btn_trigger_invoice_form")
                                    ) {
                                        Icon(imageVector = if (showAddInvoice) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (showAddInvoice) "Close" else "Stage Invoice", style = MaterialTheme.typography.labelMedium)
                                    }
                                }

                                if (showAddInvoice) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = invDesc, onValueChange = { invDesc = it }, label = { Text("Staging Description") }, modifier = Modifier.fillMaxWidth().testTag("inv_desc_input"))
                                        OutlinedTextField(value = invNet, onValueChange = { invNet = it }, label = { Text("Net Valuation Amount (£)") }, modifier = Modifier.fillMaxWidth().testTag("inv_net_input"))
                                        Button(
                                            onClick = {
                                                if (invDesc.isNotBlank() && invNet.isNotBlank()) {
                                                    viewModel.addInvoice(invDesc, invNet.toDoubleOrNull() ?: 0.0, "25 September 2026")
                                                    invDesc = ""
                                                    invNet = ""
                                                    showAddInvoice = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("btn_save_invoice")
                                        ) {
                                            Text("Generate Staged Invoice")
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                if (invoices.isEmpty()) {
                                    Text("No staged invoices generated.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    invoices.forEach { invoice ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text("[${invoice.invoiceNumber}]", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(invoice.description, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                                                }
                                                Text("Net: £${String.format("%,.2f", invoice.netAmount)} + VAT 20%: £${String.format("%,.2f", invoice.vatAmount)}", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                                Text("Total Bill: £${String.format("%,.2f", invoice.totalAmount)} • Issued: ${invoice.date}", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(horizontalAlignment = Alignment.End) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(2.dp))
                                                        .background(if (invoice.status == "PAID") Color(0xFFE2F0D9) else Color(0xFFF2DEDE))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = invoice.status,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = if (invoice.status == "PAID") BritishGreen else BrickRed,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(6.dp))
                                                if (invoice.status == "SENT") {
                                                    Button(
                                                        onClick = { viewModel.payInvoice(invoice) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                                        shape = RoundedCornerShape(2.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Text("Received", fontSize = 11.sp)
                                                    }
                                                }
                                            }
                                        }
                                        Divider(color = SlateSeparator)
                                    }
                                }
                            }
                        }
                    }
                }

                "CASHFLOW" -> {
                    // Business Cashflow Panel
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("HARCOURT RESTORATION LEDGER", style = MaterialTheme.typography.labelLarge)
                                }
                                Spacer(modifier = Modifier.height(14.dp))

                                CashflowLedgerLine(label = "Net Revenue Paid (This Year)", value = "£${String.format("%,.2f", totalRevenue)}", isHighlight = true)
                                CashflowLedgerLine(label = "Outstanding Stage Payments", value = "£${String.format("%,.2f", outstanding)}")
                                CashflowLedgerLine(label = "VAT Liability Recorded (20%)", value = "£${String.format("%,.2f", totalVat)}")
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = SlateSeparator)
                                Spacer(modifier = Modifier.height(6.dp))
                                
                                Text(
                                    text = "All accounting streams reflect certified staged invoices. Staged invoices must be approved on-site by client project managers prior to payment release under JCT minor works standards.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SteelGrey,
                                    fontSize = 11.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }

                "PROFITABILITY" -> {
                    // Contract Margins Breakdown
                    activeJob?.let { job ->
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.dp, SlateSeparator)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("PROFITABILITY ASSESSMENTS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                                    Text(job.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    val labourAlloc = job.costToDate * 0.55
                                    val materialAlloc = job.costToDate * 0.45
                                    val projectedProfit = maxOf(0.0, job.contractValue - job.costToDate)
                                    val projectedMargin = if (job.contractValue > 0) (projectedProfit / job.contractValue) * 100.0 else 0.0

                                    CashflowLedgerLine(label = "Contract Agreed Price", value = "£${String.format("%,.2f", job.contractValue)}")
                                    CashflowLedgerLine(label = "Accumulated Costs to Date", value = "£${String.format("%,.2f", job.costToDate)}")
                                    CashflowLedgerLine(label = "  - Labor Allocation Estimate", value = "£${String.format("%,.2f", labourAlloc)}")
                                    CashflowLedgerLine(label = "  - Material Allocation Estimate", value = "£${String.format("%,.2f", materialAlloc)}")
                                    
                                    Divider(color = SlateSeparator, modifier = Modifier.padding(vertical = 8.dp))
                                    
                                    CashflowLedgerLine(label = "Projected Contract Profit", value = "£${String.format("%,.2f", projectedProfit)}", isHighlight = true)
                                    CashflowLedgerLine(label = "Projected Profit Margin", value = "${String.format("%.1f", projectedMargin)}%", isHighlight = true)
                                }
                            }
                        }
                    } ?: item {
                        Text("Please select a contract on the Today tab to view specific project profitability.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                    }
                }
            }
        }
    }
}

@Composable
fun CashflowLedgerLine(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = if (isHighlight) MaterialTheme.colorScheme.primary else CharcoalIron, fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Normal)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (isHighlight) MaterialTheme.colorScheme.tertiary else CharcoalIron)
    }
    Divider(color = SlateSeparator, thickness = 0.5.dp)
}
