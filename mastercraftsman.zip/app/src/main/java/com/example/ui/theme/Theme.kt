package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = BritishGreen,
    onPrimary = OffWhite,
    primaryContainer = SandstoneCard,
    onPrimaryContainer = CharcoalIron,
    secondary = InkBlue,
    onSecondary = OffWhite,
    secondaryContainer = SlateSeparator,
    onSecondaryContainer = CharcoalIron,
    tertiary = BrickRed,
    onTertiary = OffWhite,
    background = LimestoneBg,
    onBackground = CharcoalIron,
    surface = OffWhite,
    onSurface = CharcoalIron,
    surfaceVariant = SandstoneCard,
    onSurfaceVariant = CharcoalIron,
    outline = SteelGrey,
    inverseSurface = CharcoalIron,
    inverseOnSurface = LimestoneBg,
    error = BrickRed,
    onError = OffWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = AgedGold,
    onPrimary = CharcoalIron,
    primaryContainer = CharcoalIron,
    onPrimaryContainer = SandstoneCard,
    secondary = InkBlue,
    onSecondary = OffWhite,
    secondaryContainer = CharcoalIron,
    onSecondaryContainer = SandstoneCard,
    tertiary = BrickRed,
    onTertiary = OffWhite,
    background = CharcoalIron,
    onBackground = LimestoneBg,
    surface = Color(0xFF151918),
    onSurface = LimestoneBg,
    surfaceVariant = CharcoalIron,
    onSurfaceVariant = LimestoneBg,
    outline = SlateSeparator,
    inverseSurface = LimestoneBg,
    inverseOnSurface = CharcoalIron,
    error = BrickRed,
    onError = OffWhite
)

@Composable
fun MastercraftTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
