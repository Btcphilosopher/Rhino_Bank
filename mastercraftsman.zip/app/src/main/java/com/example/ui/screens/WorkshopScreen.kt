package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.WorkshopComponentEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun WorkshopScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeJob by viewModel.activeJob.collectAsState()
    val components by viewModel.jobComponents.collectAsState()
    val drawings by viewModel.jobDrawings.collectAsState()

    var activeTab by remember { mutableStateOf("BANKER") } // BANKER, DRAWINGS

    // Component Creation State
    var showAddComp by remember { mutableStateOf(false) }
    var compName by remember { mutableStateOf("Window Mullion - Splayed Block") }
    var compStone by remember { mutableStateOf("Bath Limestone") }
    var compDims by remember { mutableStateOf("450 x 215 x 215mm") }
    var compCraft by remember { mutableStateOf("Edward Harcourt") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "BANKER MASON WORKSHOP",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = activeJob?.name ?: "No Job Selected",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Stone Production Board • Template Register • Drawing Revisions",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TabButton(text = "Banker Staging Board", isSelected = activeTab == "BANKER", onClick = { activeTab = "BANKER" })
            TabButton(text = "Drawings Register", isSelected = activeTab == "DRAWINGS", onClick = { activeTab = "DRAWINGS" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "BANKER" -> {
                    // Banker Mason Component production board
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("STONE COMPONENT REGISTER", style = MaterialTheme.typography.labelLarge)
                                    Button(
                                        onClick = { showAddComp = !showAddComp },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(2.dp),
                                        modifier = Modifier.testTag("btn_trigger_comp_form")
                                    ) {
                                        Icon(imageVector = if (showAddComp) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (showAddComp) "Close" else "Record Block", style = MaterialTheme.typography.labelMedium)
                                    }
                                }

                                if (showAddComp) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = compName, onValueChange = { compName = it }, label = { Text("Component Title (e.g. Window Sill surround)") }, modifier = Modifier.fillMaxWidth().testTag("comp_name_input"))
                                        OutlinedTextField(value = compStone, onValueChange = { compStone = it }, label = { Text("Stone Type (e.g. Bath Stone)") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = compDims, onValueChange = { compDims = it }, label = { Text("Dimensions (Height x Width x Depth mm)") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = compCraft, onValueChange = { compCraft = it }, label = { Text("Lead Banker Craftsman") }, modifier = Modifier.fillMaxWidth())
                                        Button(
                                            onClick = {
                                                if (compName.isNotBlank() && compStone.isNotBlank()) {
                                                    viewModel.addComponent(compName, compStone, compDims, compCraft)
                                                    compName = ""
                                                    showAddComp = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("btn_save_component")
                                        ) {
                                            Text("Save Component Passport")
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                if (components.isEmpty()) {
                                    Text("No banker stones currently in production.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    components.forEach { comp ->
                                        ComponentPassportRow(
                                            comp = comp,
                                            onAdvance = { nextStatus ->
                                                viewModel.updateComponentStatus(comp, nextStatus, 4.0) // Adds 4 hours to the banker sheet
                                            }
                                        )
                                        Divider(color = SlateSeparator)
                                    }
                                }
                            }
                        }
                    }
                }

                "DRAWINGS" -> {
                    // Drawings register
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("CONTRACT DRAWING REGISTERS", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(12.dp))

                                if (drawings.isEmpty()) {
                                    Text("No drawings recorded for this project.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    drawings.forEach { dwg ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text("${dwg.drawingNumber} (Rev ${dwg.revision})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                Text(dwg.title, style = MaterialTheme.typography.bodyMedium, color = CharcoalIron)
                                                Text("Issued by ${dwg.author} • ${dwg.date}", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(2.dp))
                                                    .background(Color(0xFFE2F0D9))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text("CURRENT", style = MaterialTheme.typography.labelSmall, color = BritishGreen, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Divider(color = SlateSeparator)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ComponentPassportRow(
    comp: WorkshopComponentEntity,
    onAdvance: (String) -> Unit
) {
    val nextStagingMap = mapOf(
        "TEMPLATE" to "ROUGH OUT",
        "ROUGH OUT" to "DRESS",
        "DRESS" to "DETAIL",
        "DETAIL" to "FINISHED",
        "FINISHED" to "DELIVERED"
    )

    Column(modifier = Modifier.padding(vertical = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "PASSPORT ${comp.componentNumber}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
                Text(comp.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Stone: ${comp.stoneType} • Size: ${comp.dimensions}", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                Text("Craftsman: ${comp.craftsmanName} • Hours worked: ${comp.hoursSpent}h", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFFECE6DA))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(comp.status, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        val nextStatus = nextStagingMap[comp.status]
        if (nextStatus != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onAdvance(nextStatus) },
                colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .align(Alignment.End)
                    .height(32.dp)
                    .testTag("btn_advance_comp_${comp.id}")
            ) {
                Text("Advance to $nextStatus (+4 hrs worked)", fontSize = 11.sp)
            }
        } else {
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = BritishGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("DELIVERED TO SITE", style = MaterialTheme.typography.labelSmall, color = BritishGreen, fontWeight = FontWeight.Bold)
            }
        }
    }
}
