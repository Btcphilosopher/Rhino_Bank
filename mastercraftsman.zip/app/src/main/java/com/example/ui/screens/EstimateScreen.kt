package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.JobEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun EstimateScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeJob by viewModel.activeJob.collectAsState()

    var activeTab by remember { mutableStateOf("ESTIMATE") } // ESTIMATE, LABOUR, QUOTE_PREVIEW

    // Costs State
    var costLabour by remember { mutableStateOf(11200.0) }
    var costMaterials by remember { mutableStateOf(9840.0) }
    var costPlant by remember { mutableStateOf(2200.0) }
    var costAccess by remember { mutableStateOf(3200.0) } // Scaffolding
    var costWaste by remember { mutableStateOf(650.0) }
    var costOverhead by remember { mutableStateOf(1200.0) }
    var markupPercent by remember { mutableStateOf(22f) } // Default 22%

    val netCost = costLabour + costMaterials + costPlant + costAccess + costWaste + costOverhead
    val markupValue = netCost * (markupPercent / 100.0)
    val quoteValue = netCost + markupValue
    val vatValue = quoteValue * 0.20 // 20% standard UK VAT
    val grossTotal = quoteValue + vatValue

    // Labour Crew hours input
    var hrsMaster by remember { mutableStateOf(120) }
    var hrsMason by remember { mutableStateOf(240) }
    var hrsApprentice by remember { mutableStateOf(160) }

    // Rates (Standard synthetic)
    val rateMaster = 38.0
    val rateMason = 30.0
    val rateApprentice = 16.0

    // Auto calculate labour cost when hours change
    LaunchedEffect(hrsMaster, hrsMason, hrsApprentice) {
        costLabour = (hrsMaster * rateMaster) + (hrsMason * rateMason) + (hrsApprentice * rateApprentice)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ESTIMATING ENGINE",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = activeJob?.name ?: "No Project Selected",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Project Costing • Crew Allocation • Polish Quote Builder",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TabButton(text = "Cost Breakdown", isSelected = activeTab == "ESTIMATE", onClick = { activeTab = "ESTIMATE" })
            TabButton(text = "Crew & Productivity", isSelected = activeTab == "LABOUR", onClick = { activeTab = "LABOUR" })
            TabButton(text = "Generate Quote", isSelected = activeTab == "QUOTE_PREVIEW", onClick = { activeTab = "QUOTE_PREVIEW" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "ESTIMATE" -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("DIRECT PROJECT COSTS", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(12.dp))

                                CostInputField(label = "Labour Crews (Linked to Crew tab)", value = costLabour, enabled = false, onValueChange = {})
                                CostInputField(label = "Materials Supply (Stone, bricks, hydraulic binders)", value = costMaterials, onValueChange = { costMaterials = it })
                                CostInputField(label = "Plant Hire (Mixer, saw, diamond blades, cutters)", value = costPlant, onValueChange = { costPlant = it })
                                CostInputField(label = "Access / Temporary Works (Scaffolding, safety rail)", value = costAccess, onValueChange = { costAccess = it })
                                CostInputField(label = "Waste Disposal & Skip Hire", value = costWaste, onValueChange = { costWaste = it })
                                CostInputField(label = "Overhead & Fuel Transport", value = costOverhead, onValueChange = { costOverhead = it })
                            }
                        }
                    }

                    // Profitability Markup Editor
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("PROFIT MARKUP", style = MaterialTheme.typography.labelLarge)
                                    Text("${markupPercent.toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Slider(
                                    value = markupPercent,
                                    onValueChange = { markupPercent = it },
                                    valueRange = 5f..40f,
                                    colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary, activeTrackColor = MaterialTheme.colorScheme.primary, inactiveTrackColor = SlateSeparator)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Net Direct Cost", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                    Text("£${String.format("%,.2f", netCost)}", style = MaterialTheme.typography.bodyLarge)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Markup Profit Value", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                    Text("£${String.format("%,.2f", markupValue)}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                                }
                                Divider(color = SlateSeparator, modifier = Modifier.padding(vertical = 8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Net Contract Quote", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("£${String.format("%,.2f", quoteValue)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                                }
                            }
                        }
                    }
                }

                "LABOUR" -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("CREW ALLOCATION", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(12.dp))

                                CrewHoursInput(label = "Edward Harcourt (Master Mason - £38/hr)", hours = hrsMaster, onHoursChange = { hrsMaster = it })
                                CrewHoursInput(label = "James Miller (Mason - £30/hr)", hours = hrsMason, onHoursChange = { hrsMason = it })
                                CrewHoursInput(label = "Arthur Pendelton (Apprentice - £16/hr)", hours = hrsApprentice, onHoursChange = { hrsApprentice = it })

                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = SlateSeparator)
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Calculated Crew Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("£${String.format("%,.2f", costLabour)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }

                    // Productivity Assumptions Reference Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("HARCOURT PRODUCTIVITY SPEEDS", style = MaterialTheme.typography.labelLarge)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("• Natural Stone Walling: 5.2 m² per day per mason", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                Text("• Facade Joint Repointing: 18.0 m² per day per crew", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                Text("• Traditional Brickwork (Double Skin): 12.0 m² per day per bricklayer", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Values are customized for traditional natural hydraulic lime mortars and manual banker dressing.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SteelGrey
                                )
                            }
                        }
                    }
                }

                "QUOTE_PREVIEW" -> {
                    // PROFESSIONAL PRINT READY LETTERHEAD QUOTATION
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("quote_letterhead_card"),
                            colors = CardDefaults.cardColors(containerColor = LimestoneBg), // Aged paper look
                            shape = RoundedCornerShape(2.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                // Letterhead Title
                                Text(
                                    text = "HARCOURT MASONRY & RESTORATION",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 1.sp
                                )
                                Text("Traditional Stonemasonry & Conservation Specialists", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                Text("Yorkshire, United Kingdom • Est. 2011", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                                Spacer(modifier = Modifier.height(14.dp))
                                Divider(color = SteelGrey, thickness = 1.dp)
                                Spacer(modifier = Modifier.height(14.dp))

                                // Invoice Metadata
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("QUOTATION FOR:", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                                        Text(activeJob?.clientName ?: "No Client", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(activeJob?.siteAddress ?: "No Site Address", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("QUOTE REF:", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                                        Text("Q-2026-${activeJob?.jobNumber?.takeLast(4) ?: "0184"}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrickRed)
                                        Text("DATE: 25 September 2026", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Scope Details Table
                                Text("PROPOSED SCOPE OF WORKS:", style = MaterialTheme.typography.labelSmall, color = SteelGrey)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Carefully rake out defective mortar joints to the agreed depth and repoint selected areas using the specified NHL natural hydraulic lime repair mortar matching historical binder density.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CharcoalIron
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // Line Items Costing
                                TableRowItem(label = "Net Subtotal Cost", value = "£${String.format("%,.2f", netCost)}")
                                TableRowItem(label = "Craft Markup (${markupPercent.toInt()}%)", value = "£${String.format("%,.2f", markupValue)}")
                                TableRowItem(label = "Total Contract Net Value", value = "£${String.format("%,.2f", quoteValue)}", bold = true)
                                TableRowItem(label = "Standard UK VAT (20.0%)", value = "£${String.format("%,.2f", vatValue)}")
                                Divider(color = SteelGrey, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("GROSS VALUATION TOTAL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("£${String.format("%,.2f", grossTotal)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                // Terms & Disclaimers
                                Text("CONTRACT TERMS:", style = MaterialTheme.typography.labelSmall, color = SteelGrey, fontWeight = FontWeight.Bold)
                                Text("1. Quote valid for 60 days. All weights and deliveries approximate.\n2. Invoices staged 30% mobilization, 40% mid-project, 30% snagging approval.\n3. All heritage interventions approved by Conservation Officer.", style = MaterialTheme.typography.bodySmall, color = SteelGrey, fontSize = 10.sp, lineHeight = 13.sp)
                            }
                        }
                    }

                    // Actions
                    item {
                        Button(
                            onClick = {
                                activeJob?.let { job ->
                                    viewModel.createJob(
                                        name = job.name,
                                        client = job.clientName,
                                        site = job.siteAddress,
                                        type = job.projectType,
                                        value = quoteValue,
                                        start = job.startDate,
                                        end = job.targetCompletion,
                                        notes = job.notes,
                                        contact = job.clientContact,
                                        architect = job.architectName,
                                        siteContact = job.siteContact
                                    )
                                    viewModel.navigateTo("jobs")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_save_quote")
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save and Apply Quote Value to Contract", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CostInputField(
    label: String,
    value: Double,
    enabled: Boolean = true,
    onValueChange: (Double) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = String.format("%.0f", value),
            onValueChange = { onValueChange(it.toDoubleOrNull() ?: 0.0) },
            prefix = { Text("£ ") },
            enabled = enabled,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color(0xFFF2EFE8)
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun CrewHoursInput(
    label: String,
    hours: Int,
    onHoursChange: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = { if (hours > 0) onHoursChange(hours - 8) },
                colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFECE6DA))
            ) {
                Text("-8", fontWeight = FontWeight.Bold)
            }
            Text("$hours hrs", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 12.dp))
            IconButton(
                onClick = { onHoursChange(hours + 8) },
                colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFECE6DA))
            ) {
                Text("+8", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TableRowItem(
    label: String,
    value: String,
    bold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}
