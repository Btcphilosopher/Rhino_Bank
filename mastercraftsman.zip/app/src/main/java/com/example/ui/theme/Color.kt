package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British Craftsman's Material Palette
val LimestoneBg = Color(0xFFF8F6F1)       // Creamy, warm limestone-paper site notebook
val SandstoneCard = Color(0xFFEDE8DF)     // Solid, robust golden-sandstone card background
val SlateSeparator = Color(0xFFD6D3C9)    // Muted grey slate separator line
val CharcoalIron = Color(0xFF1E2422)      // Deep weathered wrought-iron typography / dark contrast
val SteelGrey = Color(0xFF535D5A)         // Technical engineering steel secondary text
val BrickRed = Color(0xFFAB3526)          // Traditional red clay-brick accent/highlights
val BritishGreen = Color(0xFF0F432B)      // Sovereign heritage deep green (primary buttons/actions)
val InkBlue = Color(0xFF14374D)           // Traditional drawing-set blueprint blue
val AgedGold = Color(0xFFBFA667)          // Premium gold brass details
val OffWhite = Color(0xFFFFFFFF)
