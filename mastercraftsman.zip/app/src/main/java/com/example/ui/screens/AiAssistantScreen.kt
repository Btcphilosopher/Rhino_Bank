package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun AiAssistantScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.aiMessages.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    val activeJob by viewModel.activeJob.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val quickPrompts = listOf(
        "NHL 3.5 Sandstone Mix Ratios",
        "COSHH Silica Dust safety controls",
        "Draft Whitby Manor repoint quote scope",
        "Summarize my active contract details"
    )

    // Scroll to bottom when messages list size changes
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "MASTERCRAFT AI WORKSPACE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
                Text(
                    text = "Craft Assistant",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Active: ${activeJob?.name ?: "No Job Selected"} • Restrained Guidelines",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SteelGrey
                )
            }
            IconButton(
                onClick = { viewModel.clearAiConversation() },
                modifier = Modifier.testTag("btn_clear_conversation")
            ) {
                Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear Conversation", tint = BrickRed)
            }
        }

        // Main Chat Bubbles Column
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Context Warning Label
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SlateSeparator, RoundedCornerShape(2.dp))
                        .background(Color(0xFFEDE8DF))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "AI ASSISTANT WARNING: AI suggestions are guides only. They do not constitute certified structural engineering, building regulation approvals, or safety RAMS. Verify all materials physically.",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 10.sp,
                        lineHeight = 13.sp,
                        color = SteelGrey,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            items(messages) { msgPair ->
                val (text, isUser) = msgPair
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isUser) BritishGreen else Color(0xFFEDE8DF))
                            .border(1.dp, SlateSeparator, RoundedCornerShape(4.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isUser) Icons.Default.SmartToy else Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = if (isUser) Color.White else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isUser) "Edward Harcourt" else "Mastercraft AI",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isUser) Color.White else MaterialTheme.colorScheme.tertiary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (isUser) Color.White else CharcoalIron,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            if (isLoading) {
                item {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE8DF)),
                            modifier = Modifier.width(120.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
                                Text("Analyzing...", style = MaterialTheme.typography.labelSmall, color = CharcoalIron)
                            }
                        }
                    }
                }
            }
        }

        // Pre-defined technical suggestions row
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            Text(
                text = "TECHNICAL BENCH PROMPTS",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickPrompts.forEach { prompt ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .border(1.dp, SlateSeparator, RoundedCornerShape(2.dp))
                            .background(Color(0xFFEDE8DF))
                            .clickable { viewModel.sendAiMessage(prompt) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(prompt, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Bottom Input box row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Consult with Mastercraft AI on heritage masonry specs...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_input_field"),
                shape = RoundedCornerShape(4.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = SlateSeparator
                )
            )
            Button(
                onClick = {
                    if (textInput.isNotBlank()) {
                        viewModel.sendAiMessage(textInput)
                        textInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("btn_send_ai_prompt")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send")
            }
        }
    }
}
