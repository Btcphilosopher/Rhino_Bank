package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.SiteDiaryEntity
import com.example.data.database.TimesheetEntity
import com.example.data.database.ToolEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun SiteDiaryScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeJob by viewModel.activeJob.collectAsState()
    val diaries by viewModel.jobDiaries.collectAsState()
    val timesheets by viewModel.jobTimesheets.collectAsState()
    val tools by viewModel.allTools.collectAsState()

    var activeTab by remember { mutableStateOf("DIARY") } // DIARY, TIMESHEET, SAFETY, TOOL_CHECK

    // Diary State Form
    var showAddDiary by remember { mutableStateOf(false) }
    var weatherDiary by remember { mutableStateOf("Dry and Clear") }
    var crewCount by remember { mutableStateOf("4") }
    var hrsWorked by remember { mutableStateOf("32") }
    var completedWork by remember { mutableStateOf("") }
    var deliveredMat by remember { mutableStateOf("") }
    var siteIssues by remember { mutableStateOf("None") }

    // Timesheet Form State
    var showTimesheetForm by remember { mutableStateOf(false) }
    var workerName by remember { mutableStateOf("Edward Harcourt") }
    var workerRole by remember { mutableStateOf("Master Stonemason") }
    var tsHours by remember { mutableStateOf(8.0) }
    var tsTask by remember { mutableStateOf("") }

    // Safety Checklist State
    var checkGuard by remember { mutableStateOf(false) }
    var checkBlade by remember { mutableStateOf(false) }
    var checkWater by remember { mutableStateOf(false) }
    var checkPpe by remember { mutableStateOf(false) }
    var toolCheckPassedMsg by remember { mutableStateOf("") }
    var selectedToolName by remember { mutableStateOf("Stihl TS410 350mm Cut-off Saw") }

    val hazards = listOf(
        Pair("Silica Dust (RCS)", "Crystalline silica inhalation during dry-stone / brick cutting • CONTROL: Always use wet-suppression Stihl saw, double-cartridge dust masks, external ventilation."),
        Pair("Falls from Height", "Working on multi-lift scaffolds • CONTROL: Check toe-boards, double guard rails weekly. Wearing full safety harness."),
        Pair("Manual Handling Injuries", "Lifting heavy sandstone blocks (30kg+) • CONTROL: Use mechanical scissor lifts, shared lifting, correct posture.")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SITE JOURNAL",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = activeJob?.name ?: "No Job Selected",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Daily Records • Operational Timesheets • UK Safety Compliance",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TabButton(text = "Site Diary", isSelected = activeTab == "DIARY", onClick = { activeTab = "DIARY" })
            TabButton(text = "Timesheets", isSelected = activeTab == "TIMESHEET", onClick = { activeTab = "TIMESHEET" })
            TabButton(text = "Pre-use Checks", isSelected = activeTab == "TOOL_CHECK", onClick = { activeTab = "TOOL_CHECK" })
            TabButton(text = "Risk Register", isSelected = activeTab == "SAFETY", onClick = { activeTab = "SAFETY" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "DIARY" -> {
                    // Daily Site Diary list & creation
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("DAILY SITE DIARIES", style = MaterialTheme.typography.labelLarge)
                                    Button(
                                        onClick = { showAddDiary = !showAddDiary },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(2.dp),
                                        modifier = Modifier.testTag("btn_trigger_diary_form")
                                    ) {
                                        Icon(imageVector = if (showAddDiary) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (showAddDiary) "Close" else "Record Today", style = MaterialTheme.typography.labelMedium)
                                    }
                                }

                                if (showAddDiary) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = weatherDiary, onValueChange = { weatherDiary = it }, label = { Text("Weather") }, modifier = Modifier.fillMaxWidth())
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(value = crewCount, onValueChange = { crewCount = it }, label = { Text("Crew size") }, modifier = Modifier.weight(1f))
                                            OutlinedTextField(value = hrsWorked, onValueChange = { hrsWorked = it }, label = { Text("Total Hours") }, modifier = Modifier.weight(1f))
                                        }
                                        OutlinedTextField(value = completedWork, onValueChange = { completedWork = it }, label = { Text("Scope of Works Completed Today") }, modifier = Modifier.fillMaxWidth().testTag("diary_completed_input"))
                                        OutlinedTextField(value = deliveredMat, onValueChange = { deliveredMat = it }, label = { Text("Materials Delivered to Site") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = siteIssues, onValueChange = { siteIssues = it }, label = { Text("Site Delays / Access Issues") }, modifier = Modifier.fillMaxWidth())
                                        
                                        Button(
                                            onClick = {
                                                if (completedWork.isNotBlank()) {
                                                    viewModel.addSiteDiary(
                                                        weather = weatherDiary,
                                                        crew = crewCount.toIntOrNull() ?: 1,
                                                        hours = hrsWorked.toIntOrNull() ?: 8,
                                                        completed = completedWork,
                                                        delivered = deliveredMat,
                                                        issues = siteIssues,
                                                        notes = ""
                                                    )
                                                    completedWork = ""
                                                    deliveredMat = ""
                                                    showAddDiary = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("btn_save_diary")
                                        ) {
                                            Text("Save Daily Site Diary")
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                if (diaries.isEmpty()) {
                                    Text("No daily site records saved.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    diaries.forEach { diary ->
                                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text(text = diary.date, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(2.dp))
                                                        .background(Color(0xFFEDE8DF))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Crew: ${diary.crewCount} • Hours: ${diary.hoursWorked}h", style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(text = "Completed: ${diary.workCompleted}", style = MaterialTheme.typography.bodyLarge, color = CharcoalIron)
                                            if (diary.materialsDelivered.isNotEmpty()) {
                                                Text(text = "Deliveries: ${diary.materialsDelivered}", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                            }
                                            if (diary.issues != "None") {
                                                Text(text = "Delays: ${diary.issues}", style = MaterialTheme.typography.bodyMedium, color = BrickRed, fontWeight = FontWeight.Bold)
                                            }
                                            Divider(color = SlateSeparator, modifier = Modifier.padding(top = 8.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "TIMESHEET" -> {
                    // Crew Timesheets
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("CREW LABOUR TIMESHEETS", style = MaterialTheme.typography.labelLarge)
                                    IconButton(onClick = { showTimesheetForm = !showTimesheetForm }) {
                                        Icon(imageVector = if (showTimesheetForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                                    }
                                }

                                if (showTimesheetForm) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = workerName, onValueChange = { workerName = it }, label = { Text("Craftsman Name") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = workerRole, onValueChange = { workerRole = it }, label = { Text("Role") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = tsTask, onValueChange = { tsTask = it }, label = { Text("Task Executed Today") }, modifier = Modifier.fillMaxWidth())
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Hours Worked:")
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(onClick = { if (tsHours > 1) tsHours -= 1 }) {
                                                    Icon(imageVector = Icons.Default.Remove, contentDescription = null)
                                                }
                                                Text("${tsHours.toInt()} hours", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                IconButton(onClick = { tsHours += 1 }) {
                                                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                                }
                                            }
                                        }
                                        Button(
                                            onClick = {
                                                if (tsTask.isNotBlank()) {
                                                    viewModel.addTimesheet(workerName, workerRole, tsHours, tsTask)
                                                    tsTask = ""
                                                    showTimesheetForm = false
                                                }
                                            },
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Submit Daily Hours")
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                if (timesheets.isEmpty()) {
                                    Text("No hours recorded today.", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                } else {
                                    timesheets.forEach { ts ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(text = ts.workerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                Text(text = "${ts.role} • ${ts.taskCompleted}", style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(2.dp))
                                                    .background(Color(0xFFE2F0D9))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text("${ts.hours.toInt()} hrs", style = MaterialTheme.typography.labelSmall, color = BritishGreen, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Divider(color = SlateSeparator)
                                    }
                                }
                            }
                        }
                    }
                }

                "TOOL_CHECK" -> {
                    // PUWER Safety pre-use tool checklist
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("PUWER MASONRY TOOL CHECKLIST", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(10.dp))

                                Text("Select Tool to Inspect:", style = MaterialTheme.typography.titleMedium)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    tools.take(3).forEach { tool ->
                                        val sel = selectedToolName == tool.name
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .border(1.dp, if (sel) MaterialTheme.colorScheme.primary else SlateSeparator, RoundedCornerShape(2.dp))
                                                .background(if (sel) Color(0xFFECE6DA) else Color.Transparent)
                                                .clickable {
                                                    selectedToolName = tool.name
                                                    toolCheckPassedMsg = ""
                                                }
                                                .padding(8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(tool.name.substringBefore(" "), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Checks
                                ToolCheckRow(label = "Blade Guard firmly aligned and crack-free", checked = checkGuard, onCheckedChange = { checkGuard = it })
                                ToolCheckRow(label = "Diamond / Cutting Blade checked for edge fractures", checked = checkBlade, onCheckedChange = { checkBlade = it })
                                ToolCheckRow(label = "Water Feed line suppression pump checked (Dust suppression)", checked = checkWater, onCheckedChange = { checkWater = it })
                                ToolCheckRow(label = "Operator wearing double-eye protection, steel toes, respirator", checked = checkPpe, onCheckedChange = { checkPpe = it })

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        if (checkGuard && checkBlade && checkWater && checkPpe) {
                                            toolCheckPassedMsg = "SAFETY CHECK SIGNED OFF: Pre-use inspection completed successfully. Signed by Edward Harcourt."
                                            val matchedTool = tools.firstOrNull { it.name == selectedToolName }
                                            if (matchedTool != null) {
                                                viewModel.checkTool(matchedTool, "Excellent")
                                            }
                                        } else {
                                            toolCheckPassedMsg = "SAFETY CANNOT BE SIGNED OFF: Please ensure all safety checks are inspected and passed."
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (checkGuard && checkBlade && checkWater && checkPpe) BritishGreen else BrickRed),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("btn_sign_tool_check")
                                ) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sign Off Pre-Use Safety Checks")
                                }

                                if (toolCheckPassedMsg.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, if (toolCheckPassedMsg.startsWith("SAFETY CHECK")) BritishGreen else BrickRed, RoundedCornerShape(2.dp))
                                            .background(if (toolCheckPassedMsg.startsWith("SAFETY CHECK")) Color(0xFFE2F0D9) else Color(0xFFF2DEDE))
                                            .padding(12.dp)
                                    ) {
                                        Text(toolCheckPassedMsg, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                "SAFETY" -> {
                    // Risk Register
                    items(hazards) { hazard ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Outlined.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(hazard.first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(hazard.second, style = MaterialTheme.typography.bodyMedium, color = CharcoalIron)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolCheckRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = CharcoalIron)
    }
}
