package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun ProfileScreen(
    viewModel: MastercraftViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf("PROFILE") } // PROFILE, EDUCATION

    val credentials = listOf(
        Pair("NVQ Level 3 Heritage Stonemasonry", "Issued by City & Guilds • Certified specialist conservation status"),
        Pair("CSCS Gold Skilled Worker Card", "Card Ref: CSCS-984214 • Exp: Nov 2028 • Traditional Masonry"),
        Pair("First Aid at Work (Level 3)", "Issued by St John Ambulance • Exp: June 2027"),
        Pair("COSHH Crystalline Silica Safety Certificate", "Issued by CITB • Approved wet-suppression operator")
    )

    val learningTopics = listOf(
        Pair("Stone Mineral Identification", "Learn to identify Portland limestone by fossil fragments, York Sandstone by layered grit, and Cotswold by golden oolitic grains."),
        Pair("Joint Splay Geometries", "How to calculate the precise angle of splay quoins and window tracery mullions on the banker bench."),
        Pair("Hydraulic Binders NHL 2.0 vs 3.5", "NHL 2.0 is softer, used for timber-frames. NHL 3.5 is general structural, suited for external Yorkshire sandstone facades."),
        Pair("JCT Conservation Contracts", "Understanding Joint Contracts Tribunal variations, staging, and final snagging sign-offs.")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Technical Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "CRAFTSMAN PROFILE",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = "Edward Harcourt",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Master Stonemason • Harcourt Masonry & Restoration",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
        }

        // Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEDE8DF))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TabButton(text = "Credentials & Bio", isSelected = activeTab == "PROFILE", onClick = { activeTab = "PROFILE" })
            TabButton(text = "Apprentice Hub", isSelected = activeTab == "EDUCATION", onClick = { activeTab = "EDUCATION" })
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                "PROFILE" -> {
                    // Bio & Qualifications list
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("WORKBENCH PROFILE SUMMARY", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Edward Harcourt has over 15 years of experience in heritage masonry, architectural sandstone carving, traditional red-clay brickwork repair, and natural lime repointing. Operating primarily in Yorkshire and the North East under strict historical conservation guidelines.",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = CharcoalIron
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("VERIFIED HERITAGE CREDENTIALS", style = MaterialTheme.typography.labelLarge)
                                Spacer(modifier = Modifier.height(10.dp))

                                credentials.forEach { cred ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = BritishGreen, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(cred.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            }
                                            Text(cred.second, style = MaterialTheme.typography.bodyMedium, color = SteelGrey)
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(Color(0xFFE2F0D9))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("ACTIVE", style = MaterialTheme.typography.labelSmall, color = BritishGreen, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Divider(color = SlateSeparator)
                                }
                            }
                        }
                    }
                }

                "EDUCATION" -> {
                    // Apprentice Learning Hub topics
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Book, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("APPRENTICESHIP SYLLABUS", style = MaterialTheme.typography.labelLarge)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Traditional Building Skills occupational frameworks under CITB guidelines.", style = MaterialTheme.typography.bodySmall, color = SteelGrey)
                            }
                        }
                    }

                    items(learningTopics) { topic ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, SlateSeparator)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(topic.first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(topic.second, style = MaterialTheme.typography.bodyMedium, color = CharcoalIron)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Done, contentDescription = null, tint = BritishGreen, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("CITB Recommended Reading", style = MaterialTheme.typography.labelSmall, color = BritishGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
