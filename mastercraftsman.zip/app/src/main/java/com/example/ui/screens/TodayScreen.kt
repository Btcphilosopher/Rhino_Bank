package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.JobEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MastercraftViewModel

@Composable
fun TodayScreen(
    viewModel: MastercraftViewModel,
    modifier: Modifier = Modifier
) {
    val jobs by viewModel.allJobs.collectAsState()
    val activeJob by viewModel.activeJob.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Technical Header Bar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text(
                    text = "MASTERCRAFTSMAN",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Good morning, Edward",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Harcourt Restoration • Yorkshire Base",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SteelGrey
                )
            }
        }

        // Today's Site Diary Agenda
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("today_schedule_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, SlateSeparator)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TODAY'S AGENDA",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    // Agenda Item 1
                    AgendaRow(
                        time = "07:30",
                        project = "WHITBY MANOR",
                        description = "South elevation sandstone repair & lime batching",
                        isHighlight = true
                    )
                    Divider(color = SlateSeparator, modifier = Modifier.padding(vertical = 10.dp))

                    // Agenda Item 2
                    AgendaRow(
                        time = "09:30",
                        project = "YORK TERRACE",
                        description = "Brick stitch tie crack-re-inspection with conservation officer",
                        isHighlight = false
                    )
                    Divider(color = SlateSeparator, modifier = Modifier.padding(vertical = 10.dp))

                    // Agenda Item 3
                    AgendaRow(
                        time = "14:00",
                        project = "SUPPLIER YARD",
                        description = "Collect York Stone coping & NHL lime binders",
                        isHighlight = false
                    )
                }
            }
        }

        // Quick Workbench Shortcuts
        item {
            Text(
                text = "WORKBENCH ACTIONS",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActionButton(
                    text = "New Survey",
                    icon = Icons.Outlined.ContentPasteSearch,
                    tag = "action_btn_survey",
                    onClick = { viewModel.navigateTo("survey") },
                    modifier = Modifier.weight(1f)
                )
                ActionButton(
                    text = "Estimator",
                    icon = Icons.Outlined.Calculate,
                    tag = "action_btn_estimate",
                    onClick = { viewModel.navigateTo("estimate") },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActionButton(
                    text = "Site Diary",
                    icon = Icons.Outlined.MenuBook,
                    tag = "action_btn_diary",
                    onClick = { viewModel.navigateTo("site") },
                    modifier = Modifier.weight(1f)
                )
                ActionButton(
                    text = "Craft AI",
                    icon = Icons.Outlined.SmartToy,
                    tag = "action_btn_ai",
                    onClick = { viewModel.navigateTo("ai_assistant") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Active Jobs Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE CONTRACTS",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "View All",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clickable { viewModel.navigateTo("jobs") }
                        .padding(4.dp)
                )
            }
        }

        val activeContracts = jobs.filter { it.status == "ON SITE" || it.status == "AWARDED" }
        if (activeContracts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No active contracts. Create a job to get started.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SteelGrey
                    )
                }
            }
        } else {
            items(activeContracts.size) { index ->
                val job = activeContracts[index]
                ActiveContractCard(
                    job = job,
                    isSelected = activeJob?.id == job.id,
                    onClick = {
                        viewModel.selectJob(job.id)
                        viewModel.navigateTo("job_detail")
                    }
                )
            }
        }
        
        // Safety Legal Bottom Disclaimer
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateSeparator, RoundedCornerShape(2.dp))
                    .background(Color(0xFFF0EDE6))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "HEALTH & SAFETY / STRUCTURAL DISCLAIMER",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "All calculators, quantities, structural measurements, and material estimations are approximate site guides. Verify against certified engineering drawings and architect specifications prior to purchasing or executing structural works.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            color = SteelGrey
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AgendaRow(
    time: String,
    project: String,
    description: String,
    isHighlight: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = time,
            style = MaterialTheme.typography.labelLarge,
            color = if (isHighlight) MaterialTheme.colorScheme.tertiary else SteelGrey,
            modifier = Modifier.width(54.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = project,
                style = MaterialTheme.typography.titleMedium,
                color = if (isHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ),
        border = BorderStroke(1.dp, SlateSeparator),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(12.dp),
        modifier = modifier
            .testTag(tag)
            .height(54.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
fun ActiveContractCard(
    job: JobEntity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("contract_card_${job.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFECE6DA) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else SlateSeparator)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CONTRACT ${job.jobNumber}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Text(
                        text = job.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (job.status == "ON SITE") BritishGreen else SteelGrey)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = job.status,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Client: ${job.clientName}",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
            Text(
                text = "Type: ${job.projectType}",
                style = MaterialTheme.typography.bodyMedium,
                color = SteelGrey
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Understated progress line
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Progress: ${job.progressPercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Contract: £${String.format("%,.2f", job.contractValue)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = job.progressPercent / 100f,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = SlateSeparator
            )
        }
    }
}
