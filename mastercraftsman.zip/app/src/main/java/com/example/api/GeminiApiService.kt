package com.example.api

import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.example.BuildConfig

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<ContentPart>,
    val systemInstruction: ContentPart? = null,
    val generationConfig: GenConfig? = null
)

@JsonClass(generateAdapter = true)
data class ContentPart(
    val parts: List<TextPart>
)

@JsonClass(generateAdapter = true)
data class TextPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GenConfig(
    val temperature: Double? = 0.5,
    val maxOutputTokens: Int? = 1024,
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: ContentPart? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val apiService: GeminiApiService = retrofit.create(GeminiApiService::class.java)

    suspend fun askGemini(prompt: String, systemPrompt: String? = null): String {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isEmpty() || key == "MY_GEMINI_API_KEY") {
            return "Demo Key Mode: Under UK Heritage restoration standards, this stone replacement must utilize matching Yorkshire Sandstone from Crosland Hill Quarry, layered along its original geological bedding plane. NHL 3.5 lime mortar with coarse sand mix at 1:3 ratio is recommended for joint repointing. (Please configure a real GEMINI_API_KEY in the Secrets panel to activate live AI answers.)"
        }

        val request = GeminiRequest(
            contents = listOf(
                ContentPart(parts = listOf(TextPart(text = prompt)))
            ),
            systemInstruction = systemPrompt?.let {
                ContentPart(parts = listOf(TextPart(text = it)))
            }
        )

        return try {
            val response = apiService.generateContent(key, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "No valid response from AI."
        } catch (e: Exception) {
            "AI Offline or Connection Error: ${e.localizedMessage}. Please verify internet access and your API key."
        }
    }
}
