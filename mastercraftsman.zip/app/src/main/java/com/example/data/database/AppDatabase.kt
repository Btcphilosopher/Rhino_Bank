package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        JobEntity::class,
        SurveyEntity::class,
        MeasurementEntity::class,
        MaterialProductEntity::class,
        SiteDiaryEntity::class,
        DefectEntity::class,
        TimesheetEntity::class,
        ToolEntity::class,
        InvoiceEntity::class,
        VariationEntity::class,
        WorkshopComponentEntity::class,
        DrawingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mastercraftDao(): MastercraftDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mastercraftsman_db"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        seedDatabase(database.mastercraftDao())
                    }
                }
            }
        }

        suspend fun seedDatabase(dao: MastercraftDao) {
            // 1. Seed Materials (Stones, Bricks, Mortars)
            val materialsList = listOf(
                // Stones
                MaterialProductEntity(
                    category = "Natural Stone",
                    name = "Yorkshire Sandstone",
                    description = "Traditional British fine-grained warm sandstone, durable and highly suited for heritage walling and sills.",
                    origin = "Crosland Hill, Yorkshire",
                    colour = "Warm Buff / Gold",
                    texture = "Fine-grained",
                    density = "2350 kg/m³",
                    typicalApplication = "Ashlar masonry, lintels, coping, sills",
                    format = "Sawn blocks, split walling, dimensional masonry",
                    pricePerUnit = 185.0,
                    unitType = "tonne",
                    supplierName = "Yorkshire Stone Ltd"
                ),
                MaterialProductEntity(
                    category = "Natural Stone",
                    name = "Bath Limestone",
                    description = "Oolitic limestone, honey-coloured stone widely used in Bath and southern England heritage preservation.",
                    origin = "Hartham Park, Wiltshire",
                    colour = "Honey / Cream",
                    texture = "Oolitic, medium-grained",
                    density = "2100 kg/m³",
                    typicalApplication = "Carving, cornices, mullions, quoins",
                    format = "Dimensional blocks, banker masonry components",
                    pricePerUnit = 240.0,
                    unitType = "tonne",
                    supplierName = "Bath Stone Quarrying Ltd"
                ),
                MaterialProductEntity(
                    category = "Natural Stone",
                    name = "Portland Limestone",
                    description = "Fossiliferous Dorset oolitic limestone, the premium choice for prestigious institutional and classical architecture.",
                    origin = "Isle of Portland, Dorset",
                    colour = "Bright White / Light Grey",
                    texture = "Fine fossil grain",
                    density = "2250 kg/m³",
                    typicalApplication = "Classical columns, banker carving, ashlar cladding",
                    format = "Sawn 6-sides blocks, bespoke templates",
                    pricePerUnit = 310.0,
                    unitType = "tonne",
                    supplierName = "Albion Stone Plc"
                ),
                MaterialProductEntity(
                    category = "Natural Stone",
                    name = "Cotswold Stone",
                    description = "Coarse oolitic limestone characteristic of Cotswold dry stone walling and manor restoration.",
                    origin = "Guiting Power, Gloucestershire",
                    colour = "Rich Golden Yellow",
                    texture = "Coarse / Shell-rich",
                    density = "1950 kg/m³",
                    typicalApplication = "Dry-stone walling, random rubble masonry, dressing",
                    format = "Guillotine-cut walling, rubble bags",
                    pricePerUnit = 125.0,
                    unitType = "tonne",
                    supplierName = "Gloucestershire Stone Co"
                ),
                MaterialProductEntity(
                    category = "Natural Stone",
                    name = "Welsh Slate",
                    description = "Extremely fine-grained metamorphic roofing and paving slate of unrivaled structural purity and split performance.",
                    origin = "Penrhyn Quarry, Bethesda",
                    colour = "Heather Blue / Dark Purple",
                    texture = "Planar fissile slate",
                    density = "2750 kg/m³",
                    typicalApplication = "Heritage roofing, hearths, bespoke paving, copings",
                    format = "Split roofing slates, dimensional slabs",
                    pricePerUnit = 420.0,
                    unitType = "tonne",
                    supplierName = "Welsh Slate Ltd"
                ),
                // Bricks
                MaterialProductEntity(
                    category = "Brick",
                    name = "Handmade Red Multi Facing Brick",
                    description = "Traditional hand-moulded red brick with sand creasing and gentle variations in size and tint.",
                    origin = "Leicestershire Claypits",
                    colour = "Crimson / Flame Orange",
                    texture = "Sandy, weathered",
                    density = "1800 kg/m³",
                    typicalApplication = "Heritage extensions, chimneys, traditional garden walls",
                    format = "Imperial (68mm) or Metric (65mm)",
                    pricePerUnit = 0.85,
                    unitType = "unit",
                    supplierName = "British Clayworks Co"
                ),
                MaterialProductEntity(
                    category = "Brick",
                    name = "Reclaimed London Stock Brick",
                    description = "Genuine soot-stained reclaimed yellow clay bricks, perfect for conservation work in London and Home Counties.",
                    origin = "Deconstruction Sites",
                    colour = "Yellow / Buff / Black soot mix",
                    texture = "Heavy weathered",
                    density = "1700 kg/m³",
                    typicalApplication = "Conservation wall matching, internal feature walls",
                    format = "Serrated Imperial",
                    pricePerUnit = 1.15,
                    unitType = "unit",
                    supplierName = "Heritage Reclamation Ltd"
                ),
                MaterialProductEntity(
                    category = "Brick",
                    name = "Blue Staffordshire Engineering Brick (Class A)",
                    description = "Ultra-dense, low absorption clay brick with exceptionally high compressive strength and chemical resistance.",
                    origin = "Staffordshire",
                    colour = "Dull Blue / Gunmetal Grey",
                    texture = "Smooth / Metallic",
                    density = "2300 kg/m³",
                    typicalApplication = "DPC courses, foundations, retaining walls, bridges",
                    format = "Metric 65mm",
                    pricePerUnit = 0.95,
                    unitType = "unit",
                    supplierName = "Stafford Clay Co"
                ),
                // Mortars
                MaterialProductEntity(
                    category = "Mortar",
                    name = "NHL 3.5 Natural Hydraulic Lime",
                    description = "Premium grade natural hydraulic binder, suitable for general masonry walling and historic repointing.",
                    origin = "Chaux de Saint-Astier, France",
                    colour = "Off-White / Cream",
                    texture = "Fine powder",
                    pricePerUnit = 16.50,
                    unitType = "bag",
                    supplierName = "The Lime Centre"
                ),
                MaterialProductEntity(
                    category = "Mortar",
                    name = "NHL 2.0 Natural Hydraulic Lime",
                    description = "Softer binder ideal for historic timber-frame brickwork and delicate sandstone blocks.",
                    origin = "Chaux de Saint-Astier, France",
                    colour = "Light Pale",
                    texture = "Extremely fine",
                    pricePerUnit = 18.20,
                    unitType = "bag",
                    supplierName = "The Lime Centre"
                ),
                MaterialProductEntity(
                    category = "Mortar",
                    name = "Lime Putty (Fat Lime)",
                    description = "Pure slaked lime, matured for minimum 4 months, ideal for conservation plastering and historic brick repointing.",
                    origin = "Derbyshire Limestone",
                    colour = "Pure White",
                    texture = "Gelatinous paste",
                    pricePerUnit = 14.00,
                    unitType = "tub",
                    supplierName = "Traditional Lime Supplies"
                )
            )

            for (material in materialsList) {
                dao.insertMaterial(material)
            }

            // 2. Seed Jobs
            val jobsList = listOf(
                JobEntity(
                    jobNumber = "JOB-2026-0184",
                    name = "Whitby Manor Restore",
                    clientName = "North Yorkshire Heritage Trust",
                    siteAddress = "Whitby Cliff Road, Whitby, YO21",
                    contractValue = 38420.0,
                    costToDate = 17280.0,
                    status = "ON SITE",
                    startDate = "2026-09-12",
                    targetCompletion = "2026-10-18",
                    progressPercent = 42,
                    projectType = "HERITAGE RESTORATION",
                    notes = "Rake out and repoint south facade with NHL 3.5. Stabilize 6 lintels. Replace 4 badly spalled ashlar sandstone blocks with matching Yorkshire sandstone.",
                    clientContact = "Arthur Sterling, Lead Trustee",
                    architectName = "Simpson & Brown Architects",
                    siteContact = "James Miller, Site Manager"
                ),
                JobEntity(
                    jobNumber = "JOB-2026-0210",
                    name = "York Terrace Masonry",
                    clientName = "York Preservation Group",
                    siteAddress = "12 Bootham, York, YO30",
                    contractValue = 18250.0,
                    costToDate = 12400.0,
                    status = "ON SITE",
                    startDate = "2026-08-05",
                    targetCompletion = "2026-10-05",
                    progressPercent = 68,
                    projectType = "BRICK REPAIR",
                    notes = "Stitch cracks in historic multi-red walling. Replace spalled structural bricks. Point with NHL 2.0 mix matched with river sand.",
                    clientContact = "Eleanor Thorne",
                    architectName = "Brierley Groom Conservation",
                    siteContact = "Eleanor Thorne"
                ),
                JobEntity(
                    jobNumber = "JOB-2026-0095",
                    name = "Harrogate Garden Wall",
                    clientName = "Sir Jonathan Vance",
                    siteAddress = "Duchy Road, Harrogate, HG1",
                    contractValue = 14800.0,
                    costToDate = 2660.0,
                    status = "ON SITE",
                    startDate = "2026-09-01",
                    targetCompletion = "2026-11-20",
                    progressPercent = 18,
                    projectType = "DRY STONE WALL",
                    notes = "Rebuild 45 meters of dry stone boundary wall using local irregular millstone grit. Construct standard foundation, double skin with heavy hearting, throughstones, and upright copes.",
                    clientContact = "Sir Jonathan Vance",
                    architectName = "Nicholson Landscape Design",
                    siteContact = "Edward Harcourt"
                ),
                JobEntity(
                    jobNumber = "JOB-2026-0301",
                    name = "Fountains Abbey Conservation",
                    clientName = "Historic England",
                    siteAddress = "Fountains, Ripon, HG4",
                    contractValue = 85200.0,
                    costToDate = 0.0,
                    status = "AWARDED",
                    startDate = "2026-11-01",
                    targetCompletion = "2027-04-15",
                    progressPercent = 0,
                    projectType = "HERITAGE RESTORATION",
                    notes = "Emergency stabilization of vaulted arches on the east aisle. Micro-pinning and bespoke banker sills. Limestone matches.",
                    clientContact = "Dr. Michael Ross",
                    architectName = "Historic England Advisory",
                    siteContact = "Historic England Officer"
                ),
                JobEntity(
                    jobNumber = "JOB-2026-0112",
                    name = "Helmsley Chimney Repair",
                    clientName = "Lord Feversham Estate",
                    siteAddress = "Helmsley, North Yorkshire, YO62",
                    contractValue = 6800.0,
                    costToDate = 6800.0,
                    status = "COMPLETE",
                    startDate = "2026-07-10",
                    targetCompletion = "2026-08-01",
                    progressPercent = 100,
                    projectType = "CHIMNEY",
                    notes = "Bespoke stone corbelling and lead flashing. Repointed with hydraulic lime.",
                    clientContact = "Lord Feversham Estate",
                    architectName = "Estate Surveyor",
                    siteContact = "Estate Forester"
                )
            )

            val jobIds = mutableListOf<Long>()
            for (job in jobsList) {
                val id = dao.insertJob(job)
                jobIds.add(id)
            }

            // 3. Seed Drawings (For Whitby Manor - Job 1)
            val whitbyId = jobIds.getOrNull(0) ?: 1L
            dao.insertDrawing(
                DrawingEntity(
                    jobId = whitbyId,
                    drawingNumber = "A-201",
                    title = "Ground Floor Elevation Layout",
                    revision = "C",
                    author = "Simpson & Brown Architects",
                    status = "Current",
                    date = "2026-09-02"
                )
            )
            dao.insertDrawing(
                DrawingEntity(
                    jobId = whitbyId,
                    drawingNumber = "A-302",
                    title = "South Elevation Masonry Details & Defect Plan",
                    revision = "B",
                    author = "Simpson & Brown Architects",
                    status = "Current",
                    date = "2026-09-10"
                )
            )

            // 4. Seed Surveys (For Whitby Manor)
            dao.insertSurvey(
                SurveyEntity(
                    jobId = whitbyId,
                    weather = "Dry / Wind gusts",
                    surveyDate = "2026-09-12",
                    notes = "Surveyed south wall via scaffold tower. Identified 12 square meters of heavily eroded mortar joints on the lower tier and 3 badly cracked quoins."
                )
            )

            // 5. Seed Measurements (For Whitby Manor)
            dao.insertMeasurement(
                MeasurementEntity(
                    jobId = whitbyId,
                    label = "South Elevation Panel A",
                    length = 18.4,
                    height = 1.2,
                    thickness = 0.215,
                    quantity = 22.08,
                    type = "wall_calc",
                    calculatedMaterialCost = 1850.0,
                    calculatedLabourCost = 1420.0,
                    notes = "Main frontage with standard 215mm wall thickness. Calculated with 10% waste."
                )
            )

            // 6. Seed Site Diaries (For Whitby Manor)
            dao.insertSiteDiary(
                SiteDiaryEntity(
                    jobId = whitbyId,
                    date = "2026-09-24",
                    weather = "Dry and Clear",
                    crewCount = 4,
                    hoursWorked = 32,
                    workCompleted = "Dressed four replacement sills in the workshop. On site: finished joint preparation of South wall lower bay, ready for NHL hydraulic lime pointing tomorrow.",
                    materialsDelivered = "3 tonnes of fine river sand delivered by Yorkshire Stone Ltd.",
                    issues = "Scaffold team delayed in modifying top lift safety handrail.",
                    notes = "Progressing well. Mortar batch tests matched perfectly with historical binder colour."
                )
            )

            // 7. Seed Defects (For Whitby Manor)
            dao.insertDefect(
                DefectEntity(
                    jobId = whitbyId,
                    defectNumber = "D-001",
                    title = "Cracked Splay Quoin Block",
                    location = "South facade, left corner, second tier",
                    priority = "High",
                    status = "PLANNED",
                    photoUri = "defect_quoin",
                    actionRequired = "Requires careful stitch-pinning with helical stainless steel bar and conservation grout."
                )
            )
            dao.insertDefect(
                DefectEntity(
                    jobId = whitbyId,
                    defectNumber = "D-002",
                    title = "Excessive Cement Pointing",
                    location = "South wall, window head arch",
                    priority = "Medium",
                    status = "OPEN",
                    photoUri = "defect_cement",
                    actionRequired = "Rake out hard cement pointing carefully using manual chisels to prevent sandstone edge fracture."
                )
            )

            // 8. Seed Tools
            val toolsList = listOf(
                ToolEntity(
                    name = "Stihl TS410 350mm Cut-off Saw",
                    serialNumber = "ST-410-984252",
                    lastCheckedDate = "2026-09-24",
                    condition = "Excellent",
                    location = "Workshop - Banker Shed",
                    notes = "Pre-use checks completed: guard functional, blade checked for cracks, water feed pump working."
                ),
                ToolEntity(
                    name = "Makita DGA504 18V Angle Grinder",
                    serialNumber = "MK-504-18241",
                    lastCheckedDate = "2026-09-24",
                    condition = "Good",
                    location = "Workshop - Site Kit Bag A",
                    notes = "Equipped with diamond cutting blade for dry mortar raking. Guard aligned."
                ),
                ToolEntity(
                    name = "Sola Big Red 120cm Spirit Level",
                    serialNumber = "SL-RED-120",
                    lastCheckedDate = "2026-09-20",
                    condition = "Excellent",
                    location = "Van Drawer 1",
                    notes = "Calibrated. Dual vial alignment checked."
                ),
                ToolEntity(
                    name = "Mastercraft Heavy-Duty Mortar Mixer",
                    serialNumber = "MC-MIX-2026",
                    lastCheckedDate = "2026-09-23",
                    condition = "Service Required",
                    location = "Harrogate Site",
                    notes = "Engine starting smoothly, but drum belt showing signs of wear. Schedule replacement next week."
                )
            )
            for (tool in toolsList) {
                dao.insertTool(tool)
            }

            // 9. Seed Invoices
            val invoicesList = listOf(
                InvoiceEntity(
                    invoiceNumber = "INV-2026-0184",
                    jobId = whitbyId,
                    description = "Stage 1 payment: Survey, scaffold erection, and masonry joint preparation.",
                    netAmount = 14400.0,
                    vatAmount = 2880.0,
                    totalAmount = 17280.0,
                    status = "PAID",
                    date = "2026-09-18"
                ),
                InvoiceEntity(
                    invoiceNumber = "INV-2026-0185",
                    jobId = whitbyId,
                    description = "Stage 2 milestone: Stone banker dressing and lintel stabilization.",
                    netAmount = 12500.0,
                    vatAmount = 2500.0,
                    totalAmount = 15000.0,
                    status = "SENT",
                    date = "2026-09-24"
                ),
                InvoiceEntity(
                    invoiceNumber = "INV-2026-0210",
                    jobId = jobIds.getOrNull(1) ?: 2L,
                    description = "Heritage brick conservation work - Bootham Terrace.",
                    netAmount = 10000.0,
                    vatAmount = 2000.0,
                    totalAmount = 12000.0,
                    status = "PAID",
                    date = "2026-09-10"
                )
            )
            for (invoice in invoicesList) {
                dao.insertInvoice(invoice)
            }

            // 10. Seed Timesheets
            val timesheetsList = listOf(
                TimesheetEntity(
                    workerName = "Edward Harcourt",
                    role = "Master Stonemason",
                    date = "2026-09-24",
                    jobId = whitbyId,
                    hours = 8.0,
                    taskCompleted = "Banker stone dressing of south window jamb block, carving detail splay."
                ),
                TimesheetEntity(
                    workerName = "James Miller",
                    role = "Mason",
                    date = "2026-09-24",
                    jobId = whitbyId,
                    hours = 8.0,
                    taskCompleted = "Scaffold masonry inspection and joint preparation lower bay."
                ),
                TimesheetEntity(
                    workerName = "Arthur Pendelton",
                    role = "Apprentice Mason",
                    date = "2026-09-24",
                    jobId = whitbyId,
                    hours = 8.0,
                    taskCompleted = "Raking out joints lower bay, cleaning and washing facades with low pressure water."
                )
            )
            for (ts in timesheetsList) {
                dao.insertTimesheet(ts)
            }

            // 11. Seed Components (For Whitby Manor Components - Banker Mason Mode)
            dao.insertComponent(
                WorkshopComponentEntity(
                    jobId = whitbyId,
                    componentNumber = "C-018",
                    name = "Mullion Replacement - Left Tracery",
                    stoneType = "Bath Stone",
                    dimensions = "450 x 215 x 215mm",
                    status = "ROUGH OUT",
                    craftsmanName = "Edward Harcourt",
                    hoursSpent = 4.5
                )
            )
            dao.insertComponent(
                WorkshopComponentEntity(
                    jobId = whitbyId,
                    componentNumber = "C-019",
                    name = "Coping Stone - Gabled Peak",
                    stoneType = "Yorkshire Sandstone",
                    dimensions = "900 x 300 x 150mm",
                    status = "DRESS",
                    craftsmanName = "James Miller",
                    hoursSpent = 12.0
                )
            )
            dao.insertComponent(
                WorkshopComponentEntity(
                    jobId = whitbyId,
                    componentNumber = "C-020",
                    name = "Bespoke Window Lintel Block",
                    stoneType = "Yorkshire Sandstone",
                    dimensions = "1200 x 250 x 215mm",
                    status = "FINISHED",
                    craftsmanName = "Edward Harcourt",
                    hoursSpent = 24.5
                )
            )
        }
    }
}
