package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jobs")
data class JobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobNumber: String,
    val name: String,
    val clientName: String,
    val siteAddress: String,
    val contractValue: Double,
    val costToDate: Double,
    val status: String, // LEAD, SURVEY, ESTIMATING, QUOTED, AWARDED, PLANNED, ON SITE, PAUSED, SNAGGING, COMPLETE, ARCHIVED
    val startDate: String,
    val targetCompletion: String,
    val progressPercent: Int,
    val projectType: String, // NEW BUILD, STONE WALL, BRICK WALL, HERITAGE RESTORATION, etc.
    val notes: String,
    val clientContact: String,
    val architectName: String = "",
    val siteContact: String = ""
)

@Entity(tableName = "surveys")
data class SurveyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val weather: String,
    val surveyDate: String,
    val notes: String
)

@Entity(tableName = "measurements")
data class MeasurementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val label: String,
    val length: Double,
    val height: Double,
    val thickness: Double = 0.0,
    val quantity: Double,
    val type: String, // length, area, volume, wall_calc, brick_calc, stone_calc, repoint_calc
    val calculatedMaterialCost: Double = 0.0,
    val calculatedLabourCost: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "materials")
data class MaterialProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // Natural Stone, Brick, Mortar, Tool, Fixings, etc.
    val name: String,
    val description: String,
    val origin: String = "",
    val colour: String = "",
    val texture: String = "",
    val density: String = "",
    val typicalApplication: String = "",
    val format: String = "",
    val pricePerUnit: Double,
    val unitType: String, // tonne, m2, bag, etc.
    val supplierName: String,
    val leadTimeDays: Int = 3
)

@Entity(tableName = "site_diaries")
data class SiteDiaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val date: String,
    val weather: String,
    val crewCount: Int,
    val hoursWorked: Int,
    val workCompleted: String,
    val materialsDelivered: String,
    val issues: String,
    val notes: String = ""
)

@Entity(tableName = "defects")
data class DefectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val defectNumber: String,
    val title: String,
    val location: String,
    val priority: String, // High, Medium, Low
    val status: String, // OPEN, ASSESSED, PLANNED, REPAIRED, CLOSED
    val photoUri: String = "",
    val actionRequired: String = ""
)

@Entity(tableName = "timesheets")
data class TimesheetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerName: String,
    val role: String,
    val date: String,
    val jobId: Long,
    val hours: Double,
    val taskCompleted: String
)

@Entity(tableName = "tools")
data class ToolEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val serialNumber: String,
    val lastCheckedDate: String,
    val condition: String, // Excellent, Good, Service Required
    val location: String,
    val notes: String = ""
)

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val jobId: Long,
    val description: String,
    val netAmount: Double,
    val vatAmount: Double,
    val totalAmount: Double,
    val status: String, // DRAFT, SENT, PART PAID, PAID, OVERDUE
    val date: String
)

@Entity(tableName = "variations")
data class VariationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val variationNumber: String,
    val description: String,
    val cost: Double,
    val status: String // DRAFT, SUBMITTED, APPROVED, REJECTED
)

@Entity(tableName = "components")
data class WorkshopComponentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val componentNumber: String,
    val name: String,
    val stoneType: String,
    val dimensions: String,
    val status: String, // DRAWING, TEMPLATE, BLOCK, MARK OUT, ROUGH OUT, DRESS, DETAIL, FINISH, INSPECT, DELIVERED
    val craftsmanName: String,
    val hoursSpent: Double
)

@Entity(tableName = "drawings")
data class DrawingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val drawingNumber: String,
    val title: String,
    val revision: String,
    val author: String,
    val status: String, // Current, Superseded
    val date: String
)
