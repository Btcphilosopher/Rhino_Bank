package com.example.data.repository

import com.example.data.database.*
import kotlinx.coroutines.flow.Flow

class MastercraftRepository(private val dao: MastercraftDao) {

    // Jobs
    val allJobs: Flow<List<JobEntity>> = dao.getAllJobs()

    fun getJobById(jobId: Long): Flow<JobEntity?> = dao.getJobById(jobId)

    suspend fun getJobByIdSync(jobId: Long): JobEntity? = dao.getJobByIdSync(jobId)

    suspend fun insertJob(job: JobEntity): Long = dao.insertJob(job)

    suspend fun updateJob(job: JobEntity) = dao.updateJob(job)

    suspend fun deleteJob(job: JobEntity) = dao.deleteJob(job)


    // Surveys
    fun getSurveysForJob(jobId: Long): Flow<List<SurveyEntity>> = dao.getSurveysForJob(jobId)

    suspend fun insertSurvey(survey: SurveyEntity): Long = dao.insertSurvey(survey)


    // Measurements
    fun getMeasurementsForJob(jobId: Long): Flow<List<MeasurementEntity>> = dao.getMeasurementsForJob(jobId)

    suspend fun insertMeasurement(measurement: MeasurementEntity): Long = dao.insertMeasurement(measurement)

    suspend fun deleteMeasurement(measurement: MeasurementEntity) = dao.deleteMeasurement(measurement)


    // Materials Catalog
    val allMaterials: Flow<List<MaterialProductEntity>> = dao.getAllMaterials()

    suspend fun insertMaterial(material: MaterialProductEntity): Long = dao.insertMaterial(material)


    // Site Diaries
    fun getDiariesForJob(jobId: Long): Flow<List<SiteDiaryEntity>> = dao.getDiariesForJob(jobId)

    suspend fun insertSiteDiary(diary: SiteDiaryEntity): Long = dao.insertSiteDiary(diary)


    // Defects
    val allDefects: Flow<List<DefectEntity>> = dao.getAllDefects()

    fun getDefectsForJob(jobId: Long): Flow<List<DefectEntity>> = dao.getDefectsForJob(jobId)

    suspend fun insertDefect(defect: DefectEntity): Long = dao.insertDefect(defect)


    // Timesheets
    val allTimesheets: Flow<List<TimesheetEntity>> = dao.getAllTimesheets()

    fun getTimesheetsForJob(jobId: Long): Flow<List<TimesheetEntity>> = dao.getTimesheetsForJob(jobId)

    suspend fun insertTimesheet(timesheet: TimesheetEntity): Long = dao.insertTimesheet(timesheet)


    // Tools
    val allTools: Flow<List<ToolEntity>> = dao.getAllTools()

    suspend fun insertTool(tool: ToolEntity): Long = dao.insertTool(tool)


    // Invoices
    val allInvoices: Flow<List<InvoiceEntity>> = dao.getAllInvoices()

    fun getInvoicesForJob(jobId: Long): Flow<List<InvoiceEntity>> = dao.getInvoicesForJob(jobId)

    suspend fun insertInvoice(invoice: InvoiceEntity): Long = dao.insertInvoice(invoice)


    // Variations
    fun getVariationsForJob(jobId: Long): Flow<List<VariationEntity>> = dao.getVariationsForJob(jobId)

    suspend fun insertVariation(variation: VariationEntity): Long = dao.insertVariation(variation)


    // Workshop Components
    val allComponents: Flow<List<WorkshopComponentEntity>> = dao.getAllComponents()

    fun getComponentsForJob(jobId: Long): Flow<List<WorkshopComponentEntity>> = dao.getComponentsForJob(jobId)

    suspend fun insertComponent(component: WorkshopComponentEntity): Long = dao.insertComponent(component)


    // Drawings
    fun getDrawingsForJob(jobId: Long): Flow<List<DrawingEntity>> = dao.getDrawingsForJob(jobId)

    suspend fun insertDrawing(drawing: DrawingEntity): Long = dao.insertDrawing(drawing)
}
