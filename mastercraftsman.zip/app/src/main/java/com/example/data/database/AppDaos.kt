package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MastercraftDao {

    // Jobs
    @Query("SELECT * FROM jobs ORDER BY id DESC")
    fun getAllJobs(): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE id = :jobId LIMIT 1")
    fun getJobById(jobId: Long): Flow<JobEntity?>

    @Query("SELECT * FROM jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJobByIdSync(jobId: Long): JobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobEntity): Long

    @Update
    suspend fun updateJob(job: JobEntity)

    @Delete
    suspend fun deleteJob(job: JobEntity)


    // Surveys
    @Query("SELECT * FROM surveys WHERE jobId = :jobId ORDER BY id DESC")
    fun getSurveysForJob(jobId: Long): Flow<List<SurveyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurvey(survey: SurveyEntity): Long


    // Measurements
    @Query("SELECT * FROM measurements WHERE jobId = :jobId ORDER BY id DESC")
    fun getMeasurementsForJob(jobId: Long): Flow<List<MeasurementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: MeasurementEntity): Long

    @Delete
    suspend fun deleteMeasurement(measurement: MeasurementEntity)


    // Materials Catalog
    @Query("SELECT * FROM materials ORDER BY category, name ASC")
    fun getAllMaterials(): Flow<List<MaterialProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterial(material: MaterialProductEntity): Long


    // Site Diaries
    @Query("SELECT * FROM site_diaries WHERE jobId = :jobId ORDER BY date DESC, id DESC")
    fun getDiariesForJob(jobId: Long): Flow<List<SiteDiaryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSiteDiary(diary: SiteDiaryEntity): Long


    // Defects
    @Query("SELECT * FROM defects WHERE jobId = :jobId ORDER BY id DESC")
    fun getDefectsForJob(jobId: Long): Flow<List<DefectEntity>>

    @Query("SELECT * FROM defects ORDER BY id DESC")
    fun getAllDefects(): Flow<List<DefectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDefect(defect: DefectEntity): Long


    // Timesheets
    @Query("SELECT * FROM timesheets ORDER BY date DESC, id DESC")
    fun getAllTimesheets(): Flow<List<TimesheetEntity>>

    @Query("SELECT * FROM timesheets WHERE jobId = :jobId ORDER BY date DESC")
    fun getTimesheetsForJob(jobId: Long): Flow<List<TimesheetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimesheet(timesheet: TimesheetEntity): Long


    // Tools
    @Query("SELECT * FROM tools ORDER BY name ASC")
    fun getAllTools(): Flow<List<ToolEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTool(tool: ToolEntity): Long


    // Invoices
    @Query("SELECT * FROM invoices ORDER BY date DESC, id DESC")
    fun getAllInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE jobId = :jobId ORDER BY id DESC")
    fun getInvoicesForJob(jobId: Long): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity): Long


    // Variations
    @Query("SELECT * FROM variations WHERE jobId = :jobId ORDER BY id DESC")
    fun getVariationsForJob(jobId: Long): Flow<List<VariationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVariation(variation: VariationEntity): Long


    // Workshop Components
    @Query("SELECT * FROM components ORDER BY id DESC")
    fun getAllComponents(): Flow<List<WorkshopComponentEntity>>

    @Query("SELECT * FROM components WHERE jobId = :jobId ORDER BY id DESC")
    fun getComponentsForJob(jobId: Long): Flow<List<WorkshopComponentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComponent(component: WorkshopComponentEntity): Long


    // Drawings
    @Query("SELECT * FROM drawings WHERE jobId = :jobId ORDER BY id DESC")
    fun getDrawingsForJob(jobId: Long): Flow<List<DrawingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDrawing(drawing: DrawingEntity): Long
}
