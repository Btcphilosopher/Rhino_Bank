/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { FLAGSHIP_CONTRACTS, INITIAL_MARKET_DATA, PRESET_SCENARIOS, INITIAL_QUOTES } from './src/data/flagshipContracts';
import { SyntheticContract, MarketDataPoint, ContractStatus } from './src/types/contract';
import { RhinoContractEngine } from './src/services/contractEngine';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// In-memory authoritative store initialized with flagship contracts
let contractsStore: SyntheticContract[] = [...FLAGSHIP_CONTRACTS];
let marketDataStore: MarketDataPoint[] = [...INITIAL_MARKET_DATA];
let quotesStore = [...INITIAL_QUOTES];

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

// REST API Endpoints

// 1. List Contracts
app.get('/v1/contracts', (req: Request, res: Response) => {
  res.json({
    count: contractsStore.length,
    contracts: contractsStore
  });
});

// 2. Get Single Contract
app.get('/v1/contracts/:id', (req: Request, res: Response) => {
  const contract = contractsStore.find((c) => c.id === req.params.id);
  if (!contract) {
    return res.status(404).json({ error: 'Synthetic Contract not found' });
  }
  res.json(contract);
});

// 3. Create Contract
app.post('/v1/contracts', (req: Request, res: Response) => {
  const newContract: SyntheticContract = req.body;
  if (!newContract.id || !newContract.title) {
    return res.status(400).json({ error: 'Missing required contract parameters' });
  }

  // Price & Risk derive immediately
  const pricing = RhinoContractEngine.priceContract(newContract);
  const greeks = RhinoContractEngine.calculateGreeks(newContract, pricing);

  newContract.pricingResult = pricing;
  newContract.riskMetrics = greeks;
  newContract.version = '1.0';
  newContract.status = newContract.status || 'DRAFT';
  newContract.createdAt = new Date().toISOString();
  newContract.updatedAt = new Date().toISOString();

  contractsStore.unshift(newContract);
  res.status(201).json(newContract);
});

// 4. Re-price Contract
app.post('/v1/contracts/:id/price', (req: Request, res: Response) => {
  const contract = contractsStore.find((c) => c.id === req.params.id);
  if (!contract) return res.status(404).json({ error: 'Contract not found' });

  const { modelName, spot, riskFreeRate, impliedVol } = req.body;
  const newPricing = RhinoContractEngine.priceContract(contract, modelName, { spot, riskFreeRate, impliedVol });
  const newGreeks = RhinoContractEngine.calculateGreeks(contract, newPricing);

  contract.pricingResult = newPricing;
  contract.riskMetrics = newGreeks;
  contract.updatedAt = new Date().toISOString();

  res.json({
    contractId: contract.id,
    pricingResult: newPricing,
    riskMetrics: newGreeks
  });
});

// 5. Run Scenario Shock
app.post('/v1/contracts/:id/scenarios', (req: Request, res: Response) => {
  const contract = contractsStore.find((c) => c.id === req.params.id);
  if (!contract) return res.status(404).json({ error: 'Contract not found' });

  const { scenarioId, customShock } = req.body;
  const shock = PRESET_SCENARIOS.find((s) => s.id === scenarioId) || customShock;
  
  if (!shock) return res.status(400).json({ error: 'Invalid scenario shock specification' });

  const scenarioResult = RhinoContractEngine.runScenario(contract, shock);
  res.json({
    contractId: contract.id,
    scenario: shock,
    basePVGbp: contract.pricingResult.presentValueGbp,
    ...scenarioResult
  });
});

// 6. Transition Status with Cryptographic Hash
app.post('/v1/contracts/:id/transition', (req: Request, res: Response) => {
  const index = contractsStore.findIndex((c) => c.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Contract not found' });

  const { newStatus, actor, notes } = req.body as { newStatus: ContractStatus; actor: string; notes: string };
  const updatedContract = RhinoContractEngine.transitionStatus(contractsStore[index], newStatus, actor || 'Desk Trader', notes);

  contractsStore[index] = updatedContract;
  res.json(updatedContract);
});

// 7. Amend Contract (Version Lineage)
app.post('/v1/contracts/:id/amend', (req: Request, res: Response) => {
  const index = contractsStore.findIndex((c) => c.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Contract not found' });

  const { updatedFields, actor, reason } = req.body;
  const amendedContract = RhinoContractEngine.amendContract(
    contractsStore[index],
    updatedFields,
    actor || 'Senior Quant Structurer',
    reason || 'Bilateral negotiation of terms'
  );

  contractsStore[index] = amendedContract;
  res.json(amendedContract);
});

// 8. Replay Contract Lifecycle
app.get('/v1/contracts/:id/replay', (req: Request, res: Response) => {
  const contract = contractsStore.find((c) => c.id === req.params.id);
  if (!contract) return res.status(404).json({ error: 'Contract not found' });

  const replaySteps = RhinoContractEngine.replayLifecycle(contract);
  res.json({
    contractId: contract.id,
    title: contract.title,
    replaySteps
  });
});

// 9. Market Data & Oracles
app.get('/v1/market-data', (req: Request, res: Response) => {
  res.json({
    timestamp: new Date().toISOString(),
    marketData: marketDataStore
  });
});

app.get('/v1/quotes', (req: Request, res: Response) => {
  res.json(quotesStore);
});

app.get('/v1/oracles', (req: Request, res: Response) => {
  res.json({
    oracles: [
      { name: 'N2EX Power Oracle Node UK-01', assetClass: 'ENERGY', consensusNodes: 5, latencyMs: 14, status: 'HEALTHY', lastFixing: '£88.20/MWh' },
      { name: 'Rhino Crypto Multi-Exchange Oracle', assetClass: 'DIGITAL_ASSETS', consensusNodes: 8, latencyMs: 8, status: 'HEALTHY', lastFixing: '$115,240.00' },
      { name: 'Rotterdam Hydrogen Terminal Feed', assetClass: 'ENERGY', consensusNodes: 3, latencyMs: 22, status: 'HEALTHY', lastFixing: '€4.45/kg' },
      { name: 'ORR Passenger Rail Twin Feed', assetClass: 'INFRASTRUCTURE', consensusNodes: 4, latencyMs: 35, status: 'HEALTHY', lastFixing: '112.4 Index' }
    ]
  });
});

// 10. Structured CDO Lab
app.get('/v1/cdo-lab', (req: Request, res: Response) => {
  const result = RhinoContractEngine.simulateCDOTranches();
  res.json(result);
});

// AI endpoints using @google/genai SDK

// AI Natural Language Contract Designer (Gemini 3.8 / 3.1)
app.post('/api/ai/design-contract', async (req: Request, res: Response) => {
  try {
    const { userPrompt } = req.body;
    if (!userPrompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const systemInstruction = `You are RhinoContract AI, an institutional quantitative structurer for RhinoFinance Synthetic Contracts.
Your task is to parse a natural language contract request into a formal structured synthetic contract specification in JSON format.
You must return a valid JSON object strictly adhering to the schema below.
Identify any missing or ambiguous inputs in 'ambiguityWarnings'.
Tag every field provenance appropriately.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Design a formal synthetic financial contract for this user request: "${userPrompt}"`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            assetClass: { type: Type.STRING },
            contractFamily: { type: Type.STRING },
            productType: { type: Type.STRING },
            underlyingReferenceAsset: { type: Type.STRING },
            referenceIndex: { type: Type.STRING },
            notional: { type: Type.NUMBER },
            currency: { type: Type.STRING },
            tradeDate: { type: Type.STRING },
            effectiveDate: { type: Type.STRING },
            maturityDate: { type: Type.STRING },
            governingLaw: { type: Type.STRING },
            settlementMethod: { type: Type.STRING },
            paymentScheduleFrequency: { type: Type.STRING },
            fixingMethodology: { type: Type.STRING },
            fixedStrikeRate: { type: Type.NUMBER },
            formulaDescription: { type: Type.STRING },
            summaryText: { type: Type.STRING },
            termSheetMarkdown: { type: Type.STRING },
            ambiguityWarnings: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['title', 'assetClass', 'notional', 'currency', 'summaryText']
        }
      }
    });

    const parsedContent = JSON.parse(response.text || '{}');
    
    // Construct full SyntheticContract
    const proposedContract: Partial<SyntheticContract> = {
      id: `RHINO-AI-${Date.now().toString().slice(-6)}`,
      version: '1.0',
      title: parsedContent.title || 'RHINO AI PROPOSED SYNTHETIC CONTRACT',
      assetClass: (parsedContent.assetClass || 'ENERGY').toUpperCase() as any,
      contractFamily: (parsedContent.contractFamily || 'SWAP').toUpperCase() as any,
      productType: parsedContent.productType || 'Synthetic Differential Swap',
      underlyingReferenceAsset: parsedContent.underlyingReferenceAsset || 'AI Reference Reference Index',
      referenceIndex: parsedContent.referenceIndex || 'AI-INDEX-01',
      notional: parsedContent.notional || 100000000,
      currency: parsedContent.currency || 'GBP',
      tradeDate: parsedContent.tradeDate || new Date().toISOString().split('T')[0],
      effectiveDate: parsedContent.effectiveDate || new Date().toISOString().split('T')[0],
      maturityDate: parsedContent.maturityDate || '2031-12-31',
      counterparties: [
        {
          id: 'CP-RHINO-DESK',
          name: 'RhinoFinance International Derivatives Desk',
          legalEntityIdentifier: '213800RHINOFINL389102',
          jurisdiction: 'United Kingdom',
          creditRating: 'AA+',
          role: 'FIXED_PAYER'
        },
        {
          id: 'CP-COUNTERPARTY-AI',
          name: 'Institutional Counterparty Ltd',
          legalEntityIdentifier: '549300INSTITUTIONAL99',
          jurisdiction: 'United Kingdom',
          creditRating: 'A',
          role: 'FLOATING_PAYER'
        }
      ],
      governingLaw: parsedContent.governingLaw || 'English Law',
      settlementMethod: (parsedContent.settlementMethod || 'CASH_SETTLED') as any,
      paymentScheduleFrequency: parsedContent.paymentScheduleFrequency || 'QUARTERLY',
      fixingMethodology: parsedContent.fixingMethodology || 'Arithmetic daily mean fixing over quarterly period',
      status: 'DRAFT',
      fieldProvenances: {
        title: { source: 'AI_PROPOSED', actor: 'Rhino AI Designer', timestamp: new Date().toISOString() },
        notional: { source: 'AI_PROPOSED', actor: 'Rhino AI Designer', timestamp: new Date().toISOString() },
        payoff: { source: 'AI_PROPOSED', actor: 'Rhino AI Designer', timestamp: new Date().toISOString() }
      },
      humanReadableDocument: {
        summaryText: parsedContent.summaryText || 'AI Proposed Synthetic Contract',
        termSheetMarkdown: parsedContent.termSheetMarkdown || '### AI PROPOSED TERM SHEET',
        legalClausesMarkdown: '#### CLAUSE 1: AI GENERATED PROVISIONAL CLAUSES'
      },
      valuationMethodology: 'Black-76 Commodity Forward Engine'
    };

    res.json({
      proposedContract,
      ambiguityWarnings: parsedContent.ambiguityWarnings || []
    });
  } catch (error: any) {
    console.error('AI Contract Generation Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate contract proposal' });
  }
});

// AI Contract Assistant / Intelligence Endpoint
app.post('/api/ai/assistant', async (req: Request, res: Response) => {
  try {
    const { question, contractContext } = req.body;
    if (!question) return res.status(400).json({ error: 'Question is required' });

    const systemInstruction = `You are RHINO CONTRACT INTELLIGENCE, an elite quant and legal derivatives expert at RhinoFinance.
You analyze synthetic financial contracts, risk, P&L, model assumptions, and legal clauses.
CRITICAL MANDATE:
You must explicitly classify every assertion in your answer with tags:
[CONTRACT FACT] - Stated directly in contract terms.
[MARKET DATA] - From current market curves/fixings.
[MODEL OUTPUT] - Derived by mathematical model (PV, Greeks, XVA).
[AI INTERPRETATION] - Your analytical reasoning or legal interpretation.
[SCENARIO] - Hypothesized stress outcome.
[ASSUMPTION] - Underlying mathematical or economic assumption.

Be concise, authoritative, and institutional.`;

    const prompt = `Contract Context:
Title: ${contractContext?.title || 'General'}
Notional: ${contractContext?.notional} ${contractContext?.currency}
Product Type: ${contractContext?.productType}
PV: ${contractContext?.pricingResult?.presentValueGbp} GBP
Delta: ${contractContext?.riskMetrics?.delta}
Legal Summary: ${contractContext?.humanReadableDocument?.summaryText}

User Question: "${question}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: { systemInstruction }
    });

    res.json({ answer: response.text });
  } catch (error: any) {
    console.error('AI Assistant Error:', error);
    res.status(500).json({ error: error.message || 'Assistant unavailable' });
  }
});

// Express Server and Vite integration
const PORT = process.env.PORT || 3000;

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    // Mount Vite dev server middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      if (url.startsWith('/v1/') || url.startsWith('/api/')) {
        return next();
      }
      try {
        let template = (await import('fs')).readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`RhinoFinance Synthetic Contracts Server running on port ${PORT}`);
  });
}

startServer();
