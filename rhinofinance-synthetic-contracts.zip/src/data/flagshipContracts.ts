/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SyntheticContract, MarketDataPoint, ScenarioShock, MarketQuote } from '../types/contract';

export const FLAGSHIP_CONTRACTS: SyntheticContract[] = [
  {
    id: 'RHINO-UK-POWER-SWAP-01',
    version: '1.0',
    title: 'RHINO UK POWER REVENUE SWAP 01',
    productType: 'Energy Commodity Revenue Swap',
    contractFamily: 'REVENUE_INDEX_SWAP',
    assetClass: 'ENERGY',
    underlyingReferenceAsset: 'UK Wholesale Electricity Power Index (N2EX UK Day-Ahead)',
    referenceIndex: 'N2EX-UK-POWER-GBP-MWh',
    notional: 500000000,
    currency: 'GBP',
    tradeDate: '2026-01-15',
    effectiveDate: '2026-02-01',
    maturityDate: '2031-02-01',
    counterparties: [
      {
        id: 'CP-RHINO-DESK-01',
        name: 'RhinoFinance International Derivatives Desk',
        legalEntityIdentifier: '213800RHINOFINL389102',
        jurisdiction: 'United Kingdom (English Law)',
        creditRating: 'AA+',
        role: 'FIXED_PAYER',
        nettingAgreementId: 'ISDA-2026-RHINO-UK-001',
        marginAccountRef: 'VM-MARGIN-GBP-0992'
      },
      {
        id: 'CP-BRITISH-ENERGY-02',
        name: 'Thames Energy Holdings PLC',
        legalEntityIdentifier: '549300THAMESENGY88190',
        jurisdiction: 'United Kingdom',
        creditRating: 'A-',
        role: 'FLOATING_PAYER',
        nettingAgreementId: 'ISDA-2026-RHINO-UK-001',
        marginAccountRef: 'VM-MARGIN-GBP-0993'
      }
    ],
    governingLaw: 'English Law (High Court of Justice, London)',
    settlementMethod: 'CASH_SETTLED',
    paymentScheduleFrequency: 'QUARTERLY',
    fixingMethodology: 'Arithmetic average of daily N2EX UK Day-Ahead Electricity fixing price over each quarterly observation window.',
    status: 'LIVE',
    fieldProvenances: {
      notional: { source: 'USER_DEFINED', actor: 'Quant desk head', timestamp: '2026-01-15T09:00:00Z' },
      fixedRate: { source: 'MODEL_CALCULATED', actor: 'Black-76 Power Forward Calibrator v4', timestamp: '2026-01-15T09:05:00Z' },
      legalText: { source: 'AI_PROPOSED', actor: 'Rhino Contract Intelligence (Gemini 3.8)', timestamp: '2026-01-15T09:02:00Z' }
    },
    rsclSpec: {
      parties: {
        partyA: {
          id: 'CP-RHINO-DESK-01',
          name: 'RhinoFinance International',
          legalEntityIdentifier: '213800RHINOFINL389102',
          jurisdiction: 'United Kingdom',
          creditRating: 'AA+',
          role: 'FIXED_PAYER'
        },
        partyB: {
          id: 'CP-BRITISH-ENERGY-02',
          name: 'Thames Energy Holdings PLC',
          legalEntityIdentifier: '549300THAMESENGY88190',
          jurisdiction: 'United Kingdom',
          creditRating: 'A-',
          role: 'FLOATING_PAYER'
        },
        governingLaw: 'English Law',
        documentationFormat: 'RSCL 2026 Synthetic Derivative Architecture'
      },
      reference: {
        assetClass: 'ENERGY',
        primaryIdentifier: 'N2EX-UK-POWER-GBP-MWh',
        indexName: 'N2EX UK Electricity Day-Ahead Spot Index',
        fallbackIndexName: 'ICE UK Base Electricity Futures Settlement Price',
        sourceOracle: 'Rhino Energy Oracle Node UK-01 (Multi-Source Consensus)',
        fixingFrequency: 'Daily Arithmetic Average',
        dayCountConvention: 'ACT/365'
      },
      notional: {
        amount: 500000000,
        currency: 'GBP'
      },
      dates: {
        tradeDate: '2026-01-15',
        effectiveDate: '2026-02-01',
        maturityDate: '2031-02-01',
        settlementLagDays: 2
      },
      paymentLegs: [
        {
          legId: 'LEG-FIXED-01',
          payer: 'RhinoFinance International',
          type: 'FIXED',
          rateOrFormula: 'Fixed Price: £84.50 / MWh',
          fixedRatePercent: 8.45,
          paymentFrequency: 'QUARTERLY'
        },
        {
          legId: 'LEG-FLOAT-02',
          payer: 'Thames Energy Holdings PLC',
          type: 'FLOATING',
          rateOrFormula: 'N2EX_UK_POWER_INDEX_AVERAGE',
          paymentFrequency: 'QUARTERLY'
        }
      ],
      observations: {
        observationType: 'AVERAGING_WINDOW',
        dates: ['2026-04-30', '2026-07-31', '2026-10-31', '2027-01-31'],
        fixingSource: 'N2EX Power Auction'
      },
      payoff: {
        formulaDescription: 'Quarterly Cashflow = Notional * (Floating_Power_Index - Fixed_Strike_84.50) / Base_Index_Scale',
        capPercent: 25.0,
        floorPercent: -20.0
      },
      collateral: {
        required: true,
        initialMarginRequirementGbp: 25000000,
        variationMarginThresholdGbp: 1000000,
        eligibleCollateralTypes: ['CASH_GBP', 'UK_GILTS', 'BOE_TOKENISED_DEPOSIT'],
        haircutSchedule: {
          'CASH_GBP': 0.0,
          'UK_GILTS': 0.02,
          'BOE_TOKENISED_DEPOSIT': 0.005
        }
      },
      governance: {
        disruptionHandling: 'If N2EX fixing fails for 3 consecutive days, ICE UK Base Electricity Futures settlement applies.',
        earlyTerminationClause: 'Mutual consent or 50% rating downgrade of counterparty.',
        resolutionJurisdiction: 'London Court of International Arbitration (LCIA)'
      }
    },
    humanReadableDocument: {
      summaryText: 'Synthetic 5-year UK Power Revenue Swap referencing £500m notional with quarterly cash settlement based on N2EX UK Electricity Index against a fixed strike of £84.50/MWh.',
      termSheetMarkdown: `### SYNTHETIC TERM SHEET: RHINO UK POWER REVENUE SWAP 01
**Contract Identifier**: \`RHINO-UK-POWER-SWAP-01\`
**Notional Amount**: £500,000,000.00 GBP
**Fixed Payer**: RhinoFinance International Derivatives Desk (AA+)
**Floating Payer**: Thames Energy Holdings PLC (A-)
**Effective Date**: 1 February 2026
**Maturity Date**: 1 February 2031 (5-Year Term)
**Fixed Leg**: £84.50 per MWh (Fixed Rate equivalent: 8.45%)
**Floating Leg**: N2EX UK Wholesale Electricity Day-Ahead Index
**Payment Schedule**: Quarterly in Arrears (2 Business Day Settlement Lag)
**Collateral Requirement**: £25,000,000 Initial Margin in UK Gilts / BOE Tokenised Deposits
**Governance**: English Law, LCIA Arbitration London`,
      legalClausesMarkdown: `#### CLAUSE 1: DEFINITIONS & REFERENCE INDEX
1.1 "Reference Price" means the arithmetic mean of the daily fixing prices published by N2EX for United Kingdom Base Electricity Day-Ahead Market.
1.2 "Notional Scale" means 5,917,159.76 MWh equivalent over the 5-year lifecycle.

#### CLAUSE 2: PAYOFF & SETTLEMENT OBLIGATION
On each Settlement Date $t$, the net settlement payment $S_t$ shall be calculated as:
$$S_t = \\text{Notional}_t \\times \\frac{\\bar{P}_{\\text{N2EX}, t} - 84.50}{84.50}$$
Where $\\bar{P}_{\\text{N2EX}, t}$ represents the observed arithmetic average power price for quarter $t$.`
    },
    executionCode: {
      codeLanguage: 'SOLIDITY',
      sourceCode: `// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.20;

contract RhinoUKPowerSwapExecutable {
    address public fixedPayer = 0x8891...3910;
    address public floatingPayer = 0x5493...8819;
    uint256 public constant strikePriceGbpMwh = 8450; // 84.50 GBP scaled x100
    uint256 public constant notionalGbp = 500000000;
    
    function executeQuarterlySettlement(uint256 fixingPriceGbpMwh) external returns (int256 netPayout) {
        int256 priceDiff = int256(fixingPriceGbpMwh) - int256(strikePriceGbpMwh);
        netPayout = (int256(notionalGbp) * priceDiff) / int256(strikePriceGbpMwh);
        return netPayout;
    }
}`,
      contractHash: '0x9d4a821e28b14078a9c33e144a11b901fcd2a9d8',
      executionEnvironment: 'EVM Interchain Rhino Ledger Network',
      oracleInputs: ['N2EX_UK_POWER_INDEX_AVERAGE', 'BOE_SONIA_DISCOUNT_CURVE'],
      executionStatus: 'ACTIVE'
    },
    valuationMethodology: 'Black-76 Commodity Forward Model with Seasonal Mean-Reverting Hull-White Yield Calibration',
    pricingResult: {
      modelName: 'Black-76 Commodity Forward Engine',
      modelVersion: 'v4.2.1-prod',
      cleanPrice: 102.45,
      dirtyPrice: 103.12,
      presentValueGbp: 12250000,
      forwardValueGbp: 14800000,
      discountFactor: 0.9124,
      impliedVolatility: 0.324,
      calculationRuntimeMs: 4.2,
      calibrationStatus: 'CALIBRATED',
      timestamp: '2026-09-28T01:40:00Z',
      inputs: {
        'N2EX_Spot': 88.20,
        'Forward_Strike': 84.50,
        'Volatility_3Y': 0.324,
        'SONIA_RiskFreeRate': 0.0425,
        'Convenience_Yield': 0.012
      },
      confidenceScore: 0.98
    },
    riskMetrics: {
      delta: 591716, // GBP per £1 move in power price
      gamma: 12450,
      vega: 845000,
      theta: -12500,
      rho: 420000,
      dv01: 215000,
      cs01: 45000,
      fxDelta: 0,
      commodityDelta: 591716,
      inflationSensitivity: 18000,
      cvaGbp: 1250000,
      dvaGbp: 450000,
      fvaGbp: 620000,
      mvaGbp: 310000,
      initialMarginGbp: 25000000,
      variationMarginGbp: 3200000,
      pfePeakGbp: 48000000
    },
    cashFlows: [
      {
        id: 'CF-Q1-2026',
        date: '2026-04-30',
        legId: 'LEG-FLOAT-02',
        payer: 'Thames Energy Holdings PLC',
        receiver: 'RhinoFinance International',
        grossAmount: 26035500,
        netAmount: 1035500,
        currency: 'GBP',
        fixingRateUsed: 88.00,
        status: 'SETTLED',
        settlementTxHash: '0x8f2a...19d2',
        timestamp: '2026-05-02T10:00:00Z'
      },
      {
        id: 'CF-Q2-2026',
        date: '2026-07-31',
        legId: 'LEG-FLOAT-02',
        payer: 'Thames Energy Holdings PLC',
        receiver: 'RhinoFinance International',
        grossAmount: 26627200,
        netAmount: 1627200,
        currency: 'GBP',
        fixingRateUsed: 90.00,
        status: 'SETTLED',
        settlementTxHash: '0x4e9c...88a1',
        timestamp: '2026-08-02T10:00:00Z'
      },
      {
        id: 'CF-Q3-2026',
        date: '2026-10-31',
        legId: 'LEG-FLOAT-02',
        payer: 'Thames Energy Holdings PLC',
        receiver: 'RhinoFinance International',
        grossAmount: 26094600,
        netAmount: 1094600,
        currency: 'GBP',
        fixingRateUsed: 88.20,
        status: 'SCHEDULED',
        timestamp: '2026-09-28T01:40:00Z'
      }
    ],
    collateral: {
      contractId: 'RHINO-UK-POWER-SWAP-01',
      requiredInitialMarginGbp: 25000000,
      requiredVariationMarginGbp: 3200000,
      totalRequiredGbp: 28200000,
      postedCollateralGbp: 30000000,
      collateralAsset: 'UK Gilts 4.25% 2032',
      haircutPercent: 2.0,
      effectiveCollateralValueGbp: 29400000,
      collateralStatus: 'FULLY_COLLATERALISED',
      lastMarginCallTimestamp: '2026-09-25T16:00:00Z'
    },
    auditHistory: [
      {
        id: 'EVT-001',
        contractId: 'RHINO-UK-POWER-SWAP-01',
        contractVersion: '1.0',
        eventType: 'CONTRACT_CREATED',
        actor: 'Quantitative Structuring Desk (Rhino Admin)',
        details: 'Initial creation of 5-Year UK Power Revenue Swap referencing £500m notional.',
        previousHash: 'GENESIS_00000000000000000000000000000000',
        eventHash: '0xa1b2c3d4e5f67890123456789abcdef012345678',
        timestamp: '2026-01-15T09:00:00Z'
      },
      {
        id: 'EVT-002',
        contractId: 'RHINO-UK-POWER-SWAP-01',
        contractVersion: '1.0',
        eventType: 'RFQ_EXECUTED',
        actor: 'Counterparty Thames Energy PLC',
        details: 'Bilateral trade agreement confirmed and signed under ISDA master agreement.',
        previousHash: '0xa1b2c3d4e5f67890123456789abcdef012345678',
        eventHash: '0xb2c3d4e5f67890123456789abcdef0123456789a',
        timestamp: '2026-01-20T14:30:00Z'
      }
    ],
    dataProvenance: 'Multi-Oracle Feed (N2EX London + ICE Futures Europe + BOE SONIA)',
    createdAt: '2026-01-15T09:00:00Z',
    updatedAt: '2026-09-28T01:40:00Z'
  },
  {
    id: 'RHINO-BTC-VOL-SWAP-01',
    version: '1.0',
    title: 'RHINO BTC VOLATILITY SWAP 01',
    productType: 'Digital Asset Volatility Swap',
    contractFamily: 'VOLATILITY_SWAP',
    assetClass: 'DIGITAL_ASSETS',
    underlyingReferenceAsset: 'Bitcoin (BTC/USD) 30-Day Realised Volatility Index',
    referenceIndex: 'RHINO-BTC-30D-RVOL-USD',
    notional: 50000000,
    currency: 'USD',
    tradeDate: '2026-06-01',
    effectiveDate: '2026-06-01',
    maturityDate: '2027-06-01',
    counterparties: [
      {
        id: 'CP-RHINO-DESK-01',
        name: 'RhinoFinance Digital Assets Desk',
        legalEntityIdentifier: '213800RHINOFINL389102',
        jurisdiction: 'United Kingdom',
        creditRating: 'AA+',
        role: 'BUYER',
        nettingAgreementId: 'ISDA-DA-2026-011'
      },
      {
        id: 'CP-SIGMA-CAPITAL',
        name: 'Sigma Crypto Market Makers Fund',
        legalEntityIdentifier: '984900SIGMACRYPTO1002',
        jurisdiction: 'Cayman Islands',
        creditRating: 'BBB',
        role: 'SELLER',
        nettingAgreementId: 'ISDA-DA-2026-011'
      }
    ],
    governingLaw: 'English Law',
    settlementMethod: 'CASH_SETTLED',
    paymentScheduleFrequency: 'MONTHLY',
    fixingMethodology: '30-Day annualized log return standard deviation calculated from hourly Deribit/Coinbase index fixings.',
    status: 'LIVE',
    fieldProvenances: {
      volStrike: { source: 'USER_DEFINED', actor: 'Crypto Quant Desk', timestamp: '2026-06-01T10:00:00Z' }
    },
    rsclSpec: {
      parties: {
        partyA: {
          id: 'CP-RHINO-DESK-01',
          name: 'RhinoFinance Digital Assets Desk',
          legalEntityIdentifier: '213800RHINOFINL389102',
          jurisdiction: 'United Kingdom',
          creditRating: 'AA+',
          role: 'BUYER'
        },
        partyB: {
          id: 'CP-SIGMA-CAPITAL',
          name: 'Sigma Crypto Market Makers Fund',
          legalEntityIdentifier: '984900SIGMACRYPTO1002',
          jurisdiction: 'Cayman Islands',
          creditRating: 'BBB',
          role: 'SELLER'
        },
        governingLaw: 'English Law',
        documentationFormat: 'RSCL Digital Asset Annex 2026'
      },
      reference: {
        assetClass: 'DIGITAL_ASSETS',
        primaryIdentifier: 'RHINO-BTC-30D-RVOL-USD',
        indexName: 'Rhino Bitcoin 30-Day Realised Volatility Index',
        fallbackIndexName: 'Deribit DVOL Index',
        sourceOracle: 'Rhino Multi-Exchange Crypto Oracle (Deribit, Coinbase, Binance, Kraken)',
        fixingFrequency: 'Hourly Log Returns',
        dayCountConvention: 'ACT/365'
      },
      notional: {
        amount: 50000000,
        currency: 'USD'
      },
      dates: {
        tradeDate: '2026-06-01',
        effectiveDate: '2026-06-01',
        maturityDate: '2027-06-01',
        settlementLagDays: 1
      },
      paymentLegs: [
        {
          legId: 'LEG-VOL-01',
          payer: 'Sigma Crypto Market Makers Fund',
          type: 'OPTION_PAYOFF',
          rateOrFormula: 'Notional * (Realised_Vol_Percent - Strike_Vol_58.50%) / 100',
          paymentFrequency: 'MONTHLY'
        }
      ],
      observations: {
        observationType: 'DAILY_CLOSE',
        dates: [],
        fixingSource: 'Rhino Realised Vol Calculator'
      },
      payoff: {
        formulaDescription: 'Settlement = Vega_Notional * (Realised_Volatility - Strike_Volatility_58.5%)',
        strikePrice: 58.5,
        capPercent: 120.0,
        floorPercent: 0.0
      },
      collateral: {
        required: true,
        initialMarginRequirementGbp: 10000000,
        variationMarginThresholdGbp: 250000,
        eligibleCollateralTypes: ['USDC', 'USDT', 'CASH_USD'],
        haircutSchedule: { 'USDC': 0.005, 'USDT': 0.01 }
      },
      governance: {
        disruptionHandling: 'Hard fork handling: Primary fork with highest hash rate governs index.',
        earlyTerminationClause: '150% vol spike or exchange shutdown.',
        resolutionJurisdiction: 'London Court of International Arbitration'
      }
    },
    humanReadableDocument: {
      summaryText: 'Synthetic 1-year $50m BTC Volatility Swap paying the difference between 30-day realized BTC volatility and a strike volatility of 58.50%.',
      termSheetMarkdown: '### TERM SHEET: RHINO BTC VOLATILITY SWAP 01\n**Strike Volatility**: 58.50% annualized\n**Vega Notional**: $500,000 per 1% volatility point\n**Settlement Currency**: USD / USDC',
      legalClausesMarkdown: '#### CLAUSE 1: REALISED VOLATILITY CALCULATION FORMULA\n$$\\sigma_{\\text{realised}} = \\sqrt{\\frac{365}{N} \\sum_{i=1}^N \\left( \\ln \\frac{S_i}{S_{i-1}} \\right)^2} \\times 100\\%'
    },
    valuationMethodology: 'Heston Stochastic Volatility Model with Jump Diffusion',
    pricingResult: {
      modelName: 'Heston Stochastic Volatility Engine',
      modelVersion: 'v2.1',
      cleanPrice: 104.80,
      dirtyPrice: 105.10,
      presentValueGbp: 2400000,
      forwardValueGbp: 2750000,
      discountFactor: 0.952,
      impliedVolatility: 0.625,
      calculationRuntimeMs: 8.4,
      calibrationStatus: 'CALIBRATED',
      timestamp: '2026-09-28T01:40:00Z',
      inputs: {
        'BTC_Spot': 115000,
        'Strike_Vol': 58.5,
        'Implied_Vol': 62.5,
        'Heston_Kappa': 2.5,
        'Heston_Theta': 0.35,
        'Heston_Xi': 0.45
      },
      confidenceScore: 0.96
    },
    riskMetrics: {
      delta: 125000,
      gamma: 4200,
      vega: 500000,
      theta: -8500,
      rho: 110000,
      dv01: 35000,
      cs01: 18000,
      fxDelta: 125000,
      commodityDelta: 0,
      inflationSensitivity: 0,
      cvaGbp: 850000,
      dvaGbp: 210000,
      fvaGbp: 340000,
      mvaGbp: 180000,
      initialMarginGbp: 10000000,
      variationMarginGbp: 1200000,
      pfePeakGbp: 18000000
    },
    cashFlows: [],
    collateral: {
      contractId: 'RHINO-BTC-VOL-SWAP-01',
      requiredInitialMarginGbp: 10000000,
      requiredVariationMarginGbp: 1200000,
      totalRequiredGbp: 11200000,
      postedCollateralGbp: 12000000,
      collateralAsset: 'USDC Circle Institutional Deposit',
      haircutPercent: 0.5,
      effectiveCollateralValueGbp: 11940000,
      collateralStatus: 'FULLY_COLLATERALISED',
      lastMarginCallTimestamp: '2026-09-26T12:00:00Z'
    },
    auditHistory: [],
    dataProvenance: 'Multi-Exchange WebSocket Oracle (Deribit / Coinbase / Kraken)',
    createdAt: '2026-06-01T10:00:00Z',
    updatedAt: '2026-09-28T01:40:00Z'
  },
  {
    id: 'RHINO-HYDROGEN-SWAP-01',
    version: '1.0',
    title: 'RHINO NORTH SEA HYDROGEN SWAP 01',
    productType: 'Green Hydrogen Energy Transition Differential Swap',
    contractFamily: 'SWAP',
    assetClass: 'ENERGY',
    underlyingReferenceAsset: 'North Sea Green Hydrogen Index vs Natural Gas TTF Parity',
    referenceIndex: 'HY-INDEX-NORTHSEA-EUR-KG',
    notional: 100000000,
    currency: 'EUR',
    tradeDate: '2026-03-10',
    effectiveDate: '2026-04-01',
    maturityDate: '2029-04-01',
    counterparties: [
      {
        id: 'CP-RHINO-DESK-01',
        name: 'RhinoFinance Energy & Commodities Desk',
        legalEntityIdentifier: '213800RHINOFINL389102',
        jurisdiction: 'United Kingdom',
        creditRating: 'AA+',
        role: 'FIXED_PAYER',
        nettingAgreementId: 'ISDA-EUR-2026-088'
      },
      {
        id: 'CP-ORSTED-HY',
        name: 'North Sea Green Energy Consortium NV',
        legalEntityIdentifier: '549300NORTHSEAHY9921',
        jurisdiction: 'Netherlands',
        creditRating: 'A',
        role: 'FLOATING_PAYER',
        nettingAgreementId: 'ISDA-EUR-2026-088'
      }
    ],
    governingLaw: 'English Law',
    settlementMethod: 'CASH_SETTLED',
    paymentScheduleFrequency: 'SEMI_ANNUALLY',
    fixingMethodology: 'Weighted average of Rotterdam Green Hydrogen Import Index and Electrolyser Terminal Output Index.',
    status: 'LIVE',
    fieldProvenances: {},
    rsclSpec: {
      parties: {
        partyA: {
          id: 'CP-RHINO-DESK-01',
          name: 'RhinoFinance Energy & Commodities Desk',
          legalEntityIdentifier: '213800RHINOFINL389102',
          jurisdiction: 'United Kingdom',
          creditRating: 'AA+',
          role: 'FIXED_PAYER'
        },
        partyB: {
          id: 'CP-ORSTED-HY',
          name: 'North Sea Green Energy Consortium NV',
          legalEntityIdentifier: '549300NORTHSEAHY9921',
          jurisdiction: 'Netherlands',
          creditRating: 'A',
          role: 'FLOATING_PAYER'
        },
        governingLaw: 'English Law',
        documentationFormat: 'RSCL Commodity Energy Annex'
      },
      reference: {
        assetClass: 'ENERGY',
        primaryIdentifier: 'HY-INDEX-NORTHSEA-EUR-KG',
        indexName: 'North Sea Green Hydrogen Parity Index',
        fallbackIndexName: 'TTF Natural Gas + Carbon Allowance Equivalent',
        sourceOracle: 'Rhino Hydrogen Infrastructure Oracle',
        fixingFrequency: 'Semi-annual Fixing',
        dayCountConvention: 'ACT/360'
      },
      notional: { amount: 100000000, currency: 'EUR' },
      dates: { tradeDate: '2026-03-10', effectiveDate: '2026-04-01', maturityDate: '2029-04-01', settlementLagDays: 3 },
      paymentLegs: [
        { legId: 'LEG-1', payer: 'RhinoFinance Energy & Commodities Desk', type: 'FIXED', rateOrFormula: 'Fixed Price: €4.20 / kg', paymentFrequency: 'SEMI_ANNUALLY' },
        { legId: 'LEG-2', payer: 'North Sea Green Energy Consortium NV', type: 'FLOATING', rateOrFormula: 'HY_INDEX_NORTHSEA', paymentFrequency: 'SEMI_ANNUALLY' }
      ],
      observations: { observationType: 'PERIODIC_FIXING', dates: [], fixingSource: 'Rotterdam Terminal Feed' },
      payoff: { formulaDescription: 'Semi-annual payout = Notional * (Hydrogen_Price_EUR_kg - 4.20) / 4.20' },
      collateral: {
        required: true,
        initialMarginRequirementGbp: 8000000,
        variationMarginThresholdGbp: 500000,
        eligibleCollateralTypes: ['CASH_EUR', 'GERMAN_BUNDS'],
        haircutSchedule: { 'CASH_EUR': 0.0, 'GERMAN_BUNDS': 0.015 }
      },
      governance: { disruptionHandling: 'TTF Gas parity formula applies if electrolyser shutdown exceeds 10 days.', earlyTerminationClause: 'Force Majeure', resolutionJurisdiction: 'LCIA' }
    },
    humanReadableDocument: {
      summaryText: '3-Year €100m Synthetic North Sea Green Hydrogen Differential Swap vs €4.20/kg strike.',
      termSheetMarkdown: '### TERM SHEET: NORTH SEA HYDROGEN SWAP 01\n**Fixed Strike**: €4.20/kg\n**Notional**: €100,000,000',
      legalClausesMarkdown: '#### CLAUSE 1: HYDROGEN PRICE PARITY INDEX'
    },
    valuationMethodology: 'Bespoke Convenience-Yield Commodity Cost-of-Carry Model',
    pricingResult: {
      modelName: 'Commodity Cost-of-Carry Model with Hydrogen Yield',
      modelVersion: 'v1.8',
      cleanPrice: 99.80,
      dirtyPrice: 100.20,
      presentValueGbp: 1850000,
      forwardValueGbp: 2100000,
      discountFactor: 0.935,
      impliedVolatility: 0.28,
      calculationRuntimeMs: 3.8,
      calibrationStatus: 'CALIBRATED',
      timestamp: '2026-09-28T01:40:00Z',
      inputs: { 'Hydrogen_Spot': 4.45, 'Strike': 4.20, 'TTF_Gas_Equivalent': 3.90 },
      confidenceScore: 0.95
    },
    riskMetrics: {
      delta: 238095,
      gamma: 8100,
      vega: 290000,
      theta: -4100,
      rho: 82000,
      dv01: 42000,
      cs01: 15000,
      fxDelta: 1850000,
      commodityDelta: 238095,
      inflationSensitivity: 12000,
      cvaGbp: 420000,
      dvaGbp: 110000,
      fvaGbp: 180000,
      mvaGbp: 90000,
      initialMarginGbp: 8000000,
      variationMarginGbp: 650000,
      pfePeakGbp: 12000000
    },
    cashFlows: [],
    collateral: {
      contractId: 'RHINO-HYDROGEN-SWAP-01',
      requiredInitialMarginGbp: 8000000,
      requiredVariationMarginGbp: 650000,
      totalRequiredGbp: 8650000,
      postedCollateralGbp: 9000000,
      collateralAsset: 'German Bunds 2.30% 2030',
      haircutPercent: 1.5,
      effectiveCollateralValueGbp: 8865000,
      collateralStatus: 'FULLY_COLLATERALISED',
      lastMarginCallTimestamp: '2026-09-25T16:00:00Z'
    },
    auditHistory: [],
    dataProvenance: 'Rhino Green Energy Telemetry & Rotterdam Terminal Oracle',
    createdAt: '2026-03-10T09:00:00Z',
    updatedAt: '2026-09-28T01:40:00Z'
  },
  {
    id: 'RHINO-RAIL-INFRA-SWAP-01',
    version: '1.0',
    title: 'RHINO INFRASTRUCTURE REVENUE SWAP 01',
    productType: 'Infrastructure Rail Passenger Revenue Index Swap',
    contractFamily: 'REVENUE_INDEX_SWAP',
    assetClass: 'INFRASTRUCTURE',
    underlyingReferenceAsset: 'Manchester-London West Coast Rail Passenger Revenue Index',
    referenceIndex: 'UK-RAIL-REVENUE-MCR-LDN-INDEX',
    notional: 250000000,
    currency: 'GBP',
    tradeDate: '2025-10-01',
    effectiveDate: '2025-10-15',
    maturityDate: '2035-10-15',
    counterparties: [
      {
        id: 'CP-RHINO-DESK-01',
        name: 'RhinoFinance Infrastructure Capital Desk',
        legalEntityIdentifier: '213800RHINOFINL389102',
        jurisdiction: 'United Kingdom',
        creditRating: 'AA+',
        role: 'FIXED_PAYER',
        nettingAgreementId: 'ISDA-INFRA-2025-001'
      },
      {
        id: 'CP-UK-RAIL-PENSION',
        name: 'Railways Pension Trustee Company Ltd',
        legalEntityIdentifier: '213800RAILPENSION901',
        jurisdiction: 'United Kingdom',
        creditRating: 'AAA',
        role: 'FLOATING_PAYER',
        nettingAgreementId: 'ISDA-INFRA-2025-001'
      }
    ],
    governingLaw: 'English Law',
    settlementMethod: 'CASH_SETTLED',
    paymentScheduleFrequency: 'ANNUALLY',
    fixingMethodology: 'ORR (Office of Rail and Road) verified annual passenger ticket revenue index scaled against 2025 baseline.',
    status: 'LIVE',
    fieldProvenances: {},
    rsclSpec: {
      parties: {
        partyA: {
          id: 'CP-RHINO-DESK-01',
          name: 'RhinoFinance Infrastructure Capital',
          legalEntityIdentifier: '213800RHINOFINL389102',
          jurisdiction: 'United Kingdom',
          creditRating: 'AA+',
          role: 'FIXED_PAYER'
        },
        partyB: {
          id: 'CP-UK-RAIL-PENSION',
          name: 'Railways Pension Trustee Company Ltd',
          legalEntityIdentifier: '213800RAILPENSION901',
          jurisdiction: 'United Kingdom',
          creditRating: 'AAA',
          role: 'FLOATING_PAYER'
        },
        governingLaw: 'English Law',
        documentationFormat: 'RSCL Infrastructure Digital Twin Format'
      },
      reference: {
        assetClass: 'INFRASTRUCTURE',
        primaryIdentifier: 'UK-RAIL-REVENUE-MCR-LDN-INDEX',
        indexName: 'Manchester-London Rail Passenger Revenue Index',
        fallbackIndexName: 'UK National Rail Passenger Kilometre Index',
        sourceOracle: 'Rhino Infrastructure Digital Twin Oracle (ORR Telemetry + Ticket System API)',
        fixingFrequency: 'Annual',
        dayCountConvention: 'ACT/365'
      },
      notional: { amount: 250000000, currency: 'GBP' },
      dates: { tradeDate: '2025-10-01', effectiveDate: '2025-10-15', maturityDate: '2035-10-15', settlementLagDays: 5 },
      paymentLegs: [
        { legId: 'LEG-1', payer: 'RhinoFinance Infrastructure Capital', type: 'FIXED', rateOrFormula: 'Fixed Benchmark Growth: 3.75% p.a.', paymentFrequency: 'ANNUALLY' },
        { legId: 'LEG-2', payer: 'Railways Pension Trustee Company Ltd', type: 'FLOATING', rateOrFormula: 'ACTUAL_RAIL_REVENUE_INDEX_GROWTH', paymentFrequency: 'ANNUALLY' }
      ],
      observations: { observationType: 'PERIODIC_FIXING', dates: [], fixingSource: 'ORR Official Statistics' },
      payoff: { formulaDescription: 'Annual Cashflow = Notional * (Actual_Revenue_Growth - 3.75%)' },
      collateral: {
        required: true,
        initialMarginRequirementGbp: 15000000,
        variationMarginThresholdGbp: 1000000,
        eligibleCollateralTypes: ['CASH_GBP', 'UK_GILTS'],
        haircutSchedule: { 'CASH_GBP': 0.0, 'UK_GILTS': 0.02 }
      },
      governance: { disruptionHandling: 'If ORR data delayed >30 days, train passenger sensor counts govern temporary fixing.', earlyTerminationClause: 'Government nationalization trigger', resolutionJurisdiction: 'High Court, London' }
    },
    humanReadableDocument: {
      summaryText: '10-Year £250m Synthetic Rail Revenue Swap hedging Manchester to London passenger volume vs 3.75% fixed benchmark.',
      termSheetMarkdown: '### TERM SHEET: RHINO INFRASTRUCTURE REVENUE SWAP 01\n**Notional**: £250,000,000\n**Term**: 10 Years\n**Fixed Growth Rate**: 3.75% per annum',
      legalClausesMarkdown: '#### CLAUSE 1: INFRASTRUCTURE DIGITAL TWIN CONNECTION\nThis synthetic contract connects directly to the Rhino Infrastructure Digital Twin sensor network.'
    },
    valuationMethodology: 'Discounted Cash Flow with Econometric Rail Demand Regression Model',
    pricingResult: {
      modelName: 'Infrastructure Econometric Cash Flow Engine',
      modelVersion: 'v3.0',
      cleanPrice: 101.50,
      dirtyPrice: 101.90,
      presentValueGbp: 4250000,
      forwardValueGbp: 5800000,
      discountFactor: 0.885,
      impliedVolatility: 0.12,
      calculationRuntimeMs: 2.9,
      calibrationStatus: 'CALIBRATED',
      timestamp: '2026-09-28T01:40:00Z',
      inputs: { 'Passenger_Index_Growth': 0.0415, 'Fixed_Benchmark': 0.0375, 'UK_CPI_Inflation': 0.024 },
      confidenceScore: 0.97
    },
    riskMetrics: {
      delta: 2500000,
      gamma: 18000,
      vega: 120000,
      theta: -3200,
      rho: 185000,
      dv01: 98000,
      cs01: 22000,
      fxDelta: 0,
      commodityDelta: 0,
      inflationSensitivity: 240000,
      cvaGbp: 320000,
      dvaGbp: 180000,
      fvaGbp: 210000,
      mvaGbp: 85000,
      initialMarginGbp: 15000000,
      variationMarginGbp: 820000,
      pfePeakGbp: 22000000
    },
    cashFlows: [],
    collateral: {
      contractId: 'RHINO-RAIL-INFRA-SWAP-01',
      requiredInitialMarginGbp: 15000000,
      requiredVariationMarginGbp: 820000,
      totalRequiredGbp: 15820000,
      postedCollateralGbp: 16500000,
      collateralAsset: 'UK Gilts 3.75% 2038',
      haircutPercent: 2.0,
      effectiveCollateralValueGbp: 16170000,
      collateralStatus: 'FULLY_COLLATERALISED',
      lastMarginCallTimestamp: '2026-09-24T10:00:00Z'
    },
    auditHistory: [],
    dataProvenance: 'ORR Passenger Rail Data & Rhino Infrastructure Digital Twin',
    createdAt: '2025-10-01T09:00:00Z',
    updatedAt: '2026-09-28T01:40:00Z'
  }
];

export const INITIAL_MARKET_DATA: MarketDataPoint[] = [
  { id: 'MKT-01', ticker: 'N2EX-UK-POWER', name: 'N2EX UK Power Day-Ahead Spot', assetClass: 'ENERGY', value: 88.20, currency: 'GBP', unit: '£/MWh', timestamp: '2026-09-28T01:40:00Z', source: 'N2EX London', status: 'LIVE', confidenceScore: 0.99 },
  { id: 'MKT-02', ticker: 'BTC-USD-SPOT', name: 'Bitcoin Spot Index', assetClass: 'DIGITAL_ASSETS', value: 115240.00, currency: 'USD', unit: '$', timestamp: '2026-09-28T01:40:00Z', source: 'Rhino Multi-Exchange Crypto Consensus', status: 'LIVE', confidenceScore: 0.99 },
  { id: 'MKT-03', ticker: 'HY-NORTHSEA-INDEX', name: 'North Sea Green Hydrogen Parity', assetClass: 'ENERGY', value: 4.45, currency: 'EUR', unit: '€/kg', timestamp: '2026-09-28T01:40:00Z', source: 'Rotterdam Terminal Feed', status: 'LIVE', confidenceScore: 0.96 },
  { id: 'MKT-04', ticker: 'MCR-LDN-RAIL-INDEX', name: 'MCR-LDN Rail Passenger Revenue', assetClass: 'INFRASTRUCTURE', value: 112.4, currency: 'GBP', unit: 'Index (100=2025)', timestamp: '2026-09-28T01:40:00Z', source: 'ORR Telemetry Twin', status: 'LIVE', confidenceScore: 0.98 },
  { id: 'MKT-05', ticker: 'SONIA-3M-CURVE', name: 'BOE SONIA 3M Swap Rate', assetClass: 'RATES', value: 4.25, currency: 'GBP', unit: '% p.a.', timestamp: '2026-09-28T01:40:00Z', source: 'Bank of England Curve', status: 'LIVE', confidenceScore: 1.0 },
  { id: 'MKT-06', ticker: 'GBP-USD-FX', name: 'Sterling FX Spot Rate', assetClass: 'FX', value: 1.3245, currency: 'USD', unit: '$ per £', timestamp: '2026-09-28T01:40:00Z', source: 'EBS FX Spot', status: 'LIVE', confidenceScore: 1.0 },
  { id: 'MKT-07', ticker: 'UK-CPI-INFLATION', name: 'UK CPI Inflation YoY', assetClass: 'INFLATION', value: 2.40, currency: 'GBP', unit: '%', timestamp: '2026-09-28T01:40:00Z', source: 'ONS Statistics', status: 'LIVE', confidenceScore: 0.99 },
  { id: 'MKT-08', ticker: 'ITRAXX-EUROPE-CDS', name: 'iTraxx Europe 5Y CDS Spread', assetClass: 'CREDIT', value: 58.5, currency: 'EUR', unit: 'bps', timestamp: '2026-09-28T01:40:00Z', source: 'Markit Credit Indices', status: 'LIVE', confidenceScore: 0.98 }
];

export const PRESET_SCENARIOS: ScenarioShock[] = [
  { id: 'SCEN-01', name: 'STERLING CRISIS & RATE HIKE', description: 'Simulates +250bps UK SONIA rate shock, -15% GBP FX drop, and +80bps credit spread blowout.', rateShiftBps: 250, fxShiftPercent: -15, equityShiftPercent: -12, commodityShiftPercent: 10, creditSpreadShiftBps: 80, volatilityShiftPercent: 45, inflationShiftBps: 180 },
  { id: 'SCEN-02', name: 'ENERGY & POWER PRICE CRUNCH', description: 'Simulates +80% European gas & UK electricity power shock with +35% commodity volatility.', rateShiftBps: 50, fxShiftPercent: -3, equityShiftPercent: -8, commodityShiftPercent: 80, creditSpreadShiftBps: 40, volatilityShiftPercent: 35, inflationShiftBps: 220 },
  { id: 'SCEN-03', name: 'GLOBAL LIQUIDITY & VOLATILITY SPIKE', description: 'Simulates systemic market collapse: +100% vol spike, -25% equities, -40% crypto, +120bps credit spreads.', rateShiftBps: -100, fxShiftPercent: -5, equityShiftPercent: -25, commodityShiftPercent: -15, creditSpreadShiftBps: 120, volatilityShiftPercent: 100, inflationShiftBps: -50 },
  { id: 'SCEN-04', name: 'DIGITAL ASSET LIQUIDATION CRASH', description: 'Simulates -50% crypto asset fall with +150% realised volatility spike and counterparty margin freeze.', rateShiftBps: 0, fxShiftPercent: -2, equityShiftPercent: -5, commodityShiftPercent: 0, creditSpreadShiftBps: 25, volatilityShiftPercent: 150, inflationShiftBps: 0 }
];

export const INITIAL_QUOTES: MarketQuote[] = [
  { id: 'QT-001', contractId: 'RHINO-UK-POWER-SWAP-01', contractTitle: 'RHINO UK POWER REVENUE SWAP 01', bidPrice: 101.80, askPrice: 103.10, midPrice: 102.45, dealer: 'Barclays Investment Bank Derivatives Desk', notionalAvailable: 100000000, validUntil: '2026-09-28T18:00:00Z', status: 'ACTIVE' },
  { id: 'QT-002', contractId: 'RHINO-UK-POWER-SWAP-01', contractTitle: 'RHINO UK POWER REVENUE SWAP 01', bidPrice: 101.90, askPrice: 103.00, midPrice: 102.45, dealer: 'Goldman Sachs International', notionalAvailable: 250000000, validUntil: '2026-09-28T18:00:00Z', status: 'ACTIVE' },
  { id: 'QT-003', contractId: 'RHINO-BTC-VOL-SWAP-01', contractTitle: 'RHINO BTC VOLATILITY SWAP 01', bidPrice: 103.50, askPrice: 106.10, midPrice: 104.80, dealer: 'Jump Crypto & Trading UK', notionalAvailable: 50000000, validUntil: '2026-09-28T18:00:00Z', status: 'ACTIVE' }
];
