/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssetClass =
  | 'RATES'
  | 'FX'
  | 'EQUITIES'
  | 'COMMODITIES'
  | 'CREDIT'
  | 'DIGITAL_ASSETS'
  | 'INFLATION'
  | 'BONDS'
  | 'INFRASTRUCTURE'
  | 'ENERGY'
  | 'PROPERTY'
  | 'FREIGHT'
  | 'CARBON'
  | 'BESPOKE';

export type ContractFamily =
  | 'SWAP'
  | 'FORWARD'
  | 'FUTURES'
  | 'OPTION'
  | 'BARRIER_OPTION'
  | 'DIGITAL_OPTION'
  | 'SWAPTION'
  | 'TOTAL_RETURN_SWAP'
  | 'CREDIT_DEFAULT_SWAP'
  | 'SYNTHETIC_CDO'
  | 'VOLATILITY_SWAP'
  | 'REVENUE_INDEX_SWAP'
  | 'BESPOKE_STRUCTURE';

export type ContractStatus =
  | 'DRAFT'
  | 'STRUCTURED'
  | 'PRICED'
  | 'RFQ'
  | 'NEGOTIATING'
  | 'AGREED'
  | 'AUTHORISED'
  | 'EXECUTED'
  | 'LIVE'
  | 'PAYMENT_DUE'
  | 'PAYMENT_SETTLED'
  | 'MATURED'
  | 'AMENDED'
  | 'NOVATED'
  | 'COLLATERAL_REVIEW'
  | 'DISPUTED'
  | 'DEFAULTED'
  | 'TERMINATED'
  | 'CANCELLED'
  | 'EXPIRED'
  | 'RESTRUCTURED';

export type SettlementMethod = 'CASH_SETTLED' | 'PHYSICAL_SETTLEMENT' | 'TOKEN_SETTLED' | 'HYBRID';

export type ProvenanceType =
  | 'USER_DEFINED'
  | 'AI_PROPOSED'
  | 'MARKET_DATA'
  | 'MODEL_CALCULATED'
  | 'SYSTEM_DEFAULT';

export interface FieldProvenance {
  source: ProvenanceType;
  actor: string;
  timestamp: string;
  notes?: string;
  ambiguityWarning?: string;
}

export interface Counterparty {
  id: string;
  name: string;
  legalEntityIdentifier: string;
  jurisdiction: string;
  creditRating: string;
  role: 'BUYER' | 'SELLER' | 'FIXED_PAYER' | 'FLOATING_PAYER' | 'PROTECTION_BUYER' | 'PROTECTION_SELLER';
  nettingAgreementId?: string;
  marginAccountRef?: string;
}

export interface RSCLSpec {
  parties: {
    partyA: Counterparty;
    partyB: Counterparty;
    governingLaw: string;
    documentationFormat: string;
  };
  reference: {
    assetClass: AssetClass;
    primaryIdentifier: string;
    indexName: string;
    fallbackIndexName: string;
    sourceOracle: string;
    fixingFrequency: string;
    dayCountConvention: string;
  };
  notional: {
    amount: number;
    currency: string;
    amortizationSchedule?: { date: string; amount: number }[];
  };
  dates: {
    tradeDate: string;
    effectiveDate: string;
    maturityDate: string;
    settlementLagDays: number;
  };
  paymentLegs: {
    legId: string;
    payer: string;
    type: 'FIXED' | 'FLOATING' | 'OPTION_PAYOFF' | 'TOTAL_RETURN' | 'PERFORMANCE';
    rateOrFormula: string;
    fixedRatePercent?: number;
    spreadBps?: number;
    leverageMultiplier?: number;
    paymentFrequency: string;
  }[];
  observations: {
    observationType: 'DAILY_CLOSE' | 'PERIODIC_FIXING' | 'BARRIER_CONTINUOUS' | 'AVERAGING_WINDOW';
    dates: string[];
    fixingSource: string;
  };
  payoff: {
    formulaDescription: string;
    capPercent?: number;
    floorPercent?: number;
    barrierLevel?: number;
    barrierType?: 'KNOCK_IN' | 'KNOCK_OUT' | 'DOUBLE_BARRIER' | 'NONE';
    strikePrice?: number;
    participationRate?: number;
  };
  collateral: {
    required: boolean;
    initialMarginRequirementGbp: number;
    variationMarginThresholdGbp: number;
    eligibleCollateralTypes: string[];
    haircutSchedule: Record<string, number>;
  };
  governance: {
    disruptionHandling: string;
    earlyTerminationClause: string;
    resolutionJurisdiction: string;
  };
}

export interface PricingModelResult {
  modelName: string;
  modelVersion: string;
  cleanPrice: number;
  dirtyPrice: number;
  presentValueGbp: number;
  forwardValueGbp: number;
  discountFactor: number;
  impliedVolatility?: number;
  calculationRuntimeMs: number;
  calibrationStatus: 'CALIBRATED' | 'APPROXIMATED' | 'OVERRIDDEN';
  timestamp: string;
  inputs: Record<string, number | string>;
  confidenceScore: number;
}

export interface ContractGreeks {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  dv01: number;
  cs01: number;
  fxDelta: number;
  commodityDelta: number;
  inflationSensitivity: number;
  cvaGbp: number; // Credit Valuation Adjustment
  dvaGbp: number; // Debit Valuation Adjustment
  fvaGbp: number; // Funding Valuation Adjustment
  mvaGbp: number; // Margin Valuation Adjustment
  initialMarginGbp: number;
  variationMarginGbp: number;
  pfePeakGbp: number; // Potential Future Exposure peak
}

export interface CashFlowEvent {
  id: string;
  date: string;
  legId: string;
  payer: string;
  receiver: string;
  grossAmount: number;
  netAmount: number;
  currency: string;
  fixingRateUsed: number;
  status: 'SCHEDULED' | 'FIXED' | 'CALCULATED' | 'MARGINED' | 'SETTLED' | 'DEFAULTED';
  settlementTxHash?: string;
  timestamp: string;
}

export interface CollateralPosition {
  contractId: string;
  requiredInitialMarginGbp: number;
  requiredVariationMarginGbp: number;
  totalRequiredGbp: number;
  postedCollateralGbp: number;
  collateralAsset: string;
  haircutPercent: number;
  effectiveCollateralValueGbp: number;
  collateralStatus: 'FULLY_COLLATERALISED' | 'MARGIN_CALL_PENDING' | 'DEFICIT' | 'SURPLUS';
  lastMarginCallTimestamp: string;
}

export interface ContractAuditEvent {
  id: string;
  contractId: string;
  contractVersion: string;
  eventType: string;
  actor: string;
  details: string;
  previousHash: string;
  eventHash: string;
  timestamp: string;
}

export interface SyntheticContract {
  id: string;
  version: string;
  parentVersionId?: string;
  title: string;
  productType: string;
  contractFamily: ContractFamily;
  assetClass: AssetClass;
  underlyingReferenceAsset: string;
  referenceIndex: string;
  notional: number;
  currency: string;
  tradeDate: string;
  effectiveDate: string;
  maturityDate: string;
  counterparties: Counterparty[];
  governingLaw: string;
  settlementMethod: SettlementMethod;
  paymentScheduleFrequency: string;
  fixingMethodology: string;
  status: ContractStatus;
  
  // Provenance mapping for fields
  fieldProvenances: Record<string, FieldProvenance>;

  // Formal specification
  rsclSpec: RSCLSpec;

  // Human readable document
  humanReadableDocument: {
    summaryText: string;
    termSheetMarkdown: string;
    legalClausesMarkdown: string;
  };

  // Execution layer code representation
  executionCode?: {
    codeLanguage: 'SOLIDITY' | 'RUST_WASM' | 'INTERCHAIN' | 'PYTHON_EXECUTABLE';
    sourceCode: string;
    contractHash: string;
    executionEnvironment: string;
    oracleInputs: string[];
    executionStatus: 'PENDING_DEPLOY' | 'DEPLOYED' | 'ACTIVE' | 'EXPIRED';
  };

  // Valuation & Quantitative Pricing
  valuationMethodology: string;
  pricingResult: PricingModelResult;
  riskMetrics: ContractGreeks;

  // Schedules
  cashFlows: CashFlowEvent[];
  collateral: CollateralPosition;

  // Audit
  auditHistory: ContractAuditEvent[];
  dataProvenance: string;
  createdAt: string;
  updatedAt: string;
}

export interface ScenarioShock {
  id: string;
  name: string;
  description: string;
  rateShiftBps: number;
  fxShiftPercent: number;
  equityShiftPercent: number;
  commodityShiftPercent: number;
  creditSpreadShiftBps: number;
  volatilityShiftPercent: number;
  inflationShiftBps: number;
}

export interface MarketDataPoint {
  id: string;
  ticker: string;
  name: string;
  assetClass: AssetClass;
  value: number;
  currency: string;
  unit: string;
  timestamp: string;
  source: string;
  status: 'LIVE' | 'SIMULATED' | 'HISTORICAL' | 'SCENARIO' | 'MANUAL';
  confidenceScore: number;
}

export interface MarketQuote {
  id: string;
  contractId: string;
  contractTitle: string;
  bidPrice: number;
  askPrice: number;
  midPrice: number;
  dealer: string;
  notionalAvailable: number;
  validUntil: string;
  status: 'ACTIVE' | 'ACCEPTED' | 'EXPIRED' | 'WITHDRAWN';
}

export interface CDOTranche {
  id: string;
  name: string; // e.g., "Equity", "Mezzanine", "Senior", "Super-Senior"
  attachmentPointPercent: number;
  detachmentPointPercent: number;
  notionalGbp: number;
  couponBps: number;
  expectedLossPercent: number;
  presentValueGbp: number;
  riskRating: string;
}
