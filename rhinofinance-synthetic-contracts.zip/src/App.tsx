/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SyntheticContract, MarketDataPoint, MarketQuote, ContractStatus } from './types/contract';
import { FLAGSHIP_CONTRACTS, INITIAL_MARKET_DATA, INITIAL_QUOTES } from './data/flagshipContracts';
import { RhinoContractEngine } from './services/contractEngine';
import { Navbar } from './components/Navbar';
import { ContractDetailTerminal } from './components/ContractDetailTerminal';
import { ContractFactory } from './components/ContractFactory';
import { ContractComposer } from './components/ContractComposer';
import { AIDesigner } from './components/AIDesigner';
import { PricingRiskTerminal } from './components/PricingRiskTerminal';
import { ScenarioLab } from './components/ScenarioLab';
import { LifecycleReplay } from './components/LifecycleReplay';
import { ContractDiff } from './components/ContractDiff';
import { SyntheticMarket } from './components/SyntheticMarket';
import { CDOLab } from './components/CDOLab';
import { CollateralNetting } from './components/CollateralNetting';
import { RhinoAIAssistant } from './components/RhinoAIAssistant';
import { APIDocs } from './components/APIDocs';

export default function App() {
  const [contracts, setContracts] = useState<SyntheticContract[]>(FLAGSHIP_CONTRACTS);
  const [selectedContractId, setSelectedContractId] = useState<string>(FLAGSHIP_CONTRACTS[0].id);
  const [marketData, setMarketData] = useState<MarketDataPoint[]>(INITIAL_MARKET_DATA);
  const [quotes, setQuotes] = useState<MarketQuote[]>(INITIAL_QUOTES);
  const [activeTab, setActiveTab] = useState<string>('terminal');

  // Load state from backend API on mount if available
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const res = await fetch('/v1/contracts');
        if (res.ok) {
          const data = await res.json();
          if (data.contracts && data.contracts.length > 0) {
            setContracts(data.contracts);
            setSelectedContractId(data.contracts[0].id);
          }
        }
      } catch (err) {
        console.log('Using initial client state:', err);
      }
    };
    fetchInitialData();
  }, []);

  const selectedContract = contracts.find((c) => c.id === selectedContractId) || contracts[0];

  // Callbacks
  const handlePriceUpdate = async (contractId: string, modelName: string) => {
    const updatedContracts = contracts.map((c) => {
      if (c.id === contractId) {
        const newPricing = RhinoContractEngine.priceContract(c, modelName);
        const newGreeks = RhinoContractEngine.calculateGreeks(c, newPricing);
        return {
          ...c,
          valuationMethodology: modelName,
          pricingResult: newPricing,
          riskMetrics: newGreeks,
          updatedAt: new Date().toISOString()
        };
      }
      return c;
    });
    setContracts(updatedContracts);
  };

  const handleStatusTransition = (contractId: string, status: ContractStatus) => {
    const updatedContracts = contracts.map((c) => {
      if (c.id === contractId) {
        return RhinoContractEngine.transitionStatus(c, status, 'Desk Trader', `Transitioned to ${status}`);
      }
      return c;
    });
    setContracts(updatedContracts);
  };

  const handleAmend = (contractId: string, updatedFields: Partial<SyntheticContract>, reason: string) => {
    const updatedContracts = contracts.map((c) => {
      if (c.id === contractId) {
        return RhinoContractEngine.amendContract(c, updatedFields, 'Senior Structurer', reason);
      }
      return c;
    });
    setContracts(updatedContracts);
  };

  const handleContractCreated = (newContract: SyntheticContract) => {
    setContracts([newContract, ...contracts]);
    setSelectedContractId(newContract.id);
    setActiveTab('terminal');
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 selection:bg-amber-500 selection:text-slate-950 font-sans">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        contracts={contracts}
        selectedContractId={selectedContractId}
        setSelectedContractId={setSelectedContractId}
      />

      <main className="py-2">
        {activeTab === 'terminal' && (
          <ContractDetailTerminal
            contract={selectedContract}
            onPriceUpdate={handlePriceUpdate}
            onStatusChange={handleStatusTransition}
          />
        )}

        {activeTab === 'factory' && (
          <ContractFactory onContractCreated={handleContractCreated} />
        )}

        {activeTab === 'composer' && (
          <ContractComposer onContractCreated={handleContractCreated} />
        )}

        {activeTab === 'ai-designer' && (
          <AIDesigner onContractProposed={handleContractCreated} />
        )}

        {activeTab === 'pricing-risk' && (
          <PricingRiskTerminal
            contract={selectedContract}
            onPriceUpdate={handlePriceUpdate}
          />
        )}

        {activeTab === 'scenarios' && (
          <ScenarioLab contract={selectedContract} />
        )}

        {activeTab === 'lifecycle' && (
          <LifecycleReplay
            contract={selectedContract}
            onStatusTransition={handleStatusTransition}
          />
        )}

        {activeTab === 'diff' && (
          <ContractDiff
            contract={selectedContract}
            onAmend={handleAmend}
          />
        )}

        {activeTab === 'market' && (
          <SyntheticMarket quotes={quotes} contracts={contracts} />
        )}

        {activeTab === 'cdo-lab' && <CDOLab />}

        {activeTab === 'collateral' && <CollateralNetting contracts={contracts} />}

        {activeTab === 'ai-assistant' && <RhinoAIAssistant contract={selectedContract} />}

        {activeTab === 'api-docs' && <APIDocs />}
      </main>
    </div>
  );
}
