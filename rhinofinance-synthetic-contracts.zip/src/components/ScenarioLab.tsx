/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract, ScenarioShock } from '../types/contract';
import { PRESET_SCENARIOS } from '../data/flagshipContracts';
import { RhinoContractEngine } from '../services/contractEngine';
import { Activity, AlertTriangle, ShieldAlert, ArrowDown, ArrowUp } from 'lucide-react';

interface ScenarioLabProps {
  contract: SyntheticContract;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({ contract }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(PRESET_SCENARIOS[0].id);
  const [customRatesBps, setCustomRatesBps] = useState(150);
  const [customCommodityPct, setCustomCommodityPct] = useState(30);

  const currentPreset = PRESET_SCENARIOS.find((s) => s.id === selectedScenarioId) || PRESET_SCENARIOS[0];

  const shockToRun: ScenarioShock = {
    ...currentPreset,
    rateShiftBps: customRatesBps,
    commodityShiftPercent: customCommodityPct
  };

  const scenarioResult = RhinoContractEngine.runScenario(contract, shockToRun);

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <Activity className="w-5 h-5 text-amber-400" />
          <span>SYNTHETIC CONTRACT SCENARIO LAB & STRESS TESTER</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Multi-factor macroeconomic stress testing, credit shocks, energy volatility spikes, and liquidity crisis simulations.
        </p>
      </div>

      {/* Preset Scenario Selector Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        {PRESET_SCENARIOS.map((scen) => {
          const isSelected = selectedScenarioId === scen.id;
          return (
            <div
              key={scen.id}
              onClick={() => setSelectedScenarioId(scen.id)}
              className={`p-4 rounded border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-lg'
                  : 'bg-[#121826] border-[#232d42] text-slate-400 hover:border-slate-600'
              }`}
            >
              <div className="text-[10px] text-slate-500 font-bold uppercase">{scen.id}</div>
              <div className="text-xs text-white font-bold mt-1">{scen.name}</div>
              <p className="text-[11px] text-slate-400 mt-2 line-clamp-2">{scen.description}</p>
            </div>
          );
        })}
      </div>

      {/* Custom Slider Controls & Stress Output */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-5 text-xs">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">ADJUST SHOCK PARAMETERS</h2>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-400">Rate Shift (BPS):</span>
              <span className="text-amber-300 font-bold">+{customRatesBps} BPS</span>
            </div>
            <input
              type="range"
              min="-300"
              max="500"
              step="10"
              value={customRatesBps}
              onChange={(e) => setCustomRatesBps(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-400">Commodity / Power Shift (%):</span>
              <span className="text-amber-300 font-bold">+{customCommodityPct}%</span>
            </div>
            <input
              type="range"
              min="-50"
              max="150"
              step="5"
              value={customCommodityPct}
              onChange={(e) => setCustomCommodityPct(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>
        </div>

        {/* Stress Result Overview Card */}
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 text-xs">
          <div className="border-b border-[#1f293d] pb-3 flex justify-between items-center">
            <h2 className="text-xs font-bold text-amber-400">STRESS TEST IMPACT ANALYSIS</h2>
            <span
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                scenarioResult.pnlImpactGbp >= 0 ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}
            >
              STATUS: {scenarioResult.status}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">BASE PV</span>
              <div className="text-xl font-bold text-white mt-1">
                £{(contract.pricingResult?.presentValueGbp || 0).toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">STRESSED PV</span>
              <div className="text-xl font-bold text-amber-300 mt-1">
                £{scenarioResult.shockedPVGbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">P&L IMPACT</span>
              <div
                className={`text-xl font-bold mt-1 ${
                  scenarioResult.pnlImpactGbp >= 0 ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {scenarioResult.pnlImpactGbp >= 0 ? '+' : ''}
                £{scenarioResult.pnlImpactGbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">MARGIN CALL REQD</span>
              <div className="text-xl font-bold text-amber-400 mt-1">
                £{scenarioResult.marginCallGbp.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
