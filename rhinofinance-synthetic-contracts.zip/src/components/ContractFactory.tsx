/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract, AssetClass, ContractFamily, SettlementMethod } from '../types/contract';
import { RhinoContractEngine } from '../services/contractEngine';
import { Sliders, PlusCircle, Sparkles, Check, Play } from 'lucide-react';

interface ContractFactoryProps {
  onContractCreated: (newContract: SyntheticContract) => void;
}

export const ContractFactory: React.FC<ContractFactoryProps> = ({ onContractCreated }) => {
  const [assetClass, setAssetClass] = useState<AssetClass>('ENERGY');
  const [contractFamily, setContractFamily] = useState<ContractFamily>('SWAP');
  const [title, setTitle] = useState('RHINO NEW SYNTHETIC SWAP');
  const [underlying, setUnderlying] = useState('UK Wholesale Power Index');
  const [notional, setNotional] = useState(100000000);
  const [currency, setCurrency] = useState('GBP');
  const [maturity, setMaturity] = useState('2031-12-31');
  const [paymentFreq, setPaymentFreq] = useState('QUARTERLY');
  const [strike, setStrike] = useState(85.0);
  const [settlementMethod, setSettlementMethod] = useState<SettlementMethod>('CASH_SETTLED');
  const [initialMarginPct, setInitialMarginPct] = useState(5.0);

  const assetClasses: { id: AssetClass; label: string; defaultUnderlying: string }[] = [
    { id: 'RATES', label: 'Interest Rates', defaultUnderlying: 'BOE SONIA 3M Swap Rate' },
    { id: 'FX', label: 'FX Exposure', defaultUnderlying: 'GBP/USD FX Spot Index' },
    { id: 'EQUITIES', label: 'Equities', defaultUnderlying: 'FTSE 100 Index' },
    { id: 'COMMODITIES', label: 'Commodities', defaultUnderlying: 'London Metal Exchange Copper Spot' },
    { id: 'CREDIT', label: 'Credit', defaultUnderlying: 'iTraxx Europe Crossover 5Y' },
    { id: 'DIGITAL_ASSETS', label: 'Digital Assets', defaultUnderlying: 'Bitcoin (BTC/USD) Realised Volatility' },
    { id: 'INFLATION', label: 'Inflation', defaultUnderlying: 'UK RPI Inflation Index' },
    { id: 'BONDS', label: 'Bonds', defaultUnderlying: 'UK Gilt 10Y Benchmark Index' },
    { id: 'INFRASTRUCTURE', label: 'Infrastructure', defaultUnderlying: 'Manchester-London Rail Passenger Revenue' },
    { id: 'ENERGY', label: 'Energy', defaultUnderlying: 'N2EX UK Day-Ahead Electricity Index' },
    { id: 'PROPERTY', label: 'Property', defaultUnderlying: 'UK Commercial Property Capital Value Index' },
    { id: 'FREIGHT', label: 'Freight', defaultUnderlying: 'Baltic Dry Capesize Freight Index' },
    { id: 'CARBON', label: 'Carbon', defaultUnderlying: 'UK Emissions Allowance (UKA) Price' },
    { id: 'BESPOKE', label: 'Bespoke Custom', defaultUnderlying: 'Bespoke Synthetic Reference Index' }
  ];

  const handleAssetSelect = (ac: AssetClass) => {
    setAssetClass(ac);
    const found = assetClasses.find((a) => a.id === ac);
    if (found) setUnderlying(found.defaultUnderlying);
  };

  const handleCreate = () => {
    const id = `RHINO-FACTORY-${Date.now().toString().slice(-6)}`;
    const imRequired = Math.round(notional * (initialMarginPct / 100));

    const draftContract: Partial<SyntheticContract> = {
      id,
      version: '1.0',
      title: title || `RHINO ${assetClass} SYNTHETIC ${contractFamily}`,
      productType: `Synthetic ${assetClass} ${contractFamily}`,
      contractFamily,
      assetClass,
      underlyingReferenceAsset: underlying,
      referenceIndex: underlying.replace(/\s+/g, '-').toUpperCase(),
      notional,
      currency,
      tradeDate: new Date().toISOString().split('T')[0],
      effectiveDate: new Date().toISOString().split('T')[0],
      maturityDate: maturity,
      counterparties: [
        {
          id: 'CP-RHINO-DESK-01',
          name: 'RhinoFinance International Desk',
          legalEntityIdentifier: '213800RHINOFINL389102',
          jurisdiction: 'United Kingdom',
          creditRating: 'AA+',
          role: 'FIXED_PAYER'
        },
        {
          id: 'CP-INSTITUTIONAL-02',
          name: 'Institutional Capital Partners',
          legalEntityIdentifier: '549300INSTITUTIONAL02',
          jurisdiction: 'United Kingdom',
          creditRating: 'A',
          role: 'FLOATING_PAYER'
        }
      ],
      governingLaw: 'English Law',
      settlementMethod,
      paymentScheduleFrequency: paymentFreq,
      fixingMethodology: 'Arithmetic daily fixing over periodic observation window',
      status: 'STRUCTURED',
      fieldProvenances: {
        notional: { source: 'USER_DEFINED', actor: 'Factory User', timestamp: new Date().toISOString() },
        strike: { source: 'USER_DEFINED', actor: 'Factory User', timestamp: new Date().toISOString() }
      },
      rsclSpec: {
        parties: {
          partyA: { id: 'CP-RHINO-DESK-01', name: 'RhinoFinance', legalEntityIdentifier: '213800RHINOFINL389102', jurisdiction: 'United Kingdom', creditRating: 'AA+', role: 'FIXED_PAYER' },
          partyB: { id: 'CP-INSTITUTIONAL-02', name: 'Institutional Capital Partners', legalEntityIdentifier: '549300INSTITUTIONAL02', jurisdiction: 'United Kingdom', creditRating: 'A', role: 'FLOATING_PAYER' },
          governingLaw: 'English Law',
          documentationFormat: 'RSCL 2026 Factory Standard'
        },
        reference: {
          assetClass,
          primaryIdentifier: underlying.replace(/\s+/g, '-').toUpperCase(),
          indexName: underlying,
          fallbackIndexName: underlying + ' Fallback Index',
          sourceOracle: 'Rhino Multi-Oracle Service',
          fixingFrequency: paymentFreq,
          dayCountConvention: 'ACT/365'
        },
        notional: { amount: notional, currency },
        dates: { tradeDate: new Date().toISOString().split('T')[0], effectiveDate: new Date().toISOString().split('T')[0], maturityDate: maturity, settlementLagDays: 2 },
        paymentLegs: [
          { legId: 'LEG-1', payer: 'RhinoFinance', type: 'FIXED', fixedRatePercent: strike, rateOrFormula: `Fixed Strike: ${strike}`, paymentFrequency: paymentFreq },
          { legId: 'LEG-2', payer: 'Institutional Capital Partners', type: 'FLOATING', rateOrFormula: underlying, paymentFrequency: paymentFreq }
        ],
        observations: { observationType: 'PERIODIC_FIXING', dates: [], fixingSource: 'Rhino Oracle' },
        payoff: { formulaDescription: `Cashflow = Notional * (Floating_Index - Strike_${strike}) / Base_Scale`, strikePrice: strike },
        collateral: {
          required: true,
          initialMarginRequirementGbp: imRequired,
          variationMarginThresholdGbp: 500000,
          eligibleCollateralTypes: ['CASH_GBP', 'UK_GILTS', 'BOE_TOKENISED_DEPOSIT'],
          haircutSchedule: { CASH_GBP: 0 }
        },
        governance: { disruptionHandling: 'Fallback Oracle Applies', earlyTerminationClause: 'Standard ISDA Event', resolutionJurisdiction: 'London LCIA' }
      },
      humanReadableDocument: {
        summaryText: `Custom ${assetClass} Synthetic ${contractFamily} referencing ${underlying} with ${currency} ${(notional / 1e6).toFixed(1)}M notional.`,
        termSheetMarkdown: `### FACTORY GENERATED TERM SHEET\n**Contract**: ${title}\n**Notional**: ${currency} ${notional.toLocaleString()}\n**Strike**: ${strike}`,
        legalClausesMarkdown: '#### FACTORY GENERATED CLAUSES'
      },
      valuationMethodology: 'Black-76 Commodity Forward Engine',
      pricingResult: {
        modelName: 'Black-76 Commodity Forward Engine',
        modelVersion: 'v4.2.1',
        cleanPrice: 100.0,
        dirtyPrice: 100.4,
        presentValueGbp: 0,
        forwardValueGbp: 0,
        discountFactor: 0.92,
        impliedVolatility: 0.28,
        calculationRuntimeMs: 3.1,
        calibrationStatus: 'CALIBRATED',
        timestamp: new Date().toISOString(),
        inputs: { strike, notional },
        confidenceScore: 0.98
      },
      riskMetrics: {
        delta: Math.round(notional * 0.001),
        gamma: 1000,
        vega: Math.round(notional * 0.0015),
        theta: -5000,
        rho: 20000,
        dv01: 45000,
        cs01: 10000,
        fxDelta: currency === 'GBP' ? 0 : Math.round(notional * 0.1),
        commodityDelta: Math.round(notional * 0.001),
        inflationSensitivity: 0,
        cvaGbp: Math.round(notional * 0.005),
        dvaGbp: Math.round(notional * 0.001),
        fvaGbp: Math.round(notional * 0.002),
        mvaGbp: Math.round(notional * 0.001),
        initialMarginGbp: imRequired,
        variationMarginGbp: 0,
        pfePeakGbp: Math.round(imRequired * 1.8)
      },
      cashFlows: [],
      collateral: {
        contractId: id,
        requiredInitialMarginGbp: imRequired,
        requiredVariationMarginGbp: 0,
        totalRequiredGbp: imRequired,
        postedCollateralGbp: imRequired,
        collateralAsset: 'UK Gilts',
        haircutPercent: 2.0,
        effectiveCollateralValueGbp: imRequired,
        collateralStatus: 'FULLY_COLLATERALISED',
        lastMarginCallTimestamp: new Date().toISOString()
      },
      auditHistory: [
        {
          id: 'EVT-01',
          contractId: id,
          contractVersion: '1.0',
          eventType: 'CONTRACT_CREATED_IN_FACTORY',
          actor: 'Rhino Factory User',
          details: 'Contract created from first principles in factory.',
          previousHash: '0x0000',
          eventHash: `0x${Date.now().toString(16)}`,
          timestamp: new Date().toISOString()
        }
      ],
      dataProvenance: 'Rhino Synthetic Contract Factory Engine',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const finalContract = draftContract as SyntheticContract;
    onContractCreated(finalContract);
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      {/* Header */}
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <span>SYNTHETIC CONTRACT FACTORY</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Construct bespoke synthetic financial contracts across 14 institutional asset classes from first principles.
          </p>
        </div>
        <button
          onClick={handleCreate}
          className="flex items-center space-x-2 px-5 py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-lg"
        >
          <PlusCircle className="w-4 h-4" />
          <span>GENERATE & EXECUTE CONTRACT</span>
        </button>
      </div>

      {/* Asset Class Selector Grid */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">1. Select Reference Asset Class (14 Classes)</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 text-xs">
          {assetClasses.map((ac) => {
            const isSelected = assetClass === ac.id;
            return (
              <button
                key={ac.id}
                onClick={() => handleAssetSelect(ac.id)}
                className={`p-3 rounded border text-left transition-all ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow'
                    : 'bg-[#121826] border-[#232d42] text-slate-400 hover:border-slate-600 hover:text-slate-200'
                }`}
              >
                <div className="text-[10px] text-slate-500 font-bold">{ac.id}</div>
                <div className="text-xs mt-0.5 truncate">{ac.label}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Configuration Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-5 text-xs">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">2. Configure Contract Terms & Structure</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Contract Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white font-bold text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Underlying / Reference Index</label>
              <input
                type="text"
                value={underlying}
                onChange={(e) => setUnderlying(e.target.value)}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Notional Amount</label>
              <input
                type="number"
                value={notional}
                onChange={(e) => setNotional(Number(e.target.value))}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-300 font-bold text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Settlement Currency</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs focus:outline-none focus:border-amber-500"
              >
                <option value="GBP">GBP (£)</option>
                <option value="EUR">EUR (€)</option>
                <option value="USD">USD ($)</option>
                <option value="USDC">USDC (Tokenised)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Maturity Date</label>
              <input
                type="date"
                value={maturity}
                onChange={(e) => setMaturity(e.target.value)}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Fixed Strike / Benchmark Rate</label>
              <input
                type="number"
                step="0.01"
                value={strike}
                onChange={(e) => setStrike(Number(e.target.value))}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-400 font-bold text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Payment Frequency</label>
              <select
                value={paymentFreq}
                onChange={(e) => setPaymentFreq(e.target.value)}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs focus:outline-none focus:border-amber-500"
              >
                <option value="MONTHLY">Monthly</option>
                <option value="QUARTERLY">Quarterly</option>
                <option value="SEMI_ANNUALLY">Semi-Annually</option>
                <option value="ANNUALLY">Annually</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Initial Margin Requirement (%)</label>
              <input
                type="number"
                value={initialMarginPct}
                onChange={(e) => setInitialMarginPct(Number(e.target.value))}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Real-time Mathematical Model Preview */}
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 text-xs">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">3. Real-Time Payoff Preview</h2>
          <div className="bg-[#0b0f17] p-4 rounded border border-[#1f293d] space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-400">Notional:</span>
              <span className="text-white font-bold">{currency} {notional.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Strike / Benchmark:</span>
              <span className="text-amber-400 font-bold">{strike}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Est. Initial Margin:</span>
              <span className="text-emerald-400 font-bold">{currency} {((notional * initialMarginPct) / 100).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Est. Delta:</span>
              <span className="text-slate-200">{(notional * 0.001).toLocaleString()}</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={handleCreate}
              className="w-full py-3 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center justify-center space-x-2 shadow-lg"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>INSTANTIATE SYNTHETIC CONTRACT</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
