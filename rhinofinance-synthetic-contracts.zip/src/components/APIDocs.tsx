/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Code, Play, CheckCircle2 } from 'lucide-react';

export const APIDocs: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState('/v1/contracts');
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const endpoints = [
    { method: 'GET', path: '/v1/contracts', desc: 'List all active synthetic contracts' },
    { method: 'GET', path: '/v1/contracts/RHINO-UK-POWER-SWAP-01', desc: 'Get contract details by ID' },
    { method: 'GET', path: '/v1/market-data', desc: 'Get live synthetic market data feeds' },
    { method: 'GET', path: '/v1/quotes', desc: 'Get active dealer order book quotes' },
    { method: 'GET', path: '/v1/oracles', desc: 'Get financial oracle node consensus status' },
    { method: 'GET', path: '/v1/cdo-lab', desc: 'Get synthetic CDO tranche loss simulation' }
  ];

  const handleTestEndpoint = async () => {
    setLoading(true);
    setApiResponse(null);
    try {
      const res = await fetch(selectedEndpoint);
      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setApiResponse(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <Code className="w-5 h-5 text-amber-400" />
          <span>INSTITUTIONAL REST & WEBSOCKET API EXPLORER</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Complete programmatic access to contract state, quantitative pricing models, risk calculations, and oracle feeds.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
        {/* Endpoints List */}
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-5 space-y-3">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">REST ENDPOINTS</h2>
          <div className="space-y-2">
            {endpoints.map((ep) => (
              <div
                key={ep.path}
                onClick={() => setSelectedEndpoint(ep.path)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  selectedEndpoint === ep.path
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                    : 'bg-[#182030] border-[#29354d] text-slate-400 hover:border-slate-500'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                    {ep.method}
                  </span>
                  <span className="text-[10px] text-slate-500">{ep.path}</span>
                </div>
                <div className="text-[11px] text-slate-300 mt-1">{ep.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Response Panel */}
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-[#1f293d] pb-2">
            <span className="text-amber-400 font-bold">ENDPOINT: {selectedEndpoint}</span>
            <button
              onClick={handleTestEndpoint}
              disabled={loading}
              className="px-4 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center space-x-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>TEST CALL</span>
            </button>
          </div>

          <div className="bg-[#0a0d14] p-4 rounded border border-[#232d42] text-xs text-emerald-300 max-h-[500px] overflow-y-auto font-mono">
            {apiResponse ? (
              <pre>{apiResponse}</pre>
            ) : (
              <span className="text-slate-500">Click "TEST CALL" to execute endpoint query...</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
