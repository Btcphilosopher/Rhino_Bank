/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract, ContractStatus } from '../types/contract';
import { RhinoContractEngine } from '../services/contractEngine';
import { RotateCcw, Play, CheckCircle2, ShieldCheck, ArrowRight } from 'lucide-react';

interface LifecycleReplayProps {
  contract: SyntheticContract;
  onStatusTransition: (contractId: string, status: ContractStatus) => void;
}

export const LifecycleReplay: React.FC<LifecycleReplayProps> = ({ contract, onStatusTransition }) => {
  const replaySteps = RhinoContractEngine.replayLifecycle(contract);
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const activeStep = replaySteps[activeStepIndex] || replaySteps[0];

  const statuses: ContractStatus[] = [
    'DRAFT',
    'STRUCTURED',
    'PRICED',
    'RFQ',
    'NEGOTIATING',
    'AGREED',
    'EXECUTED',
    'LIVE',
    'PAYMENT_DUE',
    'PAYMENT_SETTLED',
    'MATURED'
  ];

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <RotateCcw className="w-5 h-5 text-amber-400" />
          <span>CONTRACT LIFECYCLE ENGINE & HISTORICAL REPLAY</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Automated lifecycle transitions, fixing observations, cashflow settlements, and step-by-step contract state replay.
        </p>
      </div>

      {/* 1. Executable Lifecycle Transitions */}
      <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 text-xs">
        <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">1. EXECUTABLE STATUS TRANSITION ENGINE</h2>
        <div className="flex flex-wrap items-center gap-2">
          {statuses.map((st) => {
            const isCurrent = contract.status === st;
            return (
              <button
                key={st}
                onClick={() => onStatusTransition(contract.id, st)}
                className={`px-3 py-1.5 rounded font-bold transition ${
                  isCurrent
                    ? 'bg-amber-500 text-slate-950 border border-amber-400 shadow-lg'
                    : 'bg-[#182030] text-slate-400 hover:text-white hover:bg-[#232e45] border border-[#29354d]'
                }`}
              >
                {st}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Historical Contract Replay Slider */}
      <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 text-xs">
        <div className="flex justify-between items-center border-b border-[#1f293d] pb-3">
          <h2 className="text-xs font-bold text-amber-400">2. CONTRACT REPLAY STEPPER (TIMELINE)</h2>
          <span className="text-slate-400">Step {activeStepIndex + 1} of {replaySteps.length}</span>
        </div>

        {/* Timeline Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
          {replaySteps.map((stepObj, idx) => {
            const isSelected = activeStepIndex === idx;
            return (
              <div
                key={idx}
                onClick={() => setActiveStepIndex(idx)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow'
                    : 'bg-[#182030] border-[#29354d] text-slate-400 hover:border-slate-500'
                }`}
              >
                <div className="text-[10px] text-slate-500 font-bold">STEP {stepObj.step}</div>
                <div className="font-bold text-white text-xs mt-0.5">{stepObj.name}</div>
                <div className="text-[10px] text-slate-400 mt-1">{stepObj.date}</div>
              </div>
            );
          })}
        </div>

        {/* Step Inspector Detail Card */}
        <div className="bg-[#0b0f17] p-5 rounded border border-[#1f293d] space-y-4">
          <div className="flex justify-between items-center border-b border-[#1a2333] pb-3">
            <span className="text-sm font-bold text-amber-400">{activeStep.name} ({activeStep.date})</span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
              {activeStep.status}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">HISTORICAL SPOT FIXING</span>
              <div className="text-lg font-bold text-white mt-0.5">{activeStep.spot}</div>
            </div>

            <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">REVALUATION PV</span>
              <div className="text-lg font-bold text-emerald-400 mt-0.5">
                £{activeStep.pvGbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">CUMULATIVE MARGIN POSTED</span>
              <div className="text-lg font-bold text-amber-300 mt-0.5">
                £{activeStep.marginGbp.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
