/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MarketQuote, SyntheticContract } from '../types/contract';
import { ShoppingBag, ArrowUpRight, ArrowDownRight, RefreshCw, Send } from 'lucide-react';

interface SyntheticMarketProps {
  quotes: MarketQuote[];
  contracts: SyntheticContract[];
}

export const SyntheticMarket: React.FC<SyntheticMarketProps> = ({ quotes, contracts }) => {
  const [rfqContractId, setRfqContractId] = useState(contracts[0]?.id || '');
  const [rfqNotional, setRfqNotional] = useState(50000000);
  const [rfqSent, setRfqSent] = useState(false);

  const handleSendRFQ = () => {
    setRfqSent(true);
    setTimeout(() => setRfqSent(false), 3000);
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <ShoppingBag className="w-5 h-5 text-amber-400" />
          <span>RHINO SYNTHETIC CONTRACT MARKET & RFQ TERMINAL</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Bilateral RFQ negotiation, institutional dealer order book, quote comparisons, novation, and position transfer.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
        {/* Request for Quote (RFQ) Form */}
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">REQUEST FOR QUOTE (RFQ)</h2>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1">Target Synthetic Contract</label>
            <select
              value={rfqContractId}
              onChange={(e) => setRfqContractId(e.target.value)}
              className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs font-bold"
            >
              {contracts.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1">RFQ Notional Capacity</label>
            <input
              type="number"
              value={rfqNotional}
              onChange={(e) => setRfqNotional(Number(e.target.value))}
              className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-300 font-bold text-xs"
            />
          </div>

          <button
            onClick={handleSendRFQ}
            className="w-full py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center justify-center space-x-2 shadow-lg"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{rfqSent ? 'RFQ BROADCASTED TO DEALERS' : 'BROADCAST BILATERAL RFQ'}</span>
          </button>
        </div>

        {/* Dealer Order Book / Active Quotes */}
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">ACTIVE DEALER QUOTES & ORDER BOOK</h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#182030] text-slate-400 border-b border-[#29354d]">
                <tr>
                  <th className="p-3">Dealer</th>
                  <th className="p-3">Contract</th>
                  <th className="p-3">Bid Price</th>
                  <th className="p-3">Ask Price</th>
                  <th className="p-3">Mid Price</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2738]">
                {quotes.map((q) => (
                  <tr key={q.id} className="hover:bg-[#182030]">
                    <td className="p-3 font-bold text-white">{q.dealer}</td>
                    <td className="p-3 text-slate-300">{q.contractTitle}</td>
                    <td className="p-3 text-emerald-400 font-bold">{q.bidPrice}</td>
                    <td className="p-3 text-red-400 font-bold">{q.askPrice}</td>
                    <td className="p-3 text-amber-300 font-bold">{q.midPrice}</td>
                    <td className="p-3">
                      <button className="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px]">
                        EXECUTE TRADE
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
