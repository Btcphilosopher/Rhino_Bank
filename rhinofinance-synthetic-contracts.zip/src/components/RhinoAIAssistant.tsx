/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract } from '../types/contract';
import { Bot, Send, Sparkles, Loader2, ShieldCheck } from 'lucide-react';

interface RhinoAIAssistantProps {
  contract: SyntheticContract;
}

export const RhinoAIAssistant: React.FC<RhinoAIAssistantProps> = ({ contract }) => {
  const [messages, setMessages] = useState<
    { role: 'user' | 'assistant'; content: string; timestamp: string }[]
  >([
    {
      role: 'assistant',
      content: `[CONTRACT FACT] Selected Contract: ${contract.title} (${contract.id})
[MODEL OUTPUT] Current PV: £${contract.pricingResult?.presentValueGbp?.toLocaleString()} GBP
[AI INTERPRETATION] Welcome to RHINO CONTRACT INTELLIGENCE. How can I assist with legal clause auditing, hedge suggestions, or quantitative model analysis?`,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = { role: 'user' as const, content: input, timestamp: new Date().toLocaleTimeString() };
    setMessages((prev) => [...prev, userMsg]);
    const currentInput = input;
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentInput,
          contractContext: contract
        })
      });

      const data = await response.json();
      if (data.answer) {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: data.answer,
            timestamp: new Date().toLocaleTimeString()
          }
        ]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
            <Bot className="w-5 h-5 text-amber-400" />
            <span>RHINO CONTRACT INTELLIGENCE (GEMINI AI ASSISTANT)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Audits legal clauses, explains risk, suggests hedges, and breaks down model assumptions with explicit provenance tags.
          </p>
        </div>
        <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold">
          PROVENANCE TAG ENFORCED
        </span>
      </div>

      {/* Chat Conversation History */}
      <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 max-h-[600px] overflow-y-auto">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`p-4 rounded border text-xs leading-relaxed space-y-1 ${
              m.role === 'user'
                ? 'bg-[#182030] border-[#29354d] text-white ml-12'
                : 'bg-[#0b0f17] border-[#1f293d] text-slate-200 mr-12'
            }`}
          >
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold border-b border-[#1f293d] pb-1 mb-2">
              <span>{m.role === 'user' ? 'DESK TRADER' : 'RHINO CONTRACT INTELLIGENCE'}</span>
              <span>{m.timestamp}</span>
            </div>
            <div className="whitespace-pre-wrap">{m.content}</div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center space-x-2 text-amber-400 text-xs p-3">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Rhino Contract Intelligence analyzing contract terms and risk models...</span>
          </div>
        )}
      </div>

      {/* Input Box */}
      <div className="flex space-x-3">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask AI to explain clauses, suggest hedges, or analyze risk..."
          className="flex-1 bg-[#121826] border border-[#232d42] p-3 rounded text-xs text-white focus:outline-none focus:border-amber-500"
        />
        <button
          onClick={handleSend}
          disabled={loading}
          className="px-6 py-3 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center space-x-2 shadow-lg"
        >
          <Send className="w-4 h-4" />
          <span>SEND</span>
        </button>
      </div>
    </div>
  );
};
