/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SyntheticContract } from '../types/contract';
import {
  FileText,
  Sliders,
  Sparkles,
  TrendingUp,
  Activity,
  GitCompare,
  RotateCcw,
  ShoppingBag,
  Layers,
  ShieldAlert,
  Bot,
  Code,
  Box
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  contracts: SyntheticContract[];
  selectedContractId: string;
  setSelectedContractId: (id: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  contracts,
  selectedContractId,
  setSelectedContractId
}) => {
  const selectedContract = contracts.find((c) => c.id === selectedContractId) || contracts[0];

  const navItems = [
    { id: 'terminal', label: 'Contract OS', icon: FileText },
    { id: 'factory', label: 'Contract Factory', icon: Sliders },
    { id: 'composer', label: 'Composer', icon: Box },
    { id: 'ai-designer', label: 'AI Designer', icon: Sparkles },
    { id: 'pricing-risk', label: 'Pricing & Risk', icon: TrendingUp },
    { id: 'scenarios', label: 'Scenario Lab', icon: Activity },
    { id: 'lifecycle', label: 'Lifecycle & Replay', icon: RotateCcw },
    { id: 'diff', label: 'Contract Diff', icon: GitCompare },
    { id: 'market', label: 'RFQ & Market', icon: ShoppingBag },
    { id: 'cdo-lab', label: 'Structured CDO', icon: Layers },
    { id: 'collateral', label: 'Collateral & Netting', icon: ShieldAlert },
    { id: 'ai-assistant', label: 'Rhino Intelligence', icon: Bot },
    { id: 'api-docs', label: 'API & Developer', icon: Code }
  ];

  // Calculate portfolio totals
  const totalNotionalGbp = contracts.reduce((sum, c) => sum + c.notional, 0);
  const totalPVGbp = contracts.reduce((sum, c) => sum + (c.pricingResult?.presentValueGbp || 0), 0);
  const totalIMGbp = contracts.reduce((sum, c) => sum + (c.riskMetrics?.initialMarginGbp || 0), 0);

  return (
    <header className="bg-[#0b0f19] border-b border-[#232d42] text-slate-100 sticky top-0 z-50 shadow-2xl">
      {/* Top Banner with Ticker & Stats */}
      <div className="max-w-[1700px] mx-auto px-4 py-2 flex flex-wrap items-center justify-between border-b border-[#1b2438] text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-gradient-to-r from-amber-600/20 to-amber-500/10 border border-amber-500/40 px-2.5 py-1 rounded text-amber-400 font-bold tracking-wider">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
            <span>RHINOFINANCE</span>
            <span className="text-[10px] text-slate-400 font-mono">SYNTHETIC CONTRACT OPERATING SYSTEM</span>
          </div>
          <div className="hidden lg:flex items-center space-x-4 font-mono text-slate-400">
            <span>PORTFOLIO NOTIONAL: <strong className="text-white">£{(totalNotionalGbp / 1e6).toFixed(0)}M</strong></span>
            <span>GROSS PV: <strong className="text-emerald-400">+£{(totalPVGbp / 1e6).toFixed(2)}M</strong></span>
            <span>POSTED IM: <strong className="text-amber-300">£{(totalIMGbp / 1e6).toFixed(1)}M</strong></span>
            <span className="flex items-center space-x-1 text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>ORACLES: 4/4 ONLINE</span>
            </span>
          </div>
        </div>

        {/* Contract Quick Selector */}
        <div className="flex items-center space-x-3 mt-1 sm:mt-0">
          <label className="text-slate-400 text-[11px] font-mono">ACTIVE CONTRACT:</label>
          <select
            value={selectedContractId}
            onChange={(e) => setSelectedContractId(e.target.value)}
            className="bg-[#141b2d] border border-[#2d3a54] text-amber-300 text-xs rounded px-3 py-1 font-mono focus:outline-none focus:border-amber-500"
          >
            {contracts.map((c) => (
              <option key={c.id} value={c.id}>
                [{c.assetClass}] {c.title} (v{c.version})
              </option>
            ))}
          </select>
          {selectedContract && (
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {selectedContract.status}
            </span>
          )}
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="max-w-[1700px] mx-auto px-4 flex items-center overflow-x-auto scrollbar-thin scrollbar-thumb-slate-700 py-1">
        <nav className="flex space-x-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center space-x-1.5 px-3 py-2 text-xs font-medium rounded transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-[#1e293b] text-amber-400 border border-amber-500/40 shadow-inner font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#131b2e]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
