/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract } from '../types/contract';
import { RhinoContractEngine } from '../services/contractEngine';
import { GitCompare, ArrowRight, RefreshCw } from 'lucide-react';

interface ContractDiffProps {
  contract: SyntheticContract;
  onAmend: (contractId: string, updatedFields: Partial<SyntheticContract>, reason: string) => void;
}

export const ContractDiff: React.FC<ContractDiffProps> = ({ contract, onAmend }) => {
  const [amendNotional, setAmendNotional] = useState(contract.notional * 1.2);
  const [amendReason, setAmendReason] = useState('Bilateral increase in notional capacity');

  // Create simulated v1.0 vs v1.1 comparison
  const v1 = contract;
  const v2Draft: SyntheticContract = {
    ...contract,
    version: '1.1',
    notional: amendNotional,
    pricingResult: {
      ...contract.pricingResult,
      presentValueGbp: Math.round(contract.pricingResult.presentValueGbp * 1.2)
    },
    riskMetrics: {
      ...contract.riskMetrics,
      delta: Math.round(contract.riskMetrics.delta * 1.2)
    }
  };

  const diffResult = RhinoContractEngine.compareVersions(v1, v2Draft);

  const handleApplyAmendment = () => {
    onAmend(contract.id, { notional: amendNotional }, amendReason);
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <GitCompare className="w-5 h-5 text-amber-400" />
          <span>CONTRACT VERSION LINEAGE & DIFFERENTIAL ENGINE</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Compare term modifications across version lineage v1.0 → v1.1 with automated PV difference and risk delta calculation.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
        {/* Amend Input Form */}
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">PROPOSE TERM AMENDMENT (v1.1)</h2>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1">Amended Notional Amount</label>
            <input
              type="number"
              value={amendNotional}
              onChange={(e) => setAmendNotional(Number(e.target.value))}
              className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-300 font-bold text-xs"
            />
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1">Amendment Reason</label>
            <input
              type="text"
              value={amendReason}
              onChange={(e) => setAmendReason(e.target.value)}
              className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-white text-xs"
            />
          </div>

          <button
            onClick={handleApplyAmendment}
            className="w-full py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-lg mt-2"
          >
            COMMIT AMENDMENT TO IMMUTABLE LINEAGE
          </button>
        </div>

        {/* Diff Result Breakdown */}
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6">
          <div className="border-b border-[#1f293d] pb-3 flex justify-between items-center">
            <h2 className="text-xs font-bold text-amber-400">DIFF SUMMARY: VERSION 1.0 vs VERSION 1.1</h2>
            <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold">
              IMMUTABLE LINEAGE
            </span>
          </div>

          {/* Value Difference Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">PV DIFFERENCE</span>
              <div className="text-xl font-bold text-emerald-400 mt-1">
                +£{diffResult.pvDiffGbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">DELTA DELTA</span>
              <div className="text-xl font-bold text-amber-300 mt-1">
                +{diffResult.deltaDiff.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">AMENDMENT STATUS</span>
              <div className="text-sm font-bold text-white mt-2">IMMUTABLE RECORD</div>
            </div>
          </div>

          {/* Term Differences Table */}
          <div className="border-t border-[#1f293d] pt-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-300">MODIFIED CONTRACT CLAUSES & TERMS</h3>
            <div className="bg-[#0b0f17] p-4 rounded border border-[#1f293d] space-y-2">
              {diffResult.termDiffs.map((td, idx) => (
                <div key={idx} className="flex justify-between items-center border-b border-[#182030] pb-2 text-xs">
                  <span className="text-white font-bold">{td.field}:</span>
                  <div className="flex items-center space-x-2">
                    <span className="text-red-400 line-through">{td.oldVal?.toLocaleString()}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-emerald-400 font-bold">{td.newVal?.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
