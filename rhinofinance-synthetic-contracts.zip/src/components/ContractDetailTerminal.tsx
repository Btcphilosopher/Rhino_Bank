/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract } from '../types/contract';
import {
  FileText,
  Code2,
  TrendingUp,
  Shield,
  Clock,
  CheckCircle2,
  Lock,
  Cpu,
  Layers,
  HelpCircle,
  Hash
} from 'lucide-react';

interface ContractDetailTerminalProps {
  contract: SyntheticContract;
  onPriceUpdate?: (contractId: string, modelName: string) => void;
  onStatusChange?: (contractId: string, status: string) => void;
}

export const ContractDetailTerminal: React.FC<ContractDetailTerminalProps> = ({
  contract,
  onPriceUpdate,
  onStatusChange
}) => {
  const [subTab, setSubTab] = useState<'legal' | 'rscl' | 'payoff' | 'pricing' | 'risk' | 'collateral' | 'cashflows' | 'code' | 'audit'>('legal');

  if (!contract) {
    return <div className="p-8 text-center text-slate-400">No contract selected</div>;
  }

  // Payoff chart generation
  const generatePayoffPoints = () => {
    const points: { spot: number; payoff: number }[] = [];
    const strike = contract.rsclSpec?.payoff?.strikePrice || contract.rsclSpec?.paymentLegs?.[0]?.fixedRatePercent || 84.5;
    const notional = contract.notional;

    for (let s = strike * 0.6; s <= strike * 1.4; s += (strike * 0.8) / 20) {
      let payoff = ((s - strike) / strike) * notional;
      if (contract.rsclSpec?.payoff?.capPercent) {
        payoff = Math.min(payoff, (contract.rsclSpec.payoff.capPercent / 100) * notional);
      }
      if (contract.rsclSpec?.payoff?.floorPercent) {
        payoff = Math.max(payoff, (contract.rsclSpec.payoff.floorPercent / 100) * notional);
      }
      points.push({ spot: parseFloat(s.toFixed(2)), payoff: Math.round(payoff) });
    }
    return points;
  };

  const payoffPoints = generatePayoffPoints();
  const maxPayoff = Math.max(...payoffPoints.map((p) => Math.abs(p.payoff))) || 1;

  return (
    <div className="p-6 space-y-6 max-w-[1700px] mx-auto text-slate-100">
      {/* Contract Header Overview Card */}
      <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-400 font-mono text-xs font-bold border border-amber-500/30">
                {contract.assetClass}
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-xs border border-slate-700">
                {contract.contractFamily}
              </span>
              <span className="text-slate-400 font-mono text-xs">ID: {contract.id}</span>
              <span className="text-slate-500 font-mono text-xs">v{contract.version}</span>
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-white mb-2">{contract.title}</h1>
            <p className="text-slate-300 text-sm max-w-4xl">{contract.humanReadableDocument?.summaryText}</p>
          </div>

          <div className="flex flex-col items-end space-y-2">
            <div className="flex items-center space-x-2">
              <span className="text-slate-400 text-xs font-mono">STATUS:</span>
              <span className="px-3 py-1 rounded font-mono text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {contract.status}
              </span>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400 font-mono">PRESENT VALUE (PV)</div>
              <div className={`text-xl font-bold font-mono ${contract.pricingResult?.presentValueGbp >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {contract.pricingResult?.presentValueGbp >= 0 ? '+' : ''}
                £{(contract.pricingResult?.presentValueGbp || 0).toLocaleString()} GBP
              </div>
            </div>
          </div>
        </div>

        {/* Essential Key Metadata Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mt-6 pt-6 border-t border-[#1e2738] font-mono text-xs">
          <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
            <span className="text-slate-400 text-[11px]">NOTIONAL</span>
            <div className="text-base font-bold text-white mt-0.5">
              {contract.currency} {(contract.notional / 1e6).toFixed(1)}M
            </div>
          </div>

          <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
            <span className="text-slate-400 text-[11px]">MATURITY</span>
            <div className="text-base font-bold text-amber-300 mt-0.5">{contract.maturityDate}</div>
          </div>

          <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
            <span className="text-slate-400 text-[11px]">SETTLEMENT</span>
            <div className="text-base font-bold text-white mt-0.5">{contract.settlementMethod}</div>
          </div>

          <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
            <span className="text-slate-400 text-[11px]">MODEL</span>
            <div className="text-sm font-bold text-slate-200 mt-0.5 truncate">{contract.valuationMethodology}</div>
          </div>

          <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
            <span className="text-slate-400 text-[11px]">POSTED COLLATERAL</span>
            <div className="text-base font-bold text-emerald-400 mt-0.5">
              £{((contract.collateral?.postedCollateralGbp || 0) / 1e6).toFixed(1)}M
            </div>
          </div>

          <div className="bg-[#182030] p-3 rounded border border-[#29354d]">
            <span className="text-slate-400 text-[11px]">DELTA GREEK</span>
            <div className="text-base font-bold text-amber-400 mt-0.5">
              {(contract.riskMetrics?.delta || 0).toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center space-x-1 border-b border-[#232d42] overflow-x-auto scrollbar-thin py-1">
        {[
          { id: 'legal', label: '1. Legal & Document', icon: FileText },
          { id: 'rscl', label: '2. Machine RSCL Spec', icon: Code2 },
          { id: 'payoff', label: '3. Payoff Engine', icon: Cpu },
          { id: 'pricing', label: '4. Pricing Model', icon: TrendingUp },
          { id: 'risk', label: '5. Risk Waterfall', icon: Shield },
          { id: 'collateral', label: '6. Collateral', icon: Lock },
          { id: 'cashflows', label: '7. Cashflow Ledger', icon: Clock },
          { id: 'code', label: '8. Smart Execution', icon: Layers },
          { id: 'audit', label: '9. Cryptographic Audit', icon: Hash }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-mono font-medium rounded-t border-t border-x transition-all ${
                isActive
                  ? 'bg-[#141a26] text-amber-400 border-[#2b3852] border-b-transparent shadow'
                  : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200 hover:bg-[#121824]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Sub-Tab 1: Legal & Document View */}
      {subTab === 'legal' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-[#1f293d] pb-4">
              <h2 className="text-lg font-bold font-mono text-amber-400 flex items-center space-x-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <span>HUMAN-READABLE SYNTHETIC CONTRACT TERM SHEET</span>
              </h2>
              <span className="text-xs font-mono text-slate-400">Governing Law: {contract.governingLaw}</span>
            </div>

            <div className="prose prose-invert max-w-none text-slate-300 text-xs font-mono leading-relaxed bg-[#0b0f17] p-5 rounded border border-[#1f293d]">
              <pre className="whitespace-pre-wrap font-mono text-xs">{contract.humanReadableDocument?.termSheetMarkdown}</pre>
            </div>

            <div className="border-t border-[#1f293d] pt-4">
              <h3 className="text-sm font-bold font-mono text-slate-200 mb-3">AUTHORITATIVE LEGAL CLAUSES</h3>
              <div className="prose prose-invert max-w-none text-slate-300 text-xs font-mono bg-[#0b0f17] p-5 rounded border border-[#1f293d]">
                <pre className="whitespace-pre-wrap font-mono text-xs">{contract.humanReadableDocument?.legalClausesMarkdown}</pre>
              </div>
            </div>
          </div>

          {/* Counterparties & Legal Metadata */}
          <div className="space-y-6">
            <div className="bg-[#121826] border border-[#232d42] rounded-lg p-5 space-y-4 font-mono text-xs">
              <h3 className="text-sm font-bold text-amber-400 border-b border-[#1f293d] pb-2">COUNTERPARTY LEI & CREDIT</h3>
              {contract.counterparties?.map((cp) => (
                <div key={cp.id} className="bg-[#182030] p-3 rounded border border-[#29354d] space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">{cp.name}</span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {cp.role}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400">LEI: {cp.legalEntityIdentifier}</div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-400">Jurisdiction:</span>
                    <span className="text-slate-200">{cp.jurisdiction}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-400">Credit Rating:</span>
                    <span className="text-emerald-400 font-bold">{cp.creditRating}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Field Provenance Metadata */}
            <div className="bg-[#121826] border border-[#232d42] rounded-lg p-5 space-y-3 font-mono text-xs">
              <h3 className="text-sm font-bold text-amber-400 border-b border-[#1f293d] pb-2">FIELD PROVENANCE & ORIGIN</h3>
              {Object.entries(contract.fieldProvenances || {}).map(([field, prov]) => (
                <div key={field} className="flex items-start justify-between border-b border-[#1a2333] pb-2 text-[11px]">
                  <div>
                    <span className="text-white font-bold">{field}</span>
                    <div className="text-slate-400 text-[10px]">{prov.actor} ({prov.timestamp.split('T')[0]})</div>
                  </div>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold">
                    {prov.source}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: RSCL Machine Specification */}
      {subTab === 'rscl' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-[#1f293d] pb-3">
            <h2 className="text-base font-bold text-amber-400 flex items-center space-x-2">
              <Code2 className="w-4 h-4 text-amber-400" />
              <span>RHINO SYNTHETIC CONTRACT LANGUAGE (RSCL) MACHINE SPECIFICATION</span>
            </h2>
            <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/30">
              STRONGLY TYPED VALIDATED SCHEMA
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Machine-readable JSON schema defining parties, reference index, notional, payment legs, observation windows, payoff formula, collateral, and governance clauses.
          </p>

          <div className="bg-[#0a0d14] p-5 rounded border border-[#232d42] overflow-x-auto max-h-[600px] text-xs text-emerald-300">
            <pre>{JSON.stringify(contract.rsclSpec, null, 2)}</pre>
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Payoff Engine */}
      {subTab === 'payoff' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 font-mono">
          <div className="border-b border-[#1f293d] pb-3">
            <h2 className="text-base font-bold text-amber-400">MATHEMATICAL PAYOFF ENGINE & BOUNDARY SIMULATOR</h2>
            <p className="text-xs text-slate-400 mt-1">
              Formula: {contract.rsclSpec?.payoff?.formulaDescription}
            </p>
          </div>

          {/* SVG Payoff Graph */}
          <div className="bg-[#0b0f17] p-6 rounded border border-[#1f293d] space-y-4">
            <div className="text-xs text-slate-300 font-bold flex justify-between">
              <span>PAYOFF CURVE (£ GBP) vs UNDERLYING SPOT INDEX</span>
              <span className="text-amber-400">STRIKE: {contract.rsclSpec?.payoff?.strikePrice || contract.rsclSpec?.paymentLegs?.[0]?.fixedRatePercent}</span>
            </div>

            <div className="h-64 w-full flex items-end space-x-2 pt-6 pb-2 px-2 border-b border-l border-[#2e3c54] relative">
              {/* Zero line */}
              <div className="absolute w-full border-t border-dashed border-slate-600 top-1/2 left-0 pointer-events-none"></div>

              {payoffPoints.map((pt, idx) => {
                const heightPct = Math.abs(pt.payoff) / maxPayoff * 45;
                const isPositive = pt.payoff >= 0;
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center group relative h-full justify-center">
                    <div
                      className={`w-full rounded-t transition-all ${
                        isPositive ? 'bg-emerald-500/80 group-hover:bg-emerald-400' : 'bg-red-500/80 group-hover:bg-red-400'
                      }`}
                      style={{
                        height: `${Math.max(4, heightPct)}%`,
                        marginBottom: isPositive ? '0' : 'auto',
                        marginTop: isPositive ? 'auto' : '0'
                      }}
                    ></div>
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-2 hidden group-hover:flex flex-col bg-slate-900 text-[10px] p-2 rounded border border-slate-700 z-20 whitespace-nowrap">
                      <span>Spot: {pt.spot}</span>
                      <span className={isPositive ? 'text-emerald-400' : 'text-red-400'}>
                        Payoff: £{pt.payoff.toLocaleString()}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Min Index: {(payoffPoints[0]?.spot || 0)}</span>
              <span className="text-amber-300 font-bold">STRIKE PRICE</span>
              <span>Max Index: {(payoffPoints[payoffPoints.length - 1]?.spot || 0)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 4: Pricing Model */}
      {subTab === 'pricing' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
          <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6">
            <div className="border-b border-[#1f293d] pb-3 flex justify-between items-center">
              <div>
                <h2 className="text-base font-bold text-amber-400">QUANTITATIVE PRICING ENGINE OUTPUT</h2>
                <span className="text-xs text-slate-400">Model: {contract.pricingResult?.modelName}</span>
              </div>
              <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
                {contract.pricingResult?.calibrationStatus}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
                <span className="text-slate-400 text-[11px]">CLEAN PRICE</span>
                <div className="text-xl font-bold text-white mt-1">{contract.pricingResult?.cleanPrice} %</div>
              </div>

              <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
                <span className="text-slate-400 text-[11px]">DIRTY PRICE</span>
                <div className="text-xl font-bold text-white mt-1">{contract.pricingResult?.dirtyPrice} %</div>
              </div>

              <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
                <span className="text-slate-400 text-[11px]">FORWARD VALUE</span>
                <div className="text-xl font-bold text-amber-300 mt-1">
                  £{((contract.pricingResult?.forwardValueGbp || 0) / 1e6).toFixed(2)}M
                </div>
              </div>

              <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
                <span className="text-slate-400 text-[11px]">DISCOUNT FACTOR</span>
                <div className="text-xl font-bold text-slate-200 mt-1">{contract.pricingResult?.discountFactor}</div>
              </div>

              <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
                <span className="text-slate-400 text-[11px]">IMPLIED VOLATILITY</span>
                <div className="text-xl font-bold text-slate-200 mt-1">
                  {((contract.pricingResult?.impliedVolatility || 0) * 100).toFixed(1)} %
                </div>
              </div>

              <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
                <span className="text-slate-400 text-[11px]">RUNTIME LATENCY</span>
                <div className="text-xl font-bold text-emerald-400 mt-1">{contract.pricingResult?.calculationRuntimeMs} ms</div>
              </div>
            </div>

            <div className="border-t border-[#1f293d] pt-4">
              <h3 className="text-xs font-bold text-slate-300 mb-2">MODEL CALIBRATION INPUT PARAMETERS</h3>
              <div className="bg-[#0b0f17] p-4 rounded border border-[#1f293d] grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                {Object.entries(contract.pricingResult?.inputs || {}).map(([key, val]) => (
                  <div key={key} className="flex justify-between border-b border-[#182030] pb-1">
                    <span className="text-slate-400">{key}:</span>
                    <span className="text-amber-300 font-bold">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-[#121826] border border-[#232d42] rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-bold text-amber-400 border-b border-[#1f293d] pb-2">MODEL QUALITY & PROVENANCE</h3>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Confidence Score:</span>
                <span className="text-emerald-400 font-bold">{((contract.pricingResult?.confidenceScore || 0) * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Engine Version:</span>
                <span className="text-slate-200">{contract.pricingResult?.modelVersion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Timestamp:</span>
                <span className="text-slate-400 text-[10px]">{contract.pricingResult?.timestamp}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 5: Risk Waterfall */}
      {subTab === 'risk' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 font-mono">
          <div className="border-b border-[#1f293d] pb-3 flex justify-between items-center">
            <h2 className="text-base font-bold text-amber-400">CONTRACT RISK WATERFALL & SENSITIVITY METRICS</h2>
            <span className="text-xs text-slate-400">Institutional XVA & Greek Sensitivity Suite</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400">DELTA (1 UNIT MOVE)</span>
              <div className="text-xl font-bold text-amber-400 mt-1">
                £{(contract.riskMetrics?.delta || 0).toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400">VEGA (1% VOL MOVE)</span>
              <div className="text-xl font-bold text-amber-400 mt-1">
                £{(contract.riskMetrics?.vega || 0).toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400">DV01 (1 BPS RATE)</span>
              <div className="text-xl font-bold text-amber-400 mt-1">
                £{(contract.riskMetrics?.dv01 || 0).toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400">CS01 (1 BPS CREDIT)</span>
              <div className="text-xl font-bold text-amber-400 mt-1">
                £{(contract.riskMetrics?.cs01 || 0).toLocaleString()}
              </div>
            </div>
          </div>

          {/* XVA Table */}
          <div className="border-t border-[#1f293d] pt-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-300">XVA ADJUSTMENTS BREAKDOWN</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[11px]">CVA (Credit Risk)</span>
                <div className="text-base font-bold text-red-400 mt-0.5">
                  -£{(contract.riskMetrics?.cvaGbp || 0).toLocaleString()}
                </div>
              </div>

              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[11px]">DVA (Debit Risk)</span>
                <div className="text-base font-bold text-emerald-400 mt-0.5">
                  +£{(contract.riskMetrics?.dvaGbp || 0).toLocaleString()}
                </div>
              </div>

              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[11px]">FVA (Funding)</span>
                <div className="text-base font-bold text-amber-400 mt-0.5">
                  -£{(contract.riskMetrics?.fvaGbp || 0).toLocaleString()}
                </div>
              </div>

              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[11px]">MVA (Margin)</span>
                <div className="text-base font-bold text-amber-400 mt-0.5">
                  -£{(contract.riskMetrics?.mvaGbp || 0).toLocaleString()}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 6: Collateral */}
      {subTab === 'collateral' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 font-mono">
          <div className="border-b border-[#1f293d] pb-3 flex justify-between items-center">
            <h2 className="text-base font-bold text-amber-400">COLLATERAL & MARGIN REQUIREMENTS</h2>
            <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
              {contract.collateral?.collateralStatus}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
            <div className="bg-[#182030] p-4 rounded border border-[#29354d] space-y-2">
              <span className="text-slate-400">INITIAL MARGIN (IM) REQUIRED</span>
              <div className="text-2xl font-bold text-amber-300">
                £{((contract.collateral?.requiredInitialMarginGbp || 0) / 1e6).toFixed(2)}M
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d] space-y-2">
              <span className="text-slate-400">VARIATION MARGIN (VM) REQUIRED</span>
              <div className="text-2xl font-bold text-amber-300">
                £{((contract.collateral?.requiredVariationMarginGbp || 0) / 1e6).toFixed(2)}M
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d] space-y-2">
              <span className="text-slate-400">EFFECTIVE POSTED COLLATERAL</span>
              <div className="text-2xl font-bold text-emerald-400">
                £{((contract.collateral?.effectiveCollateralValueGbp || 0) / 1e6).toFixed(2)}M
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 7: Cashflow Ledger */}
      {subTab === 'cashflows' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 font-mono">
          <h2 className="text-base font-bold text-amber-400 border-b border-[#1f293d] pb-3">PERIODIC CASHFLOW & SETTLEMENT LEDGER</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#182030] text-slate-400 uppercase border-b border-[#29354d]">
                <tr>
                  <th className="p-3">Cashflow ID</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Payer</th>
                  <th className="p-3">Gross Amount</th>
                  <th className="p-3">Fixing Rate</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Tx Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2738] text-slate-200">
                {contract.cashFlows?.map((cf) => (
                  <tr key={cf.id} className="hover:bg-[#182030]">
                    <td className="p-3 font-bold text-amber-300">{cf.id}</td>
                    <td className="p-3">{cf.date}</td>
                    <td className="p-3">{cf.payer}</td>
                    <td className="p-3 font-bold text-white">
                      {cf.currency} {cf.grossAmount.toLocaleString()}
                    </td>
                    <td className="p-3 text-amber-400">{cf.fixingRateUsed}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {cf.status}
                      </span>
                    </td>
                    <td className="p-3 text-[10px] text-slate-400">{cf.settlementTxHash || 'Pending'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 8: Code */}
      {subTab === 'code' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 font-mono">
          <div className="flex justify-between items-center border-b border-[#1f293d] pb-3">
            <h2 className="text-base font-bold text-amber-400">EXECUTABLE SMART CONTRACT LOGIC & ORACLES</h2>
            <span className="text-xs text-slate-400">Hash: {contract.executionCode?.contractHash}</span>
          </div>

          <div className="bg-[#0a0d14] p-5 rounded border border-[#232d42] text-xs text-blue-300">
            <pre>{contract.executionCode?.sourceCode}</pre>
          </div>
        </div>
      )}

      {/* Sub-Tab 9: Cryptographic Audit */}
      {subTab === 'audit' && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 font-mono">
          <h2 className="text-base font-bold text-amber-400 border-b border-[#1f293d] pb-3">IMMUTABLE CRYPTOGRAPHIC AUDIT LINEAGE</h2>
          <div className="space-y-3">
            {contract.auditHistory?.map((evt) => (
              <div key={evt.id} className="bg-[#182030] p-4 rounded border border-[#29354d] space-y-1.5 text-xs">
                <div className="flex justify-between text-amber-300 font-bold">
                  <span>{evt.eventType}</span>
                  <span className="text-slate-400 text-[11px]">{evt.timestamp}</span>
                </div>
                <div className="text-slate-200">{evt.details}</div>
                <div className="flex justify-between text-[10px] text-slate-500 border-t border-[#232f45] pt-1">
                  <span>Actor: {evt.actor}</span>
                  <span>Hash: {evt.eventHash}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
