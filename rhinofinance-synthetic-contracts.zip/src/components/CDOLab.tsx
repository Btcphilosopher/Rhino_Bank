/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RhinoContractEngine } from '../services/contractEngine';
import { Layers, Play, BarChart2 } from 'lucide-react';

export const CDOLab: React.FC = () => {
  const [portfolioNotional, setPortfolioNotional] = useState(100000000);
  const [cdoData, setCdoData] = useState(() => RhinoContractEngine.simulateCDOTranches(portfolioNotional));

  const handleSimulate = () => {
    setCdoData(RhinoContractEngine.simulateCDOTranches(portfolioNotional));
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-amber-400" />
            <span>STRUCTURED SYNTHETICS LAB (SYNTHETIC CDO & TRANCHES)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Model synthetic credit basket default waterfalls, attachment/detachment points, and Monte Carlo tranche loss distributions.
          </p>
        </div>
        <button
          onClick={handleSimulate}
          className="flex items-center space-x-2 px-5 py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-lg"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>RUN DEFAULT LOSS SIMULATION</span>
        </button>
      </div>

      {/* Tranches Table */}
      <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 text-xs">
        <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">SYNTHETIC CDO TRANCHE STRUCTURE & WATERFALL</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#182030] text-slate-400 border-b border-[#29354d]">
              <tr>
                <th className="p-3">Tranche Name</th>
                <th className="p-3">Attachment - Detachment</th>
                <th className="p-3">Tranche Notional</th>
                <th className="p-3">Coupon (bps)</th>
                <th className="p-3">Expected Loss (%)</th>
                <th className="p-3">Risk Rating</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2738]">
              {cdoData.tranches.map((tr) => (
                <tr key={tr.id} className="hover:bg-[#182030]">
                  <td className="p-3 font-bold text-white">{tr.name}</td>
                  <td className="p-3 text-amber-300 font-bold">{tr.attachmentPointPercent}% - {tr.detachmentPointPercent}%</td>
                  <td className="p-3 text-slate-200">£{(tr.notionalGbp / 1e6).toFixed(1)}M</td>
                  <td className="p-3 text-emerald-400 font-bold">{tr.couponBps} bps</td>
                  <td className="p-3 text-red-400 font-bold">{tr.expectedLossPercent}%</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[10px]">
                      {tr.riskRating}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
