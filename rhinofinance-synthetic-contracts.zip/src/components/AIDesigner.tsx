/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract } from '../types/contract';
import { Sparkles, ArrowRight, ShieldAlert, CheckCircle2, Bot, AlertTriangle, Loader2 } from 'lucide-react';

interface AIDesignerProps {
  onContractProposed: (contract: SyntheticContract) => void;
}

export const AIDesigner: React.FC<AIDesignerProps> = ({ onContractProposed }) => {
  const [prompt, setPrompt] = useState(
    'Create a five-year synthetic contract paying the difference between UK electricity prices and a fixed strike of £84.50/MWh, settled quarterly in GBP for £500m notional.'
  );
  const [loading, setLoading] = useState(false);
  const [proposedContract, setProposedContract] = useState<SyntheticContract | null>(null);
  const [ambiguityWarnings, setAmbiguityWarnings] = useState<string[]>([]);
  const [step, setStep] = useState<'PROMPT' | 'PROPOSED' | 'REVIEWED' | 'EXECUTED'>('PROMPT');

  const handleGenerate = async () => {
    setLoading(true);
    setAmbiguityWarnings([]);
    try {
      const response = await fetch('/api/ai/design-contract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userPrompt: prompt })
      });

      const data = await response.json();
      if (data.proposedContract) {
        setProposedContract(data.proposedContract as SyntheticContract);
        setAmbiguityWarnings(data.ambiguityWarnings || []);
        setStep('PROPOSED');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAuthoriseAndExecute = () => {
    if (proposedContract) {
      const executed = {
        ...proposedContract,
        status: 'EXECUTED' as const,
        updatedAt: new Date().toISOString()
      };
      setStep('EXECUTED');
      onContractProposed(executed);
    }
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      {/* Header */}
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span>NATURAL-LANGUAGE AI CONTRACT DESIGNER (GEMINI 3.8)</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Controlled AI-driven contract structuring pipeline with strict human authorisation governance and explicit field provenances.
        </p>
      </div>

      {/* Controlled Governance Pipeline Banner */}
      <div className="bg-[#182030] border border-[#2d3a54] p-4 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs">
        {[
          { id: 'PROMPT', name: '1. USER REQUEST' },
          { id: 'PROPOSED', name: '2. AI INTERPRETATION' },
          { id: 'SPEC', name: '3. CONTRACT SPEC' },
          { id: 'REVIEWED', name: '4. HUMAN REVIEW' },
          { id: 'EXECUTED', name: '5. AUTHORISED EXECUTION' }
        ].map((p, idx) => (
          <div key={p.id} className="flex items-center space-x-2">
            <span
              className={`px-3 py-1 rounded font-bold ${
                step === p.id
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-[#121826] text-slate-400 border border-[#232d42]'
              }`}
            >
              {p.name}
            </span>
            {idx < 4 && <ArrowRight className="w-3.5 h-3.5 text-slate-500" />}
          </div>
        ))}
      </div>

      {/* Input Prompt Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-4 text-xs">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">WRITE NATURAL LANGUAGE CONTRACT REQUEST</h2>

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            className="w-full bg-[#182030] border border-[#2d3a54] p-3 rounded text-white text-xs focus:outline-none focus:border-amber-500 resize-none font-mono"
            placeholder="Describe your desired synthetic exposure in natural language..."
          ></textarea>

          <div className="flex justify-between items-center pt-2">
            <span className="text-[11px] text-slate-400">Powered by Gemini 3.8 Flash Quantitative Structurer</span>
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="px-5 py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center space-x-2 shadow-lg disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{loading ? 'AI STRUCTURING...' : 'GENERATE FORMAL PROPOSAL'}</span>
            </button>
          </div>
        </div>

        {/* Safety & Ambiguity Guidelines */}
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-3 text-xs">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2 flex items-center space-x-1.5">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>AI GOVERNANCE CONSTITUTION</span>
          </h2>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            AI structurers generate proposals with machine RSCL specifications and provenance tags.
            <strong> AI NEVER EXECUTED AUTOMATICALLY.</strong> Every clause requires explicit human quant review and authorisation before binding execution.
          </p>
        </div>
      </div>

      {/* Proposed Contract Output & Human Approval View */}
      {proposedContract && (
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 text-xs">
          <div className="flex justify-between items-center border-b border-[#1f293d] pb-3">
            <div>
              <h2 className="text-base font-bold text-amber-400">AI PROPOSED FORMAL CONTRACT SPECIFICATION</h2>
              <span className="text-slate-400 text-[11px]">Proposed ID: {proposedContract.id}</span>
            </div>
            <span className="px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold">
              AI_PROPOSED (PENDING HUMAN REVIEW)
            </span>
          </div>

          {/* Ambiguity Warnings if any */}
          {ambiguityWarnings.length > 0 && (
            <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded text-amber-300 space-y-1">
              <div className="font-bold flex items-center space-x-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>IDENTIFIED CLAUSE AMBIGUITIES (REQUIRES HUMAN CLARIFICATION)</span>
              </div>
              <ul className="list-disc list-inside text-[11px] text-amber-200">
                {ambiguityWarnings.map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">PROPOSED TITLE</span>
              <div className="text-sm font-bold text-white mt-1">{proposedContract.title}</div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">NOTIONAL & CURRENCY</span>
              <div className="text-sm font-bold text-amber-300 mt-1">
                {proposedContract.currency} {proposedContract.notional?.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">ASSET CLASS</span>
              <div className="text-sm font-bold text-emerald-400 mt-1">{proposedContract.assetClass}</div>
            </div>
          </div>

          <div className="bg-[#0b0f17] p-4 rounded border border-[#1f293d]">
            <h3 className="text-xs font-bold text-slate-300 mb-2">TERM SHEET SUMMARY</h3>
            <p className="text-slate-300">{proposedContract.humanReadableDocument?.summaryText}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 border-t border-[#1f293d] pt-4">
            <button
              onClick={() => setProposedContract(null)}
              className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
            >
              REJECT / RE-PROMPT
            </button>
            <button
              onClick={handleAuthoriseAndExecute}
              className="px-5 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center space-x-2 shadow-lg"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>AUTHORISE & EXECUTE CONTRACT</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
