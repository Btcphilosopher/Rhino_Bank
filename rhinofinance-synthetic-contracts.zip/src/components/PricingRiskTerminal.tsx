/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyntheticContract } from '../types/contract';
import { RhinoContractEngine } from '../services/contractEngine';
import { TrendingUp, Shield, Cpu, RefreshCw, BarChart2 } from 'lucide-react';

interface PricingRiskTerminalProps {
  contract: SyntheticContract;
  onPriceUpdate: (contractId: string, modelName: string) => void;
}

export const PricingRiskTerminal: React.FC<PricingRiskTerminalProps> = ({ contract, onPriceUpdate }) => {
  const [selectedModel, setSelectedModel] = useState(contract.valuationMethodology || 'Black-76 Commodity Forward Engine');
  const [spotOverride, setSpotOverride] = useState(88.2);
  const [rateOverride, setRateOverride] = useState(0.0425);
  const [volOverride, setVolOverride] = useState(0.324);
  const [calculating, setCalculating] = useState(false);

  const availableModels = [
    'Black-76 Commodity Forward Engine',
    'Black-Scholes Vanilla Options Framework',
    'Bachelier Normal Volatility Model',
    '10,000 Path Monte Carlo Simulation Engine',
    'Heston Stochastic Volatility Model with Jumps',
    'SABR Volatility Surface Interpolator',
    'Hull-White 1-Factor Short Rate Model',
    'Bespoke Convenience-Yield Commodity Model'
  ];

  const handleRecalculate = () => {
    setCalculating(true);
    setTimeout(() => {
      onPriceUpdate(contract.id, selectedModel);
      setCalculating(false);
    }, 300);
  };

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-amber-400" />
            <span>QUANTITATIVE PRICING & RISK TERMINAL</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Institutional derivatives desk valuation models, real-time yield/volatility curve calibration, and XVA risk waterfalls.
          </p>
        </div>
        <button
          onClick={handleRecalculate}
          disabled={calculating}
          className="flex items-center space-x-2 px-5 py-2.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-lg"
        >
          <RefreshCw className={`w-4 h-4 ${calculating ? 'animate-spin' : ''}`} />
          <span>RE-CALIBRATE & PRICING RUN</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Model Selection & Curve Calibration Overrides */}
        <div className="bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-5 text-xs">
          <h2 className="text-xs font-bold text-amber-400 border-b border-[#1f293d] pb-2">1. SELECT QUANTITATIVE MODEL</h2>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1">Pricing Model Framework</label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full bg-[#182030] border border-[#2d3a54] p-2.5 rounded text-white text-xs font-bold focus:outline-none focus:border-amber-500"
            >
              {availableModels.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          <div className="border-t border-[#1f293d] pt-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-300">2. MARKET DATA & CURVE SHIFT INPUTS</h3>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Spot Price Index</label>
              <input
                type="number"
                step="0.1"
                value={spotOverride}
                onChange={(e) => setSpotOverride(Number(e.target.value))}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-300 font-bold text-xs"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Risk-Free Rate (SONIA / OIS)</label>
              <input
                type="number"
                step="0.001"
                value={rateOverride}
                onChange={(e) => setRateOverride(Number(e.target.value))}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-300 font-bold text-xs"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Volatility Input</label>
              <input
                type="number"
                step="0.01"
                value={volOverride}
                onChange={(e) => setVolOverride(Number(e.target.value))}
                className="w-full bg-[#182030] border border-[#2d3a54] p-2 rounded text-amber-300 font-bold text-xs"
              />
            </div>
          </div>
        </div>

        {/* Pricing Results & Valuation Outputs */}
        <div className="lg:col-span-2 bg-[#121826] border border-[#232d42] rounded-lg p-6 space-y-6 text-xs">
          <div className="border-b border-[#1f293d] pb-3 flex justify-between items-center">
            <h2 className="text-xs font-bold text-amber-400">3. VALUATION & PRESENT VALUE (PV)</h2>
            <span className="text-[10px] text-slate-400">
              Calculation Runtime: {contract.pricingResult?.calculationRuntimeMs} ms
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">CLEAN PRICE</span>
              <div className="text-2xl font-bold text-white mt-1">{contract.pricingResult?.cleanPrice} %</div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">PRESENT VALUE (PV)</span>
              <div className="text-2xl font-bold text-emerald-400 mt-1">
                £{(contract.pricingResult?.presentValueGbp || 0).toLocaleString()}
              </div>
            </div>

            <div className="bg-[#182030] p-4 rounded border border-[#29354d]">
              <span className="text-slate-400 text-[11px]">FORWARD VALUE</span>
              <div className="text-2xl font-bold text-amber-300 mt-1">
                £{(contract.pricingResult?.forwardValueGbp || 0).toLocaleString()}
              </div>
            </div>
          </div>

          <div className="border-t border-[#1f293d] pt-4 space-y-3">
            <h3 className="text-xs font-bold text-amber-400">4. GREEKS & XVA RISK WATERFALL</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[10px]">DELTA</span>
                <div className="text-base font-bold text-amber-300 mt-0.5">
                  {(contract.riskMetrics?.delta || 0).toLocaleString()}
                </div>
              </div>

              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[10px]">VEGA</span>
                <div className="text-base font-bold text-amber-300 mt-0.5">
                  {(contract.riskMetrics?.vega || 0).toLocaleString()}
                </div>
              </div>

              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[10px]">DV01</span>
                <div className="text-base font-bold text-amber-300 mt-0.5">
                  {(contract.riskMetrics?.dv01 || 0).toLocaleString()}
                </div>
              </div>

              <div className="bg-[#0b0f17] p-3 rounded border border-[#1f293d]">
                <span className="text-slate-400 text-[10px]">CVA</span>
                <div className="text-base font-bold text-red-400 mt-0.5">
                  -£{(contract.riskMetrics?.cvaGbp || 0).toLocaleString()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
