/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SyntheticContract } from '../types/contract';
import { ShieldAlert, ArrowRight, Lock, DollarSign } from 'lucide-react';

interface CollateralNettingProps {
  contracts: SyntheticContract[];
}

export const CollateralNetting: React.FC<CollateralNettingProps> = ({ contracts }) => {
  const grossExposureGbp = contracts.reduce((sum, c) => sum + Math.abs(c.pricingResult?.presentValueGbp || 0), 0);
  const netExposureGbp = contracts.reduce((sum, c) => sum + (c.pricingResult?.presentValueGbp || 0), 0);
  const totalIMPosted = contracts.reduce((sum, c) => sum + (c.collateral?.postedCollateralGbp || 0), 0);

  return (
    <div className="p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-mono">
      <div className="bg-[#121826] border border-[#232d42] p-6 rounded-lg shadow-xl">
        <h1 className="text-xl font-bold text-amber-400 flex items-center space-x-2">
          <ShieldAlert className="w-5 h-5 text-amber-400" />
          <span>BILATERAL NETTING & COLLATERAL OPTIMISATION ENGINE</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Bilateral ISDA netting aggregation, gross vs net exposure calculation, haircut schedules, and margin call reconciliation.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
        <div className="bg-[#182030] p-5 rounded border border-[#29354d] space-y-2">
          <span className="text-slate-400">GROSS PORTFOLIO EXPOSURE</span>
          <div className="text-2xl font-bold text-white">
            £{(grossExposureGbp / 1e6).toFixed(2)}M
          </div>
          <p className="text-[11px] text-slate-400">Sum of absolute contract PVs</p>
        </div>

        <div className="bg-[#182030] p-5 rounded border border-[#29354d] space-y-2">
          <span className="text-slate-400">NETTED SETTLEMENT EXPOSURE</span>
          <div className="text-2xl font-bold text-emerald-400">
            £{(netExposureGbp / 1e6).toFixed(2)}M
          </div>
          <p className="text-[11px] text-emerald-400 font-bold">
            Saved Netting Benefit: £{((grossExposureGbp - Math.abs(netExposureGbp)) / 1e6).toFixed(2)}M
          </p>
        </div>

        <div className="bg-[#182030] p-5 rounded border border-[#29354d] space-y-2">
          <span className="text-slate-400">TOTAL EFFECTIVE POSTED COLLATERAL</span>
          <div className="text-2xl font-bold text-amber-300">
            £{(totalIMPosted / 1e6).toFixed(2)}M
          </div>
          <p className="text-[11px] text-amber-300">Gilts & BOE Tokenised Deposits</p>
        </div>
      </div>
    </div>
  );
};
