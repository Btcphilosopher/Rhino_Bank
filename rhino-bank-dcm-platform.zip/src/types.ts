/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface IssuerFinancials {
  revenue: number;
  ebitda: number;
  netIncome: number;
  totalAssets: number;
  totalLiabilities: number;
  cashAndEquivalents: number;
  existingDebt: number;
  existingEquity: number;
  reportingYear: number;
}

export interface MeetingLog {
  id: string;
  date: string;
  topic: string;
  summary: string;
  attendees: string;
}

export interface CommunicationLog {
  id: string;
  date: string;
  type: 'Email' | 'Call' | 'Meeting' | 'Proposal';
  summary: string;
  sender: string;
}

export interface IssuerProfile {
  id: string;
  name: string;
  registrationNumber: string;
  country: string;
  industry: string;
  ownership: 'Private' | 'State-Owned' | 'Public Listed' | 'Municipal Joint Venture';
  creditRating: string; // e.g. AAA, AA+, AA, AA-, A+, A, BBB+, BBB, BB+
  boardMembers: string[];
  legalAdvisers: string;
  auditors: string;
  relationshipManager: string;
  meetingHistory: MeetingLog[];
  communicationLog: CommunicationLog[];
  pipelineStage: string;
  financials: IssuerFinancials;
  existingDebtNotes: string;
  documents: string[];
}

export type DealWorkflowStage =
  | 'Initial Client Meeting'
  | 'Opportunity Assessment'
  | 'Internal Screening'
  | 'Indicative Pricing'
  | 'Mandate Proposal'
  | 'Client Approval'
  | 'Due Diligence'
  | 'Investment Committee'
  | 'Pricing Committee'
  | 'Documentation'
  | 'Marketing'
  | 'Bookbuilding'
  | 'Allocation'
  | 'Settlement Simulation'
  | 'Post-Issue Monitoring';

export interface DealStageStatus {
  stageName: DealWorkflowStage;
  assignedStaff: string;
  deadline: string;
  status: 'Not Started' | 'In Progress' | 'Completed' | 'Deferred';
  approved: boolean;
  notes: string;
  requiredDocs: { name: string; uploaded: boolean }[];
}

export interface DealMandate {
  id: string;
  issuerId: string;
  issuerName: string;
  bondName: string;
  bondType: 'Corporate' | 'Infrastructure' | 'Municipal' | 'Green' | 'Project Finance' | 'Revenue' | 'Floating Rate Note' | 'Inflation Linked' | 'Convertible' | 'Zero Coupon';
  targetVolume: number;
  estimatedFeePercent: number; // e.g. 1.25 for 1.25%
  estimatedProbability: number; // e.g. 85 for 85%
  workflowStages: DealStageStatus[];
  currentStageIndex: number;
  riskNotes: string;
  createdDate: string;
}

export interface BondStructure {
  id: string;
  dealId: string;
  issuerId: string;
  issuerName: string;
  bondName: string;
  principalAmount: number;
  couponRate: number; // e.g. 5.5 for 5.5%
  couponFrequency: 'Annual' | 'Semi-Annual' | 'Quarterly' | 'Zero';
  maturityYears: number;
  currency: 'USD' | 'EUR' | 'GBP' | 'AUD' | 'ZAR' | 'CHF';
  issuePricePercent: number; // e.g. 99.5
  faceValue: number;
  issueDate: string;
  settlementDate: string;
  callOptionDetails?: string;
  putOptionDetails?: string;
  security: 'Unsecured' | 'Senior Secured' | 'Subordinated' | 'Asset-Backed' | 'Government Guaranteed';
  guarantees?: string;
  trustee: string;
  legalJurisdiction: string;
  listingExchange: string;
  isin: string;
  purposeOfIssue: string;
  useOfProceeds: string; // Category, e.g. Railway construction, Hospital development
}

export interface CashFlowRow {
  period: number;
  date: string;
  outstandingPrincipal: number;
  interestPayment: number;
  principalRepayment: number;
  totalDebtService: number;
  projectCashFlow: number;
  netCashFlow: number;
}

export interface SensitivityMatrixCell {
  discountRate: number;
  couponRate: number;
  npv: number;
}

export interface FinancialAnalysis {
  cashFlows: CashFlowRow[];
  npv: number;
  irr: number;
  averageDscr: number;
  llcr: number; // Loan Life Coverage Ratio
  plcr: number; // Project Life Coverage Ratio
  breakEvenYear: number;
  sensitivityMatrix: SensitivityMatrixCell[];
}

export interface YieldCurvePoint {
  tenor: number; // in years (e.g. 1, 2, 3, 5, 7, 10, 20, 30)
  govtRate: number;
  corpRate: number;
  muniRate: number;
  infraRate: number;
  zeroRate: number;
  forwardRate: number;
}

export interface YieldCurveSpreadMetrics {
  governmentYield10Y: number;
  corporateYield10Y: number;
  municipalYield10Y: number;
  infrastructureYield10Y: number;
  corpSpread10Y: number; // bps
  muniSpread10Y: number; // bps
  infraSpread10Y: number; // bps
  curveSteepness: number; // 10Y - 2Y government rate in bps
  isInverted: boolean;
  termPremiumEstimate: number; // bps
}

export interface RhinoGradingDetails {
  weightedScore: number; // 0 - 100
  rating: 'Rhino Platinum' | 'Rhino Gold' | 'Rhino Silver' | 'Investment Grade' | 'Watch List' | 'High Risk';
  scores: {
    couponCompetitiveness: number; // 0 - 100
    durationMatch: number;
    convexityProfile: number;
    creditQuality: number;
    yieldSpreadCompetitive: number;
    debtServiceCoverage: number;
    projectQuality: number;
    sectorOutlook: number;
    inflationSensitivity: number;
    interestRateSensitivity: number;
    liquidityAssumptions: number;
    expectedInvestorDemand: number;
    regionalEconomicOutlook: number;
  };
  explanations: Record<string, string>;
}

export interface CommitteeVote {
  voterName: string;
  voterRole: string;
  vote: 'Approve' | 'Approve with Conditions' | 'Reject';
  conditions: string;
  timestamp: string;
}

export interface PricingCommitteeDecision {
  dealId: string;
  bondName: string;
  issuerName: string;
  couponRate: number;
  yieldRate: number;
  spreadBps: number;
  feesPct: number;
  votes: CommitteeVote[];
  status: 'Approved' | 'Approved with Conditions' | 'Rejected' | 'Pending';
  decisionDate?: string;
  finalResolutionText?: string;
}

export interface InvestorProfile {
  id: string;
  name: string;
  category: 'Pension Fund' | 'Insurance Company' | 'Asset Manager' | 'Bank' | 'Sovereign Wealth Fund' | 'Family Office' | 'Retail (Simulation)';
  totalAum: number; // in Millions USD
  preferredSectors: string[];
  preferredRatings: string[];
  historicalVolumeMillions: number;
  relationshipStatus: 'Strategic' | 'Active' | 'Prospect';
  country: string;
  contactPerson: string;
}

export interface BookOrder {
  id: string;
  investorId: string;
  investorName: string;
  investorCategory: string;
  bidPrice: number; // percent of par, e.g. 100
  bidYield: number; // coupon yield, e.g. 5.6
  bidVolume: number; // total amount bid
  allocatedVolume: number; // allocated amount
  timestamp: string;
}

export interface BookbuildingSimulation {
  dealId: string;
  targetVolume: number;
  priceGuidancePercent: number; // initial guidance
  orders: BookOrder[];
  subscriptionRatio: number; // Demand / Target
  totalDemand: number;
  allocationMethod: 'Pro-Rata' | 'Strategic Priority' | 'AUM Weighted' | 'Manual';
}

export interface CreditRatioMetrics {
  debtToEquity: number;
  interestCoverage: number;
  debtToEbitda: number;
  currentRatio: number;
  cashToTotalDebt: number;
  freeCashFlowCoverage: number;
}

export interface InternalCreditReport {
  issuerId: string;
  issuerName: string;
  ratios: CreditRatioMetrics;
  peerComparisonTable: { name: string; dToE: number; intCoverage: number; rating: string }[];
  creditOutlook: 'Stable' | 'Positive' | 'Negative' | 'Developing';
  analystSummary: string;
  riskRatingScore: number; // 0 - 100 internal rating
}

export interface ComplianceWorkflow {
  dealId: string;
  kycStatus: 'Passed' | 'Pending' | 'Flagged';
  amlStatus: 'Passed' | 'Pending' | 'Flagged';
  sanctionsPassed: boolean;
  conflictChecked: boolean;
  auditorNotes: string;
  allClear: boolean;
  signoffUser?: string;
  signoffDate?: string;
  auditLogs: { timestamp: string; action: string; user: string }[];
}

export interface SettlementMilestoneTracker {
  dealId: string;
  pricingDate: string;
  issueDate: string;
  settlementDate: string;
  interestCommencementDate: string;
  firstCouponDate: string;
  maturityDate: string;
  milestones: { name: string; date: string; status: 'Not Started' | 'Completed' }[];
  settlementStatus: 'Pending Pricing' | 'In Flight' | 'Settled' | 'Failed';
}

export interface HistoricalIssuedBond {
  id: string;
  name: string;
  issuerName: string;
  isin: string;
  issueDate: string;
  maturityDate: string;
  volume: number;
  couponRate: number;
  currentPricePercent: number;
  currentYield: number;
  durationYears: number;
  sector: string;
  region: string;
}
