/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Settings, 
  HelpCircle, 
  CheckCircle, 
  AlertTriangle, 
  Lock, 
  Unlock, 
  ClipboardList, 
  ArrowRight,
  Sparkles,
  Info,
  History
} from 'lucide-react';
import { DealMandate, ComplianceWorkflow } from '../types';

interface ComplianceProps {
  deals: DealMandate[];
  darkMode: boolean;
}

export default function Compliance({
  deals,
  darkMode,
}: ComplianceProps) {
  const [selectedDealId, setSelectedDealId] = useState<string>(deals[0]?.id || '');
  const activeDeal = deals.find(d => d.id === selectedDealId) || deals[0];

  // Checklist items
  const [kycPassed, setKycPassed] = useState(true);
  const [amlPassed, setAmlPassed] = useState(true);
  const [sanctionsPassed, setSanctionsPassed] = useState(true);
  const [conflictChecked, setConflictChecked] = useState(true);
  const [dToELimitPassed, setDToELimitPassed] = useState(true);
  
  // Safety override barrier
  const [complianceSignoff, setComplianceSignoff] = useState(false);

  // Custom auditor notes
  const [auditorNotes, setAuditorNotes] = useState(
    "All principal directors have been screened against OFAC and EU sanctions databases. SADC regional exposure parameters remain within approved thresholds. Conflict check completed."
  );

  const [auditLogs, setAuditLogs] = useState([
    { timestamp: '2026-07-25 09:15', action: 'OFAC Sanctions Screen run', user: 'Compliance Officer (Helen)' },
    { timestamp: '2026-07-25 10:20', action: 'KYC corporate registry verified', user: 'Compliance Officer (Helen)' },
    { timestamp: '2026-07-25 11:10', action: 'Exposure limits check passed', user: 'Risk Desk Lead' }
  ]);

  const handleToggleSignoff = () => {
    const isReady = kycPassed && amlPassed && sanctionsPassed && conflictChecked && dToELimitPassed;
    if (!isReady && !complianceSignoff) {
      alert("Cannot sign-off compliance. All underlying KYC/AML/Sanctions checklists must be approved first!");
      return;
    }
    setComplianceSignoff(!complianceSignoff);
    
    // Log signoff
    const action = !complianceSignoff 
      ? 'FINAL COMPLIANCE SIGN-OFF APPROVED' 
      : 'Compliance sign-off rescinded';
    
    setAuditLogs([
      { timestamp: new Date().toISOString().split('T')[0] + ' ' + new Date().toTimeString().split(' ')[0].substring(0, 5), action, user: 'Compliance Officer (Helen)' },
      ...auditLogs
    ]);
  };

  const isReady = kycPassed && amlPassed && sanctionsPassed && conflictChecked && dToELimitPassed;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">COMPLIANCE & KYC CENTRAL DESK</h2>
          <p className="text-xs text-slate-500 font-mono">Conduct statutory KYC/AML reviews, audit exposure caps, and toggle distribution blockades</p>
        </div>
        <div>
          <select
            value={selectedDealId}
            onChange={(e) => setSelectedDealId(e.target.value)}
            className={`p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-300'}`}
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.bondName} (# {d.id})</option>
            ))}
          </select>
        </div>
      </div>

      {activeDeal ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1 & 2: Checklist & Status */}
          <div className="lg:col-span-2 space-y-6">
            {/* Regulatory Lock Barrier Card */}
            <div className={`p-6 border rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${
              complianceSignoff 
                ? 'bg-emerald-500/5 border-emerald-500/30' 
                : 'bg-rose-500/5 border-rose-500/20'
            }`}>
              <div className="flex items-center space-x-4">
                <div className={`p-4 rounded-md ${complianceSignoff ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                  {complianceSignoff ? <Unlock size={26} /> : <Lock size={26} />}
                </div>
                <div>
                  <h3 className="text-xs font-bold tracking-wider uppercase font-sans">SETTLEMENT BARRIER STATUS</h3>
                  <p className="text-base font-extrabold font-mono mt-1 text-slate-100 dark:text-slate-100">
                    {complianceSignoff ? 'COMPLIANCE CERTIFICATE ISSUED (FUNDS UNLOCKED)' : 'DISTRIBUTION BLOCKADE ACTIVE'}
                  </p>
                  <p className="text-[10px] text-slate-500 font-sans mt-1">
                    Settlement system check: {!complianceSignoff ? 'Locked pending final compliance officer authorization.' : 'Advisory clear. SWIFT release authorised.'}
                  </p>
                </div>
              </div>

              <div>
                <button
                  onClick={handleToggleSignoff}
                  className={`px-4 py-2 text-xs font-mono tracking-wide rounded-md transition-colors font-bold ${
                    complianceSignoff 
                      ? 'bg-amber-600 hover:bg-amber-700 text-white' 
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  }`}
                >
                  {complianceSignoff ? 'REVOKE SIGN-OFF' : 'APPROVE REGULATORY CLEARANCE'}
                </button>
              </div>
            </div>

            {/* Checklist items list */}
            <div className={`p-5 border rounded-lg shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans flex items-center gap-1.5">
                <ClipboardList size={14} className="text-amber-500" />
                Compliance Gate Checks list
              </h3>

              <div className="space-y-2.5 font-sans">
                {/* KYC */}
                <div className={`p-3 border flex items-center justify-between rounded-md transition-colors ${kycPassed ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox" checked={kycPassed} onChange={() => { setKycPassed(!kycPassed); setComplianceSignoff(false); }}
                      className="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-700 rounded mt-0.5 accent-amber-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-200 dark:text-slate-100 block">KYC: Corporate Registry and Legal Entity Identifier</span>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">Verification of CIPC, registered office, and Articles of Association.</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 border rounded-md ${kycPassed ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                    {kycPassed ? 'PASSED' : 'PENDING'}
                  </span>
                </div>

                {/* AML */}
                <div className={`p-3 border flex items-center justify-between rounded-md transition-colors ${amlPassed ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox" checked={amlPassed} onChange={() => { setAmlPassed(!amlPassed); setComplianceSignoff(false); }}
                      className="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-700 rounded mt-0.5 accent-amber-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-200 dark:text-slate-100 block">AML: Anti-Money Laundering & Ultimate Beneficial Owners</span>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">Tracing ultimate beneficial shareholders owning more than 10% voting equity.</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 border rounded-md ${amlPassed ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                    {amlPassed ? 'PASSED' : 'PENDING'}
                  </span>
                </div>

                {/* Sanctions */}
                <div className={`p-3 border flex items-center justify-between rounded-md transition-colors ${sanctionsPassed ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox" checked={sanctionsPassed} onChange={() => { setSanctionsPassed(!sanctionsPassed); setComplianceSignoff(false); }}
                      className="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-700 rounded mt-0.5 accent-amber-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-200 dark:text-slate-100 block">Sanctions: OFAC, EU & SADC Consolidated list screening</span>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">Automated screening against high-risk Politically Exposed Persons (PEPs) indices.</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 border rounded-md ${sanctionsPassed ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                    {sanctionsPassed ? 'PASSED' : 'PENDING'}
                  </span>
                </div>

                {/* Conflict */}
                <div className={`p-3 border flex items-center justify-between rounded-md transition-colors ${conflictChecked ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox" checked={conflictChecked} onChange={() => { setConflictChecked(!conflictChecked); setComplianceSignoff(false); }}
                      className="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-700 rounded mt-0.5 accent-amber-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-200 dark:text-slate-100 block">Conflict: Internal advisory conflict checking</span>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">Verification that underwrite advisory does not conflict with syndicate books.</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 border rounded-md ${conflictChecked ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                    {conflictChecked ? 'PASSED' : 'PENDING'}
                  </span>
                </div>

                {/* SADC Credit Limit */}
                <div className={`p-3 border flex items-center justify-between rounded-md transition-colors ${dToELimitPassed ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox" checked={dToELimitPassed} onChange={() => { setDToELimitPassed(!dToELimitPassed); setComplianceSignoff(false); }}
                      className="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-700 rounded mt-0.5 accent-amber-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-200 dark:text-slate-100 block">Risk: Leverage exposure compliance bounds check</span>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">Issuer balance sheet debt-to-equity is confirmed below SADC regional caps.</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 border rounded-md ${dToELimitPassed ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                    {dToELimitPassed ? 'PASSED' : 'PENDING'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Column 3: Audit Trail & Compliance notes */}
          <div className="space-y-6">
            {/* Auditor notes */}
            <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[260px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <ClipboardList size={14} />
                Auditor Audit covenants Notes
              </h3>
              <p className="text-[10px] text-slate-500 font-sans leading-relaxed mb-3">
                Log regulatory observations, SADC sanctions clearance references or country risk assessments.
              </p>
              <textarea
                value={auditorNotes}
                onChange={e => setAuditorNotes(e.target.value)}
                className={`flex-1 p-2 text-xs border rounded-md focus:outline-none resize-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
              />
            </div>

            {/* Audit Trail Log */}
            <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[320px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <History size={14} />
                Compliance System Audit Logs
              </h3>
              <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 text-[11px] font-mono">
                {auditLogs.map((log, idx) => (
                  <div key={idx} className="p-2 border border-slate-800/10 dark:border-slate-800 bg-slate-950/40 space-y-1 rounded-md leading-relaxed">
                    <div className="flex justify-between text-[10px] text-slate-500 font-bold">
                      <span>Liaison: {log.user}</span>
                      <span>{log.timestamp}</span>
                    </div>
                    <p className="text-slate-300">{log.action}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          No pipeline deals registered. Complete Client and Deal Workflow registration.
        </div>
      )}
    </div>
  );
}
