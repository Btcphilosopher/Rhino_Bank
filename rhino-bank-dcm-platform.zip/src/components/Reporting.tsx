/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  FileText, 
  Settings, 
  HelpCircle, 
  Download, 
  Printer, 
  Sparkles, 
  RefreshCw, 
  Scale, 
  ArrowRight,
  ClipboardCheck,
  CheckCircle,
  FileCheck2
} from 'lucide-react';
import { DealMandate, IssuerProfile, BondStructure } from '../types';

interface ReportingProps {
  deals: DealMandate[];
  issuers: IssuerProfile[];
  bonds: BondStructure[];
  darkMode: boolean;
}

export default function Reporting({
  deals,
  issuers,
  bonds,
  darkMode,
}: ReportingProps) {
  const [selectedBondId, setSelectedBondId] = useState<string>(bonds[0]?.id || '');
  const activeBond = bonds.find(b => b.id === selectedBondId) || bonds[0];
  
  const activeIssuer = activeBond 
    ? issuers.find(i => i.id === activeBond.issuerId) || issuers[0]
    : issuers[0];

  const [memoType, setMemoType] = useState<'ic-memo' | 'pricing-paper'>('ic-memo');
  const [generatedText, setGeneratedText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  // Trigger Gemini API request
  const handleGenerateMemo = async () => {
    if (!activeBond || !activeIssuer) {
      alert("Please ensure at least one issuer and bond are registered first!");
      return;
    }

    setLoading(true);
    setGeneratedText('');

    try {
      const response = await fetch('/api/generate-memo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: memoType,
          bond: activeBond,
          issuer: activeIssuer,
          metrics: {
            averageDscr: 1.45,
            llcr: 1.55,
            plcr: 1.75,
            irr: 8.25,
            weightedScore: 88,
            rating: 'Rhino Silver',
            spreadBps: 155,
            feesPct: 1.25
          }
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setGeneratedText(data.text);
      } else {
        setGeneratedText(data.fallbackText || "Failed to draft memo. Fallback pre-compiled template loaded.");
      }
    } catch (err: any) {
      console.error(err);
      setGeneratedText("Error contacting server ledger engine. Showing cached draft:\n\n# Fallback Error Code 500\nConnection to ledger timed out.");
    } finally {
      setLoading(false);
    }
  };

  // Helper to format text line by line for terminal display
  const renderFormattedText = (rawText: string) => {
    if (!rawText) return null;
    return rawText.split('\n').map((line, idx) => {
      if (line.startsWith('# ')) {
        return <h1 key={idx} className="text-lg font-bold text-amber-500 border-b border-slate-800/40 pb-1 mt-6 mb-3 font-sans tracking-tight uppercase">{line.replace('# ', '')}</h1>;
      }
      if (line.startsWith('## ')) {
        return <h2 key={idx} className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-5 mb-2 font-sans tracking-wide uppercase">{line.replace('## ', '')}</h2>;
      }
      if (line.startsWith('### ')) {
        return <h3 key={idx} className="text-xs font-bold text-slate-400 mt-4 mb-1.5 font-sans uppercase">{line.replace('### ', '')}</h3>;
      }
      if (line.startsWith('* ')) {
        return <li key={idx} className="ml-4 text-xs text-slate-300 font-mono list-disc py-0.5">{line.replace('* ', '')}</li>;
      }
      if (line.startsWith('- ')) {
        return <li key={idx} className="ml-4 text-xs text-slate-300 font-mono list-disc py-0.5">{line.replace('- ', '')}</li>;
      }
      return <p key={idx} className="text-xs text-slate-300 leading-relaxed font-mono py-1">{line}</p>;
    });
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">REPORTING & UNDERWRITING CENTRAL</h2>
          <p className="text-xs text-slate-500 font-mono">Draft prospectus notes, compile investment memorandums, and export compliance ledgers</p>
        </div>
        <div className="flex items-center space-x-2">
          <select
            value={selectedBondId}
            onChange={(e) => setSelectedBondId(e.target.value)}
            className={`p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-300'}`}
          >
            {bonds.map(b => (
              <option key={b.id} value={b.id}>{b.bondName}</option>
            ))}
          </select>
        </div>
      </div>

      {activeBond ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1: Document Configurator */}
          <div className={`p-5 border rounded-lg shadow-sm flex flex-col justify-between h-[calc(100vh-230px)] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="space-y-6">
              <div>
                <span className="text-[10px] font-mono tracking-widest text-amber-500 uppercase font-bold">
                  DOCUMENT CONFIGURATOR
                </span>
                <h3 className="text-sm font-bold font-sans text-slate-400 mt-1">{activeBond.bondName}</h3>
                <p className="text-[11px] text-slate-500 font-mono mt-0.5">Issuer: {activeIssuer.name}</p>
              </div>

              {/* Selector for memo type */}
              <div className="space-y-2 font-sans text-xs">
                <span className="text-[9px] font-mono font-bold tracking-widest text-slate-500 uppercase block">
                  Select Document Type:
                </span>
                <div className="space-y-2 font-mono">
                  <button
                    onClick={() => { setMemoType('ic-memo'); setGeneratedText(''); }}
                    className={`w-full p-3 text-left border rounded-md font-mono transition-all block ${
                      memoType === 'ic-memo' 
                        ? 'bg-amber-500/10 border-amber-500 text-slate-200 font-bold' 
                        : 'border-slate-800/60 hover:bg-slate-800/30 text-slate-400'
                    }`}
                  >
                    <span className="block text-xs font-bold text-slate-100">Investment Committee Memo</span>
                    <span className="block text-[9px] text-slate-500 mt-1 uppercase font-semibold">10-section formal proposal</span>
                  </button>

                  <button
                    onClick={() => { setMemoType('pricing-paper'); setGeneratedText(''); }}
                    className={`w-full p-3 text-left border rounded-md font-mono transition-all block ${
                      memoType === 'pricing-paper' 
                        ? 'bg-amber-500/10 border-amber-500 text-slate-200 font-bold' 
                        : 'border-slate-800/60 hover:bg-slate-800/30 text-slate-400'
                    }`}
                  >
                    <span className="block text-xs font-bold text-slate-100">Pricing Decision Paper</span>
                    <span className="block text-[9px] text-slate-500 mt-1 uppercase font-semibold">Technical pricing spreadsheet</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="space-y-2 pt-4 border-t border-slate-800/30">
              <button
                onClick={handleGenerateMemo}
                disabled={loading}
                className="w-full flex items-center justify-center space-x-2 bg-amber-500 hover:bg-amber-600 text-slate-950 py-2.5 text-xs font-mono transition-all rounded-md font-bold disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <RefreshCw className="animate-spin text-slate-950" size={13} />
                    <span className="text-slate-950">DRAFTING MEMORANDUM...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={13} className="fill-slate-950 text-slate-950" />
                    <span className="text-slate-950">GENERATE FORMAL LEDGER REPORT</span>
                  </>
                )}
              </button>
              
              <button
                onClick={() => window.print()}
                disabled={!generatedText}
                className="w-full flex items-center justify-center space-x-1.5 border border-slate-700/60 hover:bg-slate-800/30 text-slate-400 py-2 text-xs font-mono transition-all rounded-md disabled:opacity-40"
              >
                <Printer size={13} />
                <span>PRINT DOCUMENT</span>
              </button>
            </div>
          </div>

          {/* Column 2 & 3: Ledger output board */}
          <div className={`p-6 border lg:col-span-2 rounded-lg shadow-sm h-[calc(100vh-230px)] flex flex-col justify-between ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-800/30">
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans flex items-center gap-1.5">
                <FileText size={14} className="text-amber-500" />
                Institutional Draft ledger View
              </h3>
              <span className="text-[10px] text-slate-500 font-mono">STATUS: {generatedText ? 'DRAFTED' : 'AWAITING GENERATION'}</span>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto pr-1">
              {generatedText ? (
                <div className="space-y-4 p-4 border border-slate-800/50 bg-slate-950 rounded-md">
                  {renderFormattedText(generatedText)}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-500 text-xs font-mono py-12 text-center max-w-sm mx-auto space-y-4">
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-md text-slate-400">
                    <Sparkles size={32} className="text-amber-500" />
                  </div>
                  <p>
                    Select a core document template and click <strong>"GENERATE FORMAL LEDGER REPORT"</strong> to execute server-side Gemini generation.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          No structured bonds registered. Build one in Structuring first.
        </div>
      )}
    </div>
  );
}
