/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BarChart as RechartsBarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { 
  Layers, 
  Settings, 
  HelpCircle, 
  UserPlus, 
  Coins, 
  TrendingUp, 
  Play, 
  ArrowRight,
  ShieldCheck,
  CheckCircle,
  FileCheck2
} from 'lucide-react';
import { BookOrder, DealMandate, InvestorProfile } from '../types';
import { simulateAllocation } from '../utils';
import { INITIAL_INVESTORS, MOCK_ORDERS_DEAL_002 } from '../mockData';

interface BookbuildingProps {
  deals: DealMandate[];
  darkMode: boolean;
}

export default function Bookbuilding({
  deals,
  darkMode,
}: BookbuildingProps) {
  // Filter deals at or past marketing / bookbuilding stage
  const eligibleDeals = deals.filter(d => d.currentStageIndex >= 10);
  const [selectedDealId, setSelectedDealId] = useState<string>(eligibleDeals[0]?.id || deals[0]?.id || '');
  const activeDeal = deals.find(d => d.id === selectedDealId) || deals[0];

  // Dynamic order book state
  const [orders, setOrders] = useState<BookOrder[]>(MOCK_ORDERS_DEAL_002);
  const [allocationMethod, setAllocationMethod] = useState<'Pro-Rata' | 'Strategic Priority' | 'AUM Weighted'>('Pro-Rata');

  // Input states for custom bids
  const [selectedInvestorId, setSelectedInvestorId] = useState<string>(INITIAL_INVESTORS[0]?.id || '');
  const [bidVolume, setBidVolume] = useState<number>(20000000);
  const [bidYield, setBidYield] = useState<number>(5.15);

  const activeInvestor = INITIAL_INVESTORS.find(i => i.id === selectedInvestorId) || INITIAL_INVESTORS[0];

  // Calculate book statistics
  const totalVolumeTarget = activeDeal ? activeDeal.targetVolume : 150000000;
  const totalDemand = orders.reduce((sum, o) => sum + o.bidVolume, 0);
  const subscriptionRatio = totalVolumeTarget > 0 ? totalDemand / totalVolumeTarget : 1.0;
  const totalAllocated = orders.reduce((sum, o) => sum + o.allocatedVolume, 0);

  // Recharts chart data mapping bidder types
  const demandByCategoryMap: Record<string, number> = {};
  orders.forEach(o => {
    demandByCategoryMap[o.investorCategory] = (demandByCategoryMap[o.investorCategory] || 0) + o.bidVolume;
  });
  const demandChartData = Object.keys(demandByCategoryMap).map(key => ({
    category: key,
    Demand: Math.round(demandByCategoryMap[key] / 1000000), // in Millions
  }));

  // Trigger allocation solver
  const handleRunAllocation = () => {
    const allocatedOrders = simulateAllocation(orders, totalVolumeTarget, allocationMethod);
    setOrders(allocatedOrders);
  };

  // Add custom bidding log
  const handleAddBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeInvestor) return;

    const newOrder: BookOrder = {
      id: `ord-${String(orders.length + 1).padStart(3, '0')}`,
      investorId: activeInvestor.id,
      investorName: activeInvestor.name,
      investorCategory: activeInvestor.category,
      bidPrice: 100.0, // assume par
      bidYield,
      bidVolume,
      allocatedVolume: 0,
      timestamp: new Date().toISOString().split('T')[0] + ' ' + new Date().toTimeString().split(' ')[0].substring(0, 5)
    };

    setOrders([...orders, newOrder]);
  };

  // Reset book orders
  const handleResetOrders = () => {
    setOrders(MOCK_ORDERS_DEAL_002.map(o => ({ ...o, allocatedVolume: 0 })));
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">BOOKBUILDING DISTRIBUTION</h2>
          <p className="text-xs text-slate-500 font-mono">Open primary bidding books, tally subscriber demands, and run strategic allocations</p>
        </div>
        <div>
          <select
            value={selectedDealId}
            onChange={(e) => setSelectedDealId(e.target.value)}
            className={`p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-300'}`}
          >
            {eligibleDeals.map(d => (
              <option key={d.id} value={d.id}>{d.bondName} (# {d.id})</option>
            ))}
          </select>
        </div>
      </div>

      {activeDeal ? (
        <>
          {/* Dashboard ribbon */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-center">
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Underwrite Target</span>
              <span className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                ${(totalVolumeTarget / 1000000).toFixed(0)}M
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Total Bid demand</span>
              <span className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                ${(totalDemand / 1000000).toFixed(1)}M
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Oversubscription Ratio</span>
              <span className={`text-sm font-bold mt-1 block ${subscriptionRatio > 1.5 ? 'text-emerald-500' : subscriptionRatio >= 1.0 ? 'text-amber-500' : 'text-rose-500'}`}>
                {subscriptionRatio.toFixed(2)}x
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">allocated amount</span>
              <span className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                ${(totalAllocated / 1000000).toFixed(1)}M
              </span>
            </div>
          </div>

          {/* Allocation control board */}
          <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <div>
                <h3 className="text-xs font-bold tracking-wider uppercase font-sans">Syndicate Allocation solver</h3>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5">Select strategic criteria and run allocations</p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <select
                  value={allocationMethod}
                  onChange={(e) => setAllocationMethod(e.target.value as any)}
                  className={`py-1.5 px-3 text-xs font-mono border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                >
                  <option value="Pro-Rata">Pro-Rata Fill ratio</option>
                  <option value="Strategic Priority">Strategic Priority (Pensions/SWF)</option>
                  <option value="AUM Weighted">AUM Weight Modifiers</option>
                </select>
                <button
                  type="button"
                  onClick={handleRunAllocation}
                  className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 text-xs font-mono transition-colors rounded-md"
                >
                  <Play size={12} className="fill-white" />
                  <span>RUN ALLOCATION</span>
                </button>
                <button
                  type="button"
                  onClick={handleResetOrders}
                  className="px-2.5 py-1.5 text-xs font-mono border border-slate-700/40 hover:bg-rose-500/10 text-rose-500 transition-colors rounded-md"
                >
                  RESET BOOK
                </button>
              </div>
            </div>
          </div>

          {/* Two-Column panel: Bidding list & Bidding input / chart */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Order Ledger */}
            <div className={`p-5 border lg:col-span-2 rounded-lg shadow-sm flex flex-col h-[480px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <Layers size={14} />
                Syndicate bidding Order Book
              </h3>

              <div className="flex-1 overflow-y-auto pr-1">
                <table className="w-full text-left border-collapse text-xs font-mono">
                  <thead>
                    <tr className={`border-b uppercase text-[9px] tracking-wider ${darkMode ? 'border-slate-800 text-slate-500' : 'border-slate-200 text-slate-500'}`}>
                      <th className="pb-2">Investor / Bidder</th>
                      <th className="pb-2">Category</th>
                      <th className="pb-2 text-right">Bid Yield</th>
                      <th className="pb-2 text-right">Demand Vol</th>
                      <th className="pb-2 text-right">Allocated Vol</th>
                      <th className="pb-2 text-right">Fill Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/10 dark:divide-slate-800/40">
                    {orders.map(order => {
                      const fillRate = order.bidVolume > 0 ? (order.allocatedVolume / order.bidVolume) * 100 : 0;
                      return (
                        <tr key={order.id} className="hover:bg-slate-500/5">
                          <td className="py-2.5 text-slate-300 dark:text-slate-100 font-bold truncate max-w-[160px]">{order.investorName}</td>
                          <td className="py-2.5 text-slate-500">{order.investorCategory}</td>
                          <td className="py-2.5 text-right font-bold text-amber-500">{order.bidYield.toFixed(2)}%</td>
                          <td className="py-2.5 text-right font-bold text-slate-300 dark:text-slate-100">${(order.bidVolume / 1000000).toFixed(1)}M</td>
                          <td className="py-2.5 text-right font-bold text-emerald-500">${(order.allocatedVolume / 1000000).toFixed(1)}M</td>
                          <td className="py-2.5 text-right">
                            <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-md ${fillRate >= 80 ? 'bg-emerald-500/10 text-emerald-500' : fillRate > 0 ? 'bg-amber-500/10 text-amber-500' : 'bg-slate-800/40 text-slate-500'}`}>
                              {fillRate.toFixed(0)}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bidding input & Demand Chart */}
            <div className="space-y-6">
              {/* Bidding input */}
              <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                  <UserPlus size={14} />
                  Record new Bidding log
                </h3>

                <form onSubmit={handleAddBid} className="space-y-4 font-mono text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase mb-1">Select Investor</label>
                    <select
                      value={selectedInvestorId}
                      onChange={e => setSelectedInvestorId(e.target.value)}
                      className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                    >
                      {INITIAL_INVESTORS.map(inv => (
                        <option key={inv.id} value={inv.id}>{inv.name} (AUM: ${inv.totalAum}M)</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-500 uppercase mb-1">Bid Volume ($)</label>
                      <input
                        type="number" step="1000000"
                        value={bidVolume}
                        onChange={e => setBidVolume(Number(e.target.value))}
                        className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-500 uppercase mb-1">Bid Yield (%)</label>
                      <input
                        type="number" step="0.01"
                        value={bidYield}
                        onChange={e => setBidYield(Number(e.target.value))}
                        className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 py-2 text-xs font-mono transition-colors rounded-md font-bold"
                  >
                    SUBMIT INSTITUTIONAL BID
                  </button>
                </form>
              </div>

              {/* Demand Chart */}
              <div className={`p-5 border rounded-lg shadow-sm h-[225px] flex flex-col justify-between ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h4 className="text-xs font-bold tracking-wider uppercase font-sans mb-2">Demand distribution by class</h4>
                <div className="flex-1 min-h-0">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart data={demandChartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1f2937' : '#f3f4f6'} />
                      <XAxis dataKey="category" stroke="#94a3b8" fontSize={9} />
                      <YAxis stroke="#94a3b8" fontSize={9} />
                      <Tooltip />
                      <Bar dataKey="Demand" fill="#f59e0b" name="Demand ($M)" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          No pipeline deals at active Bookbuilding stages. Ensure a deal progresses to stage 12 first.
        </div>
      )}
    </div>
  );
}
