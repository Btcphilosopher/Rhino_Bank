/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Building2, 
  MapPin, 
  Layers, 
  DollarSign, 
  Users, 
  FileText, 
  User, 
  History, 
  Edit3, 
  CheckCircle,
  FileCheck2,
  Trash2
} from 'lucide-react';
import { IssuerProfile, IssuerFinancials, MeetingLog, CommunicationLog } from '../types';

interface ClientManagementProps {
  issuers: IssuerProfile[];
  setIssuers: React.Dispatch<React.SetStateAction<IssuerProfile[]>>;
  darkMode: boolean;
}

export default function ClientManagement({
  issuers,
  setIssuers,
  darkMode,
}: ClientManagementProps) {
  const [selectedIssuer, setSelectedIssuer] = useState<IssuerProfile | null>(issuers[0] || null);
  const [isEditing, setIsEditing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states
  const [name, setName] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [country, setCountry] = useState('');
  const [industry, setIndustry] = useState('');
  const [ownership, setOwnership] = useState<'Private' | 'State-Owned' | 'Public Listed' | 'Municipal Joint Venture'>('Private');
  const [creditRating, setCreditRating] = useState('BBB+');
  const [boardMembers, setBoardMembers] = useState('');
  const [legalAdvisers, setLegalAdvisers] = useState('');
  const [auditors, setAuditors] = useState('');
  const [relationshipManager, setRelationshipManager] = useState('');
  const [existingDebtNotes, setExistingDebtNotes] = useState('');
  
  // Financial statement states
  const [revenue, setRevenue] = useState(0);
  const [ebitda, setEbitda] = useState(0);
  const [netIncome, setNetIncome] = useState(0);
  const [totalAssets, setTotalAssets] = useState(0);
  const [totalLiabilities, setTotalLiabilities] = useState(0);
  const [cashAndEquivalents, setCashAndEquivalents] = useState(0);
  const [existingDebt, setExistingDebt] = useState(0);
  const [existingEquity, setExistingEquity] = useState(0);

  // Open editor for New Client
  const handleNewClientClick = () => {
    setSelectedIssuer(null);
    setIsEditing(true);
    setName('');
    setRegistrationNumber(`REG-2026-${Math.floor(100000 + Math.random() * 900000)}`);
    setCountry('South Africa');
    setIndustry('Infrastructure');
    setOwnership('State-Owned');
    setCreditRating('A');
    setBoardMembers('James Khumalo, Patricia de Lille');
    setLegalAdvisers('ENS Africa');
    setAuditors('PwC');
    setRelationshipManager('Marcus Nkosi');
    setExistingDebtNotes('N/A');
    setRevenue(100000000);
    setEbitda(35000000);
    setNetIncome(12000000);
    setTotalAssets(500000000);
    setTotalLiabilities(200000000);
    setCashAndEquivalents(15000000);
    setExistingDebt(120000000);
    setExistingEquity(180000000);
  };

  // Open editor for Existing Client
  const handleEditClientClick = (issuer: IssuerProfile) => {
    setSelectedIssuer(issuer);
    setIsEditing(true);
    setName(issuer.name);
    setRegistrationNumber(issuer.registrationNumber);
    setCountry(issuer.country);
    setIndustry(issuer.industry);
    setOwnership(issuer.ownership);
    setCreditRating(issuer.creditRating);
    setBoardMembers(issuer.boardMembers.join(', '));
    setLegalAdvisers(issuer.legalAdvisers);
    setAuditors(issuer.auditors);
    setRelationshipManager(issuer.relationshipManager);
    setExistingDebtNotes(issuer.existingDebtNotes);
    
    setRevenue(issuer.financials.revenue);
    setEbitda(issuer.financials.ebitda);
    setNetIncome(issuer.financials.netIncome);
    setTotalAssets(issuer.financials.totalAssets);
    setTotalLiabilities(issuer.financials.totalLiabilities);
    setCashAndEquivalents(issuer.financials.cashAndEquivalents);
    setExistingDebt(issuer.financials.existingDebt);
    setExistingEquity(issuer.financials.existingEquity);
  };

  // Delete Client
  const handleDeleteClient = (id: string) => {
    const nextList = issuers.filter(i => i.id !== id);
    setIssuers(nextList);
    setSelectedIssuer(nextList[0] || null);
    setIsEditing(false);
  };

  // Save Form
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const financialObj: IssuerFinancials = {
      revenue,
      ebitda,
      netIncome,
      totalAssets,
      totalLiabilities,
      cashAndEquivalents,
      existingDebt,
      existingEquity,
      reportingYear: 2025
    };

    const boardArr = boardMembers.split(',').map(m => m.trim()).filter(Boolean);

    if (selectedIssuer) {
      // Editing existing
      const updated = issuers.map(i => {
        if (i.id === selectedIssuer.id) {
          return {
            ...i,
            name,
            registrationNumber,
            country,
            industry,
            ownership,
            creditRating,
            boardMembers: boardArr,
            legalAdvisers,
            auditors,
            relationshipManager,
            existingDebtNotes,
            financials: financialObj
          };
        }
        return i;
      });
      setIssuers(updated);
      setSelectedIssuer(updated.find(u => u.id === selectedIssuer.id) || null);
    } else {
      // Creating new
      const newId = `iss-${String(issuers.length + 1).padStart(3, '0')}`;
      const newClient: IssuerProfile = {
        id: newId,
        name,
        registrationNumber,
        country,
        industry,
        ownership,
        creditRating,
        boardMembers: boardArr,
        legalAdvisers,
        auditors,
        relationshipManager,
        pipelineStage: 'Initial Client Meeting',
        meetingHistory: [],
        communicationLog: [
          { id: 'c-init', date: new Date().toISOString().split('T')[0], type: 'Meeting', summary: 'DCM Profile initialized.', sender: relationshipManager }
        ],
        financials: financialObj,
        existingDebtNotes,
        documents: ['Audit_Statements_2025.pdf']
      };
      const updated = [...issuers, newClient];
      setIssuers(updated);
      setSelectedIssuer(newClient);
    }
    setIsEditing(false);
  };

  // Filter list based on search
  const filteredIssuers = issuers.filter(i => 
    i.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    i.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
    i.industry.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Column 1: Client Database Registrar */}
      <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[calc(100vh-140px)] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans">Corporate Registrar</h3>
            <p className="text-[10px] text-slate-500 font-mono mt-0.5">Active primary debt issuers</p>
          </div>
          <button
            onClick={handleNewClientClick}
            className="flex items-center space-x-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 px-2.5 py-1.5 text-xs tracking-wide font-mono transition-all rounded-md font-bold"
          >
            <Plus size={14} />
            <span>NEW CLIENT</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search issuers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-8 pr-3 py-2 text-xs border rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500 ${
              darkMode 
                ? 'bg-slate-950 border-slate-800 text-slate-200 placeholder-slate-500' 
                : 'bg-white border-slate-300 text-slate-800'
            }`}
          />
        </div>

        {/* Client List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {filteredIssuers.map((issuer) => {
            const isSelected = selectedIssuer && selectedIssuer.id === issuer.id;
            return (
              <div
                key={issuer.id}
                onClick={() => {
                  setSelectedIssuer(issuer);
                  setIsEditing(false);
                }}
                className={`p-3 border cursor-pointer transition-all duration-150 rounded-md flex items-start space-x-3 ${
                  isSelected 
                    ? 'border-amber-500 bg-amber-500/5' 
                    : darkMode 
                      ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/60'
                }`}
              >
                <div className={`p-2 rounded-md ${isSelected ? 'bg-amber-500 text-slate-950 font-bold' : darkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600'}`}>
                  <Building2 size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h4 className="text-xs font-bold truncate pr-1 text-slate-200 dark:text-slate-100">{issuer.name}</h4>
                    <span className="text-[9px] font-bold font-mono px-1.5 py-0.5 bg-emerald-500/10 text-emerald-500 uppercase border border-emerald-500/20 rounded-md">{issuer.creditRating}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-[10px] text-slate-500 font-mono mt-1.5">
                    <span className="flex items-center gap-1"><MapPin size={10} /> {issuer.country}</span>
                    <span>•</span>
                    <span className="truncate">{issuer.industry}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Column 2 & 3: Details Panel or Editor */}
      <div className="lg:col-span-2 h-[calc(100vh-140px)] overflow-y-auto">
        {isEditing ? (
          /* Editor UI */
          <form onSubmit={handleSave} className={`p-6 border rounded-lg shadow-sm space-y-6 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center border-b pb-4 border-slate-800/10 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold font-sans">{selectedIssuer ? `Edit Issuer: ${selectedIssuer.name}` : 'Register New Issuer'}</h3>
                <p className="text-[10px] text-slate-500 font-mono">Input corporate, governance, and asset statistics</p>
              </div>
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className={`px-3 py-1.5 text-xs font-mono border transition-colors rounded-md ${darkMode ? 'border-slate-800 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'}`}
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 text-xs font-mono transition-colors rounded-md"
                >
                  SAVE PROFILE
                </button>
              </div>
            </div>

            {/* General Corporate Stats */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase">General Corporate Metadata</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Company / Issuer Name</label>
                  <input
                    type="text" required
                    value={name} onChange={e => setName(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Registration Identifier</label>
                  <input
                    type="text" required
                    value={registrationNumber} onChange={e => setRegistrationNumber(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Country Jurisdiction</label>
                  <input
                    type="text" required
                    value={country} onChange={e => setCountry(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Sector / Industry</label>
                  <input
                    type="text" required
                    value={industry} onChange={e => setIndustry(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Ownership Model</label>
                  <select
                    value={ownership} onChange={e => setOwnership(e.target.value as any)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  >
                    <option value="Private">Private</option>
                    <option value="State-Owned">State-Owned</option>
                    <option value="Public Listed">Public Listed</option>
                    <option value="Municipal Joint Venture">Municipal Joint Venture</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Credit Agency Rating</label>
                  <select
                    value={creditRating} onChange={e => setCreditRating(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  >
                    {['AAA', 'AA+', 'AA', 'AA-', 'A+', 'A', 'A-', 'BBB+', 'BBB', 'BBB-', 'BB+', 'BB', 'B+', 'B', 'CCC'].map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Governance & Covenants */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase">Governance & Advisers</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Board Members (Comma-separated)</label>
                  <input
                    type="text"
                    value={boardMembers} onChange={e => setBoardMembers(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Lead Relationship Manager</label>
                  <input
                    type="text"
                    value={relationshipManager} onChange={e => setRelationshipManager(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Auditors</label>
                  <input
                    type="text"
                    value={auditors} onChange={e => setAuditors(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Legal Advisers</label>
                  <input
                    type="text"
                    value={legalAdvisers} onChange={e => setLegalAdvisers(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
              </div>
            </div>

            {/* Financial Ledger Details */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase">Financial Statements Ledger (USD)</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Annual Revenue</label>
                  <input
                    type="number" required
                    value={revenue} onChange={e => setRevenue(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">EBITDA</label>
                  <input
                    type="number" required
                    value={ebitda} onChange={e => setEbitda(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Net Income</label>
                  <input
                    type="number" required
                    value={netIncome} onChange={e => setNetIncome(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Cash Reserves</label>
                  <input
                    type="number" required
                    value={cashAndEquivalents} onChange={e => setCashAndEquivalents(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Total Assets</label>
                  <input
                    type="number" required
                    value={totalAssets} onChange={e => setTotalAssets(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Total Liabilities</label>
                  <input
                    type="number" required
                    value={totalLiabilities} onChange={e => setTotalLiabilities(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Outstanding Debt</label>
                  <input
                    type="number" required
                    value={existingDebt} onChange={e => setExistingDebt(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Total Equity</label>
                  <input
                    type="number" required
                    value={existingEquity} onChange={e => setExistingEquity(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <label className="block text-[10px] font-mono text-slate-400 uppercase">Existing Debt Maturity Notes</label>
              <textarea
                value={existingDebtNotes} onChange={e => setExistingDebtNotes(e.target.value)}
                rows={3}
                className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
              />
            </div>
          </form>
        ) : selectedIssuer ? (
          /* Profile Details View */
          <div className="space-y-6">
            {/* Header Card */}
            <div className={`p-6 border rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-4">
                <div className={`p-4 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-md`}>
                  <Building2 size={24} />
                </div>
                <div>
                  <div className="flex items-center space-x-3">
                    <h3 className="text-lg font-bold font-sans text-slate-100 dark:text-slate-100">{selectedIssuer.name}</h3>
                    <span className="text-xs font-bold font-mono px-2 py-0.5 bg-amber-500/10 text-amber-500 uppercase border border-amber-500/20 rounded">
                      {selectedIssuer.creditRating}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-xs font-mono text-slate-400 mt-1.5">
                    <span className="flex items-center gap-1"><MapPin size={12} /> {selectedIssuer.country}</span>
                    <span>•</span>
                    <span>{selectedIssuer.ownership}</span>
                    <span>•</span>
                    <span className="text-[11px] font-bold text-slate-500">REG: {selectedIssuer.registrationNumber}</span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEditClientClick(selectedIssuer)}
                  className={`flex items-center space-x-1.5 px-3.5 py-1.5 text-xs font-mono border rounded-md transition-all ${darkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-300' : 'border-slate-300 hover:bg-slate-100'}`}
                >
                  <Edit3 size={12} />
                  <span>EDIT PROFILE</span>
                </button>
                <button
                  onClick={() => {
                    if(confirm("Confirm deletion? This will delete the issuer profile permanently.")) {
                      handleDeleteClient(selectedIssuer.id);
                    }
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-mono border rounded-md transition-all border-red-900/30 text-rose-500 hover:bg-rose-500/10`}
                >
                  <Trash2 size={12} />
                </button>
              </div>
            </div>

            {/* Financial Summary Card */}
            <div className={`p-6 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-2">
                <DollarSign size={14} />
                Balance Sheet & Financial Matrix (Reporting Year: {selectedIssuer.financials.reportingYear})
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Annual Revenue</span>
                  <span className="text-base font-bold font-mono text-slate-100 dark:text-slate-100 mt-1 block">
                    ${(selectedIssuer.financials.revenue / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">EBITDA (Operations)</span>
                  <span className="text-base font-bold font-mono text-slate-100 dark:text-slate-100 mt-1 block">
                    ${(selectedIssuer.financials.ebitda / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Total Outstanding Debt</span>
                  <span className="text-base font-bold font-mono text-rose-500 mt-1 block">
                    ${(selectedIssuer.financials.existingDebt / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Leverage ratio (Debt/EBITDA)</span>
                  <span className="text-base font-bold font-mono text-slate-100 dark:text-slate-100 mt-1 block">
                    {(selectedIssuer.financials.existingDebt / selectedIssuer.financials.ebitda).toFixed(2)}x
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Total Assets</span>
                  <span className="text-sm font-bold font-mono text-slate-300 dark:text-slate-200 mt-1 block">
                    ${(selectedIssuer.financials.totalAssets / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Total Liabilities</span>
                  <span className="text-sm font-bold font-mono text-slate-300 dark:text-slate-200 mt-1 block">
                    ${(selectedIssuer.financials.totalLiabilities / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Cash & Reserves</span>
                  <span className="text-sm font-bold font-mono text-emerald-500 mt-1 block">
                    ${(selectedIssuer.financials.cashAndEquivalents / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="p-3 bg-slate-900/40 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Total Net Equity</span>
                  <span className="text-sm font-bold font-mono text-slate-300 dark:text-slate-200 mt-1 block">
                    ${(selectedIssuer.financials.existingEquity / 1000000).toFixed(1)}M
                  </span>
                </div>
              </div>

              {/* Debt notes */}
              <div className="mt-6 border-t border-slate-800/50 pt-4">
                <span className="text-[10px] font-mono text-slate-500 uppercase block mb-1">Leverage & Credit Footnote</span>
                <p className="text-xs text-slate-400 leading-relaxed font-sans">{selectedIssuer.existingDebtNotes}</p>
              </div>
            </div>

            {/* Governance, Board & Advisers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Board */}
              <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-2">
                  <Users size={14} />
                  Corporate Board & Key Officers
                </h4>
                <div className="space-y-2.5 font-sans">
                  {selectedIssuer.boardMembers.map((member, index) => (
                    <div key={index} className="flex items-center space-x-2.5 py-1.5 border-b border-slate-800/10 dark:border-slate-800 last:border-b-0">
                      <div className="w-2.5 h-2.5 bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold text-[8px] rounded-full">
                        •
                      </div>
                      <span className="text-xs font-semibold text-slate-300 dark:text-slate-200">{member}</span>
                      <span className="text-[10px] text-slate-500 font-mono italic pl-2">Board Director</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Legal & RM */}
              <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-2">
                  <FileText size={14} />
                  Professional Advisory & Intermediaries
                </h4>
                <div className="space-y-4 text-xs font-sans">
                  <div className="flex justify-between py-1 border-b border-slate-800/10 dark:border-slate-800">
                    <span className="text-slate-500 font-mono uppercase text-[10px]">Relationship Lead:</span>
                    <span className="font-semibold text-slate-300 dark:text-slate-200">{selectedIssuer.relationshipManager}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/10 dark:border-slate-800">
                    <span className="text-slate-500 font-mono uppercase text-[10px]">Statutory Auditors:</span>
                    <span className="font-semibold text-slate-300 dark:text-slate-200">{selectedIssuer.auditors}</span>
                  </div>
                  <div className="flex justify-between py-1 last:border-b-0">
                    <span className="text-slate-500 font-mono uppercase text-[10px]">Lead Legal Counsel:</span>
                    <span className="font-semibold text-slate-300 dark:text-slate-200">{selectedIssuer.legalAdvisers}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* History logs & Communication registers */}
            <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-2">
                <History size={14} />
                Origination & Communication History Logs
              </h4>
              <div className="space-y-3.5 max-h-60 overflow-y-auto pr-1">
                {selectedIssuer.communicationLog.map((log) => (
                  <div key={log.id} className="p-3 bg-slate-900/30 border border-slate-800/40 rounded-md flex items-start space-x-3 text-xs">
                    <div className="px-2 py-0.5 bg-amber-500/10 text-amber-500 font-mono text-[9px] font-bold uppercase border border-amber-500/20 rounded">
                      {log.type}
                    </div>
                    <div className="flex-1 min-w-0 font-sans">
                      <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                        <span>Liaison: {log.sender}</span>
                        <span>Date Logged: {log.date}</span>
                      </div>
                      <p className="text-slate-300 dark:text-slate-200 mt-1.5 leading-relaxed font-sans">{log.summary}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-500 text-xs font-mono">
            Please register or select an issuer profile from the left registrar.
          </div>
        )}
      </div>
    </div>
  );
}
