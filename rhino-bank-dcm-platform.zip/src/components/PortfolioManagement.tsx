/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  FolderGit, 
  Settings, 
  HelpCircle, 
  Calendar, 
  ArrowUpRight, 
  Activity, 
  ShieldCheck, 
  Clock, 
  Coins, 
  Sparkles,
  ChevronRight,
  TrendingUp,
  Award
} from 'lucide-react';
import { HistoricalIssuedBond } from '../types';
import { INITIAL_HISTORICAL_BONDS } from '../mockData';

interface PortfolioManagementProps {
  historicalBonds: HistoricalIssuedBond[];
  darkMode: boolean;
}

export default function PortfolioManagement({
  historicalBonds,
  darkMode,
}: PortfolioManagementProps) {
  const [bondsList, setBondsList] = useState<HistoricalIssuedBond[]>(historicalBonds);

  // Compute stats
  const totalOutstanding = bondsList.reduce((sum, b) => sum + b.volume, 0);
  const totalCouponAnnual = bondsList.reduce((sum, b) => sum + (b.volume * (b.couponRate / 100)), 0);

  // Simulated cash reserves for treasury
  const [treasuryLiquidity, setTreasuryLiquidity] = useState(45000000); // $45M
  const [fundingShortfallThreshold, setFundingShortfallThreshold] = useState(20000000); // $20M

  // Coupon calendars events
  const couponEvents = [
    { month: 'January', date: 'Jan 15', bond: 'South Africa Freight Rail Series IV', type: 'Semi-Annual', payment: 9300000 },
    { month: 'February', date: 'Feb 18', bond: 'JHB Municipal Green Grid Bonds', type: 'Semi-Annual', payment: 4350000 },
    { month: 'May', date: 'May 15', bond: 'South Africa Freight Rail Series IV', type: 'Semi-Annual', payment: 9300000 },
    { month: 'August', date: 'Aug 20', bond: 'Nairobi Bypass Transport Bond', type: 'Annual', payment: 14960000 },
    { month: 'November', date: 'Nov 10', bond: 'Kenya Solar Fields Alpha', type: 'Annual', payment: 5400000 },
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">PORTFOLIO & TREASURY OFFICE</h2>
          <p className="text-xs text-slate-500 font-mono">Monitor underwritten asset books, upcoming interest payments, and maturity ladders</p>
        </div>
        <div className={`px-3 py-1 text-xs font-mono border rounded-md ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-900/40' : 'border-slate-200 text-slate-600 bg-slate-50'}`}>
          TREASURY ID: TR-2026-REG
        </div>
      </div>

      {/* KPI Ribbons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">TOTAL OUTSTANDING BOOK</p>
          <h3 className="text-xl font-bold tracking-tight mt-1 font-mono text-slate-100 dark:text-slate-100">${(totalOutstanding / 1000000).toFixed(0)}M</h3>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">Across {bondsList.length} outstanding issuances</p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-amber-500" />
        </div>

        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">ANNUAL COUPON LIABILITIES</p>
          <h3 className="text-xl font-bold tracking-tight mt-1 font-mono text-slate-100 dark:text-slate-100">${(totalCouponAnnual / 1000000).toFixed(2)}M</h3>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">Weighted yield of {(totalCouponAnnual / totalOutstanding * 100).toFixed(2)}%</p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-blue-500" />
        </div>

        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">LIQUID TREASURY CASH Reserves</p>
          <h3 className="text-xl font-bold tracking-tight mt-1 font-mono text-emerald-500">${(treasuryLiquidity / 1000000).toFixed(2)}M</h3>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">Cleared for collateral backstops</p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-emerald-500" />
        </div>

        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">TREASURY SOLVENCY RATIO</p>
          <h3 className="text-xl font-bold tracking-tight mt-1 font-mono text-slate-100 dark:text-slate-100">{(treasuryLiquidity / totalCouponAnnual * 100).toFixed(0)}%</h3>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">Interest cover cushion: <span className="text-emerald-500">Robust</span></p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-amber-500" />
        </div>
      </div>

      {/* Main Layout: Maturity Ladder vs. Coupon Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Maturity Ladder List */}
        <div className={`p-5 border lg:col-span-2 rounded-lg shadow-sm flex flex-col h-[460px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
            <TrendingUp size={14} className="text-amber-500" />
            Outstanding Maturity Ladder Profile
          </h3>
          
          <div className="flex-1 overflow-y-auto pr-1">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className={`border-b uppercase text-[9px] tracking-wider ${darkMode ? 'border-slate-800 text-slate-500' : 'border-slate-200 text-slate-500'}`}>
                  <th className="pb-2">Underwritten Instrument</th>
                  <th className="pb-2">Issuer</th>
                  <th className="pb-2">Issue Date</th>
                  <th className="pb-2">Maturity Date</th>
                  <th className="pb-2 text-right">Yield</th>
                  <th className="pb-2 text-right">Outstanding Volume</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/10 dark:divide-slate-800/40">
                {bondsList.map(bond => (
                  <tr key={bond.id} className="hover:bg-slate-500/5">
                    <td className="py-3 text-slate-300 dark:text-slate-100 font-bold truncate max-w-[180px]">{bond.name}</td>
                    <td className="py-3 text-slate-500">{bond.issuerName}</td>
                    <td className="py-3 text-slate-500">{bond.issueDate}</td>
                    <td className="py-3 text-slate-500 font-bold text-rose-500">{bond.maturityDate}</td>
                    <td className="py-3 text-right font-bold text-amber-500">{bond.couponRate.toFixed(2)}%</td>
                    <td className="py-3 text-right font-bold text-slate-200 dark:text-slate-100">${(bond.volume / 1000000).toFixed(0)}M</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Coupon Calendar List */}
        <div className={`p-5 border rounded-lg shadow-sm h-[460px] flex flex-col ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
            <Calendar size={14} />
            Coupon Cash Interest Calendar
          </h3>
          <p className="text-[10px] text-slate-500 font-sans leading-relaxed mb-4">
            Scheduled upcoming cash payments representing annual and semi-annual interest obligations to primary subscribers.
          </p>

          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
            {couponEvents.map((event, idx) => (
              <div key={idx} className="p-3 bg-slate-900/30 border border-slate-800/60 rounded-md flex items-start justify-between text-xs font-mono">
                <div>
                  <span className="text-[10px] font-bold text-amber-500 block uppercase">{event.date}</span>
                  <span className="text-slate-300 dark:text-slate-100 font-bold block truncate max-w-[180px] mt-1">{event.bond}</span>
                  <span className="text-[9px] text-slate-500 block mt-0.5">Payment type: {event.type}</span>
                </div>
                <div className="text-right">
                  <span className="text-emerald-500 font-bold block">${(event.payment / 1000000).toFixed(2)}M</span>
                  <span className="text-[9px] text-slate-500 block mt-0.5">Cleared</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
