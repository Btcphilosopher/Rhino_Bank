/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  UsersRound, 
  Settings, 
  HelpCircle, 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  ChevronRight, 
  Sparkles, 
  Scale, 
  FileSignature 
} from 'lucide-react';
import { DealMandate, CommitteeVote, PricingCommitteeDecision } from '../types';

interface PricingCommitteeProps {
  deals: DealMandate[];
  darkMode: boolean;
}

const DEFAULT_COMMITTEE_MEMBERS = [
  { name: 'Dr. Alistair Cole', role: 'Syndicate Desk Lead' },
  { name: 'Floyd Brink', role: 'Chief Risk Officer' },
  { name: 'Marcus Nkosi', role: 'DCM Director' },
  { name: 'Sarah Jenkins', role: 'DCM Managing Director (Chair)' }
];

export default function PricingCommittee({
  deals,
  darkMode,
}: PricingCommitteeProps) {
  // Select active deal for Pricing Committee
  const pricingDeals = deals.filter(d => d.currentStageIndex >= 3); // Available for pricing review
  const [selectedDealId, setSelectedDealId] = useState<string>(pricingDeals[0]?.id || deals[0]?.id || '');
  const activeDeal = deals.find(d => d.id === selectedDealId) || deals[0];

  // Voting state panel
  const [votes, setVotes] = useState<CommitteeVote[]>([
    { voterName: 'Dr. Alistair Cole', voterRole: 'Syndicate Desk Lead', vote: 'Approve', conditions: 'Condition: Final bookbuilding subscription must reach at least 1.5x cover.', timestamp: '2026-07-25 11:30' },
    { voterName: 'Floyd Brink', voterRole: 'Chief Risk Officer', vote: 'Approve with Conditions', conditions: 'Condition: Sovereign guarantee letter must be signed and verified by Treasury.', timestamp: '2026-07-25 11:45' },
    { voterName: 'Marcus Nkosi', voterRole: 'DCM Director', vote: 'Approve', conditions: 'None.', timestamp: '2026-07-25 11:55' },
    { voterName: 'Sarah Jenkins', voterRole: 'DCM Managing Director (Chair)', vote: 'Approve', conditions: 'None.', timestamp: '2026-07-25 12:05' }
  ]);

  const [couponRate, setCouponRate] = useState(activeDeal ? 5.85 : 5.5);
  const [yieldRate, setYieldRate] = useState(activeDeal ? 5.95 : 5.6);
  const [spreadBps, setSpreadBps] = useState(activeDeal ? 145 : 120);
  const [resolutionText, setResolutionText] = useState(
    "THE COMMITTEE HEREBY RESOLVES that the proposed pricing structure meets all conservative risk thresholds. The syndicate desk is cleared to open the bookbuilt order logs."
  );

  const handleCastVote = (voterIdx: number, voteType: 'Approve' | 'Approve with Conditions' | 'Reject', conditionStr: string) => {
    const updatedVotes = votes.map((v, idx) => {
      if (idx === voterIdx) {
        return {
          ...v,
          vote: voteType,
          conditions: conditionStr,
          timestamp: new Date().toISOString().split('T')[0] + ' ' + new Date().toTimeString().split(' ')[0].substring(0, 5)
        };
      }
      return v;
    });
    setVotes(updatedVotes);
  };

  // Tally votes
  const approvedVotesCount = votes.filter(v => v.vote === 'Approve' || v.vote === 'Approve with Conditions').length;
  const isApproved = approvedVotesCount >= Math.ceil(DEFAULT_COMMITTEE_MEMBERS.length / 2);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">PRICING COMMITTEE DESK</h2>
          <p className="text-xs text-slate-500 font-mono">Cast advisory votes, record covenants, and approve underwrite yield caps</p>
        </div>
        <div>
          <select
            value={selectedDealId}
            onChange={(e) => setSelectedDealId(e.target.value)}
            className={`p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-300'}`}
          >
            {pricingDeals.map(d => (
              <option key={d.id} value={d.id}>{d.bondName} (# {d.id})</option>
            ))}
          </select>
        </div>
      </div>

      {activeDeal ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1 & 2: Voting and Board members */}
          <div className="lg:col-span-2 space-y-6">
            {/* Committee status */}
            <div className={`p-5 border rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-3.5">
                <div className={`p-3 rounded-md ${isApproved ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                  {isApproved ? <CheckCircle2 size={24} /> : <XCircle size={24} />}
                </div>
                <div>
                  <h3 className="text-xs font-bold tracking-wider uppercase font-sans">PRICING RESOLUTION RATIO</h3>
                  <p className="text-base font-extrabold font-mono mt-1 text-slate-200 dark:text-slate-100">
                    {approvedVotesCount} OF {DEFAULT_COMMITTEE_MEMBERS.length} VOTERS CLEAR
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">
                    Covenants check: <span className="text-emerald-500">100% compliant</span>
                  </p>
                </div>
              </div>

              <div>
                {isApproved ? (
                  <span className="px-3 py-1.5 text-xs font-bold font-mono bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 rounded-md uppercase tracking-wide">
                    PASSED COMMITTEE RESOLUTION
                  </span>
                ) : (
                  <span className="px-3 py-1.5 text-xs font-bold font-mono bg-rose-500/10 text-rose-500 border border-rose-500/20 rounded-md uppercase tracking-wide">
                    REJECTED / INSUFFICIENT QUORUM
                  </span>
                )}
              </div>
            </div>

            {/* Voting List */}
            <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
                <UsersRound size={14} className="text-amber-500" />
                Pricing Board voters List
              </h3>

              <div className="space-y-4 font-sans">
                {votes.map((voter, idx) => {
                  let badge = 'bg-blue-500/10 text-blue-500 border-blue-500/20';
                  if (voter.vote === 'Approve') badge = 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
                  else if (voter.vote === 'Approve with Conditions') badge = 'bg-amber-500/10 text-amber-500 border-amber-500/20';
                  else if (voter.vote === 'Reject') badge = 'bg-rose-500/10 text-rose-500 border-rose-500/20';

                  return (
                    <div key={voter.voterName} className="p-3.5 bg-slate-900/30 border border-slate-800/60 rounded-md space-y-3">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                        <div>
                          <span className="text-xs font-bold text-slate-200 dark:text-slate-100 block">{voter.voterName}</span>
                          <span className="text-[10px] text-slate-500 font-mono block mt-0.5">{voter.voterRole}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 border rounded-md ${badge}`}>
                            {voter.vote}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">{voter.timestamp}</span>
                        </div>
                      </div>

                      {voter.conditions !== 'None.' && (
                        <p className="text-[11px] leading-relaxed text-slate-400 font-mono bg-slate-900/40 p-2 border border-slate-800/50 rounded-md">
                          {voter.conditions}
                        </p>
                      )}

                      {/* Cast/Modify Vote Sliders/Buttons */}
                      <div className="flex space-x-2 pt-2 border-t border-slate-800/30">
                        <button
                          type="button"
                          onClick={() => handleCastVote(idx, 'Approve', 'None.')}
                          className="px-2.5 py-1 text-[10px] font-mono border border-emerald-500/30 hover:bg-emerald-500/10 text-emerald-500 transition-colors rounded-md"
                        >
                          CAST: APPROVE
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const condition = prompt("Enter specific Pricing Covenants / Conditions:") || "None.";
                            handleCastVote(idx, 'Approve with Conditions', condition);
                          }}
                          className="px-2.5 py-1 text-[10px] font-mono border border-amber-500/30 hover:bg-amber-500/10 text-amber-500 transition-colors rounded-md"
                        >
                          CAST: CONDITIONAL
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const reason = prompt("Enter Rejection notes:") || "Does not meet conservative spread guidelines.";
                            handleCastVote(idx, 'Reject', `Rejected: ${reason}`);
                          }}
                          className="px-2.5 py-1 text-[10px] font-mono border border-rose-500/30 hover:bg-rose-500/10 text-rose-500 transition-colors rounded-md"
                        >
                          CAST: REJECT
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Column 3: Pricing calibration & covenants notepad */}
          <div className="space-y-6">
            {/* Coupon and spread settings */}
            <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-1.5">
                <Scale size={14} />
                Pricing calibrations
              </h4>

              <div className="space-y-4 font-mono text-xs">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Coupon pricing Rate (%)</label>
                  <input
                    type="number" step="0.05"
                    value={couponRate}
                    onChange={e => setCouponRate(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Expected Pricing Yield (%)</label>
                  <input
                    type="number" step="0.05"
                    value={yieldRate}
                    onChange={e => setYieldRate(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Primary Underwrite Spread (Bps)</label>
                  <input
                    type="number"
                    value={spreadBps}
                    onChange={e => setSpreadBps(Number(e.target.value))}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>
              </div>
            </div>

            {/* Final resolution drafting paper */}
            <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[320px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <FileSignature size={14} />
                Signed Resolution Text
              </h3>
              <p className="text-[10px] text-slate-500 font-sans leading-relaxed mb-3">
                Edit final board resolution draft that is compiled into the compliance ledger.
              </p>
              <textarea
                value={resolutionText}
                onChange={e => setResolutionText(e.target.value)}
                className={`flex-1 p-2 text-xs border rounded-md focus:outline-none resize-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          No pipeline deals available for pricing reviews.
        </div>
      )}
    </div>
  );
}
