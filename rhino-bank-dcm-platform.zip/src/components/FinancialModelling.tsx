/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from 'recharts';
import { 
  Calculator, 
  Settings, 
  DollarSign, 
  Table, 
  Layers, 
  ArrowRightLeft,
  Sparkles,
  Percent
} from 'lucide-react';
import { BondStructure } from '../types';
import { generateFinancialModel } from '../utils';

interface FinancialModellingProps {
  bonds: BondStructure[];
  darkMode: boolean;
}

export default function FinancialModelling({
  bonds,
  darkMode,
}: FinancialModellingProps) {
  const [selectedBondId, setSelectedBondId] = useState<string>(bonds[0]?.id || '');
  const [isAmortizing, setIsAmortizing] = useState(false);
  const [discountRate, setDiscountRate] = useState(6.0);
  const [projectCashFlowAnnual, setProjectCashFlowAnnual] = useState(0); // 0 means default auto-calculated

  const activeBond = bonds.find(b => b.id === selectedBondId) || bonds[0];

  const model = activeBond 
    ? generateFinancialModel(
        activeBond.principalAmount,
        activeBond.couponRate,
        activeBond.couponFrequency,
        activeBond.maturityYears,
        isAmortizing,
        projectCashFlowAnnual,
        discountRate
      )
    : null;

  // Formatting large currency helper
  const formatCurr = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: activeBond?.currency || 'USD', maximumFractionDigits: 0 }).format(val);
  };

  // Sensitivity Matrix Pivot
  // In utils.ts we generated a flat matrix of 25 cells (5 coupons x 5 discount rates)
  // Let's group them to render a Pivot Table
  const discountSteps = model 
    ? Array.from(new Set(model.sensitivityMatrix.map(s => s.discountRate))).sort((a,b) => a - b)
    : [];
  const couponSteps = model
    ? Array.from(new Set(model.sensitivityMatrix.map(s => s.couponRate))).sort((a,b) => a - b)
    : [];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold tracking-tight font-sans">QUANTITATIVE DEBT MODELLING</h2>
        <p className="text-xs text-slate-500 font-mono">Simulate amortization schedules, debt service covers, and NPV/IRR sensitivities</p>
      </div>

      {/* Bond Selector & Parameters */}
      <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Select Bond */}
          <div>
            <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Target Bond</label>
            <select
              value={selectedBondId}
              onChange={(e) => {
                setSelectedBondId(e.target.value);
                setProjectCashFlowAnnual(0); // Reset custom cashflow
              }}
              className={`w-full p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
            >
              {bonds.map(b => (
                <option key={b.id} value={b.id}>{b.bondName} (${(b.principalAmount/1000000).toFixed(0)}M)</option>
              ))}
            </select>
          </div>

          {/* Schedule toggle */}
          <div>
            <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Structure Type</label>
            <div className="flex rounded-md overflow-hidden border border-slate-800/20 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsAmortizing(false)}
                className={`flex-1 py-1.5 text-xs font-mono transition-all ${!isAmortizing ? 'bg-amber-500 text-slate-900 font-bold' : darkMode ? 'bg-slate-900 text-slate-400' : 'bg-slate-100 text-slate-600'}`}
              >
                BULLET
              </button>
              <button
                type="button"
                onClick={() => setIsAmortizing(true)}
                className={`flex-1 py-1.5 text-xs font-mono transition-all ${isAmortizing ? 'bg-amber-500 text-slate-900 font-bold' : darkMode ? 'bg-slate-900 text-slate-400' : 'bg-slate-100 text-slate-600'}`}
              >
                AMORTIZING
              </button>
            </div>
          </div>

          {/* Discount Rate */}
          <div>
            <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Discount Rate / WACC (%)</label>
            <input
              type="number" step="0.25"
              value={discountRate}
              onChange={(e) => setDiscountRate(Number(e.target.value))}
              className={`w-full p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
            />
          </div>

          {/* Custom Project Revenue */}
          <div>
            <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Annual Project EBITDA ($)</label>
            <input
              type="number"
              placeholder="Auto-calculated (1.45x cover)"
              value={projectCashFlowAnnual || ''}
              onChange={(e) => setProjectCashFlowAnnual(Number(e.target.value))}
              className={`w-full p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
            />
          </div>
        </div>
      </div>

      {model && activeBond ? (
        <>
          {/* Summary KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 font-mono">
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Project NPV</span>
              <span className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                {formatCurr(model.npv)}
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Internal Rate of Return</span>
              <span className="text-sm font-bold text-rose-500 mt-1 block">
                {model.irr.toFixed(2)}%
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Average DSCR Cover</span>
              <span className="text-sm font-bold text-emerald-500 mt-1 block">
                {model.averageDscr.toFixed(2)}x
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800/80' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Loan Life Cover (LLCR)</span>
              <span className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                {model.llcr.toFixed(2)}x
              </span>
            </div>
            <div className={`p-4 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 uppercase block">Break-even Tenure</span>
              <span className="text-sm font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                {model.breakEvenYear} Years
              </span>
            </div>
          </div>

          {/* Area Chart: Debt service cover */}
          <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4">Debt Service vs. Cash Flow Cover</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={model.cashFlows} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1f2937' : '#f3f4f6'} />
                  <XAxis dataKey="period" stroke="#94a3b8" fontSize={10} name="Period" />
                  <YAxis stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
                  <Tooltip formatter={(v) => formatCurr(v as number)} />
                  <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
                  <Area type="monotone" dataKey="projectCashFlow" stroke="#10b981" fillOpacity={0.1} fill="#10b981" name="Project Available Cash ($)" />
                  <Area type="monotone" dataKey="totalDebtService" stroke="#f59e0b" fillOpacity={0.15} fill="#f59e0b" name="Total Debt Service ($)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Columns: Amortisation ledger & NPV Sensitivity Table */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Cash flows table */}
            <div className={`p-5 border col-span-2 rounded-lg shadow-sm flex flex-col h-[420px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <Table size={14} />
                Amortisation Debt Schedule
              </h3>
              <div className="flex-1 overflow-auto">
                <table className="w-full text-left border-collapse text-xs font-mono">
                  <thead>
                    <tr className={`border-b tracking-wider uppercase text-[9px] ${darkMode ? 'border-slate-800 text-slate-500' : 'border-slate-200 text-slate-500'}`}>
                      <th className="pb-2">Period</th>
                      <th className="pb-2">Date</th>
                      <th className="pb-2 text-right">Outstanding</th>
                      <th className="pb-2 text-right">Interest</th>
                      <th className="pb-2 text-right">Principal</th>
                      <th className="pb-2 text-right">Debt Service</th>
                      <th className="pb-2 text-right">Net Cover</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/10 dark:divide-slate-800/40">
                    {model.cashFlows.map(row => (
                      <tr key={row.period} className="hover:bg-slate-500/5">
                        <td className="py-2.5 font-bold text-slate-400">{row.period}</td>
                        <td className="py-2.5 text-slate-500">{row.date}</td>
                        <td className="py-2.5 text-right text-slate-400">{formatCurr(row.outstandingPrincipal)}</td>
                        <td className="py-2.5 text-right text-slate-300">{formatCurr(row.interestPayment)}</td>
                        <td className="py-2.5 text-right text-slate-300">{formatCurr(row.principalRepayment)}</td>
                        <td className="py-2.5 text-right font-bold text-slate-200 dark:text-slate-100">{formatCurr(row.totalDebtService)}</td>
                        <td className="py-2.5 text-right text-emerald-500 font-bold">{(row.projectCashFlow / row.totalDebtService).toFixed(2)}x</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* NPV Sensitivity Table */}
            <div className={`p-5 border rounded-lg shadow-sm h-[420px] flex flex-col ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <Percent size={14} />
                NPV Sensitivity Pivot Matrix
              </h3>
              <p className="text-[10px] text-slate-500 font-sans leading-relaxed mb-4">
                Simulates project Net Present Value (NPV, Millions) against variations in the **Discount Rate** (rows) and **Coupon Rate** (columns).
              </p>
              <div className="flex-1 overflow-auto">
                <table className="w-full text-left border-collapse text-[10px] font-mono border dark:border-slate-800">
                  <thead>
                    <tr className="bg-slate-900/60 border-b border-slate-800">
                      <th className="p-2 border-r dark:border-slate-800 text-slate-500 uppercase font-mono">Disc \ Coupon</th>
                      {couponSteps.map(c => (
                        <th key={c} className="p-2 text-right text-slate-400">{c.toFixed(2)}%</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {discountSteps.map(d => {
                      return (
                        <tr key={d} className="hover:bg-slate-500/5">
                          <td className="p-2 border-r dark:border-slate-800 bg-slate-900/20 font-bold text-slate-400">{d.toFixed(2)}%</td>
                          {couponSteps.map(c => {
                            const cell = model.sensitivityMatrix.find(s => s.discountRate === d && s.couponRate === c);
                            const valM = cell ? cell.npv / 1000000 : 0;
                            const isPositive = valM >= 0;
                            return (
                              <td 
                                key={c} 
                                className={`p-2 text-right font-semibold ${isPositive ? 'text-emerald-500 bg-emerald-500/5' : 'text-rose-500 bg-rose-500/5'}`}
                              >
                                ${valM.toFixed(1)}M
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          Please register or select a bond from the list.
        </div>
      )}
    </div>
  );
}
