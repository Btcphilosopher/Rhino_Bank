/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Settings, 
  HelpCircle, 
  TrendingUp, 
  Percent, 
  User, 
  FileText, 
  Table, 
  Sparkles,
  BarChart,
  ArrowRight
} from 'lucide-react';
import { IssuerProfile, CreditRatioMetrics, InternalCreditReport } from '../types';

interface CreditAnalysisProps {
  issuers: IssuerProfile[];
  darkMode: boolean;
}

export default function CreditAnalysis({
  issuers,
  darkMode,
}: CreditAnalysisProps) {
  const [selectedIssuerId, setSelectedIssuerId] = useState<string>(issuers[0]?.id || '');
  const activeIssuer = issuers.find(i => i.id === selectedIssuerId) || issuers[0];

  // Calculated ratios
  const [ratios, setRatios] = useState<CreditRatioMetrics>({
    debtToEquity: 1.1,
    interestCoverage: 4.5,
    debtToEbitda: 3.2,
    currentRatio: 1.6,
    cashToTotalDebt: 0.15,
    freeCashFlowCoverage: 1.2
  });

  const [creditOutlook, setCreditOutlook] = useState<'Stable' | 'Positive' | 'Negative' | 'Developing'>('Stable');
  const [riskRatingScore, setRiskRatingScore] = useState(72);
  const [analystSummary, setAnalystSummary] = useState(
    "Overall strong balance sheet with substantial state backing. Interest coverage is sound at 4.5x. Refinancing risk remains manageable due to robust liquidity levels."
  );

  // Auto-calculate ratios based on active issuer balance sheet values on selection change
  useEffect(() => {
    if (activeIssuer) {
      const fin = activeIssuer.financials;
      const debtToEbitda = fin.ebitda > 0 ? Number((fin.existingDebt / fin.ebitda).toFixed(2)) : 3.5;
      const debtToEquity = fin.existingEquity > 0 ? Number((fin.existingDebt / fin.existingEquity).toFixed(2)) : 1.2;
      const interestPaymentMock = fin.existingDebt * 0.0575; // assume 5.75% cost of debt
      const interestCoverage = interestPaymentMock > 0 ? Number((fin.ebitda / interestPaymentMock).toFixed(2)) : 4.0;
      const currentRatio = fin.totalLiabilities > 0 ? Number((fin.totalAssets / fin.totalLiabilities).toFixed(2)) : 1.5;
      const cashToTotalDebt = fin.existingDebt > 0 ? Number((fin.cashAndEquivalents / fin.existingDebt).toFixed(2)) : 0.12;
      const freeCashFlowCoverage = Number((fin.ebitda * 0.7 / interestPaymentMock).toFixed(2)); // assume FCF is 70% of EBITDA

      setRatios({
        debtToEquity,
        interestCoverage,
        debtToEbitda,
        currentRatio,
        cashToTotalDebt,
        freeCashFlowCoverage
      });

      // Risk score proxies
      let score = 70;
      if (activeIssuer.creditRating.startsWith('AAA')) score = 95;
      else if (activeIssuer.creditRating.startsWith('AA')) score = 88;
      else if (activeIssuer.creditRating.startsWith('A')) score = 80;
      else if (activeIssuer.creditRating.startsWith('BBB')) score = 70;
      else score = 55;
      setRiskRatingScore(score);

      setAnalystSummary(
        `Automated Credit Ledger Assessment: ${activeIssuer.name} presents a debt-to-EBITDA ratio of ${debtToEbitda}x and an interest cover of ${interestCoverage}x. Balance sheet strength is verified. Risk profile aligns with a long-term '${activeIssuer.creditRating}' corporate rating standard.`
      );
    }
  }, [selectedIssuerId, activeIssuer]);

  // Peer benchmark comparison list (mocked based on issuer sector)
  const peerBenchmarks = [
    { name: 'Standard SADC Peer Limit', dToE: 1.5, intCoverage: 3.5, rating: 'BBB' },
    { name: 'Nairobi Utility Index', dToE: 2.1, intCoverage: 2.8, rating: 'BB+' },
    { name: 'Pan-African Sovereign Minimum', dToE: 1.0, intCoverage: 5.0, rating: 'A' },
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">CREDIT ANALYSIS SUITE</h2>
          <p className="text-xs text-slate-500 font-mono">Perform leverage analysis, assess coverage margins, and log analyst summaries</p>
        </div>
        <div>
          <select
            value={selectedIssuerId}
            onChange={(e) => setSelectedIssuerId(e.target.value)}
            className={`p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-300'}`}
          >
            {issuers.map(i => (
              <option key={i.id} value={i.id}>{i.name}</option>
            ))}
          </select>
        </div>
      </div>

      {activeIssuer ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1 & 2: Ratio Cards & Analysis */}
          <div className="lg:col-span-2 space-y-6">
            {/* Leverage Ratios Grid */}
            <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
                <Percent size={14} className="text-amber-500" />
                Solvency & Coverage Indices
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 font-mono text-center">
                <div className="p-4 bg-slate-900/30 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] text-slate-500 uppercase block">Leverage (Debt/EBITDA)</span>
                  <span className={`text-base font-bold block mt-1 ${ratios.debtToEbitda > 4.0 ? 'text-rose-500' : 'text-slate-100'}`}>
                    {ratios.debtToEbitda}x
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-1">SADC Target: &lt; 3.5x</span>
                </div>

                <div className="p-4 bg-slate-900/30 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] text-slate-500 uppercase block">Interest Coverage</span>
                  <span className={`text-base font-bold block mt-1 ${ratios.interestCoverage < 2.5 ? 'text-rose-500' : 'text-emerald-500'}`}>
                    {ratios.interestCoverage}x
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-1">SADC Target: &lt; 3.0x</span>
                </div>

                <div className="p-4 bg-slate-900/30 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] text-slate-500 uppercase block">Liquidity (Current Ratio)</span>
                  <span className="text-base font-bold text-slate-100 block mt-1">
                    {ratios.currentRatio}x
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-1">SADC Target: &lt; 1.2x</span>
                </div>

                <div className="p-4 bg-slate-900/30 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] text-slate-500 uppercase block">Debt-to-Equity (D/E)</span>
                  <span className="text-base font-bold text-slate-100 block mt-1">
                    {ratios.debtToEquity}x
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-1">Target: &lt; 1.5x</span>
                </div>

                <div className="p-4 bg-slate-900/30 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] text-slate-500 uppercase block">Cash-to-Debt Cover</span>
                  <span className="text-base font-bold text-slate-100 block mt-1">
                    {(ratios.cashToTotalDebt * 100).toFixed(1)}%
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-1">Cash buffer index</span>
                </div>

                <div className="p-4 bg-slate-900/30 border border-slate-800/60 rounded-md">
                  <span className="text-[10px] text-slate-500 uppercase block">FCF Coverage Margin</span>
                  <span className="text-base font-bold text-slate-100 block mt-1">
                    {ratios.freeCashFlowCoverage}x
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-1">Principal debt backstop</span>
                </div>
              </div>
            </div>

            {/* Peer Comparison Ledger */}
            <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
                <Table size={14} />
                Corporate Peer Group & Underwrite limits
              </h3>
              
              <div className="overflow-x-auto font-mono text-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className={`border-b uppercase text-[9px] tracking-wider ${darkMode ? 'border-slate-800 text-slate-500' : 'border-slate-200 text-slate-500'}`}>
                      <th className="pb-2">Sovereign Benchmark / Index Group</th>
                      <th className="pb-2 text-right">Max Leverage (D/E)</th>
                      <th className="pb-2 text-right">Min Interest Coverage</th>
                      <th className="pb-2 text-right">Rating Floor</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/10 dark:divide-slate-800/40">
                    <tr className="bg-amber-500/5 font-bold border-l-2 border-amber-500">
                      <td className="py-3 pl-2 text-slate-300 dark:text-slate-100">{activeIssuer.name} (Active client)</td>
                      <td className="py-3 text-right text-slate-300 dark:text-slate-100">{ratios.debtToEquity}x</td>
                      <td className="py-3 text-right text-emerald-500">{ratios.interestCoverage}x</td>
                      <td className="py-3 text-right text-amber-500 pr-2">{activeIssuer.creditRating}</td>
                    </tr>
                    {peerBenchmarks.map((peer, idx) => (
                      <tr key={idx} className="hover:bg-slate-500/5">
                        <td className="py-3 pl-2 text-slate-400">{peer.name}</td>
                        <td className="py-3 text-right text-slate-500">{peer.dToE}x</td>
                        <td className="py-3 text-right text-slate-500">{peer.intCoverage}x</td>
                        <td className="py-3 text-right text-slate-500 font-bold pr-2">{peer.rating}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Column 3: Risk Score & Analyst Notepad */}
          <div className="space-y-6">
            {/* Risk Gauge */}
            <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <span className="text-[10px] font-mono tracking-widest text-amber-500 uppercase font-bold">
                INTERNAL RISK SCORE
              </span>
              <div className="flex items-baseline justify-between mt-3 font-mono">
                <span className="text-3xl font-extrabold text-slate-200 dark:text-slate-100">{riskRatingScore}</span>
                <span className="text-xs text-slate-500">Out of 100</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 mt-4 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${riskRatingScore > 80 ? 'bg-emerald-500' : riskRatingScore > 65 ? 'bg-amber-500' : 'bg-rose-500'}`} 
                  style={{ width: `${riskRatingScore}%` }} 
                />
              </div>
              <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1.5">
                <span>0 (Default Risk)</span>
                <span>100 (Sovereign Grade)</span>
              </div>
            </div>

            {/* Analyst Notepad */}
            <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[320px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
                <FileText size={14} />
                Analyst Ledger Notes
              </h3>
              
              <div className="mb-3">
                <label className="block text-[9px] font-mono text-slate-500 uppercase mb-1">Corporate Credit Outlook</label>
                <select
                  value={creditOutlook}
                  onChange={(e) => setCreditOutlook(e.target.value as any)}
                  className={`w-full p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                >
                  <option value="Stable">Stable Outlook</option>
                  <option value="Positive">Positive Outlook</option>
                  <option value="Negative">Negative Outlook</option>
                  <option value="Developing">Developing Outlook</option>
                </select>
              </div>

              <textarea
                value={analystSummary}
                onChange={(e) => setAnalystSummary(e.target.value)}
                className={`flex-1 p-2 text-xs border rounded-md focus:outline-none resize-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                placeholder="Log secondary due diligence observations, environmental rating covenants, or sovereign risk notes..."
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          Please register at least one issuer profile in Client Management.
        </div>
      )}
    </div>
  );
}
