/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  BarChart as RechartsBarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart as RechartsPieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';
import { 
  TrendingUp, 
  Coins, 
  Briefcase, 
  Leaf, 
  MapPin, 
  Layers, 
  AlertCircle,
  Clock,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { DealMandate, IssuerProfile, HistoricalIssuedBond } from '../types';

interface ExecutiveDashboardProps {
  deals: DealMandate[];
  issuers: IssuerProfile[];
  historicalBonds: HistoricalIssuedBond[];
  darkMode: boolean;
  onNavigateToDeal: (dealId: string) => void;
}

export default function ExecutiveDashboard({
  deals,
  issuers,
  historicalBonds,
  darkMode,
  onNavigateToDeal,
}: ExecutiveDashboardProps) {
  // Compute metrics
  const pipelineValue = deals.reduce((sum, d) => sum + d.targetVolume, 0);
  const YTD_CapitalRaised = historicalBonds.reduce((sum, b) => sum + b.volume, 0);
  
  // Estimated YTD Fees based on historical bonds (say average fee of 1.35%)
  const historicalFees = historicalBonds.reduce((sum, b) => sum + (b.volume * 0.0135), 0);
  const activeMandatesCount = deals.length;

  // Average coupon
  const totalCoupon = historicalBonds.reduce((sum, b) => sum + b.couponRate, 0);
  const avgCoupon = historicalBonds.length > 0 ? totalCoupon / historicalBonds.length : 5.8;

  // Average duration
  const totalDuration = historicalBonds.reduce((sum, b) => sum + b.durationYears, 0);
  const avgDuration = historicalBonds.length > 0 ? totalDuration / historicalBonds.length : 5.1;

  // Sector breakdown for chart
  const sectorDataMap: Record<string, number> = {};
  historicalBonds.forEach(b => {
    const s = b.sector.toLowerCase().includes('green') ? 'Green' : b.sector;
    sectorDataMap[s] = (sectorDataMap[s] || 0) + b.volume;
  });
  deals.forEach(d => {
    sectorDataMap[d.bondType] = (sectorDataMap[d.bondType] || 0) + d.targetVolume;
  });

  const sectorData = Object.keys(sectorDataMap).map(key => ({
    name: key,
    value: Math.round(sectorDataMap[key] / 1000000) // in Millions
  }));

  // Geographic distribution
  const geoDataMap: Record<string, number> = {};
  issuers.forEach(i => {
    const dealsForIssuer = deals.filter(d => d.issuerId === i.id);
    const vol = dealsForIssuer.reduce((sum, d) => sum + d.targetVolume, 0);
    geoDataMap[i.country] = (geoDataMap[i.country] || 0) + vol;
  });
  historicalBonds.forEach(b => {
    // deduce region country
    const country = b.region.includes('SA') || b.region.includes('Johannesburg') ? 'South Africa' : 'Kenya';
    geoDataMap[country] = (geoDataMap[country] || 0) + b.volume;
  });

  const geoData = Object.keys(geoDataMap).map(key => ({
    country: key,
    volume: Math.round(geoDataMap[key] / 1000000)
  }));

  const COLORS = ['#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899'];

  // Pipeline stages distribution
  const pipelineByStage = [
    { stage: 'Origination', count: deals.filter(d => d.currentStageIndex <= 3).length, value: deals.filter(d => d.currentStageIndex <= 3).reduce((sum, d) => sum + d.targetVolume, 0) / 1000000 },
    { stage: 'Structuring', count: deals.filter(d => d.currentStageIndex > 3 && d.currentStageIndex <= 7).length, value: deals.filter(d => d.currentStageIndex > 3 && d.currentStageIndex <= 7).reduce((sum, d) => sum + d.targetVolume, 0) / 1000000 },
    { stage: 'Syndicate & Book', count: deals.filter(d => d.currentStageIndex > 7 && d.currentStageIndex <= 12).length, value: deals.filter(d => d.currentStageIndex > 7 && d.currentStageIndex <= 12).reduce((sum, d) => sum + d.targetVolume, 0) / 1000000 },
    { stage: 'Settlement & Post', count: deals.filter(d => d.currentStageIndex > 12).length, value: deals.filter(d => d.currentStageIndex > 12).reduce((sum, d) => sum + d.targetVolume, 0) / 1000000 },
  ];

  return (
    <div className="space-y-6 h-full">
      {/* Page Title & Context */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">EXECUTIVE SCORECARD</h2>
          <p className="text-xs text-slate-500 font-mono">Consolidated Debt Capital Markets pipeline & advisory metrics</p>
        </div>
        <div className={`px-3 py-1.5 border text-xs font-mono flex items-center gap-2 ${darkMode ? 'border-slate-800 bg-slate-900/50 text-slate-400' : 'border-slate-200 bg-slate-100 text-slate-600'}`}>
          <Clock size={12} className="text-slate-400" />
          <span>PORTFOLIO AS OF: Q3 2026</span>
        </div>
      </div>

      {/* KPI Ribbons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">YTD CAPITAL RAISED</p>
              <h3 className="text-2xl font-bold tracking-tight mt-1 font-mono">${(YTD_CapitalRaised / 1000000).toFixed(0)}M</h3>
            </div>
            <div className={`p-2 rounded-md bg-amber-500/10 text-amber-500`}>
              <TrendingUp size={18} />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 font-mono flex items-center gap-1">
            <span className="text-emerald-500 font-semibold">↑ +14.2%</span> vs prior year YTD
          </p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-amber-500" />
        </div>

        {/* Metric 2 */}
        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">DCM ACTIVE PIPELINE</p>
              <h3 className="text-2xl font-bold tracking-tight mt-1 font-mono">${(pipelineValue / 1000000).toFixed(0)}M</h3>
            </div>
            <div className={`p-2 rounded-md bg-blue-500/10 text-blue-500`}>
              <Briefcase size={18} />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 font-mono">
            Across <span className="font-semibold text-slate-400 dark:text-slate-200">{activeMandatesCount} live mandates</span> in workflow
          </p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-blue-500" />
        </div>

        {/* Metric 3 */}
        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">ESTIMATED DCM FEES</p>
              <h3 className="text-2xl font-bold tracking-tight mt-1 font-mono">${(historicalFees / 1000000).toFixed(2)}M</h3>
            </div>
            <div className={`p-2 rounded-md bg-emerald-500/10 text-emerald-500`}>
              <Coins size={18} />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 font-mono">
            Weighted avg fee rate: <span className="font-semibold text-emerald-500">1.35%</span>
          </p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-emerald-500" />
        </div>

        {/* Metric 4 */}
        <div className={`p-5 border relative overflow-hidden rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 font-mono uppercase">AVG COUPON & DURATION</p>
              <h3 className="text-2xl font-bold tracking-tight mt-1 font-mono">{avgCoupon.toFixed(2)}% / {avgDuration.toFixed(1)}Y</h3>
            </div>
            <div className={`p-2 rounded-md bg-amber-500/10 text-amber-500`}>
              <Leaf size={18} />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 font-mono">
            Certified Greenium discount: <span className="text-emerald-500 font-semibold">-18 bps</span>
          </p>
          <div className="absolute bottom-0 left-0 w-full h-[3px] bg-amber-500" />
        </div>
      </div>

      {/* Charts Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Pipeline stage breakdown */}
        <div className={`p-5 border col-span-2 rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-xs font-bold tracking-wider uppercase font-sans">Mandate Pipeline Stage Allocation</h4>
            <span className="text-[10px] text-slate-500 font-mono">Values in Millions USD</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsBarChart data={pipelineByStage} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1f2937' : '#f3f4f6'} />
                <XAxis dataKey="stage" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={darkMode ? { backgroundColor: '#1e293b', border: '1px solid #475569', color: '#f1f5f9' } : { backgroundColor: '#ffffff', border: '1px solid #cbd5e1' }}
                  labelStyle={{ fontWeight: 'bold', fontSize: '11px' }}
                />
                <Bar dataKey="value" fill="#f59e0b" name="Pipeline ($M)">
                  {pipelineByStage.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </RechartsBarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Sector allocation */}
        <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h4 className="text-xs font-bold tracking-wider uppercase font-sans mb-4">Underwriting Exposure by Sector</h4>
          <div className="h-48 relative">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsPieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </RechartsPieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 text-[10px] font-mono">
            {sectorData.map((d, index) => (
              <div key={d.name} className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 inline-block" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                <span className="text-slate-400 truncate">{d.name}:</span>
                <span className="font-bold">${d.value}M</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Panel: Live pipeline & Regional exposure */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live Deals Tracker */}
        <div className={`p-5 border lg:col-span-2 rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-xs font-bold tracking-wider uppercase font-sans">Closing Mandates Pipeline Probability</h4>
            <span className="px-2 py-0.5 text-[9px] bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 font-mono rounded">ACTIVE DEALS</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className={`text-[10px] tracking-wider uppercase border-b ${darkMode ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'}`}>
                  <th className="pb-2 font-mono">Mandate</th>
                  <th className="pb-2 font-mono">Sector</th>
                  <th className="pb-2 font-mono text-right">Volume</th>
                  <th className="pb-2 font-mono text-right">Probability</th>
                  <th className="pb-2 font-mono text-right">Pipeline Stage</th>
                  <th className="pb-2 text-right"></th>
                </tr>
              </thead>
              <tbody className="text-xs divide-y divide-slate-800/10 dark:divide-slate-800/60 font-sans">
                {deals.map(deal => {
                  let badgeColor = 'bg-blue-500/10 text-blue-500';
                  if (deal.estimatedProbability >= 80) badgeColor = 'bg-emerald-500/10 text-emerald-500';
                  else if (deal.estimatedProbability < 70) badgeColor = 'bg-amber-500/10 text-amber-500';

                  return (
                    <tr key={deal.id} className="hover:bg-slate-500/5 transition-colors">
                      <td className="py-3 font-semibold text-slate-300 dark:text-slate-200">{deal.bondName}</td>
                      <td className="py-3 text-slate-500 text-[11px]">{deal.bondType}</td>
                      <td className="py-3 text-right font-mono font-medium text-slate-300 dark:text-slate-100">${(deal.targetVolume / 1000000).toFixed(0)}M</td>
                      <td className="py-3 text-right font-mono">
                        <span className={`px-2 py-0.5 font-bold rounded ${badgeColor}`}>
                          {deal.estimatedProbability}%
                        </span>
                      </td>
                      <td className="py-3 text-right font-mono text-slate-400 text-[11px]">
                        Stage {deal.currentStageIndex + 1}: {deal.workflowStages[deal.currentStageIndex].stageName}
                      </td>
                      <td className="py-3 text-right">
                        <button 
                          onClick={() => onNavigateToDeal(deal.id)}
                          className="p-1 hover:text-amber-500 transition-colors"
                          title="Drill-down to pipeline"
                        >
                          <ArrowUpRight size={14} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Regional Exposure */}
        <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h4 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
            <MapPin size={14} className="text-amber-500" />
            Regional Investment Exposure
          </h4>
          <div className="space-y-4 font-mono">
            {geoData.length === 0 ? (
              <p className="text-xs text-slate-500">No regional data calculated.</p>
            ) : (
              geoData.sort((a,b) => b.volume - a.volume).map(geo => {
                const percentage = Math.round((geo.volume / (YTD_CapitalRaised / 1000000 + pipelineValue / 1000000)) * 100) || 30;
                return (
                  <div key={geo.country} className="space-y-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-slate-300 dark:text-slate-200">{geo.country}</span>
                      <span className="text-slate-400 font-bold">${geo.volume}M ({percentage}%)</span>
                    </div>
                    <div className={`w-full h-1.5 bg-slate-800/20 dark:bg-slate-800 rounded-full overflow-hidden`}>
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: `${Math.min(100, Math.max(10, percentage))}%` }} />
                    </div>
                  </div>
                );
              })
            )}
            
            <div className={`mt-6 p-3.5 border text-[11px] leading-relaxed text-slate-500 rounded-lg bg-slate-900/50 dark:border-slate-800`}>
              <div className="flex items-start gap-2">
                <ShieldCheck size={14} className="text-emerald-500 shrink-0 mt-0.5" />
                <p>
                  <strong>Compliance Assurance:</strong> Regional exposure indices are locked. Sovereign ratings limit exposure caps across South Africa (BBB+/AA-), Kenya (A-), and Nigeria (AA).
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
