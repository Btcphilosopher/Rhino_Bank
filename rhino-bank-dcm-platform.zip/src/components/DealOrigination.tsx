/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  User, 
  FileText, 
  Plus, 
  TrendingUp, 
  Briefcase, 
  Users, 
  ArrowRight,
  Sparkles,
  Lock,
  Unlock,
  AlertCircle
} from 'lucide-react';
import { DealWorkflowStage, DealMandate, DealStageStatus, IssuerProfile } from '../types';

interface DealOriginationProps {
  deals: DealMandate[];
  setDeals: React.Dispatch<React.SetStateAction<DealMandate[]>>;
  issuers: IssuerProfile[];
  darkMode: boolean;
  selectedDealId: string | null;
  setSelectedDealId: (id: string | null) => void;
}

const STAGES_ORDER: DealWorkflowStage[] = [
  'Initial Client Meeting',
  'Opportunity Assessment',
  'Internal Screening',
  'Indicative Pricing',
  'Mandate Proposal',
  'Client Approval',
  'Due Diligence',
  'Investment Committee',
  'Pricing Committee',
  'Documentation',
  'Marketing',
  'Bookbuilding',
  'Allocation',
  'Settlement Simulation',
  'Post-Issue Monitoring'
];

export default function DealOrigination({
  deals,
  setDeals,
  issuers,
  darkMode,
  selectedDealId,
  setSelectedDealId,
}: DealOriginationProps) {
  const [selectedDeal, setSelectedDeal] = useState<DealMandate | null>(
    deals.find(d => d.id === selectedDealId) || deals[0] || null
  );
  const [activeStageIndex, setActiveStageIndex] = useState<number>(
    selectedDeal ? selectedDeal.currentStageIndex : 0
  );

  // Synchronization with external navigation
  React.useEffect(() => {
    if (selectedDealId) {
      const deal = deals.find(d => d.id === selectedDealId);
      if (deal) {
        setSelectedDeal(deal);
        setActiveStageIndex(deal.currentStageIndex);
      }
    }
  }, [selectedDealId, deals]);

  const selectDeal = (deal: DealMandate) => {
    setSelectedDeal(deal);
    setSelectedDealId(deal.id);
    setActiveStageIndex(deal.currentStageIndex);
  };

  // Create new Deal Proposal
  const handleCreateDeal = () => {
    if (issuers.length === 0) {
      alert("Please register at least one client profile first.");
      return;
    }
    const issuer = issuers[0];
    const newId = `deal-${String(deals.length + 1).padStart(3, '0')}`;
    
    // Construct default 15 stages
    const stages: DealStageStatus[] = STAGES_ORDER.map((stageName, index) => ({
      stageName,
      assignedStaff: 'Marcus Nkosi',
      deadline: new Date(Date.now() + (index + 1) * 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: index === 0 ? 'In Progress' : 'Not Started',
      approved: false,
      notes: `Awaiting activation of stage ${index + 1}.`,
      requiredDocs: [
        { name: `${stageName.replace(/\s+/g, '_')}_Paper_v1.pdf`, uploaded: false }
      ]
    }));

    const newDeal: DealMandate = {
      id: newId,
      issuerId: issuer.id,
      issuerName: issuer.name,
      bondName: `${issuer.name} Series I Refinancing Bond`,
      bondType: 'Infrastructure',
      targetVolume: 150000000,
      estimatedFeePercent: 1.25,
      estimatedProbability: 40,
      workflowStages: stages,
      currentStageIndex: 0,
      riskNotes: 'Primary risk covenants pending assessment.',
      createdDate: new Date().toISOString().split('T')[0]
    };

    const updated = [...deals, newDeal];
    setDeals(updated);
    setSelectedDeal(newDeal);
    setSelectedDealId(newId);
    setActiveStageIndex(0);
  };

  // Modify currently selected deal details
  const updateDeal = (updatedDeal: DealMandate) => {
    const updated = deals.map(d => d.id === updatedDeal.id ? updatedDeal : d);
    setDeals(updated);
    setSelectedDeal(updatedDeal);
  };

  // Save current active stage modifications
  const handleStagePropChange = (field: keyof DealStageStatus, value: any) => {
    if (!selectedDeal) return;
    const updatedStages = selectedDeal.workflowStages.map((stage, idx) => {
      if (idx === activeStageIndex) {
        return { ...stage, [field]: value };
      }
      return stage;
    });

    // Automatically recalculate deal stage if approved
    let currentStageIndex = selectedDeal.currentStageIndex;
    if (field === 'approved') {
      if (value === true) {
        // If approved and not final stage, set next stage in progress
        if (activeStageIndex < STAGES_ORDER.length - 1) {
          updatedStages[activeStageIndex].status = 'Completed';
          updatedStages[activeStageIndex + 1].status = 'In Progress';
          currentStageIndex = activeStageIndex + 1;
        } else {
          updatedStages[activeStageIndex].status = 'Completed';
        }
      } else {
        updatedStages[activeStageIndex].status = 'In Progress';
        currentStageIndex = activeStageIndex;
      }
    }

    updateDeal({
      ...selectedDeal,
      workflowStages: updatedStages,
      currentStageIndex
    });
  };

  // Toggle checklist item upload
  const handleDocToggle = (docIdx: number) => {
    if (!selectedDeal) return;
    const stage = selectedDeal.workflowStages[activeStageIndex];
    const updatedDocs = stage.requiredDocs.map((doc, idx) => {
      if (idx === docIdx) {
        return { ...doc, uploaded: !doc.uploaded };
      }
      return doc;
    });

    const updatedStages = selectedDeal.workflowStages.map((s, idx) => {
      if (idx === activeStageIndex) {
        return { ...s, requiredDocs: updatedDocs };
      }
      return s;
    });

    updateDeal({
      ...selectedDeal,
      workflowStages: updatedStages
    });
  };

  // Calculate project economics
  const totalPipelineFees = deals.reduce((sum, d) => sum + (d.targetVolume * (d.estimatedFeePercent / 100)), 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
      {/* Column 1: Mandates list */}
      <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[calc(100vh-140px)] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans">Mandate Book</h3>
            <p className="text-[10px] text-slate-500 font-mono">Active investment underwriting</p>
          </div>
          <button
            onClick={handleCreateDeal}
            className="flex items-center space-x-1 bg-amber-500 hover:bg-amber-600 text-slate-900 px-2 py-1.5 text-[10px] tracking-wide font-mono font-bold transition-colors rounded-md"
          >
            <Plus size={12} />
            <span>ORIGINATE</span>
          </button>
        </div>

        {/* Pipeline value box */}
        <div className="p-3 bg-slate-900/40 border border-slate-800/80 mb-4 rounded-md">
          <span className="text-[10px] font-mono text-slate-500 uppercase block">Total Pipeline Est. Fees</span>
          <span className="text-sm font-bold font-mono text-emerald-500 mt-1 block">
            ${(totalPipelineFees / 1000000).toFixed(2)}M
          </span>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {deals.map(deal => {
            const isSelected = selectedDeal && selectedDeal.id === deal.id;
            return (
              <div
                key={deal.id}
                onClick={() => selectDeal(deal)}
                className={`p-3 border cursor-pointer transition-all duration-150 rounded-md flex flex-col ${
                  isSelected 
                    ? 'border-amber-500 bg-amber-500/5' 
                    : darkMode 
                      ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/60'
                }`}
              >
                <div className="flex justify-between items-start">
                  <h4 className="text-[11px] font-bold text-slate-300 dark:text-slate-100 truncate pr-1">{deal.bondName}</h4>
                  <span className="text-[9px] font-bold font-mono text-slate-400 shrink-0">#{deal.id}</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mt-3">
                  <span className="truncate">{deal.bondType} ({deal.estimatedProbability}%)</span>
                  <span className="font-bold text-slate-300 dark:text-slate-200">${(deal.targetVolume / 1000000).toFixed(0)}M</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Column 2: 15-Stage Workflow visual timeline */}
      <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[calc(100vh-140px)] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3">15-Stage Core Pipeline</h3>
        <div className="flex-1 overflow-y-auto pr-1 space-y-1 timeline-scrollbar">
          {selectedDeal?.workflowStages.map((stage, idx) => {
            const isCurrentActive = activeStageIndex === idx;
            const isCompleted = stage.status === 'Completed' || stage.approved;
            const isFuture = stage.status === 'Not Started';

            let stepColor = 'text-slate-600 border-slate-800 bg-transparent';
            if (isCurrentActive) stepColor = 'text-amber-500 border-amber-500 bg-amber-500/10 font-bold';
            else if (isCompleted) stepColor = 'text-emerald-500 border-emerald-500/30 bg-emerald-500/5';

            return (
              <div
                key={stage.stageName}
                onClick={() => setActiveStageIndex(idx)}
                className={`p-2 border cursor-pointer transition-all flex items-center justify-between rounded-md text-[11px] font-mono ${stepColor}`}
              >
                <div className="flex items-center space-x-2 truncate">
                  <span className="text-[9px] font-mono text-slate-500 w-4">{idx + 1}</span>
                  {isCompleted ? (
                    <CheckCircle2 size={13} className="text-emerald-500" />
                  ) : isCurrentActive ? (
                    <Circle size={13} className="text-amber-500 animate-pulse" />
                  ) : (
                    <Circle size={13} className="text-slate-600" />
                  )}
                  <span className={`truncate ${isCurrentActive ? 'font-bold' : ''}`}>{stage.stageName}</span>
                </div>
                {idx === selectedDeal.currentStageIndex && (
                  <span className="text-[8px] tracking-widest text-amber-500 font-bold font-mono animate-pulse">LIVE</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Column 3 & 4: Active stage details panel */}
      <div className="lg:col-span-2 h-[calc(100vh-140px)] overflow-y-auto">
        {selectedDeal ? (
          (() => {
            const activeStage = selectedDeal.workflowStages[activeStageIndex];
            const isCurrentLive = selectedDeal.currentStageIndex === activeStageIndex;
            return (
              <div className={`p-6 border rounded-lg shadow-sm space-y-6 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                {/* Stage Header */}
                <div className="flex justify-between items-start border-b pb-4 border-slate-800/10 dark:border-slate-800">
                  <div>
                    <span className="text-[9px] font-mono tracking-widest text-amber-500 uppercase font-bold">
                      STAGE {activeStageIndex + 1} OF 15 • {activeStage.status}
                    </span>
                    <h3 className="text-base font-bold font-sans text-slate-200 dark:text-slate-100 mt-1">{activeStage.stageName}</h3>
                    <p className="text-[10px] text-slate-500 font-mono mt-1">
                      Assigned to mandate: <span className="text-slate-400 font-semibold">{selectedDeal.bondName}</span>
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {/* Approval toggle */}
                    {activeStage.approved ? (
                      <span className="px-2.5 py-1 text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center gap-1 rounded">
                        <Lock size={12} /> APPROVED
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 text-[10px] font-bold font-mono bg-amber-500/10 text-amber-500 border border-amber-500/20 flex items-center gap-1 rounded">
                        <Unlock size={12} /> PENDING SIGN-OFF
                      </span>
                    )}
                  </div>
                </div>

                {/* Mandate Probability & Economics Sliders (Editable if current live stage) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-slate-900/30 border border-slate-800/60 rounded-lg shadow-inner">
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Estimated Underwrite Fee (%)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={selectedDeal.estimatedFeePercent}
                      onChange={(e) => updateDeal({ ...selectedDeal, estimatedFeePercent: Number(e.target.value) })}
                      className={`w-full p-2 text-xs font-mono border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Deal Closing Probability (%)</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedDeal.estimatedProbability}
                      onChange={(e) => updateDeal({ ...selectedDeal, estimatedProbability: Number(e.target.value) })}
                      className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                    />
                    <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
                      <span>0%</span>
                      <span className="text-amber-500 font-bold">{selectedDeal.estimatedProbability}%</span>
                      <span>100%</span>
                    </div>
                  </div>
                </div>

                {/* Stage Parameters */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Assigned Officer / Staff</label>
                    <input
                      type="text"
                      value={activeStage.assignedStaff}
                      onChange={e => handleStagePropChange('assignedStaff', e.target.value)}
                      className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Milestone Deadline</label>
                    <input
                      type="date"
                      value={activeStage.deadline}
                      onChange={e => handleStagePropChange('deadline', e.target.value)}
                      className={`w-full p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                    />
                  </div>
                </div>

                {/* Staff stage notes */}
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Operational Stage Review & Notes</label>
                  <textarea
                    value={activeStage.notes}
                    onChange={e => handleStagePropChange('notes', e.target.value)}
                    rows={4}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                    placeholder="Enter due diligence, credit screening progress or committee feedback notes..."
                  />
                </div>

                {/* Document Verification Gate */}
                <div className="space-y-3">
                  <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase">Required Document Gates</h4>
                  <p className="text-[10px] text-slate-500 font-sans leading-relaxed">
                    Verify and click checkbox to simulate uploading and approving documents required for this specific origination gate.
                  </p>
                  <div className="space-y-2">
                    {activeStage.requiredDocs.map((doc, idx) => (
                      <div
                        key={idx}
                        onClick={() => handleDocToggle(idx)}
                        className={`p-3 border cursor-pointer flex items-center justify-between rounded-md transition-colors ${
                          doc.uploaded 
                            ? 'bg-emerald-500/5 border-emerald-500/30' 
                            : 'bg-slate-900/20 border-slate-800/80 hover:bg-slate-900/40'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <FileText size={14} className={doc.uploaded ? 'text-emerald-500' : 'text-slate-500'} />
                          <span className={`text-xs font-mono ${doc.uploaded ? 'text-slate-200 font-semibold' : 'text-slate-400'}`}>
                            {doc.name}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={doc.uploaded}
                          readOnly
                          className="w-4 h-4 rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Save & Approve Button */}
                <div className="flex justify-end gap-3 pt-4 border-t border-slate-800/20 dark:border-slate-800">
                  {!activeStage.approved ? (
                    <button
                      type="button"
                      onClick={() => handleStagePropChange('approved', true)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 text-xs font-mono tracking-wide rounded-md flex items-center gap-1.5 font-semibold"
                    >
                      <CheckCircle2 size={14} />
                      <span>SIGN-OFF & APPROVE STAGE</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleStagePropChange('approved', false)}
                      className="bg-amber-600 hover:bg-amber-700 text-white px-5 py-2 text-xs font-mono tracking-wide rounded-md flex items-center gap-1.5 font-semibold"
                    >
                      <AlertCircle size={14} />
                      <span>REVERT SIGN-OFF</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })()
        ) : (
          <div className="flex items-center justify-center h-full text-slate-500 text-xs font-mono">
            No deal selected. Register an issuer and originate a bond mandate from the left drawer.
          </div>
        )}
      </div>
    </div>
  );
}
