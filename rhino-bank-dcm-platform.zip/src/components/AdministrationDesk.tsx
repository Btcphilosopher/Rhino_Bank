/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sliders, 
  Settings, 
  HelpCircle, 
  RotateCcw, 
  ShieldAlert, 
  Cpu, 
  Server, 
  Sparkles,
  Save,
  CheckCircle2
} from 'lucide-react';

interface AdministrationDeskProps {
  darkMode: boolean;
  onResetDatabase: () => void;
}

export default function AdministrationDesk({
  darkMode,
  onResetDatabase,
}: AdministrationDeskProps) {
  // System configurations state
  const [maxUnderwritingSize, setMaxUnderwritingSize] = useState(500000000); // $500M
  const [systemAlertThreshold, setSystemAlertThreshold] = useState(85); // 85% utilization
  const [useBackupEngine, setUseBackupEngine] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold tracking-tight font-sans">ADMINISTRATION & SYSTEM DESK</h2>
        <p className="text-xs text-slate-500 font-mono">Configure global underwrite limits, adjust API endpoints, and flush local database states</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: System Parameter Controls */}
        <div className={`p-5 border lg:col-span-2 rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
            <Sliders size={14} className="text-amber-500" />
            Global Underwriting Bounds Settings
          </h3>

          <form onSubmit={handleSaveSettings} className="space-y-5 font-mono text-xs">
            <div>
              <label className="block text-[10px] text-slate-400 uppercase mb-1">Max Underwriting Tranche Size ($)</label>
              <input
                type="number" step="10000000"
                value={maxUnderwritingSize}
                onChange={e => setMaxUnderwritingSize(Number(e.target.value))}
                className={`w-full p-2.5 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
              />
              <span className="text-[9px] text-slate-500 mt-1 block">Upper absolute ceiling bound for single issues underwritten by Rhino syndicate desk.</span>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 uppercase mb-1">Global Stress-Test Utilization threshold (%)</label>
              <input
                type="number" min="50" max="100"
                value={systemAlertThreshold}
                onChange={e => setSystemAlertThreshold(Number(e.target.value))}
                className={`w-full p-2.5 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
              />
              <span className="text-[9px] text-slate-500 mt-1 block">Trigger warning alert flags if debt service allocations exceed this percentage of EBITDA.</span>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <input
                type="checkbox" id="backup" checked={useBackupEngine} onChange={() => setUseBackupEngine(!useBackupEngine)}
                className="w-4 h-4 text-amber-500 focus:ring-amber-500 border-slate-700 rounded accent-amber-500"
              />
              <label htmlFor="backup" className="text-xs text-slate-300 select-none">Deploy auxiliary secondary cashflow projection solvers (Secant fallback)</label>
            </div>

            <div className="flex items-center space-x-3 pt-4 border-t border-slate-800/30">
              <button
                type="submit"
                className="flex items-center space-x-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 px-4 py-2 text-xs font-mono transition-colors rounded-md font-bold"
              >
                <Save size={13} />
                <span>SAVE PARAMETERS</span>
              </button>
              {saved && (
                <span className="text-emerald-500 text-[10px] font-bold flex items-center gap-1 animate-pulse">
                  <CheckCircle2 size={12} />
                  SETTINGS COMMITTED SUCCESSFULLY
                </span>
              )}
            </div>
          </form>
        </div>

        {/* Right column: Database Reset / Diagnostics */}
        <div className="space-y-6">
          {/* Diagnostics */}
          <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-3 flex items-center gap-1.5">
              <Cpu size={14} />
              DCM Engine Diagnostics
            </h3>
            <div className="space-y-2.5 font-mono text-[10px] text-slate-400">
              <div className="flex justify-between border-b border-slate-800/30 pb-1.5">
                <span>Compiler:</span>
                <span className="text-slate-300 font-bold">Node ESM + Vite</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/30 pb-1.5">
                <span>AI Core:</span>
                <span className="text-amber-500 font-bold">Gemini-3.6-Flash SDK</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/30 pb-1.5">
                <span>Solver status:</span>
                <span className="text-emerald-500 font-bold">Running (Secant solver)</span>
              </div>
              <div className="flex justify-between">
                <span>Regional standard:</span>
                <span className="text-slate-300 font-bold">SADC Investment Grade</span>
              </div>
            </div>
          </div>

          {/* Database Reset Action */}
          <div className={`p-5 border border-rose-500/10 rounded-lg shadow-sm bg-rose-500/[0.02] ${darkMode ? '' : 'bg-white'}`}>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-1.5 text-rose-500 flex items-center gap-1.5">
              <ShieldAlert size={15} />
              Platform Database Flushing
            </h3>
            <p className="text-[10px] text-slate-500 font-sans leading-relaxed mb-4">
              Flushing state parameters restores the system to initial SADC seed files. Any manually added client issuers, deal mandates, or simulated bookbuilding bids will be deleted.
            </p>
            <button
              type="button"
              onClick={() => {
                if (confirm("Reset local database state back to default SADC seeds? This action cannot be undone.")) {
                  onResetDatabase();
                  alert("State flushed successfully.");
                }
              }}
              className="w-full flex items-center justify-center space-x-1 bg-rose-950/20 hover:bg-rose-950/40 border border-rose-500/20 hover:border-rose-500/40 text-rose-500 py-2.5 text-xs font-mono transition-colors rounded-md font-bold"
            >
              <RotateCcw size={13} />
              <span>FLUSH PLATFORM STATE</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
