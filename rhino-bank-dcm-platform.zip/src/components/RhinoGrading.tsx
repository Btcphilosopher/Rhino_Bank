/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Settings, 
  HelpCircle, 
  Sparkles, 
  Sliders, 
  ChevronRight,
  TrendingUp,
  Info,
  ShieldCheck
} from 'lucide-react';
import { BondStructure } from '../types';
import { calculateRhinoGrading } from '../utils';

interface RhinoGradingProps {
  bonds: BondStructure[];
  darkMode: boolean;
}

export default function RhinoGrading({
  bonds,
  darkMode,
}: RhinoGradingProps) {
  const [selectedBondId, setSelectedBondId] = useState<string>(bonds[0]?.id || '');
  const activeBond = bonds.find(b => b.id === selectedBondId) || bonds[0];

  // Sliders state
  const [creditQuality, setCreditQuality] = useState(75);
  const [couponScore, setCouponScore] = useState(80);
  const [yieldSpreadScore, setYieldSpreadScore] = useState(70);
  const [dscrScore, setDscrScore] = useState(85);
  const [projectQuality, setProjectQuality] = useState(80);
  const [sectorOutlook, setSectorOutlook] = useState(85);
  const [interestRateSensitivity, setInterestRateSensitivity] = useState(70);
  const [liquidityAssumptions, setLiquidityAssumptions] = useState(75);
  const [expectedInvestorDemand, setExpectedInvestorDemand] = useState(80);
  const [regionalOutlook, setRegionalOutlook] = useState(75);

  const [hoveredEx, setHoveredEx] = useState<string | null>(null);

  // Initialize sliders on bond change
  useEffect(() => {
    if (activeBond) {
      const grading = calculateRhinoGrading(
        activeBond.couponRate,
        activeBond.maturityYears,
        activeBond.security === 'Government Guaranteed' ? 'AAA' : 'BBB+', // proxy rating
        1.45, // default average dscr
        activeBond.useOfProceeds,
        activeBond.principalAmount
      );

      setCreditQuality(grading.scores.creditQuality);
      setCouponScore(grading.scores.couponCompetitiveness);
      setYieldSpreadScore(grading.scores.yieldSpreadCompetitive);
      setDscrScore(grading.scores.debtServiceCoverage);
      setProjectQuality(grading.scores.projectQuality);
      setSectorOutlook(grading.scores.sectorOutlook);
      setInterestRateSensitivity(grading.scores.interestRateSensitivity);
      setLiquidityAssumptions(grading.scores.liquidityAssumptions);
      setExpectedInvestorDemand(grading.scores.expectedInvestorDemand);
      setRegionalOutlook(grading.scores.regionalEconomicOutlook);
    }
  }, [selectedBondId, activeBond]);

  // Recalculate overall score based on weights
  const weightedScore = Math.round(
    creditQuality * 0.25 +
    couponScore * 0.15 +
    yieldSpreadScore * 0.10 +
    dscrScore * 0.15 +
    projectQuality * 0.10 +
    sectorOutlook * 0.10 +
    interestRateSensitivity * 0.05 +
    liquidityAssumptions * 0.05 +
    expectedInvestorDemand * 0.05 +
    regionalOutlook * 0.05
  );

  let calculatedRating: 'Rhino Platinum' | 'Rhino Gold' | 'Rhino Silver' | 'Investment Grade' | 'Watch List' | 'High Risk' = 'Investment Grade';
  if (weightedScore >= 97) calculatedRating = 'Rhino Platinum';
  else if (weightedScore >= 90) calculatedRating = 'Rhino Gold';
  else if (weightedScore >= 80) calculatedRating = 'Rhino Silver';
  else if (weightedScore >= 70) calculatedRating = 'Investment Grade';
  else if (weightedScore >= 60) calculatedRating = 'Watch List';
  else calculatedRating = 'High Risk';

  // Specific rating colors
  const getRatingColors = (rating: string) => {
    switch (rating) {
      case 'Rhino Platinum': return { bg: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20', glow: 'shadow-indigo-500/10 border-indigo-500' };
      case 'Rhino Gold': return { bg: 'bg-amber-500/10 text-amber-400 border-amber-500/20', glow: 'shadow-amber-500/10 border-amber-500' };
      case 'Rhino Silver': return { bg: 'bg-slate-300/10 text-slate-300 border-slate-300/20', glow: 'shadow-slate-400/10 border-slate-400' };
      case 'Investment Grade': return { bg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', glow: 'shadow-emerald-500/10 border-emerald-500' };
      case 'Watch List': return { bg: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20', glow: 'shadow-yellow-500/10 border-yellow-500' };
      default: return { bg: 'bg-rose-500/10 text-rose-500 border-rose-500/20', glow: 'shadow-rose-500/10 border-rose-500' };
    }
  };

  const colors = getRatingColors(calculatedRating);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight font-sans">RHINO CURVE GRADING MODEL</h2>
          <p className="text-xs text-slate-500 font-mono">Weighted risk score synthesizer and proprietary quality indexer</p>
        </div>
        <div>
          <select
            value={selectedBondId}
            onChange={(e) => setSelectedBondId(e.target.value)}
            className={`p-2 text-xs border rounded-md font-mono focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-300'}`}
          >
            {bonds.map(b => (
              <option key={b.id} value={b.id}>{b.bondName}</option>
            ))}
          </select>
        </div>
      </div>

      {activeBond ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Grade Dashboard Gauge */}
          <div className={`p-6 border flex flex-col justify-between rounded-lg shadow-sm h-[calc(100vh-230px)] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-amber-500 uppercase font-bold">
                PROPRIETARY RATING GRADE
              </span>
              <h3 className="text-sm font-bold font-sans text-slate-400 mt-1">{activeBond.bondName}</h3>
              <p className="text-[11px] text-slate-500 font-mono mt-0.5">ISIN: {activeBond.isin}</p>
            </div>

            {/* Huge Rating Number Dial */}
            <div className="my-8 flex flex-col items-center justify-center relative">
              <div className={`w-36 h-36 rounded-full border-4 flex flex-col items-center justify-center transition-all ${colors.glow}`}>
                <span className="text-4xl font-extrabold font-mono text-slate-100 dark:text-slate-100 tracking-tight">
                  {weightedScore}
                </span>
                <span className="text-[10px] font-mono text-slate-400 tracking-wider uppercase mt-1">
                  SCORE
                </span>
              </div>
              <div className={`mt-6 px-4 py-1.5 border text-xs font-bold font-mono tracking-wide rounded-md ${colors.bg}`}>
                {calculatedRating}
              </div>
            </div>

            {/* Weights Legend details */}
            <div className="space-y-3 font-sans text-xs">
              <span className="text-[9px] font-mono font-bold tracking-widest text-slate-500 uppercase block">
                CORE WEIGHT COEFFICIENTS:
              </span>
              <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 font-mono">
                <div>• Credit Quality: <span className="font-bold text-slate-300">25%</span></div>
                <div>• Debt service cover: <span className="font-bold text-slate-300">15%</span></div>
                <div>• Coupon competitiveness: <span className="font-bold text-slate-300">15%</span></div>
                <div>• Yield Spread: <span className="font-bold text-slate-300">10%</span></div>
                <div>• Project Quality: <span className="font-bold text-slate-300">10%</span></div>
                <div>• Sector Outlook: <span className="font-bold text-slate-300">10%</span></div>
              </div>
            </div>
          </div>

          {/* Center & Right Column: Interactive Parameter Sliders */}
          <div className={`p-6 border lg:col-span-2 rounded-lg shadow-sm h-[calc(100vh-230px)] overflow-y-auto ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
              <Sliders size={14} className="text-amber-500" />
              Rhino Synthesis Control Board
            </h3>
            
            <div className="space-y-5 font-mono">
              {/* Slider 1: Credit */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Credit Rating Quality (25% Weight)</span>
                  <span className="font-bold text-amber-500">{creditQuality}/100</span>
                </div>
                <input
                  type="range" min="0" max="100" value={creditQuality}
                  onChange={e => setCreditQuality(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Slider 2: Coupon */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Coupon Yield competitiveness (15% Weight)</span>
                  <span className="font-bold text-amber-500">{couponScore}/100</span>
                </div>
                <input
                  type="range" min="0" max="100" value={couponScore}
                  onChange={e => setCouponScore(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Slider 3: DSCR */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Debt Service Cashflow Cover (15% Weight)</span>
                  <span className="font-bold text-amber-500">{dscrScore}/100</span>
                </div>
                <input
                  type="range" min="0" max="100" value={dscrScore}
                  onChange={e => setDscrScore(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Slider 4: Yield Spread */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Primary Market Yield Spread (10% Weight)</span>
                  <span className="font-bold text-amber-500">{yieldSpreadScore}/100</span>
                </div>
                <input
                  type="range" min="0" max="100" value={yieldSpreadScore}
                  onChange={e => setYieldSpreadScore(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Slider 5: Project Quality */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Socio-Economic Project Quality (10% Weight)</span>
                  <span className="font-bold text-amber-500">{projectQuality}/100</span>
                </div>
                <input
                  type="range" min="0" max="100" value={projectQuality}
                  onChange={e => setProjectQuality(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Slider 6: Sector Outlook */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Industrial Sector secular tailwinds (10% Weight)</span>
                  <span className="font-bold text-amber-500">{sectorOutlook}/100</span>
                </div>
                <input
                  type="range" min="0" max="100" value={sectorOutlook}
                  onChange={e => setSectorOutlook(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Secondary elements (5% each) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Rate Sensitivity</span>
                    <span className="font-bold text-slate-300">{interestRateSensitivity}</span>
                  </div>
                  <input
                    type="range" min="0" max="100" value={interestRateSensitivity}
                    onChange={e => setInterestRateSensitivity(Number(e.target.value))}
                    className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-slate-400"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Liquidity assumptions</span>
                    <span className="font-bold text-slate-300">{liquidityAssumptions}</span>
                  </div>
                  <input
                    type="range" min="0" max="100" value={liquidityAssumptions}
                    onChange={e => setLiquidityAssumptions(Number(e.target.value))}
                    className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-slate-400"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Expected investor appetite</span>
                    <span className="font-bold text-slate-300">{expectedInvestorDemand}</span>
                  </div>
                  <input
                    type="range" min="0" max="100" value={expectedInvestorDemand}
                    onChange={e => setExpectedInvestorDemand(Number(e.target.value))}
                    className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-slate-400"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Regional macro outlook</span>
                    <span className="font-bold text-slate-300">{regionalOutlook}</span>
                  </div>
                  <input
                    type="range" min="0" max="100" value={regionalOutlook}
                    onChange={e => setRegionalOutlook(Number(e.target.value))}
                    className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-slate-400"
                  />
                </div>
              </div>

              {/* Disclaimer */}
              <div className={`mt-6 p-4 border text-[11px] leading-relaxed text-slate-500 rounded-md bg-slate-900/50 dark:border-slate-800`}>
                <div className="flex items-start gap-2">
                  <ShieldCheck size={14} className="text-emerald-500 shrink-0 mt-0.5" />
                  <p>
                    <strong>Synthesis Compliance Certification:</strong> This control panel models synthetic variations of the Rhino Credit Metric. Real underwriting must proceed via the formal Investment Committee and Pricing Committee review gates.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-48 text-slate-500 text-xs font-mono">
          No structured bonds available for grading. Create one in Structuring.
        </div>
      )}
    </div>
  );
}
