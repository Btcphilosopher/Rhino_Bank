/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Sliders, 
  Search, 
  Layers, 
  Globe, 
  Calendar, 
  Info, 
  FileText, 
  ShieldCheck, 
  Flame,
  Leaf,
  Settings
} from 'lucide-react';
import { BondStructure, IssuerProfile, DealMandate } from '../types';

interface BondStructuringProps {
  bonds: BondStructure[];
  setBonds: React.Dispatch<React.SetStateAction<BondStructure[]>>;
  issuers: IssuerProfile[];
  deals: DealMandate[];
  darkMode: boolean;
}

const USE_OF_PROCEEDS_OPTIONS = [
  'Railway construction & freight logistics',
  'Hospital development & medical networks',
  'Sanitary housing & urban development',
  'Water purification & desalination infrastructure',
  'Seaport deepening & crane berths expansion',
  'Airport terminal & runway expansion',
  'Renewable geothermal & solar farm arrays',
  'Rural fiber data-center grids',
  'Clean manufacturing facilities expansion',
  'Regional corporate balance sheet refinancing'
];

export default function BondStructuring({
  bonds,
  setBonds,
  issuers,
  deals,
  darkMode,
}: BondStructuringProps) {
  const [selectedBond, setSelectedBond] = useState<BondStructure | null>(bonds[0] || null);
  const [isCreating, setIsCreating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states
  const [dealId, setDealId] = useState('');
  const [bondName, setBondName] = useState('');
  const [bondType, setBondType] = useState<'Corporate' | 'Infrastructure' | 'Municipal' | 'Green' | 'Project Finance' | 'Revenue' | 'Floating Rate Note' | 'Inflation Linked' | 'Convertible' | 'Zero Coupon'>('Infrastructure');
  const [principalAmount, setPrincipalAmount] = useState(200000000);
  const [couponRate, setCouponRate] = useState(5.75);
  const [couponFrequency, setCouponFrequency] = useState<'Annual' | 'Semi-Annual' | 'Quarterly' | 'Zero'>('Semi-Annual');
  const [maturityYears, setMaturityYears] = useState(10);
  const [currency, setCurrency] = useState<'USD' | 'EUR' | 'GBP' | 'AUD' | 'ZAR' | 'CHF'>('USD');
  const [issuePricePercent, setIssuePricePercent] = useState(100.0);
  const [security, setSecurity] = useState<'Unsecured' | 'Senior Secured' | 'Subordinated' | 'Asset-Backed' | 'Government Guaranteed'>('Senior Secured');
  const [listingExchange, setListingExchange] = useState('London Stock Exchange (LSE)');
  const [legalJurisdiction, setLegalJurisdiction] = useState('English Law');
  const [trustee, setTrustee] = useState('Deutsche Bank Trustees Ltd');
  const [useOfProceeds, setUseOfProceeds] = useState(USE_OF_PROCEEDS_OPTIONS[0]);
  const [purposeOfIssue, setPurposeOfIssue] = useState('Funding Mpumalanga logistics lines to boost national port exports.');
  const [callOptionDetails, setCallOptionDetails] = useState('Callable at par starting Year 5 on any coupon date.');
  const [putOptionDetails, setPutOptionDetails] = useState('None');
  const [guarantees, setGuarantees] = useState('Partial Sovereign Guarantee of 30% on principal.');

  const handleStartCreate = () => {
    setIsCreating(true);
    setSelectedBond(null);
    setBondName('TARG Mpumalanga Freight Corridor Bond v2');
    setDealId(deals[0]?.id || '');
    setPrincipalAmount(250000000);
    setCouponRate(6.25);
    setMaturityYears(15);
    setUseOfProceeds(USE_OF_PROCEEDS_OPTIONS[0]);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const activeDeal = deals.find(d => d.id === dealId);
    const issuerId = activeDeal ? activeDeal.issuerId : (issuers[0]?.id || 'iss-001');
    const issuerName = activeDeal ? activeDeal.issuerName : (issuers[0]?.name || 'Trans-African Rail Group');

    const generatedIsin = `XS${Math.floor(1000000000 + Math.random() * 9000000000)}`;

    const newBond: BondStructure = {
      id: `bond-${String(bonds.length + 1).padStart(3, '0')}`,
      dealId,
      issuerId,
      issuerName,
      bondName,
      principalAmount,
      couponRate,
      couponFrequency,
      maturityYears,
      currency,
      issuePricePercent,
      faceValue: principalAmount,
      issueDate: new Date().toISOString().split('T')[0],
      settlementDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      callOptionDetails,
      putOptionDetails,
      security,
      guarantees,
      trustee,
      legalJurisdiction,
      listingExchange,
      isin: generatedIsin,
      purposeOfIssue,
      useOfProceeds
    };

    const updated = [...bonds, newBond];
    setBonds(updated);
    setSelectedBond(newBond);
    setIsCreating(false);
  };

  const filteredBonds = bonds.filter(b => 
    b.bondName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.isin.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.issuerName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Column 1: Bonds List */}
      <div className={`p-5 border rounded-lg shadow-sm flex flex-col h-[calc(100vh-140px)] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans">Underwrite Registry</h3>
            <p className="text-[10px] text-slate-500 font-mono">Structured primary bonds</p>
          </div>
          <button
            onClick={handleStartCreate}
            className="flex items-center space-x-1 bg-amber-500 hover:bg-amber-600 text-slate-900 px-2.5 py-1.5 text-xs font-mono font-bold transition-colors rounded-md"
          >
            <Plus size={14} />
            <span>STRUCTURE</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search active books (ISIN, Issuer)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-8 pr-3 py-2 text-xs border rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500 ${
              darkMode 
                ? 'bg-slate-900 border-slate-800 text-slate-200 placeholder-slate-500' 
                : 'bg-white border-slate-300 text-slate-800'
            }`}
          />
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filteredBonds.map(b => {
            const isSelected = selectedBond && selectedBond.id === b.id;
            return (
              <div
                key={b.id}
                onClick={() => {
                  setSelectedBond(b);
                  setIsCreating(false);
                }}
                className={`p-3 border cursor-pointer transition-all duration-150 rounded-md ${
                  isSelected 
                    ? 'border-amber-500 bg-amber-500/5' 
                    : darkMode 
                      ? 'border-slate-800 bg-slate-900/40 hover:bg-slate-900' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/60'
                }`}
              >
                <div className="flex justify-between items-start">
                  <h4 className="text-xs font-bold text-slate-300 dark:text-slate-100 truncate pr-1">{b.bondName}</h4>
                  {b.bondName.toLowerCase().includes('green') && (
                    <Leaf size={14} className="text-emerald-500 shrink-0 mt-0.5" />
                  )}
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mt-3">
                  <span>ISIN: {b.isin}</span>
                  <span className="font-bold text-slate-300 dark:text-slate-100">${(b.principalAmount / 1000000).toFixed(0)}M</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Column 2 & 3: Details or Structuring Wizard Form */}
      <div className="lg:col-span-2 h-[calc(100vh-140px)] overflow-y-auto">
        {isCreating ? (
          /* Form UI */
          <form onSubmit={handleSave} className={`p-6 border rounded-lg shadow-sm space-y-6 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center border-b pb-4 border-slate-800/10 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold font-sans">Bond Structuring Engineering Panel</h3>
                <p className="text-[10px] text-slate-500 font-mono">Calibrate yield parameters, currency hedging, and proceed classifications</p>
              </div>
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className={`px-3 py-1.5 text-xs font-mono border transition-colors rounded-md ${darkMode ? 'border-slate-800 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'}`}
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-600 text-slate-900 px-4 py-1.5 text-xs font-mono font-bold transition-colors rounded-md"
                >
                  SAVE & COMPILE BOND
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Select Deal Mandate</label>
                <select
                  value={dealId} onChange={e => setDealId(e.target.value)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                >
                  {deals.map(d => (
                    <option key={d.id} value={d.id}>{d.bondName} (#{d.id})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Bond Instrument Name</label>
                <input
                  type="text" required
                  value={bondName} onChange={e => setBondName(e.target.value)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Bond Instrument Type</label>
                <select
                  value={bondType} onChange={e => setBondType(e.target.value as any)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                >
                  <option value="Corporate">Corporate Bonds</option>
                  <option value="Infrastructure">Infrastructure Bonds</option>
                  <option value="Municipal">Municipal Bonds</option>
                  <option value="Green">Certified Green Bonds</option>
                  <option value="Project Finance">Project Finance Bonds</option>
                  <option value="Revenue">Revenue Bonds</option>
                  <option value="Floating Rate Note">Floating Rate Note (FRN)</option>
                  <option value="Inflation Linked">Inflation Linked Bonds</option>
                  <option value="Convertible">Convertible Bonds</option>
                  <option value="Zero Coupon">Zero Coupon Bonds</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Volume / Principal Amount ($)</label>
                <input
                  type="number" required
                  value={principalAmount} onChange={e => setPrincipalAmount(Number(e.target.value))}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Fixed Coupon Rate (%)</label>
                <input
                  type="number" step="0.01" required
                  value={couponRate} onChange={e => setCouponRate(Number(e.target.value))}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Coupon Payment Frequency</label>
                <select
                  value={couponFrequency} onChange={e => setCouponFrequency(e.target.value as any)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                >
                  <option value="Annual">Annual</option>
                  <option value="Semi-Annual">Semi-Annual</option>
                  <option value="Quarterly">Quarterly</option>
                  <option value="Zero">Zero (Zero Coupon)</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Maturity Tenor (Years)</label>
                <input
                  type="number" required
                  value={maturityYears} onChange={e => setMaturityYears(Number(e.target.value))}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-955 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Currency Denomination</label>
                <select
                  value={currency} onChange={e => setCurrency(e.target.value as any)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="ZAR">ZAR (R)</option>
                  <option value="AUD">AUD (A$)</option>
                  <option value="CHF">CHF (Fr)</option>
                </select>
              </div>
            </div>

            {/* Credit Securitization */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase">Securitization & Legal Structure</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Security / Seniority Class</label>
                  <select
                    value={security} onChange={e => setSecurity(e.target.value as any)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  >
                    <option value="Unsecured">Unsecured</option>
                    <option value="Senior Secured">Senior Secured</option>
                    <option value="Subordinated">Subordinated</option>
                    <option value="Asset-Backed">Asset-Backed</option>
                    <option value="Government Guaranteed">Government Guaranteed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Listing Exchange</label>
                  <input
                    type="text"
                    value={listingExchange} onChange={e => setListingExchange(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Governing Legal Jurisdiction</label>
                  <input
                    type="text"
                    value={legalJurisdiction} onChange={e => setLegalJurisdiction(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Lead Trustee</label>
                  <input
                    type="text"
                    value={trustee} onChange={e => setTrustee(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>
              </div>
            </div>

            {/* Options details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Call Option Clauses</label>
                <input
                  type="text"
                  value={callOptionDetails} onChange={e => setCallOptionDetails(e.target.value)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Put Option Clauses</label>
                <input
                  type="text"
                  value={putOptionDetails} onChange={e => setPutOptionDetails(e.target.value)}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
            </div>

            {/* Use of proceeds */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase">Use of Proceeds & Capital Allocation</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">ESG Proceed Category</label>
                  <select
                    value={useOfProceeds} onChange={e => setUseOfProceeds(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  >
                    {USE_OF_PROCEEDS_OPTIONS.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Specific Guarantees / Backstops</label>
                  <input
                    type="text"
                    value={guarantees} onChange={e => setGuarantees(e.target.value)}
                    className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Capital Expenditure Purpose Statement</label>
                <textarea
                  value={purposeOfIssue} onChange={e => setPurposeOfIssue(e.target.value)}
                  rows={2}
                  className={`w-full p-2 text-xs border rounded-md focus:outline-none ${darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300'}`}
                />
              </div>
            </div>
          </form>
        ) : selectedBond ? (
          /* Bond Details View */
          <div className="space-y-6">
            {/* Header summary */}
            <div className={`p-6 border rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-4">
                <div className={`p-4 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-md`}>
                  <Sliders size={24} />
                </div>
                <div>
                  <div className="flex items-center space-x-3">
                    <h3 className="text-base font-bold font-sans text-slate-100 dark:text-slate-100">{selectedBond.bondName}</h3>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-500 uppercase border border-emerald-500/20 rounded">
                      {selectedBond.bondType}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-xs font-mono text-slate-400 mt-1.5">
                    <span>ISIN: {selectedBond.isin}</span>
                    <span>•</span>
                    <span>Issuer: {selectedBond.issuerName}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Structuring Parameters */}
            <div className={`p-6 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-1.5">
                <Globe size={14} />
                Primary Pricing & Yield Grid
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 font-mono">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Underwriting Volume</span>
                  <span className="text-base font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                    {selectedBond.currency} ${(selectedBond.principalAmount / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Fixed Coupon</span>
                  <span className="text-base font-bold text-rose-500 mt-1 block">
                    {selectedBond.couponRate.toFixed(2)}%
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Tenor / Maturity</span>
                  <span className="text-base font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                    {selectedBond.maturityYears} Years
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Payment Schedule</span>
                  <span className="text-base font-bold text-slate-200 dark:text-slate-100 mt-1 block">
                    {selectedBond.couponFrequency}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Par Issue Price</span>
                  <span className="text-sm font-bold text-slate-300 dark:text-slate-200 mt-1 block">
                    {selectedBond.issuePricePercent.toFixed(2)}%
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Face Nominal Value</span>
                  <span className="text-sm font-bold text-slate-300 dark:text-slate-200 mt-1 block">
                    ${(selectedBond.faceValue / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Issue Date</span>
                  <span className="text-sm font-bold text-slate-300 dark:text-slate-200 mt-1 block">
                    {selectedBond.issueDate}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Settlement Target</span>
                  <span className="text-sm font-bold text-slate-300 dark:text-slate-200 mt-1 block">
                    {selectedBond.settlementDate}
                  </span>
                </div>
              </div>
            </div>

            {/* Securitization and Legal Covenant Card */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Covenants */}
              <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-1.5">
                  <ShieldCheck size={14} className="text-emerald-500" />
                  Collateral & Covenant Protections
                </h4>
                <div className="space-y-4 text-xs font-sans">
                  <div>
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Priority seniority class:</span>
                    <span className="font-semibold text-slate-200 dark:text-slate-100 mt-1 block">{selectedBond.security}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Lead Trustee bank:</span>
                    <span className="font-semibold text-slate-200 dark:text-slate-100 mt-1 block">{selectedBond.trustee}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">External backstops / Guarantees:</span>
                    <span className="font-semibold text-slate-200 dark:text-slate-100 mt-1 block">{selectedBond.guarantees || 'No statutory guarantees registered.'}</span>
                  </div>
                </div>
              </div>

              {/* Exchange Details */}
              <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-4 flex items-center gap-1.5">
                  <Settings size={14} className="text-amber-500" />
                  Listing & Legal Governance
                </h4>
                <div className="space-y-4 text-xs font-sans">
                  <div>
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Listing registry:</span>
                    <span className="font-semibold text-slate-200 dark:text-slate-100 mt-1 block">{selectedBond.listingExchange}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Legal governing jurisdiction:</span>
                    <span className="font-semibold text-slate-200 dark:text-slate-100 mt-1 block">{selectedBond.legalJurisdiction}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Call option:</span>
                      <span className="text-[11px] text-slate-400 mt-1 block truncate" title={selectedBond.callOptionDetails}>{selectedBond.callOptionDetails || 'Bullet'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Put option:</span>
                      <span className="text-[11px] text-slate-400 mt-1 block truncate" title={selectedBond.putOptionDetails}>{selectedBond.putOptionDetails || 'None'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Use of Proceeds Box */}
            <div className={`p-6 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h4 className="text-[10px] font-bold tracking-widest font-mono text-amber-500 uppercase mb-3 flex items-center gap-1.5">
                <Leaf size={14} className="text-emerald-500" />
                ESG Use of Proceeds & CapEx Allocation
              </h4>
              <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-md text-xs">
                <span className="text-[10px] font-mono text-emerald-500 font-bold block uppercase mb-1">Proceeds Class:</span>
                <p className="font-semibold text-slate-200 dark:text-slate-100 mb-2 font-sans">{selectedBond.useOfProceeds}</p>
                <span className="text-[10px] font-mono text-slate-500 block uppercase mb-1">CapEx detailed statement:</span>
                <p className="text-slate-400 leading-relaxed font-sans">{selectedBond.purposeOfIssue}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-500 text-xs font-mono">
            No bond selected. Click structure to begin.
          </div>
        )}
      </div>
    </div>
  );
}
