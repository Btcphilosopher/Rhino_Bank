/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { 
  TrendingUp, 
  Sliders, 
  ArrowRight, 
  Calculator, 
  Activity, 
  Sparkles,
  Info
} from 'lucide-react';
import { YieldCurvePoint, YieldCurveSpreadMetrics } from '../types';
import { INITIAL_YIELD_CURVE_POINTS } from '../mockData';

interface YieldCurveAnalyticsProps {
  darkMode: boolean;
}

export default function YieldCurveAnalytics({
  darkMode,
}: YieldCurveAnalyticsProps) {
  // Sandbox Curve state
  const [curvePoints, setCurvePoints] = useState<YieldCurvePoint[]>(INITIAL_YIELD_CURVE_POINTS);
  const [selectedTenor, setSelectedTenor] = useState<number>(10);
  
  // Shock sliders
  const [parallelShift, setParallelShift] = useState<number>(0); // in basis points
  const [twistSlope, setTwistSlope] = useState<number>(0); // steepening / flattening

  const handleResetShock = () => {
    setParallelShift(0);
    setTwistSlope(0);
  };

  // Compute shocked curve in real-time
  const shockedCurvePoints = curvePoints.map(point => {
    // Parallel shift adds bps equally (e.g. +50 bps = +0.5%)
    const parallelShiftPct = parallelShift / 100;

    // Slope twist pivots around the 5Y tenor (index point tenor 5)
    // Long end rises, short end drops for steepening (+twist)
    const distanceFactor = (point.tenor - 5) / 25; // scaling factor
    const twistPct = (twistSlope / 100) * distanceFactor;

    const shiftedGovt = Math.max(0.1, point.govtRate + parallelShiftPct + twistPct);
    const shiftedCorp = Math.max(0.1, point.corpRate + parallelShiftPct + twistPct);
    const shiftedMuni = Math.max(0.1, point.muniRate + parallelShiftPct + twistPct);
    const shiftedInfra = Math.max(0.1, point.infraRate + parallelShiftPct + twistPct);

    return {
      ...point,
      govtRate: Number(shiftedGovt.toFixed(3)),
      corpRate: Number(shiftedCorp.toFixed(3)),
      muniRate: Number(shiftedMuni.toFixed(3)),
      infraRate: Number(shiftedInfra.toFixed(3))
    };
  });

  const activePoint = shockedCurvePoints.find(p => p.tenor === selectedTenor) || shockedCurvePoints[5]; // 10Y default

  // Calculate spreads in bps (1% = 100 bps)
  const corpSpreadBps = Math.round((activePoint.corpRate - activePoint.govtRate) * 100);
  const muniSpreadBps = Math.round((activePoint.muniRate - activePoint.govtRate) * 100);
  const infraSpreadBps = Math.round((activePoint.infraRate - activePoint.govtRate) * 100);

  // Steeper measure (30Y Govt - 1Y Govt)
  const govt30Y = shockedCurvePoints.find(p => p.tenor === 30)?.govtRate || 5.9;
  const govt1Y = shockedCurvePoints.find(p => p.tenor === 1)?.govtRate || 4.5;
  const computedSteepness = Math.round((govt30Y - govt1Y) * 100);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold tracking-tight font-sans">YIELD CURVE & CREDIT SPREADS</h2>
        <p className="text-xs text-slate-500 font-mono">Plot government benchmarks, calculate spreads, and model interest-rate twists</p>
      </div>

      {/* Sliders & Twist Sandbox */}
      <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xs font-bold tracking-wider uppercase font-sans flex items-center gap-1.5">
            <Sliders size={14} className="text-amber-500" />
            Macro Yield Shock Sandbox
          </h3>
          <button
            onClick={handleResetShock}
            className="px-2.5 py-1 text-[10px] font-mono border border-slate-700/30 hover:bg-amber-500/10 text-amber-500 transition-colors rounded-md"
          >
            RESET SHOCK
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Parallel Shift Slider */}
          <div>
            <div className="flex justify-between text-xs font-mono mb-1.5">
              <span className="text-slate-400">Parallel Shift (Bps)</span>
              <span className={`font-bold ${parallelShift > 0 ? 'text-emerald-500' : parallelShift < 0 ? 'text-rose-500' : 'text-slate-400'}`}>
                {parallelShift > 0 ? `+${parallelShift}` : parallelShift} bps
              </span>
            </div>
            <input
              type="range"
              min="-200"
              max="200"
              step="5"
              value={parallelShift}
              onChange={(e) => setParallelShift(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
              <span>-200 bps (Dovish)</span>
              <span>0 (Benchmark)</span>
              <span>+200 bps (Hawkish)</span>
            </div>
          </div>

          {/* Twisting / Slope Twist Slider */}
          <div>
            <div className="flex justify-between text-xs font-mono mb-1.5">
              <span className="text-slate-400">Curve Slope Twist (Steepening)</span>
              <span className={`font-bold ${twistSlope > 0 ? 'text-amber-500' : twistSlope < 0 ? 'text-blue-500' : 'text-slate-400'}`}>
                {twistSlope > 0 ? `Steepener (+${twistSlope})` : twistSlope < 0 ? `Flattener (${twistSlope})` : 'Neutral'}
              </span>
            </div>
            <input
              type="range"
              min="-150"
              max="150"
              step="5"
              value={twistSlope}
              onChange={(e) => setTwistSlope(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
              <span>Inversion (-150 bps)</span>
              <span>Flat</span>
              <span>Steepening (+150 bps)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Chart panel */}
      <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4">Sovereign & Credit Yield Term Structure</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={shockedCurvePoints} margin={{ top: 10, right: 20, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1f2937' : '#f3f4f6'} />
              <XAxis dataKey="tenor" stroke="#94a3b8" fontSize={10} name="Tenor (Y)" label={{ value: 'Tenor (Years)', position: 'insideBottom', offset: -5, fontSize: 10 }} />
              <YAxis stroke="#94a3b8" fontSize={10} label={{ value: 'Yield (%)', angle: -90, position: 'insideLeft', offset: 10, fontSize: 10 }} />
              <Tooltip formatter={(value) => `${value}%`} labelStyle={{ fontWeight: 'bold', fontSize: '11px', color: '#000' }} />
              <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
              <Line type="monotone" dataKey="govtRate" stroke="#64748b" strokeWidth={2} dot={{ r: 4 }} name="Govt Benchmark (%)" />
              <Line type="monotone" dataKey="corpRate" stroke="#3b82f6" strokeWidth={1.5} dot={{ r: 3 }} name="Corp Sector Curve (%)" />
              <Line type="monotone" dataKey="muniRate" stroke="#10b981" strokeWidth={1.5} dot={{ r: 3 }} name="Muni Revenue Curve (%)" />
              <Line type="monotone" dataKey="infraRate" stroke="#f59e0b" strokeWidth={2} dot={{ r: 4 }} name="Infrastructure Premium (%)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Credit spreads calculator widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tenor selector card */}
        <div className={`p-5 border rounded-lg shadow-sm ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h3 className="text-xs font-bold tracking-wider uppercase font-sans mb-4 flex items-center gap-1.5">
            <Calculator size={14} />
            Benchmark Tenor Pricing Spread
          </h3>
          <p className="text-[10px] text-slate-500 font-sans leading-relaxed mb-4">
            Select a benchmark maturity point to compute precise credit premiums and underwrite spreads.
          </p>
          <div className="grid grid-cols-4 gap-2 font-mono">
            {[1, 2, 3, 5, 7, 10, 20, 30].map(tenor => (
              <button
                key={tenor}
                onClick={() => setSelectedTenor(tenor)}
                className={`py-2 text-xs border transition-all rounded-md font-bold ${
                  selectedTenor === tenor 
                    ? 'bg-amber-500 text-slate-900 border-amber-500 font-bold' 
                    : darkMode 
                      ? 'border-slate-800 hover:bg-slate-800 text-slate-300' 
                      : 'border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                {tenor}Y
              </button>
            ))}
          </div>
        </div>

        {/* Spread breakdown card */}
        <div className={`p-5 border col-span-2 rounded-lg shadow-sm font-mono ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xs font-bold tracking-wider uppercase font-sans flex items-center gap-1.5">
              <Activity size={14} />
              Spreads Grid: {selectedTenor}Y Benchmark tenors
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Govt base: {activePoint.govtRate}%</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-3 bg-slate-900/30 border border-slate-800/60 rounded-md text-center">
              <span className="text-[9px] text-slate-500 uppercase block">Corp Spread</span>
              <span className="text-lg font-bold text-blue-500 mt-1 block">+{corpSpreadBps} bps</span>
              <span className="text-[10px] text-slate-400 font-semibold block mt-1">Yield: {activePoint.corpRate}%</span>
            </div>
            <div className="p-3 bg-slate-900/30 border border-slate-800/60 rounded-md text-center">
              <span className="text-[9px] text-slate-500 uppercase block">Muni Spread</span>
              <span className="text-lg font-bold text-emerald-500 mt-1 block">+{muniSpreadBps} bps</span>
              <span className="text-[10px] text-slate-400 font-semibold block mt-1">Yield: {activePoint.muniRate}%</span>
            </div>
            <div className="p-3 bg-slate-900/30 border border-slate-800/60 rounded-md text-center">
              <span className="text-[9px] text-slate-500 uppercase block">Infra Premium</span>
              <span className="text-lg font-bold text-amber-500 mt-1 block">+{infraSpreadBps} bps</span>
              <span className="text-[10px] text-slate-400 font-semibold block mt-1">Yield: {activePoint.infraRate}%</span>
            </div>
          </div>

          <div className={`mt-4 p-3 border text-[11px] leading-relaxed text-slate-500 rounded-lg bg-slate-900/40 dark:border-slate-800`}>
            <div className="flex items-start gap-2">
              <Info size={14} className="text-slate-400 shrink-0 mt-0.5" />
              <p>
                <strong>Term Premium & Steepness:</strong> The 30Y-1Y Government steepness is currently <strong className="text-slate-300">{computedSteepness} bps</strong>. Forward projections indicate a {computedSteepness > 100 ? 'steep rising cost trajectory' : 'flat stable pricing outlook'}.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
