/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  GitCommit, 
  SlidersHorizontal, 
  TrendingUp, 
  Award, 
  UsersRound, 
  Layers, 
  Scale, 
  ShieldAlert, 
  CalendarClock, 
  FolderGit, 
  FileCheck, 
  FileSpreadsheet, 
  UserSquare2, 
  Sun, 
  Moon, 
  Search, 
  Terminal,
  Activity,
  CheckCircle2
} from 'lucide-react';

export type ActiveModule =
  | 'dashboard'
  | 'clients'
  | 'deals'
  | 'structuring'
  | 'modelling'
  | 'yield-curve'
  | 'grading'
  | 'pricing-committee'
  | 'bookbuilding'
  | 'credit'
  | 'compliance'
  | 'portfolio'
  | 'reports'
  | 'admin';

interface SidebarProps {
  activeModule: ActiveModule;
  setActiveModule: (m: ActiveModule) => void;
  darkMode: boolean;
  setDarkMode: (d: boolean) => void;
  activeRole: string;
  setActiveRole: (r: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export default function Sidebar({
  activeModule,
  setActiveModule,
  darkMode,
  setDarkMode,
  activeRole,
  setActiveRole,
  searchQuery,
  setSearchQuery,
}: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard, category: 'CORE' },
    { id: 'clients', label: 'Client Management', icon: Users, category: 'ORIGINATION' },
    { id: 'deals', label: 'Deal Workflow (15-Stage)', icon: GitCommit, category: 'ORIGINATION' },
    { id: 'structuring', label: 'Bond Structuring & proceeds', icon: SlidersHorizontal, category: 'STRUCTURING' },
    { id: 'modelling', label: 'Financial Modelling', icon: FileSpreadsheet, category: 'STRUCTURING' },
    { id: 'yield-curve', label: 'Yield Curve Analytics', icon: TrendingUp, category: 'ANALYTICS' },
    { id: 'grading', label: 'Rhino Curve Grading', icon: Award, category: 'ANALYTICS' },
    { id: 'credit', label: 'Credit Analysis Suite', icon: Activity, category: 'ANALYTICS' },
    { id: 'pricing-committee', label: 'Pricing Committee', icon: UsersRound, category: 'EXECUTION' },
    { id: 'bookbuilding', label: 'Bookbuilding Simulator', icon: Layers, category: 'EXECUTION' },
    { id: 'compliance', label: 'Compliance & KYC Desk', icon: ShieldAlert, category: 'RISK' },
    { id: 'portfolio', label: 'Portfolio & Treasury', icon: FolderGit, category: 'MONITORING' },
    { id: 'reports', label: 'Reporting & GenAI', icon: FileCheck, category: 'MONITORING' },
    { id: 'admin', label: 'Administration Desk', icon: UserSquare2, category: 'SYSTEM' },
  ];

  const categories = ['CORE', 'ORIGINATION', 'STRUCTURING', 'ANALYTICS', 'EXECUTION', 'RISK', 'MONITORING', 'SYSTEM'];

  return (
    <div className={`w-80 border-r flex flex-col h-screen ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-[#fafafa] border-slate-200 text-slate-800'}`}>
      {/* Header */}
      <div className={`p-5 border-b flex items-center justify-between ${darkMode ? 'border-slate-800' : 'border-slate-200'}`}>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-amber-500 rounded flex items-center justify-center font-bold text-slate-900 tracking-wider">
            R
          </div>
          <div>
            <h1 className="font-bold tracking-tight text-lg">RHINO BANK</h1>
            <p className="text-[10px] tracking-widest text-slate-400 font-mono">DCM TERMINAL v4.2</p>
          </div>
        </div>
        <div className="flex space-x-1">
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className={`p-1.5 rounded-md border transition-all ${darkMode ? 'border-slate-800 text-yellow-500 hover:bg-slate-800' : 'border-slate-200 text-slate-600 hover:bg-slate-100'}`}
            title="Toggle theme"
          >
            {darkMode ? <Sun size={14} /> : <Moon size={14} />}
          </button>
        </div>
      </div>

      {/* Global Terminal Search */}
      <div className="p-4 border-b border-slate-800/10 dark:border-slate-800">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search terminal... (ISIN, Issuer)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-9 pr-3 py-2 text-xs border rounded-md font-mono focus:outline-none focus:ring-1 focus:ring-amber-500 ${
              darkMode 
                ? 'bg-slate-800 border-slate-700 text-slate-200 placeholder-slate-500' 
                : 'bg-white border-slate-300 text-slate-800 placeholder-slate-400'
            }`}
          />
        </div>
      </div>

      {/* Navigation list */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
        {categories.map((cat) => {
          const items = menuItems.filter(i => i.category === cat);
          if (items.length === 0) return null;
          return (
            <div key={cat} className="space-y-1">
              <span className="text-[10px] font-bold tracking-widest font-mono text-slate-500 pl-3 block mb-1">
                {cat}
              </span>
              {items.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveModule(item.id as ActiveModule)}
                    className={`w-full flex items-center space-x-3 px-3 py-2.5 text-xs transition-all duration-150 rounded-md font-sans ${
                      isActive
                        ? 'bg-amber-500/10 text-amber-500 font-medium'
                        : darkMode
                          ? 'text-slate-400 hover:bg-slate-800 hover:text-white'
                          : 'text-slate-600 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    <Icon size={16} className={isActive ? 'text-amber-500' : 'text-slate-500'} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Role Switcher & User Profile */}
      <div className={`p-4 border-t ${darkMode ? 'border-slate-800 bg-slate-950' : 'border-slate-200 bg-slate-100/50'}`}>
        <div className="flex items-center space-x-2.5 mb-3">
          <Terminal size={14} className="text-emerald-500" />
          <span className="text-[11px] font-mono font-semibold tracking-wider text-emerald-500 flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
            CONNECTED AS:
          </span>
        </div>
        <select
          value={activeRole}
          onChange={(e) => setActiveRole(e.target.value)}
          className={`w-full py-1.5 px-2.5 text-xs font-mono border rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500 ${
            darkMode 
              ? 'bg-slate-800 border-slate-700 text-slate-200' 
              : 'bg-white border-slate-300 text-slate-800'
          }`}
        >
          <option value="DCM Executive (MD)">DCM Executive (MD)</option>
          <option value="Relationship Banker">Relationship Banker</option>
          <option value="Quant Analyst">Quant Analyst</option>
          <option value="Compliance Officer">Compliance Officer</option>
          <option value="Syndicate Syndicate Trader">Syndicate Desk Lead</option>
        </select>
        <div className="mt-3 flex items-center space-x-2 text-[10px] text-slate-500 font-mono">
          <CheckCircle2 size={12} className="text-emerald-500" />
          <span>Role-based access fully active</span>
        </div>
      </div>
    </div>
  );
}
