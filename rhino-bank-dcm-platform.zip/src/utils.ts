/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CashFlowRow, FinancialAnalysis, SensitivityMatrixCell, RhinoGradingDetails, BookOrder, IssuerProfile } from './types';

/**
 * Solves for IRR (Internal Rate of Return) of a cash flow array using the Secant Method.
 */
export function calculateIRR(cashFlows: number[]): number {
  if (cashFlows.length === 0) return 0;

  // Secant Method parameters
  let x0 = 0.1; // 10% guess 1
  let x1 = 0.2; // 20% guess 2
  let f0 = calculateNPVForIRR(cashFlows, x0);
  let f1 = calculateNPVForIRR(cashFlows, x1);

  const maxIterations = 100;
  const tolerance = 1e-6;

  for (let i = 0; i < maxIterations; i++) {
    if (Math.abs(f1 - f0) < 1e-12) break;

    const xNext = x1 - f1 * (x1 - x0) / (f1 - f0);
    const fNext = calculateNPVForIRR(cashFlows, xNext);

    if (Math.abs(fNext) < tolerance) {
      return xNext * 100; // Return percentage
    }

    x0 = x1;
    f0 = f1;
    x1 = xNext;
    f1 = fNext;
  }

  // Fallback to average or guess if solver fails to converge
  return x1 * 100;
}

function calculateNPVForIRR(cashFlows: number[], rate: number): number {
  let npv = 0;
  for (let t = 0; t < cashFlows.length; t++) {
    npv += cashFlows[t] / Math.pow(1 + rate, t);
  }
  return npv;
}

/**
 * Generates the Amortisation Cash Flow Schedule.
 */
export function generateFinancialModel(
  principal: number,
  couponRate: number,
  frequency: 'Annual' | 'Semi-Annual' | 'Quarterly' | 'Zero',
  maturityYears: number,
  isAmortizing: boolean = false,
  baseProjectCashFlow: number = 0,
  discountRate: number = 6.0
): FinancialAnalysis {
  const periodsPerYear = frequency === 'Annual' ? 1 : frequency === 'Semi-Annual' ? 2 : frequency === 'Quarterly' ? 4 : 1;
  const totalPeriods = frequency === 'Zero' ? 1 : maturityYears * periodsPerYear;
  
  const couponRatePerPeriod = frequency === 'Zero' ? 0 : (couponRate / 100) / periodsPerYear;
  const discountRatePerPeriod = (discountRate / 100) / periodsPerYear;

  const rows: CashFlowRow[] = [];
  let outstandingPrincipal = principal;

  // Initial outflow at t = 0 (investment)
  const irrFlows: number[] = [-principal];
  const netFlows: number[] = [];

  // If no base cashflow is specified, assume a safe cover of 1.4x the average debt service
  const estimatedAnnualDebtService = isAmortizing 
    ? (principal / maturityYears) + (principal * (couponRate / 100))
    : principal * (couponRate / 100);
  const derivedProjectCashFlowAnnual = baseProjectCashFlow > 0 ? baseProjectCashFlow : estimatedAnnualDebtService * 1.45;
  const projectCashFlowPerPeriod = derivedProjectCashFlowAnnual / periodsPerYear;

  const today = new Date();

  for (let p = 1; p <= totalPeriods; p++) {
    const rowDate = new Date();
    rowDate.setMonth(today.getMonth() + (p * (12 / periodsPerYear)));
    const dateStr = rowDate.toISOString().split('T')[0];

    let interestPayment = outstandingPrincipal * couponRatePerPeriod;
    let principalRepayment = 0;

    if (frequency === 'Zero') {
      interestPayment = 0;
      principalRepayment = principal;
    } else if (p === totalPeriods) {
      principalRepayment = outstandingPrincipal; // Bullet repayment
    } else if (isAmortizing) {
      principalRepayment = principal / totalPeriods; // Straight-line amortisation
    }

    const totalDebtService = interestPayment + principalRepayment;
    const projectCF = projectCashFlowPerPeriod * (1 + (p * 0.005)); // 0.5% growth per period
    const netCF = projectCF - totalDebtService;

    rows.push({
      period: p,
      date: dateStr,
      outstandingPrincipal,
      interestPayment,
      principalRepayment,
      totalDebtService,
      projectCashFlow: projectCF,
      netCashFlow: netCF
    });

    irrFlows.push(projectCF); // IRR of the project cash flows
    outstandingPrincipal -= principalRepayment;
  }

  // NPV and IRR of project
  let npv = -principal;
  for (let i = 0; i < rows.length; i++) {
    const t = rows[i].period;
    npv += rows[i].projectCashFlow / Math.pow(1 + discountRatePerPeriod, t);
  }

  const irr = calculateIRR(irrFlows);

  // DSCR calculation
  let sumDscr = 0;
  let dscrCount = 0;
  rows.forEach(r => {
    if (r.totalDebtService > 0) {
      sumDscr += r.projectCashFlow / r.totalDebtService;
      dscrCount++;
    }
  });
  const averageDscr = dscrCount > 0 ? sumDscr / dscrCount : 1.5;

  // LLCR (NPV of remaining cash flows to loan maturity / remaining debt)
  // At period 0:
  let npvOfCForLLCR = 0;
  rows.forEach(r => {
    npvOfCForLLCR += r.projectCashFlow / Math.pow(1 + discountRatePerPeriod, r.period);
  });
  const llcr = npvOfCForLLCR / principal;

  // PLCR: Project life cashflows are longer than loan life. Assume project cashflow extends 1.5x times loan duration
  let npvProjectTotal = npvOfCForLLCR;
  const extraPeriods = Math.round(totalPeriods * 0.5);
  for (let p = totalPeriods + 1; p <= totalPeriods + extraPeriods; p++) {
    const extendedCF = projectCashFlowPerPeriod * (1 + (p * 0.005));
    npvProjectTotal += extendedCF / Math.pow(1 + discountRatePerPeriod, p);
  }
  const plcr = npvProjectTotal / principal;

  // Break-even period
  let cumulativeCash = -principal;
  let breakEvenYear = maturityYears;
  for (let i = 0; i < rows.length; i++) {
    cumulativeCash += rows[i].projectCashFlow;
    if (cumulativeCash >= 0) {
      breakEvenYear = Number((rows[i].period / periodsPerYear).toFixed(1));
      break;
    }
  }

  // Generate Sensitivity Matrix (varying coupon rate +/- 2% and discount rate +/- 2%)
  const sensitivityMatrix: SensitivityMatrixCell[] = [];
  const couponSteps = [couponRate - 1.5, couponRate - 0.75, couponRate, couponRate + 0.75, couponRate + 1.5];
  const discountSteps = [discountRate - 1.5, discountRate - 0.75, discountRate, discountRate + 0.75, discountRate + 1.5];

  discountSteps.forEach(disc => {
    couponSteps.forEach(coup => {
      let tempNpv = -principal;
      const coupRatePerP = (coup / 100) / periodsPerYear;
      const discRatePerP = (disc / 100) / periodsPerYear;
      let tempOutstanding = principal;

      for (let p = 1; p <= totalPeriods; p++) {
        const intPayment = tempOutstanding * coupRatePerP;
        let princRepayment = 0;
        if (p === totalPeriods) princRepayment = tempOutstanding;
        else if (isAmortizing) princRepayment = principal / totalPeriods;

        const totalDS = intPayment + princRepayment;
        const projectCF = projectCashFlowPerPeriod * (1 + (p * 0.005));
        
        tempNpv += projectCF / Math.pow(1 + discRatePerP, p);
        tempOutstanding -= princRepayment;
      }

      sensitivityMatrix.push({
        discountRate: disc,
        couponRate: coup,
        npv: tempNpv
      });
    });
  });

  return {
    cashFlows: rows,
    npv,
    irr,
    averageDscr,
    llcr,
    plcr,
    breakEvenYear,
    sensitivityMatrix
  };
}

/**
 * Calculates Rhino proprietary score (0 - 100) and rating grade.
 */
export function calculateRhinoGrading(
  couponRate: number,
  maturityYears: number,
  ratingStr: string,
  dscr: number,
  sector: string,
  targetVolume: number
): RhinoGradingDetails {
  // Let's formulate a scoring algorithm:
  // Rating quality mapping: AAA=100, AA=90, A=80, BBB=70, BB=50, B=30, CCC=10
  let creditQualityScore = 70;
  if (ratingStr.startsWith('AAA')) creditQualityScore = 100;
  else if (ratingStr.startsWith('AA+')) creditQualityScore = 95;
  else if (ratingStr.startsWith('AA')) creditQualityScore = 90;
  else if (ratingStr.startsWith('AA-')) creditQualityScore = 87;
  else if (ratingStr.startsWith('A+')) creditQualityScore = 82;
  else if (ratingStr.startsWith('A')) creditQualityScore = 80;
  else if (ratingStr.startsWith('A-')) creditQualityScore = 76;
  else if (ratingStr.startsWith('BBB+')) creditQualityScore = 72;
  else if (ratingStr.startsWith('BBB')) creditQualityScore = 68;
  else if (ratingStr.startsWith('BB+')) creditQualityScore = 55;
  else if (ratingStr.startsWith('BB')) creditQualityScore = 50;
  else if (ratingStr.startsWith('B')) creditQualityScore = 35;

  // Sector premium & quality score
  let sectorOutlookScore = 75;
  let projectQualityScore = 70;
  if (sector.toLowerCase().includes('green') || sector.toLowerCase().includes('renew')) {
    sectorOutlookScore = 95; // Green premium
    projectQualityScore = 90;
  } else if (sector.toLowerCase().includes('infra')) {
    sectorOutlookScore = 88;
    projectQualityScore = 85;
  } else if (sector.toLowerCase().includes('muni')) {
    sectorOutlookScore = 82;
    projectQualityScore = 80;
  } else if (sector.toLowerCase().includes('telecom') || sector.toLowerCase().includes('tech')) {
    sectorOutlookScore = 90;
    projectQualityScore = 82;
  }

  // DSCR quality score
  let dscrScore = 50;
  if (dscr >= 2.0) dscrScore = 100;
  else if (dscr >= 1.6) dscrScore = 90;
  else if (dscr >= 1.3) dscrScore = 80;
  else if (dscr >= 1.1) dscrScore = 70;
  else if (dscr >= 1.0) dscrScore = 60;
  else dscrScore = 40;

  // Coupon competitiveness
  // Lower coupon is better for issuer, but standard market needs pricing room.
  // Rate between 4% and 7.5% is typical.
  let couponScore = Math.max(0, Math.min(100, 100 - Math.abs(couponRate - 5.5) * 15));

  // Sensitivities
  const inflationSensitivity = couponRate > 6.5 ? 85 : 65; // Higher fixed rate is better against mild inflation
  const interestRateSensitivity = maturityYears > 15 ? 40 : maturityYears > 7 ? 70 : 90; // Shorter maturity is less sensitive to interest rate hikes (less duration risk)
  const durationMatch = maturityYears > 10 ? 88 : 78;
  const convexityProfile = maturityYears > 15 ? 90 : 65; // Higher maturity has higher convexity

  const yieldSpreadCompetitive = creditQualityScore * 0.9 + (couponRate > 5.0 ? 10 : -10);
  const expectedInvestorDemand = (sectorOutlookScore * 0.4) + (creditQualityScore * 0.4) + 20;
  const regionalEconomicOutlook = 78;
  const liquidityAssumptions = targetVolume > 300000000 ? 90 : 75; // Bigger volume has higher liquidity index

  // Calculate weighted score
  // 25% credit, 20% coupon/yield, 15% DSCR, 15% project/sector, 10% sensitivity/liquidity, 15% demand/regional
  const weightedScore = Math.round(
    creditQualityScore * 0.25 +
    couponScore * 0.15 +
    yieldSpreadCompetitive * 0.10 +
    dscrScore * 0.15 +
    projectQualityScore * 0.10 +
    sectorOutlookScore * 0.10 +
    interestRateSensitivity * 0.05 +
    liquidityAssumptions * 0.05 +
    expectedInvestorDemand * 0.05 +
    regionalEconomicOutlook * 0.05
  );

  let rating: 'Rhino Platinum' | 'Rhino Gold' | 'Rhino Silver' | 'Investment Grade' | 'Watch List' | 'High Risk' = 'Investment Grade';
  if (weightedScore >= 97) rating = 'Rhino Platinum';
  else if (weightedScore >= 90) rating = 'Rhino Gold';
  else if (weightedScore >= 80) rating = 'Rhino Silver';
  else if (weightedScore >= 70) rating = 'Investment Grade';
  else if (weightedScore >= 60) rating = 'Watch List';
  else rating = 'High Risk';

  const explanations: Record<string, string> = {
    couponCompetitiveness: `Scored ${couponScore.toFixed(0)}/100 based on the proposed ${couponRate}% coupon. Reflects excellent pricing efficiency relative to peer groups and the primary swap curve.`,
    durationMatch: `Scored ${durationMatch.toFixed(0)}/100. Measures asset-liability matching alignment. High long-term profile fits pension duration needs.`,
    convexityProfile: `Scored ${convexityProfile.toFixed(0)}/100. Long-duration convexity profiles support positive hedging values under changing yield curve shifts.`,
    creditQuality: `Scored ${creditQualityScore.toFixed(0)}/100. Based on standard credit agency rating of '${ratingStr}'. Highlights strong balance sheet metrics.`,
    yieldSpreadCompetitive: `Scored ${yieldSpreadCompetitive.toFixed(0)}/100. Reflects primary syndicate interest in capturing the proposed risk-adjusted asset premium over the benchmark curves.`,
    debtServiceCoverage: `Scored ${dscrScore.toFixed(0)}/100. Sound projected average DSCR of ${dscr.toFixed(2)}x guarantees robust cash cushions.`,
    projectQuality: `Scored ${projectQualityScore.toFixed(0)}/100. Projects such as high-capacity clean infrastructure or telecommunication assets score highly.`,
    sectorOutlook: `Scored ${sectorOutlookScore.toFixed(0)}/100. Positive secular headwinds drive capital into infrastructure and ESG green instruments.`,
    inflationSensitivity: `Scored ${inflationSensitivity.toFixed(0)}/100. High-yield instruments insulate investors during high consumer price index cycles.`,
    interestRateSensitivity: `Scored ${interestRateSensitivity.toFixed(0)}/100. Short to mid tenor curves protect bond principal from aggressive central bank tightening cycles.`,
    liquidityAssumptions: `Scored ${liquidityAssumptions.toFixed(0)}/100. Tranche sizing of $${(targetVolume / 1000000).toFixed(1)}M meets primary market liquidity indexes.`,
    expectedInvestorDemand: `Scored ${expectedInvestorDemand.toFixed(0)}/100. Substantial appetite indicated by SWF and pension funds for certified quality paper.`,
    regionalEconomicOutlook: `Scored ${regionalEconomicOutlook.toFixed(0)}/100. Reflects regional GDP projections, industrial investment indexes, and urban tax base sustainability.`
  };

  return {
    weightedScore,
    rating,
    scores: {
      couponCompetitiveness: couponScore,
      durationMatch,
      convexityProfile,
      creditQuality: creditQualityScore,
      yieldSpreadCompetitive,
      debtServiceCoverage: dscrScore,
      projectQuality: projectQualityScore,
      sectorOutlook: sectorOutlookScore,
      inflationSensitivity,
      interestRateSensitivity,
      liquidityAssumptions,
      expectedInvestorDemand,
      regionalEconomicOutlook
    },
    explanations
  };
}

/**
 * Simulates Bookbuilding Allocations.
 */
export function simulateAllocation(
  orders: BookOrder[],
  targetVolume: number,
  method: 'Pro-Rata' | 'Strategic Priority' | 'AUM Weighted' | 'Manual'
): BookOrder[] {
  const totalBidVolume = orders.reduce((sum, o) => sum + o.bidVolume, 0);
  
  if (totalBidVolume <= targetVolume) {
    // Under-subscribed, allocate everything fully
    return orders.map(o => ({ ...o, allocatedVolume: o.bidVolume }));
  }

  if (method === 'Manual') {
    return orders; // Managed manually in UI
  }

  if (method === 'Pro-Rata') {
    const ratio = targetVolume / totalBidVolume;
    return orders.map(o => ({
      ...o,
      allocatedVolume: Math.round(o.bidVolume * ratio)
    }));
  }

  if (method === 'AUM Weighted') {
    // In our mock database we don't have investor AUM on the order itself, but we can assign arbitrary priority weights based on category:
    // Sovereign Wealth / Pension Funds / Insurers get heavier weight, retail gets lower.
    let totalWeight = 0;
    const weightedOrders = orders.map(o => {
      let weight = 1.0;
      if (o.investorCategory.includes('Sovereign') || o.investorCategory.includes('Pension')) weight = 1.8;
      else if (o.investorCategory.includes('Insurance')) weight = 1.5;
      else if (o.investorCategory.includes('Asset')) weight = 1.2;
      else if (o.investorCategory.includes('Retail')) weight = 0.5;

      const orderWeight = o.bidVolume * weight;
      totalWeight += orderWeight;
      return { ...o, weightModifier: orderWeight };
    });

    const ratio = targetVolume / totalWeight;
    return weightedOrders.map(o => ({
      id: o.id,
      investorId: o.investorId,
      investorName: o.investorName,
      investorCategory: o.investorCategory,
      bidPrice: o.bidPrice,
      bidYield: o.bidYield,
      bidVolume: o.bidVolume,
      allocatedVolume: Math.min(o.bidVolume, Math.round(o.weightModifier * ratio)),
      timestamp: o.timestamp
    }));
  }

  if (method === 'Strategic Priority') {
    // Pension funds and sovereigns get filled 100%, insurance 85%, asset managers remaining, family offices/retail gets leftovers
    let remainingVolume = targetVolume;
    const sortedOrders = [...orders].sort((a, b) => {
      const getPriority = (cat: string) => {
        if (cat.includes('Sovereign') || cat.includes('Pension')) return 1;
        if (cat.includes('Insurance')) return 2;
        if (cat.includes('Asset')) return 3;
        return 4; // family / retail
      };
      return getPriority(a.investorCategory) - getPriority(b.investorCategory);
    });

    const allocationMap = new Map<string, number>();

    sortedOrders.forEach(o => {
      const category = o.investorCategory;
      let targetFill = o.bidVolume;

      if (category.includes('Insurance')) targetFill = Math.min(o.bidVolume, Math.round(o.bidVolume * 0.9));
      else if (category.includes('Asset')) targetFill = Math.min(o.bidVolume, Math.round(o.bidVolume * 0.7));
      else if (category.includes('Family') || category.includes('Retail')) targetFill = Math.min(o.bidVolume, Math.round(o.bidVolume * 0.4));

      const actualAllocated = Math.min(remainingVolume, targetFill);
      allocationMap.set(o.id, actualAllocated);
      remainingVolume -= actualAllocated;
    });

    // If we still have left-over volume due to scale-down, distribute proportionally to pension/sovereign
    if (remainingVolume > 0) {
      orders.forEach(o => {
        if (o.investorCategory.includes('Pension') || o.investorCategory.includes('Sovereign')) {
          const currentAlloc = allocationMap.get(o.id) || 0;
          const additionalAlloc = Math.min(remainingVolume, o.bidVolume - currentAlloc);
          allocationMap.set(o.id, currentAlloc + additionalAlloc);
          remainingVolume -= additionalAlloc;
        }
      });
    }

    return orders.map(o => ({
      ...o,
      allocatedVolume: allocationMap.get(o.id) || 0
    }));
  }

  return orders;
}
