/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Sidebar, { ActiveModule } from './components/Sidebar';
import ExecutiveDashboard from './components/ExecutiveDashboard';
import ClientManagement from './components/ClientManagement';
import DealOrigination from './components/DealOrigination';
import BondStructuring from './components/BondStructuring';
import FinancialModelling from './components/FinancialModelling';
import YieldCurveAnalytics from './components/YieldCurveAnalytics';
import RhinoGrading from './components/RhinoGrading';
import CreditAnalysis from './components/CreditAnalysis';
import PricingCommittee from './components/PricingCommittee';
import Bookbuilding from './components/Bookbuilding';
import Compliance from './components/Compliance';
import PortfolioManagement from './components/PortfolioManagement';
import Reporting from './components/Reporting';
import AdministrationDesk from './components/AdministrationDesk';

import { IssuerProfile, DealMandate, BondStructure, HistoricalIssuedBond } from './types';
import { INITIAL_ISSUERS, INITIAL_DEALS, INITIAL_HISTORICAL_BONDS } from './mockData';

export default function App() {
  const [activeModule, setActiveModule] = useState<ActiveModule>('dashboard');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [activeRole, setActiveRole] = useState<string>('DCM Executive (MD)');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Primary persistent state structures
  const [issuers, setIssuers] = useState<IssuerProfile[]>(INITIAL_ISSUERS);
  const [deals, setDeals] = useState<DealMandate[]>(INITIAL_DEALS);
  const [historicalBonds, setHistoricalBonds] = useState<HistoricalIssuedBond[]>(INITIAL_HISTORICAL_BONDS);
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null);

  // Generate some base bonds corresponding to deals so Structuring and Modelling lists are populated
  const [bonds, setBonds] = useState<BondStructure[]>(() => {
    return INITIAL_DEALS.map(deal => ({
      id: `bond-${deal.id}`,
      dealId: deal.id,
      issuerId: deal.issuerId,
      issuerName: deal.issuerName,
      bondName: deal.bondName,
      principalAmount: deal.targetVolume,
      couponRate: deal.id === 'deal-002' ? 5.15 : 6.25,
      couponFrequency: 'Semi-Annual',
      maturityYears: 10,
      currency: 'USD',
      issuePricePercent: 100.0,
      faceValue: 1000,
      issueDate: '2026-08-15',
      settlementDate: '2026-08-18',
      security: 'Senior Secured',
      trustee: 'Standard Chartered Trustee Services',
      legalJurisdiction: 'South Africa',
      listingExchange: 'JSE',
      isin: deal.id === 'deal-002' ? 'ZAE000394851' : 'ZAE000109348',
      purposeOfIssue: 'Capital Expansion',
      useOfProceeds: deal.bondType === 'Green' ? 'Clean energy solar array fields' : 'Freight cargo railways development'
    }));
  });

  // Reset database callback
  const handleResetDatabase = () => {
    setIssuers(INITIAL_ISSUERS);
    setDeals(INITIAL_DEALS);
    setHistoricalBonds(INITIAL_HISTORICAL_BONDS);
    
    // reset bonds
    const resetBonds = INITIAL_DEALS.map(deal => ({
      id: `bond-${deal.id}`,
      dealId: deal.id,
      issuerId: deal.issuerId,
      issuerName: deal.issuerName,
      bondName: deal.bondName,
      principalAmount: deal.targetVolume,
      couponRate: deal.id === 'deal-002' ? 5.15 : 6.25,
      couponFrequency: 'Semi-Annual',
      maturityYears: 10,
      currency: 'USD',
      issuePricePercent: 100.0,
      faceValue: 1000,
      issueDate: '2026-08-15',
      settlementDate: '2026-08-18',
      security: 'Senior Secured',
      trustee: 'Standard Chartered Trustee Services',
      legalJurisdiction: 'South Africa',
      listingExchange: 'JSE',
      isin: deal.id === 'deal-002' ? 'ZAE000394851' : 'ZAE000109348',
      purposeOfIssue: 'Capital Expansion',
      useOfProceeds: deal.bondType === 'Green' ? 'Clean energy solar array fields' : 'Freight cargo railways development'
    }));
    setBonds(resetBonds);
  };

  // Helper to filter items based on search query
  const filteredIssuers = issuers.filter(i => 
    i.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    i.creditRating.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredDeals = deals.filter(d => 
    d.bondName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.issuerName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredBonds = bonds.filter(b => 
    b.bondName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.issuerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.isin.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Render the active module selection
  const renderActiveView = () => {
    switch (activeModule) {
      case 'dashboard':
        return (
          <ExecutiveDashboard 
            deals={filteredDeals} 
            issuers={filteredIssuers} 
            historicalBonds={historicalBonds} 
            darkMode={darkMode} 
            onNavigateToDeal={(dealId) => {
              setSelectedDealId(dealId);
              setActiveModule('deals');
            }}
          />
        );
      case 'clients':
        return (
          <ClientManagement 
            issuers={filteredIssuers} 
            setIssuers={setIssuers} 
            darkMode={darkMode} 
          />
        );
      case 'deals':
        return (
          <DealOrigination 
            deals={filteredDeals} 
            setDeals={setDeals} 
            issuers={filteredIssuers} 
            darkMode={darkMode} 
            selectedDealId={selectedDealId}
            setSelectedDealId={setSelectedDealId}
          />
        );
      case 'structuring':
        return (
          <BondStructuring 
            bonds={filteredBonds} 
            setBonds={setBonds} 
            issuers={filteredIssuers}
            deals={filteredDeals} 
            darkMode={darkMode} 
          />
        );
      case 'modelling':
        return (
          <FinancialModelling 
            bonds={filteredBonds} 
            darkMode={darkMode} 
          />
        );
      case 'yield-curve':
        return (
          <YieldCurveAnalytics 
            darkMode={darkMode} 
          />
        );
      case 'grading':
        return (
          <RhinoGrading 
            bonds={filteredBonds} 
            darkMode={darkMode} 
          />
        );
      case 'credit':
        return (
          <CreditAnalysis 
            issuers={filteredIssuers} 
            darkMode={darkMode} 
          />
        );
      case 'pricing-committee':
        return (
          <PricingCommittee 
            deals={filteredDeals} 
            darkMode={darkMode} 
          />
        );
      case 'bookbuilding':
        return (
          <Bookbuilding 
            deals={filteredDeals} 
            darkMode={darkMode} 
          />
        );
      case 'compliance':
        return (
          <Compliance 
            deals={filteredDeals} 
            darkMode={darkMode} 
          />
        );
      case 'portfolio':
        return (
          <PortfolioManagement 
            historicalBonds={historicalBonds} 
            darkMode={darkMode} 
          />
        );
      case 'reports':
        return (
          <Reporting 
            deals={filteredDeals} 
            issuers={filteredIssuers} 
            bonds={filteredBonds} 
            darkMode={darkMode} 
          />
        );
      case 'admin':
        return (
          <AdministrationDesk 
            darkMode={darkMode} 
            onResetDatabase={handleResetDatabase} 
          />
        );
      default:
        return (
          <ExecutiveDashboard 
            deals={filteredDeals} 
            issuers={filteredIssuers} 
            historicalBonds={historicalBonds} 
            darkMode={darkMode} 
            onNavigateToDeal={(dealId) => {
              setSelectedDealId(dealId);
              setActiveModule('deals');
            }}
          />
        );
    }
  };

  return (
    <div className={`flex h-screen overflow-hidden ${darkMode ? 'bg-[#0f172a] text-slate-100' : 'bg-[#f8fafc] text-slate-900'}`}>
      {/* Sidebar Navigation */}
      <Sidebar
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header / Status bar */}
        <header className={`px-6 py-4 border-b flex items-center justify-between shrink-0 ${darkMode ? 'bg-[#0a192f] border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="flex items-center space-x-3.5 text-xs font-mono">
            <span className="text-slate-400">ROLE COMPATIBILITY CONTEXT:</span>
            <span className="px-2.5 py-1 bg-amber-500/10 text-amber-500 border border-amber-500/20 font-bold uppercase rounded-md">
              {activeRole}
            </span>
          </div>

          <div className="flex items-center space-x-4 text-xs font-mono text-slate-400">
            <span>SADC SWIFT GATE: <strong className="text-emerald-500 font-bold uppercase">ACTIVE (STANDBY)</strong></span>
            <span>|</span>
            <span>SYSTEM LATENCY: <strong className="text-slate-200 font-bold">1.5 ms</strong></span>
          </div>
        </header>

        {/* Primary View Area */}
        <main className="flex-1 overflow-y-auto p-6">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
