/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { IssuerProfile, DealMandate, YieldCurvePoint, InvestorProfile, HistoricalIssuedBond, YieldCurveSpreadMetrics, BookOrder } from './types';

export const INITIAL_ISSUERS: IssuerProfile[] = [
  {
    id: 'iss-001',
    name: 'Trans-African Rail Group',
    registrationNumber: 'REG-1994-884920',
    country: 'South Africa',
    industry: 'Infrastructure & Transport',
    ownership: 'State-Owned',
    creditRating: 'BBB+',
    boardMembers: ['Thabo Mbeki II', 'Elena Romanova', 'Dr. Alistair Vance', 'Sibongile Sisulu'],
    legalAdvisers: 'Webber Wentzel Attorneys',
    auditors: 'PricewaterhouseCoopers',
    relationshipManager: 'Marcus Nkosi (DCM Director)',
    pipelineStage: 'Investment Committee',
    meetingHistory: [
      { id: 'm-1', date: '2026-02-15', topic: 'Rail Corridor expansion finance', summary: 'Discussed raising $400M via dual-tranche Infrastructure Bonds to fund the Mpumalanga Freight Corridor.', attendees: 'Marcus Nkosi, Thabo Mbeki II, CFO Elena Romanova' },
      { id: 'm-2', date: '2026-04-10', topic: 'Structuring and rating advisory', summary: 'Agreed on offering a Sovereign Guarantee from Treasury to lift the rating to BBB+ from local BBB.', attendees: 'Marcus Nkosi, Dr. Alistair Vance' }
    ],
    communicationLog: [
      { id: 'c-1', date: '2026-05-01', type: 'Proposal', summary: 'Sent indicative term sheet and pricing grid with spreads varying +160 to +210 bps over the government benchmark curve.', sender: 'Marcus Nkosi' },
      { id: 'c-2', date: '2026-05-20', type: 'Email', summary: 'CFO confirmed board approval of the indicative proposal. Initiating internal screening.', sender: 'Elena Romanova' }
    ],
    financials: {
      revenue: 1250000000,
      ebitda: 420000000,
      netIncome: 145000000,
      totalAssets: 4800000000,
      totalLiabilities: 2900000000,
      cashAndEquivalents: 320000000,
      existingDebt: 2100000000,
      existingEquity: 1900000000,
      reportingYear: 2025
    },
    existingDebtNotes: 'Senior Secured Freight Corridor Bonds due 2029 ($500M, 6.2%). Unsecured Syndicated Rail Credit Facility due 2027 ($300M, SOFR + 250bps).',
    documents: ['Board_Resolution_Freight_2026.pdf', 'Audited_Financial_Statements_2025.pdf', 'Sovereign_Guarantee_Letter_Draft.pdf']
  },
  {
    id: 'iss-002',
    name: 'Green Energy Capital',
    registrationNumber: 'REG-2018-384910',
    country: 'Kenya',
    industry: 'Renewable Energy',
    ownership: 'Private',
    creditRating: 'A-',
    boardMembers: ['Nanjala Wafula', 'Hans Lindemann', 'Kofi Mensah'],
    legalAdvisers: 'Anjarwalla & Khanna',
    auditors: 'Deloitte & Touche',
    relationshipManager: 'Sophie Chen (VP Climate Finance)',
    pipelineStage: 'Bookbuilding',
    meetingHistory: [
      { id: 'm-3', date: '2026-01-10', topic: 'Rift Valley Solar Project Financing', summary: 'Pitched a $150M Certified Green Bond with use of proceeds directed to the Rift Valley solar panels array.', attendees: 'Sophie Chen, Hans Lindemann' }
    ],
    communicationLog: [
      { id: 'c-3', date: '2026-02-28', type: 'Meeting', summary: 'Completed initial ESG compliance screening. Certified by Climate Bonds Initiative (CBI).', sender: 'Sophie Chen' }
    ],
    financials: {
      revenue: 310000000,
      ebitda: 145000000,
      netIncome: 55000000,
      totalAssets: 850000000,
      totalLiabilities: 450000000,
      cashAndEquivalents: 85000000,
      existingDebt: 320000000,
      existingEquity: 400000000,
      reportingYear: 2025
    },
    existingDebtNotes: 'Series A Solar Financing facility ($120M, 5.8% due 2028). Minority shareholder loans ($50M).',
    documents: ['CBI_Green_Bond_Certificate_Rift_Solar.pdf', 'Rift_Valley_Solar_Feasibility_Report.pdf']
  },
  {
    id: 'iss-003',
    name: 'City of Johannesburg Metropolitan Municipality',
    registrationNumber: 'MUNI-JHB-002',
    country: 'South Africa',
    industry: 'Municipal & Public Finance',
    ownership: 'Municipal Joint Venture',
    creditRating: 'AA-',
    boardMembers: ['Mayor Kabelo Gwamanda', 'City CFO Floyd Brink', 'Tshepo Nkambule'],
    legalAdvisers: 'Edward Nathan Sonnenbergs (ENS)',
    auditors: 'Auditor-General of South Africa',
    relationshipManager: 'Marcus Nkosi (DCM Director)',
    pipelineStage: 'Indicative Pricing',
    meetingHistory: [
      { id: 'm-4', date: '2026-03-05', topic: 'Soweto Water & Roads Modernisation', summary: 'Reviewed city infrastructure budget deficits. Proposed Municipal Infrastructure Bond to raise ZAR 2.5 Billion (~$135M USD equivalent).', attendees: 'Marcus Nkosi, Floyd Brink' }
    ],
    communicationLog: [
      { id: 'c-4', date: '2026-04-12', type: 'Email', summary: 'Requested details on credit rating premium for municipal water-revenue ringfenced structures.', sender: 'Floyd Brink' }
    ],
    financials: {
      revenue: 3800000000,
      ebitda: 780000000,
      netIncome: 210000000,
      totalAssets: 12400000000,
      totalLiabilities: 6200000000,
      cashAndEquivalents: 950000000,
      existingDebt: 4500000000,
      existingEquity: 6200000000,
      reportingYear: 2025
    },
    existingDebtNotes: 'JHB Municipal Bond Series VII ($150M equivalent, 7.9% due 2030). Development Bank of Southern Africa (DBSA) Water Facility ($100M).',
    documents: ['JHB_Metro_Budget_2025_2026.pdf', 'Auditor_General_Clean_Audit_Report.pdf']
  },
  {
    id: 'iss-004',
    name: 'Rhino Tech & Telecom plc',
    registrationNumber: 'REG-2001-923847',
    country: 'Nigeria',
    industry: 'Telecommunications',
    ownership: 'Public Listed',
    creditRating: 'AA',
    boardMembers: ['Aliko Dangote Jr', 'Sarah Jenkins', 'Chinedu Eze', 'Patricia Obozuwa'],
    legalAdvisers: 'Aluko & Oyebode',
    auditors: 'KPMG',
    relationshipManager: 'Tariq Al-Mansoor (Corporate Finance MD)',
    pipelineStage: 'Marketing',
    meetingHistory: [
      { id: 'm-5', date: '2026-05-18', topic: 'Data Centre expansion financing', summary: 'Formulated a $250M corporate Senior Unsecured bond structure for building 3 Tier-IV regional data centres in Lagos, Nairobi, and Accra.', attendees: 'Tariq Al-Mansoor, Sarah Jenkins (CFO)' }
    ],
    communicationLog: [
      { id: 'c-5', date: '2026-06-02', type: 'Email', summary: 'Discussed the credit spread advantage of being rated AA, allowing pricing at +110 bps over sovereign.', sender: 'Sarah Jenkins' }
    ],
    financials: {
      revenue: 2100000000,
      ebitda: 980000000,
      netIncome: 450000000,
      totalAssets: 3500000000,
      totalLiabilities: 1500000000,
      cashAndEquivalents: 620000000,
      existingDebt: 800000000,
      existingEquity: 2000000000,
      reportingYear: 2025
    },
    existingDebtNotes: 'Nigeria Telecom Debentures ($300M, 5.2% due 2028). Syndicated Commercial Loan ($200M).',
    documents: ['Lagos_Data_Centre_Feasibility.pdf', 'Rating_Agency_Credit_Report_AA.pdf']
  }
];

export const INITIAL_DEALS: DealMandate[] = [
  {
    id: 'deal-001',
    issuerId: 'iss-001',
    issuerName: 'Trans-African Rail Group',
    bondName: 'Freight Corridor Infrastructure Bonds, Series A',
    bondType: 'Infrastructure',
    targetVolume: 400000000,
    estimatedFeePercent: 1.5,
    estimatedProbability: 75,
    currentStageIndex: 7, // Investment Committee stage
    riskNotes: 'Sovereign guarantee from Government of South Africa is required to secure the investment grade rating (BBB+). Coal transport demand fluctuations are a key risk factor.',
    createdDate: '2026-03-01',
    workflowStages: [
      { stageName: 'Initial Client Meeting', assignedStaff: 'Marcus Nkosi', deadline: '2026-03-10', status: 'Completed', approved: true, notes: 'Introductory meeting successfully completed. Target identified.', requiredDocs: [{ name: 'Executive Pitch Deck', uploaded: true }] },
      { stageName: 'Opportunity Assessment', assignedStaff: 'David Miller', deadline: '2026-03-20', status: 'Completed', approved: true, notes: 'Infrastructure sector team issued a highly favorable thematic report.', requiredDocs: [{ name: 'Internal Sector Analysis', uploaded: true }] },
      { stageName: 'Internal Screening', assignedStaff: 'Risk Desk (Janice)', deadline: '2026-03-30', status: 'Completed', approved: true, notes: 'Risk committee passed project with standard covenants.', requiredDocs: [{ name: 'Initial Risk Memo', uploaded: true }] },
      { stageName: 'Indicative Pricing', assignedStaff: 'Sophie Chen', deadline: '2026-04-10', status: 'Completed', approved: true, notes: 'Determined target spread of G-Curve + 180 bps.', requiredDocs: [{ name: 'Indicative Pricing Grid', uploaded: true }] },
      { stageName: 'Mandate Proposal', assignedStaff: 'Marcus Nkosi', deadline: '2026-04-25', status: 'Completed', approved: true, notes: 'Formal RFP won and Mandate Agreement signed.', requiredDocs: [{ name: 'Signed Mandate Letter', uploaded: true }] },
      { stageName: 'Client Approval', assignedStaff: 'Marcus Nkosi', deadline: '2026-05-05', status: 'Completed', approved: true, notes: 'TARG board formally accepted the structuring term sheet.', requiredDocs: [{ name: 'Board Resolution Consent', uploaded: true }] },
      { stageName: 'Due Diligence', assignedStaff: 'Legal Desk / Webber', deadline: '2026-06-15', status: 'Completed', approved: true, notes: 'Legal, financial, environmental, and engineering due diligence complete.', requiredDocs: [{ name: 'Legal Due Diligence Report', uploaded: true }, { name: 'EIA Greenlight', uploaded: true }] },
      { stageName: 'Investment Committee', assignedStaff: 'IC Chair (A. Cole)', deadline: '2026-07-28', status: 'In Progress', approved: false, notes: 'Committee review scheduled. Preparing formal memorandum.', requiredDocs: [{ name: 'Investment Committee Paper', uploaded: false }] },
      { stageName: 'Pricing Committee', assignedStaff: 'Syndicate Desk', deadline: '2026-08-05', status: 'Not Started', approved: false, notes: 'Waiting for IC sign-off.', requiredDocs: [{ name: 'Pricing Model Projections', uploaded: false }] },
      { stageName: 'Documentation', assignedStaff: 'Legal Desk', deadline: '2026-08-15', status: 'Not Started', approved: false, notes: 'Term Sheet and offering circular drafting in queue.', requiredDocs: [{ name: 'Offering Circular Draft', uploaded: false }] },
      { stageName: 'Marketing', assignedStaff: 'Sophie Chen', deadline: '2026-08-25', status: 'Not Started', approved: false, notes: 'Non-deal roadshow in Cape Town, London, and Munich planned.', requiredDocs: [{ name: 'Roadshow Presentation', uploaded: false }] },
      { stageName: 'Bookbuilding', assignedStaff: 'Syndicate Desk', deadline: '2026-09-02', status: 'Not Started', approved: false, notes: 'Order book opening target.', requiredDocs: [{ name: 'Simulator Config', uploaded: false }] },
      { stageName: 'Allocation', assignedStaff: 'Bookrunner Team', deadline: '2026-09-03', status: 'Not Started', approved: false, notes: 'Allocation engine runs.', requiredDocs: [] },
      { stageName: 'Settlement Simulation', assignedStaff: 'Treasury / Ops', deadline: '2026-09-10', status: 'Not Started', approved: false, notes: 'Reconciliation of SWIFT instructions.', requiredDocs: [] },
      { stageName: 'Post-Issue Monitoring', assignedStaff: 'Portfolio Desk', deadline: '2026-12-31', status: 'Not Started', approved: false, notes: 'Maturity reporting tracking.', requiredDocs: [] }
    ]
  },
  {
    id: 'deal-002',
    issuerId: 'iss-002',
    issuerName: 'Green Energy Capital',
    bondName: 'Rift Valley Solar Certified Green Bonds',
    bondType: 'Green',
    targetVolume: 150000000,
    estimatedFeePercent: 1.75,
    estimatedProbability: 95,
    currentStageIndex: 11, // Bookbuilding stage
    riskNotes: 'Project execution risk on solar arrays. High environmental compliance check required to keep Climate Bonds Initiative status. Fully secured by asset pledges.',
    createdDate: '2026-02-10',
    workflowStages: [
      { stageName: 'Initial Client Meeting', assignedStaff: 'Sophie Chen', deadline: '2026-02-15', status: 'Completed', approved: true, notes: 'Client is keen on green premium (greenium) savings.', requiredDocs: [{ name: 'Green Bond Pitch', uploaded: true }] },
      { stageName: 'Opportunity Assessment', assignedStaff: 'Sophie Chen', deadline: '2026-02-25', status: 'Completed', approved: true, notes: 'Vast renewable development potential.', requiredDocs: [{ name: 'Feasibility Assessment', uploaded: true }] },
      { stageName: 'Internal Screening', assignedStaff: 'Risk Desk (Janice)', deadline: '2026-03-05', status: 'Completed', approved: true, notes: 'Screening passed.', requiredDocs: [] },
      { stageName: 'Indicative Pricing', assignedStaff: 'Sophie Chen', deadline: '2026-03-12', status: 'Completed', approved: true, notes: 'Indicative pricing at G-Curve + 120 bps (reflecting CBI discount).', requiredDocs: [] },
      { stageName: 'Mandate Proposal', assignedStaff: 'Sophie Chen', deadline: '2026-03-25', status: 'Completed', approved: true, notes: 'Mandate signed.', requiredDocs: [{ name: 'Mandate Letter', uploaded: true }] },
      { stageName: 'Client Approval', assignedStaff: 'Sophie Chen', deadline: '2026-04-01', status: 'Completed', approved: true, notes: 'Board approved.', requiredDocs: [] },
      { stageName: 'Due Diligence', assignedStaff: 'Legal Desk', deadline: '2026-04-20', status: 'Completed', approved: true, notes: 'ESG compliance, land deeds verified.', requiredDocs: [{ name: 'CBI Certificate', uploaded: true }] },
      { stageName: 'Investment Committee', assignedStaff: 'IC Chair (A. Cole)', deadline: '2026-05-02', status: 'Completed', approved: true, notes: 'Full approval given.', requiredDocs: [{ name: 'IC Approval Memo', uploaded: true }] },
      { stageName: 'Pricing Committee', assignedStaff: 'Syndicate Desk', deadline: '2026-05-10', status: 'Completed', approved: true, notes: 'Committee approved 5.15% fixed coupon pricing.', requiredDocs: [{ name: 'Pricing Report Signed', uploaded: true }] },
      { stageName: 'Documentation', assignedStaff: 'Legal Desk', deadline: '2026-05-25', status: 'Completed', approved: true, notes: 'Prospectus and offering circular generated and registered.', requiredDocs: [{ name: 'Final Offering Circular', uploaded: true }] },
      { stageName: 'Marketing', assignedStaff: 'Sophie Chen', deadline: '2026-06-15', status: 'Completed', approved: true, notes: 'Roadshows generated 3x pipeline interest.', requiredDocs: [] },
      { stageName: 'Bookbuilding', assignedStaff: 'Syndicate Desk', deadline: '2026-07-30', status: 'In Progress', approved: false, notes: 'Order book currently open. Massive investor turnout.', requiredDocs: [{ name: 'Bidding Register', uploaded: true }] },
      { stageName: 'Allocation', assignedStaff: 'Bookrunner Team', deadline: '2026-08-01', status: 'Not Started', approved: false, notes: 'Ready to allocate.', requiredDocs: [] },
      { stageName: 'Settlement Simulation', assignedStaff: 'Treasury', deadline: '2026-08-10', status: 'Not Started', approved: false, notes: 'Scheduled for Aug 10.', requiredDocs: [] },
      { stageName: 'Post-Issue Monitoring', assignedStaff: 'Portfolio Desk', deadline: '2027-08-10', status: 'Not Started', approved: false, notes: 'Yearly environmental impact reporting.', requiredDocs: [] }
    ]
  },
  {
    id: 'deal-003',
    issuerId: 'iss-003',
    issuerName: 'City of Johannesburg Metropolitan Municipality',
    bondName: 'Soweto Water & Sanitation Revenue Bonds',
    bondType: 'Municipal',
    targetVolume: 135000000,
    estimatedFeePercent: 1.25,
    estimatedProbability: 60,
    currentStageIndex: 3, // Indicative Pricing
    riskNotes: 'Municipal revenue collection leakage is high. Soweto water revenue is ring-fenced to safeguard payments. Subject to national budget local transfers.',
    createdDate: '2026-03-05',
    workflowStages: [
      { stageName: 'Initial Client Meeting', assignedStaff: 'Marcus Nkosi', deadline: '2026-03-10', status: 'Completed', approved: true, notes: 'Mayor and CFO present. Urgent need for water upgrades.', requiredDocs: [] },
      { stageName: 'Opportunity Assessment', assignedStaff: 'David Miller', deadline: '2026-03-25', status: 'Completed', approved: true, notes: 'Strong developmental and social return, aligning with Rhino ESG objectives.', requiredDocs: [{ name: 'Soweto Social Impact Report', uploaded: true }] },
      { stageName: 'Internal Screening', assignedStaff: 'Risk Desk (Janice)', deadline: '2026-04-10', status: 'Completed', approved: true, notes: 'Passed screening with strict oversight covenant.', requiredDocs: [] },
      { stageName: 'Indicative Pricing', assignedStaff: 'Marcus Nkosi', deadline: '2026-07-28', status: 'In Progress', approved: false, notes: 'Modeling municipal curve spreads.', requiredDocs: [] },
      { stageName: 'Mandate Proposal', assignedStaff: 'Marcus Nkosi', deadline: '2026-08-10', status: 'Not Started', approved: false, notes: 'Proposal is being structured.', requiredDocs: [] },
      { stageName: 'Client Approval', assignedStaff: 'Marcus Nkosi', deadline: '2026-08-20', status: 'Not Started', approved: false, notes: 'Requires council resolution.', requiredDocs: [] },
      { stageName: 'Due Diligence', assignedStaff: 'Legal Desk', deadline: '2026-09-10', status: 'Not Started', approved: false, notes: 'Audit of municipal accounts is pending.', requiredDocs: [] },
      { stageName: 'Investment Committee', assignedStaff: 'IC Chair', deadline: '2026-09-20', status: 'Not Started', approved: false, notes: 'Pending DD.', requiredDocs: [] },
      { stageName: 'Pricing Committee', assignedStaff: 'Syndicate Desk', deadline: '2026-09-25', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Documentation', assignedStaff: 'Legal Desk', deadline: '2026-10-05', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Marketing', assignedStaff: 'Sophie Chen', deadline: '2026-10-15', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Bookbuilding', assignedStaff: 'Syndicate Desk', deadline: '2026-10-25', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Allocation', assignedStaff: 'Bookrunner Team', deadline: '2026-10-28', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Settlement Simulation', assignedStaff: 'Treasury', deadline: '2026-11-05', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Post-Issue Monitoring', assignedStaff: 'Portfolio Desk', deadline: '2027-11-05', status: 'Not Started', approved: false, notes: '', requiredDocs: [] }
    ]
  },
  {
    id: 'deal-004',
    issuerId: 'iss-004',
    issuerName: 'Rhino Tech & Telecom plc',
    bondName: 'Regional Tier-IV Data Centre Expansion Notes',
    bondType: 'Corporate',
    targetVolume: 250000000,
    estimatedFeePercent: 1.15,
    estimatedProbability: 90,
    currentStageIndex: 10, // Marketing Stage
    riskNotes: 'Technological obsolescence. Currency fluctuations across Naira, Shilling, and Cedi. Energy infrastructure supply secured via captive diesel and gas generators.',
    createdDate: '2026-05-15',
    workflowStages: [
      { stageName: 'Initial Client Meeting', assignedStaff: 'Tariq Al-Mansoor', deadline: '2026-05-20', status: 'Completed', approved: true, notes: 'CFO enthusiastic. Strong corporate financials.', requiredDocs: [] },
      { stageName: 'Opportunity Assessment', assignedStaff: 'David Miller', deadline: '2026-05-30', status: 'Completed', approved: true, notes: 'Tech sector growth supports AAA/AA issuance spreads.', requiredDocs: [] },
      { stageName: 'Internal Screening', assignedStaff: 'Risk Desk (Janice)', deadline: '2026-06-05', status: 'Completed', approved: true, notes: 'Passed screening, debt/EBITDA is under 2.5x.', requiredDocs: [] },
      { stageName: 'Indicative Pricing', assignedStaff: 'Tariq Al-Mansoor', deadline: '2026-06-12', status: 'Completed', approved: true, notes: 'Indicative pricing set at G-Curve + 110 bps.', requiredDocs: [] },
      { stageName: 'Mandate Proposal', assignedStaff: 'Tariq Al-Mansoor', deadline: '2026-06-20', status: 'Completed', approved: true, notes: 'Mandate executed.', requiredDocs: [{ name: 'Mandate Agreement Telecom', uploaded: true }] },
      { stageName: 'Client Approval', assignedStaff: 'Tariq Al-Mansoor', deadline: '2026-06-25', status: 'Completed', approved: true, notes: 'Board approved.', requiredDocs: [] },
      { stageName: 'Due Diligence', assignedStaff: 'Legal Desk', deadline: '2026-07-05', status: 'Completed', approved: true, notes: 'Complete engineering review on Lagos facility.', requiredDocs: [] },
      { stageName: 'Investment Committee', assignedStaff: 'IC Chair', deadline: '2026-07-12', status: 'Completed', approved: true, notes: 'Approved.', requiredDocs: [] },
      { stageName: 'Pricing Committee', assignedStaff: 'Syndicate Desk', deadline: '2026-07-18', status: 'Completed', approved: true, notes: 'Coupon approved at 5.45% fixed.', requiredDocs: [] },
      { stageName: 'Documentation', assignedStaff: 'Legal Desk', deadline: '2026-07-23', status: 'Completed', approved: true, notes: 'Offering memo finalized.', requiredDocs: [{ name: 'Offering Circular Final', uploaded: true }] },
      { stageName: 'Marketing', assignedStaff: 'Sophie Chen', deadline: '2026-08-05', status: 'In Progress', approved: false, notes: 'Digital roadshow and investor calls currently active.', requiredDocs: [] },
      { stageName: 'Bookbuilding', assignedStaff: 'Syndicate Desk', deadline: '2026-08-12', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Allocation', assignedStaff: 'Bookrunner Team', deadline: '2026-08-14', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Settlement Simulation', assignedStaff: 'Treasury', deadline: '2026-08-20', status: 'Not Started', approved: false, notes: '', requiredDocs: [] },
      { stageName: 'Post-Issue Monitoring', assignedStaff: 'Portfolio Desk', deadline: '2027-08-20', status: 'Not Started', approved: false, notes: '', requiredDocs: [] }
    ]
  }
];

export const INITIAL_YIELD_CURVE_POINTS: YieldCurvePoint[] = [
  { tenor: 1, govtRate: 4.5, corpRate: 5.6, muniRate: 5.1, infraRate: 5.9, zeroRate: 4.4, forwardRate: 4.5 },
  { tenor: 2, govtRate: 4.7, corpRate: 5.85, muniRate: 5.35, infraRate: 6.2, zeroRate: 4.62, forwardRate: 4.9 },
  { tenor: 3, govtRate: 4.9, corpRate: 6.1, muniRate: 5.6, infraRate: 6.45, zeroRate: 4.81, forwardRate: 5.3 },
  { tenor: 5, govtRate: 5.1, corpRate: 6.35, muniRate: 5.85, infraRate: 6.75, zeroRate: 5.03, forwardRate: 5.4 },
  { tenor: 7, govtRate: 5.25, corpRate: 6.55, muniRate: 6.05, infraRate: 6.95, zeroRate: 5.19, forwardRate: 5.62 },
  { tenor: 10, govtRate: 5.4, corpRate: 6.75, muniRate: 6.25, infraRate: 7.2, zeroRate: 5.34, forwardRate: 5.75 },
  { tenor: 20, govtRate: 5.7, corpRate: 7.15, muniRate: 6.65, infraRate: 7.6, zeroRate: 5.61, forwardRate: 6.0 },
  { tenor: 30, govtRate: 5.9, corpRate: 7.45, muniRate: 6.95, infraRate: 7.9, zeroRate: 5.78, forwardRate: 6.3 }
];

export const INITIAL_YIELD_METRICS: YieldCurveSpreadMetrics = {
  governmentYield10Y: 5.4,
  corporateYield10Y: 6.75,
  municipalYield10Y: 6.25,
  infrastructureYield10Y: 7.2,
  corpSpread10Y: 135, // bps
  muniSpread10Y: 85, // bps
  infraSpread10Y: 180, // bps
  curveSteepness: 90, // bps (5.4% - 4.5% = 90bps)
  isInverted: false,
  termPremiumEstimate: 120 // bps
};

export const INITIAL_INVESTORS: InvestorProfile[] = [
  { id: 'inv-001', name: 'Government Employees Pension Fund (GEPF)', category: 'Pension Fund', totalAum: 155000, preferredSectors: ['Infrastructure', 'Municipal', 'Green'], preferredRatings: ['AAA', 'AA+', 'AA', 'AA-'], historicalVolumeMillions: 4500, relationshipStatus: 'Strategic', country: 'South Africa', contactPerson: 'Sipho Zulu' },
  { id: 'inv-002', name: 'Liberty Life Insurance Group', category: 'Insurance Company', totalAum: 48000, preferredSectors: ['Corporate', 'Infrastructure'], preferredRatings: ['AA', 'AA-', 'A+', 'A'], historicalVolumeMillions: 1200, relationshipStatus: 'Active', country: 'South Africa', contactPerson: 'Clarissa de Beer' },
  { id: 'inv-003', name: 'Sanlam Investment Managers', category: 'Asset Manager', totalAum: 65000, preferredSectors: ['Corporate', 'Green', 'Revenue'], preferredRatings: ['A+', 'A', 'BBB+', 'BBB'], historicalVolumeMillions: 2800, relationshipStatus: 'Active', country: 'South Africa', contactPerson: 'Francois van der Merwe' },
  { id: 'inv-004', name: 'African Development Fund (ADF)', category: 'Sovereign Wealth Fund', totalAum: 22000, preferredSectors: ['Infrastructure', 'Project Finance', 'Green'], preferredRatings: ['AAA', 'AA+'], historicalVolumeMillions: 1500, relationshipStatus: 'Strategic', country: 'Cote d\'Ivoire', contactPerson: 'Dr. Amara Kone' },
  { id: 'inv-005', name: 'Apex Wealth Family Office', category: 'Family Office', totalAum: 3500, preferredSectors: ['Corporate', 'Convertible', 'Zero Coupon'], preferredRatings: ['BBB+', 'BBB', 'BB+', 'BB'], historicalVolumeMillions: 450, relationshipStatus: 'Prospect', country: 'United Kingdom', contactPerson: 'Hugo Montagu' },
  { id: 'inv-006', name: 'Rhino Syndicate Retail Pool', category: 'Retail (Simulation)', totalAum: 1200, preferredSectors: ['Municipal', 'Green'], preferredRatings: ['AAA', 'AA', 'A'], historicalVolumeMillions: 150, relationshipStatus: 'Active', country: 'Pan-African', contactPerson: 'Internal Desk' }
];

export const INITIAL_HISTORICAL_BONDS: HistoricalIssuedBond[] = [
  { id: 'hb-1', name: 'South Africa Freight Rail Series IV', issuerName: 'Trans-African Rail Group', isin: 'XS2048194810', issueDate: '2023-05-15', maturityDate: '2033-05-15', volume: 300000000, couponRate: 6.2, currentPricePercent: 101.4, currentYield: 5.95, durationYears: 5.4, sector: 'Infrastructure', region: 'Gauteng, SA' },
  { id: 'hb-2', name: 'JHB Municipal Green Grid Bonds', issuerName: 'City of Johannesburg Metropolitan Municipality', isin: 'XS2491039485', issueDate: '2024-02-18', maturityDate: '2031-02-18', volume: 150000000, couponRate: 5.8, currentPricePercent: 99.1, currentYield: 5.98, durationYears: 4.1, sector: 'Green Infrastructure', region: 'Johannesburg, SA' },
  { id: 'hb-3', name: 'Kenya Solar Fields Alpha', issuerName: 'Green Energy Capital', isin: 'XS2103940182', issueDate: '2022-11-10', maturityDate: '2029-11-10', volume: 100000000, couponRate: 5.4, currentPricePercent: 100.2, currentYield: 5.35, durationYears: 3.2, sector: 'Renewable Energy', region: 'Rift Valley, KE' },
  { id: 'hb-4', name: 'Nairobi Bypass Transport Bond', issuerName: 'Kenya Highways Authority', isin: 'XS2019483710', issueDate: '2021-08-20', maturityDate: '2036-08-20', volume: 220000000, couponRate: 6.8, currentPricePercent: 102.5, currentYield: 6.45, durationYears: 7.8, sector: 'Infrastructure', region: 'Nairobi, KE' }
];

export const MOCK_ORDERS_DEAL_002: BookOrder[] = [
  { id: 'ord-1', investorId: 'inv-001', investorName: 'Government Employees Pension Fund (GEPF)', investorCategory: 'Pension Fund', bidPrice: 100.0, bidYield: 5.15, bidVolume: 60000000, allocatedVolume: 0, timestamp: '2026-07-25 09:30:15' },
  { id: 'ord-2', investorId: 'inv-002', investorName: 'Liberty Life Insurance Group', investorCategory: 'Insurance Company', bidPrice: 99.8, bidYield: 5.19, bidVolume: 35000000, allocatedVolume: 0, timestamp: '2026-07-25 09:45:22' },
  { id: 'ord-3', investorId: 'inv-003', investorName: 'Sanlam Investment Managers', investorCategory: 'Asset Manager', bidPrice: 100.1, bidYield: 5.13, bidVolume: 50000000, allocatedVolume: 0, timestamp: '2026-07-25 10:12:05' },
  { id: 'ord-4', investorId: 'inv-004', investorName: 'African Development Fund (ADF)', investorCategory: 'Sovereign Wealth Fund', bidPrice: 100.3, bidYield: 5.10, bidVolume: 40000000, allocatedVolume: 0, timestamp: '2026-07-25 10:30:00' },
  { id: 'ord-5', investorId: 'inv-005', investorName: 'Apex Wealth Family Office', investorCategory: 'Family Office', bidPrice: 99.5, bidYield: 5.25, bidVolume: 15000000, allocatedVolume: 0, timestamp: '2026-07-25 10:45:11' },
  { id: 'ord-6', investorId: 'inv-006', investorName: 'Rhino Syndicate Retail Pool', investorCategory: 'Retail (Simulation)', bidPrice: 100.0, bidYield: 5.15, bidVolume: 10000000, allocatedVolume: 0, timestamp: '2026-07-25 11:00:00' }
];
