/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client lazily
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY is not defined in the environment. AI features will fallback to client-side default templates.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || 'PLACEHOLDER_KEY',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// REST API for Gemini generation
app.post('/api/generate-memo', async (req, res) => {
  const { type, bond, issuer, metrics } = req.body;

  if (!bond || !issuer) {
    return res.status(400).json({ error: 'Missing required bond or issuer parameters.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    // If key is missing, return a beautiful generated static institutional template
    console.log("No API key found. Providing high-fidelity pre-compiled template.");
    return res.json({ text: getStaticTemplate(type, bond, issuer, metrics) });
  }

  try {
    const ai = getGeminiClient();
    let prompt = '';

    if (type === 'ic-memo') {
      prompt = `
You are an elite Managing Director in Debt Capital Markets (DCM) and Head of Infrastructure Finance at Rhino Bank.
Draft a highly formal, comprehensive, 10-section Investment Committee Memorandum for the following proposed bond issue:

--- CLIENT PROFILE ---
Organisation Name: ${issuer.name}
Country: ${issuer.country}
Industry: ${issuer.industry}
Ownership Structure: ${issuer.ownership}
Credit Rating: ${issuer.creditRating}
Registration: ${issuer.registrationNumber}
Financials: Revenue $${(issuer.financials.revenue / 1000000).toFixed(1)}M, EBITDA $${(issuer.financials.ebitda / 1000000).toFixed(1)}M, Existing Debt $${(issuer.financials.existingDebt / 1000000).toFixed(1)}M.

--- BOND STRUCTURE ---
Bond Name: ${bond.bondName}
Type: ${bond.bondType} Bonds
Target Principal Amount: $${(bond.principalAmount / 1000000).toFixed(1)}M
Maturity: ${bond.maturityYears} Years
Proposed Coupon: ${bond.couponRate}% (${bond.couponFrequency} Payments)
Currency: ${bond.currency}
Security: ${bond.security}
Guarantees: ${bond.guarantees || 'None'}
Use of Proceeds Purpose: ${bond.useOfProceeds} (${bond.purposeOfIssue})
Listing Exchange: ${bond.listingExchange}
Legal Jurisdiction: ${bond.legalJurisdiction}

--- ANALYTIC METRICS ---
Average Debt Service Coverage Ratio (DSCR): ${metrics.averageDscr?.toFixed(2)}x
Loan Life Coverage Ratio (LLCR): ${metrics.llcr?.toFixed(2)}x
Project Life Coverage Ratio (PLCR): ${metrics.plcr?.toFixed(2)}x
Project IRR: ${metrics.irr?.toFixed(2)}%
Rhino Grading weighted score: ${metrics.weightedScore || 85} (${metrics.rating || 'Rhino Gold'})

Please draft the Investment Committee Paper with the following strict sections:
1. EXECUTIVE SUMMARY & TRANSACTION OVERVIEW
2. ISSUER PROFILE & FINANCIAL CAPACITY (analyzing debt-to-equity, cash buffers, ebitda cover)
3. STRUCTURAL CHARACTERISTICS (explaining security, covenants, call/put protections, maturity ladder)
4. USE OF PROCEEDS & DEVELOPMENT IMPACT (explaining social/environmental/capital expenditure targets)
5. BENCHMARK YIELD CURVE & CREDIT SPREAD ANALYSIS (explaining how the G-Curve premium is calibrated)
6. PROPRIETARY RHINO GRADING ANALYSIS (analyzing why the deal fits the ${metrics.rating || 'Rhino Gold'} designation)
7. RISK MATRIX & MITIGATION (covering refinancing risks, execution leakage, interest-rate risk, and currency mismatches)
8. COVENANTS AND PROTECTION TRIGGERS (specifying debt-to-EBITDA limits, minimum DSCR triggers, negative pledges)
9. MARKETING & INVESTOR TARGETS (Pension funds, Sovereign Wealth Funds, Insurers)
10. SYNDICATE RECOMMENDATION & FORMAL PROPOSAL

Format the memorandum in a beautiful, dense financial layout using Markdown. Include rich tables, professional terminology (e.g. greenium, pari-passu, covenants, bullet structures), and specific regional context. Avoid any marketing hype. Make it read like an official paper signed by the Rhino DCM Investment Committee.
`;
    } else if (type === 'pricing-paper') {
      prompt = `
You are the Head of the Syndicate Desk and Chairman of the Pricing Committee at Rhino Bank.
Draft a highly technical, quantitative Pricing Committee Paper for the following primary debt offering:

--- ISSUE PARAMETERS ---
Issuer Name: ${issuer.name}
Bond Name: ${bond.bondName}
Type: ${bond.bondType} Bonds
Target Amount: $${(bond.principalAmount / 1000000).toFixed(1)}M
Maturity: ${bond.maturityYears} Years
Target Coupon Rate: ${bond.couponRate}%
Currency: ${bond.currency}
Spreads: Spreads computed over government benchmark is ${metrics.spreadBps || 150} bps.

Provide a highly granular analysis structured into the following sections:
1. PRIMARY PRICING MANDATE & OBJECTIVES
2. SWAP SPREAD & CREDIT RISK PREMIUM CALIBRATION (explain G-curve spread, risk premium, greenium/esg concessions if applicable)
3. ORDER BOOK DEMAND ANALYSIS (assume subscription ratio is above 1.8x, describe investor demand buckets)
4. YIELD VS VOLUME ELASTICITY MATRIX (provide a markdown table with varying yields: Coupon - 25bps, Target Coupon, Coupon + 25bps, and simulated demands)
5. UNDERWRITING RISK & FEES (suggesting a underwriting fee percentage of ${metrics.feesPct || 1.25}%)
6. PRICING RESOLUTION (formal recommendation to launch the bond at issue price of ${bond.issuePricePercent}% of par)

Use precise banking terms, specific bps margins, and quantitative analysis. Format beautifully in Markdown.
`;
    } else {
      prompt = `
Draft an Executive Summary Report for the bond ${bond.bondName} issued by ${issuer.name}. Keep it concise, professional, and dense with financial performance ratios, use of proceeds impact, and a clear breakdown of the Rhino proprietary score. Format in Markdown.
`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error('Error calling Gemini API:', error);
    res.status(500).json({ error: error.message || 'Failed to generate memo via AI. Fallback template loaded.', fallbackText: getStaticTemplate(type, bond, issuer, metrics) });
  }
});

function getStaticTemplate(type: string, bond: any, issuer: any, metrics: any): string {
  const volM = (bond.principalAmount / 1000000).toFixed(1);
  const revM = (issuer.financials.revenue / 1000000).toFixed(1);
  const debtM = (issuer.financials.existingDebt / 1000000).toFixed(1);

  if (type === 'ic-memo') {
    return `
# RHINO BANK | DEBT CAPITAL MARKETS
### INVESTMENT COMMITTEE MEMORANDUM (INSTITUTIONAL GRADE)
**TO:** Rhino Bank Investment Committee  
**FROM:** Debt Capital Markets Desk  
**DATE:** July 25, 2026  
**SUBJECT:** Proposal for underwriting ${bond.bondName} issued by ${issuer.name}  

---

## 1. EXECUTIVE SUMMARY & TRANSACTION OVERVIEW
We present for approval a senior secured debt origination mandate for **${issuer.name}** for a total volume of **$${volM}M USD equivalent**. The bond is structured as an **${bond.bondType} instrument** of ${bond.maturityYears} years tenor, yielding a fixed coupon of **${bond.couponRate}% per annum**. Rhino Bank is mandated as the Sole Bookrunner and Lead Manager.

## 2. ISSUER PROFILE & FINANCIAL CAPACITY
*   **Organisation:** ${issuer.name} (Credit Rating: \`${issuer.creditRating}\`)
*   **Industry:** ${issuer.industry} (Ownership: ${issuer.ownership})
*   **Revenues:** $${revM}M USD  
*   **Existing Leverage:** Total Outstanding Debt sits at $${debtM}M USD.
*   **Leverage Metrics:** Debt to EBITDA stands at a healthy ${(issuer.financials.existingDebt / issuer.financials.ebitda).toFixed(2)}x, indicating substantial debt-carrying capability before reaching rating covenant triggers.

## 3. STRUCTURAL CHARACTERISTICS
*   **Tranche Sizing:** Single tranche, Bullet repayment on ${bond.maturityYears}-year maturity.
*   **Security:** ${bond.security} over primary underlying revenue assets.
*   **Covenants:** 
    *   Minimum DSCR maintenance covenant set at **1.20x**.
    *   Debt-to-Equity ceiling not to exceed **1.8x**.
    *   Negative pledge on all physical assets.

## 4. USE OF PROCEEDS & DEVELOPMENT IMPACT
Proceeds will be exclusively deployed to **${bond.useOfProceeds}** in ${issuer.country}. This project directly aligns with Rhino ESG objectives and the United Nations Sustainable Development Goals (SDG 9: Industry, Innovation and Infrastructure, and SDG 11: Sustainable Cities). 

## 5. BENCHMARK YIELD CURVE & CREDIT SPREAD
Calibration is based on the G-Curve plus a credit spread of **${metrics.spreadBps || 160} bps**. The premium compensates for sub-sovereign rating adjustments and regional liquidity factors. 

## 6. PROPRIETARY RHINO GRADING ANALYSIS
The issue receives a **Proprietary Score of ${metrics.weightedScore || 85}/100**, placing it securely inside the **${metrics.rating || 'Rhino Gold'}** bracket. This score reflects high credit ratings, a robust debt service profile, and strong regional developmental support.

## 7. RISK MATRIX & MITIGATION
*   *Interest-rate Risk:* Fixed-rate structure protects the issuer during tight monetary periods, shifting duration risk to yield-seeking pension portfolios.
*   *Asset Maintenance Risk:* Insulated by specialized escrow reserves and mandatory operational maintenance covenants.

## 8. SYNDICATE RECOMMENDATION
The DCM Syndicate Desk recommends unconditional approval of this underwriting mandate. Primary placement interest from major insurers and regional pension funds stands at a projected oversubscription of **1.85x**.
`;
  } else {
    return `
# RHINO BANK | SYNDICATE DESK
### PRICING COMMITTEE DECISION PAPER
**MANDATE:** ${bond.bondName} ($${volM}M)  
**ISSUER:** ${issuer.name}  
**DATE:** July 25, 2026  

---

## 1. PRICING MANDATE & OBJECTIVES
The Syndicate desk has completed the initial pricing book for the proposed debt placement. Market benchmarks reflect high appetite for ${bond.bondType} fixed-income assets.

## 2. BENCHMARK AND SPREAD CALIBRATION
*   **Benchmark 10Y Government Yield:** 5.40%
*   **Credit Spread Premium:** +${metrics.spreadBps || 150} bps
*   **Target Coupon Yield:** ${bond.couponRate}%
*   **Pricing Basis:** Par offering at 100.0% of nominal value.

## 3. DEMAND INTEGRITY
Primary marketing registers a demand pipeline of **1.92x oversubscription**. Asset managers represent 45% of the book, pension funds 35%, and SWFs 15%.

## 4. FEES & UNDERWRITING RESOLUTION
*   **Proposed Management Fee:** ${metrics.feesPct || 1.25}% of underwritten volume.
*   **Resolution:** Pricing Committee recommends launching the order book immediately. All compliance gates (KYC, Sanctions check) are fully satisfied.
`;
  }
}

// Vite integration & routing
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
