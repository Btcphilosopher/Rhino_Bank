/**
 * RHINO MERCHANT NETWORK - Test Execution Script
 */

import { runFullSystemTests } from '../src/backend/testRunner';

console.log('=======================================================');
console.log('RHINO MERCHANT NETWORK - AUTOMATED SYSTEM VERIFICATION');
console.log('=======================================================');

const report = runFullSystemTests();

console.log(`Total System Tests: ${report.total}`);
console.log(`Passed: ${report.passed}`);
console.log(`Failed: ${report.failed}\n`);

for (const res of report.results) {
  const icon = res.status === 'PASSED' ? '✓' : '✗';
  console.log(`[${icon}] ${res.suite} :: ${res.name} (${res.duration_ms}ms)`);
  if (res.message) {
    console.error(`    Error: ${res.message}`);
  }
}

if (report.failed > 0) {
  process.exit(1);
} else {
  console.log('\nAll core financial invariants verified successfully!');
}
