/**
 * RHINO MERCHANT NETWORK - Server Entry Point
 * Express API Backend + Vite Development/Production Middleware
 * Binds strictly to port 3000 and 0.0.0.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { apiRouter } from './src/backend/apiRoutes';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser
  app.use(express.json());

  // Mount API routes
  app.use('/api', apiRouter);

  // Vite middleware for development / static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(`RHINO MERCHANT NETWORK - BANK-GRADE PAYMENTS PLATFORM`);
    console.log(`Institution: RHINO BANK | Technical Platform: rhino-payments`);
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
    console.log(`=======================================================`);
  });
}

startServer();
