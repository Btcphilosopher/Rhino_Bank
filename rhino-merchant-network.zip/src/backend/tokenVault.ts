/**
 * RHINO MERCHANT NETWORK - PCI-Isolated Synthetic Token Vault
 * Secures payment credentials by issuing cryptographically bound tokens & cryptograms.
 * Never exposes raw PAN credentials to downstream acquiring planes.
 */

import { PaymentToken, TokenStatus } from '../types/rhino';

export class TokenVaultService {
  private tokensMap: Map<string, PaymentToken> = new Map();

  /**
   * Tokenize synthetic card credentials
   */
  public tokenizeCard(params: {
    merchantId: string;
    customerId?: string;
    pan: string;
    expMonth: number;
    expYear: number;
    cvv: string;
    cardholderName: string;
  }): PaymentToken {
    // Sanitize input (never store full raw PAN)
    const sanitizedPan = params.pan.replace(/\s+/g, '');
    const last4 = sanitizedPan.slice(-4) || '4242';
    const bin = sanitizedPan.slice(0, 6) || '400000';

    // Infer issuer country & brand
    const cardBrand = sanitizedPan.startsWith('4')
      ? 'VISA_SYNTHETIC'
      : sanitizedPan.startsWith('5')
      ? 'MC_SYNTHETIC'
      : sanitizedPan.startsWith('3')
      ? 'AMEX_SYNTHETIC'
      : 'RHINO_CARD';

    const tokenId = `tok_rhino_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const cryptogram = `crypt_3ds2_${Math.random().toString(36).substring(2, 12).toUpperCase()}`;

    const token: PaymentToken = {
      id: tokenId,
      token_vault_id: 'vault_rhino_pci_zone_1',
      merchant_id: params.merchantId,
      customer_id: params.customerId,
      token: tokenId,
      token_status: 'ACTIVE',
      card_brand: cardBrand,
      last4,
      exp_month: params.expMonth,
      exp_year: params.expYear,
      cardholder_name: params.cardholderName || 'VALUED RHINO CUSTOMER',
      issuer_country: bin.startsWith('4000') ? 'GBR' : 'USA',
      bin,
      cryptogram,
      created_at: new Date().toISOString(),
    };

    this.tokensMap.set(tokenId, token);
    return token;
  }

  public getToken(tokenId: string): PaymentToken | undefined {
    return this.tokensMap.get(tokenId);
  }

  public getTokensForMerchant(merchantId: string): PaymentToken[] {
    return Array.from(this.tokensMap.values()).filter((t) => t.merchant_id === merchantId);
  }

  public updateTokenStatus(tokenId: string, status: TokenStatus): PaymentToken {
    const token = this.tokensMap.get(tokenId);
    if (!token) {
      throw new Error(`TOKEN_NOT_FOUND: Token ${tokenId} does not exist in vault.`);
    }
    token.token_status = status;
    this.tokensMap.set(tokenId, token);
    return token;
  }
}

export const globalTokenVault = new TokenVaultService();
