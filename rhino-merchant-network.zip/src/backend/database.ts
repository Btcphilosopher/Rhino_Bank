/**
 * RHINO MERCHANT NETWORK - Core Database Store & Seed Fixtures
 * Manages synthetic market state: Merchants, Stores, Terminals, Customers, Tokens,
 * Payment Intents, Transactions, Disputes, Subscriptions, Invoices, Payment Links, Audit Events.
 */

import {
  AuditEvent,
  Customer,
  Dispute,
  Invoice,
  Merchant,
  PaymentIntent,
  PaymentLink,
  Store,
  Subscription,
  Terminal,
  Transaction,
  WebhookDelivery,
} from '../types/rhino';
import { globalFraudEngine } from './fraudEngine';
import { globalLedgerEngine } from './ledger';
import { globalRoutingEngine } from './routingEngine';
import { globalSettlementEngine } from './settlementEngine';
import { globalTokenVault } from './tokenVault';

export class DatabaseStore {
  public merchants: Map<string, Merchant> = new Map();
  public stores: Map<string, Store> = new Map();
  public terminals: Map<string, Terminal> = new Map();
  public customers: Map<string, Customer> = new Map();
  public paymentIntents: Map<string, PaymentIntent> = new Map();
  public transactions: Map<string, Transaction> = new Map();
  public disputes: Map<string, Dispute> = new Map();
  public invoices: Map<string, Invoice> = new Map();
  public paymentLinks: Map<string, PaymentLink> = new Map();
  public subscriptions: Map<string, Subscription> = new Map();
  public webhooks: Map<string, WebhookDelivery> = new Map();
  public auditLogs: AuditEvent[] = [];

  constructor() {
    this.seedMarketData();
  }

  /**
   * Seed rich synthetic bank & merchant market
   */
  private seedMarketData() {
    // 1. Merchants across diverse industries
    const seedMerchants: Partial<Merchant>[] = [
      {
        id: 'merch_coffee_01',
        merchant_code: 'RH-M-COFFEE-001',
        legal_name: 'Rhino Coffee Group Ltd',
        trading_name: 'Rhino Coffee Roasters',
        merchant_category_code: '5814', // Fast Food / Coffee
        country: 'GBR',
        industry: 'Specialty Coffee & Bakery',
        onboarding_status: 'APPROVED',
        risk_tier: 'LOW',
        risk_score: 12,
        settlement_currency: 'GBP',
        expected_monthly_volume: 185000,
        average_transaction_value: 8.5,
        max_transaction_value: 120.0,
        sales_channels: ['POS_TERMINAL', 'MOBILE_APP', 'ONLINE'],
      },
      {
        id: 'merch_tech_02',
        merchant_code: 'RH-M-TECH-002',
        legal_name: 'Apex Cloud Software Systems Inc',
        trading_name: 'Apex Cloud Platforms',
        merchant_category_code: '5734', // Computer Software
        country: 'USA',
        industry: 'B2B Software & Cloud Services',
        onboarding_status: 'APPROVED',
        risk_tier: 'LOW',
        risk_score: 18,
        settlement_currency: 'USD',
        expected_monthly_volume: 1250000,
        average_transaction_value: 450.0,
        max_transaction_value: 25000.0,
        sales_channels: ['ECOMMERCE', 'SUBSCRIPTION', 'INVOICE'],
      },
      {
        id: 'merch_luxury_03',
        merchant_code: 'RH-M-LUX-003',
        legal_name: 'Maison de Paris Mode SARL',
        trading_name: 'Maison Luxury Boutique',
        merchant_category_code: '5691', // Apparel & Fashion
        country: 'FRA',
        industry: 'Luxury Fashion Retail',
        onboarding_status: 'APPROVED',
        risk_tier: 'MEDIUM',
        risk_score: 42,
        settlement_currency: 'EUR',
        expected_monthly_volume: 890000,
        average_transaction_value: 1250.0,
        max_transaction_value: 15000.0,
        sales_channels: ['POS_TERMINAL', 'ECOMMERCE', 'PAYMENT_LINK'],
      },
      {
        id: 'merch_airline_04',
        merchant_code: 'RH-M-AIR-004',
        legal_name: 'TransGlobal Airways Group Plc',
        trading_name: 'TransGlobal Express',
        merchant_category_code: '4511', // Airlines
        country: 'GBR',
        industry: 'Aviation & Travel',
        onboarding_status: 'APPROVED',
        risk_tier: 'HIGH',
        risk_score: 68,
        settlement_currency: 'GBP',
        expected_monthly_volume: 8500000,
        average_transaction_value: 680.0,
        max_transaction_value: 12000.0,
        sales_channels: ['ECOMMERCE', 'MOBILE_APP', 'CALL_CENTRE'],
      },
    ];

    for (const m of seedMerchants) {
      const fullMerch: Merchant = {
        id: m.id!,
        merchant_code: m.merchant_code!,
        legal_entity_id: `leg_${m.id}`,
        legal_name: m.legal_name!,
        trading_name: m.trading_name!,
        merchant_category_code: m.merchant_category_code!,
        country: m.country!,
        industry: m.industry!,
        onboarding_status: m.onboarding_status!,
        risk_tier: m.risk_tier!,
        risk_score: m.risk_score!,
        settlement_currency: m.settlement_currency!,
        expected_monthly_volume: m.expected_monthly_volume!,
        average_transaction_value: m.average_transaction_value!,
        max_transaction_value: m.max_transaction_value!,
        sales_channels: m.sales_channels!,
        created_at: new Date(Date.now() - 86400000 * 90).toISOString(),
        updated_at: new Date().toISOString(),
      };
      this.merchants.set(fullMerch.id, fullMerch);
      globalLedgerEngine.registerMerchantAccount(fullMerch.id, fullMerch.settlement_currency);
    }

    // 2. Seed Stores
    const seedStore: Store = {
      id: 'store_london_01',
      merchant_id: 'merch_coffee_01',
      store_code: 'LDN-001',
      name: 'Rhino Coffee - City Flagship',
      address: '100 Bishopsgate, London EC2N 4AG',
      city: 'London',
      country: 'GBR',
      created_at: new Date(Date.now() - 86400000 * 60).toISOString(),
    };
    this.stores.set(seedStore.id, seedStore);

    // 3. Seed Terminals
    const seedTerminal: Terminal = {
      id: 'RH-T001',
      terminal_id: 'RH-T001',
      merchant_id: 'merch_coffee_01',
      store_id: 'store_london_01',
      model: 'Rhino Touch POS-5000',
      serial_number: 'SN-RHPOS-992183',
      status: 'ACTIVE',
      battery_level: 98,
      firmware_version: 'v4.2.1-sec',
      ip_address: '192.168.1.142',
      last_seen_at: new Date().toISOString(),
      offline_transactions_count: 0,
      offline_volume: 0,
      public_key_fingerprint: '3f:a2:1b:e8:99:c4:d2',
    };
    this.terminals.set(seedTerminal.id, seedTerminal);

    // 4. Seed Customer
    const seedCustomer: Customer = {
      id: 'cust_001',
      merchant_id: 'merch_coffee_01',
      email: 'alex.taylor@example.co.uk',
      name: 'Alex Taylor',
      phone: '+44 7700 900077',
      risk_score: 5,
      created_at: new Date(Date.now() - 86400000 * 30).toISOString(),
    };
    this.customers.set(seedCustomer.id, seedCustomer);

    // 5. Seed Initial Transactions & Ledger Entries
    const initialTxs: { amount: number; desc: string; entry: any; merchId: string; curr: any }[] = [
      { amount: 8.5, desc: 'Artisan Flat White & Croissant', entry: 'CONTACTLESS', merchId: 'merch_coffee_01', curr: 'GBP' },
      { amount: 14.2, desc: 'Single Origin Beans 500g', entry: 'CHIP', merchId: 'merch_coffee_01', curr: 'GBP' },
      { amount: 450.0, desc: 'Monthly Enterprise Cloud Subscription', entry: 'RECURRING', merchId: 'merch_tech_02', curr: 'USD' },
      { amount: 1250.0, desc: 'Italian Leather Handbag', entry: 'CONTACTLESS', merchId: 'merch_luxury_03', curr: 'EUR' },
      { amount: 680.0, desc: 'London to Tokyo Flight Booking', entry: 'ECOMMERCE', merchId: 'merch_airline_04', curr: 'GBP' },
    ];

    for (let i = 0; i < initialTxs.length; i++) {
      const item = initialTxs[i];
      const txId = `RH-TX-${100000 + i}`;
      const token = globalTokenVault.tokenizeCard({
        merchantId: item.merchId,
        pan: '4000001234564242',
        expMonth: 12,
        expYear: 2028,
        cvv: '123',
        cardholderName: 'ALEX TAYLOR',
      });

      const routeResult = globalRoutingEngine.selectRoute({
        amount: item.amount,
        currency: item.curr,
        country: 'GBR',
        entryMode: item.entry,
        riskScore: 10,
      });

      const fee = Math.round((item.amount * 0.015 + 0.1) * 100) / 100;
      const net = Math.round((item.amount - fee) * 100) / 100;

      const tx: Transaction = {
        id: txId,
        rhino_reference: `RH-REF-${Date.now()}-${i}`,
        merchant_id: item.merchId,
        store_id: item.merchId === 'merch_coffee_01' ? 'store_london_01' : undefined,
        terminal_id: item.merchId === 'merch_coffee_01' ? 'RH-T001' : undefined,
        customer_id: 'cust_001',
        token_id: token.id,
        amount: item.amount,
        captured_amount: item.amount,
        refunded_amount: 0,
        currency: item.curr,
        entry_mode: item.entry,
        status: 'CAPTURED',
        payment_method: 'VISA_SYNTHETIC',
        route_used: routeResult.selectedRoute.route_id,
        is_rerouted: false,
        authorisation_code: `AUTH-${Math.floor(100000 + Math.random() * 900000)}`,
        network_reference: `NET-REF-${Date.now()}`,
        risk_score: 8,
        risk_decision: 'ALLOW',
        risk_reasons: ['Low risk score', 'Valid 3DS cryptogram'],
        fee_amount: fee,
        net_amount: net,
        cleared: true,
        settled: false,
        is_offline: false,
        created_at: new Date(Date.now() - 3600000 * (i + 1)).toISOString(),
        updated_at: new Date().toISOString(),
        attempts: [
          {
            id: `ATT-${i}`,
            transaction_id: txId,
            attempt_number: 1,
            route_selected: routeResult.selectedRoute.route_id,
            response_code: '00',
            response_message: 'APPROVED - 00',
            latency_ms: 115,
            success: true,
            timestamp: new Date().toISOString(),
          },
        ],
      };

      this.transactions.set(tx.id, tx);

      // Post initial ledger entries
      globalLedgerEngine.recordPaymentCapture(tx.id, item.merchId, item.amount, fee, item.curr, `corr_init_${i}`);
    }

    // Generate initial settlement batch
    globalSettlementEngine.generateSettlementBatch({
      merchantId: 'merch_coffee_01',
      currency: 'GBP',
      transactions: Array.from(this.transactions.values()),
    });

    // Seed Audit Log
    this.auditLogs.push({
      id: 'AUDIT-001',
      correlation_id: 'CORR-SYS-BOOT',
      operator: 'SYSTEM_BOOTSTRAPPER',
      category: 'SYSTEM',
      action: 'BOOTSTRAP_RHINO_PAYMENTS_NETWORK',
      details: { status: 'SUCCESS', version: 'v3.7.0-enterprise' },
      ip_address: '127.0.0.1',
      timestamp: new Date().toISOString(),
    });
  }

  public recordAudit(category: any, action: string, operator: string, details: any) {
    const event: AuditEvent = {
      id: `AUDIT-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      correlation_id: `CORR-${Date.now()}`,
      operator,
      category,
      action,
      details,
      ip_address: '10.240.0.1',
      timestamp: new Date().toISOString(),
    };
    this.auditLogs.unshift(event);
    return event;
  }
}

export const dbStore = new DatabaseStore();
