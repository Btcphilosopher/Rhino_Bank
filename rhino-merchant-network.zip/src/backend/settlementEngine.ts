/**
 * RHINO MERCHANT NETWORK - Batch Settlement & Payout Engine
 * Gross-to-Net settlement calculations with multi-currency netting,
 * fee deductions, reserve holds, and automated payout instruction dispatch.
 */

import { Currency, Payout, SettlementBatch, Transaction } from '../types/rhino';
import { globalLedgerEngine } from './ledger';

export class SettlementEngineService {
  private batches: Map<string, SettlementBatch> = new Map();
  private payouts: Map<string, Payout> = new Map();

  /**
   * Run automated gross-to-net settlement calculation for a merchant
   */
  public generateSettlementBatch(params: {
    merchantId: string;
    currency: Currency;
    transactions: Transaction[];
    adjustments?: number;
  }): { batch: SettlementBatch; payout: Payout } {
    const { merchantId, currency, transactions, adjustments = 0 } = params;

    const capturedTxs = transactions.filter(
      (t) => t.merchant_id === merchantId && t.currency === currency && t.status === 'CAPTURED' && !t.settled
    );

    let grossAmount = 0;
    let feeAmount = 0;
    let refundAmount = 0;
    let chargebackAmount = 0;

    for (const tx of capturedTxs) {
      grossAmount += tx.captured_amount || tx.amount;
      feeAmount += tx.fee_amount || 0;
      refundAmount += tx.refunded_amount || 0;
      if (tx.status === 'DISPUTED') {
        chargebackAmount += tx.amount;
      }
    }

    grossAmount = Math.round(grossAmount * 100) / 100;
    feeAmount = Math.round(feeAmount * 100) / 100;
    refundAmount = Math.round(refundAmount * 100) / 100;
    chargebackAmount = Math.round(chargebackAmount * 100) / 100;

    // Net settlement calculation: Gross - Refunds - Chargebacks - Fees + Adjustments
    const netAmount = Math.max(0, Math.round((grossAmount - refundAmount - chargebackAmount - feeAmount + adjustments) * 100) / 100);

    const batchId = `SETTLE-BATCH-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const batch: SettlementBatch = {
      id: batchId,
      batch_reference: `RH-BATCH-${Date.now().toString().slice(-8)}`,
      merchant_id: merchantId,
      currency,
      business_date: new Date().toISOString().split('T')[0],
      gross_amount: grossAmount,
      refund_amount: refundAmount,
      chargeback_amount: chargebackAmount,
      fee_amount: feeAmount,
      adjustment_amount: adjustments,
      net_amount: netAmount,
      status: 'POSTED',
      created_at: new Date().toISOString(),
      processed_at: new Date().toISOString(),
    };

    this.batches.set(batchId, batch);

    // Mark transactions as settled
    for (const tx of capturedTxs) {
      tx.settled = true;
      tx.status = 'SETTLED';
    }

    // Generate Payout
    const payoutId = `PAYOUT-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const payout: Payout = {
      id: payoutId,
      payout_reference: `RH-PAY-${Date.now().toString().slice(-8)}`,
      merchant_id: merchantId,
      settlement_batch_id: batchId,
      amount: netAmount,
      currency,
      status: 'COMPLETED',
      iban_last4: '8819',
      bank_name: 'RHINO BANK INSTITUTIONAL CLEARING',
      scheduled_date: new Date().toISOString().split('T')[0],
      executed_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
    };

    this.payouts.set(payoutId, payout);

    // Post double-entry ledger settlement payout entry
    if (netAmount > 0) {
      globalLedgerEngine.recordSettlementPayout(payoutId, merchantId, netAmount, currency, `corr_settle_${batchId}`);
    }

    return { batch, payout };
  }

  public getBatchesForMerchant(merchantId: string): SettlementBatch[] {
    return Array.from(this.batches.values()).filter((b) => b.merchant_id === merchantId);
  }

  public getPayoutsForMerchant(merchantId: string): Payout[] {
    return Array.from(this.payouts.values()).filter((p) => p.merchant_id === merchantId);
  }

  public getAllBatches(): SettlementBatch[] {
    return Array.from(this.batches.values());
  }

  public getAllPayouts(): Payout[] {
    return Array.from(this.payouts.values());
  }
}

export const globalSettlementEngine = new SettlementEngineService();
