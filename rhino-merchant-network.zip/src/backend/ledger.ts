/**
 * RHINO MERCHANT NETWORK - Ledger Subsystem
 * Immutable Double-Entry Ledger Engine
 * Enforces fundamental accounting invariant: SUM(Debits) === SUM(Credits)
 */

import { Currency, LedgerAccount, LedgerAccountType, LedgerEntry } from '../types/rhino';

export class DoubleEntryLedgerEngine {
  private entries: LedgerEntry[] = [];
  private accountConfigs: Map<string, LedgerAccount> = new Map();

  constructor() {
    this.seedSystemAccounts();
  }

  /**
   * Initialize standard bank-grade chart of accounts
   */
  private seedSystemAccounts() {
    const defaultAccounts: { type: LedgerAccountType; code: string; name: string }[] = [
      { type: 'BANK_CASH', code: '1000-CASH', name: 'Rhino Bank Cash Reserves' },
      { type: 'NETWORK_RECEIVABLE', code: '1100-NET-REC', name: 'Card Network & Issuer Receivables' },
      { type: 'MERCHANT_RECEIVABLE', code: '1200-MERCH-REC', name: 'Merchant Gross Receivables' },
      { type: 'MERCHANT_PAYABLE', code: '2000-MERCH-PAY', name: 'Merchant Payable Settlements' },
      { type: 'FEE_REVENUE', code: '3000-FEE-REV', name: 'Rhino Gateway & Interchange Fee Revenue' },
      { type: 'REFUND_LIABILITY', code: '2100-REFUND-LIAB', name: 'Pending Merchant Refund Liabilities' },
      { type: 'CHARGEBACK_LIABILITY', code: '2200-CB-LIAB', name: 'Dispute & Chargeback Reserve Fund' },
      { type: 'SETTLEMENT_CLEARING', code: '1300-SETTLE-CLR', name: 'Settlement Batch Clearing House' },
      { type: 'FX_GAIN_LOSS', code: '4000-FX-GAIN', name: 'Foreign Exchange Conversion Gain/Loss' },
      { type: 'RESERVE_ACCOUNT', code: '2300-RISK-RES', name: 'High-Risk Merchant Collateral Reserve' },
    ];

    const currencies: Currency[] = ['GBP', 'USD', 'EUR', 'CHF', 'JPY', 'CAD', 'AUD', 'SGD', 'HKD'];

    for (const curr of currencies) {
      for (const acc of defaultAccounts) {
        const id = `${acc.code}-${curr}`;
        this.accountConfigs.set(id, {
          id,
          account_type: acc.type,
          currency: curr,
          code: acc.code,
          name: `${acc.name} (${curr})`,
          description: `System ledger account for ${acc.name}`,
          balance: 0,
        });
      }
    }
  }

  /**
   * Register a custom merchant specific ledger payable account
   */
  public registerMerchantAccount(merchantId: string, currency: Currency): LedgerAccount {
    const id = `2000-MERCH-PAY-${merchantId}-${currency}`;
    if (!this.accountConfigs.has(id)) {
      const acc: LedgerAccount = {
        id,
        merchant_id: merchantId,
        account_type: 'MERCHANT_PAYABLE',
        currency,
        code: `2000-${merchantId.slice(0, 8)}`,
        name: `Merchant Payable (${merchantId.slice(0, 8)}) [${currency}]`,
        description: `Direct payable balance for merchant ${merchantId}`,
        balance: 0,
      };
      this.accountConfigs.set(id, acc);
    }
    return this.getAccount(id)!;
  }

  public getAccount(id: string): LedgerAccount | undefined {
    const acc = this.accountConfigs.get(id);
    if (!acc) return undefined;
    // Calculate balance dynamically from immutable entries
    const derivedBalance = this.calculateAccountBalance(id);
    return { ...acc, balance: derivedBalance };
  }

  public getAllAccounts(): LedgerAccount[] {
    return Array.from(this.accountConfigs.keys()).map((id) => this.getAccount(id)!);
  }

  public getMerchantAccounts(merchantId: string): LedgerAccount[] {
    return this.getAllAccounts().filter((a) => a.merchant_id === merchantId);
  }

  /**
   * Pure derivation of account balance from all entries
   */
  public calculateAccountBalance(accountId: string): number {
    const accountEntries = this.entries.filter((e) => e.account_id === accountId);
    let total = 0;
    for (const e of accountEntries) {
      const accType = e.account_type;
      // Normal balance side rules:
      // Asset accounts (Bank Cash, Network Rec, Merchant Rec) -> DEBIT positive, CREDIT negative
      // Liability/Equity/Revenue (Merchant Payable, Fee Rev, Reserves) -> CREDIT positive, DEBIT negative
      const isAsset =
        accType === 'BANK_CASH' ||
        accType === 'NETWORK_RECEIVABLE' ||
        accType === 'MERCHANT_RECEIVABLE' ||
        accType === 'SETTLEMENT_CLEARING';

      if (isAsset) {
        total += e.direction === 'DEBIT' ? e.amount : -e.amount;
      } else {
        total += e.direction === 'CREDIT' ? e.amount : -e.amount;
      }
    }
    return Math.round(total * 100) / 100;
  }

  /**
   * Post a balanced double-entry accounting transaction
   */
  public postTransaction(
    transactionId: string,
    correlationId: string,
    currency: Currency,
    debits: { accountId: string; amount: number; merchantId?: string; description?: string }[],
    credits: { accountId: string; amount: number; merchantId?: string; description?: string }[],
    sourceEvent: string
  ): LedgerEntry[] {
    // 1. Verify exact Decimal summation invariant: SUM(Debits) === SUM(Credits)
    const sumDebits = debits.reduce((acc, d) => acc + Math.round(d.amount * 100), 0);
    const sumCredits = credits.reduce((acc, c) => acc + Math.round(c.amount * 100), 0);

    if (sumDebits !== sumCredits) {
      throw new Error(
        `LEDGER_UNBALANCED_ERROR: Total debits (${sumDebits / 100} ${currency}) do not match total credits (${sumCredits / 100} ${currency}). Double-entry invariant broken.`
      );
    }

    const newEntries: LedgerEntry[] = [];
    const timestamp = new Date().toISOString();

    // Process Debits
    for (const d of debits) {
      const acc = this.getAccount(d.accountId) || this.getSystemAccount('BANK_CASH', currency);
      const entry: LedgerEntry = {
        id: `LDE-D-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        transaction_id: transactionId,
        correlation_id: correlationId,
        account_id: acc.id,
        account_type: acc.account_type,
        merchant_id: d.merchantId || acc.merchant_id,
        direction: 'DEBIT',
        amount: Math.round(d.amount * 100) / 100,
        currency,
        description: d.description || `Debit entry for ${sourceEvent}`,
        source_event: sourceEvent,
        created_at: timestamp,
      };
      newEntries.push(entry);
    }

    // Process Credits
    for (const c of credits) {
      const acc = this.getAccount(c.accountId) || this.getSystemAccount('FEE_REVENUE', currency);
      const entry: LedgerEntry = {
        id: `LDE-C-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        transaction_id: transactionId,
        correlation_id: correlationId,
        account_id: acc.id,
        account_type: acc.account_type,
        merchant_id: c.merchantId || acc.merchant_id,
        direction: 'CREDIT',
        amount: Math.round(c.amount * 100) / 100,
        currency,
        description: c.description || `Credit entry for ${sourceEvent}`,
        source_event: sourceEvent,
        created_at: timestamp,
      };
      newEntries.push(entry);
    }

    // Append to immutable log
    this.entries.push(...newEntries);
    return newEntries;
  }

  /**
   * Helper to fetch system account ID by type and currency
   */
  public getSystemAccount(type: LedgerAccountType, currency: Currency): LedgerAccount {
    const codeMap: Record<LedgerAccountType, string> = {
      BANK_CASH: '1000-CASH',
      NETWORK_RECEIVABLE: '1100-NET-REC',
      MERCHANT_RECEIVABLE: '1200-MERCH-REC',
      MERCHANT_PAYABLE: '2000-MERCH-PAY',
      FEE_REVENUE: '3000-FEE-REV',
      REFUND_LIABILITY: '2100-REFUND-LIAB',
      CHARGEBACK_LIABILITY: '2200-CB-LIAB',
      SETTLEMENT_CLEARING: '1300-SETTLE-CLR',
      FX_GAIN_LOSS: '4000-FX-GAIN',
      RESERVE_ACCOUNT: '2300-RISK-RES',
    };
    const code = codeMap[type];
    const id = `${code}-${currency}`;
    let acc = this.accountConfigs.get(id);
    if (!acc) {
      acc = {
        id,
        account_type: type,
        currency,
        code,
        name: `${type} (${currency})`,
        description: `System account for ${type}`,
        balance: 0,
      };
      this.accountConfigs.set(id, acc);
    }
    return this.getAccount(id)!;
  }

  /**
   * Post standard payment capture ledger entry:
   * Debit: Network Receivable (Gross Amount)
   * Credit: Merchant Payable (Net Amount = Gross - Fee)
   * Credit: Fee Revenue (Fee Amount)
   */
  public recordPaymentCapture(
    transactionId: string,
    merchantId: string,
    grossAmount: number,
    feeAmount: number,
    currency: Currency,
    correlationId: string
  ): LedgerEntry[] {
    const netAmount = Math.round((grossAmount - feeAmount) * 100) / 100;
    const netRecAcc = this.getSystemAccount('NETWORK_RECEIVABLE', currency);
    const merchPayAcc = this.registerMerchantAccount(merchantId, currency);
    const feeRevAcc = this.getSystemAccount('FEE_REVENUE', currency);

    return this.postTransaction(
      transactionId,
      correlationId,
      currency,
      [
        {
          accountId: netRecAcc.id,
          amount: grossAmount,
          description: `Network receivable for payment capture ${transactionId}`,
        },
      ],
      [
        {
          accountId: merchPayAcc.id,
          amount: netAmount,
          merchantId,
          description: `Merchant net payable after fee ${feeAmount}`,
        },
        {
          accountId: feeRevAcc.id,
          amount: feeAmount,
          description: `Rhino acquiring fee for transaction ${transactionId}`,
        },
      ],
      'PaymentCaptured'
    );
  }

  /**
   * Post refund ledger entry:
   * Debit: Merchant Payable (Net Refund)
   * Credit: Bank Cash / Refund Liability (Refund Amount)
   */
  public recordRefund(
    refundId: string,
    transactionId: string,
    merchantId: string,
    refundAmount: number,
    currency: Currency,
    correlationId: string
  ): LedgerEntry[] {
    const merchPayAcc = this.registerMerchantAccount(merchantId, currency);
    const refundLiabAcc = this.getSystemAccount('REFUND_LIABILITY', currency);

    return this.postTransaction(
      refundId,
      correlationId,
      currency,
      [
        {
          accountId: merchPayAcc.id,
          amount: refundAmount,
          merchantId,
          description: `Debit merchant payable for refund ${refundId}`,
        },
      ],
      [
        {
          accountId: refundLiabAcc.id,
          amount: refundAmount,
          description: `Credit refund liability for payment ${transactionId}`,
        },
      ],
      'PaymentRefunded'
    );
  }

  /**
   * Post Settlement Batch execution ledger entry:
   * Debit: Merchant Payable (Net Settlement)
   * Credit: Bank Cash (Outgoing Payout)
   */
  public recordSettlementPayout(
    payoutId: string,
    merchantId: string,
    payoutAmount: number,
    currency: Currency,
    correlationId: string
  ): LedgerEntry[] {
    const merchPayAcc = this.registerMerchantAccount(merchantId, currency);
    const cashAcc = this.getSystemAccount('BANK_CASH', currency);

    return this.postTransaction(
      payoutId,
      correlationId,
      currency,
      [
        {
          accountId: merchPayAcc.id,
          amount: payoutAmount,
          merchantId,
          description: `Payout debit clearing merchant payable ${merchantId}`,
        },
      ],
      [
        {
          accountId: cashAcc.id,
          amount: payoutAmount,
          description: `Payout credit outgoing cash transfer ${payoutId}`,
        },
      ],
      'PayoutCompleted'
    );
  }

  public getEntriesForTransaction(transactionId: string): LedgerEntry[] {
    return this.entries.filter((e) => e.transaction_id === transactionId);
  }

  public getEntriesForMerchant(merchantId: string): LedgerEntry[] {
    return this.entries.filter((e) => e.merchant_id === merchantId);
  }

  public getAllEntries(): LedgerEntry[] {
    return [...this.entries];
  }
}

export const globalLedgerEngine = new DoubleEntryLedgerEngine();
