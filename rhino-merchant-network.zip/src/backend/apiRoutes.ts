/**
 * RHINO MERCHANT NETWORK - Express REST API Route Controllers
 * Bank-Grade Merchant Payments, Acquiring, Payment Orchestration & Commerce Infrastructure API
 */

import { Request, Response, Router } from 'express';
import { Currency, Dispute, EntryMode, FraudRule, Invoice, PaymentIntent, PaymentLink, Subscription, Transaction } from '../types/rhino';
import { globalAIIntelligence } from './aiAssistant';
import { dbStore } from './database';
import { globalFraudEngine } from './fraudEngine';
import { globalLedgerEngine } from './ledger';
import { globalReconciliationEngine } from './reconciliationEngine';
import { globalRoutingEngine } from './routingEngine';
import { globalSettlementEngine } from './settlementEngine';
import { globalTokenVault } from './tokenVault';

export const apiRouter = Router();

// Idempotency cache map
const idempotencyMap: Map<string, { status: number; body: any }> = new Map();

/**
 * Middleware: Idempotency-Key validation & response caching
 */
function idempotencyMiddleware(req: Request, res: Response, next: Function) {
  const ik = req.headers['idempotency-key'] as string;
  if (req.method === 'POST' && ik) {
    if (idempotencyMap.has(ik)) {
      const cached = idempotencyMap.get(ik)!;
      return res.status(cached.status).json({ ...cached.body, _cached_idempotent: true });
    }
  }
  next();
}

apiRouter.use(idempotencyMiddleware as any);

/**
 * Health & Overview Status
 */
apiRouter.get('/v1/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    institution: 'RHINO BANK',
    platform: 'rhino-payments',
    time: new Date().toISOString(),
    network_health: {
      ACQUIRER_A: 'HEALTHY',
      ACQUIRER_B: 'HEALTHY',
      NETWORK_A: 'HEALTHY',
      NETWORK_B: 'HEALTHY',
      WALLET_A: 'HEALTHY',
    },
    ledger_balanced: true,
  });
});

/**
 * POST /v1/payment-intents
 * Create PaymentIntent
 */
apiRouter.post('/v1/payment-intents', (req, res) => {
  try {
    const { merchant_id, amount, currency = 'GBP', description = 'Rhino Merchant Payment', capture_method = 'AUTOMATIC' } = req.body;

    if (!merchant_id || !amount) {
      return res.status(400).json({ error: 'INVALID_REQUEST: merchant_id and amount are required.' });
    }

    const intentId = `pi_rhino_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const intent: PaymentIntent = {
      id: intentId,
      merchant_id,
      amount: Number(amount),
      currency: currency as Currency,
      description,
      status: 'REQUIRES_PAYMENT_METHOD',
      capture_method,
      payment_method_type: 'CARD',
      metadata: req.body.metadata || {},
      expires_at: new Date(Date.now() + 1800000).toISOString(), // 30 mins
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    dbStore.paymentIntents.set(intentId, intent);
    dbStore.recordAudit('PAYMENT', 'CREATE_PAYMENT_INTENT', 'MERCHANT_API', { intentId, amount, currency });

    res.status(201).json(intent);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /v1/payment-intents/:id
 */
apiRouter.get('/v1/payment-intents/:id', (req, res) => {
  const intent = dbStore.paymentIntents.get(req.params.id);
  if (!intent) return res.status(404).json({ error: 'PAYMENT_INTENT_NOT_FOUND' });
  res.json(intent);
});

/**
 * POST /v1/transactions/process
 * Core Payment Processing Engine (Card-Present & Card-Not-Present)
 */
apiRouter.post('/v1/transactions/process', (req, res) => {
  try {
    const ik = req.headers['idempotency-key'] as string;
    const {
      merchant_id = 'merch_coffee_01',
      terminal_id,
      store_id,
      amount,
      currency = 'GBP',
      pan = '4000001234564242',
      exp_month = 12,
      exp_year = 2028,
      cvv = '123',
      cardholder_name = 'ALEX TAYLOR',
      entry_mode = 'CONTACTLESS',
      force_route,
      simulate_offline = false,
      simulate_fraud_challenge = false,
    } = req.body;

    const merch = dbStore.merchants.get(merchant_id) || dbStore.merchants.get('merch_coffee_01')!;

    // 1. Tokenize Card in PCI-Isolated Vault
    const token = globalTokenVault.tokenizeCard({
      merchantId: merch.id,
      pan,
      expMonth: exp_month,
      expYear: exp_year,
      cvv,
      cardholderName: cardholder_name,
    });

    const txId = `RH-TX-${Math.floor(100000 + Math.random() * 900000)}`;

    // 2. Fraud & Risk Check
    const fraudEval = globalFraudEngine.evaluateTransaction({
      transactionId: txId,
      amount: Number(amount),
      currency,
      merchantId: merch.id,
      merchantCountry: merch.country,
      merchantRiskScore: merch.risk_score,
      bin: token.bin,
      issuerCountry: token.issuer_country,
      entryMode: entry_mode as EntryMode,
      cardLast4: token.last4,
    });

    if (simulate_fraud_challenge && fraudEval.decision === 'ALLOW') {
      fraudEval.decision = 'CHALLENGE';
      fraudEval.risk_score = 65;
      fraudEval.rules_triggered.push('SIMULATION: Forced 3DS Challenge Demo');
    }

    if (fraudEval.decision === 'DECLINE') {
      const declinedTx: Transaction = {
        id: txId,
        rhino_reference: `RH-REF-${Date.now()}`,
        merchant_id: merch.id,
        terminal_id,
        store_id,
        token_id: token.id,
        amount: Number(amount),
        captured_amount: 0,
        refunded_amount: 0,
        currency,
        entry_mode: entry_mode as EntryMode,
        status: 'DECLINED',
        payment_method: token.card_brand,
        route_used: 'REJECTED_AT_RISK_PLANE',
        is_rerouted: false,
        risk_score: fraudEval.risk_score,
        risk_decision: 'DECLINE',
        risk_reasons: fraudEval.rules_triggered,
        fee_amount: 0,
        net_amount: 0,
        cleared: false,
        settled: false,
        is_offline: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        attempts: [],
      };
      dbStore.transactions.set(txId, declinedTx);
      dbStore.recordAudit('FRAUD', 'TRANSACTION_BLOCKED_RISK', 'FRAUD_ENGINE', { txId, riskScore: fraudEval.risk_score });

      const resp = {
        approved: false,
        status: 'DECLINED',
        response_code: '51_RISK_DECLINE',
        transaction: declinedTx,
        fraud_decision: fraudEval,
      };

      if (ik) idempotencyMap.set(ik, { status: 200, body: resp });
      return res.json(resp);
    }

    // 3. Dynamic Smart Routing & Network Failover Selection
    const routeResult = globalRoutingEngine.selectRoute({
      amount: Number(amount),
      currency,
      country: merch.country,
      entryMode: entry_mode as EntryMode,
      riskScore: fraudEval.risk_score,
      forceRoute: force_route,
    });

    // 4. Authorization & Fee Calculation
    const feeAmount = Math.round((Number(amount) * 0.015 + 0.1) * 100) / 100;
    const netAmount = Math.round((Number(amount) - feeAmount) * 100) / 100;
    const authCode = `AUTH-${Math.floor(100000 + Math.random() * 900000)}`;

    const approvedTx: Transaction = {
      id: txId,
      rhino_reference: `RH-REF-${Date.now()}`,
      merchant_id: merch.id,
      terminal_id,
      store_id,
      token_id: token.id,
      amount: Number(amount),
      captured_amount: Number(amount),
      refunded_amount: 0,
      currency,
      entry_mode: entry_mode as EntryMode,
      status: 'CAPTURED',
      payment_method: token.card_brand,
      route_used: routeResult.selectedRoute.route_id,
      original_route_attempted: force_route || routeResult.selectedRoute.route_id,
      is_rerouted: routeResult.isRerouted,
      authorisation_code: authCode,
      network_reference: `NET-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      risk_score: fraudEval.risk_score,
      risk_decision: fraudEval.decision,
      risk_reasons: fraudEval.rules_triggered,
      fee_amount: feeAmount,
      net_amount: netAmount,
      cleared: true,
      settled: false,
      is_offline: Boolean(simulate_offline),
      idempotency_key: ik,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      attempts: [
        {
          id: `ATT-1-${txId}`,
          transaction_id: txId,
          attempt_number: 1,
          route_selected: routeResult.selectedRoute.route_id,
          response_code: '00',
          response_message: 'APPROVED - 00',
          latency_ms: routeResult.selectedRoute.average_latency_ms,
          success: true,
          timestamp: new Date().toISOString(),
        },
      ],
    };

    dbStore.transactions.set(txId, approvedTx);

    // 5. Post Double-Entry Ledger Event
    globalLedgerEngine.recordPaymentCapture(txId, merch.id, Number(amount), feeAmount, currency, `corr_proc_${txId}`);

    dbStore.recordAudit('PAYMENT', 'AUTHORIZE_AND_CAPTURE', 'GATEWAY', {
      txId,
      merchantId: merch.id,
      amount,
      authCode,
      route: routeResult.selectedRoute.route_id,
    });

    const responseObj = {
      approved: true,
      status: 'CAPTURED',
      response_code: '00_APPROVED',
      authorisation_code: authCode,
      transaction: approvedTx,
      fraud_decision: fraudEval,
      route_info: routeResult,
    };

    if (ik) idempotencyMap.set(ik, { status: 200, body: responseObj });
    return res.json(responseObj);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /v1/refunds
 */
apiRouter.post('/v1/refunds', (req, res) => {
  try {
    const { transaction_id, amount, reason = 'Customer return' } = req.body;
    const tx = dbStore.transactions.get(transaction_id);

    if (!tx) return res.status(404).json({ error: 'TRANSACTION_NOT_FOUND' });

    const refundAmount = Number(amount) || tx.captured_amount;
    if (tx.refunded_amount + refundAmount > tx.captured_amount) {
      return res.status(400).json({ error: 'REFUND_EXCEEDS_CAPTURED_AMOUNT: Cannot refund more than net captured balance.' });
    }

    const refundId = `RFD-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
    tx.refunded_amount += refundAmount;
    if (tx.refunded_amount >= tx.captured_amount) {
      tx.status = 'REFUNDED';
    } else {
      tx.status = 'PARTIALLY_REFUNDED';
    }

    // Ledger entry for refund
    globalLedgerEngine.recordRefund(refundId, tx.id, tx.merchant_id, refundAmount, tx.currency, `corr_rfd_${refundId}`);

    dbStore.recordAudit('PAYMENT', 'ISSUE_REFUND', 'MERCHANT_PORTAL', { refundId, txId: tx.id, refundAmount });

    res.json({ success: true, refund_id: refundId, refunded_amount: refundAmount, transaction: tx });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /v1/transactions
 */
apiRouter.get('/v1/transactions', (req, res) => {
  const { merchant_id } = req.query;
  let txs = Array.from(dbStore.transactions.values());
  if (merchant_id) {
    txs = txs.filter((t) => t.merchant_id === merchant_id);
  }
  res.json(txs.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
});

/**
 * GET /v1/transactions/:id/trace
 * Master Payment Trace Graph Visualization
 */
apiRouter.get('/v1/transactions/:id/trace', (req, res) => {
  const tx = dbStore.transactions.get(req.params.id);
  if (!tx) return res.status(404).json({ error: 'TRANSACTION_NOT_FOUND' });

  const ledgerEntries = globalLedgerEngine.getEntriesForTransaction(tx.id);
  const merch = dbStore.merchants.get(tx.merchant_id);

  const traceGraph = {
    transaction_id: tx.id,
    rhino_reference: tx.rhino_reference,
    nodes: [
      { step: 1, stage: 'CUSTOMER_TAP', detail: `Card/Token: ${tx.payment_method} (${tx.entry_mode})`, status: 'SUCCESS' },
      { step: 2, stage: 'TOKENISATION', detail: `PCI Vault Token ${tx.token_id}`, status: 'SUCCESS' },
      { step: 3, stage: 'FRAUD_CHECK', detail: `Risk Score ${tx.risk_score}/100 -> Decision: ${tx.risk_decision}`, status: 'SUCCESS' },
      { step: 4, stage: 'SMART_ROUTING', detail: `Selected Route: ${tx.route_used} ${tx.is_rerouted ? '(Rerouted)' : ''}`, status: 'SUCCESS' },
      { step: 5, stage: 'AUTHORISATION', detail: `Approved Auth Code: ${tx.authorisation_code}`, status: 'SUCCESS' },
      { step: 6, stage: 'CAPTURE', detail: `Captured Gross Amount: ${tx.currency} ${tx.captured_amount.toFixed(2)}`, status: 'SUCCESS' },
      { step: 7, stage: 'DOUBLE_ENTRY_LEDGER', detail: `Balanced Entries Posted: ${ledgerEntries.length} lines`, status: 'SUCCESS' },
      { step: 8, stage: 'SETTLEMENT', detail: `Cleared & Batched for Merchant: ${merch?.trading_name}`, status: tx.settled ? 'SUCCESS' : 'PENDING' },
    ],
    ledger_entries: ledgerEntries,
  };

  res.json(traceGraph);
});

/**
 * GET /v1/merchants
 */
apiRouter.get('/v1/merchants', (req, res) => {
  res.json(Array.from(dbStore.merchants.values()));
});

/**
 * POST /v1/merchants/onboard
 */
apiRouter.post('/v1/merchants/onboard', (req, res) => {
  try {
    const { legal_name, trading_name, country = 'GBR', industry = 'Retail', settlement_currency = 'GBP', expected_monthly_volume = 100000 } = req.body;

    const merchId = `merch_${Date.now().toString().slice(-6)}`;
    const merchant = {
      id: merchId,
      merchant_code: `RH-M-${Math.floor(100 + Math.random() * 900)}`,
      legal_entity_id: `leg_${merchId}`,
      legal_name,
      trading_name,
      merchant_category_code: '5999',
      country,
      industry,
      onboarding_status: 'APPROVED' as const,
      risk_tier: 'LOW' as const,
      risk_score: 15,
      settlement_currency: settlement_currency as Currency,
      expected_monthly_volume: Number(expected_monthly_volume),
      average_transaction_value: 45.0,
      max_transaction_value: 2500.0,
      sales_channels: ['POS_TERMINAL', 'ECOMMERCE'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    dbStore.merchants.set(merchId, merchant);
    globalLedgerEngine.registerMerchantAccount(merchId, settlement_currency as Currency);

    dbStore.recordAudit('MERCHANT', 'ONBOARD_MERCHANT', 'ONBOARDING_DESK', { merchId, trading_name });

    res.status(201).json(merchant);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /v1/terminals
 */
apiRouter.get('/v1/terminals', (req, res) => {
  res.json(Array.from(dbStore.terminals.values()));
});

/**
 * POST /v1/terminals/:id/offline-sync
 * Reconnect & Process Offline Queued Terminal Transactions
 */
apiRouter.post('/v1/terminals/:id/offline-sync', (req, res) => {
  const terminal = dbStore.terminals.get(req.params.id);
  if (!terminal) return res.status(404).json({ error: 'TERMINAL_NOT_FOUND' });

  const offlineCount = terminal.offline_transactions_count || 3;
  const offlineVolume = terminal.offline_volume || 72.5;

  terminal.status = 'ACTIVE';
  terminal.last_seen_at = new Date().toISOString();
  terminal.offline_transactions_count = 0;
  terminal.offline_volume = 0;

  dbStore.recordAudit('SYSTEM', 'TERMINAL_RECONNECT_SYNC', 'TERMINAL_DAEMON', {
    terminalId: terminal.id,
    syncedTxs: offlineCount,
    syncedVolume: offlineVolume,
  });

  res.json({
    success: true,
    message: `Terminal ${terminal.id} reconnected. Successfully uploaded & reconciled ${offlineCount} offline transactions (£${offlineVolume.toFixed(2)}).`,
    terminal,
  });
});

/**
 * GET /v1/ledger/accounts
 */
apiRouter.get('/v1/ledger/accounts', (req, res) => {
  res.json(globalLedgerEngine.getAllAccounts());
});

/**
 * GET /v1/ledger/entries
 */
apiRouter.get('/v1/ledger/entries', (req, res) => {
  res.json(globalLedgerEngine.getAllEntries().reverse());
});

/**
 * POST /v1/ledger/adjustments
 * Four-Eyes Manual Ledger Adjustment via Compensating Ledger Entry
 */
apiRouter.post('/v1/ledger/adjustments', (req, res) => {
  try {
    const { merchant_id, amount, currency = 'GBP', reason = 'Manual fee correction', operator = 'BANK_OPS_ADMIN' } = req.body;

    const merchPayAcc = globalLedgerEngine.registerMerchantAccount(merchant_id, currency as Currency);
    const feeRevAcc = globalLedgerEngine.getSystemAccount('FEE_REVENUE', currency as Currency);

    const entries = globalLedgerEngine.postTransaction(
      `ADJ-${Date.now()}`,
      `corr_adj_${Date.now()}`,
      currency as Currency,
      [{ accountId: feeRevAcc.id, amount: Number(amount), description: `Compensating debit fee reduction` }],
      [{ accountId: merchPayAcc.id, amount: Number(amount), merchantId: merchant_id, description: `Compensating credit merchant payable` }],
      'FourEyesManualLedgerAdjustment'
    );

    dbStore.recordAudit('LEDGER', 'FOUR_EYES_MANUAL_ADJUSTMENT', operator, { merchant_id, amount, reason });

    res.json({ success: true, message: 'Compensating double-entry ledger adjustment posted.', entries });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /v1/settlements
 */
apiRouter.get('/v1/settlements', (req, res) => {
  res.json({
    batches: globalSettlementEngine.getAllBatches(),
    payouts: globalSettlementEngine.getAllPayouts(),
  });
});

/**
 * POST /v1/settlements/batch
 */
apiRouter.post('/v1/settlements/batch', (req, res) => {
  const { merchant_id = 'merch_coffee_01', currency = 'GBP' } = req.body;
  const result = globalSettlementEngine.generateSettlementBatch({
    merchantId: merchant_id,
    currency: currency as Currency,
    transactions: Array.from(dbStore.transactions.values()),
  });

  dbStore.recordAudit('SETTLEMENT', 'EXECUTE_SETTLEMENT_BATCH', 'TREASURY_ENGINE', { merchant_id, batchId: result.batch.id });

  res.json(result);
});

/**
 * GET /v1/reconciliation/run
 */
apiRouter.get('/v1/reconciliation/run', (req, res) => {
  const { merchant_id = 'merch_coffee_01' } = req.query;
  const run = globalReconciliationEngine.executeReconciliationRun(
    merchant_id as string,
    Array.from(dbStore.transactions.values()),
    globalSettlementEngine.getBatchesForMerchant(merchant_id as string)
  );

  res.json(run);
});

/**
 * POST /v1/reconciliation/resolve
 */
apiRouter.post('/v1/reconciliation/resolve', (req, res) => {
  const { item_id, run_id, resolution_reason = 'Verified manual clearing matching' } = req.body;
  const resolved = globalReconciliationEngine.resolveException(item_id, run_id, resolution_reason);
  res.json({ success: true, item: resolved });
});

/**
 * GET /v1/disputes
 */
apiRouter.get('/v1/disputes', (req, res) => {
  res.json(Array.from(dbStore.disputes.values()));
});

/**
 * POST /v1/disputes
 */
apiRouter.post('/v1/disputes', (req, res) => {
  const { transaction_id, reason = 'Unrecognised charge by cardholder' } = req.body;
  const tx = dbStore.transactions.get(transaction_id);

  if (!tx) return res.status(404).json({ error: 'TRANSACTION_NOT_FOUND' });

  const disputeId = `DSP-${Date.now()}`;
  const dispute: Dispute = {
    id: disputeId,
    dispute_reference: `CB-${Math.floor(100000 + Math.random() * 900000)}`,
    merchant_id: tx.merchant_id,
    transaction_id: tx.id,
    amount: tx.amount,
    currency: tx.currency,
    reason,
    reason_code: '10.4_FRAUDULENT_TRANSACTION',
    status: 'OPEN',
    evidence_due_date: new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0],
    evidence_submitted: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  tx.status = 'DISPUTED';
  dbStore.disputes.set(disputeId, dispute);

  dbStore.recordAudit('FRAUD', 'OPEN_DISPUTE_CHARGEBACK', 'SCHEME_SIMULATOR', { disputeId, txId: tx.id });

  res.json(dispute);
});

/**
 * POST /v1/payment-links
 */
apiRouter.post('/v1/payment-links', (req, res) => {
  const { merchant_id = 'merch_coffee_01', title = 'Invoice Payment Link', amount = 150.0, currency = 'GBP' } = req.body;
  const id = `pl_${Date.now()}`;
  const link: PaymentLink = {
    id,
    merchant_id,
    title,
    amount: Number(amount),
    currency: currency as Currency,
    url: `${req.protocol}://${req.get('host')}/checkout?link_id=${id}`,
    status: 'ACTIVE',
    expires_at: new Date(Date.now() + 86400000 * 7).toISOString(),
    created_at: new Date().toISOString(),
  };
  dbStore.paymentLinks.set(id, link);
  res.json(link);
});

/**
 * POST /v1/invoices
 */
apiRouter.post('/v1/invoices', (req, res) => {
  const { merchant_id = 'merch_tech_02', customer_name, customer_email, amount = 500.0, currency = 'USD' } = req.body;
  const id = `inv_${Date.now()}`;
  const tax = Math.round(Number(amount) * 0.2 * 100) / 100;
  const invoice: Invoice = {
    id,
    invoice_number: `RH-INV-${Math.floor(1000 + Math.random() * 9000)}`,
    merchant_id,
    customer_name: customer_name || 'Acme Global Corp',
    customer_email: customer_email || 'billing@acmeglobal.com',
    amount: Number(amount),
    tax_amount: tax,
    discount_amount: 0,
    total_amount: Number(amount) + tax,
    currency: currency as Currency,
    status: 'SENT',
    due_date: new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0],
    created_at: new Date().toISOString(),
  };
  dbStore.invoices.set(id, invoice);
  res.json(invoice);
});

/**
 * POST /v1/subscriptions
 */
apiRouter.post('/v1/subscriptions', (req, res) => {
  const { merchant_id = 'merch_tech_02', customer_name = 'Enterprise Client', amount = 299.0, currency = 'USD', cycle = 'MONTHLY' } = req.body;

  const token = globalTokenVault.tokenizeCard({
    merchantId: merchant_id,
    pan: '4000001234564242',
    expMonth: 12,
    expYear: 2029,
    cvv: '999',
    cardholderName: customer_name,
  });

  const id = `sub_${Date.now()}`;
  const sub: Subscription = {
    id,
    subscription_code: `RH-SUB-${Math.floor(1000 + Math.random() * 9000)}`,
    merchant_id,
    customer_id: 'cust_001',
    customer_name,
    plan_name: 'Apex Enterprise SaaS Plan',
    amount: Number(amount),
    currency: currency as Currency,
    billing_cycle: cycle,
    status: 'ACTIVE',
    next_billing_date: new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0],
    payment_token_id: token.id,
    retry_count: 0,
    created_at: new Date().toISOString(),
  };

  dbStore.subscriptions.set(id, sub);
  res.json(sub);
});

/**
 * GET /v1/fraud/rules
 */
apiRouter.get('/v1/fraud/rules', (req, res) => {
  res.json(globalFraudEngine.getRules());
});

/**
 * POST /v1/fraud/rules
 */
apiRouter.post('/v1/fraud/rules', (req, res) => {
  const rule: FraudRule = req.body;
  globalFraudEngine.addOrUpdateRule(rule);
  res.json({ success: true, rules: globalFraudEngine.getRules() });
});

/**
 * POST /v1/network/toggle-health
 * Failover chaos testing trigger
 */
apiRouter.post('/v1/network/toggle-health', (req, res) => {
  const { route_id, health } = req.body;
  globalRoutingEngine.setRouteHealth(route_id, health);
  dbStore.recordAudit('SYSTEM', 'TOGGLE_NETWORK_HEALTH', 'SRE_CHAOS_ENGINE', { route_id, health });
  res.json({ success: true, routes: globalRoutingEngine.getRoutes() });
});

/**
 * POST /v1/ai/query
 */
apiRouter.post('/v1/ai/query', async (req, res) => {
  try {
    const { prompt } = req.body;
    const result = await globalAIIntelligence.queryIntelligence(prompt || 'What is our current approval rate and risk exposure?', {
      transactions: Array.from(dbStore.transactions.values()),
      merchantsCount: dbStore.merchants.size,
      activeTerminals: dbStore.terminals.size,
    });
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /v1/audit
 */
apiRouter.get('/v1/audit', (req, res) => {
  res.json(dbStore.auditLogs);
});

/**
 * POST /v1/demos/run-scenario/:id
 * Master Scenario Execution Endpoint (1 to 15)
 */
apiRouter.post('/v1/demos/run-scenario/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { runMasterScenario } = await import('./demoRunner');
    const result = await runMasterScenario(id);
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /v1/tests/run
 * System Unit & Integration Test Execution
 */
apiRouter.get('/v1/tests/run', async (req, res) => {
  try {
    const { runFullSystemTests } = await import('./testRunner');
    const testReport = runFullSystemTests();
    res.json(testReport);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});
