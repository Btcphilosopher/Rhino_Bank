/**
 * RHINO MERCHANT NETWORK - Payment Orchestration Routing Engine
 * Dynamic multi-acquirer and multi-network route selection.
 * Optimizes: Expected Approval Rate - Processing Cost - Latency Penalty - Risk Cost.
 * Detects provider health degradation and executes automatic transparent failovers.
 */

import { Currency, EntryMode } from '../types/rhino';

export interface RouteOption {
  route_id: string;
  provider_name: string;
  type: 'ACQUIRER' | 'NETWORK' | 'WALLET';
  health_status: 'HEALTHY' | 'DEGRADED' | 'DOWN';
  cost_bps: number; // Basis points (e.g. 15 = 0.15%)
  fixed_fee: number;
  historical_approval_rate: number;
  average_latency_ms: number;
}

export class PaymentRoutingEngine {
  private routes: Map<string, RouteOption> = new Map();

  constructor() {
    this.seedRoutes();
  }

  private seedRoutes() {
    const routeList: RouteOption[] = [
      {
        route_id: 'ACQUIRER_A',
        provider_name: 'Rhino Global Acquiring Services Alpha',
        type: 'ACQUIRER',
        health_status: 'HEALTHY',
        cost_bps: 12,
        fixed_fee: 0.05,
        historical_approval_rate: 0.985,
        average_latency_ms: 140,
      },
      {
        route_id: 'ACQUIRER_B',
        provider_name: 'Rhino Secondary European Acquirer Beta',
        type: 'ACQUIRER',
        health_status: 'HEALTHY',
        cost_bps: 18,
        fixed_fee: 0.08,
        historical_approval_rate: 0.972,
        average_latency_ms: 190,
      },
      {
        route_id: 'NETWORK_A',
        provider_name: 'Rhino Direct Scheme Network A',
        type: 'NETWORK',
        health_status: 'HEALTHY',
        cost_bps: 10,
        fixed_fee: 0.04,
        historical_approval_rate: 0.989,
        average_latency_ms: 110,
      },
      {
        route_id: 'NETWORK_B',
        provider_name: 'Rhino Backup Scheme Network B',
        type: 'NETWORK',
        health_status: 'HEALTHY',
        cost_bps: 22,
        fixed_fee: 0.1,
        historical_approval_rate: 0.965,
        average_latency_ms: 220,
      },
      {
        route_id: 'WALLET_A',
        provider_name: 'Rhino Express Digital Wallet Switch',
        type: 'WALLET',
        health_status: 'HEALTHY',
        cost_bps: 8,
        fixed_fee: 0.02,
        historical_approval_rate: 0.992,
        average_latency_ms: 85,
      },
    ];

    for (const r of routeList) {
      this.routes.set(r.route_id, r);
    }
  }

  public getRoutes(): RouteOption[] {
    return Array.from(this.routes.values());
  }

  public setRouteHealth(routeId: string, health: 'HEALTHY' | 'DEGRADED' | 'DOWN'): void {
    const route = this.routes.get(routeId);
    if (route) {
      route.health_status = health;
      this.routes.set(routeId, route);
    }
  }

  /**
   * Determine optimal route for transaction with mathematical objective optimization
   */
  public selectRoute(params: {
    amount: number;
    currency: Currency;
    country: string;
    entryMode: EntryMode;
    riskScore: number;
    forceRoute?: string;
  }): { selectedRoute: RouteOption; score: number; fallbackRoute?: RouteOption; isRerouted: boolean } {
    if (params.forceRoute && this.routes.has(params.forceRoute)) {
      const forced = this.routes.get(params.forceRoute)!;
      if (forced.health_status !== 'DOWN') {
        return { selectedRoute: forced, score: 100, isRerouted: false };
      }
    }

    const available = Array.from(this.routes.values()).filter((r) => r.health_status !== 'DOWN');

    if (available.length === 0) {
      throw new Error('NO_HEALTHY_ROUTE_AVAILABLE: All payment routing networks are offline.');
    }

    // Score candidates: Maximize (ApprovalRate * 100) - (CostBps * 0.5) - (LatencyMs / 50) - (HealthPenalty)
    let bestRoute: RouteOption | null = null;
    let bestScore = -Infinity;
    let fallbackRoute: RouteOption | undefined = undefined;

    for (const route of available) {
      let healthMultiplier = 1.0;
      if (route.health_status === 'DEGRADED') healthMultiplier = 0.4;

      const expectedApproval = route.historical_approval_rate * healthMultiplier;
      const processingCost = (params.amount * (route.cost_bps / 10000) + route.fixed_fee) / params.amount;
      const latencyPenalty = route.average_latency_ms / 1000;

      const score = expectedApproval * 100 - processingCost * 20 - latencyPenalty * 10;

      if (score > bestScore) {
        if (bestRoute) fallbackRoute = bestRoute;
        bestScore = score;
        bestRoute = route;
      } else if (!fallbackRoute) {
        fallbackRoute = route;
      }
    }

    const isRerouted = params.forceRoute ? params.forceRoute !== bestRoute!.route_id : false;

    return {
      selectedRoute: bestRoute!,
      score: Math.round(bestScore * 10) / 10,
      fallbackRoute,
      isRerouted,
    };
  }
}

export const globalRoutingEngine = new PaymentRoutingEngine();
