/**
 * RHINO MERCHANT NETWORK - Real Synthetic Fraud & Risk Rule Engine
 * Multi-layer transaction velocity analysis, country/IP anomaly scoring,
 * versioned rule evaluation & explainable machine learning decision traceability.
 */

import { EntryMode, FraudDecision, FraudDecisionType, FraudRule, Transaction } from '../types/rhino';

export class FraudEngineService {
  private rules: FraudRule[] = [];
  private velocityTracker: Map<string, { timestamps: number[]; amounts: number[] }> = new Map();

  constructor() {
    this.seedDefaultRules();
  }

  private seedDefaultRules() {
    this.rules = [
      {
        id: 'RULE-101',
        name: 'High Transaction Velocity (>3 in 60s)',
        description: 'Detects rapid repeated authorizations on same card/device',
        version: 'v2.4.0',
        condition_expr: 'velocity_60s > 3',
        score_modifier: 45,
        action: 'ADD_SCORE',
        active: true,
      },
      {
        id: 'RULE-102',
        name: 'Unusual Large Amount (>£3,000)',
        description: 'Triggers 3DS authentication challenge for high value ticket',
        version: 'v2.4.0',
        condition_expr: 'amount > 3000',
        score_modifier: 35,
        action: 'CHALLENGE',
        active: true,
      },
      {
        id: 'RULE-103',
        name: 'Cross-Border Country Anomaly',
        description: 'Issuer country mismatch with merchant processing country',
        version: 'v2.4.0',
        condition_expr: 'issuer_country != merchant_country',
        score_modifier: 25,
        action: 'ADD_SCORE',
        active: true,
      },
      {
        id: 'RULE-104',
        name: 'High-Risk MCC / Merchant Tier',
        description: 'Increases scrutiny for high chargeback risk industries',
        version: 'v2.4.0',
        condition_expr: 'merchant_risk_score > 70',
        score_modifier: 20,
        action: 'ADD_SCORE',
        active: true,
      },
      {
        id: 'RULE-105',
        name: 'Known Fraud / Stolen Card Test BIN',
        description: 'Immediate decline for flagged synthetic test stolen credentials',
        version: 'v2.4.0',
        condition_expr: 'bin == "400002"',
        score_modifier: 100,
        action: 'DECLINE',
        active: true,
      },
    ];
  }

  public getRules(): FraudRule[] {
    return this.rules;
  }

  public addOrUpdateRule(rule: FraudRule): void {
    const idx = this.rules.findIndex((r) => r.id === rule.id);
    if (idx >= 0) {
      this.rules[idx] = rule;
    } else {
      this.rules.push(rule);
    }
  }

  /**
   * Evaluate transaction against fraud engine & versioned rules
   */
  public evaluateTransaction(params: {
    transactionId: string;
    amount: number;
    currency: string;
    merchantId: string;
    merchantCountry: string;
    merchantRiskScore: number;
    bin?: string;
    issuerCountry?: string;
    entryMode: EntryMode;
    cardholderName?: string;
    cardLast4?: string;
  }): FraudDecision {
    const now = Date.now();
    const trackerKey = `${params.merchantId}_${params.bin || 'anon'}_${params.cardLast4 || '4242'}`;
    const history = this.velocityTracker.get(trackerKey) || { timestamps: [], amounts: [] };

    // Prune history > 300 seconds
    const validIndices = history.timestamps.map((t, i) => (now - t <= 300000 ? i : -1)).filter((i) => i !== -1);
    history.timestamps = validIndices.map((i) => history.timestamps[i]);
    history.amounts = validIndices.map((i) => history.amounts[i]);

    // Record current
    history.timestamps.push(now);
    history.amounts.push(params.amount);
    this.velocityTracker.set(trackerKey, history);

    // Calculate features
    const velocity60s = history.timestamps.filter((t) => now - t <= 60000).length;
    const issuerCountry = params.issuerCountry || 'GBR';
    const bin = params.bin || '400000';

    let totalScore = 0;
    const triggeredRules: string[] = [];
    let overrideDecision: FraudDecisionType | null = null;

    // Evaluate active rules
    for (const rule of this.rules) {
      if (!rule.active) continue;

      let triggered = false;
      if (rule.condition_expr.includes('velocity_60s > 3') && velocity60s > 3) triggered = true;
      if (rule.condition_expr.includes('amount > 3000') && params.amount > 3000) triggered = true;
      if (rule.condition_expr.includes('issuer_country != merchant_country') && issuerCountry !== params.merchantCountry)
        triggered = true;
      if (rule.condition_expr.includes('merchant_risk_score > 70') && params.merchantRiskScore > 70) triggered = true;
      if (rule.condition_expr.includes('bin == "400002"') && bin === '400002') triggered = true;

      if (triggered) {
        triggeredRules.push(`${rule.id}: ${rule.name}`);
        totalScore += rule.score_modifier;
        if (rule.action === 'DECLINE') overrideDecision = 'DECLINE';
        else if (rule.action === 'CHALLENGE' && overrideDecision !== 'DECLINE') overrideDecision = 'CHALLENGE';
        else if (rule.action === 'REVIEW' && !overrideDecision) overrideDecision = 'REVIEW';
      }
    }

    // Final Decision threshold assignment
    let decision: FraudDecisionType = 'ALLOW';
    if (overrideDecision) {
      decision = overrideDecision;
    } else if (totalScore >= 80) {
      decision = 'DECLINE';
    } else if (totalScore >= 50) {
      decision = 'CHALLENGE';
    } else if (totalScore >= 30) {
      decision = 'REVIEW';
    }

    const recommendationMap: Record<FraudDecisionType, string> = {
      ALLOW: 'Transaction within safe risk parameters. Proceed with authorization.',
      CHALLENGE: '3DS / Biometric authentication required to verify cardholder identity.',
      REVIEW: 'Flagged for manual fraud operations review due to moderate velocity or score.',
      DECLINE: 'High probability of fraud. Immediate authorization block.',
    };

    const decisionObj: FraudDecision = {
      id: `DEC-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      transaction_id: params.transactionId,
      risk_score: Math.min(100, totalScore),
      decision,
      rules_triggered: triggeredRules,
      recommendation: recommendationMap[decision],
      model_id: 'RHINO-ML-FRAUD-PROD-V3',
      model_version: '3.7.1-gradient-boost',
      features_hash: `sha256_${Math.random().toString(36).substring(2, 10)}`,
      evaluated_at: new Date().toISOString(),
    };

    return decisionObj;
  }
}

export const globalFraudEngine = new FraudEngineService();
