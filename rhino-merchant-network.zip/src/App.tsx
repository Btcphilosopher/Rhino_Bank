/**
 * RHINO MERCHANT NETWORK - Main Application Shell
 */

import React, { useState } from 'react';
import { Header, NavTab } from './components/Header';
import { BankControlCentre } from './components/BankControlCentre';
import { MerchantPortal } from './components/MerchantPortal';
import { TerminalSimulator } from './components/TerminalSimulator';
import { CheckoutSimulator } from './components/CheckoutSimulator';
import { ScenarioSuite } from './components/ScenarioSuite';
import { SpecsViewer } from './components/SpecsViewer';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('BANK_CONTROL');

  return (
    <div className="min-h-screen bg-[#0b0e11] text-[#c9d1d9] flex flex-col font-sans selection:bg-[#38d39f] selection:text-black">
      {/* Header Bar */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} systemHealth="ONLINE (mTLS 1.3)" />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6">
        {activeTab === 'BANK_CONTROL' && <BankControlCentre />}
        {activeTab === 'MERCHANT_PORTAL' && <MerchantPortal />}
        {activeTab === 'TERMINAL_SIM' && <TerminalSimulator />}
        {activeTab === 'CHECKOUT_SIM' && <CheckoutSimulator />}
        {activeTab === 'SCENARIO_SUITE' && <ScenarioSuite />}
        {activeTab === 'SPECS_DOCS' && <SpecsViewer />}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-[#21262d] bg-[#0d1117] px-6 py-4 mt-8 font-mono text-[11px] text-[#8b949e]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex items-center space-x-2">
            <span className="text-[#38d39f] font-bold">RHINO BANK PLC</span>
            <span>|</span>
            <span>MERCHANT ACQUIRING & COMMERCE INFRASTRUCTURE</span>
          </div>
          <div>
            <span>PCI-DSS LEVEL 1 CERTIFIED | DOUBLE-ENTRY LEDGER ENGINE v3.7</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
