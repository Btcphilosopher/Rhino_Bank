/**
 * RHINO MERCHANT NETWORK - Domain Models & Canonical Data Architecture
 * Rhino Bank Institutional Payments Infrastructure
 */

export type Currency = 'GBP' | 'USD' | 'EUR' | 'CHF' | 'JPY' | 'CAD' | 'AUD' | 'SGD' | 'HKD';

export type OnboardingStatus =
  | 'APPLICATION'
  | 'DOCUMENTS_REQUIRED'
  | 'UNDER_REVIEW'
  | 'KYC_PENDING'
  | 'KYB_PENDING'
  | 'RISK_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'SUSPENDED'
  | 'CLOSED';

export type RiskTier = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type PaymentIntentStatus =
  | 'CREATED'
  | 'REQUIRES_PAYMENT_METHOD'
  | 'REQUIRES_ACTION'
  | 'PROCESSING'
  | 'AUTHORISED'
  | 'CAPTURED'
  | 'PARTIALLY_CAPTURED'
  | 'CANCELLED'
  | 'FAILED'
  | 'EXPIRED';

export type TransactionStatus =
  | 'INITIATED'
  | 'VALIDATED'
  | 'ROUTED'
  | 'RISK_CHECKED'
  | 'AUTH_REQUESTED'
  | 'AUTH_RESPONSE'
  | 'AUTHORISED'
  | 'DECLINED'
  | 'CAPTURE_REQUESTED'
  | 'CAPTURED'
  | 'CLEARED'
  | 'SETTLED'
  | 'RECONCILED'
  | 'REFUNDED'
  | 'PARTIALLY_REFUNDED'
  | 'REVERSED'
  | 'DISPUTED';

export type EntryMode =
  | 'CONTACTLESS'
  | 'CHIP'
  | 'MAGSTRIPE_SIMULATION'
  | 'MANUAL_ENTRY'
  | 'ECOMMERCE'
  | 'MOTO'
  | 'RECURRING'
  | 'CARD_ON_FILE'
  | 'PAYMENT_LINK'
  | 'INVOICE'
  | 'MOBILE_WALLET';

export type FraudDecisionType = 'ALLOW' | 'CHALLENGE' | 'REVIEW' | 'DECLINE';

export type TokenStatus = 'ACTIVE' | 'SUSPENDED' | 'EXPIRED' | 'REVOKED' | 'REPLACED';

export type DisputeStatus =
  | 'OPEN'
  | 'RECEIVED'
  | 'UNDER_REVIEW'
  | 'EVIDENCE_REQUIRED'
  | 'EVIDENCE_SUBMITTED'
  | 'WON'
  | 'LOST'
  | 'ACCEPTED'
  | 'CLOSED';

export type PayoutStatus =
  | 'CREATED'
  | 'APPROVED'
  | 'SUBMITTED'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'FAILED'
  | 'RETURNED';

export type ReconciliationStatus = 'UNMATCHED' | 'MATCHED' | 'PARTIAL' | 'EXCEPTION' | 'RESOLVED';

export type LedgerAccountType =
  | 'BANK_CASH'
  | 'NETWORK_RECEIVABLE'
  | 'MERCHANT_RECEIVABLE'
  | 'MERCHANT_PAYABLE'
  | 'FEE_REVENUE'
  | 'REFUND_LIABILITY'
  | 'CHARGEBACK_LIABILITY'
  | 'SETTLEMENT_CLEARING'
  | 'FX_GAIN_LOSS'
  | 'RESERVE_ACCOUNT';

export interface Bank {
  id: string;
  name: string;
  swift_code: string;
  institution_number: string;
  country: string;
}

export interface LegalEntity {
  id: string;
  legal_name: string;
  trading_name: string;
  company_number: string;
  tax_id: string;
  country: string;
  industry: string;
  website: string;
  address: {
    line1: string;
    city: string;
    postal_code: string;
    country: string;
  };
  beneficial_owners: BeneficialOwner[];
}

export interface BeneficialOwner {
  id: string;
  full_name: string;
  dob: string;
  nationality: string;
  ownership_percentage: number;
  is_pep: boolean;
}

export interface Merchant {
  id: string;
  merchant_code: string;
  legal_entity_id: string;
  legal_name: string;
  trading_name: string;
  merchant_category_code: string;
  country: string;
  industry: string;
  onboarding_status: OnboardingStatus;
  risk_tier: RiskTier;
  risk_score: number;
  settlement_currency: Currency;
  expected_monthly_volume: number;
  average_transaction_value: number;
  max_transaction_value: number;
  sales_channels: string[];
  created_at: string;
  updated_at: string;
}

export interface Store {
  id: string;
  merchant_id: string;
  store_code: string;
  name: string;
  address: string;
  city: string;
  country: string;
  created_at: string;
}

export interface Terminal {
  id: string;
  terminal_id: string;
  merchant_id: string;
  store_id: string;
  model: string;
  serial_number: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'OFFLINE' | 'MAINTENANCE';
  battery_level: number;
  firmware_version: string;
  ip_address: string;
  last_seen_at: string;
  offline_transactions_count: number;
  offline_volume: number;
  public_key_fingerprint: string;
}

export interface Customer {
  id: string;
  merchant_id: string;
  email: string;
  name: string;
  phone?: string;
  risk_score: number;
  created_at: string;
}

export interface PaymentToken {
  id: string;
  token_vault_id: string;
  merchant_id: string;
  customer_id?: string;
  token: string;
  token_status: TokenStatus;
  card_brand: string;
  last4: string;
  exp_month: number;
  exp_year: number;
  cardholder_name: string;
  issuer_country: string;
  bin: string;
  cryptogram?: string;
  created_at: string;
}

export interface PaymentIntent {
  id: string;
  merchant_id: string;
  store_id?: string;
  terminal_id?: string;
  customer_id?: string;
  amount: number;
  currency: Currency;
  description: string;
  status: PaymentIntentStatus;
  capture_method: 'AUTOMATIC' | 'MANUAL';
  payment_method_type: string;
  token_id?: string;
  metadata: Record<string, any>;
  expires_at: string;
  created_at: string;
  updated_at: string;
}

export interface TransactionAttempt {
  id: string;
  transaction_id: string;
  attempt_number: number;
  route_selected: string;
  network_reference?: string;
  authorisation_code?: string;
  response_code: string;
  response_message: string;
  latency_ms: number;
  success: boolean;
  timestamp: string;
}

export interface Transaction {
  id: string;
  rhino_reference: string;
  merchant_id: string;
  store_id?: string;
  terminal_id?: string;
  customer_id?: string;
  payment_intent_id?: string;
  token_id?: string;
  amount: number;
  captured_amount: number;
  refunded_amount: number;
  currency: Currency;
  entry_mode: EntryMode;
  status: TransactionStatus;
  payment_method: string;
  route_used: string;
  original_route_attempted?: string;
  is_rerouted: boolean;
  authorisation_code?: string;
  network_reference?: string;
  issuer_reference?: string;
  risk_score: number;
  risk_decision: FraudDecisionType;
  risk_reasons: string[];
  fee_amount: number;
  net_amount: number;
  cleared: boolean;
  settled: boolean;
  is_offline: boolean;
  idempotency_key?: string;
  created_at: string;
  updated_at: string;
  attempts: TransactionAttempt[];
}

export interface FraudRule {
  id: string;
  name: string;
  description: string;
  version: string;
  condition_expr: string;
  score_modifier: number;
  action: FraudDecisionType | 'ADD_SCORE';
  active: boolean;
}

export interface FraudDecision {
  id: string;
  transaction_id: string;
  risk_score: number;
  decision: FraudDecisionType;
  rules_triggered: string[];
  recommendation: string;
  model_id: string;
  model_version: string;
  features_hash: string;
  evaluated_at: string;
}

export interface Dispute {
  id: string;
  dispute_reference: string;
  merchant_id: string;
  transaction_id: string;
  amount: number;
  currency: Currency;
  reason: string;
  reason_code: string;
  status: DisputeStatus;
  evidence_due_date: string;
  evidence_submitted: boolean;
  created_at: string;
  updated_at: string;
}

export interface LedgerAccount {
  id: string;
  merchant_id?: string;
  account_type: LedgerAccountType;
  currency: Currency;
  code: string;
  name: string;
  description: string;
  balance: number; // Derived from ledger entries only!
}

export interface LedgerEntry {
  id: string;
  transaction_id: string;
  correlation_id: string;
  account_id: string;
  account_type: LedgerAccountType;
  merchant_id?: string;
  direction: 'DEBIT' | 'CREDIT';
  amount: number;
  currency: Currency;
  description: string;
  source_event: string;
  created_at: string;
}

export interface SettlementBatch {
  id: string;
  batch_reference: string;
  merchant_id: string;
  currency: Currency;
  business_date: string;
  gross_amount: number;
  refund_amount: number;
  chargeback_amount: number;
  fee_amount: number;
  adjustment_amount: number;
  net_amount: number;
  status: 'OPEN' | 'PROCESSING' | 'POSTED' | 'PAID' | 'RECONCILED';
  created_at: string;
  processed_at?: string;
}

export interface Payout {
  id: string;
  payout_reference: string;
  merchant_id: string;
  settlement_batch_id: string;
  amount: number;
  currency: Currency;
  status: PayoutStatus;
  iban_last4: string;
  bank_name: string;
  scheduled_date: string;
  executed_at?: string;
  created_at: string;
}

export interface ReconciliationItem {
  id: string;
  run_id: string;
  merchant_id: string;
  transaction_id?: string;
  clearing_ref?: string;
  settlement_ref?: string;
  expected_amount: number;
  actual_amount: number;
  discrepancy_amount: number;
  currency: Currency;
  status: ReconciliationStatus;
  discrepancy_reason?: string;
  created_at: string;
}

export interface FXQuote {
  id: string;
  source_currency: Currency;
  target_currency: Currency;
  base_rate: number;
  spread: number;
  effective_rate: number;
  expires_at: string;
  provider: string;
}

export interface PaymentLink {
  id: string;
  merchant_id: string;
  title: string;
  amount: number;
  currency: Currency;
  url: string;
  status: 'ACTIVE' | 'PAID' | 'EXPIRED' | 'CANCELLED';
  expires_at: string;
  created_at: string;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  merchant_id: string;
  customer_name: string;
  customer_email: string;
  amount: number;
  tax_amount: number;
  discount_amount: number;
  total_amount: number;
  currency: Currency;
  status: 'DRAFT' | 'SENT' | 'VIEWED' | 'PARTIALLY_PAID' | 'PAID' | 'OVERDUE' | 'VOID';
  due_date: string;
  created_at: string;
}

export interface Subscription {
  id: string;
  subscription_code: string;
  merchant_id: string;
  customer_id: string;
  customer_name: string;
  plan_name: string;
  amount: number;
  currency: Currency;
  billing_cycle: 'MONTHLY' | 'QUARTERLY' | 'ANNUAL';
  status: 'ACTIVE' | 'PAUSED' | 'CANCELLED' | 'PAST_DUE';
  next_billing_date: string;
  payment_token_id: string;
  retry_count: number;
  created_at: string;
}

export interface WebhookDelivery {
  id: string;
  event_id: string;
  event_type: string;
  merchant_id: string;
  target_url: string;
  payload: any;
  signature: string;
  attempt_number: number;
  status_code: number;
  success: boolean;
  delivered_at: string;
}

export interface AuditEvent {
  id: string;
  correlation_id: string;
  operator: string;
  category: 'AUTH' | 'MERCHANT' | 'PAYMENT' | 'FRAUD' | 'LEDGER' | 'SYSTEM' | 'RECONCILIATION';
  action: string;
  details: Record<string, any>;
  ip_address: string;
  timestamp: string;
}

export interface MasterDemoResult {
  scenario_id: number;
  title: string;
  status: 'PASSED' | 'FAILED' | 'RUNNING';
  steps: {
    stage: string;
    description: string;
    payload?: any;
    status: 'SUCCESS' | 'WARN' | 'INFO' | 'ERROR';
    timestamp: string;
  }[];
  trace?: {
    merchant: string;
    amount: string;
    token_id?: string;
    intent_id?: string;
    transaction_id?: string;
    authorisation_code?: string;
    risk_score?: number;
    route?: string;
    ledger_balanced: boolean;
    settlement_id?: string;
    payout_id?: string;
  };
  duration_ms: number;
}
