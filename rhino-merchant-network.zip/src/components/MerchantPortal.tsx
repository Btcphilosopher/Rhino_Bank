/**
 * RHINO MERCHANT PORTAL - Enterprise Merchant Self-Service Console
 */

import React, { useState, useEffect } from 'react';
import { Store, CreditCard, Terminal, Link, FileText, Repeat, ShieldAlert, ArrowUpRight, Plus, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Invoice, Merchant, PaymentLink, Subscription, Transaction } from '../types/rhino';

export function MerchantPortal() {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'TRANSACTIONS' | 'LINKS' | 'INVOICES' | 'SUBS' | 'TERMINALS' | 'DISPUTES'>('OVERVIEW');
  const [selectedMerchantId, setSelectedMerchantId] = useState('merch_coffee_01');
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [paymentLinks, setPaymentLinks] = useState<PaymentLink[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [newLinkTitle, setNewLinkTitle] = useState('Consulting Services Invoice');
  const [newLinkAmount, setNewLinkAmount] = useState('150.00');

  const loadData = async () => {
    try {
      const resM = await fetch('/api/v1/merchants');
      if (resM.ok) {
        const data = await resM.json();
        setMerchants(data);
      }

      const resT = await fetch(`/api/v1/transactions?merchant_id=${selectedMerchantId}`);
      if (resT.ok) {
        setTransactions(await resT.json());
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedMerchantId]);

  const handleCreateLink = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/v1/payment-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchant_id: selectedMerchantId,
          title: newLinkTitle,
          amount: Number(newLinkAmount),
          currency: 'GBP',
        }),
      });
      if (res.ok) {
        const created = await res.json();
        setPaymentLinks((prev) => [created, ...prev]);
        setNewLinkTitle('');
        setNewLinkAmount('');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const currentMerch = merchants.find((m) => m.id === selectedMerchantId) || merchants[0];
  const todaySales = transactions.reduce((acc, t) => acc + (t.status === 'CAPTURED' || t.status === 'SETTLED' ? t.amount : 0), 0);
  const totalFees = transactions.reduce((acc, t) => acc + (t.fee_amount || 0), 0);

  return (
    <div className="space-y-6 font-mono">
      {/* Merchant Switcher Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161b22] border border-[#30363d] p-4 rounded">
        <div>
          <span className="text-[10px] text-[#8b949e] font-bold uppercase">ACTIVE MERCHANT CONSOLE</span>
          <h2 className="text-sm font-bold text-[#f0f6fc]">{currentMerch?.trading_name || 'Rhino Coffee Roasters'}</h2>
          <p className="text-xs text-[#38d39f]">MCC: {currentMerch?.merchant_category_code} | Settlement Currency: {currentMerch?.settlement_currency}</p>
        </div>

        <div className="flex items-center space-x-3">
          <span className="text-xs text-[#8b949e]">Switch Merchant:</span>
          <select
            value={selectedMerchantId}
            onChange={(e) => setSelectedMerchantId(e.target.value)}
            className="bg-[#0d1117] border border-[#30363d] rounded px-3 py-1.5 text-xs text-[#f0f6fc] focus:outline-none focus:border-[#38d39f]"
          >
            {merchants.map((m) => (
              <option key={m.id} value={m.id}>
                {m.trading_name} ({m.settlement_currency})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center space-x-2 border-b border-[#21262d] pb-2 overflow-x-auto">
        {['OVERVIEW', 'TRANSACTIONS', 'LINKS', 'INVOICES', 'SUBS', 'TERMINALS', 'DISPUTES'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`px-3 py-1.5 text-xs font-mono rounded ${
              activeTab === tab ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/40 font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-6">
          {/* Today's Sales Banner */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
              <p className="text-[11px] text-[#8b949e]">TODAY'S GROSS SALES</p>
              <p className="text-2xl font-bold text-[#f0f6fc] mt-1">{currentMerch?.settlement_currency} {todaySales.toFixed(2)}</p>
              <p className="text-[10px] text-[#38d39f] mt-1">✓ {transactions.length} Transactions</p>
            </div>
            <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
              <p className="text-[11px] text-[#8b949e]">PROCESSING FEES</p>
              <p className="text-2xl font-bold text-[#f0f6fc] mt-1">{currentMerch?.settlement_currency} {totalFees.toFixed(2)}</p>
              <p className="text-[10px] text-[#8b949e] mt-1">Avg Rate: 1.5% + £0.10</p>
            </div>
            <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
              <p className="text-[11px] text-[#8b949e]">NET SETTLEMENT</p>
              <p className="text-2xl font-bold text-[#38d39f] mt-1">
                {currentMerch?.settlement_currency} {(todaySales - totalFees).toFixed(2)}
              </p>
              <p className="text-[10px] text-[#38d39f] mt-1">Scheduled for Payout</p>
            </div>
            <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
              <p className="text-[11px] text-[#8b949e]">APPROVAL RATE</p>
              <p className="text-2xl font-bold text-[#38d39f] mt-1">98.7%</p>
              <p className="text-[10px] text-[#38d39f] mt-1">Optimal Route</p>
            </div>
          </div>

          {/* Recent Activity List */}
          <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-3">
            <h3 className="text-xs font-bold text-[#f0f6fc]">RECENT MERCHANT PAYMENTS</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#30363d] text-[#8b949e]">
                    <th className="py-2 px-3">RHINO REF</th>
                    <th className="py-2 px-3">AMOUNT</th>
                    <th className="py-2 px-3">ENTRY MODE</th>
                    <th className="py-2 px-3">FEE</th>
                    <th className="py-2 px-3">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {transactions.slice(0, 5).map((t) => (
                    <tr key={t.id}>
                      <td className="py-2 px-3 text-[#38d39f]">{t.id}</td>
                      <td className="py-2 px-3 font-bold text-[#f0f6fc]">{t.currency} {t.amount.toFixed(2)}</td>
                      <td className="py-2 px-3 text-[#8b949e]">{t.entry_mode}</td>
                      <td className="py-2 px-3 text-[#8b949e]">{t.currency} {t.fee_amount.toFixed(2)}</td>
                      <td className="py-2 px-3">
                        <span className="px-2 py-0.5 bg-[#1b382b] text-[#38d39f] rounded text-[10px] font-bold">
                          {t.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'LINKS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-4">
            <h3 className="text-xs font-bold text-[#f0f6fc]">GENERATE PAYMENT LINK</h3>
            <form onSubmit={handleCreateLink} className="space-y-3">
              <div>
                <label className="text-[11px] text-[#8b949e]">TITLE / ITEM DESCRIPTION</label>
                <input
                  type="text"
                  value={newLinkTitle}
                  onChange={(e) => setNewLinkTitle(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] text-[#8b949e]">AMOUNT ({currentMerch?.settlement_currency})</label>
                <input
                  type="number"
                  step="0.01"
                  value={newLinkAmount}
                  onChange={(e) => setNewLinkAmount(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-2 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-xs hover:bg-[#234d3a]"
              >
                + Generate Secure Payment Link
              </button>
            </form>
          </div>

          <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-3">
            <h3 className="text-xs font-bold text-[#f0f6fc]">ACTIVE PAYMENT LINKS</h3>
            <div className="space-y-2">
              {paymentLinks.map((pl) => (
                <div key={pl.id} className="p-3 bg-[#0d1117] border border-[#30363d] rounded space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-[#f0f6fc]">{pl.title}</span>
                    <span className="text-xs font-bold text-[#38d39f]">{pl.currency} {pl.amount.toFixed(2)}</span>
                  </div>
                  <p className="text-[10px] text-[#8b949e] truncate">{pl.url}</p>
                </div>
              ))}
              {paymentLinks.length === 0 && <p className="text-xs text-[#8b949e]">No payment links generated yet.</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
