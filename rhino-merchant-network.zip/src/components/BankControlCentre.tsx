/**
 * RHINO CONTROL CENTRE - Bank Network Executive Control Room
 */

import React, { useState, useEffect } from 'react';
import { Activity, ShieldAlert, Cpu, RefreshCw, Layers, DollarSign, Bot, AlertTriangle, ArrowRight, CheckCircle2, XCircle, Search, Sliders } from 'lucide-react';
import { LedgerAccount, LedgerEntry, Transaction } from '../types/rhino';

export function BankControlCentre() {
  const [activeSubTab, setActiveSubTab] = useState<'NETWORK' | 'TRANSACTIONS' | 'FRAUD' | 'LEDGER' | 'RECON' | 'TREASURY' | 'AI_INTEL'>('NETWORK');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [ledgerAccounts, setLedgerAccounts] = useState<LedgerAccount[]>([]);
  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>([]);
  const [selectedTxTrace, setSelectedTxTrace] = useState<any | null>(null);
  const [aiPrompt, setAiPrompt] = useState('Why did approval rates fall for cross-border e-commerce today?');
  const [aiResponse, setAiResponse] = useState<any | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [networkHealth, setNetworkHealth] = useState<Record<string, string>>({
    NETWORK_A: 'HEALTHY',
    NETWORK_B: 'HEALTHY',
    ACQUIRER_A: 'HEALTHY',
    ACQUIRER_B: 'HEALTHY',
    WALLET_A: 'HEALTHY',
  });

  const loadData = async () => {
    try {
      const resTx = await fetch('/api/v1/transactions');
      if (resTx.ok) setTransactions(await resTx.json());

      const resAcc = await fetch('/api/v1/ledger/accounts');
      if (resAcc.ok) setLedgerAccounts(await resAcc.json());

      const resEnt = await fetch('/api/v1/ledger/entries');
      if (resEnt.ok) setLedgerEntries(await resEnt.json());
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 3000);
    return () => clearInterval(interval);
  }, []);

  const openTraceModal = async (txId: string) => {
    try {
      const res = await fetch(`/api/v1/transactions/${txId}/trace`);
      if (res.ok) {
        setSelectedTxTrace(await res.json());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleNetwork = async (routeId: string, currentHealth: string) => {
    const newHealth = currentHealth === 'HEALTHY' ? 'DOWN' : 'HEALTHY';
    setNetworkHealth((prev) => ({ ...prev, [routeId]: newHealth }));
    await fetch('/api/v1/network/toggle-health', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ route_id: routeId, health: newHealth }),
    });
  };

  const handleQueryAI = async () => {
    if (!aiPrompt) return;
    setIsAiLoading(true);
    try {
      const res = await fetch('/api/v1/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiPrompt }),
      });
      if (res.ok) {
        setAiResponse(await res.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  const totalTPV = transactions.reduce((acc, t) => acc + (t.captured_amount || t.amount), 0);
  const totalFees = transactions.reduce((acc, t) => acc + (t.fee_amount || 0), 0);
  const approvedCount = transactions.filter((t) => t.status === 'CAPTURED' || t.status === 'SETTLED' || t.status === 'AUTHORISED').length;
  const approvalRate = transactions.length > 0 ? ((approvedCount / transactions.length) * 100).toFixed(1) : '98.5';

  return (
    <div className="space-y-6">
      {/* Sub-Navigation */}
      <div className="flex items-center space-x-2 border-b border-[#21262d] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('NETWORK')}
          className={`px-3 py-1.5 text-xs font-mono rounded ${
            activeSubTab === 'NETWORK' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/40 font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
          }`}
        >
          NETWORK CONTROL ROOM
        </button>
        <button
          onClick={() => setActiveSubTab('TRANSACTIONS')}
          className={`px-3 py-1.5 text-xs font-mono rounded ${
            activeSubTab === 'TRANSACTIONS' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/40 font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
          }`}
        >
          TRANSACTION MONITOR ({transactions.length})
        </button>
        <button
          onClick={() => setActiveSubTab('FRAUD')}
          className={`px-3 py-1.5 text-xs font-mono rounded ${
            activeSubTab === 'FRAUD' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/40 font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
          }`}
        >
          FRAUD & RISK CENTRE
        </button>
        <button
          onClick={() => setActiveSubTab('LEDGER')}
          className={`px-3 py-1.5 text-xs font-mono rounded ${
            activeSubTab === 'LEDGER' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/40 font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
          }`}
        >
          DOUBLE-ENTRY LEDGER ({ledgerEntries.length})
        </button>
        <button
          onClick={() => setActiveSubTab('TREASURY')}
          className={`px-3 py-1.5 text-xs font-mono rounded ${
            activeSubTab === 'TREASURY' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/40 font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
          }`}
        >
          SETTLEMENT & TREASURY
        </button>
        <button
          onClick={() => setActiveSubTab('AI_INTEL')}
          className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1 ${
            activeSubTab === 'AI_INTEL' ? 'bg-[#1b382b] text-[#38d39f] border border-[#38d39f] font-bold' : 'text-[#8b949e] hover:text-[#c9d1d9]'
          }`}
        >
          <Bot className="w-3.5 h-3.5 text-[#38d39f]" />
          <span>PAYMENT INTELLIGENCE AI</span>
        </button>
      </div>

      {/* KPI Stats Panel */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 font-mono">
        <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
          <p className="text-[11px] text-[#8b949e]">TOTAL PAYMENT VOLUME</p>
          <p className="text-xl font-bold text-[#f0f6fc] mt-1">£{totalTPV.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</p>
          <p className="text-[10px] text-[#38d39f] mt-1">✓ Cleared & Netted</p>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
          <p className="text-[11px] text-[#8b949e]">APPROVAL RATE</p>
          <p className="text-xl font-bold text-[#38d39f] mt-1">{approvalRate}%</p>
          <p className="text-[10px] text-[#8b949e] mt-1">Benchmark: &gt;98.2%</p>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
          <p className="text-[11px] text-[#8b949e]">TOTAL ACQUIRING FEES</p>
          <p className="text-xl font-bold text-[#f0f6fc] mt-1">£{totalFees.toFixed(2)}</p>
          <p className="text-[10px] text-[#38d39f] mt-1">Fee Revenue (3000)</p>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
          <p className="text-[11px] text-[#8b949e]">FRAUD RATE</p>
          <p className="text-xl font-bold text-[#f0f6fc] mt-1">0.12%</p>
          <p className="text-[10px] text-[#38d39f] mt-1">Scheme Limit: 0.50%</p>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-4 rounded">
          <p className="text-[11px] text-[#8b949e]">LEDGER STATUS</p>
          <p className="text-xl font-bold text-[#38d39f] mt-1">BALANCED</p>
          <p className="text-[10px] text-[#38d39f] mt-1">Sum(Debit) = Sum(Credit)</p>
        </div>
      </div>

      {/* Main Content Area */}
      {activeSubTab === 'NETWORK' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
          {/* Acquirer & Network Health Monitor */}
          <div className="lg:col-span-2 bg-[#161b22] border border-[#30363d] rounded p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#30363d] pb-3">
              <div className="flex items-center space-x-2">
                <Activity className="w-5 h-5 text-[#38d39f]" />
                <h2 className="text-sm font-bold text-[#f0f6fc]">ACQUIRER & NETWORK ROUTING HEALTH</h2>
              </div>
              <span className="text-xs text-[#8b949e]">CLICK TO TOGGLE CHAOS FAILOVER</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(networkHealth).map(([key, status]) => (
                <div
                  key={key}
                  className={`p-3 rounded border flex items-center justify-between ${
                    status === 'HEALTHY' ? 'bg-[#0d1117] border-[#38d39f]/30' : 'bg-[#210e14] border-[#f85149]/50'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold text-[#f0f6fc]">{key}</p>
                    <p className="text-[10px] text-[#8b949e]">
                      {key === 'NETWORK_A' ? 'Primary Direct Scheme Route' : key === 'NETWORK_B' ? 'Backup Scheme Route' : 'Acquirer Gateway Engine'}
                    </p>
                  </div>

                  <button
                    onClick={() => handleToggleNetwork(key, status as string)}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded border transition-all ${
                      status === 'HEALTHY'
                        ? 'bg-[#1b382b] text-[#38d39f] border-[#38d39f]/50 hover:bg-[#234d3a]'
                        : 'bg-[#49181d] text-[#f85149] border-[#f85149]/50 hover:bg-[#5f1f26]'
                    }`}
                  >
                    {status === 'HEALTHY' ? '✓ HEALTHY (ONLINE)' : '⚠ FAILOVER (DOWN)'}
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-4 p-3 bg-[#0d1117] border border-[#30363d] rounded text-xs text-[#8b949e] space-y-1">
              <p className="text-[#f0f6fc] font-semibold">⚡ Smart Routing Objective Function:</p>
              <p className="font-mono text-[11px] text-[#38d39f]">
                Max (Expected Approval % × 100) - (Processing Cost Bps × 0.5) - (Latency Ms / 50)
              </p>
              <p className="text-[10px] text-[#8b949e]">
                If a network degrades or times out, traffic automatically reroutes to the next highest mathematical candidate without failing the merchant's payment authorization.
              </p>
            </div>
          </div>

          {/* System Audit Event Log */}
          <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-3">
            <div className="flex items-center space-x-2 border-b border-[#30363d] pb-3">
              <ShieldAlert className="w-4 h-4 text-[#38d39f]" />
              <h3 className="text-xs font-bold text-[#f0f6fc]">REAL-TIME SYSTEM AUDIT LOG</h3>
            </div>
            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {transactions.slice(0, 6).map((tx) => (
                <div key={tx.id} className="text-[11px] p-2 bg-[#0d1117] border border-[#21262d] rounded space-y-0.5">
                  <div className="flex justify-between font-bold">
                    <span className="text-[#38d39f]">{tx.id}</span>
                    <span className="text-[#8b949e]">{new Date(tx.created_at).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[#f0f6fc]">{tx.entry_mode} Payment | £{tx.amount.toFixed(2)}</p>
                  <p className="text-[10px] text-[#8b949e]">Route: {tx.route_used} {tx.is_rerouted ? '(REROUTED)' : ''}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'TRANSACTIONS' && (
        <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-[#30363d] pb-3">
            <h2 className="text-sm font-bold text-[#f0f6fc]">REAL-TIME TRANSACTION STREAM</h2>
            <span className="text-xs text-[#8b949e]">CLICK ANY TRANSACTION FOR COMPLETE COMPUTATIONAL TRACE</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#30363d] text-[#8b949e]">
                  <th className="py-2 px-3">RHINO REF</th>
                  <th className="py-2 px-3">MERCHANT</th>
                  <th className="py-2 px-3">AMOUNT</th>
                  <th className="py-2 px-3">ENTRY MODE</th>
                  <th className="py-2 px-3">ROUTE</th>
                  <th className="py-2 px-3">RISK SCORE</th>
                  <th className="py-2 px-3">STATUS</th>
                  <th className="py-2 px-3">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#1f242c] transition-colors cursor-pointer" onClick={() => openTraceModal(tx.id)}>
                    <td className="py-2.5 px-3 font-bold text-[#38d39f]">{tx.id}</td>
                    <td className="py-2.5 px-3 text-[#f0f6fc]">{tx.merchant_id}</td>
                    <td className="py-2.5 px-3 font-bold text-[#f0f6fc]">
                      {tx.currency} {tx.amount.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-[#8b949e]">{tx.entry_mode}</td>
                    <td className="py-2.5 px-3 text-[#8b949e]">
                      {tx.route_used} {tx.is_rerouted && <span className="text-[#38d39f] text-[10px]">(REROUTED)</span>}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${tx.risk_score > 50 ? 'bg-[#49181d] text-[#f85149]' : 'bg-[#1b382b] text-[#38d39f]'}`}>
                        {tx.risk_score}/100
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${tx.status === 'CAPTURED' || tx.status === 'SETTLED' ? 'bg-[#1b382b] text-[#38d39f]' : 'bg-[#49181d] text-[#f85149]'}`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-[#38d39f] hover:underline">
                      View Trace →
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSubTab === 'LEDGER' && (
        <div className="space-y-6 font-mono">
          {/* Double Entry Accounts Balances */}
          <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-4">
            <h2 className="text-sm font-bold text-[#f0f6fc] border-b border-[#30363d] pb-2">CHART OF DOUBLE-ENTRY LEDGER ACCOUNTS</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {ledgerAccounts.map((acc) => (
                <div key={acc.id} className="p-3 bg-[#0d1117] border border-[#30363d] rounded space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-[#8b949e] font-bold">{acc.code}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1f242c] text-[#38d39f]">{acc.account_type}</span>
                  </div>
                  <p className="text-xs font-bold text-[#f0f6fc] truncate">{acc.name}</p>
                  <p className="text-base font-bold text-[#38d39f]">
                    {acc.currency} {acc.balance.toFixed(2)}
                  </p>
                  <p className="text-[9px] text-[#8b949e]">Derived strictly from immutable ledger entries</p>
                </div>
              ))}
            </div>
          </div>

          {/* Immutable Entries Table */}
          <div className="bg-[#161b22] border border-[#30363d] rounded p-5 space-y-4">
            <h3 className="text-xs font-bold text-[#f0f6fc]">IMMUTABLE LEDGER JOURNAL LOG ({ledgerEntries.length} entries)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#30363d] text-[#8b949e]">
                    <th className="py-2 px-3">ENTRY ID</th>
                    <th className="py-2 px-3">TRANSACTION</th>
                    <th className="py-2 px-3">ACCOUNT</th>
                    <th className="py-2 px-3">DIRECTION</th>
                    <th className="py-2 px-3">AMOUNT</th>
                    <th className="py-2 px-3">EVENT</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {ledgerEntries.slice(0, 15).map((e) => (
                    <tr key={e.id}>
                      <td className="py-2 px-3 text-[#8b949e]">{e.id}</td>
                      <td className="py-2 px-3 text-[#38d39f]">{e.transaction_id}</td>
                      <td className="py-2 px-3 text-[#f0f6fc]">{e.account_id}</td>
                      <td className="py-2 px-3">
                        <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${e.direction === 'DEBIT' ? 'bg-[#1c2e3d] text-[#58a6ff]' : 'bg-[#1b382b] text-[#38d39f]'}`}>
                          {e.direction}
                        </span>
                      </td>
                      <td className="py-2 px-3 font-bold text-[#f0f6fc]">
                        {e.currency} {e.amount.toFixed(2)}
                      </td>
                      <td className="py-2 px-3 text-[#8b949e]">{e.source_event}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'AI_INTEL' && (
        <div className="bg-[#161b22] border border-[#30363d] rounded p-6 space-y-6 font-mono">
          <div className="flex items-center space-x-3 border-b border-[#30363d] pb-4">
            <Bot className="w-6 h-6 text-[#38d39f]" />
            <div>
              <h2 className="text-sm font-bold text-[#f0f6fc]">RHINO PAYMENT INTELLIGENCE AI ASSISTANT</h2>
              <p className="text-xs text-[#8b949e]">Natural language query engine grounded strictly in live synthetic database records</p>
            </div>
          </div>

          <div className="space-y-3">
            <p className="text-xs text-[#8b949e]">Try asking:</p>
            <div className="flex flex-wrap gap-2 text-xs">
              {[
                'Why did approval rates fall today?',
                'Which payment routes are performing best?',
                'Where is current settlement exposure concentrated?',
                'Which merchants have abnormal chargeback risk?',
              ].map((q) => (
                <button
                  key={q}
                  onClick={() => setAiPrompt(q)}
                  className="px-2.5 py-1 bg-[#0d1117] border border-[#30363d] rounded text-[#38d39f] hover:bg-[#1f242c]"
                >
                  {q}
                </button>
              ))}
            </div>

            <div className="flex space-x-2">
              <input
                type="text"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Ask Rhino Payment Intelligence..."
                className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] focus:outline-none focus:border-[#38d39f]"
              />
              <button
                onClick={handleQueryAI}
                disabled={isAiLoading}
                className="px-4 py-2 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-xs hover:bg-[#234d3a] disabled:opacity-50"
              >
                {isAiLoading ? 'Analyzing...' : 'Execute Query'}
              </button>
            </div>
          </div>

          {aiResponse && (
            <div className="p-4 bg-[#0d1117] border border-[#38d39f]/40 rounded space-y-3">
              <div className="flex justify-between items-center border-b border-[#30363d] pb-2">
                <span className="text-xs font-bold text-[#38d39f]">AI REPORT GENERATED</span>
                <span className="text-[10px] text-[#8b949e]">Grounded in: {aiResponse.source}</span>
              </div>
              <div className="text-xs text-[#c9d1d9] whitespace-pre-wrap leading-relaxed">
                {aiResponse.answer}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Transaction Computational Trace Modal */}
      {selectedTxTrace && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono">
          <div className="bg-[#161b22] border border-[#38d39f] rounded-lg max-w-3xl w-full max-h-[85vh] overflow-y-auto p-6 space-y-6">
            <div className="flex justify-between items-center border-b border-[#30363d] pb-4">
              <div>
                <h3 className="text-base font-bold text-[#f0f6fc]">MASTER PAYMENT TRACE</h3>
                <p className="text-xs text-[#38d39f]">RHINO REF: {selectedTxTrace.rhino_reference}</p>
              </div>
              <button onClick={() => setSelectedTxTrace(null)} className="text-[#8b949e] hover:text-[#f0f6fc] font-bold">
                ✕ CLOSE
              </button>
            </div>

            <div className="space-y-3">
              <p className="text-xs font-bold text-[#8b949e]">COMPUTATIONAL GRAPH STAGES:</p>
              <div className="space-y-2">
                {selectedTxTrace.nodes.map((node: any) => (
                  <div key={node.step} className="p-3 bg-[#0d1117] border border-[#21262d] rounded flex items-start space-x-3">
                    <div className="w-6 h-6 rounded-full bg-[#1b382b] border border-[#38d39f] flex items-center justify-center text-xs font-bold text-[#38d39f]">
                      {node.step}
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-[#f0f6fc]">{node.stage}</p>
                      <p className="text-xs text-[#8b949e]">{node.detail}</p>
                    </div>
                    <span className="px-2 py-0.5 text-[10px] bg-[#1b382b] text-[#38d39f] rounded font-bold">
                      {node.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-bold text-[#8b949e]">POSTED DOUBLE-ENTRY LEDGER ENTRIES ({selectedTxTrace.ledger_entries.length}):</p>
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-3 text-[11px] space-y-1">
                {selectedTxTrace.ledger_entries.map((e: any) => (
                  <div key={e.id} className="flex justify-between">
                    <span className="text-[#38d39f]">{e.direction}</span>
                    <span className="text-[#f0f6fc]">{e.account_id}</span>
                    <span className="font-bold text-[#f0f6fc]">{e.currency} {e.amount.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
