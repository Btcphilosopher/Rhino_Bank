/**
 * RHINO TERMINAL SIMULATOR - Hardware POS Terminal Device Protocol Simulator
 * Real-time NFC/Contactless tap, Chip Insert, Pin pad, Offline queueing, & Backend Authorization
 */

import React, { useState } from 'react';
import { Wifi, WifiOff, Battery, CreditCard, Radio, CheckCircle2, XCircle, RefreshCw } from 'lucide-react';

export function TerminalSimulator() {
  const [amount, setAmount] = useState('24.50');
  const [terminalState, setTerminalState] = useState<'READY' | 'TAP_CARD' | 'PROCESSING' | 'APPROVED' | 'DECLINED' | 'ERROR'>('READY');
  const [offlineMode, setOfflineMode] = useState(false);
  const [lastTxResponse, setLastTxResponse] = useState<any | null>(null);

  const handleKeyPress = (digit: string) => {
    if (digit === 'C') {
      setAmount('0.00');
    } else if (digit === 'DEL') {
      setAmount((prev) => (prev.length > 1 ? prev.slice(0, -1) : '0.00'));
    } else {
      setAmount((prev) => (prev === '0.00' || prev === '' ? digit : prev + digit));
    }
  };

  const handleStartPayment = () => {
    if (Number(amount) <= 0) return;
    setTerminalState('TAP_CARD');
  };

  const handleSimulateTap = async (entryMode: 'CONTACTLESS' | 'CHIP' | 'MOBILE_WALLET') => {
    setTerminalState('PROCESSING');
    try {
      const res = await fetch('/api/v1/transactions/process', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': `terminal_ik_${Date.now()}`,
        },
        body: JSON.stringify({
          merchant_id: 'merch_coffee_01',
          terminal_id: 'RH-T001',
          amount: Number(amount),
          currency: 'GBP',
          entry_mode: entryMode,
          pan: '4000001234564242',
          exp_month: 12,
          exp_year: 2028,
          cvv: '123',
          cardholder_name: 'ALEX TAYLOR',
          simulate_offline: offlineMode,
        }),
      });

      const data = await res.json();
      setLastTxResponse(data);

      if (data.approved) {
        setTerminalState('APPROVED');
      } else {
        setTerminalState('DECLINED');
      }
    } catch (e) {
      setTerminalState('ERROR');
    }
  };

  const handleReconnectSync = async () => {
    try {
      await fetch('/api/v1/terminals/RH-T001/offline-sync', { method: 'POST' });
      setOfflineMode(false);
      alert('Terminal reconnected. Offline queued transactions uploaded and reconciled!');
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 font-mono">
      {/* Terminal Hardware Enclosure */}
      <div className="bg-[#151a21] border-2 border-[#30363d] rounded-2xl p-6 shadow-2xl space-y-6">
        {/* Top Status Bar */}
        <div className="flex items-center justify-between text-xs text-[#8b949e] border-b border-[#21262d] pb-3">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-[#f0f6fc]">RH-T001</span>
            <span className="text-[10px] px-1.5 py-0.5 bg-[#1b382b] text-[#38d39f] rounded font-bold">POS-5000</span>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setOfflineMode(!offlineMode)}
              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                offlineMode ? 'bg-[#49181d] text-[#f85149]' : 'bg-[#1b382b] text-[#38d39f]'
              }`}
            >
              {offlineMode ? <WifiOff className="w-3 h-3" /> : <Wifi className="w-3 h-3" />}
              <span>{offlineMode ? 'OFFLINE MODE' : 'ONLINE (mTLS)'}</span>
            </button>

            <div className="flex items-center space-x-1">
              <Battery className="w-3.5 h-3.5 text-[#38d39f]" />
              <span>98%</span>
            </div>
          </div>
        </div>

        {/* High-Contrast Financial LCD Display Screen */}
        <div className="bg-[#090d12] border-2 border-[#38d39f]/40 rounded-xl p-6 text-center space-y-4 shadow-inner min-h-[220px] flex flex-col justify-center items-center">
          <p className="text-[11px] font-bold text-[#8b949e] uppercase tracking-widest">RHINO PAYMENTS</p>

          {terminalState === 'READY' && (
            <div className="space-y-2">
              <p className="text-3xl font-extrabold text-[#38d39f] tracking-wider">£{amount}</p>
              <p className="text-xs text-[#8b949e]">ENTER AMOUNT & PRESS CHARGE</p>
            </div>
          )}

          {terminalState === 'TAP_CARD' && (
            <div className="space-y-3 animate-pulse">
              <Radio className="w-10 h-10 text-[#38d39f] mx-auto" />
              <p className="text-2xl font-bold text-[#f0f6fc]">£{amount}</p>
              <p className="text-xs text-[#38d39f]">TAP CARD / INSERT CHIP / PHONE</p>
            </div>
          )}

          {terminalState === 'PROCESSING' && (
            <div className="space-y-2">
              <RefreshCw className="w-8 h-8 text-[#38d39f] animate-spin mx-auto" />
              <p className="text-sm font-bold text-[#f0f6fc]">AUTHORISING WITH RHINO BANK...</p>
              <p className="text-[10px] text-[#8b949e]">EMV Cryptogram Verification</p>
            </div>
          )}

          {terminalState === 'APPROVED' && (
            <div className="space-y-2">
              <CheckCircle2 className="w-10 h-10 text-[#38d39f] mx-auto" />
              <p className="text-xl font-bold text-[#38d39f]">APPROVED - £{amount}</p>
              <p className="text-xs text-[#f0f6fc]">RHINO REF: {lastTxResponse?.transaction?.id}</p>
              <p className="text-[10px] text-[#8b949e]">AUTH CODE: {lastTxResponse?.authorisation_code}</p>
            </div>
          )}

          {terminalState === 'DECLINED' && (
            <div className="space-y-2">
              <XCircle className="w-10 h-10 text-[#f85149] mx-auto" />
              <p className="text-xl font-bold text-[#f85149]">DECLINED</p>
              <p className="text-xs text-[#8b949e]">{lastTxResponse?.response_code}</p>
            </div>
          )}
        </div>

        {/* Terminal Interactive Actions */}
        {terminalState === 'TAP_CARD' && (
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => handleSimulateTap('CONTACTLESS')}
              className="p-3 bg-[#1b382b] border border-[#38d39f] rounded text-xs font-bold text-[#38d39f] hover:bg-[#234d3a] flex flex-col items-center gap-1"
            >
              <Radio className="w-4 h-4" />
              <span>TAP CARD</span>
            </button>
            <button
              onClick={() => handleSimulateTap('CHIP')}
              className="p-3 bg-[#1b382b] border border-[#38d39f] rounded text-xs font-bold text-[#38d39f] hover:bg-[#234d3a] flex flex-col items-center gap-1"
            >
              <CreditCard className="w-4 h-4" />
              <span>INSERT CHIP</span>
            </button>
            <button
              onClick={() => handleSimulateTap('MOBILE_WALLET')}
              className="p-3 bg-[#1b382b] border border-[#38d39f] rounded text-xs font-bold text-[#38d39f] hover:bg-[#234d3a] flex flex-col items-center gap-1"
            >
              <Radio className="w-4 h-4" />
              <span>APPLE PAY</span>
            </button>
          </div>
        )}

        {/* Physical Pin Pad */}
        <div className="grid grid-cols-3 gap-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'DEL'].map((k) => (
            <button
              key={k}
              onClick={() => handleKeyPress(k)}
              disabled={terminalState !== 'READY'}
              className="p-3 bg-[#0d1117] border border-[#30363d] rounded text-sm font-bold text-[#f0f6fc] hover:bg-[#1f242c] active:bg-[#38d39f] active:text-black transition-all disabled:opacity-40"
            >
              {k}
            </button>
          ))}
        </div>

        {/* Terminal Action Buttons */}
        <div className="flex gap-3">
          {terminalState === 'READY' ? (
            <button
              onClick={handleStartPayment}
              className="flex-1 py-3 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-sm hover:bg-[#234d3a]"
            >
              CHARGE £{amount}
            </button>
          ) : (
            <button
              onClick={() => setTerminalState('READY')}
              className="flex-1 py-3 bg-[#21262d] text-[#f0f6fc] border border-[#30363d] rounded font-bold text-sm hover:bg-[#30363d]"
            >
              NEW SALE / CANCEL
            </button>
          )}

          {offlineMode && (
            <button
              onClick={handleReconnectSync}
              className="px-4 py-3 bg-[#1c2e3d] text-[#58a6ff] border border-[#58a6ff] rounded font-bold text-xs hover:bg-[#264259]"
            >
              RECONNECT & SYNC
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
