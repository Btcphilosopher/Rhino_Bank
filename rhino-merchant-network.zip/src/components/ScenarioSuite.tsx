/**
 * RHINO SCENARIO SUITE - Master Canonical Demo Executer (15 Scenarios) & Test Runner
 */

import React, { useState } from 'react';
import { Play, CheckCircle2, XCircle, AlertTriangle, Cpu, RefreshCw } from 'lucide-react';
import { MasterDemoResult } from '../types/rhino';

const SCENARIO_LIST = [
  { id: 1, title: '1. Card-Present Contactless Tap', desc: 'Contactless NFC tap -> EMV Cryptogram -> Tokenisation -> Route -> Double-entry' },
  { id: 2, title: '2. E-Commerce 3DS Payment', desc: 'Web checkout -> Token Vault -> 3DS2 Challenge OTP -> Capture -> Ledger' },
  { id: 3, title: '3. Tokenised Recurring Charge', desc: 'Vault token charge -> CoF bypass CVV -> Ledger posting' },
  { id: 4, title: '4. Fraud Engine Challenge', desc: 'High ticket amount -> Fraud rule triggers -> Score > 50 Challenge' },
  { id: 5, title: '5. Network Failover & Reroute', desc: 'Primary route down -> Smart engine auto-reroutes to secondary acquirer' },
  { id: 6, title: '6. Partial & Full Refund', desc: 'Refund capture -> Ledger debit payable & credit refund liability' },
  { id: 7, title: '7. Chargeback & Dispute Hold', desc: 'Dispute filed -> Ledger reserve hold posted to account 2200' },
  { id: 8, title: '8. Settlement Batch Calculation', desc: 'EOD Gross-to-Net calculation -> Deduct interchange & merchant net payout' },
  { id: 9, title: '9. Reconciliation Exception Finder', desc: 'Automated audit matching gateway logs vs clearing file exceptions' },
  { id: 10, title: '10. Merchant Bank Payout', desc: 'Cleared payout instruction -> Direct bank transfer completed' },
  { id: 11, title: '11. Terminal Going Offline', desc: 'Connectivity loss -> Terminal stores offline transactions in local queue' },
  { id: 12, title: '12. Terminal Reconnect Sync', desc: 'mTLS restored -> Upload & reconcile queued offline transactions' },
  { id: 13, title: '13. Multi-Currency FX Transaction', desc: '€1,250 EUR processing -> FX rate spread applied -> EUR ledger balanced' },
  { id: 14, title: '14. Payment Link Checkout Flow', desc: 'Merchant link generation -> Customer Apple Pay checkout' },
  { id: 15, title: '15. Subscription Billing Engine', desc: 'Automated recurring billing run -> Token charge execution' },
];

export function ScenarioSuite() {
  const [activeTab, setActiveTab] = useState<'SCENARIOS' | 'UNIT_TESTS'>('SCENARIOS');
  const [runningScenarioId, setRunningScenarioId] = useState<number | null>(null);
  const [scenarioResults, setScenarioResults] = useState<Record<number, MasterDemoResult>>({});
  const [unitTestReport, setUnitTestReport] = useState<any | null>(null);
  const [isTestRunning, setIsTestRunning] = useState(false);

  const handleRunScenario = async (id: number) => {
    setRunningScenarioId(id);
    try {
      const res = await fetch(`/api/v1/demos/run-scenario/${id}`, { method: 'POST' });
      if (res.ok) {
        const result = await res.json();
        setScenarioResults((prev) => ({ ...prev, [id]: result }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setRunningScenarioId(null);
    }
  };

  const handleRunAllScenarios = async () => {
    for (const sc of SCENARIO_LIST) {
      await handleRunScenario(sc.id);
    }
  };

  const handleRunUnitTests = async () => {
    setIsTestRunning(true);
    try {
      const res = await fetch('/api/v1/tests/run');
      if (res.ok) {
        setUnitTestReport(await res.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsTestRunning(false);
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161b22] border border-[#30363d] p-4 rounded">
        <div>
          <h2 className="text-sm font-bold text-[#f0f6fc]">CANONICAL DEMONSTRATION & VERIFICATION SUITE</h2>
          <p className="text-xs text-[#8b949e]">Executes complete computational traces for all 15 required domain scenarios & core unit tests</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('SCENARIOS')}
            className={`px-3 py-1.5 text-xs rounded font-bold ${activeTab === 'SCENARIOS' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
          >
            15 DEMO SCENARIOS
          </button>
          <button
            onClick={() => setActiveTab('UNIT_TESTS')}
            className={`px-3 py-1.5 text-xs rounded font-bold ${activeTab === 'UNIT_TESTS' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
          >
            SYSTEM UNIT TESTS
          </button>
        </div>
      </div>

      {activeTab === 'SCENARIOS' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <span className="text-xs text-[#8b949e]">Select any scenario to execute live on the Rhino backend:</span>
            <button
              onClick={handleRunAllScenarios}
              className="px-4 py-2 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-xs hover:bg-[#234d3a] flex items-center space-x-2"
            >
              <Play className="w-3.5 h-3.5" />
              <span>EXECUTE ALL 15 SCENARIOS</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SCENARIO_LIST.map((sc) => {
              const res = scenarioResults[sc.id];
              const isRunning = runningScenarioId === sc.id;

              return (
                <div key={sc.id} className="bg-[#161b22] border border-[#30363d] rounded p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-xs font-bold text-[#f0f6fc]">{sc.title}</h3>
                      <p className="text-[10px] text-[#8b949e] mt-0.5">{sc.desc}</p>
                    </div>

                    <button
                      onClick={() => handleRunScenario(sc.id)}
                      disabled={isRunning}
                      className="px-3 py-1 bg-[#0d1117] text-[#38d39f] border border-[#38d39f]/40 rounded font-bold text-xs hover:bg-[#1f242c] disabled:opacity-50 flex items-center space-x-1"
                    >
                      {isRunning ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                      <span>{isRunning ? 'RUNNING' : 'RUN'}</span>
                    </button>
                  </div>

                  {res && (
                    <div className="p-3 bg-[#0d1117] border border-[#21262d] rounded space-y-2">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="font-bold text-[#38d39f]">STATUS: {res.status} ({res.duration_ms}ms)</span>
                        <span className="text-[10px] text-[#8b949e]">{res.steps.length} Steps Executed</span>
                      </div>

                      <div className="space-y-1 text-[10px]">
                        {res.steps.map((st, idx) => (
                          <div key={idx} className="flex space-x-2 text-[#8b949e]">
                            <span className="text-[#38d39f] font-bold">[{st.stage}]</span>
                            <span className="text-[#c9d1d9]">{st.description}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'UNIT_TESTS' && (
        <div className="bg-[#161b22] border border-[#30363d] rounded p-6 space-y-6">
          <div className="flex justify-between items-center border-b border-[#30363d] pb-4">
            <div>
              <h3 className="text-sm font-bold text-[#f0f6fc]">AUTOMATED FINANCIAL INVARIANT UNIT TESTS</h3>
              <p className="text-xs text-[#8b949e]">Verifies double-entry ledger equality, token vault encryption, fraud rules, and failovers</p>
            </div>
            <button
              onClick={handleRunUnitTests}
              disabled={isTestRunning}
              className="px-4 py-2 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-xs hover:bg-[#234d3a] disabled:opacity-50"
            >
              {isTestRunning ? 'Running Tests...' : 'Run Automated System Verification'}
            </button>
          </div>

          {unitTestReport && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="p-3 bg-[#0d1117] border border-[#30363d] rounded">
                  <p className="text-[10px] text-[#8b949e]">TOTAL TESTS</p>
                  <p className="text-lg font-bold text-[#f0f6fc]">{unitTestReport.total}</p>
                </div>
                <div className="p-3 bg-[#0d1117] border border-[#30363d] rounded">
                  <p className="text-[10px] text-[#8b949e]">PASSED</p>
                  <p className="text-lg font-bold text-[#38d39f]">{unitTestReport.passed}</p>
                </div>
                <div className="p-3 bg-[#0d1117] border border-[#30363d] rounded">
                  <p className="text-[10px] text-[#8b949e]">FAILED</p>
                  <p className="text-lg font-bold text-[#f85149]">{unitTestReport.failed}</p>
                </div>
              </div>

              <div className="space-y-2">
                {unitTestReport.results.map((r: any, idx: number) => (
                  <div key={idx} className="p-3 bg-[#0d1117] border border-[#21262d] rounded flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[#8b949e] font-bold">[{r.suite}]</span>{' '}
                      <span className="text-[#f0f6fc]">{r.name}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${r.status === 'PASSED' ? 'bg-[#1b382b] text-[#38d39f]' : 'bg-[#49181d] text-[#f85149]'}`}>
                      {r.status} ({r.duration_ms}ms)
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
