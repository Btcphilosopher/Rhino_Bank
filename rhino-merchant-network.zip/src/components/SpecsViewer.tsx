/**
 * RHINO SPECS VIEWER - Architecture, Double-Entry Invariants, & Code Viewer
 */

import React, { useState } from 'react';
import { Cpu, FileText, Database, Shield } from 'lucide-react';

export function SpecsViewer() {
  const [activeDoc, setActiveDoc] = useState<'DOUBLE_ENTRY' | 'SCHEMA' | 'RUST' | 'KOTLIN' | 'OPENAPI'>('DOUBLE_ENTRY');

  return (
    <div className="space-y-6 font-mono">
      {/* Top Selector Bar */}
      <div className="flex items-center space-x-2 border-b border-[#21262d] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveDoc('DOUBLE_ENTRY')}
          className={`px-3 py-1.5 text-xs rounded font-bold ${activeDoc === 'DOUBLE_ENTRY' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
        >
          DOUBLE-ENTRY INVARIANTS
        </button>
        <button
          onClick={() => setActiveDoc('SCHEMA')}
          className={`px-3 py-1.5 text-xs rounded font-bold ${activeDoc === 'SCHEMA' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
        >
          RELATIONAL DATABASE SCHEMA
        </button>
        <button
          onClick={() => setActiveDoc('RUST')}
          className={`px-3 py-1.5 text-xs rounded font-bold ${activeDoc === 'RUST' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
        >
          RUST ENGINE CODE
        </button>
        <button
          onClick={() => setActiveDoc('KOTLIN')}
          className={`px-3 py-1.5 text-xs rounded font-bold ${activeDoc === 'KOTLIN' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
        >
          KOTLIN POS DAEMON
        </button>
        <button
          onClick={() => setActiveDoc('OPENAPI')}
          className={`px-3 py-1.5 text-xs rounded font-bold ${activeDoc === 'OPENAPI' ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]' : 'text-[#8b949e]'}`}
        >
          OPENAPI 3.7 SPECIFICATION
        </button>
      </div>

      <div className="bg-[#161b22] border border-[#30363d] rounded p-6">
        {activeDoc === 'DOUBLE_ENTRY' && (
          <div className="space-y-4 text-xs text-[#c9d1d9] leading-relaxed">
            <h3 className="text-sm font-bold text-[#38d39f]">RHINO BANK DOUBLE-ENTRY ACCOUNTING INVARIANTS</h3>
            <p>
              Rhino Merchant Network enforces strict mathematical double-entry accounting. Balances are derived dynamically by summing immutable journal entries rather than mutating stored scalar balance fields.
            </p>
            <div className="p-4 bg-[#0d1117] border border-[#30363d] rounded text-[11px] text-[#38d39f]">
              <p className="font-bold">CORE ACCOUNTING FORMULA:</p>
              <p className="mt-1">SUM(Debits across all entries) === SUM(Credits across all entries)</p>
            </div>
            <ul className="list-disc pl-5 space-y-1 text-[#8b949e]">
              <li><strong className="text-[#f0f6fc]">Asset Accounts (1000 series):</strong> Debit-positive (e.g. Cash Clearing 1000, Scheme Receivables 1100).</li>
              <li><strong className="text-[#f0f6fc]">Liability Accounts (2000 series):</strong> Credit-positive (e.g. Merchant Payables 2000, Chargeback Reserves 2200).</li>
              <li><strong className="text-[#f0f6fc]">Revenue Accounts (3000 series):</strong> Credit-positive (e.g. Acquirer Fee Revenue 3000).</li>
            </ul>
          </div>
        )}

        {activeDoc === 'RUST' && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-[#38d39f]">RUST CORE PAYMENT ENGINE (rust-core/src/lib.rs)</h3>
            <pre className="p-4 bg-[#0d1117] border border-[#30363d] rounded text-[11px] text-[#38d39f] overflow-x-auto">
{`// Rhino High-Throughput Rust Core Engine
pub struct RhinoEngine {
    pub routes: HashMap<String, PaymentRoute>,
}

impl RhinoEngine {
    pub fn select_optimal_route(&self, amount: f64, risk_score: u8) -> Option<&PaymentRoute> {
        self.routes.values()
            .filter(|r| r.is_healthy)
            .max_by_key(|r| (r.approval_rate * 1000.0) as i64 - (r.cost_bps as i64))
    }
}`}
            </pre>
          </div>
        )}

        {activeDoc === 'KOTLIN' && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-[#38d39f]">KOTLIN ANDROID POS DAEMON (android/RhinoPosDaemon.kt)</h3>
            <pre className="p-4 bg-[#0d1117] border border-[#30363d] rounded text-[11px] text-[#38d39f] overflow-x-auto">
{`// Rhino Android POS Terminal Service
class RhinoPosDaemon(private val mtlsClient: OkHttpClient) {
    fun processTapToPay(nfcData: ByteArray): TransactionResult {
        val emvCryptogram = generateEmvCryptogram(nfcData)
        return mtlsClient.executeAuthorisation(emvCryptogram)
    }
}`}
            </pre>
          </div>
        )}

        {activeDoc === 'SCHEMA' && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-[#38d39f]">POSTGRESQL RELATIONAL SCHEMA</h3>
            <pre className="p-4 bg-[#0d1117] border border-[#30363d] rounded text-[11px] text-[#38d39f] overflow-x-auto">
{`CREATE TABLE merchants (
    id VARCHAR(64) PRIMARY KEY,
    trading_name VARCHAR(255) NOT NULL,
    risk_score INT NOT NULL DEFAULT 10,
    settlement_currency VARCHAR(3) NOT NULL
);

CREATE TABLE ledger_entries (
    id VARCHAR(64) PRIMARY KEY,
    transaction_id VARCHAR(64) NOT NULL,
    account_id VARCHAR(64) NOT NULL,
    direction VARCHAR(6) CHECK (direction IN ('DEBIT', 'CREDIT')),
    amount NUMERIC(18, 4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`}
            </pre>
          </div>
        )}

        {activeDoc === 'OPENAPI' && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-[#38d39f]">OPENAPI 3.7 SPECIFICATION SUMMARY</h3>
            <p className="text-xs text-[#8b949e]">Complete specification available in /openapi/openapi.yaml</p>
            <div className="p-4 bg-[#0d1117] border border-[#30363d] rounded text-[11px] text-[#f0f6fc] space-y-1">
              <p><span className="text-[#38d39f] font-bold">POST</span> /api/v1/payment-intents</p>
              <p><span className="text-[#38d39f] font-bold">POST</span> /api/v1/transactions/process (Supports Idempotency-Key)</p>
              <p><span className="text-[#38d39f] font-bold">POST</span> /api/v1/refunds</p>
              <p><span className="text-[#38d39f] font-bold">GET</span> /api/v1/ledger/accounts</p>
              <p><span className="text-[#38d39f] font-bold">POST</span> /api/v1/settlements/batch</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
