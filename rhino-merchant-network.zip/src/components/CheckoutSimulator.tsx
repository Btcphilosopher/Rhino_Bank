/**
 * RHINO E-COMMERCE CHECKOUT SIMULATOR - E-Commerce & Payment Intent Checkout
 */

import React, { useState } from 'react';
import { ShieldCheck, Lock, CreditCard, CheckCircle2 } from 'lucide-react';

export function CheckoutSimulator() {
  const [amount, setAmount] = useState('150.00');
  const [currency, setCurrency] = useState('GBP');
  const [cardName, setCardName] = useState('Alex Taylor');
  const [cardNumber, setCardNumber] = useState('4000001234564242');
  const [expMonth, setExpMonth] = useState('12');
  const [expYear, setExpYear] = useState('2028');
  const [cvv, setCvv] = useState('123');
  const [isProcessing, setIsProcessing] = useState(false);
  const [show3DSModal, setShow3DSModal] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [checkoutResult, setCheckoutResult] = useState<any | null>(null);

  const handleStartCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate 3DS trigger if amount > 100
    if (Number(amount) > 100) {
      setTimeout(() => {
        setIsProcessing(false);
        setShow3DSModal(true);
      }, 600);
    } else {
      executeBackendPayment();
    }
  };

  const executeBackendPayment = async () => {
    setIsProcessing(true);
    setShow3DSModal(false);
    try {
      const res = await fetch('/api/v1/transactions/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchant_id: 'merch_coffee_01',
          amount: Number(amount),
          currency,
          pan: cardNumber,
          exp_month: Number(expMonth),
          exp_year: Number(expYear),
          cvv,
          cardholder_name: cardName,
          entry_mode: 'ECOMMERCE',
        }),
      });

      const data = await res.json();
      setCheckoutResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 font-mono">
      <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-6 space-y-6 shadow-xl">
        <div className="flex justify-between items-center border-b border-[#30363d] pb-4">
          <div>
            <span className="text-[10px] text-[#38d39f] font-bold">RHINO SECURE CHECKOUT</span>
            <h2 className="text-sm font-bold text-[#f0f6fc]">Rhino Coffee Roasters - Order #99281</h2>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-[#8b949e]">TOTAL DUE</span>
            <p className="text-lg font-bold text-[#38d39f]">{currency} {amount}</p>
          </div>
        </div>

        {checkoutResult ? (
          <div className="p-6 bg-[#0d1117] border border-[#38d39f] rounded-lg text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-[#38d39f] mx-auto" />
            <h3 className="text-lg font-bold text-[#38d39f]">PAYMENT SUCCESSFUL!</h3>
            <p className="text-xs text-[#f0f6fc]">Transaction ID: {checkoutResult.transaction?.id}</p>
            <p className="text-xs text-[#8b949e]">Auth Code: {checkoutResult.authorisation_code}</p>

            <button
              onClick={() => setCheckoutResult(null)}
              className="mt-4 px-6 py-2 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-xs"
            >
              Make Another Payment
            </button>
          </div>
        ) : (
          <form onSubmit={handleStartCheckout} className="space-y-4">
            <div>
              <label className="text-[11px] text-[#8b949e]">CARDHOLDER NAME</label>
              <input
                type="text"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                required
              />
            </div>

            <div>
              <label className="text-[11px] text-[#8b949e]">SYNTHETIC CARD NUMBER (PAN)</label>
              <input
                type="text"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                required
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] text-[#8b949e]">EXP MONTH</label>
                <input
                  type="text"
                  value={expMonth}
                  onChange={(e) => setExpMonth(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] text-[#8b949e]">EXP YEAR</label>
                <input
                  type="text"
                  value={expYear}
                  onChange={(e) => setExpYear(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] text-[#8b949e]">CVV</label>
                <input
                  type="text"
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#f0f6fc] mt-1"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-3 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-sm hover:bg-[#234d3a] disabled:opacity-50"
            >
              {isProcessing ? 'Tokenising & Processing...' : `PAY ${currency} ${amount}`}
            </button>
          </form>
        )}
      </div>

      {/* 3DS Authentication Challenge Modal */}
      {show3DSModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono">
          <div className="bg-[#161b22] border-2 border-[#38d39f] rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center space-x-2 border-b border-[#30363d] pb-3">
              <ShieldCheck className="w-5 h-5 text-[#38d39f]" />
              <h3 className="text-sm font-bold text-[#f0f6fc]">RHINO BANK 3DS2 AUTHENTICATION</h3>
            </div>

            <p className="text-xs text-[#8b949e]">
              Enter One-Time Passcode sent to registered mobile ending in <span className="text-[#38d39f] font-bold">**88</span>:
            </p>

            <input
              type="text"
              value={otpCode}
              onChange={(e) => setOtpCode(e.target.value)}
              placeholder="Enter 6-digit OTP (e.g. 123456)"
              className="w-full bg-[#0d1117] border border-[#38d39f] rounded px-3 py-2 text-center text-sm font-bold text-[#38d39f]"
            />

            <button
              onClick={executeBackendPayment}
              className="w-full py-2 bg-[#1b382b] text-[#38d39f] border border-[#38d39f] rounded font-bold text-xs hover:bg-[#234d3a]"
            >
              Verify & Complete Payment
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
