/**
 * RHINO MERCHANT NETWORK - Institutional Header & System Navigation
 */

import { Activity, ShieldCheck, Terminal, CreditCard, PlayCircle, FileText, Cpu } from 'lucide-react';

export type NavTab = 'BANK_CONTROL' | 'MERCHANT_PORTAL' | 'TERMINAL_SIM' | 'CHECKOUT_SIM' | 'SCENARIO_SUITE' | 'SPECS_DOCS';

interface HeaderProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  systemHealth: string;
}

export function Header({ activeTab, setActiveTab, systemHealth }: HeaderProps) {
  return (
    <header className="border-b border-[#21262d] bg-[#0d1117] px-6 py-3 sticky top-0 z-50 shadow-md">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 max-w-7xl mx-auto">
        {/* Brand Title */}
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded bg-[#1b382b] border border-[#38d39f]/40 flex items-center justify-center font-mono font-bold text-[#38d39f] text-lg tracking-wider shadow-inner">
            RH
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-bold tracking-widest text-[#f0f6fc] font-mono uppercase">
                RHINO MERCHANT NETWORK
              </h1>
              <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-[#161b22] text-[#38d39f] border border-[#38d39f]/30 rounded">
                RHINO BANK
              </span>
            </div>
            <p className="text-[11px] font-mono text-[#8b949e]">
              BANK-GRADE ACQUIRING & ORCHESTRATION INFRASTRUCTURE
            </p>
          </div>
        </div>

        {/* Live Metrics Ticker */}
        <div className="hidden lg:flex items-center space-x-6 px-4 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-xs font-mono">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#38d39f] animate-pulse"></span>
            <span className="text-[#8b949e]">STATUS:</span>
            <span className="text-[#f0f6fc] font-semibold">{systemHealth}</span>
          </div>
          <div className="h-3 w-[1px] bg-[#30363d]" />
          <div>
            <span className="text-[#8b949e]">TPS:</span>{' '}
            <span className="text-[#38d39f] font-semibold">1,482</span>
          </div>
          <div className="h-3 w-[1px] bg-[#30363d]" />
          <div>
            <span className="text-[#8b949e]">ACCEPTANCE:</span>{' '}
            <span className="text-[#38d39f] font-semibold">98.8%</span>
          </div>
          <div className="h-3 w-[1px] bg-[#30363d]" />
          <div>
            <span className="text-[#8b949e]">LEDGER:</span>{' '}
            <span className="text-[#38d39f] font-semibold">BALANCED</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          <button
            onClick={() => setActiveTab('BANK_CONTROL')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1.5 transition-all ${
              activeTab === 'BANK_CONTROL'
                ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/50 font-semibold'
                : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>BANK CONTROL</span>
          </button>

          <button
            onClick={() => setActiveTab('MERCHANT_PORTAL')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1.5 transition-all ${
              activeTab === 'MERCHANT_PORTAL'
                ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/50 font-semibold'
                : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>MERCHANT PORTAL</span>
          </button>

          <button
            onClick={() => setActiveTab('TERMINAL_SIM')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1.5 transition-all ${
              activeTab === 'TERMINAL_SIM'
                ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/50 font-semibold'
                : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>TERMINAL POS</span>
          </button>

          <button
            onClick={() => setActiveTab('CHECKOUT_SIM')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1.5 transition-all ${
              activeTab === 'CHECKOUT_SIM'
                ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/50 font-semibold'
                : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>CHECKOUT</span>
          </button>

          <button
            onClick={() => setActiveTab('SCENARIO_SUITE')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1.5 transition-all ${
              activeTab === 'SCENARIO_SUITE'
                ? 'bg-[#1b382b] text-[#38d39f] border border-[#38d39f] font-semibold'
                : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
            }`}
          >
            <PlayCircle className="w-3.5 h-3.5 text-[#38d39f]" />
            <span className="text-[#38d39f]">DEMO SCENARIOS (15)</span>
          </button>

          <button
            onClick={() => setActiveTab('SPECS_DOCS')}
            className={`px-3 py-1.5 text-xs font-mono rounded flex items-center space-x-1.5 transition-all ${
              activeTab === 'SPECS_DOCS'
                ? 'bg-[#1f242c] text-[#38d39f] border border-[#38d39f]/50 font-semibold'
                : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>ARCHITECTURE</span>
          </button>
        </nav>
      </div>
    </header>
  );
}
