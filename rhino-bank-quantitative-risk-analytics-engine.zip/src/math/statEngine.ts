/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Rhino Bank Quantitative Risk Analytics Engine
 * Core Mathematical & Statistical Engine
 */

// --- STATISTICAL DISTRIBUTIONS & APPROXIMATIONS ---

/**
 * Standard Normal Cumulative Distribution Function (CDF)
 * Uses standard numerical approximation (highly stable)
 */
export function pnorm(x: number): number {
  const b1 =  0.319381530;
  const b2 = -0.356563782;
  const b3 =  1.781477937;
  const b4 = -1.821255978;
  const b5 =  1.330274429;
  const p  =  0.2316419;
  const c  =  0.39894228;

  if (x >= 0.0) {
    const t = 1.0 / (1.0 + p * x);
    return (1.0 - c * Math.exp(-x * x / 2.0) * t *
           (t *(t *(t *(t * b5 + b4) + b3) + b2) + b1));
  } else {
    const t = 1.0 / (1.0 - p * x);
    return (c * Math.exp(-x * x / 2.0) * t *
           (t *(t *(t *(t * b5 + b4) + b3) + b2) + b1));
  }
}

/**
 * Standard Normal Inverse Cumulative Distribution Function (quantile function / qnorm)
 * Uses Wichura's high-precision approximation for statistical applications
 */
export function qnorm(p: number): number {
  if (p <= 0 || p >= 1) {
    if (p === 0) return -Infinity;
    if (p === 1) return Infinity;
    throw new Error("p must be between 0 and 1 exclusive");
  }

  // Coefficients for approximation
  const c0 = 2.515517;
  const c1 = 0.802853;
  const c2 = 0.010328;
  const d1 = 1.432788;
  const d2 = 0.189269;
  const d3 = 0.001308;

  const t = Math.sqrt(-2.0 * Math.log(p < 0.5 ? p : 1.0 - p));
  const num = c0 + c1 * t + c2 * t * t;
  const den = 1.0 + d1 * t + d2 * t * t + d3 * t * t * t;
  const q = t - num / den;

  return p < 0.5 ? -q : q;
}

/**
 * Get critical value (z* or t*) for a specific confidence level
 * @param confidenceLevel e.g. 0.95
 * @param df degrees of freedom (null or undefined for Normal distribution)
 */
export function getCriticalValue(confidenceLevel: number, df?: number): number {
  const alpha = 1 - confidenceLevel;
  const p = 1 - alpha / 2;

  if (!df || df >= 1000) {
    return qnorm(p);
  }

  // Student-t approximation using Cornish-Fisher expansion based on normal quantile
  const z = qnorm(p);
  const g1 = (z * z + 1) / 4;
  const g2 = (5 * z * z * z + 16 * z) / 96;
  const g3 = (3 * z * z * z * z * z + 19 * z * z * z + 17 * z) / 384;
  const g4 = (79 * Math.pow(z, 7) + 776 * Math.pow(z, 5) + 1482 * Math.pow(z, 3) - 1920 * z) / 92160;

  const tVal = z + (z * z + 1) / (4 * df) * z +
               (5 * Math.pow(z, 3) + 16 * z) / (96 * df * df) +
               (3 * Math.pow(z, 5) + 19 * Math.pow(z, 3) + 17 * z) / (384 * df * df * df);
  return Math.max(z, tVal); // t-value is always wider than z-value
}

// --- CORE QUANTITATIVE STAT ENGINE ---

export interface StatisticalUncertaintyResult {
  mean: number;
  sd: number;
  sampleSize: number;
  populationSize?: number;
  confidenceLevel: number;
  criticalValue: number;
  standardError: number;
  marginOfError: number;
  ciLower: number;
  ciUpper: number;
  ciWidth: number;
  reliabilityScore: number; // 0 to 100
  dataQualityScore: number; // 0 to 100
  effectiveSampleSize: number;
}

/**
 * Primary function to calculate statistical uncertainty
 */
export function calculate_statistical_uncertainty(
  sampleSize: number,
  sd: number,
  mean: number,
  confidenceLevel: number = 0.95,
  populationSize?: number,
  outliersCount: number = 0,
  missingObservations: number = 0
): StatisticalUncertaintyResult {
  if (sampleSize <= 1) {
    return {
      mean, sd, sampleSize, populationSize, confidenceLevel,
      criticalValue: 1.96, standardError: 0, marginOfError: 0,
      ciLower: mean, ciUpper: mean, ciWidth: 0,
      reliabilityScore: 0, dataQualityScore: 0, effectiveSampleSize: sampleSize
    };
  }

  const df = sampleSize - 1;
  const criticalValue = getCriticalValue(confidenceLevel, df);

  // Standard Error calculation
  let standardError = sd / Math.sqrt(sampleSize);

  // Apply Finite Population Correction (FPC) if applicable
  let fpc = 1.0;
  if (populationSize && populationSize > sampleSize) {
    fpc = Math.sqrt((populationSize - sampleSize) / (populationSize - 1));
    standardError = standardError * fpc;
  }

  const marginOfError = criticalValue * standardError;
  const ciLower = mean - marginOfError;
  const ciUpper = mean + marginOfError;
  const ciWidth = ciUpper - ciLower;

  // Calculate Effective Sample Size (discounting missing values/outliers slightly)
  const totalObserved = sampleSize + missingObservations;
  const missingRatio = totalObserved > 0 ? missingObservations / totalObserved : 0;
  const outlierRatio = sampleSize > 0 ? outliersCount / sampleSize : 0;
  const effectiveSampleSize = Math.max(2, Math.round(sampleSize * (1 - missingRatio - outlierRatio * 0.5)));

  // Data Quality Score (0-100)
  // Penalized by missing data and high proportion of outliers
  const dqBase = 100 * (1 - missingRatio) * (1 - Math.min(0.5, outlierRatio * 2));
  const dataQualityScore = Math.max(10, Math.min(100, Math.round(dqBase)));

  // Reliability Score (0-100)
  // Higher sample size, lower relative standard error, higher quality score yields higher reliability
  const relativeSE = mean !== 0 ? Math.abs(standardError / mean) : sd;
  const reScore = (100 / (1 + relativeSE * 5)) * (Math.min(500, sampleSize) / 500) * (dataQualityScore / 100);
  const reliabilityScore = Math.max(5, Math.min(100, Math.round(reScore + 30 * (Math.min(100, sampleSize) / 100))));

  return {
    mean,
    sd,
    sampleSize,
    populationSize,
    confidenceLevel,
    criticalValue,
    standardError,
    marginOfError,
    ciLower,
    ciUpper,
    ciWidth,
    reliabilityScore,
    dataQualityScore,
    effectiveSampleSize
  };
}

// --- MONTE CARLO ENGINE ---

export interface MonteCarloPath {
  id: number;
  values: number[];
}

export interface MonteCarloSummary {
  timeSteps: number[];
  meanPath: number[];
  lowerEnvelope: number[]; // e.g. 5th percentile
  upperEnvelope: number[]; // e.g. 95th percentile
  finalValues: number[];
  var95: number;
  var99: number;
  cvar95: number;
  paths: MonteCarloPath[]; // Subset for plotting
}

/**
 * Runs a high-performance Monte Carlo simulation using Geometric Brownian Motion (GBM)
 */
export function run_monte_carlo(
  initialValue: number,
  drift: number,       // expected annual return, e.g. 0.08
  volatility: number,  // annual volatility, e.g. 0.15
  horizonYears: number = 5,
  stepsPerYear: number = 12,
  numPaths: number = 1000,
  confidenceLevel: number = 0.95
): MonteCarloSummary {
  const steps = horizonYears * stepsPerYear;
  const dt = 1 / stepsPerYear;
  const paths: number[][] = Array.from({ length: numPaths }, () => new Array(steps + 1));

  // Initialize all paths at initialValue
  for (let i = 0; i < numPaths; i++) {
    paths[i][0] = initialValue;
  }

  // Box-Muller transform for standard normal variables
  const getGaussian = (): number => {
    let u = 0, v = 0;
    while(u === 0) u = Math.random();
    while(v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  };

  // Generate paths
  const driftTerm = (drift - 0.5 * volatility * volatility) * dt;
  const volTerm = volatility * Math.sqrt(dt);

  for (let step = 1; step <= steps; step++) {
    for (let i = 0; i < numPaths; i++) {
      const z = getGaussian();
      paths[i][step] = paths[i][step - 1] * Math.exp(driftTerm + volTerm * z);
    }
  }

  // Calculate step statistics
  const timeSteps = Array.from({ length: steps + 1 }, (_, i) => i * dt);
  const meanPath: number[] = new Array(steps + 1);
  const lowerEnvelope: number[] = new Array(steps + 1);
  const upperEnvelope: number[] = new Array(steps + 1);

  const lowerPct = (1 - confidenceLevel) / 2;
  const upperPct = 1 - lowerPct;

  for (let step = 0; step <= steps; step++) {
    const stepValues = paths.map(p => p[step]);
    stepValues.sort((a, b) => a - b);

    // Mean
    const sum = stepValues.reduce((acc, v) => acc + v, 0);
    meanPath[step] = sum / numPaths;

    // Percentiles
    const lowerIdx = Math.max(0, Math.floor(stepValues.length * lowerPct));
    const upperIdx = Math.min(stepValues.length - 1, Math.floor(stepValues.length * upperPct));
    lowerEnvelope[step] = stepValues[lowerIdx];
    upperEnvelope[step] = stepValues[upperIdx];
  }

  // Risk metrics at final step (final portfolio returns)
  const finalValues = paths.map(p => p[steps]);
  const finalReturns = finalValues.map(v => (v - initialValue) / initialValue);
  finalReturns.sort((a, b) => a - b);

  // Value at Risk (VaR)
  const var95Idx = Math.floor(finalReturns.length * 0.05);
  const var99Idx = Math.floor(finalReturns.length * 0.01);

  // VaR defined as positive loss
  const var95 = -finalReturns[var95Idx];
  const var99 = -finalReturns[var99Idx];

  // Conditional Value at Risk (CVaR / Expected Shortfall)
  const cvar95Returns = finalReturns.slice(0, var95Idx + 1);
  const cvar95Sum = cvar95Returns.reduce((acc, r) => acc + r, 0);
  const cvar95 = -cvar95Sum / (cvar95Returns.length || 1);

  // Package a subset of paths (e.g., 15 paths) for plotting
  const plotPaths: MonteCarloPath[] = [];
  const spacing = Math.max(1, Math.floor(numPaths / 15));
  for (let i = 0; i < numPaths; i += spacing) {
    if (plotPaths.length < 15) {
      plotPaths.push({ id: i, values: paths[i] });
    }
  }

  return {
    timeSteps,
    meanPath,
    lowerEnvelope,
    upperEnvelope,
    finalValues,
    var95,
    var99,
    cvar95,
    paths: plotPaths
  };
}

// --- BOOTSTRAP ANALYSIS LIBRARY ---

export interface BootstrapResult {
  observed: number;
  bias: number;
  standardError: number;
  ciLower: number;
  ciUpper: number;
  replications: number[];
}

/**
 * Runs a bootstrap resampling for a chosen statistic (mean, sd, Sharpe, or median)
 */
export function run_bootstrap(
  data: number[],
  statistic: 'mean' | 'sd' | 'sharpe' | 'median' = 'mean',
  replicationsCount: number = 1000,
  confidenceLevel: number = 0.95
): BootstrapResult {
  const n = data.length;
  if (n === 0) {
    return { observed: 0, bias: 0, standardError: 0, ciLower: 0, ciUpper: 0, replications: [] };
  }

  // Calculate observed statistic
  const getMean = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const getSd = (arr: number[], m: number) => {
    if (arr.length <= 1) return 0;
    const sqDiffSum = arr.reduce((acc, v) => acc + Math.pow(v - m, 2), 0);
    return Math.sqrt(sqDiffSum / (arr.length - 1));
  };
  const getMedian = (arr: number[]) => {
    const sorted = [...arr].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  };
  const getSharpe = (arr: number[]) => {
    const m = getMean(arr);
    const s = getSd(arr, m);
    // Annualize (assuming monthly returns)
    return s > 0 ? (m / s) * Math.sqrt(12) : 0;
  };

  let observed = 0;
  if (statistic === 'mean') observed = getMean(data);
  else if (statistic === 'sd') observed = getSd(data, getMean(data));
  else if (statistic === 'median') observed = getMedian(data);
  else if (statistic === 'sharpe') observed = getSharpe(data);

  // Generate bootstrap replications
  const replications: number[] = new Array(replicationsCount);
  for (let b = 0; b < replicationsCount; b++) {
    // Resample with replacement
    const resample: number[] = new Array(n);
    for (let i = 0; i < n; i++) {
      const randIdx = Math.floor(Math.random() * n);
      resample[i] = data[randIdx];
    }

    if (statistic === 'mean') replications[b] = getMean(resample);
    else if (statistic === 'sd') replications[b] = getSd(resample, getMean(resample));
    else if (statistic === 'median') replications[b] = getMedian(resample);
    else if (statistic === 'sharpe') replications[b] = getSharpe(resample);
  }

  replications.sort((a, b) => a - b);

  // Compute stats
  const repMean = getMean(replications);
  const bias = repMean - observed;
  const standardError = getSd(replications, repMean);

  // Percentile confidence interval
  const alpha = 1 - confidenceLevel;
  const lowerIdx = Math.max(0, Math.floor(replicationsCount * (alpha / 2)));
  const upperIdx = Math.min(replicationsCount - 1, Math.floor(replicationsCount * (1 - alpha / 2)));

  const ciLower = replications[lowerIdx];
  const ciUpper = replications[upperIdx];

  return {
    observed,
    bias,
    standardError,
    ciLower,
    ciUpper,
    replications
  };
}

// --- PORTFOLIO STATISTICS ---

export interface PortfolioMetrics {
  annualReturn: number;
  volatility: number;
  sharpeRatio: number;
  sortinoRatio: number;
  trackingError: number;
  alpha: number;
  beta: number;
  var95: number;
}

export function calculate_portfolio_metrics(
  returns: number[], // portfolio returns
  benchmarkReturns: number[], // benchmark returns
  riskFreeRate: number = 0.02 // annual RF
): PortfolioMetrics {
  const n = returns.length;
  if (n === 0) {
    return { annualReturn: 0, volatility: 0, sharpeRatio: 0, sortinoRatio: 0, trackingError: 0, alpha: 0, beta: 0, var95: 0 };
  }

  // Monthly scale -> annual scale (assuming monthly returns)
  const scale = 12;

  const meanPort = returns.reduce((a, b) => a + b, 0) / n;
  const meanBench = benchmarkReturns.reduce((a, b) => a + b, 0) / benchmarkReturns.length;

  const portAnnualReturn = meanPort * scale;
  const benchAnnualReturn = meanBench * scale;

  // Variances and Volatility
  const portVar = returns.reduce((acc, v) => acc + Math.pow(v - meanPort, 2), 0) / (n - 1);
  const portVol = Math.sqrt(portVar) * Math.sqrt(scale);

  const benchVar = benchmarkReturns.reduce((acc, v) => acc + Math.pow(v - meanBench, 2), 0) / (benchmarkReturns.length - 1);
  const benchVol = Math.sqrt(benchVar) * Math.sqrt(scale);

  // Sharpe Ratio
  const sharpeRatio = portVol > 0 ? (portAnnualReturn - riskFreeRate) / portVol : 0;

  // Downside deviation & Sortino Ratio
  const downsideReturns = returns.map(v => Math.min(0, v));
  const downsideVar = downsideReturns.reduce((acc, v) => acc + Math.pow(v, 2), 0) / n;
  const downsideDev = Math.sqrt(downsideVar) * Math.sqrt(scale);
  const sortinoRatio = downsideDev > 0 ? (portAnnualReturn - riskFreeRate) / downsideDev : 0;

  // Tracking Error
  const activeReturns = returns.map((v, i) => v - benchmarkReturns[i]);
  const activeMean = activeReturns.reduce((a, b) => a + b, 0) / n;
  const trackingErrorVar = activeReturns.reduce((acc, v) => acc + Math.pow(v - activeMean, 2), 0) / (n - 1);
  const trackingError = Math.sqrt(trackingErrorVar) * Math.sqrt(scale);

  // Covariance, Beta and Alpha
  let covSum = 0;
  for (let i = 0; i < n; i++) {
    covSum += (returns[i] - meanPort) * (benchmarkReturns[i] - meanBench);
  }
  const covariance = covSum / (n - 1);
  const beta = benchVar > 0 ? covariance / benchVar : 1.0;
  const alpha = portAnnualReturn - (riskFreeRate + beta * (benchAnnualReturn - riskFreeRate));

  // Portfolio VaR (Parametric)
  const var95 = -(meanPort - 1.645 * Math.sqrt(portVar)) * Math.sqrt(scale);

  return {
    annualReturn: portAnnualReturn,
    volatility: portVol,
    sharpeRatio,
    sortinoRatio,
    trackingError,
    alpha,
    beta,
    var95
  };
}

// --- CREDIT RISK STATISTICS ---

export interface CreditPortfolioSummary {
  exposureAtDefault: number;
  expectedLoss: number;
  expectedLossLower: number;
  expectedLossUpper: number;
  averagePD: number;
  pdLower: number;
  pdUpper: number;
  averageLGD: number;
  lgdLower: number;
  lgdUpper: number;
  concentrationHHI: number; // Herfindahl-Hirschman Index
}

/**
 * Calculates credit risk indicators and confidence margins based on loan book samples
 */
export function calculate_credit_statistics(
  loans: { id: string; ead: number; pd: number; lgd: number; sector: string }[],
  confidenceLevel: number = 0.95
): CreditPortfolioSummary {
  const n = loans.length;
  if (n === 0) {
    return {
      exposureAtDefault: 0, expectedLoss: 0, expectedLossLower: 0, expectedLossUpper: 0,
      averagePD: 0, pdLower: 0, pdUpper: 0, averageLGD: 0, lgdLower: 0, lgdUpper: 0, concentrationHHI: 0
    };
  }

  let totalEAD = 0;
  let weightedPDSum = 0;
  let weightedLGDSum = 0;
  let expectedLoss = 0;

  // Sectors map for concentration HHI
  const sectorWeights: { [key: string]: number } = {};

  loans.forEach(loan => {
    totalEAD += loan.ead;
    weightedPDSum += loan.pd * loan.ead;
    weightedLGDSum += loan.lgd * loan.ead;
    expectedLoss += loan.ead * loan.pd * loan.lgd;

    sectorWeights[loan.sector] = (sectorWeights[loan.sector] || 0) + loan.ead;
  });

  const averagePD = weightedPDSum / totalEAD;
  const averageLGD = weightedLGDSum / totalEAD;

  // Compute PD and LGD confidence intervals
  // Using sample standard error across loans
  const pdMean = loans.reduce((a, b) => a + b.pd, 0) / n;
  const pdVar = loans.reduce((acc, v) => acc + Math.pow(v.pd - pdMean, 2), 0) / (n - 1 || 1);
  const pdSD = Math.sqrt(pdVar);
  const pdSE = pdSD / Math.sqrt(n);
  const pdCritical = getCriticalValue(confidenceLevel, n - 1);

  const pdLower = Math.max(0, pdMean - pdCritical * pdSE);
  const pdUpper = Math.min(1.0, pdMean + pdCritical * pdSE);

  const lgdMean = loans.reduce((a, b) => a + b.lgd, 0) / n;
  const lgdVar = loans.reduce((acc, v) => acc + Math.pow(v.lgd - lgdMean, 2), 0) / (n - 1 || 1);
  const lgdSD = Math.sqrt(lgdVar);
  const lgdSE = lgdSD / Math.sqrt(n);

  const lgdLower = Math.max(0, lgdMean - pdCritical * lgdSE);
  const lgdUpper = Math.min(1.0, lgdMean + pdCritical * lgdSE);

  // Expected Loss Confidence Intervals
  // EL = EAD * PD * LGD. We propogate variance of PD and LGD under independence
  const elMean = expectedLoss / n;
  const els = loans.map(l => l.ead * l.pd * l.lgd);
  const elMeanReal = els.reduce((a, b) => a + b, 0) / n;
  const elVar = els.reduce((acc, v) => acc + Math.pow(v - elMeanReal, 2), 0) / (n - 1 || 1);
  const elSD = Math.sqrt(elVar);
  const elSE = elSD / Math.sqrt(n);

  const expectedLossLower = Math.max(0, expectedLoss - pdCritical * elSE * n);
  const expectedLossUpper = expectedLoss + pdCritical * elSE * n;

  // Concentration HHI
  let hhi = 0;
  Object.keys(sectorWeights).forEach(sector => {
    const sWeight = sectorWeights[sector] / totalEAD;
    hhi += Math.pow(sWeight * 100, 2); // percentage scale, max 10000
  });

  return {
    exposureAtDefault: totalEAD,
    expectedLoss,
    expectedLossLower,
    expectedLossUpper,
    averagePD,
    pdLower,
    pdUpper,
    averageLGD,
    lgdLower,
    lgdUpper,
    concentrationHHI: hhi
  };
}

// --- TREASURY & LIQUIDITY FORECASTS ---

export interface LiquidityProjectedRange {
  day: number;
  expectedCash: number;
  lowerBound95: number;
  upperBound95: number;
  lowerBound99: number;
  upperBound99: number;
}

/**
 * Projects liquidity curves based on deposit outflows and cash inflows under normal and stressed parameters
 */
export function project_liquidity_reserves(
  startingCash: number,
  averageDailyNetCashFlow: number,
  dailyVolatility: number,
  horizonDays: number = 30
): LiquidityProjectedRange[] {
  const projections: LiquidityProjectedRange[] = [];

  for (let d = 0; d <= horizonDays; d++) {
    const expectedCash = startingCash + averageDailyNetCashFlow * d;

    // Standard deviation grows with the square root of time (Wiener process)
    const cumulativeVolatility = dailyVolatility * Math.sqrt(d);

    const lowerBound95 = Math.max(0, expectedCash - 1.96 * cumulativeVolatility);
    const upperBound95 = expectedCash + 1.96 * cumulativeVolatility;

    const lowerBound99 = Math.max(0, expectedCash - 2.576 * cumulativeVolatility);
    const upperBound99 = expectedCash + 2.576 * cumulativeVolatility;

    projections.push({
      day: d,
      expectedCash,
      lowerBound95,
      upperBound95,
      lowerBound99,
      upperBound99
    });
  }

  return projections;
}

// --- CUSTOMER LIFETIME VALUE STATISTICS ---

export interface CustomerCLVAnalysis {
  clvMean: number;
  clvLower: number;
  clvUpper: number;
  monthlyDepositGrowthMean: number;
  monthlyDepositGrowthLower: number;
  monthlyDepositGrowthUpper: number;
  retentionRate: number;
}

export function calculate_customer_statistics(
  customers: { id: string; clv: number; depositGrowthRate: number; activeMonths: number }[],
  confidenceLevel: number = 0.95
): CustomerCLVAnalysis {
  const n = customers.length;
  if (n === 0) {
    return { clvMean: 0, clvLower: 0, clvUpper: 0, monthlyDepositGrowthMean: 0, monthlyDepositGrowthLower: 0, monthlyDepositGrowthUpper: 0, retentionRate: 0 };
  }

  const clvValues = customers.map(c => c.clv);
  const clvMean = clvValues.reduce((a, b) => a + b, 0) / n;
  const clvVar = clvValues.reduce((acc, v) => acc + Math.pow(v - clvMean, 2), 0) / (n - 1 || 1);
  const clvSD = Math.sqrt(clvVar);
  const clvSE = clvSD / Math.sqrt(n);

  const crit = getCriticalValue(confidenceLevel, n - 1);
  const clvLower = Math.max(0, clvMean - crit * clvSE);
  const clvUpper = clvMean + crit * clvSE;

  const growthValues = customers.map(c => c.depositGrowthRate);
  const monthlyDepositGrowthMean = growthValues.reduce((a, b) => a + b, 0) / n;
  const growthVar = growthValues.reduce((acc, v) => acc + Math.pow(v - monthlyDepositGrowthMean, 2), 0) / (n - 1 || 1);
  const growthSD = Math.sqrt(growthVar);
  const growthSE = growthSD / Math.sqrt(n);

  const monthlyDepositGrowthLower = monthlyDepositGrowthMean - crit * growthSE;
  const monthlyDepositGrowthUpper = monthlyDepositGrowthMean + crit * growthSE;

  // Retention rate estimate (assuming average active months relates to a constant churn rate)
  // Churn rate d = 1 / averageActiveMonths
  const avgMonths = customers.reduce((a, b) => a + b.activeMonths, 0) / n;
  const churn = avgMonths > 0 ? 1 / avgMonths : 0.05;
  const retentionRate = Math.min(1.0, Math.max(0.5, 1 - churn));

  return {
    clvMean,
    clvLower,
    clvUpper,
    monthlyDepositGrowthMean,
    monthlyDepositGrowthLower,
    monthlyDepositGrowthUpper,
    retentionRate
  };
}
