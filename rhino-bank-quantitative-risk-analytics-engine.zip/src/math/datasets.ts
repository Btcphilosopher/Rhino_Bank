/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Rhino Bank Quantitative Risk Analytics Engine
 * Sample Institutional Datasets
 */

// --- 60 MONTHS OF PORTFOLIO AND BENCHMARK RETURNS ---
// Represents a multi-asset institutional portfolio vs. a Global Blended 60/40 Benchmark
export const PORTFOLIO_RETURNS_DATA = [
  { month: "Aug 2021", portfolio: 0.021, benchmark: 0.015 },
  { month: "Sep 2021", portfolio: -0.015, benchmark: -0.018 },
  { month: "Oct 2021", portfolio: 0.032, benchmark: 0.028 },
  { month: "Nov 2021", portfolio: -0.008, benchmark: -0.012 },
  { month: "Dec 2021", portfolio: 0.019, benchmark: 0.014 },
  { month: "Jan 2022", portfolio: -0.035, benchmark: -0.041 },
  { month: "Feb 2022", portfolio: -0.018, benchmark: -0.022 },
  { month: "Mar 2022", portfolio: 0.025, benchmark: 0.019 },
  { month: "Apr 2022", portfolio: -0.048, benchmark: -0.052 },
  { month: "May 2022", portfolio: 0.005, benchmark: 0.001 },
  { month: "Jun 2022", portfolio: -0.055, benchmark: -0.062 },
  { month: "Jul 2022", portfolio: 0.041, benchmark: 0.035 },
  { month: "Aug 2022", portfolio: -0.022, benchmark: -0.025 },
  { month: "Sep 2022", portfolio: -0.061, benchmark: -0.068 },
  { month: "Oct 2022", portfolio: 0.048, benchmark: 0.042 },
  { month: "Nov 2022", portfolio: 0.038, benchmark: 0.031 },
  { month: "Dec 2022", portfolio: -0.029, benchmark: -0.034 },
  { month: "Jan 2023", portfolio: 0.045, benchmark: 0.039 },
  { month: "Feb 2023", portfolio: -0.012, benchmark: -0.015 },
  { month: "Mar 2023", portfolio: 0.018, benchmark: 0.012 },
  { month: "Apr 2023", portfolio: 0.011, benchmark: 0.008 },
  { month: "May 2023", portfolio: -0.005, benchmark: -0.009 },
  { month: "Jun 2023", portfolio: 0.035, benchmark: 0.029 },
  { month: "Jul 2023", portfolio: 0.028, benchmark: 0.024 },
  { month: "Aug 2023", portfolio: -0.019, benchmark: -0.022 },
  { month: "Sep 2023", portfolio: -0.031, benchmark: -0.035 },
  { month: "Oct 2023", portfolio: -0.021, benchmark: -0.026 },
  { month: "Nov 2023", portfolio: 0.052, benchmark: 0.045 },
  { month: "Dec 2023", portfolio: 0.039, benchmark: 0.032 },
  { month: "Jan 2024", portfolio: 0.012, benchmark: 0.008 },
  { month: "Feb 2024", portfolio: 0.028, benchmark: 0.022 },
  { month: "Mar 2024", portfolio: 0.022, benchmark: 0.018 },
  { month: "Apr 2024", portfolio: -0.018, benchmark: -0.021 },
  { month: "May 2024", portfolio: 0.031, benchmark: 0.025 },
  { month: "Jun 2024", portfolio: 0.015, benchmark: 0.011 },
  { month: "Jul 2024", portfolio: 0.018, benchmark: 0.014 },
  { month: "Aug 2024", portfolio: 0.021, benchmark: 0.017 },
  { month: "Sep 2024", portfolio: 0.012, benchmark: 0.009 },
  { month: "Oct 2024", portfolio: -0.008, benchmark: -0.011 },
  { month: "Nov 2024", portfolio: 0.035, benchmark: 0.029 },
  { month: "Dec 2024", portfolio: 0.022, benchmark: 0.018 },
  { month: "Jan 2025", portfolio: 0.015, benchmark: 0.012 },
  { month: "Feb 2025", portfolio: 0.025, benchmark: 0.020 },
  { month: "Mar 2025", portfolio: -0.011, benchmark: -0.014 },
  { month: "Apr 2025", portfolio: 0.019, benchmark: 0.015 },
  { month: "May 2025", portfolio: 0.028, benchmark: 0.022 },
  { month: "Jun 2025", portfolio: -0.005, benchmark: -0.008 },
  { month: "Jul 2025", portfolio: 0.021, benchmark: 0.017 },
  { month: "Aug 2025", portfolio: -0.012, benchmark: -0.015 },
  { month: "Sep 2025", portfolio: 0.032, benchmark: 0.026 },
  { month: "Oct 2025", portfolio: 0.018, benchmark: 0.013 },
  { month: "Nov 2025", portfolio: 0.025, benchmark: 0.020 },
  { month: "Dec 2025", portfolio: 0.014, benchmark: 0.011 },
  { month: "Jan 2026", portfolio: -0.015, benchmark: -0.018 },
  { month: "Feb 2026", portfolio: 0.031, benchmark: 0.024 },
  { month: "Mar 2026", portfolio: 0.022, benchmark: 0.018 },
  { month: "Apr 2026", portfolio: -0.008, benchmark: -0.011 },
  { month: "May 2026", portfolio: 0.019, benchmark: 0.015 },
  { month: "Jun 2026", portfolio: 0.024, benchmark: 0.020 },
  { month: "Jul 2026", portfolio: 0.018, benchmark: 0.014 }
];

export const PORTFOLIO_VECTOR = PORTFOLIO_RETURNS_DATA.map(d => d.portfolio);
export const BENCHMARK_VECTOR = PORTFOLIO_RETURNS_DATA.map(d => d.benchmark);

// --- 200 LOAN BOOK RECORDS FOR CREDIT RISK ANALYTICS ---
export interface LoanRecord {
  id: string;
  ead: number;     // Exposure at Default ($)
  pd: number;      // Probability of Default (ratio 0-1)
  lgd: number;     // Loss Given Default (ratio 0-1)
  sector: string;  // Industry Sector
  vintage: number; // Year of Origination
}

const SECTORS = ["Commercial Real Estate", "Technology & Retail", "Industrial & Logistics", "Infrastructure & Energy", "Financial Services", "Consumer Finance"];

const generateLoans = (): LoanRecord[] => {
  const loans: LoanRecord[] = [];
  const seedRandom = (i: number) => {
    // Semi-deterministic pseudo-random generator
    const x = Math.sin(i) * 10000;
    return x - Math.floor(x);
  };

  for (let i = 1; i <= 200; i++) {
    const r1 = seedRandom(i * 1.5);
    const r2 = seedRandom(i * 2.7);
    const r3 = seedRandom(i * 3.9);
    const r4 = seedRandom(i * 4.2);

    // Exposures range from $250,000 to $12,500,000
    const ead = Math.round((250000 + r1 * 12250000) / 1000) * 1000;

    // PDs range from 0.005 (0.5%) to 0.12 (12%)
    const sectorIndex = Math.floor(r4 * SECTORS.length);
    const sector = SECTORS[sectorIndex];

    let basePD = 0.01 + r2 * 0.06;
    if (sector === "Commercial Real Estate") basePD += 0.02; // higher risk
    if (sector === "Financial Services") basePD -= 0.008;    // lower risk
    const pd = Math.max(0.002, Math.min(0.20, basePD));

    // LGDs range from 0.25 (25%) to 0.65 (65%)
    let baseLGD = 0.30 + r3 * 0.30;
    if (sector === "Infrastructure & Energy") baseLGD -= 0.10; // asset backed
    const lgd = Math.max(0.10, Math.min(0.85, baseLGD));

    const vintage = 2018 + Math.floor(r1 * 8);

    loans.push({
      id: `LN-${10000 + i}`,
      ead,
      pd,
      lgd,
      sector,
      vintage
    });
  }
  return loans;
};

export const SAMPLE_LOANS = generateLoans();

// --- TREASURY RESERVES & DAILY CASH FLOW OBSERVATIONS ---
export interface CashFlowRecord {
  date: string;
  inflow: number;
  outflow: number;
  netFlow: number;
  closingReserve: number;
}

const generateCashFlows = (): CashFlowRecord[] => {
  const data: CashFlowRecord[] = [];
  let closingReserve = 500000000; // $500M initial liquidity reserve
  const baseInflow = 45000000;    // $45M base daily inflow
  const baseOutflow = 43500000;   // $43.5M base daily outflow

  const seedRandom = (i: number) => {
    const x = Math.sin(i) * 10000;
    return x - Math.floor(x);
  };

  const today = new Date("2026-06-25");

  for (let i = 1; i <= 30; i++) {
    const r1 = seedRandom(i * 1.3);
    const r2 = seedRandom(i * 2.5);

    // Inflows fluctuate by +/- 20%
    const inflow = Math.round(baseInflow * (0.9 + r1 * 0.25));
    // Outflows fluctuate by +/- 25%
    const outflow = Math.round(baseOutflow * (0.85 + r2 * 0.35));
    const netFlow = inflow - outflow;
    closingReserve += netFlow;

    const dateStr = new Date(today.getTime() + i * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    data.push({
      date: dateStr,
      inflow,
      outflow,
      netFlow,
      closingReserve
    });
  }
  return data;
};

export const SAMPLE_CASH_FLOWS = generateCashFlows();

// --- CUSTOMER BEHAVIOR & PROFITABILITY RECORDS ---
export interface CustomerRecord {
  id: string;
  tier: "Wealth" | "Premier" | "Retail" | "SME";
  clv: number;               // Customer Lifetime Value ($)
  depositGrowthRate: number; // Monthly Growth Rate (fraction)
  activeMonths: number;
  savingsBalance: number;
}

const generateCustomers = (): CustomerRecord[] => {
  const list: CustomerRecord[] = [];
  const tiers: ("Wealth" | "Premier" | "Retail" | "SME")[] = ["Wealth", "Premier", "Retail", "SME"];

  const seedRandom = (i: number) => {
    const x = Math.sin(i) * 10000;
    return x - Math.floor(x);
  };

  for (let i = 1; i <= 300; i++) {
    const r1 = seedRandom(i * 1.8);
    const r2 = seedRandom(i * 2.4);
    const r3 = seedRandom(i * 3.1);

    const tierIndex = Math.floor(r1 * 4);
    const tier = tiers[tierIndex];

    let baseCLV = 1500;
    let savings = 5000;
    let growth = 0.005;

    if (tier === "Wealth") {
      baseCLV = 75000 + r2 * 120000;
      savings = 250000 + r3 * 1500000;
      growth = 0.008 + r1 * 0.015;
    } else if (tier === "Premier") {
      baseCLV = 15000 + r2 * 25000;
      savings = 50000 + r3 * 180000;
      growth = 0.004 + r1 * 0.01;
    } else if (tier === "SME") {
      baseCLV = 35000 + r2 * 90000;
      savings = 120000 + r3 * 800000;
      growth = 0.006 + r1 * 0.02;
    } else {
      // Retail
      baseCLV = 800 + r2 * 2200;
      savings = 1500 + r3 * 12000;
      growth = 0.002 + r1 * 0.006;
    }

    const clv = Math.round(baseCLV);
    const savingsBalance = Math.round(savings);
    const depositGrowthRate = Number(growth.toFixed(4));
    const activeMonths = 6 + Math.floor(r2 * 110);

    list.push({
      id: `CST-${50000 + i}`,
      tier,
      clv,
      depositGrowthRate,
      activeMonths,
      savingsBalance
    });
  }
  return list;
};

export const SAMPLE_CUSTOMERS = generateCustomers();
