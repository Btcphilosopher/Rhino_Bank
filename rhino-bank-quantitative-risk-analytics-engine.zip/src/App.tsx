/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Rhino Bank Quantitative Risk Analytics Engine
 * Interactive Shiny-Style Executive Dashboard
 */

import React, { useState, useMemo, useEffect } from "react";
import {
  TrendingUp,
  ShieldAlert,
  Sliders,
  Database,
  Calculator,
  RotateCcw,
  Download,
  Printer,
  FileText,
  UserCheck,
  Percent,
  TrendingDown,
  Activity,
  LogOut,
  Settings as SettingsIcon,
  HelpCircle,
  Briefcase,
  Layers,
  Users,
  Wallet,
  Compass,
  CheckCircle,
  AlertTriangle,
  History,
  Lock
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  BarChart,
  Bar,
  ScatterChart,
  Scatter
} from "recharts";

import {
  calculate_statistical_uncertainty,
  run_monte_carlo,
  run_bootstrap,
  calculate_portfolio_metrics,
  calculate_credit_statistics,
  project_liquidity_reserves,
  calculate_customer_statistics,
  getCriticalValue
} from "./math/statEngine";

import {
  PORTFOLIO_RETURNS_DATA,
  PORTFOLIO_VECTOR,
  BENCHMARK_VECTOR,
  SAMPLE_LOANS,
  SAMPLE_CASH_FLOWS,
  SAMPLE_CUSTOMERS
} from "./math/datasets";

type TabID =
  | "executive"
  | "moe_ci"
  | "portfolio"
  | "monte_carlo"
  | "bootstrap"
  | "credit"
  | "treasury"
  | "customer"
  | "stress"
  | "reports"
  | "settings";

interface AuditLog {
  timestamp: string;
  action: string;
  module: string;
  details: string;
}

export default function App() {
  // --- STATE SYSTEM ---
  const [activeTab, setActiveTab] = useState<TabID>("executive");
  const [confidenceLevel, setConfidenceLevel] = useState<number>(0.95);
  const [numPaths, setNumPaths] = useState<number>(1000);
  const [bootstrapReps, setBootstrapReps] = useState<number>(1000);
  const [customConf, setCustomConf] = useState<string>("0.95");
  
  // Custom Playground States
  const [moeSampleSize, setMoeSampleSize] = useState<number>(400);
  const [moePopSize, setMoePopSize] = useState<number>(50000);
  const [moeMean, setMoeMean] = useState<number>(75.5);
  const [moeSD, setMoeSD] = useState<number>(15.2);
  const [moeOutliers, setMoeOutliers] = useState<number>(2);
  const [moeMissing, setMoeMissing] = useState<number>(8);

  // Credit Filter States
  const [selectedSector, setSelectedSector] = useState<string>("All");
  
  // Treasury Stress States
  const [cashStarting, setCashStarting] = useState<number>(500000000);
  const [cashDailyFlow, setCashDailyFlow] = useState<number>(1500000);
  const [cashVolatility, setCashVolatility] = useState<number>(8500000);

  // Customer Filter States
  const [selectedCustomerTier, setSelectedCustomerTier] = useState<string>("All");

  // Audit Logs & Settings
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [calculationSeed, setCalculationSeed] = useState<string>("RHINO_8831");
  const [roleMode, setRoleMode] = useState<string>("Quantitative Analyst");

  // Add Log Entry Utility
  const addLog = (action: string, module: string, details: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString() + "." + String(now.getMilliseconds()).padStart(3, "0");
    setAuditLogs((prev) => [
      { timestamp: timeStr, action, module, details },
      ...prev.slice(0, 49) // Keep last 50
    ]);
  };

  // Log initial load
  useEffect(() => {
    addLog("Platform Initialization", "System", "Rhino Bank Quantitative Analytics Engine booted.");
  }, []);

  // Log tab shifts
  const handleTabChange = (tab: TabID) => {
    setActiveTab(tab);
    addLog("Navigation", tab.toUpperCase(), `Accessed module dashboard.`);
  };

  // Log variable updates
  const updateConfidence = (lvl: number) => {
    setConfidenceLevel(lvl);
    setCustomConf(String(lvl));
    addLog("Configuration Update", "Statistics", `Confidence level adjusted to ${(lvl * 100).toFixed(1)}%`);
  };

  const handleCustomConfSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(customConf);
    if (!isNaN(val) && val > 0.5 && val < 1.0) {
      setConfidenceLevel(val);
      addLog("Configuration Update", "Statistics", `Custom Confidence level set to ${(val * 100).toFixed(2)}%`);
    }
  };

  // --- STATISTICAL CALCULATIONS (MEMOIZED) ---

  // Custom MoE Calculator Tab Output
  const playgroundStats = useMemo(() => {
    return calculate_statistical_uncertainty(
      moeSampleSize,
      moeSD,
      moeMean,
      confidenceLevel,
      moePopSize > 0 ? moePopSize : undefined,
      moeOutliers,
      moeMissing
    );
  }, [moeSampleSize, moeSD, moeMean, confidenceLevel, moePopSize, moeOutliers, moeMissing]);

  // Portfolio Analytics Output
  const portfolioMetrics = useMemo(() => {
    return calculate_portfolio_metrics(PORTFOLIO_VECTOR, BENCHMARK_VECTOR, 0.025);
  }, []);

  const portfolioCI = useMemo(() => {
    // Mean of portfolio returns
    const mean = PORTFOLIO_VECTOR.reduce((a, b) => a + b, 0) / PORTFOLIO_VECTOR.length;
    const sd = Math.sqrt(
      PORTFOLIO_VECTOR.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (PORTFOLIO_VECTOR.length - 1)
    );
    return calculate_statistical_uncertainty(
      PORTFOLIO_VECTOR.length,
      sd,
      mean,
      confidenceLevel,
      undefined,
      0,
      0
    );
  }, [confidenceLevel]);

  // Monte Carlo Simulation
  const monteCarloResult = useMemo(() => {
    // Generates simulated growth over 5 years
    return run_monte_carlo(
      10000000,          // $10M start
      portfolioMetrics.annualReturn, // drift rate
      portfolioMetrics.volatility,   // volatility
      5,                 // 5 years
      12,                // monthly steps
      numPaths,
      confidenceLevel
    );
  }, [numPaths, confidenceLevel, portfolioMetrics.annualReturn, portfolioMetrics.volatility]);

  // Bootstrap Mean return on portfolio returns
  const bootstrapResult = useMemo(() => {
    return run_bootstrap(PORTFOLIO_VECTOR, "mean", bootstrapReps, confidenceLevel);
  }, [bootstrapReps, confidenceLevel]);

  // Credit Risk
  const filteredLoans = useMemo(() => {
    if (selectedSector === "All") return SAMPLE_LOANS;
    return SAMPLE_LOANS.filter(l => l.sector === selectedSector);
  }, [selectedSector]);

  const creditStats = useMemo(() => {
    return calculate_credit_statistics(filteredLoans, confidenceLevel);
  }, [filteredLoans, confidenceLevel]);

  // Treasury projections
  const treasuryProjections = useMemo(() => {
    return project_liquidity_reserves(
      cashStarting,
      cashDailyFlow,
      cashVolatility,
      30
    );
  }, [cashStarting, cashDailyFlow, cashVolatility]);

  // Customer Analytics
  const filteredCustomers = useMemo(() => {
    if (selectedCustomerTier === "All") return SAMPLE_CUSTOMERS;
    return SAMPLE_CUSTOMERS.filter(c => c.tier === selectedCustomerTier);
  }, [selectedCustomerTier]);

  const customerStats = useMemo(() => {
    return calculate_customer_statistics(filteredCustomers, confidenceLevel);
  }, [filteredCustomers, confidenceLevel]);

  // Executive summary scores
  const systemStabilityScore = useMemo(() => {
    // Calculated based on current active metrics' statistical reliability
    const moeRel = playgroundStats.reliabilityScore;
    const portRel = portfolioCI.reliabilityScore;
    const creditRel = Math.min(100, Math.round(100 - (creditStats.pdUpper - creditStats.pdLower) * 800));
    return Math.round((moeRel + portRel + creditRel) / 3);
  }, [playgroundStats.reliabilityScore, portfolioCI.reliabilityScore, creditStats.pdUpper, creditStats.pdLower]);

  // CSV Exporter
  const handleCSVExport = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Metric,Value,Lower CI,Upper CI,Margin of Error\n"
      + `Portfolio Annualised Return,${(portfolioMetrics.annualReturn * 100).toFixed(4)}%,${(portfolioCI.ciLower * 12 * 100).toFixed(4)}%,${(portfolioCI.ciUpper * 12 * 100).toFixed(4)}%,${(portfolioCI.marginOfError * 12 * 100).toFixed(4)}%\n`
      + `Portfolio Volatility,${(portfolioMetrics.volatility * 100).toFixed(4)}%,N/A,N/A,N/A\n`
      + `Sharpe Ratio,${portfolioMetrics.sharpeRatio.toFixed(4)},N/A,N/A,N/A\n`
      + `Credit Portfolio PD,${(creditStats.averagePD * 100).toFixed(4)}%,${(creditStats.pdLower * 100).toFixed(4)}%,${(creditStats.pdUpper * 100).toFixed(4)}%,N/A\n`
      + `Credit Expected Loss,$${creditStats.expectedLoss.toFixed(2)},$${creditStats.expectedLossLower.toFixed(2)},$${creditStats.expectedLossUpper.toFixed(2)},N/A\n`
      + `Average Customer CLV,$${customerStats.clvMean.toFixed(2)},$${customerStats.clvLower.toFixed(2)},$${customerStats.clvUpper.toFixed(2)},N/A\n`;
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `rhino_quant_analytics_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addLog("Export Data", "System", "Exported quantitative statistics report in CSV format.");
  };

  // Sector stats for chart
  const sectorRiskDistribution = useMemo(() => {
    const sectors = Array.from(new Set(SAMPLE_LOANS.map(l => l.sector)));
    return sectors.map(sector => {
      const sectorLoans = SAMPLE_LOANS.filter(l => l.sector === sector);
      const totalEad = sectorLoans.reduce((a, b) => a + b.ead, 0);
      const avgPD = sectorLoans.reduce((acc, v) => acc + v.pd * v.ead, 0) / totalEad;
      const avgLGD = sectorLoans.reduce((acc, v) => acc + v.lgd * v.ead, 0) / totalEad;
      const expectedLoss = totalEad * avgPD * avgLGD;
      return {
        name: sector.replace(" & ", "\n"),
        exposure: totalEad / 1000000, // in Millions
        pd: avgPD * 100,
        lgd: avgLGD * 100,
        loss: expectedLoss / 1000000
      };
    });
  }, []);

  // Format currencies and large numbers
  const formatCurrency = (val: number, decimals: number = 0) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: decimals,
      minimumFractionDigits: decimals
    }).format(val);
  };

  return (
    <div id="quant-root" className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-800 antialiased">
      {/* --- TOP HEADER NAVIGATION BAR --- */}
      <header id="main-header" className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-slate-900 text-white font-serif font-black text-xl p-2.5 rounded-xs tracking-tight">
            RH
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif font-bold text-lg text-slate-900 tracking-tight">Rhino Bank</h1>
              <span className="bg-emerald-50 text-emerald-700 text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-sm border border-emerald-100">
                Quantitative Core
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono">STABLE SYSTEM • VER 4.12.0 • SHA-512 ACTIVE</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-sm border border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Global Confidence:</span>
            <div className="flex gap-1.5">
              {[0.90, 0.95, 0.99].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => updateConfidence(lvl)}
                  className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded-xs transition-all ${
                    confidenceLevel === lvl
                      ? "bg-slate-900 text-white shadow-xs"
                      : "text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {(lvl * 100).toFixed(0)}%
                </button>
              ))}
            </div>
          </div>

          <div className="text-right">
            <p className="text-xs font-semibold text-slate-900">{roleMode}</p>
            <p className="text-[10px] text-slate-500">Secured: {calculationSeed}</p>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* --- SHINY-LIKE SIDEBAR NAVIGATION --- */}
        <aside id="sidebar-nav" className="w-68 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800">
          <div className="p-4 border-b border-slate-800">
            <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Analytics Modules (R-Shiny)</p>
          </div>
          
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            <button
              id="nav-executive"
              onClick={() => handleTabChange("executive")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "executive"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <TrendingUp size={15} />
              Executive Dashboard
            </button>

            <button
              id="nav-moe-ci"
              onClick={() => handleTabChange("moe_ci")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "moe_ci"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Calculator size={15} />
              Statistical Playground
            </button>

            <button
              id="nav-portfolio"
              onClick={() => handleTabChange("portfolio")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "portfolio"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Briefcase size={15} />
              Portfolio Analytics
            </button>

            <button
              id="nav-monte-carlo"
              onClick={() => handleTabChange("monte_carlo")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "monte_carlo"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Compass size={15} />
              Monte Carlo Engine
            </button>

            <button
              id="nav-bootstrap"
              onClick={() => handleTabChange("bootstrap")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "bootstrap"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Layers size={15} />
              Bootstrap Analysis
            </button>

            <button
              id="nav-credit"
              onClick={() => handleTabChange("credit")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "credit"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <ShieldAlert size={15} />
              Credit Risk Analytics
            </button>

            <button
              id="nav-treasury"
              onClick={() => handleTabChange("treasury")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "treasury"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Wallet size={15} />
              Treasury & Liquidity
            </button>

            <button
              id="nav-customer"
              onClick={() => handleTabChange("customer")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "customer"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Users size={15} />
              Customer Analytics
            </button>

            <button
              id="nav-stress"
              onClick={() => handleTabChange("stress")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "stress"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <Activity size={15} />
              Stress testing
            </button>

            <div className="my-4 border-t border-slate-800"></div>

            <button
              id="nav-reports"
              onClick={() => handleTabChange("reports")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "reports"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <FileText size={15} />
              Report Centre
            </button>

            <button
              id="nav-settings"
              onClick={() => handleTabChange("settings")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-xs font-semibold tracking-wide transition-all ${
                activeTab === "settings"
                  ? "bg-slate-800 text-white border-l-2 border-slate-400"
                  : "hover:bg-slate-800 hover:text-white text-slate-400"
              }`}
            >
              <SettingsIcon size={15} />
              Settings & Audit
            </button>
          </nav>

          {/* Quick action controls inside sidebar */}
          <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <p className="text-[10px] text-slate-400 font-semibold tracking-wider font-mono">CALCULATOR READY</p>
            </div>
            <button
              id="sidebar-csv-btn"
              onClick={handleCSVExport}
              className="w-full flex items-center justify-center gap-2 bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white px-3 py-2 rounded-xs text-[11px] font-bold border border-slate-700 transition-all"
            >
              <Download size={13} />
              Export Global Statistics
            </button>
          </div>
        </aside>

        {/* --- MAIN CORE WORKSPACE --- */}
        <main id="main-content" className="flex-1 p-8 overflow-y-auto max-w-7xl mx-auto w-full">
          {/* Active Navigation Header */}
          <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
            <div>
              <p className="text-[11px] font-bold tracking-widest text-slate-400 uppercase">Rhino Bank quantitative Suite</p>
              <h2 className="font-serif font-bold text-2xl text-slate-900 tracking-tight capitalize">
                {activeTab.replace("_", " & ")} Module
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-500">Active Confidence Threshold:</span>
              <span className="bg-slate-900 text-white px-2.5 py-1 text-xs font-mono font-bold rounded-xs tracking-wider">
                {(confidenceLevel * 100).toFixed(2)}%
              </span>
            </div>
          </div>

          {/* --- MODULE CONTENTS --- */}

          {/* 1. EXECUTIVE DASHBOARD MODULE */}
          {activeTab === "executive" && (
            <div id="executive-module" className="space-y-6">
              {/* Summary Stats Matrix */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-xs font-semibold text-slate-400 tracking-wide uppercase">Portfolio Annualised Return</p>
                  <div className="flex items-baseline gap-2 mt-2">
                    <span className="text-3xl font-serif font-black text-slate-900">
                      {(portfolioMetrics.annualReturn * 100).toFixed(2)}%
                    </span>
                    <span className="text-xs text-emerald-600 font-semibold">+{(portfolioMetrics.alpha * 100).toFixed(2)}% α</span>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-500 flex justify-between">
                    <span>CI [{(confidenceLevel * 100).toFixed(0)}%]:</span>
                    <span className="font-mono">
                      {(portfolioCI.ciLower * 12 * 100).toFixed(2)}% to {(portfolioCI.ciUpper * 12 * 100).toFixed(2)}%
                    </span>
                  </div>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-xs font-semibold text-slate-400 tracking-wide uppercase">Credit Book Expected Loss</p>
                  <div className="flex items-baseline gap-2 mt-2">
                    <span className="text-3xl font-serif font-black text-red-700">
                      {formatCurrency(creditStats.expectedLoss)}
                    </span>
                    <span className="text-xs text-slate-500 font-semibold">on {formatCurrency(creditStats.exposureAtDefault, 0)} EAD</span>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-500 flex justify-between">
                    <span>CI Bounds:</span>
                    <span className="font-mono text-red-600 font-medium">
                      {formatCurrency(creditStats.expectedLossLower)} - {formatCurrency(creditStats.expectedLossUpper)}
                    </span>
                  </div>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-xs font-semibold text-slate-400 tracking-wide uppercase">Treasury Reserves (Forecast 30D)</p>
                  <div className="flex items-baseline gap-2 mt-2">
                    <span className="text-3xl font-serif font-black text-slate-900">
                      {formatCurrency(SAMPLE_CASH_FLOWS[SAMPLE_CASH_FLOWS.length - 1].closingReserve)}
                    </span>
                    <span className="text-xs text-slate-500">Closing</span>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-500 flex justify-between">
                    <span>Stressed Min [99%]:</span>
                    <span className="font-mono text-amber-600 font-bold">
                      {formatCurrency(treasuryProjections[30].lowerBound99)}
                    </span>
                  </div>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-xs font-semibold text-slate-400 tracking-wide uppercase">Platform Reliability Score</p>
                  <div className="flex items-baseline gap-2 mt-2">
                    <span className="text-3xl font-serif font-black text-slate-900">{systemStabilityScore}%</span>
                    <span className="text-xs text-emerald-600 font-semibold">Robust</span>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-500 flex justify-between">
                    <span>Sample validation:</span>
                    <span className="font-semibold text-emerald-600">Passed</span>
                  </div>
                </div>
              </div>

              {/* Core Executive Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Portfolio Performance & Confidence Bands</h3>
                    <p className="text-xs text-slate-500">Historical performance with dynamic uncertainty envelopes</p>
                  </div>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={PORTFOLIO_RETURNS_DATA}>
                        <defs>
                          <linearGradient id="colorPort" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#1e293b" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#1e293b" stopOpacity={0.01}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="month" stroke="#94a3b8" fontSize={10} tickLine={false} />
                        <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} />
                        <Tooltip formatter={(v: any) => [`${(Number(v) * 100).toFixed(2)}%`]} />
                        <Legend verticalAlign="top" height={36} iconType="square" />
                        <Area type="monotone" name="Portfolio Performance" dataKey="portfolio" stroke="#0f172a" strokeWidth={2} fillOpacity={1} fill="url(#colorPort)" />
                        <Line type="monotone" name="Benchmark" dataKey="benchmark" stroke="#94a3b8" strokeWidth={1} strokeDasharray="4 4" dot={false} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Treasury Reserves 30-Day Outlook</h3>
                    <p className="text-xs text-slate-500">Expected liquidity with 95% and 99% confidence boundaries</p>
                  </div>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={treasuryProjections}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="day" name="Day" stroke="#94a3b8" fontSize={10} tickLine={false} />
                        <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} tickFormatter={(v) => `$${(v / 1000000).toFixed(0)}M`} />
                        <Tooltip formatter={(v: any) => [`$${(Number(v) / 1000000).toFixed(2)}M`]} />
                        <Area type="monotone" name="99% Confidence Band" dataKey="upperBound99" stroke="none" fill="#fef3c7" fillOpacity={0.5} />
                        <Area type="monotone" name="95% Confidence Band" dataKey="upperBound95" stroke="none" fill="#dbeafe" fillOpacity={0.7} />
                        <Area type="monotone" name="Expected Reserves" dataKey="expectedCash" stroke="#2563eb" strokeWidth={2.5} fill="none" />
                        <Area type="monotone" name="95% Min Limit" dataKey="lowerBound95" stroke="none" fill="#ffffff" fillOpacity={1.0} />
                        <Area type="monotone" name="99% Absolute Floor" dataKey="lowerBound99" stroke="none" fill="#ffffff" fillOpacity={1.0} />
                        <Legend verticalAlign="top" height={36} iconType="square" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Regulatory Validation and Audit Trail */}
              <div className="bg-white border border-slate-200 rounded-xs shadow-xs p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="text-emerald-600" size={18} />
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Model Validation & Internal Controls</h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">FRB SR 11-7 / CRD IV COMPLIANT</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xs">
                    <p className="text-xs font-bold text-slate-700">Sample Size Validation</p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Current sample sizes exceed Basel III minimums. Standard Error variance converges to optimal limits.
                    </p>
                    <div className="mt-3 flex items-center justify-between text-xs">
                      <span className="text-slate-500">Minimum Sample Size:</span>
                      <span className="font-mono font-bold text-slate-900">N=30</span>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xs">
                    <p className="text-xs font-bold text-slate-700">Confidence Band Convergence</p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Calculated critical value is <span className="font-mono font-bold">{portfolioCI.criticalValue.toFixed(4)}</span>. Width parameters are mathematically robust.
                    </p>
                    <div className="mt-3 flex items-center justify-between text-xs">
                      <span className="text-slate-500">Numerical Precision:</span>
                      <span className="font-mono font-bold text-emerald-600">Passed (1e-12)</span>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xs">
                    <p className="text-xs font-bold text-slate-700">Data Integrity Controls</p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      No convergence failures. Missing values handled via non-parametric robust weighting models.
                    </p>
                    <div className="mt-3 flex items-center justify-between text-xs">
                      <span className="text-slate-500">Data Quality Score:</span>
                      <span className="font-mono font-bold text-slate-900">98.2%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. STATISTICAL PLAYGROUND (MoE & CI) */}
          {activeTab === "moe_ci" && (
            <div id="moe-module" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Controls */}
              <div className="lg:col-span-4 bg-white p-6 border border-slate-200 rounded-xs shadow-xs space-y-5">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sliders size={16} className="text-slate-600" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase">Input Statistics</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Sample Size (n)</span>
                      <span className="font-mono text-slate-900 font-bold">{moeSampleSize}</span>
                    </label>
                    <input
                      type="range"
                      min={10}
                      max={1000}
                      value={moeSampleSize}
                      onChange={(e) => setMoeSampleSize(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Population Size (N) <span className="text-[9px] font-normal text-slate-400">(0 for infinite)</span></span>
                      <span className="font-mono text-slate-900 font-bold">{moePopSize || "Infinite"}</span>
                    </label>
                    <input
                      type="number"
                      value={moePopSize}
                      onChange={(e) => setMoePopSize(parseInt(e.target.value) || 0)}
                      className="w-full text-xs border border-slate-200 rounded-sm p-1.5 mt-1 font-mono focus:outline-none focus:border-slate-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Sample Mean (μ)</span>
                      <span className="font-mono text-slate-900 font-bold">{moeMean}</span>
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={moeMean}
                      onChange={(e) => setMoeMean(parseFloat(e.target.value) || 0)}
                      className="w-full text-xs border border-slate-200 rounded-sm p-1.5 mt-1 font-mono focus:outline-none focus:border-slate-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Sample Standard Deviation (s)</span>
                      <span className="font-mono text-slate-900 font-bold">{moeSD}</span>
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={100}
                      step="0.1"
                      value={moeSD}
                      onChange={(e) => setMoeSD(parseFloat(e.target.value) || 1)}
                      className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer mt-1"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600">Outliers Count</label>
                      <input
                        type="number"
                        min={0}
                        max={50}
                        value={moeOutliers}
                        onChange={(e) => setMoeOutliers(Math.max(0, parseInt(e.target.value) || 0))}
                        className="w-full text-xs border border-slate-200 rounded-sm p-1.5 mt-1 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600">Missing Obs.</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={moeMissing}
                        onChange={(e) => setMoeMissing(Math.max(0, parseInt(e.target.value) || 0))}
                        className="w-full text-xs border border-slate-200 rounded-sm p-1.5 mt-1 font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Confidence Level Override</h4>
                  <form onSubmit={handleCustomConfSubmit} className="flex gap-2">
                    <input
                      type="text"
                      value={customConf}
                      onChange={(e) => setCustomConf(e.target.value)}
                      placeholder="e.g. 0.95"
                      className="flex-1 text-xs border border-slate-200 rounded-sm px-2 py-1 font-mono focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="bg-slate-900 text-white px-3 py-1 rounded-sm text-xs font-semibold hover:bg-slate-800"
                    >
                      Apply
                    </button>
                  </form>
                </div>
              </div>

              {/* Analytical Outputs */}
              <div className="lg:col-span-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Margin of Error (MoE)</p>
                    <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                      ±{playgroundStats.marginOfError.toFixed(4)}
                    </p>
                    <p className="text-[11px] mt-1 text-slate-500 font-mono">
                      SE: {playgroundStats.standardError.toFixed(4)}
                    </p>
                  </div>

                  <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Confidence Interval</p>
                    <p className="text-2xl font-serif font-black text-slate-900 mt-2">
                      [{playgroundStats.ciLower.toFixed(2)}, {playgroundStats.ciUpper.toFixed(2)}]
                    </p>
                    <p className="text-[11px] mt-1 text-slate-500">
                      Width: {playgroundStats.ciWidth.toFixed(4)}
                    </p>
                  </div>

                  <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Critical Value (t* or z*)</p>
                    <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                      {playgroundStats.criticalValue.toFixed(4)}
                    </p>
                    <p className="text-[11px] mt-1 text-slate-500">
                      {moeSampleSize >= 1000 ? "Z Normal quantile" : `t quantile (df = ${moeSampleSize - 1})`}
                    </p>
                  </div>
                </div>

                {/* Plot of Width vs Confidence levels */}
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Margin of Error Sensitivity Comparison</h3>
                    <p className="text-xs text-slate-500">How Margin of Error and Confidence boundaries change with selected thresholds</p>
                  </div>

                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[0.90, 0.95, 0.975, 0.99, 0.995].map(lvl => {
                          const stats = calculate_statistical_uncertainty(
                            moeSampleSize, moeSD, moeMean, lvl, moePopSize > 0 ? moePopSize : undefined
                          );
                          return {
                            name: `${(lvl * 100).toFixed(1)}%`,
                            MoE: stats.marginOfError,
                            Lower: stats.ciLower,
                            Upper: stats.ciUpper
                          };
                        })}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip />
                        <Bar dataKey="MoE" name="Margin of Error" fill="#0f172a" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Validation warnings */}
                {playgroundStats.reliabilityScore < 45 && (
                  <div className="bg-amber-50 border border-amber-200 p-4 rounded-xs flex items-start gap-3">
                    <AlertTriangle className="text-amber-700 mt-0.5 shrink-0" size={16} />
                    <div>
                      <p className="text-xs font-bold text-amber-900">Unstable Statistical Reliability Warning</p>
                      <p className="text-[11px] text-amber-700 mt-1">
                        The calculated reliability score is low ({playgroundStats.reliabilityScore}%). High volatility, small sample size, or high missing ratios weaken the statistical validity. Basel standard requires larger sampling depths to guarantee regulatory approval.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. PORTFOLIO ANALYTICS MODULE */}
          {activeTab === "portfolio" && (
            <div id="portfolio-module" className="space-y-6">
              {/* Stats overview */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Annualised Volatility</p>
                  <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                    {(portfolioMetrics.volatility * 100).toFixed(2)}%
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">Benchmark: {(0.12 * 100).toFixed(2)}%</p>
                </div>

                <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Sharpe Ratio</p>
                  <p className="text-2xl font-serif font-black text-emerald-700 mt-1">
                    {portfolioMetrics.sharpeRatio.toFixed(2)}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">Risk Free Rate used: 2.5%</p>
                </div>

                <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Beta & Tracking Error</p>
                  <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                    β {portfolioMetrics.beta.toFixed(2)}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">Tracking Error: {(portfolioMetrics.trackingError * 100).toFixed(2)}%</p>
                </div>

                <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Parametric VaR (95%)</p>
                  <p className="text-2xl font-serif font-black text-red-700 mt-1">
                    {(portfolioMetrics.var95 * 100).toFixed(2)}%
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">Estimated annual limit</p>
                </div>
              </div>

              {/* Chart: Active returns comparison vs benchmark */}
              <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                <div className="mb-4">
                  <h3 className="text-sm font-bold text-slate-900 uppercase">Return Scatter & Linear Regression Space</h3>
                  <p className="text-xs text-slate-500">Comparing active portfolio returns vs global benchmark (n=60 monthly observations)</p>
                </div>

                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart margin={{ top: 10, right: 30, left: 20, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis type="number" dataKey="benchmark" name="Benchmark Return" stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} label={{ value: 'Benchmark Return', position: 'bottom', offset: 0, style: { fontSize: 10, fill: '#64748b' } }} />
                      <YAxis type="number" dataKey="portfolio" name="Portfolio Return" stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} label={{ value: 'Portfolio Return', angle: -90, position: 'left', style: { fontSize: 10, fill: '#64748b' } }} />
                      <Tooltip formatter={(value) => `${(Number(value) * 100).toFixed(2)}%`} cursor={{ strokeDasharray: '3 3' }} />
                      <Scatter name="Monthly Returns" data={PORTFOLIO_RETURNS_DATA} fill="#0f172a" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Technical confidence analysis */}
              <div className="bg-white p-6 border border-slate-200 rounded-xs">
                <h3 className="text-xs font-bold text-slate-900 uppercase mb-3">Auditable Portfolio Return Metrics</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400">
                        <th className="pb-2 font-semibold">Parameter</th>
                        <th className="pb-2 font-semibold text-right">Estimate</th>
                        <th className="pb-2 font-semibold text-right">Standard Error</th>
                        <th className="pb-2 font-semibold text-right">Confidence Level</th>
                        <th className="pb-2 font-semibold text-right">Lower Bound</th>
                        <th className="pb-2 font-semibold text-right">Upper Bound</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono">
                      <tr>
                        <td className="py-3 font-semibold text-slate-900">Average Portfolio return (Monthly)</td>
                        <td className="py-3 text-right">{(portfolioCI.mean * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">{(portfolioCI.standardError * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">{(confidenceLevel * 100).toFixed(1)}%</td>
                        <td className="py-3 text-right">{(portfolioCI.ciLower * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">{(portfolioCI.ciUpper * 100).toFixed(4)}%</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-semibold text-slate-900">Annualised Return Equivalent</td>
                        <td className="py-3 text-right">{(portfolioCI.mean * 12 * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">{(portfolioCI.standardError * 12 * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">{(confidenceLevel * 100).toFixed(1)}%</td>
                        <td className="py-3 text-right">{(portfolioCI.ciLower * 12 * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">{(portfolioCI.ciUpper * 12 * 100).toFixed(4)}%</td>
                      </tr>
                      <tr>
                        <td className="py-3 font-semibold text-slate-900">Alpha (Jensen's α)</td>
                        <td className="py-3 text-right">{(portfolioMetrics.alpha * 100).toFixed(4)}%</td>
                        <td className="py-3 text-right">N/A</td>
                        <td className="py-3 text-right">N/A</td>
                        <td className="py-3 text-right">N/A</td>
                        <td className="py-3 text-right">N/A</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 4. MONTE CARLO ENGINE MODULE */}
          {activeTab === "monte_carlo" && (
            <div id="monte-carlo-module" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Controls */}
              <div className="lg:col-span-4 bg-white p-6 border border-slate-200 rounded-xs shadow-xs space-y-5">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sliders size={16} className="text-slate-600" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase">GBM Parameters</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Simulation Paths</span>
                      <span className="font-mono text-slate-900 font-bold">{numPaths} runs</span>
                    </label>
                    <input
                      type="range"
                      min={100}
                      max={5000}
                      step={100}
                      value={numPaths}
                      onChange={(e) => setNumPaths(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Volatility (Annualized)</span>
                      <span className="font-mono text-slate-900 font-bold">{(portfolioMetrics.volatility * 100).toFixed(1)}%</span>
                    </label>
                    <p className="text-[10px] text-slate-400">Locked to historical portfolio standard deviation</p>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Expected Portfolio Growth (Drift)</span>
                      <span className="font-mono text-slate-900 font-bold">{(portfolioMetrics.annualReturn * 100).toFixed(1)}%</span>
                    </label>
                    <p className="text-[10px] text-slate-400">Derived from 60-month annualized history</p>
                  </div>

                  <div className="pt-4 border-t border-slate-100 space-y-2">
                    <p className="text-[11px] font-bold text-slate-500 uppercase">Information</p>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      This engine uses standard Geometric Brownian Motion (GBM) driven by a pseudo-random seed to generate terminal valuation distributions.
                    </p>
                  </div>
                </div>
              </div>

              {/* Output graphs & Risk indicators */}
              <div className="lg:col-span-8 space-y-6">
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Geometric Brownian Motion (GBM) Pathways</h3>
                    <p className="text-xs text-slate-500">Representative subset paths with standard confidence bounds (95% area envelope)</p>
                  </div>

                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={monteCarloResult.timeSteps.map((t, idx) => {
                          const item: any = { time: t.toFixed(2) };
                          item.Lower = monteCarloResult.lowerEnvelope[idx];
                          item.Upper = monteCarloResult.upperEnvelope[idx];
                          item.Mean = monteCarloResult.meanPath[idx];
                          // Adding path overrides
                          monteCarloResult.paths.forEach((p, pIdx) => {
                            item[`path_${pIdx}`] = p.values[idx];
                          });
                          return item;
                        })}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="time" stroke="#94a3b8" fontSize={10} label={{ value: 'Simulation Horizon (Years)', position: 'bottom', offset: 0, style: { fontSize: 10 } }} />
                        <YAxis stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `$${(v / 1000000).toFixed(1)}M`} />
                        <Tooltip formatter={(v: any) => [`$${(Number(v) / 1000000).toFixed(3)}M`]} />
                        <Area type="monotone" name="Confidence Envelope" dataKey="Upper" stroke="none" fill="#f1f5f9" fillOpacity={1.0} />
                        <Area type="monotone" name="Mean trajectory" dataKey="Mean" stroke="#000000" strokeWidth={2.5} fill="none" />
                        <Area type="monotone" name="Confidence lower bound" dataKey="Lower" stroke="none" fill="#ffffff" fillOpacity={1.0} />
                        {/* Selected individual paths */}
                        {Array.from({ length: 6 }).map((_, i) => (
                          <Line
                            key={i}
                            type="monotone"
                            dataKey={`path_${i}`}
                            stroke={`#cbd5e1`}
                            strokeWidth={0.8}
                            dot={false}
                          />
                        ))}
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Simulated VaR statistics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-5 border border-slate-200 rounded-xs">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Simulated 95% VaR</p>
                    <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                      {(monteCarloResult.var95 * 100).toFixed(2)}%
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">Minimum loss threshold at 95% limits</p>
                  </div>

                  <div className="bg-white p-5 border border-slate-200 rounded-xs">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Simulated 99% VaR</p>
                    <p className="text-2xl font-serif font-black text-red-700 mt-1">
                      {(monteCarloResult.var99 * 100).toFixed(2)}%
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">Stressed extreme loss boundary</p>
                  </div>

                  <div className="bg-white p-5 border border-slate-200 rounded-xs">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Simulated 95% CVaR</p>
                    <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                      {(monteCarloResult.cvar95 * 100).toFixed(2)}%
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">Expected shortfall in tail scenarios</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. BOOTSTRAP RESAMPLING MODULE */}
          {activeTab === "bootstrap" && (
            <div id="bootstrap-module" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Controls */}
              <div className="lg:col-span-4 bg-white p-6 border border-slate-200 rounded-xs shadow-xs space-y-5">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sliders size={16} className="text-slate-600" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase">Bootstrap Specs</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Replications (B)</span>
                      <span className="font-mono text-slate-900 font-bold">{bootstrapReps} times</span>
                    </label>
                    <input
                      type="range"
                      min={100}
                      max={2000}
                      step={100}
                      value={bootstrapReps}
                      onChange={(e) => setBootstrapReps(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 mt-1"
                    />
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xs">
                    <p className="text-xs font-bold text-slate-700">Non-Parametric Analysis</p>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Resampling without parametric assumptions avoids assumptions of normality. Perfect for heavy-tailed credit and asset returns.
                    </p>
                  </div>
                </div>
              </div>

              {/* Analytical Output */}
              <div className="lg:col-span-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs text-center">
                    <p className="text-xs font-bold text-slate-400 uppercase">Observed Portfolio Mean</p>
                    <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                      {(bootstrapResult.observed * 100).toFixed(4)}%
                    </p>
                    <p className="text-[10px] text-slate-500">Unbiased sample estimate</p>
                  </div>

                  <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs text-center">
                    <p className="text-xs font-bold text-slate-400 uppercase">Bootstrap Std. Error</p>
                    <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                      {(bootstrapResult.standardError * 100).toFixed(4)}%
                    </p>
                    <p className="text-[10px] text-slate-500">Empirical variation</p>
                  </div>

                  <div className="bg-white p-5 border border-slate-200 rounded-xs shadow-xs text-center">
                    <p className="text-xs font-bold text-slate-400 uppercase">Bias Factor</p>
                    <p className="text-2xl font-serif font-black text-slate-900 mt-1">
                      {(bootstrapResult.bias * 100).toFixed(5)}%
                    </p>
                    <p className="text-[10px] text-slate-500">Observed vs Mean replication</p>
                  </div>
                </div>

                {/* Bootstrap Distribution Chart */}
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Bootstrap Replications Distribution</h3>
                    <p className="text-xs text-slate-500">Histogram of simulated portfolio means (B={bootstrapReps}) with confidence intervals</p>
                  </div>

                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={(() => {
                          const bucketSize = 0.0005;
                          const reps = bootstrapResult.replications;
                          const min = reps[0];
                          const max = reps[reps.length - 1];
                          const buckets: { [key: string]: number } = {};
                          for (let val of reps) {
                            const bKey = Math.floor(val / bucketSize) * bucketSize;
                            buckets[bKey] = (buckets[bKey] || 0) + 1;
                          }
                          return Object.keys(buckets).map(k => ({
                            bin: (parseFloat(k) * 100).toFixed(2) + "%",
                            Frequency: buckets[k],
                            raw: parseFloat(k)
                          })).sort((a, b) => a.raw - b.raw);
                        })()}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="bin" stroke="#94a3b8" fontSize={9} />
                        <YAxis stroke="#94a3b8" fontSize={9} />
                        <Tooltip />
                        <Bar dataKey="Frequency" fill="#0f172a" name="Replications" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xs flex justify-between text-xs text-slate-600 font-mono">
                    <span>CI Lower limit: <strong className="text-slate-900">{(bootstrapResult.ciLower * 100).toFixed(4)}%</strong></span>
                    <span>CI Upper limit: <strong className="text-slate-900">{(bootstrapResult.ciUpper * 100).toFixed(4)}%</strong></span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 6. CREDIT RISK ANALYTICS MODULE */}
          {activeTab === "credit" && (
            <div id="credit-module" className="space-y-6">
              {/* Sector Selector */}
              <div className="bg-white p-4 border border-slate-200 rounded-xs shadow-xs flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-600">Filter Credit Portfolio by Sector:</span>
                <select
                  value={selectedSector}
                  onChange={(e) => setSelectedSector(e.target.value)}
                  className="text-xs border border-slate-200 rounded-sm p-1.5 font-mono focus:outline-none focus:border-slate-400"
                >
                  <option value="All">All Sectors (200 loans)</option>
                  <option value="Commercial Real Estate">Commercial Real Estate</option>
                  <option value="Technology & Retail">Technology & Retail</option>
                  <option value="Industrial & Logistics">Industrial & Logistics</option>
                  <option value="Infrastructure & Energy">Infrastructure & Energy</option>
                  <option value="Financial Services">Financial Services</option>
                  <option value="Consumer Finance">Consumer Finance</option>
                </select>
              </div>

              {/* Analytical Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Probability of Default (PD)</p>
                  <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                    {(creditStats.averagePD * 100).toFixed(3)}%
                  </p>
                  <p className="text-[11px] mt-1 text-slate-500 font-mono">
                    CI Boundary: [{(creditStats.pdLower * 100).toFixed(2)}% - {(creditStats.pdUpper * 100).toFixed(2)}%]
                  </p>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Loss Given Default (LGD)</p>
                  <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                    {(creditStats.averageLGD * 100).toFixed(2)}%
                  </p>
                  <p className="text-[11px] mt-1 text-slate-500 font-mono">
                    CI Boundary: [{(creditStats.lgdLower * 100).toFixed(2)}% - {(creditStats.lgdUpper * 100).toFixed(2)}%]
                  </p>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Concentration Index (HHI)</p>
                  <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                    {creditStats.concentrationHHI.toFixed(1)}
                  </p>
                  <p className="text-[11px] mt-1 text-slate-500">
                    {creditStats.concentrationHHI < 1500 ? "Highly diversified" : "Moderate concentration"}
                  </p>
                </div>
              </div>

              {/* Chart: Credit risk sector analysis */}
              <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                <div className="mb-4">
                  <h3 className="text-sm font-bold text-slate-900 uppercase">Sector Risk Breakdown & EL Projections</h3>
                  <p className="text-xs text-slate-500">Total exposure vs. Expected loss across commercial portfolios</p>
                </div>

                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sectorRiskDistribution}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={9} />
                      <YAxis stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `$${v}M`} />
                      <Tooltip formatter={(value) => `$${Number(value).toFixed(2)}M`} />
                      <Legend />
                      <Bar dataKey="exposure" name="Total Exposure (EAD)" fill="#475569" />
                      <Bar dataKey="loss" name="Expected Credit Loss" fill="#b91c1c" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 7. TREASURY MODULE */}
          {activeTab === "treasury" && (
            <div id="treasury-module" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Controls */}
              <div className="lg:col-span-4 bg-white p-6 border border-slate-200 rounded-xs shadow-xs space-y-5">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sliders size={16} className="text-slate-600" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase">Reserves Stress Params</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Starting Liquidity Reserve</span>
                      <span className="font-mono text-slate-900 font-bold">${(cashStarting / 1000000).toFixed(0)}M</span>
                    </label>
                    <input
                      type="range"
                      min={100000000}
                      max={800000000}
                      step={50000000}
                      value={cashStarting}
                      onChange={(e) => setCashStarting(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Expected Net Daily Flow</span>
                      <span className="font-mono text-slate-900 font-bold">${(cashDailyFlow / 1000).toFixed(0)}K</span>
                    </label>
                    <input
                      type="range"
                      min={-5000000}
                      max={5000000}
                      step={250000}
                      value={cashDailyFlow}
                      onChange={(e) => setCashDailyFlow(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 flex justify-between">
                      <span>Daily Flow Volatility</span>
                      <span className="font-mono text-slate-900 font-bold">${(cashVolatility / 1000000).toFixed(1)}M</span>
                    </label>
                    <input
                      type="range"
                      min={1000000}
                      max={15000000}
                      step={500000}
                      value={cashVolatility}
                      onChange={(e) => setCashVolatility(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* Outputs */}
              <div className="lg:col-span-8 space-y-6">
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                  <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase">30-Day Cash Reserves Scenario Bands</h3>
                    <p className="text-xs text-slate-500">Simulated daily liquidity boundaries highlighting standard and extreme stress thresholds</p>
                  </div>

                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={treasuryProjections}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="day" stroke="#94a3b8" fontSize={10} />
                        <YAxis stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `$${(v / 1000000).toFixed(0)}M`} />
                        <Tooltip formatter={(v: any) => [`$${(Number(v) / 1000000).toFixed(2)}M`]} />
                        <Area type="monotone" name="Stressed Range (99%)" dataKey="upperBound99" stroke="none" fill="#fee2e2" fillOpacity={0.4} />
                        <Area type="monotone" name="Standard Deviation (95%)" dataKey="upperBound95" stroke="none" fill="#e0f2fe" fillOpacity={0.6} />
                        <Area type="monotone" name="Expected reserves path" dataKey="expectedCash" stroke="#0284c7" strokeWidth={2} fill="none" />
                        <Area type="monotone" name="Lower bounds 95%" dataKey="lowerBound95" stroke="none" fill="#ffffff" fillOpacity={1.0} />
                        <Area type="monotone" name="Lower bounds 99%" dataKey="lowerBound99" stroke="none" fill="#ffffff" fillOpacity={1.0} />
                        <Legend />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 8. CUSTOMER ANALYTICS MODULE */}
          {activeTab === "customer" && (
            <div id="customer-module" className="space-y-6">
              {/* Filter */}
              <div className="bg-white p-4 border border-slate-200 rounded-xs shadow-xs flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-600">Filter Customer Cohorts:</span>
                <select
                  value={selectedCustomerTier}
                  onChange={(e) => setSelectedCustomerTier(e.target.value)}
                  className="text-xs border border-slate-200 rounded-sm p-1.5 font-mono focus:outline-none"
                >
                  <option value="All">All Customer Segments</option>
                  <option value="Wealth">Wealth Portfolio (HNW)</option>
                  <option value="Premier">Premier Accounts</option>
                  <option value="Retail">Retail Accounts</option>
                  <option value="SME">SME Portfolio</option>
                </select>
              </div>

              {/* Outputs */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Estimated Cohort CLV Mean</p>
                  <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                    {formatCurrency(customerStats.clvMean)}
                  </p>
                  <p className="text-[11px] mt-1 text-slate-500 font-mono">
                    CI: [{formatCurrency(customerStats.clvLower)} - {formatCurrency(customerStats.clvUpper)}]
                  </p>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Expected Deposit Growth (Mo.)</p>
                  <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                    {(customerStats.monthlyDepositGrowthMean * 100).toFixed(3)}%
                  </p>
                  <p className="text-[11px] mt-1 text-slate-500 font-mono">
                    CI: [{(customerStats.monthlyDepositGrowthLower * 100).toFixed(2)}% - {(customerStats.monthlyDepositGrowthUpper * 100).toFixed(2)}%]
                  </p>
                </div>

                <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs text-center">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Cohort Retention Rate</p>
                  <p className="text-3xl font-serif font-black text-slate-900 mt-2">
                    {(customerStats.retentionRate * 100).toFixed(2)}%
                  </p>
                  <p className="text-[11px] mt-1 text-slate-500">
                    Calculated from active cohort tenure
                  </p>
                </div>
              </div>

              {/* Savings bal distribution bar chart */}
              <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                <div className="mb-4">
                  <h3 className="text-sm font-bold text-slate-900 uppercase">Savings balance spectrum</h3>
                  <p className="text-xs text-slate-500">Aggregated cohort cash distribution inside Rhino Bank</p>
                </div>

                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={(() => {
                        const segments = ["<$10K", "$10K-$50K", "$50K-$250K", "$250K+"];
                        const counts = [0, 0, 0, 0];
                        filteredCustomers.forEach(c => {
                          if (c.savingsBalance < 10000) counts[0]++;
                          else if (c.savingsBalance < 50000) counts[1]++;
                          else if (c.savingsBalance < 250000) counts[2]++;
                          else counts[3]++;
                        });
                        return segments.map((seg, i) => ({ name: seg, Accounts: counts[i] }));
                      })()}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                      <YAxis stroke="#94a3b8" fontSize={10} />
                      <Tooltip />
                      <Bar dataKey="Accounts" fill="#1e293b" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 9. STRESS & SCENARIO ANALYSIS MODULE */}
          {activeTab === "stress" && (
            <div id="stress-module" className="space-y-6">
              <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs">
                <h3 className="text-sm font-bold text-slate-900 uppercase mb-3">Historical Macro-Economic Stress Simulators</h3>
                <p className="text-xs text-slate-500 mb-5 leading-relaxed">
                  Apply historical shock environments to the portfolio standard parameters to calculate the adjusted Margin of Error and see if the portfolio values remain within Basel safety guidelines.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-5 border border-slate-200 bg-slate-50 rounded-xs hover:border-slate-400 transition-all cursor-pointer">
                    <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-100 px-2 py-0.5 rounded-sm uppercase font-mono">STRESS MODEL</span>
                    <h4 className="text-sm font-bold text-slate-900 mt-2">2008 Lehman GFC Collapse</h4>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Increases annualized portfolio volatility by 2.5x and reduces expected annual returns to -18.5%.
                    </p>
                    <button
                      onClick={() => {
                        setMoeSD(38.0);
                        setMoeMean(-18.5);
                        addLog("Stress Testing", "System", "Applied Lehman GFC Stress Shock parameters.");
                        setActiveTab("moe_ci");
                      }}
                      className="mt-4 text-xs font-bold text-slate-900 hover:underline flex items-center gap-1.5"
                    >
                      Apply parameters to Playground &rarr;
                    </button>
                  </div>

                  <div className="p-5 border border-slate-200 bg-slate-50 rounded-xs hover:border-slate-400 transition-all cursor-pointer">
                    <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-100 px-2 py-0.5 rounded-sm uppercase font-mono">STRESS MODEL</span>
                    <h4 className="text-sm font-bold text-slate-900 mt-2">2020 COVID Liquidity Freeze</h4>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Sets starting treasury net flow to negative limits and multiplies daily cash outflow volatility by 4.0x.
                    </p>
                    <button
                      onClick={() => {
                        setCashDailyFlow(-4500000);
                        setCashVolatility(14500000);
                        addLog("Stress Testing", "System", "Applied 2020 COVID Liquidity Shock parameters.");
                        setActiveTab("treasury");
                      }}
                      className="mt-4 text-xs font-bold text-slate-900 hover:underline flex items-center gap-1.5"
                    >
                      Apply parameters to Treasury &rarr;
                    </button>
                  </div>

                  <div className="p-5 border border-slate-200 bg-slate-50 rounded-xs hover:border-slate-400 transition-all cursor-pointer">
                    <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-100 px-2 py-0.5 rounded-sm uppercase font-mono">STRESS MODEL</span>
                    <h4 className="text-sm font-bold text-slate-900 mt-2">1970s Style Stagflation Shock</h4>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Elevates standard error and outlier bounds across customers, compressing overall growth indices to 0.1%.
                    </p>
                    <button
                      onClick={() => {
                        setMoeSD(25.0);
                        setMoeMean(0.1);
                        setMoeOutliers(15);
                        addLog("Stress Testing", "System", "Applied 1970s Stagflation Shock parameters.");
                        setActiveTab("moe_ci");
                      }}
                      className="mt-4 text-xs font-bold text-slate-900 hover:underline flex items-center gap-1.5"
                    >
                      Apply parameters to Playground &rarr;
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 10. REPORT CENTRE MODULE */}
          {activeTab === "reports" && (
            <div id="reports-module" className="space-y-6">
              <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Institutional Committee Reports Generator</h3>
                    <p className="text-xs text-slate-500">Board-ready risk documentation with mathematical derivations</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => window.print()}
                      className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xs text-xs font-bold transition-all border border-slate-200"
                    >
                      <Printer size={13} />
                      Print / Save PDF
                    </button>
                    <button
                      onClick={handleCSVExport}
                      className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-3 py-1.5 rounded-xs text-xs font-bold transition-all"
                    >
                      <Download size={13} />
                      Download Raw CSV
                    </button>
                  </div>
                </div>

                {/* Simulated Audit-Grade Report Canvas */}
                <div className="border border-slate-200 bg-slate-50 p-8 rounded-xs font-serif text-slate-900 max-w-4xl mx-auto space-y-6 shadow-xs leading-relaxed">
                  {/* Header */}
                  <div className="text-center border-b-2 border-slate-900 pb-5 space-y-1">
                    <p className="text-xs tracking-widest font-sans font-black text-slate-400 uppercase">RHINO BANK LIMITED</p>
                    <h4 className="text-xl font-bold font-serif">QUANTITATIVE RISK & COMPLIANCE COMMITTEE REPORT</h4>
                    <p className="text-[10px] font-sans text-slate-500">
                      PREPARED BY INDEPENDENT QUANTITATIVE MODEL VALIDATION DESK • COMPLIES WITH BCBS 239 STANDARDS
                    </p>
                  </div>

                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-4 text-xs font-sans border-b border-slate-200 pb-4">
                    <div>
                      <p><strong>Date of Calculation:</strong> {new Date().toLocaleDateString()}</p>
                      <p><strong>Model Authority:</strong> FRB SR 11-7 validation guidelines</p>
                    </div>
                    <div className="text-right">
                      <p><strong>System Confidence Bound:</strong> {(confidenceLevel * 100).toFixed(2)}%</p>
                      <p><strong>Execution Reference:</strong> RN-ENG-VAL-88219</p>
                    </div>
                  </div>

                  {/* Exec Summary Section */}
                  <div className="space-y-2">
                    <h5 className="font-sans font-black text-xs uppercase tracking-wide text-slate-500">I. EXECUTIVE RISK STATEMENT</h5>
                    <p className="text-sm font-serif">
                      Following robust mathematical audit across active portfolios, the desk confirms the overall asset margin parameters fall well within expected risk thresholds. At the requested <strong>{(confidenceLevel * 100).toFixed(1)}% confidence interval</strong>, the historical volatility converges to <strong>{(portfolioMetrics.volatility * 100).toFixed(2)}% annualized</strong>.
                    </p>
                  </div>

                  {/* Analytical Table */}
                  <div className="space-y-3 pt-3">
                    <h5 className="font-sans font-black text-xs uppercase tracking-wide text-slate-500">II. AUDITABLE PARAMETER BOUNDARIES</h5>
                    <table className="w-full text-xs font-sans text-left border-collapse border border-slate-200">
                      <thead>
                        <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                          <th className="p-2 border border-slate-200">Indicator</th>
                          <th className="p-2 border border-slate-200 text-right">Point Estimate</th>
                          <th className="p-2 border border-slate-200 text-right">Standard Error</th>
                          <th className="p-2 border border-slate-200 text-right">Critical Limit</th>
                          <th className="p-2 border border-slate-200 text-right">Lower Limit</th>
                          <th className="p-2 border border-slate-200 text-right">Upper Limit</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                        <tr>
                          <td className="p-2 font-sans font-semibold">Mean Portfolio Return (Mo.)</td>
                          <td className="p-2 text-right">{(portfolioCI.mean * 100).toFixed(4)}%</td>
                          <td className="p-2 text-right">{(portfolioCI.standardError * 100).toFixed(4)}%</td>
                          <td className="p-2 text-right">{portfolioCI.criticalValue.toFixed(3)}</td>
                          <td className="p-2 text-right">{(portfolioCI.ciLower * 100).toFixed(4)}%</td>
                          <td className="p-2 text-right">{(portfolioCI.ciUpper * 100).toFixed(4)}%</td>
                        </tr>
                        <tr>
                          <td className="p-2 font-sans font-semibold">Credit Probability of Default (PD)</td>
                          <td className="p-2 text-right">{(creditStats.averagePD * 100).toFixed(3)}%</td>
                          <td className="p-2 text-right">{(creditStats.pdUpper - creditStats.averagePD).toFixed(4)}%</td>
                          <td className="p-2 text-right">{portfolioCI.criticalValue.toFixed(3)}</td>
                          <td className="p-2 text-right">{(creditStats.pdLower * 100).toFixed(2)}%</td>
                          <td className="p-2 text-right">{(creditStats.pdUpper * 100).toFixed(2)}%</td>
                        </tr>
                        <tr>
                          <td className="p-2 font-sans font-semibold">Customer Lifetime Value (CLV)</td>
                          <td className="p-2 text-right">{formatCurrency(customerStats.clvMean)}</td>
                          <td className="p-2 text-right">N/A</td>
                          <td className="p-2 text-right">{portfolioCI.criticalValue.toFixed(3)}</td>
                          <td className="p-2 text-right">{formatCurrency(customerStats.clvLower)}</td>
                          <td className="p-2 text-right">{formatCurrency(customerStats.clvUpper)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Validation signatures */}
                  <div className="pt-10 grid grid-cols-2 gap-10 text-xs font-sans">
                    <div className="border-t border-slate-400 pt-3 text-center">
                      <p className="font-bold">Valentin Rhino, PhD</p>
                      <p className="text-slate-500">Head of Model Validation Unit</p>
                    </div>
                    <div className="border-t border-slate-400 pt-3 text-center">
                      <p className="font-bold">Patricia Quant, FSA</p>
                      <p className="text-slate-500">Chief Risk Officer (CRO)</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 11. SETTINGS & AUDIT MODULE */}
          {activeTab === "settings" && (
            <div id="settings-module" className="space-y-6">
              <div className="bg-white p-6 border border-slate-200 rounded-xs shadow-xs space-y-6">
                <h3 className="text-sm font-bold text-slate-900 uppercase border-b border-slate-100 pb-3">Platform Configurations</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-600 block">Calculation Seed & Version Control</label>
                    <input
                      type="text"
                      value={calculationSeed}
                      onChange={(e) => setCalculationSeed(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-sm p-2 font-mono"
                    />
                    <p className="text-[11px] text-slate-400">Forces mathematical pseudo-random seeds to stay consistent for reproducibility checks.</p>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-600 block">Active Auditor Persona</label>
                    <select
                      value={roleMode}
                      onChange={(e) => setRoleMode(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-sm p-2 font-mono focus:outline-none"
                    >
                      <option value="Chief Risk Officer (CRO)">Chief Risk Officer (CRO)</option>
                      <option value="Quantitative Analyst">Quantitative Analyst</option>
                      <option value="Internal Auditor">Internal Auditor</option>
                      <option value="Regulator Desk Officer">Regulator Desk Officer</option>
                    </select>
                  </div>
                </div>

                {/* Audit trail list */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Immutable Calculation Audit History</h4>
                    <button
                      onClick={() => setAuditLogs([])}
                      className="text-[11px] font-bold text-red-600 hover:underline"
                    >
                      Clear Log
                    </button>
                  </div>

                  <div className="border border-slate-200 rounded-xs bg-slate-50 max-h-64 overflow-y-auto font-mono text-[10px] divide-y divide-slate-100">
                    {auditLogs.length === 0 ? (
                      <p className="p-4 text-slate-400 text-center">No calculations executed yet.</p>
                    ) : (
                      auditLogs.map((log, i) => (
                        <div key={i} className="p-3 flex items-start gap-4 hover:bg-slate-100">
                          <span className="text-slate-400 shrink-0">{log.timestamp}</span>
                          <span className="text-slate-500 font-bold shrink-0">[{log.module}]</span>
                          <span className="font-semibold text-slate-700 shrink-0">{log.action}:</span>
                          <span className="text-slate-600">{log.details}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* --- FOOTER REGULATORY NOTICES --- */}
      <footer id="regulatory-footer" className="bg-slate-900 border-t border-slate-800 text-slate-500 text-[11px] p-6 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="leading-relaxed">
            &copy; 2026 Rhino Bank Limited. All quantitative calculations, variance projections, and confidence intervals are strictly intended for internal institutional validation under Basel Accords. Do not redistribute without written consent from the Risk Committee.
          </p>
          <div className="flex items-center gap-3 font-mono shrink-0">
            <span className="flex items-center gap-1.5"><Lock size={11} className="text-emerald-500" /> SECURE-SSL</span>
            <span>AUDIT-LOG: ENABLED</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
