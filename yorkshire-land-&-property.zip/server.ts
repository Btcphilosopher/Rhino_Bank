import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Initialize environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Shared properties database matching our data.ts exactly for server-side report generation
const PROPERTIES_DATABASE = [
  {
    id: "prop-1",
    title: "The Calder Logistics & Freight Terminal",
    type: "Logistics Park",
    town: "Doncaster",
    county: "South Yorkshire",
    postcode: "DN11 8SP",
    price: 18500000,
    tenure: "Freehold",
    floorAreaSqFt: 245000,
    landAreaAcres: 18.4,
    planningStatus: "Full Approval",
    developmentPotential: "Outline planning secured for an additional 80,000 sq ft logistics unit with 15m eaves height.",
    industrialClassification: "B8 (Storage or Distribution)",
    environmentalRating: "B",
    railAccess: true,
    railAccessDistance: 0.2,
    motorwayAccess: true,
    motorwayAccessDistance: 1.1,
    airportAccess: true,
    airportAccessDistance: 8.5,
    description: "An exceptional, institutional-grade logistics park. Completed in 2021, the terminal serves as a critical national distribution hub. Features include 24 dock-level loading doors, 50m secure service yards, ESFR sprinkler systems, and a dedicated rail freight siding connected directly to the East Coast Main Line. Currently let to a global logistics operator with an unexpired lease term (WAULT) of 14.5 years.",
    nearbyInvestment: "Part of the Doncaster Inland Port Masterplan, benefiting from a £120m regional transport infrastructure upgrade."
  },
  {
    id: "prop-2",
    title: "Wharfedale Agricultural & Forestry Estate",
    type: "Agricultural Land",
    town: "Grassington",
    county: "North Yorkshire",
    postcode: "BD23 5LQ",
    price: 4950000,
    tenure: "Freehold",
    landAreaAcres: 1240,
    planningStatus: "Agricultural Use",
    developmentPotential: "Significant carbon sequestration, peatland restoration, and high-yielding woodland creation potential. Tenancy-free possession available.",
    environmentalRating: "A",
    railAccess: false,
    motorwayAccess: false,
    airportAccess: false,
    description: "A breathtaking and historically significant upland estate spanning 1,240 acres of highly productive limestone pasture, deep peat moorland, and commercial coniferous forestry. Includes an original 17th-century stone farmstead, five let agricultural cottages, and extensive shooting and mineral rights. Managed strictly under an environmental enhancement framework with excellent subsidy streams.",
    nearbyInvestment: "Yorkshire Dales Biodiversity Fund matches environmental restoration capital at a 1.2x ratio."
  },
  {
    id: "prop-3",
    title: "Airedale Science & Biotech Park",
    type: "Science Park",
    town: "Leeds",
    county: "West Yorkshire",
    postcode: "LS2 9JT",
    price: 34200000,
    tenure: "Freehold",
    floorAreaSqFt: 112000,
    landAreaAcres: 4.8,
    planningStatus: "Full Approval",
    developmentPotential: "Full planning granted for Phase 3: a 45,000 sq ft Class II Wet Lab and cleanroom workspace.",
    industrialClassification: "E(g)(ii) (Research & Development)",
    environmentalRating: "A",
    railAccess: true,
    railAccessDistance: 0.8,
    motorwayAccess: true,
    motorwayAccessDistance: 1.5,
    airportAccess: true,
    airportAccessDistance: 9.0,
    description: "An ultra-premium research and science park located in the Innovation Arc of Leeds. The complex consists of three high-specification buildings featuring state-of-the-art laboratory spaces, sterile climate-controlled rooms, and Grade-A creative incubation workspaces. Tenanted by leading oncology research organizations and University of Leeds spin-outs, boasting exceptional retention rates and net-initial yields of 6.8%.",
    nearbyInvestment: "Leeds Innovation Arc is the recipient of a £450m joint private-public expansion venture."
  },
  {
    id: "prop-4",
    title: "The Don Valley Heavy Industrial Complex",
    type: "Factory",
    town: "Sheffield",
    county: "South Yorkshire",
    postcode: "S9 2RX",
    price: 9250000,
    tenure: "Freehold",
    floorAreaSqFt: 180000,
    landAreaAcres: 12.2,
    planningStatus: "Outline Approval",
    developmentPotential: "Pre-allocated area for hydrogen fuel cell generation terminal or heavy metal recycling operations.",
    industrialClassification: "B2 (General Industrial)",
    environmentalRating: "D",
    railAccess: true,
    railAccessDistance: 0.5,
    motorwayAccess: true,
    motorwayAccessDistance: 1.8,
    airportAccess: false,
    description: "Deep in Sheffield's industrial heartland, this heavy manufacturing complex features robust steel-frame construction, multiple overhead gantry cranes (up to 25-tonne capacity), a massive three-phase 4MVA power substation, and an active rail spur. Perfectly suited for advanced metallurgy, green steel fabrication, or modular infrastructure assembly.",
    nearbyInvestment: "Adjoins the Advanced Manufacturing Research Centre (AMRC) which recently received £85m for aerospace research."
  },
  {
    id: "prop-5",
    title: "Nidd Valley Premium Business Park",
    type: "Business Park",
    town: "Harrogate",
    county: "North Yorkshire",
    postcode: "HG3 1RY",
    price: 14750000,
    tenure: "Freehold",
    floorAreaSqFt: 64000,
    landAreaAcres: 6.5,
    planningStatus: "Full Approval",
    developmentPotential: "Approval secured for an additional 12,000 sq ft office pavilion built to Net-Zero Carbon standards.",
    industrialClassification: "E(g)(i) (Offices)",
    environmentalRating: "A",
    railAccess: false,
    motorwayAccess: true,
    motorwayAccessDistance: 5.2,
    airportAccess: true,
    airportAccessDistance: 12.0,
    description: "A premium business park situated in Harrogate's affluent northern sector. Consists of four architecturally stunning office pavilions featuring Yorkshire stone facades and floor-to-ceiling high-performance glazing. Current tenants include boutique wealth management firms, regional headquarters of blue-chip insurance agencies, and tech consultants. Current occupancy is at 100% with upward-only rent reviews.",
    nearbyInvestment: "Harrogate corporate district has seen a 12% increase in prime Grade-A rental rates over the last 18 months."
  },
  {
    id: "prop-6",
    title: "The York Central Mixed-Use Regeneration Site",
    type: "Mixed-Use Development",
    town: "York",
    county: "North Yorkshire",
    postcode: "YO24 4NT",
    price: 26000000,
    tenure: "Freehold",
    floorAreaSqFt: 350000,
    landAreaAcres: 11.5,
    planningStatus: "Outline Approval",
    developmentPotential: "Pre-allocated masterplan for 250 high-density residential apartments, 120,000 sq ft offices, and retail arcade.",
    environmentalRating: "B",
    railAccess: true,
    railAccessDistance: 0.1,
    motorwayAccess: true,
    motorwayAccessDistance: 6.8,
    airportAccess: false,
    description: "One of the most exciting urban regeneration opportunities in the North of England. Located immediately adjacent to York's historic railway station, this 11.5-acre site offers an investor or developer the opportunity to spearhead York Central's next major mixed-use quarter. The outline masterplan has been fully endorsed by Homes England, Network Rail, and York City Council.",
    nearbyInvestment: "York Central Infrastructure Fund has cleared £135m in public utility and road delivery capital."
  },
  {
    id: "prop-7",
    title: "Humber Bank Clean Energy & Quarry Reserve",
    type: "Quarry & Mineral Site",
    town: "Hull",
    county: "East Riding of Yorkshire",
    postcode: "HU12 8DZ",
    price: 11500000,
    tenure: "Freehold",
    landAreaAcres: 340,
    planningStatus: "Full Approval",
    developmentPotential: "Consent for 45MW utility-scale battery energy storage system (BESS) and 15MW ground-mounted solar farm.",
    environmentalRating: "B",
    railAccess: true,
    railAccessDistance: 2.5,
    motorwayAccess: true,
    motorwayAccessDistance: 4.0,
    airportAccess: false,
    description: "A major coastal resource and renewable energy development asset. Comprises a 180-acre active aggregate limestone quarry with proven reserves of 4.2 million tonnes, and 160 acres of flat coastal land with full planning consent for green hydrogen production and high-capacity battery storage. Strategic position adjacent to deep-water port facilities.",
    nearbyInvestment: "Humber Decarbonisation Initiative has targeted £1.2bn in private green fuel infrastructure by 2028."
  }
];

// Lazy-initialize Gemini SDK to handle API key verification securely without crashing on boot
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined in Secrets panel.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}

// ✦ AI Intelligence Report generation endpoint using gemini-3.6-flash
app.post("/api/intelligence/report", async (req, res) => {
  try {
    const { propertyId } = req.body;
    if (!propertyId) {
      return res.status(400).json({ error: "Missing propertyId parameter." });
    }

    // Find property profile from database
    const property = PROPERTIES_DATABASE.find((p) => p.id === propertyId);
    
    // Default mock data if custom listing was passed (seller portal)
    const activeProperty: any = property || {
      title: "Custom Strategic Yorkshire Tract",
      type: "Development Site",
      town: "Leeds Corridor",
      county: "West Yorkshire",
      postcode: "LS1",
      price: 1500000,
      tenure: "Freehold",
      landAreaAcres: 10.0,
      planningStatus: "Outline Approval",
      developmentPotential: "Immediate high density planning capacity.",
      environmentalRating: "B",
      nearbyInvestment: "Regional capital transport upgrades.",
      description: "A high potential commercial space indexed by land agent."
    };

    const client = getGeminiClient();

    const formattedPrice = activeProperty.price > 0 
      ? `£${activeProperty.price.toLocaleString("en-GB")}` 
      : "POA";

    const prompt = `You are an elite Senior Commercial Underwriter, property technology expert, and GIS surveyor at Rhino Bank's specialized real estate division.
Draft a highly professional, institutional-grade Commercial Property Intelligence and Investment Briefing report for the following asset:

---
PROPERTY NAME: ${activeProperty.title}
PROPERTY CLASSIFICATION: ${activeProperty.type}
LOCATION: ${activeProperty.town}, ${activeProperty.county} (${activeProperty.postcode})
CAPITAL VALUATION: ${formattedPrice}
TENURE STRUCTURE: ${activeProperty.tenure}
FOOTPRINT AREA: ${activeProperty.landAreaAcres ? `${activeProperty.landAreaAcres} Acres` : "N/A"} / ${activeProperty.floorAreaSqFt ? `${activeProperty.floorAreaSqFt} sq ft` : "N/A"}
PLANNING CONSENT STANDING: ${activeProperty.planningStatus}
DEVELOPMENT POTENTIAL METRICS: ${activeProperty.developmentPotential}
BREEAM EPC ENVIRONMENTAL STANDING: ${activeProperty.environmentalRating}
NEARBY GOVERNMENT INVESTMENT INITIATIVE: ${activeProperty.nearbyInvestment}
CORE EXECUTIVE SYNOPSIS: ${activeProperty.description}
---

Your response MUST be formatted strictly using clear capital headings and double line spacing, written under Swiss minimalist design and typographical principles:
Tone: Objective, authoritative, highly professional, with quiet confidence. Do not use flowery marketing descriptions, and avoid promotional sales terminology. Write only the factual analysis.

Structure:
I. EXECUTIVE FINANCIAL SUMMARY & UNDERWRITING SYNOPSIS
A comprehensive financial analysis justifying the asset value of ${formattedPrice}. Discuss cap-rates, yield horizons, and Rhino Bank's bridging and structural mortgage viability based on its ${activeProperty.tenure} tenure.

II. MUNICIPAL PLANNING & DEVELOPMENT CAPACITY INDEX
Detailed analysis of the planning permission (${activeProperty.planningStatus}) and real development density guidelines. Estimate square footage capacity limits, construction hurdles, and local council masterplan alignment.

III. REGIONAL ACCESSIBILITY & INDUSTRIAL TRANSIT PROFILE
Provide a highly specialized breakdown of logistics, rail, and road networks. Highlight access to motorways (M1/M62/M18) and high-freight railway spines based on the provided location context.

IV. ENVIRONMENTAL COMPLIANCE & ENERGY DECARBONIZATION MATRIX
Analyse the EPC rating of '${activeProperty.environmentalRating}'. Discuss peatland restoration, carbon-sequestration tax incentives, and net-zero office/warehouse adaptation guidelines.

V. COMPARABLE REGIONAL MARKET REGISTER
Generate 3 realistic, highly specific comparable commercial sales in ${activeProperty.county} over the past 18 months, with transaction values, yield compressions, and square footage pricing to defend this asset's capital valuation.

Keep your entire response in clear, concise paragraphs. Do not use markdown bold on every single sentence. Maintain a quiet, premium, elite institutional voice.`;

    const response = await client.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt
    });

    const reportText = response.text || "AI Report compilation finished with empty feedback.";
    res.json({ report: reportText });

  } catch (error: any) {
    console.error("Gemini Server Error:", error);
    res.status(500).json({ 
      error: "AI Generation failed on Rhino Server.", 
      message: error.message || error 
    });
  }
});

// Configure Vite middleware / asset routing
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode - Use Vite HMR / middleware proxy
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    console.log("Vite development server middleware mounted successfully.");
  } else {
    // Production Mode - Serve static bundled assets
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static distribution assets from dist directory.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Yorkshire Land & Property platform active at http://localhost:${PORT}`);
  });
}

startServer();
