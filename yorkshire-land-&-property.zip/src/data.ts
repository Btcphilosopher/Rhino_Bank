import { Property, PropertyType } from "./types";

export const INITIAL_PROPERTIES: Property[] = [
  {
    id: "prop-1",
    title: "The Calder Logistics & Freight Terminal",
    type: PropertyType.LOGISTICS_PARK,
    location: {
      town: "Doncaster",
      county: "South Yorkshire",
      postcode: "DN11 8SP",
      region: "Humber & South Yorkshire"
    },
    coordinates: {
      x: 62,
      y: 72,
      gridRef: "SE 5982 0451"
    },
    price: 18500000,
    tenure: "Freehold",
    floorAreaSqFt: 245000,
    landAreaAcres: 18.4,
    planningStatus: "Full Approval",
    developmentPotential: "Outline planning secured for an additional 80,000 sq ft logistics unit with 15m eaves height.",
    industrialClassification: "B8 (Storage or Distribution)",
    environmentalRating: "B",
    infrastructure: {
      railAccess: true,
      railAccessDistanceMiles: 0.2, // Direct rail-freight link
      motorwayAccess: true,
      motorwayAccessDistanceMiles: 1.1, // Near M18 J3 and A1(M)
      airportAccess: true,
      airportAccessDistanceMiles: 8.5, // Doncaster Sheffield Airport zone
      enterpriseZone: true,
      investmentZone: false
    },
    description: "An exceptional, institutional-grade logistics park. Completed in 2021, the terminal serves as a critical national distribution hub. Features include 24 dock-level loading doors, 50m secure service yards, ESFR sprinkler systems, and a dedicated rail freight siding connected directly to the East Coast Main Line. Currently let to a global logistics operator with an unexpired lease term (WAULT) of 14.5 years.",
    highlights: [
      "Direct rail freight terminal siding with active signaling",
      "High specification build with 15m internal clear height",
      "Excellent proximity to M18, M1, and A1(M) transit corridors",
      "Fully let to AAA-rated international tenant producing stable income"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "Part of the Doncaster Inland Port Masterplan, benefiting from a £120m regional transport infrastructure upgrade.",
    localBusinessData: [
      { Sector: "Logistics & Distribution", Count: 142 },
      { Sector: "Manufacturing", Count: 58 },
      { Sector: "Professional Services", Count: 31 }
    ],
    economicProfile: {
      employmentRate: 74.2,
      averageSalary: 29500,
      populationTrend: "Increasing (+1.4% annually, driven by logistics jobs hub)"
    },
    brochureAvailable: true
  },
  {
    id: "prop-2",
    title: "Wharfedale Agricultural & Forestry Estate",
    type: PropertyType.AGRICULTURAL_LAND,
    location: {
      town: "Grassington",
      county: "North Yorkshire",
      postcode: "BD23 5LQ",
      region: "Yorkshire Dales"
    },
    coordinates: {
      x: 25,
      y: 25,
      gridRef: "SD 9851 6412"
    },
    price: 4950000,
    tenure: "Freehold",
    landAreaAcres: 1240,
    planningStatus: "Agricultural Use",
    developmentPotential: "Significant carbon sequestration, peatland restoration, and high-yielding woodland creation potential. Tenancy-free possession available.",
    environmentalRating: "A",
    infrastructure: {
      railAccess: false,
      motorwayAccess: false,
      motorwayAccessDistanceMiles: 22.0,
      airportAccess: false,
      enterpriseZone: false,
      investmentZone: false
    },
    description: "A breathtaking and historically significant upland estate spanning 1,240 acres of highly productive limestone pasture, deep peat moorland, and commercial coniferous forestry. Includes an original 17th-century stone farmstead, five let agricultural cottages, and extensive shooting and mineral rights. Managed strictly under an environmental enhancement framework with excellent subsidy streams.",
    highlights: [
      "1,240 contiguous acres in the heart of the Yorkshire Dales",
      "Fully integrated countryside stewardship and organic subsidy profiles",
      "Substantial commercial forestry block ready for high-yield timber harvest",
      "Includes mineral rights, carbon offset registry rights, and stone structures"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "Yorkshire Dales Biodiversity Fund matches environmental restoration capital at a 1.2x ratio.",
    localBusinessData: [
      { Sector: "Agriculture & Forestry", Count: 64 },
      { Sector: "Eco-tourism", Count: 18 },
      { Sector: "Specialized Contracting", Count: 7 }
    ],
    economicProfile: {
      employmentRate: 81.5,
      averageSalary: 31000,
      populationTrend: "Stable (-0.1% change, strong wealthy retirement inflows)"
    },
    brochureAvailable: true
  },
  {
    id: "prop-3",
    title: "Airedale Science & Biotech Park",
    type: PropertyType.SCIENCE_PARK,
    location: {
      town: "Leeds",
      county: "West Yorkshire",
      postcode: "LS2 9JT",
      region: "Leeds City Region"
    },
    coordinates: {
      x: 50,
      y: 55,
      gridRef: "SE 2984 3450"
    },
    price: 34200000,
    tenure: "Freehold",
    floorAreaSqFt: 112000,
    landAreaAcres: 4.8,
    planningStatus: "Full Approval",
    developmentPotential: "Full planning granted for Phase 3: a 45,000 sq ft Class II Wet Lab and cleanroom workspace.",
    industrialClassification: "E(g)(ii) (Research & Development)",
    environmentalRating: "A",
    infrastructure: {
      railAccess: true,
      railAccessDistanceMiles: 0.8, // Close to Leeds Central Station
      motorwayAccess: true,
      motorwayAccessDistanceMiles: 1.5, // M621 link connecting to M1 and M62
      airportAccess: true,
      airportAccessDistanceMiles: 9.0, // Leeds Bradford Airport
      enterpriseZone: false,
      investmentZone: true // Active Leeds Investment Zone
    },
    description: "An ultra-premium research and science park located in the Innovation Arc of Leeds. The complex consists of three high-specification buildings featuring state-of-the-art laboratory spaces, sterile climate-controlled rooms, and Grade-A creative incubation workspaces. Tenanted by leading oncology research organizations and University of Leeds spin-outs, boasting exceptional retention rates and net-initial yields of 6.8%.",
    highlights: [
      "Grade-A wet and dry labs fitted to BSL-2 containment standards",
      "BREEAM 'Excellent' certification with 100% renewable self-sufficient microgrid",
      "Direct academic pipelines with world-class regional universities",
      "Situated in Leeds' core designated Investment Zone with tax incentives"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "Leeds Innovation Arc is the recipient of a £450m joint private-public expansion venture.",
    localBusinessData: [
      { Sector: "Biotechnology & Healthcare", Count: 84 },
      { Sector: "Advanced Research / Tech", Count: 112 },
      { Sector: "Venture Capital & Finance", Count: 45 }
    ],
    economicProfile: {
      employmentRate: 78.9,
      averageSalary: 42500,
      populationTrend: "Strong growth (+2.1% annually, high skilled talent retention)"
    },
    brochureAvailable: true
  },
  {
    id: "prop-4",
    title: "The Don Valley Heavy Industrial Complex",
    type: PropertyType.FACTORY,
    location: {
      town: "Sheffield",
      county: "South Yorkshire",
      postcode: "S9 2RX",
      region: "Sheffield City Region"
    },
    coordinates: {
      x: 48,
      y: 80,
      gridRef: "SK 3845 8891"
    },
    price: 9250000,
    tenure: "Freehold",
    floorAreaSqFt: 180000,
    landAreaAcres: 12.2,
    planningStatus: "Outline Approval",
    developmentPotential: "Pre-allocated area for hydrogen fuel cell generation terminal or heavy metal recycling operations.",
    industrialClassification: "B2 (General Industrial)",
    environmentalRating: "D",
    infrastructure: {
      railAccess: true,
      railAccessDistanceMiles: 0.5,
      motorwayAccess: true,
      motorwayAccessDistanceMiles: 1.8, // Immediate access to M1 J34
      airportAccess: false,
      enterpriseZone: true,
      investmentZone: false
    },
    description: "Deep in Sheffield's industrial heartland, this heavy manufacturing complex features robust steel-frame construction, multiple overhead gantry cranes (up to 25-tonne capacity), a massive three-phase 4MVA power substation, and an active rail spur. Perfectly suited for advanced metallurgy, green steel fabrication, or modular infrastructure assembly.",
    highlights: [
      "Unmatched power capacity with 4MVA dedicated grid substation",
      "6 overhead heavy-duty gantry cranes (10t to 25t working load limits)",
      "Dedicated, secure heavy-vehicle yards with multi-gate egress",
      "Qualifies for Sheffield Enterprise Zone corporate tax relief benefits"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "Adjoins the Advanced Manufacturing Research Centre (AMRC) which recently received £85m for aerospace research.",
    localBusinessData: [
      { Sector: "Metallurgy & Steel", Count: 91 },
      { Sector: "Advanced Aerospace Manufacturing", Count: 34 },
      { Sector: "Industrial Waste Processing", Count: 19 }
    ],
    economicProfile: {
      employmentRate: 71.8,
      averageSalary: 34200,
      populationTrend: "Increasing (+0.8% annually, strong advanced manufacturing job demand)"
    },
    brochureAvailable: true
  },
  {
    id: "prop-5",
    title: "Nidd Valley Premium Business Park",
    type: PropertyType.BUSINESS_PARK,
    location: {
      town: "Harrogate",
      county: "North Yorkshire",
      postcode: "HG3 1RY",
      region: "North Yorkshire"
    },
    coordinates: {
      x: 48,
      y: 35,
      gridRef: "SE 3121 5542"
    },
    price: 14750000,
    tenure: "Freehold",
    floorAreaSqFt: 64000,
    landAreaAcres: 6.5,
    planningStatus: "Full Approval",
    developmentPotential: "Approval secured for an additional 12,000 sq ft office pavilion built to Net-Zero Carbon standards.",
    industrialClassification: "E(g)(i) (Offices)",
    environmentalRating: "A",
    infrastructure: {
      railAccess: false,
      motorwayAccess: true,
      motorwayAccessDistanceMiles: 5.2, // Connects to A1(M) J47
      airportAccess: true,
      airportAccessDistanceMiles: 12.0, // Leeds Bradford Airport
      enterpriseZone: false,
      investmentZone: false
    },
    description: "A premium business park situated in Harrogate's affluent northern sector. Consists of four architecturally stunning office pavilions featuring Yorkshire stone facades and floor-to-ceiling high-performance glazing. Current tenants include boutique wealth management firms, regional headquarters of blue-chip insurance agencies, and tech consultants. Current occupancy is at 100% with upward-only rent reviews.",
    highlights: [
      "Stunning architectural design utilising local Yorkshire sandstone",
      "High-efficiency heat pumps, solar arrays, and EPC 'A' credentials",
      "Beautifully landscaped parklands with wetland retention ponds",
      "Secure underground parking with 48 high-speed EV charging bays"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "Harrogate corporate district has seen a 12% increase in prime Grade-A rental rates over the last 18 months.",
    localBusinessData: [
      { Sector: "Wealth Management & Finance", Count: 48 },
      { Sector: "Legal & Professional Services", Count: 52 },
      { Sector: "Software & Technology", Count: 29 }
    ],
    economicProfile: {
      employmentRate: 83.4,
      averageSalary: 45000,
      populationTrend: "Highly affluent expansion (+0.9% annually, professional class inflow)"
    },
    brochureAvailable: true
  },
  {
    id: "prop-6",
    title: "The York Central Mixed-Use Regeneration Site",
    type: PropertyType.MIXED_USE,
    location: {
      town: "York",
      county: "North Yorkshire",
      postcode: "YO24 4NT",
      region: "York City Region"
    },
    coordinates: {
      x: 65,
      y: 40,
      gridRef: "SE 5934 5210"
    },
    price: 26000000,
    tenure: "Freehold",
    floorAreaSqFt: 350000, // Total masterplanned build capacity
    landAreaAcres: 11.5,
    planningStatus: "Outline Approval",
    developmentPotential: "Pre-allocated masterplan for 250 high-density residential apartments, 120,000 sq ft offices, and retail arcade.",
    environmentalRating: "B",
    infrastructure: {
      railAccess: true,
      railAccessDistanceMiles: 0.1, // Adjacent to York Mainline Rail Station
      motorwayAccess: true,
      motorwayAccessDistanceMiles: 6.8, // Linked to A1(M) via direct A64
      airportAccess: false,
      enterpriseZone: false,
      investmentZone: true
    },
    description: "One of the most exciting urban regeneration opportunities in the North of England. Located immediately adjacent to York's historic railway station, this 11.5-acre site offers an investor or developer the opportunity to spearhead York Central's next major mixed-use quarter. The outline masterplan has been fully endorsed by Homes England, Network Rail, and York City Council.",
    highlights: [
      "Unrivaled location directly backing onto York Mainline Station",
      "Backed by central government funding with pre-allocated infrastructure grants",
      "Opportunity to deliver prime residential, high-end retail, and corporate hubs",
      "Enterprise and Tax Incentive Zone status active across the site border"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1570126618953-d437176e8c79?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "York Central Infrastructure Fund has cleared £135m in public utility and road delivery capital.",
    localBusinessData: [
      { Sector: "Tourism & Hospitality", Count: 174 },
      { Sector: "Public Sector & Rail", Count: 62 },
      { Sector: "Retail & Commerce", Count: 121 }
    ],
    economicProfile: {
      employmentRate: 79.1,
      averageSalary: 36000,
      populationTrend: "Expanding urban population (+1.6% annually, driven by university grads)"
    },
    brochureAvailable: false
  },
  {
    id: "prop-7",
    title: "Humber Bank Clean Energy & Quarry Reserve",
    type: PropertyType.QUARRY_MINERALS,
    location: {
      town: "Hull",
      county: "East Riding of Yorkshire",
      postcode: "HU12 8DZ",
      region: "Humber Region"
    },
    coordinates: {
      x: 85,
      y: 60,
      gridRef: "TA 1650 2812"
    },
    price: 11500000,
    tenure: "Freehold",
    landAreaAcres: 340,
    planningStatus: "Full Approval",
    developmentPotential: "Consent for 45MW utility-scale battery energy storage system (BESS) and 15MW ground-mounted solar farm.",
    environmentalRating: "B",
    infrastructure: {
      railAccess: true,
      railAccessDistanceMiles: 2.5,
      motorwayAccess: true,
      motorwayAccessDistanceMiles: 4.0, // Access via A63 to M62
      airportAccess: false,
      enterpriseZone: true,
      investmentZone: true
    },
    description: "A major coastal resource and renewable energy development asset. Comprises a 180-acre active aggregate limestone quarry with proven reserves of 4.2 million tonnes, and 160 acres of flat coastal land with full planning consent for green hydrogen production and high-capacity battery storage. Strategic position adjacent to deep-water port facilities.",
    highlights: [
      "Dual-income potential: active mineral quarrying + green energy development",
      "4.2M tonnes of high-grade limestone aggregates in proven reserve",
      "Full planning consent for 45MW Battery Energy Storage System (BESS)",
      "Humber Freeport designation with significant customs and tariff advantages"
    ],
    droneSimulationImage: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=1200",
    nearbyInvestment: "Humber Decarbonisation Initiative has targeted £1.2bn in private green fuel infrastructure by 2028.",
    localBusinessData: [
      { Sector: "Chemical & Industrial", Count: 42 },
      { Sector: "Maritime & Shipping", Count: 88 },
      { Sector: "Renewable Energy Support", Count: 31 }
    ],
    economicProfile: {
      employmentRate: 70.4,
      averageSalary: 31800,
      populationTrend: "Stable (+0.4% annually, massive growth in green tech engineering)"
    },
    brochureAvailable: true
  }
];

export const YORKSHIRE_MARKET_INDICES = [
  {
    name: "Industrial & Logistics Land (per Acre)",
    currentValue: 850000, // £850k/acre
    change12mPercent: 8.4,
    history: [
      { date: "2021", value: 610000 },
      { date: "2022", value: 680000 },
      { date: "2023", value: 740000 },
      { date: "2024", value: 785000 },
      { date: "2025", value: 815000 },
      { date: "2026", value: 850000 }
    ]
  },
  {
    name: "Grade-A Commercial Office Yields",
    currentValue: 6.45, // 6.45%
    change12mPercent: -1.2, // yield compression (positive for values)
    history: [
      { date: "2021", value: 7.10 },
      { date: "2022", value: 6.95 },
      { date: "2023", value: 6.80 },
      { date: "2024", value: 6.65 },
      { date: "2025", value: 6.55 },
      { date: "2026", value: 6.45 }
    ]
  },
  {
    name: "Agricultural Grade-2 Silt/Clay Land (per Acre)",
    currentValue: 12200, // £12.2k/acre
    change12mPercent: 5.8,
    history: [
      { date: "2021", value: 9800 },
      { date: "2022", value: 10400 },
      { date: "2023", value: 11100 },
      { date: "2024", value: 11400 },
      { date: "2025", value: 11800 },
      { date: "2026", value: 12200 }
    ]
  }
];

export const YORKSHIRE_INFRASTRUCTURE_PROJECTS = [
  {
    id: "proj-1",
    name: "Transpennine Rail Route Upgrade (TRU)",
    status: "Active Construction",
    sector: "Transport & Rail",
    cost: "£11,500,000,000",
    completion: "2028",
    impact: "Slashing Leeds-to-Manchester transit to 41 minutes and York-to-Leeds to 18 minutes. Complete electrification and multi-tracking."
  },
  {
    id: "proj-2",
    name: "Leeds Innovation Arc - District Heating Expansion",
    status: "Phase 2 Delivery",
    sector: "Green Utility Infrastructure",
    cost: "£85,000,000",
    completion: "2027",
    impact: "Providing zero-carbon geothermal heating to over 3.5 million sq ft of planned commercial office, bio-science, and academic parks."
  },
  {
    id: "proj-3",
    name: "M1-M18 Infraconnect Hubs",
    status: "Planning Stage",
    sector: "Logistics Link",
    cost: "£240,000,000",
    completion: "2029",
    impact: "Bypassing heavy intersections to offer uninterrupted autonomous freight lanes linking Doncaster freight ports directly to Northern distribution centers."
  }
];
