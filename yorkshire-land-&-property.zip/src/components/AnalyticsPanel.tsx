import React, { useState } from "react";
import { YORKSHIRE_MARKET_INDICES, YORKSHIRE_INFRASTRUCTURE_PROJECTS } from "../data";
import { Landmark, AreaChart, TrendingUp, HelpCircle, AlertCircle, HardHat, Compass, FileText } from "lucide-react";

export default function AnalyticsPanel() {
  const [selectedCategory, setSelectedCategory] = useState<number>(0);
  const activeIndex = YORKSHIRE_MARKET_INDICES[selectedCategory];

  // Formatting currency
  const formatValue = (indexName: string, val: number) => {
    if (indexName.includes("Yield")) {
      return `${val.toFixed(2)}%`;
    }
    return new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(val);
  };

  // Calculations for custom SVG chart bounding boxes
  const chartWidth = 550;
  const chartHeight = 220;
  const paddingX = 50;
  const paddingY = 30;

  const minVal = Math.min(...activeIndex.history.map(h => h.value)) * 0.95;
  const maxVal = Math.max(...activeIndex.history.map(h => h.value)) * 1.05;
  const valRange = maxVal - minVal;

  const getSvgCoordinates = (index: number, val: number) => {
    const x = paddingX + (index / (activeIndex.history.length - 1)) * (chartWidth - paddingX * 2);
    const y = chartHeight - paddingY - ((val - minVal) / valRange) * (chartHeight - paddingY * 2);
    return { x, y };
  };

  const points = activeIndex.history.map((h, idx) => getSvgCoordinates(idx, h.value));
  const pointsPathString = points.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  return (
    <div id="market-intelligence" className="max-w-7xl mx-auto space-y-10 rounded-none">
      
      {/* Intro Magazine Eyebrow */}
      <div className="border-b-2 border-dark pb-6 rounded-none">
        <span className="text-[10px] font-mono text-primary tracking-widest uppercase block font-bold mb-2">
          RHINO INVESTMENT ADVISORY BRIEFING
        </span>
        <h2 className="text-2xl md:text-4xl font-black tracking-tight text-dark mt-2 font-serif uppercase">
          Yorkshire Market Intelligence
        </h2>
        <p className="text-stone-500 font-serif text-sm md:text-base mt-2 max-w-2xl leading-relaxed">
          Aggregated regional index valuations, commercial lease yields, and sovereign municipal infrastructure capital projections across West, North, East, and South Yorkshire.
        </p>
      </div>

      {/* Grid: 2 Columns - SVG charts on left, projects on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start rounded-none">
        
        {/* Interactive Indexes Column */}
        <div className="lg:col-span-7 bg-white border-2 border-dark p-6 md:p-8 space-y-6 rounded-none">
          <div className="flex items-center justify-between border-b border-border-muted pb-4 rounded-none">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h3 className="font-serif text-lg font-extrabold text-dark uppercase">Sovereign Land Valuation Indexes</h3>
            </div>
            <span className="font-mono text-[9px] text-stone-400 uppercase font-bold">REF: RHN-INDX-2026</span>
          </div>

          {/* Index Category Switches */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 rounded-none">
            {YORKSHIRE_MARKET_INDICES.map((idxData, index) => (
              <button
                key={index}
                onClick={() => setSelectedCategory(index)}
                className={`p-3 text-left border-2 transition font-mono rounded-none cursor-pointer ${
                  selectedCategory === index
                    ? "bg-dark text-white border-dark font-extrabold"
                    : "bg-cream text-stone-600 border-border-muted hover:border-dark"
                }`}
              >
                <span className="block text-[8px] text-stone-400 uppercase tracking-widest mb-1 font-bold">
                  INDEX {index + 1}
                </span>
                <span className="block text-xs leading-snug truncate font-bold">
                  {idxData.name}
                </span>
                <span className={`block text-[10px] mt-1 font-extrabold ${
                  idxData.change12mPercent > 0 ? "text-emerald-600" : "text-primary"
                }`}>
                  {idxData.change12mPercent > 0 ? "▲" : "▼"} {Math.abs(idxData.change12mPercent)}% (12m)
                </span>
              </button>
            ))}
          </div>

          {/* Render the Custom Hand-crafted SVG Chart (Swiss Minimalist Style) */}
          <div className="border-2 border-dark bg-white p-4 relative overflow-x-auto select-none rounded-none">
            <div className="text-[10px] font-mono text-stone-400 uppercase tracking-widest mb-2 border-b border-border-muted pb-1 flex justify-between font-bold">
              <span>HISTORICAL TREND LINE</span>
              <span className="text-dark font-black">
                CURRENT: {formatValue(activeIndex.name, activeIndex.currentValue)}
              </span>
            </div>

            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto text-dark min-w-[500px]">
              {/* Backgrid reference lines */}
              <line x1={paddingX} y1={paddingY} x2={chartWidth - paddingX} y2={paddingY} stroke="#e5e5e5" strokeWidth={1} strokeDasharray="4 4" />
              <line x1={paddingX} y1={chartHeight / 2} x2={chartWidth - paddingX} y2={chartHeight / 2} stroke="#e5e5e5" strokeWidth={1} strokeDasharray="4 4" />
              <line x1={paddingX} y1={chartHeight - paddingY} x2={chartWidth - paddingX} y2={chartHeight - paddingY} stroke="#1a1a1a" strokeWidth={1.5} />

              {/* Vertical grids for years */}
              {activeIndex.history.map((h, idx) => {
                const x = paddingX + (idx / (activeIndex.history.length - 1)) * (chartWidth - paddingX * 2);
                return (
                  <line key={idx} x1={x} y1={paddingY} x2={x} y2={chartHeight - paddingY} stroke="#f1f1f1" strokeWidth={1} />
                );
              })}

              {/* Y Axis bounds labels */}
              <text x={paddingX - 10} y={paddingY + 4} textAnchor="end" className="text-[8px] font-mono fill-stone-400 font-bold">
                {formatValue(activeIndex.name, maxVal)}
              </text>
              <text x={paddingX - 10} y={chartHeight / 2 + 4} textAnchor="end" className="text-[8px] font-mono fill-stone-400 font-bold">
                {formatValue(activeIndex.name, (maxVal + minVal)/2)}
              </text>
              <text x={paddingX - 10} y={chartHeight - paddingY + 4} textAnchor="end" className="text-[8px] font-mono fill-stone-400 font-bold">
                {formatValue(activeIndex.name, minVal)}
              </text>

              {/* Gradient fill under the trend line */}
              <defs>
                <linearGradient id="chartGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#A67C52" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#A67C52" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path
                d={`${pointsPathString} L ${points[points.length - 1].x} ${chartHeight - paddingY} L ${points[0].x} ${chartHeight - paddingY} Z`}
                fill="url(#chartGlow)"
              />

              {/* Core Trendline Path */}
              <path
                d={pointsPathString}
                fill="none"
                stroke="#A67C52" // Burnished brass
                strokeWidth={3}
                strokeLinecap="square"
                strokeLinejoin="miter"
              />

              {/* Circle Nodes for data points */}
              {points.map((p, idx) => (
                <g key={idx}>
                  <rect
                    x={p.x - (isSelectedNode(idx) ? 5 : 3.5)}
                    y={p.y - (isSelectedNode(idx) ? 5 : 3.5)}
                    width={isSelectedNode(idx) ? 10 : 7}
                    height={isSelectedNode(idx) ? 10 : 7}
                    fill={isSelectedNode(idx) ? "#1A1A1A" : "#ffffff"}
                    stroke="#A67C52"
                    strokeWidth={2}
                    className="cursor-pointer transition-all hover:scale-125"
                  />
                  {/* Subtle data labels above circle node */}
                  <text
                    x={p.x}
                    y={p.y - 10}
                    textAnchor="middle"
                    className="text-[8px] font-mono fill-dark font-black"
                  >
                    {formatValue(activeIndex.name, activeIndex.history[idx].value)}
                  </text>
                </g>
              ))}

              {/* Year bottom labels */}
              {activeIndex.history.map((h, idx) => {
                const x = paddingX + (idx / (activeIndex.history.length - 1)) * (chartWidth - paddingX * 2);
                return (
                  <text key={idx} x={x} y={chartHeight - paddingY + 14} textAnchor="middle" className="text-[9px] font-mono fill-stone-500 font-bold">
                    {h.date}
                  </text>
                );
              })}
            </svg>
          </div>
          
          <div className="bg-dark p-4 text-stone-300 text-[11px] leading-relaxed font-mono border border-stone-800 rounded-none">
            <span className="text-white font-extrabold block mb-1">MUNICIPAL FORECAST ASSESSMENT</span>
            Yorkshire’s prime distribution assets are showing yields compression as Leeds City and South Yorkshire terminals continue to serve as major logistical bottlenecks, compressing national supply corridors onto the M1 and M18 arterial spans.
          </div>
        </div>

        {/* Infrastructure Projects Column */}
        <div className="lg:col-span-5 space-y-6 rounded-none">
          <div className="bg-white border-2 border-dark p-6 space-y-4 rounded-none">
            <div className="flex items-center space-x-2 border-b border-border-muted pb-3 rounded-none">
              <HardHat className="h-5 w-5 text-primary" />
              <h3 className="font-serif text-lg font-black text-dark uppercase">Active Sovereign Infrastructure Projects</h3>
            </div>
            
            <div className="space-y-4 rounded-none">
              {YORKSHIRE_INFRASTRUCTURE_PROJECTS.map((proj) => (
                <div key={proj.id} className="border-2 border-dark p-4 space-y-2 text-dark bg-white rounded-none">
                  <div className="flex justify-between items-start rounded-none">
                    <span className="text-[8px] font-mono bg-dark text-white px-1.5 py-0.5 uppercase font-bold rounded-none">
                      {proj.sector}
                    </span>
                    <span className="text-[10px] font-mono text-primary font-extrabold">
                      {proj.status}
                    </span>
                  </div>
                  <h4 className="font-serif font-extrabold text-sm text-dark">{proj.name}</h4>
                  <div className="grid grid-cols-2 text-[10px] font-mono text-stone-500 py-1 border-t border-b border-border-muted rounded-none">
                    <span>CAPITAL COST: <strong className="text-dark font-extrabold">{proj.cost}</strong></span>
                    <span>COMPLETION: <strong className="text-dark font-extrabold">{proj.completion}</strong></span>
                  </div>
                  <p className="text-[11px] text-stone-600 leading-relaxed font-serif">
                    {proj.impact}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

    </div>
  );

  function isSelectedNode(index: number) {
    return index === activeIndex.history.length - 1;
  }
}
