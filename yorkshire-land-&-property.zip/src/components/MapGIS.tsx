import React, { useRef, useEffect, useState } from "react";
import { Property, PropertyType } from "../types";
import { Compass, Layers, MapPin, ZoomIn, ZoomOut, Brush, RefreshCw, AlertTriangle } from "lucide-react";

interface MapGISProps {
  properties: Property[];
  selectedProperty: Property | null;
  onSelectProperty: (property: Property) => void;
  filteredProperties: Property[];
  onDrawFilter: (propertyIds: string[] | null) => void;
}

type MapLayer = "satellite" | "topographic" | "planning" | "transport" | "flood";

export default function MapGIS({
  properties,
  selectedProperty,
  onSelectProperty,
  filteredProperties,
  onDrawFilter
}: MapGISProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeLayers, setActiveLayers] = useState<Record<MapLayer, boolean>>({
    satellite: false,
    topographic: true,
    planning: true,
    transport: true,
    flood: false
  });

  const [zoom, setZoom] = useState<number>(1.0);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  
  // Drawing tool state
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [drawnPoints, setDrawnPoints] = useState<{ x: number; y: number }[]>([]);
  const [hoveredProperty, setHoveredProperty] = useState<Property | null>(null);

  const toggleLayer = (layer: MapLayer) => {
    setActiveLayers((prev) => ({ ...prev, [layer]: !prev[layer] }));
  };

  // Convert canvas client coordinates to GIS grid space (0-100)
  const getGridCoords = (clientX: number, clientY: number, rect: DOMRect) => {
    const canvasX = clientX - rect.left;
    const canvasY = clientY - rect.top;
    
    // Reverse the zoom and pan transform
    const x = ((canvasX - offset.x) / zoom / rect.width) * 100;
    const y = ((canvasY - offset.y) / zoom / rect.height) * 100;
    return { x, y };
  };

  // Convert GIS grid space (0-100) to actual canvas coordinates
  const getCanvasCoords = (gridX: number, gridY: number, width: number, height: number) => {
    const cx = (gridX / 100) * width * zoom + offset.x;
    const cy = (gridY / 100) * height * zoom + offset.y;
    return { x: cx, y: cy };
  };

  // Handle canvas mouse events
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();

    if (isDrawing) {
      const p = getGridCoords(e.clientX, e.clientY, rect);
      setDrawnPoints((prev) => [...prev, p]);
    } else {
      setIsDragging(true);
      setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const width = canvas.width;
    const height = canvas.height;

    if (isDragging && !isDrawing) {
      setOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    } else {
      // Check for hovered property
      const mouseGrid = getGridCoords(e.clientX, e.clientY, rect);
      let found: Property | null = null;
      
      for (const prop of properties) {
        const dx = prop.coordinates.x - mouseGrid.x;
        const dy = prop.coordinates.y - mouseGrid.y;
        // distance threshold in grid coordinates
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 3.5 / zoom) {
          found = prop;
          break;
        }
      }
      setHoveredProperty(found);
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) {
      setIsDragging(false);
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDrawing) return; // Add point handled in mousedown
    
    // If we clicked on a property, select it
    if (hoveredProperty) {
      onSelectProperty(hoveredProperty);
    }
  };

  // Check if a point is inside a polygon (Ray-casting algorithm)
  const isPointInPolygon = (point: { x: number; y: number }, polygon: { x: number; y: number }[]) => {
    let isInside = false;
    const { x, y } = point;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].x, yi = polygon[i].y;
      const xj = polygon[j].x, yj = polygon[j].y;
      
      const intersect = ((yi > y) !== (yj > y))
          && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
      if (intersect) isInside = !isInside;
    }
    return isInside;
  };

  // Complete drawing and filter
  const finishDrawing = () => {
    if (drawnPoints.length < 3) {
      alert("Please plot at least 3 points to define a boundary area.");
      return;
    }
    
    // Find all properties that fall inside drawn points
    const insideProperties = properties.filter((prop) => 
      isPointInPolygon(prop.coordinates, drawnPoints)
    );
    
    onDrawFilter(insideProperties.map((p) => p.id));
    setIsDrawing(false);
  };

  const resetDrawing = () => {
    setDrawnPoints([]);
    onDrawFilter(null);
    setIsDrawing(false);
  };

  // Render the canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set high-DPI scaling
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const w = rect.width;
    const h = rect.height;

    ctx.clearRect(0, 0, w, h);

    // 1. BASE BACKGROUND LAYER
    if (activeLayers.satellite) {
      // Premium Dark Satellite mockup
      ctx.fillStyle = "#11141a"; // deep charcoal
      ctx.fillRect(0, 0, w, h);
      
      // Draw simulated satellite patches (textured landscape grids)
      ctx.fillStyle = "#151e24";
      ctx.beginPath();
      ctx.arc(w/2, h/2, Math.max(w, h) * 0.6, 0, Math.PI * 2);
      ctx.fill();

      // Industrial clusters (represented as subtle dark blue patches)
      ctx.fillStyle = "#1e293b";
      ctx.fillRect(w * 0.45 * zoom + offset.x, h * 0.5 * zoom + offset.y, 80 * zoom, 60 * zoom);
      ctx.fillRect(w * 0.6 * zoom + offset.x, h * 0.65 * zoom + offset.y, 110 * zoom, 70 * zoom);
    } else {
      // Yorkshire Stone Warm Minimalist canvas
      ctx.fillStyle = "#F5F5F0"; // warm limestone cream theme variable
      ctx.fillRect(0, 0, w, h);
    }

    // 2. GRID SYSTEM (Swiss Layout)
    ctx.strokeStyle = activeLayers.satellite ? "rgba(255, 255, 255, 0.08)" : "rgba(26, 26, 26, 0.07)";
    ctx.lineWidth = 1;
    const gridSize = 40 * zoom;
    const startX = offset.x % gridSize;
    const startY = offset.y % gridSize;

    // Vertical lines
    for (let x = startX; x < w; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    // Horizontal lines
    for (let y = startY; y < h; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // 3. TOPOGRAPHIC CONTOURS LAYER
    if (activeLayers.topographic) {
      ctx.strokeStyle = activeLayers.satellite ? "rgba(255, 255, 255, 0.15)" : "rgba(112, 102, 92, 0.18)";
      ctx.lineWidth = 0.8;
      
      const drawContour = (centerX: number, centerY: number, radius: number, variance: number) => {
        ctx.beginPath();
        for (let angle = 0; angle < Math.PI * 2; angle += 0.1) {
          const r = radius + Math.sin(angle * 5) * variance;
          const gridX = centerX + Math.cos(angle) * r;
          const gridY = centerY + Math.sin(angle) * r;
          const cc = getCanvasCoords(gridX, gridY, w, h);
          if (angle === 0) {
            ctx.moveTo(cc.x, cc.y);
          } else {
            ctx.lineTo(cc.x, cc.y);
          }
        }
        ctx.closePath();
        ctx.stroke();
      };

      // Yorkshire Dales Uplands Topo simulation (North-West)
      drawContour(20, 20, 15, 2);
      drawContour(20, 20, 11, 1.5);
      drawContour(20, 20, 7, 1);
      
      // North York Moors (North-East)
      drawContour(75, 22, 16, 2.5);
      drawContour(75, 22, 12, 1.8);
      drawContour(75, 22, 8, 1.2);

      // Pennine Foothills (West)
      drawContour(15, 60, 22, 3);
      drawContour(15, 60, 17, 2);
      drawContour(15, 60, 12, 1.5);
    }

    // 4. FLOOD PLAIN LAYER (Blue hatching)
    if (activeLayers.flood) {
      ctx.fillStyle = activeLayers.satellite ? "rgba(56, 189, 248, 0.15)" : "rgba(14, 116, 144, 0.12)";
      ctx.strokeStyle = activeLayers.satellite ? "rgba(56, 189, 248, 0.4)" : "rgba(14, 116, 144, 0.35)";
      ctx.lineWidth = 1.2;

      // Rivers winding simulation (Ouse, Calder, Aire)
      const drawRiver = (points: {x: number, y: number}[]) => {
        ctx.beginPath();
        points.forEach((pt, idx) => {
          const cc = getCanvasCoords(pt.x, pt.y, w, h);
          if (idx === 0) ctx.moveTo(cc.x, cc.y);
          else ctx.lineTo(cc.x, cc.y);
        });
        ctx.stroke();
      };

      // River Ouse / Humber simulation
      drawRiver([
        { x: 30, y: 10 },
        { x: 42, y: 32 },
        { x: 55, y: 48 },
        { x: 68, y: 56 },
        { x: 82, y: 62 },
        { x: 99, y: 64 }
      ]);

      // River Calder / Aire
      drawRiver([
        { x: 10, y: 62 },
        { x: 35, y: 58 },
        { x: 50, y: 55 },
        { x: 68, y: 56 }
      ]);

      // Draw active flood plain buffer area
      ctx.beginPath();
      const floodAreaCoords = [
        { x: 50, y: 45 },
        { x: 72, y: 50 },
        { x: 95, y: 58 },
        { x: 90, y: 70 },
        { x: 65, y: 65 },
        { x: 45, y: 58 }
      ];
      floodAreaCoords.forEach((pt, idx) => {
        const cc = getCanvasCoords(pt.x, pt.y, w, h);
        if (idx === 0) ctx.moveTo(cc.x, cc.y);
        else ctx.lineTo(cc.x, cc.y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    // 5. PLANNING & ENTERPRISE ZONES LAYER
    if (activeLayers.planning) {
      // Enterprise Zone 1 (South Yorkshire distribution corridor)
      ctx.fillStyle = "rgba(166, 124, 82, 0.06)"; // brass gold tone
      ctx.strokeStyle = "rgba(166, 124, 82, 0.35)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);

      const drawZone = (label: string, coords: {x: number, y: number}[]) => {
        ctx.beginPath();
        coords.forEach((pt, idx) => {
          const cc = getCanvasCoords(pt.x, pt.y, w, h);
          if (idx === 0) ctx.moveTo(cc.x, cc.y);
          else ctx.lineTo(cc.x, cc.y);
        });
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Print zone label in center of polygon
        const sum = coords.reduce((acc, p) => ({ x: acc.x + p.x, y: acc.y + p.y }), { x: 0, y: 0 });
        const center = getCanvasCoords(sum.x / coords.length, sum.y / coords.length, w, h);
        
        ctx.fillStyle = activeLayers.satellite ? "rgba(166, 124, 82, 0.8)" : "#A67C52";
        ctx.font = "bold 9px monospace";
        ctx.textAlign = "center";
        ctx.fillText(label, center.x, center.y);
      };

      drawZone("DONCASTER ENTERPRISE PORT", [
        { x: 58, y: 68 },
        { x: 68, y: 68 },
        { x: 68, y: 76 },
        { x: 58, y: 76 }
      ]);

      drawZone("LEEDS TECH INVESTMENT ARC", [
        { x: 45, y: 51 },
        { x: 55, y: 51 },
        { x: 55, y: 59 },
        { x: 45, y: 59 }
      ]);

      ctx.setLineDash([]); // Reset dashed lines
    }

    // 6. TRANSPORT NETWORKS (Motorways + Railways)
    if (activeLayers.transport) {
      // Motorways (Double line in burnished copper)
      ctx.strokeStyle = activeLayers.satellite ? "rgba(166, 124, 82, 0.7)" : "#C084FC"; // subtle purple or copper
      ctx.strokeStyle = "#A67C52"; // Theme core brass
      ctx.lineWidth = 2.5;

      const drawHighroad = (points: {x: number, y: number}[]) => {
        ctx.beginPath();
        points.forEach((pt, idx) => {
          const cc = getCanvasCoords(pt.x, pt.y, w, h);
          if (idx === 0) ctx.moveTo(cc.x, cc.y);
          else ctx.lineTo(cc.x, cc.y);
        });
        ctx.stroke();
      };

      // M1 / A1(M) North-South spine
      drawHighroad([
        { x: 48, y: 99 },
        { x: 48, y: 75 },
        { x: 50, y: 55 },
        { x: 53, y: 35 },
        { x: 54, y: 0 }
      ]);

      // M62 Transpennine corridor (East-West)
      ctx.strokeStyle = "#A67C52"; // Theme core brass motorway
      drawHighroad([
        { x: 0, y: 58 },
        { x: 35, y: 57 },
        { x: 50, y: 55 },
        { x: 70, y: 56 },
        { x: 99, y: 60 }
      ]);

      // Railways (Dashed grey lines with sleepers)
      ctx.strokeStyle = activeLayers.satellite ? "rgba(255, 255, 255, 0.4)" : "#334155";
      ctx.lineWidth = 1.2;
      ctx.setLineDash([6, 4]);
      
      // East Coast Main Line
      drawHighroad([
        { x: 62, y: 99 },
        { x: 62, y: 72 },
        { x: 65, y: 40 },
        { x: 60, y: 20 },
        { x: 58, y: 0 }
      ]);
      ctx.setLineDash([]);
    }

    // 7. PROPERTY PINS & PULSING HIGHLIGHTS
    properties.forEach((prop) => {
      const isSelected = selectedProperty?.id === prop.id;
      const isHovered = hoveredProperty?.id === prop.id;
      const isFilteredOut = !filteredProperties.some((p) => p.id === prop.id);
      
      const pos = getCanvasCoords(prop.coordinates.x, prop.coordinates.y, w, h);

      // Don't render if completely outside canvas boundary limits
      if (pos.x < 0 || pos.x > w || pos.y < 0 || pos.y > h) return;

      if (isFilteredOut) {
        ctx.globalAlpha = 0.18; // significantly dim inactive items
      } else {
        ctx.globalAlpha = 1.0;
      }

      // Draw subtle pulsing background circle for highlighted assets
      if (isSelected || isHovered) {
        ctx.fillStyle = "rgba(166, 124, 82, 0.15)"; // brass glow
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 22, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.strokeStyle = "#A67C52"; // Brass gold border
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 22, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Core property pin
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 7, 0, Math.PI * 2);

      // Fill color depends on property category
      if (prop.type === PropertyType.AGRICULTURAL_LAND || prop.type === PropertyType.FORESTRY) {
        ctx.fillStyle = "#15803d"; // Forest green
      } else if (prop.type === PropertyType.LOGISTICS_PARK || prop.type === PropertyType.WAREHOUSE || prop.type === PropertyType.FACTORY) {
        ctx.fillStyle = "#1e293b"; // Slate black
      } else if (prop.type === PropertyType.DEVELOPMENT_LAND || prop.type === PropertyType.MIXED_USE) {
        ctx.fillStyle = "#A67C52"; // Rich brass gold
      } else {
        ctx.fillStyle = "#0369a1"; // Slate Blue
      }
      ctx.fill();

      // Sharp white inner dot for professional contrast
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 2.2, 0, Math.PI * 2);
      ctx.fill();

      // Draw labels above hovered or selected assets
      if (isHovered || isSelected) {
        ctx.globalAlpha = 1.0;
        ctx.font = "bold 11px system-ui, sans-serif";
        ctx.fillStyle = activeLayers.satellite ? "#ffffff" : "#1e293b";
        ctx.textAlign = "center";
        
        // Background box for text
        const textWidth = ctx.measureText(prop.title).width;
        ctx.fillStyle = activeLayers.satellite ? "rgba(15, 23, 42, 0.95)" : "rgba(255, 255, 255, 0.95)";
        ctx.strokeStyle = activeLayers.satellite ? "rgba(255, 255, 255, 0.15)" : "rgba(0,0,0,0.1)";
        ctx.lineWidth = 1;
        ctx.fillRect(pos.x - textWidth/2 - 8, pos.y - 28, textWidth + 16, 18);
        ctx.strokeRect(pos.x - textWidth/2 - 8, pos.y - 28, textWidth + 16, 18);

        ctx.fillStyle = activeLayers.satellite ? "#f8fafc" : "#0f172a";
        ctx.fillText(prop.title, pos.x, pos.y - 15);
      }

      ctx.globalAlpha = 1.0; // Reset transparency
    });

    // 8. RENDER DRAWN FILTER BOUNDARY (Polygon)
    if (drawnPoints.length > 0) {
      ctx.strokeStyle = "#16a34a"; // emerald green
      ctx.fillStyle = "rgba(22, 163, 74, 0.15)"; // transparent green
      ctx.lineWidth = 2.2;

      ctx.beginPath();
      drawnPoints.forEach((p, idx) => {
        const cc = getCanvasCoords(p.x, p.y, w, h);
        if (idx === 0) ctx.moveTo(cc.x, cc.y);
        else ctx.lineTo(cc.x, cc.y);
      });

      if (!isDrawing) {
        ctx.closePath();
        ctx.fill();
      }
      ctx.stroke();

      // Render dots on each coordinate point
      drawnPoints.forEach((p) => {
        const cc = getCanvasCoords(p.x, p.y, w, h);
        ctx.fillStyle = "#15803d";
        ctx.beginPath();
        ctx.arc(cc.x, cc.y, 4, 0, Math.PI * 2);
        ctx.fill();
      });
    }

  }, [properties, selectedProperty, filteredProperties, activeLayers, zoom, offset, isDrawing, drawnPoints, hoveredProperty]);

  // Handle zooming
  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.2, 4.0));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.2, 0.6));
  const handleReset = () => {
    setZoom(1.0);
    setOffset({ x: 0, y: 0 });
    resetDrawing();
  };

  return (
    <div id="gis-viewport" className="flex flex-col h-full bg-dark rounded-none border-2 border-dark text-white overflow-hidden relative" ref={containerRef}>
      {/* Top Bar controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border-b-2 border-dark px-4 py-3 z-10 rounded-none">
        <div className="flex items-center space-x-2 rounded-none">
          <Compass className="h-5 w-5 text-primary animate-spin-slow" />
          <div className="rounded-none">
            <h3 className="text-xs font-black tracking-widest text-dark font-mono uppercase">GIS SPATIAL VIEWER</h3>
            <p className="text-[10px] text-stone-500 font-mono uppercase font-bold">Yorkshire Grid Ref Reference System</p>
          </div>
        </div>

        {/* Action Toggles */}
        <div className="flex items-center space-x-2 rounded-none">
          <button
            onClick={() => setIsDrawing(!isDrawing)}
            className={`flex items-center space-x-1.5 px-3 py-1 font-mono text-xs border-2 border-dark rounded-none font-black uppercase transition cursor-pointer ${
              isDrawing
                ? "bg-emerald-700 text-white border-dark"
                : "bg-white text-dark hover:bg-primary hover:text-white"
            }`}
            title="Plot points on map to filter assets within a custom boundary."
          >
            <Brush className="h-3.5 w-3.5" />
            <span>{isDrawing ? "DRAWING BOUNDARY..." : "DRAW BOUNDARY"}</span>
          </button>

          {drawnPoints.length > 0 && (
            <>
              {isDrawing && (
                <button
                  onClick={finishDrawing}
                  className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-950 border-2 border-dark text-white font-mono text-xs font-black uppercase transition rounded-none cursor-pointer"
                >
                  COMPLETE
                </button>
              )}
              <button
                onClick={resetDrawing}
                className="p-1 bg-white border-2 border-dark text-dark hover:bg-primary hover:text-white transition rounded-none cursor-pointer"
                title="Clear Boundary Filter"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            </>
          )}

          <div className="h-4 w-[2px] bg-dark"></div>

          <button
            onClick={handleZoomIn}
            className="p-1 bg-white border-2 border-dark text-dark hover:bg-primary hover:text-white transition rounded-none cursor-pointer"
          >
            <ZoomIn className="h-4 w-4" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-1 bg-white border-2 border-dark text-dark hover:bg-primary hover:text-white transition rounded-none cursor-pointer"
          >
            <ZoomOut className="h-4 w-4" />
          </button>
          <button
            onClick={handleReset}
            className="px-2 py-1 bg-white border-2 border-dark text-dark hover:bg-primary hover:text-white transition text-[10px] font-mono font-black uppercase rounded-none cursor-pointer"
          >
            RESET PAN
          </button>
        </div>
      </div>

      {/* Layer selector shelf */}
      <div className="flex flex-wrap items-center gap-2 bg-stone-100 border-b-2 border-dark px-4 py-2 text-xs rounded-none text-dark">
        <span className="text-[10px] text-stone-500 font-mono flex items-center space-x-1 uppercase font-black rounded-none">
          <Layers className="h-3 w-3 mr-1" /> ACTIVE LAYERS:
        </span>
        
        <button
          onClick={() => toggleLayer("satellite")}
          className={`px-2 py-0.5 font-mono text-[10px] border-2 transition rounded-none font-black uppercase cursor-pointer ${
            activeLayers.satellite
              ? "bg-primary text-white border-dark"
              : "bg-white text-dark border-dark hover:border-primary"
          }`}
        >
          SATELLITE IMAGERY
        </button>

        <button
          onClick={() => toggleLayer("topographic")}
          className={`px-2 py-0.5 font-mono text-[10px] border-2 transition rounded-none font-black uppercase cursor-pointer ${
            activeLayers.topographic
              ? "bg-primary text-white border-dark"
              : "bg-white text-dark border-dark hover:border-primary"
          }`}
        >
          CONTOURS & TOPO
        </button>

        <button
          onClick={() => toggleLayer("planning")}
          className={`px-2 py-0.5 font-mono text-[10px] border-2 transition rounded-none font-black uppercase cursor-pointer ${
            activeLayers.planning
              ? "bg-primary text-white border-dark"
              : "bg-white text-dark border-dark hover:border-primary"
          }`}
        >
          PLANNING SITES / REGIONS
        </button>

        <button
          onClick={() => toggleLayer("transport")}
          className={`px-2 py-0.5 font-mono text-[10px] border-2 transition rounded-none font-black uppercase cursor-pointer ${
            activeLayers.transport
              ? "bg-primary text-white border-dark"
              : "bg-white text-dark border-dark hover:border-primary"
          }`}
        >
          TRANSIT & CORRIDORS
        </button>

        <button
          onClick={() => toggleLayer("flood")}
          className={`px-2 py-0.5 font-mono text-[10px] border-2 transition rounded-none font-black uppercase cursor-pointer ${
            activeLayers.flood
              ? "bg-red-700 text-white border-dark"
              : "bg-white text-dark border-dark hover:border-red-700"
          }`}
        >
          FLOOD RISK ASSESSMENT
        </button>
      </div>

      {/* Main Canvas Area */}
      <div className="relative flex-1 bg-dark cursor-crosshair overflow-hidden rounded-none">
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onClick={handleClick}
          className="absolute inset-0 w-full h-full block rounded-none"
        />

        {/* GIS HUD / Informational panel overlay */}
        <div className="absolute bottom-4 left-4 bg-dark/95 border-2 border-dark p-3 w-64 text-white font-mono text-[10px] space-y-1.5 z-10 pointer-events-none select-none rounded-none shadow-none">
          <div className="flex items-center justify-between border-b border-stone-700 pb-1 mb-1 rounded-none">
            <span className="font-black text-primary">GIS MATRIX SENSOR</span>
            <span className="text-[9px] text-emerald-400 font-black">ONLINE</span>
          </div>
          <div className="flex justify-between rounded-none">
            <span className="text-stone-500 font-bold">COORDINATE MASK:</span>
            <span className="font-bold">OSGB36 / GRID SE</span>
          </div>
          <div className="flex justify-between rounded-none">
            <span className="text-stone-500 font-bold">CURSOR POS:</span>
            <span className="font-bold">
              {hoveredProperty
                ? `${hoveredProperty.coordinates.gridRef}`
                : isDrawing && drawnPoints.length > 0
                ? `SE ${Math.round(drawnPoints[drawnPoints.length - 1].x * 100)} ${Math.round(
                    drawnPoints[drawnPoints.length - 1].y * 100
                  )}`
                : "SCANNING CORRIDOR..."}
            </span>
          </div>
          <div className="flex justify-between rounded-none">
            <span className="text-stone-500 font-bold">BOUND FILTER:</span>
            <span className={`font-black ${drawnPoints.length > 0 ? "text-emerald-400" : "text-stone-500"}`}>
              {drawnPoints.length > 0 ? `${drawnPoints.length} VERTICES PLOTTED` : "INACTIVE"}
            </span>
          </div>
          <div className="flex justify-between rounded-none">
            <span className="text-stone-500 font-bold">ZOOM RATIO:</span>
            <span className="font-bold">{Math.round(zoom * 100)}%</span>
          </div>
        </div>

        {/* Drawer tooltip overlay */}
        {isDrawing && (
          <div className="absolute top-4 left-4 bg-emerald-950/95 border-2 border-dark p-3 text-emerald-200 font-mono text-[11px] max-w-sm rounded-none z-10 shadow-none">
            <div className="flex items-start space-x-2 rounded-none">
              <AlertTriangle className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5 animate-pulse" />
              <div className="rounded-none">
                <p className="font-black uppercase tracking-wider text-white">Boundary Drawing Mode Active</p>
                <p className="text-[10px] text-emerald-200 mt-1 leading-relaxed font-bold">
                  1. Click multiple times directly on the map surface to draw a custom filter polygon.
                  <br />
                  2. Click <span className="font-bold underline">COMPLETE</span> at the top right once you finish.
                  <br />
                  3. The portal will automatically isolate properties inside that area.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Map Legend */}
      <div className="bg-stone-100 border-t-2 border-dark px-4 py-2.5 flex flex-wrap items-center justify-between text-[10px] font-mono gap-3 rounded-none text-dark">
        <div className="flex items-center space-x-4 flex-wrap gap-y-2 rounded-none">
          <span className="text-stone-500 uppercase font-black rounded-none">PIN CLASSIFICATION:</span>
          <span className="flex items-center space-x-1 rounded-none font-bold">
            <span className="h-2.5 w-2.5 rounded-none bg-emerald-700 block border border-dark"></span>
            <span>AGRICULTURAL / FORESTRY</span>
          </span>
          <span className="flex items-center space-x-1 rounded-none font-bold">
            <span className="h-2.5 w-2.5 rounded-none bg-dark block border border-stone-500"></span>
            <span>LOGISTICS / FACTORIES</span>
          </span>
          <span className="flex items-center space-x-1 rounded-none font-bold">
            <span className="h-2.5 w-2.5 rounded-none bg-primary block border border-dark"></span>
            <span>DEVELOPMENT / MIXED USE</span>
          </span>
          <span className="flex items-center space-x-1 rounded-none font-bold">
            <span className="h-2.5 w-2.5 rounded-none bg-sky-700 block border border-dark"></span>
            <span>BUSINESS & SCIENCE PARKS</span>
          </span>
        </div>
        <div className="text-stone-500 text-[9px] uppercase font-bold rounded-none">
          DRAG MOUSE TO PAN • SCROLL TO ZOOM • CLICK PIN TO INSPECT DETAILS
        </div>
      </div>
    </div>
  );
}
