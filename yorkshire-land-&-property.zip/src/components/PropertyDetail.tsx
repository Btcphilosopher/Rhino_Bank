import React, { useState } from "react";
import { Property, PropertyType, FinancingApplication } from "../types";
import { 
  Building, MapPin, Scale, ChevronRight, FileText, Calculator, 
  Sparkles, Train, HelpCircle, AlertCircle, ShieldCheck, HardHat, 
  ArrowRight, Landmark, UploadCloud, CheckCircle, Compass, RefreshCw
} from "lucide-react";

interface PropertyDetailProps {
  property: Property;
  onBack: () => void;
  onApplyFinance: (application: FinancingApplication) => void;
  onAddToast: (msg: string, type: "success" | "info" | "error") => void;
}

export default function PropertyDetail({
  property,
  onBack,
  onApplyFinance,
  onAddToast
}: PropertyDetailProps) {
  const [activeTab, setActiveTab] = useState<"overview" | "finance" | "planning" | "intelligence">("overview");
  
  // Rhino Bank Financing tool state
  const [loanType, setLoanType] = useState<"Mortgage" | "Development" | "Bridging">("Mortgage");
  const [leveragePercent, setLeveragePercent] = useState<number>(65); // 65% LTV default
  const [loanTermYears, setLoanTermYears] = useState<number>(15);
  const [financeSubmitted, setFinanceSubmitted] = useState<boolean>(false);
  const [financeNotes, setFinanceNotes] = useState<string>("");

  // AI Intelligence Report generator state
  const [isGeneratingReport, setIsGeneratingReport] = useState<boolean>(false);
  const [aiReport, setAiReport] = useState<string | null>(null);

  // Formatting utilities
  const formatCurrency = (val: number) => {
    if (val === 0) return "POA (Price on Application)";
    return new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(val);
  };

  const formatSqFt = (val?: number) => {
    if (!val) return "N/A";
    return new Intl.NumberFormat("en-GB").format(val) + " sq ft";
  };

  // Financing calculation constants
  const getInterestRate = () => {
    switch (loanType) {
      case "Mortgage": return 5.85; // 5.85% annual interest
      case "Development": return 7.25; // 7.25%
      case "Bridging": return 0.85; // 0.85% monthly
    }
  };

  const calculatedFinancing = () => {
    if (property.price === 0) return null;
    const principal = property.price * (leveragePercent / 100);
    const deposit = property.price - principal;
    const annualRate = getInterestRate();
    
    let monthlyRepayment = 0;
    if (loanType === "Bridging") {
      // Monthly interest-only bridging calculation
      monthlyRepayment = principal * (annualRate / 100);
    } else {
      // Standard amortized calculation
      const monthlyRate = (annualRate / 100) / 12;
      const totalPayments = loanTermYears * 12;
      monthlyRepayment = (principal * monthlyRate * Math.pow(1 + monthlyRate, totalPayments)) / (Math.pow(1 + monthlyRate, totalPayments) - 1);
    }

    return {
      principal,
      deposit,
      monthlyRepayment,
      interestRate: annualRate
    };
  };

  const fin = calculatedFinancing();

  // Submit to Rhino Bank Integrated Finance Engine
  const handleSubmitFinance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fin) return;

    const refNumber = `RHN-${Math.floor(100000 + Math.random() * 900000)}`;
    const app: FinancingApplication = {
      id: `app-${Date.now()}`,
      propertyId: property.id,
      propertyTitle: property.title,
      type: loanType === "Mortgage" ? "Mortgage" : loanType === "Development" ? "Development" : "Bridging",
      amount: fin.principal,
      status: "Under Review",
      dateApplied: new Date().toLocaleDateString("en-GB"),
      referenceNo: refNumber,
      documents: [
        { name: "Property Prospectus Summary", date: new Date().toLocaleDateString("en-GB"), status: "Verified" },
        { name: "Environmental Rating Statement", date: new Date().toLocaleDateString("en-GB"), status: "Verified" },
        { name: "Corporate Financial Accounts", date: "Pending", status: "Action Required" },
        { name: "Detailed Site Valuation", date: "Pending", status: "Rhino Appointed" }
      ]
    };

    onApplyFinance(app);
    setFinanceSubmitted(true);
    onAddToast(`Rhino Bank Finance Application ${refNumber} has been successfully compiled and submitted!`, "success");
  };

  // Call server-side Gemini API endpoint
  const handleGenerateAIReport = async () => {
    setIsGeneratingReport(true);
    setAiReport(null);
    onAddToast("Initiating server-side Gemini 3.6-flash Intelligence Core...", "info");

    try {
      const response = await fetch("/api/intelligence/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ propertyId: property.id })
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with AI intelligence server.");
      }

      const data = await response.json();
      setAiReport(data.report);
      onAddToast("Comprehensive Property Intelligence briefing compiled successfully.", "success");
    } catch (err: any) {
      console.error(err);
      onAddToast(`AI Compilation Failed: ${err.message || err}`, "error");
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div id={`prospectus-${property.id}`} className="max-w-7xl mx-auto bg-cream border-2 border-dark shadow-none relative overflow-hidden rounded-none">
      {/* Editorial Title banner */}
      <div className="border-b-2 border-dark px-6 py-5 md:px-10 md:py-8 bg-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4 rounded-none">
        <div>
          <button 
            onClick={onBack} 
            className="text-xs font-mono tracking-widest text-primary hover:underline uppercase flex items-center mb-2 font-bold cursor-pointer"
          >
            ← Back to Yorkshire Marketplace
          </button>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 bg-dark text-[10px] text-white font-mono uppercase tracking-widest font-extrabold rounded-none">
              RHINO PROPERTY INTEL
            </span>
            <span className="px-2 py-0.5 border border-border-muted text-[10px] text-stone-600 font-mono uppercase rounded-none font-semibold">
              {property.planningStatus}
            </span>
          </div>
          <h1 className="text-xl md:text-3xl font-black tracking-tight text-dark mt-2 font-serif uppercase">
            {property.title}
          </h1>
          <div className="flex items-center text-stone-500 font-mono text-xs mt-1.5 space-x-1">
            <MapPin className="h-3.5 w-3.5 text-primary shrink-0" />
            <span>{property.location.town}, {property.location.county} ({property.location.postcode})</span>
          </div>
        </div>
        <div className="text-left md:text-right">
          <span className="block text-[10px] font-mono text-stone-400 uppercase tracking-widest">ESTIMATED ASSET CAPITAL VALUE</span>
          <span className="text-2xl md:text-3xl font-black text-primary font-mono tracking-tight">
            {formatCurrency(property.price)}
          </span>
          <span className="block text-xs font-mono text-stone-500 mt-1 font-bold">{property.tenure} Option</span>
        </div>
      </div>

      {/* Hero Drone simulation section / Aerial photo placeholder */}
      <div className="relative h-[280px] md:h-[450px] bg-dark overflow-hidden group rounded-none border-b-2 border-dark">
        <img 
          src={property.droneSimulationImage} 
          alt={`${property.title} Aerial`}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-85 transition-transform duration-1000 group-hover:scale-105"
        />
        {/* Topographic outline details printed over photo */}
        <div className="absolute inset-0 bg-gradient-to-t from-dark/90 via-transparent to-dark/50 pointer-events-none p-6 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="bg-dark/90 backdrop-blur-none border border-stone-800 p-2 text-stone-300 font-mono text-[9px] uppercase space-y-0.5 rounded-none">
              <p>GRID REF: {property.coordinates.gridRef}</p>
              <p>REGION: {property.location.region}</p>
            </div>
            <div className="bg-primary text-white p-2 font-mono text-[10px] tracking-widest uppercase font-bold rounded-none">
              BREEAM: RATING {property.environmentalRating}
            </div>
          </div>
          
          <div className="flex justify-between items-end flex-wrap gap-2 text-white">
            <div>
              <p className="text-[10px] font-mono text-stone-300 uppercase">Primary Classification</p>
              <p className="text-lg font-serif font-bold italic tracking-wide">{property.type}</p>
            </div>
            <div className="flex space-x-6 text-right">
              {property.floorAreaSqFt && (
                <div>
                  <p className="text-[10px] font-mono text-stone-300 uppercase">Internal Area</p>
                  <p className="text-sm font-mono font-bold">{formatSqFt(property.floorAreaSqFt)}</p>
                </div>
              )}
              {property.landAreaAcres && (
                <div>
                  <p className="text-[10px] font-mono text-stone-300 uppercase">Site Footprint</p>
                  <p className="text-sm font-mono font-bold">{property.landAreaAcres} Acres</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Swiss Editorial Tab Selection */}
      <div className="flex border-b-2 border-dark bg-white rounded-none">
        {(["overview", "finance", "planning", "intelligence"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-4 text-center font-mono text-xs tracking-wider uppercase border-r border-border-muted transition rounded-none cursor-pointer ${
              activeTab === tab 
                ? "bg-dark text-white font-extrabold" 
                : "text-stone-500 hover:text-dark hover:bg-cream/40"
            }`}
          >
            {tab === "intelligence" ? "✦ AI INTELLIGENCE" : tab}
          </button>
        ))}
      </div>

      {/* Content panes */}
      <div className="p-6 md:p-10 bg-white">
        
        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Main content editorial */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h3 className="text-xs font-mono text-stone-400 uppercase tracking-widest mb-3">EXECUTIVE SUMMARY</h3>
                <p className="text-stone-800 leading-relaxed font-serif text-base md:text-lg first-letter:text-4xl first-letter:font-sans first-letter:font-bold first-letter:float-left first-letter:mr-2">
                  {property.description}
                </p>
              </div>
              <div className="border-t border-border-muted pt-6">
                <h3 className="text-xs font-mono text-stone-400 uppercase tracking-widest mb-3">KEY INVESTMENT HIGHLIGHTS</h3>
                <ul className="space-y-3 font-mono text-xs text-stone-700">
                  {property.highlights.map((high, idx) => (
                    <li key={idx} className="flex items-start space-x-2">
                      <ChevronRight className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      <span>{high}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Local Economic Profile */}
              <div className="border-t border-border-muted pt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-[10px] font-mono text-stone-400 uppercase tracking-widest mb-3">REGIONAL WORKFORCE DEMOGRAPHY</h4>
                  <div className="space-y-2 text-xs font-mono text-stone-700 bg-stone-50 p-3 border border-border-muted rounded-none">
                    <div className="flex justify-between">
                      <span>Employment rate:</span>
                      <span className="font-bold">{property.economicProfile.employmentRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Average local salary:</span>
                      <span className="font-bold">£{property.economicProfile.averageSalary.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Population Trend:</span>
                      <span className="font-bold">{property.economicProfile.populationTrend}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] font-mono text-stone-400 uppercase tracking-widest mb-3">LOCAL BUSINESS CONCENTRATION</h4>
                  <div className="space-y-2 text-xs font-mono text-stone-700 bg-stone-50 p-3 border border-border-muted rounded-none">
                    {property.localBusinessData.map((data, idx) => (
                      <div key={idx} className="flex justify-between">
                        <span>{data.Sector}:</span>
                        <span className="font-bold">{data.Count} Operations</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Side-box Grid specification */}
            <div className="space-y-6">
              <div className="bg-dark p-5 text-stone-300 font-mono text-xs border border-border-muted shadow-none rounded-none">
                <div className="flex items-center space-x-1 border-b border-stone-800 pb-2 mb-3">
                  <Landmark className="h-4 w-4 text-primary" />
                  <span className="text-[10px] tracking-widest text-white uppercase font-black">Rhino Institutional Audit</span>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-stone-500 font-bold">ASSET ID:</span>
                    <span className="text-white font-bold">{property.id.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500 font-bold">GRID REF:</span>
                    <span className="text-white font-bold">{property.coordinates.gridRef}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500 font-bold">PLANNING CLS:</span>
                    <span className="text-white font-bold">{property.industrialClassification || "N/A - Specified Land"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500 font-bold">AVAILABILITY:</span>
                    <span className="text-emerald-400 font-bold uppercase">Immediate Contract</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500 font-bold">TENURE TYPE:</span>
                    <span className="text-white font-bold">{property.tenure}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500 font-bold">BREEAM CO2:</span>
                    <span className="text-primary font-bold">EPC {property.environmentalRating} Rating</span>
                  </div>
                </div>
              </div>

              {/* Infrastructure Quick status */}
              <div className="border border-border-muted p-5 space-y-4 bg-cream/30 rounded-none">
                <h4 className="text-[10px] font-mono text-stone-400 uppercase tracking-widest border-b border-border-muted pb-1.5 font-bold">
                  COMMERCIAL TRANSPORT CORRIDORS
                </h4>

                <div className="space-y-2.5 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-1.5 text-dark">
                      <Train className="h-3.5 w-3.5 text-primary" />
                      <span>Direct Rail Access:</span>
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-none ${
                      property.infrastructure.railAccess ? "bg-emerald-100 text-emerald-800" : "bg-stone-200 text-stone-600"
                    }`}>
                      {property.infrastructure.railAccess ? `ACTIVE (${property.infrastructure.railAccessDistanceMiles} mi)` : "NO ACCESS"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-1.5 text-dark">
                      <Building className="h-3.5 w-3.5 text-primary" />
                      <span>Motorway Network:</span>
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-none ${
                      property.infrastructure.motorwayAccess ? "bg-emerald-100 text-emerald-800" : "bg-stone-200 text-stone-600"
                    }`}>
                      {property.infrastructure.motorwayAccess ? `ACTIVE (${property.infrastructure.motorwayAccessDistanceMiles} mi)` : "DISTANT"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-1.5 text-dark">
                      <Compass className="h-3.5 w-3.5 text-primary" />
                      <span>Airport Access:</span>
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-none ${
                      property.infrastructure.airportAccess ? "bg-emerald-100 text-emerald-800" : "bg-stone-200 text-stone-600"
                    }`}>
                      {property.infrastructure.airportAccess ? `ACTIVE (${property.infrastructure.airportAccessDistanceMiles} mi)` : "DISTANT"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-1.5 text-dark">
                      <ShieldCheck className="h-3.5 w-3.5 text-primary" />
                      <span>Enterprise Zone:</span>
                    </span>
                    <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-none ${
                      property.infrastructure.enterpriseZone ? "bg-amber-100 text-amber-800 border border-amber-300" : "bg-stone-100 text-stone-500"
                    }`}>
                      {property.infrastructure.enterpriseZone ? "TAX EXEMPT STATUS" : "STANDARD"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* FINANCE TAB */}
        {activeTab === "finance" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Calculator Panel */}
            <div className="lg:col-span-7 space-y-6">
              <div className="border-2 border-dark p-6 bg-cream/20 rounded-none">
                <div className="flex items-center space-x-2 border-b border-border-muted pb-3 mb-5">
                  <Calculator className="h-5 w-5 text-primary" />
                  <h3 className="font-serif text-lg font-black text-dark uppercase">Rhino Bank Port finance Compiler</h3>
                </div>

                <form onSubmit={handleSubmitFinance} className="space-y-4 font-mono text-xs text-dark">
                  <div className="grid grid-cols-3 gap-3">
                    {(["Mortgage", "Development", "Bridging"] as const).map((type) => (
                      <button
                        type="button"
                        key={type}
                        onClick={() => {
                          setLoanType(type);
                          if (type === "Bridging") setLoanTermYears(1); // bridging is short-term
                        }}
                        className={`py-2 px-3 border transition text-center rounded-none cursor-pointer text-[10px] ${
                          loanType === type 
                            ? "bg-dark text-white border-dark font-extrabold" 
                            : "bg-white border-border-muted text-stone-500 hover:border-dark"
                        }`}
                      >
                        {type === "Mortgage" ? "Mortgage (Term)" : type === "Development" ? "Dev Credit" : "Bridge Loan"}
                      </button>
                    ))}
                  </div>

                  <div>
                    <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1.5 font-bold">
                      DEVERAGE LEVEL (LTV PERCENTAGE): {leveragePercent}%
                    </label>
                    <input 
                      type="range" 
                      min="30" 
                      max="80" 
                      value={leveragePercent} 
                      onChange={(e) => setLeveragePercent(Number(e.target.value))}
                      className="w-full accent-primary cursor-pointer"
                    />
                    <div className="flex justify-between text-[9px] text-stone-400 mt-1 font-bold">
                      <span>30% LTV (Conservative)</span>
                      <span>50% LTV</span>
                      <span>80% LTV (Max Rhino Limit)</span>
                    </div>
                  </div>

                  {loanType !== "Bridging" && (
                    <div>
                      <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1.5 font-bold">
                        REPAYMENT AMORTIZATION CONTRACT: {loanTermYears} YEARS
                      </label>
                      <input 
                        type="range" 
                        min="5" 
                        max="30" 
                        value={loanTermYears} 
                        onChange={(e) => setLoanTermYears(Number(e.target.value))}
                        className="w-full accent-primary cursor-pointer"
                      />
                      <div className="flex justify-between text-[9px] text-stone-400 mt-1 font-bold">
                        <span>5 Years (Agile)</span>
                        <span>15 Years</span>
                        <span>30 Years (Maximum Maturity)</span>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1.5 font-bold">
                      APPLICATION MEMORANDUM & STRATEGIC INTENT
                    </label>
                    <textarea
                      rows={3}
                      value={financeNotes}
                      onChange={(e) => setFinanceNotes(e.target.value)}
                      placeholder="Specify your investment goals, development roadmap, or portfolio expansion parameters for underwriting review..."
                      className="w-full p-2.5 border border-border-muted text-xs bg-white text-dark focus:border-primary outline-none rounded-none"
                    />
                  </div>

                  {!financeSubmitted ? (
                    <button
                      type="submit"
                      className="w-full bg-dark hover:bg-primary text-white font-black py-3 uppercase tracking-wider font-mono text-xs flex items-center justify-center space-x-2 transition rounded-none cursor-pointer"
                    >
                      <Landmark className="h-4 w-4 text-primary" />
                      <span>COMPILE & SUBMIT LOAN TO RHINO UNDERWRITING</span>
                    </button>
                  ) : (
                    <div className="bg-emerald-50 border-2 border-emerald-500 p-4 text-emerald-900 flex items-start space-x-2 rounded-none">
                      <CheckCircle className="h-5 w-5 shrink-0 mt-0.5 text-emerald-600" />
                      <div>
                        <p className="font-extrabold">RHINO CORPORATE LOAN PORTAL INITIATED</p>
                        <p className="text-[11px] mt-0.5">
                          Underwriting ref submitted. The dossier is active in your **Client Dashboard**. Please review outstanding document uploads there to complete underwriting compliance.
                        </p>
                      </div>
                    </div>
                  )}
                </form>
              </div>
            </div>

            {/* Calculations results sidebar */}
            <div className="lg:col-span-5 space-y-6">
              <div className="border-2 border-dark p-5 bg-white text-dark font-mono text-xs space-y-4 rounded-none">
                <h4 className="text-[10px] text-stone-400 uppercase tracking-widest border-b border-border-muted pb-1.5 font-bold">
                  FINANCING COMMODITY DETAILS
                </h4>

                {fin && (
                  <div className="space-y-3.5">
                    <div className="flex justify-between items-center">
                      <span className="text-stone-500 font-bold">LOAN CLASS:</span>
                      <span className="font-extrabold uppercase bg-cream px-2 py-0.5 border border-border-muted rounded-none">{loanType}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-stone-500 font-bold">UNDERWRITING RATE:</span>
                      <span className="font-extrabold text-primary text-sm">
                        {fin.interestRate}% {loanType === "Bridging" ? "Monthly Interest-Only" : "Annual Fixed"}
                      </span>
                    </div>

                    <div className="flex justify-between items-center border-t border-border-muted pt-2">
                      <span className="text-stone-500 font-bold">PRINCIPAL LEVERAGE:</span>
                      <span className="font-extrabold text-dark">{formatCurrency(fin.principal)}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-stone-500 font-bold">REQUIRED DEPOSIT:</span>
                      <span className="font-extrabold text-dark">{formatCurrency(fin.deposit)}</span>
                    </div>

                    <div className="flex justify-between items-center border-t-2 border-dark pt-3">
                      <div>
                        <span className="text-[9px] text-stone-400 uppercase block font-bold">INDICATIVE REPAYMENT</span>
                        <span className="text-stone-500 text-[10px] font-semibold">({loanType === "Bridging" ? "Interest Only" : "Principal + Interest"})</span>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-lg text-dark block font-mono">
                          {formatCurrency(fin.monthlyRepayment)}
                        </span>
                        <span className="text-[9px] text-stone-400 font-bold">per calendar month</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-dark p-4 text-stone-300 text-[10px] leading-relaxed border border-border-muted rounded-none">
                  <div className="flex items-center space-x-1.5 mb-1.5 text-white">
                    <ShieldCheck className="h-4 w-4 text-primary" />
                    <span className="font-extrabold uppercase tracking-wider">RHINO BANK DECREE</span>
                  </div>
                  <p className="font-mono">
                    All financing options are compiled dynamically based on prime corporate lending rates index. Actual commercial bridge or portfolio loan approvals are subject to complete site inspections, localized environmental impact surveys, and asset yield validations by accredited Rhino Bank surveyors.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PLANNING & INFRASTRUCTURE TAB */}
        {activeTab === "planning" && (
          <div className="space-y-8 font-serif">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Planning info card */}
              <div className="lg:col-span-2 space-y-6">
                <div>
                  <h3 className="text-xs font-mono text-stone-400 uppercase tracking-widest mb-2 font-bold">PLANNING & EXPANSION MATRIX</h3>
                  <div className="border-2 border-dark p-5 bg-cream/25 space-y-4 rounded-none">
                    <div className="flex items-center space-x-2">
                      <HardHat className="h-5 w-5 text-primary" />
                      <span className="font-mono text-xs font-extrabold text-dark uppercase tracking-widest">
                        PLANNING STATUS: {property.planningStatus}
                      </span>
                    </div>
                    <p className="text-stone-800 leading-relaxed font-serif text-sm">
                      {property.developmentPotential}
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-xs font-mono text-stone-400 uppercase tracking-widest mb-3 font-bold">NEARBY INVESTMENT MASTERPLAN</h3>
                  <p className="text-stone-800 leading-relaxed font-serif text-sm">
                    {property.nearbyInvestment}
                  </p>
                </div>
              </div>

              {/* Side facts */}
              <div>
                <h3 className="text-xs font-mono text-stone-400 uppercase tracking-widest mb-3 font-bold">ENVIRONMENTAL RATING AUDIT</h3>
                <div className="border-2 border-dark p-5 bg-white space-y-4 font-mono text-xs rounded-none">
                  <div className="flex items-center justify-between">
                    <span className="font-bold">CO2 Rating Index:</span>
                    <span className="px-2 py-0.5 bg-dark text-white font-extrabold text-[10px] rounded-none">EPC {property.environmentalRating}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold">Freeport status:</span>
                    <span className="font-bold text-dark">{property.infrastructure.enterpriseZone ? "ACTIVE EXEMPT" : "STANDARD CORRIDOR"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold">Peatland / Carbon Index:</span>
                    <span className="font-bold text-dark">{property.type === PropertyType.AGRICULTURAL_LAND ? "PROTECTED V3" : "SECURED DEVELOPMENT"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold">Regional Yield Target:</span>
                    <span className="font-bold text-dark">{(property.price > 0 ? (6.4 + Math.random()).toFixed(2) : 7.2)}% Indicative</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* AI INTELLIGENCE TAB */}
        {activeTab === "intelligence" && (
          <div className="space-y-6 font-serif">
            <div className="border-2 border-dark bg-cream/25 p-6 md:p-8 relative rounded-none">
              {/* Dynamic premium watermarks */}
              <div className="absolute top-4 right-4 text-[9px] font-mono text-stone-400 uppercase tracking-widest border border-border-muted px-2 py-1 select-none pointer-events-none rounded-none font-bold">
                RHINO INTEL LABS
              </div>

              <div className="max-w-3xl">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <h3 className="font-serif text-xl font-black text-dark uppercase">
                    ✦ Yorkshire Land Intelligence Compiler
                  </h3>
                </div>
                
                <p className="text-stone-700 text-sm leading-relaxed mb-6 font-serif">
                  Leveraging server-side **Gemini 3.6-flash Intelligence**, our core compiles deep spatial analysis, municipal planning framework assessments, carbon sequestration dynamics, comparable transaction registers, and transport yield factors for **{property.title}** dynamically.
                </p>

                {!aiReport ? (
                  <button
                    onClick={handleGenerateAIReport}
                    disabled={isGeneratingReport}
                    className="px-6 py-3 bg-dark text-white hover:bg-primary font-mono text-xs font-bold uppercase tracking-widest transition inline-flex items-center space-x-2 disabled:opacity-50 rounded-none cursor-pointer"
                  >
                    {isGeneratingReport ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin text-primary" />
                        <span>COMPILING AI DOSSIER (EST. 5-8 SECONDS)...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4 text-primary" />
                        <span>GENERATE COMPREHENSIVE INVESTMENT INTELLIGENCE REPORT</span>
                      </>
                    )}
                  </button>
                ) : (
                  <div className="space-y-6">
                    <div className="flex space-x-2 justify-end mb-4 border-b border-border-muted pb-3">
                      <button
                        onClick={handlePrintReport}
                        className="px-3 py-1.5 border-2 border-dark hover:bg-dark hover:text-white font-mono text-[10px] text-dark uppercase tracking-widest transition rounded-none cursor-pointer font-bold"
                      >
                        Print/Save PDF
                      </button>
                      <button
                        onClick={handleGenerateAIReport}
                        disabled={isGeneratingReport}
                        className="px-3 py-1.5 bg-dark text-white font-mono text-[10px] uppercase tracking-widest transition hover:bg-primary rounded-none cursor-pointer font-bold"
                      >
                        Refresh Analysis
                      </button>
                    </div>

                    {/* AI report output styled beautifully under Swiss typography principles */}
                    <div className="prose prose-stone max-w-none text-dark font-serif text-sm leading-relaxed space-y-4 print:p-6 bg-white p-6 border-2 border-dark shadow-none rounded-none">
                      <div className="border-b-2 border-dark pb-4 mb-6 text-center print:block">
                        <span className="font-mono text-[9px] uppercase tracking-widest text-stone-500 block font-bold">CONFIDENTIAL DOSSIER</span>
                        <h2 className="text-xl font-black font-serif uppercase text-dark tracking-tight mt-1">YORKSHIRE PROPERTY INTELLIGENCE BRIEFING</h2>
                        <span className="font-mono text-[10px] text-stone-600 mt-1 block font-bold">ASSET SPECIFICATION: {property.title} | DATE: {new Date().toLocaleDateString("en-GB")}</span>
                      </div>

                      {/* Custom formatted response display */}
                      <div className="whitespace-pre-wrap font-serif text-dark leading-relaxed text-sm space-y-4">
                        {aiReport}
                      </div>

                      <div className="border-t border-border-muted pt-4 mt-8 text-center text-[9px] font-mono text-stone-400 uppercase tracking-widest print:block font-bold">
                        PROPERTY OF RHINO BANK CO. • DISSEMINATION REGULATED UNDER SECURE PORTFOLIO STATUTES
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
