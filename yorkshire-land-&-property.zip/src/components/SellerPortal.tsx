import React, { useState } from "react";
import { Property, PropertyType } from "../types";
import { 
  PlusCircle, Edit3, Trash2, AreaChart, UploadCloud, 
  MapPin, Check, Briefcase, Landmark, Info, AlertTriangle, FileText
} from "lucide-react";

interface SellerPortalProps {
  properties: Property[];
  onAddProperty: (property: Property) => void;
  onRemoveProperty: (propId: string) => void;
  onAddToast: (msg: string, type: "success" | "info" | "error") => void;
}

export default function SellerPortal({
  properties,
  onAddProperty,
  onRemoveProperty,
  onAddToast
}: SellerPortalProps) {
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  
  // Form fields
  const [title, setTitle] = useState<string>("");
  const [type, setType] = useState<PropertyType>(PropertyType.DEVELOPMENT_LAND);
  const [town, setTown] = useState<string>("");
  const [county, setCounty] = useState<string>("North Yorkshire");
  const [postcode, setPostcode] = useState<string>("");
  const [region, setRegion] = useState<string>("Leeds City Region");
  const [price, setPrice] = useState<number>(1250000);
  const [tenure, setTenure] = useState<"Freehold" | "Leasehold">("Freehold");
  const [landArea, setLandArea] = useState<number>(5.5);
  const [floorArea, setFloorArea] = useState<number>(0);
  const [planningStatus, setPlanningStatus] = useState<any>("Outline Approval");
  const [industrialClassification, setIndustrialClassification] = useState<string>("");
  const [railAccess, setRailAccess] = useState<boolean>(false);
  const [motorwayAccess, setMotorwayAccess] = useState<boolean>(true);
  const [description, setDescription] = useState<string>("");
  const [highlights, setHighlights] = useState<string>("");

  // Simulated broker metrics
  const brokerStats = {
    totalValueListed: properties.reduce((acc, p) => acc + p.price, 0),
    activeListingsCount: properties.length,
    brochuresDownloaded: properties.length * 14 + 23,
    financeEnquiries: properties.length * 3 + 1
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title || !town || !postcode || !description) {
      onAddToast("Please compile all required core prospectus parameters before listing.", "error");
      return;
    }

    // Split highlights by newlines or commas
    const processedHighlights = highlights
      ? highlights.split("\n").filter((h) => h.trim().length > 0)
      : ["Premium commercial opportunity in Yorkshire.", "Excellent transit links.", "Full sovereign legal validation."];

    // Pick a mock architectural drone image based on type
    let droneImage = "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1200"; // logistics default
    if (type === PropertyType.AGRICULTURAL_LAND || type === PropertyType.FORESTRY) {
      droneImage = "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&q=80&w=1200";
    } else if (type === PropertyType.SCIENCE_PARK || type === PropertyType.BUSINESS_PARK) {
      droneImage = "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200";
    }

    // Assign randomized coordinates inside Yorkshire bounds (X: 30-80, Y: 25-75)
    const randomX = Math.floor(30 + Math.random() * 50);
    const randomY = Math.floor(25 + Math.random() * 50);
    const gridRef = `SE ${Math.floor(1000 + Math.random() * 8999)} ${Math.floor(1000 + Math.random() * 8999)}`;

    const newProperty: Property = {
      id: `prop-custom-${Date.now()}`,
      title,
      type,
      location: {
        town,
        county,
        postcode: postcode.toUpperCase(),
        region
      },
      coordinates: {
        x: randomX,
        y: randomY,
        gridRef
      },
      price,
      tenure,
      landAreaAcres: landArea > 0 ? landArea : undefined,
      floorAreaSqFt: floorArea > 0 ? floorArea : undefined,
      planningStatus,
      developmentPotential: `Unrivaled capacity in ${town}. Complete local government alignment.`,
      industrialClassification: industrialClassification || undefined,
      environmentalRating: "B",
      infrastructure: {
        railAccess,
        railAccessDistanceMiles: railAccess ? 1.5 : undefined,
        motorwayAccess,
        motorwayAccessDistanceMiles: motorwayAccess ? 3.0 : undefined,
        airportAccess: false,
        enterpriseZone: false,
        investmentZone: false
      },
      description,
      highlights: processedHighlights,
      droneSimulationImage: droneImage,
      nearbyInvestment: `Integrated with ${county} regional capital investments structure.`,
      localBusinessData: [
        { Sector: "Professional Support", Count: 18 },
        { Sector: "Operational Logistics", Count: 24 }
      ],
      economicProfile: {
        employmentRate: 75.8,
        averageSalary: 32500,
        populationTrend: "Stable upward projection"
      },
      brochureAvailable: true
    };

    onAddProperty(newProperty);
    onAddToast(`Dossier for '${title}' successfully indexed on Yorkshire Land & Property!`, "success");
    
    // Reset Form
    setTitle("");
    setTown("");
    setPostcode("");
    setDescription("");
    setHighlights("");
    setShowAddForm(false);
  };

  return (
    <div id="seller-portal" className="max-w-7xl mx-auto space-y-8 rounded-none">
      
      {/* Portal Header */}
      <div className="border-b-2 border-dark pb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 rounded-none">
        <div>
          <span className="text-[10px] font-mono text-primary tracking-widest uppercase block font-bold mb-1">
            MUNICIPAL BROKERAGE CONSOLE
          </span>
          <h2 className="text-2xl md:text-3xl font-black tracking-tight text-dark font-serif uppercase">
            Landowner & Broker Portal
          </h2>
          <p className="text-stone-500 font-serif text-xs md:text-sm mt-1 max-w-xl font-semibold leading-relaxed">
            Register development tracts, upload strategic planning permission records, and audit corporate underwriting inquiries compiled by Rhino Bank.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2.5 bg-dark text-white border-2 border-dark hover:bg-primary hover:text-white font-mono text-xs font-black uppercase tracking-wider transition flex items-center space-x-1.5 rounded-none cursor-pointer"
        >
          <PlusCircle className="h-4 w-4" />
          <span>{showAddForm ? "CLOSE COMPILER" : "INDEX NEW PROPERTY / SITE"}</span>
        </button>
      </div>

      {/* Broker KPIs strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 bg-dark p-4 text-stone-300 font-mono text-xs border-2 border-dark rounded-none shadow-none">
        <div>
          <span className="text-stone-500 block text-[9px] uppercase font-bold">TOTAL MANAGED VOLUME</span>
          <span className="text-base font-black text-primary">
            £{(brokerStats.totalValueListed / 1000000).toFixed(2)}M
          </span>
        </div>
        <div>
          <span className="text-stone-500 block text-[9px] uppercase font-bold">ACTIVE INDEXED TRACTS</span>
          <span className="text-base font-black text-white">{brokerStats.activeListingsCount} Sites</span>
        </div>
        <div>
          <span className="text-stone-500 block text-[9px] uppercase font-bold">BROCHURE DOWNLOADS</span>
          <span className="text-base font-black text-white">{brokerStats.brochuresDownloaded} Requests</span>
        </div>
        <div>
          <span className="text-stone-500 block text-[9px] uppercase font-bold">RHINO FINANCE INQUIRIES</span>
          <span className="text-base font-black text-emerald-400">{brokerStats.financeEnquiries} Leads</span>
        </div>
      </div>

      {/* RENDER ADD PROPERTY FORM */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-white border-2 border-dark p-6 md:p-8 space-y-6 font-mono text-xs text-dark rounded-none">
          <div className="flex items-center space-x-2 border-b border-border-muted pb-3 mb-4 rounded-none">
            <Briefcase className="h-5 w-5 text-primary" />
            <h3 className="font-serif text-lg font-black text-dark uppercase">Indexing Dossier Compiler</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 rounded-none">
            
            {/* Left Fields Column */}
            <div className="space-y-4 rounded-none">
              <div>
                <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                  PROSPECTUS TITLE *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Humber Freeport Advanced Assembly Yard"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-none">
                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    ASSET CLASSIFICATION
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as PropertyType)}
                    className="w-full p-2.5 border-2 border-dark text-dark bg-white text-xs outline-none rounded-none font-bold cursor-pointer"
                  >
                    {Object.values(PropertyType).map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    CAPITAL PRICE (£) *
                  </label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                  />
                  <span className="text-[9px] text-stone-400 uppercase mt-0.5 block font-semibold">Use 0 for Price on Application (POA)</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 rounded-none">
                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    TOWN / CITY *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Leeds"
                    value={town}
                    onChange={(e) => setTown(e.target.value)}
                    className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    COUNTY
                  </label>
                  <select
                    value={county}
                    onChange={(e) => setCounty(e.target.value)}
                    className="w-full p-2.5 border-2 border-dark text-dark bg-white text-xs outline-none rounded-none font-bold cursor-pointer"
                  >
                    <option value="North Yorkshire">North Yorkshire</option>
                    <option value="West Yorkshire">West Yorkshire</option>
                    <option value="South Yorkshire">South Yorkshire</option>
                    <option value="East Riding of Yorkshire">East Riding</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    POSTCODE *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="LS1 4DY"
                    value={postcode}
                    onChange={(e) => setPostcode(e.target.value)}
                    className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-none">
                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    SITE TENURE
                  </label>
                  <select
                    value={tenure}
                    onChange={(e) => setTenure(e.target.value as any)}
                    className="w-full p-2.5 border-2 border-dark text-dark bg-white text-xs outline-none rounded-none font-bold cursor-pointer"
                  >
                    <option value="Freehold">Freehold</option>
                    <option value="Leasehold">Leasehold</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    PLANNING CONSENT STATUS
                  </label>
                  <select
                    value={planningStatus}
                    onChange={(e) => setPlanningStatus(e.target.value as any)}
                    className="w-full p-2.5 border-2 border-dark text-dark bg-white text-xs outline-none rounded-none font-bold cursor-pointer"
                  >
                    <option value="Full Approval">Full Approval</option>
                    <option value="Outline Approval">Outline Approval</option>
                    <option value="Allocated">Allocated Zone</option>
                    <option value="Strategic Land">Strategic Land</option>
                    <option value="Agricultural Use">Agricultural Use</option>
                    <option value="No Current Consent">No Current Consent</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Right Fields Column */}
            <div className="space-y-4 rounded-none">
              <div className="grid grid-cols-2 gap-3 rounded-none">
                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    LAND FOOTPRINT (ACRES)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={landArea}
                    onChange={(e) => setLandArea(Number(e.target.value))}
                    className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                    INTERNAL FLOOR (SQ FT)
                  </label>
                  <input
                    type="number"
                    value={floorArea}
                    onChange={(e) => setFloorArea(Number(e.target.value))}
                    className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                  INFRASTRUCTURE ACCESSIBILITY
                </label>
                <div className="flex space-x-6 py-2 rounded-none">
                  <label className="flex items-center space-x-2 cursor-pointer text-xs font-bold text-dark">
                    <input
                      type="checkbox"
                      checked={railAccess}
                      onChange={(e) => setRailAccess(e.target.checked)}
                      className="rounded-none border-2 border-dark h-4 w-4 accent-primary"
                    />
                    <span>Direct Rail Siding Link</span>
                  </label>

                  <label className="flex items-center space-x-2 cursor-pointer text-xs font-bold text-dark">
                    <input
                      type="checkbox"
                      checked={motorwayAccess}
                      onChange={(e) => setMotorwayAccess(e.target.checked)}
                      className="rounded-none border-2 border-dark h-4 w-4 accent-primary"
                    />
                    <span>Primary Motorway Corridors (M1/M62/A1M)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                  PROSPECTUS HIGHLIGHTS (ONE PER LINE)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Directly accessible via dual carriageway.&#10;Outline consent secured for 4 distribution hubs."
                  value={highlights}
                  onChange={(e) => setHighlights(e.target.value)}
                  className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                />
              </div>

              <div>
                <label className="block text-[10px] text-stone-500 uppercase tracking-widest mb-1 font-black">
                  COMPREHENSIVE DOSSIER DESCRIPTION *
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Provide structured specifications, history, planning logs, covenant restrictions, and municipal growth context..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2.5 border-2 border-dark text-dark focus:border-primary outline-none bg-white text-xs rounded-none font-bold"
                />
              </div>
            </div>

          </div>

          <button
            type="submit"
            className="w-full py-3 bg-primary hover:bg-dark text-white font-black font-mono tracking-widest uppercase transition rounded-none border-2 border-dark cursor-pointer"
          >
            ✦ FINALIZE & COMPILE PROSPECTUS FOR MARKET DISTRIBUTION
          </button>
        </form>
      )}

      {/* Broker Current Active Listings list */}
      <div className="space-y-4 rounded-none">
        <h3 className="font-serif text-lg font-black text-dark uppercase border-b-2 border-dark pb-2 rounded-none">
          Municipal Inventory Under Your Administration
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 rounded-none">
          {properties.map((prop) => (
            <div key={prop.id} className="border-2 border-dark p-4 bg-white flex flex-col justify-between space-y-4 rounded-none">
              <div>
                <div className="flex justify-between items-start rounded-none">
                  <span className="font-mono text-[9px] bg-dark text-white px-2 py-0.5 uppercase font-black rounded-none">
                    {prop.type}
                  </span>
                  <span className="font-mono text-[9px] text-stone-400 font-bold">ID: {prop.id}</span>
                </div>
                
                <h4 className="font-serif font-extrabold text-sm text-dark mt-2 leading-snug">{prop.title}</h4>
                <p className="text-[10px] text-stone-400 font-mono mt-1 font-bold">{prop.location.town}, {prop.location.postcode}</p>
                <p className="font-mono text-xs text-dark font-black mt-2">
                  {prop.price > 0 ? `£${prop.price.toLocaleString()}` : "POA"}
                </p>
              </div>

              <div className="flex justify-between items-center border-t border-border-muted pt-3 rounded-none">
                <span className="font-mono text-[9px] text-emerald-700 font-extrabold">
                  ● ACTIVE MARKET INDEXING
                </span>
                
                <div className="flex space-x-2 rounded-none">
                  <button
                    onClick={() => {
                      onRemoveProperty(prop.id);
                      onAddToast(`Dossier for '${prop.title}' withdrawn from municipal marketplace index.`, "info");
                    }}
                    className="p-1.5 text-stone-400 hover:text-white hover:bg-red-600 transition border-2 border-dark rounded-none cursor-pointer"
                    title="Withdraw Listing Immediately"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
