import React, { useState } from "react";
import { Property, FinancingApplication, SecureDocument } from "../types";
import { 
  Landmark, ShieldCheck, FolderOpen, Heart, Search, 
  UploadCloud, Mail, ChevronRight, FileText, Check, Clock, AlertCircle 
} from "lucide-react";

interface DashboardProps {
  watchedProperties: Property[];
  onUnwatchProperty: (propId: string) => void;
  financingApplications: FinancingApplication[];
  savedSearches: { id: string; name: string; timestamp: string; count: number }[];
  onSelectProperty: (property: Property) => void;
  onAddToast: (msg: string, type: "success" | "info" | "error") => void;
}

export default function Dashboard({
  watchedProperties,
  onUnwatchProperty,
  financingApplications,
  savedSearches,
  onSelectProperty,
  onAddToast
}: DashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<"finance" | "portfolio" | "vault" | "comms">("finance");
  
  // Vault state
  const [vaultDocs, setVaultDocs] = useState<SecureDocument[]>([
    { id: "doc-1", name: "Corporate_Underwriting_Accounts_2025.pdf", category: "Financial", uploadedAt: "12/06/2026", size: "4.2 MB" },
    { id: "doc-2", name: "Calder_Logistics_Environmental_Audit_B.pdf", category: "Environmental", uploadedAt: "24/07/2026", size: "12.8 MB" },
    { id: "doc-3", name: "Airedale_Outline_Planning_Permission.pdf", category: "Planning", uploadedAt: "18/05/2026", size: "1.8 MB" }
  ]);

  const [dragActive, setDragActive] = useState<boolean>(false);

  // File Upload Handlers (Drag & Drop + Click Select)
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (fileName: string, fileSize: number) => {
    const sizeStr = `${(fileSize / (1024 * 1024)).toFixed(1)} MB`;
    const newDoc: SecureDocument = {
      id: `doc-${Date.now()}`,
      name: fileName,
      category: fileName.toLowerCase().includes("plan") ? "Planning" : 
                fileName.toLowerCase().includes("environ") ? "Environmental" : 
                fileName.toLowerCase().includes("legal") ? "Legal" : "Financial",
      uploadedAt: new Date().toLocaleDateString("en-GB"),
      size: sizeStr
    };
    
    setVaultDocs((prev) => [newDoc, ...prev]);
    onAddToast(`Document '${fileName}' securely encrypted and uploaded to the compliance vault!`, "success");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      processFile(file.name, file.size);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      processFile(file.name, file.size);
    }
  };

  return (
    <div id="investor-dashboard" className="max-w-7xl mx-auto space-y-8 rounded-none">
      
      {/* Upper Profile Banner */}
      <div className="bg-white border-2 border-dark p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 rounded-none">
        <div className="flex items-center space-x-4">
          <div className="h-14 w-14 bg-dark flex items-center justify-center text-white font-serif text-xl font-bold rounded-none border-2 border-dark">
            TB
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-mono text-[9px] bg-primary/20 text-primary font-extrabold px-2 py-0.5 uppercase tracking-wider rounded-none">
                RHINO PREMIUM EXECUTIVE
              </span>
              <span className="font-mono text-[9px] text-stone-500 font-bold">MEMBERSHIP NO: #RHN-482093</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black font-serif text-dark mt-1 uppercase">
              Thomas Bradley (Portfolio Investor)
            </h2>
            <p className="text-stone-500 font-serif text-xs font-semibold">tom@ahyx.org • Yorkshire Corporate Equity Partner</p>
          </div>
        </div>

        <div className="flex space-x-8 text-left font-mono text-xs border-t md:border-t-0 border-border-muted pt-4 md:pt-0 w-full md:w-auto font-bold">
          <div>
            <span className="block text-[9px] text-stone-400 uppercase font-bold">ACTIVE FINANCING</span>
            <span className="text-sm font-black text-dark">{financingApplications.length} Application(s)</span>
          </div>
          <div>
            <span className="block text-[9px] text-stone-400 uppercase font-bold">WATCHLIST VALUE</span>
            <span className="text-sm font-black text-primary">
              £{(watchedProperties.reduce((acc, p) => acc + p.price, 0) / 1000000).toFixed(1)}M Total
            </span>
          </div>
        </div>
      </div>

      {/* Grid: 3-column Left navigations, right content panels */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start rounded-none">
        
        {/* Navigation buttons menu */}
        <div className="lg:col-span-3 flex flex-col space-y-1.5 font-mono text-xs rounded-none">
          <button
            onClick={() => setActiveSubTab("finance")}
            className={`p-3 text-left border-2 transition flex items-center justify-between rounded-none cursor-pointer ${
              activeSubTab === "finance"
                ? "bg-dark text-white border-dark font-extrabold"
                : "bg-cream text-stone-600 border-border-muted hover:border-dark"
            }`}
          >
            <span className="flex items-center space-x-2">
              <Landmark className="h-4 w-4" />
              <span>Financing Dossiers</span>
            </span>
            <span className="bg-primary text-white text-[9px] h-4 px-1.5 flex items-center justify-center font-black rounded-none">
              {financingApplications.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab("portfolio")}
            className={`p-3 text-left border-2 transition flex items-center justify-between rounded-none cursor-pointer ${
              activeSubTab === "portfolio"
                ? "bg-dark text-white border-dark font-extrabold"
                : "bg-cream text-stone-600 border-border-muted hover:border-dark"
            }`}
          >
            <span className="flex items-center space-x-2">
              <Heart className="h-4 w-4 animate-pulse" />
              <span>Target Asset Watchlist</span>
            </span>
            <span className="bg-primary text-white text-[9px] h-4 px-1.5 flex items-center justify-center font-black rounded-none">
              {watchedProperties.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab("vault")}
            className={`p-3 text-left border-2 transition flex items-center justify-between rounded-none cursor-pointer ${
              activeSubTab === "vault"
                ? "bg-dark text-white border-dark font-extrabold"
                : "bg-cream text-stone-600 border-border-muted hover:border-dark"
            }`}
          >
            <span className="flex items-center space-x-2">
              <FolderOpen className="h-4 w-4" />
              <span>Secure Document Vault</span>
            </span>
            <span className="bg-primary text-white text-[9px] h-4 px-1.5 flex items-center justify-center font-black rounded-none">
              {vaultDocs.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab("comms")}
            className={`p-3 text-left border-2 transition flex items-center justify-between rounded-none cursor-pointer ${
              activeSubTab === "comms"
                ? "bg-dark text-white border-dark font-extrabold"
                : "bg-cream text-stone-600 border-border-muted hover:border-dark"
            }`}
          >
            <span className="flex items-center space-x-2">
              <Mail className="h-4 w-4" />
              <span>Underwriting Secure chat</span>
            </span>
            <span className="text-[10px] text-emerald-600 font-extrabold">ONLINE</span>
          </button>
        </div>

        {/* Content detail panels */}
        <div className="lg:col-span-9 bg-white border-2 border-dark p-6 md:p-8 rounded-none">
          
          {/* FINANCE TAB */}
          {activeSubTab === "finance" && (
            <div className="space-y-6 rounded-none">
              <div className="flex justify-between items-center border-b-2 border-dark pb-3 mb-4 rounded-none">
                <h3 className="font-serif text-lg font-black text-dark uppercase">Rhino Bank active Loan Dossiers</h3>
                <span className="font-mono text-[9px] text-stone-400 uppercase font-bold">Real-Time Underwriting status</span>
              </div>

              {financingApplications.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-dark bg-cream/20 rounded-none">
                  <Landmark className="h-10 w-10 mx-auto text-stone-400 mb-2" />
                  <p className="font-serif text-sm text-dark font-extrabold uppercase">No Active Financing Dossiers Found</p>
                  <p className="font-serif text-xs text-stone-500 mt-1 max-w-sm mx-auto leading-relaxed">
                    Select an institutional asset from the search listing and submit a mortgage/bridge credit request to activate underwriting portals.
                  </p>
                </div>
              ) : (
                <div className="space-y-6 rounded-none">
                  {financingApplications.map((app) => (
                    <div key={app.id} className="border-2 border-dark p-5 space-y-4 text-dark bg-white rounded-none">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border-muted pb-3 rounded-none">
                        <div>
                          <span className="font-mono text-[9px] bg-dark text-white px-2 py-0.5 uppercase mr-2 font-black rounded-none">
                            {app.type} FINANCE
                          </span>
                          <span className="font-mono text-xs text-stone-500 font-bold">REF: {app.referenceNo}</span>
                        </div>
                        <span className={`px-2 py-0.5 font-mono text-[10px] font-extrabold flex items-center space-x-1 rounded-none ${
                          app.status === "Approved" ? "bg-emerald-100 text-emerald-900 border border-emerald-400" : "bg-amber-100 text-amber-900 border border-amber-400"
                        }`}>
                          {app.status === "Approved" ? <Check className="h-3 w-3 mr-1" /> : <Clock className="h-3 w-3 mr-1 animate-pulse" />}
                          <span>{app.status.toUpperCase()}</span>
                        </span>
                      </div>

                      <div className="flex justify-between items-start flex-wrap gap-4 rounded-none">
                        <div>
                          <h4 className="font-serif font-extrabold text-sm text-dark">{app.propertyTitle}</h4>
                          <span className="text-[10px] text-stone-400 font-mono font-bold">SUBMITTED ON: {app.dateApplied}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-stone-400 font-mono block font-bold">UNDERWRITTEN CAPITAL</span>
                          <span className="text-base font-black text-primary font-mono">£{app.amount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                        </div>
                      </div>

                      {/* Document Compliance checklist */}
                      <div className="bg-cream/40 p-4 border border-border-muted space-y-2.5 rounded-none">
                        <span className="text-[9px] text-stone-400 font-mono uppercase tracking-widest block font-extrabold">
                          FINANCING DOSSIER COMPLIANCE REGISTRY
                        </span>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[11px] rounded-none">
                          {app.documents.map((doc, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 bg-white border border-border-muted rounded-none">
                              <span className="truncate pr-2 text-dark font-semibold">{doc.name}</span>
                              <span className={`px-1.5 py-0.5 text-[9px] font-black rounded-none shrink-0 ${
                                doc.status === "Verified" ? "bg-emerald-100 text-emerald-900 border border-emerald-300" : "bg-amber-100 text-amber-900 border border-amber-300 animate-pulse"
                              }`}>
                                {doc.status.toUpperCase()}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* WATCHED PORTFOLIO */}
          {activeSubTab === "portfolio" && (
            <div className="space-y-6 rounded-none">
              <div className="flex justify-between items-center border-b-2 border-dark pb-3 mb-4 rounded-none">
                <h3 className="font-serif text-lg font-black text-dark uppercase">Target Asset Watchlist</h3>
                <span className="font-mono text-[9px] text-stone-400 uppercase font-bold">Tracked opportunities</span>
              </div>

              {watchedProperties.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-dark bg-cream/20 rounded-none">
                  <Heart className="h-10 w-10 mx-auto text-stone-400 mb-2" />
                  <p className="font-serif text-sm text-dark font-extrabold uppercase">No Bookmarked Properties</p>
                  <p className="font-serif text-xs text-stone-500 mt-1 max-w-sm mx-auto leading-relaxed">
                    Browse the Yorkshire listings and click the bookmark button to construct your private regional acquisition watchlist.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 rounded-none">
                  {watchedProperties.map((prop) => (
                    <div key={prop.id} className="border-2 border-dark p-4 hover:border-primary transition flex flex-col justify-between space-y-4 rounded-none bg-white">
                      <div>
                        <div className="flex justify-between items-start mb-2 rounded-none">
                          <span className="font-mono text-[9px] uppercase bg-dark text-white px-1.5 py-0.5 font-bold rounded-none">
                            {prop.type}
                          </span>
                          <button
                            onClick={() => {
                              onUnwatchProperty(prop.id);
                              onAddToast(`Removed '${prop.title}' from watchlist.`, "info");
                            }}
                            className="text-[10px] font-mono text-stone-400 hover:text-dark uppercase font-extrabold cursor-pointer"
                          >
                            Unwatch
                          </button>
                        </div>
                        <h4 className="font-serif font-extrabold text-sm text-dark leading-tight">{prop.title}</h4>
                        <p className="text-[10px] text-stone-400 font-mono mt-1 font-semibold">{prop.location.town}, {prop.location.postcode}</p>
                      </div>

                      <div className="flex justify-between items-end border-t border-border-muted pt-3 rounded-none">
                        <div>
                          <span className="block text-[8px] text-stone-400 font-mono uppercase font-bold">ASSET VALUE</span>
                          <span className="text-xs font-black text-primary font-mono">
                            {prop.price > 0 ? `£${prop.price.toLocaleString()}` : "POA"}
                          </span>
                        </div>
                        <button
                          onClick={() => onSelectProperty(prop)}
                          className="px-2.5 py-1 bg-dark hover:bg-primary text-white font-mono text-[9px] uppercase tracking-wider transition rounded-none cursor-pointer font-bold"
                        >
                          OPEN PROSPECTUS
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* SECURE VAULT */}
          {activeSubTab === "vault" && (
            <div className="space-y-6 rounded-none">
              <div className="flex justify-between items-center border-b-2 border-dark pb-3 mb-4 rounded-none">
                <h3 className="font-serif text-lg font-black text-dark uppercase">Compliance document Vault</h3>
                <span className="font-mono text-[9px] text-stone-400 uppercase font-bold">military AES-256 Encryption active</span>
              </div>

              {/* Drag and Drop Zone */}
              <div 
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-none p-8 text-center transition ${
                  dragActive 
                    ? "border-emerald-500 bg-emerald-50/20" 
                    : "border-dark hover:border-primary bg-cream/10"
                }`}
              >
                <UploadCloud className="h-10 w-10 mx-auto text-primary mb-2" />
                <p className="font-mono text-xs font-black text-dark uppercase tracking-wide">
                  Drag and Drop compliance documents here
                </p>
                <p className="font-serif text-xs text-stone-500 mt-1 leading-relaxed">
                  Supports PDF, DXF Site plans, XML, DOCX or Planning certifications. (Max 50MB)
                </p>
                
                {/* Manual selector */}
                <label className="mt-4 px-4 py-2 bg-dark hover:bg-primary text-white font-mono text-[10px] uppercase tracking-widest cursor-pointer inline-block transition rounded-none font-bold">
                  Browse dossiers
                  <input 
                    type="file" 
                    className="hidden" 
                    onChange={handleFileInput}
                    accept=".pdf,.docx,.doc,.xls,.xlsx,.png,.jpg,.jpeg,.zip"
                  />
                </label>
              </div>

              {/* File Register List */}
              <div className="space-y-2 font-mono text-xs text-dark rounded-none">
                <span className="text-[9px] text-stone-400 uppercase tracking-widest block font-black">
                  ACTIVE DOSSIER ENCRYPTION REGISTER
                </span>

                {vaultDocs.map((doc) => (
                  <div key={doc.id} className="border-2 border-dark p-3 bg-white flex items-center justify-between hover:border-primary transition rounded-none">
                    <div className="flex items-center space-x-3 truncate">
                      <FileText className="h-5 w-5 text-primary shrink-0" />
                      <div className="truncate">
                        <p className="font-bold text-dark truncate pr-2">{doc.name}</p>
                        <p className="text-[9px] text-stone-400 font-bold">CATEGORY: {doc.category.toUpperCase()} | UPLOADED: {doc.uploadedAt}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 shrink-0">
                      <span className="text-[10px] text-stone-500 font-bold">{doc.size}</span>
                      <span className="text-[9px] bg-emerald-100 text-emerald-900 px-2 py-0.5 border border-emerald-400 font-black uppercase rounded-none">
                        SECURED
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SECURE COMMS */}
          {activeSubTab === "comms" && (
            <div className="space-y-6 rounded-none">
              <div className="flex justify-between items-center border-b-2 border-dark pb-3 mb-4 rounded-none">
                <h3 className="font-serif text-lg font-black text-dark uppercase">Rhino Private Banker Hotline</h3>
                <span className="font-mono text-[9px] text-primary font-black uppercase tracking-wider">SECURED RSA CHANNEL</span>
              </div>

              <div className="border-2 border-dark bg-cream p-4 space-y-4 font-serif text-sm rounded-none">
                <div className="flex items-start space-x-3 rounded-none">
                  <div className="h-8 w-8 bg-dark text-white font-mono text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5 rounded-none">
                    RB
                  </div>
                  <div>
                    <span className="font-mono text-[10px] font-black text-dark uppercase tracking-wider">Rhino Underwriting Bot (Automatic AI Dispatcher)</span>
                    <p className="text-stone-800 mt-1 leading-relaxed">
                      Welcome, Thomas. Your corporate credentials are fully verified. All financing calculations, bridging credit thresholds, and document archives submitted on the **Yorkshire Land & Property** portal are encrypted and actively logged directly on Rhino Bank’s underwriting matrix.
                    </p>
                    <p className="text-stone-800 mt-2 leading-relaxed">
                      If you require bridging terms over 75% LTV, click the **Secure Document Vault** tab above, drag-and-drop your latest institutional asset accounts dossier, and message our specialist corporate loan team below.
                    </p>
                  </div>
                </div>
              </div>

              {/* Chat Input placeholder */}
              <div className="flex gap-2 rounded-none">
                <input
                  type="text"
                  placeholder="Enter secure message to corporate loan underwriting department..."
                  className="flex-1 p-2.5 border-2 border-dark font-mono text-xs focus:border-primary outline-none text-dark bg-white rounded-none"
                />
                <button
                  onClick={() => onAddToast("Direct secure link active. Underwriters will respond via secure secure ledger within 4 hours.", "info")}
                  className="px-4 py-2 bg-dark hover:bg-primary text-white font-mono text-xs uppercase tracking-widest transition rounded-none font-bold cursor-pointer"
                >
                  SEND MSG
                </button>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
