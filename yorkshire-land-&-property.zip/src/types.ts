export enum PropertyType {
  COMMERCIAL_OFFICE = "Commercial Office",
  INDUSTRIAL_UNIT = "Industrial Unit",
  WAREHOUSE = "Warehouse",
  FACTORY = "Factory",
  RETAIL = "Retail Premises",
  HOSPITALITY = "Hospitality Site",
  AGRICULTURAL_LAND = "Agricultural Land",
  DEVELOPMENT_LAND = "Development Land",
  RESIDENTIAL_INVESTMENT = "Residential Investment Portfolio",
  STUDENT_ACCOMMODATION = "Student Accommodation",
  BUSINESS_PARK = "Business Park",
  SCIENCE_PARK = "Science Park",
  LOGISTICS_PARK = "Logistics Park",
  MIXED_USE = "Mixed-Use Development",
  RENEWABLE_ENERGY = "Renewable Energy Site",
  FORESTRY = "Forestry Land",
  QUARRY_MINERALS = "Quarry & Mineral Site"
}

export interface Coordinates {
  x: number; // 0 to 100 on our custom GIS grid representing Yorkshire
  y: number; // 0 to 100 on our custom GIS grid representing Yorkshire
  gridRef: string; // e.g. SE 1234 5678
}

export interface InvestmentMetrics {
  currentYield: number; // e.g. 7.5 for 7.5%
  targetYield: number;
  rentalIncomeAnnual: number;
  rentalHistory: { year: number; amount: number }[];
  comparableSales: { property: string; salePrice: number; date: string }[];
}

export interface Property {
  id: string;
  title: string;
  type: PropertyType;
  location: {
    town: string;
    county: string;
    postcode: string;
    region: string;
  };
  coordinates: Coordinates;
  price: number; // 0 for POA (Price on Application)
  tenure: "Freehold" | "Leasehold" | "Mixed";
  floorAreaSqFt?: number;
  landAreaAcres?: number;
  planningStatus: "Allocated" | "Outline Approval" | "Full Approval" | "Strategic Land" | "Agricultural Use" | "No Current Consent";
  developmentPotential: string;
  industrialClassification?: string; // e.g. B2 General Industrial, B8 Storage/Distribution
  environmentalRating: "A" | "B" | "C" | "D" | "E" | "F" | "G";
  infrastructure: {
    railAccess: boolean;
    railAccessDistanceMiles?: number;
    motorwayAccess: boolean;
    motorwayAccessDistanceMiles?: number;
    airportAccess: boolean;
    airportAccessDistanceMiles?: number;
    enterpriseZone: boolean;
    investmentZone: boolean;
  };
  description: string;
  highlights: string[];
  droneSimulationImage: string; // Simulated satellite/aerial visual style
  nearbyInvestment: string;
  localBusinessData: { Sector: string; Count: number }[];
  economicProfile: { employmentRate: number; averageSalary: number; populationTrend: string };
  brochureAvailable: boolean;
}

export interface SavedSearch {
  id: string;
  name: string;
  filters: any;
  timestamp: string;
}

export interface FinancingApplication {
  id: string;
  propertyId: string;
  propertyTitle: string;
  type: "Mortgage" | "Development" | "Bridging" | "Portfolio" | "Corporate";
  amount: number;
  status: "Under Review" | "Approved" | "Information Required" | "Term Sheet Issued";
  dateApplied: string;
  referenceNo: string;
  documents: { name: string; date: string; status: string }[];
}

export interface SecureDocument {
  id: string;
  name: string;
  category: "Planning" | "Environmental" | "Valuation" | "Legal" | "Financial";
  uploadedAt: string;
  size: string;
}

export interface MarketIndex {
  name: string;
  currentValue: number;
  change12mPercent: number;
  history: { date: string; value: number }[];
}
