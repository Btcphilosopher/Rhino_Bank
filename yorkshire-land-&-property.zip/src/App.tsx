import React, { useState, useMemo } from "react";
import { INITIAL_PROPERTIES, YORKSHIRE_MARKET_INDICES } from "./data";
import { Property, PropertyType, SavedSearch, FinancingApplication } from "./types";
import MapGIS from "./components/MapGIS";
import PropertyDetail from "./components/PropertyDetail";
import AnalyticsPanel from "./components/AnalyticsPanel";
import Dashboard from "./components/Dashboard";
import SellerPortal from "./components/SellerPortal";
import { 
  Compass, Landmark, Layers, Search, Eye, Sparkles, Heart, 
  MapPin, SlidersHorizontal, Train, Check, FileText, Globe, RefreshCw, X, ChevronRight
} from "lucide-react";

interface Toast {
  id: string;
  message: string;
  type: "success" | "info" | "error";
}

export default function App() {
  // Main State
  const [properties, setProperties] = useState<Property[]>(INITIAL_PROPERTIES);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [watchedPropertyIds, setWatchedPropertyIds] = useState<string[]>([]);
  const [financingApplications, setFinancingApplications] = useState<FinancingApplication[]>([]);
  
  // Tab Views: "marketplace" | "intelligence" | "dashboard" | "seller"
  const [currentView, setCurrentView] = useState<"marketplace" | "intelligence" | "dashboard" | "seller">("marketplace");
  
  // Search Filters State
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedType, setSelectedType] = useState<string>("ALL");
  const [maxPrice, setMaxPrice] = useState<number>(40000000); // 40M max
  const [minYield, setMinYield] = useState<number>(0);
  const [minLandArea, setMinLandArea] = useState<number>(0);
  const [requireRail, setRequireRail] = useState<boolean>(false);
  const [requireMotorway, setRequireMotorway] = useState<boolean>(false);
  const [requireEnterpriseZone, setRequireEnterpriseZone] = useState<boolean>(false);
  const [selectedPlanning, setSelectedPlanning] = useState<string>("ALL");
  const [selectedEnvironmental, setSelectedEnvironmental] = useState<string>("ALL");

  // GIS Drawn filter boundaries
  const [drawnFilteredPropertyIds, setDrawnFilteredPropertyIds] = useState<string[] | null>(null);

  // Saved Searches state
  const [savedSearches, setSavedSearches] = useState<{ id: string; name: string; timestamp: string; count: number }[]>([]);

  // Toast System
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (message: string, type: "success" | "info" | "error" = "info") => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Saved Searches handler
  const handleSaveSearch = () => {
    if (searchTerm || selectedType !== "ALL" || requireRail || requireMotorway) {
      const name = `${selectedType !== "ALL" ? selectedType : "Tracts"} in ${searchTerm || "Yorkshire"}`;
      const searchItem = {
        id: `search-${Date.now()}`,
        name,
        timestamp: new Date().toLocaleDateString("en-GB"),
        count: filteredProperties.length
      };
      setSavedSearches((prev) => [searchItem, ...prev]);
      addToast(`Filter query '${name}' saved to portfolio profile successfully.`, "success");
    } else {
      addToast("Please define filter parameters before saving queries.", "error");
    }
  };

  // Watchlist managers
  const handleToggleWatch = (propId: string) => {
    if (watchedPropertyIds.includes(propId)) {
      setWatchedPropertyIds((prev) => prev.filter((id) => id !== propId));
      addToast("Property removed from watchlist portfolio.", "info");
    } else {
      setWatchedPropertyIds((prev) => [...prev, propId]);
      addToast("Property added to watchlist portfolio.", "success");
    }
  };

  const handleUnwatchProperty = (propId: string) => {
    setWatchedPropertyIds((prev) => prev.filter((id) => id !== propId));
  };

  // Broker inventory updates
  const handleAddProperty = (newProperty: Property) => {
    setProperties((prev) => [newProperty, ...prev]);
  };

  const handleRemoveProperty = (propId: string) => {
    setProperties((prev) => prev.filter((p) => p.id !== propId));
    if (selectedProperty?.id === propId) {
      setSelectedProperty(null);
    }
  };

  // Finance underwriter integration
  const handleApplyFinance = (app: FinancingApplication) => {
    setFinancingApplications((prev) => [app, ...prev]);
  };

  // Multi-tier search filtering pipeline
  const filteredProperties = useMemo(() => {
    return properties.filter((prop) => {
      // Draw Boundary filter takes highest priority
      if (drawnFilteredPropertyIds !== null && !drawnFilteredPropertyIds.includes(prop.id)) {
        return false;
      }

      // Search matching (Town, county, postcode, gridRef, title)
      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const matchesLocation = 
          prop.location.town.toLowerCase().includes(query) ||
          prop.location.county.toLowerCase().includes(query) ||
          prop.location.postcode.toLowerCase().includes(query) ||
          prop.coordinates.gridRef.toLowerCase().includes(query) ||
          prop.title.toLowerCase().includes(query);
        if (!matchesLocation) return false;
      }

      // Property classification
      if (selectedType !== "ALL" && prop.type !== selectedType) {
        return false;
      }

      // Price ceilings
      if (maxPrice < 40000000 && prop.price > maxPrice) {
        return false;
      }

      // Land Footprint floor
      if (minLandArea > 0 && (!prop.landAreaAcres || prop.landAreaAcres < minLandArea)) {
        return false;
      }

      // Rail Link checklist
      if (requireRail && !prop.infrastructure.railAccess) {
        return false;
      }

      // Motorway network proximity
      if (requireMotorway && !prop.infrastructure.motorwayAccess) {
        return false;
      }

      // Enterprise tax zone checklist
      if (requireEnterpriseZone && !prop.infrastructure.enterpriseZone) {
        return false;
      }

      // Planning permissions status
      if (selectedPlanning !== "ALL" && prop.planningStatus !== selectedPlanning) {
        return false;
      }

      // Environmental Carbon compliance standing
      if (selectedEnvironmental !== "ALL" && prop.environmentalRating !== selectedEnvironmental) {
        return false;
      }

      return true;
    });
  }, [properties, searchTerm, selectedType, maxPrice, minLandArea, requireRail, requireMotorway, requireEnterpriseZone, selectedPlanning, selectedEnvironmental, drawnFilteredPropertyIds]);

  // Derived list of watched properties objects
  const watchedPropertiesList = useMemo(() => {
    return properties.filter((p) => watchedPropertyIds.includes(p.id));
  }, [properties, watchedPropertyIds]);

  // Quick hero jumps
  const handleHeroNavigate = (typeFilter?: string, planningFilter?: string) => {
    if (typeFilter) setSelectedType(typeFilter);
    if (planningFilter) setSelectedPlanning(planningFilter);
    setCurrentView("marketplace");
    setSelectedProperty(null);
    addToast("Searching criteria applied. Results updated.", "info");
  };

  return (
    <div className="min-h-screen bg-cream text-dark font-sans selection:bg-primary/30 flex flex-col justify-between">
      
      {/* Editorial Corporate Header */}
      <header className="border-b border-border-muted bg-white sticky top-0 z-50 px-4 md:px-10 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          {/* Logo Brand Frame */}
          <div className="flex items-center space-x-3.5 cursor-pointer" onClick={() => { setSelectedProperty(null); setCurrentView("marketplace"); }}>
            <div className="h-10 w-10 bg-dark flex items-center justify-center border border-primary shrink-0 rounded-none shadow-none">
              <Compass className="h-5 w-5 text-primary animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold tracking-widest font-mono text-dark uppercase leading-none">
                YORKSHIRE LAND & PROPERTY
              </h1>
              <div className="flex items-center text-[10px] text-stone-500 mt-1 uppercase tracking-wide font-medium space-x-1">
                <span>A</span>
                <span className="font-extrabold text-primary font-mono">Rhino Bank</span>
                <span>Subsidiary</span>
              </div>
            </div>
          </div>

          {/* Navigation tabs */}
          <nav className="flex items-center border-t md:border-t-0 border-border-muted pt-3 md:pt-0 gap-1 md:gap-2">
            {(["marketplace", "intelligence", "dashboard", "seller"] as const).map((view) => (
              <button
                key={view}
                onClick={() => {
                  setCurrentView(view);
                  setSelectedProperty(null);
                }}
                className={`px-3 py-1.5 font-mono text-[10px] md:text-xs tracking-wider uppercase transition rounded-none ${
                  currentView === view && !selectedProperty
                    ? "bg-dark text-white font-bold border-b-2 border-primary"
                    : "text-stone-500 hover:text-dark hover:bg-stone-50"
                }`}
              >
                {view === "marketplace" ? "Search Marketplace" : 
                 view === "intelligence" ? "Market Intelligence" : 
                 view === "dashboard" ? "Client Portfolio" : "Seller Portal"}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Main Container Stage */}
      <main className="flex-grow py-6 px-4 md:px-10 max-w-7xl mx-auto w-full">
        
        {/* VIEW LANDING COMPASS */}
        {currentView === "marketplace" && !selectedProperty && (
          <div className="space-y-8">
            
            {/* High-Contrast Hero Cover */}
            <div className="relative border-4 border-dark bg-white p-8 md:p-14 shadow-none rounded-none overflow-hidden">
              <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:16px_16px]" />
              
              <div className="relative max-w-4xl space-y-6">
                <span className="font-mono text-[9px] text-primary tracking-widest font-extrabold bg-primary/10 border border-primary/30 px-3 py-1.5 uppercase rounded-none inline-block">
                  INVEST IN YORKSHIRE. BUILD THE FUTURE.
                </span>
                <h2 className="text-4xl md:text-7xl font-black font-serif tracking-tight text-dark uppercase leading-none">
                  YORKSHIRE'S LAND.<br/>
                  <span className="text-primary font-serif">FUTURE ASSETS.</span>
                </h2>
                <p className="text-stone-600 font-serif text-sm md:text-base leading-relaxed max-w-xl">
                  Commercial properties, agricultural land reserves, technical bioscience hubs, shipping terminals, and high-yielding development tracts underwritten by Rhino Bank institutional capital.
                </p>

                {/* Hero Stats Board */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-b border-border-muted py-6 font-mono">
                  <div>
                    <span className="block text-[8px] text-stone-400 uppercase tracking-widest">Sovereign Indices Yield</span>
                    <span className="text-2xl font-black text-dark tracking-tight">6.84% <span className="text-emerald-500 text-xs font-sans font-semibold">▲ 0.12%</span></span>
                  </div>
                  <div>
                    <span className="block text-[8px] text-stone-400 uppercase tracking-widest">Sovereign Land Custody</span>
                    <span className="text-2xl font-black text-dark tracking-tight">14,200 <span className="text-primary text-xs font-serif italic font-normal">Acres</span></span>
                  </div>
                  <div>
                    <span className="block text-[8px] text-stone-400 uppercase tracking-widest">Rhino Liquidity Vault</span>
                    <span className="text-2xl font-black text-dark tracking-tight">£1.2B+ <span className="text-stone-400 text-xs font-normal">Committed</span></span>
                  </div>
                </div>

                {/* Quick Hero Navigation Buttons */}
                <div className="flex flex-wrap gap-2 pt-2 font-mono text-[10px]">
                  <button
                    onClick={() => handleHeroNavigate("ALL")}
                    className="px-4 py-2.5 bg-dark text-white hover:bg-primary transition tracking-widest uppercase font-bold rounded-none cursor-pointer"
                  >
                    SEARCH ALL PROPERTY
                  </button>
                  <button
                    onClick={() => handleHeroNavigate(PropertyType.DEVELOPMENT_LAND)}
                    className="px-4 py-2.5 bg-white border border-dark text-dark hover:bg-stone-100 transition tracking-wider uppercase font-bold rounded-none cursor-pointer"
                  >
                    DEVELOPMENT SITES
                  </button>
                  <button
                    onClick={() => handleHeroNavigate(PropertyType.AGRICULTURAL_LAND)}
                    className="px-4 py-2.5 bg-white border border-dark text-dark hover:bg-stone-100 transition tracking-wider uppercase font-bold rounded-none cursor-pointer"
                  >
                    AGRICULTURAL TRACTS
                  </button>
                  <button
                    onClick={() => handleHeroNavigate(undefined, "Outline Approval")}
                    className="px-4 py-2.5 bg-white border border-dark text-dark hover:bg-stone-100 transition tracking-wider uppercase font-bold rounded-none cursor-pointer"
                  >
                    PLANNING DEALS
                  </button>
                </div>
              </div>
            </div>

            {/* Twin Panel Matrix: Search / Listing Grid on Left, Custom GIS Map on Right */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch min-h-[600px]">
              
              {/* Filter and Property Card Queue Column */}
              <div className="lg:col-span-6 space-y-6 flex flex-col">
                
                {/* Advanced Search Filter Panel */}
                <div className="bg-white border-2 border-dark p-5 space-y-4 rounded-none">
                  <div className="flex items-center justify-between border-b border-border-muted pb-2.5">
                    <div className="flex items-center space-x-1.5 text-dark">
                      <SlidersHorizontal className="h-4 w-4 text-primary" />
                      <h3 className="font-mono text-xs font-bold uppercase tracking-wider">Enterprise Search Filters</h3>
                    </div>
                    <button
                      onClick={handleSaveSearch}
                      className="text-[10px] font-mono text-primary hover:underline uppercase flex items-center font-bold cursor-pointer"
                    >
                      ✦ SAVE FILTER QUERY
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-[11px] text-dark">
                    {/* Search query box */}
                    <div>
                      <label className="block text-[9px] text-stone-400 uppercase tracking-widest mb-1">
                        LOC / TOWN / GRID REF / ZIP
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          placeholder="e.g. Leeds, Doncaster, BD23, SE 59"
                          className="w-full p-2 border border-border-muted text-xs focus:border-primary outline-none text-dark bg-cream/40 rounded-none"
                        />
                        <Search className="absolute right-2.5 top-2.5 h-3.5 w-3.5 text-stone-400" />
                      </div>
                    </div>

                    {/* Property type drop down */}
                    <div>
                      <label className="block text-[9px] text-stone-400 uppercase tracking-widest mb-1">
                        CLASSIFICATION INDEX
                      </label>
                      <select
                        value={selectedType}
                        onChange={(e) => setSelectedType(e.target.value)}
                        className="w-full p-2 border border-border-muted text-xs text-dark bg-cream/40 focus:border-primary outline-none rounded-none cursor-pointer"
                      >
                        <option value="ALL">ALL CLASSIFICATIONS</option>
                        {Object.values(PropertyType).map((t) => (
                          <option key={t} value={t}>{t.toUpperCase()}</option>
                        ))}
                      </select>
                    </div>

                    {/* Planning status selector */}
                    <div>
                      <label className="block text-[9px] text-stone-400 uppercase tracking-widest mb-1">
                        PLANNING DESIGNATION
                      </label>
                      <select
                        value={selectedPlanning}
                        onChange={(e) => setSelectedPlanning(e.target.value)}
                        className="w-full p-2 border border-border-muted text-xs text-dark bg-cream/40 focus:border-primary outline-none rounded-none cursor-pointer"
                      >
                        <option value="ALL">ALL CONSENTS</option>
                        <option value="Full Approval">FULL APPROVAL</option>
                        <option value="Outline Approval">OUTLINE APPROVAL</option>
                        <option value="Allocated">ALLOCATED SITES</option>
                        <option value="Strategic Land">STRATEGIC TRACTS</option>
                        <option value="Agricultural Use">AGRICULTURAL ONLY</option>
                      </select>
                    </div>

                    {/* Environmental standings */}
                    <div>
                      <label className="block text-[9px] text-stone-400 uppercase tracking-widest mb-1">
                        EPC BREEAM CARBON RATING
                      </label>
                      <select
                        value={selectedEnvironmental}
                        onChange={(e) => setSelectedEnvironmental(e.target.value)}
                        className="w-full p-2 border border-border-muted text-xs text-dark bg-cream/40 focus:border-primary outline-none rounded-none cursor-pointer"
                      >
                        <option value="ALL">ALL EPC RATINGS</option>
                        <option value="A">RATING A (ECO ULTRA)</option>
                        <option value="B">RATING B (PREMIUM EFFICIENCY)</option>
                        <option value="C">RATING C (STANDARD)</option>
                        <option value="D">RATING D (UPLAND INDUSTRIAL)</option>
                      </select>
                    </div>
                  </div>

                  {/* Range indicators */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-[10px] text-stone-500 pt-1.5">
                    <div>
                      <div className="flex justify-between uppercase mb-1">
                        <span>PRICE CEILING:</span>
                        <strong className="text-dark font-extrabold">
                          {maxPrice === 40000000 ? "NO CAP" : `£${(maxPrice / 1000000).toFixed(1)}M`}
                        </strong>
                      </div>
                      <input 
                        type="range" 
                        min="1000000" 
                        max="40000000" 
                        step="1000000"
                        value={maxPrice} 
                        onChange={(e) => setMaxPrice(Number(e.target.value))}
                        className="w-full accent-primary cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between uppercase mb-1">
                        <span>MINIMUM SITE FOOTPRINT:</span>
                        <strong className="text-dark font-extrabold">
                          {minLandArea === 0 ? "ANY SIZE" : `${minLandArea} ACRES`}
                        </strong>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="1500" 
                        step="50"
                        value={minLandArea} 
                        onChange={(e) => setMinLandArea(Number(e.target.value))}
                        className="w-full accent-primary cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Checkbox matrices */}
                  <div className="flex flex-wrap gap-4 font-mono text-[10px] text-[#2b2826] border-t border-border-muted pt-3">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={requireRail}
                        onChange={(e) => setRequireRail(e.target.checked)}
                        className="rounded-none h-3.5 w-3.5 accent-primary border border-border-muted"
                      />
                      <span className="uppercase font-semibold text-[9px]">Direct Rail-Freight Siding</span>
                    </label>

                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={requireMotorway}
                        onChange={(e) => setRequireMotorway(e.target.checked)}
                        className="rounded-none h-3.5 w-3.5 accent-primary border border-border-muted"
                      />
                      <span className="uppercase font-semibold text-[9px]">Motorway Arterial corridor</span>
                    </label>

                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={requireEnterpriseZone}
                        onChange={(e) => setRequireEnterpriseZone(e.target.checked)}
                        className="rounded-none h-3.5 w-3.5 accent-primary border border-border-muted"
                      />
                      <span className="uppercase font-semibold text-[9px]">Enterprise zone status</span>
                    </label>
                  </div>
                </div>

                {/* Results Count & active boundaries alert */}
                <div className="flex justify-between items-center bg-white border border-border-muted px-4 py-2.5 text-xs font-mono rounded-none">
                  <span className="text-stone-500 uppercase font-bold text-[10px]">
                    {filteredProperties.length} TRANSACTION DOSSIERS COMMITTED
                  </span>
                  
                  {drawnFilteredPropertyIds !== null && (
                    <button
                      onClick={() => setDrawnFilteredPropertyIds(null)}
                      className="text-primary font-bold uppercase tracking-wider text-[9px] flex items-center hover:underline cursor-pointer"
                    >
                      <X className="h-3.5 w-3.5 mr-1" /> Clear Spatial Boundary Filter
                    </button>
                  )}
                </div>

                {/* Property results cards list */}
                <div className="space-y-4 flex-1 overflow-y-auto pr-1 max-h-[600px]">
                  {filteredProperties.length === 0 ? (
                    <div className="bg-white border-2 border-dark p-10 text-center rounded-none">
                      <SlidersHorizontal className="h-10 w-10 mx-auto text-stone-300 mb-2" />
                      <p className="font-serif text-sm text-dark font-bold uppercase">No Matching Land Portfolios Identified</p>
                      <p className="font-serif text-xs text-stone-400 mt-1 max-w-sm mx-auto leading-relaxed">
                        Adjust index criteria parameters, clear spatial boundaries or input alternate coordinates keywords to update the marketplace ledger.
                      </p>
                    </div>
                  ) : (
                    filteredProperties.map((prop) => {
                      const isWatched = watchedPropertyIds.includes(prop.id);
                      return (
                        <div
                          key={prop.id}
                          className="bg-white border border-border-muted p-5 flex flex-col justify-between hover:border-dark transition-all group relative rounded-none"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <span className="px-2 py-0.5 bg-dark text-white font-mono text-[9px] uppercase tracking-wider font-bold rounded-none">
                                {prop.type}
                              </span>
                              <div className="flex items-center space-x-2">
                                <span className="font-mono text-[9px] text-stone-400 uppercase">GRID {prop.coordinates.gridRef}</span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleToggleWatch(prop.id);
                                  }}
                                  className="p-1 text-stone-300 hover:text-primary transition cursor-pointer"
                                >
                                  <Heart className={`h-4 w-4 ${isWatched ? "fill-primary text-primary" : "text-stone-300 hover:text-stone-400"}`} />
                                </button>
                              </div>
                            </div>

                            <h4 
                              onClick={() => setSelectedProperty(prop)}
                              className="text-lg font-serif font-extrabold text-dark uppercase cursor-pointer hover:text-primary tracking-tight line-clamp-1 leading-tight"
                            >
                              {prop.title}
                            </h4>
                            
                            <div className="flex items-center space-x-1.5 text-stone-500 font-mono text-[10px] mt-1 uppercase">
                              <MapPin className="h-3 w-3 text-primary" />
                              <span>{prop.location.town}, {prop.location.county} ({prop.location.postcode})</span>
                            </div>

                            <p className="text-xs text-stone-600 font-serif leading-relaxed line-clamp-2 mt-2">
                              {prop.description}
                            </p>
                          </div>

                          <div className="flex justify-between items-end mt-4 pt-3 border-t border-border-muted">
                            <div>
                              <span className="block text-[8px] font-mono text-stone-400 uppercase tracking-widest">ASSET ALLOCATION VALUE</span>
                              <span className="text-base font-extrabold text-primary font-mono tracking-tight">
                                {prop.price > 0 ? `£${prop.price.toLocaleString()}` : "POA"}
                              </span>
                            </div>

                            <button
                              onClick={() => setSelectedProperty(prop)}
                              className="px-3.5 py-1.5 bg-dark text-white font-mono text-[10px] tracking-wider uppercase font-bold hover:bg-primary transition flex items-center rounded-none cursor-pointer"
                            >
                              <span>Inspect Dossier</span>
                              <ChevronRight className="h-3.5 w-3.5 ml-1" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Interactive GIS Mapping Column on Right */}
              <div className="lg:col-span-6 min-h-[500px]">
                <MapGIS
                  properties={properties}
                  selectedProperty={selectedProperty}
                  onSelectProperty={(p) => { setSelectedProperty(p); }}
                  filteredProperties={filteredProperties}
                  onDrawFilter={(ids) => setDrawnFilteredPropertyIds(ids)}
                />
              </div>
            </div>

          </div>
        )}

        {/* VIEW DETAILED PROPERTY SPECIFICATION */}
        {currentView === "marketplace" && selectedProperty && (
          <PropertyDetail
            property={selectedProperty}
            onBack={() => setSelectedProperty(null)}
            onApplyFinance={handleApplyFinance}
            onAddToast={addToast}
          />
        )}

        {/* VIEW ANALYTICS INTELLIGENCE CODES */}
        {currentView === "intelligence" && (
          <AnalyticsPanel />
        )}

        {/* VIEW CLIENT DASHBOARD PROFILES */}
        {currentView === "dashboard" && (
          <Dashboard
            watchedProperties={watchedPropertiesList}
            onUnwatchProperty={handleUnwatchProperty}
            financingApplications={financingApplications}
            savedSearches={savedSearches}
            onSelectProperty={(p) => { setSelectedProperty(p); setCurrentView("marketplace"); }}
            onAddToast={addToast}
          />
        )}

        {/* VIEW SELLER BROKER COMPILER */}
        {currentView === "seller" && (
          <SellerPortal
            properties={properties}
            onAddProperty={handleAddProperty}
            onRemoveProperty={handleRemoveProperty}
            onAddToast={addToast}
          />
        )}

      </main>

      {/* Global Toast Drawer overlay */}
      <div className="fixed bottom-6 right-6 z-50 space-y-3 font-mono text-xs max-w-sm w-full">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`p-4 border-2 shadow-none flex items-start space-x-2 animate-fade-in rounded-none ${
              toast.type === "success" 
                ? "bg-emerald-50 text-emerald-900 border-emerald-500" 
                : toast.type === "error"
                ? "bg-rose-50 text-rose-900 border-rose-500"
                : "bg-dark text-white border-dark"
            }`}
          >
            <div className="flex-1">
              <span className="font-extrabold block uppercase text-[10px] tracking-wider mb-0.5">
                {toast.type === "success" ? "TRANSACTION SECURED" : toast.type === "error" ? "SYSTEM ALERT" : "LEDGER UPDATE"}
              </span>
              <p className="text-[11px] leading-relaxed">{toast.message}</p>
            </div>
            <button 
              onClick={() => removeToast(toast.id)} 
              className="text-stone-400 hover:text-dark hover:scale-110 shrink-0 font-bold cursor-pointer"
            >
              ×
            </button>
          </div>
        ))}
      </div>

      {/* Institutional Footer */}
      <footer className="border-t-2 border-dark bg-dark text-stone-300 py-10 px-4 md:px-10 font-mono text-[10px] tracking-wider uppercase mt-12 rounded-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <span className="font-black text-white block text-sm tracking-widest">YORKSHIRE LAND & PROPERTY</span>
            <p className="text-stone-400 lowercase font-serif normal-case text-xs">
              © 2026 Yorkshire Land & Property (A Rhino Bank Company). All rights reserved. Underwritten by Rhino Bank Corporate Finance.
            </p>
          </div>

          <div className="flex flex-wrap gap-4 text-stone-500 font-mono font-bold">
            <span className="border border-stone-800 px-2 py-1 text-primary">SECURE AES-256 CHANNEL</span>
            <span className="border border-stone-800 px-2 py-1 text-primary">OSGB36 GRID REF MATRIX</span>
            <span className="border border-stone-800 px-2 py-1 text-primary">COMPLIANCE VAULT V4.0</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
