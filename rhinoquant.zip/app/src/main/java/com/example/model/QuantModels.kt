package com.example.model

enum class FactorCategory(val label: String) {
    VALUE("Value"),
    MOMENTUM("Momentum"),
    QUALITY("Quality"),
    SIZE("Size"),
    VOLATILITY("Volatility"),
    LIQUIDITY("Liquidity"),
    CARRY("Carry"),
    GROWTH("Growth"),
    PROFITABILITY("Profitability")
}

data class FactorItem(
    val id: String,
    val name: String,
    val category: FactorCategory,
    val icScore: Double, // Information Coefficient
    val tStat: Double,
    val turnoverMonthlyPct: Double,
    val halfLifeDays: Int,
    val annualizedAlphaPct: Double,
    val sharpeContribution: Double,
    val formulaDescription: String
)

enum class MLModelType(val label: String) {
    LINEAR_REGRESSION("Ridge / Lasso Linear"),
    LOGISTIC_REGRESSION("Logistic Classifier"),
    RANDOM_FOREST("Random Forest (100 Trees)"),
    GRADIENT_BOOSTING("LightGBM / XGBoost Regressor"),
    LSTM_NEURAL_NET("Temporal LSTM Network"),
    GARCH_VOLATILITY("GARCH(1,1) Volatility")
}

data class MLModelItem(
    val id: String,
    val name: String,
    val type: MLModelType,
    val target: String,
    val features: List<String>,
    val trainR2Score: Double,
    val valR2Score: Double,
    val testR2Score: Double,
    val precisionRoc: Double,
    val status: String, // TRAINED, VALIDATING, DEPLOYED
    val featureImportances: Map<String, Float>
)

data class DatasetItem(
    val id: String,
    val name: String,
    val assetCoverage: String,
    val frequency: String,
    val dateRange: String,
    val sizeMb: Double,
    val rowCount: Long,
    val format: String = "Apache Parquet"
)

data class QuantExperiment(
    val id: String,
    val name: String,
    val datasetName: String,
    val featuresList: List<String>,
    val modelType: String,
    val validationMethod: String,
    val sharpe: Double,
    val maxDrawdownPct: Double,
    val winRatePct: Double,
    val status: String // RUNNING, COMPLETED, QUEUED
)

data class StrategyComponentDAG(
    val id: String,
    val name: String,
    val universe: String,
    val features: List<String>,
    val signalFormula: String,
    val sizingMethod: String,
    val stopLossPct: Double,
    val takeProfitPct: Double,
    val maxLeverage: Double,
    val rebalanceFrequency: String,
    val transactionCostBps: Double,
    val isLive: Boolean
)

data class BacktestMetricSummary(
    val strategyName: String,
    val period: String,
    val initialCapital: Double,
    val finalNav: Double,
    val totalReturnPct: Double,
    val annualizedReturnPct: Double,
    val sharpeRatio: Double,
    val sortinoRatio: Double,
    val maxDrawdownPct: Double,
    val volatilityPct: Double,
    val winRatePct: Double,
    val profitFactor: Double,
    val turnoverPct: Double,
    val calmarRatio: Double,
    val equityCurve: List<Float>,
    val benchmarkCurve: List<Float>,
    val drawdownCurve: List<Float>,
    val monthlyReturnsMatrix: List<Float>
)

data class HftTelemetryData(
    val messagesPerSec: Long,
    val ordersPerSec: Long,
    val fillsPerSec: Long,
    val mdLatencyP50Us: Double,
    val strategyLatencyP50Us: Double,
    val riskLatencyP50Us: Double,
    val endToEndP99Us: Double,
    val grossPnl: Double,
    val feesPaid: Double,
    val netPnl: Double,
    val queuePositionPercent: Double,
    val fillRatioPct: Double,
    val cancelRatioPct: Double,
    val adverseSelectionBps: Double
)
