package com.example.model

data class IPOModelData(
    val companyName: String,
    val tickerSymbol: String,
    val targetExchange: String,
    val ttmRevenueM: Double,
    val ttmEbitdaM: Double,
    val revenueGrowthPct: Double,
    val ebitdaMarginPct: Double,
    val netDebtM: Double,
    val totalSharesM: Double,
    val targetOfferingM: Double,
    val peerMedianEvEbitda: Double,
    val peerMedianPe: Double,
    val calculatedEvLowM: Double,
    val calculatedEvHighM: Double,
    val indicativeSharePriceLow: Double,
    val indicativeSharePriceHigh: Double,
    val institutionalBookOversubscription: Double
)

data class CorporateBondIssuance(
    val id: String,
    val issuerName: String,
    val sector: String,
    val creditRating: String, // e.g., "AA- / Aa3"
    val issueSizeM: Double,
    val currency: String,
    val tenorYears: Int,
    val benchmarkCurve: String,
    val benchmarkYieldPct: Double,
    val indicativeSpreadBps: Double,
    val finalCouponPct: Double,
    val bookDemandM: Double,
    val stage: String // PRE_MARKETING, BOOK_BUILDING, PRICED, ALLOCATED
)

data class LBOModelData(
    val targetName: String,
    val enterpriseValueM: Double,
    val ebitdaM: Double,
    val entryMultiple: Double,
    val seniorDebtPct: Double,
    val mezzanineDebtPct: Double,
    val sponsorEquityPct: Double,
    val exitHoldingYears: Int,
    val exitMultiple: Double,
    val projectedIrrPct: Double,
    val projectedMoic: Double
)

data class InsuranceAnalyticsData(
    val businessLine: String,
    val grossWrittenPremiumM: Double,
    val earnedPremiumM: Double,
    val paidClaimsM: Double,
    val lossRatioPct: Double,
    val combinedRatioPct: Double,
    val actuarialClaimReserveM: Double,
    val catastrophePml100M: Double,
    val reinsuranceCoverageM: Double
)

data class TreasuryALMData(
    val totalCashEquivalentM: Double,
    val hqlaBufferM: Double,
    val liquidityCoverageRatioPct: Double, // LCR e.g. 142.5%
    val netStableFundingRatioPct: Double, // NSFR e.g. 128.4%
    val interestRateRiskDeltaEvePct: Double, // Delta EVE for +200bps
    val interestRateRiskDeltaNiiPct: Double, // Delta NII for +200bps
    val durationOfEquityYears: Double,
    val regulatoryCet1RatioPct: Double
)

data class OptionGreeks(
    val underlyingTicker: String,
    val strikePrice: Double,
    val spotPrice: Double,
    val daysToExpiry: Int,
    val impliedVolPct: Double,
    val callPrice: Double,
    val putPrice: Double,
    val delta: Double,
    val gamma: Double,
    val thetaPerDay: Double,
    val vegaPer1Pct: Double,
    val rhoPer1Pct: Double
)

data class FixedIncomeBond(
    val isin: String,
    val name: String,
    val issuerType: String, // SOVEREIGN, CORPORATE_IG, CORPORATE_HY
    val couponPct: Double,
    val maturityDate: String,
    val cleanPrice: Double,
    val yieldToMaturityPct: Double,
    val modifiedDurationYears: Double,
    val convexity: Double,
    val zSpreadBps: Double,
    val oasBps: Double,
    val dv01: Double,
    val rating: String
)
