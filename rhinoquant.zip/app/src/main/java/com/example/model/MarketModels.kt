package com.example.model

enum class AssetClass(val label: String, val badge: String) {
    EQUITIES("Equities", "EQ"),
    BONDS("Bonds", "FI"),
    FX("Foreign Exchange", "FX"),
    RATES("Rates & Curves", "RT"),
    COMMODITIES("Commodities", "CM"),
    CRYPTO("Digital Assets", "CR"),
    DERIVATIVES("Derivatives", "DR"),
    INDICES("Indices", "IDX")
}

enum class DataSourceType(val label: String) {
    LIVE("LIVE"),
    DELAYED("DELAYED (15m)"),
    HISTORICAL("HISTORICAL"),
    SYNTHETIC("SYNTHETIC DEMO")
}

data class CandleStickPoint(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class OrderBookLevel(
    val price: Double,
    val size: Double,
    val total: Double,
    val ordersCount: Int
)

data class OrderBookData(
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val spread: Double,
    val spreadBps: Double,
    val midPrice: Double
)

data class MarketTrade(
    val id: String,
    val timeFormatted: String,
    val price: Double,
    val size: Double,
    val isBuy: Boolean
)

data class Instrument(
    val ticker: String,
    val name: String,
    val assetClass: AssetClass,
    val price: Double,
    val change: Double,
    val changePercent: Double,
    val high24h: Double,
    val low24h: Double,
    val volume24h: Double,
    val marketCapM: Double,
    val peRatio: Double?,
    val evEbitda: Double?,
    val beta: Double?,
    val impliedVol: Double?,
    val yieldPercent: Double?,
    val durationYears: Double?,
    val currency: String = "USD",
    val dataSource: DataSourceType = DataSourceType.SYNTHETIC,
    val priceHistory: List<CandleStickPoint> = emptyList(),
    val summary: String = ""
)
