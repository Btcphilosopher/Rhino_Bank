package com.example.model

data class PositionItem(
    val ticker: String,
    val name: String,
    val assetClass: AssetClass,
    val quantity: Double,
    val entryPrice: Double,
    val markPrice: Double,
    val marketValue: Double,
    val weightPct: Double,
    val dailyPnl: Double,
    val dailyPnlPct: Double,
    val totalUnrealizedPnl: Double,
    val beta: Double,
    val ctrPct: Double // Contribution to Risk
)

data class PortfolioSummary(
    val nav: Double,
    val dailyPnl: Double,
    val dailyPnlPct: Double,
    val inceptionReturnPct: Double,
    val grossLeverage: Double,
    val netLeverage: Double,
    val cashBalance: Double,
    val cashPct: Double,
    val var95_1d: Double,
    val expectedShortfall99: Double,
    val totalPositionsCount: Int
)

data class ExposureItem(
    val label: String,
    val percentage: Float,
    val notionalM: Double
)

data class StressScenario(
    val id: String,
    val name: String,
    val description: String,
    val historicalReference: String,
    val equityShockPct: Double,
    val ratesShockBps: Double,
    val fxShockPct: Double,
    val volShockPct: Double,
    val creditSpreadWideningBps: Double,
    val estimatedNavImpactPct: Double,
    val estimatedLossM: Double,
    val estimatedRecoveryDays: Int
)

enum class OptimizationObjective(val label: String) {
    MAX_SHARPE("Max Sharpe Ratio"),
    MIN_VOLATILITY("Minimum Volatility (Global Min Var)"),
    RISK_PARITY("Equal Risk Contribution (Risk Parity)"),
    MAX_DIVERSIFICATION("Maximum Diversification"),
    TARGET_RETURN("Target Return / Min Risk")
}

data class OptimizationResult(
    val objective: OptimizationObjective,
    val expectedReturnPct: Double,
    val expectedVolPct: Double,
    val sharpeRatio: Double,
    val assetWeights: Map<String, Float>,
    val efficientFrontierCurve: List<Pair<Float, Float>>, // Volatility to Expected Return
    val activeConstraintsDescription: String
)
