package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val QuantColorScheme = darkColorScheme(
    primary = QuantCyan,
    onPrimary = DarkCanvas,
    primaryContainer = DarkSurfaceElevated,
    onPrimaryContainer = QuantCyan,
    secondary = QuantGold,
    onSecondary = DarkCanvas,
    secondaryContainer = DarkSurfaceCard,
    onSecondaryContainer = QuantGold,
    tertiary = QuantBlue,
    onTertiary = TextPrimary,
    background = DarkCanvas,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    outlineVariant = DarkBorderSubtle,
    error = FinancialBear,
    onError = TextPrimary
)

@Composable
fun RhinoQuantTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = QuantColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    RhinoQuantTheme(darkTheme, dynamicColor, content)
}

