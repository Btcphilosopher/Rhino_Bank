package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FinancialMath
import com.example.model.OptionGreeks
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun DerivativesView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    var spotPrice by remember { mutableStateOf(228.45) }
    var strikePrice by remember { mutableStateOf(230.00) }
    var volPct by remember { mutableStateOf(22.0) }
    var daysToExpiry by remember { mutableStateOf(30) }
    var selectedStrategy by remember { mutableStateOf("BULL_CALL_SPREAD") }

    val calculatedGreeks = remember(spotPrice, strikePrice, volPct, daysToExpiry) {
        FinancialMath.calculateBlackScholes(
            spotPrice = spotPrice,
            strikePrice = strikePrice,
            riskFreeRate = 0.045,
            volatility = volPct / 100.0,
            daysToExpiry = daysToExpiry,
            ticker = "AAPL-OPT"
        )
    }


    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Greeks Pricing Output
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "BLACK-SCHOLES-MERTON ANALYTICAL ENGINE",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = QuantCyan
                                )
                            )
                            Text(
                                text = "Full 1st and 2nd Order Analytical Derivatives (Greeks)",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(color = DarkSurfaceElevated, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = "Call: $${String.format(Locale.US, "%.2f", calculatedGreeks.callPrice)}",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FinancialBull
                                    )
                                )
                            }
                            Surface(color = DarkSurfaceElevated, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = "Put: $${String.format(Locale.US, "%.2f", calculatedGreeks.putPrice)}",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FinancialBear
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Greeks 5-pack cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuantMetricCard(
                            title = "Delta (Δ)",
                            value = String.format(Locale.US, "%.3f", calculatedGreeks.delta),
                            subValue = "Call Sensitivity",
                            accentColor = QuantCyan,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "Gamma (Γ)",
                            value = String.format(Locale.US, "%.4f", calculatedGreeks.gamma),
                            subValue = "Curvature",
                            accentColor = QuantGold,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "Vega (ν)",
                            value = String.format(Locale.US, "%.3f", calculatedGreeks.vegaPer1Pct),
                            subValue = "Per 1% IV",
                            accentColor = QuantPurple,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuantMetricCard(
                            title = "Theta (θ)",
                            value = String.format(Locale.US, "-$%.3f", kotlin.math.abs(calculatedGreeks.thetaPerDay)),
                            subValue = "1-Day Decay",
                            accentColor = FinancialBear,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "Rho (ρ)",
                            value = String.format(Locale.US, "%.3f", calculatedGreeks.rhoPer1Pct),
                            subValue = "Rate Risk",
                            accentColor = TextSecondary,
                            modifier = Modifier.weight(1f)
                        )

                        QuantMetricCard(
                            title = "Moneyness",
                            value = "${String.format(Locale.US, "%.1f%%", (spotPrice / strikePrice) * 100.0)}",
                            subValue = if (spotPrice >= strikePrice) "ITM Call" else "OTM Call",
                            accentColor = FinancialBull,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Interactive Parameter Sliders
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurfaceCard
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "INTERACTIVE CONTRACT PARAMETERS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Spot Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Underlying Spot: $${String.format(Locale.US, "%.2f", spotPrice)}", style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                        Slider(
                            value = spotPrice.toFloat(),
                            onValueChange = { spotPrice = it.toDouble() },
                            valueRange = 150f..300f,
                            modifier = Modifier.width(180.dp),
                            colors = SliderDefaults.colors(thumbColor = QuantCyan, activeTrackColor = QuantCyan)
                        )
                    }

                    // Strike Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Strike Price: $${String.format(Locale.US, "%.2f", strikePrice)}", style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                        Slider(
                            value = strikePrice.toFloat(),
                            onValueChange = { strikePrice = it.toDouble() },
                            valueRange = 150f..300f,
                            modifier = Modifier.width(180.dp),
                            colors = SliderDefaults.colors(thumbColor = QuantGold, activeTrackColor = QuantGold)
                        )
                    }

                    // IV Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Implied Volatility: ${String.format(Locale.US, "%.1f%%", volPct)}", style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                        Slider(
                            value = volPct.toFloat(),
                            onValueChange = { volPct = it.toDouble() },
                            valueRange = 10f..80f,
                            modifier = Modifier.width(180.dp),
                            colors = SliderDefaults.colors(thumbColor = QuantPurple, activeTrackColor = QuantPurple)
                        )
                    }

                    // DTE Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Days to Expiry (DTE): ${daysToExpiry}d", style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                        Slider(
                            value = daysToExpiry.toFloat(),
                            onValueChange = { daysToExpiry = it.toInt() },
                            valueRange = 1f..180f,
                            modifier = Modifier.width(180.dp),
                            colors = SliderDefaults.colors(thumbColor = FinancialBull, activeTrackColor = FinancialBull)
                        )
                    }
                }
            }
        }

        // Multi-Leg Strategy Payoff Diagram
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EXPIRY PAYOFF PROFILE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantCyan
                            )
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("LONG_CALL" to "Long Call", "BULL_CALL_SPREAD" to "Bull Spread", "STRADDLE" to "Straddle").forEach { (st, label) ->
                                val isSel = selectedStrategy == st
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .clickable { selectedStrategy = st }
                                        .background(if (isSel) DarkSurfaceElevated else DarkCanvas)
                                        .border(1.dp, if (isSel) QuantCyan else DarkBorderSubtle, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSel) QuantCyan else TextMuted
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OptionPayoffChart(
                        strike = strikePrice,
                        premium = calculatedGreeks.callPrice,
                        strategyType = selectedStrategy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkCanvas)
                            .padding(6.dp)
                    )
                }
            }
        }
    }
}
