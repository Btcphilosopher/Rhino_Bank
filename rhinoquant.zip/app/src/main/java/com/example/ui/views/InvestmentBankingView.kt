package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun InvestmentBankingView(
    state: WorkstationUiState,
    onUpdateOffering: (Double) -> Unit,
    onUpdateLBOExit: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedIBTab by remember { mutableStateOf("IPO") }
    val ipo = state.ipoModel
    val lbo = state.lboModel
    val treasury = state.treasuryData

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // IB Sub-Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "IPO" to "ECM / IPO Pricing",
                    "DCM" to "DCM Bond Syndicate",
                    "LBO" to "PE / LBO Model",
                    "TREASURY" to "Treasury ALM"
                ).forEach { (key, label) ->
                    val isSel = selectedIBTab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { selectedIBTab = key }
                            .background(if (isSel) DarkSurfaceElevated else DarkSurfaceCard)
                            .border(1.dp, if (isSel) QuantCyan else DarkBorder, RoundedCornerShape(6.dp))
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) QuantCyan else TextSecondary
                            )
                        )
                    }
                }
            }
        }

        when (selectedIBTab) {
            "IPO" -> {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                        color = DarkSurface
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${ipo.companyName} (${ipo.tickerSymbol}) - IPO SYNDICATE DESK",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = QuantGold
                                        )
                                    )
                                    Text(
                                        text = "Target Exchange: ${ipo.targetExchange} • Growth: ${ipo.revenueGrowthPct}%",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                                    )
                                }

                                Surface(color = FinancialBullDim, shape = RoundedCornerShape(4.dp)) {
                                    Text(
                                        text = "${String.format(Locale.US, "%.1fx", ipo.institutionalBookOversubscription)} OVERSUBSCRIBED",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FinancialBull
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                QuantMetricCard(
                                    title = "Enterprise Value (EV)",
                                    value = "£${String.format(Locale.US, "%.1fB", ipo.calculatedEvLowM / 1000.0)} - £${String.format(Locale.US, "%.1fB", ipo.calculatedEvHighM / 1000.0)}",
                                    subValue = "Revenue: £${ipo.ttmRevenueM}M",
                                    accentColor = QuantCyan,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Target IPO Size",
                                    value = "£${String.format(Locale.US, "%.0fM", ipo.targetOfferingM)}",
                                    subValue = "Dilution: ${String.format(Locale.US, "%.1f%%", (ipo.targetOfferingM / ipo.calculatedEvHighM) * 100.0)}",
                                    accentColor = QuantGold,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Valuation Multiples",
                                    value = "${ipo.peerMedianEvEbitda}x EV/EBITDA",
                                    subValue = "${ipo.peerMedianPe}x P/E",
                                    accentColor = FinancialBull,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Offering Size Slider
                            Text(
                                text = "ADJUST OFFERING BOOK SIZE: £${String.format(Locale.US, "%.0fM", ipo.targetOfferingM)}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                            )
                            Slider(
                                value = ipo.targetOfferingM.toFloat(),
                                onValueChange = { onUpdateOffering(it.toDouble()) },
                                valueRange = 150f..600f,
                                colors = SliderDefaults.colors(thumbColor = QuantGold, activeTrackColor = QuantGold)
                            )
                        }
                    }
                }
            }

            "DCM" -> {
                item {
                    SectionHeader(
                        title = "DCM CORPORATE BOND SYNDICATE BOOKBUILDING",
                        subtitle = "Institutional Allocations, Orderbook Multiples & Spread over Benchmark"
                    )
                }

                items(state.dcmIssuances) { dcm ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                        color = DarkSurfaceCard
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(color = DarkSurfaceElevated, shape = RoundedCornerShape(4.dp)) {
                                        Text(
                                            text = dcm.creditRating,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold, color = QuantGold)
                                        )
                                    }
                                    Text(
                                        text = dcm.issuerName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                                    )
                                }

                                Text(
                                    text = "Book: £${dcm.bookDemandM}M (${String.format(Locale.US, "%.1fx", dcm.bookDemandM / dcm.issueSizeM)} Cover)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = FinancialBull)
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Coupon: ${dcm.finalCouponPct}% • Tenor: ${dcm.tenorYears}y",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = TextSecondary)
                                )
                                Text(
                                    text = "Spread: +${dcm.indicativeSpreadBps.toInt()} bps vs ${dcm.benchmarkCurve}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = QuantCyan)
                                )
                            }
                        }
                    }
                }
            }

            "LBO" -> {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                        color = DarkSurface
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "SPONSOR LBO VALUATION & RETURN WATERFALL: ${lbo.targetName.uppercase()}",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = QuantCyan)
                            )
                            Text(
                                text = "5-Year Exit Waterfall • Senior Debt + Mezzanine + Sponsor Equity",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                QuantMetricCard(
                                    title = "Entry EV / EBITDA",
                                    value = "£${lbo.enterpriseValueM.toInt()}M (${lbo.entryMultiple}x)",
                                    subValue = "EBITDA: £${lbo.ebitdaM.toInt()}M",
                                    accentColor = QuantCyan,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Sponsor Equity",
                                    value = "${(lbo.sponsorEquityPct * 100).toInt()}%",
                                    subValue = "Senior: ${(lbo.seniorDebtPct * 100).toInt()}% | Mezz: ${(lbo.mezzanineDebtPct * 100).toInt()}%",
                                    accentColor = QuantGold,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Projected IRR / MOIC",
                                    value = "${String.format(Locale.US, "%.1f%%", lbo.projectedIrrPct)} IRR",
                                    subValue = "${String.format(Locale.US, "%.2fx", lbo.projectedMoic)} MOIC",
                                    accentColor = FinancialBull,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Exit Multiple Slider
                            Text(
                                text = "ADJUST EXIT EV/EBITDA MULTIPLE: ${String.format(Locale.US, "%.1fx", lbo.exitMultiple)}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                            )
                            Slider(
                                value = lbo.exitMultiple.toFloat(),
                                onValueChange = { onUpdateLBOExit(it.toDouble()) },
                                valueRange = 8f..18f,
                                colors = SliderDefaults.colors(thumbColor = QuantCyan, activeTrackColor = QuantCyan)
                            )
                        }
                    }
                }
            }

            "TREASURY" -> {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                        color = DarkSurface
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "RHINO BANK TREASURY & LIQUIDITY ALM",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = QuantGold)
                            )
                            Text(
                                text = "Basel III Prudential Ratios & High Quality Liquid Assets (HQLA)",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                QuantMetricCard(
                                    title = "Liquidity Coverage (LCR)",
                                    value = "${treasury.liquidityCoverageRatioPct}%",
                                    subValue = "Regulatory Min: 100%",
                                    delta = "+42% Buffer",
                                    isPositive = true,
                                    accentColor = FinancialBull,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Net Stable Funding (NSFR)",
                                    value = "${treasury.netStableFundingRatioPct}%",
                                    subValue = "Regulatory Min: 100%",
                                    accentColor = QuantCyan,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "HQLA Buffer",
                                    value = "£${String.format(Locale.US, "%.1fB", treasury.hqlaBufferM / 1000.0)}",
                                    subValue = "Central Bank Reserves",
                                    accentColor = QuantGold,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

