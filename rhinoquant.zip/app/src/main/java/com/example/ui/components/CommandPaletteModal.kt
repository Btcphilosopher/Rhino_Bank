package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Instrument
import com.example.model.WorkstationTab
import com.example.ui.theme.*

data class QuickCommand(
    val title: String,
    val category: String,
    val subtitle: String,
    val icon: ImageVector,
    val action: () -> Unit
)

@Composable
fun CommandPaletteModal(
    isOpen: Boolean,
    onClose: () -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    instruments: List<Instrument>,
    onSelectInstrument: (String) -> Unit,
    onSelectTab: (WorkstationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isOpen) return

    val commands = remember {
        listOf(
            QuickCommand("Open Risk Terminal", "COMMAND", "View Parametric VaR & Stress Maps", Icons.Default.Warning) {
                onSelectTab(WorkstationTab.RISK_TERMINAL)
                onClose()
            },
            QuickCommand("Run Strategy Backtest", "COMMAND", "Execute Alpha Model Backtest", Icons.Default.PlayArrow) {
                onSelectTab(WorkstationTab.BACKTEST)
                onClose()
            },
            QuickCommand("Open Fixed Income Desk", "COMMAND", "Sovereign & Corporate Yield Curves", Icons.Default.Timeline) {
                onSelectTab(WorkstationTab.FIXED_INCOME)
                onClose()
            },
            QuickCommand("Launch IPO Valuation Model", "COMMAND", "Investment Banking ECM Tool", Icons.Default.AccountBalance) {
                onSelectTab(WorkstationTab.BANKING)
                onClose()
            },
            QuickCommand("Inspect HFT Order Flow", "COMMAND", "Microsecond Telemetry & Latencies", Icons.Default.Speed) {
                onSelectTab(WorkstationTab.HFT_MONITOR)
                onClose()
            },
            QuickCommand("Open Research Notebook", "COMMAND", "Python / SQL Quant Environment", Icons.Default.Code) {
                onSelectTab(WorkstationTab.NOTEBOOK)
                onClose()
            }
        )
    }

    val filteredInstruments = remember(searchQuery, instruments) {
        if (searchQuery.isBlank()) instruments.take(5)
        else instruments.filter {
            it.ticker.contains(searchQuery, ignoreCase = true) ||
                    it.name.contains(searchQuery, ignoreCase = true) ||
                    it.assetClass.label.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredCommands = remember(searchQuery) {
        if (searchQuery.isBlank()) commands
        else commands.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                    it.subtitle.contains(searchQuery, ignoreCase = true)
        }
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(12.dp))
                .border(1.5.dp, QuantCyan, RoundedCornerShape(12.dp)),
            color = DarkCanvasSecondary
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text(
                            "Search instruments, models, trades, commands...",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = QuantCyan)
                    },
                    trailingIcon = {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = QuantCyan,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (filteredInstruments.isNotEmpty()) {
                        item {
                            Text(
                                text = "INSTRUMENTS & ASSETS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = QuantCyan
                                ),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }

                        items(filteredInstruments) { inst ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable {
                                        onSelectInstrument(inst.ticker)
                                        onSelectTab(WorkstationTab.MARKETS)
                                        onClose()
                                    }
                                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                                color = DarkSurface
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            color = DarkSurfaceElevated,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = inst.assetClass.badge,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = QuantGold
                                                )
                                            )
                                        }

                                        Column {
                                            Text(
                                                text = inst.ticker,
                                                style = MaterialTheme.typography.labelLarge.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = TextPrimary
                                                )
                                            )
                                            Text(
                                                text = inst.name,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontSize = 10.sp,
                                                    color = TextSecondary
                                                )
                                            )
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${inst.currency} ${inst.price}",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                        )
                                        Text(
                                            text = "${if (inst.changePercent >= 0) "+" else ""}${String.format(java.util.Locale.US, "%.2f", inst.changePercent)}%",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (inst.changePercent >= 0) FinancialBull else FinancialBear
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (filteredCommands.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "WORKSTATION ACTIONS & WORKSPACES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = QuantGold
                                ),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }

                        items(filteredCommands) { cmd ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { cmd.action() }
                                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                                color = DarkSurfaceCard
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(cmd.icon, contentDescription = null, tint = QuantCyan, modifier = Modifier.size(18.dp))
                                    Column {
                                        Text(
                                            text = cmd.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                color = TextPrimary
                                            )
                                        )
                                        Text(
                                            text = cmd.subtitle,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontSize = 10.sp,
                                                color = TextSecondary
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
