package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssetClass
import com.example.model.Instrument
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun MarketsTerminalView(
    state: WorkstationUiState,
    onSelectInstrument: (String) -> Unit,
    onSetTimeframe: (String) -> Unit,
    onSetChartType: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedAssetClass by remember { mutableStateOf<AssetClass?>(null) }
    val selected = state.selectedInstrument ?: state.instruments.first()

    val filteredInstruments = remember(selectedAssetClass, state.instruments) {
        if (selectedAssetClass == null) state.instruments
        else state.instruments.filter { it.assetClass == selectedAssetClass }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Asset Class Filter Pills
        item {
            val scrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // ALL pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { selectedAssetClass = null }
                        .background(if (selectedAssetClass == null) DarkSurfaceElevated else DarkSurfaceCard)
                        .border(1.dp, if (selectedAssetClass == null) QuantCyan else DarkBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "ALL ASSET CLASSES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (selectedAssetClass == null) QuantCyan else TextSecondary
                        )
                    )
                }

                AssetClass.values().forEach { ac ->
                    val isSel = selectedAssetClass == ac
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { selectedAssetClass = ac }
                            .background(if (isSel) DarkSurfaceElevated else DarkSurfaceCard)
                            .border(1.dp, if (isSel) QuantCyan else DarkBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = ac.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) QuantCyan else TextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Instrument Summary & Analytics Header
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = selected.ticker,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = QuantCyan
                                    )
                                )
                                Text(
                                    text = selected.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                                )
                                Surface(
                                    color = SyntheticBadgeBg,
                                    shape = RoundedCornerShape(4.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SyntheticBadgeBorder)
                                ) {
                                    Text(
                                        text = selected.dataSource.label,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SyntheticBadgeText
                                        )
                                    )
                                }
                            }
                            Text(
                                text = selected.summary,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${selected.currency} ${String.format(Locale.US, "%.2f", selected.price)}",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "${if (selected.changePercent >= 0) "+" else ""}${String.format(Locale.US, "%.2f", selected.changePercent)}% (${if (selected.change >= 0) "+" else ""}${String.format(Locale.US, "%.2f", selected.change)})",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected.changePercent >= 0) FinancialBull else FinancialBear
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Timeframe & Chart Type Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("1M", "5M", "15M", "1H", "1D", "1W").forEach { tf ->
                                val isSel = state.activeTimeframe == tf
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .clickable { onSetTimeframe(tf) }
                                        .background(if (isSel) DarkSurfaceElevated else DarkCanvas)
                                        .border(1.dp, if (isSel) QuantCyan else DarkBorderSubtle, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = tf,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSel) QuantCyan else TextMuted
                                        )
                                    )
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("CANDLESTICK", "LINE", "DEPTH").forEach { ct ->
                                val isSel = state.activeChartType == ct
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .clickable { onSetChartType(ct) }
                                        .background(if (isSel) DarkSurfaceElevated else DarkCanvas)
                                        .border(1.dp, if (isSel) QuantGold else DarkBorderSubtle, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = ct,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSel) QuantGold else TextMuted
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Primary Chart
                    when (state.activeChartType) {
                        "CANDLESTICK" -> CandlestickChart(
                            candles = selected.priceHistory,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkCanvas)
                                .padding(6.dp)
                        )
                        "LINE" -> FinancialLineChart(
                            points = selected.priceHistory.map { it.close.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkCanvas)
                                .padding(6.dp)
                        )
                        "DEPTH" -> state.orderBook?.let {
                            OrderBookDepthChart(
                                orderBook = it,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DarkCanvas)
                                    .padding(6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Quantitative Fundamentals & Risk Breakdown
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "24H High / Low",
                    value = "${String.format(Locale.US, "%.2f", selected.high24h)} / ${String.format(Locale.US, "%.2f", selected.low24h)}",
                    subValue = "Vol: ${String.format(Locale.US, "%.1fM", selected.volume24h / 1000000.0)}",
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "P/E / EV-EBITDA",
                    value = "${selected.peRatio?.let { String.format(Locale.US, "%.1fx", it) } ?: "N/A"} | ${selected.evEbitda?.let { String.format(Locale.US, "%.1fx", it) } ?: "N/A"}",
                    subValue = "Beta: ${selected.beta ?: "N/A"}",
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Implied Vol (30D)",
                    value = "${selected.impliedVol?.let { String.format(Locale.US, "%.1f%%", it) } ?: "N/A"}",
                    subValue = "Yield: ${selected.yieldPercent?.let { String.format(Locale.US, "%.2f%%", it) } ?: "N/A"}",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // L2 Order Book & Tape
        item {
            OrderBookComponent(
                orderBook = state.orderBook,
                recentTrades = state.recentTrades,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Instrument Table list
        item {
            SectionHeader(
                title = "MARKET UNIVERSE QUOTES",
                subtitle = "Select an asset to load full analytics, L2 order book and Greeks"
            )
        }

        items(filteredInstruments) { inst ->
            val isSelected = selected.ticker == inst.ticker
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { onSelectInstrument(inst.ticker) }
                    .border(1.dp, if (isSelected) QuantCyan else DarkBorderSubtle, RoundedCornerShape(6.dp)),
                color = if (isSelected) DarkSurfaceElevated else DarkSurfaceCard
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(color = DarkSurface, shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = inst.assetClass.badge,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = QuantGold
                                )
                            )
                        }

                        Column {
                            Text(
                                text = inst.ticker,
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) QuantCyan else TextPrimary
                                )
                            )
                            Text(
                                text = inst.name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${inst.currency} ${String.format(Locale.US, "%.2f", inst.price)}",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "${if (inst.changePercent >= 0) "+" else ""}${String.format(Locale.US, "%.2f", inst.changePercent)}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (inst.changePercent >= 0) FinancialBull else FinancialBear
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
