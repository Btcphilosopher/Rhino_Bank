package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun CommoditiesAndCarryView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Commodities & Forward Term Structure Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Brent Crude Prompt",
                    value = "$84.50 / bbl",
                    subValue = "Term: Backwardation ($2.4/mo)",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Gold Spot (XAU/USD)",
                    value = "$2,418.50 / oz",
                    subValue = "Real Rate Beta: -0.74",
                    accentColor = QuantAmber,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "G10 Carry Sharpe",
                    value = "1.82",
                    subValue = "Top Pair: USD/JPY (+5.0% yield)",
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Commodity Term Structure & Convenience Yields
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "COMMODITY FUTURES TERM STRUCTURE & ROLL YIELD",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantCyan
                        )
                    )
                    Text(
                        text = "Calendar Spread Dynamics, Storage Arbitrage & Convenience Yield",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val commodities = listOf(
                        Triple("Brent Crude Oil", "$84.50 (M1) → $82.10 (M6)", "Backwardation (+3.4% Roll Return)"),
                        Triple("Natural Gas (Henry Hub)", "$2.45 (M1) → $2.95 (M6)", "Contango (-18.2% Storage Drag)"),
                        Triple("Gold (COMEX)", "$2,418 (M1) → $2,442 (M6)", "Contango (Cost of Carry)"),
                        Triple("Copper (LME High Grade)", "$9,840/t (Cash) → $9,910/t (3M)", "Modest Contango (-0.7%)"),
                        Triple("Chicago Wheat", "$580/bu (Prompt) → $610/bu (Dec)", "Super-Contango (Abundant Harvest)")
                    )

                    commodities.forEach { (name, curve, regime) ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.5.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                            color = DarkSurfaceCard
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                                    Text(curve, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TextSecondary))
                                }
                                Text(
                                    regime,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (regime.contains("Backwardation")) FinancialBull else QuantAmber
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // FX & Rates Carry Trade Lab
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "FX CARRY TRADE & VOLATILITY-ADJUSTED SPREADS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )
                    Text(
                        text = "Unhedged Interest Rate Parity Deviations & Implied Vol Filters",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val carryPairs = listOf(
                        Pair("USD / JPY (Long USD, Short JPY)", "+5.10% Net Yield | Vol: 8.4% | Sharpe: 1.68"),
                        Pair("GBP / JPY (Long GBP, Short JPY)", "+4.85% Net Yield | Vol: 9.1% | Sharpe: 1.45"),
                        Pair("USD / CHF (Long USD, Short CHF)", "+3.95% Net Yield | Vol: 6.8% | Sharpe: 1.52"),
                        Pair("BRL / USD (Long BRL, Short USD)", "+6.25% Net Yield | Vol: 13.5% | Sharpe: 1.15"),
                        Pair("MXN / JPY (Long MXN, Short JPY)", "+10.45% Net Yield | Vol: 12.2% | Sharpe: 2.10")
                    )

                    carryPairs.forEach { (pair, stats) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pair, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = TextPrimary))
                            Text(
                                stats,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = QuantCyan
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
