package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OptimizationObjective
import com.example.model.PositionItem
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun PortfolioManagementView(
    state: WorkstationUiState,
    onSetOptimizationObjective: (OptimizationObjective) -> Unit,
    modifier: Modifier = Modifier
) {
    val summary = state.portfolioSummary

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Portfolio NAV and Leverage Summary
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Portfolio Net NAV",
                    value = String.format(Locale.US, "£%.2fM", summary.nav / 1000000.0),
                    subValue = "Daily: +£${String.format(Locale.US, "%.1fk", summary.dailyPnl / 1000.0)} (+${String.format(Locale.US, "%.2f", summary.dailyPnlPct)}%)",
                    delta = "Inception: +${summary.inceptionReturnPct}%",
                    isPositive = true,
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Gross / Net Exposure",
                    value = "£360.0M / £82.4M",
                    subValue = "Long: £221.2M | Short: £138.8M",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Gross Leverage",
                    value = "${String.format(Locale.US, "%.2fx", summary.grossLeverage)}",
                    subValue = "Limit: 3.50x (Max)",
                    delta = "Net: ${String.format(Locale.US, "%.2fx", summary.netLeverage)}",
                    isPositive = true,
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
            }
        }


        // Portfolio Optimization Engine Selector
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "CONVEX PORTFOLIO OPTIMIZATION ENGINE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantCyan
                        )
                    )
                    Text(
                        text = "Markowitz Quadratic Programming & Risk Parity with Factor Constraints",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OptimizationObjective.values().forEach { obj ->
                            val isSel = state.optimizationObjective == obj
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { onSetOptimizationObjective(obj) }
                                    .background(if (isSel) DarkSurfaceElevated else DarkSurfaceCard)
                                    .border(1.dp, if (isSel) QuantCyan else DarkBorderSubtle, RoundedCornerShape(6.dp))
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = obj.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSel) QuantCyan else TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sector Exposures vs Target Limits
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "SECTOR WEIGHTS & RISK LIMITS (%)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    state.sectorExposures.forEach { exp ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = exp.label,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    color = TextPrimary
                                ),
                                modifier = Modifier.width(130.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(DarkCanvas)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth((exp.percentage / 35.0f).coerceIn(0.05f, 1f))
                                        .fillMaxHeight()
                                        .background(QuantCyan)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "${String.format(Locale.US, "%.1f", exp.percentage)}% (£${exp.notionalM.toInt()}M)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextMuted
                                ),
                                modifier = Modifier.width(90.dp)
                            )
                        }
                    }
                }
            }
        }

        // Active Positions Table
        item {
            SectionHeader(
                title = "ACTIVE BOOK POSITIONS",
                subtitle = "Mark-to-Market Valuations, Weights & Unrealized P&L"
            )
        }

        items(state.positions) { pos ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                color = DarkSurfaceCard
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = pos.ticker,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = QuantCyan
                                )
                            )
                            Text(
                                text = pos.name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            )
                        }
                        Text(
                            text = "Size: ${String.format(Locale.US, "%,d", pos.quantity.toLong())} @ avg £${String.format(Locale.US, "%.2f", pos.entryPrice)} (Weight: ${pos.weightPct}%)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                color = TextSecondary
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "£${String.format(Locale.US, "%.2fM", pos.marketValue / 1000000.0)}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "${if (pos.totalUnrealizedPnl >= 0) "+" else ""}£${String.format(Locale.US, "%.1fk", pos.totalUnrealizedPnl / 1000.0)}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (pos.totalUnrealizedPnl >= 0) FinancialBull else FinancialBear
                            )
                        )
                    }
                }
            }
        }

    }
}
