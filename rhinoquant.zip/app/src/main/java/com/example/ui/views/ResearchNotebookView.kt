package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NotebookCell
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState

@Composable
fun ResearchNotebookView(
    state: WorkstationUiState,
    onExecuteCell: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "RHINOQUANT INTERACTIVE RESEARCH NOTEBOOK",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantCyan
                            )
                        )
                        Text(
                            text = "Kernel: Python 3.11 (Polars, Numba, DuckDB, JAX) • Point-in-Time Point Data Connector",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                        )
                    }

                    Button(
                        onClick = { state.notebookCells.forEach { onExecuteCell(it.id) } },
                        colors = ButtonDefaults.buttonColors(containerColor = QuantCyan, contentColor = DarkCanvas),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("RUN ALL CELLS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        items(state.notebookCells) { cell ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    // Cell Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(color = DarkSurfaceElevated, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = cell.type.name,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (cell.type == com.example.model.CellType.PYTHON) QuantCyan else QuantGold
                                    )
                                )
                            }
                            Text(
                                text = "Cell [${cell.id}]",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextMuted
                                )
                            )
                        }

                        Button(
                            onClick = { onExecuteCell(cell.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceCard,
                                contentColor = if (cell.isExecuting) QuantGold else QuantCyan
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(4.dp),
                            enabled = !cell.isExecuting
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (cell.isExecuting) Icons.Default.Refresh else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = if (cell.isExecuting) "Running..." else "Execute",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Code Editor Block
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkCanvas)
                            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                        color = DarkCanvas
                    ) {
                        Text(
                            text = cell.codeOrText,
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextPrimary
                            )
                        )
                    }


                    Spacer(modifier = Modifier.height(6.dp))

                    // Output Block
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurfaceCard),
                        color = DarkSurfaceCard
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = "OUTPUT [STDOUT / MATRIX]",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextMuted
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = cell.output,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = QuantCyan
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
