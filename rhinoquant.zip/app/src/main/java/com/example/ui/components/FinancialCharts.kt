package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CandleStickPoint
import com.example.model.OrderBookData
import com.example.ui.theme.*
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    candles: List<CandleStickPoint>,
    modifier: Modifier = Modifier,
    bullColor: Color = FinancialBull,
    bearColor: Color = FinancialBear,
    gridColor: Color = DarkBorder
) {
    if (candles.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("No Historical Candle Data", style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
        return
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val volHeight = h * 0.22f
        val priceHeight = h * 0.74f

        val minPrice = candles.minOf { it.low } * 0.998
        val maxPrice = candles.maxOf { it.high } * 1.002
        val priceRange = max(0.0001, maxPrice - minPrice)

        val maxVol = candles.maxOfOrNull { it.volume } ?: 1.0

        // Draw horizontal grid lines
        for (i in 0..4) {
            val y = priceHeight * (i / 4f)
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }
        drawLine(
            color = gridColor,
            start = Offset(0f, priceHeight + 10f),
            end = Offset(w, priceHeight + 10f),
            strokeWidth = 1f
        )

        val candleCount = candles.size
        val barWidth = max(2f, (w / candleCount) * 0.7f)
        val stepX = w / candleCount

        candles.forEachIndexed { i, c ->
            val x = (i * stepX) + (stepX / 2f)
            val isBull = c.close >= c.open
            val color = if (isBull) bullColor else bearColor

            // Price coordinates
            val highY = (priceHeight * (1f - ((c.high - minPrice) / priceRange))).toFloat()
            val lowY = (priceHeight * (1f - ((c.low - minPrice) / priceRange))).toFloat()
            val openY = (priceHeight * (1f - ((c.open - minPrice) / priceRange))).toFloat()
            val closeY = (priceHeight * (1f - ((c.close - minPrice) / priceRange))).toFloat()

            // Wick
            drawLine(
                color = color,
                start = Offset(x, highY),
                end = Offset(x, lowY),
                strokeWidth = 1.5f
            )

            // Body
            val topBody = min(openY, closeY)
            val bodyH = max(2f, kotlin.math.abs(closeY - openY))
            drawRect(
                color = color,
                topLeft = Offset(x - barWidth / 2f, topBody),
                size = Size(barWidth, bodyH)
            )

            // Volume bar at bottom
            val volRatio = (c.volume / maxVol).toFloat().coerceIn(0f, 1f)
            val vH = volRatio * volHeight
            val volTop = h - vH
            drawRect(
                color = color.copy(alpha = 0.4f),
                topLeft = Offset(x - barWidth / 2f, volTop),
                size = Size(barWidth, vH)
            )
        }
    }
}

@Composable
fun FinancialLineChart(
    points: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color = QuantCyan,
    fillGradient: Boolean = true,
    benchmarkPoints: List<Float>? = null
) {
    if (points.size < 2) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("Insufficient Data", style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
        return
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val allPoints = points + (benchmarkPoints ?: emptyList())
        val minY = (allPoints.minOrNull() ?: 0f) * 0.995f
        val maxY = (allPoints.maxOrNull() ?: 100f) * 1.005f
        val rangeY = max(0.0001f, maxY - minY)

        // Draw subtle grid
        for (i in 0..3) {
            val y = h * (i / 3f)
            drawLine(
                color = DarkBorderSubtle,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }

        // Draw Benchmark if present
        if (benchmarkPoints != null && benchmarkPoints.size > 1) {
            val benchPath = Path()
            val stepX = w / (benchmarkPoints.size - 1)
            benchmarkPoints.forEachIndexed { i, pt ->
                val x = i * stepX
                val y = h * (1f - ((pt - minY) / rangeY))
                if (i == 0) benchPath.moveTo(x, y) else benchPath.lineTo(x, y)
            }
            drawPath(
                path = benchPath,
                color = TextMuted.copy(alpha = 0.6f),
                style = Stroke(width = 1.8f, cap = StrokeCap.Round)
            )
        }

        // Draw Main Series
        val path = Path()
        val fillPath = Path()
        val stepX = w / (points.size - 1)

        points.forEachIndexed { i, pt ->
            val x = i * stepX
            val y = h * (1f - ((pt - minY) / rangeY))
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            if (i == points.size - 1) {
                fillPath.lineTo(x, h)
                fillPath.close()
            }
        }

        if (fillGradient) {
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(lineColor.copy(alpha = 0.35f), lineColor.copy(alpha = 0.0f)),
                    startY = 0f,
                    endY = h
                )
            )
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 2.4f, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun OrderBookDepthChart(
    orderBook: OrderBookData,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val halfW = w / 2f

        val maxDepth = max(
            orderBook.bids.lastOrNull()?.total ?: 1.0,
            orderBook.asks.lastOrNull()?.total ?: 1.0
        )

        // Draw Bids (Green Left)
        val bidPath = Path()
        bidPath.moveTo(halfW, h)
        orderBook.bids.forEachIndexed { i, b ->
            val xRatio = (i.toFloat() / orderBook.bids.size)
            val x = halfW - (xRatio * halfW)
            val y = h * (1f - (b.total / maxDepth).toFloat().coerceIn(0f, 1f))
            bidPath.lineTo(x, y)
        }
        bidPath.lineTo(0f, h)
        bidPath.close()

        drawPath(
            path = bidPath,
            brush = Brush.verticalGradient(
                colors = listOf(FinancialBull.copy(alpha = 0.45f), FinancialBull.copy(alpha = 0.05f))
            )
        )

        // Draw Asks (Red Right)
        val askPath = Path()
        askPath.moveTo(halfW, h)
        orderBook.asks.forEachIndexed { i, a ->
            val xRatio = (i.toFloat() / orderBook.asks.size)
            val x = halfW + (xRatio * halfW)
            val y = h * (1f - (a.total / maxDepth).toFloat().coerceIn(0f, 1f))
            askPath.lineTo(x, y)
        }
        askPath.lineTo(w, h)
        askPath.close()

        drawPath(
            path = askPath,
            brush = Brush.verticalGradient(
                colors = listOf(FinancialBear.copy(alpha = 0.45f), FinancialBear.copy(alpha = 0.05f))
            )
        )

        // Mid price divider
        drawLine(
            color = QuantCyan,
            start = Offset(halfW, 0f),
            end = Offset(halfW, h),
            strokeWidth = 1.5f
        )
    }
}

@Composable
fun YieldCurveChart(
    tenors: List<String>,
    giltYields: List<Float>,
    treasuryYields: List<Float>,
    bundYields: List<Float>,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val allYields = giltYields + treasuryYields + bundYields
        val minY = (allYields.minOrNull() ?: 2.0f) * 0.9f
        val maxY = (allYields.maxOrNull() ?: 5.0f) * 1.1f
        val rangeY = max(0.01f, maxY - minY)

        // Horizontal yield grids
        for (i in 0..4) {
            val y = h * (i / 4f)
            drawLine(color = DarkBorderSubtle, start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f)
        }

        fun drawCurve(yields: List<Float>, color: Color) {
            if (yields.size < 2) return
            val path = Path()
            val stepX = w / (yields.size - 1)
            yields.forEachIndexed { i, yVal ->
                val x = i * stepX
                val y = h * (1f - ((yVal - minY) / rangeY))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                drawCircle(color = color, radius = 3.5f, center = Offset(x, y))
            }
            drawPath(path = path, color = color, style = Stroke(width = 2.5f, cap = StrokeCap.Round))
        }

        drawCurve(treasuryYields, QuantCyan) // US
        drawCurve(giltYields, QuantGold)    // UK
        drawCurve(bundYields, QuantPurple)  // Bund
    }
}

@Composable
fun OptionPayoffChart(
    strike: Double,
    premium: Double,
    strategyType: String = "LONG_CALL",
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val midY = h / 2f

        // Zero P&L line
        drawLine(
            color = DarkBorder,
            start = Offset(0f, midY),
            end = Offset(w, midY),
            strokeWidth = 1.5f
        )

        val path = Path()
        val spotMin = strike * 0.7
        val spotMax = strike * 1.3
        val spotRange = spotMax - spotMin
        val maxPnl = strike * 0.3
        val pnlRange = maxPnl * 2.0

        for (i in 0..40) {
            val spot = spotMin + (i / 40.0) * spotRange
            val pnl = when (strategyType) {
                "LONG_CALL" -> max(0.0, spot - strike) - premium
                "LONG_PUT" -> max(0.0, strike - spot) - premium
                "BULL_CALL_SPREAD" -> {
                    val k2 = strike * 1.1
                    (max(0.0, spot - strike) - max(0.0, spot - k2)) - premium
                }
                "STRADDLE" -> (max(0.0, spot - strike) + max(0.0, strike - spot)) - (premium * 1.8)
                else -> max(0.0, spot - strike) - premium
            }

            val x = ((spot - spotMin) / spotRange).toFloat() * w
            val y = (midY - (pnl / pnlRange).toFloat() * h).coerceIn(4f, h - 4f)

            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = QuantCyan,
            style = Stroke(width = 2.5f, cap = StrokeCap.Round)
        )
    }
}
