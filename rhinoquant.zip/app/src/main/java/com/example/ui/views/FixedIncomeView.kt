package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FinancialMath
import com.example.model.FixedIncomeBond
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun FixedIncomeView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    var selectedBond by remember { mutableStateOf(state.fixedIncomeBonds.firstOrNull()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Fixed Income Rates Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "UK Gilt 10Y Benchmark",
                    value = "4.28%",
                    subValue = "Spread to Bund: +190 bps",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "US Treasury 10Y",
                    value = "4.35%",
                    subValue = "2s10s Curve: +14 bps",
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Portfolio DV01",
                    value = "£48.5k / bp",
                    subValue = "Eff Duration: 6.82y",
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Multi-Country Sovereign Yield Curves
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SOVEREIGN YIELD CURVE COMPARISON",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantCyan
                            )
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(modifier = Modifier.size(8.dp).background(QuantCyan))
                                Text("US Treasury", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextPrimary))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(modifier = Modifier.size(8.dp).background(QuantGold))
                                Text("UK Gilt", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextPrimary))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(modifier = Modifier.size(8.dp).background(QuantPurple))
                                Text("German Bund", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextPrimary))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    YieldCurveChart(
                        tenors = listOf("1M", "3M", "6M", "1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "20Y", "30Y"),
                        treasuryYields = listOf(5.25f, 5.15f, 4.95f, 4.60f, 4.25f, 4.15f, 4.22f, 4.30f, 4.35f, 4.65f, 4.70f),
                        giltYields = listOf(5.00f, 4.90f, 4.75f, 4.45f, 4.10f, 4.05f, 4.15f, 4.20f, 4.28f, 4.60f, 4.65f),
                        bundYields = listOf(3.60f, 3.45f, 3.25f, 2.95f, 2.55f, 2.45f, 2.38f, 2.40f, 2.42f, 2.65f, 2.70f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkCanvas)
                            .padding(6.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("1M", "1Y", "2Y", "5Y", "10Y", "30Y").forEach { tenor ->
                            Text(tenor, style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TextMuted))
                        }
                    }
                }
            }
        }

        // Active Bond Pricer Card
        selectedBond?.let { bond ->
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                    color = DarkSurface
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${bond.name} (${bond.isin})",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = QuantGold
                                    )
                                )
                                Text(
                                    text = "Maturity: ${bond.maturityDate} • Rating: ${bond.rating} • Type: ${bond.issuerType}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                                )
                            }

                            Text(
                                text = "Price: £${String.format(Locale.US, "%.2f", bond.cleanPrice)}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            QuantMetricCard(
                                title = "Yield to Maturity (YTM)",
                                value = "${String.format(Locale.US, "%.2f", bond.yieldToMaturityPct)}%",
                                modifier = Modifier.weight(1f)
                            )
                            QuantMetricCard(
                                title = "Mod. Duration",
                                value = "${String.format(Locale.US, "%.2f", bond.modifiedDurationYears)}y",
                                accentColor = QuantCyan,
                                modifier = Modifier.weight(1f)
                            )
                            QuantMetricCard(
                                title = "DV01 (Risk / bp)",
                                value = "£${String.format(Locale.US, "%.1f", bond.dv01)}",
                                accentColor = FinancialBull,
                                modifier = Modifier.weight(1f)
                            )
                            QuantMetricCard(
                                title = "OAS Spread",
                                value = "${bond.oasBps.toInt()} bps",
                                accentColor = QuantAmber,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Bonds Universe Table
        item {
            SectionHeader(
                title = "SOVEREIGN & CORPORATE DEBT BOOK",
                subtitle = "Click to inspect bond analytics, convexity & DV01 ladder"
            )
        }

        items(state.fixedIncomeBonds) { bond ->
            val isSelected = selectedBond?.isin == bond.isin
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { selectedBond = bond }
                    .border(1.dp, if (isSelected) QuantGold else DarkBorderSubtle, RoundedCornerShape(6.dp)),
                color = if (isSelected) DarkSurfaceElevated else DarkSurfaceCard
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(color = DarkSurface, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = bond.rating,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = QuantGold
                                    )
                                )
                            }
                            Text(
                                text = bond.name,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) QuantGold else TextPrimary
                                )
                            )
                        }
                        Text(
                            text = "${bond.couponPct}% cpn • ${bond.maturityDate} • ISIN: ${bond.isin}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "YTM: ${String.format(Locale.US, "%.2f", bond.yieldToMaturityPct)}%",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Dur: ${String.format(Locale.US, "%.1fy", bond.modifiedDurationYears)} | DV01: £${String.format(Locale.US, "%.0f", bond.dv01)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextSecondary)
                        )
                    }
                }
            }
        }

    }
}
