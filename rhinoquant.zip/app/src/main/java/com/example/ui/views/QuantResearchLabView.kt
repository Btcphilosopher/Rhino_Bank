package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FactorCategory
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun QuantResearchLabView(
    state: WorkstationUiState,
    onRunExperiment: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedLabTab by remember { mutableStateOf("FACTORS") }
    var newExperimentName by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Lab Sub-Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("FACTORS" to "Factor Lab", "ML_MODELS" to "Machine Learning Lab", "EXPERIMENTS" to "Experiment Runner", "DATASETS" to "Point-in-Time Data").forEach { (key, label) ->
                    val isSel = selectedLabTab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { selectedLabTab = key }
                            .background(if (isSel) DarkSurfaceElevated else DarkSurfaceCard)
                            .border(1.dp, if (isSel) QuantCyan else DarkBorder, RoundedCornerShape(6.dp))
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) QuantCyan else TextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Section Content based on selected lab tab
        when (selectedLabTab) {
            "FACTORS" -> {
                item {
                    SectionHeader(
                        title = "CROSS-SECTIONAL FACTOR ALPHA RESEARCH",
                        subtitle = "Information Coefficient (IC), t-stat, Decay Half-Life & Neutralized Sharpe"
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuantMetricCard(
                            title = "Top Alpha Factor",
                            value = "Momentum 12M",
                            subValue = "IC: 0.068 (t-stat: 4.82)",
                            accentColor = QuantCyan,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "Longest Half-Life",
                            value = "Operating Accruals",
                            subValue = "Half-Life: 365 Days",
                            accentColor = QuantGold,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "Max Sharpe Alpha",
                            value = "G10 FX Carry",
                            subValue = "Sharpe Contrib: 1.62",
                            accentColor = FinancialBull,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                items(state.factors) { factor ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                        color = DarkSurfaceCard
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        color = DarkSurfaceElevated,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = factor.category.label,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = QuantGold
                                            )
                                        )
                                    }
                                    Text(
                                        text = factor.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    )
                                }

                                Text(
                                    text = String.format(Locale.US, "Ann. Alpha: +%.1f%%", factor.annualizedAlphaPct),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = FinancialBull
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = factor.formulaDescription,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "IC: ${String.format(Locale.US, "%.4f", factor.icScore)} (t: ${String.format(Locale.US, "%.2f", factor.tStat)})",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = QuantCyan)
                                )
                                Text(
                                    text = "Turnover: ${factor.turnoverMonthlyPct}%/mo",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TextMuted)
                                )
                                Text(
                                    text = "Half-Life: ${factor.halfLifeDays}d",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = QuantGold)
                                )
                                Text(
                                    text = "Sharpe: ${String.format(Locale.US, "%.2f", factor.sharpeContribution)}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = FinancialBull)
                                )
                            }
                        }
                    }
                }
            }

            "ML_MODELS" -> {
                item {
                    SectionHeader(
                        title = "INSTITUTIONAL MACHINE LEARNING ENGINE",
                        subtitle = "Purged Cross-Validation, Leakage Prevention & Feature Importances"
                    )
                }

                items(state.mlModels) { model ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                        color = DarkSurface
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = model.name,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = QuantCyan
                                        )
                                    )
                                    Text(
                                        text = "${model.type.label} • Target: ${model.target}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = TextMuted)
                                    )
                                }

                                Surface(
                                    color = if (model.status == "DEPLOYED") FinancialBullDim else DarkSurfaceElevated,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = model.status,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (model.status == "DEPLOYED") FinancialBull else QuantGold
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // R2 metrics row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                QuantMetricCard(
                                    title = "Train R²",
                                    value = String.format(Locale.US, "%.3f", model.trainR2Score),
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Val R² (Purged)",
                                    value = String.format(Locale.US, "%.3f", model.valR2Score),
                                    accentColor = QuantGold,
                                    modifier = Modifier.weight(1f)
                                )
                                QuantMetricCard(
                                    title = "Test R² (OOS)",
                                    value = String.format(Locale.US, "%.3f", model.testR2Score),
                                    accentColor = FinancialBull,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "FEATURE IMPORTANCES (SHAP / GINI)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextMuted
                                )
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            model.featureImportances.forEach { (feat, importance) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = feat,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = TextSecondary
                                        ),
                                        modifier = Modifier.width(130.dp)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(DarkCanvas)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth(importance.coerceIn(0f, 1f))
                                                .fillMaxHeight()
                                                .background(QuantCyan)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = String.format(Locale.US, "%.1f%%", importance * 100f),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = TextPrimary
                                        ),
                                        modifier = Modifier.width(40.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            "EXPERIMENTS" -> {
                item {
                    SectionHeader(
                        title = "QUANTITATIVE EXPERIMENT TRACKER",
                        subtitle = "Walk-Forward Out-of-Sample Performance & Alpha Validation"
                    )
                }

                // New Experiment input bar
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                        color = DarkSurfaceElevated
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newExperimentName,
                                onValueChange = { newExperimentName = it },
                                modifier = Modifier.weight(1f),
                                placeholder = {
                                    Text("New Experiment name (e.g., GARCH Vol Arb v5)...", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = QuantCyan,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )

                            Button(
                                onClick = {
                                    val name = if (newExperimentName.isBlank()) "Alpha Boost Exp v${System.currentTimeMillis() % 100}" else newExperimentName
                                    onRunExperiment(name)
                                    newExperimentName = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = QuantCyan, contentColor = DarkCanvas),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Text("LAUNCH", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }

                items(state.experiments) { exp ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                        color = DarkSurfaceCard
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (exp.status == "COMPLETED") FinancialBull else QuantAmber)
                                    )
                                    Text(
                                        text = exp.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    )
                                }

                                Surface(
                                    color = if (exp.status == "COMPLETED") FinancialBullDim else DarkSurfaceElevated,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = exp.status,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (exp.status == "COMPLETED") FinancialBull else QuantAmber
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Dataset: ${exp.datasetName} • Model: ${exp.modelType} • Method: ${exp.validationMethod}",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = String.format(Locale.US, "Sharpe: %.2f", exp.sharpe),
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = QuantCyan)
                                )
                                Text(
                                    text = String.format(Locale.US, "Max DD: -%.1f%%", exp.maxDrawdownPct),
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = FinancialBear)
                                )
                                Text(
                                    text = String.format(Locale.US, "Win Rate: %.1f%%", exp.winRatePct),
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = FinancialBull)
                                )
                            }
                        }
                    }
                }
            }

            "DATASETS" -> {
                item {
                    SectionHeader(
                        title = "POINT-IN-TIME QUANTITATIVE DATASETS",
                        subtitle = "CRSP, Compustat PIT, Nanosecond ITCH L3 and Rates Surfaces"
                    )
                }

                items(state.datasets) { ds ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                        color = DarkSurfaceCard
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ds.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = QuantCyan
                                    )
                                )
                                Text(
                                    text = ds.format,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        color = QuantGold
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = "Coverage: ${ds.assetCoverage} • Period: ${ds.dateRange}",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = TextSecondary)
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Frequency: ${ds.frequency}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted)
                                )
                                Text(
                                    text = "Size: ${String.format(Locale.US, "%.1f MB", ds.sizeMb)}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted)
                                )
                                Text(
                                    text = "Rows: ${String.format(Locale.US, "%,d", ds.rowCount)}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TextPrimary)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
