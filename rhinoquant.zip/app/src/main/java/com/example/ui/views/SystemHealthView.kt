package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState

@Composable
fun SystemHealthView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // System Health Overview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Cluster Status",
                    value = "ALL OPERATIONAL",
                    subValue = "Uptime: 99.999% (42d 18h)",
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Ring Buffer Drops",
                    value = "0 (0.000%)",
                    subValue = "Lock-free SPSC Queues",
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Engine Latency",
                    value = "0.82 µs",
                    subValue = "p99.9: 4.15 µs",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Microservices Grid
        item {
            SectionHeader(
                title = "RHINOQUANT CORE MICROSERVICES & INFRASTRUCTURE",
                subtitle = "Hot-Standby Dual Redundancy Across Equinix LD4 & NY4"
            )
        }

        val services = listOf(
            Triple("RhinoHFT Engine", "FPGA Feed Parser & Order Router", "PRIMARY (LD4) • 8.9µs p99 • 0 drops"),
            Triple("RhinoRisk Grid", "Monte Carlo & Parametric VaR Daemon", "ACTIVE • GPU Cluster (4x H100) • 12ms"),
            Triple("RhinoData Lakehouse", "DuckDB / Parquet Real-Time Lake", "SYNCED • 1.48M rec/s ingested"),
            Triple("RhinoOMS Gateway", "Institutional FIX 4.4 & OUCH Connectors", "CONNECTED • LSE, NYSE, CME, Eurex"),
            Triple("RhinoPricing Analytics", "PDE & Black-Scholes Solver", "ONLINE • SIMD AVX-512 Optimized"),
            Triple("RhinoTreasury ALM", "Basel III LCR / NSFR Monitoring", "NORMAL • Regulatory Compliance Active")
        )

        items(services) { service ->
            val name = service.first
            val role = service.second
            val telemetry = service.third
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp)),
                color = DarkSurfaceCard
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(FinancialBull)
                        )
                        Column {
                            Text(
                                text = name,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = role,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            )
                        }
                    }

                    Text(
                        text = telemetry,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = QuantCyan
                        )
                    )
                }
            }
        }
    }
}
