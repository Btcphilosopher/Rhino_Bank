package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Instrument
import com.example.model.WorkstationTab
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun MainWorkstationView(
    state: WorkstationUiState,
    onSelectInstrument: (String) -> Unit,
    onSelectTab: (WorkstationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Institutional KPI Overview Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Portfolio NAV",
                    value = "£148.50M",
                    subValue = "Gross Lev: 2.42x",
                    delta = "+£842.3k (+0.57%)",
                    isPositive = true,
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "1-Day 95% VaR",
                    value = "£2.41M",
                    subValue = "Limit: £2.50M (96%)",
                    delta = "ES: £4.12M",
                    isPositive = true,
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Alpha Sharpe",
                    value = "2.41",
                    subValue = "Sortino: 3.12",
                    delta = "Win: 64.2%",
                    isPositive = true,
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Multi-Panel Workspace: Watchlist + Main Analytics Chart + L2 Order Book
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    // Selected Instrument Header
                    val selected = state.selectedInstrument ?: state.instruments.first()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = selected.ticker,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = QuantCyan
                                )
                            )
                            Text(
                                text = selected.name,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                            Surface(color = DarkSurfaceElevated, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = selected.assetClass.badge,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = QuantGold
                                    )
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "${selected.currency} ${String.format(Locale.US, "%.2f", selected.price)}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "${if (selected.changePercent >= 0) "+" else ""}${String.format(Locale.US, "%.2f", selected.changePercent)}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected.changePercent >= 0) FinancialBull else FinancialBear
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Candlestick Chart
                    CandlestickChart(
                        candles = selected.priceHistory,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkCanvas)
                            .padding(6.dp)
                    )
                }
            }
        }

        // Multi-Asset Watchlist Bar
        item {
            SectionHeader(
                title = "MULTI-ASSET WORKSPACE TICKER TAPE",
                subtitle = "Equities • Sovereign Debt • FX • Commodities • Crypto",
                actionLabel = "OPEN TERMINAL",
                onAction = { onSelectTab(WorkstationTab.MARKETS) }
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(state.instruments) { inst ->
                    val isSelected = state.selectedInstrument?.ticker == inst.ticker
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onSelectInstrument(inst.ticker) }
                            .border(
                                1.dp,
                                if (isSelected) QuantCyan else DarkBorderSubtle,
                                RoundedCornerShape(6.dp)
                            ),
                        color = if (isSelected) DarkSurfaceElevated else DarkSurfaceCard
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = inst.ticker,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) QuantCyan else TextPrimary
                                    )
                                )
                                Text(
                                    text = inst.assetClass.badge,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        color = TextMuted
                                    )
                                )
                            }
                            Text(
                                text = "${inst.currency} ${String.format(Locale.US, "%.2f", inst.price)}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "${if (inst.changePercent >= 0) "+" else ""}${String.format(Locale.US, "%.2f", inst.changePercent)}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (inst.changePercent >= 0) FinancialBull else FinancialBear
                                )
                            )
                        }
                    }
                }
            }
        }

        // Split Panel: L2 Order Book & Quick Navigation Desks
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Order Book
                OrderBookComponent(
                    orderBook = state.orderBook,
                    recentTrades = state.recentTrades,
                    modifier = Modifier.weight(1f)
                )

                // Quantitative Quick Desks
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                    color = DarkSurface
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "INSTITUTIONAL DESKS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantGold
                            )
                        )

                        val quickLinks = listOf(
                            Triple("Quant Research Lab", "Factors & Walk-Forward ML", WorkstationTab.QUANT_LAB),
                            Triple("Risk & Stress Testing", "Parametric VaR & GFC Replay", WorkstationTab.RISK_TERMINAL),
                            Triple("Fixed Income & Curves", "Gilt & Treasury OAS/DV01", WorkstationTab.FIXED_INCOME),
                            Triple("Investment Banking", "IPO & DCM Pricing Waterfall", WorkstationTab.BANKING),
                            Triple("HFT Engine Telemetry", "1.48M msg/s (8.9µs p99)", WorkstationTab.HFT_MONITOR),
                            Triple("Research Notebook", "Python / DuckDB SQL Cells", WorkstationTab.NOTEBOOK)
                        )

                        quickLinks.forEach { (title, subtitle, tab) ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable { onSelectTab(tab) }
                                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(4.dp)),
                                color = DarkSurfaceCard
                            ) {
                                Row(
                                    modifier = Modifier.padding(6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = title,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                color = TextPrimary
                                            )
                                        )
                                        Text(
                                            text = subtitle,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 9.sp,
                                                color = TextMuted
                                            )
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        tint = QuantCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
