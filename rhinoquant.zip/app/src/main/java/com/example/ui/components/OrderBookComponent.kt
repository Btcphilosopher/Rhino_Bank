package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketTrade
import com.example.model.OrderBookData
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun OrderBookComponent(
    orderBook: OrderBookData?,
    recentTrades: List<MarketTrade>,
    modifier: Modifier = Modifier
) {
    if (orderBook == null) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("Awaiting L2 Order Flow...", style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
        return
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurface)
            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "L2 ORDER BOOK",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = QuantCyan)
            )
            Text(
                text = String.format(Locale.US, "Spread: %.4f (%.1f bps)", orderBook.spread, orderBook.spreadBps),
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = TextSecondary)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table headers
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("SIZE (LOTS)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted), modifier = Modifier.weight(1f))
            Text("BID", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = FinancialBull), modifier = Modifier.weight(1f))
            Text("ASK", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = FinancialBear), modifier = Modifier.weight(1f))
            Text("SIZE (LOTS)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted), modifier = Modifier.weight(1f))
        }

        HorizontalDivider(color = DarkBorderSubtle, thickness = 1.dp)

        val rowCount = minOf(orderBook.bids.size, orderBook.asks.size)
        val maxVol = maxOf(orderBook.bids.maxOfOrNull { it.size } ?: 1.0, orderBook.asks.maxOfOrNull { it.size } ?: 1.0)

        for (i in 0 until rowCount) {
            val bid = orderBook.bids[i]
            val ask = orderBook.asks[i]

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 1.5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bid Size with bar
                Box(modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((bid.size / maxVol).toFloat().coerceIn(0.05f, 1f))
                            .height(14.dp)
                            .background(FinancialBullDim.copy(alpha = 0.5f))
                    )
                    Text(
                        text = String.format(Locale.US, "%.1f", bid.size),
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TextSecondary),
                        modifier = Modifier.padding(start = 2.dp)
                    )
                }

                // Bid Price
                Text(
                    text = String.format(Locale.US, "%.2f", bid.price),
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = FinancialBull),
                    modifier = Modifier.weight(1f)
                )

                // Ask Price
                Text(
                    text = String.format(Locale.US, "%.2f", ask.price),
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = FinancialBear),
                    modifier = Modifier.weight(1f)
                )

                // Ask Size with bar
                Box(modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((ask.size / maxVol).toFloat().coerceIn(0.05f, 1f))
                            .height(14.dp)
                            .background(FinancialBearDim.copy(alpha = 0.5f))
                    )
                    Text(
                        text = String.format(Locale.US, "%.1f", ask.size),
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TextSecondary),
                        modifier = Modifier.padding(start = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        HorizontalDivider(color = DarkBorderSubtle, thickness = 1.dp)

        // Recent Trades Tape Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("RECENT TRADES TAPE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextSecondary))
            Text("ITCH/OUCH FEED", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = QuantCyan))
        }

        recentTrades.take(4).forEach { tr ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 1.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(tr.timeFormatted, style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TextMuted))
                Text(
                    String.format(Locale.US, "%.2f", tr.price),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (tr.isBuy) FinancialBull else FinancialBear
                    )
                )
                Text(
                    String.format(Locale.US, "%.0f lots", tr.size),
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TextSecondary)
                )
            }
        }
    }
}
