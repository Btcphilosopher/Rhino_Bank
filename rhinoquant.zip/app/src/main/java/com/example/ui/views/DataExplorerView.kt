package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState

@Composable
fun DataExplorerView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    var queryText by remember {
        mutableStateOf(
            """
            SELECT ticker, asset_class, avg(price) as avg_price,
                   stddev(change_pct) as realized_vol, count(*) as trade_ticks
            FROM rhino_tick_l3
            WHERE timestamp >= NOW() - INTERVAL '1 hour'
            GROUP BY ticker, asset_class
            ORDER BY trade_ticks DESC LIMIT 10;
            """.trimIndent()
        )
    }

    var selectedTable by remember { mutableStateOf("rhino_tick_l3") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // SQL Query Editor
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DUCKDB / SQL LAKEHOUSE QUERY ENGINE",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantCyan
                            )
                        )

                        Button(
                            onClick = { /* execute query */ },
                            colors = ButtonDefaults.buttonColors(containerColor = QuantCyan, contentColor = DarkCanvas),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("EXECUTE (F5)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = queryText,
                        onValueChange = { queryText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = TextPrimary
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = QuantCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedContainerColor = DarkCanvas,
                            unfocusedContainerColor = DarkCanvas
                        )
                    )
                }
            }
        }

        // Schema Explorer & Table Selector
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "AVAILABLE LAKEHOUSE TABLES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val tables = listOf(
                        "rhino_tick_l3" to "Nanosecond L3 ITCH Market Feeds (14.2M rows)",
                        "factor_scores_pit" to "Point-in-Time Factor Cross-Section (1.8M rows)",
                        "sovereign_yields_daily" to "Global Yield Curves & Tenor Spreads (420k rows)",
                        "corporate_bonds_dcm" to "Institutional DCM Pricing & Bookbuilding (85k rows)"
                    )

                    tables.forEach { (tbl, desc) ->
                        val isSel = selectedTable == tbl
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { selectedTable = tbl }
                                .border(1.dp, if (isSel) QuantCyan else DarkBorderSubtle, RoundedCornerShape(4.dp)),
                            color = if (isSel) DarkSurfaceElevated else DarkSurfaceCard
                        ) {
                            Row(
                                modifier = Modifier.padding(6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = tbl,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) QuantCyan else TextPrimary
                                    )
                                )
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        color = TextMuted
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Tabular Query Result View
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "QUERY RESULT (0.014s • 6 rows)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = FinancialBull
                            )
                        )
                        Text(
                            text = "FORMAT: APACHE ARROW",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TextMuted)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val scrollState = rememberScrollState()
                    Row(modifier = Modifier.horizontalScroll(scrollState)) {
                        Column {
                            // Table Header
                            Row(
                                modifier = Modifier.background(DarkSurfaceElevated).padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf("TICKER", "ASSET_CLASS", "AVG_PRICE", "REALIZED_VOL", "TRADE_TICKS").forEach { col ->
                                    Text(
                                        text = col,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = QuantCyan
                                        ),
                                        modifier = Modifier.width(90.dp).padding(horizontal = 4.dp)
                                    )
                                }
                            }

                            val rows = listOf(
                                listOf("AAPL", "EQUITY", "$228.45", "18.2%", "284,102"),
                                listOf("NVDA", "EQUITY", "$124.80", "42.1%", "412,980"),
                                listOf("UK-10Y", "RATES", "£98.40", "6.2%", "148,220"),
                                listOf("BRENT", "COMMODITY", "$84.50", "24.5%", "98,400"),
                                listOf("GBPUSD", "FX", "$1.3120", "8.1%", "320,110"),
                                listOf("BTC-USD", "CRYPTO", "$64,200", "58.4%", "512,040")
                            )

                            rows.forEach { r ->
                                Row(modifier = Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                    r.forEach { cell ->
                                        Text(
                                            text = cell,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = TextPrimary
                                            ),
                                            modifier = Modifier.width(90.dp).padding(horizontal = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
