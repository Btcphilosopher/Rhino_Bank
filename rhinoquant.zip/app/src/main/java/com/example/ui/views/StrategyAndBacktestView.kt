package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun StrategyAndBacktestView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    val result = state.backtestResult
    var isRunningBacktest by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Top Backtest Action Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = result.strategyName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantCyan
                            )
                        )
                        Text(
                            text = "Period: ${result.period} • Universe: S&P 500 / FTSE 100 • Slippage: 2.5 bps",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                        )
                    }

                    Button(
                        onClick = { isRunningBacktest = true },
                        colors = ButtonDefaults.buttonColors(containerColor = QuantCyan, contentColor = DarkCanvas),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("RUN BACKTEST", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Institutional Backtest Key Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Annualized Return",
                    value = String.format(Locale.US, "+%.1f%%", result.annualizedReturnPct),
                    subValue = "Cum: +${String.format(Locale.US, "%.1f%%", result.totalReturnPct)}",
                    delta = "Vol: ${result.volatilityPct}%",
                    isPositive = true,
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Sharpe Ratio",
                    value = String.format(Locale.US, "%.2f", result.sharpeRatio),
                    subValue = "Sortino: ${String.format(Locale.US, "%.2f", result.sortinoRatio)}",
                    delta = "Calmar: ${result.calmarRatio}",
                    isPositive = true,
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Max Drawdown",
                    value = String.format(Locale.US, "-%.1f%%", result.maxDrawdownPct),
                    subValue = "NAV: £${String.format(Locale.US, "%.1fM", result.finalNav / 1000000.0)}",
                    delta = "Win: ${result.winRatePct}%",
                    isPositive = true,
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Secondary Metrics (Profit Factor, Win Rate, Trades, Turnover)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Profit Factor",
                    value = String.format(Locale.US, "%.2f", result.profitFactor),
                    subValue = "Win Rate: ${result.winRatePct}%",
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Final Portfolio NAV",
                    value = String.format(Locale.US, "£%.2fM", result.finalNav / 1000000.0),
                    subValue = "Init: £${String.format(Locale.US, "%.0fM", result.initialCapital / 1000000.0)}",
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Monthly Turnover",
                    value = "${result.turnoverPct}%",
                    subValue = "Costs: £142.5k",
                    modifier = Modifier.weight(1f)
                )
            }
        }


        // Cumulative Equity Curve vs Benchmark
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CUMULATIVE PERFORMANCE VS BENCHMARK (MSCI WORLD)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = QuantCyan
                            )
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(modifier = Modifier.size(8.dp).background(QuantCyan))
                                Text("Rhino Alpha Strategy", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextPrimary))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(modifier = Modifier.size(8.dp).background(TextMuted))
                                Text("Benchmark (MSCI)", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    FinancialLineChart(
                        points = result.equityCurve,
                        benchmarkPoints = result.benchmarkCurve,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkCanvas)
                            .padding(6.dp)
                    )
                }
            }
        }

        // Monthly Returns Table Heatmap
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "MONTHLY RETURNS MATRIX (%)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "YTD")
                    val matrixData = listOf(
                        "2023" to listOf(2.4, 1.1, -0.8, 3.2, 0.9, 2.1, -1.2, 1.8, 0.4, -0.6, 3.8, 2.9, 16.8),
                        "2024" to listOf(1.8, 2.9, 3.4, -1.1, 2.0, 1.5, 0.8, -0.4, 1.9, 2.2, 1.6, 2.4, 20.4),
                        "2025" to listOf(3.1, -0.5, 2.8, 1.9, 3.2, 2.4, -0.9, 1.5, 3.0, 1.2, 2.7, 3.1, 25.8),
                        "2026" to listOf(2.1, 1.9, 0.8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.8)
                    )

                    val scrollState = rememberScrollState()
                    Row(modifier = Modifier.horizontalScroll(scrollState)) {
                        Column {
                            // Header Row
                            Row {
                                Text("YEAR", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted), modifier = Modifier.width(44.dp))
                                months.forEach { m ->
                                    Text(m, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted), modifier = Modifier.width(36.dp))
                                }
                            }
                            HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 4.dp))

                            matrixData.forEach { (year, returns) ->
                                Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(year, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextPrimary), modifier = Modifier.width(44.dp))
                                    returns.forEachIndexed { idx, ret ->
                                        val isYtd = idx == returns.size - 1
                                        val isZero = ret == 0.0 && year == "2026" && idx >= 3
                                        val color = when {
                                            isZero -> TextMuted
                                            ret >= 0 -> FinancialBull
                                            else -> FinancialBear
                                        }
                                        Text(
                                            text = if (isZero) "-" else String.format(Locale.US, "%.1f", ret),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = if (isYtd) FontWeight.Bold else FontWeight.Normal,
                                                color = color
                                            ),
                                            modifier = Modifier.width(36.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
