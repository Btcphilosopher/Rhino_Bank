package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun HftMonitorView(
    state: WorkstationUiState,
    modifier: Modifier = Modifier
) {
    val hft = state.hftTelemetry

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // HFT Status & Microstructure Header
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(FinancialBull)
                        )
                        Column {
                            Text(
                                text = "RHINOQUANT HFT ENGINE TELEMETRY",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = QuantCyan
                                )
                            )
                            Text(
                                text = "Colocation: Equinix LD4 (Slough) & NY4 (Secaucus) • Solarflare EF_VI Kernel-Bypass",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                            )
                        }
                    }

                    Surface(
                        color = FinancialBullDim,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "ACTIVE ROUTING",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = FinancialBull
                            )
                        )
                    }
                }
            }
        }

        // Live Throughput Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Market Feed Rate",
                    value = String.format(Locale.US, "%,d msg/s", hft.messagesPerSec),
                    subValue = "ITCH / FAST Feeds",
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Order Placement Rate",
                    value = String.format(Locale.US, "%,d orders/s", hft.ordersPerSec),
                    subValue = "Cancel/Replace: ${hft.cancelRatioPct}%",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Fill Execution Rate",
                    value = String.format(Locale.US, "%,d fills/s", hft.fillsPerSec),
                    subValue = "Fill Ratio: 28.1%",
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Latency Percentile Ladder
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "TICK-TO-TRADE LATENCY PERCENTILES (HARDWARE TIMESTAMPED)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantCyan
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val latencies: List<Pair<String, Double>> = listOf(
                        "Market Data Parse (p50)" to hft.mdLatencyP50Us,
                        "Strategy Compute (p50)" to hft.strategyLatencyP50Us,
                        "Pre-Trade Risk Check (p50)" to hft.riskLatencyP50Us,
                        "End-to-End Tick-to-Trade (p99)" to hft.endToEndP99Us,
                        "Tail Latency (p99.9)" to (hft.endToEndP99Us * 1.65)
                    )

                    latencies.forEach { pair ->
                        val label = pair.first
                        val lat = pair.second
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                ),
                                modifier = Modifier.width(180.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(DarkCanvas)
                            ) {
                                val ratio = (lat / 20.0).toFloat().coerceIn(0.05f, 1f)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(ratio)
                                        .fillMaxHeight()
                                        .background(if (lat < 8.0) QuantCyan else QuantGold)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = String.format(Locale.US, "%.2f µs", lat),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                ),
                                modifier = Modifier.width(55.dp)
                            )
                        }
                    }
                }
            }
        }

        // PnL & Adverse Selection Breakdown
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "Gross Strategy P&L",
                    value = String.format(Locale.US, "£%.1fk", hft.grossPnl / 1000.0),
                    subValue = "Spread Capture",
                    isPositive = true,
                    accentColor = FinancialBull,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Maker Rebates / Fees",
                    value = String.format(Locale.US, "-£%.1fk", hft.feesPaid / 1000.0),
                    subValue = "Exchange Fees",
                    accentColor = QuantAmber,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Net Trading P&L",
                    value = String.format(Locale.US, "£%.1fk", hft.netPnl / 1000.0),
                    subValue = "Adv. Select: ${hft.adverseSelectionBps} bps",
                    isPositive = true,
                    accentColor = QuantCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }


        // Hardware Cores & Network Interconnects Table
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "CORE & FPGA ACCELERATION PIPELINES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val pipelines = listOf(
                        Triple("Xilinx Alveo U50 FPGA", "Feed Parser & BBO Extraction", "0.28 µs wire-to-mem"),
                        Triple("Solarflare X2522 NIC", "EF_VI User-space bypass", "0.45 µs rx/tx"),
                        Triple("AMD EPYC 9654 Core #04", "Limit Order Book Maintainer", "Pinned 4.8 GHz"),
                        Triple("AMD EPYC 9654 Core #08", "Alpha Prediction & Risk Filter", "AVX-512 SIMD"),
                        Triple("AMD EPYC 9654 Core #12", "OUCH Order Encoder", "Pre-warmed TCP buffer")
                    )

                    pipelines.forEach { (hw, role, status) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(hw, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = TextPrimary))
                                Text(role, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted))
                            }
                            Text(
                                status,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = QuantCyan)
                            )
                        }
                    }
                }
            }
        }
    }
}
