package com.example.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StressScenario
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.WorkstationUiState
import java.util.Locale

@Composable
fun RiskTerminalView(
    state: WorkstationUiState,
    onSelectScenario: (StressScenario) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedScenario = state.selectedStressScenario ?: state.stressScenarios.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCanvas)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Value at Risk & Capital Adequacy Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuantMetricCard(
                    title = "1D 95% Parametric VaR",
                    value = "£2.41M",
                    subValue = "Limit: £2.50M (96.4%)",
                    accentColor = QuantGold,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "10D 99% Hist. VaR",
                    value = "£5.85M",
                    subValue = "Basel III Mandated",
                    accentColor = QuantAmber,
                    modifier = Modifier.weight(1f)
                )
                QuantMetricCard(
                    title = "Expected Shortfall (CVaR)",
                    value = "£4.12M",
                    subValue = "Tail Loss Beyond VaR",
                    accentColor = FinancialBear,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Stress-Testing Scenario Selection
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "HISTORICAL & HYPOTHETICAL STRESS-TESTING LAB",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantCyan
                        )
                    )
                    Text(
                        text = "Replay extreme market dislocations through RhinoRisk full-revaluation engine",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = TextMuted)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Scenario Cards
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.stressScenarios.forEach { sc ->
                            val isSel = selectedScenario.id == sc.id
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { onSelectScenario(sc) }
                                    .border(1.dp, if (isSel) QuantCyan else DarkBorderSubtle, RoundedCornerShape(6.dp)),
                                color = if (isSel) DarkSurfaceElevated else DarkSurfaceCard
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = sc.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSel) QuantCyan else TextPrimary
                                            )
                                        )
                                        Text(
                                            text = sc.description,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontSize = 10.sp,
                                                color = TextSecondary
                                            )
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "-£${String.format(Locale.US, "%.1fM", sc.estimatedLossM)}",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace,
                                                color = FinancialBear
                                            )
                                        )
                                        Text(
                                            text = "${sc.estimatedNavImpactPct}% of NAV",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 9.sp,
                                                color = TextMuted
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Scenario Shock Decomposition
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "SCENARIO MACRO SHOCK VECTOR: ${selectedScenario.name.uppercase()}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantGold
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuantMetricCard(
                            title = "Equities Shock",
                            value = "${selectedScenario.equityShockPct}%",
                            accentColor = FinancialBear,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "Rates Shock",
                            value = "${if (selectedScenario.ratesShockBps >= 0) "+" else ""}${selectedScenario.ratesShockBps.toInt()} bps",
                            accentColor = QuantGold,
                            modifier = Modifier.weight(1f)
                        )
                        QuantMetricCard(
                            title = "VIX / Vol Shock",
                            value = "+${selectedScenario.volShockPct}%",
                            accentColor = QuantPurple,
                            modifier = Modifier.weight(1f)
                        )
                    }


                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Post-Shock Capital Adequacy: CET1 Ratio remains at 14.2% (Regulatory minimum 10.5%)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = FinancialBull,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }

        // Risk Factor Beta Sensitivities
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                color = DarkSurface
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "PORTFOLIO FACTOR SENSITIVITY DECOMPOSITION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = QuantCyan
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val sensitivities = listOf(
                        "Market Beta (MSCI World)" to "0.42 (Low Market Dependence)",
                        "Rates Sensitivity (DV01)" to "£48.5k per 1 bps move",
                        "FX Exposure (GBP/USD)" to "-£125k per 1% USD rally",
                        "Energy Shock Beta" to "+0.18 (Modest Long Commodity)",
                        "Tech / Momentum Crowding" to "0.22 (Diversified Alpha)"
                    )

                    sensitivities.forEach { (factor, desc) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(factor, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                            Text(
                                desc,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = QuantCyan
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
