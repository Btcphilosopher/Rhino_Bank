package com.example.data

import com.example.model.OptionGreeks
import kotlin.math.*

object FinancialMath {

    // Standard Normal Cumulative Distribution Function (CDF) approximation
    fun normalCdf(x: Double): Double {
        val a1 = 0.254829592
        val a2 = -0.284496736
        val a3 = 1.421413741
        val a4 = -1.453152027
        val a5 = 1.061405429
        val p = 0.3275911

        val sign = if (x < 0) -1.0 else 1.0
        val absX = abs(x) / sqrt(2.0)

        val t = 1.0 / (1.0 + p * absX)
        val erf = 1.0 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t) * exp(-absX * absX)

        return 0.5 * (1.0 + sign * erf)
    }

    // Standard Normal Probability Density Function (PDF)
    fun normalPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    // Black-Scholes Pricing & Exact Greeks
    fun calculateBlackScholes(
        spotPrice: Double,
        strikePrice: Double,
        riskFreeRate: Double = 0.045, // 4.5% US / UK SOFR / SONIA
        volatility: Double, // e.g. 0.22 (22%)
        daysToExpiry: Int,
        ticker: String = "AAPL"
    ): OptionGreeks {
        val t = max(1.0 / 365.0, daysToExpiry / 365.0)
        val sigma = max(0.01, volatility)
        val s = max(0.01, spotPrice)
        val k = max(0.01, strikePrice)
        val r = riskFreeRate

        val d1 = (ln(s / k) + (r + 0.5 * sigma * sigma) * t) / (sigma * sqrt(t))
        val d2 = d1 - sigma * sqrt(t)

        val nd1 = normalCdf(d1)
        val nd2 = normalCdf(d2)
        val n_minus_d1 = normalCdf(-d1)
        val n_minus_d2 = normalCdf(-d2)
        val npdf_d1 = normalPdf(d1)

        val callPrice = s * nd1 - k * exp(-r * t) * nd2
        val putPrice = k * exp(-r * t) * n_minus_d2 - s * n_minus_d1

        val deltaCall = nd1
        val gamma = npdf_d1 / (s * sigma * sqrt(t))
        val vega = s * npdf_d1 * sqrt(t) / 100.0 // per 1% vol shift
        val thetaCall = (-(s * npdf_d1 * sigma) / (2 * sqrt(t)) - r * k * exp(-r * t) * nd2) / 365.0 // per day
        val rhoCall = (k * t * exp(-r * t) * nd2) / 100.0 // per 1% rate shift

        return OptionGreeks(
            underlyingTicker = ticker,
            strikePrice = k,
            spotPrice = s,
            daysToExpiry = daysToExpiry,
            impliedVolPct = sigma * 100.0,
            callPrice = max(0.01, callPrice),
            putPrice = max(0.01, putPrice),
            delta = deltaCall,
            gamma = gamma,
            thetaPerDay = thetaCall,
            vegaPer1Pct = vega,
            rhoPer1Pct = rhoCall
        )
    }

    // Historical / Parametric VaR calculation (1-day & 10-day, 95% & 99%)
    fun calculateVaR(portfolioNav: Double, dailyVolPct: Double, confidence: Double = 0.95): Double {
        val z = if (confidence >= 0.99) 2.326 else 1.645
        return portfolioNav * (dailyVolPct / 100.0) * z
    }

    // Expected Shortfall / CVaR (Conditional VaR)
    fun calculateExpectedShortfall(portfolioNav: Double, dailyVolPct: Double, confidence: Double = 0.99): Double {
        val z = if (confidence >= 0.99) 2.326 else 1.645
        val esFactor = (normalPdf(z) / (1.0 - confidence))
        return portfolioNav * (dailyVolPct / 100.0) * esFactor
    }

    // Bond Pricing and Duration
    fun calculateBondMetrics(
        faceValue: Double = 100.0,
        couponRatePct: Double,
        yieldToMaturityPct: Double,
        maturityYears: Int,
        couponFrequency: Int = 2
    ): Triple<Double, Double, Double> { // Price, Modified Duration, DV01
        val y = yieldToMaturityPct / 100.0 / couponFrequency
        val c = (faceValue * (couponRatePct / 100.0)) / couponFrequency
        val n = maturityYears * couponFrequency

        var price = 0.0
        var macDuration = 0.0

        for (t in 1..n) {
            val cf = if (t == n) c + faceValue else c
            val pv = cf / (1.0 + y).pow(t.toDouble())
            price += pv
            macDuration += (t.toDouble() / couponFrequency) * pv
        }

        macDuration /= price
        val modDuration = macDuration / (1.0 + y)
        val dv01 = (price * modDuration * 0.0001)

        return Triple(price, modDuration, dv01)
    }

    // Sharpe & Sortino Ratios
    fun calculateSharpeRatio(returns: List<Double>, riskFreeDaily: Double = 0.00012): Double {
        if (returns.isEmpty()) return 0.0
        val excessReturns = returns.map { it - riskFreeDaily }
        val mean = excessReturns.average()
        val variance = excessReturns.map { (it - mean).pow(2.0) }.average()
        val stdDev = sqrt(variance)
        if (stdDev == 0.0) return 0.0
        return (mean / stdDev) * sqrt(252.0)
    }
}
