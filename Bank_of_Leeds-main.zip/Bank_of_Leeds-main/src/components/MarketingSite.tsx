import React, { useState } from "react";
import { 
  Building2, 
  ArrowRight, 
  ShieldCheck, 
  Coins, 
  Compass, 
  TrendingUp, 
  ChevronRight, 
  MapPin, 
  Layers, 
  Award,
  BookOpen,
  Anchor
} from "lucide-react";

interface MarketingSiteProps {
  onOpenPortal: (mode: "personal" | "business" | "wealth") => void;
}

export default function MarketingSite({ onOpenPortal }: MarketingSiteProps) {
  // Calculator states
  const [initialDeposit, setInitialDeposit] = useState<number>(10000);
  const [monthlySavings, setMonthlySavings] = useState<number>(500);
  const [investmentYears, setInvestmentYears] = useState<number>(10);
  const interestRate = 5.25; // 5.25% AER

  // Calculate savings values
  const calculateSavings = () => {
    const r = interestRate / 100 / 12;
    const n = investmentYears * 12;
    let total = initialDeposit;
    let totalDeposited = initialDeposit;

    for (let i = 0; i < n; i++) {
      total = (total + monthlySavings) * (1 + r);
      totalDeposited += monthlySavings;
    }

    const totalInterest = total - totalDeposited;
    return {
      total: Math.round(total),
      deposited: Math.round(totalDeposited),
      interest: Math.round(totalInterest),
    };
  };

  const results = calculateSavings();

  // Selected landmark for Yorkshire virtual tour
  const [selectedLandmark, setSelectedLandmark] = useState<number>(0);

  const landmarks = [
    {
      id: 0,
      name: "Wellington Place, Leeds",
      type: "Central Headquarters & Private Boardrooms",
      desc: "Our architectural masterpiece stands in Wellington Place. Fusing modern glass, brushed stainless steel, and native Yorkshire stone, it serves as the physical home of our executive leadership, commercial credit syndicates, and private client boardrooms.",
      stats: "70,000 sq ft • Low Carbon • York Stone Façade",
      coordinates: "53.7959° N, 1.5547° W",
    },
    {
      id: 1,
      name: "Granary Wharf, Leeds",
      type: "Treasury Strategy & Wealth Suite",
      desc: "Overlooking the historic canal basins and brick arcades, our Treasury Strategy group at Granary Wharf manages liquidity, Sterling reserve sweeps, and the Leeds Heritage Portfolio indices. A bridge between York's industrial shipping legacy and the modern global capital currents.",
      stats: "Capital desk • FX Operations • Sovereign ISA advisory",
      coordinates: "53.7925° N, 1.5478° W",
    },
    {
      id: 2,
      name: "Leeds Civic District & Town Hall",
      type: "Institutional Banking & Civic Pride",
      desc: "Representing our connection to Leeds' municipal roots. Built upon the wool, linen, and steel mills of the 19th century, we fund modern public infrastructure, carbon-neutral council grids, and primary agricultural expansions throughout North Yorkshire.",
      stats: "Municipal Debt • Green Corridors • Yorkshire Pride",
      coordinates: "53.8011° N, 1.5484° W",
    }
  ];

  return (
    <div className="bg-[#0a0a1a] text-[#f5f2ed] selection:bg-brass-accent selection:text-[#0a0a1a]">
      
      {/* 1. Cinematic Hero Section */}
      <section className="relative min-h-[92vh] flex flex-col justify-between px-6 py-12 md:px-16 md:py-20 border-b border-[#f5f2ed]/10 bg-[#0a0a1a] text-[#f5f2ed] overflow-hidden">
        {/* Subtle Architectural Grid Overlay */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="w-full h-full" style={{
            backgroundImage: `linear-gradient(to right, #f5f2ed 1px, transparent 1px), linear-gradient(to bottom, #f5f2ed 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }} />
        </div>
        
        {/* Subtle Warm Sunrise Ambient Glow */}
        <div className="absolute -bottom-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-t from-brass-accent/10 to-transparent blur-[120px] rounded-full pointer-events-none" />

        {/* Top bar info */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 z-10 font-sans border-b border-[#f5f2ed]/10 pb-6">
          <div>
            <span className="text-[#f5f2ed]/80 tracking-[0.25em] text-xs uppercase font-mono">Leeds Financial District</span>
            <span className="mx-3 text-[#f5f2ed]/30 font-serif">/</span>
            <span className="text-brass-accent text-xs font-mono">Wellington Place Headquarters</span>
          </div>
          <div className="text-brass-accent text-xs font-mono">
            EST. 2026 • AUTHORISED BY THE PRA
          </div>
        </div>

        {/* Hero Copy */}
        <div className="my-16 md:my-20 max-w-4xl z-10">
          <div className="inline-flex items-center gap-2 border border-brass-accent/30 bg-brass-accent/5 px-3 py-1.5 rounded-full mb-8">
            <span className="w-2 h-2 bg-brass-accent rounded-full animate-pulse" />
            <span className="text-brass-accent font-mono text-[10px] tracking-widest uppercase">The Sovereign Gilt Yields Activated</span>
          </div>
          
          <h1 className="font-serif text-5xl sm:text-7xl md:text-8xl font-light tracking-tight leading-[1.05] text-[#f5f2ed] mb-8">
            BANKING<br />
            FOR A<br />
            <span className="text-brass-accent italic font-serif font-light">MODERN BRITAIN.</span>
          </h1>

          <p className="font-sans text-[#f5f2ed]/80 text-lg sm:text-xl font-light leading-relaxed max-w-2xl mb-12">
            A new British financial institution built with Yorkshire confidence, engineering precision and timeless design. Headquartered in Leeds, serving individuals, businesses, and industry across the United Kingdom.
          </p>

          <div className="flex flex-wrap gap-4 sm:gap-6">
            <button 
              onClick={() => onOpenPortal("personal")}
              className="bg-brass-accent hover:bg-[#bf9e73] text-[#0a0a1a] font-bold px-8 py-4 rounded-sm transition-all duration-200 cursor-pointer flex items-center gap-2 group tracking-wide font-sans shadow-xl"
            >
              Access Digital Portal
              <ArrowRight size={16} className="transform group-hover:translate-x-1 transition-transform" />
            </button>
            <button 
              onClick={() => {
                const calcSection = document.getElementById("gilt-calculator");
                calcSection?.scrollIntoView({ behavior: "smooth" });
              }}
              className="border border-[#f5f2ed]/15 hover:border-[#f5f2ed]/45 bg-[#f5f2ed]/5 text-[#f5f2ed] px-8 py-4 rounded-sm transition-all duration-200 cursor-pointer font-sans"
            >
              Explore Growth Yields
            </button>
          </div>
        </div>

        {/* Bottom Metadata Indicators */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-8 border-t border-[#f5f2ed]/10 z-10">
          <div>
            <div className="text-[10px] uppercase tracking-widest font-mono text-[#f5f2ed]/40 mb-1">Tier-1 Equity Ratio</div>
            <div className="font-serif text-2xl text-[#f5f2ed] font-light">18.4% <span className="text-[11px] font-sans text-brass-accent font-normal">Super-Stable</span></div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-widest font-mono text-[#f5f2ed]/40 mb-1">Headquarters</div>
            <div className="font-serif text-2xl text-[#f5f2ed] font-light">Leeds, UK</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-widest font-mono text-[#f5f2ed]/40 mb-1">Sovereign Reserves</div>
            <div className="font-serif text-2xl text-[#f5f2ed] font-light">£4.2 Billion</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-widest font-mono text-[#f5f2ed]/40 mb-1">AER Growth Caps</div>
            <div className="font-serif text-2xl text-[#f5f2ed] font-light">5.25% AER</div>
          </div>
        </div>
      </section>

      {/* 2. Core Pillars of Yorkshire Supermodernism */}
      <section className="py-24 px-6 md:px-16 border-b border-[#f5f2ed]/10 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          
          {/* Header left Column */}
          <div className="lg:col-span-1 space-y-6">
            <span className="text-brass-accent font-mono text-xs tracking-widest uppercase block">Our Philosophy</span>
            <h2 className="font-serif text-4xl sm:text-5xl font-light tracking-tight text-[#f5f2ed] leading-tight">
              A Permanent Institution. Built for a Century.
            </h2>
            <p className="text-[#f5f2ed]/70 font-sans font-light leading-relaxed">
              We reject the ephemeral trends of corporate fintech and the rigid inertia of High Street conglomerates. Fusing monumental Yorkshire heritage with Swiss editorial utility and precision engineering, we represent a permanent standard of British capital.
            </p>
            <div className="pt-4">
              <div className="flex items-center gap-3 py-3 border-y border-[#f5f2ed]/10">
                <Award size={18} className="text-brass-accent" />
                <span className="font-mono text-xs tracking-wider uppercase text-[#f5f2ed]/80">Winner: UK Design Guild Mark 2026</span>
              </div>
            </div>
          </div>

          {/* Cards right Columns */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-8 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 bg-[#f5f2ed]/10 text-brass-accent flex items-center justify-center rounded-sm mb-6 border border-[#f5f2ed]/10">
                <Compass size={20} />
              </div>
              <h3 className="font-serif text-xl font-medium text-[#f5f2ed] mb-3">Architectural Precision</h3>
              <p className="text-sm text-[#f5f2ed]/60 leading-relaxed font-light">
                Every screen, ledger line, and transaction flow is designed on a rigorous mathematical grid. Intuitive controls optimized for high-capacity treasury or legacy portfolio tracking.
              </p>
            </div>

            <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-8 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 bg-[#f5f2ed]/10 text-brass-accent flex items-center justify-center rounded-sm mb-6 border border-[#f5f2ed]/10">
                <ShieldCheck size={20} />
              </div>
              <h3 className="font-serif text-xl font-medium text-[#f5f2ed] mb-3">Yorkshire Gilt Reserves</h3>
              <p className="text-sm text-[#f5f2ed]/60 leading-relaxed font-light">
                Underwritten by physical sterling gilts and modern Yorkshire real-estate assets. Capital structure optimized for long-term endurance and generational wealth storage.
              </p>
            </div>

            <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-8 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 bg-[#f5f2ed]/10 text-brass-accent flex items-center justify-center rounded-sm mb-6 border border-[#f5f2ed]/10">
                <Coins size={20} />
              </div>
              <h3 className="font-serif text-xl font-medium text-[#f5f2ed] mb-3">Commercial Confidence</h3>
              <p className="text-sm text-[#f5f2ed]/60 leading-relaxed font-light">
                Providing founders, municipal authorities, and SME directors with multi-user sweep lines, integrated cash flow projections, and international trade finance guarantees.
              </p>
            </div>

            <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-8 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 bg-[#f5f2ed]/10 text-brass-accent flex items-center justify-center rounded-sm mb-6 border border-[#f5f2ed]/10">
                <TrendingUp size={20} />
              </div>
              <h3 className="font-serif text-xl font-medium text-[#f5f2ed] mb-3">The Wellington Advisory</h3>
              <p className="text-sm text-[#f5f2ed]/60 leading-relaxed font-light">
                Instant secure access to advanced, AI-assisted strategic allocation and treasury guidance. Designed with premium British financial intelligence and regional commercial insight.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* 3. Core Services Exploration */}
      <section className="py-24 bg-[#0a0a1a] text-[#f5f2ed] px-6 md:px-16 border-b border-[#f5f2ed]/10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-[#f5f2ed]/10 pb-8">
            <div>
              <span className="text-brass-accent font-mono text-xs tracking-widest uppercase block mb-2">Comprehensive Capabilities</span>
              <h2 className="font-serif text-4xl sm:text-5xl font-light tracking-tight">Structured Merchant Banking</h2>
            </div>
            <p className="text-[#f5f2ed]/60 font-sans font-light max-w-md mt-4 md:mt-0">
              Personal, Business, Wealth and Institutional products designed with quiet wealth standards. Fusing Yorkshire’s real economy with 21st-century digital velocity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            
            {/* Service 1 */}
            <div className="border border-[#f5f2ed]/10 p-8 flex flex-col justify-between h-[360px] hover:border-brass-accent/50 transition-colors bg-[#f5f2ed]/5">
              <div>
                <span className="text-[#f5f2ed]/40 font-mono text-xs uppercase block mb-6">01 / Personal</span>
                <h3 className="font-serif text-2xl font-light tracking-tight mb-4 text-[#f5f2ed]">Sovereign Portfolios</h3>
                <ul className="text-xs text-[#f5f2ed]/60 space-y-2 font-sans font-light">
                  <li>• Current and Sovereign Savings</li>
                  <li>• Yorkshire Property Mortgages</li>
                  <li>• Personal Premium Cards</li>
                  <li>• Sterling Foreign Exchanges</li>
                  <li>• Financial Planning Sweeps</li>
                </ul>
              </div>
              <button 
                onClick={() => onOpenPortal("personal")}
                className="inline-flex items-center gap-1 text-brass-accent text-xs font-mono tracking-wider uppercase group hover:text-[#f5f2ed] transition-colors cursor-pointer"
              >
                Access personal 
                <ChevronRight size={14} className="transform group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Service 2 */}
            <div className="border border-[#f5f2ed]/10 p-8 flex flex-col justify-between h-[360px] hover:border-brass-accent/50 transition-colors bg-[#f5f2ed]/5">
              <div>
                <span className="text-[#f5f2ed]/40 font-mono text-xs uppercase block mb-6">02 / Business</span>
                <h3 className="font-serif text-2xl font-light tracking-tight mb-4 text-[#f5f2ed]">Enterprise Portal</h3>
                <ul className="text-xs text-[#f5f2ed]/60 space-y-2 font-sans font-light">
                  <li>• Commercial Current Accounts</li>
                  <li>• Bulk Payroll Automations</li>
                  <li>• Multi-user Credential Tiers</li>
                  <li>• Trade & Invoice Financing</li>
                  <li>• Treasury Reserve Desks</li>
                </ul>
              </div>
              <button 
                onClick={() => onOpenPortal("business")}
                className="inline-flex items-center gap-1 text-brass-accent text-xs font-mono tracking-wider uppercase group hover:text-[#f5f2ed] transition-colors cursor-pointer"
              >
                Access business 
                <ChevronRight size={14} className="transform group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Service 3 */}
            <div className="border border-[#f5f2ed]/10 p-8 flex flex-col justify-between h-[360px] hover:border-brass-accent/50 transition-colors bg-[#f5f2ed]/5">
              <div>
                <span className="text-[#f5f2ed]/40 font-mono text-xs uppercase block mb-6">03 / Wealth</span>
                <h3 className="font-serif text-2xl font-light tracking-tight mb-4 text-[#f5f2ed]">Heritage Advisory</h3>
                <ul className="text-xs text-[#f5f2ed]/60 space-y-2 font-sans font-light">
                  <li>• Discretionary Portfolios</li>
                  <li>• Generational Inheritance Wrappers</li>
                  <li>• Land and Real-Estate Gilt Shields</li>
                  <li>• Tax-Shielded ISAs</li>
                  <li>• Family Office Desk</li>
                </ul>
              </div>
              <button 
                onClick={() => onOpenPortal("wealth")}
                className="inline-flex items-center gap-1 text-brass-accent text-xs font-mono tracking-wider uppercase group hover:text-[#f5f2ed] transition-colors cursor-pointer"
              >
                Access wealth 
                <ChevronRight size={14} className="transform group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Service 4 */}
            <div className="border border-[#f5f2ed]/10 p-8 flex flex-col justify-between h-[360px] hover:border-brass-accent/50 transition-colors bg-[#f5f2ed]/5">
              <div>
                <span className="text-[#f5f2ed]/40 font-mono text-xs uppercase block mb-6">04 / Corporate</span>
                <h3 className="font-serif text-2xl font-light tracking-tight mb-4 text-[#f5f2ed]">Civic & Industrial</h3>
                <ul className="text-xs text-[#f5f2ed]/60 space-y-2 font-sans font-light">
                  <li>• Infrastructure Corridors</li>
                  <li>• Renewable Grid Finance</li>
                  <li>• Manufacturing Credit Facilities</li>
                  <li>• Export Trade Guarantees</li>
                  <li>• Public Sector Liquidity</li>
                </ul>
              </div>
              <div className="text-[#f5f2ed]/40 text-[10px] font-mono tracking-wider uppercase">
                Institutional Access Only
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4. Interactive Savings Growth / Yield Calculator */}
      <section id="gilt-calculator" className="py-24 px-6 md:px-16 border-b border-[#f5f2ed]/10 bg-[#0a0a1a]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Controls left col */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <span className="text-brass-accent font-mono text-xs tracking-widest uppercase block mb-2">Yield Projections</span>
              <h2 className="font-serif text-4xl sm:text-5xl font-light tracking-tight text-[#f5f2ed] leading-tight">
                Granite Compound Growth Calculator
              </h2>
              <p className="text-[#f5f2ed]/70 text-sm font-sans font-light leading-relaxed mt-4">
                Calculate the compounding strength of our flagship <span className="font-medium text-[#f5f2ed]">Granite Saver Account (5.25% AER)</span>. Built on structural reserve buffers, yielding premium growth for serious capital reserves.
              </p>
            </div>

            {/* Sliders Container */}
            <div className="space-y-6 bg-[#f5f2ed]/5 p-6 border border-[#f5f2ed]/10 shadow-xl rounded-sm">
              
              {/* Slider 1 */}
              <div>
                <div className="flex justify-between text-xs font-mono mb-2">
                  <span className="text-[#f5f2ed]/60 uppercase">Initial Deposit</span>
                  <span className="text-brass-accent font-semibold">£{initialDeposit.toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="5000" 
                  max="250000" 
                  step="5000"
                  value={initialDeposit}
                  onChange={(e) => setInitialDeposit(Number(e.target.value))}
                  className="w-full accent-brass-accent bg-[#0a0a1a] h-1 rounded-sm cursor-pointer border border-[#f5f2ed]/10"
                />
                <div className="flex justify-between text-[10px] text-[#f5f2ed]/40 font-mono mt-1">
                  <span>£5,000</span>
                  <span>£250,000</span>
                </div>
              </div>

              {/* Slider 2 */}
              <div>
                <div className="flex justify-between text-xs font-mono mb-2">
                  <span className="text-[#f5f2ed]/60 uppercase">Monthly Savings Sweep</span>
                  <span className="text-brass-accent font-semibold">£{monthlySavings.toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="100" 
                  max="10000" 
                  step="100"
                  value={monthlySavings}
                  onChange={(e) => setMonthlySavings(Number(e.target.value))}
                  className="w-full accent-brass-accent bg-[#0a0a1a] h-1 rounded-sm cursor-pointer border border-[#f5f2ed]/10"
                />
                <div className="flex justify-between text-[10px] text-[#f5f2ed]/40 font-mono mt-1">
                  <span>£100</span>
                  <span>£10,000</span>
                </div>
              </div>

              {/* Slider 3 */}
              <div>
                <div className="flex justify-between text-xs font-mono mb-2">
                  <span className="text-[#f5f2ed]/60 uppercase">Investment Horizon</span>
                  <span className="text-brass-accent font-semibold">{investmentYears} Years</span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="30" 
                  step="1"
                  value={investmentYears}
                  onChange={(e) => setInvestmentYears(Number(e.target.value))}
                  className="w-full accent-brass-accent bg-[#0a0a1a] h-1 rounded-sm cursor-pointer border border-[#f5f2ed]/10"
                />
                <div className="flex justify-between text-[10px] text-[#f5f2ed]/40 font-mono mt-1">
                  <span>1 Year</span>
                  <span>30 Years</span>
                </div>
              </div>

              <div className="p-3 bg-brass-accent/10 border border-brass-accent/20 text-[#f5f2ed] text-xs font-mono flex items-center justify-between rounded-sm">
                <span>COMPOUND ANNUAL RATE</span>
                <span className="text-brass-accent font-semibold">{interestRate}% AER</span>
              </div>

            </div>
          </div>

          {/* Visualization right col */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-[#0a0a1a] text-[#f5f2ed] p-8 border border-[#f5f2ed]/15 rounded-sm space-y-8 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 font-mono text-[9px] text-[#f5f2ed]/30 tracking-widest">
                LEEDS-YIELD ENGINE v4.1
              </div>

              <div>
                <span className="text-brass-accent font-mono text-[10px] uppercase tracking-widest">Compounded Projection</span>
                <h3 className="font-serif text-5xl font-light text-stone-primary mt-2">
                  £{results.total.toLocaleString()}
                </h3>
                <p className="text-[#f5f2ed]/60 text-xs font-sans font-light mt-1">
                  Net estimated balance at maturity in North Yorkshire Trust holdings.
                </p>
              </div>

              {/* Precise SVG Bar Visualization */}
              <div className="h-60 flex items-end gap-2 border-b border-[#f5f2ed]/10 pb-2 relative">
                {/* Horizontal reference gridlines */}
                <div className="absolute inset-0 flex flex-col justify-between pointer-events-none text-[#f5f2ed]/40 text-[10px] font-mono">
                  <div className="border-b border-[#f5f2ed]/5 w-full pt-1"><span>{`£${Math.round(results.total).toLocaleString()}`}</span></div>
                  <div className="border-b border-[#f5f2ed]/5 w-full"><span>{`£${Math.round(results.total * 0.66).toLocaleString()}`}</span></div>
                  <div className="border-b border-[#f5f2ed]/5 w-full"><span>{`£${Math.round(results.total * 0.33).toLocaleString()}`}</span></div>
                </div>

                {/* Bars representing progression */}
                {Array.from({ length: 8 }).map((_, index) => {
                  const fraction = (index + 1) / 8;
                  const currentYears = Math.round(investmentYears * fraction);
                  
                  // Compound interest calculation for this specific step bar
                  const r = interestRate / 100 / 12;
                  const n = currentYears * 12;
                  let stepTotal = initialDeposit;
                  let stepDeposited = initialDeposit;
                  for (let i = 0; i < n; i++) {
                    stepTotal = (stepTotal + monthlySavings) * (1 + r);
                    stepDeposited += monthlySavings;
                  }
                  
                  const stepInterest = Math.max(0, stepTotal - stepDeposited);
                  const totalHeightPct = (stepTotal / results.total) * 90; // scale to fit
                  const depositHeightPct = (stepDeposited / stepTotal) * totalHeightPct;
                  const interestHeightPct = totalHeightPct - depositHeightPct;

                  return (
                    <div key={index} className="flex-1 flex flex-col justify-end items-center group relative z-10 h-full">
                      
                      {/* Tooltip */}
                      <div className="absolute bottom-full mb-2 bg-[#0a0a1a] border border-[#f5f2ed]/20 p-2.5 rounded text-[11px] font-mono text-[#f5f2ed] opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none shadow-xl z-30 w-32 text-center">
                        <div className="text-[#f5f2ed]/50">Year {currentYears}</div>
                        <div className="font-semibold text-white">£{Math.round(stepTotal).toLocaleString()}</div>
                        <div className="text-[9px] text-brass-accent mt-0.5">Int: £{Math.round(stepInterest).toLocaleString()}</div>
                      </div>

                      {/* Interest Portion */}
                      <div 
                        style={{ height: `${interestHeightPct}%` }} 
                        className="w-full bg-brass-accent hover:opacity-90 transition-all duration-300"
                        title={`Interest: £${Math.round(stepInterest).toLocaleString()}`}
                      />

                      {/* Principal Portion */}
                      <div 
                        style={{ height: `${depositHeightPct}%` }} 
                        className="w-full bg-[#f5f2ed]/10 border-t border-[#f5f2ed]/20 hover:bg-[#f5f2ed]/20 transition-all duration-300"
                        title={`Deposited: £${Math.round(stepDeposited).toLocaleString()}`}
                      />

                      <div className="text-[10px] font-mono text-[#f5f2ed]/40 mt-2">
                        Yr {currentYears}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Legend & Breakdown indicators */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2 font-mono text-xs text-[#f5f2ed]">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-[#f5f2ed]/10 border border-[#f5f2ed]/20" />
                  <div>
                    <div className="text-[#f5f2ed]/40 text-[10px]">TOTAL DEPOSITED</div>
                    <div className="text-[#f5f2ed] text-sm font-semibold">£{results.deposited.toLocaleString()}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-brass-accent" />
                  <div>
                    <div className="text-brass-accent text-[10px]">INTEREST EARNED</div>
                    <div className="text-[#f5f2ed] text-sm font-semibold">£{results.interest.toLocaleString()}</div>
                  </div>
                </div>
                <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-2.5 rounded-sm flex flex-col justify-center">
                  <span className="text-[#f5f2ed]/40 text-[9px] uppercase">Compound Power</span>
                  <span className="text-white text-xs font-semibold">+{Math.round((results.interest / results.deposited) * 100)}% Gilt Multiplier</span>
                </div>
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* 5. Yorkshire Virtual Tour / Map District */}
      <section className="py-24 px-6 md:px-16 border-b border-[#f5f2ed]/10 bg-[#0a0a1a]">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-16">
            <span className="text-brass-accent font-mono text-xs tracking-widest uppercase block mb-2">Yorkshire Foundations</span>
            <h2 className="font-serif text-4xl sm:text-5xl font-light tracking-tight text-[#f5f2ed] leading-tight">
              Leeds Financial District & Corporate Grid
            </h2>
            <p className="text-[#f5f2ed]/70 font-sans font-light leading-relaxed mt-4">
              We operate exclusively within key physical structures of modern Leeds. An architectural grid that connects native Yorkshire heritage with contemporary European merchant flow. Click on our districts below to inspect our operational coordinates.
            </p>
          </div>

          {/* Landmarks layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Left Pillar list selector */}
            <div className="lg:col-span-4 space-y-3">
              {landmarks.map((mark) => (
                <button
                  key={mark.id}
                  onClick={() => setSelectedLandmark(mark.id)}
                  className={`w-full text-left p-6 border transition-all duration-200 rounded-sm cursor-pointer block ${
                    selectedLandmark === mark.id 
                      ? "border-brass-accent bg-[#f5f2ed]/10 shadow-xl" 
                      : "border-[#f5f2ed]/10 hover:border-brass-accent/40 bg-[#f5f2ed]/5"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                     <span className="text-[10px] font-mono tracking-widest text-[#f5f2ed]/40 uppercase">LOCATION 0{mark.id + 1}</span>
                     <MapPin size={12} className={selectedLandmark === mark.id ? "text-brass-accent" : "text-[#f5f2ed]/20"} />
                  </div>
                  <h4 className={`font-serif text-lg font-medium transition-colors ${selectedLandmark === mark.id ? "text-[#f5f2ed]" : "text-[#f5f2ed]/80"}`}>
                    {mark.name}
                  </h4>
                  <p className="text-xs text-[#f5f2ed]/50 font-sans font-light mt-1 truncate">{mark.type}</p>
                </button>
              ))}
            </div>

            {/* Right Display detail panel */}
            <div className="lg:col-span-8 bg-[#f5f2ed]/5 border border-[#f5f2ed]/15 p-8 md:p-12 rounded-sm relative overflow-hidden flex flex-col justify-between min-h-[420px] shadow-2xl">
              
              {/* Subtle visual grid motif */}
              <div className="absolute top-0 right-0 w-64 h-64 border-l border-b border-[#f5f2ed]/5 opacity-40 pointer-events-none" style={{
                backgroundImage: 'radial-gradient(circle, #a68966 1.5px, transparent 1.5px)',
                backgroundSize: '16px 16px'
              }} />

              {/* Top coordinates tag */}
              <div className="flex justify-between items-center border-b border-[#f5f2ed]/10 pb-6">
                <div>
                  <span className="font-mono text-[10px] text-[#f5f2ed]/40 block uppercase">Operational Coordinates</span>
                  <span className="font-mono text-xs text-brass-accent font-semibold">{landmarks[selectedLandmark].coordinates}</span>
                </div>
                <div className="bg-brass-accent/10 border border-brass-accent/30 text-brass-accent font-mono text-[10px] px-3 py-1 uppercase tracking-wider">
                  Secure Site
                </div>
              </div>

              {/* Landmark details */}
              <div className="my-8 space-y-6">
                <span className="text-[11px] font-mono tracking-widest text-brass-accent uppercase block">{landmarks[selectedLandmark].type}</span>
                <h3 className="font-serif text-3xl md:text-4xl text-[#f5f2ed] font-light tracking-tight">
                  {landmarks[selectedLandmark].name}
                </h3>
                <p className="text-[#f5f2ed]/70 text-sm md:text-base font-sans font-light leading-relaxed max-w-2xl">
                  {landmarks[selectedLandmark].desc}
                </p>
              </div>

              {/* Footer specs tag */}
              <div className="pt-6 border-t border-[#f5f2ed]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="text-xs font-mono text-[#f5f2ed]/50">
                  <span className="uppercase block text-[9px] text-[#f5f2ed]/40">Specifications Desk</span>
                  <span className="text-[#f5f2ed]/80 font-medium">{landmarks[selectedLandmark].stats}</span>
                </div>
                <button 
                  onClick={() => onOpenPortal("personal")}
                  className="bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] font-sans text-xs uppercase tracking-widest px-5 py-3 rounded-sm transition-colors cursor-pointer flex items-center gap-1 font-bold shadow-xl"
                >
                  Schedule Private Visit
                  <ArrowRight size={12} className="text-[#0a0a1a]" />
                </button>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* 6. Professional Credentials Section */}
      <section className="py-24 bg-[#0a0a1a] px-6 md:px-16 border-b border-[#f5f2ed]/10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 font-sans">
          <div className="space-y-4">
            <h4 className="font-serif text-xl font-medium text-[#f5f2ed]">PRA & FCA Regulatory Shield</h4>
            <p className="text-xs text-[#f5f2ed]/60 leading-relaxed font-light">
              Bank of Leeds is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Registered Office: 1 Wellington Place, Leeds, LS1 4AP. Registered in England & Wales under No. 870496.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="font-serif text-xl font-medium text-[#f5f2ed]">FSCS Deposit Protection</h4>
            <p className="text-xs text-[#f5f2ed]/60 leading-relaxed font-light">
              Your eligible deposits with the Bank of Leeds are protected up to a total of <span className="font-semibold text-[#f5f2ed]">£85,000</span> by the Financial Services Compensation Scheme (FSCS), the UK's deposit protection guarantee. For joint accounts, the protection extends up to £170,000.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="font-serif text-xl font-medium text-[#f5f2ed]">Enterprise Cybersecurity Grid</h4>
            <p className="text-xs text-[#f5f2ed]/60 leading-relaxed font-light">
              All electronic communications, sweep sweeps, and credential ledger sweeps are hardened under AES-256 GCM cryptographic parameters. Guided under secure, institutional fraud algorithms overseen by our Wellington Treasury desks.
            </p>
          </div>
        </div>
      </section>

      {/* 7. Footer */}
      <footer className="bg-[#0a0a1a] text-[#f5f2ed]/60 py-16 px-6 md:px-16 border-t border-[#f5f2ed]/10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-12 border-b border-[#f5f2ed]/10 pb-12">
          
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-serif text-xl font-semibold tracking-widest text-[#f5f2ed]">BANK OF LEEDS</span>
            </div>
            <p className="text-xs text-[#f5f2ed]/40 max-w-sm font-sans font-light">
              Built on Trust. Designed for Tomorrow. Serving individuals, businesses and industry across the United Kingdom.
            </p>
            <div className="text-[10px] font-mono text-[#f5f2ed]/30 tracking-wider">
              AUTHORISATION PRN: 870496 • REGISTRATION No: 087049612
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-8">
            <div className="space-y-3">
              <span className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase tracking-widest block">PERSONAL</span>
              <ul className="text-xs space-y-2 font-sans font-light">
                <li><a onClick={() => onOpenPortal("personal")} className="hover:text-brass-accent cursor-pointer transition-colors">Sovereign Accounts</a></li>
                <li><a onClick={() => onOpenPortal("personal")} className="hover:text-brass-accent cursor-pointer transition-colors">Obsidian Credit Cards</a></li>
                <li><a onClick={() => onOpenPortal("personal")} className="hover:text-brass-accent cursor-pointer transition-colors">Yorkshire Mortgages</a></li>
              </ul>
            </div>
            <div className="space-y-3">
              <span className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase tracking-widest block">BUSINESS</span>
              <ul className="text-xs space-y-2 font-sans font-light">
                <li><a onClick={() => onOpenPortal("business")} className="hover:text-brass-accent cursor-pointer transition-colors">Enterprise Checking</a></li>
                <li><a onClick={() => onOpenPortal("business")} className="hover:text-brass-accent cursor-pointer transition-colors">Invoice Sweep</a></li>
                <li><a onClick={() => onOpenPortal("business")} className="hover:text-brass-accent cursor-pointer transition-colors">Treasury Reserve</a></li>
              </ul>
            </div>
            <div className="space-y-3 col-span-2 sm:col-span-1">
              <span className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase tracking-widest block">WEALTH</span>
              <ul className="text-xs space-y-2 font-sans font-light">
                <li><a onClick={() => onOpenPortal("wealth")} className="hover:text-brass-accent cursor-pointer transition-colors">Heritage ISA Portfolio</a></li>
                <li><a onClick={() => onOpenPortal("wealth")} className="hover:text-brass-accent cursor-pointer transition-colors">Estate & Family Trust</a></li>
                <li><a onClick={() => onOpenPortal("wealth")} className="hover:text-brass-accent cursor-pointer transition-colors">Wellington Private Office</a></li>
              </ul>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-[#f5f2ed]/30">
          <div>
            © {new Date().getFullYear()} Bank of Leeds plc. All rights reserved.
          </div>
          <div className="flex gap-4">
            <span className="hover:text-[#f5f2ed]/60 cursor-pointer">Security Ledger</span>
            <span>•</span>
            <span className="hover:text-[#f5f2ed]/60 cursor-pointer">PRA Shield Conditions</span>
            <span>•</span>
            <span className="hover:text-[#f5f2ed]/60 cursor-pointer">Modern British Banking Code</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
