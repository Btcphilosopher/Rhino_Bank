import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, Sparkles, X, ChevronRight, CornerDownRight } from "lucide-react";
import { ChatMessage } from "../types";

interface AdvisoryChatProps {
  onClose?: () => void;
}

export default function AdvisoryChat({ onClose }: AdvisoryChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init",
      sender: "advisor",
      content: "Welcome to The Wellington Suite Advisory. I am your strategic wealth and treasury advisor. How may I assist you with your business holdings, Sovereign Accounts, or Yorkshire investment legacy today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      sender: "user",
      content: inputValue,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.content,
          history: messages.map((m) => ({
            role: m.sender === "user" ? "user" : "model",
            content: m.content,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error("Advisory offline");
      }

      const data = await response.json();
      
      const advisorMsg: ChatMessage = {
        id: Math.random().toString(),
        sender: "advisor",
        content: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      
      setMessages((prev) => [...prev, advisorMsg]);
    } catch (err) {
      console.warn("Using simulated advisor due to local environment limits.");
      // Gorgeous, high-fidelity local simulation if API is missing or offline
      setTimeout(() => {
        const query = userMsg.content.toLowerCase();
        let reply = "";

        if (query.includes("mortgage") || query.includes("house") || query.includes("property")) {
          reply = `Our Private Lending Board offers bespoke Yorkshire Property Mortgages tailored to prime estates. Currently, we structure loans starting at £750,000 against premier residential holdings in Ilkley, North Yorkshire, and Granary Wharf commercial assets. Let me arrange a direct consultation with the Lending Director at Wellington Place.`;
        } else if (query.includes("saving") || query.includes("interest") || query.includes("isa")) {
          reply = `The Bank of Leeds Heritage Portfolio provides tax-efficient ISA Wrappers and our flagship Granite Fixed-Term Account yielding up to 5.25% AER on structured £100,000+ deposits. This program is backed by the commercial resilience of modern Leeds.`;
        } else if (query.includes("business") || query.includes("merchant") || query.includes("payroll")) {
          reply = `Our Enterprise Portal integrates cash-flow projections and multi-user credential sweeps. For automated payroll and commercial credit sweeps, we configure tailored Sterling lines of credit linked directly with your treasury assets.`;
        } else if (query.includes("investment") || query.includes("wealth") || query.includes("portfolio")) {
          reply = `The Leeds Heritage Asset Allocation currently indexes major commercial infrastructure corridors and green energy initiatives across the North of England, coupled with sovereign sterling gilt shields. We target a balanced 7.4% net yield.`;
        } else {
          reply = `As your strategic partner at Bank of Leeds, I have noted your inquiry regarding "${userMsg.content}". Whether you wish to explore commercial trade lines, Sovereign savings sweeps, or private wealth portfolios, we ensure absolute precision. Would you like me to outline our structured terms for these options?`;
        }

        const advisorMsg: ChatMessage = {
          id: Math.random().toString(),
          sender: "advisor",
          content: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, advisorMsg]);
      }, 1000);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a1a] text-[#f5f2ed] border-l border-[#f5f2ed]/10 shadow-2xl font-sans">
      {/* Header */}
      <div className="p-4 border-b border-[#f5f2ed]/10 flex items-center justify-between bg-[#0a0a1a]">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 bg-brass-accent rounded-full animate-pulse" />
          <div>
            <h4 className="font-serif text-sm tracking-widest text-[#f5f2ed] uppercase font-semibold">The Wellington Suite</h4>
            <p className="text-[10px] text-[#f5f2ed]/50 uppercase tracking-wider font-mono">Private Advisory System</p>
          </div>
        </div>
        {onClose && (
          <button 
            onClick={onClose}
            className="text-[#f5f2ed]/40 hover:text-[#f5f2ed] transition-colors duration-150 p-1 rounded hover:bg-[#f5f2ed]/5"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex flex-col max-w-[85%] ${msg.sender === "user" ? "ml-auto items-end" : "mr-auto items-start"}`}
          >
            <div className={`p-3 rounded-lg text-sm leading-relaxed ${
              msg.sender === "user" 
                ? "bg-brass-accent text-zinc-950 font-semibold rounded-br-none" 
                : "bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 text-[#f5f2ed] rounded-bl-none"
            }`}>
              {msg.sender === "advisor" && (
                <div className="flex items-center gap-1.5 text-[10px] uppercase font-mono tracking-widest text-brass-accent mb-1.5">
                  <Sparkles size={10} />
                  <span>Leeds Advisor</span>
                </div>
              )}
              <p className="font-light">{msg.content}</p>
            </div>
            <span className="text-[9px] text-[#f5f2ed]/40 font-mono mt-1.5 px-1">
              {msg.timestamp}
            </span>
          </div>
        ))}
        {isLoading && (
          <div className="mr-auto items-start max-w-[85%]">
            <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-3 rounded-lg text-sm text-[#f5f2ed] rounded-bl-none">
              <div className="flex items-center gap-1.5 text-[10px] uppercase font-mono tracking-widest text-brass-accent mb-1.5">
                <Sparkles size={10} className="animate-spin" />
                <span>Formulating Advisor response...</span>
              </div>
              <div className="flex items-center gap-1 space-x-1 py-1">
                <div className="w-1.5 h-1.5 bg-brass-accent rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1.5 h-1.5 bg-brass-accent rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1.5 h-1.5 bg-brass-accent rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Recommended Prompt Pills */}
      <div className="p-3 bg-[#0a0a1a] border-t border-[#f5f2ed]/10 flex gap-2 overflow-x-auto whitespace-nowrap scrollbar-none">
        {[
          "Yorkshire Property Mortgages",
          "Granite Fixed Saver yields",
          "Treasury sweep structures",
          "Heritage ISA portfolios",
        ].map((pill, i) => (
          <button
            key={i}
            onClick={() => setInputValue(pill)}
            className="text-[11px] bg-[#0a0a1a] hover:bg-[#f5f2ed]/5 text-[#f5f2ed]/75 hover:text-[#f5f2ed] border border-[#f5f2ed]/10 px-2.5 py-1 rounded transition-colors duration-150 font-sans tracking-wide cursor-pointer"
          >
            {pill}
          </button>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-3 bg-[#0a0a1a] border-t border-[#f5f2ed]/10 flex items-center gap-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Consult Wellington Suite Advisory..."
          className="flex-1 bg-[#0a0a1a] border border-[#f5f2ed]/15 focus:border-brass-accent text-sm text-[#f5f2ed] px-3 py-2.5 rounded focus:outline-none placeholder-[#f5f2ed]/35 font-sans rounded-sm"
        />
        <button
          type="submit"
          className="bg-brass-accent text-zinc-950 p-2.5 rounded hover:bg-[#E6C17A] transition-colors cursor-pointer flex items-center justify-center rounded-sm font-semibold"
          title="Send message"
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
}
