import React, { useState, useEffect } from "react";
import { 
  Building2, 
  User, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CreditCard, 
  Send, 
  TrendingUp, 
  ChevronRight, 
  Plus, 
  Lock, 
  Sparkles, 
  Search, 
  LogOut, 
  RefreshCw, 
  CheckCircle, 
  AlertTriangle, 
  FileText, 
  Globe, 
  DollarSign, 
  PieChart, 
  Layers, 
  ChevronDown
} from "lucide-react";
import { 
  BankAccount, 
  Transaction, 
  CardConfig, 
  SavingsGoal, 
  BusinessInvoice, 
  FxRate 
} from "../types";

interface DigitalPortalProps {
  initialMode: "personal" | "business" | "wealth";
  userEmail: string;
  onLogout: () => void;
  onOpenAdvisory: () => void;
}

export default function DigitalPortal({ initialMode, userEmail, onLogout, onOpenAdvisory }: DigitalPortalProps) {
  // Mode selection: Personal vs Business vs Wealth
  const [activeMode, setActiveMode] = useState<"personal" | "business" | "wealth">(initialMode);
  const [activeSection, setActiveSection] = useState<string>("overview");

  // State synchronization message
  const [syncing, setSyncing] = useState<boolean>(false);
  const triggerSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 900);
  };

  // -----------------------------------------
  // MOCK DATA & PERSISTED STATE
  // -----------------------------------------
  
  // Bank Accounts
  const [accounts, setAccounts] = useState<BankAccount[]>([
    { id: "acc-1", name: "Sterling Current Account", accountNumber: "88402910", sortCode: "40-27-15", balance: 14250.80, type: "Personal Current" },
    { id: "acc-2", name: "Sovereign Savings (Granite)", accountNumber: "55301988", sortCode: "40-27-16", balance: 85200.00, type: "Sovereign Savings" },
    { id: "acc-3", name: "Leeds Heritage ISA", accountNumber: "33219455", sortCode: "40-27-17", balance: 45000.00, type: "Heritage Investment" },
    { id: "acc-4", name: "Business Checking Account", accountNumber: "11220499", sortCode: "40-27-99", balance: 247900.50, type: "Business Checking" },
    { id: "acc-5", name: "Treasury Sterling Reserve", accountNumber: "99887711", sortCode: "40-00-10", balance: 1250000.00, type: "Treasury Reserve" }
  ]);

  // Personal Transactions
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: "tx-1", date: "2026-07-20", reference: "Wellington Place Rent sweep", category: "Housing", amount: -1250.00, status: "Completed" },
    { id: "tx-2", date: "2026-07-19", reference: "Yorkshire Tech Corp Monthly Salary", category: "Salary", amount: 4850.00, status: "Completed" },
    { id: "tx-3", date: "2026-07-18", reference: "Granary Wharf Café", category: "Leisure", amount: -14.20, status: "Completed" },
    { id: "tx-4", date: "2026-07-17", reference: "Ilkley Organic Provisions", category: "Leisure", amount: -84.50, status: "Completed" },
    { id: "tx-5", date: "2026-07-15", reference: "LNER Leeds to King's Cross rail", category: "Transport", amount: -112.00, status: "Completed" },
    { id: "tx-6", date: "2026-07-12", reference: "Transfer to Granite Savings", category: "Transfer", amount: -1000.00, status: "Completed" },
    { id: "tx-7", date: "2026-07-10", reference: "Yorkshire Wind & Energy Bonds", category: "Investments", amount: -500.00, status: "Completed" }
  ]);

  // Card Configurations
  const [cards, setCards] = useState<CardConfig[]>([
    {
      id: "card-obsidian",
      holder: "TOM AHYX",
      cardNumber: "•••• •••• •••• 1912",
      expiry: "11/30",
      type: "Yorkshire Obsidian",
      isFrozen: false,
      limits: { dailyContactless: 150, dailyAtm: 500, monthlyOnline: 5000 },
      allowedFeatures: { contactless: true, international: true, atm: true }
    },
    {
      id: "card-brass",
      holder: "TOM AHYX",
      cardNumber: "•••• •••• •••• 8847",
      expiry: "04/29",
      type: "Sovereign Brass",
      isFrozen: false,
      limits: { dailyContactless: 100, dailyAtm: 300, monthlyOnline: 3000 },
      allowedFeatures: { contactless: true, international: false, atm: true }
    }
  ]);

  // Savings Goals
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([
    { id: "goal-1", title: "Yorkshire Country Manor ISA", targetAmount: 150000, currentAmount: 45000, targetDate: "2028-12-15", category: "Property" },
    { id: "goal-2", title: "Granary Wharf Business bond", targetAmount: 50000, currentAmount: 25000, targetDate: "2027-06-01", category: "Investments" }
  ]);

  // Business Invoices
  const [invoices, setInvoices] = useState<BusinessInvoice[]>([
    { id: "inv-1", clientName: "Northern Infrastructure Ltd", amount: 48500.00, issueDate: "2026-07-10", dueDate: "2026-08-10", status: "Outstanding", description: "Granite Civil Engineering consultation" },
    { id: "inv-2", clientName: "Yorkshire Textile Loom Mills", amount: 12400.00, issueDate: "2026-07-05", dueDate: "2026-08-05", status: "Paid", description: "Automated loom control sweeps" },
    { id: "inv-3", clientName: "Leeds District Development", amount: 75000.00, issueDate: "2026-06-20", dueDate: "2026-07-20", status: "Overdue", description: "Wellington Place architectural grid consultation" }
  ]);

  // Interactive Wealth Allocation State
  const [wealthAlloc, setWealthAlloc] = useState({
    cash: 15,
    gilts: 25,
    property: 20,
    greenEnergy: 25,
    equities: 15
  });

  // FX terminal rates
  const [fxRates, setFxRates] = useState<FxRate[]>([
    { pair: "GBP/USD", rate: 1.2942, change: 0.15 },
    { pair: "GBP/EUR", rate: 1.1874, change: -0.08 },
    { pair: "GBP/CHF", rate: 1.1422, change: 0.22 }
  ]);

  // -----------------------------------------
  // TRANSACTION / TRANSFER SUBMISSION
  // -----------------------------------------
  const [recipientName, setRecipientName] = useState("");
  const [sortCode, setSortCode] = useState("");
  const [accNum, setAccNum] = useState("");
  const [payAmount, setPayAmount] = useState("");
  const [payRef, setPayRef] = useState("");
  const [payCategory, setPayCategory] = useState<Transaction["category"]>("Transfer");

  // Flow controllers
  const [processingPayment, setProcessingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [securityStatus, setSecurityStatus] = useState("");
  const [fxCalcResult, setFxCalcResult] = useState<string | null>(null);

  const handleMakePayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(payAmount);
    
    if (!recipientName || !sortCode || !accNum || isNaN(amountNum) || amountNum <= 0) {
      alert("Please provide complete sorting and account coordinates.");
      return;
    }

    // Verify current account balance
    const currentAcc = accounts.find(a => a.id === "acc-1");
    if (!currentAcc || currentAcc.balance < amountNum) {
      alert("Insufficient liquidity in Sterling Current Account.");
      return;
    }

    setProcessingPayment(true);
    setSecurityStatus("Initiating Wellington Cryptographic Grid...");
    
    setTimeout(() => {
      setSecurityStatus("Verifying PRA regulatory compliance thresholds...");
      
      setTimeout(() => {
        setSecurityStatus("Executing dual Sterling Ledger clearance...");
        
        setTimeout(() => {
          // Complete payment
          const newTx: Transaction = {
            id: `tx-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            reference: payRef || `Transfer to ${recipientName}`,
            category: payCategory,
            amount: -amountNum,
            status: "Completed"
          };

          // Update transaction history
          setTransactions(prev => [newTx, ...prev]);

          // Update current account balance
          setAccounts(prev => prev.map(a => {
            if (a.id === "acc-1") {
              return { ...a, balance: a.balance - amountNum };
            }
            return a;
          }));

          setProcessingPayment(false);
          setPaymentSuccess(true);
          triggerSync();

          // Reset inputs
          setRecipientName("");
          setSortCode("");
          setAccNum("");
          setPayAmount("");
          setPayRef("");
          
          setTimeout(() => setPaymentSuccess(false), 5000);
        }, 850);
      }, 850);
    }, 850);
  };

  // -----------------------------------------
  // GOALS TOP-UP
  // -----------------------------------------
  const [topupGoalId, setTopupGoalId] = useState("");
  const [topupAmount, setTopupAmount] = useState("");

  const handleTopupGoal = (goalId: string, amount: number) => {
    const currentAcc = accounts.find(a => a.id === "acc-1");
    if (!currentAcc || currentAcc.balance < amount) {
      alert("Insufficient current balance for goal top-up.");
      return;
    }

    setAccounts(prev => prev.map(a => {
      if (a.id === "acc-1") return { ...a, balance: a.balance - amount };
      return a;
    }));

    setSavingsGoals(prev => prev.map(g => {
      if (g.id === goalId) return { ...g, currentAmount: g.currentAmount + amount };
      return g;
    }));

    // Add transaction
    const targetGoal = savingsGoals.find(g => g.id === goalId);
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      reference: `Gilt sweep: ${targetGoal?.title || "Savings Goal"}`,
      category: "Investments",
      amount: -amount,
      status: "Completed"
    };
    setTransactions(prev => [newTx, ...prev]);
    triggerSync();
  };

  // -----------------------------------------
  // INVOICE ACTIONS
  // -----------------------------------------
  const [newInvClient, setNewInvClient] = useState("");
  const [newInvAmount, setNewInvAmount] = useState("");
  const [newInvDesc, setNewInvDesc] = useState("");

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newInvAmount);
    if (!newInvClient || isNaN(amountNum) || amountNum <= 0) {
      alert("Please provide valid invoice client and amount parameters.");
      return;
    }

    const newInv: BusinessInvoice = {
      id: `inv-${Date.now()}`,
      clientName: newInvClient,
      amount: amountNum,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: "Outstanding",
      description: newInvDesc || "Commercial general services"
    };

    setInvoices(prev => [newInv, ...prev]);
    setNewInvClient("");
    setNewInvAmount("");
    setNewInvDesc("");
    triggerSync();
  };

  const handlePayInvoice = (invoiceId: string) => {
    const invoice = invoices.find(i => i.id === invoiceId);
    if (!invoice || invoice.status === "Paid") return;

    // Update invoice status
    setInvoices(prev => prev.map(i => {
      if (i.id === invoiceId) return { ...i, status: "Paid" };
      return i;
    }));

    // Increment Business Checking balance
    setAccounts(prev => prev.map(a => {
      if (a.id === "acc-4") return { ...a, balance: a.balance + invoice.amount };
      return a;
    }));

    triggerSync();
  };

  // -----------------------------------------
  // CARDS CONTROLLER
  // -----------------------------------------
  const toggleFreezeCard = (cardId: string) => {
    setCards(prev => prev.map(c => {
      if (c.id === cardId) return { ...c, isFrozen: !c.isFrozen };
      return c;
    }));
    triggerSync();
  };

  const toggleFeature = (cardId: string, feature: "contactless" | "international" | "atm") => {
    setCards(prev => prev.map(c => {
      if (c.id === cardId) {
        return {
          ...c,
          allowedFeatures: {
            ...c.allowedFeatures,
            [feature]: !c.allowedFeatures[feature]
          }
        };
      }
      return c;
    }));
    triggerSync();
  };

  // -----------------------------------------
  // WEALTH compound return projection
  // -----------------------------------------
  const calculateWealthYield = () => {
    // Basic yield multipliers
    const cashYield = 0.045; // 4.5%
    const giltYield = 0.0525; // 5.25%
    const propYield = 0.065; // 6.5%
    const greenYield = 0.078; // 7.8%
    const eqYield = 0.092; // 9.2%

    const totalWeight = wealthAlloc.cash + wealthAlloc.gilts + wealthAlloc.property + wealthAlloc.greenEnergy + wealthAlloc.equities;
    
    const weightedYield = 
      (wealthAlloc.cash * cashYield + 
       wealthAlloc.gilts * giltYield + 
       wealthAlloc.property * propYield + 
       wealthAlloc.greenEnergy * greenYield + 
       wealthAlloc.equities * eqYield) / totalWeight;

    return (weightedYield * 100).toFixed(2);
  };

  // Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");

  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = t.reference.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === "All" || t.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Total balance sum
  const totalWealthBalance = accounts
    .filter(a => a.id === "acc-1" || a.id === "acc-2" || a.id === "acc-3")
    .reduce((sum, a) => sum + a.balance, 0);

  const totalBusinessBalance = accounts
    .filter(a => a.id === "acc-4" || a.id === "acc-5")
    .reduce((sum, a) => sum + a.balance, 0);

  // FX fluctuations effect
  useEffect(() => {
    const interval = setInterval(() => {
      setFxRates(prev => prev.map(f => {
        const delta = (Math.random() - 0.5) * 0.002;
        const newRate = f.rate + delta;
        const newPct = f.change + (delta > 0 ? 0.01 : -0.01);
        return {
          ...f,
          rate: parseFloat(newRate.toFixed(4)),
          change: parseFloat(newPct.toFixed(2))
        };
      }));
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a1a] text-[#f5f2ed] flex flex-col md:flex-row font-sans">
      
      {/* ==================== LEFT SIDEBAR ==================== */}
      <aside className="w-full md:w-80 bg-[#0a0a1a] text-white border-r border-[#f5f2ed]/10 flex flex-col justify-between p-6 z-10">
        
        <div>
          {/* Logo Brand Header */}
          <div className="pb-6 border-b border-[#f5f2ed]/10 mb-8">
            <span className="font-serif text-lg tracking-widest block font-bold text-[#f5f2ed]">BANK OF LEEDS</span>
            <span className="text-[10px] uppercase font-mono tracking-widest text-brass-accent">Secure Gilt Portal</span>
          </div>
 
          {/* User profile capsule */}
          <div className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-4 rounded-sm flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded bg-brass-accent/10 border border-brass-accent/30 flex items-center justify-center text-brass-accent">
              <User size={18} />
            </div>
            <div>
              <div className="text-[10px] text-[#f5f2ed]/40 font-mono tracking-wider uppercase">Active Sweep Credentials</div>
              <div className="text-xs font-semibold text-[#f5f2ed] tracking-wide truncate max-w-[170px]">{userEmail}</div>
              <div className="text-[9px] text-[#f5f2ed]/50 font-mono">FCA Shield Authenticated</div>
            </div>
          </div>
 
          {/* Portal Mode Switcher */}
          <div className="mb-8 space-y-2">
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#f5f2ed]/40 block px-1 mb-1">Select Vault Segment</span>
            <div className="grid grid-cols-3 gap-1 bg-[#0a0a1a] p-1 border border-[#f5f2ed]/10 rounded-sm">
              <button
                onClick={() => { setActiveMode("personal"); setActiveSection("overview"); }}
                className={`py-2 text-[10px] font-mono uppercase tracking-wider rounded transition-colors cursor-pointer ${activeMode === "personal" ? "bg-brass-accent text-zinc-950 font-bold" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
              >
                Personal
              </button>
              <button
                onClick={() => { setActiveMode("business"); setActiveSection("overview"); }}
                className={`py-2 text-[10px] font-mono uppercase tracking-wider rounded transition-colors cursor-pointer ${activeMode === "business" ? "bg-brass-accent text-zinc-950 font-bold" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
              >
                Business
              </button>
              <button
                onClick={() => { setActiveMode("wealth"); setActiveSection("overview"); }}
                className={`py-2 text-[10px] font-mono uppercase tracking-wider rounded transition-colors cursor-pointer ${activeMode === "wealth" ? "bg-brass-accent text-zinc-950 font-bold" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
              >
                Wealth
              </button>
            </div>
          </div>
 
          {/* Sidebar Menu options */}
          <nav className="space-y-1 mb-8">
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#f5f2ed]/40 block px-1 mb-1">Ledger Sweep Sections</span>
            
            <button
              onClick={() => setActiveSection("overview")}
              className={`w-full text-left px-3 py-2.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-between cursor-pointer ${activeSection === "overview" ? "bg-[#f5f2ed]/5 text-brass-accent font-semibold border-l-2 border-brass-accent" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
            >
              <span>Vault Overview</span>
              <ChevronRight size={12} />
            </button>
 
            {activeMode === "personal" && (
              <>
                <button
                  onClick={() => setActiveSection("payments")}
                  className={`w-full text-left px-3 py-2.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-between cursor-pointer ${activeSection === "payments" ? "bg-[#f5f2ed]/5 text-brass-accent font-semibold border-l-2 border-brass-accent" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
                >
                  <span>Payments & sweeps</span>
                  <ChevronRight size={12} />
                </button>
                <button
                  onClick={() => setActiveSection("cards")}
                  className={`w-full text-left px-3 py-2.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-between cursor-pointer ${activeSection === "cards" ? "bg-[#f5f2ed]/5 text-brass-accent font-semibold border-l-2 border-brass-accent" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
                >
                  <span>Card freezing desk</span>
                  <ChevronRight size={12} />
                </button>
              </>
            )}
 
            {activeMode === "business" && (
              <>
                <button
                  onClick={() => setActiveSection("invoices")}
                  className={`w-full text-left px-3 py-2.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-between cursor-pointer ${activeSection === "invoices" ? "bg-[#f5f2ed]/5 text-brass-accent font-semibold border-l-2 border-brass-accent" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
                >
                  <span>Invoice Engine</span>
                  <ChevronRight size={12} />
                </button>
                <button
                  onClick={() => setActiveSection("fx")}
                  className={`w-full text-left px-3 py-2.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-between cursor-pointer ${activeSection === "fx" ? "bg-[#f5f2ed]/5 text-brass-accent font-semibold border-l-2 border-brass-accent" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
                >
                  <span>Treasury & FX Desk</span>
                  <ChevronRight size={12} />
                </button>
              </>
            )}
 
            {activeMode === "wealth" && (
              <button
                onClick={() => setActiveSection("allocation")}
                className={`w-full text-left px-3 py-2.5 rounded text-xs font-mono uppercase tracking-wider transition-colors flex items-center justify-between cursor-pointer ${activeSection === "allocation" ? "bg-[#f5f2ed]/5 text-brass-accent font-semibold border-l-2 border-brass-accent" : "text-[#f5f2ed]/60 hover:text-white hover:bg-[#f5f2ed]/5"}`}
              >
                <span>Bespoke Asset Allocation</span>
                <ChevronRight size={12} />
              </button>
            )}
 
          </nav>
 
          {/* AI Advisor activation button */}
          <div className="pt-4 border-t border-[#f5f2ed]/10">
            <button
              onClick={onOpenAdvisory}
              className="w-full bg-[#0a0a1a] hover:bg-[#f5f2ed]/5 text-brass-accent hover:text-white border border-brass-accent/30 p-3.5 rounded text-xs font-mono uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Sparkles size={14} className="animate-pulse" />
              <span>Consult Wellington Suite</span>
            </button>
          </div>
 
        </div>
 
        {/* Exit Controls */}
        <div className="pt-6 border-t border-[#f5f2ed]/10 mt-12 flex items-center justify-between">
          <div className="text-[10px] font-mono text-[#f5f2ed]/30">
            SECURITY KEY: LF-8704
          </div>
          <button 
            onClick={onLogout}
            className="text-[#f5f2ed]/60 hover:text-white text-xs font-mono flex items-center gap-1 cursor-pointer hover:underline"
          >
            <LogOut size={14} />
            <span>EXIT VAULT</span>
          </button>
        </div>
 
      </aside>
 
      {/* ==================== MAIN PANEL ==================== */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#0a0a1a]">
        
        {/* Core Header */}
        <header className="bg-[#0a0a1a]/95 backdrop-blur-md border-b border-[#f5f2ed]/10 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 bg-brass-accent/10 text-brass-accent font-semibold rounded-sm">
              {activeMode} segment
            </span>
            <div className="text-[#f5f2ed]/20 font-serif">|</div>
            <span className="text-xs font-mono text-[#f5f2ed]/60 tracking-wider">
              {new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
          </div>
 
          <div className="flex items-center gap-4">
            {/* Flashing secure light */}
            <div className="flex items-center gap-1.5 font-mono text-[10px] text-[#f5f2ed]/40">
              <span className="w-2 h-2 rounded-full bg-racing-green animate-pulse" />
              <span>REGULATORY CORE ACTIVE</span>
            </div>
 
            {syncing ? (
              <RefreshCw size={14} className="animate-spin text-brass-accent" />
            ) : (
              <button 
                onClick={triggerSync}
                className="text-[#f5f2ed]/40 hover:text-white p-1 rounded-sm"
                title="Synchronize Sterling Ledgers"
              >
                <RefreshCw size={14} />
              </button>
            )}
          </div>
        </header>

        {/* Core Dashboard Body */}
        <div className="p-6 md:p-8 space-y-8 flex-1 overflow-y-auto">
          
          {/* OVERVIEW SECTION */}
          {activeSection === "overview" && (
            <div className="space-y-8">
              
              {/* Account Balances Matrix */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {activeMode === "personal" && accounts.slice(0, 3).map((acc) => (
                  <div key={acc.id} className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl hover:border-brass-accent/40 transition-colors relative">
                    <div className="text-[9px] font-mono text-[#f5f2ed]/40 uppercase tracking-widest block mb-1">ACCOUNT NO: {acc.accountNumber}</div>
                    <h4 className="font-serif text-base font-medium text-[#f5f2ed] mb-4">{acc.name}</h4>
                    <div className="text-3xl font-serif text-[#f5f2ed] font-light mb-2">
                      £{acc.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="flex items-center justify-between text-[10px] font-mono text-[#f5f2ed]/50 pt-3 border-t border-[#f5f2ed]/10">
                      <span>SORT-CODE: {acc.sortCode}</span>
                      <span className="text-brass-accent">{acc.type}</span>
                    </div>
                  </div>
                ))}

                {activeMode === "business" && accounts.slice(3, 5).map((acc) => (
                  <div key={acc.id} className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl hover:border-brass-accent/40 transition-colors relative md:col-span-1">
                    <div className="text-[9px] font-mono text-[#f5f2ed]/40 uppercase tracking-widest block mb-1">COMMERCIAL SWEEP NO: {acc.accountNumber}</div>
                    <h4 className="font-serif text-base font-medium text-[#f5f2ed] mb-4">{acc.name}</h4>
                    <div className="text-3xl font-serif text-[#f5f2ed] font-light mb-2">
                      £{acc.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="flex items-center justify-between text-[10px] font-mono text-[#f5f2ed]/50 pt-3 border-t border-[#f5f2ed]/10">
                      <span>SORT-CODE: {acc.sortCode}</span>
                      <span className="text-brass-accent">{acc.type}</span>
                    </div>
                  </div>
                ))}

                {activeMode === "wealth" && (
                  <div className="bg-[#f5f2ed]/5 text-[#f5f2ed] border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl md:col-span-3 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
                    {/* Subtle grid accent */}
                    <div className="absolute inset-0 opacity-5" style={{
                      backgroundImage: `linear-gradient(to right, #f5f2ed 1px, transparent 1px)`,
                      backgroundSize: '20px 20px'
                    }} />
                    
                    <div className="space-y-2 z-10">
                      <span className="text-brass-accent font-mono text-[9px] uppercase tracking-widest">Heritage Holdings Sweep</span>
                      <h3 className="font-serif text-2xl font-light text-[#f5f2ed]">Leeds Sovereign Discretionary Vault</h3>
                      <p className="text-xs text-[#f5f2ed]/60 font-sans font-light max-w-xl">
                        A combined tax-efficient corpus indexed with sterling bonds, North Yorkshire estate properties, and clean grid infrastructure corridors. Formulated under FCA private banking structures.
                      </p>
                    </div>

                    <div className="z-10 text-right">
                      <span className="text-[#f5f2ed]/40 font-mono text-[10px] block uppercase">Combined Portfolio Value</span>
                      <span className="font-serif text-4xl text-brass-accent font-light">
                        £{totalWealthBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      </span>
                      <span className="font-mono text-[10px] text-[#f5f2ed]/50 block mt-1">YIELD TARGET: 6.85% AER</span>
                    </div>
                  </div>
                )}
              </div>

              {/* SECONDARY ROW GRID */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Personal / General transactions list */}
                {(activeMode === "personal" || activeMode === "wealth") && (
                  <div className="lg:col-span-8 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#f5f2ed]/10 pb-4">
                      <div>
                        <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Sterling Ledger History</h4>
                        <p className="text-xs text-[#f5f2ed]/60 font-light">Search and index verified transaction sweeps.</p>
                      </div>

                      {/* Filters */}
                      <div className="flex gap-2">
                        <select 
                          value={categoryFilter} 
                          onChange={(e) => setCategoryFilter(e.target.value)}
                          className="bg-[#0a0a1a] border border-[#f5f2ed]/15 text-[#f5f2ed] text-xs px-2.5 py-1.5 focus:outline-none focus:border-brass-accent font-sans rounded-sm"
                        >
                          <option value="All">All Categories</option>
                          <option value="Salary">Salary</option>
                          <option value="Housing">Housing</option>
                          <option value="Leisure">Leisure</option>
                          <option value="Transport">Transport</option>
                          <option value="Investments">Investments</option>
                          <option value="Transfer">Transfer</option>
                        </select>
                      </div>
                    </div>

                    {/* Search Field */}
                    <div className="relative">
                      <Search className="absolute left-3 top-2.5 text-[#f5f2ed]/40" size={14} />
                      <input 
                        type="text" 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Filter reference sweeps..."
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 text-[#f5f2ed] pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-brass-accent font-sans rounded-sm placeholder-[#f5f2ed]/30"
                      />
                    </div>

                    {/* Transaction Items */}
                    <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                      {filteredTransactions.length === 0 ? (
                        <div className="text-center py-12 text-xs text-[#f5f2ed]/40 font-mono">
                          No ledger sweeps matched your queries.
                        </div>
                      ) : filteredTransactions.map((tx) => (
                        <div key={tx.id} className="flex items-center justify-between p-3.5 border border-[#f5f2ed]/5 hover:border-[#f5f2ed]/15 transition-colors rounded-sm bg-[#0a0a1a]/40">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center border ${
                              tx.amount > 0 
                                ? "bg-racing-green/10 border-racing-green/20 text-racing-green" 
                                : "bg-[#f5f2ed]/5 border-[#f5f2ed]/10 text-[#f5f2ed]"
                            }`}>
                              {tx.amount > 0 ? <ArrowDownLeft size={14} /> : <ArrowUpRight size={14} />}
                            </div>
                            <div>
                              <div className="text-xs font-semibold text-[#f5f2ed] tracking-wide">{tx.reference}</div>
                              <div className="flex items-center gap-2 mt-0.5 text-[10px] font-mono text-[#f5f2ed]/40">
                                <span className="uppercase tracking-wider">{tx.category}</span>
                                <span>•</span>
                                <span>{tx.date}</span>
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className={`text-xs font-semibold ${tx.amount > 0 ? "text-racing-green" : "text-[#f5f2ed]"}`}>
                              {tx.amount > 0 ? "+" : ""}£{Math.abs(tx.amount).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                            </span>
                            <span className="text-[8px] font-mono block text-[#f5f2ed]/30 uppercase tracking-wider">{tx.status}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>
                )}

                {/* spending insights Donut chart right side */}
                {activeMode === "personal" && (
                  <div className="lg:col-span-4 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6 flex flex-col justify-between">
                    <div>
                      <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Spending Insights</h4>
                      <p className="text-xs text-[#f5f2ed]/50 font-light">Allocations by general sweep ledger.</p>
                    </div>

                    {/* SVG Donut Chart */}
                    <div className="relative flex justify-center py-4">
                      <svg width="160" height="160" viewBox="0 0 160 160" className="transform -rotate-90">
                        {/* Housing: 40% (251.2 length) */}
                        <circle cx="80" cy="80" r="60" fill="transparent" stroke="#1c1917" strokeWidth="18" strokeDasharray="150.7 376.8" strokeDashoffset="0" />
                        {/* Investments: 25% */}
                        <circle cx="80" cy="80" r="60" fill="transparent" stroke="#a68966" strokeWidth="18" strokeDasharray="94.2 376.8" strokeDashoffset="-150.7" />
                        {/* Leisure: 20% */}
                        <circle cx="80" cy="80" r="60" fill="transparent" stroke="#54433a" strokeWidth="18" strokeDasharray="75.4 376.8" strokeDashoffset="-244.9" />
                        {/* Transport: 15% */}
                        <circle cx="80" cy="80" r="60" fill="transparent" stroke="#44403c" strokeWidth="18" strokeDasharray="56.5 376.8" strokeDashoffset="-320.3" />
                      </svg>
                      {/* Hover stats label */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase">Total Debit</span>
                        <span className="text-base font-serif font-semibold text-[#f5f2ed]">£2,960.70</span>
                      </div>
                    </div>

                    {/* Chart Legend */}
                    <div className="grid grid-cols-2 gap-3 pt-4 border-t border-[#f5f2ed]/10 font-mono text-[10px]">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 bg-[#1c1917] rounded-sm" />
                        <span className="text-[#f5f2ed]/60">Housing (40%)</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 bg-[#a68966] rounded-sm" />
                        <span className="text-[#f5f2ed]/60">Invest (25%)</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 bg-[#54433a] rounded-sm" />
                        <span className="text-[#f5f2ed]/60">Leisure (20%)</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 bg-[#44403c] rounded-sm" />
                        <span className="text-[#f5f2ed]/60">Transit (15%)</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Savings goals list Personal side */}
                {activeMode === "personal" && (
                  <div className="lg:col-span-12 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl">
                    <div className="flex justify-between items-center border-b border-[#f5f2ed]/10 pb-4 mb-6">
                      <div>
                        <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Active Savings Goals</h4>
                        <p className="text-xs text-[#f5f2ed]/50 font-light">Compounding against our 5.25% AER reserve rates.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {savingsGoals.map((g) => {
                        const percent = Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100));
                        return (
                           <div key={g.id} className="border border-[#f5f2ed]/10 p-5 rounded-sm bg-[#0a0a1a]/50 relative">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <span className="text-[9px] font-mono text-brass-accent uppercase tracking-widest">{g.category} Target</span>
                                 <h5 className="font-serif text-base font-semibold text-[#f5f2ed]">{g.title}</h5>
                              </div>
                              <span className="text-xs font-mono text-[#f5f2ed]/50">Maturity: {g.targetDate}</span>
                            </div>

                            <div className="space-y-2 mb-4">
                              <div className="flex justify-between text-xs font-mono">
                                <span className="text-[#f5f2ed]/50">PROGRESS: {percent}%</span>
                                 <span className="text-[#f5f2ed] font-semibold">£{g.currentAmount.toLocaleString()} / £{g.targetAmount.toLocaleString()}</span>
                              </div>
                              <div className="w-full bg-[#f5f2ed]/10 h-1.5 rounded-full overflow-hidden">
                                <div style={{ width: `${percent}%` }} className="bg-brass-accent h-full rounded-full" />
                              </div>
                            </div>

                            {/* Easy quick Top Up action */}
                            <div className="flex gap-2 pt-2 border-t border-[#f5f2ed]/10">
                              <button 
                                onClick={() => handleTopupGoal(g.id, 1000)}
                                 className="bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] text-[10px] font-mono uppercase px-3 py-2 rounded-sm transition-colors cursor-pointer font-bold"
                              >
                                + £1,000 Sweep
                              </button>
                              <button 
                                onClick={() => handleTopupGoal(g.id, 5000)}
                                 className="bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] text-[10px] font-mono uppercase px-3 py-2 rounded-sm transition-colors cursor-pointer font-bold"
                              >
                                + £5,000 Gilt Sweep
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* BUSINESS OVERVIEW MODULES */}
                {activeMode === "business" && (
                  <>
                    {/* Cash Flow Line Chart */}
                    <div className="lg:col-span-8 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                      <div>
                        <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Commercial Treasury Analytics</h4>
                        <p className="text-xs text-[#f5f2ed]/50 font-light">6-Month Cash Inflows and Outflow forecasts (GBP).</p>
                      </div>

                      {/* Line Chart built on beautiful pure SVG */}
                      <div className="h-64 border-b border-[#f5f2ed]/10 pb-2 relative">
                        {/* Horizontal reference grid lines */}
                        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none text-[#f5f2ed]/40 text-[9px] font-mono">
                          <div className="border-b border-[#f5f2ed]/5 w-full pt-1"><span>£300,000</span></div>
                          <div className="border-b border-[#f5f2ed]/5 w-full"><span>£200,000</span></div>
                          <div className="border-b border-[#f5f2ed]/5 w-full"><span>£100,000</span></div>
                        </div>

                        {/* Custom area vectors */}
                        <svg className="w-full h-full absolute inset-0 z-10" preserveAspectRatio="none" viewBox="0 0 100 100">
                          {/* Inflows line (racing green) */}
                          <path 
                            d="M 5,80 L 20,60 L 40,45 L 60,35 L 80,25 L 95,15" 
                            fill="none" 
                            stroke="#00ff88" 
                            strokeWidth="2.5" 
                          />
                          {/* Inflows fill area */}
                          <path 
                            d="M 5,80 L 20,60 L 40,45 L 60,35 L 80,25 L 95,15 L 95,100 L 5,100 Z" 
                            fill="rgba(0, 255, 136, 0.04)" 
                          />

                          {/* Outflows line (Deep brass) */}
                          <path 
                            d="M 5,90 L 20,80 L 40,75 L 60,65 L 80,55 L 95,50" 
                            fill="none" 
                            stroke="#a68966" 
                            strokeWidth="2" 
                          />
                        </svg>

                        {/* Interactive Dot details */}
                        <div className="absolute inset-0 flex justify-between px-[5%] z-20">
                          {["Feb", "Mar", "Apr", "May", "Jun", "Jul"].map((m, i) => (
                            <div key={i} className="flex flex-col justify-end items-center h-full group">
                              <div className="w-2.5 h-2.5 bg-racing-green rounded-full border border-[#0a0a1a] transform hover:scale-125 transition-transform cursor-pointer" />
                              <span className="text-[10px] font-mono text-[#f5f2ed]/40 mt-2">{m}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-6 font-mono text-xs">
                        <div className="flex items-center gap-1.5">
                          <div className="w-3 h-0.5 bg-racing-green" />
                          <span className="text-[#f5f2ed]/60">Monthly Inflow (Avg: £245k)</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <div className="w-3 h-0.5 bg-brass-accent" />
                          <span className="text-[#f5f2ed]/60">Treasury Drain (Avg: £120k)</span>
                        </div>
                      </div>
                    </div>

                    {/* Pending invoices list quick widget */}
                    <div className="lg:col-span-4 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl flex flex-col justify-between">
                      <div>
                        <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Pending Invoices</h4>
                        <p className="text-xs text-[#f5f2ed]/50 font-light">Instant commercial liquid sweep sweeps.</p>
                      </div>

                      <div className="space-y-3 my-6 max-h-[220px] overflow-y-auto">
                        {invoices.filter(i => i.status !== "Paid").map(inv => (
                          <div key={inv.id} className="p-3 border border-[#f5f2ed]/5 bg-[#0a0a1a]/50 rounded-sm flex items-center justify-between">
                            <div>
                              <div className="text-xs font-semibold truncate max-w-[130px] text-[#f5f2ed]">{inv.clientName}</div>
                              <span className="text-[9px] font-mono text-[#f5f2ed]/40 block">DUE: {inv.dueDate}</span>
                            </div>
                            <div className="text-right">
                              <div className="text-xs font-mono font-semibold text-[#f5f2ed]">£{inv.amount.toLocaleString()}</div>
                              <button 
                                onClick={() => handlePayInvoice(inv.id)}
                                className="text-[9px] font-mono text-brass-accent uppercase hover:underline cursor-pointer block mt-0.5"
                              >
                                Mark Paid
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      <button 
                        onClick={() => setActiveSection("invoices")}
                        className="w-full bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] py-3 text-xs font-mono uppercase tracking-wider rounded-sm transition-colors cursor-pointer font-bold"
                      >
                        Enter Invoice Engine
                      </button>
                    </div>
                  </>
                )}

              </div>

            </div>
          )}

          {/* PAYMENTS & SWEEPS SECTION */}
          {activeSection === "payments" && activeMode === "personal" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Form left col */}
              <div className="lg:col-span-7 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                <div>
                  <h4 className="font-serif text-xl font-medium text-[#f5f2ed]">Bespoke Sterling Transfer</h4>
                  <p className="text-xs text-[#f5f2ed]/50 font-light">Transfer funds instantly to any regulated British banking holding.</p>
                </div>

                <form onSubmit={handleMakePayment} className="space-y-4 font-sans">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Beneficiary Name</label>
                      <input 
                        type="text" 
                        required
                        value={recipientName}
                        onChange={(e) => setRecipientName(e.target.value)}
                        placeholder="e.g. Leeds Estate Trust Ltd"
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Payment Category</label>
                      <select 
                        value={payCategory}
                        onChange={(e) => setPayCategory(e.target.value as Transaction["category"])}
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent text-[#f5f2ed] rounded-sm"
                      >
                        <option value="Transfer" className="bg-[#0a0a1a]">Account Transfer</option>
                        <option value="Housing" className="bg-[#0a0a1a]">Housing & Estate</option>
                        <option value="Investments" className="bg-[#0a0a1a]">Gilt / ISA Investment</option>
                        <option value="Leisure" className="bg-[#0a0a1a]">Commercial Trade</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Sort Code (6 Digits)</label>
                      <input 
                        type="text" 
                        required
                        maxLength={8}
                        value={sortCode}
                        onChange={(e) => setSortCode(e.target.value)}
                        placeholder="e.g. 40-27-15"
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent font-mono text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Account Number (8 Digits)</label>
                      <input 
                        type="text" 
                        required
                        maxLength={8}
                        value={accNum}
                        onChange={(e) => setAccNum(e.target.value)}
                        placeholder="e.g. 88402910"
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent font-mono text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Amount (GBP)</label>
                      <input 
                        type="number" 
                        required
                        min="1"
                        value={payAmount}
                        onChange={(e) => setPayAmount(e.target.value)}
                        placeholder="e.g. 500"
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent font-semibold text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Reference (Optional)</label>
                      <input 
                        type="text" 
                        value={payRef}
                        onChange={(e) => setPayRef(e.target.value)}
                        placeholder="e.g. Ilkley Estate sweep"
                        className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                      />
                    </div>
                  </div>

                  <button 
                    type="submit" 
                    disabled={processingPayment}
                    className="w-full bg-brass-accent hover:bg-[#E6C17A] text-zinc-950 font-sans text-xs uppercase tracking-widest font-semibold py-3.5 rounded-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    {processingPayment ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" />
                        <span>Verifying security grids...</span>
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        <span>Authorize Sovereign Transfer</span>
                      </>
                    )}
                  </button>

                </form>

                {processingPayment && (
                  <div className="bg-[#0a0a1a]/50 border border-brass-accent/30 p-4 rounded-sm flex items-start gap-3 mt-4">
                    <span className="w-2.5 h-2.5 bg-brass-accent rounded-full animate-ping mt-1.5" />
                    <div>
                      <div className="text-xs font-semibold text-[#f5f2ed] uppercase tracking-wide font-mono">Ledger Cryptographic Audit</div>
                      <p className="text-[11px] text-[#f5f2ed]/60 mt-0.5 font-light leading-relaxed">{securityStatus}</p>
                    </div>
                  </div>
                )}

                {paymentSuccess && (
                  <div className="bg-racing-green/10 border border-racing-green/30 p-4 rounded-sm flex items-start gap-3 mt-4">
                    <CheckCircle className="text-racing-green mt-0.5" size={18} />
                    <div>
                      <div className="text-xs font-semibold text-racing-green uppercase tracking-wide font-mono">Transfer Confirmed</div>
                      <p className="text-[11px] text-[#f5f2ed]/80 mt-0.5 font-light leading-relaxed">The Sterling Ledger sweep completed successfully. Recipient corridors notified.</p>
                    </div>
                  </div>
                )}

              </div>

              {/* Informational sidebar right col */}
              <div className="lg:col-span-5 bg-brass-accent/10 text-[#f5f2ed] p-6 border border-brass-accent/20 rounded-sm space-y-6 shadow-sm flex flex-col justify-between">
                <div className="space-y-4">
                  <span className="text-brass-accent font-mono text-[9px] uppercase tracking-widest block">Lending Gilt Assurance</span>
                  <h4 className="font-serif text-lg font-light text-[#f5f2ed]">Underwritten Security Thresholds</h4>
                  <p className="text-xs text-[#f5f2ed]/60 font-sans font-light leading-relaxed">
                    Under the Banking Act of 2009, Bank of Leeds structures each private Sterling transfer within custom cryptographic frames. This ensures absolute protection against cyber-clutter and unauthorized sweeps.
                  </p>
                </div>

                <div className="p-4 bg-[#0a0a1a]/40 border border-[#f5f2ed]/10 rounded-sm space-y-2">
                  <span className="text-[#f5f2ed]/40 text-[9px] uppercase tracking-wider block font-mono">FCA Regulator limits</span>
                  <ul className="text-[10px] space-y-1.5 text-[#f5f2ed]/70 font-mono">
                    <li>• Contactless cap: £100 per sweep</li>
                    <li>• Daily transfer ceiling: £250,000</li>
                    <li>• Gilt shield assurance: Guaranteed</li>
                  </ul>
                </div>
              </div>

            </div>
          )}

          {/* CARDS CONTROL DECK */}
          {activeSection === "cards" && activeMode === "personal" && (
            <div className="space-y-8">
              <div>
                <h4 className="font-serif text-xl font-medium text-[#f5f2ed]">Sovereign Obsidian Card Controls</h4>
                <p className="text-xs text-[#f5f2ed]/50 font-light">Actively manage features and cryptographic status of your physical gold-inlaid cards.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {cards.map((card) => (
                  <div key={card.id} className="bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                    
                    {/* Visual Card representation */}
                    <div className={`aspect-[1.586/1] rounded-xl p-6 relative overflow-hidden text-white flex flex-col justify-between shadow-lg transition-all duration-300 ${
                      card.isFrozen ? "bg-zinc-800 grayscale brightness-50 border border-zinc-700/30" : 
                      card.type === "Yorkshire Obsidian" ? "bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800" :
                      "bg-gradient-to-br from-[#121212] via-[#2A2315] to-[#121212] border border-[#C5A059]/30"
                    }`}>
                      {/* Subtle logo */}
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-serif text-xs font-bold tracking-widest text-stone-primary block">BANK OF LEEDS</span>
                          <span className="text-[7px] uppercase tracking-widest text-brass-accent font-mono block">Sovereign Gilt Member</span>
                        </div>
                        {/* Chip graphic */}
                        <div className="w-8 h-7 bg-gradient-to-r from-brass-accent to-[#E6C17A] rounded-md border border-brass-accent/30" />
                      </div>

                      {/* Card number */}
                      <div className="font-mono text-base tracking-[0.25em] text-stone-primary py-2 text-center">
                        {card.cardNumber}
                      </div>

                      {/* Cardholder name & Expiry */}
                      <div className="flex justify-between items-end font-mono text-[9px] tracking-wider text-stone-limestone">
                        <div>
                          <span className="text-[7px] text-zinc-500 uppercase block">CARD HOLDER</span>
                          <span className="text-xs uppercase">{card.holder}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[7px] text-zinc-500 uppercase block">EXPIRY</span>
                          <span className="text-xs">{card.expiry}</span>
                        </div>
                      </div>
                    </div>

                    {/* Features checklist switches */}
                    <div className="space-y-4">
                      
                      {/* Freeze Card switch */}
                      <div className="flex items-center justify-between py-2 border-b border-[#f5f2ed]/10">
                        <div>
                          <span className="text-xs font-semibold text-[#f5f2ed] block">Lock/Freeze Card</span>
                          <span className="text-[10px] text-[#f5f2ed]/50">Temporarily block all physical and digital sweeps.</span>
                        </div>
                        <button 
                          onClick={() => toggleFreezeCard(card.id)}
                          className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 cursor-pointer ${card.isFrozen ? "bg-[#a68966]" : "bg-[#f5f2ed]/20"}`}
                        >
                          <div className={`w-4 h-4 rounded-full bg-[#0a0a1a] transition-transform duration-200 ${card.isFrozen ? "translate-x-6 bg-[#0a0a1a]" : ""}`} />
                        </button>
                      </div>

                      {/* Feature 1 */}
                      <div className="flex items-center justify-between py-2 border-b border-[#f5f2ed]/10">
                        <div>
                          <span className="text-xs font-semibold text-[#f5f2ed] block">Contactless Purchases</span>
                          <span className="text-[10px] text-[#f5f2ed]/50">Enable tap-to-pay under PRA regulatory boundaries.</span>
                        </div>
                        <button 
                          disabled={card.isFrozen}
                          onClick={() => toggleFeature(card.id, "contactless")}
                          className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 cursor-pointer ${card.isFrozen ? "opacity-20 cursor-not-allowed" : ""} ${card.allowedFeatures.contactless ? "bg-racing-green" : "bg-[#f5f2ed]/20"}`}
                        >
                          <div className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${card.allowedFeatures.contactless ? "translate-x-6" : ""}`} />
                        </button>
                      </div>

                      {/* Feature 2 */}
                      <div className="flex items-center justify-between py-2 border-b border-[#f5f2ed]/10">
                        <div>
                          <span className="text-xs font-semibold text-[#f5f2ed] block">International Transactions</span>
                          <span className="text-[10px] text-[#f5f2ed]/50">Support payments and currency conversions outside the UK.</span>
                        </div>
                        <button 
                          disabled={card.isFrozen}
                          onClick={() => toggleFeature(card.id, "international")}
                          className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 cursor-pointer ${card.isFrozen ? "opacity-20 cursor-not-allowed" : ""} ${card.allowedFeatures.international ? "bg-racing-green" : "bg-[#f5f2ed]/20"}`}
                        >
                          <div className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${card.allowedFeatures.international ? "translate-x-6" : ""}`} />
                        </button>
                      </div>

                      {/* Feature 3 */}
                      <div className="flex items-center justify-between py-2">
                        <div>
                          <span className="text-xs font-semibold text-[#f5f2ed] block">ATM Cash Withdrawals</span>
                          <span className="text-[10px] text-[#f5f2ed]/50">Allow physical cash dispenser sweeps globally.</span>
                        </div>
                        <button 
                          disabled={card.isFrozen}
                          onClick={() => toggleFeature(card.id, "atm")}
                          className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 cursor-pointer ${card.isFrozen ? "opacity-20 cursor-not-allowed" : ""} ${card.allowedFeatures.atm ? "bg-racing-green" : "bg-[#f5f2ed]/20"}`}
                        >
                          <div className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${card.allowedFeatures.atm ? "translate-x-6" : ""}`} />
                        </button>
                      </div>

                    </div>

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* INVOICE ENGINE SECTION */}
          {activeSection === "invoices" && activeMode === "business" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Invoice List left col */}
              <div className="lg:col-span-8 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                <div>
                  <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Commercial Invoices ledger</h4>
                  <p className="text-xs text-[#f5f2ed]/50 font-light">Index pending receivables and execute instant liquidation sweeps.</p>
                </div>

                <div className="space-y-4">
                  {invoices.map((inv) => (
                    <div key={inv.id} className="p-4 border border-[#f5f2ed]/5 bg-[#0a0a1a]/50 hover:border-brass-accent/30 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-sm">
                      <div className="flex items-start gap-3">
                        <div className={`w-9 h-9 rounded bg-[#f5f2ed]/10 flex items-center justify-center text-brass-accent`}>
                          <FileText size={18} />
                        </div>
                        <div>
                          <h5 className="font-serif text-base font-semibold text-[#f5f2ed]">{inv.clientName}</h5>
                          <p className="text-xs text-[#f5f2ed]/60 mt-0.5">{inv.description}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] font-mono text-[#f5f2ed]/40">
                            <span>ISSUE: {inv.issueDate}</span>
                            <span>•</span>
                            <span>DUE: {inv.dueDate}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-6 border-t sm:border-t-0 border-[#f5f2ed]/10 pt-3 sm:pt-0">
                        <div className="text-left sm:text-right">
                          <div className="text-sm font-semibold font-mono text-[#f5f2ed]">£{inv.amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</div>
                          <span className={`text-[9px] font-mono uppercase tracking-wider block ${
                            inv.status === "Paid" ? "text-racing-green" : 
                            inv.status === "Outstanding" ? "text-brass-accent" : "text-red-400"
                          }`}>{inv.status}</span>
                        </div>

                        {inv.status !== "Paid" && (
                          <button 
                            onClick={() => handlePayInvoice(inv.id)}
                            className="bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] text-[10px] font-mono uppercase px-4 py-2.5 rounded-sm transition-colors cursor-pointer font-bold"
                          >
                            Sweep Assets
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

              </div>

              {/* Form Create Invoice right col */}
              <div className="lg:col-span-4 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                <div>
                  <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Create Gilt Invoice</h4>
                  <p className="text-xs text-[#f5f2ed]/50 font-light">Issue new institutional payment coordinates.</p>
                </div>

                <form onSubmit={handleCreateInvoice} className="space-y-4 text-xs font-sans">
                  <div>
                    <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Debtor Client Name</label>
                    <input 
                      type="text" 
                      required
                      value={newInvClient}
                      onChange={(e) => setNewInvClient(e.target.value)}
                      placeholder="e.g. Leeds Civic Council Office"
                      className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Invoice Amount (GBP)</label>
                    <input 
                      type="number" 
                      required
                      min="1"
                      value={newInvAmount}
                      onChange={(e) => setNewInvAmount(e.target.value)}
                      placeholder="e.g. 15000"
                      className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent font-semibold text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Service Specifications</label>
                    <textarea 
                      value={newInvDesc}
                      onChange={(e) => setNewInvDesc(e.target.value)}
                      placeholder="e.g. Infrastructure civil design services"
                      className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2 text-xs focus:outline-none focus:border-brass-accent h-20 text-[#f5f2ed] placeholder-[#f5f2ed]/30 rounded-sm"
                    />
                  </div>

                  <button 
                    type="submit" 
                    className="w-full bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] py-3 font-mono uppercase tracking-widest text-[10px] transition-colors cursor-pointer font-bold"
                  >
                    Generate Invoice Ledger
                  </button>
                </form>
              </div>

            </div>
          )}

          {/* TREASURY & FX TERMINAL */}
          {activeSection === "fx" && activeMode === "business" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* FX Rates List left col */}
              <div className="lg:col-span-7 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                <div className="flex items-center justify-between border-b border-[#f5f2ed]/10 pb-4">
                  <div>
                    <span className="text-brass-accent font-mono text-[9px] uppercase tracking-widest block">Wellington Suite Terminal</span>
                    <h4 className="font-serif text-lg font-light text-[#f5f2ed]">Sterling Foreign Exchange rates</h4>
                  </div>
                  <div className="flex items-center gap-1 bg-[#0a0a1a] border border-[#f5f2ed]/10 text-[10px] text-[#f5f2ed]/50 px-2.5 py-1 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-racing-green animate-ping" />
                    <span>LIVE TICKER STATUS</span>
                  </div>
                </div>

                <div className="space-y-4">
                  {fxRates.map((fx) => (
                    <div key={fx.pair} className="p-4 border border-[#f5f2ed]/5 bg-[#0a0a1a]/40 rounded-sm flex items-center justify-between hover:bg-[#0a0a1a]/80 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-[#f5f2ed]/10 flex items-center justify-center text-brass-accent">
                          <Globe size={16} />
                        </div>
                        <div>
                          <span className="font-mono text-sm font-bold block text-[#f5f2ed]">{fx.pair}</span>
                          <span className="text-[9px] text-[#f5f2ed]/40 font-mono block">Sterling base liquidity</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-lg font-mono tracking-wider block font-semibold text-[#f5f2ed]">{fx.rate}</span>
                        <span className={`text-[10px] font-mono block font-medium ${fx.change >= 0 ? "text-racing-green" : "text-red-400"}`}>
                          {fx.change >= 0 ? "+" : ""}{fx.change}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-4 bg-[#0a0a1a]/60 border border-[#f5f2ed]/10 rounded-sm text-xs font-mono text-[#f5f2ed]/60">
                  <span className="uppercase text-[9px] text-brass-accent block mb-1">Treasury compliance</span>
                  We settle corporate FX sweeps within 140 milliseconds under native commercial liquidity pools. Authorized under FSCS limits.
                </div>
              </div>

              {/* FX Converter right col */}
              <div className="lg:col-span-5 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                <div>
                  <h4 className="font-serif text-lg font-medium text-[#f5f2ed]">Exchange Calculator</h4>
                  <p className="text-xs text-[#f5f2ed]/50 font-light">Verify conversions instantly against our wholesale reserve rates.</p>
                </div>

                {/* Simulated calculator */}
                <div className="space-y-4 text-xs font-sans">
                  <div>
                    <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Convert From</label>
                    <div className="flex border border-[#f5f2ed]/15 focus-within:border-brass-accent rounded-sm overflow-hidden">
                      <input 
                        type="number" 
                        defaultValue={1000}
                        id="from-amount"
                        className="flex-1 bg-[#0a0a1a] text-[#f5f2ed] px-3 py-2 text-xs focus:outline-none"
                      />
                      <span className="bg-[#f5f2ed]/10 px-4 py-2 font-mono text-xs text-[#f5f2ed]/70 flex items-center">GBP</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-[#f5f2ed]/40 uppercase block mb-1">Target Currency</label>
                    <select 
                      id="target-curr"
                      className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 text-[#f5f2ed] px-3 py-2 text-xs focus:outline-none focus:border-brass-accent rounded-sm"
                    >
                      <option value="usd" className="bg-[#0a0a1a]">US Dollar (USD) • Rate: 1.2942</option>
                      <option value="eur" className="bg-[#0a0a1a]">Euro (EUR) • Rate: 1.1874</option>
                      <option value="chf" className="bg-[#0a0a1a]">Swiss Franc (CHF) • Rate: 1.1422</option>
                    </select>
                  </div>

                  {/* Calculator inline results panel (Avoids Disruptive window.alerts) */}
                  {fxCalcResult && (
                    <div className="p-3.5 bg-brass-accent/10 border border-brass-accent/30 rounded-sm text-[11px] text-[#f5f2ed] font-sans leading-relaxed">
                      <span className="font-mono text-[9px] uppercase tracking-wider text-brass-accent block mb-1">Treasury Calculation Rate</span>
                      {fxCalcResult}
                    </div>
                  )}

                  {/* Result button */}
                  <button 
                    type="button"
                    onClick={() => {
                      const fromAmt = parseFloat((document.getElementById("from-amount") as HTMLInputElement).value) || 0;
                      const target = (document.getElementById("target-curr") as HTMLSelectElement).value;
                      let factor = 1.2942;
                      let label = "USD";
                      if (target === "eur") { factor = 1.1874; label = "EUR"; }
                      if (target === "chf") { factor = 1.1422; label = "CHF"; }
                      setFxCalcResult(`Treasury Projection: £${fromAmt.toLocaleString('en-GB', { minimumFractionDigits: 2 })} GBP yields ${(fromAmt * factor).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${label} at wholesale reserve rates.`);
                    }}
                    className="w-full bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] py-3 font-mono uppercase tracking-widest text-[10px] transition-colors cursor-pointer font-bold"
                  >
                    Execute conversion sweep
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* BESPOKE ASSET ALLOCATION (WEALTH) */}
          {activeSection === "allocation" && activeMode === "wealth" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Sliders and projection left col */}
              <div className="lg:col-span-7 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 p-6 rounded-sm shadow-xl space-y-6">
                <div>
                  <span className="text-brass-accent font-mono text-xs tracking-widest uppercase block mb-2">Heritage allocations</span>
                  <h4 className="font-serif text-xl font-medium text-[#f5f2ed]">Configure private yield corridor weights</h4>
                  <p className="text-xs text-[#f5f2ed]/50 font-light">
                    Adjust allocation sliders to optimize the composition of your combined £{totalWealthBalance.toLocaleString()} portfolio holdings. Projections calculate 10-year maturity returns based on asset class volatility.
                  </p>
                </div>

                {/* Adjustments */}
                <div className="space-y-5 bg-[#0a0a1a]/50 p-5 border border-[#f5f2ed]/10 rounded-sm">
                  
                  {/* Class 1 */}
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span className="text-[#f5f2ed]/60 uppercase">Sovereign Gilts (4.5% yield)</span>
                      <span className="text-brass-accent font-semibold">{wealthAlloc.gilts}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={wealthAlloc.gilts}
                      onChange={(e) => setWealthAlloc({ ...wealthAlloc, gilts: Number(e.target.value) })}
                      className="w-full accent-brass-accent bg-[#f5f2ed]/10 h-1 rounded-sm cursor-pointer"
                    />
                  </div>

                  {/* Class 2 */}
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span className="text-[#f5f2ed]/60 uppercase">North Yorkshire Estate Trust (6.5% yield)</span>
                      <span className="text-brass-accent font-semibold">{wealthAlloc.property}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={wealthAlloc.property}
                      onChange={(e) => setWealthAlloc({ ...wealthAlloc, property: Number(e.target.value) })}
                      className="w-full accent-brass-accent bg-[#f5f2ed]/10 h-1 rounded-sm cursor-pointer"
                    />
                  </div>

                  {/* Class 3 */}
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span className="text-[#f5f2ed]/60 uppercase">Green Grid Infrastructure (7.8% yield)</span>
                      <span className="text-brass-accent font-semibold">{wealthAlloc.greenEnergy}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={wealthAlloc.greenEnergy}
                      onChange={(e) => setWealthAlloc({ ...wealthAlloc, greenEnergy: Number(e.target.value) })}
                      className="w-full accent-brass-accent bg-[#f5f2ed]/10 h-1 rounded-sm cursor-pointer"
                    />
                  </div>

                  {/* Class 4 */}
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span className="text-[#f5f2ed]/60 uppercase">High-Growth Sterling Indices (9.2% yield)</span>
                      <span className="text-brass-accent font-semibold">{wealthAlloc.equities}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={wealthAlloc.equities}
                      onChange={(e) => setWealthAlloc({ ...wealthAlloc, equities: Number(e.target.value) })}
                      className="w-full accent-brass-accent bg-[#f5f2ed]/10 h-1 rounded-sm cursor-pointer"
                    />
                  </div>

                  <div className="text-[10px] font-mono text-[#f5f2ed]/40 text-center uppercase">
                    Weights combine dynamically to formulate absolute return corridors.
                  </div>

                </div>
              </div>

              {/* Return projections right col */}
              <div className="lg:col-span-5 bg-brass-accent/10 text-white p-6 border border-brass-accent/20 rounded-sm shadow-xl flex flex-col justify-between">
                <div className="space-y-4">
                  <span className="text-brass-accent font-mono text-[9px] uppercase tracking-widest block">Compounding Projections</span>
                  <h4 className="font-serif text-lg font-light text-[#f5f2ed]">Heritage Suite Yield Optimization</h4>
                  
                  <div className="py-6 border-y border-[#f5f2ed]/10">
                    <span className="text-[#f5f2ed]/40 font-mono text-[10px] uppercase block">Target Portfolio Yield</span>
                    <span className="text-5xl font-serif text-brass-accent font-light">{calculateWealthYield()}% AER</span>
                  </div>

                  <p className="text-xs text-[#f5f2ed]/60 font-sans font-light leading-relaxed">
                    This allocation sweeps cash buffers into structured gilts and infrastructure corridors automatically. Backed under PRA capital covenants.
                  </p>
                </div>

                <div className="bg-[#0a0a1a]/60 border border-[#f5f2ed]/10 p-4 rounded-sm text-xs font-mono text-[#f5f2ed]/80">
                  <span className="text-[9px] text-[#f5f2ed]/40 block uppercase mb-1">10-Year Growth Projection</span>
                  £{Math.round(totalWealthBalance * Math.pow(1 + parseFloat(calculateWealthYield())/100, 10)).toLocaleString()} Value at Maturity.
                </div>
              </div>

            </div>
          )}

        </div>

      </main>

    </div>
  );
}
