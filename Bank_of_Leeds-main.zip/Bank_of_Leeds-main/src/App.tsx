import React, { useState } from "react";
import { Sparkles, X, Lock, Building2, Eye, ShieldAlert, Check } from "lucide-react";
import MarketingSite from "./components/MarketingSite";
import DigitalPortal from "./components/DigitalPortal";
import AdvisoryChat from "./components/AdvisoryChat";

export default function App() {
  // Navigation states
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [activePortalMode, setActivePortalMode] = useState<"personal" | "business" | "wealth">("personal");
  
  // Login Modal state
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [emailInput, setEmailInput] = useState<string>("tom@ahyx.org");
  const [passwordInput, setPasswordInput] = useState<string>("••••••••••••");
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(false);

  // AI advisory drawer state
  const [showAdvisory, setShowAdvisory] = useState<boolean>(false);

  // Trigger login process
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;

    setIsAuthenticating(true);
    
    // Simulate high-grade cryptographic sweep verification
    setTimeout(() => {
      setIsAuthenticating(false);
      setIsLoggedIn(true);
      setShowLoginModal(false);
    }, 1200);
  };

  const handleOpenPortalFromMarketing = (mode: "personal" | "business" | "wealth") => {
    setActivePortalMode(mode);
    setShowLoginModal(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setShowAdvisory(false);
  };

  return (
    <div className="min-h-screen bg-[#0a0a1a] text-[#f5f2ed] font-sans selection:bg-brass-accent selection:text-[#0a0a1a] flex flex-col">
      
      {/* 1. FIXED TOP HEADER (Only on marketing view) */}
      {!isLoggedIn && (
        <header className="sticky top-0 z-40 bg-[#0a0a1a]/95 backdrop-blur-md border-b border-[#f5f2ed]/10 px-6 py-4 md:px-16 flex items-center justify-between">
          <div className="flex items-center gap-10">
            {/* Logo */}
            <div className="flex flex-col cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <span className="font-serif text-lg tracking-[0.2em] font-semibold text-[#f5f2ed] block">BANK OF LEEDS</span>
              <span className="text-[9px] font-mono tracking-widest text-[#a68966] uppercase">Yorkshire Supermodernism</span>
            </div>

            {/* Nav anchors */}
            <nav className="hidden lg:flex items-center gap-8 text-[11px] font-mono uppercase tracking-widest text-[#f5f2ed]/60">
              <a onClick={() => handleOpenPortalFromMarketing("personal")} className="hover:text-brass-accent cursor-pointer transition-colors duration-150">Personal</a>
              <a onClick={() => handleOpenPortalFromMarketing("business")} className="hover:text-brass-accent cursor-pointer transition-colors duration-150">Business</a>
              <a onClick={() => handleOpenPortalFromMarketing("wealth")} className="hover:text-brass-accent cursor-pointer transition-colors duration-150">Wealth</a>
              <span className="text-[#f5f2ed]/20">/</span>
              <a onClick={() => {
                const landmarkSec = document.getElementById("gilt-calculator");
                landmarkSec?.scrollIntoView({ behavior: 'smooth' });
              }} className="hover:text-brass-accent cursor-pointer transition-colors duration-150">Yield Projections</a>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => handleOpenPortalFromMarketing("personal")}
              className="bg-[#f5f2ed] hover:bg-[#FAF7F2] text-[#0a0a1a] text-[10px] font-mono uppercase tracking-widest px-5 py-3 rounded-sm transition-colors cursor-pointer font-bold shadow-xl"
            >
              Access Portal
            </button>
          </div>
        </header>
      )}

      {/* ==================== SCREEN SWITCHER ==================== */}
      <div className="flex-1 flex min-h-0 relative">
        
        {isLoggedIn ? (
          /* DIGITAL ONLINE BANKING WORKSPACE */
          <div className="flex-1 flex flex-col md:flex-row min-h-0 w-full relative">
            <div className="flex-1 min-w-0">
              <DigitalPortal 
                initialMode={activePortalMode}
                userEmail={emailInput}
                onLogout={handleLogout}
                onOpenAdvisory={() => setShowAdvisory(true)}
              />
            </div>

            {/* Sliding Wellington Private AI Advisory Side Drawer */}
            {showAdvisory && (
              <div className="w-full md:w-96 h-[60vh] md:h-auto border-t md:border-t-0 border-[#f5f2ed]/10 flex-shrink-0 z-30 shadow-2xl relative">
                <AdvisoryChat onClose={() => setShowAdvisory(false)} />
              </div>
            )}
          </div>
        ) : (
          /* PUBLIC MARKETING PORTAL */
          <div className="flex-1">
            <MarketingSite onOpenPortal={handleOpenPortalFromMarketing} />
          </div>
        )}

      </div>

      {/* ==================== HIGH-SECURITY LOGIN GLASS MODAL ==================== */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-[#0a0a1a]/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0a0a1a] border border-[#f5f2ed]/15 shadow-2xl max-w-md w-full p-8 relative rounded-sm font-sans text-[#f5f2ed]">
            
            {/* Close button */}
            <button 
              onClick={() => setShowLoginModal(false)}
              className="absolute top-6 right-6 text-[#f5f2ed]/60 hover:text-[#f5f2ed] transition-colors"
            >
              <X size={18} />
            </button>

            {/* Header info */}
            <div className="text-center pb-6 border-b border-[#f5f2ed]/10 mb-6">
              <span className="text-[10px] font-mono text-[#a68966] block uppercase tracking-widest">Sovereign Encryption Gate</span>
              <h3 className="font-serif text-2xl font-light text-[#f5f2ed] mt-2">Access Bank of Leeds Vault</h3>
              <p className="text-xs text-[#f5f2ed]/60 mt-1 font-light">Underwritten by the PRA and FCA regulatory grid parameters.</p>
            </div>

            {/* Login form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              
              <div>
                <label className="text-[10px] font-mono text-[#f5f2ed]/50 uppercase block mb-1">Authenticated Email (Sort Sweep)</label>
                <div className="relative">
                  <input 
                    type="email" 
                    required
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="e.g. tom@ahyx.org"
                    className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2.5 text-xs focus:outline-none focus:border-brass-accent font-semibold text-[#f5f2ed] placeholder-[#f5f2ed]/30"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono text-[#f5f2ed]/50 uppercase block mb-1">Cryptographic Vault Passcode</label>
                <div className="relative">
                  <input 
                    type="password" 
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-[#0a0a1a] border border-[#f5f2ed]/15 px-3 py-2.5 text-xs focus:outline-none focus:border-brass-accent font-mono text-[#f5f2ed]/50 placeholder-[#f5f2ed]/30"
                  />
                </div>
              </div>

              <div className="p-3 bg-[#f5f2ed]/5 border border-[#f5f2ed]/10 rounded-sm flex items-start gap-2 text-[11px] text-[#f5f2ed]/80 font-light leading-relaxed">
                <Lock size={14} className="text-brass-accent mt-0.5 flex-shrink-0" />
                <span>Entering this gate invokes a secure TLS dual-ledger handshake. Your session is underwritten under PRN: 870496 parameters.</span>
              </div>

              <button 
                type="submit"
                disabled={isAuthenticating}
                className="w-full bg-[#a68966] hover:bg-[#bf9e73] text-[#0a0a1a] py-3 font-mono text-xs uppercase tracking-widest font-bold rounded-sm transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xl"
              >
                {isAuthenticating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#0a0a1a] border-t-transparent rounded-full animate-spin" />
                    <span>Conducting security check...</span>
                  </>
                ) : (
                  <span>Initialize Cryptographic Sweep</span>
                )}
              </button>

            </form>

            <div className="text-center pt-6 text-[10px] font-mono text-[#f5f2ed]/40">
              FSCS DEPOSIT ASSURED UP TO £85,000
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
