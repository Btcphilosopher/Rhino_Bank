export interface Transaction {
  id: string;
  date: string;
  reference: string;
  category: "Salary" | "Housing" | "Transport" | "Investments" | "Business" | "Lifestyle" | "Treasury" | "Transfer" | "Leisure";
  amount: number; // positive for credit, negative for debit
  status: "Completed" | "Pending" | "Processing" | "Flagged";
}

export interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  sortCode: string;
  balance: number;
  type: "Personal Current" | "Sovereign Savings" | "Heritage Investment" | "Business Checking" | "Treasury Reserve";
}

export interface CardConfig {
  id: string;
  holder: string;
  cardNumber: string; // masked except last 4
  expiry: string;
  type: "Yorkshire Obsidian" | "Sovereign Brass";
  isFrozen: boolean;
  limits: {
    dailyContactless: number;
    dailyAtm: number;
    monthlyOnline: number;
  };
  allowedFeatures: {
    contactless: boolean;
    international: boolean;
    atm: boolean;
  };
}

export interface SavingsGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  category: string;
}

export interface BusinessInvoice {
  id: string;
  clientName: string;
  amount: number;
  issueDate: string;
  dueDate: string;
  status: "Paid" | "Outstanding" | "Overdue";
  description: string;
}

export interface FxRate {
  pair: string;
  rate: number;
  change: number; // positive or negative percentage
}

export interface ChatMessage {
  id: string;
  sender: "user" | "advisor";
  content: string;
  timestamp: string;
}
