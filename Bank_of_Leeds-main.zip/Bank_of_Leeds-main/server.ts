import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialize Gemini client to avoid startup crashes if key is missing
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// API endpoint for Chat Advisory
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    
    if (!message) {
       res.status(400).json({ error: "Message is required" });
       return;
    }
    
    const client = getAiClient();
    const chatHistory = history || [];
    
    const systemInstruction = `You are the Wellington Suite Advisory AI, the premium private banking and financial strategy director representing the BANK OF LEEDS (headquartered in Wellington Place, Leeds, Yorkshire).
You are extremely professional, eloquent, understated, and highly intelligent. You represent a 21st-century British merchant banking institution—confident, trustworthy, and architecturally beautiful.
Your role is to assist high-net-worth individuals, business founders, and institutional clients.
Avoid sounding like a generic fintech startup or a dry traditional high-street teller.
When discussing services, refer to Bank of Leeds' flagship offerings:
- Sovereign Personal Accounts & Yorkshire Obsidian Cards
- Leeds Heritage Portfolio (ISAs & estate planning)
- Granite Fixed Saver accounts
- Wellington Commercial Loans (infrastructure and manufacturing finance)
- Granary Wharf Treasury Management

You have a deep pride in Yorkshire's industrial, textile, and financial legacy. You may use elegant British spelling (e.g., colour, programme, idealised, customisation) and subtly reference the commercial strength of Leeds as one of Europe's leading financial capitals.
Keep your responses precise, structured with clear paragraphs or bullet points, and incredibly helpful. Make sure to present your insights as high-end strategic guidance rather than certified legal/financial advice.`;

    const chat = client.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction,
        temperature: 0.7,
      },
      history: chatHistory.map((h: any) => ({
        role: h.role,
        parts: [{ text: h.content }]
      }))
    });

    const response = await chat.sendMessage({ message });
    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ 
      error: error.message || "An unexpected error occurred in our advisory engine." 
    });
  }
});

// Setup Vite dev server or serve production static assets
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Bank of Leeds Server running at http://localhost:${PORT}`);
  });
}

bootstrap();
