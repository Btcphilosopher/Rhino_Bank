"""
RHINOQUANT CHINA MBS - Loss Allocation & Waterfall Engine (Python Module)
Executes sequential payment waterfall & tranche loss absorption.
"""

from typing import List, Dict, Any

class WaterfallEngine:
    def __init__(self, tranches: List[Dict[str, Any]]):
        """
        Tranche input format:
        [
          {"name": "A1", "priority": 1, "balance": 500000000, "coupon": 0.032, "seniority": "SENIOR"},
          {"name": "B", "priority": 2, "balance": 150000000, "coupon": 0.042, "seniority": "MEZZANINE"},
          {"name": "EQ", "priority": 3, "balance": 50000000, "coupon": 0.085, "seniority": "EQUITY"}
        ]
        """
        self.tranches = sorted(tranches, key=lambda x: x["priority"])

    def execute_month(self, distributable_cash: float, pool_loss: float) -> Dict[str, Any]:
        payouts = {}
        avail_cash = distributable_cash

        # 1. Pay Interest by Priority
        for tr in self.tranches:
            if tr["balance"] <= 0:
                continue
            interest_due = (tr["balance"] * tr["coupon"]) / 12.0
            interest_paid = min(avail_cash, interest_due)
            avail_cash -= interest_paid

            payouts[tr["name"]] = {
                "interest_paid": interest_paid,
                "principal_paid": 0.0,
                "loss_allocated": 0.0,
                "ending_balance": tr["balance"]
            }

        # 2. Pay Principal by Priority
        for tr in self.tranches:
            if avail_cash <= 0 or tr["balance"] <= 0:
                break
            principal_paid = min(avail_cash, tr["balance"])
            tr["balance"] -= principal_paid
            avail_cash -= principal_paid

            payouts[tr["name"]]["principal_paid"] = principal_paid
            payouts[tr["name"]]["ending_balance"] = tr["balance"]

        # 3. Absorb Loss by Reverse Seniority (Equity -> Subordinate -> Senior)
        remaining_loss = pool_loss
        for tr in reversed(self.tranches):
            if remaining_loss <= 0:
                break
            if tr["balance"] <= 0:
                continue
            loss_absorbed = min(remaining_loss, tr["balance"])
            tr["balance"] -= loss_absorbed
            remaining_loss -= loss_absorbed

            payouts[tr["name"]]["loss_allocated"] = loss_absorbed
            payouts[tr["name"]]["ending_balance"] = tr["balance"]

        return {
            "payouts": payouts,
            "residual_cash": avail_cash,
            "unabsorbed_loss": remaining_loss
        }
