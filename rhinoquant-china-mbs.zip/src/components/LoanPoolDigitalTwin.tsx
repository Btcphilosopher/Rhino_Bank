import React, { useState } from 'react';
import { LoanPool, LoanStatus } from '../types/mbs';
import { MapPin, Building2, User, AlertTriangle, CheckCircle, RefreshCw, Eye } from 'lucide-react';

interface LoanPoolDigitalTwinProps {
  pools: LoanPool[];
}

export const LoanPoolDigitalTwin: React.FC<LoanPoolDigitalTwinProps> = ({ pools }) => {
  const [selectedPoolId, setSelectedPoolId] = useState<string>(pools[0]?.pool_id || '');
  const [selectedCity, setSelectedCity] = useState<string>('ALL');

  const pool = pools.find((p) => p.pool_id === selectedPoolId) || pools[0];

  const regions = [
    { name: '北京', balance: 45.2, ltv: 0.54, defaultRate: 0.18, color: 'emerald' },
    { name: '上海', balance: 52.8, ltv: 0.52, defaultRate: 0.15, color: 'emerald' },
    { name: '深圳', balance: 38.6, ltv: 0.59, defaultRate: 0.28, color: 'cyan' },
    { name: '广州', balance: 29.4, ltv: 0.61, defaultRate: 0.32, color: 'cyan' },
    { name: '杭州', balance: 31.0, ltv: 0.58, defaultRate: 0.22, color: 'emerald' },
    { name: '成都', balance: 22.5, ltv: 0.65, defaultRate: 0.42, color: 'amber' },
    { name: '南京', balance: 18.9, ltv: 0.60, defaultRate: 0.25, color: 'cyan' },
    { name: '武汉', balance: 16.2, ltv: 0.67, defaultRate: 0.55, color: 'amber' },
    { name: '西安', balance: 14.1, ltv: 0.68, defaultRate: 0.58, color: 'amber' },
    { name: '苏州', balance: 19.8, ltv: 0.56, defaultRate: 0.20, color: 'emerald' }
  ];

  // Simulated Individual Loan Items for Digital Twin Drill-Down
  const sampleLoans = Array.from({ length: 12 }).map((_, idx) => ({
    loanId: `LN-2026-${(idx + 101).toString()}`,
    borrowerId: `BRW-${(8000 + idx).toString()}`,
    city: regions[idx % regions.length].name,
    originalBal: 2500000 + (idx % 5) * 800000,
    currentBal: Math.round((2500000 + (idx % 5) * 800000) * (0.75 - idx * 0.02)),
    rate: 0.0345 + (idx % 4) * 0.0015,
    ltv: 0.55 + (idx % 5) * 0.04,
    dsti: 0.35 + (idx % 3) * 0.05,
    status: idx === 7 ? LoanStatus.DELINQUENT_30 : idx === 11 ? LoanStatus.PREPAID : LoanStatus.PERFORMING
  }));

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Pool Header & Selector */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <Building2 className="w-4 h-4 text-cyan-400" />
          <span className="text-slate-400">选择资产池:</span>
          <select
            value={selectedPoolId}
            onChange={(e) => setSelectedPoolId(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-cyan-400 font-bold px-3 py-1.5 rounded focus:outline-none focus:border-cyan-500"
          >
            {pools.map((p) => (
              <option key={p.pool_id} value={p.pool_id}>
                {p.pool_id} - {p.name} (贷款数: {p.loan_count}笔)
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-4 text-slate-400">
          <div>
            加权平均利率 (WAC): <span className="text-emerald-400 font-bold">{(pool.weighted_average_coupon * 100).toFixed(2)}%</span>
          </div>
          <div>
            加权平均期限 (WAM): <span className="text-cyan-400 font-bold">{pool.weighted_average_maturity} 月</span>
          </div>
          <div>
            加权平均LTV: <span className="text-amber-400 font-bold">{(pool.weighted_average_ltv * 100).toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {/* Region Distribution & Map Cards */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3 text-xs">
          <div className="flex items-center space-x-2 font-bold text-slate-200">
            <MapPin className="w-4 h-4 text-cyan-400" />
            <span>全国合成住房贷款池地区风险分布与 LTV 压力阵列</span>
          </div>
          <span className="text-slate-400">合成数据集 • 包含15个重点城市资产分布</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {regions.map((reg) => (
            <div
              key={reg.name}
              className={`p-3 rounded border transition-colors cursor-pointer ${
                selectedCity === reg.name
                  ? 'bg-slate-800 border-cyan-500'
                  : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
              }`}
              onClick={() => setSelectedCity(reg.name === selectedCity ? 'ALL' : reg.name)}
            >
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-100">{reg.name}</span>
                <span className="text-[10px] text-slate-400">¥{reg.balance}亿</span>
              </div>

              <div className="mt-2 space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>平均LTV:</span>
                  <span className="font-bold text-slate-200">{(reg.ltv * 100).toFixed(0)}%</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>预期违约率:</span>
                  <span className="font-bold text-emerald-400">{reg.defaultRate}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* LTV vs Credit Score Risk Matrix Heatmap & Delinquency State Machine */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* Risk Matrix */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="font-bold text-slate-200 mb-3 border-b border-slate-800 pb-2">
            地区 × LTV × 信用评级 交叉风险矩阵 (LTV Matrix)
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse text-[11px]">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <th className="p-2 text-left">LTV 区间</th>
                  <th className="p-2">AAA 级</th>
                  <th className="p-2">AA 级</th>
                  <th className="p-2">A 级</th>
                  <th className="p-2">BBB 及以下</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                <tr>
                  <td className="p-2 text-left font-bold text-slate-300">&lt; 50%</td>
                  <td className="p-2 bg-emerald-950/40 text-emerald-400 font-bold">0.05%</td>
                  <td className="p-2 bg-emerald-950/30 text-emerald-400">0.08%</td>
                  <td className="p-2 bg-emerald-950/20 text-emerald-300">0.12%</td>
                  <td className="p-2 bg-slate-950 text-slate-300">0.25%</td>
                </tr>
                <tr>
                  <td className="p-2 text-left font-bold text-slate-300">50% - 65%</td>
                  <td className="p-2 bg-emerald-950/30 text-emerald-400">0.10%</td>
                  <td className="p-2 bg-emerald-950/20 text-emerald-300">0.18%</td>
                  <td className="p-2 bg-cyan-950/30 text-cyan-300">0.32%</td>
                  <td className="p-2 bg-amber-950/30 text-amber-300">0.65%</td>
                </tr>
                <tr>
                  <td className="p-2 text-left font-bold text-slate-300">65% - 75%</td>
                  <td className="p-2 bg-emerald-950/20 text-emerald-300">0.22%</td>
                  <td className="p-2 bg-cyan-950/30 text-cyan-300">0.45%</td>
                  <td className="p-2 bg-amber-950/40 text-amber-300 font-bold">0.85%</td>
                  <td className="p-2 bg-rose-950/40 text-rose-400 font-bold">1.45%</td>
                </tr>
                <tr>
                  <td className="p-2 text-left font-bold text-slate-300">&gt; 75%</td>
                  <td className="p-2 bg-amber-950/30 text-amber-300">0.50%</td>
                  <td className="p-2 bg-amber-950/40 text-amber-300 font-bold">0.95%</td>
                  <td className="p-2 bg-rose-950/50 text-rose-400 font-bold">2.10%</td>
                  <td className="p-2 bg-rose-950/80 text-rose-300 font-extrabold">4.80%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* State Machine Transition Diagram */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="font-bold text-slate-200 mb-3 border-b border-slate-800 pb-2">
            住房贷款事件驱动状态机 (Loan Event State Machine)
          </div>

          <div className="space-y-2.5 text-[11px] font-mono">
            <div className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
              <span className="flex items-center space-x-1.5 text-emerald-400 font-bold">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>正常 (PERFORMING)</span>
              </span>
              <span className="text-slate-400">池占比 98.2%</span>
            </div>

            <div className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
              <span className="flex items-center space-x-1.5 text-amber-400 font-bold">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>逾期30天 (DELINQUENT_30)</span>
              </span>
              <span className="text-slate-400">池占比 1.1%</span>
            </div>

            <div className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
              <span className="flex items-center space-x-1.5 text-rose-400 font-bold">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>违约/止赎 (DEFAULTED / FORECLOSURE)</span>
              </span>
              <span className="text-slate-400">池占比 0.3% (处置回收率 75.0%)</span>
            </div>

            <div className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
              <span className="flex items-center space-x-1.5 text-cyan-400 font-bold">
                <RefreshCw className="w-3.5 h-3.5" />
                <span>提前偿还/结清 (PREPAID / PAYOFF)</span>
              </span>
              <span className="text-slate-400">3M CPR: 8.5%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Loan Level Digital Twin Drilldown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
            <Eye className="w-4 h-4 text-cyan-400" />
            <span>底册住房贷款逐笔穿透明细 (Loan Level Digital Twin Drilldown)</span>
          </div>
          <span className="text-xs text-slate-400">显示样本 12 笔 / 共 100,000+ 笔底层贷款</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3 font-medium">贷款ID</th>
                <th className="p-3 font-medium">借款人ID</th>
                <th className="p-3 font-medium">房屋地区</th>
                <th className="p-3 font-medium text-right">初始余额 (元)</th>
                <th className="p-3 font-medium text-right">当前余额 (元)</th>
                <th className="p-3 font-medium text-right">利率</th>
                <th className="p-3 font-medium text-right">LTV</th>
                <th className="p-3 font-medium text-right">债务收入比 (DSTI)</th>
                <th className="p-3 font-medium text-center">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {sampleLoans.map((loan) => (
                <tr key={loan.loanId} className="hover:bg-slate-800/40">
                  <td className="p-3 text-cyan-400 font-bold">{loan.loanId}</td>
                  <td className="p-3 text-slate-300">{loan.borrowerId}</td>
                  <td className="p-3 font-bold text-slate-200">{loan.city}</td>
                  <td className="p-3 text-right text-slate-300">¥{loan.originalBal.toLocaleString()}</td>
                  <td className="p-3 text-right text-slate-100 font-bold">¥{loan.currentBal.toLocaleString()}</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">{(loan.rate * 100).toFixed(2)}%</td>
                  <td className="p-3 text-right text-slate-200">{(loan.ltv * 100).toFixed(1)}%</td>
                  <td className="p-3 text-right text-slate-300">{(loan.dsti * 100).toFixed(1)}%</td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        loan.status === LoanStatus.PERFORMING
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : loan.status === LoanStatus.PREPAID
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}
                    >
                      {loan.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
