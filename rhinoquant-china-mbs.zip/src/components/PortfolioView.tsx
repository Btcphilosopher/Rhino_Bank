import React from 'react';
import { PortfolioSummary } from '../types/mbs';
import { Wallet, TrendingUp, ShieldAlert, BarChart, ArrowUpRight, PieChart } from 'lucide-react';

interface PortfolioViewProps {
  fund: PortfolioSummary | null;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({ fund }) => {
  if (!fund) return null;

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Fund Overview Hero Metrics */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
          <div className="flex items-center space-x-2 text-sm font-bold text-slate-100">
            <Wallet className="w-4 h-4 text-cyan-400" />
            <span>{fund.fund_name}</span>
          </div>
          <span className="text-xs bg-cyan-950 text-cyan-300 px-2.5 py-1 rounded border border-cyan-800">
            虚拟机构基金 (虚拟资本: 100亿人民币)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <div className="text-slate-400">总资产规模 (AUM)</div>
            <div className="text-xl font-bold text-slate-100 mt-1">
              ¥{(fund.aum / 1e8).toFixed(2)} 亿元
            </div>
            <div className="text-slate-500 text-[11px] mt-1">
              现金: ¥{(fund.cash_balance / 1e8).toFixed(2)}亿
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <div className="text-slate-400">未实现盈亏 (Unrealized P&L)</div>
            <div className="text-xl font-bold text-emerald-400 mt-1">
              +¥{(fund.unrealized_pnl / 10000).toFixed(1)} 万元
            </div>
            <div className="text-slate-500 text-[11px] mt-1">今日变动: +¥{(fund.daily_pnl / 10000).toFixed(1)}万</div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <div className="text-slate-400">组合加权收益率 / 久期</div>
            <div className="text-xl font-bold text-cyan-400 mt-1">
              {(fund.portfolio_yield * 100).toFixed(2)}% / {fund.portfolio_duration}年
            </div>
            <div className="text-slate-500 text-[11px] mt-1">WAL: 3.82 年</div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <div className="text-slate-400">DV01 利率敏感度</div>
            <div className="text-xl font-bold text-amber-400 mt-1">
              ¥{(fund.portfolio_dv01 / 10000).toFixed(2)} 万元/bp
            </div>
            <div className="text-slate-500 text-[11px] mt-1">100bp 冲击: ¥{(fund.portfolio_dv01 * 100 / 1e8).toFixed(2)}亿</div>
          </div>
        </div>
      </div>

      {/* Risk Metrics Cards (VaR & Expected Shortfall) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-2">
          <div className="flex items-center space-x-2 text-rose-400 font-bold border-b border-slate-800 pb-2">
            <ShieldAlert className="w-4 h-4" />
            <span>组合量化风险价值 (VaR & Expected Shortfall)</span>
          </div>
          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">95% 1日在风险价值 (1-Day VaR):</span>
              <span className="font-bold text-rose-400">¥{(fund.var_95_1d / 10000).toFixed(2)} 万元</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">预期损失尾部 (Expected Shortfall):</span>
              <span className="font-bold text-rose-300">¥{(fund.expected_shortfall / 10000).toFixed(2)} 万元</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">模拟蒙特卡洛路径数:</span>
              <span className="font-bold text-cyan-400">10,000 路径</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-2">
          <div className="flex items-center space-x-2 text-cyan-400 font-bold border-b border-slate-800 pb-2">
            <PieChart className="w-4 h-4" />
            <span>持仓信用评级与资产结构分布 (Credit Rating Exposure)</span>
          </div>
          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">AAA 级优先 tranche:</span>
              <span className="font-bold text-emerald-400">75.0% (¥{(fund.total_market_value * 0.75 / 1e8).toFixed(2)}亿)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">AA 级夹层 tranche:</span>
              <span className="font-bold text-cyan-400">15.0% (¥{(fund.total_market_value * 0.15 / 1e8).toFixed(2)}亿)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">A+ 级次级 tranche:</span>
              <span className="font-bold text-amber-400">10.0% (¥{(fund.total_market_value * 0.10 / 1e8).toFixed(2)}亿)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Position Details Table */}
      <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
            <BarChart className="w-4 h-4 text-cyan-400" />
            <span>RhinoQuant China Fund 持仓明细 (Position Breakdown)</span>
          </div>
          <span className="text-xs text-slate-400">持仓笔数: {fund.positions.length} 笔</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3 font-medium">持仓ID</th>
                <th className="p-3 font-medium">分层名称</th>
                <th className="p-3 font-medium">评级</th>
                <th className="p-3 font-medium text-right">面额数量 (元)</th>
                <th className="p-3 font-medium text-right">持仓市值 (元)</th>
                <th className="p-3 font-medium text-right">未实现盈亏 (元)</th>
                <th className="p-3 font-medium text-right">到期收益率</th>
                <th className="p-3 font-medium text-right">久期 (年)</th>
                <th className="p-3 font-medium text-right">DV01 (元/bp)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {fund.positions.map((pos) => (
                <tr key={pos.position_id} className="hover:bg-slate-800/40">
                  <td className="p-3 text-cyan-400 font-bold">{pos.position_id}</td>
                  <td className="p-3 font-bold text-slate-200">{pos.tranche_name}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      {pos.credit_rating}
                    </span>
                  </td>
                  <td className="p-3 text-right text-slate-300">¥{pos.par_value.toLocaleString()}</td>
                  <td className="p-3 text-right text-slate-100 font-bold">¥{pos.market_value.toLocaleString()}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">
                    +¥{pos.unrealized_pnl.toLocaleString()}
                  </td>
                  <td className="p-3 text-right text-emerald-400">{(pos.yield_to_maturity * 100).toFixed(2)}%</td>
                  <td className="p-3 text-right text-slate-300">{pos.duration}</td>
                  <td className="p-3 text-right text-amber-300 font-bold">¥{pos.dv01.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
