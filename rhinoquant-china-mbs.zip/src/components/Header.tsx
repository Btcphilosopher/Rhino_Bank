import React from 'react';
import { Activity, ShieldCheck, Database, Cpu, Terminal, TrendingUp, AlertTriangle } from 'lucide-react';
import { PortfolioSummary } from '../types/mbs';

interface HeaderProps {
  fund: PortfolioSummary | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  invariantStatus: { total: number; passed: number } | null;
}

export const Header: React.FC<HeaderProps> = ({
  fund,
  activeTab,
  setActiveTab,
  invariantStatus
}) => {
  const tabs = [
    { id: 'market', label: '市场终端' },
    { id: 'research', label: '证券研究' },
    { id: 'pool_twin', label: '贷款池透视' },
    { id: 'cashflow', label: '现金流与瀑布' },
    { id: 'trading', label: '模拟交易' },
    { id: 'portfolio', label: '投资组合' },
    { id: 'scenarios', label: '风险情景' },
    { id: 'disclosure', label: '存续期与披露' },
    { id: 'ai_intelligence', label: 'AI智库' },
    { id: 'code_browser', label: '系统工程' },
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 font-mono text-sm">
      {/* Top Banner */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 bg-slate-900/90">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-slate-800 px-2.5 py-1 rounded border border-slate-700">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span className="font-bold tracking-wider text-slate-100">RHINOQUANT</span>
            <span className="text-xs bg-cyan-950 text-cyan-300 px-1.5 py-0.5 rounded border border-cyan-800">CHINA MBS</span>
          </div>
          <span className="text-xs text-slate-400 hidden lg:inline">中国住房抵押贷款证券化定价与交易操作系统 v3.5</span>
        </div>

        {/* Top Fund Ticker Bar */}
        {fund && (
          <div className="hidden md:flex items-center space-x-6 text-xs">
            <div>
              <span className="text-slate-400">基金AUM: </span>
              <span className="text-cyan-400 font-bold">¥{(fund.aum / 1e8).toFixed(2)} 亿</span>
            </div>
            <div>
              <span className="text-slate-400">日P&L: </span>
              <span className="text-emerald-400 font-bold">+¥{(fund.daily_pnl / 10000).toFixed(1)} 万</span>
            </div>
            <div>
              <span className="text-slate-400">组合收益率: </span>
              <span className="text-slate-200 font-bold">{(fund.portfolio_yield * 100).toFixed(2)}%</span>
            </div>
            <div>
              <span className="text-slate-400">久期: </span>
              <span className="text-slate-200 font-bold">{fund.portfolio_duration} 年</span>
            </div>
            <div>
              <span className="text-slate-400">DV01: </span>
              <span className="text-amber-400 font-bold">¥{(fund.portfolio_dv01 / 10000).toFixed(2)} 万/bp</span>
            </div>
          </div>
        )}

        {/* Live System Badges */}
        <div className="flex items-center space-x-3 text-xs">
          {invariantStatus && (
            <div className="flex items-center space-x-1 px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>金融不变量: {invariantStatus.passed}/{invariantStatus.total} 通过</span>
            </div>
          )}
          <div className="flex items-center space-x-1.5 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs text-emerald-400">系统就绪</span>
          </div>
        </div>
      </div>

      {/* Navigation Tab Bar */}
      <div className="flex items-center space-x-1 px-2 overflow-x-auto scrollbar-none bg-slate-950">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 text-xs font-medium border-b-2 transition-colors whitespace-nowrap flex items-center space-x-1.5 ${
                isActive
                  ? 'border-cyan-500 text-cyan-400 bg-slate-900/60 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/30'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
