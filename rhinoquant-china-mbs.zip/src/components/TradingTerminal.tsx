import React, { useState } from 'react';
import { Security, AccountingEntry } from '../types/mbs';
import { DollarSign, Send, FileText, CheckCircle2, ArrowRightLeft, BookOpen, Clock } from 'lucide-react';

interface TradingTerminalProps {
  securities: Security[];
  accountingEntries: AccountingEntry[];
  onTradeSubmitted: () => void;
}

export const TradingTerminal: React.FC<TradingTerminalProps> = ({
  securities,
  accountingEntries,
  onTradeSubmitted
}) => {
  const [selectedSecId, setSelectedSecId] = useState<string>(securities[0]?.security_id || '');
  const [selectedTrancheId, setSelectedTrancheId] = useState<string>(securities[0]?.tranches[0]?.tranche_id || '');
  const [tradeSide, setTradeSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'LIMIT' | 'MARKET'>('LIMIT');
  const [price, setPrice] = useState<number>(100.25);
  const [quantityPar, setQuantityPar] = useState<number>(50000000); // 5000万 Par
  const [counterparty, setCounterparty] = useState<string>('中国工商银行固定收益交易部 (虚拟库)');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [lastTradeResult, setLastTradeResult] = useState<any>(null);

  const currentSec = securities.find((s) => s.security_id === selectedSecId) || securities[0];

  const handleSecChange = (secId: string) => {
    setSelectedSecId(secId);
    const sec = securities.find((s) => s.security_id === secId);
    if (sec && sec.tranches.length > 0) {
      setSelectedTrancheId(sec.tranches[0].tranche_id);
      setPrice(sec.tranches[0].clean_price);
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tranche_id: selectedTrancheId,
          side: tradeSide,
          price,
          quantity: quantityPar,
          counterparty
        })
      });

      const data = await res.json();
      setLastTradeResult(data);
      onTradeSubmitted();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Order Entry Form */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-3">
          <div className="flex items-center space-x-2 font-bold text-xs text-cyan-400 border-b border-slate-800 pb-2">
            <ArrowRightLeft className="w-4 h-4" />
            <span>中国 MBS 模拟交易下单终端 (Order Entry)</span>
          </div>

          <form onSubmit={handleSubmitOrder} className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">选择目标 MBS 证券:</label>
              <select
                value={selectedSecId}
                onChange={(e) => handleSecChange(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 p-2 rounded focus:outline-none focus:border-cyan-500"
              >
                {securities.map((s) => (
                  <option key={s.security_id} value={s.security_id}>
                    {s.ticker} - {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">选择交易分层:</label>
              <select
                value={selectedTrancheId}
                onChange={(e) => {
                  setSelectedTrancheId(e.target.value);
                  const tr = currentSec.tranches.find((t) => t.tranche_id === e.target.value);
                  if (tr) setPrice(tr.clean_price);
                }}
                className="w-full bg-slate-950 border border-slate-700 text-cyan-300 font-bold p-2 rounded focus:outline-none focus:border-cyan-500"
              >
                {currentSec.tranches.map((t) => (
                  <option key={t.tranche_id} value={t.tranche_id}>
                    {t.tranche_name} ({t.rating_agency_rating}) - 净价: {t.clean_price}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-1">买卖方向:</label>
                <div className="grid grid-cols-2 gap-1">
                  <button
                    type="button"
                    onClick={() => setTradeSide('BUY')}
                    className={`py-1.5 rounded font-bold transition-colors ${
                      tradeSide === 'BUY'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-950 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    买入 (BUY)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTradeSide('SELL')}
                    className={`py-1.5 rounded font-bold transition-colors ${
                      tradeSide === 'SELL'
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-950 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    卖出 (SELL)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">订单类型:</label>
                <select
                  value={orderType}
                  onChange={(e: any) => setOrderType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 text-slate-200 p-2 rounded focus:outline-none focus:border-cyan-500"
                >
                  <option value="LIMIT">限价单 (Limit)</option>
                  <option value="MARKET">市价单 (Market)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">委托净价 (Clean Price):</label>
              <input
                type="number"
                step="0.01"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">面额数量 (Par Amount RMB):</label>
              <input
                type="number"
                step="1000000"
                value={quantityPar}
                onChange={(e) => setQuantityPar(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded font-mono focus:outline-none focus:border-cyan-500"
              />
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                即 ¥{(quantityPar / 10000).toFixed(0)} 万元面额
              </span>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">交易对手 (Counterparty):</label>
              <input
                type="text"
                value={counterparty}
                onChange={(e) => setCounterparty(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-300 p-2 rounded focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="pt-2 border-t border-slate-800">
              <div className="flex justify-between text-xs mb-2">
                <span className="text-slate-400">成交总金额:</span>
                <span className="font-bold text-emerald-400 font-mono">
                  ¥{((quantityPar * price) / 100).toLocaleString()} 元
                </span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-2.5 rounded font-bold transition-colors flex items-center justify-center space-x-2 ${
                  tradeSide === 'BUY'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-rose-600 hover:bg-rose-500 text-white'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? '提交交割中...' : `确认提交 ${tradeSide === 'BUY' ? '买入' : '卖出'} 订单`}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Order Book & Last Trade Result */}
        <div className="lg:col-span-2 space-y-4">
          {/* Recent Trade Result Banner */}
          {lastTradeResult && (
            <div className="bg-emerald-950/40 border border-emerald-800 p-3 rounded text-xs flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <div>
                  <div className="font-bold text-emerald-300">
                    订单已实时成交清算: {lastTradeResult.trade_id}
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    {lastTradeResult.secTicker} - {lastTradeResult.trancheName} | 面额: ¥
                    {(lastTradeResult.quantity / 10000).toFixed(0)}万元 | 结算金额: ¥
                    {lastTradeResult.totalAmount.toLocaleString()}元
                  </div>
                </div>
              </div>
              <span className="px-2 py-1 bg-emerald-900 text-emerald-300 rounded text-[10px] font-bold">
                已平账结算
              </span>
            </div>
          )}

          {/* Double-Entry Accounting Ledger (Debits = Credits) */}
          <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden text-xs">
            <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center space-x-2 font-bold text-slate-200">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <span>复式记账双重会计凭证审计 (Double-Entry Accounting Ledger)</span>
              </div>
              <span className="text-emerald-400 font-bold">借方 = 贷方 100% 守恒</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <th className="p-3 font-medium">凭证号</th>
                    <th className="p-3 font-medium">时间</th>
                    <th className="p-3 font-medium">摘要</th>
                    <th className="p-3 font-medium">借方科目 (Debit)</th>
                    <th className="p-3 font-medium">贷方科目 (Credit)</th>
                    <th className="p-3 font-medium text-right">金额 (元)</th>
                    <th className="p-3 font-medium text-center">试算平衡</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {accountingEntries.map((entry) => (
                    <tr key={entry.entry_id} className="hover:bg-slate-800/40">
                      <td className="p-3 text-cyan-400 font-bold">{entry.entry_id}</td>
                      <td className="p-3 text-slate-400">{entry.timestamp}</td>
                      <td className="p-3 font-medium text-slate-200">{entry.description}</td>
                      <td className="p-3 text-emerald-400">{entry.debits[0]?.account}</td>
                      <td className="p-3 text-amber-400">{entry.credits[0]?.account}</td>
                      <td className="p-3 text-right font-bold text-slate-100">
                        ¥{entry.debits[0]?.amount.toLocaleString()}
                      </td>
                      <td className="p-3 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                          借贷平
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
