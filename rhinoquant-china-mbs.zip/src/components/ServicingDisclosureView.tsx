import React from 'react';
import { LoanPool, Security } from '../types/mbs';
import { FileText, Shield, Network, ArrowRight, Download, CheckCircle } from 'lucide-react';

interface ServicingDisclosureViewProps {
  pools: LoanPool[];
  securities: Security[];
}

export const ServicingDisclosureView: React.FC<ServicingDisclosureViewProps> = ({ pools, securities }) => {
  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Full Data Lineage Backward Tracer Card */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-3">
        <div className="flex items-center space-x-2 font-bold text-xs text-cyan-400 border-b border-slate-800 pb-2">
          <Network className="w-4 h-4" />
          <span>全生命周期数据与模型血缘溯源图 (Full Life-Cycle Data & Model Lineage Tracer)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-6 gap-2 text-center text-xs">
          <div className="p-3 bg-slate-950 rounded border border-cyan-800/60">
            <div className="text-cyan-400 font-bold">1. NAV 资产净值</div>
            <div className="text-[10px] text-slate-400 mt-1">¥100.25 亿</div>
          </div>
          <div className="flex items-center justify-center text-slate-600 hidden sm:flex">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="p-3 bg-slate-950 rounded border border-cyan-800/60">
            <div className="text-cyan-400 font-bold">2. 组合持仓</div>
            <div className="text-[10px] text-slate-400 mt-1">RhinoQuant Fund</div>
          </div>
          <div className="flex items-center justify-center text-slate-600 hidden sm:flex">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="p-3 bg-slate-950 rounded border border-cyan-800/60">
            <div className="text-cyan-400 font-bold">3. MBS 分层证券</div>
            <div className="text-[10px] text-slate-400 mt-1">优先 A1 / A2 / B</div>
          </div>
          <div className="flex items-center justify-center text-slate-600 hidden sm:flex">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="p-3 bg-slate-950 rounded border border-cyan-800/60">
            <div className="text-cyan-400 font-bold">4. 资产池 SPV</div>
            <div className="text-[10px] text-slate-400 mt-1">RHX-POOL-001</div>
          </div>
          <div className="flex items-center justify-center text-slate-600 hidden sm:flex">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="p-3 bg-slate-950 rounded border border-cyan-800/60">
            <div className="text-cyan-400 font-bold">5. 底层住房贷款</div>
            <div className="text-[10px] text-slate-400 mt-1">100,000+ 合成样本</div>
          </div>
          <div className="flex items-center justify-center text-slate-600 hidden sm:flex">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="p-3 bg-slate-950 rounded border border-cyan-800/60">
            <div className="text-cyan-400 font-bold">6. 抵押房产物权</div>
            <div className="text-[10px] text-slate-400 mt-1">一二线城市房产</div>
          </div>
        </div>
      </div>

      {/* Monthly Pool Servicing Report Template */}
      <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>受托机构月度信息披露与资产池服务报告 (Monthly Servicer Report)</span>
          </div>

          <button
            onClick={() => alert('已导出规范机构披露报告 XML / JSON')}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs flex items-center space-x-1"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出披露报告 (XML/JSON)</span>
          </button>
        </div>

        <div className="p-4 space-y-4 text-xs font-mono">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950 p-3 rounded border border-slate-800">
            <div>
              <span className="text-slate-400">报告期: </span>
              <span className="font-bold text-slate-100">2026年08期 (2026-08-01 至 2026-08-31)</span>
            </div>
            <div>
              <span className="text-slate-400">受托机构: </span>
              <span className="font-bold text-slate-100">中信信托有限责任公司 (合成受托人)</span>
            </div>
            <div>
              <span className="text-slate-400">资产服务机构: </span>
              <span className="font-bold text-slate-100">中国建设银行 (合成服务商)</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="font-bold text-cyan-300">资产池存续期本期变动数据汇总:</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400">期初本金余额:</div>
                <div className="font-bold text-slate-100 text-sm">¥10,000,000,000.00</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400">本期回收常规本金:</div>
                <div className="font-bold text-emerald-400 text-sm">¥125,400,000.00</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400">本期提前偿还本金:</div>
                <div className="font-bold text-cyan-400 text-sm">¥68,200,000.00</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400">本期违约损失额:</div>
                <div className="font-bold text-rose-400 text-sm">¥2,100,000.00</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
