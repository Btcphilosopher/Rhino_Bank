/**
 * RHINOQUANT CHINA MBS - Core Financial Domain Models
 */

// Loan Status Enum representing explicit State Machine transitions
export enum LoanStatus {
  PERFORMING = '正常',
  DELINQUENT_30 = '逾期30天',
  DELINQUENT_90 = '严重逾期',
  RESTRUCTURED = '重组',
  DEFAULTED = '违约',
  FORECLOSURE = '止赎',
  DISPOSITION = '处置',
  RECOVERED = '回收',
  PAYOFF = '结清',
  PREPAID = '提前偿还'
}

export interface Borrower {
  borrower_id: string;
  name_hash: string;
  age: number;
  monthly_income: number;
  debt_service_ratio: number; // DSTI %
  credit_score: number;
  credit_band: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB';
  employment_type: string;
  region: string;
}

export interface Property {
  property_id: string;
  address_code: string;
  region: string; // 北京, 上海, 深圳, 广州, 杭州, 成都, 武汉, etc.
  property_type: '普通住宅' | '高端住宅' | '保障性住房' | '公寓' | '商住两用';
  occupancy_type: '自住' | '出租' | '投资';
  origination_value: number; // RMB
  current_value: number;
  area_sqm: number;
}

export interface MortgageLoan {
  loan_id: string;
  borrower_id: string;
  property_id: string;
  origination_date: string;
  original_balance: number; // RMB
  current_balance: number; // RMB
  interest_rate: number; // Annual rate e.g. 0.0385 (3.85%)
  loan_term: number; // Total months e.g. 360
  remaining_term: number; // Remaining months e.g. 280
  seasoning: number; // Elapsed months e.g. 80
  payment_frequency: 'MONTHLY';
  amortisation_type: 'EQUAL_PAYMENT' | 'EQUAL_PRINCIPAL';
  monthly_pmt: number;
  loan_status: LoanStatus;
  property_value: number;
  loan_to_value: number; // LTV ratio e.g. 0.65
  region: string;
  credit_band: string;
  version: number;
}

export interface LoanPool {
  pool_id: string;
  name: string;
  originator: string; // Virtual Originator Bank e.g., RhinoQuant Synthetic Bank
  loan_count: number;
  original_balance: number;
  current_balance: number;
  weighted_average_coupon: number; // WAC (annual rate)
  weighted_average_maturity: number; // WAM (months)
  weighted_average_ltv: number; // WA-LTV
  weighted_average_age: number; // WAA (seasoning)
  regional_distribution: Record<string, number>; // Region -> Percentage
  property_distribution: Record<string, number>;
  credit_distribution: Record<string, number>;
  delinquency_distribution: Record<string, number>;
  cpr_3m: number; // 3-month CPR %
  default_rate_annual: number; // Annualized default rate %
}

export interface Tranche {
  tranche_id: string;
  security_id: string;
  tranche_name: string; // e.g. "A1", "A2", "B", "C", "Equity"
  priority: number; // 1 = Highest senior
  initial_balance: number;
  current_balance: number;
  coupon_rate: number; // Annual rate
  coupon_type: 'FIXED' | 'FLOATING';
  benchmark: string; // e.g., "LPR-1Y" or "FIXED"
  spread_bp: number;
  seniority: 'SENIOR' | 'MEZZANINE' | 'SUBORDINATE' | 'EQUITY';
  attachment_point: number; // % e.g. 0.15
  detachment_point: number; // % e.g. 1.00
  rating_agency_rating: 'AAA' | 'AA+' | 'AA' | 'A+' | 'BBB' | 'NR';
  clean_price: number;
  dirty_price: number;
  ytm: number;
  wal: number; // Weighted Average Life (years)
  duration: number; // Modified Duration
  convexity: number;
  dv01: number;
  z_spread: number;
  oas: number;
}

export interface SPV {
  spv_id: string;
  spv_name: string; // e.g., "RhinoQuant 2026-1 Mortgage Trust SPV"
  trustee: string; // Virtual Trustee
  servicer: string; // Virtual Servicer
  pool_id: string;
  total_asset_balance: number;
  total_securities_balance: number;
  overcollateralization: number;
  reserve_account_balance: number;
  excess_spread_ytd: number;
}

export interface Security {
  security_id: string;
  ticker: string; // e.g. RHX-CN-MBS-001
  name: string;
  spv_id: string;
  issue_date: string;
  maturity_date: string;
  total_issue_amount: number;
  current_total_balance: number;
  tranches: Tranche[];
  underlying_pool_id: string;
}

export interface MonthlyCashflow {
  month: number;
  date: string;
  beginning_balance: number;
  scheduled_principal: number;
  scheduled_interest: number;
  prepayment_principal: number;
  default_balance: number;
  recovery_amount: number;
  loss_amount: number;
  total_cash_available: number;
  servicing_fees: number;
  trustee_fees: number;
  net_cash_distributable: number;
  ending_balance: number;
  cpr_applied: number;
  smm_applied: number;
  pd_applied: number;
  lgd_applied: number;
}

export interface TrancheMonthlyPayout {
  month: number;
  tranche_id: string;
  tranche_name: string;
  beginning_balance: number;
  interest_due: number;
  interest_paid: number;
  principal_paid: number;
  loss_allocated: number;
  ending_balance: number;
}

export interface ScenarioConfig {
  scenario_id: string;
  name: string;
  rate_shift_bp: number; // e.g. +200, -100
  property_price_change_pct: number; // e.g. -0.20 for -20%
  cpr_multiplier: number; // e.g. 1.5x
  default_multiplier: number; // e.g. 2.0x
  recovery_rate_override?: number; // e.g. 0.60
}

export interface PortfolioPosition {
  position_id: string;
  security_id: string;
  tranche_id: string;
  security_name: string;
  tranche_name: string;
  holding_units: number;
  par_value: number;
  cost_basis: number;
  current_price: number;
  market_value: number;
  unrealized_pnl: number;
  realized_pnl: number;
  yield_to_maturity: number;
  duration: number;
  dv01: number;
  credit_rating: string;
}

export interface PortfolioSummary {
  fund_name: string;
  aum: number; // e.g. 10,000,000,000 RMB (100亿)
  cash_balance: number;
  total_market_value: number;
  daily_pnl: number;
  unrealized_pnl: number;
  portfolio_yield: number;
  portfolio_duration: number;
  portfolio_dv01: number;
  var_95_1d: number; // 95% 1-day Value at Risk
  expected_shortfall: number;
  positions: PortfolioPosition[];
}

export interface Order {
  order_id: string;
  security_id: string;
  tranche_id: string;
  side: 'BUY' | 'SELL';
  order_type: 'LIMIT' | 'MARKET';
  price: number;
  yield: number;
  quantity: number; // Par amount in RMB
  status: 'SUBMITTED' | 'EXECUTED' | 'PARTIAL' | 'CANCELLED' | 'SETTLED';
  counterparty: string;
  timestamp: string;
}

export interface AccountingEntry {
  entry_id: string;
  timestamp: string;
  event_type: string; // 'TRADE_SETTLEMENT' | 'CASHFLOW_RECEIPT' | 'LOSS_WRITEDOWN'
  description: string;
  debits: { account: string; amount: number }[];
  credits: { account: string; amount: number }[];
  is_balanced: boolean;
}

export interface AuditLogEvent {
  event_id: string;
  timestamp: string;
  user: string;
  action: string;
  target_object: string;
  old_value: string;
  new_value: string;
  model_version: string;
}

export interface FinancialInvariantResult {
  invariant_id: string;
  rule_id?: string;
  name: string;
  passed: boolean;
  expected: string;
  actual: string;
  diff: number;
  status_message: string;
  status?: 'PASSED' | 'FAILED';
  details?: string;
}

export type InvariantCheckResult = FinancialInvariantResult & {
  rule_id: string;
  status: 'PASSED' | 'FAILED';
  details: string;
};
