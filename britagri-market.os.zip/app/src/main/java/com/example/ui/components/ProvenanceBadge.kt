package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ObservationStatus
import com.example.data.model.ProvenanceSource
import com.example.ui.theme.*

@Composable
fun ProvenanceBadge(
    status: ObservationStatus,
    source: ProvenanceSource? = null,
    modifier: Modifier = Modifier
) {
    var showDialog by remember { mutableStateOf(false) }

    val (bgColor, textColor, borderColor) = when (status) {
        ObservationStatus.LIVE -> Triple(Color(0xFF064E3B), PriceGreen, PriceGreen)
        ObservationStatus.RECENT -> Triple(Color(0xFF0F3E2E), Color(0xFF6EE7B7), PriceGreen)
        ObservationStatus.DELAYED -> Triple(Color(0xFF3B1E06), Color(0xFFFBBF24), Color(0xFFFBBF24))
        ObservationStatus.PUBLISHED -> Triple(Color(0xFF1E3A8A), TerminalCyan, Color(0xFF60A5FA))
        ObservationStatus.MODELLED -> Triple(Color(0xFF4C1D95), Color(0xFFC084FC), Color(0xFFA855F7))
        ObservationStatus.SYNTHETIC -> Triple(Color(0xFF262C36), Color(0xFF94A3B8), Color(0xFF475569))
        ObservationStatus.INDICATIVE -> Triple(Color(0xFF78350F), GrainGold, GrainGold)
        ObservationStatus.ESTIMATED -> Triple(Color(0xFF334155), Color(0xFFCBD5E1), Color(0xFF64748B))
        ObservationStatus.FORECAST -> Triple(Color(0xFF431407), TerminalOrange, TerminalOrange)
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(3.dp))
            .border(0.75.dp, borderColor.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
            .clickable { showDialog = true }
            .padding(horizontal = 5.dp, vertical = 1.5.dp)
    ) {
        Text(
            text = if (source != null) "${status.label} • ${source.shortCode}" else status.label,
            color = textColor,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(
                    text = "DATA PROVENANCE & METHODOLOGY",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    color = GrainGold
                )
            },
            text = {
                androidx.compose.foundation.layout.Column {
                    Text(
                        text = "STATUS: ${status.name}",
                        color = textColor,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                    Text(
                        text = status.description,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                    )
                    if (source != null) {
                        Text(
                            text = "PRIMARY SOURCE: ${source.fullName} (${source.shortCode})",
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "UK Market Architecture Rule: Modelled & synthetic prices are strictly distinguished from observed transactions.",
                        color = TextMuted,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("OK", color = TerminalCyan, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = TerminalCardBackground
        )
    }
}
