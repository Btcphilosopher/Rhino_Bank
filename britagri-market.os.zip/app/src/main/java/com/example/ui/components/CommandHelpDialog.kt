package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CommandHelpDialog(
    onDismiss: () -> Unit,
    onRunCommand: (String) -> Unit
) {
    val quickCommands = listOf(
        "BRITAIN" to "Open 'Britain Now' flagship visual flight board",
        "WHEAT" to "Load UK Feed Wheat & Breadmaking Wheat terminal",
        "BARLEY" to "Load UK Feed & Malting Barley spot quotes",
        "MILK" to "Dairy Complex: Farmgate, Butter, SMP, Cheddar & AMPE/MCVE",
        "CATTLE" to "Finished Cattle R4L deadweight & liveweight quotes",
        "LAMB" to "Finished Lamb SQQ auction and abattoir quotes",
        "SELL" to "Farmer Netback Realisation & Grain Offer Board",
        "MILL" to "Flour Mill / Processor Raw Material Procurement Desk",
        "CURVES" to "Forward Curves, Regional Basis & Storage Carry Arbitrage",
        "DROUGHT" to "UK Drought Scenario: Soil moisture & shock propagation",
        "INVENTORY" to "UK Crop Balance Sheets & Storage Utilisation",
        "TWIN" to "Agricultural Digital Twin Network Graph"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "BRITAGRI TERMINAL COMMAND DIRECTORY",
                color = GrainGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "KEYBOARD SHORTCUTS & FUNCTION CODES",
                    color = TextGold,
                    fontSize = 10.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ALT+1: Britain Now • ALT+2: Screener • ALT+3: Farmer • ALT+4: Processor • ALT+5: Curves • ALT+6: Scenario Lab • ALT+7: Balance Sheet • ALT+8: Digital Twin",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = TerminalCardBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "SUPPORTED COMMAND STRINGS",
                    color = GrainGoldLight,
                    fontSize = 10.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                quickCommands.forEach { (cmd, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                onRunCommand(cmd)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text(
                                text = cmd,
                                color = TextGold,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = desc,
                            color = TextPrimary,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 8.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("CLOSE", color = TerminalCyan, fontFamily = FontFamily.Monospace)
            }
        },
        containerColor = TerminalCardBackground
    )
}
