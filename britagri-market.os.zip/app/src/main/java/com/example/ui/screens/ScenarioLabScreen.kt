package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScenarioDefinition
import com.example.ui.TerminalViewModel
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun ScenarioLabScreen(
    viewModel: TerminalViewModel
) {
    val scenarios = viewModel.repository.scenariosList
    val activeScenario by viewModel.activeScenario.collectAsState()

    var selectedScenario by remember { mutableStateOf(activeScenario ?: scenarios.first()) }

    // Custom Interactive Sliders
    var rainDeltaSlider by remember { mutableStateOf(selectedScenario.rainPct.toFloat()) }
    var fertDeltaSlider by remember { mutableStateOf(selectedScenario.fertiliserPct.toFloat()) }
    var dieselDeltaSlider by remember { mutableStateOf(selectedScenario.dieselPct.toFloat()) }

    // Dynamic Calculated Impacts based on sliders
    val dynamicWheatDelta = ((rainDeltaSlider * -0.45) + (fertDeltaSlider * 0.35) + (dieselDeltaSlider * 0.10))
    val dynamicMilkDelta = ((rainDeltaSlider * -0.28) + (fertDeltaSlider * 0.12) + (dieselDeltaSlider * 0.05))
    val dynamicBarleyDelta = ((rainDeltaSlider * -0.42) + (fertDeltaSlider * 0.30) + (dieselDeltaSlider * 0.08))

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Module Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "QUANTITATIVE SCENARIO & SHOCK PROPAGATION LAB",
                            color = GrainGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Computable Multi-Sector Agricultural Network Cascade Simulation",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }

                    ProvenanceBadge(
                        status = com.example.data.model.ObservationStatus.MODELLED,
                        source = com.example.data.model.ProvenanceSource.SYNTHETIC_ENGINE
                    )
                }
            }
        }

        // Scenario Preset Selector Pills
        item {
            Text(
                text = "MACRO & CLIMATE SHOCK PRESETS",
                color = GrainGoldLight,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                scenarios.forEach { sc ->
                    val isSel = selectedScenario.id == sc.id
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedScenario = sc
                                rainDeltaSlider = sc.rainPct.toFloat()
                                fertDeltaSlider = sc.fertiliserPct.toFloat()
                                dieselDeltaSlider = sc.dieselPct.toFloat()
                            }
                            .border(
                                width = if (isSel) 1.25.dp else 0.5.dp,
                                color = if (isSel) GrainGold else TerminalCardBorder,
                                shape = RoundedCornerShape(4.dp)
                            ),
                        color = if (isSel) BritishRacingGreen else TerminalCardBackground,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = sc.name,
                                    color = if (isSel) TextGold else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = sc.subtitle,
                                    color = TextMuted,
                                    fontSize = 8.5.sp
                                )
                            }
                            Text(
                                text = "RUN >>",
                                color = if (isSel) GrainGoldLight else TextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Interactive Shock Sliders
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "INTERACTIVE INPUT STRESS PARAMETERS",
                        color = GrainGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Rain Slider
                    Text(
                        text = "Rainfall Anomaly: ${rainDeltaSlider.roundToInt()}%",
                        color = TextPrimary,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Slider(
                        value = rainDeltaSlider,
                        onValueChange = { rainDeltaSlider = it },
                        valueRange = -50f..50f,
                        colors = SliderDefaults.colors(thumbColor = TerminalCyan, activeTrackColor = TerminalCyan)
                    )

                    // Fertiliser Slider
                    Text(
                        text = "Fertiliser Price Shock: +${fertDeltaSlider.roundToInt()}%",
                        color = TextPrimary,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Slider(
                        value = fertDeltaSlider,
                        onValueChange = { fertDeltaSlider = it },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = GrainGold, activeTrackColor = GrainGold)
                    )

                    // Diesel Slider
                    Text(
                        text = "Red Diesel / Freight Surcharge: +${dieselDeltaSlider.roundToInt()}%",
                        color = TextPrimary,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Slider(
                        value = dieselDeltaSlider,
                        onValueChange = { dieselDeltaSlider = it },
                        valueRange = 0f..60f,
                        colors = SliderDefaults.colors(thumbColor = PriceGreen, activeTrackColor = PriceGreen)
                    )
                }
            }
        }

        // Simulated Market Propagation Impact
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalDarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "COMPUTED COMMODITY PRICE IMPACT",
                        color = GrainGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ImpactBox(
                            title = "FEED WHEAT",
                            pct = dynamicWheatDelta,
                            spotEst = 186.40 * (1.0 + dynamicWheatDelta / 100.0),
                            unit = "£/t",
                            modifier = Modifier.weight(1f)
                        )
                        ImpactBox(
                            title = "FEED BARLEY",
                            pct = dynamicBarleyDelta,
                            spotEst = 164.80 * (1.0 + dynamicBarleyDelta / 100.0),
                            unit = "£/t",
                            modifier = Modifier.weight(1f)
                        )
                        ImpactBox(
                            title = "FARMGATE MILK",
                            pct = dynamicMilkDelta,
                            spotEst = 35.00 * (1.0 + dynamicMilkDelta / 100.0),
                            unit = "ppl",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Step-by-Step Propagation Waterfall
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "PHYSICAL CAUSAL TRANSMISSION PATHWAY",
                        color = GrainGold,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Field → Soil Moisture → Crop Yield → Feed Ration → Factory Intake → Consumer Retail",
                        color = TextMuted,
                        fontSize = 8.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    selectedScenario.propagationSteps.forEachIndexed { idx, step ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = "[0${idx + 1}]",
                                color = GrainGold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(
                                text = step,
                                color = TextPrimary,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ImpactBox(
    title: String,
    pct: Double,
    spotEst: Double,
    unit: String,
    modifier: Modifier = Modifier
) {
    val isPos = pct >= 0
    Box(
        modifier = modifier
            .background(TerminalBlack, RoundedCornerShape(4.dp))
            .border(0.75.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, color = TextMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
            Text(
                text = "${if (isPos) "+" else ""}${"%.1f".format(pct)}%",
                color = if (isPos) PriceGreen else PriceRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "Est: ${"%.2f".format(spotEst)} $unit",
                color = TextSecondary,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
