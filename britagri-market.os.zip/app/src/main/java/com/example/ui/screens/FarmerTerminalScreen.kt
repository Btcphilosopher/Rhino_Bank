package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TerminalViewModel
import com.example.ui.components.ArableSensitivityMatrixView
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun FarmerTerminalScreen(
    viewModel: TerminalViewModel
) {
    val commodities by viewModel.commodities.collectAsState()
    val savedScenarios by viewModel.marginScenarios.collectAsState()

    // Selling parameters
    val cropId by viewModel.sellCrop.collectAsState()
    val qtyStr by viewModel.sellQuantityTonnes.collectAsState()
    val regionStr by viewModel.sellRegion.collectAsState()
    val moistureStr by viewModel.sellMoisturePct.collectAsState()
    val proteinStr by viewModel.sellProteinPct.collectAsState()
    val specWeightStr by viewModel.sellSpecificWeight.collectAsState()
    val haulageStr by viewModel.sellHaulageMiles.collectAsState()
    val hasRedTractor by viewModel.sellHasRedTractor.collectAsState()
    val storageMoStr by viewModel.sellStorageMonths.collectAsState()

    // Arable Margin Inputs
    val marginCrop by viewModel.marginCrop.collectAsState()
    val marginYieldStr by viewModel.marginYield.collectAsState()
    val marginLandStr by viewModel.marginLandHa.collectAsState()
    val seedCostStr by viewModel.marginSeedCost.collectAsState()
    val fertCostStr by viewModel.marginFertiliserCost.collectAsState()
    val sprayCostStr by viewModel.marginSprayCost.collectAsState()
    val machCostStr by viewModel.marginMachineryCost.collectAsState()
    val labourCostStr by viewModel.marginLabourCost.collectAsState()
    val dryingCostStr by viewModel.marginDryingPerTonne.collectAsState()
    val storageCostStr by viewModel.marginStoragePerTonneMonth.collectAsState()
    val transCostStr by viewModel.marginTransportPerTonne.collectAsState()

    val currentNetback = remember(
        cropId, qtyStr, regionStr, moistureStr, proteinStr, specWeightStr, haulageStr, hasRedTractor, storageMoStr
    ) {
        viewModel.repository.calculateFarmerNetback(
            commodityId = cropId,
            quantityTonnes = qtyStr.toDoubleOrNull() ?: 500.0,
            farmRegion = regionStr,
            deliveryMonth = "October 2026",
            moisturePct = moistureStr.toDoubleOrNull() ?: 14.5,
            proteinPct = proteinStr.toDoubleOrNull() ?: 11.0,
            specificWeightKgHl = specWeightStr.toDoubleOrNull() ?: 76.0,
            distanceMiles = haulageStr.toDoubleOrNull() ?: 35.0,
            hasRedTractor = hasRedTractor,
            storageMonths = storageMoStr.toIntOrNull() ?: 0
        )
    }

    // Computed arable economics
    val cropObj = commodities.find { it.id == cropId } ?: commodities.firstOrNull()
    val currentSellingPrice = cropObj?.spotPrice ?: 186.40

    val yld = marginYieldStr.toDoubleOrNull() ?: 8.8
    val land = marginLandStr.toDoubleOrNull() ?: 150.0
    val seed = seedCostStr.toDoubleOrNull() ?: 65.0
    val fert = fertCostStr.toDoubleOrNull() ?: 215.0
    val spray = sprayCostStr.toDoubleOrNull() ?: 95.0
    val mach = machCostStr.toDoubleOrNull() ?: 140.0
    val labour = labourCostStr.toDoubleOrNull() ?: 55.0
    val drying = dryingCostStr.toDoubleOrNull() ?: 14.0
    val storage = storageCostStr.toDoubleOrNull() ?: 4.20
    val trans = transCostStr.toDoubleOrNull() ?: 11.50

    val totalProduction = yld * land
    val totalRevenue = totalProduction * currentSellingPrice
    val varCostsPerHa = seed + fert + spray
    val fixedCostsPerHa = mach + labour
    val postHarvestPerTonne = drying + storage + trans
    val totalCosts = (varCostsPerHa + fixedCostsPerHa) * land + (postHarvestPerTonne * totalProduction)
    val totalGrossMargin = totalRevenue - totalCosts
    val marginPerHa = totalGrossMargin / max(1.0, land)
    val marginPerTonne = totalGrossMargin / max(1.0, totalProduction)
    val breakevenPrice = totalCosts / max(1.0, totalProduction)
    val breakevenYield = totalCosts / max(1.0, currentSellingPrice * land)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Module 1: Signature Demo 1 — SELL MY GRAIN & NETBACK REALISATION
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "FARMER NETBACK REALISATION ENGINE",
                                color = GrainGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Calculate exact physical gate price after freight, moisture & quality deductions",
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }
                        ProvenanceBadge(
                            status = com.example.data.model.ObservationStatus.INDICATIVE,
                            source = com.example.data.model.ProvenanceSource.SYNTHETIC_ENGINE
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input Form Fields (Row 1: Crop & Quantity)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("COMMODITY", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("WHEAT_FEED" to "Feed Wheat", "WHEAT_MILL" to "Milling Grp 1", "BARLEY_FEED" to "Barley", "RAPESEED_OSR" to "OSR").forEach { (id, label) ->
                                    val isSel = cropId == id
                                    Surface(
                                        modifier = Modifier
                                            .clickable { viewModel.sellCrop.value = id }
                                            .border(0.5.dp, if (isSel) GrainGold else TerminalCardBorder, RoundedCornerShape(3.dp)),
                                        color = if (isSel) BritishRacingGreen else TerminalBlack,
                                        shape = RoundedCornerShape(3.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (isSel) GrainGoldLight else TextSecondary,
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 2: Lot details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = qtyStr,
                            onValueChange = { viewModel.sellQuantityTonnes.value = it },
                            label = { Text("Quantity (t)", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = moistureStr,
                            onValueChange = { viewModel.sellMoisturePct.value = it },
                            label = { Text("Moisture %", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = proteinStr,
                            onValueChange = { viewModel.sellProteinPct.value = it },
                            label = { Text("Protein %", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = haulageStr,
                            onValueChange = { viewModel.sellHaulageMiles.value = it },
                            label = { Text("Miles to Buyer", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Result Payout Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                            .border(1.dp, BritishRacingGreenAccent, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "NET FARMGATE REALISATION",
                                        color = TextGold,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "£${"%.2f".format(currentNetback.netFarmRealisation)} / t",
                                        color = PriceGreen,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "TOTAL LOT NET VALUE",
                                        color = TextMuted,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "£${"%,.2f".format(currentNetback.totalLotValueNet)}",
                                        color = GrainGoldLight,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Divider(color = BritishRacingGreenAccent.copy(alpha = 0.5f), thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Delivered Ref: £${"%.2f".format(currentNetback.regionalPriceDelivered)}", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text("Haulage (${haulageStr}mi): -£${"%.2f".format(currentNetback.freightDeduction)}", color = PriceRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text("Moisture Adj: -£${"%.2f".format(currentNetback.moistureDeduction)}", color = PriceRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Module 2: ARABLE ENTERPRISE GROSS MARGIN & BREAKEVEN ENGINE
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ARABLE GROSS MARGIN & BREAKEVEN ENGINE",
                                color = GrainGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Nix Pocketbook / AHDB Enterprise Model ($land ha @ $yld t/ha)",
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.saveCurrentArableMargin(
                                    crop = cropObj?.name ?: "Feed Wheat",
                                    yieldTonnesHa = yld,
                                    landHa = land,
                                    sellingPricePerTonne = currentSellingPrice,
                                    seedCostHa = seed,
                                    fertCostHa = fert,
                                    sprayCostHa = spray,
                                    machineryHa = mach,
                                    labourHa = labour,
                                    dryingCostTonne = drying,
                                    storageCostTonne = storage,
                                    transportCostTonne = trans
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright),
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SAVE SCENARIO", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input Grid for Costs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = marginYieldStr,
                            onValueChange = { viewModel.marginYield.value = it },
                            label = { Text("Yield (t/ha)", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = marginLandStr,
                            onValueChange = { viewModel.marginLandHa.value = it },
                            label = { Text("Land (ha)", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = fertCostStr,
                            onValueChange = { viewModel.marginFertiliserCost.value = it },
                            label = { Text("Fertiliser (£/ha)", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = sprayCostStr,
                            onValueChange = { viewModel.marginSprayCost.value = it },
                            label = { Text("Sprays (£/ha)", fontSize = 8.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Key Economic KPIs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MarginStatBox(
                            title = "GROSS MARGIN",
                            value = "£${marginPerHa.toInt()} / ha",
                            subtitle = "Total: £${"%,.0f".format(totalGrossMargin)}",
                            color = if (marginPerHa >= 0) PriceGreen else PriceRed,
                            modifier = Modifier.weight(1f)
                        )
                        MarginStatBox(
                            title = "BREAKEVEN PRICE",
                            value = "£${"%.2f".format(breakevenPrice)} / t",
                            subtitle = "Spot: £${"%.2f".format(currentSellingPrice)}/t",
                            color = if (currentSellingPrice >= breakevenPrice) GrainGoldLight else PriceRed,
                            modifier = Modifier.weight(1f)
                        )
                        MarginStatBox(
                            title = "BREAKEVEN YIELD",
                            value = "${"%.2f".format(breakevenYield)} t/ha",
                            subtitle = "Target: ${"%.2f".format(yld)} t/ha",
                            color = TerminalCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2D Sensitivity Matrix
                    ArableSensitivityMatrixView(
                        basePrice = currentSellingPrice,
                        baseYield = yld,
                        totalCostPerHa = (totalCosts / max(1.0, land))
                    )
                }
            }
        }

        // Module 3: Saved Farm Scenarios
        if (savedScenarios.isNotEmpty()) {
            item {
                Text(
                    text = "SAVED FARM MARGIN MODELS",
                    color = GrainGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            items(savedScenarios) { sc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalCardBackground, RoundedCornerShape(4.dp))
                        .border(0.5.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = sc.title,
                            color = TextPrimary,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Gross Margin: £${sc.marginPerUnit.toInt()}/ha • Breakeven: £${sc.breakevenPrice}/t",
                            color = GrainGoldLight,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    IconButton(
                        onClick = { viewModel.deleteMarginScenario(sc.id) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun MarginStatBox(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TerminalBlack, RoundedCornerShape(4.dp))
            .border(0.75.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, color = TextMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
            Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(subtitle, color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
