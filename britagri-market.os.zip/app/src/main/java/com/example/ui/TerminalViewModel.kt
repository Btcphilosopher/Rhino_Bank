package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BritAgriDatabase
import com.example.data.local.CustomOrderEntity
import com.example.data.local.MarginScenarioEntity
import com.example.data.model.*
import com.example.data.repository.MarketDataRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

enum class TerminalScreen(val title: String, val shortcut: String, val iconName: String) {
    BRITAIN_NOW("Britain Now", "ALT+1", "public"),
    MARKET_WATCH("Market Watch", "ALT+2", "table_chart"),
    FARMER_DESK("Farmer Desk", "ALT+3", "agriculture"),
    PROCESSOR_DESK("Procurement", "ALT+4", "factory"),
    CURVES_BASIS("Curves & Basis", "ALT+5", "show_chart"),
    SCENARIO_LAB("Scenario Lab", "ALT+6", "science"),
    BALANCE_SHEET("Balance Sheet", "ALT+7", "inventory_2"),
    NETWORK_TWIN("Digital Twin", "ALT+8", "hub")
}

class TerminalViewModel(application: Application) : AndroidViewModel(application) {
    private val database = BritAgriDatabase.getDatabase(application)
    val repository = MarketDataRepository(database, viewModelScope)

    val commodities = repository.commodities
    val ukRegions = repository.ukRegions
    val spreads = repository.spreads
    val dairyComplex = repository.dairyComplex
    val balanceSheets = repository.balanceSheets
    val supplyChainNodes = repository.supplyChainNodes
    val supplyChainFlows = repository.supplyChainFlows
    val lastTickTime = repository.lastTickTime
    val terminalStatus = repository.terminalStatus

    val customOrders = repository.customOrders.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val marginScenarios = repository.marginScenarios.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val auditLogs = repository.auditLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val watchlist = repository.watchlist.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _currentScreen = MutableStateFlow(TerminalScreen.BRITAIN_NOW)
    val currentScreen: StateFlow<TerminalScreen> = _currentScreen.asStateFlow()

    private val _selectedRole = MutableStateFlow(AppTerminalRole.FARMER)
    val selectedRole: StateFlow<AppTerminalRole> = _selectedRole.asStateFlow()

    private val _selectedCommodity = MutableStateFlow<Commodity?>(null)
    val selectedCommodity: StateFlow<Commodity?> = _selectedCommodity.asStateFlow()

    private val _inspectedCalculation = MutableStateFlow<MarketDataRepository.NetbackCalculationResult?>(null)
    val inspectedCalculation: StateFlow<MarketDataRepository.NetbackCalculationResult?> = _inspectedCalculation.asStateFlow()

    private val _selectedRegion = MutableStateFlow<UKRegionInfo?>(null)
    val selectedRegion: StateFlow<UKRegionInfo?> = _selectedRegion.asStateFlow()

    private val _activeScenario = MutableStateFlow<ScenarioDefinition?>(null)
    val activeScenario: StateFlow<ScenarioDefinition?> = _activeScenario.asStateFlow()

    private val _commandQuery = MutableStateFlow("")
    val commandQuery: StateFlow<String> = _commandQuery.asStateFlow()

    private val _commandFeedback = MutableStateFlow<String?>(null)
    val commandFeedback: StateFlow<String?> = _commandFeedback.asStateFlow()

    // Screener filter states
    private val _screenerCategoryFilter = MutableStateFlow<CommodityCategory?>(null)
    val screenerCategoryFilter: StateFlow<CommodityCategory?> = _screenerCategoryFilter.asStateFlow()

    private val _screenerSearchQuery = MutableStateFlow("")
    val screenerSearchQuery: StateFlow<String> = _screenerSearchQuery.asStateFlow()

    // Farmer Netback selling form state
    var sellCrop = MutableStateFlow("WHEAT_FEED")
    var sellQuantityTonnes = MutableStateFlow("500")
    var sellRegion = MutableStateFlow("East Anglia")
    var sellDeliveryMonth = MutableStateFlow("October 2026")
    var sellMoisturePct = MutableStateFlow("14.5")
    var sellProteinPct = MutableStateFlow("11.0")
    var sellSpecificWeight = MutableStateFlow("76.0")
    var sellHaulageMiles = MutableStateFlow("35")
    var sellHasRedTractor = MutableStateFlow(true)
    var sellStorageMonths = MutableStateFlow("0")

    // Arable Margin Calculator state
    var marginCrop = MutableStateFlow("Feed Wheat")
    var marginYield = MutableStateFlow("8.8") // t/ha
    var marginLandHa = MutableStateFlow("150") // ha
    var marginSeedCost = MutableStateFlow("65") // £/ha
    var marginFertiliserCost = MutableStateFlow("215") // £/ha
    var marginSprayCost = MutableStateFlow("95") // £/ha
    var marginMachineryCost = MutableStateFlow("140") // £/ha
    var marginLabourCost = MutableStateFlow("55") // £/ha
    var marginDryingPerTonne = MutableStateFlow("14") // £/t
    var marginStoragePerTonneMonth = MutableStateFlow("4.20") // £/t/mo
    var marginTransportPerTonne = MutableStateFlow("11.50") // £/t

    // Processor Procurement state
    var procRequirementTonnesPerMonth = MutableStateFlow("10000")
    var procCurrentStockTonnes = MutableStateFlow("8200")
    var procAvgPurchasePrice = MutableStateFlow("181.40")

    init {
        viewModelScope.launch {
            commodities.collect { list ->
                if (_selectedCommodity.value == null && list.isNotEmpty()) {
                    _selectedCommodity.value = list.first()
                }
            }
        }
    }

    fun setScreen(screen: TerminalScreen) {
        _currentScreen.value = screen
    }

    fun setRole(role: AppTerminalRole) {
        _selectedRole.value = role
    }

    fun selectCommodity(commodity: Commodity) {
        _selectedCommodity.value = commodity
    }

    fun selectRegion(region: UKRegionInfo?) {
        _selectedRegion.value = region
    }

    fun setCategoryFilter(category: CommodityCategory?) {
        _screenerCategoryFilter.value = category
    }

    fun setScreenerSearch(query: String) {
        _screenerSearchQuery.value = query
    }

    fun selectScenario(scenario: ScenarioDefinition?) {
        _activeScenario.value = scenario
    }

    fun openCalculationInspector(commodityId: String, region: String = "East Anglia") {
        val qty = sellQuantityTonnes.value.toDoubleOrNull() ?: 500.0
        val moist = sellMoisturePct.value.toDoubleOrNull() ?: 14.5
        val prot = sellProteinPct.value.toDoubleOrNull() ?: 11.0
        val spWt = sellSpecificWeight.value.toDoubleOrNull() ?: 76.0
        val miles = sellHaulageMiles.value.toDoubleOrNull() ?: 35.0
        val rt = sellHasRedTractor.value
        val storageMo = sellStorageMonths.value.toIntOrNull() ?: 0

        _inspectedCalculation.value = repository.calculateFarmerNetback(
            commodityId = commodityId,
            quantityTonnes = qty,
            farmRegion = region,
            deliveryMonth = sellDeliveryMonth.value,
            moisturePct = moist,
            proteinPct = prot,
            specificWeightKgHl = spWt,
            distanceMiles = miles,
            hasRedTractor = rt,
            storageMonths = storageMo
        )
    }

    fun closeCalculationInspector() {
        _inspectedCalculation.value = null
    }

    fun executeCommandLine(input: String) {
        val cmd = input.trim().uppercase()
        _commandQuery.value = ""

        when {
            cmd == "HELP" || cmd == "?" -> {
                _commandFeedback.value = "COMMANDS: WHEAT, BARLEY, OSR, MILK, CATTLE, LAMB, FERTILISER, MAP, SCREEN, SELL, MILL, CURVES, SPREADS, DROUGHT, INVENTORY, TWIN"
            }
            cmd.startsWith("WHEAT") -> {
                val wheat = commodities.value.find { it.id == "WHEAT_FEED" }
                wheat?.let { selectCommodity(it) }
                if (cmd.contains("CURVE")) _currentScreen.value = TerminalScreen.CURVES_BASIS
                else if (cmd.contains("MARGIN") || cmd.contains("SELL")) _currentScreen.value = TerminalScreen.FARMER_DESK
                else if (cmd.contains("MILL")) _currentScreen.value = TerminalScreen.PROCESSOR_DESK
                else _currentScreen.value = TerminalScreen.MARKET_WATCH
                _commandFeedback.value = "LOADED: UK WHEAT TERMINAL"
            }
            cmd.startsWith("BARLEY") -> {
                commodities.value.find { it.id == "BARLEY_FEED" }?.let { selectCommodity(it) }
                _currentScreen.value = TerminalScreen.MARKET_WATCH
                _commandFeedback.value = "LOADED: UK FEED BARLEY"
            }
            cmd.startsWith("MILK") || cmd.startsWith("DAIRY") -> {
                commodities.value.find { it.id == "MILK_FARMGATE" }?.let { selectCommodity(it) }
                _currentScreen.value = TerminalScreen.MARKET_WATCH
                _commandFeedback.value = "LOADED: UK DAIRY COMPLEX (AMPE / MCVE)"
            }
            cmd.startsWith("CATTLE") || cmd.startsWith("BEEF") -> {
                commodities.value.find { it.id == "CATTLE_DEADWT" }?.let { selectCommodity(it) }
                _currentScreen.value = TerminalScreen.MARKET_WATCH
                _commandFeedback.value = "LOADED: FINISHED CATTLE R4L"
            }
            cmd.startsWith("LAMB") || cmd.startsWith("SHEEP") -> {
                commodities.value.find { it.id == "LAMB_SQQ" }?.let { selectCommodity(it) }
                _currentScreen.value = TerminalScreen.MARKET_WATCH
                _commandFeedback.value = "LOADED: FINISHED LAMB SQQ"
            }
            cmd == "MAP" || cmd == "BRITAIN" || cmd == "NOW" -> {
                _currentScreen.value = TerminalScreen.BRITAIN_NOW
                _commandFeedback.value = "BRITAIN NOW FLIGHT BOARD"
            }
            cmd == "SCREEN" || cmd == "WATCH" || cmd == "MKT" -> {
                _currentScreen.value = TerminalScreen.MARKET_WATCH
                _commandFeedback.value = "INSTITUTIONAL SCREENER"
            }
            cmd == "SELL" || cmd == "FARMER" || cmd == "NETBACK" -> {
                _currentScreen.value = TerminalScreen.FARMER_DESK
                _commandFeedback.value = "FARMER REALISATION DESK"
            }
            cmd == "MILL" || cmd == "PROC" || cmd == "BUY" -> {
                _currentScreen.value = TerminalScreen.PROCESSOR_DESK
                _commandFeedback.value = "PROCESSOR PROCUREMENT DESK"
            }
            cmd == "CURVE" || cmd == "CURVES" || cmd == "BASIS" || cmd == "SPREADS" -> {
                _currentScreen.value = TerminalScreen.CURVES_BASIS
                _commandFeedback.value = "FORWARD CURVES & REGIONAL BASIS"
            }
            cmd == "DROUGHT" || cmd == "SCENARIO" || cmd == "LAB" || cmd == "SHOCK" -> {
                _currentScreen.value = TerminalScreen.SCENARIO_LAB
                _activeScenario.value = repository.scenariosList.first()
                _commandFeedback.value = "SCENARIO LAB: UK SUMMER DROUGHT"
            }
            cmd == "INVENTORY" || cmd == "BALANCE" || cmd == "SUPPLY" -> {
                _currentScreen.value = TerminalScreen.BALANCE_SHEET
                _commandFeedback.value = "UK CROP BALANCE SHEET & INVENTORY"
            }
            cmd == "TWIN" || cmd == "GRAPH" || cmd == "FLOW" -> {
                _currentScreen.value = TerminalScreen.NETWORK_TWIN
                _commandFeedback.value = "AGRICULTURAL DIGITAL TWIN"
            }
            else -> {
                // Search commodity by query
                val matched = commodities.value.find { it.name.uppercase().contains(cmd) || it.ticker.uppercase().contains(cmd) }
                if (matched != null) {
                    selectCommodity(matched)
                    _currentScreen.value = TerminalScreen.MARKET_WATCH
                    _commandFeedback.value = "LOADED: ${matched.name}"
                } else {
                    _commandFeedback.value = "UNKNOWN COMMAND: '$cmd'. TYPE 'HELP' FOR ALL CODES."
                }
            }
        }
    }

    fun submitFarmSellOffer(
        commodityCode: String,
        commodityName: String,
        quantityTonnes: Double,
        minPrice: Double,
        region: String,
        location: String,
        deliveryMonth: String,
        qualityGrade: String,
        certification: String,
        storageType: String,
        contactName: String
    ) {
        viewModelScope.launch {
            repository.saveCustomOrder(
                CustomOrderEntity(
                    commodityCode = commodityCode,
                    commodityName = commodityName,
                    orderType = "OFFER_SELL",
                    quantityTonnes = quantityTonnes,
                    targetPricePerTonne = minPrice,
                    region = region,
                    location = location,
                    deliveryMonth = deliveryMonth,
                    qualityGrade = qualityGrade,
                    certification = certification,
                    storageType = storageType,
                    contactEntity = contactName
                )
            )
            _commandFeedback.value = "FARM OFFER POSTED: $quantityTonnes t $commodityName @ £$minPrice/t"
        }
    }

    fun submitBuyerTenderRequest(
        commodityCode: String,
        commodityName: String,
        quantityTonnes: Double,
        targetPrice: Double,
        region: String,
        location: String,
        deliveryMonth: String,
        qualityGrade: String,
        contactName: String
    ) {
        viewModelScope.launch {
            repository.saveCustomOrder(
                CustomOrderEntity(
                    commodityCode = commodityCode,
                    commodityName = commodityName,
                    orderType = "BID_BUY",
                    quantityTonnes = quantityTonnes,
                    targetPricePerTonne = targetPrice,
                    region = region,
                    location = location,
                    deliveryMonth = deliveryMonth,
                    qualityGrade = qualityGrade,
                    certification = "Red Tractor Assured",
                    storageType = "Processor Delivered",
                    contactEntity = contactName
                )
            )
            _commandFeedback.value = "BUY TENDER POSTED: $quantityTonnes t $commodityName @ £$targetPrice/t"
        }
    }

    fun deleteCustomOrder(id: Long) {
        viewModelScope.launch {
            repository.deleteCustomOrder(id)
        }
    }

    fun saveCurrentArableMargin(
        crop: String,
        yieldTonnesHa: Double,
        landHa: Double,
        sellingPricePerTonne: Double,
        seedCostHa: Double,
        fertCostHa: Double,
        sprayCostHa: Double,
        machineryHa: Double,
        labourHa: Double,
        dryingCostTonne: Double,
        storageCostTonne: Double,
        transportCostTonne: Double
    ) {
        viewModelScope.launch {
            val totalProductionTonnes = yieldTonnesHa * landHa
            val totalRevenue = totalProductionTonnes * sellingPricePerTonne
            val varCosts = (seedCostHa + fertCostHa + sprayCostHa) * landHa
            val fixedMachLabour = (machineryHa + labourHa) * landHa
            val postHarvestHandling = (dryingCostTonne + storageCostTonne + transportCostTonne) * totalProductionTonnes

            val totalCost = varCosts + fixedMachLabour + postHarvestHandling
            val grossMarginTotal = totalRevenue - totalCost
            val marginPerHa = grossMarginTotal / max(1.0, landHa)
            val breakevenPrice = totalCost / max(1.0, totalProductionTonnes)

            repository.saveMarginScenario(
                MarginScenarioEntity(
                    title = "$crop Margin ($landHa ha @ $yieldTonnesHa t/ha)",
                    enterpriseType = "ARABLE_CROP",
                    cropOrStock = crop,
                    areaHaOrHead = landHa,
                    yieldPerHaOrDeadweight = yieldTonnesHa,
                    sellingPrice = sellingPricePerTonne,
                    totalRevenue = ((totalRevenue * 100).roundToInt() / 100.0),
                    variableCosts = ((varCosts * 100).roundToInt() / 100.0),
                    fixedMachineryLabour = ((fixedMachLabour * 100).roundToInt() / 100.0),
                    dryingStorageFreight = ((postHarvestHandling * 100).roundToInt() / 100.0),
                    grossMarginTotal = ((grossMarginTotal * 100).roundToInt() / 100.0),
                    marginPerUnit = ((marginPerHa * 100).roundToInt() / 100.0),
                    breakevenPrice = ((breakevenPrice * 100).roundToInt() / 100.0)
                )
            )
            _commandFeedback.value = "SAVED: $crop Margin Scenario (£${marginPerHa.roundToInt()}/ha)"
        }
    }

    fun deleteMarginScenario(id: Long) {
        viewModelScope.launch {
            repository.deleteMarginScenario(id)
        }
    }

    fun toggleWatchlist(commodityId: String, isPinned: Boolean) {
        viewModelScope.launch {
            repository.toggleWatchlist(commodityId, isPinned)
        }
    }

    fun clearFeedback() {
        _commandFeedback.value = null
    }
}
