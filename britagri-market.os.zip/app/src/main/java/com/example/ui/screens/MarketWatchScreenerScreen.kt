package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Commodity
import com.example.data.model.CommodityCategory
import com.example.ui.TerminalViewModel
import com.example.ui.components.OrderBookLadderView
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun MarketWatchScreenerScreen(
    viewModel: TerminalViewModel
) {
    val commodities by viewModel.commodities.collectAsState()
    val selectedCommodity by viewModel.selectedCommodity.collectAsState()
    val categoryFilter by viewModel.screenerCategoryFilter.collectAsState()
    val searchQuery by viewModel.screenerSearchQuery.collectAsState()

    var showPostDialog by remember { mutableStateOf(false) }

    val filteredList = commodities.filter { comm ->
        val matchesCat = categoryFilter == null || comm.category == categoryFilter
        val matchesQuery = searchQuery.isBlank() ||
                comm.name.contains(searchQuery, ignoreCase = true) ||
                comm.ticker.contains(searchQuery, ignoreCase = true)
        matchesCat && matchesQuery
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Screen Header & Search / Filter Toolbar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalCardBackground, RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "UK AGRICULTURAL SPOT MARKET SCREENER",
                        color = GrainGold,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Button(
                        onClick = { showPostDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright),
                        shape = RoundedCornerShape(3.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("POST BID/OFFER", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Category Filter Pills
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    CategoryPill(
                        label = "ALL MARKETS (${commodities.size})",
                        isSelected = categoryFilter == null,
                        onClick = { viewModel.setCategoryFilter(null) }
                    )
                    CommodityCategory.values().forEach { cat ->
                        CategoryPill(
                            label = cat.displayName.uppercase(),
                            isSelected = categoryFilter == cat,
                            onClick = { viewModel.setCategoryFilter(cat) }
                        )
                    }
                }
            }
        }

        // Active Order Book & Selected Commodity Depth Inspector
        val active = selectedCommodity ?: commodities.firstOrNull()
        if (active != null) {
            item {
                val orderBook = remember(active.id, active.spotPrice) {
                    viewModel.repository.getOrderBook(active.id)
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalDarkSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, BritishRacingGreenAccent.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = active.name.uppercase(),
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "[${active.ticker}]",
                                    color = GrainGold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = active.description,
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.openCalculationInspector(active.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("WHY £${"%.2f".format(active.spotPrice)}? INSPECT", color = GrainGoldLight, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Order book ladder view
                    OrderBookLadderView(orderBook = orderBook)
                }
            }
        }

        // Screener Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalHeaderBackground)
                    .border(0.5.dp, TerminalCardBorder)
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TICKER / COMMODITY", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2f))
                Text("STATUS", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("SPOT PRICE", color = TextPrimary, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("24H CHG", color = PriceGreen, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
            }
        }

        // Dense Screener Table Rows
        items(filteredList) { comm ->
            val isSelected = selectedCommodity?.id == comm.id
            val isPos = comm.change >= 0

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isSelected) BritishRacingGreen.copy(alpha = 0.5f) else TerminalCardBackground)
                    .border(0.5.dp, if (isSelected) GrainGold else TerminalCardBorder)
                    .clickable { viewModel.selectCommodity(comm) }
                    .padding(vertical = 6.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2f)) {
                    Text(
                        text = comm.ticker,
                        color = if (isSelected) GrainGoldLight else GrainGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = comm.name,
                        color = TextPrimary,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }

                Box(modifier = Modifier.weight(1.2f)) {
                    ProvenanceBadge(status = comm.status, source = comm.source)
                }

                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = "${"%.2f".format(comm.spotPrice)}",
                        color = TextPrimary,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = comm.unit,
                        color = TextMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.weight(1.2f)
                ) {
                    Text(
                        text = "${if (isPos) "+" else ""}${"%.2f".format(comm.change)}",
                        color = if (isPos) PriceGreen else PriceRed,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${if (isPos) "+" else ""}${"%.2f".format(comm.changePct)}%",
                        color = if (isPos) PriceGreen else PriceRed,
                        fontSize = 8.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showPostDialog) {
        PostOrderDialog(
            commodities = commodities,
            onDismiss = { showPostDialog = false },
            onSubmitSell = { code, name, qty, price, reg, loc, mth, gr, cert, st, cont ->
                viewModel.submitFarmSellOffer(code, name, qty, price, reg, loc, mth, gr, cert, st, cont)
                showPostDialog = false
            },
            onSubmitBuy = { code, name, qty, price, reg, loc, mth, gr, cont ->
                viewModel.submitBuyerTenderRequest(code, name, qty, price, reg, loc, mth, gr, cont)
                showPostDialog = false
            }
        )
    }
}

@Composable
private fun CategoryPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clickable { onClick() }
            .border(
                0.75.dp,
                if (isSelected) GrainGold else TerminalCardBorder,
                RoundedCornerShape(3.dp)
            ),
        color = if (isSelected) BritishRacingGreen else TerminalBlack,
        shape = RoundedCornerShape(3.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) GrainGoldLight else TextSecondary,
            fontSize = 8.5.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun PostOrderDialog(
    commodities: List<Commodity>,
    onDismiss: () -> Unit,
    onSubmitSell: (String, String, Double, Double, String, String, String, String, String, String, String) -> Unit,
    onSubmitBuy: (String, String, Double, Double, String, String, String, String, String) -> Unit
) {
    var isSellMode by remember { mutableStateOf(true) }
    var selectedComm by remember { mutableStateOf(commodities.firstOrNull()?.id ?: "WHEAT_FEED") }
    var qtyText by remember { mutableStateOf("250") }
    var priceText by remember { mutableStateOf("184.50") }
    var regionText by remember { mutableStateOf("East Anglia") }
    var locationText by remember { mutableStateOf("Lincolnshire Farm Silo") }
    var monthText by remember { mutableStateOf("October 2026") }
    var contactText by remember { mutableStateOf("Wolds Agri Trading Ltd") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isSellMode) "POST FARM SELL OFFER" else "POST BUYER PROCUREMENT TENDER",
                    color = GrainGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Switch between Sell / Buy
                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { isSellMode = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSellMode) BritishRacingGreenBright else TerminalBlack
                        ),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.weight(1f).height(32.dp)
                    ) {
                        Text("SELLER OFFER", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { isSellMode = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isSellMode) Color(0xFF1E3A8A) else TerminalBlack
                        ),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.weight(1f).height(32.dp)
                    ) {
                        Text("BUYER TENDER", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("Quantity (Tonnes)", fontSize = 9.sp, color = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Target Price (£/tonne)", fontSize = 9.sp, color = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = regionText,
                    onValueChange = { regionText = it },
                    label = { Text("UK Region", fontSize = 9.sp, color = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = contactText,
                    onValueChange = { contactText = it },
                    label = { Text("Trading Entity / Farm Name", fontSize = 9.sp, color = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = qtyText.toDoubleOrNull() ?: 250.0
                    val pr = priceText.toDoubleOrNull() ?: 184.0
                    val commName = commodities.find { it.id == selectedComm }?.name ?: "Feed Wheat"

                    if (isSellMode) {
                        onSubmitSell(selectedComm, commName, qty, pr, regionText, locationText, monthText, "Feed Standard", "Red Tractor Assured", "On Farm", contactText)
                    } else {
                        onSubmitBuy(selectedComm, commName, qty, pr, regionText, locationText, monthText, "Feed Standard", contactText)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright)
            ) {
                Text("TRANSMIT TO TERMINAL", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
            }
        },
        containerColor = TerminalCardBackground
    )
}
