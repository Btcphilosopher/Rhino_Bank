package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BRITAGRI Professional Terminal Palette
val TerminalBlack = Color(0xFF090C0E)
val TerminalDarkSurface = Color(0xFF11161B)
val TerminalCardBackground = Color(0xFF161D24)
val TerminalCardBorder = Color(0xFF242E38)
val TerminalHeaderBackground = Color(0xFF0D1217)

// British Racing Greens
val BritishRacingGreen = Color(0xFF0D3320)
val BritishRacingGreenBright = Color(0xFF1B5E38)
val BritishRacingGreenAccent = Color(0xFF22C55E)
val BritishRacingGreenMuted = Color(0xFF082014)

// Agricultural Golds & Ambers
val GrainGold = Color(0xFFE5A93C)
val GrainGoldLight = Color(0xFFFCD34D)
val GrainGoldDark = Color(0xFFB45309)

// Price Indicators & Status
val PriceGreen = Color(0xFF22C55E)
val PriceGreenBg = Color(0xFF0D2818)
val PriceRed = Color(0xFFEF4444)
val PriceRedBg = Color(0xFF2D1215)
val PriceNeutral = Color(0xFF94A3B8)

// Semantic Accents
val TerminalCyan = Color(0xFF38BDF8)
val TerminalOrange = Color(0xFFFB923C)
val TerminalPurple = Color(0xFFA855F7)
val TerminalBlue = Color(0xFF60A5FA)

// Typography & Surface Ink
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextMonospace = Color(0xFFE2E8F0)
val TextGold = Color(0xFFFDE68A)
val TextGreen = Color(0xFF86EFAC)
val TextRed = Color(0xFFFCA5A5)

// Provenance Badges
val BadgeObserved = Color(0xFF10B981)
val BadgePublished = Color(0xFF3B82F6)
val BadgeIndicative = Color(0xFFF59E0B)
val BadgeModelled = Color(0xFF8B5CF6)
val BadgeSynthetic = Color(0xFF64748B)
