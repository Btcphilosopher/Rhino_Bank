package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TerminalViewModel
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*
import kotlin.math.max

@Composable
fun ProcessorTerminalScreen(
    viewModel: TerminalViewModel
) {
    val commodities by viewModel.commodities.collectAsState()
    val dairyComplex by viewModel.dairyComplex.collectAsState()
    val customOrders by viewModel.customOrders.collectAsState()

    var enterpriseType by remember { mutableStateOf("FLOUR_MILL") } // "FLOUR_MILL" or "DAIRY_CREAMERY"
    var monthlyDemandTonnes by remember { mutableStateOf("10000") }
    var physicalStockOnHand by remember { mutableStateOf("7800") }
    var forwardContractedTonnes by remember { mutableStateOf("14200") }
    var avgPurchasePrice by remember { mutableStateOf("182.40") }

    val currentSpotWheat = commodities.find { it.id == "WHEAT_FEED" }?.spotPrice ?: 186.40
    val currentSpotBread = commodities.find { it.id == "WHEAT_MILL" }?.spotPrice ?: 224.50

    val demand = monthlyDemandTonnes.toDoubleOrNull() ?: 10000.0
    val stock = physicalStockOnHand.toDoubleOrNull() ?: 7800.0
    val forward = forwardContractedTonnes.toDoubleOrNull() ?: 14200.0
    val wac = avgPurchasePrice.toDoubleOrNull() ?: 182.40

    // Days cover = (stock / (demand / 30.0))
    val dailyBurn = demand / 30.0
    val physicalDaysCover = stock / max(0.1, dailyBurn)
    val totalForwardDaysCover = (stock + forward) / max(0.1, dailyBurn)
    val unpricedOpenExposure = max(0.0, (demand * 3.0) - (stock + forward)) // 90-day coverage window
    val markToMarketGainLoss = (currentSpotWheat - wac) * (stock + forward)

    // Flour Mill Grist Yield Model:
    // 100t wheat yields 76t Baker's Flour + 24t Wheatfeed (Animal Feed)
    // Flour sales value approx £310/t, Wheatfeed value approx £165/t
    val flourYieldPct = 0.76
    val wheatfeedYieldPct = 0.24
    val flourMarketPrice = 315.00
    val wheatfeedMarketPrice = 168.00
    val millingOperatingCostPerTonne = 28.50

    val revenuePerTonneProcessed = (flourYieldPct * flourMarketPrice) + (wheatfeedYieldPct * wheatfeedMarketPrice)
    val rawMaterialCostPerTonne = wac
    val millingGrossMarginPerTonne = revenuePerTonneProcessed - rawMaterialCostPerTonne - millingOperatingCostPerTonne

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Module Header & Mode Switcher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RAW MATERIAL PROCUREMENT & PROCESSING DESK",
                                color = GrainGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Flour Mills • Dairies • Compound Feed Plants • Food Processors",
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }

                        ProvenanceBadge(
                            status = com.example.data.model.ObservationStatus.PUBLISHED,
                            source = com.example.data.model.ProvenanceSource.AHDB
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Mode Toggle: Flour Mill vs Dairy Processor
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { enterpriseType = "FLOUR_MILL" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (enterpriseType == "FLOUR_MILL") BritishRacingGreenBright else TerminalBlack
                            ),
                            shape = RoundedCornerShape(3.dp),
                            modifier = Modifier.weight(1f).height(30.dp)
                        ) {
                            Text("FLOUR & FEED MILL PROCUREMENT", fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { enterpriseType = "DAIRY_CREAMERY" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (enterpriseType == "DAIRY_CREAMERY") BritishRacingGreenBright else TerminalBlack
                            ),
                            shape = RoundedCornerShape(3.dp),
                            modifier = Modifier.weight(1f).height(30.dp)
                        ) {
                            Text("DAIRY CREAMERY (AMPE/MCVE)", fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        if (enterpriseType == "FLOUR_MILL") {
            // Flour Mill Procurement KPI Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ProcessorStatBox(
                        title = "PHYSICAL STOCK COVER",
                        value = "${"%.1f".format(physicalDaysCover)} DAYS",
                        subtitle = "${stock.toInt()}t On-Site Silo",
                        color = if (physicalDaysCover < 15) PriceRed else PriceGreen,
                        modifier = Modifier.weight(1f)
                    )
                    ProcessorStatBox(
                        title = "TOTAL FORWARD COVER",
                        value = "${"%.1f".format(totalForwardDaysCover)} DAYS",
                        subtitle = "${forward.toInt()}t Contracted",
                        color = TerminalCyan,
                        modifier = Modifier.weight(1f)
                    )
                    ProcessorStatBox(
                        title = "WAC vs SPOT",
                        value = "£${"%.2f".format(wac)} / t",
                        subtitle = "Spot: £${"%.2f".format(currentSpotWheat)}/t",
                        color = if (wac < currentSpotWheat) PriceGreen else GrainGold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Grinding Margin & Processing Economics
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "MILLING GRIST YIELD & PROCESSING SPREAD",
                            color = GrainGold,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Standard UK Roller Mill (76% Bakers Flour, 24% Co-product Wheatfeed)",
                            color = TextMuted,
                            fontSize = 9.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Revenue Decomposition
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Bakers Flour (76% @ £${flourMarketPrice.toInt()}/t):", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                            Text("+£${"%.2f".format(flourYieldPct * flourMarketPrice)}/t", color = PriceGreen, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Wheatfeed Pellets (24% @ £${wheatfeedMarketPrice.toInt()}/t):", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                            Text("+£${"%.2f".format(wheatfeedYieldPct * wheatfeedMarketPrice)}/t", color = PriceGreen, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Raw Wheat Delivered Cost (WAC):", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                            Text("-£${"%.2f".format(rawMaterialCostPerTonne)}/t", color = PriceRed, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Milling Energy & Labour Cost:", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                            Text("-£${"%.2f".format(millingOperatingCostPerTonne)}/t", color = PriceRed, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Divider(color = BritishRacingGreenAccent.copy(alpha = 0.5f), thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "NET CRUSH / MILLING MARGIN",
                                color = GrainGoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "£${"%.2f".format(millingGrossMarginPerTonne)} / tonne",
                                color = if (millingGrossMarginPerTonne > 0) PriceGreen else PriceRed,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Inbound Delivery Pipeline from Contracted Farms & Silos
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "INBOUND RAW MATERIAL DELIVERY PIPELINE",
                            color = GrainGold,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Scheduled intake trucks & quality verification checkpoints",
                            color = TextMuted,
                            fontSize = 9.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        val deliveries = listOf(
                            Triple("Bury Central Silo", "450t Grp 1 Wheat", "Arriving Today (14:30) • TASCC"),
                            Triple("Lincolnshire Grain Pool", "800t Feed Wheat", "Scheduled Tomorrow • Red Tractor"),
                            Triple("Wolds Farmer Syndicate", "320t Feed Barley", "In Transit (Haulier ID #441)"),
                            Triple("Tilbury Port Terminal", "1,200t Canadian CWRS", "Customs Cleared • Protein 14.8%")
                        )

                        deliveries.forEach { (origin, cargo, status) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(TerminalDarkSurface, RoundedCornerShape(3.dp))
                                    .padding(6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.LocalShipping, contentDescription = null, tint = TerminalCyan, modifier = Modifier.size(16.dp))
                                    Column {
                                        Text(origin, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Text(cargo, color = GrainGoldLight, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                Text(status, color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        } else {
            // Dairy Creamery Mode (AMPE & MCVE Analysis)
            val dairy = dairyComplex
            if (dairy != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "DAIRY VALUATION COMPLEX (AMPE & MCVE)",
                                color = GrainGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "AHDB Official Formulae: Milk intake valuation against wholesale dairy commodities",
                                color = TextMuted,
                                fontSize = 9.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ProcessorStatBox(
                                    title = "FARMGATE MILK",
                                    value = "${"%.2f".format(dairy.farmgatePpl)} ppl",
                                    subtitle = "Standard Litre (4% / 3.3%)",
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                ProcessorStatBox(
                                    title = "AMPE VALUE",
                                    value = "${"%.2f".format(dairy.ampePpl)} ppl",
                                    subtitle = "Butter + SMP Netback",
                                    color = PriceGreen,
                                    modifier = Modifier.weight(1f)
                                )
                                ProcessorStatBox(
                                    title = "MCVE VALUE",
                                    value = "${"%.2f".format(dairy.mcvePpl)} ppl",
                                    subtitle = "Mild Cheddar + Whey",
                                    color = TerminalCyan,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "WHOLESALE COMMODITY INGREDIENTS:",
                                color = GrainGoldLight,
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Bulk Butter: £${dairy.butterPerTonne.toInt()}/t", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Text("SMP: £${dairy.smpPerTonne.toInt()}/t", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Text("Cheddar: £${dairy.mildCheddarPerTonne.toInt()}/t", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ProcessorStatBox(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TerminalBlack, RoundedCornerShape(4.dp))
            .border(0.75.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, color = TextMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
            Text(value, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(subtitle, color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
