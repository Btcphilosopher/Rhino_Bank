package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
    primary = BritishRacingGreenAccent,
    onPrimary = TerminalBlack,
    primaryContainer = BritishRacingGreen,
    onPrimaryContainer = TextGold,
    secondary = GrainGold,
    onSecondary = TerminalBlack,
    secondaryContainer = GrainGoldDark,
    onSecondaryContainer = TextGold,
    tertiary = TerminalCyan,
    onTertiary = TerminalBlack,
    background = TerminalBlack,
    onBackground = TextPrimary,
    surface = TerminalDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalCardBackground,
    onSurfaceVariant = TextSecondary,
    outline = TerminalCardBorder,
    error = PriceRed,
    onError = TerminalBlack
)

@Composable
fun BritAgriTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
