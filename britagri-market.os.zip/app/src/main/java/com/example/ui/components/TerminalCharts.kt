package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CommodityOrderBook
import com.example.data.model.ForwardCurvePoint
import com.example.ui.theme.*
import kotlin.math.max

@Composable
fun MiniSparkline(
    isPositive: Boolean,
    modifier: Modifier = Modifier.size(width = 60.dp, height = 24.dp)
) {
    val lineColor = if (isPositive) PriceGreen else PriceRed

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val path = Path()

        val points = if (isPositive) {
            listOf(0.7f, 0.65f, 0.8f, 0.5f, 0.45f, 0.6f, 0.3f, 0.2f)
        } else {
            listOf(0.25f, 0.35f, 0.3f, 0.55f, 0.48f, 0.68f, 0.62f, 0.85f)
        }

        val stepX = w / (points.size - 1)
        points.forEachIndexed { index, yRatio ->
            val x = index * stepX
            val y = yRatio * h
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 1.75f, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun OrderBookLadderView(
    orderBook: CommodityOrderBook,
    modifier: Modifier = Modifier
) {
    val maxVol = max(
        orderBook.bids.maxOfOrNull { it.volumeTonnes } ?: 1000.0,
        orderBook.offers.maxOfOrNull { it.volumeTonnes } ?: 1000.0
    )

    Column(
        modifier = modifier
            .background(TerminalCardBackground, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "DEPTH: ${orderBook.commodityName.uppercase()}",
                color = GrainGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            ProvenanceBadge(
                status = com.example.data.model.ObservationStatus.SYNTHETIC,
                source = com.example.data.model.ProvenanceSource.SYNTHETIC_ENGINE
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalHeaderBackground)
                .padding(vertical = 4.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("COUNT", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
            Text("BID VOL (t)", color = PriceGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
            Text("PRICE (£)", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
            Text("ASK VOL (t)", color = PriceRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
        }

        // Offers (Asks) in reverse order (highest to lowest)
        orderBook.offers.reversed().forEach { level ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .padding(vertical = 1.dp)
            ) {
                // Volume bar fill from right
                val fillRatio = (level.volumeTonnes / maxVol).toFloat()
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        color = PriceRedBg.copy(alpha = 0.7f),
                        topLeft = Offset(size.width * (1f - fillRatio), 0f),
                        size = Size(size.width * fillRatio, size.height)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${level.orderCount}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(text = "-", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text(text = "£${"%.2f".format(level.price)}", color = PriceRed, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text(text = "${level.volumeTonnes.toInt()}t", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                }
            }
        }

        // Mid Market Spread Line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .background(BritishRacingGreen.copy(alpha = 0.5f))
                .border(0.75.dp, BritishRacingGreenAccent.copy(alpha = 0.5f))
                .padding(vertical = 3.dp, horizontal = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "MID: £${"%.2f".format(orderBook.lastPrice)}",
                    color = GrainGoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "SPREAD: £${"%.2f".format(orderBook.spread)}/t",
                    color = TerminalCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Bids
        orderBook.bids.forEach { level ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .padding(vertical = 1.dp)
            ) {
                // Volume bar fill from left
                val fillRatio = (level.volumeTonnes / maxVol).toFloat()
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        color = PriceGreenBg.copy(alpha = 0.7f),
                        topLeft = Offset(0f, 0f),
                        size = Size(size.width * fillRatio, size.height)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${level.orderCount}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(text = "${level.volumeTonnes.toInt()}t", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text(text = "£${"%.2f".format(level.price)}", color = PriceGreen, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text(text = "-", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                }
            }
        }
    }
}

@Composable
fun ForwardCurveCanvas(
    points: List<ForwardCurvePoint>,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
) {
    if (points.isEmpty()) return

    val minPrice = (points.minOf { it.futuresRef } - 5.0).toFloat()
    val maxPrice = (points.maxOf { it.deliveredPrice } + 5.0).toFloat()
    val priceRange = max(1f, maxPrice - minPrice)

    Column(
        modifier = modifier
            .background(TerminalCardBackground, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "UK FEED WHEAT FORWARD CURVE & CARRY",
                color = GrainGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("■ Futures Ref", color = TerminalCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("■ Delivered", color = PriceGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            val w = size.width
            val h = size.height

            // Grid lines
            val gridCount = 4
            for (i in 0..gridCount) {
                val y = (h / gridCount) * i
                drawLine(
                    color = TerminalCardBorder.copy(alpha = 0.5f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }

            val stepX = w / (points.size - 1)
            val futuresPath = Path()
            val deliveredPath = Path()

            points.forEachIndexed { i, pt ->
                val x = i * stepX
                val yFutures = h - (((pt.futuresRef.toFloat() - minPrice) / priceRange) * h)
                val yDelivered = h - (((pt.deliveredPrice.toFloat() - minPrice) / priceRange) * h)

                if (i == 0) {
                    futuresPath.moveTo(x, yFutures)
                    deliveredPath.moveTo(x, yDelivered)
                } else {
                    futuresPath.lineTo(x, yFutures)
                    deliveredPath.lineTo(x, yDelivered)
                }

                // Draw dots
                drawCircle(color = TerminalCyan, radius = 3.5f, center = Offset(x, yFutures))
                drawCircle(color = PriceGreen, radius = 3.5f, center = Offset(x, yDelivered))
            }

            drawPath(futuresPath, color = TerminalCyan, style = Stroke(width = 2.5f))
            drawPath(deliveredPath, color = PriceGreen, style = Stroke(width = 2f))
        }

        // X Axis labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            points.forEach { pt ->
                Text(
                    text = pt.period.take(6),
                    color = TextMuted,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ArableSensitivityMatrixView(
    basePrice: Double,
    baseYield: Double,
    totalCostPerHa: Double,
    modifier: Modifier = Modifier
) {
    val yieldDeltas = listOf(-1.5, -0.8, 0.0, +0.8, +1.5)
    val priceDeltas = listOf(-25.0, -10.0, 0.0, +10.0, +25.0)

    Column(
        modifier = modifier
            .background(TerminalCardBackground, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Text(
            text = "GROSS MARGIN SENSITIVITY MATRIX (£/ha)",
            color = GrainGold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "YIELD (t/ha) vs SELLING PRICE (£/t) • Baseline Cost: £${totalCostPerHa.toInt()}/ha",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        // Column Header: Price points
        Row(modifier = Modifier.fillMaxWidth()) {
            Text("YIELD", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
            priceDeltas.forEach { pDelta ->
                val p = basePrice + pDelta
                Text(
                    text = "£${p.toInt()}",
                    color = if (pDelta == 0.0) GrainGoldLight else TextSecondary,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (pDelta == 0.0) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Rows
        yieldDeltas.forEach { yDelta ->
            val currentYield = baseYield + yDelta
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${"%.1f".format(currentYield)} t",
                    color = if (yDelta == 0.0) GrainGoldLight else TextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (yDelta == 0.0) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.weight(1.1f)
                )

                priceDeltas.forEach { pDelta ->
                    val p = basePrice + pDelta
                    val rev = currentYield * p
                    val margin = rev - totalCostPerHa
                    val isPos = margin >= 0
                    val isBase = (yDelta == 0.0 && pDelta == 0.0)

                    val bgColor = when {
                        isBase -> BritishRacingGreen
                        margin > 600 -> Color(0xFF064E3B)
                        margin > 200 -> Color(0xFF0F3E2E)
                        margin > 0 -> Color(0xFF1E293B)
                        else -> Color(0xFF3F1418)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 1.5.dp)
                            .background(bgColor, RoundedCornerShape(3.dp))
                            .border(if (isBase) 1.dp else 0.dp, GrainGold, RoundedCornerShape(3.dp))
                            .padding(vertical = 3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "£${margin.toInt()}",
                            color = if (isPos) PriceGreen else PriceRed,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isBase) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
