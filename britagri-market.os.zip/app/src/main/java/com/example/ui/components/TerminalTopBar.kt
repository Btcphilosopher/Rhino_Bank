package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppTerminalRole
import com.example.data.model.Commodity
import com.example.ui.TerminalScreen
import com.example.ui.theme.*

@Composable
fun TerminalTopBar(
    commodities: List<Commodity>,
    lastBstTime: String,
    currentScreen: TerminalScreen,
    selectedRole: AppTerminalRole,
    onRoleSelected: (AppTerminalRole) -> Unit,
    onScreenSelected: (TerminalScreen) -> Unit,
    onExecuteCommand: (String) -> Unit,
    commandFeedback: String?,
    onClearFeedback: () -> Unit,
    onShowHelp: () -> Unit
) {
    var commandInput by remember { mutableStateOf("") }
    var roleDropdownOpen by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(TerminalHeaderBackground)
            .border(width = 0.75.dp, color = TerminalCardBorder)
    ) {
        // Top Ticker Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalBlack)
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 3.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "BRITAGRI TERMINAL",
                color = GrainGold,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            commodities.take(8).forEach { comm ->
                val isPos = comm.change >= 0
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = comm.ticker,
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${"%.2f".format(comm.spotPrice)}",
                        color = TextPrimary,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${if (isPos) "+" else ""}${"%.2f".format(comm.change)}",
                        color = if (isPos) PriceGreen else PriceRed,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Text(
                text = "• BST: $lastBstTime",
                color = TextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Divider(color = TerminalCardBorder, thickness = 0.5.dp)

        // Main Institutional Header & Command Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand & System ID
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                        .border(1.dp, BritishRacingGreenAccent, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "MARKET.OS",
                        color = TextGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column {
                    Text(
                        text = "BRITAGRI",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "UK PHYSICAL COMMODITY EXCHANGE",
                        color = TextMuted,
                        fontSize = 7.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Role Selector Pill
            Box {
                Surface(
                    modifier = Modifier
                        .clickable { roleDropdownOpen = true }
                        .border(0.75.dp, BritishRacingGreenAccent.copy(alpha = 0.7f), RoundedCornerShape(4.dp)),
                    color = BritishRacingGreenMuted,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "ROLE: ${selectedRole.badge}",
                            color = GrainGoldLight,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "▼", color = TextMuted, fontSize = 7.sp)
                    }
                }

                DropdownMenu(
                    expanded = roleDropdownOpen,
                    onDismissRequest = { roleDropdownOpen = false },
                    modifier = Modifier.background(TerminalCardBackground)
                ) {
                    AppTerminalRole.values().forEach { role ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = "${role.badge} - ${role.title}",
                                        color = if (role == selectedRole) GrainGold else TextPrimary,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = role.description,
                                        color = TextMuted,
                                        fontSize = 9.sp
                                    )
                                }
                            },
                            onClick = {
                                onRoleSelected(role)
                                roleDropdownOpen = false
                            }
                        )
                    }
                }
            }

            // Quick Command Input
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    placeholder = {
                        Text(
                            text = "CMD (e.g. WHEAT, MILK, SELL, DROUGHT, MAP)",
                            color = TextMuted,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimary,
                        fontSize = 10.sp
                    ),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GrainGold,
                        unfocusedBorderColor = TerminalCardBorder,
                        focusedContainerColor = TerminalBlack,
                        unfocusedContainerColor = TerminalBlack
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            if (commandInput.isNotBlank()) {
                                onExecuteCommand(commandInput)
                                commandInput = ""
                                focusManager.clearFocus()
                            }
                        }
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (commandInput.isNotBlank()) {
                                    onExecuteCommand(commandInput)
                                    commandInput = ""
                                    focusManager.clearFocus()
                                }
                            }
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Run", tint = GrainGold, modifier = Modifier.size(16.dp))
                        }
                    }
                )
            }

            // Command Help Button
            IconButton(
                onClick = onShowHelp,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(Icons.Default.HelpOutline, contentDescription = "Terminal Help", tint = TerminalCyan, modifier = Modifier.size(18.dp))
            }
        }

        // Optional Command Feedback Banner
        if (commandFeedback != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRacingGreen)
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ">> $commandFeedback",
                    color = GrainGoldLight,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "[DISMISS]",
                    color = TextPrimary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { onClearFeedback() }
                )
            }
        }

        // Navigation Tabs (Bloomberg / Terminal Function Keys)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalDarkSurface)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TerminalScreen.values().forEach { screen ->
                val isSelected = screen == currentScreen
                Surface(
                    modifier = Modifier
                        .clickable { onScreenSelected(screen) }
                        .border(
                            width = if (isSelected) 1.25.dp else 0.5.dp,
                            color = if (isSelected) GrainGold else TerminalCardBorder,
                            shape = RoundedCornerShape(3.dp)
                        ),
                    color = if (isSelected) BritishRacingGreen else TerminalCardBackground,
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = screen.shortcut,
                            color = if (isSelected) GrainGold else TextMuted,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = screen.title.uppercase(),
                            color = if (isSelected) TextPrimary else TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
