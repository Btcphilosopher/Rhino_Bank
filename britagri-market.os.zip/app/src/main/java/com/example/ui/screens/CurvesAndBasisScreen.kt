package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SpreadMetric
import com.example.ui.TerminalViewModel
import com.example.ui.components.ForwardCurveCanvas
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun CurvesAndBasisScreen(
    viewModel: TerminalViewModel
) {
    val commodities by viewModel.commodities.collectAsState()
    val regions by viewModel.ukRegions.collectAsState()
    val spreads by viewModel.spreads.collectAsState()

    val wheatCurve = remember {
        viewModel.repository.getForwardCurve("WHEAT_FEED")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Module Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "FORWARD CURVES, REGIONAL BASIS & SPREADS",
                            color = GrainGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "ICE LIFFE Futures Term Structure • Regional Freight Basis • Storage Arbitrage",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }

                    ProvenanceBadge(
                        status = com.example.data.model.ObservationStatus.LIVE,
                        source = com.example.data.model.ProvenanceSource.ICE_LIFFE
                    )
                }
            }
        }

        // Forward Curve Canvas Chart
        item {
            ForwardCurveCanvas(points = wheatCurve)
        }

        // Forward Curve Term Structure Table & Storage Carry Arbitrage
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "STORAGE CARRY & ARBITRAGE ECONOMICS",
                            color = GrainGold,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Storage: £1.45/t/mo • Cost of Money: 6.5%",
                            color = TextMuted,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalHeaderBackground)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("PERIOD", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                        Text("FUTURES", color = TerminalCyan, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("DELIVERED", color = PriceGreen, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("CARRY (£)", color = GrainGold, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("NET MARGIN", color = TextPrimary, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    }

                    wheatCurve.forEach { pt ->
                        val isPos = pt.netCarryMargin >= 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pt.period, color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                            Text("£${"%.2f".format(pt.futuresRef)}", color = TerminalCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text("£${"%.2f".format(pt.deliveredPrice)}", color = PriceGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text("+£${"%.2f".format(pt.futuresRef - 188.50)}", color = GrainGold, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text(
                                text = "${if (isPos) "+" else ""}£${"%.2f".format(pt.netCarryMargin)}/t",
                                color = if (isPos) PriceGreen else PriceRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.3f)
                            )
                        }
                        Divider(color = TerminalCardBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                    }
                }
            }
        }

        // UK Regional Basis Matrix (Deficit vs Surplus Zones)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "UK REGIONAL BASIS MATRIX (DEFICIT vs SURPLUS)",
                        color = GrainGold,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Difference to ICE LIFFE Benchmark reflecting regional supply/demand & haulage distance",
                        color = TextMuted,
                        fontSize = 8.5.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    regions.forEach { reg ->
                        val isPrem = reg.basisDiff >= 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(reg.name, color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                            Text("Spot: £${"%.2f".format(reg.wheatSpot)}/t", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                            Text(
                                text = "${if (isPrem) "+" else ""}£${"%.2f".format(reg.basisDiff)}/t",
                                color = if (isPrem) PriceGreen else PriceRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Quantitative Spreads & Substitution Ratios
        item {
            Text(
                text = "COMMODITY SPREADS & SUBSTITUTION RATIOS",
                color = GrainGold,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(spreads) { sp ->
            SpreadMetricCard(spread = sp)
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SpreadMetricCard(spread: SpreadMetric) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = spread.title,
                    color = GrainGoldLight,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${"%.2f".format(spread.currentSpread)} ${spread.unit}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${spread.legA} vs ${spread.legB}", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                Text("Z-Score: ${"%.2f".format(spread.zScore)}σ (30d Mean: ${"%.2f".format(spread.historical30dMean)})", color = TerminalCyan, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
            }

            Text(
                text = "Arbitrage / Logic: ${spread.rationale}",
                color = TextSecondary,
                fontSize = 8.5.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
