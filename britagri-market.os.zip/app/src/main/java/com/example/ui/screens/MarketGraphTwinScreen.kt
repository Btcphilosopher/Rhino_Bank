package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SupplyChainFlowEdge
import com.example.data.model.SupplyChainNode
import com.example.ui.TerminalViewModel
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun MarketGraphTwinScreen(
    viewModel: TerminalViewModel
) {
    val nodes by viewModel.supplyChainNodes.collectAsState()
    val flows by viewModel.supplyChainFlows.collectAsState()

    var selectedNode by remember { mutableStateOf<SupplyChainNode?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Module Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BRITISH AGRI DIGITAL TWIN & NETWORK GRAPH",
                            color = GrainGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Computable Physical Economy: Farm → Storage → Mill → Port Flow Nodes",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }

                    ProvenanceBadge(
                        status = com.example.data.model.ObservationStatus.MODELLED,
                        source = com.example.data.model.ProvenanceSource.SYNTHETIC_ENGINE
                    )
                }
            }
        }

        // Visual Graph Canvas Area
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalDarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "TOPOLOGY & COMMODITY FLOW NETWORK",
                        color = GrainGoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Tap on any supply chain node to inspect processing capacity and pipeline",
                        color = TextMuted,
                        fontSize = 8.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                            .background(TerminalBlack, RoundedCornerShape(4.dp))
                            .border(0.75.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw flow edges between nodes
                            flows.forEach { flow ->
                                val fromNode = nodes.find { it.id == flow.fromNodeId }
                                val toNode = nodes.find { it.id == flow.toNodeId }

                                if (fromNode != null && toNode != null) {
                                    val startX = fromNode.xRatio * w
                                    val startY = fromNode.yRatio * h
                                    val endX = toNode.xRatio * w
                                    val endY = toNode.yRatio * h

                                    drawLine(
                                        color = if (flow.isBottleneck) PriceRed.copy(alpha = 0.8f) else GrainGold.copy(alpha = 0.5f),
                                        start = Offset(startX, startY),
                                        end = Offset(endX, endY),
                                        strokeWidth = if (flow.isBottleneck) 2.5f else 1.5f,
                                        cap = StrokeCap.Round
                                    )
                                }
                            }
                        }

                        // Render Node Badges
                        nodes.forEach { node ->
                            val isSel = selectedNode?.id == node.id
                            val nodeColor = when (node.nodeType) {
                                SupplyChainNode.NodeType.FARM_ORIGIN -> PriceGreen
                                SupplyChainNode.NodeType.GRAIN_STORE -> GrainGold
                                SupplyChainNode.NodeType.FLOUR_MILL -> TerminalCyan
                                SupplyChainNode.NodeType.FEED_MILL -> Color(0xFFC084FC)
                                SupplyChainNode.NodeType.DAIRY_PROCESSING -> Color(0xFFFBBF24)
                                SupplyChainNode.NodeType.ABATTOIR -> PriceRed
                                SupplyChainNode.NodeType.CARGO_PORT -> Color(0xFF60A5FA)
                                else -> Color(0xFF94A3B8)
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .offset(
                                        x = (node.xRatio * 280).dp,
                                        y = (node.yRatio * 190).dp
                                    )
                                    .clickable { selectedNode = node }
                                    .background(
                                        if (isSel) nodeColor else TerminalCardBackground,
                                        CircleShape
                                    )
                                    .border(
                                        1.dp,
                                        if (isSel) Color.White else nodeColor,
                                        CircleShape
                                    )
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = node.name.take(12),
                                    color = if (isSel) TerminalBlack else TextPrimary,
                                    fontSize = 7.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Node Inspector Banner
        val activeNode = selectedNode ?: nodes.firstOrNull()
        if (activeNode != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = activeNode.name.uppercase(),
                                    color = GrainGold,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "TYPE: ${activeNode.nodeType.name} • REGION: ${activeNode.region}",
                                    color = TextMuted,
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "${activeNode.currentLoadPct}% UTILIZATION",
                                color = if (activeNode.currentLoadPct > 85) PriceRed else PriceGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Annual Capacity: ${"%,.0f".format(activeNode.capacityTonnes)}t", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("Throughput: ${"%,.0f".format(activeNode.throughputTonnesPerDay)}t/day", color = TerminalCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Active Flow Edges Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ACTIVE INTER-NODE COMMODITY FLOWS",
                        color = GrainGold,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    flows.forEach { fl ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(2f)) {
                                Text(fl.commodity, color = TextPrimary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("${fl.fromNodeId.take(10)} → ${fl.toNodeId.take(10)}", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text("${fl.flowTonnesPerDay.toInt()} t/day", color = TerminalCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text("£${"%.2f".format(fl.freightCostPerTonne)}/t", color = PriceGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        }
                        Divider(color = TerminalCardBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
