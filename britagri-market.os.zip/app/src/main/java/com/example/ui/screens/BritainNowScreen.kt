package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Commodity
import com.example.data.model.UKRegionInfo
import com.example.ui.TerminalScreen
import com.example.ui.TerminalViewModel
import com.example.ui.components.MiniSparkline
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun BritainNowScreen(
    viewModel: TerminalViewModel,
    onNavigate: (TerminalScreen) -> Unit
) {
    val commodities by viewModel.commodities.collectAsState()
    val regions by viewModel.ukRegions.collectAsState()
    val lastBstTime by viewModel.lastTickTime.collectAsState()
    val selectedRegion by viewModel.selectedRegion.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Hero Branding & Status Bar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(TerminalDarkSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, BritishRacingGreenAccent.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            ) {
                // Background Hero Art
                Image(
                    painter = painterResource(id = R.drawable.britagri_hero),
                    contentDescription = "British Agricultural Infrastructure",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().alpha(0.35f)
                )

                // Overlay Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "BRITAIN NOW • PHYSICAL MARKET FLIGHT BOARD",
                                color = GrainGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "UK AGRICULTURAL COMMODITY COMPUTER • $lastBstTime",
                                color = TextPrimary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        ProvenanceBadge(
                            status = com.example.data.model.ObservationStatus.LIVE,
                            source = com.example.data.model.ProvenanceSource.AHDB
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        QuickStatsPill(label = "ACTIVE REGIONS", value = "11 UK ZONES", color = TerminalCyan)
                        QuickStatsPill(label = "AVG GRAIN STOCK", value = "74% CAPACITY", color = GrainGold)
                        QuickStatsPill(label = "FREIGHT RATE", value = "£0.11/t/mile", color = PriceGreen)
                    }
                }
            }
        }

        // UK Agricultural Interactive Physical Map & Regional Matrix
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "UK PHYSICAL COMMODITY GEOGRAPHY",
                                color = GrainGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Tap any agricultural region below to inspect local basis, storage & grain flows",
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Simplified Interactive UK Map View with Regional Nodes
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(TerminalBlack, RoundedCornerShape(4.dp))
                            .border(0.75.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw stylized British Isles coastline
                            val ukOutline = Path().apply {
                                moveTo(w * 0.45f, h * 0.10f) // North Scotland
                                lineTo(w * 0.58f, h * 0.18f) // Aberdeenshire
                                lineTo(w * 0.52f, h * 0.32f) // Edinburgh / Borders
                                lineTo(w * 0.65f, h * 0.44f) // Newcastle / Yorkshire
                                lineTo(w * 0.76f, h * 0.60f) // East Anglia / Wash
                                lineTo(w * 0.72f, h * 0.75f) // Thames / Kent
                                lineTo(w * 0.50f, h * 0.78f) // South Coast / Southampton
                                lineTo(w * 0.28f, h * 0.85f) // Cornwall
                                lineTo(w * 0.38f, h * 0.68f) // Bristol Channel
                                lineTo(w * 0.30f, h * 0.56f) // Wales
                                lineTo(w * 0.42f, h * 0.48f) // Liverpool / Lancs
                                lineTo(w * 0.38f, h * 0.32f) // Galloway
                                lineTo(w * 0.35f, h * 0.18f) // Highlands
                                close()
                            }

                            drawPath(
                                path = ukOutline,
                                color = BritishRacingGreenMuted,
                                style = androidx.compose.ui.graphics.drawscope.Fill
                            )
                            drawPath(
                                path = ukOutline,
                                color = BritishRacingGreenBright.copy(alpha = 0.5f),
                                style = Stroke(width = 1.5f)
                            )

                            // Draw trade flow vectors
                            // East Anglia to Tilbury
                            drawLine(
                                color = GrainGold.copy(alpha = 0.7f),
                                start = Offset(w * 0.72f, h * 0.60f),
                                end = Offset(w * 0.70f, h * 0.72f),
                                strokeWidth = 2.5f,
                                cap = StrokeCap.Round
                            )
                            // Yorkshire to Port of Hull
                            drawLine(
                                color = TerminalCyan.copy(alpha = 0.7f),
                                start = Offset(w * 0.58f, h * 0.46f),
                                end = Offset(w * 0.68f, h * 0.48f),
                                strokeWidth = 2.5f,
                                cap = StrokeCap.Round
                            )
                            // South West Dairy to Creamery
                            drawLine(
                                color = PriceGreen.copy(alpha = 0.7f),
                                start = Offset(w * 0.35f, h * 0.78f),
                                end = Offset(w * 0.30f, h * 0.82f),
                                strokeWidth = 2.5f,
                                cap = StrokeCap.Round
                            )
                        }

                        // Regional Node Markers
                        regions.forEach { reg ->
                            val xPos = when (reg.id) {
                                "EAST_ANGLIA" -> 0.70f
                                "YORKSHIRE" -> 0.58f
                                "EAST_MIDLANDS" -> 0.55f
                                "WEST_MIDLANDS" -> 0.45f
                                "NORTH_WEST" -> 0.42f
                                "NORTH_EAST" -> 0.55f
                                "SOUTH_WEST" -> 0.32f
                                "SOUTH_EAST" -> 0.68f
                                "SCOTLAND" -> 0.48f
                                "WALES" -> 0.35f
                                "NORTHERN_IRELAND" -> 0.18f
                                else -> 0.5f
                            }
                            val yPos = when (reg.id) {
                                "EAST_ANGLIA" -> 0.58f
                                "YORKSHIRE" -> 0.44f
                                "EAST_MIDLANDS" -> 0.52f
                                "WEST_MIDLANDS" -> 0.56f
                                "NORTH_WEST" -> 0.44f
                                "NORTH_EAST" -> 0.32f
                                "SOUTH_WEST" -> 0.78f
                                "SOUTH_EAST" -> 0.70f
                                "SCOTLAND" -> 0.18f
                                "WALES" -> 0.58f
                                "NORTHERN_IRELAND" -> 0.38f
                                else -> 0.5f
                            }

                            val isSelected = selectedRegion?.id == reg.id

                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .offset(x = (xPos * 300).dp, y = (yPos * 170).dp)
                                    .clickable { viewModel.selectRegion(reg) }
                                    .background(
                                        if (isSelected) GrainGold else BritishRacingGreen,
                                        CircleShape
                                    )
                                    .border(1.dp, if (isSelected) Color.White else BritishRacingGreenAccent, CircleShape)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = reg.shortCode,
                                    color = if (isSelected) TerminalBlack else TextPrimary,
                                    fontSize = 7.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Selected Region Inspector Banner
                    val activeReg = selectedRegion ?: regions.firstOrNull()
                    if (activeReg != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRacingGreen.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                .border(0.75.dp, BritishRacingGreenAccent, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "ZONE: ${activeReg.name.uppercase()} (${activeReg.primaryProduce})",
                                        color = GrainGoldLight,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "BASIS: ${if (activeReg.basisDiff >= 0) "+" else ""}£${"%.2f".format(activeReg.basisDiff)}/t",
                                        color = if (activeReg.basisDiff >= 0) PriceGreen else PriceRed,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Feed Wheat: £${"%.2f".format(activeReg.wheatSpot)}/t", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                    Text("Milk: ${"%.2f".format(activeReg.milkPpl)} ppl", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                    Text("Storage: ${activeReg.storageUtilPct}% used", color = GrainGold, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                    Text("Grain: ${"%,.0f".format(activeReg.availableGrainTonnes)}t", color = TerminalCyan, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Benchmark Commodity Prices
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "UK CORE COMMODITY BENCHMARKS",
                    color = GrainGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "VIEW FULL SCREENER →",
                    color = TerminalCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { onNavigate(TerminalScreen.MARKET_WATCH) }
                )
            }
        }

        items(commodities.take(7)) { commodity ->
            CommoditySummaryCard(
                commodity = commodity,
                onInspect = { viewModel.openCalculationInspector(commodity.id) },
                onSelect = {
                    viewModel.selectCommodity(commodity)
                    onNavigate(TerminalScreen.MARKET_WATCH)
                }
            )
        }

        // Bottom Fast Action Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onNavigate(TerminalScreen.FARMER_DESK) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.Agriculture, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SELL GRAIN (NETBACK)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onNavigate(TerminalScreen.SCENARIO_LAB) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.WaterDrop, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DROUGHT LAB", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun QuickStatsPill(label: String, value: String, color: Color) {
    Surface(
        color = TerminalBlack.copy(alpha = 0.8f),
        shape = RoundedCornerShape(3.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, color.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)) {
            Text(label, color = TextMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
            Text(value, color = color, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun CommoditySummaryCard(
    commodity: Commodity,
    onInspect: () -> Unit,
    onSelect: () -> Unit
) {
    val isPos = commodity.change >= 0

    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Ticker & Name
            Column(modifier = Modifier.weight(1.8f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = commodity.ticker,
                        color = GrainGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    ProvenanceBadge(status = commodity.status, source = commodity.source)
                }
                Text(
                    text = commodity.name,
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Vol: ${"%,.0f".format(commodity.volumeTonnes)}t • Ref: ${commodity.futuresReference?.let { "£${"%.2f".format(it)}" } ?: "Physical"}",
                    color = TextMuted,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Middle: Sparkline
            MiniSparkline(isPositive = isPos, modifier = Modifier.size(50.dp, 20.dp))

            // Right: Price & Change
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.weight(1.3f)
            ) {
                Text(
                    text = "${"%.2f".format(commodity.spotPrice)} ${commodity.unit}",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isPos) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = if (isPos) PriceGreen else PriceRed,
                        modifier = Modifier.size(11.dp)
                    )
                    Text(
                        text = "${if (isPos) "+" else ""}${"%.2f".format(commodity.change)} (${"%.2f".format(commodity.changePct)}%)",
                        color = if (isPos) PriceGreen else PriceRed,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "[WHY? PROVENANCE]",
                    color = TerminalCyan,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { onInspect() }
                )
            }
        }
    }
}
