package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.MarketDataRepository
import com.example.ui.theme.*

@Composable
fun CalculationInspectorDialog(
    result: MarketDataRepository.NetbackCalculationResult,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CALCULATION PROVENANCE EXPLORER",
                        color = GrainGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${result.commodityName} • UK Physical Netback Model",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Summary Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BritishRacingGreen, RoundedCornerShape(6.dp))
                        .border(1.dp, BritishRacingGreenAccent, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "NET FARM REALISATION",
                            color = TextGold,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "£${"%.2f".format(result.netFarmRealisation)} / tonne",
                            color = PriceGreen,
                            fontSize = 22.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Total Lot Net Value: £${"%,.2f".format(result.totalLotValueNet)} (Gross: £${"%,.2f".format(result.totalLotValueGross)})",
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "DECOMPOSITION WATERFALL",
                    color = GrainGoldLight,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                result.formulaProvenanceSteps.forEachIndexed { index, (label, amount) ->
                    val isFinal = index == result.formulaProvenanceSteps.lastIndex
                    val isDeduction = amount < 0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isFinal) BritishRacingGreen.copy(alpha = 0.4f) else Color.Transparent)
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = if (isFinal) GrainGold else TextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isFinal) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = when {
                                isFinal -> "£${"%.2f".format(amount)}/t"
                                amount > 0 -> "+£${"%.2f".format(amount)}/t"
                                amount < 0 -> "-£${"%.2f".format(-amount)}/t"
                                else -> "£0.00/t"
                            },
                            color = when {
                                isFinal -> PriceGreen
                                isDeduction -> PriceRed
                                amount > 0 -> PriceGreen
                                else -> TextMuted
                            },
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Divider(color = TerminalCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Audit Standard: ISO-Agri/AHDB physical commodity specification v2026.3. All calculations preserve transparent unbundled logistics & quality tolerances.",
                    color = TextMuted,
                    fontSize = 9.sp,
                    lineHeight = 13.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreenBright)
            ) {
                Text("CLOSE INSPECTOR", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        },
        containerColor = TerminalCardBackground
    )
}
