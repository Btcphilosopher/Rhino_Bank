package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CropBalanceSheet
import com.example.ui.TerminalViewModel
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun BalanceSheetInventoryScreen(
    viewModel: TerminalViewModel
) {
    val balanceSheets by viewModel.balanceSheets.collectAsState()
    val regions by viewModel.ukRegions.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Module Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "UK CROP BALANCE SHEETS & STORAGE INVENTORY",
                            color = GrainGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "AHDB / DEFRA National Supply & Demand Matrix (Thousand Tonnes)",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }

                    ProvenanceBadge(
                        status = com.example.data.model.ObservationStatus.PUBLISHED,
                        source = com.example.data.model.ProvenanceSource.AHDB
                    )
                }
            }
        }

        // UK Crop Balance Sheets (Wheat, Barley, Rapeseed)
        items(balanceSheets) { sheet ->
            BalanceSheetCard(sheet = sheet)
        }

        // Regional Grain Store Utilisation Matrix
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalCardBorder)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "REGIONAL GRAIN STORAGE UTILISATION",
                        color = GrainGold,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Commercial Silos & On-Farm Certified Capacity by Agricultural Zone",
                        color = TextMuted,
                        fontSize = 8.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    regions.forEach { reg ->
                        Column(modifier = Modifier.padding(vertical = 3.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(reg.name, color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Text("${reg.storageUtilPct}% Full (${"%,.0f".format(reg.availableGrainTonnes)}t available)", color = GrainGoldLight, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                            LinearProgressIndicator(
                                progress = { (reg.storageUtilPct / 100f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .padding(top = 2.dp),
                                color = if (reg.storageUtilPct > 80) PriceRed else if (reg.storageUtilPct > 65) GrainGold else PriceGreen,
                                trackColor = TerminalBlack
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun BalanceSheetCard(sheet: CropBalanceSheet) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalCardBackground),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BritishRacingGreenAccent)),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${sheet.cropName.uppercase()} (${sheet.marketingYear})",
                    color = GrainGold,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Stock-to-Use: ${sheet.stockToUsePct}%",
                    color = if (sheet.stockToUsePct < 12.0) PriceRed else PriceGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Grid of Balance Sheet line items
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                BalanceLine("Opening Stock", sheet.openingStockKt)
                BalanceLine("Production", sheet.productionKt)
                BalanceLine("Imports", sheet.importsKt)
                BalanceLine("Total Supply", sheet.totalAvailabilityKt, isBold = true)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Divider(color = TerminalCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                BalanceLine("Food/Milling", sheet.humanIndustrialUseKt)
                BalanceLine("Animal Feed", sheet.animalFeedKt)
                BalanceLine("Exports", sheet.exportsKt)
                BalanceLine("Ending Stock", sheet.closingStockKt, isBold = true, highlight = true)
            }
        }
    }
}

@Composable
private fun BalanceLine(label: String, valueKt: Double, isBold: Boolean = false, highlight: Boolean = false) {
    Column(modifier = Modifier.widthIn(min = 60.dp)) {
        Text(label, color = TextMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
        Text(
            text = "${"%,.0f".format(valueKt)} kt",
            color = if (highlight) GrainGoldLight else if (isBold) TextPrimary else TextSecondary,
            fontSize = 9.5.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace
        )
    }
}
