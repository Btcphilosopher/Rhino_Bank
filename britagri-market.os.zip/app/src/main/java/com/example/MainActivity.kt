package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.TerminalScreen
import com.example.ui.TerminalViewModel
import com.example.ui.components.CalculationInspectorDialog
import com.example.ui.components.CommandHelpDialog
import com.example.ui.components.TerminalTopBar
import com.example.ui.screens.*
import com.example.ui.theme.BritAgriTheme
import com.example.ui.theme.TerminalBlack

class MainActivity : ComponentActivity() {
    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BritAgriTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()
                val commodities by viewModel.commodities.collectAsState()
                val lastBstTime by viewModel.lastTickTime.collectAsState()
                val selectedRole by viewModel.selectedRole.collectAsState()
                val commandFeedback by viewModel.commandFeedback.collectAsState()
                val inspectedCalculation by viewModel.inspectedCalculation.collectAsState()

                var showHelpDialog by remember { mutableStateOf(false) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TerminalTopBar(
                            commodities = commodities,
                            lastBstTime = lastBstTime,
                            currentScreen = currentScreen,
                            selectedRole = selectedRole,
                            onRoleSelected = { viewModel.setRole(it) },
                            onScreenSelected = { viewModel.setScreen(it) },
                            onExecuteCommand = { viewModel.executeCommandLine(it) },
                            commandFeedback = commandFeedback,
                            onClearFeedback = { viewModel.clearFeedback() },
                            onShowHelp = { showHelpDialog = true }
                        )
                    },
                    containerColor = TerminalBlack
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(TerminalBlack)
                    ) {
                        when (currentScreen) {
                            TerminalScreen.BRITAIN_NOW -> BritainNowScreen(
                                viewModel = viewModel,
                                onNavigate = { viewModel.setScreen(it) }
                            )
                            TerminalScreen.MARKET_WATCH -> MarketWatchScreenerScreen(
                                viewModel = viewModel
                            )
                            TerminalScreen.FARMER_DESK -> FarmerTerminalScreen(
                                viewModel = viewModel
                            )
                            TerminalScreen.PROCESSOR_DESK -> ProcessorTerminalScreen(
                                viewModel = viewModel
                            )
                            TerminalScreen.CURVES_BASIS -> CurvesAndBasisScreen(
                                viewModel = viewModel
                            )
                            TerminalScreen.SCENARIO_LAB -> ScenarioLabScreen(
                                viewModel = viewModel
                            )
                            TerminalScreen.BALANCE_SHEET -> BalanceSheetInventoryScreen(
                                viewModel = viewModel
                            )
                            TerminalScreen.NETWORK_TWIN -> MarketGraphTwinScreen(
                                viewModel = viewModel
                            )
                        }

                        // Inspection Dialog if active
                        inspectedCalculation?.let { result ->
                            CalculationInspectorDialog(
                                result = result,
                                onDismiss = { viewModel.closeCalculationInspector() }
                            )
                        }

                        // Help Directory Dialog
                        if (showHelpDialog) {
                            CommandHelpDialog(
                                onDismiss = { showHelpDialog = false },
                                onRunCommand = { viewModel.executeCommandLine(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}
