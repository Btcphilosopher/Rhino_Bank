package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_orders")
data class CustomOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val commodityCode: String,
    val commodityName: String,
    val orderType: String, // "OFFER_SELL" or "BID_BUY"
    val quantityTonnes: Double,
    val targetPricePerTonne: Double,
    val region: String,
    val location: String,
    val deliveryMonth: String,
    val qualityGrade: String,
    val certification: String, // "Red Tractor Assured", "TASCC", "Organic"
    val storageType: String, // "On-Farm Bin", "Central Silo", "Processor Delivered"
    val contactEntity: String,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "farm_margin_scenarios")
data class MarginScenarioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val enterpriseType: String, // "ARABLE_WHEAT", "LIVESTOCK_BEEF", "DAIRY_MILK"
    val cropOrStock: String,
    val areaHaOrHead: Double,
    val yieldPerHaOrDeadweight: Double,
    val sellingPrice: Double,
    val totalRevenue: Double,
    val variableCosts: Double,
    val fixedMachineryLabour: Double,
    val dryingStorageFreight: Double,
    val grossMarginTotal: Double,
    val marginPerUnit: Double,
    val breakevenPrice: Double,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "terminal_audit_logs")
data class TerminalAuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userRole: String,
    val actionType: String,
    val targetEntity: String,
    val benchmarkReference: String,
    val calculatedNetback: Double,
    val provenanceModel: String,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_watchlist")
data class WatchlistEntity(
    @PrimaryKey val commodityId: String,
    val pinnedOrder: Int = 0,
    val notes: String = "",
    val priceAlertLow: Double? = null,
    val priceAlertHigh: Double? = null
)
