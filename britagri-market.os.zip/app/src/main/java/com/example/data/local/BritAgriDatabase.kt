package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CustomOrderEntity::class,
        MarginScenarioEntity::class,
        TerminalAuditEntity::class,
        WatchlistEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BritAgriDatabase : RoomDatabase() {
    abstract fun customOrderDao(): CustomOrderDao
    abstract fun marginScenarioDao(): MarginScenarioDao
    abstract fun terminalAuditDao(): TerminalAuditDao
    abstract fun watchlistDao(): WatchlistDao

    companion object {
        @Volatile
        private var INSTANCE: BritAgriDatabase? = null

        fun getDatabase(context: Context): BritAgriDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BritAgriDatabase::class.java,
                    "britagri_market_terminal.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
