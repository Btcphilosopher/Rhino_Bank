package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomOrderDao {
    @Query("SELECT * FROM custom_orders ORDER BY timestampMs DESC")
    fun getAllOrders(): Flow<List<CustomOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: CustomOrderEntity): Long

    @Query("DELETE FROM custom_orders WHERE id = :orderId")
    suspend fun deleteOrder(orderId: Long)
}

@Dao
interface MarginScenarioDao {
    @Query("SELECT * FROM farm_margin_scenarios ORDER BY timestampMs DESC")
    fun getAllScenarios(): Flow<List<MarginScenarioEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenario(scenario: MarginScenarioEntity): Long

    @Query("DELETE FROM farm_margin_scenarios WHERE id = :id")
    suspend fun deleteScenario(id: Long)
}

@Dao
interface TerminalAuditDao {
    @Query("SELECT * FROM terminal_audit_logs ORDER BY timestampMs DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<TerminalAuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TerminalAuditEntity): Long
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM user_watchlist ORDER BY pinnedOrder ASC")
    fun getWatchlist(): Flow<List<WatchlistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: WatchlistEntity)

    @Query("DELETE FROM user_watchlist WHERE commodityId = :commodityId")
    suspend fun remove(commodityId: String)
}
