package com.example.data.model

enum class CommodityCategory(val displayName: String, val badgeColorHex: Long) {
    ARABLE("Arable & Grains", 0xFFE5A93C),
    LIVESTOCK("Livestock & Meat", 0xFFEF4444),
    DAIRY("Dairy Complex", 0xFF38BDF8),
    ROOTS_PRODUCE("Roots & Fresh Produce", 0xFF10B981),
    INPUTS_ENERGY("Inputs & Energy", 0xFFA855F7)
}

enum class ObservationStatus(val label: String, val description: String) {
    LIVE("LIVE", "Real-time exchange/order matched data"),
    RECENT("RECENT", "Observed transaction within last 2 hours"),
    DELAYED("DELAYED", "Exchange reference delayed 15 mins"),
    PUBLISHED("PUBLISHED", "Verified survey index (AHDB/Defra/ONS)"),
    MODELLED("MODELLED", "Derived mathematical conversion/parity"),
    SYNTHETIC("SYNTHETIC", "Deterministic baseline simulated market"),
    INDICATIVE("INDICATIVE", "Indicative merchant spot quotation"),
    ESTIMATED("ESTIMATED", "Econometric regional extrapolation"),
    FORECAST("FORECAST", "Forward seasonal yield projection")
}

enum class ProvenanceSource(val shortCode: String, val fullName: String) {
    AHDB("AHDB", "Agriculture and Horticulture Development Board"),
    DEFRA("DEFRA", "Department for Environment, Food & Rural Affairs"),
    ICE_LIFFE("ICE", "ICE Futures Europe (UK Feed Wheat)"),
    UK_MET_OFFICE("MET", "UK Met Office Agro-Meteorology"),
    BALTIC_EXCHANGE("BALTIC", "Baltic Freight Index & UK Road Haulage"),
    RED_TRACTOR("RT", "Assured Food Standards (Red Tractor)"),
    SYNTHETIC_ENGINE("SIM_OS", "BritAgri Deterministic Microstructure Engine"),
    MERCHANT_CONSORTIUM("MKT_GB", "UK Grain & Feed Trade Association Merchants")
}

data class Commodity(
    val id: String,
    val name: String,
    val ticker: String,
    val category: CommodityCategory,
    val unit: String,
    val spotPrice: Double,
    val change: Double,
    val changePct: Double,
    val high24h: Double,
    val low24h: Double,
    val volumeTonnes: Double,
    val futuresReference: Double?,
    val defaultBasis: Double,
    val status: ObservationStatus,
    val source: ProvenanceSource,
    val description: String
)

data class QualitySpec(
    val moisturePct: Double = 14.5,
    val proteinPct: Double = 11.0,
    val specificWeightKgHl: Double = 76.0,
    val hagbergFallingNumber: Int = 250,
    val screeningsPct: Double = 1.8,
    val fatClass: String = "4L",
    val conformation: String = "R",
    val butterfatPct: Double = 4.15,
    val milkProteinPct: Double = 3.35,
    val sccKml: Int = 165
)

data class MarketObservation(
    val id: String,
    val commodityId: String,
    val commodityName: String,
    val region: String,
    val locationNode: String,
    val grade: String,
    val bid: Double,
    val offer: Double,
    val mid: Double,
    val volume: Double,
    val transportCostEst: Double,
    val storageCostEst: Double,
    val basisToFutures: Double,
    val qualitySpec: QualitySpec,
    val timestamp: String,
    val status: ObservationStatus,
    val source: ProvenanceSource,
    val confidencePct: Int
)

data class UKRegionInfo(
    val id: String,
    val name: String,
    val shortCode: String,
    val latitude: Double,
    val longitude: Double,
    val primaryProduce: String,
    val wheatSpot: Double,
    val barleySpot: Double,
    val rapeseedSpot: Double,
    val milkPpl: Double,
    val cattleDeadweightP: Double,
    val storageUtilPct: Int,
    val availableGrainTonnes: Double,
    val activeHauliers: Int,
    val basisDiff: Double
)

data class OrderBookLevel(
    val price: Double,
    val volumeTonnes: Double,
    val orderCount: Int,
    val isSynthetic: Boolean = true
)

data class CommodityOrderBook(
    val commodityId: String,
    val commodityName: String,
    val region: String,
    val lastPrice: Double,
    val bids: List<OrderBookLevel>,
    val offers: List<OrderBookLevel>,
    val spread: Double,
    val isSimulatedLiquidity: Boolean = true
)

data class ForwardCurvePoint(
    val period: String,
    val deliveryMonthYear: String,
    val futuresRef: Double,
    val basis: Double,
    val deliveredPrice: Double,
    val storageCarryCost: Double,
    val netCarryMargin: Double,
    val openInterestTonnes: Double
)

data class SpreadMetric(
    val id: String,
    val title: String,
    val legA: String,
    val legB: String,
    val currentSpread: Double,
    val unit: String,
    val historical30dMean: Double,
    val zScore: Double,
    val correlation: Double,
    val physicalArbitrageFeasible: Boolean,
    val rationale: String
)

data class DairyComplexValue(
    val farmgatePpl: Double,
    val butterPerTonne: Double,
    val smpPerTonne: Double,
    val mildCheddarPerTonne: Double,
    val spotCreamPerTonne: Double,
    val wheyPowderPerTonne: Double,
    val ampePpl: Double, // Actual Milk Price Equivalent
    val mcvePpl: Double, // Milk to Cheese Value Equivalent
    val mmvPpl: Double,  // Marginal Milk Value
    val standardFatPct: Double = 4.0,
    val standardProteinPct: Double = 3.3
)

data class CropBalanceSheet(
    val cropName: String,
    val marketingYear: String,
    val openingStockKt: Double,
    val productionKt: Double,
    val importsKt: Double,
    val totalAvailabilityKt: Double,
    val humanIndustrialUseKt: Double,
    val animalFeedKt: Double,
    val seedAndWasteKt: Double,
    val exportsKt: Double,
    val totalConsumptionKt: Double,
    val closingStockKt: Double,
    val stockToUsePct: Double,
    val importDependencyPct: Double
)

data class ScenarioDefinition(
    val id: String,
    val name: String,
    val subtitle: String,
    val iconName: String,
    val rainPct: Double,
    val cropYieldPct: Double,
    val feedDemandPct: Double,
    val milkDeliveryPct: Double,
    val fertiliserPct: Double,
    val dieselPct: Double,
    val freightPct: Double,
    val wheatPriceDeltaPct: Double,
    val barleyPriceDeltaPct: Double,
    val milkPriceDeltaPct: Double,
    val cattlePriceDeltaPct: Double,
    val propagationSteps: List<String>
)

data class SupplyChainNode(
    val id: String,
    val name: String,
    val nodeType: NodeType,
    val region: String,
    val capacityTonnes: Double,
    val currentLoadPct: Int,
    val throughputTonnesPerDay: Double,
    val xRatio: Float,
    val yRatio: Float
) {
    enum class NodeType {
        FARM_ORIGIN,
        GRAIN_STORE,
        FLOUR_MILL,
        FEED_MILL,
        DAIRY_PROCESSING,
        ABATTOIR,
        CARGO_PORT,
        DISTRIBUTION_HUB
    }
}

data class SupplyChainFlowEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val commodity: String,
    val flowTonnesPerDay: Double,
    val freightCostPerTonne: Double,
    val isBottleneck: Boolean
)

enum class AppTerminalRole(val title: String, val badge: String, val description: String) {
    FARMER("Farmer / Grower", "PRODUCER", "Netback farmgate pricing, quality deductions, margin modelling"),
    MERCHANT("Grain Merchant", "TRADER", "Regional basis, spreads, bulk collection, storage carry"),
    PROCESSOR("Mill / Food Processor", "BUYER", "Procurement coverage, pipeline orders, quality matching"),
    DAIRY_PROC("Dairy & Creamery", "DAIRY", "AMPE / MCVE conversion, milk fat & protein yield pricing"),
    LIVESTOCK_OPERATOR("Livestock Operator", "FEEDLOT", "Finished deadweight SQQ, feed conversion margin"),
    ANALYST("Market Quant / Analyst", "RESEARCH", "Supply-demand balance sheets, shock scenarios, macro basis")
}
