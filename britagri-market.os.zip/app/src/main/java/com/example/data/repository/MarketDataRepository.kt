package com.example.data.repository

import com.example.data.local.BritAgriDatabase
import com.example.data.local.CustomOrderEntity
import com.example.data.local.MarginScenarioEntity
import com.example.data.local.TerminalAuditEntity
import com.example.data.local.WatchlistEntity
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

class MarketDataRepository(
    private val database: BritAgriDatabase,
    private val scope: CoroutineScope
) {
    private val _commodities = MutableStateFlow<List<Commodity>>(emptyList())
    val commodities: StateFlow<List<Commodity>> = _commodities.asStateFlow()

    private val _observations = MutableStateFlow<List<MarketObservation>>(emptyList())
    val observations: StateFlow<List<MarketObservation>> = _observations.asStateFlow()

    private val _ukRegions = MutableStateFlow<List<UKRegionInfo>>(emptyList())
    val ukRegions: StateFlow<List<UKRegionInfo>> = _ukRegions.asStateFlow()

    private val _spreads = MutableStateFlow<List<SpreadMetric>>(emptyList())
    val spreads: StateFlow<List<SpreadMetric>> = _spreads.asStateFlow()

    private val _dairyComplex = MutableStateFlow<DairyComplexValue?>(null)
    val dairyComplex: StateFlow<DairyComplexValue?> = _dairyComplex.asStateFlow()

    private val _balanceSheets = MutableStateFlow<List<CropBalanceSheet>>(emptyList())
    val balanceSheets: StateFlow<List<CropBalanceSheet>> = _balanceSheets.asStateFlow()

    private val _supplyChainNodes = MutableStateFlow<List<SupplyChainNode>>(emptyList())
    val supplyChainNodes: StateFlow<List<SupplyChainNode>> = _supplyChainNodes.asStateFlow()

    private val _supplyChainFlows = MutableStateFlow<List<SupplyChainFlowEdge>>(emptyList())
    val supplyChainFlows: StateFlow<List<SupplyChainFlowEdge>> = _supplyChainFlows.asStateFlow()

    private val _terminalStatus = MutableStateFlow("MARKET LIVE • AHDB / DEFRA / SYNTHETIC STREAM ACTIVE")
    val terminalStatus: StateFlow<String> = _terminalStatus.asStateFlow()

    private val _lastTickTime = MutableStateFlow(getCurrentBstTime())
    val lastTickTime: StateFlow<String> = _lastTickTime.asStateFlow()

    private val rng = Random(42) // Deterministic seed for reproducible baseline

    val customOrders: Flow<List<CustomOrderEntity>> = database.customOrderDao().getAllOrders()
    val marginScenarios: Flow<List<MarginScenarioEntity>> = database.marginScenarioDao().getAllScenarios()
    val auditLogs: Flow<List<TerminalAuditEntity>> = database.terminalAuditDao().getRecentAuditLogs()
    val watchlist: Flow<List<WatchlistEntity>> = database.watchlistDao().getWatchlist()

    init {
        initializeBaselineData()
        startLiveMarketSimulation()
    }

    private fun getCurrentBstTime(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy • HH:mm:ss 'BST'", Locale.UK)
        sdf.timeZone = TimeZone.getTimeZone("Europe/London")
        return sdf.format(Date())
    }

    private fun initializeBaselineData() {
        val initialCommodities = listOf(
            Commodity(
                id = "WHEAT_FEED",
                name = "UK Feed Wheat",
                ticker = "W-FEED",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 186.40,
                change = 1.20,
                changePct = 0.65,
                high24h = 187.80,
                low24h = 184.90,
                volumeTonnes = 48500.0,
                futuresReference = 188.50,
                defaultBasis = -2.10,
                status = ObservationStatus.LIVE,
                source = ProvenanceSource.ICE_LIFFE,
                description = "Standard UK feed wheat delivered East Anglia / Humber, max 15% moisture, 72kg/hl"
            ),
            Commodity(
                id = "WHEAT_MILL",
                name = "UK Bread Wheat (Grp 1)",
                ticker = "W-MILL1",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 224.50,
                change = 2.50,
                changePct = 1.13,
                high24h = 226.00,
                low24h = 221.80,
                volumeTonnes = 16200.0,
                futuresReference = 188.50,
                defaultBasis = 36.00,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "Group 1 Milling Wheat, min 13.0% protein, 250s Hagberg, 76kg/hl specific weight"
            ),
            Commodity(
                id = "BARLEY_FEED",
                name = "UK Feed Barley",
                ticker = "BAR-FEED",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 164.80,
                change = -0.70,
                changePct = -0.42,
                high24h = 166.00,
                low24h = 164.20,
                volumeTonnes = 29400.0,
                futuresReference = null,
                defaultBasis = -21.60,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "UK feed barley delivered merchant store, max 15% moisture, 63kg/hl specific weight"
            ),
            Commodity(
                id = "BARLEY_MALT",
                name = "UK Malting Barley",
                ticker = "BAR-MALT",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 196.20,
                change = 0.80,
                changePct = 0.41,
                high24h = 197.50,
                low24h = 195.00,
                volumeTonnes = 11800.0,
                futuresReference = null,
                defaultBasis = 9.80,
                status = ObservationStatus.RECENT,
                source = ProvenanceSource.MERCHANT_CONSORTIUM,
                description = "Spring malting barley (Planet/Laureate), max 1.65% N, min 95% germination"
            ),
            Commodity(
                id = "RAPESEED_OSR",
                name = "Oilseed Rape (00)",
                ticker = "OSR-40",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 421.00,
                change = 2.50,
                changePct = 0.60,
                high24h = 424.00,
                low24h = 418.00,
                volumeTonnes = 14300.0,
                futuresReference = 426.50,
                defaultBasis = -5.50,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "Double-zero rapeseed, basis 40% oil, 9% moisture, 2% admixture delivered crush"
            ),
            Commodity(
                id = "OATS_MILL",
                name = "UK Milling Oats",
                ticker = "OAT-MILL",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 188.00,
                change = -1.10,
                changePct = -0.58,
                high24h = 190.00,
                low24h = 187.50,
                volumeTonnes = 6400.0,
                futuresReference = null,
                defaultBasis = 1.60,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "Milling oats delivered millers, min 50kg/hl, max 6% screenings, max 15% moisture"
            ),
            Commodity(
                id = "BEANS_FIELD",
                name = "UK Feed Beans",
                ticker = "PULSE-BN",
                category = CommodityCategory.ARABLE,
                unit = "£/t",
                spotPrice = 216.00,
                change = 0.00,
                changePct = 0.00,
                high24h = 217.00,
                low24h = 215.50,
                volumeTonnes = 5200.0,
                futuresReference = null,
                defaultBasis = 29.60,
                status = ObservationStatus.RECENT,
                source = ProvenanceSource.MERCHANT_CONSORTIUM,
                description = "Winter/Spring field feed beans, max 15% moisture, max 2% bruchid damage"
            ),
            Commodity(
                id = "POTATO_PACK",
                name = "Packing Potatoes (Piper)",
                ticker = "POT-PIPE",
                category = CommodityCategory.ROOTS_PRODUCE,
                unit = "£/t",
                spotPrice = 214.00,
                change = 3.00,
                changePct = 1.42,
                high24h = 218.00,
                low24h = 210.00,
                volumeTonnes = 18900.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.INDICATIVE,
                source = ProvenanceSource.SYNTHETIC_ENGINE,
                description = "Grade 1 Maris Piper packing grade, box stored, washed standard"
            ),
            Commodity(
                id = "SUGAR_BEET",
                name = "UK Sugar Beet",
                ticker = "BEET-SUG",
                category = CommodityCategory.ROOTS_PRODUCE,
                unit = "£/t",
                spotPrice = 37.50,
                change = 0.00,
                changePct = 0.00,
                high24h = 37.50,
                low24h = 37.50,
                volumeTonnes = 85000.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.DEFRA,
                description = "British Sugar contract delivered factory, adjusted to 16.0% sugar content"
            ),
            Commodity(
                id = "CATTLE_DEADWT",
                name = "Finished Cattle (R4L)",
                ticker = "CAT-R4L",
                category = CommodityCategory.LIVESTOCK,
                unit = "p/kg",
                spotPrice = 621.0,
                change = 4.0,
                changePct = 0.65,
                high24h = 624.0,
                low24h = 618.0,
                volumeTonnes = 7400.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "Great Britain deadweight steer/heifer, EUROP grid conformation R, Fat class 4L"
            ),
            Commodity(
                id = "LAMB_SQQ",
                name = "Finished Lamb SQQ",
                ticker = "LAMB-SQQ",
                category = CommodityCategory.LIVESTOCK,
                unit = "p/kg",
                spotPrice = 708.0,
                change = -3.0,
                changePct = -0.42,
                high24h = 715.0,
                low24h = 705.0,
                volumeTonnes = 3200.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "Standard Quality Quotation (25.5kg - 45.5kg liveweight equivalent/deadweight)"
            ),
            Commodity(
                id = "PIG_SPP",
                name = "Finished Pigs (SPP)",
                ticker = "PIG-SPP",
                category = CommodityCategory.LIVESTOCK,
                unit = "p/kg",
                spotPrice = 191.0,
                change = 1.0,
                changePct = 0.53,
                high24h = 192.5,
                low24h = 189.5,
                volumeTonnes = 9800.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.AHDB,
                description = "Standard Pig Price (EU-Spec deadweight, 70-105kg carcase weight)"
            ),
            Commodity(
                id = "MILK_FARMGATE",
                name = "UK Farmgate Milk",
                ticker = "MILK-STD",
                category = CommodityCategory.DAIRY,
                unit = "ppl",
                spotPrice = 35.00,
                change = 0.59,
                changePct = 1.71,
                high24h = 35.50,
                low24h = 34.20,
                volumeTonnes = 42000.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.DEFRA,
                description = "UK average farmgate milk price (pence per litre, 4.0% butterfat, 3.3% protein)"
            ),
            Commodity(
                id = "BUTTER_BULK",
                name = "Wholesale Butter (Salted)",
                ticker = "BUTTER-UK",
                category = CommodityCategory.DAIRY,
                unit = "£/t",
                spotPrice = 5820.00,
                change = 65.00,
                changePct = 1.13,
                high24h = 5850.00,
                low24h = 5740.00,
                volumeTonnes = 1400.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.MODELLED,
                source = ProvenanceSource.AHDB,
                description = "Bulk 25kg block salted butter wholesale ex-factory"
            ),
            Commodity(
                id = "SMP_DAIRY",
                name = "Skimmed Milk Powder",
                ticker = "SMP-DAIRY",
                category = CommodityCategory.DAIRY,
                unit = "£/t",
                spotPrice = 2180.00,
                change = 20.00,
                changePct = 0.93,
                high24h = 2200.00,
                low24h = 2150.00,
                volumeTonnes = 2800.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.MODELLED,
                source = ProvenanceSource.AHDB,
                description = "Spray dried skim milk powder, food grade, low heat"
            ),
            Commodity(
                id = "CHEDDAR_MILD",
                name = "Mild Cheddar (Bulk)",
                ticker = "CHED-MLD",
                category = CommodityCategory.DAIRY,
                unit = "£/t",
                spotPrice = 3940.00,
                change = 30.00,
                changePct = 0.77,
                high24h = 3980.00,
                low24h = 3900.00,
                volumeTonnes = 3100.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.MODELLED,
                source = ProvenanceSource.AHDB,
                description = "Block mild UK cheddar 20kg wholesale delivered UK"
            ),
            Commodity(
                id = "UREA_UK",
                name = "Granular Urea (46% N)",
                ticker = "FERT-UREA",
                category = CommodityCategory.INPUTS_ENERGY,
                unit = "£/t",
                spotPrice = 338.00,
                change = 4.00,
                changePct = 1.20,
                high24h = 342.00,
                low24h = 334.00,
                volumeTonnes = 12500.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.RECENT,
                source = ProvenanceSource.MERCHANT_CONSORTIUM,
                description = "Imported granular urea 46% N, 600kg big bags on-farm delivery"
            ),
            Commodity(
                id = "AN_FERT",
                name = "Ammonium Nitrate (34.5%)",
                ticker = "FERT-AN34",
                category = CommodityCategory.INPUTS_ENERGY,
                unit = "£/t",
                spotPrice = 322.00,
                change = 2.00,
                changePct = 0.62,
                high24h = 325.00,
                low24h = 319.00,
                volumeTonnes = 9800.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.RECENT,
                source = ProvenanceSource.MERCHANT_CONSORTIUM,
                description = "UK/European manufactured 34.5% N ammonium nitrate on-farm delivery"
            ),
            Commodity(
                id = "RED_DIESEL",
                name = "Red Diesel (Gas Oil)",
                ticker = "FUEL-RDIES",
                category = CommodityCategory.INPUTS_ENERGY,
                unit = "p/L",
                spotPrice = 74.80,
                change = 0.40,
                changePct = 0.54,
                high24h = 75.50,
                low24h = 74.10,
                volumeTonnes = 35000.0,
                futuresReference = null,
                defaultBasis = 0.0,
                status = ObservationStatus.PUBLISHED,
                source = ProvenanceSource.BALTIC_EXCHANGE,
                description = "Off-road agricultural red diesel (gas oil 10ppm), 10,000L bulk dropped"
            )
        )
        _commodities.value = initialCommodities

        val regions = listOf(
            UKRegionInfo("EAST_ANGLIA", "East Anglia", "EA", 52.4, 0.9, "Arable Grains / Sugar Beet / Onions", 188.10, 166.20, 424.50, 35.10, 622.0, 78, 124000.0, 84, 1.70),
            UKRegionInfo("YORKSHIRE", "Yorkshire & Humber", "YKS", 53.8, -1.0, "Milling Wheat / Pigs / Potatoes", 184.70, 161.90, 418.00, 34.80, 620.5, 72, 98000.0, 62, -1.70),
            UKRegionInfo("EAST_MIDLANDS", "East Midlands", "EM", 52.9, -0.8, "Feed Wheat / Rapeseed / Beef", 186.20, 164.50, 421.00, 35.00, 621.0, 68, 76000.0, 58, -0.20),
            UKRegionInfo("WEST_MIDLANDS", "West Midlands", "WM", 52.5, -2.2, "Dairy / Beef / Cereals", 185.00, 163.00, 419.00, 35.40, 623.0, 60, 42000.0, 45, -1.40),
            UKRegionInfo("NORTH_WEST", "North West & Cheshire", "NW", 53.7, -2.7, "Dairy / Feed Compounders", 182.90, 159.80, 415.00, 35.80, 624.0, 54, 31000.0, 38, -3.50),
            UKRegionInfo("NORTH_EAST", "North East England", "NE", 55.0, -1.7, "Feed Barley / Sheep", 183.50, 160.50, 416.00, 34.60, 619.0, 59, 39000.0, 29, -2.90),
            UKRegionInfo("SOUTH_WEST", "South West (Devon/Corn)", "SW", 50.8, -3.8, "Grass Dairy / Finished Cattle / Lamb", 187.50, 165.00, 422.00, 36.20, 625.0, 62, 28000.0, 52, 1.10),
            UKRegionInfo("SOUTH_EAST", "South East & Home Counties", "SE", 51.2, 0.4, "Milling Wheat / OSR / Port Export", 189.20, 167.00, 426.00, 34.90, 621.5, 81, 88000.0, 67, 2.80),
            UKRegionInfo("SCOTLAND", "Scotland (Borders & NE)", "SCOT", 56.5, -3.2, "Malting Barley / Seed Potatoes / Angus", 182.00, 168.50, 412.00, 35.20, 628.0, 65, 84000.0, 41, -4.40),
            UKRegionInfo("WALES", "Wales (Ceredigion & Powys)", "WAL", 52.3, -3.7, "Upland Sheep / Pasture Cattle / Dairy", 184.00, 161.00, 417.00, 35.50, 618.0, 48, 14000.0, 32, -2.40),
            UKRegionInfo("NORTHERN_IRELAND", "Northern Ireland", "NI", 54.6, -6.5, "Intensive Dairy / Poultry / Pigs", 192.50, 172.00, 428.00, 36.80, 595.0, 70, 22000.0, 26, 6.10)
        )
        _ukRegions.value = regions

        // Initial Spread metrics
        val spreadsList = listOf(
            SpreadMetric(
                id = "SP_WHEAT_BARLEY",
                title = "Wheat vs Feed Barley Spread",
                legA = "UK Feed Wheat (£186.40)",
                legB = "UK Feed Barley (£164.80)",
                currentSpread = 21.60,
                unit = "£/t",
                historical30dMean = 20.40,
                zScore = 0.58,
                correlation = 0.91,
                physicalArbitrageFeasible = true,
                rationale = "Feed compounders switch barley inclusion at >£18/t discount to wheat"
            ),
            SpreadMetric(
                id = "SP_OSR_WHEAT",
                title = "Rapeseed / Wheat Crush Ratio",
                legA = "Oilseed Rape (£421.00)",
                legB = "Feed Wheat (£186.40)",
                currentSpread = 2.26,
                unit = "ratio",
                historical30dMean = 2.18,
                zScore = 0.82,
                correlation = 0.64,
                physicalArbitrageFeasible = false,
                rationale = "Above 2.20x historical average, incentivising UK arable acreage expansion into winter OSR"
            ),
            SpreadMetric(
                id = "SP_UREA_WHEAT",
                title = "Fertiliser to Wheat Ratio",
                legA = "Urea 46% N (£338.00)",
                legB = "Feed Wheat (£186.40)",
                currentSpread = 1.81,
                unit = "ratio",
                historical30dMean = 1.88,
                zScore = -0.35,
                correlation = 0.72,
                physicalArbitrageFeasible = false,
                rationale = "Economic nitrogen breakeven threshold is 2.2kg wheat/kg N applied"
            ),
            SpreadMetric(
                id = "SP_MILK_FEED",
                title = "Milk to Feed Price Ratio",
                legA = "Farmgate Milk (35.00 ppl)",
                legB = "Compound Cattle Feed (26.50 ppl eq)",
                currentSpread = 1.32,
                unit = "ratio",
                historical30dMean = 1.25,
                zScore = 0.70,
                correlation = -0.38,
                physicalArbitrageFeasible = true,
                rationale = "Healthy dairy margin buffer above 1.15x critical cost-of-production floor"
            ),
            SpreadMetric(
                id = "SP_BEEF_FEED",
                title = "Finished Beef / Barley Ratio",
                legA = "Cattle R4L (621.0 p/kg)",
                legB = "Feed Barley (16.48 p/kg)",
                currentSpread = 37.68,
                unit = "ratio",
                historical30dMean = 35.20,
                zScore = 1.12,
                correlation = -0.45,
                physicalArbitrageFeasible = true,
                rationale = "Strong beef returns encouraging intensive intensive cereal bull finishing"
            )
        )
        _spreads.value = spreadsList

        // Dairy Complex baseline
        _dairyComplex.value = calculateDairyComplex(35.00, 5820.0, 2180.0, 3940.0, 2650.0, 840.0)

        // Balance sheets
        _balanceSheets.value = listOf(
            CropBalanceSheet(
                cropName = "UK Wheat (Total)",
                marketingYear = "2026/27 Forecast",
                openingStockKt = 2140.0,
                productionKt = 13850.0,
                importsKt = 1650.0,
                totalAvailabilityKt = 17640.0,
                humanIndustrialUseKt = 7100.0,
                animalFeedKt = 6850.0,
                seedAndWasteKt = 520.0,
                exportsKt = 850.0,
                totalConsumptionKt = 15320.0,
                closingStockKt = 2320.0,
                stockToUsePct = 15.14,
                importDependencyPct = 9.35
            ),
            CropBalanceSheet(
                cropName = "UK Barley (Total)",
                marketingYear = "2026/27 Forecast",
                openingStockKt = 1050.0,
                productionKt = 6900.0,
                importsKt = 120.0,
                totalAvailabilityKt = 8070.0,
                humanIndustrialUseKt = 1950.0,
                animalFeedKt = 4100.0,
                seedAndWasteKt = 280.0,
                exportsKt = 820.0,
                totalConsumptionKt = 7150.0,
                closingStockKt = 920.0,
                stockToUsePct = 12.87,
                importDependencyPct = 1.48
            ),
            CropBalanceSheet(
                cropName = "UK Oilseed Rape",
                marketingYear = "2026/27 Forecast",
                openingStockKt = 85.0,
                productionKt = 890.0,
                importsKt = 780.0,
                totalAvailabilityKt = 1755.0,
                humanIndustrialUseKt = 1620.0,
                animalFeedKt = 0.0,
                seedAndWasteKt = 15.0,
                exportsKt = 25.0,
                totalConsumptionKt = 1660.0,
                closingStockKt = 95.0,
                stockToUsePct = 5.72,
                importDependencyPct = 44.44
            )
        )

        // Supply Chain Nodes for Britain Now
        val nodes = listOf(
            SupplyChainNode("N_EA_FARMS", "Lincolnshire & East Anglia Farms", SupplyChainNode.NodeType.FARM_ORIGIN, "East Anglia", 850000.0, 82, 12000.0, 0.70f, 0.58f),
            SupplyChainNode("N_YKS_FARMS", "Yorkshire Wolds Farms", SupplyChainNode.NodeType.FARM_ORIGIN, "Yorkshire", 540000.0, 74, 8500.0, 0.60f, 0.44f),
            SupplyChainNode("N_SW_DAIRY", "Devon & Somerset Dairy Pastures", SupplyChainNode.NodeType.FARM_ORIGIN, "South West", 420000.0, 88, 6200.0, 0.35f, 0.78f),
            SupplyChainNode("N_SCOT_FARMS", "Aberdeenshire & Borders", SupplyChainNode.NodeType.FARM_ORIGIN, "Scotland", 380000.0, 68, 5100.0, 0.52f, 0.22f),

            SupplyChainNode("N_BURY_STORE", "Bury St Edmunds Central Silo", SupplyChainNode.NodeType.GRAIN_STORE, "East Anglia", 180000.0, 78, 4500.0, 0.73f, 0.62f),
            SupplyChainNode("N_MAN_MILL", "Manchester Flour Mill", SupplyChainNode.NodeType.FLOUR_MILL, "North West", 95000.0, 85, 3800.0, 0.48f, 0.48f),
            SupplyChainNode("N_TILBURY_MILL", "Tilbury Port Flour Mill & Silos", SupplyChainNode.NodeType.FLOUR_MILL, "South East", 120000.0, 91, 5200.0, 0.72f, 0.70f),
            SupplyChainNode("N_FEED_DALSTON", "Cumbria Feed Mill", SupplyChainNode.NodeType.FEED_MILL, "North West", 60000.0, 65, 2400.0, 0.44f, 0.34f),
            SupplyChainNode("N_DAIRY_DAVID", "Davidstow Creamery (Cheddar)", SupplyChainNode.NodeType.DAIRY_PROCESSING, "South West", 80000.0, 92, 3100.0, 0.28f, 0.82f),
            SupplyChainNode("N_ABATTOIR_YKS", "Yorkshire Regional Abattoir", SupplyChainNode.NodeType.ABATTOIR, "Yorkshire", 45000.0, 79, 1800.0, 0.58f, 0.46f),
            SupplyChainNode("N_PORT_HULL", "Port of Hull Agri-Terminal", SupplyChainNode.NodeType.CARGO_PORT, "Yorkshire", 210000.0, 72, 6000.0, 0.66f, 0.46f),
            SupplyChainNode("N_PORT_BRISTOL", "Port of Bristol Grain Gateway", SupplyChainNode.NodeType.CARGO_PORT, "South West", 160000.0, 80, 4800.0, 0.42f, 0.68f)
        )
        _supplyChainNodes.value = nodes

        val flows = listOf(
            SupplyChainFlowEdge("N_EA_FARMS", "N_BURY_STORE", "Feed & Milling Wheat", 4200.0, 5.80, false),
            SupplyChainFlowEdge("N_BURY_STORE", "N_TILBURY_MILL", "Breadmaking Wheat", 3100.0, 9.40, false),
            SupplyChainFlowEdge("N_YKS_FARMS", "N_MAN_MILL", "Feed & Milling Wheat", 2800.0, 11.20, false),
            SupplyChainFlowEdge("N_YKS_FARMS", "N_PORT_HULL", "Export Feed Barley", 2100.0, 6.50, false),
            SupplyChainFlowEdge("N_SW_DAIRY", "N_DAIRY_DAVID", "Raw Milk (4.15% Fat)", 5400.0, 4.20, true), // High load
            SupplyChainFlowEdge("N_SCOT_FARMS", "N_FEED_DALSTON", "Feed Barley & Oats", 1800.0, 14.80, false),
            SupplyChainFlowEdge("N_EA_FARMS", "N_PORT_HULL", "Feed Wheat for Export", 1900.0, 12.50, false),
            SupplyChainFlowEdge("N_YKS_FARMS", "N_ABATTOIR_YKS", "Finished Cattle & Lamb", 1200.0, 7.80, false)
        )
        _supplyChainFlows.value = flows

        generateMarketObservations()
    }

    private fun generateMarketObservations() {
        val list = mutableListOf<MarketObservation>()
        val baseCommodities = _commodities.value
        val regions = _ukRegions.value
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.UK)
        val now = sdf.format(Date())

        for (comm in baseCommodities.take(10)) {
            for (reg in regions.take(6)) {
                val regionalPrice = comm.spotPrice + (reg.basisDiff * 0.8) + (rng.nextDouble(-0.8, 0.8))
                val roundedPrice = (regionalPrice * 100.0).roundToInt() / 100.0
                val spread = when (comm.category) {
                    CommodityCategory.ARABLE -> 1.50
                    CommodityCategory.LIVESTOCK -> 4.0
                    CommodityCategory.DAIRY -> 0.40
                    CommodityCategory.INPUTS_ENERGY -> 3.00
                    CommodityCategory.ROOTS_PRODUCE -> 2.50
                }
                val bid = ((roundedPrice - (spread / 2.0)) * 100.0).roundToInt() / 100.0
                val offer = ((roundedPrice + (spread / 2.0)) * 100.0).roundToInt() / 100.0
                val transport = ((6.0 + (rng.nextDouble(2.0, 9.0))) * 10.0).roundToInt() / 10.0
                val storage = ((4.20 + (rng.nextDouble(0.0, 1.5))) * 10.0).roundToInt() / 10.0

                list.add(
                    MarketObservation(
                        id = "${comm.id}_${reg.id}",
                        commodityId = comm.id,
                        commodityName = comm.name,
                        region = reg.name,
                        locationNode = "${reg.name} Hub Store",
                        grade = if (comm.id == "WHEAT_MILL") "Group 1 (13.0% Pro / 250 HFN)" else "Standard Market Spec",
                        bid = bid,
                        offer = offer,
                        mid = roundedPrice,
                        volume = (rng.nextInt(150, 4500) * 10).toDouble(),
                        transportCostEst = transport,
                        storageCostEst = storage,
                        basisToFutures = comm.futuresReference?.let { ((roundedPrice - it) * 100.0).roundToInt() / 100.0 } ?: reg.basisDiff,
                        qualitySpec = QualitySpec(),
                        timestamp = now,
                        status = if (rng.nextBoolean()) ObservationStatus.RECENT else ObservationStatus.PUBLISHED,
                        source = comm.source,
                        confidencePct = rng.nextInt(92, 99)
                    )
                )
            }
        }
        _observations.value = list
    }

    private fun startLiveMarketSimulation() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(3000) // Update every 3 seconds
                _lastTickTime.value = getCurrentBstTime()

                // Small realistic price micro-ticks
                val updated = _commodities.value.map { comm ->
                    if (rng.nextInt(10) < 4) { // 40% chance of price tick per interval
                        val delta = (rng.nextDouble(-0.35, 0.40) * 100).roundToInt() / 100.0
                        val newSpot = ((comm.spotPrice + delta) * 100.0).roundToInt() / 100.0
                        val newChange = (((comm.change + delta) * 100.0).roundToInt() / 100.0)
                        val newPct = ((newChange / (newSpot - newChange)) * 10000.0).roundToInt() / 100.0
                        val newHigh = maxOf(comm.high24h, newSpot)
                        val newLow = minOf(comm.low24h, newSpot)
                        comm.copy(
                            spotPrice = newSpot,
                            change = newChange,
                            changePct = newPct,
                            high24h = newHigh,
                            low24h = newLow
                        )
                    } else comm
                }
                _commodities.value = updated

                // Update Dairy Complex calculation
                val farmgateMilk = updated.find { it.id == "MILK_FARMGATE" }?.spotPrice ?: 35.00
                val butter = updated.find { it.id == "BUTTER_BULK" }?.spotPrice ?: 5820.0
                val smp = updated.find { it.id == "SMP_DAIRY" }?.spotPrice ?: 2180.0
                val cheddar = updated.find { it.id == "CHEDDAR_MILD" }?.spotPrice ?: 3940.0
                _dairyComplex.value = calculateDairyComplex(farmgateMilk, butter, smp, cheddar, 2650.0, 840.0)
            }
        }
    }

    fun calculateDairyComplex(
        milkFarmgatePpl: Double,
        butterPerTonne: Double,
        smpPerTonne: Double,
        cheddarPerTonne: Double,
        spotCreamPerTonne: Double,
        wheyPerTonne: Double
    ): DairyComplexValue {
        // AMPE formula: Actual Milk Price Equivalent (Butter + SMP yield minus manufacturing deduction)
        // 1000L milk yields approx 45.4 kg Butter + 85.9 kg SMP
        // Value per litre = (0.0454 * Butter_£/t + 0.0859 * SMP_£/t) * 100 / 1000 - processing costs (approx 3.2 ppl)
        val ampeGrossPpl = (0.0454 * (butterPerTonne / 10.0) + 0.0859 * (smpPerTonne / 10.0))
        val ampeNetPpl = ((ampeGrossPpl - 3.20) * 100.0).roundToInt() / 100.0

        // MCVE formula: Milk to Cheese Value Equivalent (Mild Cheddar + Whey powder minus cheese making costs)
        // 1000L milk yields approx 101 kg Cheddar + 52 kg Whey
        val mcveGrossPpl = (0.101 * (cheddarPerTonne / 10.0) + 0.052 * (wheyPerTonne / 10.0))
        val mcveNetPpl = ((mcveGrossPpl - 4.10) * 100.0).roundToInt() / 100.0

        // MMV: Marginal Milk Value based on spot cream + liquid concentrate
        val mmvPpl = (((milkFarmgatePpl * 1.05) + 0.85) * 100.0).roundToInt() / 100.0

        return DairyComplexValue(
            farmgatePpl = milkFarmgatePpl,
            butterPerTonne = butterPerTonne,
            smpPerTonne = smpPerTonne,
            mildCheddarPerTonne = cheddarPerTonne,
            spotCreamPerTonne = spotCreamPerTonne,
            wheyPowderPerTonne = wheyPerTonne,
            ampePpl = ampeNetPpl,
            mcvePpl = mcveNetPpl,
            mmvPpl = mmvPpl
        )
    }

    fun getForwardCurve(commodityId: String): List<ForwardCurvePoint> {
        val baseSpot = _commodities.value.find { it.id == commodityId }?.spotPrice ?: 186.40
        val futures = _commodities.value.find { it.id == commodityId }?.futuresReference ?: 188.50
        val isWheat = commodityId.startsWith("WHEAT")

        val periods = listOf(
            Triple("Spot Deliv", "Oct 2026", 0.0),
            Triple("Nov 26", "Nov 2026", 2.20),
            Triple("Dec 26", "Dec 2026", 4.10),
            Triple("Jan 27", "Jan 2027", 5.80),
            Triple("Mar 27", "Mar 2027", 8.40),
            Triple("May 27", "May 2027", 10.90),
            Triple("Jul 27", "Jul 2027", 12.20),
            Triple("New Crop (Nov 27)", "Nov 2027", 3.50)
        )

        return periods.mapIndexed { idx, (label, monthYear, carryPrice) ->
            val curveFutures = futures + carryPrice
            val basis = if (isWheat) -2.10 + (idx * 0.25) else 0.0
            val delivered = curveFutures + basis
            val storageCarryCost = idx * 1.45 // Storage £1.45/t/month
            val netCarryMargin = carryPrice - storageCarryCost - (idx * 0.85) // minus financing cost

            ForwardCurvePoint(
                period = label,
                deliveryMonthYear = monthYear,
                futuresRef = ((curveFutures) * 100.0).roundToInt() / 100.0,
                basis = ((basis) * 100.0).roundToInt() / 100.0,
                deliveredPrice = ((delivered) * 100.0).roundToInt() / 100.0,
                storageCarryCost = ((storageCarryCost) * 100.0).roundToInt() / 100.0,
                netCarryMargin = ((netCarryMargin) * 100.0).roundToInt() / 100.0,
                openInterestTonnes = (8500 + (7 - idx) * 3200).toDouble()
            )
        }
    }

    fun getOrderBook(commodityId: String, region: String = "East Anglia"): CommodityOrderBook {
        val commodity = _commodities.value.find { it.id == commodityId } ?: _commodities.value.first()
        val mid = commodity.spotPrice

        val bids = listOf(
            OrderBookLevel(price = mid - 0.50, volumeTonnes = 450.0, orderCount = 3),
            OrderBookLevel(price = mid - 0.90, volumeTonnes = 800.0, orderCount = 5),
            OrderBookLevel(price = mid - 1.40, volumeTonnes = 1200.0, orderCount = 8),
            OrderBookLevel(price = mid - 2.10, volumeTonnes = 2500.0, orderCount = 14),
            OrderBookLevel(price = mid - 3.00, volumeTonnes = 4100.0, orderCount = 22)
        )

        val offers = listOf(
            OrderBookLevel(price = mid + 0.50, volumeTonnes = 350.0, orderCount = 2),
            OrderBookLevel(price = mid + 0.85, volumeTonnes = 600.0, orderCount = 4),
            OrderBookLevel(price = mid + 1.30, volumeTonnes = 1100.0, orderCount = 7),
            OrderBookLevel(price = mid + 1.95, volumeTonnes = 1900.0, orderCount = 11),
            OrderBookLevel(price = mid + 2.80, volumeTonnes = 3400.0, orderCount = 19)
        )

        return CommodityOrderBook(
            commodityId = commodity.id,
            commodityName = commodity.name,
            region = region,
            lastPrice = mid,
            bids = bids,
            offers = offers,
            spread = 1.00,
            isSimulatedLiquidity = true
        )
    }

    data class NetbackCalculationResult(
        val commodityName: String,
        val futuresOrTerminalRef: Double,
        val regionalBasis: Double,
        val regionalPriceDelivered: Double,
        val freightDeduction: Double,
        val moistureDeduction: Double,
        val proteinBonusMalus: Double,
        val specificWeightAdjustment: Double,
        val storageFee: Double,
        val assuranceRedTractorBonus: Double,
        val netFarmRealisation: Double,
        val totalLotValueGross: Double,
        val totalLotValueNet: Double,
        val haulageDistanceMiles: Double,
        val formulaProvenanceSteps: List<Pair<String, Double>>
    )

    fun calculateFarmerNetback(
        commodityId: String,
        quantityTonnes: Double,
        farmRegion: String,
        deliveryMonth: String,
        moisturePct: Double,
        proteinPct: Double,
        specificWeightKgHl: Double,
        distanceMiles: Double,
        hasRedTractor: Boolean,
        storageMonths: Int
    ): NetbackCalculationResult {
        val commodity = _commodities.value.find { it.id == commodityId } ?: _commodities.value.first()
        val ref = commodity.futuresReference ?: commodity.spotPrice

        val regionInfo = _ukRegions.value.find { it.name.contains(farmRegion, ignoreCase = true) }
        val basis = regionInfo?.basisDiff ?: 0.0

        val regionalGrossDelivered = ref + basis

        // Freight model: Base loading £2.50/t + £0.11/tonne/mile
        val freightPerTonne = 2.50 + (distanceMiles * 0.11)

        // Quality Adjustments
        // Moisture: standard 14.5% - deduction £2.50/t per 1.0% excess moisture + drying cost
        val moistureExcess = maxOf(0.0, moisturePct - 14.5)
        val moistureDeduction = moistureExcess * 4.20 // drying + weight loss charge

        // Protein: standard 11.0% for feed, standard 13.0% for milling
        val proteinBonusMalus = if (commodity.id == "WHEAT_MILL") {
            if (proteinPct >= 13.0) (proteinPct - 13.0) * 8.0 else (proteinPct - 13.0) * 12.0
        } else {
            0.0
        }

        // Specific Weight: standard 76.0kg/hl (min 72kg/hl for feed). Below 72 has penalty.
        val specificWeightAdjustment = if (specificWeightKgHl < 72.0) {
            (72.0 - specificWeightKgHl) * -2.00
        } else if (specificWeightKgHl > 78.0) {
            1.50
        } else 0.0

        // Storage cost: £1.45/t/month on farm vs commercial
        val storageFee = storageMonths * 1.45

        // Red Tractor Assurance bonus: uncertified grain has a £12/t discount penalty in UK
        val assuranceBonus = if (hasRedTractor) 0.0 else -12.00

        val netRealisation = regionalGrossDelivered - freightPerTonne - moistureDeduction + proteinBonusMalus + specificWeightAdjustment - storageFee + assuranceBonus
        val roundedNet = ((netRealisation) * 100.0).roundToInt() / 100.0

        val provenance = listOf(
            "1. Futures Reference (${commodity.source.shortCode})" to ref,
            "2. Regional Basis (${farmRegion})" to basis,
            "3. Regional Delivered Midpoint" to regionalGrossDelivered,
            "4. Transport Freight (${distanceMiles.roundToInt()} miles @ £0.11/t/mi + £2.50)" to -freightPerTonne,
            "5. Moisture Adjustment (${moisturePct}% vs 14.5% std)" to -moistureDeduction,
            "6. Protein Adjustment (${proteinPct}% vs std)" to proteinBonusMalus,
            "7. Specific Weight (${specificWeightKgHl} kg/hl)" to specificWeightAdjustment,
            "8. Storage Carry (${storageMonths} mo @ £1.45/t)" to -storageFee,
            "9. Red Tractor Assurance Status" to assuranceBonus,
            "10. NET FARMGATE REALISATION" to roundedNet
        )

        return NetbackCalculationResult(
            commodityName = commodity.name,
            futuresOrTerminalRef = ref,
            regionalBasis = basis,
            regionalPriceDelivered = ((regionalGrossDelivered) * 100.0).roundToInt() / 100.0,
            freightDeduction = ((freightPerTonne) * 100.0).roundToInt() / 100.0,
            moistureDeduction = ((moistureDeduction) * 100.0).roundToInt() / 100.0,
            proteinBonusMalus = ((proteinBonusMalus) * 100.0).roundToInt() / 100.0,
            specificWeightAdjustment = ((specificWeightAdjustment) * 100.0).roundToInt() / 100.0,
            storageFee = ((storageFee) * 100.0).roundToInt() / 100.0,
            assuranceRedTractorBonus = assuranceBonus,
            netFarmRealisation = roundedNet,
            totalLotValueGross = ((regionalGrossDelivered * quantityTonnes) * 100.0).roundToInt() / 100.0,
            totalLotValueNet = ((roundedNet * quantityTonnes) * 100.0).roundToInt() / 100.0,
            haulageDistanceMiles = distanceMiles,
            formulaProvenanceSteps = provenance
        )
    }

    // Scenarios Lab
    val scenariosList = listOf(
        ScenarioDefinition(
            id = "SC_DROUGHT_UK",
            name = "UK Summer Severe Drought",
            subtitle = "Rain -30% • Wheat Yield -8% • Dairy -4% • Feed +6%",
            iconName = "water_drop",
            rainPct = -30.0,
            cropYieldPct = -8.5,
            feedDemandPct = 6.0,
            milkDeliveryPct = -4.2,
            fertiliserPct = 2.0,
            dieselPct = 0.0,
            freightPct = 3.5,
            wheatPriceDeltaPct = 14.2,
            barleyPriceDeltaPct = 12.8,
            milkPriceDeltaPct = 8.5,
            cattlePriceDeltaPct = -3.2, // Early slaughter increases meat supply short term
            propagationSteps = listOf(
                "Soil moisture deficits in East Anglia & Midlands reduce grain grain-fill by 8.5%.",
                "Grass pasture burned off in South West & Wales, forcing dairy & beef farmers to feed winter forage/concentrates in August.",
                "Feed compounders bid up feed barley and feed wheat to replace forage shortfall (+6% feed demand).",
                "UK farmgate milk supply falls 4.2%, lifting spot cream to £2,950/t and bulk butter over £6,200/t (+8.5% ppl).",
                "UK closing grain stocks tighten to 11.2% stock-to-use, driving ICE feed wheat benchmark up £26.50/t."
            )
        ),
        ScenarioDefinition(
            id = "SC_FERT_SPIKE",
            name = "Nitrogen & Gas Supply Shock",
            subtitle = "Natural Gas +40% • Granular Urea +25% • Break-even N shifts",
            iconName = "bolt",
            rainPct = 0.0,
            cropYieldPct = -3.0, // Sub-optimal fertiliser application
            feedDemandPct = 0.0,
            milkDeliveryPct = -1.5,
            fertiliserPct = 25.0,
            dieselPct = 5.0,
            freightPct = 4.0,
            wheatPriceDeltaPct = 9.8,
            barleyPriceDeltaPct = 8.4,
            milkPriceDeltaPct = 3.2,
            cattlePriceDeltaPct = 1.5,
            propagationSteps = listOf(
                "European natural gas spike raises ammonia synthesis manufacturing cost.",
                "Granular Urea reaches £422/t (+25%) and Ammonium Nitrate climbs to £402/t.",
                "Farmers reduce spring top-dressing by 35kg N/ha, dropping expected UK wheat yields by 0.35 t/ha.",
                "Cost of wheat production increases from £162/t to £184/t, resetting floor price expectations.",
                "Feed millers absorb higher raw grain costs, passing +£18/t compound feed hikes to livestock producers."
            )
        ),
        ScenarioDefinition(
            id = "SC_DIESEL_FREIGHT",
            name = "Red Diesel & Haulage Surcharge",
            subtitle = "Red Diesel +25% • Road Haulage +14% • Regional Basis Widens",
            iconName = "local_shipping",
            rainPct = 0.0,
            cropYieldPct = 0.0,
            feedDemandPct = 0.0,
            milkDeliveryPct = 0.0,
            fertiliserPct = 3.0,
            dieselPct = 25.0,
            freightPct = 14.0,
            wheatPriceDeltaPct = 2.5,
            barleyPriceDeltaPct = 1.8,
            milkPriceDeltaPct = 1.0,
            cattlePriceDeltaPct = -0.8,
            propagationSteps = listOf(
                "Global crude oil rally lifts agricultural gas oil from 74.8p/L to 93.5p/L (+25%).",
                "Bulk tipper road haulage costs increase from £0.11/t/mile to £0.128/t/mile.",
                "Distance penalties widen: Northern Scotland and North West deficit basis widens by £3.80/t.",
                "Port export netbacks decrease for inland Lincolnshire and Cambridgeshire farms.",
                "Local collection demand concentrates around regional mills and processing clusters."
            )
        ),
        ScenarioDefinition(
            id = "SC_HARVEST_GLUT",
            name = "UK Bumper Harvest & Port Congestion",
            subtitle = "Production +8% • Storage Utilisation 94% • Export Basis Widens",
            iconName = "agriculture",
            rainPct = 5.0,
            cropYieldPct = 8.0,
            feedDemandPct = -2.0,
            milkDeliveryPct = 1.0,
            fertiliserPct = -2.0,
            dieselPct = 0.0,
            freightPct = 6.0,
            wheatPriceDeltaPct = -11.5,
            barleyPriceDeltaPct = -13.2,
            milkPriceDeltaPct = -1.2,
            cattlePriceDeltaPct = 1.8,
            propagationSteps = listOf(
                "Ideal summer weather produces 14.95 Mt UK wheat crop (+8% above 5-year average).",
                "Commercial grain silos in East Anglia reach 94% capacity, causing farmgate storage bottlenecks.",
                "Merchants discount harvest spot delivery by £14/t against the forward Jan/Mar curve to incentivize on-farm holding.",
                "UK export surplus grows to 1.85 Mt, forcing domestic prices to full export parity with Rouen & Baltic origins.",
                "Animal feed rations switch aggressively to barley and feed wheat, depressing imported soya meal demand."
            )
        )
    )

    suspend fun saveCustomOrder(order: CustomOrderEntity): Long {
        val id = database.customOrderDao().insertOrder(order)
        database.terminalAuditDao().insertLog(
            TerminalAuditEntity(
                userRole = "MARKET_PARTICIPANT",
                actionType = "POST_${order.orderType}",
                targetEntity = "${order.commodityCode} - ${order.quantityTonnes}t @ £${order.targetPricePerTonne}/t",
                benchmarkReference = "ICE_LIFFE / AHDB",
                calculatedNetback = order.targetPricePerTonne,
                provenanceModel = "SIMULATED_ORDERBOOK_ENGINE"
            )
        )
        return id
    }

    suspend fun deleteCustomOrder(orderId: Long) {
        database.customOrderDao().deleteOrder(orderId)
    }

    suspend fun saveMarginScenario(scenario: MarginScenarioEntity): Long {
        val id = database.marginScenarioDao().insertScenario(scenario)
        database.terminalAuditDao().insertLog(
            TerminalAuditEntity(
                userRole = "FARM_MANAGER",
                actionType = "SAVE_MARGIN_MODEL",
                targetEntity = "${scenario.cropOrStock} (${scenario.areaHaOrHead} ha/head)",
                benchmarkReference = "NIX_POCKETBOOK / AHDB_COSTS",
                calculatedNetback = scenario.grossMarginTotal,
                provenanceModel = "DETERMINISTIC_MARGIN_ENGINE"
            )
        )
        return id
    }

    suspend fun deleteMarginScenario(id: Long) {
        database.marginScenarioDao().deleteScenario(id)
    }

    suspend fun toggleWatchlist(commodityId: String, isPinned: Boolean) {
        if (isPinned) {
            database.watchlistDao().insertOrUpdate(WatchlistEntity(commodityId = commodityId))
        } else {
            database.watchlistDao().remove(commodityId)
        }
    }
}
