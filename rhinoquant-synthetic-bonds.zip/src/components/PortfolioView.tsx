import React, { useState } from 'react';
import { SyntheticBond, PortfolioPosition, Currency, Sector, CreditRating } from '../types/bond';
import { priceBond } from '../engine/pricing';
import { Briefcase, Plus, Trash2, PieChart, Layers, DollarSign, Activity } from 'lucide-react';

interface PortfolioViewProps {
  bonds: SyntheticBond[];
  rateShiftBp: number;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({ bonds, rateShiftBp }) => {
  const [positions, setPositions] = useState<PortfolioPosition[]>([
    { id: 'POS-1', bond: bonds[0] || bonds[0], faceValueMln: 10.0 },
    { id: 'POS-2', bond: bonds[1] || bonds[0], faceValueMln: 25.0 },
    { id: 'POS-3', bond: bonds[2] || bonds[0], faceValueMln: 15.0 },
  ]);

  const [selectedBondId, setSelectedBondId] = useState<string>(bonds[0]?.id || '');
  const [addSizeMln, setAddSizeMln] = useState<number>(10.0);

  // Calculate position valuations
  const positionValuations = positions.map((pos) => {
    const valuation = priceBond(pos.bond, rateShiftBp);
    const marketValueMln = (valuation.dirtyPrice / 100.0) * pos.faceValueMln;
    return {
      position: pos,
      valuation,
      marketValueMln,
    };
  });

  const totalMarketValueMln = positionValuations.reduce((sum, p) => sum + p.marketValueMln, 0);
  const totalFaceValueMln = positions.reduce((sum, p) => sum + p.faceValueMln, 0);

  // Weighted metrics
  const weightedYtm = totalMarketValueMln > 0
    ? positionValuations.reduce((sum, p) => sum + p.valuation.yieldToMaturity * p.marketValueMln, 0) / totalMarketValueMln
    : 0;

  const weightedModDur = totalMarketValueMln > 0
    ? positionValuations.reduce((sum, p) => sum + p.valuation.modifiedDuration * p.marketValueMln, 0) / totalMarketValueMln
    : 0;

  const weightedConvexity = totalMarketValueMln > 0
    ? positionValuations.reduce((sum, p) => sum + p.valuation.convexity * p.marketValueMln, 0) / totalMarketValueMln
    : 0;

  const totalDv01 = positionValuations.reduce((sum, p) => sum + p.valuation.dv01 * p.position.faceValueMln, 0);
  const totalSpreadDv01 = positionValuations.reduce((sum, p) => sum + p.valuation.spreadDv01 * p.position.faceValueMln, 0);

  // Sector breakdown
  const sectorMap: Record<string, number> = {};
  positionValuations.forEach((p) => {
    const sec = p.position.bond.sector;
    sectorMap[sec] = (sectorMap[sec] || 0) + p.marketValueMln;
  });

  const handleAddPosition = () => {
    const bondToAdd = bonds.find((b) => b.id === selectedBondId) || bonds[0];
    setPositions([
      ...positions,
      { id: `POS-${Date.now().toString().slice(-4)}`, bond: bondToAdd, faceValueMln: addSizeMln },
    ]);
  };

  const handleRemovePosition = (id: string) => {
    setPositions(positions.filter((p) => p.id !== id));
  };

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Portfolio Header Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 font-mono">
        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">TOTAL MARKET VALUE</span>
          <div className="text-xl font-bold text-amber-400 mt-1">
            £{totalMarketValueMln.toFixed(2)}m
          </div>
          <span className="text-[10px] text-slate-500">Face Value: £{totalFaceValueMln.toFixed(1)}m</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">WEIGHTED YTM</span>
          <div className="text-xl font-bold text-emerald-400 mt-1">
            {(weightedYtm * 100).toFixed(3)}%
          </div>
          <span className="text-[10px] text-slate-500">Portfolio Yield</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">WEIGHTED MOD DURATION</span>
          <div className="text-xl font-bold text-blue-400 mt-1">
            {weightedModDur.toFixed(2)} yrs
          </div>
          <span className="text-[10px] text-slate-500">Interest Rate Sensitivity</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">WEIGHTED CONVEXITY</span>
          <div className="text-xl font-bold text-purple-400 mt-1">
            {weightedConvexity.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-500">Second-order curvature</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">PORTFOLIO DV01</span>
          <div className="text-xl font-bold text-red-400 mt-1">
            £{totalDv01.toLocaleString('en-US', { maximumFractionDigits: 0 })}
          </div>
          <span className="text-[10px] text-slate-500">P&L per 1bp rate shift</span>
        </div>
      </div>

      {/* Add Position Control */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#131b2e] p-4 rounded-xl border border-slate-800 font-mono text-xs">
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <span className="text-amber-400 font-bold uppercase flex items-center gap-1">
            <Plus className="w-4 h-4" /> ADD BOND POSITION:
          </span>
          <select
            value={selectedBondId}
            onChange={(e) => setSelectedBondId(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-100 max-w-xs focus:outline-none focus:border-amber-500"
          >
            {bonds.map((b) => (
              <option key={b.id} value={b.id}>
                {b.id} - {b.name}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">FACE VALUE (£M):</span>
            <input
              type="number"
              value={addSizeMln}
              onChange={(e) => setAddSizeMln(parseFloat(e.target.value) || 1.0)}
              className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-slate-100"
            />
          </div>
        </div>

        <button
          onClick={handleAddPosition}
          className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded transition-colors"
        >
          ADD POSITION TO PORTFOLIO
        </button>
      </div>

      {/* Position Table */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider flex items-center gap-2">
          <Briefcase className="w-4 h-4" /> Portfolio Holdings & Risk Matrix
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-2">BOND ID</th>
                <th className="pb-2">INSTRUMENT NAME</th>
                <th className="pb-2">RATING</th>
                <th className="pb-2">FACE VALUE (£M)</th>
                <th className="pb-2">PRICE</th>
                <th className="pb-2">MARKET VALUE (£M)</th>
                <th className="pb-2">YTM</th>
                <th className="pb-2">MOD DUR</th>
                <th className="pb-2">DV01 (£)</th>
                <th className="pb-2 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {positionValuations.map((p) => (
                <tr key={p.position.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 font-bold text-amber-400">{p.position.bond.id}</td>
                  <td className="py-3 font-semibold text-slate-200">{p.position.bond.name}</td>
                  <td className="py-3 text-amber-300">{p.position.bond.rating}</td>
                  <td className="py-3 font-bold text-slate-100">£{p.position.faceValueMln.toFixed(1)}m</td>
                  <td className="py-3 text-emerald-400">{p.valuation.dirtyPrice.toFixed(2)}</td>
                  <td className="py-3 font-bold text-amber-300">£{p.marketValueMln.toFixed(2)}m</td>
                  <td className="py-3">{(p.valuation.yieldToMaturity * 100).toFixed(3)}%</td>
                  <td className="py-3">{p.valuation.modifiedDuration.toFixed(2)} yrs</td>
                  <td className="py-3 text-blue-400">£{(p.valuation.dv01 * p.position.faceValueMln).toFixed(0)}</td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => handleRemovePosition(p.position.id)}
                      className="text-red-400 hover:text-red-300 p-1 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Sector Exposure Breakdown */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 font-mono text-xs space-y-4">
        <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
          <PieChart className="w-4 h-4" /> Sector Exposure Breakdown
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {Object.entries(sectorMap).map(([sector, mv]) => {
            const pct = totalMarketValueMln > 0 ? (mv / totalMarketValueMln) * 100 : 0;
            return (
              <div key={sector} className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-[11px] text-slate-400 block">{sector}</span>
                <span className="text-base font-bold text-emerald-400 block mt-0.5">£{mv.toFixed(2)}m</span>
                <span className="text-[10px] text-amber-300">{pct.toFixed(1)}% of Portfolio</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
