import React, { useState } from 'react';
import { Code2, Terminal, Play, Copy, Check } from 'lucide-react';

export const ApiView: React.FC = () => {
  const [activeLang, setActiveLang] = useState<'RUST' | 'KOTLIN' | 'R' | 'REST'>('RUST');
  const [copied, setCopied] = useState<boolean>(false);
  const [simOutput, setSimOutput] = useState<string | null>(null);

  const rustCode = `// RhinoQuant Fixed Income Pricing Engine - Rust Implementation
pub struct SyntheticBond {
    pub isin: String,
    pub coupon_rate: f64,
    pub maturity_years: f64,
    pub frequency: u32,
    pub market_spread_bp: f64,
}

impl SyntheticBond {
    pub fn calculate_pv(&self, discount_curve: &[f64]) -> f64 {
        let n = (self.maturity_years * self.frequency as f64) as usize;
        let c = self.coupon_rate / (self.frequency as f64);
        let mut pv = 0.0;
        
        for t in 1..=n {
            let df = (-discount_curve[t - 1] * (t as f64 / self.frequency as f64)).exp();
            pv += c * df;
        }
        pv += (-discount_curve[n - 1] * self.maturity_years).exp(); // Par principal
        pv
    }
}`;

  const kotlinCode = `// RhinoQuant API Server - Kotlin Ktor Route
routing {
    post("/api/v1/bonds/price") {
        val request = call.receive<BondPricingRequest>()
        val valuation = quantEngine.priceBond(
            bond = request.bond,
            rateShiftBp = request.rateShiftBp
        )
        call.respond(HttpStatusCode.OK, valuation)
    }
}`;

  const rCode = `# RhinoQuant Analytics - R Calibration Engine
calibrate_nelson_siegel <- function(tenors, spot_rates) {
  fit <- nls(spot_rates ~ beta0 + beta1 * ((1 - exp(-tenors/tau))/(tenors/tau)) +
             beta2 * (((1 - exp(-tenors/tau))/(tenors/tau)) - exp(-tenors/tau)),
             start = list(beta0 = 0.04, beta1 = -0.01, beta2 = 0.02, tau = 2.0))
  return(summary(fit))
}`;

  const restCode = `POST /api/v1/bonds/price
Content-Type: application/json

{
  "bondId": "RQ-UK-CORP-2034-017",
  "couponRate": 0.04625,
  "maturityDate": "2034-06-15",
  "currency": "GBP",
  "rateShiftBp": 0
}`;

  const getCode = () => {
    switch (activeLang) {
      case 'RUST': return rustCode;
      case 'KOTLIN': return kotlinCode;
      case 'R': return rCode;
      case 'REST': return restCode;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunCode = () => {
    setSimOutput('Compiling and executing RhinoQuant engine binary...\nValuation PV: 98.4521\nYTM: 5.214%\nModified Duration: 7.82 yrs\nExecution status: SUCCESS (0.002ms)');
  };

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Header */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-2 font-mono">
        <h2 className="text-lg font-bold text-amber-400 uppercase flex items-center gap-2">
          <Code2 className="w-5 h-5 text-amber-400" /> QUANT CODE ENGINE & API INTEGRATION
        </h2>
        <p className="text-xs text-slate-400">
          High-performance Rust Pricing Core, Kotlin Ktor Service, R Calibration, and REST API
        </p>
      </div>

      {/* Language Switcher */}
      <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
        {(['RUST', 'KOTLIN', 'R', 'REST'] as const).map((lang) => (
          <button
            key={lang}
            onClick={() => { setActiveLang(lang); setSimOutput(null); }}
            className={`px-4 py-2 rounded-lg font-bold transition-all ${
              activeLang === lang
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'bg-[#131b2e] text-slate-300 hover:text-slate-100 border border-slate-800'
            }`}
          >
            {lang === 'RUST' && 'Rust Engine Core'}
            {lang === 'KOTLIN' && 'Kotlin Ktor API'}
            {lang === 'R' && 'R Calibration'}
            {lang === 'REST' && 'REST API Schema'}
          </button>
        ))}
      </div>

      {/* Code Editor Box */}
      <div className="bg-[#131b2e] rounded-xl border border-slate-800 overflow-hidden font-mono text-xs">
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-slate-800">
          <span className="text-slate-400 font-bold">{activeLang} SOURCE CODE</span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 px-3 py-1 rounded text-[11px]"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy Code'}
            </button>

            <button
              onClick={handleRunCode}
              className="flex items-center gap-1 bg-amber-500 hover:bg-amber-600 text-slate-950 px-3 py-1 rounded font-bold text-[11px]"
            >
              <Play className="w-3.5 h-3.5" /> Run Code
            </button>
          </div>
        </div>

        <pre className="p-5 text-emerald-400 overflow-x-auto bg-[#090d16] leading-relaxed">
          <code>{getCode()}</code>
        </pre>
      </div>

      {/* Simulated Console Output */}
      {simOutput && (
        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2">
          <div className="flex items-center gap-2 text-slate-400 font-bold uppercase">
            <Terminal className="w-4 h-4 text-emerald-400" /> EXECUTION CONSOLE OUTPUT
          </div>
          <pre className="p-3 bg-slate-950 text-slate-200 rounded border border-slate-800 font-mono text-[11px]">
            {simOutput}
          </pre>
        </div>
      )}
    </div>
  );
};
