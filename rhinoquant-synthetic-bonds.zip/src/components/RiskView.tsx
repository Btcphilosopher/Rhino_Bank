import React from 'react';
import { SyntheticBond } from '../types/bond';
import { priceBond } from '../engine/pricing';
import { calculateKeyRateDV01, calculateCreditRiskMetrics } from '../engine/risk';
import { ShieldAlert, BarChart3, Activity, Layers, AlertCircle, Droplets } from 'lucide-react';

interface RiskViewProps {
  bond: SyntheticBond;
  rateShiftBp: number;
}

export const RiskView: React.FC<RiskViewProps> = ({ bond, rateShiftBp }) => {
  const valuation = priceBond(bond, rateShiftBp);
  const keyRateDV01 = calculateKeyRateDV01(bond, valuation.dirtyPrice);
  const creditRisk = calculateCreditRiskMetrics(bond.rating, bond.marketSpreadBp, 10, 0.40, bond.issueSizeMln);

  const keyTenors = ['2Y', '5Y', '10Y', '20Y', '30Y'] as const;
  const maxKR = Math.max(...keyTenors.map((t) => keyRateDV01[t] || 1));

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Risk Engine Header */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-2 font-mono">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <span className="text-amber-400 font-bold text-xs">QUANTITATIVE RISK ENGINE</span>
            <h2 className="text-lg font-bold text-slate-100 font-sans">
              Risk & Sensitivity Analysis: {bond.name}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="bg-red-500/20 text-red-300 border border-red-500/40 font-bold px-2.5 py-1 rounded text-xs">
              DV01: £{valuation.dv01.toFixed(0)} / £1m
            </span>
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/40 font-bold px-2.5 py-1 rounded text-xs">
              CONVEXITY: {valuation.convexity.toFixed(1)}
            </span>
          </div>
        </div>
      </div>

      {/* Key-Rate DV01 Bar Breakdown */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
        <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
          <BarChart3 className="w-4 h-4" /> Key-Rate DV01 Bucket Breakdown (£ per £1m Face Value)
        </h3>

        <div className="grid grid-cols-5 gap-3 pt-2">
          {keyTenors.map((tenor) => {
            const val = keyRateDV01[tenor] || 0;
            const barHeightPct = maxKR > 0 ? (val / maxKR) * 100 : 0;
            return (
              <div key={tenor} className="flex flex-col items-center gap-2 bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-xs font-bold text-amber-300">{tenor} KEY RATE</span>
                <div className="w-full h-32 bg-slate-900 rounded relative flex items-end justify-center p-1">
                  <div
                    style={{ height: `${Math.max(8, barHeightPct)}%` }}
                    className="w-full bg-gradient-to-t from-emerald-600 to-emerald-400 rounded transition-all"
                  />
                </div>
                <span className="text-sm font-bold text-slate-100">£{val.toFixed(0)}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Credit Risk & Default Survival Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Survival Curve Chart */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <ShieldAlert className="w-4 h-4" /> Credit Risk & Default Survival Curve S(t) = exp(-λt)
          </h3>

          <div className="space-y-3 bg-slate-950 p-4 rounded border border-slate-800">
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Hazard Rate (λ):</span>
              <span className="font-bold text-red-400">{(creditRisk.hazardRate * 100).toFixed(3)}% / year</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Loss Given Default (LGD):</span>
              <span className="font-bold text-slate-200">{creditRisk.lossGivenDefaultPercent.toFixed(0)}%</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">10Y Expected Loss ({bond.currency}M):</span>
              <span className="font-bold text-amber-400">
                {bond.currency} {creditRisk.expectedLossMln.toFixed(2)}M
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-slate-400 block font-bold text-[11px]">Cumulative Survival Probability by Year:</span>
            <div className="grid grid-cols-5 gap-2 text-center text-[11px]">
              {creditRisk.survivalProbs.slice(0, 5).map((sp) => (
                <div key={sp.year} className="bg-slate-950 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block">Yr {sp.year}</span>
                  <span className="font-bold text-emerald-400">{(sp.probability * 100).toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Liquidity Model & Execution Spread */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <Droplets className="w-4 h-4" /> Synthetic Liquidity & Execution Spread Model
          </h3>

          <div className="space-y-3">
            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Theoretical Mid Value:</span>
                <span className="font-bold text-emerald-400">{valuation.theoreticalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Synthetic Executable Bid Value:</span>
                <span className="font-bold text-amber-400">{valuation.executablePrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Liquidity Penalty Spread:</span>
                <span className="font-bold text-red-400">+{valuation.liquidityPenaltyBp} bp</span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-3 rounded border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
              <span className="text-amber-400 font-bold block">LIQUIDITY DRIVERS:</span>
              <p>· Issue Size: £{bond.issueSizeMln}M ({bond.issueSizeMln < 500 ? 'Illiquid Tier' : 'Benchmark Liquid Tier'})</p>
              <p>· Rating Class: {bond.rating} ({bond.rating.startsWith('BB') ? 'High Yield Friction' : 'Investment Grade Depth'})</p>
              <p>· Dealer Synthetic Inventory Depth: 8.5/10</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
