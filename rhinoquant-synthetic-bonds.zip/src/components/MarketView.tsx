import React from 'react';
import { Currency, CreditRating, Sector } from '../types/bond';
import { BASE_BENCHMARK_RATES, RATING_SPREAD_CURVES, SECTOR_MULTIPLIERS, TENORS } from '../engine/curves';
import { TrendingUp, Activity, Layers, DollarSign, Shield, Zap } from 'lucide-react';

interface MarketViewProps {
  currency: Currency;
  rateShiftBp: number;
}

export const MarketView: React.FC<MarketViewProps> = ({ currency, rateShiftBp }) => {
  const benchmarks = BASE_BENCHMARK_RATES[currency] || BASE_BENCHMARK_RATES.GBP;

  return (
    <div className="space-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Header Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>{currency} 10Y BENCHMARK YIELD</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {((benchmarks['10Y'] * 100) + rateShiftBp / 100).toFixed(3)}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Spot Rate (SONIA/SOFR/ESTR Equivalent)
          </div>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>A-GRADE CREDIT YIELD (10Y)</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {((benchmarks['10Y'] * 100) + 1.55 + rateShiftBp / 100).toFixed(3)}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Benchmark + 155bp Credit Spread
          </div>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>BBB CREDIT SPREAD</span>
            <Shield className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-400">
            +292 bp
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Investment Grade Threshold Spread
          </div>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>HIGH YIELD SPREAD</span>
            <Zap className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-red-400">
            +640 bp
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Sub-Investment Grade Option-Adjusted
          </div>
        </div>
      </div>

      {/* Main Grid: Benchmark Rates Table & Sector Spread Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Benchmark Term Structure */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800">
          <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Layers className="w-4 h-4" /> {currency} Risk-Free Benchmark Term Structure
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2">TENOR</th>
                  <th className="pb-2">SPOT YIELD</th>
                  <th className="pb-2">SHOCKED YIELD</th>
                  <th className="pb-2">DISCOUNT FACTOR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {TENORS.map((t) => {
                  const baseRate = benchmarks[t.tenor] || 0.04;
                  const shockedRate = baseRate + rateShiftBp / 10000;
                  const df = Math.exp(-shockedRate * t.years);
                  return (
                    <tr key={t.tenor} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 font-bold text-slate-200">{t.tenor}</td>
                      <td className="py-2.5">{(baseRate * 100).toFixed(3)}%</td>
                      <td className="py-2.5 font-semibold text-emerald-400">
                        {(shockedRate * 100).toFixed(3)}%
                      </td>
                      <td className="py-2.5 text-slate-400">{df.toFixed(5)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Credit Rating Spread Matrix */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800">
          <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Shield className="w-4 h-4" /> Synthetic Credit Rating Spread Matrix (bp)
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2">RATING</th>
                  <th className="pb-2">2Y SPREAD</th>
                  <th className="pb-2">5Y SPREAD</th>
                  <th className="pb-2">10Y SPREAD</th>
                  <th className="pb-2">30Y SPREAD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {(['AAA', 'AA', 'A', 'BBB', 'BB', 'B', 'CCC'] as CreditRating[]).map((rating) => {
                  const curve = RATING_SPREAD_CURVES[rating];
                  return (
                    <tr key={rating} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 font-bold text-amber-300">{rating}</td>
                      <td className="py-2.5">+{curve['2Y']} bp</td>
                      <td className="py-2.5 font-semibold text-slate-200">+{curve['5Y']} bp</td>
                      <td className="py-2.5 font-semibold text-amber-400">+{curve['10Y']} bp</td>
                      <td className="py-2.5 text-slate-400">+{curve['30Y']} bp</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Sector Multiplier Grid */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800">
        <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider mb-4">
          Sector Spread Sensitivity Multipliers
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 font-mono text-xs">
          {(Object.keys(SECTOR_MULTIPLIERS) as Sector[]).map((sec) => {
            const mult = SECTOR_MULTIPLIERS[sec];
            return (
              <div key={sec} className="bg-slate-900/80 p-3 rounded-lg border border-slate-800/80 text-center">
                <div className="text-[11px] text-slate-400 font-sans truncate">{sec}</div>
                <div className={`text-base font-bold mt-1 ${mult > 1.1 ? 'text-red-400' : mult < 0.95 ? 'text-emerald-400' : 'text-slate-200'}`}>
                  {mult.toFixed(2)}x
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
