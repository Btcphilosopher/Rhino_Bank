import React, { useState } from 'react';
import { SyntheticBond, StressScenario } from '../types/bond';
import { PREBUILT_SCENARIOS, runScenario } from '../engine/scenarios';
import { Zap, ShieldAlert, Sliders, ArrowUpRight, ArrowDownRight, Layers } from 'lucide-react';

interface ScenariosViewProps {
  bond: SyntheticBond;
}

export const ScenariosView: React.FC<ScenariosViewProps> = ({ bond }) => {
  const [selectedScenario, setSelectedScenario] = useState<StressScenario>(PREBUILT_SCENARIOS[0]);
  const [positionSizeMln, setPositionSizeMln] = useState<number>(10.0);

  // Custom Scenario State
  const [customRateShift, setCustomRateShift] = useState<number>(100);
  const [customSlopeShift, setCustomSlopeShift] = useState<number>(0);
  const [customCreditShift, setCustomCreditShift] = useState<number>(50);
  const [customLiquidityShift, setCustomLiquidityShift] = useState<number>(15);

  const activeScenario: StressScenario = selectedScenario.id === 'CUSTOM' ? {
    id: 'CUSTOM',
    name: 'Custom User Shock',
    description: 'User specified scenario parameters.',
    rateShiftBp: customRateShift,
    slopeShiftBp: customSlopeShift,
    creditSpreadShiftBp: customCreditShift,
    liquiditySpreadShiftBp: customLiquidityShift,
  } : selectedScenario;

  const scenarioResult = runScenario(bond, activeScenario, positionSizeMln);

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-2 font-mono">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <span className="text-amber-400 font-bold text-xs">QUANTITATIVE STRESS TESTING & SCENARIOS</span>
            <h2 className="text-lg font-bold text-slate-100 font-sans">
              Scenario Stress Test: {bond.name} (£{positionSizeMln}M Position)
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-xs">POSITION SIZE:</span>
            <input
              type="number"
              value={positionSizeMln}
              onChange={(e) => setPositionSizeMln(parseFloat(e.target.value) || 1.0)}
              className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs font-bold"
            />
          </div>
        </div>
      </div>

      {/* Scenario Selector Pills & Grid */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
        <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
          <Zap className="w-4 h-4" /> Select Macro Stress Scenario
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {PREBUILT_SCENARIOS.map((scen) => (
            <button
              key={scen.id}
              onClick={() => setSelectedScenario(scen)}
              className={`p-3 rounded-lg border text-left transition-all ${
                selectedScenario.id === scen.id
                  ? 'bg-amber-500/10 border-amber-500/60 text-amber-300'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
              }`}
            >
              <div className="font-bold text-slate-100 mb-1">{scen.name}</div>
              <p className="text-[11px] text-slate-400 line-clamp-2">{scen.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Primary Stress P&L Result Card & Deconstruction */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* P&L Overview Card */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider">
            SCENARIO P&L SUMMARY
          </h3>

          <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-3">
            <div>
              <span className="text-[10px] text-slate-400 block">BASE POSITION VALUE:</span>
              <span className="text-lg font-bold text-slate-200">
                £{scenarioResult.originalValueMln.toFixed(2)}M
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 block">STRESSED POSITION VALUE:</span>
              <span className="text-lg font-bold text-slate-200">
                £{scenarioResult.stressedValueMln.toFixed(2)}M
              </span>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <span className="text-[10px] text-slate-400 block">PROJECTED P&L IMPACT:</span>
              <div className={`text-2xl font-bold mt-0.5 ${scenarioResult.pnlMln >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {scenarioResult.pnlMln >= 0 ? '+' : ''}£{scenarioResult.pnlMln.toFixed(3)}M
              </div>
              <span className={`text-xs font-bold ${scenarioResult.pnlMln >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                ({scenarioResult.pnlPercent >= 0 ? '+' : ''}{scenarioResult.pnlPercent.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>

        {/* P&L Attribution Breakdown */}
        <div className="lg:col-span-2 bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 text-xs">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4" /> Taylor Expansion P&L Decomposition
          </h3>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] text-slate-400">
            ΔP ≈ -ModDur × P × Δy + ½ × Convexity × P × (Δy)² - ModDur × P × Δs - P × Δl
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Rate Shift Effect (-ModDur × Δy):</span>
              <span className={`font-bold ${scenarioResult.decomposition.rateEffectMln >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {scenarioResult.decomposition.rateEffectMln >= 0 ? '+' : ''}£{scenarioResult.decomposition.rateEffectMln.toFixed(3)}M
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Convexity Cushion (+½ × Convexity × (Δy)²):</span>
              <span className="font-bold text-emerald-400">
                +£{scenarioResult.decomposition.convexityEffectMln.toFixed(3)}M
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Credit Spread Widening (-Spread × Δs):</span>
              <span className={`font-bold ${scenarioResult.decomposition.spreadEffectMln >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {scenarioResult.decomposition.spreadEffectMln >= 0 ? '+' : ''}£{scenarioResult.decomposition.spreadEffectMln.toFixed(3)}M
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Liquidity Friction Effect (-Δl):</span>
              <span className={`font-bold ${scenarioResult.decomposition.liquidityEffectMln >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {scenarioResult.decomposition.liquidityEffectMln >= 0 ? '+' : ''}£{scenarioResult.decomposition.liquidityEffectMln.toFixed(3)}M
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Higher Order Residual / Cross Effect:</span>
              <span className="font-bold text-slate-300">
                £{scenarioResult.decomposition.residualMln.toFixed(3)}M
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
