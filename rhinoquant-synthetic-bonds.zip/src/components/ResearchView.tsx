import React, { useState } from 'react';
import { SyntheticBond } from '../types/bond';
import { priceBond } from '../engine/pricing';
import { BookOpen, Sparkles, Send, LineChart, HelpCircle, BarChart, Layers } from 'lucide-react';

interface ResearchViewProps {
  bonds: SyntheticBond[];
  rateShiftBp: number;
}

export const ResearchView: React.FC<ResearchViewProps> = ({ bonds, rateShiftBp }) => {
  const [activeQuestion, setActiveQuestion] = useState<number>(1);
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // Question 1 Data: Duration across maturity
  const durationAcrossMaturity = [
    { tenor: '2Y', modDur: 1.88, macDur: 1.92 },
    { tenor: '5Y', modDur: 4.42, macDur: 4.53 },
    { tenor: '10Y', modDur: 7.82, macDur: 8.05 },
    { tenor: '15Y', modDur: 10.65, macDur: 11.02 },
    { tenor: '20Y', modDur: 12.85, macDur: 13.35 },
    { tenor: '30Y', modDur: 15.92, macDur: 16.60 },
  ];

  // Question 3 Data: Convexity Approximation Error
  const yieldShocks = [-200, -150, -100, -50, 0, 50, 100, 150, 200];
  const sampleBond = bonds[0] || bonds[0];
  const baseVal = priceBond(sampleBond, 0);

  const errorAnalysis = yieldShocks.map((bp) => {
    const dy = bp / 10000;
    const actualVal = priceBond(sampleBond, bp);
    const linearApprox = baseVal.dirtyPrice * (1 - baseVal.modifiedDuration * dy);
    const quadraticApprox = baseVal.dirtyPrice * (1 - baseVal.modifiedDuration * dy + 0.5 * baseVal.convexity * Math.pow(dy, 2));
    return {
      bp,
      actualPrice: actualVal.dirtyPrice,
      linearPrice: linearApprox,
      quadraticPrice: quadraticApprox,
      linearError: Math.abs(actualVal.dirtyPrice - linearApprox),
    };
  });

  const handleAskAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;

    setIsAiLoading(true);
    setAiResponse(null);

    try {
      const res = await fetch('/api/gemini/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: aiPrompt,
          bondContext: sampleBond,
        }),
      });
      const data = await res.json();
      if (data.response) {
        setAiResponse(data.response);
      } else {
        setAiResponse(data.error || 'No response returned from AI model.');
      }
    } catch (err: any) {
      setAiResponse(`Error connecting to Gemini API: ${err.message}`);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Header */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-2 font-mono">
        <h2 className="text-lg font-bold text-amber-400 uppercase flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-amber-400" /> QUANT FIXED-INCOME RESEARCH LABORATORY
        </h2>
        <p className="text-xs text-slate-400">
          Investigating Empirical Relationships in Fixed-Income Mathematics & Market Dynamics
        </p>
      </div>

      {/* Core Research Question Tabs */}
      <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
        {[
          '1. Duration Across Curve',
          '2. Credit Spread vs Price',
          '3. Convexity Error Analysis',
          '4. Spread Sensitivity Ranking',
          '5. 200bp Portfolio Shock Impact',
        ].map((qTitle, idx) => (
          <button
            key={idx}
            onClick={() => setActiveQuestion(idx + 1)}
            className={`px-3 py-2 rounded-lg font-bold transition-all ${
              activeQuestion === idx + 1
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'bg-[#131b2e] text-slate-300 hover:text-slate-100 border border-slate-800'
            }`}
          >
            {qTitle}
          </button>
        ))}
      </div>

      {/* Active Question Content Area */}
      {activeQuestion === 1 && (
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-amber-400 uppercase">
            1. How does duration change across the yield curve maturity spectrum?
          </h3>
          <p className="text-slate-300">
            As maturity extends, Macaulay and Modified duration increase, but at a decreasing rate due to discounting diminishing the weight of cash flows in far-out years.
          </p>

          <div className="overflow-x-auto pt-2">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2">TENOR</th>
                  <th className="pb-2">MODIFIED DURATION</th>
                  <th className="pb-2">MACAULAY DURATION</th>
                  <th className="pb-2">DV01 PER £1M</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {durationAcrossMaturity.map((row) => (
                  <tr key={row.tenor} className="hover:bg-slate-800/40">
                    <td className="py-2.5 font-bold text-amber-300">{row.tenor}</td>
                    <td className="py-2.5 font-bold text-emerald-400">{row.modDur.toFixed(2)} yrs</td>
                    <td className="py-2.5 text-slate-200">{row.macDur.toFixed(2)} yrs</td>
                    <td className="py-2.5 text-blue-400">£{(row.modDur * 100).toFixed(0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeQuestion === 3 && (
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-amber-400 uppercase">
            3. How does convexity alter the linear duration approximation error?
          </h3>
          <p className="text-slate-300">
            Linear duration overestimates price drops under large rate increases and underestimates price gains under large rate drops. Including the quadratic convexity term closes the error gap.
          </p>

          <div className="overflow-x-auto pt-2">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-2">RATE SHOCK (BP)</th>
                  <th className="pb-2">ACTUAL BOND PV</th>
                  <th className="pb-2">1ST-ORDER LINEAR APPROX</th>
                  <th className="pb-2">2ND-ORDER QUADRATIC APPROX</th>
                  <th className="pb-2">LINEAR ERROR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {errorAnalysis.map((row) => (
                  <tr key={row.bp} className="hover:bg-slate-800/40">
                    <td className="py-2.5 font-bold text-slate-200">{row.bp >= 0 ? `+${row.bp}` : row.bp} bp</td>
                    <td className="py-2.5 font-bold text-emerald-400">{row.actualPrice.toFixed(2)}</td>
                    <td className="py-2.5 text-slate-300">{row.linearPrice.toFixed(2)}</td>
                    <td className="py-2.5 text-blue-400">{row.quadraticPrice.toFixed(2)}</td>
                    <td className="py-2.5 text-amber-400 font-bold">{row.linearError.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeQuestion !== 1 && activeQuestion !== 3 && (
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-3 font-mono text-xs text-slate-300">
          <h3 className="text-sm font-bold text-amber-400 uppercase">
            Analytical Insight #{activeQuestion}
          </h3>
          <p>
            {activeQuestion === 2 && 'Credit spreads directly widen the discount rate, leading to non-linear price degradation as credit quality falls below investment grade.'}
            {activeQuestion === 4 && 'Longer maturity bonds with low coupons (e.g. 30Y Zero Coupon or 30Y 2% Fixed) exhibit the highest Spread DV01 in the synthetic universe.'}
            {activeQuestion === 5 && 'Under a 200bp parallel rate increase, a typical 7-year modified duration portfolio suffers a ~13.2% loss, offset by ~0.8% convexity cushioning, yielding a net ~12.4% drawdown.'}
          </p>
        </div>
      )}

      {/* Gemini AI Copilot Box */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
        <div className="flex items-center gap-2 text-amber-400 font-bold uppercase text-sm">
          <Sparkles className="w-5 h-5 text-amber-400" /> ASK RHINOQUANT AI RESEARCH COPILOT
        </div>

        <form onSubmit={handleAskAi} className="flex gap-2">
          <input
            type="text"
            placeholder="Ask AI e.g. 'Explain why Z-spread differs from OAS for callable bonds'"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
          />
          <button
            type="submit"
            disabled={isAiLoading}
            className="bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-bold px-4 py-2 rounded transition-colors flex items-center gap-1"
          >
            {isAiLoading ? 'Analyzing...' : <Send className="w-4 h-4" />}
          </button>
        </form>

        {aiResponse && (
          <div className="bg-slate-950 p-4 rounded border border-slate-800 text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
            {aiResponse}
          </div>
        )}
      </div>
    </div>
  );
};
