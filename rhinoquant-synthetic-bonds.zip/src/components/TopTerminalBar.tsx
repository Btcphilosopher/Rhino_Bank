import React from 'react';
import { Currency } from '../types/bond';
import { Activity, ShieldAlert, Cpu, Sparkles } from 'lucide-react';

interface TopTerminalBarProps {
  activeCurrency: Currency;
  onCurrencyChange: (c: Currency) => void;
  marketRegime: string;
  onRegimeChange: (regime: string) => void;
  rateShiftBp: number;
  onRateShiftChange: (bp: number) => void;
}

export const TopTerminalBar: React.FC<TopTerminalBarProps> = ({
  activeCurrency,
  onCurrencyChange,
  marketRegime,
  onRegimeChange,
  rateShiftBp,
  onRateShiftChange,
}) => {
  return (
    <header className="bg-[#0f172a] border-b border-slate-800 text-slate-200">
      {/* Top Banner Row */}
      <div className="flex flex-wrap items-center justify-between px-4 py-2 text-xs border-b border-slate-800/80 gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold text-sm tracking-wider text-amber-400 font-mono">
              RHINOQUANT
            </span>
            <span className="text-slate-400 font-semibold tracking-wide hidden sm:inline">
              SYNTHETIC BONDS
            </span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400 font-mono text-[11px] hidden md:inline">
            CONSTRUCT → PRICE → CURVE → RISK → STRESS
          </span>
        </div>

        {/* Live Market Ticker */}
        <div className="hidden xl:flex items-center gap-4 font-mono text-[11px] bg-slate-900/80 px-3 py-1 rounded border border-slate-800">
          <div>
            <span className="text-slate-500">{activeCurrency} BENCHMARK:</span>{' '}
            <span className="text-emerald-400 font-semibold">4.18%</span>
          </div>
          <span className="text-slate-700">·</span>
          <div>
            <span className="text-slate-500">AAA:</span>{' '}
            <span className="text-slate-300">+52bp</span>
          </div>
          <span className="text-slate-700">·</span>
          <div>
            <span className="text-slate-500">A CREDIT:</span>{' '}
            <span className="text-slate-300">5.41% (+155bp)</span>
          </div>
          <span className="text-slate-700">·</span>
          <div>
            <span className="text-slate-500">BBB CREDIT:</span>{' '}
            <span className="text-amber-300">6.27% (+292bp)</span>
          </div>
          <span className="text-slate-700">·</span>
          <div>
            <span className="text-slate-500">HY SPREAD:</span>{' '}
            <span className="text-red-400">+640bp</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          {/* Currency Switcher */}
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800">
            {(['GBP', 'USD', 'EUR', 'JPY', 'CHF', 'CAD', 'AUD'] as Currency[]).map((curr) => (
              <button
                key={curr}
                onClick={() => onCurrencyChange(curr)}
                className={`px-2 py-0.5 text-[11px] font-mono font-medium rounded transition-colors ${
                  activeCurrency === curr
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>

          {/* Rate Shock Dial */}
          <div className="flex items-center gap-2 bg-slate-900 px-2 py-1 rounded border border-slate-800">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Curve Shock:</span>
            <input
              type="range"
              min="-200"
              max="200"
              step="10"
              value={rateShiftBp}
              onChange={(e) => onRateShiftChange(parseInt(e.target.value))}
              className="w-16 h-1 accent-amber-500 cursor-pointer"
            />
            <span className={`font-mono text-[11px] ${rateShiftBp > 0 ? 'text-red-400' : rateShiftBp < 0 ? 'text-emerald-400' : 'text-slate-300'}`}>
              {rateShiftBp >= 0 ? `+${rateShiftBp}` : rateShiftBp}bp
            </span>
          </div>

          {/* Market Regime */}
          <select
            value={marketRegime}
            onChange={(e) => onRegimeChange(e.target.value)}
            className="bg-slate-900 text-slate-300 text-xs font-mono border border-slate-800 rounded px-2 py-1 focus:outline-none focus:border-amber-500"
          >
            <option value="NORMAL">Regime: Normal Base</option>
            <option value="HIGH_VOL">Regime: High Volatility</option>
            <option value="TIGHT_CREDIT">Regime: Credit Crunch</option>
            <option value="RATE_CUTS">Regime: Monetary Easing</option>
            <option value="STAGFLATION">Regime: Stagflation Shock</option>
          </select>
        </div>
      </div>
    </header>
  );
};
