import React, { useState } from 'react';
import { SyntheticIssuer, Sector, CreditRating } from '../types/bond';
import { Building2, Search, Activity, DollarSign, Percent, ShieldAlert } from 'lucide-react';

interface IssuersViewProps {
  issuers: SyntheticIssuer[];
}

export const IssuersView: React.FC<IssuersViewProps> = ({ issuers }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSector, setFilterSector] = useState<string>('ALL');

  const filteredIssuers = issuers.filter((iss) => {
    const matchesSearch = iss.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          iss.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = filterSector === 'ALL' || iss.sector === filterSector;
    return matchesSearch && matchesSector;
  });

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Header & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#131b2e] p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-lg font-bold font-mono text-amber-400 uppercase flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-400" /> SYNTHETIC ISSUER ENGINE
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            {filteredIssuers.length} Internally Coherent Synthetic Issuers & Balance Sheets
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search Issuer Name or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded pl-9 pr-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
            />
          </div>

          <select
            value={filterSector}
            onChange={(e) => setFilterSector(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
          >
            <option value="ALL">All Sectors</option>
            <option value="INDUSTRIALS">INDUSTRIALS</option>
            <option value="BANKS">BANKS</option>
            <option value="UTILITIES">UTILITIES</option>
            <option value="ENERGY">ENERGY</option>
            <option value="TECHNOLOGY">TECHNOLOGY</option>
          </select>
        </div>
      </div>

      {/* Issuers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredIssuers.map((issuer) => (
          <div
            key={issuer.id}
            className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs"
          >
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] text-amber-400 font-bold block">{issuer.id} · {issuer.country}</span>
                <h3 className="text-sm font-bold text-slate-100 font-sans">{issuer.name}</h3>
                <span className="text-[11px] text-slate-400">{issuer.sector} · {issuer.currency}</span>
              </div>
              <span className="bg-slate-900 border border-slate-700 text-amber-300 font-bold px-2 py-1 rounded">
                {issuer.rating}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
              <div>
                <span className="text-slate-500 text-[10px] block">REVENUE:</span>
                <span className="font-bold text-slate-200">{issuer.currency} {issuer.revenueMln.toLocaleString()}m</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">EBITDA:</span>
                <span className="font-bold text-slate-200">{issuer.currency} {issuer.ebitdaMln.toLocaleString()}m</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">TOTAL DEBT:</span>
                <span className="font-bold text-slate-200">{issuer.currency} {issuer.debtMln.toLocaleString()}m</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">LEVERAGE (DEBT/EBITDA):</span>
                <span className={`font-bold ${issuer.leverageRatio > 4 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {issuer.leverageRatio}x
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">INTEREST COVER:</span>
                <span className={`font-bold ${issuer.interestCoverageRatio < 2.5 ? 'text-red-400' : 'text-emerald-400'}`}>
                  {issuer.interestCoverageRatio}x
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">BASE CREDIT SPREAD:</span>
                <span className="font-bold text-amber-400">+{issuer.baseCreditSpreadBp} bp</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] pt-1 text-slate-400">
              <span>1Y Default Prob: <strong className="text-red-400">{(issuer.defaultProbability1Y * 100).toFixed(2)}%</strong></span>
              <span>Recovery Rate: <strong className="text-slate-200">{(issuer.recoveryRate * 100).toFixed(0)}%</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
