import React, { useState } from 'react';
import { Currency, CreditRating } from '../types/bond';
import { generateFullCurve, TENORS, BASE_BENCHMARK_RATES, RATING_SPREAD_CURVES } from '../engine/curves';
import { Sliders, LineChart, Table, RefreshCw } from 'lucide-react';

interface CurvesViewProps {
  currency: Currency;
  rateShiftBp: number;
}

export const CurvesView: React.FC<CurvesViewProps> = ({ currency, rateShiftBp }) => {
  const [selectedRating, setSelectedRating] = useState<CreditRating>('A');
  const [slopeShift, setSlopeShift] = useState<number>(0);
  const [beta0, setBeta0] = useState<number>(0.045);
  const [beta1, setBeta1] = useState<number>(-0.015);
  const [beta2, setBeta2] = useState<number>(0.02);
  const [tau, setTau] = useState<number>(2.5);
  const [useNelsonSiegel, setUseNelsonSiegel] = useState<boolean>(false);

  const curveNodes = generateFullCurve(
    currency,
    rateShiftBp,
    slopeShift,
    useNelsonSiegel ? { beta0, beta1, beta2, tau } : undefined
  );

  const ratingSpreads = RATING_SPREAD_CURVES[selectedRating] || RATING_SPREAD_CURVES.A;

  // Chart plotting math (SVG)
  const svgWidth = 800;
  const svgHeight = 280;
  const margin = { top: 20, right: 30, bottom: 40, left: 50 };
  const width = svgWidth - margin.left - margin.right;
  const height = svgHeight - margin.top - margin.bottom;

  const maxYears = 50;
  const maxRate = 0.10; // 10%

  const pointsRiskFree = curveNodes.map((node) => {
    const x = margin.left + (node.years / maxYears) * width;
    const y = margin.top + height - (node.spotRate / maxRate) * height;
    return `${x},${y}`;
  }).join(' ');

  const pointsCreditCurve = curveNodes.map((node) => {
    const spreadBp = ratingSpreads[node.tenor] || 100;
    const creditYield = node.spotRate + spreadBp / 10000;
    const x = margin.left + (node.years / maxYears) * width;
    const y = margin.top + height - (creditYield / maxRate) * height;
    return `${x},${y}`;
  }).join(' ');

  const pointsForwardCurve = curveNodes.map((node) => {
    const x = margin.left + (node.years / maxYears) * width;
    const y = margin.top + height - (node.forwardRate / maxRate) * height;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Chart & Calibration Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SVG Multi-Curve Chart */}
        <div className="lg:col-span-2 bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider flex items-center gap-2">
              <LineChart className="w-4 h-4" /> {currency} Yield & Credit Curve Visualizer
            </h3>
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-emerald-400 inline-block"></span>
                <span className="text-slate-300">Risk-Free Benchmark</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-amber-400 inline-block"></span>
                <span className="text-slate-300">{selectedRating} Credit Curve</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-blue-400 inline-block stroke-dasharray"></span>
                <span className="text-slate-300">Forward Curve</span>
              </div>
            </div>
          </div>

          {/* SVG Plot */}
          <div className="w-full overflow-x-auto bg-slate-950/80 rounded-lg p-2 border border-slate-800">
            <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto font-mono text-[10px]">
              {/* Grid Lines */}
              {[0, 0.02, 0.04, 0.06, 0.08, 0.10].map((rate) => {
                const y = margin.top + height - (rate / maxRate) * height;
                return (
                  <g key={rate}>
                    <line x1={margin.left} y1={y} x2={svgWidth - margin.right} y2={y} stroke="#1e293b" strokeDasharray="3,3" />
                    <text x={margin.left - 8} y={y + 3} fill="#64748b" textAnchor="end">
                      {(rate * 100).toFixed(0)}%
                    </text>
                  </g>
                );
              })}

              {/* Tenor X-Axis */}
              {[1, 5, 10, 20, 30, 50].map((yr) => {
                const x = margin.left + (yr / maxYears) * width;
                return (
                  <g key={yr}>
                    <line x1={x} y1={margin.top} x2={x} y2={margin.top + height} stroke="#1e293b" strokeDasharray="3,3" />
                    <text x={x} y={margin.top + height + 16} fill="#64748b" textAnchor="middle">
                      {yr}Y
                    </text>
                  </g>
                );
              })}

              {/* Curve Lines */}
              <polyline fill="none" stroke="#10b981" strokeWidth="2.5" points={pointsRiskFree} />
              <polyline fill="none" stroke="#f59e0b" strokeWidth="2.5" points={pointsCreditCurve} />
              <polyline fill="none" stroke="#60a5fa" strokeWidth="2" strokeDasharray="4,4" points={pointsForwardCurve} />

              {/* Data Points */}
              {curveNodes.map((node) => {
                const x = margin.left + (node.years / maxYears) * width;
                const yRF = margin.top + height - (node.spotRate / maxRate) * height;
                return (
                  <circle key={node.tenor} cx={x} cy={yRF} r="3" fill="#10b981" />
                );
              })}
            </svg>
          </div>
        </div>

        {/* Nelson-Siegel & Slope Calibration Panel */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-5">
          <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <Sliders className="w-4 h-4" /> Calibration & Model Parameters
          </h3>

          <div className="space-y-4 text-xs font-mono">
            {/* Rating Selector */}
            <div>
              <label className="text-slate-400 block mb-1">CREDIT CURVE RATING SPREAD:</label>
              <select
                value={selectedRating}
                onChange={(e) => setSelectedRating(e.target.value as CreditRating)}
                className="w-full bg-slate-900 border border-slate-700 text-amber-300 rounded p-2"
              >
                {(['AAA', 'AA', 'A', 'BBB', 'BB', 'B', 'CCC'] as CreditRating[]).map((r) => (
                  <option key={r} value={r}>{r} Credit Curve</option>
                ))}
              </select>
            </div>

            {/* Slope Shift */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>CURVE SLOPE SHIFT:</span>
                <span className="text-amber-400">{slopeShift > 0 ? `+${slopeShift}` : slopeShift} bp</span>
              </div>
              <input
                type="range"
                min="-100"
                max="100"
                value={slopeShift}
                onChange={(e) => setSlopeShift(parseInt(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Toggle Nelson-Siegel */}
            <div className="pt-2 border-t border-slate-800">
              <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useNelsonSiegel}
                  onChange={(e) => setUseNelsonSiegel(e.target.checked)}
                  className="accent-amber-500 rounded"
                />
                <span className="font-semibold text-amber-400">Enable Nelson-Siegel Model Fit</span>
              </label>
            </div>

            {useNelsonSiegel && (
              <div className="space-y-3 p-3 bg-slate-900/90 rounded border border-slate-800">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                    <span>β0 (Long-term rate level):</span>
                    <span className="text-slate-200">{(beta0 * 100).toFixed(2)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="0.10"
                    step="0.001"
                    value={beta0}
                    onChange={(e) => setBeta0(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                    <span>β1 (Short-term component/slope):</span>
                    <span className="text-slate-200">{(beta1 * 100).toFixed(2)}%</span>
                  </div>
                  <input
                    type="range"
                    min="-0.05"
                    max="0.05"
                    step="0.001"
                    value={beta1}
                    onChange={(e) => setBeta1(parseFloat(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                    <span>β2 (Medium-term curvature):</span>
                    <span className="text-slate-200">{(beta2 * 100).toFixed(2)}%</span>
                  </div>
                  <input
                    type="range"
                    min="-0.05"
                    max="0.05"
                    step="0.001"
                    value={beta2}
                    onChange={(e) => setBeta2(parseFloat(e.target.value))}
                    className="w-full accent-blue-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-0.5">
                    <span>τ (Scale parameter):</span>
                    <span className="text-slate-200">{tau.toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="10.0"
                    step="0.1"
                    value={tau}
                    onChange={(e) => setTau(parseFloat(e.target.value))}
                    className="w-full accent-purple-500"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bootstrapped Curve Table */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800">
        <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Table className="w-4 h-4" /> Bootstrapped Term Structure Data
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-2">TENOR</th>
                <th className="pb-2">YEARS</th>
                <th className="pb-2">SPOT RATE</th>
                <th className="pb-2">FORWARD RATE</th>
                <th className="pb-2">CREDIT SPREAD</th>
                <th className="pb-2">TOTAL YIELD</th>
                <th className="pb-2">DISCOUNT FACTOR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {curveNodes.map((node) => {
                const spreadBp = ratingSpreads[node.tenor] || 100;
                const totalYield = node.spotRate + spreadBp / 10000;
                return (
                  <tr key={node.tenor} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 font-bold text-slate-200">{node.tenor}</td>
                    <td className="py-2.5 text-slate-400">{node.years.toFixed(2)}</td>
                    <td className="py-2.5 text-emerald-400">{(node.spotRate * 100).toFixed(3)}%</td>
                    <td className="py-2.5 text-blue-400">{(node.forwardRate * 100).toFixed(3)}%</td>
                    <td className="py-2.5 text-amber-300">+{spreadBp} bp</td>
                    <td className="py-2.5 font-bold text-amber-400">{(totalYield * 100).toFixed(3)}%</td>
                    <td className="py-2.5 text-slate-400">{node.discountFactor.toFixed(5)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
