import React, { useState } from 'react';
import { generateSyntheticUniverse } from '../engine/generator';
import { Cpu, RefreshCw, Download, Database, Layers, Sparkles } from 'lucide-react';

export const SimulationView: React.FC = () => {
  const [universeSize, setUniverseSize] = useState<number>(1000);
  const [seed, setSeed] = useState<number>(42);
  const [generatedCount, setGeneratedCount] = useState<number>(0);
  const [genTimeMs, setGenTimeMs] = useState<number>(0);
  const [ratingCounts, setRatingCounts] = useState<Record<string, number>>({});
  const [sectorCounts, setSectorCounts] = useState<Record<string, number>>({});
  const [sampleBonds, setSampleBonds] = useState<any[]>([]);

  const handleRunSimulation = () => {
    const startTime = performance.now();
    const { bonds } = generateSyntheticUniverse(universeSize, seed);
    const endTime = performance.now();

    const elapsed = Math.round(endTime - startTime);
    setGenTimeMs(elapsed);
    setGeneratedCount(bonds.length);

    // Rating distribution
    const rCounts: Record<string, number> = {};
    const sCounts: Record<string, number> = {};

    bonds.forEach((b) => {
      rCounts[b.rating] = (rCounts[b.rating] || 0) + 1;
      sCounts[b.sector] = (sCounts[b.sector] || 0) + 1;
    });

    setRatingCounts(rCounts);
    setSectorCounts(sCounts);
    setSampleBonds(bonds.slice(0, 10));
  };

  const handleExportJson = () => {
    const { bonds } = generateSyntheticUniverse(universeSize, seed);
    const blob = new Blob([JSON.stringify(bonds, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rhinoquant_synthetic_universe_${universeSize}_seed${seed}.json`;
    a.click();
  };

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Controls Card */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <span className="text-amber-400 font-bold uppercase text-xs">MONTE CARLO / REPRODUCIBLE GENERATOR</span>
            <h2 className="text-lg font-bold text-slate-100 font-sans">
              Synthetic Bond Universe Generator (100 to 100,000 Instruments)
            </h2>
          </div>
          <button
            onClick={handleExportJson}
            disabled={generatedCount === 0}
            className="flex items-center gap-2 bg-slate-900 border border-slate-700 hover:border-slate-500 disabled:opacity-50 text-slate-200 px-4 py-2 rounded font-bold"
          >
            <Download className="w-4 h-4 text-amber-400" /> EXPORT UNIVERSE JSON
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div>
            <label className="text-slate-400 block mb-1">UNIVERSE SIZE (BONDS):</label>
            <select
              value={universeSize}
              onChange={(e) => setUniverseSize(parseInt(e.target.value))}
              className="bg-slate-900 border border-slate-700 rounded px-3 py-2 text-amber-300 font-bold"
            >
              <option value={100}>100 Bonds (Instant)</option>
              <option value={1000}>1,000 Bonds (Default)</option>
              <option value={10000}>10,000 Bonds (High Capacity)</option>
              <option value={100000}>100,000 Bonds (Stress Test)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">DETERMINISTIC SEED:</label>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(parseInt(e.target.value) || 42)}
              className="bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-slate-100 w-28 font-bold"
            />
          </div>

          <div className="pt-5">
            <button
              onClick={handleRunSimulation}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2 rounded transition-colors"
            >
              <RefreshCw className="w-4 h-4" /> GENERATE UNIVERSE
            </button>
          </div>
        </div>
      </div>

      {/* Generation Stats Banner */}
      {generatedCount > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
          <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
            <span className="text-slate-400 block">TOTAL BONDS GENERATED:</span>
            <span className="text-xl font-bold text-amber-400">{generatedCount.toLocaleString()}</span>
          </div>

          <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
            <span className="text-slate-400 block">GENERATION TIME:</span>
            <span className="text-xl font-bold text-emerald-400">{genTimeMs} ms</span>
          </div>

          <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
            <span className="text-slate-400 block">DETERMINISTIC SEED:</span>
            <span className="text-xl font-bold text-blue-400">SEED #{seed}</span>
          </div>
        </div>
      )}

      {/* Distribution Grids */}
      {generatedCount > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
          <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-3">
            <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider">
              Rating Class Distribution
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {Object.entries(ratingCounts).map(([rating, count]) => (
                <div key={rating} className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <span className="text-amber-300 font-bold block">{rating}</span>
                  <span className="text-slate-200">{count} bonds ({(count / generatedCount * 100).toFixed(1)}%)</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-3">
            <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider">
              Sector Distribution
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {Object.entries(sectorCounts).map(([sector, count]) => (
                <div key={sector} className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <span className="text-slate-300 font-bold block truncate">{sector}</span>
                  <span className="text-emerald-400">{count} bonds</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
