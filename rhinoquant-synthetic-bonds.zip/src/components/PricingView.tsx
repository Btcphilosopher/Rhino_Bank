import React from 'react';
import { SyntheticBond } from '../types/bond';
import { priceBond, solveYTM, calculatePVFromYield } from '../engine/pricing';
import { Calculator, DollarSign, Activity, Percent, ArrowDownRight, ArrowUpRight, LineChart } from 'lucide-react';

interface PricingViewProps {
  bond: SyntheticBond;
  rateShiftBp: number;
}

export const PricingView: React.FC<PricingViewProps> = ({ bond, rateShiftBp }) => {
  const valuation = priceBond(bond, rateShiftBp);

  // Price vs Yield Sensitivity Curve Data
  const yieldRange: number[] = [];
  for (let y = 0.01; y <= 0.10; y += 0.005) {
    yieldRange.push(y);
  }

  const sensitivityCurve = yieldRange.map((y) => {
    const pv = calculatePVFromYield(bond, y);
    return { yieldRate: y, price: pv };
  });

  // SVG Chart Dimensions
  const svgWidth = 600;
  const svgHeight = 220;
  const margin = { top: 20, right: 30, bottom: 40, left: 50 };
  const width = svgWidth - margin.left - margin.right;
  const height = svgHeight - margin.top - margin.bottom;

  const minPrice = Math.min(...sensitivityCurve.map((d) => d.price));
  const maxPrice = Math.max(...sensitivityCurve.map((d) => d.price));

  const pointsPriceYield = sensitivityCurve.map((d) => {
    const x = margin.left + ((d.yieldRate - 0.01) / 0.09) * width;
    const y = margin.top + height - ((d.price - minPrice) / (maxPrice - minPrice || 1)) * height;
    return `${x},${y}`;
  }).join(' ');

  // Current YTM point on chart
  const currentX = margin.left + ((valuation.yieldToMaturity - 0.01) / 0.09) * width;
  const currentY = margin.top + height - ((valuation.dirtyPrice - minPrice) / (maxPrice - minPrice || 1)) * height;

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Selected Bond Banner */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-2 font-mono">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <span className="text-amber-400 font-bold text-xs">{bond.id} · {bond.isin}</span>
            <h2 className="text-lg font-bold text-slate-100 font-sans">{bond.name}</h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="bg-slate-900 border border-slate-700 text-amber-300 font-bold px-2.5 py-1 rounded text-xs">
              {bond.rating} RATING
            </span>
            <span className="bg-amber-500/20 text-amber-300 font-bold px-2.5 py-1 rounded text-xs border border-amber-500/30">
              {bond.currency} {bond.issueSizeMln}M ISSUE
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
          <span>Issuer: <strong className="text-slate-200">{bond.issuerName}</strong></span>
          <span>·</span>
          <span>Coupon: <strong className="text-emerald-400">{(bond.couponRate * 100).toFixed(3)}% {bond.frequency}</strong></span>
          <span>·</span>
          <span>Day Count: <strong className="text-slate-200">{bond.dayCount}</strong></span>
          <span>·</span>
          <span>Spread: <strong className="text-amber-400">+{bond.marketSpreadBp} bp market / +{bond.liquiditySpreadBp} bp liquidity</strong></span>
        </div>
      </div>

      {/* Primary Valuation Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono">
        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">DIRTY PRICE</span>
          <div className="text-xl font-bold text-emerald-400 mt-1">
            {valuation.dirtyPrice.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-500">% of Par</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">CLEAN PRICE</span>
          <div className="text-xl font-bold text-slate-100 mt-1">
            {valuation.cleanPrice.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-500">Excl. Accrued</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">YIELD TO MATURITY</span>
          <div className="text-xl font-bold text-amber-400 mt-1">
            {(valuation.yieldToMaturity * 100).toFixed(3)}%
          </div>
          <span className="text-[10px] text-slate-500">Root Solved YTM</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">MOD DURATION</span>
          <div className="text-xl font-bold text-blue-400 mt-1">
            {valuation.modifiedDuration.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-500">Years</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">Z-SPREAD</span>
          <div className="text-xl font-bold text-purple-400 mt-1">
            +{valuation.zSpreadBp.toFixed(0)} bp
          </div>
          <span className="text-[10px] text-slate-500">Over Zero Curve</span>
        </div>

        <div className="bg-[#131b2e] p-4 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">EXECUTABLE PRICE</span>
          <div className="text-xl font-bold text-amber-300 mt-1">
            {valuation.executablePrice.toFixed(2)}
          </div>
          <span className="text-[10px] text-slate-500">Incl Liquidity Penalty</span>
        </div>
      </div>

      {/* Price vs Yield Curve Chart & Math Explainer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-[#131b2e] p-5 rounded-xl border border-slate-800 space-y-3">
          <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <LineChart className="w-4 h-4" /> Convexity & Price-Yield Convex Curve
          </h3>

          <div className="w-full overflow-x-auto bg-slate-950/80 rounded-lg p-2 border border-slate-800">
            <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto font-mono text-[10px]">
              {/* Axes */}
              <line x1={margin.left} y1={margin.top + height} x2={svgWidth - margin.right} y2={margin.top + height} stroke="#334155" />
              <line x1={margin.left} y1={margin.top} x2={margin.left} y2={margin.top + height} stroke="#334155" />

              {/* Price-Yield Convex Curve */}
              <polyline fill="none" stroke="#10b981" strokeWidth="2.5" points={pointsPriceYield} />

              {/* Current YTM Intersection point */}
              {currentX >= margin.left && currentX <= svgWidth - margin.right && (
                <g>
                  <line x1={currentX} y1={margin.top} x2={currentX} y2={margin.top + height} stroke="#f59e0b" strokeDasharray="3,3" />
                  <circle cx={currentX} cy={currentY} r="5" fill="#f59e0b" className="animate-ping opacity-75" />
                  <circle cx={currentX} cy={currentY} r="4" fill="#f59e0b" />
                  <text x={currentX + 8} y={currentY - 8} fill="#f59e0b" fontWeight="bold">
                    YTM: {(valuation.yieldToMaturity * 100).toFixed(2)}% @ {valuation.dirtyPrice.toFixed(2)}
                  </text>
                </g>
              )}
            </svg>
          </div>
        </div>

        {/* Math & Deconstruction */}
        <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800 font-mono text-xs space-y-3">
          <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider">
            VALUATION MATHEMATICS
          </h3>
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-slate-300">
            <div className="text-emerald-400 font-bold">
              PV = Σ [ CFₜ × DFₜ ]
            </div>
            <p className="text-[11px] text-slate-400">
              Where CFₜ represents the cash flow at period t and DFₜ is the discount factor derived from the risk-free benchmark curve + credit spread + liquidity spread.
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">Total Cash Flows:</span>
              <span className="font-bold text-slate-200">£{valuation.totalCashFlowSum.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Total Present Value:</span>
              <span className="font-bold text-emerald-400">£{valuation.totalPV.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Convexity Measure:</span>
              <span className="font-bold text-amber-400">{valuation.convexity.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">DV01 per £1m Face:</span>
              <span className="font-bold text-blue-400">£{valuation.dv01.toFixed(0)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cash Flow Schedule Table */}
      <div className="bg-[#131b2e] p-5 rounded-xl border border-slate-800">
        <h3 className="text-sm font-semibold font-mono text-amber-400 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Calculator className="w-4 h-4" /> Cash Flow Schedule & Discounting Table
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-2">PERIOD</th>
                <th className="pb-2">PAYMENT DATE</th>
                <th className="pb-2">YEAR FRAC</th>
                <th className="pb-2">COUPON</th>
                <th className="pb-2">PRINCIPAL</th>
                <th className="pb-2">TOTAL CASH FLOW</th>
                <th className="pb-2">DISCOUNT FACTOR</th>
                <th className="pb-2">PRESENT VALUE (PV)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {valuation.cashFlows.map((cf) => (
                <tr key={cf.period} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 font-bold text-slate-400">#{cf.period}</td>
                  <td className="py-2.5 font-bold text-slate-200">{cf.date}</td>
                  <td className="py-2.5 text-slate-400">{cf.yearFraction.toFixed(3)}</td>
                  <td className="py-2.5 text-emerald-400">£{cf.couponPayment.toFixed(3)}</td>
                  <td className="py-2.5 text-blue-400">
                    {cf.principalPayment > 0 ? `£${cf.principalPayment.toFixed(2)}` : '—'}
                  </td>
                  <td className="py-2.5 font-bold text-slate-100">£{cf.totalCashFlow.toFixed(3)}</td>
                  <td className="py-2.5 text-slate-400">{cf.discountFactor.toFixed(5)}</td>
                  <td className="py-2.5 font-bold text-amber-400">£{cf.pv.toFixed(3)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-slate-700 font-bold text-slate-100">
                <td colSpan={5} className="py-3 text-right uppercase text-slate-400">VALUATION SUM:</td>
                <td className="py-3 text-emerald-400">£{valuation.totalCashFlowSum.toFixed(2)}</td>
                <td className="py-3"></td>
                <td className="py-3 text-amber-400 text-sm">£{valuation.dirtyPrice.toFixed(2)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
