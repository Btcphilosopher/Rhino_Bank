import React, { useState } from 'react';
import { SyntheticBond, Currency, CreditRating, Sector, BondType, CouponFrequency, DayCountConvention, Seniority } from '../types/bond';
import { Plus, Search, Filter, ArrowRight, Shield, Calendar, DollarSign, Sparkles } from 'lucide-react';
import { priceBond } from '../engine/pricing';

interface BondsViewProps {
  bonds: SyntheticBond[];
  onSelectBond: (bond: SyntheticBond) => void;
  onCreateBond: (newBond: SyntheticBond) => void;
  rateShiftBp: number;
}

export const BondsView: React.FC<BondsViewProps> = ({
  bonds,
  onSelectBond,
  onCreateBond,
  rateShiftBp,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCurrency, setFilterCurrency] = useState<string>('ALL');
  const [filterRating, setFilterRating] = useState<string>('ALL');
  const [filterSector, setFilterSector] = useState<string>('ALL');
  const [showConstructor, setShowConstructor] = useState(false);

  // Bond Constructor Form State
  const [formName, setFormName] = useState('Synthetic British Industrial Holdings 5.125% 2035');
  const [formIssuerName, setFormIssuerName] = useState('Synthetic British Industrial Holdings');
  const [formSector, setFormSector] = useState<Sector>('INDUSTRIALS');
  const [formCurrency, setFormCurrency] = useState<Currency>('GBP');
  const [formIssueDate, setFormIssueDate] = useState('2025-01-15');
  const [formMaturityDate, setFormMaturityDate] = useState('2035-06-15');
  const [formCouponRate, setFormCouponRate] = useState<number>(5.125); // %
  const [formFrequency, setFormFrequency] = useState<CouponFrequency>('SEMI_ANNUAL');
  const [formDayCount, setFormDayCount] = useState<DayCountConvention>('ACT_ACT');
  const [formType, setFormType] = useState<BondType>('FIXED');
  const [formSeniority, setFormSeniority] = useState<Seniority>('SENIOR_UNSECURED');
  const [formRating, setFormRating] = useState<CreditRating>('A-');
  const [formIssueSizeMln, setFormIssueSizeMln] = useState<number>(750);
  const [formMarketSpreadBp, setFormMarketSpreadBp] = useState<number>(145);
  const [formLiquiditySpreadBp, setFormLiquiditySpreadBp] = useState<number>(25);

  const filteredBonds = bonds.filter((b) => {
    const matchesSearch = b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          b.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          b.isin.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCurrency = filterCurrency === 'ALL' || b.currency === filterCurrency;
    const matchesRating = filterRating === 'ALL' || b.rating === filterRating;
    const matchesSector = filterSector === 'ALL' || b.sector === filterSector;
    return matchesSearch && matchesCurrency && matchesRating && matchesSector;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const created: SyntheticBond = {
      id: `RQ-CUSTOM-${Date.now().toString().slice(-4)}`,
      isin: `GB00CUSTOM${Date.now().toString().slice(-4)}`,
      name: formName,
      issuerId: `ISS-CUSTOM-${Date.now().toString().slice(-4)}`,
      issuerName: formIssuerName,
      sector: formSector,
      currency: formCurrency,
      issueDate: formIssueDate,
      maturityDate: formMaturityDate,
      couponRate: formCouponRate / 100.0,
      frequency: formFrequency,
      dayCount: formDayCount,
      type: formType,
      seniority: formSeniority,
      rating: formRating,
      issueSizeMln: formIssueSizeMln,
      marketSpreadBp: formMarketSpreadBp,
      liquiditySpreadBp: formLiquiditySpreadBp,
    };
    onCreateBond(created);
    setShowConstructor(false);
    onSelectBond(created);
  };

  return (
    <div className="bg-[#0b0f17] text-slate-100 p-6 space-y-6">
      {/* Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#131b2e] p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-lg font-bold font-mono text-amber-400">
            SYNTHETIC BOND DIRECTORY
          </h2>
          <p className="text-xs text-slate-400">
            {filteredBonds.length} Synthetic Fixed-Income Instruments Available
          </p>
        </div>

        <button
          onClick={() => setShowConstructor(true)}
          className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold font-mono text-xs px-4 py-2 rounded.lg transition-colors"
        >
          <Plus className="w-4 h-4" /> CONSTRUCT NEW SYNTHETIC BOND
        </button>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-[#131b2e] p-4 rounded-xl border border-slate-800 text-xs font-mono">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search ISIN, Name, Code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded pl-9 pr-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <select
            value={filterCurrency}
            onChange={(e) => setFilterCurrency(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
          >
            <option value="ALL">Currency: All ({['GBP','USD','EUR','JPY'].join(', ')})</option>
            <option value="GBP">GBP - British Pound</option>
            <option value="USD">USD - US Dollar</option>
            <option value="EUR">EUR - Euro</option>
            <option value="JPY">JPY - Japanese Yen</option>
          </select>
        </div>

        <div>
          <select
            value={filterRating}
            onChange={(e) => setFilterRating(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
          >
            <option value="ALL">Rating: All Grades</option>
            <option value="AAA">AAA Rating</option>
            <option value="AA">AA Rating</option>
            <option value="A-">A- Rating</option>
            <option value="BBB">BBB Rating</option>
            <option value="BB">BB High Yield</option>
          </select>
        </div>

        <div>
          <select
            value={filterSector}
            onChange={(e) => setFilterSector(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
          >
            <option value="ALL">Sector: All Sectors</option>
            <option value="INDUSTRIALS">Industrials</option>
            <option value="BANKS">Banks & Financials</option>
            <option value="UTILITIES">Utilities</option>
            <option value="ENERGY">Energy</option>
            <option value="TECHNOLOGY">Technology</option>
          </select>
        </div>
      </div>

      {/* Bond Grid / Directory */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBonds.map((bond) => {
          const pricing = priceBond(bond, rateShiftBp);
          return (
            <div
              key={bond.id}
              onClick={() => onSelectBond(bond)}
              className="bg-[#131b2e] hover:bg-slate-800/80 transition-all p-5 rounded-xl border border-slate-800 cursor-pointer space-y-3 group"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[11px] font-mono font-bold text-amber-400">
                    {bond.id}
                  </div>
                  <h3 className="text-sm font-semibold text-slate-100 group-hover:text-amber-300 transition-colors line-clamp-1">
                    {bond.name}
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-amber-300">
                  {bond.rating}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
                <div>
                  <span className="text-slate-500 block text-[10px]">DIRTY PRICE:</span>
                  <span className="font-bold text-emerald-400">
                    {pricing.dirtyPrice.toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">YIELD TO MATURITY:</span>
                  <span className="font-bold text-amber-400">
                    {(pricing.yieldToMaturity * 100).toFixed(3)}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">MOD DURATION:</span>
                  <span className="text-slate-300">
                    {pricing.modifiedDuration.toFixed(2)} yrs
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">SPREAD:</span>
                  <span className="text-slate-300">
                    +{bond.marketSpreadBp} bp
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
                <span>{bond.currency} · {bond.type} · {bond.seniority}</span>
                <span className="text-amber-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Inspect <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bond Constructor Modal */}
      {showConstructor && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#131b2e] border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-6 max-h-[90vh] overflow-y-auto font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-base font-bold text-amber-400 uppercase flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" /> CONSTRUCT NEW SYNTHETIC BOND
              </h3>
              <button
                onClick={() => setShowConstructor(false)}
                className="text-slate-400 hover:text-slate-100 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">BOND NAME / DESCRIPTION:</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">ISSUER NAME:</label>
                  <input
                    type="text"
                    required
                    value={formIssuerName}
                    onChange={(e) => setFormIssuerName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">CURRENCY:</label>
                  <select
                    value={formCurrency}
                    onChange={(e) => setFormCurrency(e.target.value as Currency)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  >
                    <option value="GBP">GBP - British Pound</option>
                    <option value="USD">USD - US Dollar</option>
                    <option value="EUR">EUR - Euro</option>
                    <option value="JPY">JPY - Japanese Yen</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">SECTOR:</label>
                  <select
                    value={formSector}
                    onChange={(e) => setFormSector(e.target.value as Sector)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  >
                    <option value="INDUSTRIALS">INDUSTRIALS</option>
                    <option value="BANKS">BANKS</option>
                    <option value="UTILITIES">UTILITIES</option>
                    <option value="ENERGY">ENERGY</option>
                    <option value="TECHNOLOGY">TECHNOLOGY</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">COUPON RATE (%):</label>
                  <input
                    type="number"
                    step="0.001"
                    required
                    value={formCouponRate}
                    onChange={(e) => setFormCouponRate(parseFloat(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">MATURITY DATE:</label>
                  <input
                    type="date"
                    required
                    value={formMaturityDate}
                    onChange={(e) => setFormMaturityDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">BOND TYPE:</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as BondType)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  >
                    <option value="FIXED">FIXED COUPON</option>
                    <option value="FLOATING">FLOATING RATE</option>
                    <option value="ZERO">ZERO COUPON</option>
                    <option value="AMORTISING">AMORTISING</option>
                    <option value="CALLABLE">CALLABLE</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">CREDIT RATING:</label>
                  <select
                    value={formRating}
                    onChange={(e) => setFormRating(e.target.value as CreditRating)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  >
                    <option value="AAA">AAA</option>
                    <option value="AA">AA</option>
                    <option value="A-">A-</option>
                    <option value="BBB">BBB</option>
                    <option value="BB">BB</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">MARKET SPREAD (bp):</label>
                  <input
                    type="number"
                    required
                    value={formMarketSpreadBp}
                    onChange={(e) => setFormMarketSpreadBp(parseInt(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">LIQUIDITY SPREAD (bp):</label>
                  <input
                    type="number"
                    required
                    value={formLiquiditySpreadBp}
                    onChange={(e) => setFormLiquiditySpreadBp(parseInt(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowConstructor(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-bold"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded"
                >
                  CONSTRUCT & PRICE BOND
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
