export type Currency = 'GBP' | 'USD' | 'EUR' | 'JPY' | 'CHF' | 'CAD' | 'AUD';

export type CreditRating = 
  | 'AAA' | 'AA+' | 'AA' | 'AA-' 
  | 'A+' | 'A' | 'A-' 
  | 'BBB+' | 'BBB' | 'BBB-' 
  | 'BB+' | 'BB' | 'B' | 'CCC';

export type BondType = 
  | 'FIXED' 
  | 'FLOATING' 
  | 'ZERO' 
  | 'STEP_UP' 
  | 'AMORTISING' 
  | 'SINKING_FUND' 
  | 'CALLABLE' 
  | 'PUTABLE' 
  | 'CONVERTIBLE';

export type DayCountConvention = 'ACT_ACT' | 'ACT_360' | '30_360' | 'ACT_365';

export type CouponFrequency = 'ANNUAL' | 'SEMI_ANNUAL' | 'QUARTERLY' | 'MONTHLY';

export type Seniority = 'SENIOR_UNSECURED' | 'SENIOR_SECURED' | 'SUBORDINATED' | 'JUNIOR_SUBORDINATED';

export type Sector = 
  | 'INDUSTRIALS' 
  | 'BANKS' 
  | 'UTILITIES' 
  | 'CHEMICALS' 
  | 'ENERGY' 
  | 'TRANSPORT' 
  | 'TELECOMMUNICATIONS' 
  | 'TECHNOLOGY' 
  | 'INFRASTRUCTURE' 
  | 'CONSUMER' 
  | 'HEALTHCARE' 
  | 'PROPERTY';

export interface SyntheticIssuer {
  id: string;
  name: string;
  sector: Sector;
  country: string;
  currency: Currency;
  rating: CreditRating;
  revenueMln: number;
  ebitdaMln: number;
  debtMln: number;
  interestCoverageRatio: number;
  leverageRatio: number; // Debt / EBITDA
  defaultProbability1Y: number; // e.g. 0.0015 for 0.15%
  recoveryRate: number; // e.g. 0.40 for 40%
  baseCreditSpreadBp: number;
}

export interface SyntheticBond {
  id: string;
  isin: string;
  name: string;
  issuerId: string;
  issuerName: string;
  sector: Sector;
  currency: Currency;
  issueDate: string; // YYYY-MM-DD
  maturityDate: string; // YYYY-MM-DD
  couponRate: number; // decimal, e.g. 0.04625 for 4.625%
  frequency: CouponFrequency;
  dayCount: DayCountConvention;
  type: BondType;
  seniority: Seniority;
  rating: CreditRating;
  issueSizeMln: number; // in currency millions
  marketSpreadBp: number; // bp over benchmark
  liquiditySpreadBp: number; // bp liquidity premium
  
  // Optional instrument properties
  amortisationPercentPerYear?: number;
  stepUpRates?: { year: number; rate: number }[];
  callPrice?: number; // e.g. 102.5
  callDate?: string;
  putPrice?: number;
  putDate?: string;
  conversionRatio?: number;
}

export interface CashFlow {
  period: number;
  date: string;
  yearFraction: number;
  cumulativeYears: number;
  couponPayment: number;
  principalPayment: number;
  totalCashFlow: number;
  discountFactor: number;
  pv: number;
}

export interface ValuationResult {
  bondId: string;
  dirtyPrice: number; // % of par, e.g. 98.45
  cleanPrice: number;
  accruedInterest: number;
  yieldToMaturity: number; // decimal, e.g. 0.0521
  currentYield: number;
  yieldToCall?: number;
  yieldToWorst: number;
  macaulayDuration: number; // in years
  modifiedDuration: number;
  effectiveDuration: number;
  convexity: number;
  dv01: number; // per £1m / $1m face value
  spreadDv01: number;
  creditDv01: number;
  pv01: number;
  zSpreadBp: number;
  oasBp: number;
  liquidityPenaltyBp: number;
  theoreticalPrice: number;
  executablePrice: number;
  cashFlows: CashFlow[];
  totalCashFlowSum: number;
  totalPV: number;
}

export interface KeyRateDV01 {
  '2Y': number;
  '5Y': number;
  '10Y': number;
  '20Y': number;
  '30Y': number;
}

export interface CreditRiskMetrics {
  hazardRate: number; // lambda
  survivalProbs: { year: number; probability: number }[];
  defaultProbs: { year: number; cumulativeDefault: number }[];
  expectedLossMln: number;
  exposureAtDefaultMln: number;
  lossGivenDefaultPercent: number;
}

export interface CurveNode {
  tenor: string; // '1M', '3M', '6M', '1Y', '2Y', '3Y', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y', '50Y'
  years: number;
  spotRate: number; // decimal e.g. 0.0418 for 4.18%
  zeroRate: number;
  forwardRate: number;
  discountFactor: number;
}

export interface PortfolioPosition {
  id: string;
  bond: SyntheticBond;
  faceValueMln: number;
}

export interface PortfolioValuation {
  positions: {
    position: PortfolioPosition;
    valuation: ValuationResult;
    marketValueMln: number;
    weight: number;
  }[];
  totalMarketValueMln: number;
  totalFaceValueMln: number;
  weightedYtm: number;
  weightedModifiedDuration: number;
  weightedConvexity: number;
  totalDv01: number;
  totalSpreadDv01: number;
  sectorExposure: Record<Sector, number>; // Market Value Mln
  ratingExposure: Record<CreditRating, number>;
  currencyExposure: Record<Currency, number>;
}

export type ScenarioType = 
  | 'PARALLEL_UP_100' 
  | 'PARALLEL_DOWN_100' 
  | 'STEEPENING' 
  | 'FLATTENING' 
  | 'CREDIT_WIDENING' 
  | 'CREDIT_TIGHTENING' 
  | 'LIQUIDITY_SHOCK' 
  | 'RECESSION' 
  | 'INFLATION_SHOCK'
  | 'CUSTOM';

export interface StressScenario {
  id: ScenarioType;
  name: string;
  description: string;
  rateShiftBp: number; // parallel shift
  slopeShiftBp: number; // e.g. 30Y - 2Y shift
  creditSpreadShiftBp: number;
  liquiditySpreadShiftBp: number;
}

export interface ScenarioResult {
  scenario: StressScenario;
  originalValueMln: number;
  stressedValueMln: number;
  pnlMln: number;
  pnlPercent: number;
  decomposition: {
    rateEffectMln: number;
    spreadEffectMln: number;
    convexityEffectMln: number;
    liquidityEffectMln: number;
    residualMln: number;
  };
}
