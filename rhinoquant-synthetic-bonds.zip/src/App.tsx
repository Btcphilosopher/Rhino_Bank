import React, { useState, useMemo } from 'react';
import { Currency, SyntheticBond, SyntheticIssuer } from './types/bond';
import { generateSyntheticUniverse, EXAMPLE_FLAGSHIP_BOND } from './engine/generator';
import { TopTerminalBar } from './components/TopTerminalBar';
import { MarketView } from './components/MarketView';
import { CurvesView } from './components/CurvesView';
import { BondsView } from './components/BondsView';
import { IssuersView } from './components/IssuersView';
import { PricingView } from './components/PricingView';
import { PortfolioView } from './components/PortfolioView';
import { RiskView } from './components/RiskView';
import { ScenariosView } from './components/ScenariosView';
import { ResearchView } from './components/ResearchView';
import { SimulationView } from './components/SimulationView';
import { ApiView } from './components/ApiView';
import { Activity, Layers, FileText, Building2, Calculator, Briefcase, ShieldAlert, Zap, BookOpen, Cpu, Code2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'MARKET' | 'CURVES' | 'BONDS' | 'ISSUERS' | 'PRICING' | 'PORTFOLIO' | 'RISK' | 'SCENARIOS' | 'RESEARCH' | 'SIMULATION' | 'API'
  >('BONDS');

  const [currency, setCurrency] = useState<Currency>('GBP');
  const [marketRegime, setMarketRegime] = useState<string>('NORMAL');
  const [rateShiftBp, setRateShiftBp] = useState<number>(0);

  // Generate initial universe of 100 synthetic bonds reproducibly
  const initialUniverse = useMemo(() => {
    const gen = generateSyntheticUniverse(100, 42);
    return {
      issuers: gen.issuers,
      bonds: [EXAMPLE_FLAGSHIP_BOND, ...gen.bonds],
    };
  }, []);

  const [bonds, setBonds] = useState<SyntheticBond[]>(initialUniverse.bonds);
  const [issuers, setIssuers] = useState<SyntheticIssuer[]>(initialUniverse.issuers);
  const [selectedBond, setSelectedBond] = useState<SyntheticBond>(EXAMPLE_FLAGSHIP_BOND);

  const handleCreateBond = (newBond: SyntheticBond) => {
    setBonds([newBond, ...bonds]);
  };

  const navItems = [
    { id: 'MARKET', label: 'MARKET', icon: Activity },
    { id: 'CURVES', label: 'CURVES', icon: Layers },
    { id: 'BONDS', label: 'BONDS', icon: FileText },
    { id: 'ISSUERS', label: 'ISSUERS', icon: Building2 },
    { id: 'PRICING', label: 'PRICING', icon: Calculator },
    { id: 'PORTFOLIO', label: 'PORTFOLIO', icon: Briefcase },
    { id: 'RISK', label: 'RISK', icon: ShieldAlert },
    { id: 'SCENARIOS', label: 'SCENARIOS', icon: Zap },
    { id: 'RESEARCH', label: 'RESEARCH', icon: BookOpen },
    { id: 'SIMULATION', label: 'SIMULATION', icon: Cpu },
    { id: 'API', label: 'API / CODE', icon: Code2 },
  ] as const;

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Terminal Bar */}
      <TopTerminalBar
        activeCurrency={currency}
        onCurrencyChange={setCurrency}
        marketRegime={marketRegime}
        onRegimeChange={setMarketRegime}
        rateShiftBp={rateShiftBp}
        onRateShiftChange={setRateShiftBp}
      />

      {/* Main Terminal Sub-Navigation */}
      <nav className="bg-[#131b2e] border-b border-slate-800 px-4 flex items-center gap-1 overflow-x-auto scrollbar-none">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex items-center gap-1.5 px-3.5 py-3 text-xs font-mono font-bold tracking-wider whitespace-nowrap transition-colors border-b-2 ${
                isActive
                  ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Main Content Body */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === 'MARKET' && (
          <MarketView currency={currency} rateShiftBp={rateShiftBp} />
        )}

        {activeTab === 'CURVES' && (
          <CurvesView currency={currency} rateShiftBp={rateShiftBp} />
        )}

        {activeTab === 'BONDS' && (
          <BondsView
            bonds={bonds}
            onSelectBond={(b) => {
              setSelectedBond(b);
              setActiveTab('PRICING');
            }}
            onCreateBond={handleCreateBond}
            rateShiftBp={rateShiftBp}
          />
        )}

        {activeTab === 'ISSUERS' && (
          <IssuersView issuers={issuers} />
        )}

        {activeTab === 'PRICING' && (
          <PricingView bond={selectedBond} rateShiftBp={rateShiftBp} />
        )}

        {activeTab === 'PORTFOLIO' && (
          <PortfolioView bonds={bonds} rateShiftBp={rateShiftBp} />
        )}

        {activeTab === 'RISK' && (
          <RiskView bond={selectedBond} rateShiftBp={rateShiftBp} />
        )}

        {activeTab === 'SCENARIOS' && (
          <ScenariosView bond={selectedBond} />
        )}

        {activeTab === 'RESEARCH' && (
          <ResearchView bonds={bonds} rateShiftBp={rateShiftBp} />
        )}

        {activeTab === 'SIMULATION' && (
          <SimulationView />
        )}

        {activeTab === 'API' && (
          <ApiView />
        )}
      </main>

      {/* Terminal Footer */}
      <footer className="bg-[#0f172a] border-t border-slate-800 px-4 py-2 text-[11px] font-mono text-slate-500 flex flex-wrap items-center justify-between gap-2">
        <div>
          <span className="text-amber-400 font-bold">RHINOQUANT SYNTHETIC BONDS</span> · INSTITUTIONAL FIXED-INCOME ENGINE
        </div>
        <div className="flex items-center gap-4">
          <span>SELECTED BOND: <strong className="text-slate-300">{selectedBond.id}</strong></span>
          <span>CURVE SHIFT: <strong className={rateShiftBp > 0 ? 'text-red-400' : rateShiftBp < 0 ? 'text-emerald-400' : 'text-slate-300'}>{rateShiftBp >= 0 ? `+${rateShiftBp}` : rateShiftBp}bp</strong></span>
          <span>SYSTEM: DETERMINISTIC COMPUTATIONAL ENVIRONMENT</span>
        </div>
      </footer>
    </div>
  );
}
