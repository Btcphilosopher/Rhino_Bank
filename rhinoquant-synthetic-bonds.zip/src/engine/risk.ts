import { SyntheticBond, CashFlow, KeyRateDV01, CreditRiskMetrics } from '../types/bond';
import { generateCashFlowSchedule, getFrequencyFactor } from './cashflows';

export interface CalculatedRiskMetrics {
  macaulayDuration: number;
  modifiedDuration: number;
  effectiveDuration: number;
  convexity: number;
  dv01: number; // per £1m face value
  spreadDv01: number;
  creditDv01: number;
  pv01: number;
}

/**
 * Calculates Duration, Convexity, DV01, and Spread Sensitivities
 */
export function calculateRiskMetrics(
  bond: SyntheticBond,
  dirtyPrice: number,
  ytm: number,
  cashFlows: CashFlow[],
  rateShiftBp: number = 0,
  slopeShiftBp: number = 0
): CalculatedRiskMetrics {
  const m = getFrequencyFactor(bond.frequency);
  let weightedTimeSum = 0;
  let convexitySum = 0;
  const pvSum = dirtyPrice > 0 ? dirtyPrice : 100.0;

  for (const cf of cashFlows) {
    const t = cf.cumulativeYears;
    weightedTimeSum += t * cf.pv;
    convexitySum += t * (t + 1 / m) * cf.pv;
  }

  // Macaulay duration in years
  const macaulayDuration = weightedTimeSum / pvSum;

  // Modified duration = MacDur / (1 + y/m)
  const modifiedDuration = macaulayDuration / (1 + ytm / m);

  // Convexity = ConvexitySum / [PV * (1 + y/m)^2]
  const convexity = convexitySum / (pvSum * Math.pow(1 + ytm / m, 2));

  // Effective Duration via numerical +10bp / -10bp shock
  const deltaBp = 10; // 10 bp
  const cfUp = generateCashFlowSchedule(bond, rateShiftBp + deltaBp, slopeShiftBp);
  const pUp = cfUp.reduce((sum, cf) => sum + cf.pv, 0);

  const cfDown = generateCashFlowSchedule(bond, rateShiftBp - deltaBp, slopeShiftBp);
  const pDown = cfDown.reduce((sum, cf) => sum + cf.pv, 0);

  const dy = deltaBp / 10000;
  const effectiveDuration = (pDown - pUp) / (2 * dirtyPrice * dy);

  // DV01 = Dollar value of 1 basis point per £1m ($1m) face value
  // DV01 = ModifiedDuration * PV * 0.0001 * 10,000 (for £1,000,000 portfolio)
  const dv01 = (modifiedDuration * dirtyPrice / 100.0) * 0.0001 * 1000000;
  const spreadDv01 = dv01 * 0.98; // spread DV01
  const creditDv01 = dv01 * 0.92;
  const pv01 = dv01;

  return {
    macaulayDuration,
    modifiedDuration,
    effectiveDuration,
    convexity,
    dv01,
    spreadDv01,
    creditDv01,
    pv01,
  };
}

/**
 * Key-Rate DV01 Matrix calculation (2Y, 5Y, 10Y, 20Y, 30Y key rate shocks)
 */
export function calculateKeyRateDV01(
  bond: SyntheticBond,
  basePrice: number
): KeyRateDV01 {
  const keyTenors = ['2Y', '5Y', '10Y', '20Y', '30Y'] as const;
  const result: Record<string, number> = {};

  const keyYears = { '2Y': 2, '5Y': 5, '10Y': 10, '20Y': 20, '30Y': 30 };

  for (const tenor of keyTenors) {
    const targetYear = keyYears[tenor];
    const cashFlows = generateCashFlowSchedule(bond);
    let krDv01 = 0;

    for (const cf of cashFlows) {
      const t = cf.cumulativeYears;
      // Triangular key-rate shock weighting centered around targetYear
      const weight = Math.max(0, 1 - Math.abs(t - targetYear) / 5.0);
      krDv01 += weight * cf.pv * t * 0.0001 * 10000; // per £1m
    }

    result[tenor] = krDv01;
  }

  return result as unknown as KeyRateDV01;
}

/**
 * Calculates Credit Risk Survival Probabilities and Expected Loss
 */
export function calculateCreditRiskMetrics(
  rating: string,
  baseSpreadBp: number,
  maturityYears: number,
  recoveryRate: number = 0.40,
  faceValueMln: number = 1.0
): CreditRiskMetrics {
  // Hazard rate lambda approx = Spread / (1 - Recovery)
  const hazardRate = (baseSpreadBp / 10000) / (1 - recoveryRate);

  const survivalProbs: { year: number; probability: number }[] = [];
  const defaultProbs: { year: number; cumulativeDefault: number }[] = [];

  const years = Math.max(1, Math.ceil(maturityYears));
  for (let y = 1; y <= years; y++) {
    const s = Math.exp(-hazardRate * y);
    const d = 1 - s;
    survivalProbs.push({ year: y, probability: s });
    defaultProbs.push({ year: y, cumulativeDefault: d });
  }

  const cumulativeDefaultAtMaturity = 1 - Math.exp(-hazardRate * maturityYears);
  const lossGivenDefaultPercent = (1 - recoveryRate) * 100;
  const expectedLossMln = faceValueMln * cumulativeDefaultAtMaturity * (1 - recoveryRate);

  return {
    hazardRate,
    survivalProbs,
    defaultProbs,
    expectedLossMln,
    exposureAtDefaultMln: faceValueMln,
    lossGivenDefaultPercent,
  };
}
