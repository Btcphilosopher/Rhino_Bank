import { SyntheticBond, SyntheticIssuer, Currency, CreditRating, Sector, BondType, CouponFrequency, DayCountConvention, Seniority } from '../types/bond';
import { SeededPRNG } from './prng';

export const CURRENCIES: Currency[] = ['GBP', 'USD', 'EUR', 'JPY', 'CHF', 'CAD', 'AUD'];

export const SECTORS: Sector[] = [
  'INDUSTRIALS', 'BANKS', 'UTILITIES', 'CHEMICALS', 'ENERGY',
  'TRANSPORT', 'TELECOMMUNICATIONS', 'TECHNOLOGY', 'INFRASTRUCTURE',
  'CONSUMER', 'HEALTHCARE', 'PROPERTY',
];

export const RATINGS: CreditRating[] = [
  'AAA', 'AA+', 'AA', 'AA-', 'A+', 'A', 'A-',
  'BBB+', 'BBB', 'BBB-', 'BB+', 'BB', 'B', 'CCC',
];

const ISSUER_NAME_PREFIXES = [
  'British', 'Global', 'Apex', 'Vanguard', 'Consolidated', 'Imperial',
  'Titan', 'Transatlantic', 'Pinnacle', 'Alliance', 'Omega', 'Meridian',
  'Crown', 'Atlas', 'Quantum', 'Nordic', 'Sterling', 'Pacific', 'Summit',
];

const ISSUER_NAME_SUFFIXES: Record<Sector, string[]> = {
  INDUSTRIALS: ['Industrial Holdings', 'Manufacturing Corp', 'Engineering Group', 'Heavy Industries'],
  BANKS: ['Commercial Bank', 'Credit Group', 'Financial Trust', 'Capital Markets Corp'],
  UTILITIES: ['Power & Light', 'Energy Networks', 'Water Utilities', 'Clean Energy Infrastructure'],
  CHEMICALS: ['Chemicals International', 'Advanced Materials', 'Polymer Sciences'],
  ENERGY: ['Petroleum & Gas', 'Renewable Resources', 'Energy Holdings'],
  TRANSPORT: ['Rail & Freight', 'Aviation Group', 'Logistics Corp', 'Maritime Shipping'],
  TELECOMMUNICATIONS: ['Telecom Networks', 'Communications Corp', 'Mobile Systems'],
  TECHNOLOGY: ['Software Solutions', 'Semiconductor Corp', 'Cloud Technologies'],
  INFRASTRUCTURE: ['Infrastructure Partners', 'Utilities & Roads', 'Capital Projects'],
  CONSUMER: ['Brands International', 'Retail Holdings', 'Consumer Products'],
  HEALTHCARE: ['Pharmaceuticals', 'BioHealth Corp', 'Medical Systems'],
  PROPERTY: ['Real Estate Trust', 'Property Development', 'Commercial REIT'],
};

/**
 * Generates deterministic Synthetic Issuers
 */
export function generateSyntheticIssuers(count: number, seed: number = 42): SyntheticIssuer[] {
  const prng = new SeededPRNG(seed);
  const issuers: SyntheticIssuer[] = [];

  for (let i = 1; i <= count; i++) {
    const sector = prng.pick(SECTORS);
    const currency = prng.pick(CURRENCIES);
    const rating = prng.pick(RATINGS);
    const prefix = prng.pick(ISSUER_NAME_PREFIXES);
    const suffix = prng.pick(ISSUER_NAME_SUFFIXES[sector]);
    const name = `Synthetic ${prefix} ${suffix}`;

    const revenueMln = prng.nextInt(500, 25000);
    const ebitdaMargin = prng.nextFloat(0.12, 0.45);
    const ebitdaMln = Math.round(revenueMln * ebitdaMargin);

    let leverageTarget = 2.0;
    if (rating.startsWith('AAA') || rating.startsWith('AA')) leverageTarget = prng.nextFloat(1.2, 2.5);
    else if (rating.startsWith('A')) leverageTarget = prng.nextFloat(2.2, 3.8);
    else if (rating.startsWith('BBB')) leverageTarget = prng.nextFloat(3.5, 5.2);
    else leverageTarget = prng.nextFloat(5.0, 8.5);

    const debtMln = Math.round(ebitdaMln * leverageTarget);
    const interestRateEst = 0.045;
    const interestExpense = debtMln * interestRateEst;
    const interestCoverageRatio = Number((ebitdaMln / Math.max(1, interestExpense)).toFixed(2));
    const leverageRatio = Number((debtMln / Math.max(1, ebitdaMln)).toFixed(2));

    let defaultProb = 0.0005;
    if (rating.startsWith('AA')) defaultProb = 0.001;
    else if (rating.startsWith('A')) defaultProb = 0.0025;
    else if (rating.startsWith('BBB')) defaultProb = 0.008;
    else if (rating.startsWith('BB')) defaultProb = 0.025;
    else defaultProb = 0.075;

    const recoveryRate = prng.pick([0.35, 0.40, 0.45, 0.50]);
    const baseCreditSpreadBp = prng.nextInt(30, 450);

    issuers.push({
      id: `ISS-${currency}-${String(i).padStart(4, '0')}`,
      name,
      sector,
      country: currency === 'GBP' ? 'UK' : currency === 'USD' ? 'US' : currency === 'EUR' ? 'Germany' : 'Global',
      currency,
      rating,
      revenueMln,
      ebitdaMln,
      debtMln,
      interestCoverageRatio,
      leverageRatio,
      defaultProbability1Y: defaultProb,
      recoveryRate,
      baseCreditSpreadBp,
    });
  }

  return issuers;
}

/**
 * Generates a full deterministic Synthetic Bond Universe
 */
export function generateSyntheticUniverse(
  count: number,
  seed: number = 42
): { issuers: SyntheticIssuer[]; bonds: SyntheticBond[] } {
  const prng = new SeededPRNG(seed);
  const issuerCount = Math.max(10, Math.min(200, Math.round(count / 5)));
  const issuers = generateSyntheticIssuers(issuerCount, seed);

  const bondTypes: BondType[] = ['FIXED', 'FIXED', 'FIXED', 'FLOATING', 'ZERO', 'AMORTISING', 'CALLABLE', 'PUTABLE', 'STEP_UP'];
  const frequencies: CouponFrequency[] = ['SEMI_ANNUAL', 'ANNUAL', 'QUARTERLY'];
  const dayCounts: DayCountConvention[] = ['ACT_ACT', '30_360', 'ACT_360', 'ACT_365'];
  const seniorities: Seniority[] = ['SENIOR_UNSECURED', 'SENIOR_SECURED', 'SUBORDINATED'];

  const bonds: SyntheticBond[] = [];

  for (let i = 1; i <= count; i++) {
    const issuer = prng.pick(issuers);
    const type = prng.pick(bondTypes);
    const frequency = prng.pick(frequencies);
    const dayCount = prng.pick(dayCounts);
    const seniority = prng.pick(seniorities);

    const issueYear = prng.nextInt(2020, 2025);
    const tenorYears = prng.pick([2, 3, 5, 7, 10, 15, 20, 30]);
    const matYear = issueYear + tenorYears;

    const issueDate = `${issueYear}-${String(prng.nextInt(1, 12)).padStart(2, '0')}-15`;
    const maturityDate = `${matYear}-06-15`;

    let baseCoupon = prng.nextFloat(0.02, 0.08);
    if (type === 'ZERO') baseCoupon = 0;
    else if (issuer.rating.startsWith('BB') || issuer.rating.startsWith('CCC')) baseCoupon += 0.025;

    const couponRate = Number(baseCoupon.toFixed(5));
    const issueSizeMln = prng.pick([250, 500, 750, 1000, 1250, 1500, 2000]);
    const marketSpreadBp = Math.round(issuer.baseCreditSpreadBp * prng.nextFloat(0.85, 1.25));
    const liquiditySpreadBp = prng.nextInt(10, 45);

    const isinCode = `GB${prng.nextInt(100000000, 999999999)}RQ`;
    const codeName = `RQ-${issuer.country}-${issuer.sector.slice(0, 4)}-${matYear}-${String(i).padStart(3, '0')}`;

    bonds.push({
      id: codeName,
      isin: isinCode,
      name: `${issuer.name} ${Number((couponRate * 100).toFixed(3))}% ${matYear}`,
      issuerId: issuer.id,
      issuerName: issuer.name,
      sector: issuer.sector,
      currency: issuer.currency,
      issueDate,
      maturityDate,
      couponRate,
      frequency,
      dayCount,
      type,
      seniority,
      rating: issuer.rating,
      issueSizeMln,
      marketSpreadBp,
      liquiditySpreadBp,
      callPrice: type === 'CALLABLE' ? 102.0 : undefined,
      callDate: type === 'CALLABLE' ? `${issueYear + Math.round(tenorYears / 2)}-06-15` : undefined,
    });
  }

  return { issuers, bonds };
}

/**
 * Pre-built flagship benchmark bond used in core example
 */
export const EXAMPLE_FLAGSHIP_BOND: SyntheticBond = {
  id: 'RQ-UK-CORP-2034-017',
  isin: 'GB00B1234567RQ',
  name: 'Synthetic British Industrial Holdings 4.625% 2034',
  issuerId: 'ISS-GBP-0001',
  issuerName: 'Synthetic British Industrial Holdings',
  sector: 'INDUSTRIALS',
  currency: 'GBP',
  issueDate: '2024-06-15',
  maturityDate: '2034-06-15',
  couponRate: 0.04625,
  frequency: 'SEMI_ANNUAL',
  dayCount: 'ACT_ACT',
  type: 'FIXED',
  seniority: 'SENIOR_UNSECURED',
  rating: 'A-',
  issueSizeMln: 750,
  marketSpreadBp: 137,
  liquiditySpreadBp: 22,
};
