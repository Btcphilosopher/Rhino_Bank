import { SyntheticBond, StressScenario, ScenarioResult, ScenarioType } from '../types/bond';
import { priceBond } from './pricing';

export const PREBUILT_SCENARIOS: StressScenario[] = [
  {
    id: 'PARALLEL_UP_100',
    name: 'Parallel Rate +100 bp',
    description: 'Bearish yield curve shift of +100 bps across all maturities.',
    rateShiftBp: 100,
    slopeShiftBp: 0,
    creditSpreadShiftBp: 0,
    liquiditySpreadShiftBp: 0,
  },
  {
    id: 'PARALLEL_DOWN_100',
    name: 'Parallel Rate -100 bp',
    description: 'Bullish yield curve shift of -100 bps across all maturities.',
    rateShiftBp: -100,
    slopeShiftBp: 0,
    creditSpreadShiftBp: 0,
    liquiditySpreadShiftBp: 0,
  },
  {
    id: 'STEEPENING',
    name: 'Curve Steepening (+50 bp 30Y / -20 bp 2Y)',
    description: 'Yield curve steepening with long end rates rising faster than short end.',
    rateShiftBp: 15,
    slopeShiftBp: 70,
    creditSpreadShiftBp: 0,
    liquiditySpreadShiftBp: 0,
  },
  {
    id: 'FLATTENING',
    name: 'Curve Flattening (+40 bp 2Y / -10 bp 30Y)',
    description: 'Yield curve flattening or inversion driven by monetary policy tightening.',
    rateShiftBp: 15,
    slopeShiftBp: -50,
    creditSpreadShiftBp: 0,
    liquiditySpreadShiftBp: 0,
  },
  {
    id: 'CREDIT_WIDENING',
    name: 'Credit Spread Widening (+150 bp)',
    description: 'Broad credit market deterioration causing credit risk premia to blow out.',
    rateShiftBp: 0,
    slopeShiftBp: 0,
    creditSpreadShiftBp: 150,
    liquiditySpreadShiftBp: 20,
  },
  {
    id: 'CREDIT_TIGHTENING',
    name: 'Credit Spread Tightening (-40 bp)',
    description: 'Economic recovery leading to credit risk compression and spread rally.',
    rateShiftBp: 0,
    slopeShiftBp: 0,
    creditSpreadShiftBp: -40,
    liquiditySpreadShiftBp: -10,
  },
  {
    id: 'LIQUIDITY_SHOCK',
    name: 'Liquidity Crunch (+60 bp Liquidity)',
    description: 'Secondary market inventory drain and dealer pull-back causing wide bid-ask.',
    rateShiftBp: 10,
    slopeShiftBp: 0,
    creditSpreadShiftBp: 25,
    liquiditySpreadShiftBp: 60,
  },
  {
    id: 'RECESSION',
    name: 'Macro Recession (-75 bp Rate / +200 bp Credit)',
    description: 'Central bank rate cuts accompanied by corporate credit rating downgrades.',
    rateShiftBp: -75,
    slopeShiftBp: -20,
    creditSpreadShiftBp: 200,
    liquiditySpreadShiftBp: 45,
  },
  {
    id: 'INFLATION_SHOCK',
    name: 'Stagflation Shock (+175 bp Rate / +100 bp Credit)',
    description: 'Persistent inflation spike driving aggressive rate hikes and corporate margin squeeze.',
    rateShiftBp: 175,
    slopeShiftBp: 35,
    creditSpreadShiftBp: 100,
    liquiditySpreadShiftBp: 30,
  },
];

export function runScenario(
  bond: SyntheticBond,
  scenario: StressScenario,
  faceValueMln: number = 10.0
): ScenarioResult {
  const baseVal = priceBond(bond, 0, 0, 0, 0);
  const stressedVal = priceBond(
    bond,
    scenario.rateShiftBp,
    scenario.slopeShiftBp,
    scenario.creditSpreadShiftBp,
    scenario.liquiditySpreadShiftBp
  );

  const originalValueMln = (baseVal.dirtyPrice / 100.0) * faceValueMln;
  const stressedValueMln = (stressedVal.dirtyPrice / 100.0) * faceValueMln;

  const pnlMln = stressedValueMln - originalValueMln;
  const pnlPercent = (pnlMln / originalValueMln) * 100;

  // Taylor expansion P&L decomposition:
  // dP/P ~ -D_mod * dy + 0.5 * C * (dy)^2 - D_spread * ds
  const dy = scenario.rateShiftBp / 10000;
  const ds = scenario.creditSpreadShiftBp / 10000;
  const dl = scenario.liquiditySpreadShiftBp / 10000;

  const rateEffectMln = -baseVal.modifiedDuration * dy * originalValueMln;
  const convexityEffectMln = 0.5 * baseVal.convexity * Math.pow(dy, 2) * originalValueMln;
  const spreadEffectMln = -baseVal.modifiedDuration * ds * originalValueMln;
  const liquidityEffectMln = -dl * originalValueMln;

  const sumDecomp = rateEffectMln + convexityEffectMln + spreadEffectMln + liquidityEffectMln;
  const residualMln = pnlMln - sumDecomp;

  return {
    scenario,
    originalValueMln,
    stressedValueMln,
    pnlMln,
    pnlPercent,
    decomposition: {
      rateEffectMln,
      spreadEffectMln,
      convexityEffectMln,
      liquidityEffectMln,
      residualMln,
    },
  };
}
