import { SyntheticBond, CashFlow, CouponFrequency, DayCountConvention } from '../types/bond';
import { getDiscountFactorAndYield } from './curves';

export function getFrequencyFactor(freq: CouponFrequency): number {
  switch (freq) {
    case 'ANNUAL': return 1;
    case 'SEMI_ANNUAL': return 2;
    case 'QUARTERLY': return 4;
    case 'MONTHLY': return 12;
    default: return 2;
  }
}

export function parseDate(dateStr: string): Date {
  return new Date(dateStr);
}

export function formatDate(date: Date): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${dd}/${mm}/${yyyy}`;
}

export function calculateYearFraction(
  startDate: Date,
  endDate: Date,
  convention: DayCountConvention
): number {
  const diffMs = endDate.getTime() - startDate.getTime();
  const diffDays = diffMs / (1000 * 60 * 60 * 24);

  switch (convention) {
    case 'ACT_ACT':
    case 'ACT_365':
      return diffDays / 365.25;
    case 'ACT_360':
      return diffDays / 360;
    case '30_360': {
      const d1 = Math.min(startDate.getDate(), 30);
      const d2 = startDate.getDate() === 31 && d1 >= 30 ? 30 : endDate.getDate();
      const m1 = startDate.getMonth() + 1;
      const m2 = endDate.getMonth() + 1;
      const y1 = startDate.getFullYear();
      const y2 = endDate.getFullYear();
      return (360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1)) / 360;
    }
    default:
      return diffDays / 365.25;
  }
}

/**
 * Generates exact cash flow payment schedule for any synthetic bond
 */
export function generateCashFlowSchedule(
  bond: SyntheticBond,
  rateShiftBp: number = 0,
  slopeShiftBp: number = 0,
  creditShiftBp: number = 0,
  liquidityShiftBp: number = 0
): CashFlow[] {
  const issueDt = parseDate(bond.issueDate);
  const matDt = parseDate(bond.maturityDate);
  const m = getFrequencyFactor(bond.frequency);

  const totalYears = Math.max(0.25, calculateYearFraction(issueDt, matDt, bond.dayCount));
  const numPeriods = Math.max(1, Math.round(totalYears * m));

  const cashFlows: CashFlow[] = [];
  let remainingPrincipal = 100.0; // Normalized to 100 par
  let prevDate = new Date(issueDt);

  const amortisationPerPeriod = bond.type === 'AMORTISING' || bond.type === 'SINKING_FUND'
    ? (100.0 / numPeriods)
    : 0;

  for (let period = 1; period <= numPeriods; period++) {
    // Calculate current payment date
    const currentDate = new Date(issueDt);
    const monthsToAdd = Math.round((period * 12) / m);
    currentDate.setMonth(currentDate.getMonth() + monthsToAdd);

    const periodYearFraction = calculateYearFraction(prevDate, currentDate, bond.dayCount);
    const cumulativeYears = calculateYearFraction(issueDt, currentDate, bond.dayCount);

    // Coupon rate adjustment (e.g. step-up coupons or floating)
    let currentCouponRate = bond.couponRate;
    if (bond.type === 'STEP_UP' && bond.stepUpRates && bond.stepUpRates.length > 0) {
      const step = bond.stepUpRates.find((s) => cumulativeYears >= s.year);
      if (step) currentCouponRate = step.rate;
    } else if (bond.type === 'ZERO') {
      currentCouponRate = 0;
    }

    const couponPayment = (remainingPrincipal * currentCouponRate * periodYearFraction);

    let principalPayment = 0;
    if (period === numPeriods) {
      principalPayment = remainingPrincipal; // Pay remaining par at maturity
    } else if (amortisationPerPeriod > 0) {
      principalPayment = Math.min(remainingPrincipal, amortisationPerPeriod);
    }

    const totalCashFlow = couponPayment + principalPayment;

    // Get discount factor from zero rate curve + credit spread + liquidity spread + shifts
    const { discountFactor } = getDiscountFactorAndYield(
      cumulativeYears,
      bond.currency,
      bond.rating,
      bond.sector,
      bond.marketSpreadBp + bond.liquiditySpreadBp + creditShiftBp + liquidityShiftBp,
      rateShiftBp,
      slopeShiftBp
    );

    const pv = totalCashFlow * discountFactor;

    cashFlows.push({
      period,
      date: formatDate(currentDate),
      yearFraction: periodYearFraction,
      cumulativeYears,
      couponPayment,
      principalPayment,
      totalCashFlow,
      discountFactor,
      pv,
    });

    remainingPrincipal = Math.max(0, remainingPrincipal - principalPayment);
    prevDate = currentDate;
  }

  return cashFlows;
}
