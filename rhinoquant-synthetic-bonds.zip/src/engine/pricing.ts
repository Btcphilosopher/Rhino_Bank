import { SyntheticBond, ValuationResult } from '../types/bond';
import { generateCashFlowSchedule, getFrequencyFactor, parseDate, calculateYearFraction } from './cashflows';
import { calculateRiskMetrics } from './risk';

/**
 * Calculates Present Value of cash flows given a flat discount yield rate
 */
export function calculatePVFromYield(
  bond: SyntheticBond,
  ytm: number
): number {
  const cashFlows = generateCashFlowSchedule(bond);
  const m = getFrequencyFactor(bond.frequency);
  let pv = 0;

  for (const cf of cashFlows) {
    const df = Math.pow(1 + ytm / m, -cf.cumulativeYears * m);
    pv += cf.totalCashFlow * df;
  }
  return pv;
}

/**
 * High-precision Newton-Raphson & Bisection YTM Solver
 */
export function solveYTM(bond: SyntheticBond, targetDirtyPrice: number): number {
  let ytm = bond.couponRate || 0.04; // initial guess
  const m = getFrequencyFactor(bond.frequency);
  const cashFlows = generateCashFlowSchedule(bond);

  // Newton-Raphson loop
  for (let iter = 0; iter < 100; iter++) {
    let p = 0;
    let dp = 0;

    for (const cf of cashFlows) {
      const t = cf.cumulativeYears;
      const df = Math.pow(1 + ytm / m, -t * m);
      p += cf.totalCashFlow * df;
      dp += -t * cf.totalCashFlow * Math.pow(1 + ytm / m, -t * m - 1);
    }

    const diff = p - targetDirtyPrice;
    if (Math.abs(diff) < 1e-7) {
      return ytm;
    }

    if (Math.abs(dp) < 1e-10) break; // avoid divide by zero
    ytm = ytm - diff / dp;

    if (ytm < -0.5 || ytm > 2.0) {
      // Fallback to Bisection if Newton diverges
      break;
    }
  }

  // Bisection fallback
  let low = -0.1;
  let high = 1.0;
  for (let i = 0; i < 60; i++) {
    const mid = (low + high) / 2;
    const pMid = calculatePVFromYield(bond, mid);
    if (Math.abs(pMid - targetDirtyPrice) < 1e-6) return mid;
    if (pMid > targetDirtyPrice) {
      low = mid;
    } else {
      high = mid;
    }
  }
  return (low + high) / 2;
}

/**
 * Solves Z-Spread (constant basis point shift over zero curve that equates PV to target dirty price)
 */
export function solveZSpreadBp(
  bond: SyntheticBond,
  targetDirtyPrice: number,
  rateShiftBp: number = 0,
  slopeShiftBp: number = 0
): number {
  let lowBp = -500;
  let highBp = 3000;

  for (let i = 0; i < 50; i++) {
    const midBp = (lowBp + highBp) / 2;
    const cashFlows = generateCashFlowSchedule(bond, rateShiftBp, slopeShiftBp, midBp, 0);
    const pv = cashFlows.reduce((sum, cf) => sum + cf.pv, 0);

    if (Math.abs(pv - targetDirtyPrice) < 1e-5) return midBp;
    if (pv > targetDirtyPrice) {
      lowBp = midBp;
    } else {
      highBp = midBp;
    }
  }
  return (lowBp + highBp) / 2;
}

/**
 * Full Synthetic Bond Valuation Engine
 */
export function priceBond(
  bond: SyntheticBond,
  rateShiftBp: number = 0,
  slopeShiftBp: number = 0,
  creditShiftBp: number = 0,
  liquidityShiftBp: number = 0
): ValuationResult {
  const cashFlows = generateCashFlowSchedule(bond, rateShiftBp, slopeShiftBp, creditShiftBp, liquidityShiftBp);
  
  const dirtyPrice = cashFlows.reduce((sum, cf) => sum + cf.pv, 0); // % of par, e.g. 98.45
  
  // Accrued interest calculation
  const issueDt = parseDate(bond.issueDate);
  const now = new Date();
  const yearFractionSinceStart = calculateYearFraction(issueDt, now, bond.dayCount);
  const m = getFrequencyFactor(bond.frequency);
  const periodLength = 1.0 / m;
  const accruedFraction = (yearFractionSinceStart % periodLength);
  const accruedInterest = bond.couponRate * accruedFraction * 100.0;

  const cleanPrice = Math.max(0, dirtyPrice - accruedInterest);
  
  // Numerical YTM
  const ytm = solveYTM(bond, dirtyPrice);
  
  // Current yield = (Annual Coupon / Clean Price) * 100
  const currentYield = cleanPrice > 0 ? (bond.couponRate * 100) / cleanPrice : 0;

  // Yield to call if callable
  let yieldToCall: number | undefined = undefined;
  if (bond.type === 'CALLABLE' && bond.callDate && bond.callPrice) {
    const callDt = parseDate(bond.callDate);
    const callYears = calculateYearFraction(issueDt, callDt, bond.dayCount);
    // Yield to call approximation
    yieldToCall = ytm * 0.95 + (bond.callPrice > 100 ? -0.003 : 0.003);
  }

  const yieldToWorst = yieldToCall ? Math.min(ytm, yieldToCall) : ytm;

  // Calculate Duration, Convexity, DV01 & Credit Risk Metrics
  const risk = calculateRiskMetrics(bond, dirtyPrice, ytm, cashFlows, rateShiftBp, slopeShiftBp);

  // Liquidity penalty model
  const liquidityPenaltyBp = bond.liquiditySpreadBp + (bond.issueSizeMln < 500 ? 15 : 0) + (bond.type !== 'FIXED' ? 10 : 0);
  const theoreticalPrice = dirtyPrice;
  const executablePrice = dirtyPrice * (1.0 - liquidityPenaltyBp / 10000);

  const zSpreadBp = solveZSpreadBp(bond, dirtyPrice, rateShiftBp, slopeShiftBp);
  const oasBp = (bond.type === 'CALLABLE' || bond.type === 'PUTABLE' || bond.type === 'CONVERTIBLE')
    ? Math.max(0, zSpreadBp - 24) // Option value deduction
    : zSpreadBp;

  return {
    bondId: bond.id,
    dirtyPrice,
    cleanPrice,
    accruedInterest,
    yieldToMaturity: ytm,
    currentYield,
    yieldToCall,
    yieldToWorst,
    macaulayDuration: risk.macaulayDuration,
    modifiedDuration: risk.modifiedDuration,
    effectiveDuration: risk.effectiveDuration,
    convexity: risk.convexity,
    dv01: risk.dv01,
    spreadDv01: risk.spreadDv01,
    creditDv01: risk.creditDv01,
    pv01: risk.pv01,
    zSpreadBp,
    oasBp,
    liquidityPenaltyBp,
    theoreticalPrice,
    executablePrice,
    cashFlows,
    totalCashFlowSum: cashFlows.reduce((sum, cf) => sum + cf.totalCashFlow, 0),
    totalPV: dirtyPrice,
  };
}
