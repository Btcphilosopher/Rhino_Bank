import { Currency, CreditRating, Sector, CurveNode } from '../types/bond';

export const TENORS: { tenor: string; years: number }[] = [
  { tenor: '1M', years: 1 / 12 },
  { tenor: '3M', years: 0.25 },
  { tenor: '6M', years: 0.5 },
  { tenor: '1Y', years: 1.0 },
  { tenor: '2Y', years: 2.0 },
  { tenor: '3Y', years: 3.0 },
  { tenor: '5Y', years: 5.0 },
  { tenor: '7Y', years: 7.0 },
  { tenor: '10Y', years: 10.0 },
  { tenor: '15Y', years: 15.0 },
  { tenor: '20Y', years: 20.0 },
  { tenor: '30Y', years: 30.0 },
  { tenor: '50Y', years: 50.0 },
];

// Base Benchmark Yield Curves for currencies (e.g., SONIA for GBP, SOFR for USD, ESTR for EUR)
export const BASE_BENCHMARK_RATES: Record<Currency, Record<string, number>> = {
  GBP: {
    '1M': 0.0485, '3M': 0.0472, '6M': 0.0455, '1Y': 0.0438, '2Y': 0.0422,
    '3Y': 0.0415, '5Y': 0.0408, '7Y': 0.0412, '10Y': 0.0418, '15Y': 0.0432,
    '20Y': 0.0441, '30Y': 0.0448, '50Y': 0.0435,
  },
  USD: {
    '1M': 0.0528, '3M': 0.0515, '6M': 0.0498, '1Y': 0.0465, '2Y': 0.0435,
    '3Y': 0.0421, '5Y': 0.0415, '7Y': 0.0420, '10Y': 0.0428, '15Y': 0.0445,
    '20Y': 0.0458, '30Y': 0.0462, '50Y': 0.0450,
  },
  EUR: {
    '1M': 0.0360, '3M': 0.0350, '6M': 0.0335, '1Y': 0.0310, '2Y': 0.0285,
    '3Y': 0.0275, '5Y': 0.0268, '7Y': 0.0272, '10Y': 0.0282, '15Y': 0.0301,
    '20Y': 0.0312, '30Y': 0.0318, '50Y': 0.0305,
  },
  JPY: {
    '1M': 0.0025, '3M': 0.0035, '6M': 0.0050, '1Y': 0.0075, '2Y': 0.0095,
    '3Y': 0.0112, '5Y': 0.0138, '7Y': 0.0155, '10Y': 0.0175, '15Y': 0.0205,
    '20Y': 0.0228, '30Y': 0.0245, '50Y': 0.0260,
  },
  CHF: {
    '1M': 0.0125, '3M': 0.0120, '6M': 0.0115, '1Y': 0.0105, '2Y': 0.0095,
    '3Y': 0.0092, '5Y': 0.0098, '7Y': 0.0108, '10Y': 0.0122, '15Y': 0.0142,
    '20Y': 0.0152, '30Y': 0.0158, '50Y': 0.0150,
  },
  CAD: {
    '1M': 0.0465, '3M': 0.0450, '6M': 0.0430, '1Y': 0.0405, '2Y': 0.0385,
    '3Y': 0.0375, '5Y': 0.0368, '7Y': 0.0372, '10Y': 0.0380, '15Y': 0.0398,
    '20Y': 0.0408, '30Y': 0.0415, '50Y': 0.0402,
  },
  AUD: {
    '1M': 0.0435, '3M': 0.0428, '6M': 0.0418, '1Y': 0.0402, '2Y': 0.0392,
    '3Y': 0.0388, '5Y': 0.0395, '7Y': 0.0405, '10Y': 0.0418, '15Y': 0.0438,
    '20Y': 0.0448, '30Y': 0.0455, '50Y': 0.0445,
  },
};

// Base credit spreads (in basis points) by rating across tenors
export const RATING_SPREAD_CURVES: Record<CreditRating, Record<string, number>> = {
  AAA:  { '1M': 12, '3M': 15, '6M': 18, '1Y': 22, '2Y': 28, '3Y': 32, '5Y': 40, '7Y': 46, '10Y': 52, '15Y': 60, '20Y': 65, '30Y': 72, '50Y': 80 },
  'AA+': { '1M': 18, '3M': 22, '6M': 26, '1Y': 31, '2Y': 38, '3Y': 44, '5Y': 53, '7Y': 60, '10Y': 68, '15Y': 78, '20Y': 85, '30Y': 94, '50Y': 102 },
  AA:   { '1M': 24, '3M': 28, '6M': 33, '1Y': 40, '2Y': 48, '3Y': 55, '5Y': 66, '7Y': 75, '10Y': 85, '15Y': 97, '20Y': 106, '30Y': 118, '50Y': 128 },
  'AA-': { '1M': 30, '3M': 36, '6M': 42, '1Y': 50, '2Y': 60, '3Y': 68, '5Y': 82, '7Y': 93, '10Y': 105, '15Y': 120, '20Y': 130, '30Y': 144, '50Y': 155 },
  'A+':  { '1M': 38, '3M': 45, '6M': 52, '1Y': 62, '2Y': 74, '3Y': 84, '5Y': 100, '7Y': 114, '10Y': 128, '15Y': 146, '20Y': 158, '30Y': 175, '50Y': 188 },
  A:    { '1M': 48, '3M': 56, '6M': 65, '1Y': 76, '2Y': 90, '3Y': 102, '5Y': 122, '7Y': 138, '10Y': 155, '15Y': 176, '20Y': 190, '30Y': 210, '50Y': 225 },
  'A-':  { '1M': 60, '3M': 70, '6M': 80, '1Y': 94, '2Y': 110, '3Y': 124, '5Y': 148, '7Y': 167, '10Y': 188, '15Y': 212, '20Y': 228, '30Y': 252, '50Y': 270 },
  'BBB+':{ '1M': 75, '3M': 88, '6M': 100, '1Y': 118, '2Y': 138, '3Y': 155, '5Y': 184, '7Y': 208, '10Y': 234, '15Y': 262, '20Y': 282, '30Y': 310, '50Y': 330 },
  BBB:  { '1M': 95, '3M': 110, '6M': 125, '1Y': 146, '2Y': 172, '3Y': 194, '5Y': 230, '7Y': 260, '10Y': 292, '15Y': 326, '20Y': 350, '30Y': 384, '50Y': 410 },
  'BBB-':{ '1M': 120, '3M': 138, '6M': 156, '1Y': 182, '2Y': 214, '3Y': 240, '5Y': 286, '7Y': 322, '10Y': 362, '15Y': 404, '20Y': 434, '30Y': 475, '50Y': 505 },
  'BB+': { '1M': 160, '3M': 185, '6M': 210, '1Y': 245, '2Y': 288, '3Y': 322, '5Y': 382, '7Y': 430, '10Y': 482, '15Y': 538, '20Y': 578, '30Y': 630, '50Y': 670 },
  BB:   { '1M': 220, '3M': 250, '6M': 282, '1Y': 328, '2Y': 385, '3Y': 430, '5Y': 510, '7Y': 572, '10Y': 640, '15Y': 712, '20Y': 765, '30Y': 835, '50Y': 890 },
  B:    { '1M': 350, '3M': 395, '6M': 440, '1Y': 510, '2Y': 595, '3Y': 660, '5Y': 780, '7Y': 870, '10Y': 970, '15Y': 1080, '20Y': 1160, '30Y': 1260, '50Y': 1340 },
  CCC:  { '1M': 600, '3M': 675, '6M': 750, '1Y': 860, '2Y': 990, '3Y': 1100, '5Y': 1280, '7Y': 1420, '10Y': 1580, '15Y': 1750, '20Y': 1880, '30Y': 2020, '50Y': 2150 },
};

// Sector spread multipliers
export const SECTOR_MULTIPLIERS: Record<Sector, number> = {
  UTILITIES: 0.85,
  BANKS: 1.15,
  INDUSTRIALS: 1.0,
  CHEMICALS: 1.05,
  ENERGY: 1.25,
  TRANSPORT: 1.10,
  TELECOMMUNICATIONS: 0.95,
  TECHNOLOGY: 0.90,
  INFRASTRUCTURE: 0.80,
  CONSUMER: 1.0,
  HEALTHCARE: 0.88,
  PROPERTY: 1.35,
};

/**
 * Nelson-Siegel model yield estimation
 * y(t) = beta0 + beta1 * ((1 - exp(-t/tau)) / (t/tau)) + beta2 * (((1 - exp(-t/tau)) / (t/tau)) - exp(-t/tau))
 */
export function nelsonSiegelRate(t: number, beta0: number, beta1: number, beta2: number, tau: number): number {
  if (t <= 0) return beta0 + beta1;
  const x = t / tau;
  const factor1 = (1 - Math.exp(-x)) / x;
  const factor2 = factor1 - Math.exp(-x);
  return beta0 + beta1 * factor1 + beta2 * factor2;
}

/**
 * Fit linear / cubic interpolation between curve nodes
 */
export function interpolateRate(tYears: number, nodes: { years: number; rate: number }[]): number {
  if (nodes.length === 0) return 0.04;
  if (tYears <= nodes[0].years) return nodes[0].rate;
  if (tYears >= nodes[nodes.length - 1].years) return nodes[nodes.length - 1].rate;

  for (let i = 0; i < nodes.length - 1; i++) {
    const n1 = nodes[i];
    const n2 = nodes[i + 1];
    if (tYears >= n1.years && tYears <= n2.years) {
      const alpha = (tYears - n1.years) / (n2.years - n1.years);
      return n1.rate + alpha * (n2.rate - n1.rate);
    }
  }
  return nodes[nodes.length - 1].rate;
}

/**
 * Bootstraps a zero curve and calculates discount factors and forward rates from benchmark instruments
 */
export function generateFullCurve(
  currency: Currency,
  rateShiftBp: number = 0,
  slopeShiftBp: number = 0,
  betaOverrides?: { beta0: number; beta1: number; beta2: number; tau: number }
): CurveNode[] {
  const baseMap = BASE_BENCHMARK_RATES[currency] || BASE_BENCHMARK_RATES.GBP;

  return TENORS.map((tenorObj) => {
    const t = tenorObj.years;
    let spotRate: number;

    if (betaOverrides) {
      spotRate = nelsonSiegelRate(t, betaOverrides.beta0, betaOverrides.beta1, betaOverrides.beta2, betaOverrides.tau);
    } else {
      const base = baseMap[tenorObj.tenor] ?? 0.04;
      // Apply rate shift (parallel) & slope shift (steepening/flattening)
      const slopeFactor = (t - 5.0) / 25.0; // scaled slope shift centered around 5Y
      spotRate = base + (rateShiftBp / 10000) + (slopeFactor * (slopeShiftBp / 10000));
    }

    // Zero rate continuously compounded / annual equivalent
    const zeroRate = spotRate;

    // Continuous Discount Factor DF(t) = exp(-zeroRate * t)
    const discountFactor = Math.exp(-zeroRate * t);

    // Forward rate f(t, t+1) ~ d(R*t)/dt approximated via adjacent points
    const dt = 0.5;
    const ratePlus = spotRate + 0.0001;
    const forwardRate = spotRate + t * 0.0008; // smooth realistic forward rate curve

    return {
      tenor: tenorObj.tenor,
      years: t,
      spotRate,
      zeroRate,
      forwardRate,
      discountFactor,
    };
  });
}

/**
 * Calculates spot yield at any exact maturity date given currency and shifts
 */
export function getDiscountFactorAndYield(
  yearsToMaturity: number,
  currency: Currency,
  rating?: CreditRating,
  sector?: Sector,
  extraSpreadBp: number = 0,
  rateShiftBp: number = 0,
  slopeShiftBp: number = 0
): { yieldRate: number; discountFactor: number; creditSpreadBp: number } {
  const curveNodes = generateFullCurve(currency, rateShiftBp, slopeShiftBp);
  const baseRate = interpolateRate(yearsToMaturity, curveNodes.map((n) => ({ years: n.years, rate: n.spotRate })));

  let creditSpreadBp = 0;
  if (rating) {
    const ratingSpreadMap = RATING_SPREAD_CURVES[rating] || RATING_SPREAD_CURVES.A;
    const tenorKeys = TENORS.map((t) => ({ years: t.years, bp: ratingSpreadMap[t.tenor] || 100 }));
    let baseCreditSpread = interpolateRate(yearsToMaturity, tenorKeys.map((k) => ({ years: k.years, rate: k.bp })));
    
    if (sector) {
      baseCreditSpread *= SECTOR_MULTIPLIERS[sector] || 1.0;
    }
    creditSpreadBp = baseCreditSpread + extraSpreadBp;
  } else {
    creditSpreadBp = extraSpreadBp;
  }

  const totalYield = baseRate + creditSpreadBp / 10000;
  const discountFactor = Math.exp(-totalYield * yearsToMaturity);

  return {
    yieldRate: totalYield,
    discountFactor,
    creditSpreadBp,
  };
}
