import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json({ limit: '10mb' }));

const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// API endpoint for Quant AI Research Assistant
app.post('/api/gemini/research', async (req, res) => {
  try {
    const { prompt, bondContext, scenarioContext } = req.body;

    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API key not configured in environment. AI Assistant running in offline math mode.',
      });
    }

    const systemInstruction = `You are RhinoQuant Fixed Income AI Copilot, a senior Quantitative Fixed Income Strategist.
Your goal is to explain fixed income mechanics, bond pricing, yield curves, cash flows, duration, convexity, key-rate DV01, credit spreads, and stress testing.
Provide crisp, mathematically precise, institutional-grade responses with clear bullet points.
Never hallucinate numbers—use the provided context data when given.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `Context Data:\n${JSON.stringify({ bondContext, scenarioContext }, null, 2)}\n\nUser Question:\n${prompt}`,
            },
          ],
        },
      ],
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    return res.json({ response: response.text });
  } catch (err: any) {
    console.error('Gemini API error:', err);
    return res.status(500).json({ error: err?.message || 'Failed to call Gemini API' });
  }
});

async function startServer() {
  const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
