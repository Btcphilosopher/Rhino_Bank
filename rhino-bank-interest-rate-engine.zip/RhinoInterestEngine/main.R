# ==============================================================================
# Rhino Bank - Interest Rate Engine (R) Demonstration Script
# Production-ready savings interest calculations, simulations and reports.
# ==============================================================================

# Ensure libraries are loaded
library(yaml)
library(jsonlite)

# Source all engine components
source("R/utilities.R")
source("R/validation.R")
source("R/simple_interest.R")
source("R/compound_interest.R")
source("R/rate_tables.R")
source("R/promotions.R")
source("R/taxation.R")
source("R/accounts.R")
source("R/interest_engine.R")
source("R/reporting.R")
source("R/simulation.R")
source("R/forecasting.R")

cat("======================================================================\n")
cat("      RHINO BANK INTEREST RATE ENGINE (R) SYSTEM STARTING              \n")
cat("======================================================================\n\n")

# 1. Load configuration and portfolio rules
cat("[1/6] Loading interest rate rules from YAML configuration...\n")
rules <- yaml::read_yaml("config/interest_rules.yaml")
cat("Successfully loaded rules for", length(rules$products), "products.\n\n")

# 2. Parse mock database accounts from CSV
cat("[2/6] Reading default accounts portfolio from CSV...\n")
accounts_df <- read.csv("data/accounts.csv", stringsAsFactors = FALSE)
cat("Loaded", nrow(accounts_df), "accounts from storage.\n\n")

# 3. Instantiate an OO R6 Account Model for CUST-001
cat("[3/6] Initializing R6 Account Object for CUST-001 (ACC-1001)...\n")
cust_row <- accounts_df[accounts_df$customer_id == "CUST-001", ]

account_01 <- Account$new(
  customer_id       = cust_row$customer_id,
  account_number    = cust_row$account_number,
  product_type      = cust_row$product_type,
  opening_date      = cust_row$opening_date,
  current_balance   = cust_row$current_balance,
  interest_rate     = cust_row$interest_rate,
  interest_method   = cust_row$interest_method,
  compound_frequency = cust_row$compound_frequency,
  tax_status        = cust_row$tax_status,
  currency          = cust_row$currency
)

cat("Account ACC-1001 successfully initialized in active state.\n")
cat("Initial Balance: ", account_01$currency, account_01$current_balance, "\n\n")

# 4. Post manual transaction updates
cat("[4/6] Simulating real-time customer transaction ledger events...\n")
tx1 <- account_01$post_transaction("deposit", 2500.00, "Quarterly salary bonus credit")
cat("Posted Deposit: +2,500.00 (TxRef:", tx1, "). New Balance:", account_01$current_balance, "\n")

tx2 <- account_01$post_transaction("withdrawal", 450.50, "Direct debit insurance payment")
cat("Posted Withdrawal: -450.50 (TxRef:", tx2, "). New Balance:", account_01$current_balance, "\n\n")

# 5. Core Interest Calculation Execution
cat("[5/6] Invoking the interest engine for monthly period accruals...\n")
start_period <- "2025-01-15"
end_period   <- "2025-02-15" # One month accrual

interest_audit <- calculate_interest(
  opening_balance = cust_row$current_balance,
  current_balance = account_01$current_balance,
  interest_rate   = account_01$interest_rate,
  start_date      = start_period,
  end_date        = end_period,
  compounding_rule = account_01$compound_frequency,
  account_type    = account_01$product_type,
  basis           = "ACT/365",
  tax_status      = account_01$tax_status
)

cat("Calculation completed with ID: ", interest_audit$calculation_id, "\n")
cat("Gross Interest Accrued : ", interest_audit$outputs$gross_interest, "\n")
cat("Withholding Tax (20%)  : ", interest_audit$outputs$tax_withheld, "\n")
cat("Net Interest Credited  : ", interest_audit$outputs$net_interest, "\n\n")

# 6. Generate Compliance Customer Statement Report
cat("[6/6] Compiling customer statement audit sheet...\n")
stmt <- generate_customer_statement(account_01, interest_audit)

# Credit the net interest to the account
account_01$post_transaction("interest_credit", interest_audit$outputs$net_interest, "Monthly net interest credit")
cat("Final Account balance updated to: ", account_01$currency, account_01$current_balance, "\n\n")

cat("======================================================================\n")
cat("      RHINO BANK INTEREST RATE ENGINE DEMO RUN COMPLETED SUCCESSFULLY \n")
cat("======================================================================\n")
