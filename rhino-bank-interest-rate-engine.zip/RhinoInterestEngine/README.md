# Rhino Bank Interest Rate Engine (R)

An enterprise-grade, compliance-ready savings interest calculation, simulation, and forecasting system written in **R**. Specifically designed to run calculations, scenario stress tests, and portfolio summaries for a modern micro-bank.

---

## Directory Structure

```
/RhinoInterestEngine
├── config/
│   └── interest_rules.yaml      # Configurable interest rates, compounding, limits, and fees
├── data/
│   └── accounts.csv             # Demo database portfolio representing multiple accounts
├── R/
│   ├── accounts.R               # OO R6 Account class encapsulates balances and transaction histories
│   ├── interest_engine.R        # Orchestrates compound/simple interest, tiered logic, and tax withheld
│   ├── compound_interest.R      # Formula: A = P * (1 + R/m)^(m * t) for Daily, Monthly, etc.
│   ├── simple_interest.R        # Standard Formula: I = P * R * T
│   ├── rate_tables.R            # Progression-based and Flat-tier interest lookup algorithms
│   ├── promotions.R             # Expiry-checked promotional campaign rate overlays
│   ├── taxation.R               # Withholding tax calculations (e.g. 20% on standard, 0% on ISA)
│   ├── validation.R             # Balance thresholds, overdraft locks, transaction order checks
│   ├── reporting.R              # Compliance-ready Customer Statement tables and Branch summaries
│   ├── simulation.R             # Scenarios: Inflation shock, central bank rate changes (+/- interest shocks)
│   ├── forecasting.R            # Recurring monthly deposit projections (Growth schedules)
│   └── utilities.R              # Day Count fraction conventions (ACT/365, ACT/366, ACT/360, 30/360)
├── tests/
│   └── test_interest.R          # testthat unit tests covering boundary thresholds, leap years, and compounding
├── main.R                       # Demonstration execution script runs transactions, calcs, and prints statement
└── README.md                    # This architecture and operations handbook
```

---

## Banking Math & Day Count Fractions

This interest engine supports multiple standard day count conventions used by commercial banks globally:

### 1. Actual/365 (ACT/365)
The exact number of elapsed days divided by 365. Used as standard for basic saver, easy access, and junior accounts.
$$\text{Fraction} = \frac{\text{Actual days between dates}}{365}$$

### 2. Actual/366 (ACT/366)
Used during leap years.
$$\text{Fraction} = \frac{\text{Actual days between dates}}{366}$$

### 3. Actual/360 (ACT/360)
Commonly used in corporate accounts.
$$\text{Fraction} = \frac{\text{Actual days between dates}}{360}$$

### 4. 30/360 (ISDA Convention)
Assumes exactly 30 days in a month and 360 days in a year.
$$\text{Fraction} = \frac{360(Y_2 - Y_1) + 30(M_2 - M_1) + (D_2 - D_1)}{360}$$

---

## Compounding Formula

For compounding accounts, interest is accumulated according to the specified frequency:
$$A = P \times \left(1 + \frac{r}{m}\right)^{m \times t}$$

Where:
* $A$ = Final balance after interest
* $P$ = Principal (initial deposit)
* $r$ = Nominal annual interest rate
* $m$ = Number of compounding cycles per year (Daily = 365, Monthly = 12, Quarterly = 4, Annual = 1)
* $t$ = Total years elapsed (calculated using the chosen day-count fraction)

---

## progressive Tiered Interest

For tiered accounts, balances are processed through sequential brackets. For example:
* £0 - £999.99 accrued at 1.2%
* £1,000 - £4,999.99 accrued at 2.0%
* £5,000+ accrued at 3.1%

Under **progressive rules**, a balance of **£6,000** over $t$ fraction of a year would accrue interest as:
$$\text{Interest} = (1000 \times 1.2\% \times t) + (4000 \times 2.0\% \times t) + (1000 \times 3.1\% \times t)$$

---

## Running the Engine in R

To run the full simulation demonstration, navigate to the `/RhinoInterestEngine` folder and run `main.R`:

```r
install.packages(c("yaml", "jsonlite", "testthat", "R6")) # If missing

# Execute demo
source("main.R")
```

To run the unit tests:

```r
library(testthat)
test_dir("tests")
```
