# Rhino Bank - Interest Engine Unit Tests
# Adheres to the 'testthat' package standard

library(testthat)

# Source engine components
source("../R/utilities.R")
source("../R/validation.R")
source("../R/simple_interest.R")
source("../R/compound_interest.R")
source("../R/rate_tables.R")
source("../R/promotions.R")
source("../R/taxation.R")
source("../R/interest_engine.R")

test_that("Leap Year and Day Count Conventions work accurately", {
  # 2024 is a leap year, so ACT/ACT denominator should recognize 366
  fraction_leap <- day_count_fraction("2024-01-01", "2024-12-31", "ACT/ACT")
  expect_equal(fraction_leap$year_denominator, 366)
  
  # 2025 is standard year (365 days)
  fraction_std <- day_count_fraction("2025-01-01", "2025-12-31", "ACT/ACT")
  expect_equal(fraction_std$year_denominator, 365)
  
  # Days difference calculation
  count_days <- day_count_fraction("2025-01-01", "2025-01-11", "ACT/365")
  expect_equal(count_days$days_accrued, 10)
})

test_that("Simple Interest Calculation is mathematically precise", {
  # Principle: 10,000, Rate: 5% (0.05), Duration: 73 days (which is exactly 0.20 of a year on ACT/365)
  # Interest = 10000 * 0.05 * 0.20 = 100.00
  res <- calculate_simple_interest(
    balance = 10000,
    rate = 0.05,
    start_date = "2025-01-01",
    end_date = "2025-03-15", # Exactly 73 days
    basis = "ACT/365"
  )
  
  expect_equal(res$days_accrued, 73)
  expect_equal(res$fraction, 0.20)
  expect_equal(res$interest_earned, 100.00)
})

test_that("Compound Interest compounding periods yield expected outcomes", {
  # Compounding monthly vs compounding daily for 1 year
  daily_comp <- calculate_compound_interest(
    balance = 10000,
    rate = 0.05,
    start_date = "2025-01-01",
    end_date = "2025-12-31", # 364 days accrued, fraction ~0.9972
    compounding_frequency = "daily"
  )
  
  monthly_comp <- calculate_compound_interest(
    balance = 10000,
    rate = 0.05,
    start_date = "2025-01-01",
    end_date = "2025-12-31",
    compounding_frequency = "monthly"
  )
  
  # Daily compound must be greater than monthly compound due to compounding frequency
  expect_true(daily_comp$interest_earned > monthly_comp$interest_earned)
})

test_that("Tiered Rate structure parses balance brackets correctly", {
  # Rate table mock
  mock_tiers <- list(
    list(min_balance = 0.00, max_balance = 999.99, rate = 0.0120),
    list(min_balance = 1000.00, max_balance = 4999.99, rate = 0.0200),
    list(min_balance = 5000.00, max_balance = 999999.99, rate = 0.0310)
  )
  
  # Flat-rate lookup
  expect_equal(get_flat_tier_rate(500, mock_tiers), 0.0120)
  expect_equal(get_flat_tier_rate(3500, mock_tiers), 0.0200)
  expect_equal(get_flat_tier_rate(12000, mock_tiers), 0.0310)
  
  # Progressive tiered interest calculation (10,000 for 1 year, i.e. 365 days on ACT/365)
  # - first 1000 at 1.2% = 12.00
  # - next 4000 (1000 to 5000) at 2.0% = 80.00
  # - remaining 5000 (5000 to 10000) at 3.1% = 155.00
  # Total progressive interest = 12.00 + 80.00 + 155.00 = 247.00
  prog_res <- calculate_progressive_tiered_interest(
    balance = 10000,
    tiers = mock_tiers,
    days = 365,
    year_denominator = 365
  )
  
  expect_equal(prog_res$total_interest_earned, 247.00)
})

test_that("Tax withholders deduct expected rates", {
  # Gross 500 interest, Standard taxable at 20% standard rate
  exempt_case <- calculate_taxation(500.00, "exempt")
  taxable_case <- calculate_taxation(500.00, "taxable", 0.20)
  
  expect_equal(exempt_case$tax_withheld, 0.00)
  expect_equal(exempt_case$net_interest, 500.00)
  
  expect_equal(taxable_case$tax_withheld, 100.00)
  expect_equal(taxable_case$net_interest, 400.00)
})

test_that("Validation traps negative balances and invalid date boundaries", {
  # Transaction balance guard
  rules_guard <- list(allow_negative = FALSE)
  
  # Safe deposit
  expect_true(validate_transaction("deposit", 100, 50, rules_guard))
  
  # Oversized withdrawal should stop
  expect_error(validate_transaction("withdrawal", 250, 100, rules_guard))
  
  # Invalid chronological dates
  expect_error(validate_calculation_dates("2025-12-31", "2025-01-01"))
})
