#' Rhino Bank Core Interest Calculation Engine
#'
#' This is the central module of the Rhino Interest Engine. It exposes the
#' \code{calculate_interest} function which orchestrates calculations,
#' day count fractions, rates lookup, promotional bonuses, and compliance logs.
#'
#' @export
calculate_interest <- function(opening_balance, current_balance, interest_rate,
                               start_date, end_date, compounding_rule = "monthly",
                               account_type = "basic_saver", basis = "ACT/365",
                               tiers = NULL, campaign = NULL, tax_status = "taxable") {
  
  # Source dependencies locally
  source("utilities.R", local = TRUE)
  source("validation.R", local = TRUE)
  source("simple_interest.R", local = TRUE)
  source("compound_interest.R", local = TRUE)
  source("rate_tables.R", local = TRUE)
  source("promotions.R", local = TRUE)
  source("taxation.R", local = TRUE)
  
  # 1. Validation
  validate_calculation_dates(start_date, end_date)
  
  # Create unique calculation ID
  calc_id <- generate_calc_id()
  
  # 2. Rate Adjustments (Promotional and Tiered overlay)
  calc_rate <- interest_rate
  is_tiered <- FALSE
  tiered_details <- NULL
  
  if (!is.null(campaign)) {
    calc_rate <- apply_promo_rate(interest_rate, campaign, start_date)
  }
  
  # If tiered rules apply and tiers are provided
  if (!is.null(tiers) && length(tiers) > 0) {
    is_tiered <- TRUE
  }
  
  # 3. Core Calculation
  interest_details <- NULL
  gross_interest <- 0.0
  formula_used <- ""
  
  if (is_tiered) {
    # Tiered progressive interest
    counts <- day_count_fraction(start_date, end_date, basis)
    tiered_res <- calculate_progressive_tiered_interest(
      balance = current_balance, 
      tiers = tiers, 
      days = counts$days_accrued, 
      year_denominator = counts$year_denominator
    )
    gross_interest <- tiered_res$total_interest_earned
    tiered_details <- tiered_res$tier_breakdown
    formula_used <- "Progressive Tiered Interest math"
  } else {
    # Standard Simple vs Compound
    if (compounding_rule == "simple" || is.null(compounding_rule)) {
      interest_details <- calculate_simple_interest(
        balance = current_balance,
        rate = calc_rate,
        start_date = start_date,
        end_date = end_date,
        basis = basis
      )
      gross_interest <- interest_details$interest_earned
      formula_used <- interest_details$formula
    } else {
      interest_details <- calculate_compound_interest(
        balance = current_balance,
        rate = calc_rate,
        start_date = start_date,
        end_date = end_date,
        compounding_frequency = compounding_rule,
        basis = basis
      )
      gross_interest <- interest_details$interest_earned
      formula_used <- interest_details$formula
    }
  }
  
  # 4. Tax Calculation
  tax_res <- calculate_taxation(gross_interest, tax_status)
  
  # 5. Output Audit Log
  audit_trail <- list(
    timestamp = Sys.time(),
    calculation_id = calc_id,
    version = "v1.2.0-compliance",
    operator = "EngineSystem",
    inputs = list(
      opening_balance = opening_balance,
      current_balance = current_balance,
      applied_rate = calc_rate,
      base_rate = interest_rate,
      start_date = start_date,
      end_date = end_date,
      compounding_rule = compounding_rule,
      account_type = account_type,
      day_count_basis = basis,
      tax_status = tax_status
    ),
    outputs = list(
      gross_interest = bank_round(gross_interest, 4),
      tax_withheld = tax_res$tax_withheld,
      net_interest = tax_res$net_interest,
      final_balance = bank_round(current_balance + tax_res$net_interest, 4),
      effective_yield = if (!is.null(interest_details$effective_annual_yield)) interest_details$effective_annual_yield else calc_rate
    ),
    formula_used = formula_used,
    progressive_tiered_details = tiered_details
  )
  
  return(audit_trail)
}
