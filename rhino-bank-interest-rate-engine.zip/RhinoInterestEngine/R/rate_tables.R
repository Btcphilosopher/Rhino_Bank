#' Rhino Bank Tiered Rate Table Evaluator
#'
#' Evaluates interest rates based on balance tiers and lookups.
#' Supports progressive tiers (different rates on portion of balance)
#' and flat-rate matching (single rate based on entire balance bracket).
#'
#' @export

#' Determine rate for a given balance under Flat-Tier rules
#'
#' @param balance Numeric. Account balance.
#' @param tiers List of lists. Each list must have min_balance, max_balance, and rate.
#' @return Numeric. The interest rate matching the bracket.
get_flat_tier_rate <- function(balance, tiers) {
  matched_rate <- 0
  
  for (tier in tiers) {
    if (balance >= tier$min_balance && balance <= tier$max_balance) {
      matched_rate <- tier$rate
      break
    }
  }
  
  return(matched_rate)
}

#' Calculate progressive tiered interest
#'
#' Interest is calculated separately for each portion of the balance in each tier.
#' For example:
#' - Tier 1: £0 - £1000 at 1.2%
#' - Tier 2: £1000 - £5000 at 2.0%
#' - Balance of £2500 gets 1000 * 1.2% + 1500 * 2.0%.
#'
#' @param balance Numeric. Account balance.
#' @param tiers List of lists. Each list must have min_balance, max_balance, and rate.
#' @param days Integer. Days accrued.
#' @param year_denominator Integer. e.g. 365
#' @return List. Total interest earned and a breakdown of interest earned per tier.
calculate_progressive_tiered_interest <- function(balance, tiers, days, year_denominator = 365) {
  fraction <- days / year_denominator
  remaining_balance <- balance
  total_interest <- 0
  tier_breakdown <- list()
  
  for (i in seq_along(tiers)) {
    tier <- tiers[[i]]
    tier_capacity <- tier$max_balance - tier$min_balance
    
    # Amount of balance in this tier
    amount_in_tier <- min(remaining_balance, tier_capacity)
    
    if (amount_in_tier > 0) {
      interest_for_tier <- amount_in_tier * tier$rate * fraction
      total_interest <- total_interest + interest_for_tier
      
      tier_breakdown[[paste0("Tier_", i)]] <- list(
        tier_rate = tier$rate,
        allocated_balance = amount_in_tier,
        interest_earned = round(interest_for_tier, 4)
      )
      
      remaining_balance <- remaining_balance - amount_in_tier
    } else {
      break
    }
  }
  
  return(list(
    total_interest_earned = round(total_interest, 4),
    tier_breakdown = tier_breakdown
  ))
}
