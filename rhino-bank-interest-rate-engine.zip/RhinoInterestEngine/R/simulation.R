#' Rhino Bank Scenario Simulation Module
#'
#' Evaluates the financial impacts of varying economic environments, interest rate hikes,
#' and transaction schedules on interest earned.
#'
#' @export

#' Run a Scenario Simulation on an Account
#'
#' Simulates the growth of an account balance over a period under different
#' macroeconomic stress tests (e.g., Inflation Shock, Rate Cut, Rate Hike).
#'
#' @param initial_balance Numeric. Account opening amount.
#' @param rate Numeric. Base annual interest rate.
#' @param years Numeric. Number of years for simulation.
#' @param compounding Character. Compounding frequency (daily, monthly, quarterly, annual).
#' @param inflation_rate Numeric. Annualized rate of inflation.
#' @param rate_shock Numeric. Adjusts the base rate by this amount (e.g. +0.015 for +1.5%).
#' @return data.frame Containing balance projection under normal, shocked, and inflation-adjusted regimes.
run_scenario_simulation <- function(initial_balance, rate, years, 
                                    compounding = "monthly", 
                                    inflation_rate = 0.02, 
                                    rate_shock = 0.00) {
  source("compound_interest.R", local = TRUE)
  
  sim_data <- data.frame(
    Year = 0:years,
    Normal_Balance = numeric(years + 1),
    Shocked_Balance = numeric(years + 1),
    Real_Normal_Balance = numeric(years + 1), # adjusted for inflation
    stringsAsFactors = FALSE
  )
  
  sim_data$Normal_Balance[1] <- initial_balance
  sim_data$Shocked_Balance[1] <- initial_balance
  sim_data$Real_Normal_Balance[1] <- initial_balance
  
  adjusted_rate <- rate + rate_shock
  
  # Year-by-year simulation
  for (yr in 1:years) {
    # 1. Base simulation
    base_res <- calculate_compound_interest(
      balance = sim_data$Normal_Balance[yr],
      rate = rate,
      start_date = Sys.Date(),
      end_date = Sys.Date() + 365,
      compounding_frequency = compounding
    )
    sim_data$Normal_Balance[yr + 1] <- base_res$final_balance
    
    # 2. Shocked rate simulation
    shock_res <- calculate_compound_interest(
      balance = sim_data$Shocked_Balance[yr],
      rate = adjusted_rate,
      start_date = Sys.Date(),
      end_date = Sys.Date() + 365,
      compounding_frequency = compounding
    )
    sim_data$Shocked_Balance[yr + 1] <- shock_res$final_balance
    
    # 3. Real normal balance (discounted by cumulative inflation)
    discount_factor <- (1 + inflation_rate)^yr
    sim_data$Real_Normal_Balance[yr + 1] <- base_res$final_balance / discount_factor
  }
  
  # Round values
  sim_data$Normal_Balance <- round(sim_data$Normal_Balance, 2)
  sim_data$Shocked_Balance <- round(sim_data$Shocked_Balance, 2)
  sim_data$Real_Normal_Balance <- round(sim_data$Real_Normal_Balance, 2)
  
  return(sim_data)
}
