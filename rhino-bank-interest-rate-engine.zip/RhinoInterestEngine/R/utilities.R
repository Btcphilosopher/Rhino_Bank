#' Rhino Bank Interest Rate Engine Utilities
#'
#' This module implements utility functions for day count conventions, leap year checks,
#' currency rounding, and configuration lookups.
#'
#' @importFrom lubridate is_leap_year ymd
#' @export

#' Check if a given year is a leap year
#'
#' @param date A Date object or string in YYYY-MM-DD format
#' @return Logical. TRUE if leap year, FALSE otherwise
#' @examples
#' is_leap_year_date("2024-02-29") # TRUE
is_leap_year_date <- function(date) {
  dt <- as.Date(date)
  yr <- as.integer(format(dt, "%Y"))
  # Standard leap year check
  (yr %% 4 == 0 & yr %% 100 != 0) | (yr %% 400 == 0)
}

#' Calculate days in year based on day-count convention
#'
#' Supports:
#' - ACT/365: Actual days divided by 365.
#' - ACT/366: Actual days divided by 366.
#' - ACT/ACT: Actual days divided by actual days in that year (365 or 366).
#' - ACT/360: Actual days divided by 360 (often used in corporate/business accounts).
#' - 30/360: Assumes 30 days in a month and 360 in a year.
#'
#' @param start_date Date object or YYYY-MM-DD string
#' @param end_date Date object or YYYY-MM-DD string
#' @param basis Character. Day count convention basis.
#' @return A list containing `days_accrued` and `year_denominator`
#' @export
day_count_fraction <- function(start_date, end_date, basis = "ACT/365") {
  sd <- as.Date(start_date)
  ed <- as.Date(end_date)
  
  if (sd > ed) {
    stop("Start date must be less than or equal to End date.")
  }
  
  days_accrued <- as.numeric(ed - sd)
  
  denom <- switch(basis,
    "ACT/365" = 365,
    "ACT/360" = 360,
    "ACT/366" = 366,
    "ACT/ACT" = {
      # For ACT/ACT, the denominator depends on the year
      yr <- as.integer(format(sd, "%Y"))
      if (is_leap_year_date(sd) || is_leap_year_date(ed)) {
        366
      } else {
        365
      }
    },
    "30/360" = {
      # Standard ISDA 30/360 formula
      d1 <- as.integer(format(sd, "%d"))
      m1 <- as.integer(format(sd, "%m"))
      y1 <- as.integer(format(sd, "%Y"))
      
      d2 <- as.integer(format(ed, "%d"))
      m2 <- as.integer(format(ed, "%m"))
      y2 <- as.integer(format(ed, "%Y"))
      
      # ISDA rules
      if (d1 == 31) d1 <- 30
      if (d2 == 31 && d1 >= 30) d2 <- 30
      
      days_accrued <- 360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1)
      360
    },
    # Default to ACT/365
    365
  )
  
  return(list(
    days_accrued = days_accrued,
    year_denominator = denom,
    fraction = days_accrued / denom
  ))
}

#' Round to bank precision (2 decimal places for currency)
#'
#' Adheres to standard bankers' rounding (round-to-even) or standard rounding.
#'
#' @param amount Numeric value
#' @param decimals Integer. Decimal places to round to.
#' @return Numeric value rounded
#' @export
bank_round <- function(amount, decimals = 2) {
  round(amount, digits = decimals)
}

#' Generate calculation unique ID
#'
#' @return Character UUID or hash
#' @export
generate_calc_id <- function() {
  paste0("CALC-", sprintf("%06X", sample(1:16777215, 1)))
}
