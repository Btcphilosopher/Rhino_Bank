#' Rhino Bank Interest Engine Reporting Module
#'
#' Generates structured interest statements, branch summaries, and exports.
#'
#' @export

#' Generate a Customer Interest Statement
#'
#' Creates a detailed, compliance-ready breakdown of interest earned and tax withheld.
#'
#' @param account R6 Account object.
#' @param interest_audit List. Output from calculate_interest().
#' @return List. Printed formatted statement and structured list.
generate_customer_statement <- function(account, interest_audit) {
  statement_id <- paste0("STMT-", sprintf("%05d", sample(1:99999, 1)))
  
  cat("\n=======================================================\n")
  cat("                RHINO MICRO-BANK STATEMENT             \n")
  cat("=======================================================\n")
  cat("Statement ID : ", statement_id, "\n")
  cat("Date         : ", format(Sys.Date(), "%Y-%m-%d"), "\n")
  cat("Customer ID  : ", account$customer_id, "\n")
  cat("Account No.  : ", account$account_number, "\n")
  cat("Product Type : ", toupper(account$product_type), "\n")
  cat("Currency     : ", account$currency, "\n")
  cat("-------------------------------------------------------\n")
  cat("Calculation Period : ", interest_audit$inputs$start_date, " to ", interest_audit$inputs$end_date, "\n")
  cat("Day Count Basis    : ", interest_audit$inputs$day_count_basis, "\n")
  cat("Interest Method    : ", toupper(interest_audit$inputs$compounding_rule), " Compounding\n")
  cat("Interest Rate      : ", (interest_audit$inputs$applied_rate * 100), "%\n")
  cat("-------------------------------------------------------\n")
  cat("Opening Balance    : ", sprintf("%.2f", interest_audit$inputs$opening_balance), "\n")
  cat("Current Balance    : ", sprintf("%.2f", interest_audit$inputs$current_balance), "\n")
  cat("Gross Interest     : ", sprintf("%.4f", interest_audit$outputs$gross_interest), "\n")
  cat("Tax Withheld       : ", sprintf("%.2f", interest_audit$outputs$tax_withheld), "\n")
  cat("Net Interest Credited: ", sprintf("%.4f", interest_audit$outputs$net_interest), "\n")
  cat("-------------------------------------------------------\n")
  cat("Final Balance      : ", sprintf("%.2f", interest_audit$outputs$final_balance), "\n")
  cat("=======================================================\n\n")
  
  return(list(
    statement_id = statement_id,
    generated_at = Sys.time(),
    customer_id = account$customer_id,
    account_number = account$account_number,
    period = paste(interest_audit$inputs$start_date, "to", interest_audit$inputs$end_date),
    opening_balance = interest_audit$inputs$opening_balance,
    closing_balance = interest_audit$outputs$final_balance,
    gross_interest = interest_audit$outputs$gross_interest,
    tax_withheld = interest_audit$outputs$tax_withheld,
    net_interest = interest_audit$outputs$net_interest
  ))
}

#' Generate portfolio report of accrued interest across multiple accounts
#'
#' Summarises interest liabilities for a branch or complete customer list.
#'
#' @param accounts_list List of R6 Account objects.
#' @return data.frame Summary of liabilities.
generate_portfolio_report <- function(accounts_list) {
  summary_data <- data.frame(
    Account_No = character(),
    Customer_ID = character(),
    Product = character(),
    Balance = numeric(),
    Rate = numeric(),
    stringsAsFactors = FALSE
  )
  
  for (acc in accounts_list) {
    summary_data <- rbind(summary_data, data.frame(
      Account_No = acc$account_number,
      Customer_ID = acc$customer_id,
      Product = acc$product_type,
      Balance = acc$current_balance,
      Rate = acc$interest_rate,
      stringsAsFactors = FALSE
    ))
  }
  
  return(summary_data)
}
