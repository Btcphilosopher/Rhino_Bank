#' Rhino Bank Compound Interest Calculator
#'
#' Calculates compound interest on a principal balance over a given period, supporting
#' various compounding frequencies (Daily, Monthly, Quarterly, Semi-Annual, Annual).
#'
#' @export
calculate_compound_interest <- function(balance, rate, start_date, end_date, 
                                        compounding_frequency = "monthly", 
                                        basis = "ACT/365") {
  source("utilities.R", local = TRUE)
  
  counts <- day_count_fraction(start_date, end_date, basis)
  days <- counts$days_accrued
  fraction <- counts$fraction
  
  # Determine compound periods per year (m)
  m <- switch(compounding_frequency,
    "daily" = counts$year_denominator, # e.g. 365 or 360
    "weekly" = 52,
    "monthly" = 12,
    "quarterly" = 4,
    "semi-annual" = 2,
    "annual" = 1,
    # Default to monthly
    12
  )
  
  # Total years t
  t <- fraction
  
  # Number of compounding cycles in this period
  n_periods <- t * m
  
  # Standard formula: A = P * (1 + R/m)^(m * t)
  # Interest earned = A - P
  final_balance <- balance * ((1 + (rate / m))^n_periods)
  interest_earned <- final_balance - balance
  
  # Effective Annual Yield (EAY) / Effective Annual Rate (EAR)
  # EAY = (1 + R/m)^m - 1
  effective_yield <- ((1 + (rate / m))^m) - 1
  
  return(list(
    initial_balance = balance,
    final_balance = bank_round(final_balance, 4),
    interest_earned = bank_round(interest_earned, 4),
    effective_annual_yield = bank_round(effective_yield, 6),
    days_accrued = days,
    periods_count = n_periods,
    compounding_frequency = compounding_frequency,
    basis = basis,
    formula = "A = P * (1 + r/m)^(m*t)"
  ))
}
