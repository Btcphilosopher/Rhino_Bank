#' Rhino Bank Interest Taxation Engine
#'
#' Computes withholding tax on earned interest depending on the customer's tax status.
#' Supports taxable, tax-exempt (e.g. ISA, Junior ISAs), and customizable tax brackets.
#'
#' @export

#' Calculate tax withholding and net interest earned
#'
#' @param gross_interest Numeric. Total interest earned.
#' @param tax_status Character. taxable, exempt, or custom.
#' @param standard_tax_rate Numeric. Standard withholding tax rate (default 20%).
#' @return List. Gross interest, tax withheld, net interest, and applied tax rate.
calculate_taxation <- function(gross_interest, tax_status = "taxable", standard_tax_rate = 0.20) {
  if (gross_interest <= 0) {
    return(list(
      gross_interest = gross_interest,
      tax_withheld = 0,
      net_interest = gross_interest,
      tax_rate = 0
    ))
  }
  
  rate_applied <- switch(tax_status,
    "exempt" = 0.00,
    "taxable" = standard_tax_rate,
    "custom" = standard_tax_rate,
    # Default to standard taxable rate
    standard_tax_rate
  )
  
  tax_withheld <- gross_interest * rate_applied
  net_interest <- gross_interest - tax_withheld
  
  return(list(
    gross_interest = bank_round(gross_interest, 2),
    tax_withheld = bank_round(tax_withheld, 2),
    net_interest = bank_round(net_interest, 2),
    tax_rate = rate_applied
  ))
}
