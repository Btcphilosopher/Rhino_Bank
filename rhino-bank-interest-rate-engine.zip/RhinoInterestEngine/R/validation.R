#' Rhino Bank Interest Engine Validation Module
#'
#' Validates account states, transaction consistency, date order, and interest limits
#' to prevent compliance violations.
#'
#' @export

#' Validate account balance limits
#'
#' @param balance Numeric. Current balance.
#' @param product_rules List. Rules for the product.
#' @return Logical. TRUE if valid, otherwise throws an error.
validate_limits <- function(balance, product_rules) {
  if (balance < 0 && (!is.null(product_rules$allow_negative) && !product_rules$allow_negative)) {
    stop(paste("Validation Error: Negative balances are not allowed for this product rules.", balance))
  }
  
  if (!is.null(product_rules$min_balance) && balance < product_rules$min_balance) {
    # Warning or error depending on bank policy. Here we log a warning for deposit-starved accounts
    warning(paste("Account balance", balance, "is below product minimum threshold", product_rules$min_balance))
  }
  
  if (!is.null(product_rules$max_balance) && balance > product_rules$max_balance) {
    stop(paste("Validation Error: Account balance", balance, "exceeds maximum allowed threshold", product_rules$max_balance))
  }
  
  return(TRUE)
}

#' Validate transaction details
#'
#' @param tx_type Character. deposit, withdrawal, transfer, interest_credit, interest_reversal, fee_deduction
#' @param amount Numeric. Transaction value.
#' @param balance Numeric. Current balance before transaction.
#' @param product_rules List. Product constraints.
#' @return Logical.
validate_transaction <- function(tx_type, amount, balance, product_rules) {
  if (amount <= 0) {
    stop("Validation Error: Transaction amount must be positive.")
  }
  
  if (tx_type %in% c("withdrawal", "transfer", "fee_deduction")) {
    new_balance <- balance - amount
    if (new_balance < 0 && (!is.null(product_rules$allow_negative) && !product_rules$allow_negative)) {
      stop(paste("Validation Error: Insufficient funds. Cannot complete transaction of", amount, "as it would make balance negative."))
    }
  }
  
  if (tx_type == "deposit" && !is.null(product_rules$max_monthly_deposit)) {
    # Additional logic for regular saver monthly limits would sit here or in the transaction ledger
  }
  
  return(TRUE)
}

#' Validate calculation dates
#'
#' @param start_date Date. Start date.
#' @param end_date Date. End date.
#' @return Logical.
validate_calculation_dates <- function(start_date, end_date) {
  sd <- as.Date(start_date)
  ed <- as.Date(end_date)
  
  if (sd > ed) {
    stop(paste("Validation Error: Start date", sd, "cannot be after End date", ed))
  }
  
  # Future dates restriction
  if (ed > Sys.Date() + 365*10) { # Allow reasonable projections but not infinity
    stop("Validation Error: Calculation end date is too far in the future.")
  }
  
  return(TRUE)
}
