#' Rhino Bank Customer Account Model
#'
#' Implements the R6 class to encapsulate bank account attributes, current state,
#' and transaction ledgers.
#'
#' @import R6
#' @export
library(R6)

Account <- R6Class("Account",
  public = list(
    customer_id = NULL,
    account_number = NULL,
    product_type = NULL,
    opening_date = NULL,
    current_balance = 0.0,
    available_balance = 0.0,
    interest_rate = 0.0,
    interest_method = "compound",
    compound_frequency = "monthly",
    tax_status = "taxable",
    account_status = "active",
    currency = "GBP",
    transactions = NULL,
    accrued_interest = 0.0,
    last_interest_calc_date = NULL,
    
    #' Initialize a new account
    initialize = function(customer_id, account_number, product_type, opening_date, 
                          current_balance = 0.0, interest_rate = 0.015, 
                          interest_method = "compound", compound_frequency = "monthly",
                          tax_status = "taxable", currency = "GBP") {
      self$customer_id <- customer_id
      self$account_number <- account_number
      self$product_type <- product_type
      self$opening_date <- as.Date(opening_date)
      self$current_balance <- current_balance
      self$available_balance <- current_balance
      self$interest_rate <- interest_rate
      self$interest_method <- interest_method
      self$compound_frequency <- compound_frequency
      self$tax_status <- tax_status
      self$account_status <- "active"
      self$currency <- currency
      self$accrued_interest <- 0.0
      self$last_interest_calc_date <- as.Date(opening_date)
      
      # Initialize transactions ledger
      self$transactions <- data.frame(
        timestamp = Sys.time(),
        tx_id = "INIT",
        type = "deposit",
        amount = current_balance,
        balance_after = current_balance,
        description = "Initial balance deposit",
        stringsAsFactors = FALSE
      )
    },
    
    #' Record transaction
    post_transaction = function(type, amount, description = "") {
      source("validation.R", local = TRUE)
      
      # Prepare rules check (stub rules lookup)
      rules <- list(
        allow_negative = FALSE,
        min_balance = 0.0,
        max_balance = 10000000.0
      )
      
      # Validate
      validate_transaction(type, amount, self$current_balance, rules)
      
      # Apply balances
      if (type %in% c("deposit", "interest_credit", "promotional_bonus")) {
        self$current_balance <- self$current_balance + amount
      } else if (type %in% c("withdrawal", "transfer", "fee_deduction", "interest_reversal")) {
        self$current_balance <- self$current_balance - amount
      }
      
      self$available_balance <- self$current_balance
      
      # Append to ledger
      tx_id <- paste0("TX-", sprintf("%06X", sample(1:16777215, 1)))
      new_tx <- data.frame(
        timestamp = Sys.time(),
        tx_id = tx_id,
        type = type,
        amount = amount,
        balance_after = self$current_balance,
        description = description,
        stringsAsFactors = FALSE
      )
      
      self$transactions <- rbind(self$transactions, new_tx)
      
      # Return transaction ID
      return(tx_id)
    },
    
    #' Close account
    close_account = function() {
      if (self$current_balance != 0.0) {
        stop("Cannot close account. Balance must be fully withdrawn first (current balance: ", self$current_balance, ")")
      }
      self$account_status <- "closed"
      self$post_transaction("closure", 0.0, "Account officially closed.")
    }
  )
)
