#' Rhino Bank Simple Interest Calculator
#'
#' Calculates simple interest using balance, rate, and day fraction conventions.
#'
#' @export
calculate_simple_interest <- function(balance, rate, start_date, end_date, basis = "ACT/365") {
  source("utilities.R", local = TRUE)
  
  # Validate inputs
  if (balance < 0) {
    # Negative interest configuration (charging/debiting simple interest)
    # We allow it if the system has it enabled
  }
  
  # Get day fraction
  counts <- day_count_fraction(start_date, end_date, basis)
  
  # Formula: I = P * R * T
  interest_earned <- balance * rate * counts$fraction
  
  return(list(
    interest_earned = bank_round(interest_earned, 4),
    days_accrued = counts$days_accrued,
    year_denominator = counts$year_denominator,
    fraction = counts$fraction,
    formula = "I = P * R * T (Simple Interest)"
  ))
}
