#' Rhino Bank Promotional Rate and Campaign Module
#'
#' Manages promotional bonuses, campaign rates, and anniversary loyalty boosters.
#' Ensures compliance constraints (e.g. limited active period, maximum bonus caps).
#'
#' @export

#' Check if a promotional campaign is active
#'
#' @param current_date Date or string.
#' @param campaign List with start_date, end_date, and promotion_rate.
#' @return Logical.
is_promotion_active <- function(current_date, campaign) {
  if (is.null(campaign)) return(FALSE)
  
  cd <- as.Date(current_date)
  start <- as.Date(campaign$start_date)
  end <- as.Date(campaign$end_date)
  
  return(cd >= start && cd <= end)
}

#' Apply active promotional rate booster
#'
#' Adds promotional interest if eligible and active.
#'
#' @param base_rate Numeric. Base annual interest rate.
#' @param campaign List. Campaign parameters.
#' @param current_date Date. Date of interest accrual.
#' @return Numeric. Boosted rate if active, otherwise base_rate.
apply_promo_rate <- function(base_rate, campaign, current_date) {
  if (is_promotion_active(current_date, campaign)) {
    # Some campaigns override the rate, others add a booster
    if (!is.null(campaign$booster) && campaign$booster) {
      return(base_rate + campaign$promo_rate)
    } else {
      return(campaign$promo_rate)
    }
  }
  return(base_rate)
}
