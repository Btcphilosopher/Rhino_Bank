import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Lazy initialization of GoogleGenAI SDK to prevent app crashes when key is missing
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY is not configured in secrets. Please configure it in Settings > Secrets to use AI Assistant features.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Recursive helper to traverse RhinoInterestEngine folder
function getFilesRecursively(dir: string, baseDir: string): any[] {
  let results: any[] = [];
  if (!fs.existsSync(dir)) {
    return results;
  }
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getFilesRecursively(filePath, baseDir));
    } else {
      const relativePath = path.relative(baseDir, filePath);
      const content = fs.readFileSync(filePath, "utf-8");
      results.push({
        path: relativePath,
        name: file,
        content: content,
      });
    }
  });
  return results;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON parsing middleware
  app.use(express.json());

  // 1. API: Get all files inside the R project folder
  app.get("/api/files", (req, res) => {
    try {
      const rDir = path.join(process.cwd(), "RhinoInterestEngine");
      const files = getFilesRecursively(rDir, rDir);
      res.json({ files });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. API: Save content to a file inside the R project folder
  app.post("/api/files/save", (req, res) => {
    const { filePath, content } = req.body;
    if (!filePath || content === undefined) {
      return res.status(400).json({ error: "Missing filePath or content" });
    }
    const fullPath = path.join(process.cwd(), "RhinoInterestEngine", filePath);
    
    // Prevent directory traversal attacks
    if (!fullPath.startsWith(path.join(process.cwd(), "RhinoInterestEngine"))) {
      return res.status(403).json({ error: "Access Denied: Path is outside target folder." });
    }

    try {
      // Ensure folder exists
      fs.mkdirSync(path.dirname(fullPath), { recursive: true });
      fs.writeFileSync(fullPath, content, "utf-8");
      res.json({ success: true, message: `Successfully saved ${filePath}` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3. API: Quant AI Assistant endpoint
  app.post("/api/gemini/explain", async (req, res) => {
    const { prompt, fileContent, filePath } = req.body;
    try {
      const ai = getGenAI();
      const systemInstruction = `You are an expert quantitative finance developer, banking regulations systems architect, R programmer, and senior financial modeler for Rhino Bank.
Your goal is to explain and clarify complex savings interest math, leap years calculation logic, R coding conventions, R6 OOP patterns, or scenario planning constraints.
Explain things simply, focus on mathematical logic and exact day-count fractions. Make your answers concise, scannable, and actionable.`;

      let query = prompt;
      if (filePath && fileContent) {
        query = `Here is the content of the file "${filePath}":\n\`\`\`R\n${fileContent}\n\`\`\`\n\nUser Question: ${prompt}`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: query,
        config: {
          systemInstruction,
          temperature: 0.2,
        },
      });

      res.json({ explanation: response.text });
    } catch (err: any) {
      console.error("Gemini API Error:", err);
      res.status(200).json({ 
        error: true, 
        message: err.message || "An unknown error occurred while communicating with Gemini." 
      });
    }
  });

  // Vite middleware for dev or Static asset serving for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
