import React, { useState } from "react";
import { 
  PiggyBank, Play, Cpu, ShieldCheck, Sparkles, BookOpen, 
  Settings, FolderOpen, Terminal, HelpCircle, Activity 
} from "lucide-react";
import SimPlayground from "./components/SimPlayground";
import FileExplorer from "./components/FileExplorer";
import LedgerSandbox from "./components/LedgerSandbox";
import TestSuite from "./components/TestSuite";
import AIPanel from "./components/AIPanel";

export default function App() {
  const [activeTab, setActiveTab] = useState<"simulation" | "ide" | "ledger" | "tests" | "ai">("simulation");

  const tabs = [
    { id: "simulation", name: "Savings Simulator", icon: PiggyBank, description: "Compounding growth, rate shocks, & inflation forecasts" },
    { id: "ide", name: "R Project Files (IDE)", icon: FolderOpen, description: "Browse, edit, and audit the complete R package source files" },
    { id: "ledger", name: "Ledger Sandbox & Audit Logs", icon: Activity, description: "Double-entry transactions & compliance accrual trails" },
    { id: "tests", name: "testthat Unit Tests", icon: Terminal, description: "Validate boundary thresholds & leap year math" },
    { id: "ai", name: "Quant AI Assistant", icon: Sparkles, description: "Dialogue with Gemini on advanced finance modeling" }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" id="app-container">
      
      {/* Premium Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm" id="main-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo & Slogan */}
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white p-2.5 rounded-xl shadow-sm shadow-indigo-150">
              <PiggyBank className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-black text-slate-800 text-lg tracking-tight uppercase">Rhino Bank</h1>
                <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-100">
                  Interest Rate Engine R-V1.2
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Enterprise savings accrual, simulation, and forecasting system.
              </p>
            </div>
          </div>

          {/* Core metadata stats */}
          <div className="flex items-center gap-4 text-xs font-mono text-slate-500 bg-slate-50 border border-slate-150 px-4 py-2 rounded-xl h-fit">
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
              <span>R Sandbox: <strong>Active</strong></span>
            </div>
            <div className="h-3 w-px bg-slate-200"></div>
            <div>Basis: <strong>ACT/365 & 30/360 compliant</strong></div>
          </div>
        </div>
      </header>

      {/* Primary tab switcher */}
      <div className="bg-white border-b border-slate-200 py-2.5 shadow-sm" id="tab-switcher">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex flex-wrap md:flex-nowrap gap-2" aria-label="Tabs">
            {tabs.map((tab) => {
              const IconComponent = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 min-w-[150px] md:min-w-0 px-4 py-3 rounded-xl border text-left transition-all cursor-pointer group ${
                    isActive
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-sm shadow-indigo-100"
                      : "bg-white border-slate-200 hover:bg-slate-50 text-slate-600 hover:border-slate-300"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <IconComponent className={`h-4 w-4 shrink-0 ${isActive ? "text-white" : "text-indigo-500"}`} />
                    <span className="font-bold text-xs tracking-wide">{tab.name}</span>
                  </div>
                  <p className={`text-[10px] mt-1 truncate ${isActive ? "text-indigo-100" : "text-slate-400 group-hover:text-slate-500"}`}>
                    {tab.description}
                  </p>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content Space */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8" id="main-content">
        {activeTab === "simulation" && <SimPlayground />}
        {activeTab === "ide" && <FileExplorer />}
        {activeTab === "ledger" && <LedgerSandbox />}
        {activeTab === "tests" && <TestSuite />}
        {activeTab === "ai" && <AIPanel />}
      </main>

      {/* Footnote Compliance Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12" id="footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <BookOpen className="h-4 w-4 text-slate-400" />
            <span>Rhino Bank Quantitative Ledger & Interest Regulations Handbook (July 2026).</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-500 cursor-pointer">Security Standards</span>
            <span className="hover:text-slate-500 cursor-pointer">Banking Compliance</span>
            <span>Version 1.2.0</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
