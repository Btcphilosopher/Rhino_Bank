import React, { useState, useEffect } from "react";
import { Folder, FileCode, Play, Cpu, Sparkles, Save, Check, AlertCircle, RefreshCw, Send, HelpCircle } from "lucide-react";
import { RFile } from "../types";

export default function FileExplorer() {
  const [files, setFiles] = useState<RFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<RFile | null>(null);
  const [editedContent, setEditedContent] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<"idle" | "success" | "error">("idle");
  const [saveMessage, setSaveMessage] = useState<string>("");

  // AI Assistant Chat inside Code Viewer
  const [aiPrompt, setAiPrompt] = useState<string>("");
  const [aiResponse, setAiResponse] = useState<string>("");
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string>("");

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/files");
      const data = await res.json();
      if (data.files) {
        setFiles(data.files);
        // Default to utilities.R if available, or first file
        const defaultFile = data.files.find((f: RFile) => f.path === "R/interest_engine.R") || data.files[0];
        if (defaultFile) {
          setSelectedFile(defaultFile);
          setEditedContent(defaultFile.content);
        }
      }
    } catch (err) {
      console.error("Error fetching files:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectFile = (file: RFile) => {
    setSelectedFile(file);
    setEditedContent(file.content);
    setSaveStatus("idle");
    setAiResponse("");
    setAiError("");
  };

  const handleSave = async () => {
    if (!selectedFile) return;
    setSaving(true);
    setSaveStatus("idle");
    try {
      const res = await fetch("/api/files/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: selectedFile.path,
          content: editedContent,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSaveStatus("success");
        setSaveMessage(`Successfully saved ${selectedFile.name}`);
        // Update local files list
        setFiles(prev =>
          prev.map(f => f.path === selectedFile.path ? { ...f, content: editedContent } : f)
        );
      } else {
        setSaveStatus("error");
        setSaveMessage(data.error || "Failed to save file.");
      }
    } catch (err: any) {
      setSaveStatus("error");
      setSaveMessage(err.message || "Failed to save file.");
    } finally {
      setSaving(false);
    }
  };

  const handleAskAI = async (customPrompt?: string) => {
    const promptToSend = customPrompt || aiPrompt || `Explain the mathematical formulas, inputs, and day-count assumptions inside this R file.`;
    if (!selectedFile) return;
    setAiLoading(true);
    setAiError("");
    setAiResponse("");
    try {
      const res = await fetch("/api/gemini/explain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptToSend,
          fileContent: editedContent,
          filePath: selectedFile.path
        }),
      });
      const data = await res.json();
      if (data.error) {
        setAiError(data.message);
      } else {
        setAiResponse(data.explanation);
      }
    } catch (err: any) {
      setAiError("Failed to communicate with AI server. Ensure GEMINI_API_KEY is active.");
    } finally {
      setAiLoading(false);
      setAiPrompt("");
    }
  };

  // Group files by directory
  const rFiles = files.filter(f => f.path.startsWith("R/"));
  const testFiles = files.filter(f => f.path.startsWith("tests/"));
  const rootFiles = files.filter(f => !f.path.includes("/"));
  const configFiles = files.filter(f => f.path.startsWith("config/") || f.path.startsWith("data/"));

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-slate-50 border border-slate-100 rounded-xl" id="explorer-loading">
        <RefreshCw className="h-8 w-8 text-indigo-500 animate-spin mb-3" />
        <p className="text-slate-500 font-medium">Reading R interest engine file tree from disk...</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="r-code-explorer">
      {/* 1. Directory Tree Sidebar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col h-[650px] shadow-sm overflow-y-auto">
        <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100">
          <Folder className="h-5 w-5 text-indigo-500" />
          <h3 className="font-bold text-slate-800 text-sm tracking-wide uppercase">R Project Structure</h3>
        </div>

        {/* Core R Modules */}
        <div className="mb-4">
          <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>/R (Core Modules)</span>
          </div>
          <div className="space-y-1 mt-1">
            {rFiles.map(file => (
              <button
                key={file.path}
                onClick={() => handleSelectFile(file)}
                className={`w-full text-left px-3 py-2 text-xs rounded-lg flex items-center gap-2 transition-all ${
                  selectedFile?.path === file.path
                    ? "bg-indigo-50 text-indigo-600 font-semibold border-l-2 border-indigo-600"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <FileCode className="h-3.5 w-3.5" />
                <span className="truncate">{file.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tests */}
        <div className="mb-4">
          <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>/tests (Unit Tests)</span>
          </div>
          <div className="space-y-1 mt-1">
            {testFiles.map(file => (
              <button
                key={file.path}
                onClick={() => handleSelectFile(file)}
                className={`w-full text-left px-3 py-2 text-xs rounded-lg flex items-center gap-2 transition-all ${
                  selectedFile?.path === file.path
                    ? "bg-indigo-50 text-indigo-600 font-semibold border-l-2 border-indigo-600"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <FileCode className="h-3.5 w-3.5 text-pink-500" />
                <span className="truncate">{file.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Config and Datasets */}
        <div className="mb-4">
          <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>/config & /data</span>
          </div>
          <div className="space-y-1 mt-1">
            {configFiles.map(file => (
              <button
                key={file.path}
                onClick={() => handleSelectFile(file)}
                className={`w-full text-left px-3 py-2 text-xs rounded-lg flex items-center gap-2 transition-all ${
                  selectedFile?.path === file.path
                    ? "bg-indigo-50 text-indigo-600 font-semibold border-l-2 border-indigo-600"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <FileCode className="h-3.5 w-3.5 text-amber-500" />
                <span className="truncate">{file.path}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Root Scripts */}
        <div className="mt-auto pt-4 border-t border-slate-100">
          <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>Root Workspace</span>
          </div>
          <div className="space-y-1 mt-1">
            {rootFiles.map(file => (
              <button
                key={file.path}
                onClick={() => handleSelectFile(file)}
                className={`w-full text-left px-3 py-2 text-xs rounded-lg flex items-center gap-2 transition-all ${
                  selectedFile?.path === file.path
                    ? "bg-indigo-50 text-indigo-600 font-semibold border-l-2 border-indigo-600"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <FileCode className="h-3.5 w-3.5 text-teal-500" />
                <span className="truncate">{file.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Main Editor & AI Companion Panel */}
      <div className="lg:col-span-3 flex flex-col lg:grid lg:grid-cols-3 gap-6 h-[650px]" id="editor-layout">
        {/* Code editor */}
        <div className="lg:col-span-2 bg-slate-900 rounded-xl flex flex-col overflow-hidden h-full shadow-lg relative border border-slate-850">
          {/* Header */}
          <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-indigo-500"></span>
              <span className="font-mono text-xs text-slate-300 font-semibold">
                {selectedFile?.path || "No file selected"}
              </span>
            </div>
            {selectedFile && (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-semibold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  {saving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                  Save File
                </button>
              </div>
            )}
          </div>

          {/* Save status notice */}
          {saveStatus !== "idle" && (
            <div className={`px-4 py-2 text-xs flex items-center justify-between border-b ${
              saveStatus === "success" 
                ? "bg-emerald-950/80 text-emerald-400 border-emerald-900/50" 
                : "bg-rose-950/80 text-rose-400 border-rose-900/50"
            }`}>
              <div className="flex items-center gap-2">
                {saveStatus === "success" ? <Check className="h-3.5 w-3.5" /> : <AlertCircle className="h-3.5 w-3.5" />}
                <span>{saveMessage}</span>
              </div>
              <button onClick={() => setSaveStatus("idle")} className="hover:opacity-80 text-slate-400">✕</button>
            </div>
          )}

          {/* Text Editor Body */}
          <div className="flex-1 overflow-auto flex relative">
            {/* Line numbers dummy */}
            <div className="bg-slate-950/40 text-slate-600 font-mono text-right pr-3 pl-4 py-4 text-xs select-none border-r border-slate-800/50 hidden md:block select-none" style={{ minWidth: "3.5rem" }}>
              {editedContent.split("\n").map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>

            <textarea
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              className="flex-1 bg-transparent text-slate-200 font-mono text-xs p-4 focus:outline-none resize-none leading-relaxed overflow-x-auto whitespace-pre h-full"
              spellCheck="false"
              placeholder="# Choose an R source file to start auditing math tables..."
            />
          </div>
        </div>

        {/* Right side AI Companion */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col h-full shadow-sm overflow-hidden">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-indigo-500 animate-pulse" />
              <h4 className="font-bold text-slate-800 text-sm">Quant AI Companion</h4>
            </div>
            <HelpCircle className="h-4 w-4 text-slate-400 cursor-pointer hover:text-slate-500" title="Get compliance answers about day counts or R code logic." />
          </div>

          <div className="text-slate-500 text-xs mb-4 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
            Ask Gemini to analyze the active R script, explain the financial algorithms, or suggest regulatory enhancements.
          </div>

          {/* Quick prompt buttons */}
          <div className="space-y-1.5 mb-4">
            <button
              onClick={() => handleAskAI("Explain the day-count conventions and leap year handling in this module.")}
              disabled={aiLoading || !selectedFile}
              className="w-full text-left p-2 text-[11px] bg-indigo-50/50 hover:bg-indigo-50 text-indigo-700 font-medium rounded-lg border border-indigo-100 transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer"
            >
              📊 Explain Day Counts & Leap Years
            </button>
            <button
              onClick={() => handleAskAI("Verify the quantitative formulas and compounding frequency math.")}
              disabled={aiLoading || !selectedFile}
              className="w-full text-left p-2 text-[11px] bg-indigo-50/50 hover:bg-indigo-50 text-indigo-700 font-medium rounded-lg border border-indigo-100 transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer"
            >
              🧮 Verify Compounding Formulas
            </button>
            <button
              onClick={() => handleAskAI("How would I modify this file to support negative interest rates or penalty tier reductions?")}
              disabled={aiLoading || !selectedFile}
              className="w-full text-left p-2 text-[11px] bg-indigo-50/50 hover:bg-indigo-50 text-indigo-700 font-medium rounded-lg border border-indigo-100 transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer"
            >
              🔧 Adapt code for Negative Rates
            </button>
          </div>

          {/* AI Response Block */}
          <div className="flex-1 bg-slate-900 text-slate-300 p-3 rounded-lg text-xs font-mono overflow-y-auto mb-3 border border-slate-800 leading-relaxed">
            {aiLoading ? (
              <div className="flex flex-col items-center justify-center h-full py-10">
                <RefreshCw className="h-5 w-5 text-indigo-400 animate-spin mb-2" />
                <span className="text-[11px] text-slate-400 text-center">Consulting Rhino Quant AI Assistant...</span>
              </div>
            ) : aiError ? (
              <div className="text-rose-400 p-1 flex items-start gap-1.5">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>{aiError}</span>
              </div>
            ) : aiResponse ? (
              <div className="whitespace-pre-wrap select-text markdown-body leading-relaxed text-slate-200">
                {aiResponse}
              </div>
            ) : (
              <div className="text-slate-500 italic text-center py-20">
                Click a quick prompt above or type a custom query to start modeling.
              </div>
            )}
          </div>

          {/* Custom Prompt Input */}
          <div className="flex gap-1.5">
            <input
              type="text"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder="Ask a custom question..."
              disabled={aiLoading || !selectedFile}
              className="flex-1 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none focus:border-indigo-500 disabled:bg-slate-50"
              onKeyDown={(e) => {
                if (e.key === "Enter" && aiPrompt.trim()) handleAskAI();
              }}
            />
            <button
              onClick={() => handleAskAI()}
              disabled={aiLoading || !selectedFile || !aiPrompt.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white p-2 rounded-lg transition-all cursor-pointer shrink-0"
            >
              <Send className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
