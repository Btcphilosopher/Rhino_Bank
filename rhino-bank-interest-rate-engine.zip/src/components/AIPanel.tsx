import React, { useState } from "react";
import { Sparkles, Send, AlertCircle, RefreshCw, HelpCircle, Bot } from "lucide-react";

export default function AIPanel() {
  const [prompt, setPrompt] = useState<string>("");
  const [response, setResponse] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  const handleAsk = async (prefilled?: string) => {
    const query = prefilled || prompt;
    if (!query.trim()) return;

    setLoading(true);
    setError("");
    setResponse("");

    try {
      const res = await fetch("/api/gemini/explain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: query }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.message);
      } else {
        setResponse(data.explanation);
      }
    } catch (err: any) {
      setError("Failed to communicate with AI server. Ensure GEMINI_API_KEY is configured.");
    } finally {
      setLoading(false);
      setPrompt("");
    }
  };

  const SUGGESTED_TOPICS = [
    { title: "Day Count Fraction Rules", query: "Explain standard day-count conventions (ACT/365, ACT/360, 30/360) and how they determine the interest fraction. What are the global standards?" },
    { title: "Continuous Compounding", query: "Explain continuous compounding. What is the mathematical limit formula for compound interest as frequency goes to infinity? Provide the R implementation." },
    { title: "Tax Withholding Laws", query: "What are the rules regarding withholding taxes on savings interest for retail banks? How do ISAs or Junior accounts remain tax exempt?" },
    { title: "R6 Class vs S3 in R", query: "Explain the difference between R6 classes and S3/S4 object-oriented paradigms in R programming, and why R6 is superior for core ledger models." }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="ai-quant-assistant-panel">
      {/* 1. Left side - Suggested questions */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Bot className="h-5 w-5 text-indigo-500" />
          <h3 className="font-bold text-slate-800 text-sm tracking-wide uppercase">Quant AI Consultations</h3>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-105">
          Ask specific quantitative queries. Choose a recommended topic below or type your own question.
        </p>

        <div className="space-y-2">
          {SUGGESTED_TOPICS.map((topic, idx) => (
            <button
              key={idx}
              onClick={() => handleAsk(topic.query)}
              disabled={loading}
              className="w-full text-left p-3 text-xs bg-slate-50/50 hover:bg-slate-50 hover:border-indigo-500/40 border border-slate-150 rounded-xl transition-all cursor-pointer flex items-start gap-2 group"
            >
              <Sparkles className="h-4 w-4 text-indigo-400 shrink-0 mt-0.5 group-hover:text-indigo-600" />
              <div>
                <div className="font-bold text-slate-800">{topic.title}</div>
                <p className="text-[10px] text-slate-400 mt-0.5 truncate max-w-xs">{topic.query}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Main Q&A terminal */}
      <div className="lg:col-span-2 flex flex-col bg-slate-900 border border-slate-800 rounded-xl shadow-lg overflow-hidden h-[520px]">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-indigo-400" />
            <span className="font-mono text-xs text-slate-300 font-semibold">Gemini Quant Core Sandbox</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">MODEL: gemini-3.6-flash</span>
        </div>

        {/* Console space */}
        <div className="flex-1 p-4 overflow-y-auto leading-relaxed text-xs font-mono text-slate-300">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full py-20">
              <RefreshCw className="h-6 w-6 text-indigo-400 animate-spin mb-3" />
              <span className="text-slate-400">Retrieving mathematical models and central bank regulations...</span>
            </div>
          ) : error ? (
            <div className="p-3 bg-rose-950/40 border border-rose-900/50 text-rose-400 rounded-xl flex items-start gap-2">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">AI Retrieval Error</div>
                <div className="text-[11px] mt-0.5">{error}</div>
              </div>
            </div>
          ) : response ? (
            <div className="whitespace-pre-wrap select-text markdown-body leading-relaxed text-slate-150 p-2">
              {response}
            </div>
          ) : (
            <div className="text-slate-500 italic text-center py-32 select-none">
              Consult the AI engine. Type a financial modeling or compliance question below.
            </div>
          )}
        </div>

        {/* Input prompt bar */}
        <div className="bg-slate-950 p-3 border-t border-slate-800 flex gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Type a custom quantitative modeling question..."
            disabled={loading}
            className="flex-1 border border-slate-800 bg-slate-900/50 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
            onKeyDown={(e) => {
              if (e.key === "Enter" && prompt.trim()) handleAsk();
            }}
          />
          <button
            onClick={() => handleAsk()}
            disabled={loading || !prompt.trim()}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white p-2.5 rounded-lg transition-all cursor-pointer shrink-0"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
