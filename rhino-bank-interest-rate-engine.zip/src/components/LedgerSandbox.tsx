import React, { useState } from "react";
import { 
  CreditCard, ArrowDownCircle, ArrowUpCircle, ClipboardList, 
  Terminal, ShieldAlert, Check, RefreshCw, Layers 
} from "lucide-react";
import { Transaction, AuditLog } from "../types";

const INITIAL_ACCOUNTS = [
  { accountNumber: "ACC-1001", customerId: "CUST-001", type: "easy_access", balance: 12450.50, rate: 0.0325, compounding: "daily", basis: "ACT/365" },
  { accountNumber: "ACC-1002", customerId: "CUST-002", type: "basic_saver", balance: 450.00, rate: 0.0150, compounding: "monthly", basis: "ACT/365" },
  { accountNumber: "ACC-1003", customerId: "CUST-003", type: "notice_account", balance: 75000.00, rate: 0.0450, compounding: "quarterly", basis: "ACT/365" },
  { accountNumber: "ACC-1004", customerId: "CUST-004", type: "junior_saver", balance: 1500.00, rate: 0.0400, compounding: "monthly", basis: "ACT/365" }
];

export default function LedgerSandbox() {
  const [accounts, setAccounts] = useState(INITIAL_ACCOUNTS);
  const [selectedAccIdx, setSelectedAccIdx] = useState(0);
  const activeAcc = accounts[selectedAccIdx];

  // Manual Transactions List
  const [txs, setTxs] = useState<Transaction[]>([
    { id: "TX-INIT", timestamp: new Date(Date.now() - 3600000 * 24).toLocaleString(), type: "deposit", amount: activeAcc.balance, balanceAfter: activeAcc.balance, description: "Initial opening balance synced from CSV database." }
  ]);

  const [txType, setTxType] = useState<"deposit" | "withdrawal">("deposit");
  const [txAmount, setTxAmount] = useState<number>(500);
  const [txDesc, setTxDesc] = useState<string>("Quarterly earnings transfer");

  // Audit Logs output
  const [auditLog, setAuditLog] = useState<AuditLog | null>({
    timestamp: new Date().toISOString(),
    calculationId: "CALC-INIT-8E4B1",
    version: "v1.2.0-compliance",
    operator: "SandboxEngine",
    inputs: {
      productType: activeAcc.type,
      openingBalance: activeAcc.balance,
      currentBalance: activeAcc.balance,
      appliedRate: activeAcc.rate,
      baseRate: activeAcc.rate,
      compoundingRule: activeAcc.compounding,
      dayCountBasis: activeAcc.basis,
      taxStatus: "taxable"
    },
    outputs: {
      grossInterest: 33.72,
      taxWithheld: 6.74,
      netInterest: 26.98,
      finalBalance: activeAcc.balance + 26.98,
      effectiveYield: 0.033
    },
    formulaUsed: "A = P * (1 + r/m)^(m*t)"
  });

  const handlePostTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (txAmount <= 0) return;

    // Boundary rules guard
    if (txType === "withdrawal" && activeAcc.balance - txAmount < 0) {
      alert("Ledger Error: Insufficient funds. Overdraft threshold restricted on basic savings products.");
      return;
    }

    const newBalance = txType === "deposit" 
      ? activeAcc.balance + txAmount 
      : activeAcc.balance - txAmount;

    // Update account balance
    const updatedAccounts = [...accounts];
    updatedAccounts[selectedAccIdx].balance = newBalance;
    setAccounts(updatedAccounts);

    // Append to transactions list
    const newTx: Transaction = {
      id: `TX-${Math.floor(Math.random() * 16777215).toString(16).toUpperCase()}`,
      timestamp: new Date().toLocaleString(),
      type: txType,
      amount: txAmount,
      balanceAfter: newBalance,
      description: txDesc || `${txType.toUpperCase()} of funds.`
    };

    setTxs([newTx, ...txs]);

    // Recalculate immediate interest accruals and generate audit compliance log
    const calcId = `CALC-TX-${Math.floor(Math.random() * 16777215).toString(16).toUpperCase()}`;
    const rate = activeAcc.rate;
    
    // Simulate accrual calculations (over 30 days)
    const accrualDays = 30;
    const fraction = accrualDays / 365;
    const gross = newBalance * rate * fraction;
    const tax = activeAcc.type === "junior_saver" ? 0 : gross * 0.20;
    const net = gross - tax;

    setAuditLog({
      timestamp: new Date().toISOString(),
      calculationId: calcId,
      version: "v1.2.0-compliance",
      operator: "ManualSandboxOperator",
      inputs: {
        productType: activeAcc.type,
        openingBalance: activeAcc.balance,
        currentBalance: newBalance,
        appliedRate: rate,
        baseRate: rate,
        compoundingRule: activeAcc.compounding,
        dayCountBasis: activeAcc.basis,
        taxStatus: activeAcc.type === "junior_saver" ? "exempt" : "taxable"
      },
      outputs: {
        grossInterest: Math.round(gross * 10000) / 10000,
        taxWithheld: Math.round(tax * 100) / 100,
        netInterest: Math.round(net * 10000) / 10000,
        finalBalance: Math.round((newBalance + net) * 100) / 100,
        effectiveYield: rate
      },
      formulaUsed: "A = P * (1 + r/m)^(m*t) [Accrual Days: 30]"
    });

    // Reset fields
    setTxAmount(100);
    setTxDesc("");
  };

  const handleAccountChange = (idx: number) => {
    setSelectedAccIdx(idx);
    const targetAcc = accounts[idx];
    setTxs([
      { id: "TX-INIT", timestamp: new Date().toLocaleString(), type: "deposit", amount: targetAcc.balance, balanceAfter: targetAcc.balance, description: `Initial sync for ACC: ${targetAcc.accountNumber}.` }
    ]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="ledger-sandbox-grid">
      
      {/* 1. Account selection & Ledger poster */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5 h-fit">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <CreditCard className="h-5 w-5 text-indigo-500" />
          <h3 className="font-bold text-slate-800 text-sm tracking-wide uppercase">Core Ledger Poster</h3>
        </div>

        {/* Selected Account Panel */}
        <div className="space-y-1">
          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Choose Active Client Account</label>
          <div className="grid grid-cols-2 gap-1.5 mt-1.5">
            {accounts.map((acc, idx) => (
              <button
                key={acc.accountNumber}
                onClick={() => handleAccountChange(idx)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedAccIdx === idx 
                    ? "border-indigo-600 bg-indigo-50/50 shadow-sm" 
                    : "border-slate-150 bg-white hover:bg-slate-50"
                }`}
              >
                <div className="font-bold text-slate-800 text-xs">{acc.accountNumber}</div>
                <div className="text-[10px] text-slate-400 capitalize mt-0.5">{acc.type.replace("_", " ")}</div>
                <div className="font-mono font-black text-slate-800 text-sm mt-1.5">
                  £{acc.balance.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Ledger entry form */}
        <form onSubmit={handlePostTx} className="pt-4 border-t border-slate-100 space-y-4">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setTxType("deposit")}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold border flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                txType === "deposit" 
                  ? "bg-emerald-50 border-emerald-500 text-emerald-700 font-bold" 
                  : "border-slate-200 bg-white hover:bg-slate-50 text-slate-500"
              }`}
            >
              <ArrowDownCircle className="h-3.5 w-3.5 text-emerald-500" />
              Deposit
            </button>
            <button
              type="button"
              onClick={() => setTxType("withdrawal")}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold border flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                txType === "withdrawal" 
                  ? "bg-rose-50 border-rose-500 text-rose-700 font-bold" 
                  : "border-slate-200 bg-white hover:bg-slate-50 text-slate-500"
              }`}
            >
              <ArrowUpCircle className="h-3.5 w-3.5 text-rose-500" />
              Withdrawal
            </button>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase">Amount (£)</label>
            <input
              type="number"
              min={1}
              step={1}
              value={txAmount}
              onChange={(e) => setTxAmount(Number(e.target.value))}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-700 focus:outline-none focus:border-indigo-500 font-semibold"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase">Description / Memo</label>
            <input
              type="text"
              value={txDesc}
              onChange={(e) => setTxDesc(e.target.value)}
              placeholder="e.g. Salary Credit, ATM, Dividend payout..."
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-600 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer shadow-sm shadow-indigo-200 flex items-center justify-center gap-1.5"
          >
            <Check className="h-4 w-4" />
            Commit Double-Entry Transaction
          </button>
        </form>
      </div>

      {/* 2. Client ledger entries */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col h-[520px]">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
          <ClipboardList className="h-5 w-5 text-indigo-500" />
          <h3 className="font-bold text-slate-800 text-sm tracking-wide uppercase">Transaction History (ACC)</h3>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {txs.map((t) => (
            <div key={t.id} className="p-3 border border-slate-100 hover:border-slate-150 bg-slate-50/50 rounded-xl flex items-start gap-3 transition-all">
              <div className={`p-1.5 rounded-lg ${
                t.type === "deposit" ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
              }`}>
                {t.type === "deposit" ? <ArrowDownCircle className="h-4 w-4" /> : <ArrowUpCircle className="h-4 w-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-800 text-xs">{t.description}</span>
                  <span className={`font-mono text-xs font-black ${
                    t.type === "deposit" ? "text-emerald-600" : "text-rose-600"
                  }`}>
                    {t.type === "deposit" ? "+" : "-"}£{t.amount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1 font-mono">
                  <span>ID: {t.id} • {t.timestamp}</span>
                  <span className="text-slate-600 font-semibold">Bal: £{t.balanceAfter.toLocaleString("en-GB", { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Real-time Compliance Audit Log output */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col h-[520px]">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <Terminal className="h-5 w-5 text-emerald-400" />
            <h3 className="font-bold text-slate-200 text-sm tracking-wide uppercase font-sans">Compliance Accrual Log</h3>
          </div>
          <ShieldAlert className="h-4 w-4 text-amber-500 animate-pulse" title="Compliant with international accounting rules" />
        </div>

        <div className="flex-1 bg-slate-900/50 border border-slate-800/80 rounded-lg p-3 font-mono text-[11px] text-emerald-400 overflow-auto whitespace-pre leading-relaxed scrollbar-thin">
          {auditLog ? JSON.stringify(auditLog, null, 2) : "// Awaiting ledger event commits..."}
        </div>
        
        <div className="mt-3 text-[10px] text-slate-500 font-medium font-sans flex items-center gap-1.5 leading-none">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span>
          Audit Engine active: ACC day count fraction verified (ACT/365).
        </div>
      </div>
    </div>
  );
}
