import React, { useState, useEffect } from "react";
import { 
  PiggyBank, Info, Percent, Calendar, ArrowRight, ShieldCheck, 
  ChevronLeft, ChevronRight, TrendingUp, DollarSign, Activity, Settings2, Download
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";
import { runSavingsForecast } from "../utils/mathEngine";
import { SimulationParams, SimulationOutput, ProductRules } from "../types";

const PRODUCTS: ProductRules[] = [
  { key: "basic_saver", name: "Basic Saver", baseRate: 0.0150, minBalance: 0.00, maxBalance: 25000.00, compounding: "monthly", basis: "ACT/365", withdrawalLimit: 10, fees: 0.00, allowNegative: false },
  { key: "easy_access", name: "Easy Access Saver", baseRate: 0.0325, minBalance: 1.00, maxBalance: 100000.00, compounding: "daily", basis: "ACT/365", withdrawalLimit: -1, fees: 0.00, allowNegative: false },
  { key: "notice_account", name: "90-Day Notice Saver", baseRate: 0.0450, minBalance: 500.00, maxBalance: 250000.00, compounding: "quarterly", basis: "ACT/365", withdrawalLimit: -1, fees: 0.00, allowNegative: false },
  { key: "junior_saver", name: "Junior Saver", baseRate: 0.0400, minBalance: 0.00, maxBalance: 10000.00, compounding: "monthly", basis: "ACT/365", withdrawalLimit: 10, fees: 0.00, allowNegative: false },
  { key: "premium_saver", name: "Premium Saver (High-Yield)", baseRate: 0.0200, minBalance: 1000.00, maxBalance: 500000.00, compounding: "monthly", basis: "ACT/365", withdrawalLimit: 5, fees: 0.00, allowNegative: false, bonusRate: 0.0150 },
  { key: "business_savings", name: "Business Premium Savings", baseRate: 0.0250, minBalance: 10000.00, maxBalance: 5000000.00, compounding: "monthly", basis: "ACT/360", withdrawalLimit: -1, fees: 15.00, allowNegative: false },
  { key: "fixed_term", name: "1-Year Fixed Term Deposit", baseRate: 0.0485, minBalance: 2000.00, maxBalance: 100000.00, compounding: "annual", basis: "ACT/365", withdrawalLimit: 0, fees: 0.00, allowNegative: false },
  { key: "holiday_saver", name: "Holiday Saver Account", baseRate: 0.0350, minBalance: 0.00, maxBalance: 15000.00, compounding: "monthly", basis: "ACT/365", withdrawalLimit: -1, fees: 0.00, allowNegative: false },
  { key: "regular_saver", name: "Regular Monthly Saver", baseRate: 0.0550, minBalance: 10.00, maxBalance: 5000.00, compounding: "monthly", basis: "ACT/365", withdrawalLimit: 2, fees: 0.00, allowNegative: false, maxMonthlyDeposit: 250.00 }
];

export default function SimPlayground() {
  const [selectedProduct, setSelectedProduct] = useState<ProductRules>(PRODUCTS[1]); // Default to Easy Access
  const [initialDeposit, setInitialDeposit] = useState<number>(5000);
  const [monthlyDeposit, setMonthlyDeposit] = useState<number>(200);
  const [years, setYears] = useState<number>(5);
  const [compounding, setCompounding] = useState<any>("daily");
  const [basis, setBasis] = useState<any>("ACT/365");
  const [taxStatus, setTaxStatus] = useState<"taxable" | "exempt">("taxable");
  const [inflationRate, setInflationRate] = useState<number>(0.025); // 2.5% default inflation
  const [rateShock, setRateShock] = useState<number>(0.015); // +1.5% default rate shock (stress-test)

  // Output results
  const [results, setResults] = useState<SimulationOutput | null>(null);

  // Pagination for Ledger
  const [ledgerPage, setLedgerPage] = useState<number>(0);
  const ledgerPerPage = 12; // 1 year per page

  // Re-run simulation when inputs change
  useEffect(() => {
    runSim();
  }, [selectedProduct, initialDeposit, monthlyDeposit, years, compounding, basis, taxStatus, inflationRate, rateShock]);

  const runSim = () => {
    const params: SimulationParams = {
      productKey: selectedProduct.key,
      initialDeposit,
      monthlyDeposit,
      years,
      compounding,
      basis,
      taxStatus,
      inflationRate,
      rateShock
    };

    const out = runSavingsForecast(params, selectedProduct.baseRate);
    setResults(out);
  };

  const handleProductChange = (key: string) => {
    const prod = PRODUCTS.find(p => p.key === key);
    if (prod) {
      setSelectedProduct(prod);
      setCompounding(prod.compounding);
      setBasis(prod.basis);
      setTaxStatus(prod.key === "junior_saver" ? "exempt" : "taxable");
      
      // Auto adjust bounds if needed
      if (initialDeposit < prod.minBalance) {
        setInitialDeposit(prod.minBalance);
      }
      if (prod.maxMonthlyDeposit && monthlyDeposit > prod.maxMonthlyDeposit) {
        setMonthlyDeposit(prod.maxMonthlyDeposit);
      }
    }
  };

  const downloadCSV = () => {
    if (!results) return;
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Month,Date,Monthly Contribution,Cumulative Deposits,Interest This Month,Cumulative Interest,Ending Balance,Shocked Balance,Real Ending Balance\n";
    
    results.ledger.forEach(entry => {
      csvContent += `${entry.month},${entry.date},${entry.contribution},${entry.cumulativeDeposits},${entry.interestThisMonth},${entry.cumulativeInterest},${entry.endingBalance},${entry.shockedBalance},${entry.realEndingBalance}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Rhino_Savings_Forecast_${selectedProduct.key}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter line chart data (take every 3 months or so for long projections to keep chart crisp)
  const getChartData = () => {
    if (!results) return [];
    if (years <= 3) return results.ledger;
    // For 5+ years, sample quarterly (every 3 months) to keep graph visually balanced
    return results.ledger.filter((_, idx) => idx % 3 === 0 || idx === results.ledger.length - 1);
  };

  // Pagination handlers
  const totalPages = results ? Math.ceil(results.ledger.length / ledgerPerPage) : 0;
  const currentLedgerPage = results 
    ? results.ledger.slice(ledgerPage * ledgerPerPage, (ledgerPage + 1) * ledgerPerPage)
    : [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="sim-playground-grid">
      
      {/* 1. Control Panel Sidebar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5 h-fit">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Settings2 className="h-5 w-5 text-indigo-500" />
          <h3 className="font-bold text-slate-800 text-sm tracking-wide uppercase">Simulation Rules</h3>
        </div>

        {/* Product Dropdown */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Savings Product</label>
          <select
            value={selectedProduct.key}
            onChange={(e) => handleProductChange(e.target.value)}
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-700 bg-white font-medium focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            {PRODUCTS.map(p => (
              <option key={p.key} value={p.key}>
                {p.name} ({(p.baseRate * 100).toFixed(2)}% APY)
              </option>
            ))}
          </select>
          <div className="flex items-center gap-1.5 text-[10.5px] text-slate-400 bg-slate-50 p-2 rounded border border-slate-100">
            <Info className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
            <span>
              Limits: £{selectedProduct.minBalance.toLocaleString()} - £{selectedProduct.maxBalance.toLocaleString()}. Accrual basis: <strong>{selectedProduct.basis}</strong>.
            </span>
          </div>
        </div>

        {/* Slider Controls */}
        <div className="space-y-4 pt-1">
          {/* Initial deposit */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-500 uppercase tracking-wider">Initial Deposit (£)</span>
              <span className="font-bold text-indigo-600 font-mono">£{initialDeposit.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min={Math.max(selectedProduct.minBalance, 100)}
              max={selectedProduct.maxBalance === 5000000 ? 500000 : selectedProduct.maxBalance}
              step={100}
              value={initialDeposit}
              onChange={(e) => setInitialDeposit(Number(e.target.value))}
              className="w-full h-1 bg-slate-150 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>

          {/* Monthly contribution */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-500 uppercase tracking-wider">Monthly Recurring Deposit (£)</span>
              <span className="font-bold text-indigo-600 font-mono">£{monthlyDeposit.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min={0}
              max={selectedProduct.maxMonthlyDeposit || 1000}
              step={10}
              value={monthlyDeposit}
              onChange={(e) => setMonthlyDeposit(Number(e.target.value))}
              className="w-full h-1 bg-slate-150 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            {selectedProduct.maxMonthlyDeposit && (
              <div className="text-[10px] text-slate-400 italic">
                * Max allowed monthly deposit for Regular Saver is £{selectedProduct.maxMonthlyDeposit}.
              </div>
            )}
          </div>

          {/* Simulation duration */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-500 uppercase tracking-wider">Calculation Period (Years)</span>
              <span className="font-bold text-indigo-600 font-mono">{years} Years</span>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              step={1}
              value={years}
              onChange={(e) => setYears(Number(e.target.value))}
              className="w-full h-1 bg-slate-150 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
          </div>
        </div>

        {/* Advanced Financial Adjustments */}
        <div className="pt-3 border-t border-slate-100 space-y-4">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Advanced Regimes</div>

          {/* Tax status */}
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-600">Withholding Tax (Standard 20%)</span>
            <div className="flex rounded-md overflow-hidden border border-slate-200">
              <button
                onClick={() => setTaxStatus("taxable")}
                className={`px-2.5 py-1 text-[11px] font-bold ${taxStatus === "taxable" ? "bg-indigo-600 text-white" : "bg-white text-slate-500"} cursor-pointer`}
              >
                Taxable
              </button>
              <button
                onClick={() => setTaxStatus("exempt")}
                className={`px-2.5 py-1 text-[11px] font-bold ${taxStatus === "exempt" ? "bg-indigo-600 text-white" : "bg-white text-slate-500"} cursor-pointer`}
              >
                Tax-Exempt
              </button>
            </div>
          </div>

          {/* Compounding & Day Basis override */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Compounding Frequency</label>
              <select
                value={compounding}
                onChange={(e) => setCompounding(e.target.value)}
                className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs bg-white text-slate-700 cursor-pointer"
              >
                <option value="simple">Simple Interest</option>
                <option value="daily">Daily Compound</option>
                <option value="weekly">Weekly Compound</option>
                <option value="monthly">Monthly Compound</option>
                <option value="quarterly">Quarterly Compound</option>
                <option value="annual">Annual Compound</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Day Count Convention</label>
              <select
                value={basis}
                onChange={(e) => setBasis(e.target.value as any)}
                className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs bg-white text-slate-700 cursor-pointer"
              >
                <option value="ACT/365">ACT/365</option>
                <option value="ACT/366">ACT/366</option>
                <option value="ACT/360">ACT/360 (Corporate)</option>
                <option value="30/360">30/360 (ISDA)</option>
                <option value="ACT/ACT">ACT/ACT (Automatic)</option>
              </select>
            </div>
          </div>

          {/* Stress shocks */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Annualized Inflation (%)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="15"
                value={(inflationRate * 100).toFixed(1)}
                onChange={(e) => setInflationRate(Number(e.target.value) / 100)}
                className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-700 font-semibold"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Rate Shock Shift (%)</label>
              <input
                type="number"
                step="0.1"
                min="-5"
                max="5"
                value={(rateShock * 100).toFixed(1)}
                onChange={(e) => setRateShock(Number(e.target.value) / 100)}
                className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-700 font-semibold"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 2. Dashboard Analytics & Charts Panel */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Metric Summary Blocks */}
        {results && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4" id="sim-metrics">
            {/* Ending balance card */}
            <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col justify-between">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">Projected Cash Balance</span>
              <div className="mt-2 text-2xl font-black text-indigo-600 font-mono">
                £{results.finalBalance.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <span className="text-[10px] text-slate-400 mt-1 leading-none">After net compounding</span>
            </div>

            {/* Net interest card */}
            <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col justify-between">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">Net Interest Earned</span>
              <div className="mt-2 text-2xl font-black text-emerald-600 font-mono">
                £{results.netInterest.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <span className="text-[10px] text-slate-400 mt-1 leading-none">Net of withholding tax</span>
            </div>

            {/* Effective Yield card */}
            <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col justify-between col-span-2 md:col-span-1">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">Effective Annual Yield</span>
              <div className="mt-2 text-2xl font-black text-amber-500 font-mono">
                {(results.effectiveAnnualYield * 100).toFixed(4)}%
              </div>
              <span className="text-[10px] text-slate-400 mt-1 leading-none">True rate of return (EAR)</span>
            </div>
          </div>
        )}

        {/* Interactive Growth Projection Chart */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <div className="flex items-center gap-1.5">
              <TrendingUp className="h-4 w-5 text-indigo-500" />
              <h4 className="font-bold text-slate-800 text-sm">Long-term Growth & Stress Scenario Analysis</h4>
            </div>
            <div className="text-[10px] text-slate-400 italic">Compounded {compounding}</div>
          </div>

          <div className="h-64 md:h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={getChartData()} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={10} tickLine={false} label={{ value: 'Month of savings', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} tickFormatter={(val) => `£${val}`} />
                <Tooltip 
                  formatter={(value: any) => [`£${Number(value).toLocaleString("en-GB", { minimumFractionDigits: 2 })}`, '']}
                  labelFormatter={(label) => `Month: ${label}`}
                  contentStyle={{ backgroundColor: "#0f172a", borderRadius: "8px", border: "none", color: "#f8fafc", fontSize: "11px" }}
                />
                <Legend verticalAlign="top" height={36} iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", color: "#64748b" }} />
                <Line type="monotone" dataKey="endingBalance" name="Base Scenario" stroke="#4f46e5" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="shockedBalance" name={`Rate Shock Shift (+${(rateShock*100).toFixed(1)}%)`} stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                <Line type="monotone" dataKey="realEndingBalance" name={`Inflation Adjusted (${(inflationRate*100).toFixed(1)}%)`} stroke="#ef4444" strokeWidth={1.5} strokeDasharray="2 2" dot={false} />
                <Line type="monotone" dataKey="cumulativeDeposits" name="Net Principal Contribution" stroke="#94a3b8" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Ledger table panel */}
        {results && (
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-1.5">
                <Activity className="h-4.5 w-4.5 text-indigo-500" />
                <h4 className="font-bold text-slate-800 text-sm">Amortized Forecast Schedule Ledger</h4>
              </div>
              <button
                onClick={downloadCSV}
                className="text-indigo-600 hover:text-indigo-500 font-semibold text-xs flex items-center gap-1 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Export CSV
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-500 uppercase font-bold tracking-wider text-[10px] border-b border-slate-250">
                  <tr>
                    <th className="px-4 py-2.5 text-center">Month</th>
                    <th className="px-4 py-2.5">Accrual Date</th>
                    <th className="px-4 py-2.5 text-right">Contribution</th>
                    <th className="px-4 py-2.5 text-right">Deposits Total</th>
                    <th className="px-4 py-2.5 text-right">Interest (Net)</th>
                    <th className="px-4 py-2.5 text-right">Accrued Cumulative</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Ending Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 font-mono text-[11px] text-slate-600">
                  {currentLedgerPage.map((entry) => (
                    <tr key={entry.month} className="hover:bg-slate-50/50">
                      <td className="px-4 py-2 text-center text-slate-400 font-bold">{entry.month}</td>
                      <td className="px-4 py-2 font-sans text-slate-700 font-medium">{entry.date}</td>
                      <td className="px-4 py-2 text-right text-slate-500">
                        {entry.contribution > 0 ? `£${entry.contribution.toLocaleString()}` : "-"}
                      </td>
                      <td className="px-4 py-2 text-right">£{entry.cumulativeDeposits.toLocaleString()}</td>
                      <td className="px-4 py-2 text-right text-emerald-600">
                        {entry.interestThisMonth > 0 ? `£${entry.interestThisMonth.toFixed(2)}` : "-"}
                      </td>
                      <td className="px-4 py-2 text-right text-emerald-600">
                        {entry.cumulativeInterest > 0 ? `£${entry.cumulativeInterest.toLocaleString()}` : "-"}
                      </td>
                      <td className="px-4 py-2 text-right font-bold text-slate-800">
                        £{entry.endingBalance.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Table pagination controls */}
            <div className="px-5 py-2.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <span className="text-[10.5px] text-slate-500">
                Page <strong>{ledgerPage + 1}</strong> of <strong>{totalPages}</strong> (Year {ledgerPage + 1})
              </span>
              <div className="flex gap-1">
                <button
                  onClick={() => setLedgerPage(prev => Math.max(0, prev - 1))}
                  disabled={ledgerPage === 0}
                  className="p-1 rounded border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setLedgerPage(prev => Math.min(totalPages - 1, prev + 1))}
                  disabled={ledgerPage === totalPages - 1}
                  className="p-1 rounded border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
