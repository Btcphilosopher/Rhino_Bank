export interface RFile {
  path: string;
  name: string;
  content: string;
}

export interface ProductRules {
  key: string;
  name: string;
  baseRate: number;
  minBalance: number;
  maxBalance: number;
  compounding: "simple" | "daily" | "weekly" | "monthly" | "quarterly" | "semi-annual" | "annual";
  basis: "ACT/365" | "ACT/366" | "ACT/360" | "30/360" | "ACT/ACT";
  withdrawalLimit: number;
  fees: number;
  allowNegative: boolean;
  termMonths?: number;
  penaltyRate?: number;
  maxMonthlyDeposit?: number;
  bonusRate?: number;
}

export interface SimulationParams {
  productKey: string;
  initialDeposit: number;
  monthlyDeposit: number;
  years: number;
  compounding: "simple" | "daily" | "weekly" | "monthly" | "quarterly" | "semi-annual" | "annual";
  basis: "ACT/365" | "ACT/366" | "ACT/360" | "30/360" | "ACT/ACT";
  taxStatus: "taxable" | "exempt";
  inflationRate: number;
  rateShock: number;
}

export interface LedgerEntry {
  month: number;
  date: string;
  contribution: number;
  cumulativeDeposits: number;
  interestThisMonth: number;
  cumulativeInterest: number;
  endingBalance: number;
  shockedBalance: number;
  realEndingBalance: number;
}

export interface SimulationOutput {
  totalDeposits: number;
  grossInterest: number;
  taxWithheld: number;
  netInterest: number;
  finalBalance: number;
  finalShockedBalance: number;
  finalRealBalance: number;
  effectiveAnnualYield: number;
  ledger: LedgerEntry[];
  auditLog: AuditLog;
}

export interface Transaction {
  id: string;
  timestamp: string;
  type: "deposit" | "withdrawal" | "transfer" | "interest_credit" | "interest_reversal" | "fee_deduction";
  amount: number;
  balanceAfter: number;
  description: string;
}

export interface AuditLog {
  timestamp: string;
  calculationId: string;
  version: string;
  operator: string;
  inputs: {
    productType: string;
    openingBalance: number;
    currentBalance: number;
    appliedRate: number;
    baseRate: number;
    compoundingRule: string;
    dayCountBasis: string;
    taxStatus: string;
  };
  outputs: {
    grossInterest: number;
    taxWithheld: number;
    netInterest: number;
    finalBalance: number;
    effectiveYield: number;
  };
  formulaUsed: string;
}
