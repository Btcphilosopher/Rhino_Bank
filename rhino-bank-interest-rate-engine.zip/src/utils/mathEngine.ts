import { SimulationParams, SimulationOutput, LedgerEntry, AuditLog } from "../types";

export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}

export function getDayCountFraction(
  startDate: Date,
  endDate: Date,
  basis: "ACT/365" | "ACT/366" | "ACT/360" | "30/360" | "ACT/ACT"
): { daysAccrued: number; denominator: number; fraction: number } {
  const diffTime = endDate.getTime() - startDate.getTime();
  let daysAccrued = Math.round(diffTime / (1000 * 60 * 60 * 24));
  if (daysAccrued < 0) daysAccrued = 0;

  let denominator = 365;
  if (basis === "ACT/365") {
    denominator = 365;
  } else if (basis === "ACT/366") {
    denominator = 366;
  } else if (basis === "ACT/360") {
    denominator = 360;
  } else if (basis === "ACT/ACT") {
    const isLeap = isLeapYear(startDate.getFullYear()) || isLeapYear(endDate.getFullYear());
    denominator = isLeap ? 366 : 365;
  } else if (basis === "30/360") {
    let d1 = startDate.getDate();
    let m1 = startDate.getMonth() + 1;
    let y1 = startDate.getFullYear();

    let d2 = endDate.getDate();
    let m2 = endDate.getMonth() + 1;
    let y2 = endDate.getFullYear();

    if (d1 === 31) d1 = 30;
    if (d2 === 31 && d1 >= 30) d2 = 30;

    daysAccrued = 360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1);
    denominator = 360;
  }

  return {
    daysAccrued,
    denominator,
    fraction: daysAccrued / denominator,
  };
}

// Map compounding frequency name to numeric cycles per year
export function getCompoundingPeriodsPerYear(frequency: string, denominator: number = 365): number {
  switch (frequency) {
    case "daily": return denominator;
    case "weekly": return 52;
    case "monthly": return 12;
    case "quarterly": return 4;
    case "semi-annual": return 2;
    case "annual": return 1;
    default: return 12;
  }
}

export function calculateSinglePeriodInterest(
  balance: number,
  rate: number,
  compounding: string,
  basis: "ACT/365" | "ACT/366" | "ACT/360" | "30/360" | "ACT/ACT",
  startDate: Date,
  endDate: Date
): { interestEarned: number; yield: number; formula: string } {
  const { daysAccrued, denominator, fraction } = getDayCountFraction(startDate, endDate, basis);

  if (compounding === "simple") {
    const interest = balance * rate * fraction;
    return {
      interestEarned: interest,
      yield: rate,
      formula: "I = P * r * t (Simple Interest)"
    };
  }

  const m = getCompoundingPeriodsPerYear(compounding, denominator);
  const t = fraction;
  const nPeriods = t * m;

  // A = P * (1 + r/m)^(m*t)
  const finalBalance = balance * Math.pow(1 + rate / m, nPeriods);
  const interestEarned = finalBalance - balance;

  // Effective Annual Yield = (1 + r/m)^m - 1
  const effYield = Math.pow(1 + rate / m, m) - 1;

  return {
    interestEarned,
    yield: effYield,
    formula: `A = P * (1 + r/m)^(m*t) (${compounding} compounding)`
  };
}

export function runSavingsForecast(params: SimulationParams, baseRate: number): SimulationOutput {
  const {
    productKey,
    initialDeposit,
    monthlyDeposit,
    years,
    compounding,
    basis,
    taxStatus,
    inflationRate,
    rateShock
  } = params;

  const totalMonths = years * 12;
  const ledger: LedgerEntry[] = [];
  
  let currentBalance = initialDeposit;
  let currentShockedBalance = initialDeposit;
  let currentRealBalance = initialDeposit;
  
  let cumulativeDeposits = initialDeposit;
  let cumulativeInterest = 0;
  
  // Base Date
  const startDate = new Date();

  // Month 0
  ledger.push({
    month: 0,
    date: startDate.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" }),
    contribution: initialDeposit,
    cumulativeDeposits: initialDeposit,
    interestThisMonth: 0,
    cumulativeInterest: 0,
    endingBalance: initialDeposit,
    shockedBalance: initialDeposit,
    realEndingBalance: initialDeposit,
  });

  const appliedRate = baseRate;
  const shockedRate = baseRate + rateShock;

  for (let m = 1; m <= totalMonths; m++) {
    const periodStart = new Date(startDate);
    periodStart.setMonth(startDate.getMonth() + m - 1);
    const periodEnd = new Date(startDate);
    periodEnd.setMonth(startDate.getMonth() + m);

    // Calculate normal interest
    const baseCalc = calculateSinglePeriodInterest(
      currentBalance,
      appliedRate,
      compounding,
      basis,
      periodStart,
      periodEnd
    );
    const interest = baseCalc.interestEarned;

    // Calculate shocked interest
    const shockCalc = calculateSinglePeriodInterest(
      currentShockedBalance,
      shockedRate,
      compounding,
      basis,
      periodStart,
      periodEnd
    );
    const shockedInterest = shockCalc.interestEarned;

    // Deduct standard withholding tax (20%) if taxable
    const taxRate = taxStatus === "taxable" ? 0.20 : 0.00;
    const netInterest = interest * (1 - taxRate);
    const netShockedInterest = shockedInterest * (1 - taxRate);

    // End-of-month contribution
    const monthlyContribution = monthlyDeposit;
    
    // Accumulators
    currentBalance += netInterest + monthlyContribution;
    currentShockedBalance += netShockedInterest + monthlyContribution;
    
    cumulativeDeposits += monthlyContribution;
    cumulativeInterest += netInterest;

    // Adjust ending balance for cumulative inflation
    const cumulativeInflationFactor = Math.pow(1 + inflationRate, m / 12);
    currentRealBalance = currentBalance / cumulativeInflationFactor;

    ledger.push({
      month: m,
      date: periodEnd.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" }),
      contribution: monthlyContribution,
      cumulativeDeposits: Math.round(cumulativeDeposits * 100) / 100,
      interestThisMonth: Math.round(netInterest * 10000) / 10000,
      cumulativeInterest: Math.round(cumulativeInterest * 100) / 100,
      endingBalance: Math.round(currentBalance * 100) / 100,
      shockedBalance: Math.round(currentShockedBalance * 100) / 100,
      realEndingBalance: Math.round(currentRealBalance * 100) / 100,
    });
  }

  // Final aggregations
  const totalDeposits = cumulativeDeposits;
  const grossInterest = cumulativeInterest / (1 - (taxStatus === "taxable" ? 0.20 : 0.00));
  const taxWithheld = grossInterest * (taxStatus === "taxable" ? 0.20 : 0.00);
  const netInterest = cumulativeInterest;

  // Single calculation ID for compliance
  const calcId = `CALC-JS-${Math.floor(Math.random() * 16777215).toString(16).toUpperCase()}`;

  const auditLog: AuditLog = {
    timestamp: new Date().toISOString(),
    calculationId: calcId,
    version: "v1.2.0-compliance",
    operator: "SimulatedJSModel",
    inputs: {
      productType: productKey,
      openingBalance: initialDeposit,
      currentBalance: currentBalance - netInterest,
      appliedRate: appliedRate,
      baseRate: baseRate,
      compoundingRule: compounding,
      dayCountBasis: basis,
      taxStatus: taxStatus
    },
    outputs: {
      grossInterest: Math.round(grossInterest * 10000) / 10000,
      taxWithheld: Math.round(taxWithheld * 100) / 100,
      netInterest: Math.round(netInterest * 10000) / 10000,
      finalBalance: Math.round(currentBalance * 100) / 100,
      effectiveYield: Math.round((Math.pow(1 + appliedRate / (compounding === "simple" ? 1 : 12), compounding === "simple" ? 1 : 12) - 1) * 10000) / 10000
    },
    formulaUsed: compounding === "simple" ? "I = P * r * t" : "A = P * (1 + r/m)^(m*t)"
  };

  return {
    totalDeposits,
    grossInterest,
    taxWithheld,
    netInterest,
    finalBalance: currentBalance,
    finalShockedBalance: currentShockedBalance,
    finalRealBalance: currentRealBalance,
    effectiveAnnualYield: Math.pow(1 + appliedRate / (compounding === "simple" ? 1 : 12), compounding === "simple" ? 1 : 12) - 1,
    ledger,
    auditLog
  };
}
