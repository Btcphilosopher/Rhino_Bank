'use client';

import React, { useState } from 'react';
import { ShieldAlert, CheckCircle, XCircle, Sliders, Settings } from 'lucide-react';

export default function ConnectionLab() {
  // Connection Inputs
  const [connectionType, setConnectionType] = useState<'moment' | 'shear'>('moment');
  const [beamSection, setBeamSection] = useState<'UB406' | 'UB533' | 'UB610'>('UB533');
  const [boltSize, setBoltSize] = useState<'M16' | 'M20' | 'M24' | 'M30'>('M24');
  const [boltCount, setBoltCount] = useState<number>(6); // 4, 6, 8, 10
  const [plateThickness, setPlateThickness] = useState<number>(20); // 12, 15, 20, 25, 30
  const [weldThroat, setWeldThroat] = useState<number>(8); // 4, 6, 8, 10, 12

  // Load Inputs
  const [momentLoad, setMomentLoad] = useState<number>(280); // MEd in kNm (0 - 600)
  const [shearLoad, setShearLoad] = useState<number>(120); // VEd in kN (0 - 300)
  const [axialLoad, setAxialLoad] = useState<number>(45); // NEd in kN (0 - 200)

  // Section details
  const sectionProps = {
    UB406: { d: 406.4, b: 177.9, tf: 12.8, tw: 7.7, zx: 1370 }, // depth, width, flange, web, plastic modulus cm3
    UB533: { d: 533.1, b: 209.3, tf: 15.6, tw: 10.1, zx: 2480 },
    UB610: { d: 610.1, b: 228.6, tf: 17.7, tw: 11.3, zx: 3280 }
  };

  const selectedProps = sectionProps[beamSection];

  // Connection capacities (Approximate BS EN 1993 formulas for educational demo)
  const getBoltCapacity = () => {
    // Single bolt shear capacities (S355 grade, 8.8 bolt grade) in kN
    const capacities = { M16: 60.3, M20: 94.1, M24: 136.0, M30: 215.0 };
    return capacities[boltSize];
  };

  const getBoltTensionCapacity = () => {
    // Bolt tension capacity in kN (Grade 8.8)
    const capacities = { M16: 90.4, M20: 141.0, M24: 203.0, M30: 322.0 };
    return capacities[boltSize];
  };

  // Stress utilization calculation
  const boltShearCapacityTotal = getBoltCapacity() * boltCount;
  const boltTensionCapacityTotal = getBoltTensionCapacity() * (boltCount / 2); // Assume half of the bolts are in tension zone for moment loading

  // Combined utilization math:
  // 1. Shear utilisation = VEd / ShearCapacity
  const shearUtil = shearLoad / boltShearCapacityTotal;
  
  // 2. Moment tension utilisation (from MEd + NEd)
  // Approximate equivalent tension from moment: T = MEd / LeverArm (assume lever arm ~ 0.8 * beam depth)
  const leverArm = (selectedProps.d * 0.8) / 1000; // in meters
  const tensionFromMoment = momentLoad / leverArm + (axialLoad > 0 ? axialLoad : 0);
  const tensionUtil = tensionFromMoment / boltTensionCapacityTotal;

  // 3. Plate thickness utilization (bending stress in plate)
  const plateBendingCapacity = (plateThickness * plateThickness * 355) / (4 * 1000); // simplified limit kNm
  const plateBendingLoad = (momentLoad * 0.15); // scaled bending in flange proximity
  const plateUtil = plateBendingLoad / plateBendingCapacity;

  // 4. Weld stress utilization
  const weldArea = 2 * (selectedProps.d + selectedProps.b) * weldThroat; // simplified perimeter weld in mm2
  const weldCapacity = (weldArea * 250) / 1000; // kN S355
  const weldLoad = Math.sqrt(shearLoad * shearLoad + (momentLoad / leverArm) * (momentLoad / leverArm));
  const weldUtil = weldLoad / weldCapacity;

  // Total Peak Utilisation
  const peakUtil = Math.max(
    shearUtil + tensionUtil, // interaction of bolt tension/shear
    plateUtil,
    weldUtil
  );

  const isPassed = peakUtil <= 1.00;

  return (
    <section className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col gap-3 mb-16 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
            <span className="font-mono text-xs font-bold tracking-widest text-orange-500">ENGINEERING SIMULATOR</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
            CONNECTION LAB
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            Interactive analytical proof tool. Test various joint arrangements, plates, fasteners, and weld boundaries under live moment, shear, and axial forces.
          </p>
        </div>

        {/* Lab Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left: Input parameters & Sliders (col-span-4) */}
          <div className="lg:col-span-4 bg-zinc-900 border border-zinc-800 p-8 flex flex-col gap-6">
            
            <div className="flex items-center gap-2 border-b border-zinc-800 pb-3 mb-2">
              <Sliders className="h-4.5 w-4.5 text-orange-500" />
              <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-100">
                PARAMETERS
              </h3>
            </div>

            {/* Connection Type */}
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">JOINT CATEGORY</label>
              <div className="grid grid-cols-2 gap-2 bg-zinc-950 p-1 border border-zinc-850">
                <button
                  onClick={() => setConnectionType('moment')}
                  className={`py-1.5 font-mono text-[10px] font-bold tracking-widest transition-colors ${connectionType === 'moment' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'}`}
                >
                  MOMENT JOINT
                </button>
                <button
                  onClick={() => setConnectionType('shear')}
                  className={`py-1.5 font-mono text-[10px] font-bold tracking-widest transition-colors ${connectionType === 'shear' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'}`}
                >
                  SHEAR JOINT
                </button>
              </div>
            </div>

            {/* Member Profile */}
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">BEAM SECTION</label>
              <select
                value={beamSection}
                onChange={(e) => setBeamSection(e.target.value as any)}
                className="bg-zinc-950 font-mono text-xs text-zinc-200 p-2.5 border border-zinc-850 outline-none focus:border-orange-500"
              >
                <option value="UB406">UB 406 × 178 × 74 (d=406.4mm)</option>
                <option value="UB533">UB 533 × 210 × 109 (d=533.1mm)</option>
                <option value="UB610">UB 610 × 229 × 113 (d=610.1mm)</option>
              </select>
            </div>

            {/* Fasteners */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">BOLT SIZE</label>
                <select
                  value={boltSize}
                  onChange={(e) => setBoltSize(e.target.value as any)}
                  className="bg-zinc-950 font-mono text-xs text-zinc-200 p-2 border border-zinc-850 outline-none focus:border-orange-500"
                >
                  <option value="M16">M16 (8.8)</option>
                  <option value="M20">M20 (8.8)</option>
                  <option value="M24">M24 (8.8)</option>
                  <option value="M30">M30 (8.8)</option>
                </select>
              </div>
              
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">BOLT COUNT</label>
                <select
                  value={boltCount}
                  onChange={(e) => setBoltCount(Number(e.target.value))}
                  className="bg-zinc-950 font-mono text-xs text-zinc-200 p-2 border border-zinc-850 outline-none focus:border-orange-500"
                >
                  <option value={4}>4 Bolts</option>
                  <option value={6}>6 Bolts</option>
                  <option value={8}>8 Bolts</option>
                  <option value={10}>10 Bolts</option>
                </select>
              </div>
            </div>

            {/* Plate & Weld */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">ENDPLATE (t)</label>
                <select
                  value={plateThickness}
                  onChange={(e) => setPlateThickness(Number(e.target.value))}
                  className="bg-zinc-950 font-mono text-xs text-zinc-200 p-2 border border-zinc-850 outline-none focus:border-orange-500"
                >
                  <option value={12}>12 mm</option>
                  <option value={15}>15 mm</option>
                  <option value={20}>20 mm</option>
                  <option value={25}>25 mm</option>
                  <option value={30}>30 mm</option>
                </select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">WELD THROAT (a)</label>
                <select
                  value={weldThroat}
                  onChange={(e) => setWeldThroat(Number(e.target.value))}
                  className="bg-zinc-950 font-mono text-xs text-zinc-200 p-2 border border-zinc-850 outline-none focus:border-orange-500"
                >
                  <option value={4}>4 mm fillet</option>
                  <option value={6}>6 mm fillet</option>
                  <option value={8}>8 mm fillet</option>
                  <option value={10}>10 mm fillet</option>
                  <option value={12}>12 mm fillet</option>
                </select>
              </div>
            </div>

            {/* Live Sliders for Applied Loads */}
            <div className="border-t border-zinc-800 pt-4 flex flex-col gap-4">
              <span className="font-mono text-[10px] text-orange-500 font-bold tracking-wider">APPLIED LOADS</span>

              {/* Moment */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between font-mono text-[11px] text-zinc-400">
                  <span>MEd (Design Moment)</span>
                  <span className="font-bold text-zinc-100">{momentLoad} kNm</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={600}
                  value={momentLoad}
                  disabled={connectionType === 'shear'}
                  onChange={(e) => setMomentLoad(Number(e.target.value))}
                  className="w-full accent-orange-500 h-1 bg-zinc-950 outline-none rounded-none"
                />
              </div>

              {/* Shear */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between font-mono text-[11px] text-zinc-400">
                  <span>VEd (Design Shear)</span>
                  <span className="font-bold text-zinc-100">{shearLoad} kN</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={300}
                  value={shearLoad}
                  onChange={(e) => setShearLoad(Number(e.target.value))}
                  className="w-full accent-orange-500 h-1 bg-zinc-950 outline-none rounded-none"
                />
              </div>

              {/* Axial */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between font-mono text-[11px] text-zinc-400">
                  <span>NEd (Axial Tension)</span>
                  <span className="font-bold text-zinc-100">{axialLoad} kN</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={axialLoad}
                  onChange={(e) => setAxialLoad(Number(e.target.value))}
                  className="w-full accent-orange-500 h-1 bg-zinc-950 outline-none rounded-none"
                />
              </div>
            </div>

          </div>

          {/* Center: Dynamic Technical CAD-style SVG Diagram (col-span-5) */}
          <div className="lg:col-span-5 bg-zinc-950 border border-zinc-800 flex flex-col justify-between relative overflow-hidden select-none">
            
            {/* Diagram Heading */}
            <div className="bg-zinc-900 border-b border-zinc-800 px-4 py-2 flex justify-between font-mono text-[9px] text-zinc-500">
              <span>JOINT ELEVATION CROSS SECTION (SCALE 1:10)</span>
              <span>S355 REINFORCED PLATE</span>
            </div>

            {/* SVG Drawing Canvas */}
            <div className="flex-grow flex items-center justify-center p-6 h-[320px]">
              <svg viewBox="0 0 320 300" className="w-full h-full max-h-[300px]">
                {/* Background Grid paper lines */}
                <pattern id="millimeter-grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#121217" strokeWidth="0.5"/>
                </pattern>
                <rect width="320" height="300" fill="url(#millimeter-grid)" />

                {/* Left Column flange silhouette boundary */}
                <line x1="60" y1="10" x2="60" y2="290" stroke="#27272a" strokeWidth="6" />
                <line x1="50" y1="10" x2="50" y2="290" stroke="#18181b" strokeWidth="2" />
                
                {/* Endplate (Orange accent plate!) */}
                <rect
                  x="60"
                  y="40"
                  width={plateThickness * 0.5}
                  height="220"
                  fill="#f97316"
                  opacity="0.9"
                  stroke="#ffffff"
                  strokeWidth="0.5"
                />
                
                {/* Welds (Small red fillet representations at intersection) */}
                <path d={`M ${60 + plateThickness * 0.5} 80 L ${66 + plateThickness * 0.5} 80 L ${60 + plateThickness * 0.5} 74 Z`} fill="#ef4444" />
                <path d={`M ${60 + plateThickness * 0.5} 220 L ${66 + plateThickness * 0.5} 220 L ${60 + plateThickness * 0.5} 226 Z`} fill="#ef4444" />

                {/* Beam Flanges & Web Profile projecting to the right */}
                {/* Depth scaling offset based on d */}
                {(() => {
                  const beamH = selectedProps.d * 0.3; // Scale depth
                  const topFlangeY = 150 - beamH / 2;
                  const btmFlangeY = 150 + beamH / 2;
                  return (
                    <g stroke="#71717a" strokeWidth="2.5" fill="none">
                      {/* Web */}
                      <line x1={60 + plateThickness * 0.5} y1="150" x2="280" y2="150" strokeWidth={selectedProps.tw * 0.3} stroke="#52525b" />
                      {/* Flanges */}
                      <line x1={60 + plateThickness * 0.5} y1={topFlangeY} x2="280" y2={topFlangeY} strokeWidth={selectedProps.tf * 0.3} />
                      <line x1={60 + plateThickness * 0.5} y1={btmFlangeY} x2="280" y2={btmFlangeY} strokeWidth={selectedProps.tf * 0.3} />
                      
                      {/* Dimension labels */}
                      <text x="180" y={topFlangeY - 8} fill="#a1a1aa" fontSize="9" fontFamily="monospace" textAnchor="middle" stroke="none">
                        {selectedProps.d} mm Depth
                      </text>
                    </g>
                  );
                })()}

                {/* Bolts drawing dynamically */}
                {(() => {
                  const bolts = [];
                  const boltSpacing = 200 / (boltCount - 1);
                  for (let i = 0; i < boltCount; i++) {
                    const bY = 50 + i * boltSpacing;
                    bolts.push(
                      <g key={i}>
                        {/* Bolt core thread passing endplate */}
                        <line x1="50" y1={bY} x2={60 + plateThickness * 0.5 + 8} y2={bY} stroke="#ffffff" strokeWidth="3" />
                        {/* Bolt head left */}
                        <rect x="44" y={bY - 4} width="6" height="8" fill="#e4e4e7" stroke="#000" strokeWidth="0.5" />
                        {/* Nut right */}
                        <rect x={60 + plateThickness * 0.5 + 2} y={bY - 5} width="6" height="10" fill="#a1a1aa" stroke="#000" strokeWidth="0.5" />
                      </g>
                    );
                  }
                  return bolts;
                })()}

                {/* Load Forces Vector Indicators overlay */}
                <g stroke="#ef4444" strokeWidth="2" fill="#ef4444">
                  {/* Shear Force Red Arrow */}
                  <line x1="260" y1="120" x2="260" y2="180" />
                  <path d="M 260 180 L 256 172 L 264 172 Z" />
                  
                  {/* Moment bending turning loop arrow */}
                  {connectionType === 'moment' && (
                    <path d="M 240 100 Q 280 150 240 200" fill="none" stroke="#ff8c00" strokeWidth="2" strokeDasharray="3" />
                  )}
                </g>

                {/* Weld symbol */}
                <g fill="none" stroke="#71717a" strokeWidth="0.75" transform="translate(110, 65)">
                  <line x1="0" y1="0" x2="20" y2="-10" />
                  <line x1="20" y1="-10" x2="60" y2="-10" />
                  <text x="24" y="-14" fill="#a1a1aa" fontSize="7.5" fontFamily="monospace" stroke="none">a={weldThroat}</text>
                  {/* Small triangle weld symbol */}
                  <polygon points="45,-10 52,-10 48.5,-5" fill="#71717a" stroke="none" />
                </g>

              </svg>
            </div>

            {/* Diagram Dimensions Label Footer */}
            <div className="bg-zinc-900 border-t border-zinc-800 p-4 font-mono text-[10px] text-zinc-400 flex items-center justify-between">
              <div>PLATE: {plateThickness}mm S355</div>
              <div>BOLTS: {boltCount}x {boltSize} (Grade 8.8)</div>
              <div>FILLET: {weldThroat}mm</div>
            </div>

          </div>

          {/* Right: Stress & Utilization report (col-span-3) */}
          <div className="lg:col-span-3 bg-zinc-900 border border-zinc-800 p-8 flex flex-col justify-between gap-6">
            
            <div className="flex flex-col gap-6">
              
              <div className="flex items-center gap-2 border-b border-zinc-800 pb-3">
                <Settings className="h-4.5 w-4.5 text-orange-500" />
                <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-100">
                  CALCULATIONS
                </h3>
              </div>

              {/* Stress Ratios metrics bars */}
              <div className="flex flex-col gap-4 font-mono text-xs">
                
                {/* 1. Shear Util */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500">BOLT SHEAR</span>
                    <span className="text-zinc-300 font-bold">{(shearUtil * 100).toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 bg-zinc-950 w-full relative">
                    <div
                      className={`absolute top-0 bottom-0 left-0 transition-all ${shearUtil > 1.0 ? 'bg-red-500' : 'bg-orange-500'}`}
                      style={{ width: `${Math.min(100, shearUtil * 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-zinc-600">
                    <span>VEd: {shearLoad} kN</span>
                    <span>Cap: {boltShearCapacityTotal.toFixed(0)} kN</span>
                  </div>
                </div>

                {/* 2. Tension Util (only for moment joint type) */}
                {connectionType === 'moment' && (
                  <div className="flex flex-col gap-1.5">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-zinc-500">BOLT TENSION</span>
                      <span className="text-zinc-300 font-bold">{(tensionUtil * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-1.5 bg-zinc-950 w-full relative">
                      <div
                        className={`absolute top-0 bottom-0 left-0 transition-all ${tensionUtil > 1.0 ? 'bg-red-500' : 'bg-orange-500'}`}
                        style={{ width: `${Math.min(100, tensionUtil * 100)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[9px] text-zinc-600">
                      <span>Equiv NEd: {tensionFromMoment.toFixed(0)} kN</span>
                      <span>Cap: {boltTensionCapacityTotal.toFixed(0)} kN</span>
                    </div>
                  </div>
                )}

                {/* 3. Plate bending */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500">PLATE BENDING</span>
                    <span className="text-zinc-300 font-bold">{(plateUtil * 100).toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 bg-zinc-950 w-full relative">
                    <div
                      className={`absolute top-0 bottom-0 left-0 transition-all ${plateUtil > 1.0 ? 'bg-red-500' : 'bg-orange-500'}`}
                      style={{ width: `${Math.min(100, plateUtil * 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-zinc-600">
                    <span>Thick: {plateThickness} mm</span>
                    <span>Util: {plateUtil.toFixed(2)}</span>
                  </div>
                </div>

                {/* 4. Weld stress */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500">FILLET WELDS</span>
                    <span className="text-zinc-300 font-bold">{(weldUtil * 100).toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 bg-zinc-950 w-full relative">
                    <div
                      className={`absolute top-0 bottom-0 left-0 transition-all ${weldUtil > 1.0 ? 'bg-red-500' : 'bg-orange-500'}`}
                      style={{ width: `${Math.min(100, weldUtil * 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-zinc-600">
                    <span>Throat: {weldThroat} mm</span>
                    <span>Cap: {weldCapacity.toFixed(0)} kN</span>
                  </div>
                </div>

              </div>

            </div>

            {/* Big Utilization Score & PASS/FAIL stamp */}
            <div className="border-t border-zinc-800 pt-6 mt-2 flex flex-col gap-3">
              <div className="flex justify-between items-baseline font-mono text-xs text-zinc-500">
                <span>TOTAL PEAK UTILISATION:</span>
                <span className={`text-xl font-bold font-mono tabular-nums ${isPassed ? 'text-emerald-500' : 'text-red-500'}`}>
                  {peakUtil.toFixed(2)}
                </span>
              </div>

              {/* Status banner */}
              <div className={`p-4 flex items-center justify-center gap-2 font-mono text-xs font-bold border ${
                isPassed 
                  ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' 
                  : 'bg-red-500/10 border-red-500 text-red-500'
              }`}>
                {isPassed ? (
                  <>
                    <CheckCircle className="h-4.5 w-4.5" />
                    DESIGN COMPLIANT (PASS)
                  </>
                ) : (
                  <>
                    <XCircle className="h-4.5 w-4.5" />
                    STRESS OVER LIMIT (FAIL)
                  </>
                )}
              </div>

              {/* Lab verification disclaimer */}
              <div className="flex gap-2 bg-zinc-950 p-3 border border-zinc-850 font-mono text-[8px] leading-relaxed text-zinc-500">
                <ShieldAlert className="h-4 w-4 text-orange-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-zinc-400">DEMO ONLY:</span> NOT A CERTIFIED CALCULATOR. INDEPENDENT STRUCTURAL REVIEW REQUIRED BEFORE CONSTRUCTION.
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
