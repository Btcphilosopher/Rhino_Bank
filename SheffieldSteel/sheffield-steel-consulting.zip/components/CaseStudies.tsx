'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, X, Compass, Layers, ShieldCheck, MapPin } from 'lucide-react';

interface Project {
  id: string;
  num: string;
  title: string;
  location: string;
  scope: string;
  status: string;
  fullDesc: string;
  image: string | null;
  specs: { label: string; value: string }[];
}

export default function CaseStudies() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const projects: Project[] = [
    {
      id: 'p1',
      num: 'PROJECT 01',
      title: 'STEEL MILL PROCESS PLATFORM',
      location: 'South Yorkshire',
      scope: 'Structural assessment · strengthening · access steelwork · fabrication support',
      status: 'Completed',
      fullDesc: 'Design and checking of a heavy 250-tonne process structure directly adjacent to active casting lines. The engineering required rigorous thermal stress analysis, vibration dampening layouts for overhead handling hoists, and bolted moment connection retrofits capable of installation during tight 48-hour scheduled maintenance outages.',
      image: '/images/steel_mill_interior_1790779606377.jpg',
      specs: [
        { label: 'STEEL WEIGHT', value: '250 Tonnes' },
        { label: 'GRADE SIZES', value: 'S355 J2+N' },
        { label: 'CONNECTIONS', value: 'M24/M30 Grade 8.8 Preloaded' },
        { label: 'CHECK PROTOCOL', value: 'Category 3 Independent Review' }
      ]
    },
    {
      id: 'p2',
      num: 'PROJECT 02',
      title: 'LONG-SPAN MANUFACTURING HALL',
      location: 'Yorkshire',
      scope: 'Concept design · structural analysis · connection engineering · fabrication package',
      status: 'In Progress',
      fullDesc: 'Primary frame and connections design for a 45-meter clear span manufacturing facility. Utilized optimized tapered portal frames with stiffened knee joints and custom splices, reducing total structural tonnage by 14% while retaining full wind load and crane runner capacities.',
      image: '/images/steel_connection_hero_1790779589407.jpg',
      specs: [
        { label: 'CLEAR SPAN', value: '45.0 Meters' },
        { label: 'SECTIONS', value: 'Tapered Welded Plate Girders' },
        { label: 'PLATE THICK', value: 'Up to 35mm Flanges' },
        { label: 'WELD SPECS', value: 'Full Penetration Butt Welds' }
      ]
    },
    {
      id: 'p3',
      num: 'PROJECT 03',
      title: 'RAIL DEPOT STEELWORK',
      location: 'Northern England',
      scope: 'Heavy steel frame · maintenance platforms · temporary works · technical review',
      status: 'Completed',
      fullDesc: 'Engineering of suspended high-level maintenance access structures and heavy column brackets for overhead crane runways. Designed in conformance with strict Network Rail clearance envelopes and dynamic impact limitations.',
      image: null,
      specs: [
        { label: 'SECTORS', value: 'Rail Transport Infrastructure' },
        { label: 'STANDARDS', value: 'BS EN 1993-2 (Bridges/Depots)' },
        { label: 'LOAD LIMITS', value: 'Dynamic Crane Runners' },
        { label: 'DELIVERABLE', value: 'Teckla Model & Calculations' }
      ]
    },
    {
      id: 'p4',
      num: 'PROJECT 04',
      title: 'EXISTING INDUSTRIAL STRUCTURE',
      location: 'Sheffield',
      scope: 'Condition assessment · load verification · strengthening strategy',
      status: 'Completed',
      fullDesc: 'Critical forensic assessment of a 1920s riveted steel truss structure in central Sheffield. Evaluated historic wrought iron and early structural carbon steel grades, mapped exact member coordinates under corrosion, and delivered a certified, low-impact carbon fiber plate reinforcement strategy.',
      image: '/images/sheffield_landscape_1790779624158.jpg',
      specs: [
        { label: 'ORIGIN DATE', value: 'Circa 1924' },
        { label: 'ASSESSMENT', value: 'Non-Destructive Ultrasonic Testing' },
        { label: 'REPAIR METHOD', value: 'Bolted Strengthening Channels' },
        { label: 'TRUST MARK', value: 'Sheffield Historical Council Approved' }
      ]
    },
    {
      id: 'p5',
      num: 'PROJECT 05',
      title: 'BESPOKE PROCESS STRUCTURE',
      location: 'UK',
      scope: 'Concept engineering · 3D modelling · connection design · fabrication support',
      status: 'Completed',
      fullDesc: 'Engineering of highly complex multi-level plant platform framework. Leveraged advanced finite element analysis (FEA) to verify stress patterns in custom non-standard nodes and anchor assemblies under compound torsion and dynamic vibration forces.',
      image: null,
      specs: [
        { label: 'NODE COMPLEXITY', value: 'Multi-axis Stiffened Joint' },
        { label: 'ANALYSIS METHOD', value: 'FEA Stress Strain Mapping' },
        { label: 'BOLTING ARR', value: 'Pre-tensioned Friction Grip' },
        { label: 'CODE REFERENCE', value: 'BS EN 1993-1-8 (Joint Design)' }
      ]
    }
  ];

  return (
    <section id="projects" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">ENGINEERING PORTFOLIO</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
              SELECTED PROJECTS
            </h2>
          </div>
          <p className="max-w-md text-sm text-zinc-400">
            A portfolio of practical solutions. We deliver technically validated structural design packages for demanding industrial and infrastructure sectors.
          </p>
        </div>

        {/* Projects Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, idx) => {
            const hasImage = !!project.image;
            return (
              <div
                key={project.id}
                onClick={() => setSelectedProject(project)}
                className="group cursor-pointer bg-zinc-900 border border-zinc-800 flex flex-col justify-between overflow-hidden relative transition-all hover:border-zinc-700 h-[380px]"
              >
                {/* Visual Backdrop block */}
                <div className="relative h-48 bg-zinc-950 w-full overflow-hidden border-b border-zinc-800/60 flex items-center justify-center">
                  {hasImage ? (
                    <Image
                      src={project.image!}
                      alt={project.title}
                      fill
                      className="object-cover opacity-60 transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-w-7xl) 33vw, 100vw"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    /* Elegant CSS/SVG technical fallback container for non-image projects */
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950 p-6">
                      <div className="absolute inset-0 opacity-5 pointer-events-none">
                        <div className="absolute left-[33%] top-0 bottom-0 w-[1px] bg-zinc-100" />
                        <div className="absolute left-[66%] top-0 bottom-0 w-[1px] bg-zinc-100" />
                        <div className="absolute top-[50%] left-0 right-0 h-[1px] bg-zinc-100" />
                      </div>
                      <Layers className="h-10 w-10 text-zinc-700 mb-2 stroke-1" />
                      <span className="font-mono text-[9px] text-zinc-500 tracking-widest">TECHNICAL DATA ONLY</span>
                      <span className="font-mono text-[8px] text-zinc-600 mt-1">NO PHOTOGRAPHY OBTAINED</span>
                    </div>
                  )}
                  
                  {/* Status overlay bar */}
                  <div className="absolute top-4 left-4 bg-zinc-950/90 border border-zinc-800 px-2.5 py-1 font-mono text-[9px] text-zinc-400 tracking-wider">
                    {project.status.toUpperCase()}
                  </div>
                </div>

                {/* Content info */}
                <div className="p-6 flex-grow flex flex-col justify-between">
                  <div className="flex flex-col gap-2">
                    <span className="font-mono text-[10px] text-orange-500 font-bold tracking-widest">
                      {project.num}
                    </span>
                    <h3 className="text-base font-extrabold text-zinc-100 tracking-tight leading-tight group-hover:text-orange-500 transition-colors">
                      {project.title}
                    </h3>
                  </div>

                  <div className="border-t border-zinc-800/80 pt-4 mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-medium">
                      <MapPin className="h-3.5 w-3.5 text-zinc-600 shrink-0" />
                      <span>{project.location}</span>
                    </div>
                    <span className="flex items-center gap-1 text-xs text-orange-500 font-bold font-mono tracking-widest">
                      EXAMINE →
                    </span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Modal Sheet for Project Details */}
        <AnimatePresence>
          {selectedProject && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="relative w-full max-w-4xl bg-zinc-900 border border-zinc-800 max-h-[90vh] overflow-y-auto flex flex-col"
              >
                {/* Close Button */}
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 z-10 p-2 bg-zinc-950/80 hover:bg-zinc-950 text-zinc-400 hover:text-zinc-100 border border-zinc-800"
                >
                  <X className="h-4.5 w-4.5" />
                </button>

                {/* Hero visual header inside Modal */}
                <div className="relative h-64 sm:h-80 bg-zinc-950 flex items-center justify-center">
                  {selectedProject.image ? (
                    <Image
                      src={selectedProject.image}
                      alt={selectedProject.title}
                      fill
                      className="object-cover opacity-60"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950">
                      <Layers className="h-12 w-12 text-zinc-700 mb-2 stroke-1" />
                      <span className="font-mono text-[10px] text-zinc-500 tracking-widest">RESTRICTED TECHNICAL METADATA</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/40 to-transparent" />
                  
                  {/* Status overlay */}
                  <div className="absolute bottom-6 left-8 flex flex-col gap-1">
                    <span className="font-mono text-[10px] text-orange-500 font-bold tracking-widest">
                      {selectedProject.num} · {selectedProject.location.toUpperCase()}
                    </span>
                    <h2 className="text-xl sm:text-3xl font-extrabold text-zinc-100 tracking-tight leading-none">
                      {selectedProject.title}
                    </h2>
                  </div>
                </div>

                {/* Body details */}
                <div className="p-8 grid grid-cols-1 md:grid-cols-12 gap-8">
                  
                  {/* Descriptions left (col-span-7) */}
                  <div className="md:col-span-7 flex flex-col gap-6">
                    <div>
                      <h4 className="font-mono text-[10px] font-bold tracking-widest text-zinc-500 uppercase mb-2 border-b border-zinc-800 pb-1.5">
                        PROJECT BRIEF & SCOPE
                      </h4>
                      <p className="text-zinc-400 text-sm font-mono leading-relaxed italic">
                        {selectedProject.scope}
                      </p>
                    </div>

                    <div className="flex flex-col gap-4 text-zinc-300 text-sm sm:text-base leading-relaxed">
                      <p>{selectedProject.fullDesc}</p>
                    </div>
                  </div>

                  {/* Tech specs right (col-span-5) */}
                  <div className="md:col-span-5 flex flex-col gap-6 bg-zinc-950 p-6 border border-zinc-800">
                    <h4 className="font-mono text-[10px] font-bold tracking-widest text-orange-500 uppercase mb-2 border-b border-zinc-900 pb-1.5">
                      TECHNICAL METADATA
                    </h4>
                    
                    <div className="flex flex-col gap-4 font-mono text-xs">
                      {selectedProject.specs.map((spec, idx) => (
                        <div key={idx} className="flex flex-col gap-1">
                          <span className="text-zinc-500 text-[9px] uppercase">{spec.label}</span>
                          <span className="text-zinc-200 font-semibold">{spec.value}</span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 pt-4 border-t border-zinc-900 flex items-start gap-2.5 font-mono text-[9px] text-zinc-500">
                      <ShieldCheck className="h-4.5 w-4.5 text-orange-500 shrink-0 mt-0.5" />
                      <div>
                        <span>All deliverables audited and issued under UK Structural Code BS EN 1993. Reference verification archive SSC-{selectedProject.id.toUpperCase()}.</span>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Footer close bar */}
                <div className="bg-zinc-950 px-8 py-4 border-t border-zinc-850 flex justify-end">
                  <button
                    onClick={() => setSelectedProject(null)}
                    className="bg-zinc-900 border border-zinc-800 px-4 py-2 font-mono text-xs font-bold text-zinc-300 hover:text-zinc-100 hover:border-zinc-700"
                  >
                    CLOSE EXAMINER
                  </button>
                </div>

              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
