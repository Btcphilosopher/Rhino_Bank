'use client';

import React from 'react';
import { motion } from 'motion/react';

interface ProcessStep {
  number: string;
  title: string;
  desc: string;
}

export default function Process() {
  const steps: ProcessStep[] = [
    {
      number: '01',
      title: 'UNDERSTAND',
      desc: 'Deep discovery of the project brief, site conditions, equipment constraints, and fabrication shop capabilities.'
    },
    {
      number: '02',
      title: 'MODEL',
      desc: 'Creation of rigorous digital models mapping exact section geometry, loads, material properties, and boundary conditions.'
    },
    {
      number: '03',
      title: 'ANALYSE',
      desc: 'Comprehensive structural analysis covering strength, fatigue, global stability, buckling modes, and deflection limits.'
    },
    {
      number: '04',
      title: 'ENGINEER',
      desc: 'Development of elegant, constructible joint connections, weld details, and members optimized for fabrication and assembly.'
    },
    {
      number: '05',
      title: 'CHECK',
      desc: 'Rigorous internal verification and independent Category 3 design reviews providing absolute technical assurance.'
    },
    {
      number: '06',
      title: 'DELIVER',
      desc: 'Production of crisp general arrangements, clear connection details, calculation packages, and fabrication specifications.'
    },
    {
      number: '07',
      title: 'SUPPORT',
      desc: 'Active engineering presence on the workshop floor and on site during erection, material handling, and commissioning.'
    }
  ];

  return (
    <section className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Title */}
        <div className="flex flex-col gap-3 mb-16 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
            <span className="font-mono text-xs font-bold tracking-widest text-orange-500">ENGINEERING METHODOLOGY</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
            OUR LIFECYCLE
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            A linear path of structural integrity. From initial constraints through to final commissioning support, our engineering remains rigorous and practical.
          </p>
        </div>

        {/* Process Flow - Horizontal on desktop, vertical on mobile */}
        <div className="relative border-l border-zinc-800 md:border-l-0 md:border-t md:border-zinc-800 pl-6 md:pl-0 pt-0 md:pt-12 grid grid-cols-1 md:grid-cols-7 gap-8 lg:gap-10">
          
          {steps.map((step, idx) => (
            <div key={idx} className="relative flex flex-col items-start gap-4 group">
              
              {/* Timeline marker node */}
              <div className="absolute -left-[31px] top-1 md:left-0 md:-top-[55px] h-3 w-3 bg-zinc-950 border-2 border-orange-500 transition-all group-hover:bg-orange-500" />
              
              {/* Step number */}
              <div className="font-mono text-xs font-bold tracking-widest text-orange-500">
                {step.number} —
              </div>

              {/* Step title */}
              <h3 className="text-sm font-bold tracking-widest text-zinc-100 uppercase">
                {step.title}
              </h3>

              {/* Step description */}
              <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed max-w-xs md:max-w-none">
                {step.desc}
              </p>

            </div>
          ))}

        </div>

      </div>
    </section>
  );
}
