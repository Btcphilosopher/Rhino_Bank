'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Anchor, Cpu, Disc, Settings, Sliders, ShieldCheck } from 'lucide-react';

interface CapabilityGroup {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  summary: string;
  services: string[];
  technicalNote: string;
}

export default function CapabilitiesGrid() {
  const [activeTab, setActiveTab] = useState<string>('structural');

  const capabilities: CapabilityGroup[] = [
    {
      id: 'structural',
      title: 'STRUCTURAL STEEL',
      icon: Cpu,
      summary: 'Comprehensive analysis and design of standard and complex frames. We provide rigorous engineering modeling to ensure absolute stability, code compliance, and structural efficiency.',
      services: [
        'Steel frame design & analysis',
        'Beam and column sizing (UB, UC, SHS, CHS)',
        'Detailed structural assessment',
        'Custom connection calculations',
        'Structural stability & wind analysis',
        'Member strengthening & reinforcement',
        'Refurbishment alterations & interventions',
        'Heavy temporary works engineering',
        'Dynamic & dead load assessment',
        'Structural fatigue assessment'
      ],
      technicalNote: 'Calculations modeled in accordance with BS EN 1993-1-1 (Eurocode 3) using validated structural analysis methods.'
    },
    {
      id: 'industrial',
      title: 'INDUSTRIAL STEEL',
      icon: Settings,
      summary: 'Rugged, practical engineering design for industrial process facilities, manufacturing environments, energy plants, and severe-service structures.',
      services: [
        'Heavy process platforms',
        'Mezzanines & maintenance walkways',
        'Overhead crane gantries',
        'Complex plant & equipment supports',
        'Silo & pressure vessel structures',
        'Multi-span industrial pipe bridges',
        'Safe access & egress egress systems',
        'Industrial building framing',
        'Process ducting support structures',
        'Vibration-sensitive support frames'
      ],
      technicalNote: 'Designed for accessibility, material handling, mechanical tolerances, and compliance with BS EN ISO 14122 access standards.'
    },
    {
      id: 'connections',
      title: 'STEEL CONNECTIONS',
      icon: Disc,
      summary: 'Our signature capability. We focus intensely on joints — where structure, force, and fabrication actually meet. Every bolt, weld, and plate is meticulously engineered.',
      services: [
        'High-strength bolted connections',
        'Heavy welded connection design',
        'Base plate & anchor anchor design',
        'Rigid moment-resisting connections',
        'Flexible shear & simple connections',
        'Column & beam splice design',
        'Bespoke bracket & corbel details',
        'Lifting points & rigging attachments',
        'Bespoke complex column-head nodes',
        'Joint component finite element analysis'
      ],
      technicalNote: 'Connection details are verified down to weld throat thickness and bolt thread layout to prevent fabrication conflicts.'
    },
    {
      id: 'consultancy',
      title: 'TECHNICAL CONSULTANCY',
      icon: Sliders,
      summary: 'Independent technical scrutiny and advisory. We act as the third-party structural validator for developers, project managers, and lead contractors.',
      services: [
        'Independent design review (Cat 3 checks)',
        'Engineering checking & code validation',
        'Feasibility & structural options studies',
        'Value engineering & weight optimization',
        'Constructability & erection reviews',
        'Technical due diligence assessments',
        'Structural failure investigation',
        'Historic steel condition assessment',
        'Remedial repair strategies',
        'Authoritative expert engineering reports'
      ],
      technicalNote: 'Acting with complete technical independence. We offer direct, uncompromising engineering judgment on complex issues.'
    },
    {
      id: 'fabrication',
      title: 'FABRICATION SUPPORT',
      icon: Anchor,
      summary: 'Bridging the critical gap between design models and workshop reality. We understand plate cutting, weld preps, transport limits, and assembly clearances.',
      services: [
        'Fabrication drawing review',
        'Assembly & fabrication methodology',
        'Weld procedure & sequence strategy',
        'Material grade & toughness selection',
        'Workshop tolerance reviews',
        'Erection sequencing & safety analysis',
        'Temporary stability during erection',
        'Site inspection & welding oversight',
        'Site-technical engineering support',
        'As-built verification & dimensional audits'
      ],
      technicalNote: 'Helping steelwork contractors deliver on time by ensuring connections fit first-time on site.'
    }
  ];

  const currentGroup = capabilities.find(c => c.id === activeTab) || capabilities[0];

  return (
    <section id="capabilities" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">CORE COMPETENCIES</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
              OUR CAPABILITIES
            </h2>
          </div>
          <p className="max-w-md text-sm text-zinc-400">
            A specialized engineering focus. We bring Sheffield’s deep steel legacy into modern digital design, structural mechanics, and fabrication support.
          </p>
        </div>

        {/* Tab Selection Bar (Interactive Controls) */}
        <div className="flex flex-wrap items-center gap-2 border-b border-zinc-900 pb-2 mb-8 overflow-x-auto">
          {capabilities.map((cap) => {
            const Icon = cap.icon;
            const isActive = activeTab === cap.id;
            return (
              <button
                key={cap.id}
                onClick={() => setActiveTab(cap.id)}
                className={`flex items-center gap-3 px-4 py-2.5 font-mono text-xs font-bold tracking-widest transition-all whitespace-nowrap shrink-0 border ${
                  isActive
                    ? 'bg-zinc-100 text-zinc-950 border-zinc-100'
                    : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-100 hover:border-zinc-700'
                }`}
              >
                <Icon className="h-4.5 w-4.5" />
                {cap.title}
              </button>
            );
          })}
        </div>

        {/* Tab Content Panel */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-zinc-900 border border-zinc-800/80 p-8 sm:p-12"
          >
            {/* Summary Left */}
            <div className="lg:col-span-5 flex flex-col justify-between gap-8">
              <div className="flex flex-col gap-4">
                <span className="font-mono text-xs font-bold tracking-widest text-orange-500">
                  {currentGroup.title} DETAILS
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-zinc-100 tracking-tight leading-tight">
                  {currentGroup.title}
                </h3>
                <p className="text-zinc-400 text-base leading-relaxed">
                  {currentGroup.summary}
                </p>
              </div>

              {/* Technical annotation footer */}
              <div className="border-t border-zinc-800 pt-6 flex items-start gap-3">
                <ShieldCheck className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
                <div className="font-mono text-[11px] leading-relaxed text-zinc-500">
                  <span className="font-bold text-zinc-400">STANDARDS REFERENCE:</span> {currentGroup.technicalNote}
                </div>
              </div>
            </div>

            {/* List Right */}
            <div className="lg:col-span-7 border-l border-zinc-800 lg:pl-12">
              <h4 className="font-mono text-xs font-bold tracking-widest text-zinc-400 mb-6">
                ENGINEERING DELIVERABLES & METHODS
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {currentGroup.services.map((service, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-3 py-1 border-b border-zinc-950/40 text-sm font-semibold text-zinc-200"
                  >
                    {/* Tiny technical index marker instead of bullet */}
                    <span className="font-mono text-[9px] text-zinc-600 w-4">
                      {(idx + 1).toString().padStart(2, '0')}
                    </span>
                    <span className="truncate">{service}</span>
                  </div>
                ))}
              </div>
            </div>

          </motion.div>
        </AnimatePresence>

      </div>
    </section>
  );
}
