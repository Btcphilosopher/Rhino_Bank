'use client';

import React, { useState } from 'react';
import { Menu, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TopBarProps {
  onNavigate: (sectionId: string) => void;
  activeSection: string;
}

export default function TopBar({ onNavigate, activeSection }: TopBarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'capabilities', label: 'CAPABILITIES' },
    { id: 'projects', label: 'PROJECTS' },
    { id: 'engineering', label: 'ENGINEERING' },
    { id: 'insights', label: 'INSIGHTS' },
    { id: 'about', label: 'ABOUT' },
    { id: 'contact', label: 'CONTACT' },
  ];

  const handleLinkClick = (id: string) => {
    setMobileMenuOpen(false);
    onNavigate(id);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        {/* Zone 1: Brand Wordmark (Single Text Element) */}
        <button
          onClick={() => handleLinkClick('hero')}
          className="text-lg font-bold tracking-wider text-zinc-100 transition-colors hover:text-orange-500 font-mono"
        >
          SC STEEL
        </button>

        {/* Zone 2: Navigation Links (4-6 Links, text with subtle hover underlines) */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-semibold tracking-widest font-mono text-zinc-400">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className={`relative py-1 transition-colors hover:text-zinc-100 ${
                activeSection === link.id ? 'text-orange-500' : ''
              }`}
            >
              {link.label}
              {activeSection === link.id && (
                <motion.span
                  layoutId="activeNavLine"
                  className="absolute bottom-0 left-0 h-0.5 w-full bg-orange-500"
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={() => handleLinkClick('contact')}
            className="group flex items-center gap-2 border border-zinc-700 bg-zinc-900 px-4 py-2 font-mono text-xs font-bold tracking-widest text-zinc-100 transition-all hover:border-orange-500 hover:bg-orange-500 hover:text-zinc-950"
          >
            DISCUSS A PROJECT
            <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-zinc-400 hover:text-zinc-100 focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Full-screen Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: '100vh' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="fixed inset-x-0 top-16 z-40 w-full bg-zinc-950 px-6 py-8 md:hidden"
          >
            <nav className="flex flex-col gap-6 text-sm font-semibold tracking-widest font-mono text-zinc-400">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`text-left py-2 border-b border-zinc-900 transition-colors hover:text-zinc-100 ${
                    activeSection === link.id ? 'text-orange-500 border-orange-500/20' : ''
                  }`}
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => handleLinkClick('contact')}
                className="mt-4 flex items-center justify-between border border-zinc-800 bg-zinc-900 p-4 font-mono text-xs font-bold tracking-widest text-zinc-100 hover:border-orange-500"
              >
                DISCUSS A PROJECT
                <ArrowRight className="h-4 w-4 text-orange-500" />
              </button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
