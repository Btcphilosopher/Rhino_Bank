'use client';

import React from 'react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const navLinks = [
    { id: 'capabilities', label: 'CAPABILITIES' },
    { id: 'projects', label: 'PROJECTS' },
    { id: 'engineering', label: 'ENGINEERING' },
    { id: 'insights', label: 'INSIGHTS' },
    { id: 'about', label: 'ABOUT' },
    { id: 'contact', label: 'CONTACT' },
  ];

  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 py-16">
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col md:flex-row items-start justify-between gap-10">
          
          {/* Logo & description Left */}
          <div className="flex flex-col gap-4 max-w-sm">
            <button
              onClick={() => onNavigate('hero')}
              className="text-lg font-bold tracking-wider text-zinc-100 hover:text-orange-500 font-mono text-left"
            >
              SC STEEL
            </button>
            <p className="text-xs text-zinc-500 leading-relaxed font-normal">
              Sheffield Steel Consulting is an independent steel engineering and technical consultancy. We specialize in structural steelwork, preloaded moment connections, process plant framing, and fabrication reviews.
            </p>
          </div>

          {/* Navigation Mirrors Center */}
          <div className="flex flex-col gap-3">
            <span className="font-mono text-[9px] text-zinc-600 font-bold tracking-widest uppercase">
              NAVIGATION
            </span>
            <div className="grid grid-cols-2 gap-x-8 gap-y-2 font-mono text-xs font-semibold text-zinc-400">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => onNavigate(link.id)}
                  className="text-left hover:text-zinc-100 transition-colors py-0.5"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Office Credentials Right */}
          <div className="flex flex-col gap-3 max-w-xs text-right md:text-left font-mono text-xs">
            <span className="font-mono text-[9px] text-zinc-600 font-bold tracking-widest uppercase">
              REGISTERED OFFICE
            </span>
            <div className="flex flex-col gap-1 text-zinc-500 font-normal">
              <span>Vulcan Works, Kelham Island</span>
              <span>Sheffield S3 8MZ, United Kingdom</span>
              <span className="text-[10px] text-zinc-600 mt-2">REG CO: #1249710 · EST. 1986</span>
            </div>
          </div>

        </div>

        {/* Copyright notice border */}
        <div className="border-t border-zinc-900/60 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[10px] text-zinc-600">
          <span>© {new Date().getFullYear()} SHEFFIELD STEEL CONSULTING LTD. ALL RIGHTS RESERVED.</span>
          <div className="flex items-center gap-4">
            <span className="hover:text-zinc-500 transition-colors cursor-pointer">TERMS OF PRACTICE</span>
            <span>·</span>
            <span className="hover:text-zinc-500 transition-colors cursor-pointer">ACCESSIBILITY PROTOCOLS</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
