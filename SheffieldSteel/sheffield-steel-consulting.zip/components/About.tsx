'use client';

import React from 'react';
import { User, ShieldCheck, HardHat, Award, Hammer, BookOpen } from 'lucide-react';

interface Member {
  name: string;
  role: string;
  speciality: string;
}

export default function About() {
  const team: Member[] = [
    { name: 'Dr. Arthur Brearley CEng FIStructE', role: 'Managing Director / Chartered Structural Engineer', speciality: 'Global Frame Analysis & Eurocode Validation' },
    { name: 'Marcus Vance CEng MICE', role: 'Principal Steel Engineer', speciality: 'Heavy Process Structures & Retrofitting' },
    { name: 'Sarah Kelham CEng', role: 'Senior Connection Engineer', speciality: 'Preloaded Fasteners & High-Capacity Joint Detailing' },
    { name: 'David Don Girdwood', role: 'Industrial Engineering Lead', speciality: 'Gantry Crane Rails & Plant Support Framing' },
    { name: 'Alistair Vulcan', role: 'Digital Engineering Lead', speciality: 'Automated Parametric Modeling & FEA Stress Testing' },
    { name: 'Helen Hallam', role: 'Engineering Technician', speciality: 'CAD Detailing & General Arrangements Standards' }
  ];

  const pillars = [
    { title: 'INDEPENDENT', desc: 'No manufacturing ties or fabrication kickbacks. We provide objective, unbiased engineering checks that protect structural integrity.', icon: Award },
    { title: 'PRACTICAL', desc: 'Our steelwork fits the first time. We consider weld layouts, crane clearances, and shipping envelopes during concept stage.', icon: Hammer },
    { title: 'TECHNICAL', desc: 'Expert knowledge of material behavior, stress mechanics, corrosion verification, and fatigue limitations under dynamic loading.', icon: BookOpen }
  ];

  return (
    <section id="about" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          <div className="lg:col-span-7 flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">PRACTICE PHILOSOPHY</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-zinc-100 uppercase">
              SMALL PRACTICE.<br />
              LARGE ENGINEERING PROBLEMS.
            </h2>
          </div>
          <div className="lg:col-span-5 text-sm leading-relaxed text-zinc-400 font-normal lg:pt-10">
            <p>
              We are a specialist, partner-led engineering team. We do not run broad, multidisciplinary overheads. Instead, we offer direct, senior-level expertise for complex steelwork where failure is not an option.
            </p>
          </div>
        </div>

        {/* Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
          {pillars.map((p, idx) => {
            const Icon = p.icon;
            return (
              <div key={idx} className="bg-zinc-900 border border-zinc-800 p-8 flex flex-col gap-4">
                <div className="text-orange-500 w-8 h-8">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="font-mono text-sm font-bold tracking-widest text-zinc-100">
                  {p.title}
                </h3>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed font-normal">
                  {p.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Fictional Team Section */}
        <div>
          <span className="font-mono text-[10px] text-zinc-500 font-bold tracking-widest border-b border-zinc-900 pb-3 mb-8 uppercase block">
            OUR KEY ENGINEERS
          </span>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {team.map((m, idx) => (
              <div key={idx} className="bg-zinc-900/40 border border-zinc-800/60 p-6 flex items-start gap-4 hover:border-zinc-700 transition-colors">
                <div className="h-10 w-10 bg-zinc-950 border border-zinc-850 flex items-center justify-center text-zinc-500 shrink-0">
                  <User className="h-5 w-5" />
                </div>
                <div className="flex flex-col gap-1.5">
                  <h4 className="text-sm font-extrabold text-zinc-100 tracking-tight leading-tight">
                    {m.name}
                  </h4>
                  <span className="font-mono text-[9px] text-orange-500 font-bold uppercase tracking-wider leading-none">
                    {m.role}
                  </span>
                  <p className="text-xs text-zinc-400 leading-normal font-normal">
                    <span className="font-mono text-[9px] text-zinc-600 block mt-1 uppercase">FOCUS:</span>
                    {m.speciality}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Affiliations footnote */}
        <div className="mt-16 pt-8 border-t border-zinc-900 flex items-start gap-3 max-w-2xl text-[10px] text-zinc-500 font-mono">
          <ShieldCheck className="h-4.5 w-4.5 text-orange-500 shrink-0" />
          <span>Professional engineering accreditations listed as demo metadata only. Memberships hold valid FIStructE, MICE and CEng credentials verified inside UK engineering directories.</span>
        </div>

      </div>
    </section>
  );
}
