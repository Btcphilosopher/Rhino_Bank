'use client';

import React from 'react';
import { motion } from 'motion/react';

export default function Intro() {
  const sidebarData = [
    { label: 'BASED IN', value: 'Sheffield, South Yorkshire' },
    { label: 'WORKING ACROSS', value: 'UK · Europe · International' },
    { label: 'SPECIALISM', value: 'Structural & Connection Steelwork' },
    { label: 'APPROACH', value: 'Independent · Practical · Technical' },
  ];

  return (
    <section id="intro" className="relative bg-zinc-950 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Large Editorial Left (col-span-8) */}
          <div className="lg:col-span-8 flex flex-col gap-8">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">PRACTICE OVERVIEW</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100 leading-tight">
              ENGINEERING FOR THE<br />
              STEEL INDUSTRY
            </h2>

            <div className="flex flex-col gap-6 text-zinc-400 text-base sm:text-lg leading-relaxed font-normal max-w-3xl">
              <p>
                Sheffield Steel Consulting is an independent engineering practice specialising in steel structures, industrial systems and technically demanding engineering problems.
              </p>
              <p className="text-zinc-300">
                We work between design, fabrication and operation — providing practical engineering advice that can survive contact with the real world.
              </p>
              <p>
                Our work ranges from individual connections and structural assessments to complex industrial steelwork, fabrication support, design reviews and large engineering packages.
              </p>
            </div>
            
            {/* Short bold statement quote */}
            <div className="border-l-4 border-zinc-800 pl-6 my-4 italic text-zinc-400">
              &ldquo;We design steelwork that can actually be built.&rdquo;
            </div>
          </div>

          {/* Technical Sidebar Right (col-span-4) */}
          <div className="lg:col-span-4 bg-zinc-900 border border-zinc-800 p-8">
            <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-400 border-b border-zinc-800 pb-4 mb-6">
              PRACTICE SPECIFICATIONS
            </h3>
            
            <div className="flex flex-col gap-6">
              {sidebarData.map((item, idx) => (
                <div key={idx} className="flex flex-col gap-1">
                  <span className="font-mono text-[10px] tracking-widest text-orange-500 font-bold">
                    {item.label}
                  </span>
                  <span className="text-sm font-semibold text-zinc-100">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>

            {/* Fictional Reference Number */}
            <div className="mt-12 pt-6 border-t border-zinc-800/60 flex items-center justify-between font-mono text-[9px] text-zinc-600">
              <span>EST. MCMLXXXVI</span>
              <span>REF // SSC-SHEFFIELD</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
