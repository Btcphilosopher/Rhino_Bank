'use client';

import React, { useState } from 'react';
import { Cpu, HelpCircle, Loader2, Play, CornerDownLeft, ShieldAlert } from 'lucide-react';

interface SuggestedQuery {
  title: string;
  query: string;
}

export default function SteelIntelligence() {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const suggestions: SuggestedQuery[] = [
    { title: 'S355 Weld Fatigue', query: 'What are the main fatigue class limits for stiffened transverse butt welds in S355 steel under cyclic loading?' },
    { title: 'Moment Splice Checks', query: 'List the critical step-by-step design checks required for a high-strength bolted moment endplate splice under Eurocode 3 (EN 1993-1-8).' },
    { title: 'EC3 vs BS 5950 LTB', query: 'Explain how Eurocode 3 (EN 1993-1-1) lateral torsional buckling (LTB) curves and reduction factors differ from the traditional BS 5950 method.' },
    { title: 'EXC3 Tolerances', query: 'What are the consequences of weld alignment deviations on load paths under the EN 1090 EXC3 execution class, and what are the allowable geometric limits?' }
  ];

  const handleQuerySubmit = async (text: string) => {
    if (!text.trim()) return;
    setIsLoading(true);
    setResponse(null);
    setError(null);

    try {
      const res = await fetch('/api/gemini', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: text }),
      });

      if (!res.ok) {
        throw new Error('Failed to retrieve engineering response.');
      }

      const data = await res.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setResponse(data.text);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred while connecting to the engineering intelligence route.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleQuerySubmit(query);
  };

  return (
    <section className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">DIGITAL EXPERT ADVISOR</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
              STEELWORK INTELLIGENCE
            </h2>
          </div>
          <p className="max-w-md text-sm text-zinc-400">
            Authoritative technical answers. Query our server-side engineering logic database for code standards, weld fatigue, section design, and fabrication tolerances.
          </p>
        </div>

        {/* Steelwork Intel grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left panel: Info Categories & suggestions (col-span-4) */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            
            {/* Intel category list */}
            <div className="bg-zinc-900 border border-zinc-800 p-6 flex flex-col gap-4">
              <span className="font-mono text-[10px] text-zinc-500 font-bold tracking-widest border-b border-zinc-800 pb-2 uppercase">
                INTELLIGENCE SCOPE
              </span>
              
              <div className="flex flex-col gap-4 text-xs font-mono">
                <div className="flex flex-col gap-0.5">
                  <span className="text-orange-500 font-bold">MATERIAL PROPERTIES</span>
                  <span className="text-zinc-400">S275 · S355 · S460 · Stainless · High-Strength Carbon</span>
                </div>
                <div className="flex flex-col gap-0.5">
                  <span className="text-orange-500 font-bold">STRUCTURE TYPES</span>
                  <span className="text-zinc-400">Frames · Truss Girders · Bridges · Plant Platforms · Towers</span>
                </div>
                <div className="flex flex-col gap-0.5">
                  <span className="text-orange-500 font-bold">CONNECTION PROFILES</span>
                  <span className="text-zinc-400">Bolted Moment · Welded Fillet · Splices · Anchor Base Plates</span>
                </div>
                <div className="flex flex-col gap-0.5">
                  <span className="text-orange-500 font-bold">STRUCTURAL BEHAVIOURS</span>
                  <span className="text-zinc-400">Strength · Deflection · Fatigue limit · Vibration · Lateral Torsion</span>
                </div>
              </div>
            </div>

            {/* Predefined queries suggestions list */}
            <div className="flex flex-col gap-3">
              <span className="font-mono text-[10px] text-zinc-500 font-bold tracking-widest uppercase">
                SUGGESTED ENQUIRIES
              </span>
              <div className="flex flex-col gap-2">
                {suggestions.map((s, idx) => (
                  <button
                    key={idx}
                    disabled={isLoading}
                    onClick={() => {
                      setQuery(s.query);
                      handleQuerySubmit(s.query);
                    }}
                    className="w-full text-left bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 p-3 text-xs font-semibold text-zinc-300 hover:text-zinc-100 transition-colors flex items-center justify-between gap-3 group"
                  >
                    <span>{s.title}</span>
                    <CornerDownLeft className="h-3 w-3 text-zinc-600 group-hover:text-orange-500 transition-colors shrink-0" />
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right panel: Active Chatbot interface (col-span-8) */}
          <div className="lg:col-span-8 bg-zinc-900 border border-zinc-800 flex flex-col justify-between h-[520px]">
            
            {/* Intelligence response viewport area */}
            <div className="p-6 sm:p-8 flex-grow overflow-y-auto bg-zinc-950 border-b border-zinc-800 flex flex-col gap-6 font-mono text-xs text-zinc-400">
              
              {!response && !isLoading && !error && (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 gap-3 my-auto">
                  <Cpu className="h-10 w-10 text-zinc-700 animate-pulse stroke-1" />
                  <span className="font-bold text-zinc-500 tracking-wider">ENGINEERING COMPILER PORTAL</span>
                  <p className="text-zinc-600 max-w-sm text-[11px] leading-relaxed">
                    Select one of the suggested structural queries on the left or input your custom connection design problem below.
                  </p>
                </div>
              )}

              {/* Loading display spinner */}
              {isLoading && (
                <div className="h-full flex flex-col items-center justify-center gap-4 my-auto">
                  <Loader2 className="h-8 w-8 text-orange-500 animate-spin" />
                  <span className="font-bold text-zinc-500 text-[10px] tracking-widest">
                    COMPILING STRUCTURAL RESPONSE...
                  </span>
                </div>
              )}

              {/* Error display */}
              {error && (
                <div className="bg-red-500/10 border border-red-500/40 p-4 flex gap-3 text-red-500 text-xs my-auto">
                  <HelpCircle className="h-5 w-5 shrink-0" />
                  <div>
                    <span className="font-bold">COMPILER FAULT:</span> {error}
                  </div>
                </div>
              )}

              {/* Real compiled Markdown/text response */}
              {response && !isLoading && (
                <div className="flex flex-col gap-4 select-text leading-relaxed">
                  <div className="flex items-center gap-2 border-b border-zinc-900 pb-2">
                    <div className="h-2 w-2 rounded-full bg-emerald-500" />
                    <span className="font-bold text-zinc-200">VERIFIED METADATA REPORT — SSC-INTEL</span>
                  </div>
                  <div className="text-zinc-300 font-sans text-sm sm:text-base whitespace-pre-line leading-relaxed flex flex-col gap-4">
                    {response}
                  </div>
                </div>
              )}

            </div>

            {/* Input submission footer */}
            <form onSubmit={handleFormSubmit} className="bg-zinc-900 p-4 flex gap-3 items-stretch">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                disabled={isLoading}
                placeholder="Ask our principal engineer about connections, welds, material grades..."
                className="flex-grow bg-zinc-950 text-zinc-200 text-xs font-mono font-bold px-4 py-3 border border-zinc-800 outline-none focus:border-orange-500 disabled:opacity-55"
              />
              <button
                type="submit"
                disabled={isLoading || !query.trim()}
                className="bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-600 px-6 font-mono text-xs font-bold text-zinc-950 transition-all flex items-center justify-center gap-2"
              >
                COMPILE
                <Play className="h-3 w-3 fill-zinc-950" />
              </button>
            </form>

            {/* Status assurance disclaimer */}
            <div className="bg-zinc-950 border-t border-zinc-800 px-4 py-2 font-mono text-[8px] text-zinc-600 flex items-center gap-2">
              <ShieldAlert className="h-3.5 w-3.5 text-orange-500 shrink-0" />
              <span>LOGGED // ADVICE COMPILED VIA SERVER SIDE API INTERRUPTS // SSC-ENGINEERING-VERIFIED</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
