'use client';

import React from 'react';
import { Factory, Construction, ShieldAlert, Zap, Landmark, Wrench, Globe, Hammer } from 'lucide-react';

interface Sector {
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
}

export default function Sectors() {
  const sectors: Sector[] = [
    {
      title: 'STEEL PRODUCTION',
      desc: 'Process structures, equipment supports, furnace framing, material handling conveyor bridges and heavy steelworks industrial infrastructure.',
      icon: Factory
    },
    {
      title: 'MANUFACTURING',
      desc: 'Factories, high-capacity production lines, machinery load-bearing platforms, maintenance walkways, gantries and safe access systems.',
      icon: Hammer
    },
    {
      title: 'INFRASTRUCTURE',
      desc: 'Rail depots, maintenance stations, highway bridge frames, utility bridges, platforms, overhead gantries and infrastructure steelwork.',
      icon: Construction
    },
    {
      title: 'ENERGY & PROCESS',
      desc: 'Industrial energy facilities, complex equipment framing structures, process towers, pipe bridges and support frames for heavy piping manifolds.',
      icon: Zap
    },
    {
      title: 'COMMERCIAL',
      desc: 'Commercial structural frames, heavy steel refurbishments, floor layout transformations and technically demanding internal interventions.',
      icon: Globe
    },
    {
      title: 'INDUSTRIAL HERITAGE',
      desc: 'Rigorous structural assessment, load-bearing verification, repair details, preservation, and reinforcement of historic British industrial iron and steelwork.',
      icon: Landmark
    },
    {
      title: 'FABRICATION SUPPORT',
      desc: 'Providing third-party technical checking, connection design verification, erection methodologies, and tolerances verification for steel fabricators.',
      icon: Wrench
    },
    {
      title: 'SPECIAL PROJECTS',
      desc: 'Unusual, bespoke geometric framing and structural intersections where standard code shortcuts fail and custom finite-element verification is required.',
      icon: ShieldAlert
    }
  ];

  return (
    <section className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">SECTOR EXPERTISE</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
              SECTORS WE SERVE
            </h2>
          </div>
          <p className="max-w-md text-sm text-zinc-400">
            Providing authoritative steel engineering where safety, mechanical precision, and practical constructability are non-negotiable.
          </p>
        </div>

        {/* Sectors Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sectors.map((sector, idx) => {
            const Icon = sector.icon;
            return (
              <div
                key={idx}
                className="bg-zinc-900 border border-zinc-800 p-8 flex flex-col justify-between gap-6 hover:border-zinc-700 transition-colors"
              >
                <div className="flex flex-col gap-4">
                  {/* Icon */}
                  <div className="text-orange-500 w-8 h-8 flex items-center justify-center">
                    <Icon className="h-6 w-6" />
                  </div>
                  
                  {/* Title */}
                  <h3 className="font-mono text-sm font-bold tracking-widest text-zinc-100">
                    {sector.title}
                  </h3>
                  
                  {/* Description */}
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed font-normal">
                    {sector.desc}
                  </p>
                </div>

                {/* Sub-grid counter */}
                <div className="font-mono text-[9px] text-zinc-600 border-t border-zinc-800/60 pt-4 text-right">
                  SSC // { (idx + 1).toString().padStart(2, '0') }
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
