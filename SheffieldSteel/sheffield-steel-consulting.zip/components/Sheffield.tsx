'use client';

import React from 'react';
import Image from 'next/image';

export default function Sheffield() {
  return (
    <section className="relative bg-zinc-950 py-24 md:py-32 overflow-hidden border-t border-zinc-900">
      
      {/* Background visual asset overlay with scrim */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/sheffield_landscape_1790779624158.jpg"
          alt="Sheffield industrial hills and steelworks, South Yorkshire"
          fill
          className="object-cover opacity-20 filter grayscale"
          sizes="100vw"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/90 to-zinc-950/40" />
        <div className="absolute inset-0 bg-zinc-950/30" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left: Heading & Prose (col-span-7) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">HERITAGE & ORIGIN</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
              BUILT IN SHEFFIELD.
            </h2>

            <div className="flex flex-col gap-6 text-zinc-400 text-base sm:text-lg leading-relaxed max-w-2xl font-normal">
              <p>
                Sheffield has spent generations learning how steel behaves. That industrial knowledge still matters.
              </p>
              <p className="text-zinc-300">
                Our practice is based in the city and works across the boundary between engineering consultancy, manufacturing and construction.
              </p>
              <p>
                We do not treat steel as an abstract line on a screen or a factor in an idealized spreadsheet. We treat it with the respect of a material we have lived alongside, cut, welded, and erected for decades.
              </p>
            </div>

            {/* Direct, non-cliché brand voice quote */}
            <div className="border-l-4 border-orange-500 pl-6 my-2 italic text-zinc-400">
              &ldquo;Fabrication is part of engineering.&rdquo;
            </div>
          </div>

          {/* Right: Technical coordinate markers & details (col-span-5) */}
          <div className="lg:col-span-5 bg-zinc-900/60 border border-zinc-800 p-8 backdrop-blur-md">
            <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-300 border-b border-zinc-800 pb-3 mb-4">
              REGIONAL SPECIFICATION
            </h3>

            <div className="flex flex-col gap-4 font-mono text-xs text-zinc-400">
              <div className="flex justify-between items-baseline py-1.5 border-b border-zinc-900">
                <span>LATITUDE</span>
                <span className="text-zinc-100">53.3811&deg; N</span>
              </div>
              <div className="flex justify-between items-baseline py-1.5 border-b border-zinc-900">
                <span>LONGITUDE</span>
                <span className="text-zinc-100">1.4701&deg; W</span>
              </div>
              <div className="flex justify-between items-baseline py-1.5 border-b border-zinc-900">
                <span>TERRITORY</span>
                <span className="text-zinc-100">South Yorkshire, UK</span>
              </div>
              <div className="flex justify-between items-baseline py-1.5 border-b border-zinc-900">
                <span>INDUSTRIAL ROOTS</span>
                <span className="text-zinc-100">Bessemer & Brearley Legacy</span>
              </div>
            </div>

            <div className="mt-8 text-[10px] leading-relaxed text-zinc-500 font-mono">
              Sheffield Steel Consulting, Vulcan Works, Kelham Island, Sheffield S3 8MZ.
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
