'use client';

import React, { useState, useRef, useEffect } from 'react';
import { RotateCw, Maximize2, Layers, AlertCircle, Play } from 'lucide-react';

interface Point3D {
  x: number;
  y: number;
  z: number;
}

interface Member {
  p1: number; // point index
  p2: number; // point index
  type: 'column' | 'beam' | 'brace' | 'plate';
  label: string;
}

// Model parameters for Frame-042
const points: Point3D[] = [
  // Base joints
  { x: -120, y: 100, z: -80 }, // 0
  { x: -120, y: 100, z: 80 },  // 1
  { x: 120, y: 100, z: -80 },  // 2
  { x: 120, y: 100, z: 80 },   // 3
  
  // Column tops (4m level)
  { x: -120, y: -60, z: -80 }, // 4
  { x: -120, y: -60, z: 80 },  // 5
  { x: 120, y: -60, z: -80 },  // 6
  { x: 120, y: -60, z: 80 },   // 7

  // Apex coordinates (6.5m level)
  { x: 0, y: -120, z: -80 },   // 8
  { x: 0, y: -120, z: 80 },    // 9
];

const members: Member[] = [
  // Columns
  { p1: 0, p2: 4, type: 'column', label: 'COL-A1' },
  { p1: 1, p2: 5, type: 'column', label: 'COL-A2' },
  { p1: 2, p2: 6, type: 'column', label: 'COL-B1' },
  { p1: 3, p2: 7, type: 'column', label: 'COL-B2' },

  // Eaves ties / Beams
  { p1: 4, p2: 5, type: 'beam', label: 'EAVES-A' },
  { p1: 6, p2: 7, type: 'beam', label: 'EAVES-B' },
  { p1: 4, p2: 6, type: 'beam', label: 'TIE-1' },
  { p1: 5, p2: 7, type: 'beam', label: 'TIE-2' },

  // Portal Rafters
  { p1: 4, p2: 8, type: 'beam', label: 'RAFTER-A1' },
  { p1: 6, p2: 8, type: 'beam', label: 'RAFTER-B1' },
  { p1: 5, p2: 9, type: 'beam', label: 'RAFTER-A2' },
  { p1: 7, p2: 9, type: 'beam', label: 'RAFTER-B2' },

  // Ridge beam
  { p1: 8, p2: 9, type: 'beam', label: 'RIDGE-GIRT' },

  // Bracing
  { p1: 0, p2: 5, type: 'brace', label: 'X-BRACE-1' },
  { p1: 1, p2: 4, type: 'brace', label: 'X-BRACE-2' },
  { p1: 2, p2: 7, type: 'brace', label: 'X-BRACE-3' },
  { p1: 3, p2: 6, type: 'brace', label: 'X-BRACE-4' },
];

export default function DigitalEngineering() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [rotation, setRotation] = useState({ x: -25, y: 35 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  
  // Controls
  const [selectedSection, setSelectedSection] = useState('UB 610 × 229 × 113');
  const [selectedLoadCase, setSelectedLoadCase] = useState('LC01 Dead');
  const [showLoads, setShowLoads] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);
  const [showNodes, setShowNodes] = useState(true);
  const [viewMode, setViewMode] = useState<'undeformed' | 'deformed' | 'stress'>('stress');
  const [autoRotate, setAutoRotate] = useState(true);

  // Auto rotation tick
  useEffect(() => {
    if (!autoRotate || isDragging) return;
    const interval = setInterval(() => {
      setRotation(prev => ({ ...prev, y: (prev.y + 0.3) % 360 }));
    }, 16);
    return () => clearInterval(interval);
  }, [autoRotate, isDragging]);

  // Handle Dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    dragStart.current = { x: e.clientX, y: e.clientY };

    setRotation(prev => ({
      x: Math.max(-80, Math.min(80, prev.x - dy * 0.5)),
      y: (prev.y + dx * 0.5) % 360
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Draw the 3D model
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear with dark tech background
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grid center mapping
    const cx = canvas.width / 2;
    const cy = canvas.height / 2 + 20;

    // Projection calculation
    const radX = (rotation.x * Math.PI) / 180;
    const radY = (rotation.y * Math.PI) / 180;

    const cosX = Math.cos(radX);
    const sinX = Math.sin(radX);
    const cosY = Math.cos(radY);
    const sinY = Math.sin(radY);

    const project = (p: Point3D) => {
      // 3D rotation on Y (yaw)
      let x1 = p.x * cosY - p.z * sinY;
      let z1 = p.x * sinY + p.z * cosY;

      // 3D rotation on X (pitch)
      let y2 = p.y * cosX - z1 * sinX;
      let z2 = p.y * sinX + z1 * cosX;

      // Perspective scale factor
      const fov = 400;
      const d = 300; // view distance
      const scale = fov / (fov + z2 + d);

      // Deformed modifier if active
      let dx = 0;
      let dy = 0;
      if (viewMode === 'deformed' || viewMode === 'stress') {
        // Apply tiny sine deformation mapping load case
        const factor = selectedLoadCase.includes('Wind') ? 1.8 : 1.0;
        dx = Math.sin(p.y * 0.05) * 6 * factor;
        dy = (p.x !== 0 ? Math.abs(p.x) * 0.04 : 8) * factor;
      }

      return {
        x: cx + (x1 + dx) * scale * 1.5,
        y: cy + (y2 + dy) * scale * 1.5,
        z: z2,
        scale
      };
    };

    // Projected coordinate list
    const projectedPoints = points.map(project);

    // 1. Draw Ground Grid Floor reference
    ctx.strokeStyle = '#1e1e24';
    ctx.lineWidth = 1;
    for (let i = -4; i <= 4; i++) {
      const pGridStart1 = project({ x: -160, y: 100, z: i * 30 });
      const pGridEnd1 = project({ x: 160, y: 100, z: i * 30 });
      ctx.beginPath();
      ctx.moveTo(pGridStart1.x, pGridStart1.y);
      ctx.lineTo(pGridEnd1.x, pGridEnd1.y);
      ctx.stroke();

      const pGridStart2 = project({ x: i * 35, y: 100, z: -100 });
      const pGridEnd2 = project({ x: i * 35, y: 100, z: 100 });
      ctx.beginPath();
      ctx.moveTo(pGridStart2.x, pGridStart2.y);
      ctx.lineTo(pGridEnd2.x, pGridEnd2.y);
      ctx.stroke();
    }

    // 2. Draw Members
    members.forEach((member) => {
      const pt1 = projectedPoints[member.p1];
      const pt2 = projectedPoints[member.p2];

      ctx.beginPath();
      ctx.moveTo(pt1.x, pt1.y);
      ctx.lineTo(pt2.x, pt2.y);

      // Style based on view mode and member type
      if (viewMode === 'stress') {
        // Structural stress gradients (Blue is low tension, red is high compression)
        const gradient = ctx.createLinearGradient(pt1.x, pt1.y, pt2.x, pt2.y);
        if (member.type === 'column') {
          gradient.addColorStop(0, '#00c3ff'); // Blue
          gradient.addColorStop(0.5, '#00ff88'); // Green
          gradient.addColorStop(1, '#ff8c00'); // Orange
          ctx.strokeStyle = gradient;
          ctx.lineWidth = 4 * pt1.scale;
        } else if (member.type === 'brace') {
          ctx.strokeStyle = '#00ffcc';
          ctx.lineWidth = 1.5 * pt1.scale;
        } else { // beams rafters
          gradient.addColorStop(0, '#ff3b30'); // Red moment at eave
          gradient.addColorStop(0.5, '#00ff88'); // Green midpoint
          gradient.addColorStop(1, '#ff3b30'); // Red moment at ridge
          ctx.strokeStyle = gradient;
          ctx.lineWidth = 3.5 * pt1.scale;
        }
      } else {
        // Simple lines
        ctx.strokeStyle = member.type === 'column' ? '#e4e4e7' : member.type === 'brace' ? '#f59e0b' : '#a1a1aa';
        ctx.lineWidth = member.type === 'column' ? 3.5 : member.type === 'brace' ? 1.5 : 2.5;
        ctx.lineWidth *= pt1.scale;
      }
      ctx.stroke();

      // Show Member labels subtly if dragging is low
      if (!isDragging && member.type === 'column' && pt1.scale > 0.8) {
        ctx.fillStyle = '#71717a';
        ctx.font = '9px monospace';
        ctx.fillText(member.label, (pt1.x + pt2.x) / 2 + 8, (pt1.y + pt2.y) / 2);
      }
    });

    // 3. Draw Support symbols (ground boundaries)
    ctx.fillStyle = '#ff8c00';
    [0, 1, 2, 3].forEach((idx) => {
      const pt = projectedPoints[idx];
      ctx.beginPath();
      ctx.moveTo(pt.x, pt.y);
      ctx.lineTo(pt.x - 6, pt.y + 10);
      ctx.lineTo(pt.x + 6, pt.y + 10);
      ctx.closePath();
      ctx.fill();
    });

    // 4. Draw Point Load arrows if showLoads is active
    if (showLoads) {
      ctx.fillStyle = '#ff3b30';
      ctx.strokeStyle = '#ff3b30';
      ctx.lineWidth = 2;
      
      // Load applied at the ridge (points 8, 9)
      [8, 9].forEach((idx) => {
        const pt = projectedPoints[idx];
        ctx.beginPath();
        ctx.moveTo(pt.x, pt.y - 30);
        ctx.lineTo(pt.x, pt.y - 5);
        ctx.stroke();

        // Arrowhead
        ctx.beginPath();
        ctx.moveTo(pt.x, pt.y - 5);
        ctx.lineTo(pt.x - 4, pt.y - 12);
        ctx.lineTo(pt.x + 4, pt.y - 12);
        ctx.closePath();
        ctx.fill();

        // Label
        ctx.fillStyle = '#ff3b30';
        ctx.font = 'bold 9px monospace';
        ctx.fillText('120 kN', pt.x + 8, pt.y - 20);
      });
    }

    // 5. Draw Dimension Annotations
    if (showDimensions && !isDragging) {
      ctx.strokeStyle = '#52525b';
      ctx.fillStyle = '#71717a';
      ctx.lineWidth = 1;
      ctx.font = '9px monospace';

      // Width Dimension (base point 0 to 2)
      const p0 = projectedPoints[0];
      const p2 = projectedPoints[2];
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y + 20);
      ctx.lineTo(p2.x, p2.y + 20);
      ctx.stroke();
      ctx.fillText('12000 mm Span', (p0.x + p2.x) / 2 - 40, (p0.y + p2.y) / 2 + 25);

      // Height Dimension (point 0 to 4)
      const p4 = projectedPoints[4];
      ctx.beginPath();
      ctx.moveTo(p0.x - 20, p0.y);
      ctx.lineTo(p4.x - 20, p4.y);
      ctx.stroke();
      ctx.fillText('4500 mm Eaves', (p0.x + p4.x) / 2 - 90, (p0.y + p4.y) / 2);
    }

    // 6. Draw Nodes (Joints)
    if (showNodes) {
      projectedPoints.forEach((pt, idx) => {
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 3 * pt.scale, 0, 2 * Math.PI);
        ctx.fillStyle = idx >= 8 ? '#ff3b30' : '#ffffff';
        ctx.fill();
        ctx.strokeStyle = '#09090b';
        ctx.lineWidth = 1;
        ctx.stroke();

        if (!isDragging && pt.scale > 0.8) {
          ctx.fillStyle = '#a1a1aa';
          ctx.font = '8px monospace';
          ctx.fillText(`N${idx}`, pt.x + 6, pt.y - 6);
        }
      });
    }

  }, [rotation, showLoads, showDimensions, showNodes, viewMode, selectedLoadCase, isDragging]);

  // Handle Resize of canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = canvas.parentElement?.clientWidth || 700;
    canvas.height = 450;
  }, []);

  return (
    <section id="engineering" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Title */}
        <div className="flex flex-col gap-3 mb-16 max-w-3xl">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
            <span className="font-mono text-xs font-bold tracking-widest text-orange-500">DIGITAL DIGITAL ENGINEERING</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
            THE STEEL EXISTS TWICE.
          </h2>
          <p className="text-base sm:text-lg text-zinc-400 font-normal mt-2 leading-relaxed text-wrap-balance">
            First as a model. Then as a structure. We engineer every member with digital precision before fabrication, minimizing material waste and eliminating site assembly conflicts.
          </p>
        </div>

        {/* Workspace Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Visualiser Canvas Frame (col-span-8) */}
          <div className="lg:col-span-8 bg-zinc-900 border border-zinc-800 flex flex-col justify-between relative overflow-hidden group select-none">
            
            {/* Header Telemetry bar */}
            <div className="bg-zinc-950 border-b border-zinc-800 px-4 py-3 flex items-center justify-between font-mono text-[10px] text-zinc-400">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5 text-orange-500 font-bold">
                  <span className="h-2 w-2 rounded-full bg-orange-500 animate-pulse" />
                  3D ANALYTICAL MODEL
                </span>
                <span>/</span>
                <span>ID: FRAME-042</span>
                <span>/</span>
                <span className="text-zinc-500 uppercase">{viewMode} VIEW</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-500">
                <span>ROTATE: X {Math.round(rotation.x)}&deg; Y {Math.round(rotation.y)}&deg;</span>
              </div>
            </div>

            {/* Canvas Viewer */}
            <div className="relative w-full h-[450px] flex-grow cursor-grab active:cursor-grabbing">
              <canvas
                ref={canvasRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                className="block w-full h-full"
              />

              {/* Float hint helper */}
              <div className="absolute bottom-4 left-4 bg-zinc-950/80 border border-zinc-800 px-3 py-1.5 font-mono text-[9px] text-zinc-400 pointer-events-none">
                DRAG MOUSE TO ROTATE FRAME IN 3D
              </div>

              {/* Stress Heatmap Scale (only displayed in stress view mode) */}
              {viewMode === 'stress' && (
                <div className="absolute right-4 bottom-4 bg-zinc-950/95 border border-zinc-800 p-3 font-mono text-[9px] text-zinc-400 flex flex-col gap-2">
                  <div className="font-bold border-b border-zinc-800 pb-1">MOMENT STRESS (MPa)</div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-16 bg-gradient-to-r from-cyan-400 via-green-400 to-red-500" />
                  </div>
                  <div className="flex justify-between text-[8px] text-zinc-500">
                    <span>0</span>
                    <span>175</span>
                    <span>355</span>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Control Bar */}
            <div className="bg-zinc-950 border-t border-zinc-800 px-4 py-3 flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
              
              {/* Toggles */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setShowLoads(!showLoads)}
                  className={`px-2.5 py-1 border transition-colors ${showLoads ? 'bg-orange-500/10 border-orange-500 text-orange-500' : 'border-zinc-800 text-zinc-500'}`}
                >
                  LOAD VECTOR
                </button>
                <button
                  onClick={() => setShowDimensions(!showDimensions)}
                  className={`px-2.5 py-1 border transition-colors ${showDimensions ? 'bg-zinc-100/10 border-zinc-200 text-zinc-200' : 'border-zinc-800 text-zinc-500'}`}
                >
                  DIMENSIONS
                </button>
                <button
                  onClick={() => setShowNodes(!showNodes)}
                  className={`px-2.5 py-1 border transition-colors ${showNodes ? 'bg-zinc-100/10 border-zinc-200 text-zinc-200' : 'border-zinc-800 text-zinc-500'}`}
                >
                  NODES
                </button>
                <button
                  onClick={() => setAutoRotate(!autoRotate)}
                  className={`flex items-center gap-1 px-2.5 py-1 border transition-colors ${autoRotate ? 'bg-zinc-100/10 border-zinc-200 text-zinc-200' : 'border-zinc-800 text-zinc-500'}`}
                >
                  <RotateCw className={`h-3 w-3 ${autoRotate ? 'animate-spin' : ''}`} />
                  SPIN
                </button>
              </div>

              {/* View Selector */}
              <div className="flex items-center gap-1 bg-zinc-900 p-0.5 border border-zinc-800">
                {(['undeformed', 'deformed', 'stress'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={`px-2 py-1 text-[10px] font-bold uppercase transition-colors ${viewMode === mode ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'}`}
                  >
                    {mode}
                  </button>
                ))}
              </div>

            </div>

          </div>

          {/* Right Control & Properties Panel (col-span-4) */}
          <div className="lg:col-span-4 bg-zinc-900 border border-zinc-800 p-8 flex flex-col justify-between gap-8">
            
            <div className="flex flex-col gap-6">
              
              {/* Telemetry metadata block */}
              <div>
                <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-400 border-b border-zinc-800 pb-3 mb-4">
                  PROPERTIES & RESULTS
                </h3>
                
                <div className="grid grid-cols-2 gap-x-4 gap-y-3 font-mono text-xs">
                  <div className="text-zinc-500">MODEL REFS</div>
                  <div className="text-zinc-200 text-right font-bold">FRAME-042</div>

                  <div className="text-zinc-500">MATERIAL</div>
                  <div className="text-zinc-200 text-right">S355 JR / JO</div>

                  <div className="text-zinc-500">GRADE CAPACITY</div>
                  <div className="text-zinc-200 text-right">355 N/mm²</div>

                  <div className="text-zinc-500">CONNECTION</div>
                  <div className="text-zinc-200 text-right">Bolted Moment</div>

                  <div className="text-zinc-500">STATUS</div>
                  <div className="text-emerald-500 text-right font-bold">VERIFIED</div>
                </div>
              </div>

              {/* Interactive Section Profile Selector */}
              <div className="flex flex-col gap-2">
                <label className="font-mono text-[10px] font-bold tracking-widest text-orange-500">
                  SECTION MEMBER PROFILE
                </label>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="bg-zinc-950 text-zinc-200 text-xs font-mono font-bold p-3 border border-zinc-800 outline-none focus:border-orange-500"
                >
                  <option value="UB 610 × 229 × 113">UB 610 × 229 × 113 (Primary Beam)</option>
                  <option value="UC 305 × 305 × 97">UC 305 × 305 × 97 (Column Frame)</option>
                  <option value="CHS 219.1 × 10.0">CHS 219.1 × 10.0 (Circular Brace)</option>
                  <option value="SHS 150 × 150 × 8.0">SHS 150 × 150 × 8.0 (Box Column)</option>
                </select>
              </div>

              {/* Load Case Combiner */}
              <div className="flex flex-col gap-2">
                <label className="font-mono text-[10px] font-bold tracking-widest text-orange-500">
                  LOAD COMBINATION
                </label>
                <div className="flex flex-col gap-1.5 font-mono text-[11px]">
                  {['LC01 Dead', 'LC02 Imposed', 'LC03 Wind', 'LC04 Crane', 'LC05 Thermal'].map((lc) => (
                    <button
                      key={lc}
                      onClick={() => setSelectedLoadCase(lc)}
                      className={`flex items-center justify-between p-2 border text-left transition-colors ${
                        selectedLoadCase === lc
                          ? 'bg-orange-500/10 border-orange-500 text-orange-500 font-bold'
                          : 'bg-zinc-950 border-zinc-850 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <span>{lc}</span>
                      <span className="text-[9px] text-zinc-500">
                        {lc === 'LC01 Dead' ? '1.35 Gk' : lc === 'LC03 Wind' ? '1.5 Qk' : '1.50 Gk'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Quick alert */}
            <div className="bg-zinc-950/40 border border-zinc-800 p-4 flex gap-3 text-xs leading-relaxed text-zinc-400">
              <AlertCircle className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-zinc-200">NOTE:</span> Geometry is mathematically locked. Interactive analysis is a visual demonstration. Formal calculations require signed validation report.
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
