'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, BookOpen, Clock, FileText, Share2 } from 'lucide-react';

interface Article {
  id: string;
  title: string;
  abstract: string;
  readTime: string;
  category: string;
  date: string;
  content: string[];
}

export default function Insights() {
  const [activeArticle, setActiveArticle] = useState<Article | null>(null);

  const articles: Article[] = [
    {
      id: 'art-1',
      title: 'Why steel connections often determine the entire structure',
      abstract: 'In structural steelwork design, members get the glory, but the joints do the work. Overlooking connection behavior during global frame analysis leads to costly fabrication re-work, erection failures, and compromised global stability margins.',
      readTime: '8 min read',
      category: 'Joint Engineering',
      date: 'September 2026',
      content: [
        'Connection design represents the critical boundary where pure mathematics meets heavy workshop reality. While primary member sizing (selecting column and beam profiles) is relatively straightforward, the design of bolted moment splices, stiffened knee connections, and base plates holds absolute sway over global structural stability, fabrication economy, and erection speeds.',
        'A classical error in modern digital design is treating connections as idealized pinned or rigid boundaries during initial computer modeling. In reality, every joint behaves on a spectrum of semi-rigid partial strength. Neglecting joint rotational stiffness causes load distribution patterns in the physical structure that differ fundamentally from the computer calculation output, resulting in unpredicted local bending stresses and potential fatigue cracks.',
        'Furthermore, connection detailing dictates the fabrication layout. Oversized stiffeners, tight bolt spacing, and complex welded configurations can double the workshop labor hours per tonne. By analyzing joints alongside members from day one, engineers can align load paths with standard, readily fabricable plate configurations, ensuring structural safety without inflating project costs.'
      ]
    },
    {
      id: 'art-2',
      title: 'Designing steelwork for fabrication rather than simply calculation',
      abstract: 'A theoretically perfect computer-modeled structure is useless if it cannot be welded, transported, or erected. This paper details the essential principles of design-for-fabrication (DfF) and the economic impact of welding and detailing choices.',
      readTime: '6 min read',
      category: 'Workshop Practice',
      date: 'August 2026',
      content: [
        'Many structural engineers believe their responsibility ends when their calculations satisfy code criteria. However, a calculation is only useful if someone can physically build what is documented. True steel engineering is the art of balancing material capacity with workshop operations.',
        'Consider welding specifications: specifying continuous full-penetration butt welds where simple intermittent fillet welds are sufficient can increase joint preparation costs by 300% and introduce severe thermal distortion in steel plates. Fabrication-conscious design prioritizes welding symbols that allow standard flat-position welding and avoids creating tight pockets where a welder cannot reach with an electrode.',
        'Erection sequencing must also govern the design. Providing generous bolt clearance holes, splice connection positions that permit stable self-supporting erection stages, and lifting eye brackets pre-verified for rigging angles ensures that steelwork goes together safely and efficiently when it reaches the site.'
      ]
    },
    {
      id: 'art-3',
      title: 'What makes an industrial structure difficult to modify?',
      abstract: 'Industrial facilities require frequent machinery upgrades and modifications. This paper outlines the structural bottlenecks—including load path redundancy, lack of splice capacity, and weld fatigue history—that complicate steelwork alterations.',
      readTime: '10 min read',
      category: 'Alterations & Refurbishment',
      date: 'July 2026',
      content: [
        'Process plants and manufacturing facilities are living systems. Over a thirty-year lifespan, a factory may undergo five major process upgrades, each requiring new heavy machinery, pipe manifolds, or platforms to be integrated into the existing framing.',
        'The primary bottleneck in modifying steelwork is rarely the load-carrying member itself; it is the connection capacity and the load-path history. If existing joints were designed strictly for the original dead load without spare moment or shear capacity, minor equipment changes require complete connection reinforcement, which requires hazardous site welding or complex bolt drill-out.',
        'Before intervening in an existing structure, a rigorous digital condition assessment and load-verification sequence are mandatory. Meticulous ultrasonic thickness mapping and non-destructive weld testing provide the empirical evidence required to validate strengthening strategies, turning complex structural alterations into predictable engineering stages.'
      ]
    },
    {
      id: 'art-4',
      title: 'Fatigue in welded steel structures',
      abstract: 'Under repetitive dynamic cyclic loading, steelwork can fail at stress levels far below its static yield point. We review fatigue behavior, stress concentration factors, and joint detailing for severe industrial services.',
      readTime: '9 min read',
      category: 'Structural Mechanics',
      date: 'June 2026',
      content: [
        'Fatigue is the quiet killer of industrial steel structures. Under cyclic loads—such as those from overhead crane rails, reciprocating machinery, or wind-induced vortex shedding—microscopic cracks propagate from weld toes and bolt holes, culminating in sudden, brittle fracture without warning.',
        'The static yield strength of the steel grade (e.g., S275 vs S355) has almost no impact on its fatigue capacity. Instead, fatigue is entirely governed by joint detailing and local stress concentration factors (SCF). Poorly detailing a connection can drop its fatigue life by a factor of ten.',
        'To mitigate fatigue, engineers must eliminate abrupt geometric transitions. Smooth taper plates, full-penetration welds ground flush, and placing connection splices away from peak stress regions are critical safeguards. Routine non-destructive testing (NDT) and visual inspections during operation are the final defense lines against cyclic joint collapse.'
      ]
    },
    {
      id: 'art-5',
      title: 'The economics of structural steel',
      abstract: 'Material weight represents only a fraction of structural steel costs. This paper breaks down the true economics of fabrication labor, transport, erection craneage, and steel grade choices.',
      readTime: '7 min read',
      category: 'Project Economics',
      date: 'May 2026',
      content: [
        'A common mistake in structural design is optimizing strictly for minimum weight. Engineers will spend hours reducing beam sizes, believing they are saving the client money. However, in modern British steelwork, material weight constitutes less than 40% of the total fabricated, delivered, and erected cost.',
        'The true cost drivers are labor hours in the workshop and on site. Specifying custom plate girders to save a few kilograms of standard universal beam weight is highly uneconomical because the plate girder requires extensive welding and inspection labor. Standard rolled sections are almost always the cheaper option.',
        'Furthermore, specifying S355 steel instead of S275 provides a 30% yield strength increase for less than a 5% material cost premium. This yield capacity allows thinner, lighter structures, decreasing shipping weights and crane lift sizes, which yields compounding financial benefits across the project lifecycle.'
      ]
    },
    {
      id: 'art-6',
      title: 'Existing steelwork: inspection before intervention',
      abstract: 'Before modifying or reinforcing existing steel structures, engineers must gather physical evidence. We review non-destructive testing, corrosion mapping, and material sampling protocols.',
      readTime: '8 min read',
      category: 'Technical Auditing',
      date: 'April 2026',
      content: [
        'When dealing with existing buildings or historic industrial steelwork, a calculation is only as accurate as its input assumptions. Designing strengthening measures based on original drawings without on-site structural verification is an unacceptable risk.',
        'Corrosion can compromise structural capacity in highly localized patterns. Ultrasonic thickness gauges allow engineers to map plate material loss without damaging the structures. For historic steel (especially wrought iron or early steel before 1950), metallurgical laboratory testing of small core samples is required to establish weldability and carbon content limits.',
        'Our practice follows a strict protocol of physical evidence first. Before designing any structural modification, we verify members, joints, welding conditions, and foundation details. This empirical discipline eliminates site surprises and protects our clients from unnecessary structural expenditures.'
      ]
    },
    {
      id: 'art-7',
      title: 'Designing platforms around the maintenance engineer',
      abstract: 'Industrial access steelwork is often treated as an afterthought, designed to minimum standard clearances. We argue for human-centric maintenance access layout to optimize industrial safety.',
      readTime: '6 min read',
      category: 'Industrial Design',
      date: 'March 2026',
      content: [
        'An industrial platform is not just a structural support; it is a working workplace for maintenance engineers who must handle heavy valves, pumps, and tools under demanding conditions.',
        'Designing access steelwork strictly to satisfy building code clearances often results in platforms that are awkward and hazardous to work on. High-quality industrial design considers handrail positions, safety gates, clear headspace heights, and the physical swing of heavy mechanical assemblies during maintenance cycles.',
        'Providing robust lifting davits and dedicated rigging hooks pre-engineered into the framing removes the hazard of temporary site rigging, protecting both the workers and the primary process structures from un-calculated load cases.'
      ]
    },
    {
      id: 'art-8',
      title: 'Why the simplest steel structure is often the best one',
      abstract: 'Complex geometry looks impressive in digital renderings, but simplex forms deliver maximum reliability, structural efficiency, and long-term serviceability.',
      readTime: '5 min read',
      category: 'Design Philosophy',
      date: 'February 2026',
      content: [
        'In engineering, complexity is often a sign of unresolved design conflicts. When an engineer cannot figure out how to transition forces cleanly, they introduce brackets, secondary beams, and compound joint configurations.',
        'The best structures are those that look clean and uncomplicated. A simple, linear load path minimize secondary stresses, eliminates complex eccentric load moments, and makes fabrication and assembly intuitive.',
        'Our practice prides itself on simplifying the difficult. We work to resolve load paths down to their essential members, connections, and boundaries. Because in steelwork, simple means safe, economical, and constructible.'
      ]
    }
  ];

  return (
    <section id="insights" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        <AnimatePresence mode="wait">
          {!activeArticle ? (
            /* Journal Overview Page */
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {/* Header Block */}
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
                    <span className="font-mono text-xs font-bold tracking-widest text-orange-500">TECHNICAL JOURNAL</span>
                  </div>
                  <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
                    ENGINEERING INSIGHTS
                  </h2>
                </div>
                <p className="max-w-md text-sm text-zinc-400">
                  Direct, technically rigorous engineering analyses. We write about steelworks, connection mechanics, fabrication economy, and structural modifications.
                </p>
              </div>

              {/* Articles Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {articles.map((article) => (
                  <div
                    key={article.id}
                    onClick={() => setActiveArticle(article)}
                    className="bg-zinc-900 border border-zinc-800 p-8 flex flex-col justify-between gap-8 cursor-pointer hover:border-zinc-700 transition-colors group"
                  >
                    <div className="flex flex-col gap-4">
                      {/* Zero-Pill Metadata Discipline */}
                      <div className="flex items-center gap-2 text-xs font-mono text-zinc-500 font-bold uppercase">
                        <span>{article.category}</span>
                        <span aria-hidden="true" className="text-orange-500">·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" />
                          {article.readTime}
                        </span>
                      </div>
                      
                      {/* Title */}
                      <h3 className="text-lg sm:text-xl font-extrabold text-zinc-100 tracking-tight leading-tight group-hover:text-orange-500 transition-colors">
                        {article.title}
                      </h3>
                      
                      {/* Abstract */}
                      <p className="text-sm text-zinc-400 leading-relaxed font-normal">
                        {article.abstract}
                      </p>
                    </div>

                    {/* Bottom read action */}
                    <div className="border-t border-zinc-800/60 pt-4 flex justify-between items-center font-mono text-xs font-bold tracking-widest text-orange-500">
                      <span>{article.date.toUpperCase()}</span>
                      <span className="group-hover:translate-x-1 transition-transform">READ PAPER →</span>
                    </div>
                  </div>
                ))}
              </div>

            </motion.div>
          ) : (
            /* Full Article Paper View */
            <motion.div
              key="paper"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="bg-zinc-900 border border-zinc-800 p-8 sm:p-12 max-w-4xl mx-auto"
            >
              {/* Back Button */}
              <button
                onClick={() => setActiveArticle(null)}
                className="flex items-center gap-2 font-mono text-xs font-bold tracking-widest text-orange-500 hover:text-orange-600 mb-8 border border-zinc-800 bg-zinc-950 px-4 py-2"
              >
                <ArrowLeft className="h-4 w-4" />
                BACK TO INSIGHTS
              </button>

              {/* Article Header */}
              <div className="flex flex-col gap-4 border-b border-zinc-850 pb-8 mb-8">
                
                {/* Zero-Pill Metadata */}
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-500 font-bold uppercase">
                  <span>{activeArticle.category}</span>
                  <span aria-hidden="true" className="text-orange-500">·</span>
                  <span>{activeArticle.date}</span>
                  <span aria-hidden="true" className="text-orange-500">·</span>
                  <span>{activeArticle.readTime}</span>
                </div>

                <h1 className="text-2xl sm:text-4xl font-extrabold text-zinc-100 tracking-tight leading-tight text-wrap-balance">
                  {activeArticle.title}
                </h1>
              </div>

              {/* Abstract display block */}
              <div className="bg-zinc-950 border-l-4 border-orange-500 p-6 mb-8 font-sans text-sm sm:text-base leading-relaxed text-zinc-300 italic font-semibold">
                <span className="font-mono text-[10px] text-orange-500 font-bold block mb-1 uppercase">ABSTRACT</span>
                &ldquo;{activeArticle.abstract}&rdquo;
              </div>

              {/* Article Prose content (British Editorial highly readable type) */}
              <div className="flex flex-col gap-6 text-zinc-400 text-sm sm:text-base leading-relaxed font-normal max-w-3xl">
                {activeArticle.content.map((paragraph, idx) => (
                  <p key={idx}>{paragraph}</p>
                ))}
              </div>

              {/* Article Footer telemetry */}
              <div className="mt-12 pt-8 border-t border-zinc-850 flex flex-wrap items-center justify-between gap-4 font-mono text-[10px] text-zinc-500">
                <div className="flex items-center gap-1.5">
                  <FileText className="h-3.5 w-3.5" />
                  <span>REF: SSC-PAPER-{activeArticle.id.toUpperCase()}</span>
                </div>
                <span>© SHEFFIELD STEEL CONSULTING JOURNAL</span>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
