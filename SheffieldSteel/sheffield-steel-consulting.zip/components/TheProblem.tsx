'use client';

import React from 'react';
import { motion } from 'motion/react';

export default function TheProblem() {
  return (
    <section className="relative bg-zinc-950 border-t border-zinc-900 py-32 overflow-hidden">
      {/* Background visual detail: thin structural grid lines */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-5">
        <div className="absolute left-[15%] top-0 bottom-0 w-[1px] bg-zinc-100" />
        <div className="absolute left-[50%] top-0 bottom-0 w-[1px] bg-zinc-100" />
        <div className="absolute left-[85%] top-0 bottom-0 w-[1px] bg-zinc-100" />
        <div className="absolute top-[30%] left-0 right-0 h-[1px] bg-zinc-100" />
        <div className="absolute top-[70%] left-0 right-0 h-[1px] bg-zinc-100" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <div className="flex flex-col items-start gap-12 max-w-4xl">
          
          {/* Large, tightly-spaced, confident brand headings */}
          <div className="flex flex-col gap-2">
            <span className="font-mono text-xs font-bold tracking-widest text-orange-500 mb-2 block">
              THE CORE METAPHOR
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tighter text-zinc-100 leading-none">
              STEEL IS A MATERIAL.
            </h2>
            <h2 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tighter text-orange-500 leading-none">
              ENGINEERING IS THE JUDGEMENT.
            </h2>
          </div>

          {/* Core Brand Prose */}
          <div className="border-t border-zinc-800 pt-8 mt-4 grid grid-cols-1 md:grid-cols-12 gap-8 w-full">
            <div className="md:col-span-4 font-mono text-xs font-bold tracking-widest text-zinc-500 leading-relaxed uppercase">
              Beyond pure<br />mathematical calculation.<br />Practical execution.
            </div>
            
            <div className="md:col-span-8 flex flex-col gap-6 text-zinc-400 text-base sm:text-lg leading-relaxed font-normal">
              <p>
                A theoretically correct structure can still be difficult to fabricate, expensive to transport, awkward to erect or impossible to maintain.
              </p>
              <p className="text-zinc-300">
                Our work considers the complete engineering problem: loads, geometry, connections, fabrication, transport, erection, inspection, maintenance and the people who ultimately have to work with the structure.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
