'use client';

import React, { useState, useRef, useEffect } from 'react';
import { ZoomIn, ZoomOut, Maximize2, Layers, Ruler, FileText, CheckCircle } from 'lucide-react';

interface DrawingSheet {
  id: string;
  code: string;
  title: string;
  rev: string;
  status: string;
  scale: string;
  project: string;
}

export default function DrawingViewer() {
  const drawingIndex: DrawingSheet[] = [
    { id: 'ga-001', code: 'GA-001', title: 'General Arrangement Portal', rev: 'C', status: 'ISSUED FOR CONSTRUCTION', scale: '1:50', project: 'SC-2417' },
    { id: 'ga-002', code: 'GA-002', title: 'Elevations & Framing Grid', rev: 'B', status: 'ISSUED FOR REVIEW', scale: '1:100', project: 'SC-2417' },
    { id: 'st-101', code: 'ST-101', title: 'Primary Portal Frame Detail', rev: 'A', status: 'ISSUED FOR CONSTRUCTION', scale: '1:20', project: 'SC-2417' },
    { id: 'st-201', code: 'ST-201', title: 'Moment Connection Joint Details', rev: 'C', status: 'ISSUED FOR CONSTRUCTION', scale: '1:10', project: 'SC-2417' },
    { id: 'st-301', code: 'ST-301', title: 'Foundation & Holding Down Bolts', rev: 'E', status: 'ISSUED FOR CONSTRUCTION', scale: '1:25', project: 'SC-2417' },
    { id: 'fab-001', code: 'FAB-001', title: 'Fabrication Endplate Detailing', rev: 'D', status: 'ISSUED FOR FABRICATION', scale: '1:5', project: 'SC-2417' },
  ];

  const [activeSheet, setActiveSheet] = useState<DrawingSheet>(drawingIndex[3]); // Default ST-201
  const [zoom, setZoom] = useState<number>(1.0);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });

  // Layers states
  const [showGrids, setShowGrids] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);
  const [showAnnotations, setShowAnnotations] = useState(true);

  // Measurement Tool states
  const [isMeasureActive, setIsMeasureActive] = useState(false);
  const [measurePoints, setMeasurePoints] = useState<{ x: number; y: number }[]>([]);
  const [measureResult, setMeasureResult] = useState<string | null>(null);

  // Pan interaction
  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    if (isMeasureActive) return;
    setIsPanning(true);
    dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isPanning) return;
    setPan({
      x: e.clientX - dragStart.current.x,
      y: e.clientY - dragStart.current.y
    });
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  const resetView = () => {
    setZoom(1.0);
    setPan({ x: 0, y: 0 });
    setMeasurePoints([]);
    setMeasureResult(null);
  };

  // Measurement click handler
  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isMeasureActive) return;
    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    
    // Relative coordinates in target coordinates
    const clickX = ((e.clientX - rect.left - pan.x) / zoom);
    const clickY = ((e.clientY - rect.top - pan.y) / zoom);

    if (measurePoints.length === 0) {
      setMeasurePoints([{ x: clickX, y: clickY }]);
    } else if (measurePoints.length === 1) {
      const p1 = measurePoints[0];
      const p2 = { x: clickX, y: clickY };
      
      // Calculate delta distance in imaginary millimeters (scale of 10x)
      const dx = p2.x - p1.x;
      const dy = p2.y - p1.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      // Map scale based on active drawing
      const scaleMultiplier = activeSheet.code === 'ST-201' ? 15 : activeSheet.code === 'GA-001' ? 45 : 30;
      const mmDistance = Math.round(dist * scaleMultiplier);
      
      setMeasurePoints([...measurePoints, p2]);
      setMeasureResult(`${mmDistance} mm`);
    } else {
      // Reset for third click
      setMeasurePoints([{ x: clickX, y: clickY }]);
      setMeasureResult(null);
    }
  };

  return (
    <section className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col gap-3 mb-16 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
            <span className="font-mono text-xs font-bold tracking-widest text-orange-500">TECHNICAL ASSURANCE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
            DRAWING VIEWER
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            Independent design documentation records. Select drawing layers, audit endplate detailing alignments, zoom/pan layout arrangements, and check critical dimensions in real time.
          </p>
        </div>

        {/* CAD Viewer Panel layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch border border-zinc-800 bg-zinc-900">
          
          {/* Left: Drawing Index column (col-span-3) */}
          <div className="lg:col-span-3 border-r border-zinc-800 bg-zinc-950 p-6 flex flex-col gap-4">
            <span className="font-mono text-[10px] text-zinc-500 font-bold tracking-widest border-b border-zinc-900 pb-2 uppercase">
              DOCUMENT INDEX
            </span>
            <div className="flex flex-col gap-1 overflow-y-auto max-h-[380px]">
              {drawingIndex.map((sheet) => (
                <button
                  key={sheet.id}
                  onClick={() => {
                    setActiveSheet(sheet);
                    resetView();
                  }}
                  className={`w-full text-left p-3 flex flex-col gap-1 border transition-colors ${
                    activeSheet.id === sheet.id
                      ? 'bg-zinc-900 border-orange-500 text-zinc-100'
                      : 'bg-zinc-950 border-zinc-900 text-zinc-400 hover:bg-zinc-900/40 hover:text-zinc-200'
                  }`}
                >
                  <div className="flex justify-between items-baseline">
                    <span className="font-mono text-[11px] font-bold text-orange-500">{sheet.code}</span>
                    <span className="font-mono text-[9px] text-zinc-500">REV {sheet.rev}</span>
                  </div>
                  <span className="text-xs font-semibold leading-tight truncate">{sheet.title}</span>
                </button>
              ))}
            </div>
            
            {/* Legend guide */}
            <div className="mt-auto pt-4 border-t border-zinc-900 font-mono text-[9px] text-zinc-500 leading-relaxed flex flex-col gap-1.5">
              <span className="font-bold text-zinc-400">INDEX PROTOCOLS:</span>
              <span>All dwgs verified by principal steel engineers. Standard EN 1090 structural class EXC2 / EXC3.</span>
            </div>
          </div>

          {/* Centre: CAD Viewport Canvas (col-span-6) */}
          <div className="lg:col-span-6 bg-zinc-950 flex flex-col justify-between relative overflow-hidden group select-none h-[420px]">
            
            {/* Viewport controls top bar */}
            <div className="bg-zinc-900 border-b border-zinc-800 px-4 py-2 flex items-center justify-between font-mono text-[9px] text-zinc-400">
              <div className="flex items-center gap-3">
                <span className="font-bold text-orange-500">VIEWPORT</span>
                <span>/</span>
                <span>SCALE: {activeSheet.scale}</span>
                <span>/</span>
                <span className="uppercase">{isMeasureActive ? 'Ruler measurement active' : 'Pan & Zoom active'}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setZoom(prev => Math.min(3.0, prev + 0.2))}
                  className="p-1 hover:bg-zinc-800 hover:text-zinc-100"
                  title="Zoom In"
                >
                  <ZoomIn className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => setZoom(prev => Math.max(0.5, prev - 0.2))}
                  className="p-1 hover:bg-zinc-800 hover:text-zinc-100"
                  title="Zoom Out"
                >
                  <ZoomOut className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => {
                    setIsMeasureActive(!isMeasureActive);
                    setMeasurePoints([]);
                    setMeasureResult(null);
                  }}
                  className={`p-1 hover:bg-zinc-800 ${isMeasureActive ? 'bg-orange-500/20 text-orange-500' : 'text-zinc-400'}`}
                  title="Measure Distance"
                >
                  <Ruler className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={resetView}
                  className="p-1 hover:bg-zinc-800 hover:text-zinc-100"
                  title="Reset Scale"
                >
                  <Maximize2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Interactive SVG Display Area */}
            <div className="relative w-full h-[320px] flex-grow overflow-hidden bg-zinc-950 cursor-crosshair">
              
              <svg
                width="100%"
                height="100%"
                viewBox="0 0 400 300"
                className="absolute inset-0"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                onClick={handleSvgClick}
              >
                {/* Apply pan & zoom transform matrix group */}
                <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
                  
                  {/* BACKGROUND REFERENCE GRIDS LAYER */}
                  {showGrids && (
                    <g stroke="#18181b" strokeWidth="0.75" strokeDasharray="3">
                      <line x1="50" y1="20" x2="50" y2="280" />
                      <line x1="150" y1="20" x2="150" y2="280" />
                      <line x1="250" y1="20" x2="250" y2="280" />
                      <line x1="350" y1="20" x2="350" y2="280" />
                      
                      <line x1="20" y1="60" x2="380" y2="60" />
                      <line x1="20" y1="150" x2="380" y2="150" />
                      <line x1="20" y1="240" x2="380" y2="240" />

                      {/* Grid IDs */}
                      <g fill="#42424b" fontSize="8" fontFamily="monospace">
                        <text x="50" y="15" textAnchor="middle">GRID A</text>
                        <text x="250" y="15" textAnchor="middle">GRID B</text>
                      </g>
                    </g>
                  )}

                  {/* ACTIVE DWG CONTENT DYNAMIC DRAWINGS */}
                  {activeSheet.code === 'ST-201' && (
                    <g stroke="#71717a" strokeWidth="1.5" fill="none">
                      {/* Detailed Connection plate zoom representation */}
                      <rect x="150" y="50" width="100" height="200" stroke="#a1a1aa" strokeWidth="2" />
                      <rect x="155" y="60" width="90" height="180" stroke="#f97316" strokeWidth="1.25" opacity="0.6" />
                      
                      {/* Beam Profile lines */}
                      <line x1="250" y1="110" x2="370" y2="110" strokeWidth="3" />
                      <line x1="250" y1="190" x2="370" y2="190" strokeWidth="3" />
                      <line x1="250" y1="150" x2="370" y2="150" strokeWidth="1" strokeDasharray="2" />

                      {/* Column bounding */}
                      <line x1="150" y1="30" x2="150" y2="270" strokeWidth="4" />

                      {/* 6 Bolts */}
                      <circle cx="175" cy="80" r="4" fill="#a1a1aa" />
                      <circle cx="225" cy="80" r="4" fill="#a1a1aa" />
                      <circle cx="175" cy="150" r="4" fill="#a1a1aa" />
                      <circle cx="225" cy="150" r="4" fill="#a1a1aa" />
                      <circle cx="175" cy="220" r="4" fill="#a1a1aa" />
                      <circle cx="225" cy="220" r="4" fill="#a1a1aa" />

                      {/* Dimensions lines if toggled */}
                      {showDimensions && (
                        <g stroke="#4f4f56" strokeWidth="0.75" fill="#a1a1aa" fontSize="7" fontFamily="monospace">
                          {/* Width dimension 150-250 */}
                          <line x1="150" y1="265" x2="250" y2="265" />
                          <line x1="150" y1="260" x2="150" y2="270" />
                          <line x1="250" y1="260" x2="250" y2="270" />
                          <text x="200" y="260" textAnchor="middle">100 mm plate width</text>

                          {/* Height dimensions */}
                          <line x1="130" y1="50" x2="130" y2="250" />
                          <line x1="125" y1="50" x2="135" y2="50" />
                          <line x1="125" y1="250" x2="135" y2="250" />
                          <text x="120" y="150" textAnchor="middle" transform="rotate(-90, 120, 150)">200 mm height</text>
                        </g>
                      )}
                    </g>
                  )}

                  {activeSheet.code === 'GA-001' && (
                    <g stroke="#71717a" strokeWidth="1.5" fill="none">
                      {/* Entire portal bay wireframe view */}
                      {/* Columns */}
                      <line x1="100" y1="100" x2="100" y2="250" strokeWidth="3" />
                      <line x1="300" y1="100" x2="300" y2="250" strokeWidth="3" />

                      {/* Triangular rafters pitched */}
                      <line x1="100" y1="100" x2="200" y2="50" strokeWidth="2.5" />
                      <line x1="300" y1="100" x2="200" y2="50" strokeWidth="2.5" />

                      {/* Bracing knee details */}
                      <line x1="100" y1="120" x2="130" y2="100" />
                      <line x1="300" y1="120" x2="270" y2="100" />

                      {showDimensions && (
                        <g stroke="#4f4f56" strokeWidth="0.75" fill="#a1a1aa" fontSize="7" fontFamily="monospace">
                          {/* Span width */}
                          <line x1="100" y1="270" x2="300" y2="270" />
                          <line x1="100" y1="265" x2="100" y2="275" />
                          <line x1="300" y1="265" x2="300" y2="275" />
                          <text x="200" y="262" textAnchor="middle">12000 mm Portal Span</text>
                        </g>
                      )}
                    </g>
                  )}

                  {activeSheet.code !== 'ST-201' && activeSheet.code !== 'GA-001' && (
                    <g stroke="#a1a1aa" strokeWidth="1.5" fill="none">
                      {/* Simplified placeholders for the rest of sheets */}
                      <rect x="120" y="80" width="160" height="140" strokeWidth="1" strokeDasharray="2" />
                      <line x1="120" y1="80" x2="280" y2="220" strokeWidth="0.5" strokeDasharray="1" />
                      <line x1="280" y1="80" x2="120" y2="220" strokeWidth="0.5" strokeDasharray="1" />
                      <circle cx="200" cy="150" r="30" />
                      {showAnnotations && (
                        <text x="200" y="153" fill="#a1a1aa" fontSize="8" fontFamily="monospace" stroke="none" textAnchor="middle">
                          DETAIL SCHEMATIC {activeSheet.code}
                        </text>
                      )}
                    </g>
                  )}

                  {/* ANNOTATIONS LAYER */}
                  {showAnnotations && (
                    <g fill="#f97316" stroke="none" fontSize="8" fontFamily="monospace">
                      {activeSheet.code === 'ST-201' && (
                        <>
                          <circle cx="200" cy="150" r="2.5" fill="#ef4444" />
                          <text x="210" y="153">MOMENT PLATE SPLICE</text>
                          
                          <circle cx="175" cy="80" r="2.5" fill="#ef4444" />
                          <text x="182" y="76">M24 HR FASTENER</text>
                        </>
                      )}
                    </g>
                  )}

                  {/* DYNAMIC MEASUREMENT PATH LAYOUT OVERLAY */}
                  {isMeasureActive && measurePoints.length > 0 && (
                    <g stroke="#ef4444" strokeWidth="1.5" fill="#ef4444">
                      {measurePoints.map((pt, idx) => (
                        <circle key={idx} cx={pt.x} cy={pt.y} r="3" />
                      ))}
                      {measurePoints.length === 2 && (
                        <>
                          <line x1={measurePoints[0].x} y1={measurePoints[0].y} x2={measurePoints[1].x} y2={measurePoints[1].y} strokeDasharray="4" />
                          <text
                            x={(measurePoints[0].x + measurePoints[1].x) / 2 + 10}
                            y={(measurePoints[0].y + measurePoints[1].y) / 2}
                            fontFamily="monospace"
                            fontSize="9"
                            fontWeight="bold"
                            stroke="none"
                            fill="#ef4444"
                          >
                            MEASURED: {measureResult}
                          </text>
                        </>
                      )}
                    </g>
                  )}

                </g>
              </svg>

              {/* Floating Instructions overlay */}
              <div className="absolute bottom-4 left-4 bg-zinc-950/90 border border-zinc-800 p-3 font-mono text-[9px] text-zinc-400 flex flex-col gap-1">
                {isMeasureActive ? (
                  <span className="text-orange-500 font-bold">RULER TOOL: CLICK ANY TWO POINTS TO CALCULATE CAD SPACE DISPLACEMENT</span>
                ) : (
                  <span>DRAG MOUSE TO PAN · USE BUTTONS TOP RIGHT TO ZOOM</span>
                )}
              </div>

            </div>

          </div>

          {/* Right: Technical Details sheet data block (col-span-3) */}
          <div className="lg:col-span-3 bg-zinc-950 p-6 flex flex-col justify-between border-l border-zinc-800">
            
            <div className="flex flex-col gap-6">
              <span className="font-mono text-[10px] text-zinc-500 font-bold tracking-widest border-b border-zinc-900 pb-2 uppercase">
                SHEET ATTRIBUTES
              </span>

              <div className="flex flex-col gap-4 font-mono text-xs">
                
                <div className="flex flex-col gap-0.5">
                  <span className="text-zinc-500 text-[10px]">SHEET REFERENCE</span>
                  <span className="text-zinc-100 font-bold">{activeSheet.code}</span>
                </div>

                <div className="flex flex-col gap-0.5">
                  <span className="text-zinc-500 text-[10px]">REVISION STAMP</span>
                  <span className="text-zinc-100 font-bold">REV {activeSheet.rev}</span>
                </div>

                <div className="flex flex-col gap-0.5">
                  <span className="text-zinc-500 text-[10px]">VERIFICATION STATUS</span>
                  <span className="text-emerald-500 font-bold flex items-center gap-1.5">
                    <CheckCircle className="h-3.5 w-3.5" />
                    {activeSheet.status}
                  </span>
                </div>

                <div className="flex flex-col gap-0.5">
                  <span className="text-zinc-500 text-[10px]">SCALE PROPORTIONS</span>
                  <span className="text-zinc-300">{activeSheet.scale}</span>
                </div>

                <div className="flex flex-col gap-0.5">
                  <span className="text-zinc-500 text-[10px]">PROJECT CODE</span>
                  <span className="text-zinc-300">{activeSheet.project}</span>
                </div>

              </div>

              {/* Layer Toggles */}
              <div className="border-t border-zinc-900 pt-4 flex flex-col gap-3">
                <span className="font-mono text-[10px] text-zinc-500 font-bold tracking-widest uppercase">
                  LAYER FILTER CONTROL
                </span>
                <div className="flex flex-col gap-1.5 font-mono text-xs">
                  
                  <button
                    onClick={() => setShowGrids(!showGrids)}
                    className={`flex items-center justify-between p-2 border text-[10px] uppercase font-bold transition-colors ${
                      showGrids ? 'bg-zinc-900 border-zinc-800 text-zinc-200' : 'bg-transparent border-zinc-950 text-zinc-600'
                    }`}
                  >
                    <span>REFERENCE GRIDS</span>
                    <span>{showGrids ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    onClick={() => setShowDimensions(!showDimensions)}
                    className={`flex items-center justify-between p-2 border text-[10px] uppercase font-bold transition-colors ${
                      showDimensions ? 'bg-zinc-900 border-zinc-800 text-zinc-200' : 'bg-transparent border-zinc-950 text-zinc-600'
                    }`}
                  >
                    <span>DIMENSION CHANNELS</span>
                    <span>{showDimensions ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    onClick={() => setShowAnnotations(!showAnnotations)}
                    className={`flex items-center justify-between p-2 border text-[10px] uppercase font-bold transition-colors ${
                      showAnnotations ? 'bg-zinc-900 border-zinc-800 text-zinc-200' : 'bg-transparent border-zinc-950 text-zinc-600'
                    }`}
                  >
                    <span>CALLOUT TEXT</span>
                    <span>{showAnnotations ? 'ON' : 'OFF'}</span>
                  </button>

                </div>
              </div>

            </div>

            {/* Official standards symbol */}
            <div className="bg-zinc-900 border border-zinc-850 p-4 mt-6 flex flex-col gap-1 font-mono text-[9px] text-zinc-400">
              <span className="font-bold text-zinc-200">ISO 9001:2015 AUDITED</span>
              <span>All drawings certified under British Standards & Eurocodes structural integrity guidelines.</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
