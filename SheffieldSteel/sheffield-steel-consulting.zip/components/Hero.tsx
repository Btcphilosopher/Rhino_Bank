'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section id="hero" className="relative flex min-h-[90vh] items-center justify-center overflow-hidden bg-zinc-950">
      {/* Cinematic Dark Background Scrim over Technical Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/steel_connection_hero_1790779589407.jpg"
          alt="Massive bolted structural steel plate connection by Sheffield Steel Consulting"
          fill
          priority
          className="object-cover opacity-35"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/70 to-zinc-950/30" />
        <div className="absolute inset-0 bg-zinc-950/20" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-6 py-24 md:py-32">
        <div className="flex flex-col items-start gap-6 max-w-4xl">
          {/* Location / Origin Tag */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center gap-2 border-l-2 border-orange-500 pl-3 font-mono text-[10px] sm:text-xs font-bold tracking-widest text-zinc-400"
          >
            <span>SHEFFIELD</span>
            <span>·</span>
            <span>YORKSHIRE</span>
            <span>·</span>
            <span>UK / INTERNATIONAL</span>
          </motion.div>

          {/* Headline (Tightly spaced, confident display typography) */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-extrabold tracking-tight text-zinc-100 leading-none text-wrap-balance"
          >
            STEEL,<br />
            ENGINEERED<br />
            <span className="text-orange-500">PROPERLY.</span>
          </motion.h1>

          {/* Subheading (British editorial type style, max-w constraint to avoid orphans) */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.25 }}
            className="max-w-2xl text-base sm:text-lg md:text-xl font-normal leading-relaxed text-zinc-400 text-wrap-balance"
          >
            Independent steel engineering consultancy from Sheffield, supporting complex structures, fabrication and industrial projects from concept through to delivery.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mt-4 w-full sm:w-auto"
          >
            <button
              onClick={() => onNavigate('contact')}
              className="group flex items-center justify-center gap-2 bg-orange-500 px-6 py-4 font-mono text-xs font-bold tracking-widest text-zinc-950 transition-all hover:bg-orange-600"
            >
              DISCUSS A PROJECT
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              onClick={() => onNavigate('capabilities')}
              className="flex items-center justify-center gap-2 border border-zinc-800 bg-zinc-900/50 hover:bg-zinc-900 px-6 py-4 font-mono text-xs font-bold tracking-widest text-zinc-300 transition-colors hover:border-zinc-700"
            >
              VIEW CAPABILITIES
            </button>
          </motion.div>
        </div>
      </div>

      {/* Decorative technical line element */}
      <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-zinc-800 to-transparent" />

      {/* Scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 text-zinc-600 animate-bounce cursor-pointer" onClick={() => onNavigate('intro')}>
        <ChevronDown className="h-5 w-5" />
      </div>
    </section>
  );
}
