'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Briefcase, MapPin, CheckCircle2, Loader2, Send } from 'lucide-react';

interface Role {
  title: string;
  type: string;
  location: string;
  desc: string;
}

export default function Careers() {
  const [activeTab, setActiveTab] = useState<'positions' | 'apply'>('positions');
  const [selectedRole, setSelectedRole] = useState<string>('Structural Engineer');

  // Form states
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [coverNote, setCoverNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [applicationRef, setApplicationRef] = useState('');

  const roles: Role[] = [
    { title: 'Structural Engineer', type: 'FULL TIME', location: 'SHEFFIELD / HYBRID', desc: 'Sizing and checking primary frame members, portal frames, trusses, and structural steel alterations in conformance with Eurocode 3.' },
    { title: 'Steel Design Engineer', type: 'FULL TIME', location: 'SHEFFIELD', desc: 'Developing concept designs and constructability studies for massive industrial process and steelworks support systems.' },
    { title: 'Connection Engineer', type: 'FULL TIME', location: 'SHEFFIELD / HYBRID', desc: 'Signature joint connection design. Detailing bolted moments, complex shear nodes, baseplates, and weld-throat sizing.' },
    { title: 'Senior Engineer', type: 'PROJECT BASED', location: 'HYBRID', desc: 'Third-party Category 3 checking, technical reviews, condition reports, and leading structural forensic assessments.' },
    { title: 'Digital Engineering Developer', type: 'FULL TIME', location: 'SHEFFIELD / HYBRID', desc: 'Developing custom automated parametric BIM connections tools and custom HTML/Python calculation modules.' },
    { title: 'Engineering Technician', type: 'FULL TIME', location: 'SHEFFIELD', desc: 'Producing high-precision General Arrangement drawings, connection layout elevations, and assembly drafting packages.' },
    { title: 'Graduate Engineer', type: 'FULL TIME', location: 'SHEFFIELD', desc: 'Structural training track. Working on calculation validation checks and site inspections under direct senior mentoring.' }
  ];

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !phone) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const uniqueId = `SSC-APP-${Math.floor(10000 + Math.random() * 90000)}`;
      setApplicationRef(uniqueId);
      setIsSubmitting(false);
      setSubmitSuccess(true);
    }, 1500);
  };

  const handleResetForm = () => {
    setFullName('');
    setEmail('');
    setPhone('');
    setCoverNote('');
    setSubmitSuccess(false);
    setApplicationRef('');
  };

  return (
    <section id="careers" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">PRACTICE GROWTH</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100">
              COME AND ENGINEER THINGS.
            </h2>
          </div>
          
          {/* Segmented position/apply controller */}
          <div className="flex bg-zinc-900 p-1 border border-zinc-800 font-mono text-xs">
            <button
              onClick={() => setActiveTab('positions')}
              className={`px-4 py-1.5 font-bold tracking-widest transition-colors ${activeTab === 'positions' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              OPEN ROLES
            </button>
            <button
              onClick={() => setActiveTab('apply')}
              className={`px-4 py-1.5 font-bold tracking-widest transition-colors ${activeTab === 'apply' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              EXPRESS INTEREST
            </button>
          </div>
        </div>

        {/* Content Tabs */}
        {activeTab === 'positions' ? (
          /* Roles Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {roles.map((role, idx) => (
              <div
                key={idx}
                className="bg-zinc-900 border border-zinc-800 p-8 flex flex-col justify-between gap-6 hover:border-zinc-700 transition-colors"
              >
                <div className="flex flex-col gap-4">
                  {/* Title & tags */}
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-500 font-bold uppercase">
                      <span className="text-orange-500">{role.type}</span>
                      <span aria-hidden="true" className="text-zinc-700">·</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5" />
                        {role.location}
                      </span>
                    </div>
                    <h3 className="text-lg font-extrabold text-zinc-100 tracking-tight">
                      {role.title}
                    </h3>
                  </div>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed font-normal">
                    {role.desc}
                  </p>
                </div>

                {/* Apply direct CTA */}
                <button
                  onClick={() => {
                    setSelectedRole(role.title);
                    setActiveTab('apply');
                  }}
                  className="w-full text-center bg-zinc-950 hover:bg-zinc-800 border border-zinc-850 py-2.5 font-mono text-[10px] font-bold tracking-widest text-zinc-300 hover:text-zinc-100 transition-colors"
                >
                  APPLY FOR POSITION
                </button>
              </div>
            ))}
          </div>
        ) : (
          /* Form apply block */
          <div className="max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 p-8 sm:p-12 relative overflow-hidden">
            
            {!submitSuccess ? (
              <form onSubmit={handleApplySubmit} className="flex flex-col gap-6">
                <div className="border-b border-zinc-800 pb-4 flex items-center gap-2">
                  <Briefcase className="h-4.5 w-4.5 text-orange-500" />
                  <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-100">
                    EXPRESS INTEREST SUBMISSION
                  </h3>
                </div>

                {/* Role selection dropdown */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">TARGET POSITION</label>
                  <select
                    value={selectedRole}
                    onChange={(e) => setSelectedRole(e.target.value)}
                    className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                  >
                    {roles.map((r, i) => (
                      <option key={i} value={r.title}>{r.title}</option>
                    ))}
                    <option value="General/Other">Other Spec / Speculative</option>
                  </select>
                </div>

                {/* Form fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">FULL NAME *</label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Thomas Brearley"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">EMAIL ADDRESS *</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. thomas@domain.com"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">TELEPHONE NUMBER *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. +44 114 272 0000"
                    className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">EXPLAIN YOUR EXPERIENCE (COVER NOTE)</label>
                  <textarea
                    rows={4}
                    value={coverNote}
                    onChange={(e) => setCoverNote(e.target.value)}
                    placeholder="Provide a brief summary of S355 steel calculations, connections modeling or detailing experience."
                    className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500 resize-none"
                  />
                </div>

                {/* Submitting button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-600 p-3.5 font-mono text-xs font-bold tracking-widest text-zinc-950 transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      SUBMITTING APPLICATION...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      SUBMIT APPLICATION
                    </>
                  )}
                </button>

              </form>
            ) : (
              /* Success Page */
              <div className="flex flex-col items-center justify-center text-center p-8 gap-4">
                <CheckCircle2 className="h-12 w-12 text-emerald-500 animate-bounce" />
                <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-100 uppercase">
                  APPLICATION FILED SUCCESSFULLY
                </h3>
                <p className="text-zinc-400 text-sm max-w-md leading-relaxed">
                  Thank you for your interest in Sheffield Steel Consulting. Your credentials have been compiled and sent to our principal hiring engineering partner.
                </p>

                <div className="bg-zinc-950 border border-zinc-850 px-6 py-3 font-mono text-xs mt-2 flex flex-col gap-1.5 w-full">
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>APPLICANT NAME:</span>
                    <span className="text-zinc-200 font-bold">{fullName}</span>
                  </div>
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>TARGET ROLE:</span>
                    <span className="text-zinc-200 font-bold">{selectedRole}</span>
                  </div>
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>RECEIPT REFERENCE:</span>
                    <span className="text-orange-500 font-bold">{applicationRef}</span>
                  </div>
                </div>

                <button
                  onClick={handleResetForm}
                  className="mt-6 font-mono text-xs font-bold tracking-widest text-orange-500 hover:text-orange-600 border border-zinc-850 px-4 py-2"
                >
                  SUBMIT ANOTHER POSITION
                </button>
              </div>
            )}

          </div>
        )}

      </div>
    </section>
  );
}
