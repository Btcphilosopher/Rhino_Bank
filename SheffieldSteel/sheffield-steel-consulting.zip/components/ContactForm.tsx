'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Upload, CheckCircle2, Loader2, Send, ShieldCheck } from 'lucide-react';

export default function ContactForm() {
  // Form states
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [projectTitle, setProjectTitle] = useState('');
  const [projectType, setProjectType] = useState('Structural Steel Frame');
  const [estimatedScale, setEstimatedScale] = useState('Under 50 tonnes');
  const [message, setMessage] = useState('');
  
  // Fake file upload state
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [enquiryRef, setEnquiryRef] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setUploadedFile(files[0].name);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || !message) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const refNum = `SSC-RFQ-${Math.floor(10000 + Math.random() * 90000)}`;
      setEnquiryRef(refNum);
      setIsSubmitting(false);
      setSubmitSuccess(true);
    }, 1800);
  };

  const handleResetForm = () => {
    setName('');
    setCompany('');
    setEmail('');
    setPhone('');
    setProjectTitle('');
    setProjectType('Structural Steel Frame');
    setEstimatedScale('Under 50 tonnes');
    setMessage('');
    setUploadedFile(null);
    setSubmitSuccess(false);
    setEnquiryRef('');
  };

  return (
    <section id="contact" className="relative bg-zinc-950 border-t border-zinc-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left panel info details (col-span-5) */}
          <div className="lg:col-span-5 flex flex-col gap-8">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 rounded-none" />
              <span className="font-mono text-xs font-bold tracking-widest text-orange-500">PROJECT INTAKE</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100 leading-tight">
              HAVE A STEEL<br />
              PROBLEM?
            </h2>

            <p className="text-base sm:text-lg text-zinc-400 font-normal leading-relaxed text-wrap-balance">
              Send us the drawings, the photographs, the model or simply description of the engineering problem. Our principal engineering partner reviews all submissions within 24 hours.
            </p>

            <div className="border-t border-zinc-900 pt-8 mt-4 flex flex-col gap-6 font-mono text-xs">
              
              <div className="flex items-start gap-4">
                <MapPin className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
                <div className="flex flex-col gap-1 text-zinc-400">
                  <span className="font-bold text-zinc-300">VULCAN WORKS</span>
                  <span>Kelham Island, Sheffield S3 8MZ</span>
                  <span>South Yorkshire, United Kingdom</span>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Mail className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
                <div className="flex flex-col gap-1 text-zinc-400">
                  <span className="font-bold text-zinc-300">EMAIL ENQUIRIES</span>
                  <span>enquiries@sheffieldsteelconsulting.com</span>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
                <div className="flex flex-col gap-1 text-zinc-400">
                  <span className="font-bold text-zinc-300">TELEPHONE ENQUIRIES</span>
                  <span>+44 114 272 0000</span>
                </div>
              </div>

            </div>
          </div>

          {/* Right panel application form (col-span-7) */}
          <div className="lg:col-span-7 bg-zinc-900 border border-zinc-800 p-8 sm:p-12">
            
            {!submitSuccess ? (
              <form onSubmit={handleFormSubmit} className="flex flex-col gap-6">
                
                {/* Contact name & company */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">YOUR NAME *</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Thomas Brearley"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">COMPANY NAME</label>
                    <input
                      type="text"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      placeholder="e.g. South Yorkshire Fabrications"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                {/* Email & telephone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">EMAIL ADDRESS *</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. thomas@domain.com"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">TELEPHONE *</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. +44 114 272 0000"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                {/* Project title and types dropdown */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">PROJECT REFERENCE/TITLE</label>
                    <input
                      type="text"
                      value={projectTitle}
                      onChange={(e) => setProjectTitle(e.target.value)}
                      placeholder="e.g. Factory mezzanine extension"
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">PROJECT TYPE</label>
                    <select
                      value={projectType}
                      onChange={(e) => setProjectType(e.target.value)}
                      className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                    >
                      <option value="Structural Steel Frame">Structural Steel Frame</option>
                      <option value="Industrial Process Platforms">Industrial Process Platforms</option>
                      <option value="Bespoke Connections checking">Bespoke Connections checking</option>
                      <option value="Forensic structural survey">Forensic structural survey</option>
                      <option value="Erection sequencing safety">Erection sequencing safety</option>
                      <option value="General Engineering Advice">General Engineering Advice</option>
                    </select>
                  </div>
                </div>

                {/* Scale selection */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">ESTIMATED SCALE</label>
                  <select
                    value={estimatedScale}
                    onChange={(e) => setEstimatedScale(e.target.value)}
                    className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500"
                  >
                    <option value="Under 50 tonnes">Under 50 tonnes (Small Platform / Alteration)</option>
                    <option value="50 - 250 tonnes">50 - 250 tonnes (Industrial / Depot Framing)</option>
                    <option value="Over 250 tonnes">Over 250 tonnes (Large Portal Hall / Major Plant)</option>
                    <option value="Consultancy only">Advisory Only / Non-materials calculations</option>
                  </select>
                </div>

                {/* Message text area */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">EXPLAIN THE ENGINEERING CHALLENGE *</label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Provide description of structural loads, geometry issues, site constraints, or material grade challenges."
                    className="bg-zinc-950 font-mono text-xs text-zinc-200 p-3 border border-zinc-850 outline-none focus:border-orange-500 resize-none"
                  />
                </div>

                {/* CAD/Doc uploader */}
                <div className="flex flex-col gap-2">
                  <label className="font-mono text-[10px] text-zinc-500 font-bold tracking-wider">UPLOAD ATTACHED DOCUMENTS</label>
                  <div className="border border-dashed border-zinc-800 bg-zinc-950/40 p-6 flex flex-col items-center justify-center text-center cursor-pointer hover:border-zinc-700 transition-colors relative">
                    <input
                      type="file"
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      accept=".pdf,.dwg,.dxf,.ifc,.step,.xlsx,.zip"
                    />
                    <Upload className="h-8 w-8 text-zinc-600 mb-2 stroke-1" />
                    <span className="font-mono text-[10px] text-zinc-300 font-bold uppercase">
                      {uploadedFile ? `FILE: ${uploadedFile}` : 'DRAG & DROP OR CLICK TO ATTACH'}
                    </span>
                    <span className="font-mono text-[8px] text-zinc-500 mt-1 uppercase">
                      SUPPORTED FORMATS: PDF, DWG, DXF, IFC, STEP, XLSX, ZIP
                    </span>
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-600 p-4 font-mono text-xs font-bold tracking-widest text-zinc-950 transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      TRANSMITTING ENQUIRY TO SHEFFIELD...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      SEND PROJECT ENQUIRY
                    </>
                  )}
                </button>

              </form>
            ) : (
              /* Success Page */
              <div className="flex flex-col items-center justify-center text-center p-8 gap-4">
                <CheckCircle2 className="h-12 w-12 text-emerald-500 animate-bounce" />
                <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-100 uppercase">
                  TRANSMISSION RECEIVED
                </h3>
                <p className="text-zinc-400 text-sm max-w-md leading-relaxed">
                  Your project details have been securely filed and routed to our South Yorkshire engineering office.
                </p>

                <div className="bg-zinc-950 border border-zinc-850 px-6 py-4 font-mono text-xs mt-2 flex flex-col gap-1.5 w-full">
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>CONTACT SENDER:</span>
                    <span className="text-zinc-200 font-bold">{name}</span>
                  </div>
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>PROJECT TYPE:</span>
                    <span className="text-zinc-200">{projectType}</span>
                  </div>
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>SCALE CAPACITY:</span>
                    <span className="text-zinc-200">{estimatedScale}</span>
                  </div>
                  <div className="flex justify-between items-baseline text-zinc-500">
                    <span>ENQUIRY REF ID:</span>
                    <span className="text-orange-500 font-bold">{enquiryRef}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 bg-zinc-950 p-4 text-[9px] leading-relaxed text-zinc-500 font-mono text-left">
                  <ShieldCheck className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
                  <span>Your submission is logged inside our client portal system. A Chartered Structural Engineer will initiate contact via telephone or email to schedule a technical discovery call.</span>
                </div>

                <button
                  onClick={handleResetForm}
                  className="mt-6 font-mono text-xs font-bold tracking-widest text-orange-500 hover:text-orange-600 border border-zinc-850 px-4 py-2"
                >
                  TRANSMIT ANOTHER ENQUIRY
                </button>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
