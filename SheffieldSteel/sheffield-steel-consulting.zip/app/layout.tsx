import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Sheffield Steel Consulting | Independent Steel Engineering Consultancy',
  description: 'Independent steel engineering consultancy based in Sheffield, specialising in structural steel, connection engineering, industrial structures, technical review and fabrication support.',
  openGraph: {
    title: 'Sheffield Steel Consulting | Independent Steel Engineering Consultancy',
    description: 'Independent steel engineering consultancy based in Sheffield, specialising in structural steel, connection engineering, industrial structures, technical review and fabrication support.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Sheffield Steel Consulting | Independent Steel Engineering Consultancy',
    description: 'Independent steel engineering consultancy based in Sheffield, specialising in structural steel, connection engineering, industrial structures, technical review and fabrication support.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
