'use client';

import React, { useState, useEffect } from 'react';
import TopBar from '@/components/TopBar';
import Hero from '@/components/Hero';
import Intro from '@/components/Intro';
import CapabilitiesGrid from '@/components/CapabilitiesGrid';
import TheProblem from '@/components/TheProblem';
import Process from '@/components/Process';
import DigitalEngineering from '@/components/DigitalEngineering';
import ConnectionLab from '@/components/ConnectionLab';
import DrawingViewer from '@/components/DrawingViewer';
import Sectors from '@/components/Sectors';
import CaseStudies from '@/components/CaseStudies';
import Sheffield from '@/components/Sheffield';
import SteelIntelligence from '@/components/SteelIntelligence';
import Insights from '@/components/Insights';
import About from '@/components/About';
import Careers from '@/components/Careers';
import ContactForm from '@/components/ContactForm';
import Footer from '@/components/Footer';

export default function Home() {
  const [activeSection, setActiveSection] = useState('hero');

  // Smooth scroll handler for anchor links
  const handleNavigate = (sectionId: string) => {
    const targetElement = document.getElementById(sectionId);
    if (targetElement) {
      // Offset by the header height (16px * 4 = 64px)
      const offsetPosition = targetElement.offsetTop - 64;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
      setActiveSection(sectionId);
    }
  };

  // Viewport intersection sensor to update header active highlights
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['capabilities', 'projects', 'engineering', 'insights', 'about', 'contact', 'hero'];
      const scrollPos = window.scrollY + 120; // offset trigger

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop - 64;
          const bottom = top + el.offsetHeight;
          if (scrollPos >= top && scrollPos < bottom) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 antialiased selection:bg-orange-500 selection:text-zinc-950">
      
      {/* Top bar contract */}
      <TopBar onNavigate={handleNavigate} activeSection={activeSection} />

      {/* Main Sections flow */}
      <main>
        {/* 1. Hero */}
        <Hero onNavigate={handleNavigate} />

        {/* 2. Practice introduction */}
        <Intro />

        {/* 3. Capabilities */}
        <CapabilitiesGrid />

        {/* 4. "The Problem" core statement */}
        <TheProblem />

        {/* 5. Process Lifecycle */}
        <Process />

        {/* 6. Digital engineering (3D Rotating Wireframe) */}
        <DigitalEngineering />

        {/* 7. Connection Lab (Joints stress simulation) */}
        <ConnectionLab />

        {/* 8. Technical drawing viewer */}
        <DrawingViewer />

        {/* 9. Sectors Expertise */}
        <Sectors />

        {/* 10. Selected Projects & Case Studies */}
        <CaseStudies />

        {/* 11. Sheffield Legacy connection */}
        <Sheffield />

        {/* 12. Steelwork Intelligence AI assistant */}
        <SteelIntelligence />

        {/* 13. Insights Journal technical papers */}
        <Insights />

        {/* 14. About the practice & Personnel */}
        <About />

        {/* 15. Careers Roles & application */}
        <Careers />

        {/* 16. Contact Form & RFPs */}
        <ContactForm />
      </main>

      {/* 17. Clean Footer */}
      <Footer onNavigate={handleNavigate} />

    </div>
  );
}
