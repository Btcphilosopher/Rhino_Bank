import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: "Missing query prompt" }, { status: 400 });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: `You are a Principal Steel Consulting Engineer at Sheffield Steel Consulting.
Provide highly authoritative, precise, technically rigorous engineering advice.
Reference British Standards (BS 5950) or Eurocode 3 (BS EN 1993) as appropriate for steel design.
Ensure your tone is concise, professional, grounded, and practical. Do not use corporate fluff or standard AI pleasantries.
Talk about welds, bolting tolerances, fabrication sequences, steel grades (S275, S355, S460), section factors, and structural stability with high confidence.
Ensure any equations or structural mechanics concepts are written clearly.`,
        temperature: 0.2,
      },
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json(
      { error: "Error processing structural intelligence query. Please verify process.env.GEMINI_API_KEY." },
      { status: 500 }
    );
  }
}
