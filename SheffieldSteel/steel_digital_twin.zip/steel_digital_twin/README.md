# Steel Digital Twin

A production-grade **steel manufacturing digital twin and simulation platform**
in Python: an engineering-grade process simulator for an integrated
steelworks (or scrap-based mini-mill), covering metallurgy, thermodynamics,
process flow, logistics, predictive maintenance, economics, industrial
power/control systems, emissions, and an optimisation / ML layer -- all
wired together on an event-driven simulation kernel and streamed live to a
SCADA-style command-centre dashboard.

This is a **simulator**, not a game: every module is driven by real
engineering equations (mass/energy balances, heat transfer, phase-
transformation kinetics, reliability theory, corporate-finance formulas)
rather than arbitrary scripted numbers. Where a full first-principles model
would require plant-specific calibration data this project does not have
(e.g. certified CCT diagrams for a specific alloy heat), it uses
well-documented engineering approximations, called out in code comments and
below, so behaviour stays physically plausible and results are reproducible.

## Quick start

```bash
python3.11 -m venv .venv   # 3.12+ recommended; 3.11+ supported
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .

# Headless multi-year run
python scripts/run_simulation.py --years 1 --route integrated

# Live SCADA dashboard (FastAPI + WebSocket), open http://localhost:8000
python scripts/run_simulation.py --dashboard --port 8000

# Optimisation / Monte Carlo / finance walkthrough
python scripts/generate_report.py

# Test suite
pytest -q
```

## Architecture

Independent simulation engines communicate through a shared **event-driven
industrial data bus** (`core.event_bus.EventBus`) and a **shared process
state** (`core.state.PlantState` / `StateStore`), advanced by a single
**simulation clock** (`core.clock.SimulationClock`) on minute-by-minute
ticks. `plant.digital_twin.SteelworksDigitalTwin` is the orchestrator that
owns one instance of every module and calls `.tick()` on each in production
order once per simulated minute; the FastAPI dashboard drives the same
object asynchronously and streams the full snapshot to every connected
client over `/ws`.

```
src/steel_twin/
  core/            simulation clock, event bus, shared state, entities
                    (Equipment/Sensor/Actuator), PID control + alarms/ESD
  metallurgy/       alloy & slag chemistry, mechanical-property prediction,
                    JMAK phase-transformation kinetics, steel grade catalogue
  thermodynamics/   conduction/convection/radiation, combustion, gas flow,
                    steam / waste-heat recovery (NumPy + SciPy ODE solvers)
  processes/        raw materials -> ore processing -> coke plant ->
                    blast furnace -> BOF / EAF -> continuous caster ->
                    rolling mill -> finishing -> shipping
  logistics/        rail freight, port/berth/crane ops, fleet scheduling,
                    warehousing, stochastic disruption engine
  maintenance/       Weibull reliability, EWMA anomaly detection, RUL
                    forecasting, maintenance-backlog prioritisation
  economics/        commodity/electricity/carbon/FX markets (mean-reverting
                    OU processes), cost ledger, NPV/ROI/IRR/expansion NPV
  power/            plant-wide power balance, load shedding, PID governor
  emissions/        CO2/SO2/NOx/PM ledger and carbon-intensity metrics
  optimization/      genetic algorithm, Monte Carlo engine, greedy
                    workforce/maintenance/logistics-route schedulers
  ml/               ridge-regression quality predictor, isolation-forest &
                    PCA-reconstruction anomaly detectors, Holt/OLS
                    forecasters -- all NumPy-native, sklearn/torch-optional
  plant/            SteelworksDigitalTwin: wires every module together
  dashboard/        FastAPI + WebSocket SCADA-style command-centre UI
```

## What's simulated, and with which equations

**Metallurgy** (`metallurgy/`)
- IIW carbon equivalent: `CE = C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15`
- Slag basicity `B2 = %CaO/%SiO2`, `B4` with MgO/Al2O3
- Stoichiometric BOF oxygen demand from `C + 1/2 O2 -> CO`
- Blast-furnace indirect-reduction gas demand from `Fe2O3 + 3CO -> 2Fe + 3CO2`
- Mechanical properties: Maynier-style additive hardness model, empirical
  `UTS ≈ 3.45 x HB`, Hall-Petch yield strength
  `sigma_y = sigma_0 + k/sqrt(d)`, fatigue endurance ratio `Se/Su ≈ 0.45-0.5`
- JMAK phase-transformation kinetics `X(t) = 1 - exp(-k t^n)` with Arrhenius
  temperature dependence, and a CCT-style cooling-rate -> microstructure map
- Six grade families with representative target chemistries: structural
  (A36), stainless (304), tool steel (D2), automotive (SAE 1045),
  military/armor (MIL-A-46100), aerospace (AMS 4340/6415)

**Thermodynamics** (`thermodynamics/`)
- Fourier conduction, Newton convection, Stefan-Boltzmann radiation
- Lumped-capacitance transient cooling solved with `scipy.integrate.solve_ivp`
  (feeds the caster's cooling-rate -> microstructure pipeline)
- Combustion: fuel LHV, stoichiometric air demand, adiabatic flame
  temperature, thermal efficiency
- Darcy-Weisbach pressure drop, Colebrook-White friction factor, ideal-gas
  density, orifice flow
- Simplified steam/waste-heat-recovery energy balance

**Process flow** (`processes/`) -- each stage consumes upstream buffers,
requires energy, generates waste/emissions, and can starve/block
downstream stages, exactly as requested:
raw materials -> ore processing (sinter) -> coke plant -> blast furnace
(hot metal) -> BOF *or* EAF (liquid steel) -> continuous caster (slabs,
solidification thermal model) -> rolling mill (Sims'-type roll-force model,
roll fatigue) -> finishing (quality gate, contamination risk) -> shipping.

**Logistics** (`logistics/`) -- rail wagon cycling with transit delay, a
multi-berth port with crane unloading and ship queueing, an internal fleet
scheduler (cranes/trucks/locomotives with fuel burn), reorder-point
warehousing, and a stochastic disruption engine (strikes, weather,
geopolitical instability, fuel shortages, power outages) that derates
logistics throughput and can trip the power system.

**Predictive maintenance** (`maintenance/`, `ml/`) -- two-parameter Weibull
reliability model (`R(t)=exp(-(t/eta)^beta)`) per major asset, an EWMA
control-chart anomaly detector, a from-scratch Isolation Forest and a
PCA-reconstruction-error detector for multivariate sensor anomalies, and a
RUL forecaster blending the Weibull model with health-index trend
extrapolation, feeding a priority-ranked maintenance backlog.

**Economics** (`economics/`) -- commodity/electricity/carbon/FX prices as
mean-reverting Ornstein-Uhlenbeck processes (the standard model for
commodity spot prices), a full cost ledger, and NPV/ROI/payback/IRR
functions for expansion-scenario evaluation.

**Power & control** (`power/`, `core/control.py`) -- plant-wide power
balance across furnace/mill/aux loads vs. on-site generation and grid
import, with PID-governed frequency response and automatic load shedding
under a simulated outage; a general-purpose `PIDController` (with
anti-windup and simulated actuator dead-time) and `AlarmSystem`
(warn/alarm/critical with ESD action hooks) usable by any module.

**Optimisation** (`optimization/`) -- a from-scratch genetic algorithm
(tournament selection, BLX-alpha crossover, elitism) for alloy-addition /
charge-mix optimisation; a Monte Carlo engine for financial and
supply-chain risk (with a ready-made supply-chain stress test); greedy
heuristic schedulers for workforce shift-fill, maintenance-window packing,
and logistics-route selection.

**Emissions** (`emissions/`) -- per-process CO2/SO2/NOx/PM ledger and
plant-wide carbon-intensity (t CO2 / t steel), feeding the carbon-tax line
in the cost ledger.

## Dashboard

```bash
python scripts/run_simulation.py --dashboard --port 8000
```

Open `http://localhost:8000`. The FastAPI app runs the digital twin on a
background asyncio loop and pushes a full plant snapshot over `/ws` every
`tick_interval_s` (default 1s wall-clock per simulated minute); the static
frontend (`dashboard/static/`) is a dependency-free, offline-capable
SCADA-style UI (black background, orange furnace glow, cyan engineering
overlays) built with plain HTML/CSS/canvas -- no CDN required. REST
endpoints (`/api/state`, `/api/alarms`, `/api/events`,
`/api/maintenance/backlog`, `/api/control/pause|resume`) support external
tooling/BI integration.

## Extending the ML layer

`ml/quality_prediction.py`, `ml/anomaly_models.py`, and `ml/forecasting.py`
are deliberately scikit-learn-shaped (`fit(X, y)` / `predict(X)`) NumPy
implementations (ridge regression, isolation forest, PCA reconstruction,
Holt/OLS forecasting) so the simulator runs out of the box with zero deep
learning dependencies. To swap in PyTorch/TensorFlow models for a
production deployment, implement the same `fit`/`predict` interface and
substitute the class used in `plant.digital_twin.SteelworksDigitalTwin`.
`requirements.txt` includes `torch` as a commented-out optional dependency
for exactly this purpose.

## Data architecture / persistence

- `core.state.StateStore` layers lightweight event-sourcing over the plant
  state: periodic full snapshots plus per-tick diffs, enabling replayable
  production runs; `export_snapshot()` / `load_snapshot()` round-trip to
  JSON for simulation snapshots.
- `core.event_bus.EventBus` retains a bounded rolling history (default
  50,000 events) with glob-pattern topic queries (`bus.history("power.*")`)
  and an `asyncio.Queue` bridge used by the dashboard's WebSocket.
- `docker-compose.yml` provisions PostgreSQL (historian) and Redis (pub/sub
  cache for scaling the event bus across worker processes / distributed
  simulation clusters) for a production deployment; the simulator runs
  standalone without them for local development and CI.

## Performance notes

- Metallurgy/thermodynamics use NumPy/SciPy vectorised routines; the
  transient cooling ODE is solved with `scipy.integrate.solve_ivp`.
- The simulation is a single-process, minute-resolution tick loop by
  design (matching real DCS/SCADA scan rates); for multi-year headless runs
  use `scripts/run_simulation.py --years N` (no dashboard/WebSocket
  overhead). For distributed/GPU-accelerated scale-out (many plants /
  Monte Carlo ensembles in parallel), shard `SteelworksDigitalTwin`
  instances across processes (`multiprocessing`) or machines, coordinating
  through the Redis-backed event bus.
- `numba` is listed as a core dependency for JIT-accelerating hot numeric
  loops (e.g. large Monte Carlo trial counts or GA fitness evaluation) --
  decorate the relevant pure-NumPy function with `@numba.njit` where
  profiling shows it's warranted.

## Testing

```bash
pytest -q
```

Covers metallurgy (carbon-equivalent, Hall-Petch, JMAK/CCT), thermodynamics
(heat transfer, combustion, gas flow), end-to-end plant ticking on both the
integrated and EAF routes, optimisation (GA convergence, Monte Carlo
statistics, schedulers), and the maintenance/ML layer (Weibull, EWMA,
isolation forest, PCA anomaly detection, forecasters, quality predictor).

## Disclaimer

Equipment sizes, rates, yields, and chemistries are representative
industrial figures used for engineering-plausible simulation, not a
certified specification of any real facility. Validate against your own
plant's calibrated process data before using this for operational
decision-making.
