// Steel Digital Twin — SCADA dashboard client.
// Vanilla JS + canvas (no external CDN dependency, works fully offline).

const COLORS = { cyan: "#26e6e6", orange: "#ff7a1a", red: "#ff3b3b", green: "#35d68a", dim: "#1a2530" };

class Sparkline {
  constructor(canvasId, color = COLORS.cyan, maxPoints = 90) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext("2d");
    this.color = color;
    this.maxPoints = maxPoints;
    this.data = [];
    this._resize();
    window.addEventListener("resize", () => this._resize());
  }
  _resize() {
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width * devicePixelRatio;
    this.canvas.height = this.canvas.height ? this.canvas.height : 60 * devicePixelRatio;
    this.canvas.height = (this.canvas.clientHeight || 60) * devicePixelRatio;
  }
  push(value) {
    this.data.push(value);
    if (this.data.length > this.maxPoints) this.data.shift();
    this.draw();
  }
  draw() {
    const { ctx, canvas, data, color } = this;
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    if (data.length < 2) return;
    const min = Math.min(...data), max = Math.max(...data);
    const range = (max - min) || 1;
    ctx.beginPath();
    ctx.lineWidth = 2 * devicePixelRatio;
    ctx.strokeStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 6;
    data.forEach((v, i) => {
      const x = (i / (this.maxPoints - 1)) * w;
      const y = h - ((v - min) / range) * (h * 0.85) - h * 0.075;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();
    // fill under curve
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fillStyle = color + "18";
    ctx.fill();
  }
}

const charts = {
  bfTemp: new Sparkline("bf-temp-chart", COLORS.orange),
  eafPower: new Sparkline("eaf-power-chart", COLORS.cyan),
  freq: new Sparkline("freq-chart", COLORS.green),
  breakout: new Sparkline("breakout-chart", COLORS.red),
};

function statusPillClass(status) {
  if (!status) return "status-idle";
  if (status === "running") return "status-running";
  if (status === "starved" || status === "blocked" || status === "degraded") return "status-starved";
  if (status === "faulted" || status === "maintenance" || status === "shutdown") return "status-faulted";
  return "status-idle";
}

function metricRow(label, value, cls = "") {
  return `<div class="metric-row"><span class="metric-label">${label}</span><span class="metric-value ${cls}">${value}</span></div>`;
}

function render(snapshot) {
  document.getElementById("sim-clock").textContent = snapshot.sim_time + "  ·  SHIFT " + snapshot.shift;
  document.getElementById("tick-counter").textContent = "TICK " + snapshot.tick;

  // Furnace / power gauges
  const bf = snapshot.blast_furnace || {};
  if (bf.hearth_temp_c != null) {
    document.getElementById("bf-temp").textContent = bf.hearth_temp_c.toFixed(0) + "°C";
    charts.bfTemp.push(bf.hearth_temp_c);
  }
  const eaf = snapshot.eaf || {};
  if (eaf.power_demand_mw != null) {
    document.getElementById("eaf-power").textContent = eaf.power_demand_mw.toFixed(1) + " MW";
    charts.eafPower.push(eaf.power_demand_mw);
  }
  const power = snapshot.power || {};
  if (power.frequency_hz != null) {
    document.getElementById("grid-freq").textContent = power.frequency_hz.toFixed(2) + " Hz";
    document.getElementById("load-shed").textContent = "LOAD SHED: " + (power.load_shed_pct || 0).toFixed(1) + "%";
    charts.freq.push(power.frequency_hz);
  }
  const caster = snapshot.caster || {};
  if (caster.breakout_risk != null) {
    document.getElementById("breakout-risk").textContent = (caster.breakout_risk * 100).toFixed(1) + "%";
    document.getElementById("micro-phase").textContent = "PHASE: " + (caster.microstructure_phase || "--").toUpperCase();
    charts.breakout.push(caster.breakout_risk);
  }

  // Flow diagram
  const flowStages = [
    ["Raw Yard", snapshot.yard, "ore_pct", "%"],
    ["Ore Plant", snapshot.ore_processing, "sinter_produced_t", "t"],
    ["Coke Plant", snapshot.coke_plant, "coke_produced_t", "t"],
    ["Blast Furnace", bf, "hot_metal_produced_t", "t"],
    ["BOF", snapshot.bof, "steel_produced_t", "t"],
    ["EAF", eaf, "steel_produced_t", "t"],
    ["Caster", caster, "slab_cast_t", "t"],
    ["Rolling Mill", snapshot.rolling_mill, "product_out_t", "t"],
    ["Finishing", snapshot.finishing, "finished_goods_t", "t"],
    ["Shipping", snapshot.shipping, "shipped_t", "t"],
  ];
  document.getElementById("flow-diagram").innerHTML = flowStages.map(([label, obj, key, unit], i) => {
    const val = obj && obj[key] != null ? obj[key].toFixed(1) : "--";
    const arrow = i < flowStages.length - 1 ? '<span class="flow-arrow">&#8594;</span>' : "";
    return `<div class="flow-node">${label}<span class="val">${val} ${unit}</span></div>${arrow}`;
  }).join("");

  // Inventory
  const inv = [
    ["Ore stockpile", snapshot.yard?.ore_pct, "%"],
    ["Coal stockpile", snapshot.yard?.coal_pct, "%"],
    ["Coke buffer", snapshot.coke_plant?.coke_buffer_pct, "%"],
    ["Sinter buffer", snapshot.ore_processing?.sinter_buffer_pct, "%"],
    ["Hot metal buffer", bf?.hot_metal_buffer_t, "t"],
    ["Finished goods", snapshot.finishing?.finished_buffer_t, "t"],
    ["Backlog orders", snapshot.shipping?.backlog_orders_t, "t"],
  ];
  document.getElementById("inventory-list").innerHTML = inv.map(([l, v, u]) =>
    metricRow(l, v != null ? v.toFixed(1) + u : "--")).join("");

  // Energy & emissions
  const em = snapshot.emissions || {};
  const eng = [
    ["Grid import", power.grid_import_mw, "MW"],
    ["Onsite gen", power.onsite_generation_mw, "MW"],
    ["Total demand", power.total_demand_mw, "MW"],
    ["CO2 total", em.total_co2_tonnes, "t"],
    ["Carbon intensity", em.carbon_intensity_t_co2_per_t_steel, "t/t"],
  ];
  document.getElementById("energy-list").innerHTML = eng.map(([l, v, u]) =>
    metricRow(l, v != null ? v.toFixed(2) + " " + u : "--")).join("");

  // Economics
  const econ = snapshot.economics || {};
  const mkt = snapshot.markets || {};
  const econRows = [
    ["Revenue", econ.revenue, "$"],
    ["Total cost", econ.total_cost, "$"],
    ["Gross margin", econ.gross_margin, "$", econ.gross_margin >= 0 ? "green" : "red"],
    ["Steel price", mkt.steel_product_usd_per_t, "$/t"],
    ["Electricity", mkt.electricity_usd_per_mwh, "$/MWh"],
    ["Carbon price", mkt.carbon_usd_per_t, "$/t"],
  ];
  document.getElementById("econ-list").innerHTML = econRows.map(([l, v, u, cls]) =>
    metricRow(l, v != null ? (u === "$" ? "$" + Math.round(v).toLocaleString() : v.toFixed(2) + " " + u) : "--", cls || "")).join("");

  // Logistics
  const disruptions = (snapshot.disruptions && snapshot.disruptions.active_disruptions) || [];
  let logisticsHtml = [
    ["Rail delivered (total)", snapshot.rail?.delivered_total_t, "t"],
    ["Wagons in transit", snapshot.rail?.in_transit_wagons, ""],
    ["Ships queued", snapshot.port?.ships_queued, ""],
    ["Berths occupied", snapshot.port?.berths_occupied, ""],
    ["Fleet utilisation", snapshot.fleet?.fleet_utilisation_pct, "%"],
  ].map(([l, v, u]) => metricRow(l, v != null ? v.toFixed(1) + u : "--")).join("");
  if (disruptions.length) {
    logisticsHtml += `<div style="margin-top:8px;font-size:10px;color:var(--red)">⚠ ${disruptions.length} ACTIVE DISRUPTION(S)</div>`;
    logisticsHtml += disruptions.map(d => `<div class="alarm-item warning"><span class="tag">${d.kind.toUpperCase()}</span><br/>mult ${d.multiplier} · ${d.remaining_hours}h left</div>`).join("");
  }
  document.getElementById("logistics-list").innerHTML = logisticsHtml;

  // Maintenance backlog
  const backlog = snapshot.maintenance_backlog || [];
  document.getElementById("maintenance-list").innerHTML = backlog.length
    ? backlog.slice(0, 6).map(o => `
      <div class="metric-row">
        <span class="metric-label">${o.equipment}</span>
        <span class="metric-value ${o.rul_hours < 72 ? 'red' : 'orange'}">${o.rul_hours.toFixed(0)}h — ${o.action}</span>
      </div>`).join("")
    : '<div class="empty-state">No urgent work orders</div>';

  // Alarms
  const alarms = snapshot.active_alarms || [];
  document.getElementById("alarm-list").innerHTML = alarms.length
    ? alarms.map(a => `<div class="alarm-item ${a.severity === 'CRITICAL' ? '' : 'warning'}"><span class="tag">${a.severity} · ${a.tag}</span><br/>${a.description}: ${Number(a.value).toFixed(1)}</div>`).join("")
    : '<div class="empty-state">All systems nominal</div>';

  // Mechanical properties
  const mech = snapshot.mechanical_properties || {};
  const mechRows = [
    ["Tensile strength", mech.tensile_strength_mpa, "MPa"],
    ["Yield strength", mech.yield_strength_mpa, "MPa"],
    ["Hardness", mech.hardness_hb, "HB"],
    ["Elongation", mech.elongation_pct, "%"],
    ["Fatigue limit", mech.fatigue_limit_mpa, "MPa"],
    ["Impact toughness", mech.impact_toughness_j, "J"],
    ["Brittleness index", mech.brittleness_index, ""],
    ["Contamination risk", snapshot.finishing?.contamination_risk, ""],
  ];
  document.getElementById("mech-props-list").innerHTML = mechRows.map(([l, v, u]) =>
    metricRow(l, v != null ? v + " " + u : "--")).join("");

  // Equipment status
  const eqList = [
    ["Blast Furnace", bf.status], ["BOF", snapshot.bof?.status], ["EAF", eaf.status],
    ["Caster", caster.status], ["Rolling Mill", snapshot.rolling_mill?.status],
    ["Coke Plant", snapshot.coke_plant?.status], ["Finishing", snapshot.finishing?.status],
    ["Shipping", snapshot.shipping?.status],
  ];
  document.getElementById("equipment-status-list").innerHTML = eqList.map(([l, s]) =>
    `<div class="metric-row"><span class="metric-label">${l}</span><span class="status-pill ${statusPillClass(s)}">${s || "n/a"}</span></div>`
  ).join("");
}

function connect() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws`);
  const dot = document.getElementById("conn-dot");
  const status = document.getElementById("conn-status");

  ws.onopen = () => { status.textContent = "LIVE"; dot.style.background = "#35d68a"; };
  ws.onclose = () => {
    status.textContent = "RECONNECTING…"; dot.style.background = "#ff3b3b";
    setTimeout(connect, 1500);
  };
  ws.onerror = () => ws.close();
  ws.onmessage = (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.type === "snapshot" && msg.data && msg.data.tick != null) render(msg.data);
    } catch (e) { console.error(e); }
  };
}

connect();
