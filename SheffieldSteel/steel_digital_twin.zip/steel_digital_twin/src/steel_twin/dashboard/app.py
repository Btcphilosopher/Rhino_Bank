"""
FastAPI + WebSocket "industrial command-centre" dashboard backend.

Runs the SteelworksDigitalTwin on a background asyncio task at a
configurable playback rate, streams full plant-state snapshots to every
connected WebSocket client, and exposes REST endpoints for one-shot
queries (current state, event history, alarm list, maintenance backlog,
optimisation runs).

Serve with:  uvicorn steel_twin.dashboard.app:app --reload
or launch via scripts/run_simulation.py --dashboard
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from ..plant.digital_twin import SteelworksDigitalTwin, PlantConfig

STATIC_DIR = Path(__file__).parent / "static"


class ConnectionManager:
    def __init__(self) -> None:
        self.active: List[WebSocket] = []

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket) -> None:
        if ws in self.active:
            self.active.remove(ws)

    async def broadcast(self, message: dict) -> None:
        dead = []
        payload = json.dumps(message, default=str)
        for ws in self.active:
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


def create_app(config: Optional[PlantConfig] = None, tick_interval_s: float = 1.0) -> FastAPI:
    """Build the FastAPI app. `tick_interval_s` controls dashboard playback
    speed (wall-clock seconds between simulated ticks) -- independent from
    the simulation's own tick_seconds (simulated minutes-per-tick).
    """
    app = FastAPI(title="Steel Digital Twin — Command Centre")
    twin = SteelworksDigitalTwin(config)
    manager = ConnectionManager()
    app.state.twin = twin
    app.state.running = True

    @app.on_event("startup")
    async def _start_sim_loop() -> None:
        async def loop():
            while True:
                if app.state.running:
                    snapshot = twin.tick()
                    await manager.broadcast({"type": "snapshot", "data": snapshot})
                await asyncio.sleep(tick_interval_s)
        app.state.sim_task = asyncio.create_task(loop())

    @app.get("/api/state")
    def get_state():
        return twin.last_snapshot

    @app.get("/api/alarms")
    def get_alarms():
        return [
            {"tag": a.tag, "description": a.description, "value": a.value,
             "severity": a.severity.name, "tick": a.tick}
            for a in twin.alarms.active_alarms
        ]

    @app.get("/api/events")
    def get_events(topic: str = "*", limit: int = 200):
        return [e.to_dict() for e in twin.bus.history(topic, limit)]

    @app.get("/api/maintenance/backlog")
    def get_backlog():
        return twin.last_snapshot.get("maintenance_backlog", [])

    @app.post("/api/control/pause")
    def pause():
        app.state.running = False
        return {"running": False}

    @app.post("/api/control/resume")
    def resume():
        app.state.running = True
        return {"running": True}

    @app.websocket("/ws")
    async def websocket_endpoint(ws: WebSocket):
        await manager.connect(ws)
        try:
            await ws.send_text(json.dumps({"type": "snapshot", "data": twin.last_snapshot}, default=str))
            while True:
                await ws.receive_text()  # keep-alive / ignore client pings
        except WebSocketDisconnect:
            manager.disconnect(ws)

    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/")
    def index():
        return FileResponse(str(STATIC_DIR / "index.html"))

    return app


# Module-level app instance for `uvicorn steel_twin.dashboard.app:app`
app = create_app()
