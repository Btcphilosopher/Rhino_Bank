"""
Emissions and environmental systems: aggregates CO2 (and proxy criteria
pollutants) across every process stage into a plant-wide ledger, and
computes intensity metrics (t CO2 / t steel) used for carbon-tax accrual
and ESG/regulatory reporting.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict

# Representative emission factors, kg pollutant per tonne of process output,
# for criteria pollutants beyond CO2 (order-of-magnitude industrial figures).
EMISSION_FACTORS = {
    "blast_furnace": {"CO2_kg_per_t": 1700, "SO2_kg_per_t": 1.1, "NOx_kg_per_t": 1.4, "PM_kg_per_t": 0.6},
    "coke_plant": {"CO2_kg_per_t": 550, "SO2_kg_per_t": 2.0, "NOx_kg_per_t": 0.8, "PM_kg_per_t": 0.4},
    "bof": {"CO2_kg_per_t": 180, "SO2_kg_per_t": 0.3, "NOx_kg_per_t": 0.2, "PM_kg_per_t": 0.5},
    "eaf": {"CO2_kg_per_t": 100, "SO2_kg_per_t": 0.1, "NOx_kg_per_t": 0.15, "PM_kg_per_t": 0.3},
    "rolling_mill": {"CO2_kg_per_t": 60, "SO2_kg_per_t": 0.05, "NOx_kg_per_t": 0.3, "PM_kg_per_t": 0.05},
}


@dataclass
class EmissionsLedger:
    """Accumulates emissions by process and pollutant over the simulation
    run, and derives plant-wide intensity metrics.
    """

    totals_kg: Dict[str, Dict[str, float]] = field(default_factory=lambda: defaultdict(dict))
    total_steel_shipped_t: float = 0.0

    def record(self, process: str, output_t: float) -> None:
        factors = EMISSION_FACTORS.get(process)
        if not factors:
            return
        bucket = self.totals_kg.setdefault(process, defaultdict(float))
        for pollutant, factor in factors.items():
            bucket[pollutant] = bucket.get(pollutant, 0.0) + factor * output_t

    def record_shipment(self, tonnes: float) -> None:
        self.total_steel_shipped_t += tonnes

    def total_co2_tonnes(self) -> float:
        return sum(v.get("CO2_kg_per_t", 0.0) for v in self.totals_kg.values()) / 1000.0

    def carbon_intensity_t_co2_per_t_steel(self) -> float:
        if self.total_steel_shipped_t <= 0:
            return 0.0
        return self.total_co2_tonnes() / self.total_steel_shipped_t

    def summary(self) -> Dict:
        return {
            "by_process_kg": {k: dict(v) for k, v in self.totals_kg.items()},
            "total_co2_tonnes": round(self.total_co2_tonnes(), 1),
            "carbon_intensity_t_co2_per_t_steel": round(
                self.carbon_intensity_t_co2_per_t_steel(), 3),
            "total_steel_shipped_t": round(self.total_steel_shipped_t, 1),
        }
