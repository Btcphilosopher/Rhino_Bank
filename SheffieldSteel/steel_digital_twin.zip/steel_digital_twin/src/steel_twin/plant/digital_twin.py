"""
SteelworksDigitalTwin: the top-level orchestrator that wires every
independent simulation engine (metallurgy, thermodynamics, processes,
logistics, maintenance, economics, power, emissions, ML/optimisation) into
a single coherent digital twin, advanced tick by tick (default: 1 simulated
minute) via the shared EventBus and StateStore.

This is the object the FastAPI dashboard and CLI scripts drive.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..core.clock import SimulationClock
from ..core.event_bus import EventBus
from ..core.state import StateStore
from ..core.control import AlarmSystem, AlarmDefinition, AlarmSeverity

from ..processes.raw_materials import RawMaterialsYard, OreProcessingPlant
from ..processes.coke_plant import CokePlant
from ..processes.blast_furnace import BlastFurnace
from ..processes.bof import BasicOxygenFurnace
from ..processes.eaf import ElectricArcFurnace
from ..processes.continuous_caster import ContinuousCaster
from ..processes.rolling_mill import RollingMill
from ..processes.finishing_shipping import FinishingLine, ShippingDock

from ..logistics.rail_port import RailNetwork, Port, FleetScheduler, Warehouse
from ..logistics.disruptions import DisruptionEngine

from ..maintenance.predictive import (
    WeibullDegradationModel, RemainingUsefulLifeForecaster,
    MaintenanceScheduleOptimizer, EWMAAnomalyDetector,
)

from ..economics.markets import CommodityMarket, ElectricityMarket, CarbonMarket, CurrencyMarket
from ..economics.finance import PlantEconomics

from ..power.grid_control import IndustrialPowerSystem

from ..emissions.emissions_model import EmissionsLedger

from ..ml.quality_prediction import QualityPredictor

from ..metallurgy.grades import grade_by_name, SteelGrade
from ..metallurgy.chemistry import AlloyComposition, ladle_alloy_trim
from ..metallurgy.properties import predict_mechanical_properties


@dataclass
class PlantConfig:
    steel_route: str = "integrated"   # "integrated" (BF-BOF) or "eaf" (mini-mill)
    grade_key: str = "SAE_1045_automotive"
    blast_furnace_t_per_day: float = 8000.0
    eaf_heats_per_day: float = 22.0
    rolling_mill_t_per_h: float = 300.0
    seed: Optional[int] = 7


class SteelworksDigitalTwin:
    def __init__(self, config: Optional[PlantConfig] = None):
        self.config = config or PlantConfig()
        if self.config.seed is not None:
            random.seed(self.config.seed)

        self.clock = SimulationClock(tick_seconds=60.0)
        self.bus = EventBus()
        self.store = StateStore(snapshot_interval=1440)
        self.alarms = AlarmSystem()
        self._register_alarms()

        # --- Process flow -------------------------------------------------
        self.yard = RawMaterialsYard(self.bus)
        self.ore_plant = OreProcessingPlant(self.bus, self.yard)
        self.coke_plant = CokePlant(self.bus, self.yard)
        self.blast_furnace = BlastFurnace(self.bus, self.yard, self.coke_plant,
                                           nameplate_t_per_day=self.config.blast_furnace_t_per_day)
        self.bof = BasicOxygenFurnace(self.bus, self.blast_furnace)
        self.eaf = ElectricArcFurnace(self.bus, heats_per_day=self.config.eaf_heats_per_day)

        steel_source = self.bof.liquid_steel_buffer if self.config.steel_route == "integrated" \
            else self.eaf.liquid_steel_buffer
        self.caster = ContinuousCaster(self.bus, steel_source)
        self.rolling_mill = RollingMill(self.bus, self.caster.slab_buffer,
                                         nameplate_t_per_h=self.config.rolling_mill_t_per_h)
        self.finishing = FinishingLine(self.bus, self.rolling_mill.product_buffer)
        self.shipping = ShippingDock(self.bus, self.finishing.finished_goods)

        self.grade: SteelGrade = grade_by_name(self.config.grade_key)

        # --- Logistics ------------------------------------------------------
        self.rail = RailNetwork(self.bus)
        self.port = Port(self.bus)
        self.fleet = FleetScheduler(self.bus)
        self.spares_warehouse = Warehouse("spares", capacity=5000, reorder_point=800,
                                           reorder_qty=1500, initial_level=3000)
        self.disruptions = DisruptionEngine(self.bus, seed=self.config.seed)

        # --- Maintenance ------------------------------------------------------
        self.equipment_list = [
            self.blast_furnace.equipment, self.bof.equipment, self.eaf.equipment,
            self.caster.equipment, self.rolling_mill.equipment, self.coke_plant.equipment,
        ]
        self.weibull_models: Dict[str, WeibullDegradationModel] = {
            eq.name: WeibullDegradationModel(eta_hours=random.uniform(30000, 90000),
                                              beta=random.uniform(1.8, 2.8), equipment_name=eq.name)
            for eq in self.equipment_list
        }
        self.rul_forecasters: Dict[str, RemainingUsefulLifeForecaster] = {
            name: RemainingUsefulLifeForecaster(model) for name, model in self.weibull_models.items()
        }
        self.maintenance_optimizer = MaintenanceScheduleOptimizer()
        for eq in self.equipment_list:
            self.maintenance_optimizer.set_criticality(eq.name, 2.0 if "blast" in eq.name else 1.0)
        self.vibration_detectors: Dict[str, EWMAAnomalyDetector] = {
            eq.name: EWMAAnomalyDetector() for eq in self.equipment_list
        }

        # --- Economics / power / emissions -------------------------------------
        self.commodity_market = CommodityMarket()
        self.electricity_market = ElectricityMarket()
        self.carbon_market = CarbonMarket()
        self.currency_market = CurrencyMarket()
        self.plant_economics = PlantEconomics()
        self.power_system = IndustrialPowerSystem(self.bus)
        self.emissions = EmissionsLedger()

        # --- ML layer -----------------------------------------------------------
        self.quality_predictor = QualityPredictor(ridge_lambda=2.0)
        X, y = QualityPredictor.synthesize_training_data()
        self.quality_predictor.fit(X, y)

        self._last_snapshot: Dict = {}

    # ------------------------------------------------------------------
    def _register_alarms(self) -> None:
        self.alarms.register(AlarmDefinition(
            "blast_furnace_hearth_temp", "BF hearth temperature", low=1400, high=1620,
            severity=AlarmSeverity.CRITICAL, esd_action="reduce_blast_rate"))
        self.alarms.register(AlarmDefinition(
            "eaf_power_demand", "EAF transformer overload", high=999999, severity=AlarmSeverity.WARNING))
        self.alarms.register(AlarmDefinition(
            "caster_breakout_risk", "Continuous caster breakout risk", high=0.4,
            severity=AlarmSeverity.CRITICAL, esd_action="reduce_casting_speed"))

    # ------------------------------------------------------------------
    def tick(self) -> Dict:
        self.clock.tick()
        dt_hours = self.clock.tick_seconds / 3600.0
        hour_of_day = self.clock.now.hour

        # -- logistics disruptions first (affects everything downstream) --
        disruption_state = self.disruptions.tick(dt_hours)
        self.rail.disruption_multiplier = self.disruptions.logistics_multiplier
        self.port.disruption_multiplier = self.disruptions.logistics_multiplier
        power_outage_mult = self.disruptions.power_multiplier

        rail_state = self.rail.tick(dt_hours)
        self.yard.receive_delivery("ore", rail_state["arrived_t"] * 0.7)
        self.yard.receive_delivery("coal", rail_state["arrived_t"] * 0.3)
        port_state = self.port.tick(dt_hours)
        self.yard.receive_delivery("ore", port_state["unloaded_t"])
        fleet_state = self.fleet.tick(dt_hours)
        warehouse_state = self.spares_warehouse.tick(dt_hours)

        # -- process flow --
        yard_state = self.yard.tick(dt_hours)
        ore_state = self.ore_plant.tick(dt_hours)
        coke_state = self.coke_plant.tick(dt_hours)

        bf_state = eaf_state = bof_state = {}
        if self.config.steel_route == "integrated":
            bf_state = self.blast_furnace.tick(dt_hours)
        else:
            self.eaf.scrap_buffer.add(50.0)  # simplistic scrap replenishment

        if self.config.steel_route == "integrated":
            bof_state = self.bof.tick(dt_hours)
            tap_chemistry = self.bof.last_chemistry
        else:
            eaf_state = self.eaf.tick(dt_hours)
            tap_chemistry = self.eaf.last_chemistry

        # ladle metallurgy / alloy balancing (process-flow step 7): trims
        # furnace-tap chemistry onto the ordered grade before casting.
        chemistry = ladle_alloy_trim(tap_chemistry, self.grade.target_composition)

        caster_state = self.caster.tick(dt_hours, chemistry=chemistry)
        grain_size_mm = caster_state.get("grain_size_mm", 0.02)
        rolling_state = self.rolling_mill.tick(
            dt_hours, chemistry=chemistry, grain_size_mm=grain_size_mm)
        mech_props = predict_mechanical_properties(
            chemistry, grain_size_mm=grain_size_mm,
            cooling_rate_c_per_s=self.caster.last_cooling_rate_c_per_s,
        )
        finishing_state = self.finishing.tick(
            dt_hours, chemistry=chemistry, grade=self.grade,
            mech_props=mech_props,
        )
        # customer order demand: an average rate close to plant nameplate
        # (so shipping is realistically demand-constrained sometimes and
        # capacity-constrained other times) with day-to-day noise.
        shipping_demand = max(0.0, random.gauss(self.config.rolling_mill_t_per_h * 0.85, 15.0)) * dt_hours
        shipping_state = self.shipping.tick(dt_hours, demand_t=shipping_demand)

        # rejected/off-spec material is remelted as scrap rather than
        # sitting in the reject buffer forever (which would otherwise
        # eventually block the whole finishing line) -- continuously
        # reclaim it back into whichever furnace's scrap charge.
        reclaimed_scrap = self.finishing.reject_buffer.take(self.finishing.reject_buffer.level)
        if reclaimed_scrap > 0:
            target_scrap_buffer = (self.bof.scrap_buffer if self.config.steel_route == "integrated"
                                    else self.eaf.scrap_buffer)
            target_scrap_buffer.add(reclaimed_scrap)

        self.emissions.record("blast_furnace", bf_state.get("hot_metal_produced_t", 0.0))
        self.emissions.record("coke_plant", coke_state.get("coke_produced_t", 0.0))
        self.emissions.record("bof", bof_state.get("steel_produced_t", 0.0))
        self.emissions.record("eaf", eaf_state.get("steel_produced_t", 0.0))
        self.emissions.record("rolling_mill", rolling_state.get("product_out_t", 0.0))
        self.emissions.record_shipment(shipping_state.get("shipped_t", 0.0))

        # -- power ------------------------------------------------------------
        self.power_system.register_load("blast_furnace", 8.0)
        self.power_system.register_load("bof", 6.0)
        self.power_system.register_load("eaf", self.eaf.power_demand_mw)
        self.power_system.register_load("rolling_mill", 22.0)
        self.power_system.register_load("raw_materials_yard", 3.0)
        self.power_system.register_load("ore_processing", 5.0)
        self.power_system.register_load("finishing_line", 4.0)
        self.power_system.set_onsite_generation(18.0)
        power_state = self.power_system.tick(dt_hours, outage_multiplier=power_outage_mult)

        # -- markets / economics ----------------------------------------------
        prices = self.commodity_market.tick(dt_hours)
        elec_price = self.electricity_market.price_usd_per_mwh(hour_of_day, dt_hours)
        carbon_price = self.carbon_market.price_usd_per_tonne(dt_hours)
        fx_rate = self.currency_market.rate(dt_hours)

        total_co2_t_this_tick = (
            bf_state.get("hot_metal_produced_t", 0.0) * 1.7
            + coke_state.get("coke_produced_t", 0.0) * 0.55
            + bof_state.get("steel_produced_t", 0.0) * 0.18
            + eaf_state.get("steel_produced_t", 0.0) * 0.10
        )
        self.plant_economics.accrue_tick(
            dt_hours,
            ore_used_t=ore_state and 0.0 or 0.0,
            coal_used_t=0.0,
            scrap_used_t=eaf_state.get("steel_produced_t", 0.0) / 0.92 if eaf_state else 0.0,
            energy_mwh=power_state["total_demand_mw"] * dt_hours,
            energy_price_usd_per_mwh=elec_price,
            co2_tonnes=total_co2_t_this_tick,
            carbon_price_usd_per_t=carbon_price,
            maintenance_cost_usd=2500 * dt_hours,
            logistics_cost_usd=1800 * dt_hours,
            steel_shipped_t=shipping_state.get("shipped_t", 0.0),
            steel_price_usd_per_t=prices["steel_product_usd_per_t"],
            prices=prices,
        )

        # -- maintenance / anomaly detection ------------------------------------
        rul_forecasts: List[Dict] = []
        for eq in self.equipment_list:
            self.rul_forecasters[eq.name].observe(self.clock.elapsed_hours, eq.health_index)
            forecast = self.rul_forecasters[eq.name].forecast(eq.operating_hours)
            rul_forecasts.append(forecast)
            detector = self.vibration_detectors[eq.name]
            simulated_vibration = 2.0 + (1 - eq.health_index) * 8.0 + random.gauss(0, 0.3)
            anomaly = detector.update(simulated_vibration)
            if anomaly["is_anomaly"]:
                self.bus.publish(f"maintenance.{eq.name}.vibration_anomaly",
                                  anomaly, severity="warning")
        maintenance_backlog = self.maintenance_optimizer.build_backlog(rul_forecasts)

        # -- alarms ---------------------------------------------------------------
        if bf_state.get("hearth_temp_c") is not None:
            self.alarms.evaluate("blast_furnace_hearth_temp", bf_state["hearth_temp_c"],
                                  self.clock.tick_count)
        self.alarms.evaluate("caster_breakout_risk", caster_state.get("breakout_risk", 0.0),
                              self.clock.tick_count)

        snapshot = {
            "tick": self.clock.tick_count,
            "sim_time": self.clock.now.isoformat(),
            "shift": self.clock.shift_of(),
            "route": self.config.steel_route,
            "yard": yard_state,
            "ore_processing": ore_state,
            "coke_plant": coke_state,
            "blast_furnace": bf_state,
            "bof": bof_state,
            "eaf": eaf_state,
            "caster": caster_state,
            "rolling_mill": rolling_state,
            "finishing": finishing_state,
            "mechanical_properties": mech_props.__dict__,
            "shipping": shipping_state,
            "rail": rail_state,
            "port": port_state,
            "fleet": fleet_state,
            "spares_warehouse": warehouse_state,
            "disruptions": disruption_state,
            "power": power_state,
            "markets": {**prices, "electricity_usd_per_mwh": round(elec_price, 2),
                        "carbon_usd_per_t": round(carbon_price, 2), "fx_rate": round(fx_rate, 4)},
            "economics": self.plant_economics.ledger.as_dict(),
            "emissions": self.emissions.summary(),
            "maintenance_backlog": [
                {"equipment": o.equipment, "priority": o.priority_score,
                 "rul_hours": o.rul_hours, "action": o.recommended_action}
                for o in maintenance_backlog[:10]
            ],
            "active_alarms": [
                {"tag": a.tag, "description": a.description, "value": a.value,
                 "severity": a.severity.name} for a in self.alarms.active_alarms
            ],
        }

        self.store.commit(self.clock.tick_count, self.clock.now.isoformat())
        self.store.state.data.update(snapshot)
        self._last_snapshot = snapshot
        return snapshot

    def run(self, n_ticks: int) -> List[Dict]:
        history = []
        for _ in range(n_ticks):
            history.append(self.tick())
        return history

    @property
    def last_snapshot(self) -> Dict:
        return self._last_snapshot
