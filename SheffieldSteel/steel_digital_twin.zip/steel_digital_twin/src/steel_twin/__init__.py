"""
Steel Digital Twin
===================

A production-grade steel manufacturing simulator and digital twin platform.

Sub-packages
------------
core            Event-driven simulation kernel: clock, event bus, shared state,
                entities, control loops.
metallurgy      Alloy chemistry, mechanical property prediction, phase
                transformation kinetics, steel grade specifications.
thermodynamics  Heat transfer, combustion, gas flow / pressure modelling.
processes       Unit process models: raw materials, coke plant, blast furnace,
                EAF, BOF, continuous caster, rolling mill, finishing/shipping.
logistics       Rail freight, port operations, fleet scheduling, warehousing,
                and disruption modelling.
maintenance     Predictive maintenance: degradation models, anomaly detection,
                remaining-useful-life forecasting.
economics       Commodity/electricity markets, cost accounting, ROI/NPV.
power           Industrial power systems and grid modelling.
optimization    Genetic algorithms, Monte Carlo simulation, heuristic
                scheduling for production/maintenance/workforce optimisation.
ml              Lightweight machine-learning layer: quality prediction,
                anomaly models, time-series forecasting.
emissions       Environmental / emissions accounting.
plant           Top level orchestrator that wires every module into a single
                digital twin of an integrated steelworks.
dashboard       FastAPI + WebSocket SCADA-style operations dashboard.
"""

__version__ = "1.0.0"
