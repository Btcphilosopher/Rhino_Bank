"""
Industrial power systems: aggregates plant electrical demand (EAF
transformers, motors, auxiliaries), models on-site generation (top-gas /
waste-heat recovery turbines), grid import, and load-shedding control
under grid-stress or outage disruptions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from ..core.control import PIDController
from ..core.event_bus import EventBus


@dataclass
class PowerBus:
    """A single electrical bus/substation feeding one or more loads."""

    name: str
    rated_mva: float
    frequency_hz: float = 50.0
    voltage_pu: float = 1.0  # per-unit voltage, 1.0 = nominal


class IndustrialPowerSystem:
    """Site-wide power balance: sums demand from registered loads, offsets
    with on-site generation (steam turbo-generators fed by waste-heat
    recovery), and imports the remainder from the grid. A PID-style
    load-shedding controller sheds non-critical load to hold frequency/
    voltage within band during a grid disturbance, mirroring real
    industrial power-management-system (PMS) behaviour.
    """

    def __init__(self, bus: EventBus, grid_import_limit_mw: float = 180.0):
        self.bus = bus
        self.grid_import_limit_mw = grid_import_limit_mw
        self.loads_mw: Dict[str, float] = {}
        self.onsite_generation_mw = 0.0
        self.frequency_controller = PIDController(
            kp=2.0, ki=0.4, kd=0.05, setpoint=50.0, output_min=0.0, output_max=100.0,
        )
        self.load_shed_pct = 0.0
        self.non_critical_loads = {"raw_materials_yard", "ore_processing", "finishing_line"}

    def register_load(self, name: str, demand_mw: float) -> None:
        self.loads_mw[name] = demand_mw

    def set_onsite_generation(self, mw: float) -> None:
        self.onsite_generation_mw = mw

    def tick(self, dt_hours: float, outage_multiplier: float = 1.0) -> Dict:
        total_demand = sum(self.loads_mw.values())
        available_from_grid = self.grid_import_limit_mw * outage_multiplier
        supply = self.onsite_generation_mw + available_from_grid

        deficit = max(0.0, total_demand - supply)
        if deficit > 0:
            # shed non-critical loads proportionally until balanced
            non_critical_total = sum(v for k, v in self.loads_mw.items()
                                      if k in self.non_critical_loads)
            self.load_shed_pct = min(100.0, 100.0 * deficit / max(non_critical_total, 1e-6))
            self.bus.publish("power.load_shed", {"deficit_mw": round(deficit, 1),
                              "shed_pct": round(self.load_shed_pct, 1)}, severity="alarm")
        else:
            self.load_shed_pct = 0.0

        # simulated grid frequency response: deficit depresses frequency,
        # PID governor response (turbine/import ramp) restores it
        simulated_freq = 50.0 - deficit * 0.02
        governor_action = self.frequency_controller.update(simulated_freq, dt=dt_hours)

        grid_import_mw = min(total_demand - self.onsite_generation_mw, available_from_grid)
        grid_import_mw = max(0.0, grid_import_mw)

        return {
            "total_demand_mw": round(total_demand, 1),
            "onsite_generation_mw": round(self.onsite_generation_mw, 1),
            "grid_import_mw": round(grid_import_mw, 1),
            "deficit_mw": round(deficit, 1),
            "load_shed_pct": round(self.load_shed_pct, 1),
            "frequency_hz": round(simulated_freq, 3),
            "governor_action": round(governor_action, 2),
        }
