"""
Logistics & supply-chain engine: rail freight, port operations (berths +
cranes), fleet scheduling, and warehousing. All rates are subject to the
disruption engine (logistics.disruptions) which can throttle or halt flows.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..core.event_bus import EventBus


@dataclass
class Wagon:
    id: int
    capacity_t: float = 100.0
    load_t: float = 0.0
    en_route: bool = False
    eta_hours: float = 0.0


class RailNetwork:
    """Simplified single-line rail freight model: a fleet of wagons cycles
    between a mine/port origin and the plant, with transit time and a
    disruption-adjustable throughput multiplier.
    """

    def __init__(self, bus: EventBus, n_wagons: int = 120, wagon_capacity_t: float = 100.0,
                 transit_hours: float = 14.0, loads_per_day_capacity: float = 40.0):
        self.bus = bus
        self.wagons = [Wagon(i, wagon_capacity_t) for i in range(n_wagons)]
        self.transit_hours = transit_hours
        self.loads_per_day_capacity = loads_per_day_capacity
        self.disruption_multiplier = 1.0  # set externally by DisruptionEngine
        self._in_transit: List[Wagon] = []
        self.delivered_total_t = 0.0
        self.delay_hours_accum = 0.0

    def dispatch(self, dt_hours: float) -> float:
        """Dispatch loaded wagons; returns tonnes now in transit."""
        capacity_this_tick = self.loads_per_day_capacity / 24.0 * dt_hours * self.disruption_multiplier
        dispatched = 0.0
        for w in self.wagons:
            if not w.en_route and dispatched < capacity_this_tick:
                w.load_t = w.capacity_t
                w.en_route = True
                w.eta_hours = self.transit_hours / max(self.disruption_multiplier, 0.05)
                self._in_transit.append(w)
                dispatched += w.load_t
        return dispatched

    def tick(self, dt_hours: float) -> Dict:
        arrived_t = 0.0
        still_transit: List[Wagon] = []
        for w in self._in_transit:
            w.eta_hours -= dt_hours
            if w.eta_hours <= 0:
                arrived_t += w.load_t
                w.load_t = 0.0
                w.en_route = False
            else:
                still_transit.append(w)
        self._in_transit = still_transit
        dispatched = self.dispatch(dt_hours)
        self.delivered_total_t += arrived_t

        if self.disruption_multiplier < 0.5:
            self.bus.publish("logistics.rail.severe_delay",
                              {"multiplier": self.disruption_multiplier}, severity="warning")

        return {
            "arrived_t": round(arrived_t, 1),
            "in_transit_wagons": len(self._in_transit),
            "delivered_total_t": round(self.delivered_total_t, 1),
            "disruption_multiplier": round(self.disruption_multiplier, 2),
        }


@dataclass
class Berth:
    id: int
    occupied: bool = False
    ship_remaining_hours: float = 0.0
    cargo_t: float = 0.0
    crane_rate_t_per_h: float = 1200.0


class Port:
    """Bulk ore/coal terminal: ships queue for berths, cranes unload at a
    fixed rate subject to weather/crane-availability disruptions.
    """

    def __init__(self, bus: EventBus, n_berths: int = 3, avg_ship_size_t: float = 180_000,
                 ship_arrival_interval_hours: float = 60.0):
        self.bus = bus
        self.berths = [Berth(i) for i in range(n_berths)]
        self.avg_ship_size_t = avg_ship_size_t
        self.ship_arrival_interval_hours = ship_arrival_interval_hours
        self._hours_since_last_arrival = 0.0
        self.queue: List[float] = []  # queued ship cargo sizes waiting for a berth
        self.disruption_multiplier = 1.0
        self.total_unloaded_t = 0.0

    def _maybe_spawn_arrival(self, dt_hours: float) -> None:
        self._hours_since_last_arrival += dt_hours
        if self._hours_since_last_arrival >= self.ship_arrival_interval_hours:
            self._hours_since_last_arrival = 0.0
            size = max(20_000, random.gauss(self.avg_ship_size_t, self.avg_ship_size_t * 0.15))
            self.queue.append(size)

    def tick(self, dt_hours: float) -> Dict:
        self._maybe_spawn_arrival(dt_hours)

        # assign queued ships to free berths
        for berth in self.berths:
            if not berth.occupied and self.queue:
                cargo = self.queue.pop(0)
                berth.occupied = True
                berth.cargo_t = cargo
                berth.ship_remaining_hours = cargo / berth.crane_rate_t_per_h

        unloaded_this_tick = 0.0
        for berth in self.berths:
            if berth.occupied:
                rate = berth.crane_rate_t_per_h * self.disruption_multiplier
                unload = min(berth.cargo_t, rate * dt_hours)
                berth.cargo_t -= unload
                unloaded_this_tick += unload
                if berth.cargo_t <= 1e-6:
                    berth.occupied = False
                    berth.cargo_t = 0.0

        self.total_unloaded_t += unloaded_this_tick

        if len(self.queue) > len(self.berths) * 2:
            self.bus.publish("logistics.port.congestion", {"queue_len": len(self.queue)},
                              severity="warning")

        return {
            "unloaded_t": round(unloaded_this_tick, 1),
            "berths_occupied": sum(1 for b in self.berths if b.occupied),
            "ships_queued": len(self.queue),
            "total_unloaded_t": round(self.total_unloaded_t, 1),
        }


@dataclass
class Vehicle:
    id: int
    kind: str  # "crane" | "truck" | "locomotive"
    available: bool = True
    fuel_l_per_h: float = 25.0
    hours_operated: float = 0.0


class FleetScheduler:
    """Schedules internal plant fleet (cranes, yard trucks, shunting
    locomotives) against duty requests, tracking utilisation and fuel
    consumption -- feeds both economics (fuel cost) and emissions.
    """

    def __init__(self, bus: EventBus, n_cranes: int = 12, n_trucks: int = 40,
                 n_locomotives: int = 8):
        self.bus = bus
        self.fleet: List[Vehicle] = (
            [Vehicle(i, "crane") for i in range(n_cranes)]
            + [Vehicle(100 + i, "truck", fuel_l_per_h=12.0) for i in range(n_trucks)]
            + [Vehicle(200 + i, "locomotive", fuel_l_per_h=60.0) for i in range(n_locomotives)]
        )
        self.fuel_used_l_total = 0.0

    def request(self, kind: str, n_needed: int) -> List[Vehicle]:
        available = [v for v in self.fleet if v.kind == kind and v.available][:n_needed]
        for v in available:
            v.available = False
        return available

    def release(self, vehicles: List[Vehicle]) -> None:
        for v in vehicles:
            v.available = True

    def tick(self, dt_hours: float) -> Dict:
        fuel_this_tick = 0.0
        for v in self.fleet:
            if not v.available:  # actively operating
                v.hours_operated += dt_hours
                fuel_this_tick += v.fuel_l_per_h * dt_hours
        self.fuel_used_l_total += fuel_this_tick
        utilisation = sum(1 for v in self.fleet if not v.available) / max(len(self.fleet), 1)
        return {
            "fuel_used_l_this_tick": round(fuel_this_tick, 1),
            "fuel_used_l_total": round(self.fuel_used_l_total, 1),
            "fleet_utilisation_pct": round(utilisation * 100, 1),
        }


class Warehouse:
    """Generic finished-goods / spares warehouse with reorder-point
    inventory management (used both for plant spares and product
    inventory)."""

    def __init__(self, name: str, capacity: float, reorder_point: float,
                 reorder_qty: float, initial_level: float = 0.0, lead_time_hours: float = 48.0):
        self.name = name
        self.capacity = capacity
        self.level = initial_level
        self.reorder_point = reorder_point
        self.reorder_qty = reorder_qty
        self.lead_time_hours = lead_time_hours
        self._pending_orders: List[float] = []  # eta_hours remaining, tracked in parallel list
        self._pending_eta: List[float] = []

    def consume(self, amount: float) -> float:
        taken = min(self.level, amount)
        self.level -= taken
        return taken

    def receive(self, amount: float) -> None:
        self.level = min(self.capacity, self.level + amount)

    def tick(self, dt_hours: float) -> Dict:
        # advance pending orders
        arrived = 0.0
        remaining_eta = []
        for eta in self._pending_eta:
            eta -= dt_hours
            if eta <= 0:
                arrived += self.reorder_qty
            else:
                remaining_eta.append(eta)
        self._pending_eta = remaining_eta
        if arrived:
            self.receive(arrived)

        reordered = False
        if self.level <= self.reorder_point and len(self._pending_eta) == 0:
            self._pending_eta.append(self.lead_time_hours)
            reordered = True

        return {
            "level": round(self.level, 1),
            "fill_pct": round(100 * self.level / self.capacity, 1) if self.capacity else 0.0,
            "reordered": reordered,
            "orders_in_transit": len(self._pending_eta),
        }
