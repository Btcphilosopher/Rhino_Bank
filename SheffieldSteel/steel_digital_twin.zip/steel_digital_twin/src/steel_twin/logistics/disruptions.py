"""
Supply-chain disruption engine: stochastically injects strikes, weather,
geopolitical instability, fuel shortages and power outages, applying
throughput multipliers to the logistics network (and, via the event bus,
to power/economics modules) so the plant can be stress-tested end to end.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from ..core.event_bus import EventBus


class DisruptionType(str, Enum):
    STRIKE = "strike"
    WEATHER = "weather"
    GEOPOLITICAL = "geopolitical"
    FUEL_SHORTAGE = "fuel_shortage"
    POWER_OUTAGE = "power_outage"


@dataclass
class DisruptionProfile:
    kind: DisruptionType
    probability_per_day: float
    duration_hours_mean: float
    duration_hours_std: float
    severity_multiplier_range: tuple  # (min throughput multiplier, max)


DEFAULT_PROFILES: List[DisruptionProfile] = [
    DisruptionProfile(DisruptionType.STRIKE, 0.003, 72, 24, (0.0, 0.3)),
    DisruptionProfile(DisruptionType.WEATHER, 0.02, 18, 10, (0.2, 0.7)),
    DisruptionProfile(DisruptionType.GEOPOLITICAL, 0.001, 240, 120, (0.1, 0.6)),
    DisruptionProfile(DisruptionType.FUEL_SHORTAGE, 0.004, 96, 48, (0.3, 0.8)),
    DisruptionProfile(DisruptionType.POWER_OUTAGE, 0.006, 4, 3, (0.0, 0.5)),
]


@dataclass
class DisruptionEvent:
    kind: DisruptionType
    remaining_hours: float
    multiplier: float


class DisruptionEngine:
    """Rolls stochastic disruption events each tick and exposes the
    aggregate throughput multiplier currently affecting rail/port
    logistics, and separately the power-outage flag consumed by
    `power.grid_control`.
    """

    def __init__(self, bus: EventBus, profiles: Optional[List[DisruptionProfile]] = None,
                 seed: Optional[int] = None):
        self.bus = bus
        self.profiles = profiles or DEFAULT_PROFILES
        self._rng = random.Random(seed)
        self.active: List[DisruptionEvent] = []

    def tick(self, dt_hours: float) -> Dict:
        # roll for new disruptions
        for profile in self.profiles:
            p_this_tick = 1 - (1 - profile.probability_per_day) ** (dt_hours / 24.0)
            if self._rng.random() < p_this_tick:
                duration = max(1.0, self._rng.gauss(profile.duration_hours_mean,
                                                      profile.duration_hours_std))
                mult = self._rng.uniform(*profile.severity_multiplier_range)
                event = DisruptionEvent(profile.kind, duration, mult)
                self.active.append(event)
                self.bus.publish(f"logistics.disruption.{profile.kind.value}",
                                  {"duration_hours": round(duration, 1), "multiplier": round(mult, 2)},
                                  severity="alarm" if mult < 0.3 else "warning")

        # decay existing
        still_active: List[DisruptionEvent] = []
        for ev in self.active:
            ev.remaining_hours -= dt_hours
            if ev.remaining_hours > 0:
                still_active.append(ev)
        self.active = still_active

        return {
            "active_disruptions": [
                {"kind": ev.kind.value, "remaining_hours": round(ev.remaining_hours, 1),
                 "multiplier": round(ev.multiplier, 2)}
                for ev in self.active
            ],
        }

    @property
    def logistics_multiplier(self) -> float:
        """Combined multiplier for rail/port throughput -- the minimum
        across active disruptions that affect physical movement of goods
        (i.e. everything except pure power outages, handled separately).
        """
        relevant = [ev.multiplier for ev in self.active
                    if ev.kind != DisruptionType.POWER_OUTAGE]
        return min(relevant) if relevant else 1.0

    @property
    def power_outage_active(self) -> bool:
        return any(ev.kind == DisruptionType.POWER_OUTAGE for ev in self.active)

    @property
    def power_multiplier(self) -> float:
        outages = [ev.multiplier for ev in self.active if ev.kind == DisruptionType.POWER_OUTAGE]
        return min(outages) if outages else 1.0
