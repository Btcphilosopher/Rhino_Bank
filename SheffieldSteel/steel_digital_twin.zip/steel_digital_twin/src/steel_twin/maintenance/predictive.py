"""
Predictive maintenance layer.

  * WeibullDegradationModel: standard reliability-engineering failure-time
    distribution, used for bearings, conveyors, rolling-mill components
    (Weibull is the industry-standard model for mechanical wear-out
    failures -- shape parameter beta > 1 models increasing failure rate).
  * EWMAAnomalyDetector: exponentially-weighted moving-average control
    chart for vibration/temperature/current anomaly detection (a
    lightweight, dependency-free stand-in for a learned autoencoder/
    isolation-forest anomaly model, with the same interface so it can be
    swapped for `ml.anomaly_models` without touching call sites).
  * RemainingUsefulLifeForecaster: combines the health-index trend with the
    Weibull hazard function to forecast remaining useful life (RUL).
  * MaintenanceScheduleOptimizer: turns RUL forecasts + business priority
    into an ordered maintenance work-order backlog.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional


@dataclass
class WeibullDegradationModel:
    """Two-parameter Weibull reliability model:
        R(t) = exp(-(t/eta)^beta)          survival probability
        h(t) = (beta/eta) * (t/eta)^(beta-1)  instantaneous hazard rate

    eta: characteristic life (scale, hours)
    beta: shape parameter (>1 => wear-out, accelerating failure rate --
    typical for bearings/rolling contact fatigue; beta~1 => random/
    electrical failures; beta<1 => infant mortality).
    """

    eta_hours: float
    beta: float = 2.2
    equipment_name: str = ""

    def survival(self, t_hours: float) -> float:
        if t_hours <= 0:
            return 1.0
        return math.exp(-((t_hours / self.eta_hours) ** self.beta))

    def hazard_rate(self, t_hours: float) -> float:
        if t_hours <= 0:
            return 0.0
        return (self.beta / self.eta_hours) * (t_hours / self.eta_hours) ** (self.beta - 1)

    def expected_remaining_life(self, operating_hours: float,
                                 stress_factor: float = 1.0) -> float:
        """Mean residual life approximation: for a Weibull with elapsed age
        `operating_hours`, adjusted by an operational `stress_factor`
        (>1 = harsher duty cycle, e.g. overheating, overload, accelerates
        the effective clock).
        """
        effective_age = operating_hours * stress_factor
        # Numerically integrate survival function beyond current age for the
        # conditional mean residual life: E[T-t | T>t] = int_t^inf R(s)ds / R(t)
        r_t = self.survival(effective_age)
        if r_t < 1e-9:
            return 0.0
        # simple trapezoidal quadrature out to 3x characteristic life
        upper = self.eta_hours * 3
        n = 200
        step = (upper - effective_age) / n
        if step <= 0:
            return 0.0
        total = 0.0
        s = effective_age
        for _ in range(n):
            total += 0.5 * (self.survival(s) + self.survival(s + step)) * step
            s += step
        return total / r_t / max(stress_factor, 1e-6)


@dataclass
class EWMAAnomalyDetector:
    """Exponentially-weighted moving average + control-limit anomaly
    detector, suitable for streaming vibration/temperature/current signals.
    """

    lam: float = 0.2               # EWMA smoothing factor (0-1)
    n_sigma: float = 3.0            # control-limit width
    window: int = 200

    _mean: Optional[float] = field(default=None, init=False)
    _var: float = field(default=0.0, init=False)
    _history: Deque[float] = field(default_factory=lambda: deque(maxlen=200), init=False)

    def update(self, value: float) -> Dict:
        self._history.append(value)
        if self._mean is None:
            self._mean = value
            self._var = 0.0
            return {
                "value": value, "ewma": round(self._mean, 4), "std": 0.0,
                "upper_limit": self._mean, "lower_limit": self._mean,
                "is_anomaly": False, "z_score": 0.0,
            }

        # Test the incoming value against the *prior* baseline (control
        # limits computed before absorbing this observation) -- this is
        # what makes it possible to actually flag an outlier; updating the
        # baseline first would let a spike drag its own control limits
        # along with it.
        std = math.sqrt(max(self._var, 1e-9))
        upper = self._mean + self.n_sigma * std
        lower = self._mean - self.n_sigma * std
        is_anomaly = value > upper or value < lower
        z_score = (value - self._mean) / std if std > 1e-9 else 0.0

        delta = value - self._mean
        self._mean = self.lam * value + (1 - self.lam) * self._mean
        self._var = (1 - self.lam) * (self._var + self.lam * delta ** 2)

        return {
            "value": value,
            "ewma": round(self._mean, 4),
            "std": round(std, 4),
            "upper_limit": round(upper, 4),
            "lower_limit": round(lower, 4),
            "is_anomaly": is_anomaly,
            "z_score": round(z_score, 3),
        }


@dataclass
class RemainingUsefulLifeForecaster:
    """Combines a component's Weibull model with its live health-index
    trend (health_index in [0,1], from core.entities.Equipment) to produce
    an RUL estimate in hours, blending model-based and trend-based
    (degradation-slope extrapolation) predictions.
    """

    weibull: WeibullDegradationModel
    _health_history: Deque[tuple] = field(default_factory=lambda: deque(maxlen=500), init=False)

    def observe(self, tick_hours: float, health_index: float) -> None:
        self._health_history.append((tick_hours, health_index))

    def trend_based_rul(self, failure_threshold: float = 0.15) -> Optional[float]:
        """Linear extrapolation of the recent health-index slope to the
        failure threshold."""
        if len(self._health_history) < 5:
            return None
        xs = [h[0] for h in self._health_history]
        ys = [h[1] for h in self._health_history]
        n = len(xs)
        mean_x = sum(xs) / n
        mean_y = sum(ys) / n
        cov = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
        var = sum((x - mean_x) ** 2 for x in xs)
        if var < 1e-9:
            return None
        slope = cov / var  # health change per hour
        if slope >= 0:
            return None  # not degrading
        current_health = ys[-1]
        hours_to_threshold = (current_health - failure_threshold) / (-slope)
        return max(0.0, hours_to_threshold)

    def forecast(self, operating_hours: float, stress_factor: float = 1.0) -> Dict:
        model_rul = self.weibull.expected_remaining_life(operating_hours, stress_factor)
        trend_rul = self.trend_based_rul()
        if trend_rul is not None:
            blended = 0.5 * model_rul + 0.5 * trend_rul
        else:
            blended = model_rul
        return {
            "equipment": self.weibull.equipment_name,
            "model_rul_hours": round(model_rul, 1),
            "trend_rul_hours": round(trend_rul, 1) if trend_rul is not None else None,
            "blended_rul_hours": round(blended, 1),
            "failure_probability_30d": round(
                1 - self.weibull.survival(operating_hours * stress_factor + 30 * 24)
                / max(self.weibull.survival(operating_hours * stress_factor), 1e-9), 4),
        }


@dataclass
class MaintenanceWorkOrder:
    equipment: str
    priority_score: float
    rul_hours: float
    recommended_action: str


class MaintenanceScheduleOptimizer:
    """Ranks a fleet of RUL forecasts + business-criticality weights into a
    prioritised maintenance backlog (feeds optimization.scheduler for
    crew/downtime-window assignment).
    """

    def __init__(self) -> None:
        self.criticality: Dict[str, float] = {}

    def set_criticality(self, equipment: str, weight: float) -> None:
        self.criticality[equipment] = weight

    def build_backlog(self, forecasts: List[Dict]) -> List[MaintenanceWorkOrder]:
        orders = []
        for f in forecasts:
            crit = self.criticality.get(f["equipment"], 1.0)
            rul = f["blended_rul_hours"]
            # priority rises as RUL shrinks and criticality rises (simple
            # inverse-time-weighted risk score)
            urgency = 1.0 / max(rul, 1.0)
            priority = urgency * crit * 1000
            if rul < 24 * 3:
                action = "immediate shutdown & replace"
            elif rul < 24 * 14:
                action = "schedule within 2 weeks"
            else:
                action = "monitor / routine PM"
            orders.append(MaintenanceWorkOrder(f["equipment"], round(priority, 2), rul, action))
        orders.sort(key=lambda o: -o.priority_score)
        return orders
