"""
Steel grade catalogue: target chemistries and processing targets for the
grade families requested (structural, stainless, tool, automotive, and
military/aerospace-grade alloys).

Compositions are representative of well-known real specifications
(AISI/SAE/ASTM families) for engineering plausibility; treat as reference
defaults, not certified mill-spec values.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from .chemistry import AlloyComposition


@dataclass
class SteelGrade:
    name: str
    family: str
    target_composition: AlloyComposition
    tolerance_pct: float = 0.15          # allowed relative deviation per element
    target_cooling_rate_c_per_s: float = 5.0
    target_grain_size_mm: float = 0.02
    min_tensile_mpa: float = 400.0
    min_elongation_pct: float = 12.0
    typical_applications: str = ""


STEEL_GRADES: Dict[str, SteelGrade] = {
    "A36_structural": SteelGrade(
        name="A36 Structural",
        family="structural",
        target_composition=AlloyComposition(C=0.26, Mn=0.9, Si=0.20, P=0.04, S=0.05, Cu=0.20),
        target_cooling_rate_c_per_s=1.5,
        target_grain_size_mm=0.03,
        min_tensile_mpa=400.0,
        min_elongation_pct=20.0,
        typical_applications="Structural beams, plate, construction steel",
    ),
    "AISI_304_stainless": SteelGrade(
        name="AISI 304 Stainless",
        family="stainless",
        target_composition=AlloyComposition(
            C=0.05, Mn=1.5, Si=0.6, P=0.03, S=0.02, Cr=18.5, Ni=8.5, N=0.05
        ),
        target_cooling_rate_c_per_s=15.0,
        target_grain_size_mm=0.015,
        min_tensile_mpa=515.0,
        min_elongation_pct=40.0,
        typical_applications="Food processing, chemical plant, architectural",
    ),
    "AISI_D2_tool": SteelGrade(
        name="AISI D2 Tool Steel",
        family="tool_steel",
        target_composition=AlloyComposition(
            C=1.5, Mn=0.4, Si=0.4, Cr=12.0, Mo=0.9, V=0.9
        ),
        target_cooling_rate_c_per_s=25.0,
        target_grain_size_mm=0.008,
        min_tensile_mpa=1900.0,
        min_elongation_pct=2.0,
        typical_applications="Dies, punches, cutting tools",
    ),
    "SAE_1045_automotive": SteelGrade(
        name="SAE 1045 Automotive",
        family="automotive",
        target_composition=AlloyComposition(C=0.45, Mn=0.75, Si=0.25, P=0.03, S=0.03),
        target_cooling_rate_c_per_s=8.0,
        target_grain_size_mm=0.018,
        min_tensile_mpa=625.0,
        min_elongation_pct=16.0,
        typical_applications="Crankshafts, axles, gears",
    ),
    "MIL_A46100_armor": SteelGrade(
        name="MIL-A-46100 Armor Steel",
        family="military",
        target_composition=AlloyComposition(
            C=0.30, Mn=0.85, Si=0.30, Cr=1.05, Ni=1.8, Mo=0.45, V=0.05
        ),
        target_cooling_rate_c_per_s=35.0,
        target_grain_size_mm=0.006,
        min_tensile_mpa=1500.0,
        min_elongation_pct=8.0,
        typical_applications="Ballistic armor plate, vehicle hulls",
    ),
    "AMS_4340_aerospace": SteelGrade(
        name="AMS 6415 (4340) Aerospace",
        family="aerospace",
        target_composition=AlloyComposition(
            C=0.40, Mn=0.70, Si=0.25, Cr=0.80, Ni=1.83, Mo=0.25
        ),
        target_cooling_rate_c_per_s=30.0,
        target_grain_size_mm=0.007,
        min_tensile_mpa=1780.0,
        min_elongation_pct=10.0,
        typical_applications="Landing gear, high-strength structural aerospace components",
    ),
}


def grade_by_name(key: str) -> SteelGrade:
    try:
        return STEEL_GRADES[key]
    except KeyError as exc:
        raise KeyError(
            f"Unknown steel grade '{key}'. Available: {list(STEEL_GRADES)}"
        ) from exc
