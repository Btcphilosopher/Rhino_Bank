"""
Mechanical property prediction from chemistry, grain size and processing
history.

Uses established empirical/semi-empirical ferrous-metallurgy correlations
so the numbers are engineering-plausible rather than arbitrary:

  * Hardness from composition + cooling rate: simplified Maynier-style
    additive model
  * Hardness -> UTS: UTS[MPa] ~= 3.45 x HB  (long-standing empirical steel
    correlation, ASTM/AISI handbooks)
  * Yield strength via Hall-Petch grain refinement: sigma_y = sigma_0 + k/sqrt(d)
  * Ductility (elongation) inversely related to strength and impurity content
  * Fatigue endurance limit ~= 0.45-0.5 x UTS for wrought steels (Se/Su ratio)
  * Impurity (P, S) embrittlement penalty
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .chemistry import AlloyComposition


@dataclass
class MechanicalProperties:
    hardness_hb: float
    tensile_strength_mpa: float
    yield_strength_mpa: float
    elongation_pct: float          # ductility measure
    fatigue_limit_mpa: float
    impact_toughness_j: float      # Charpy V-notch proxy
    brittleness_index: float       # 0 (tough) - 1 (brittle)


# Hall-Petch constants for ferritic steel (engineering approximation, MPa, mm)
HALL_PETCH_SIGMA0 = 70.0     # MPa, lattice friction stress
HALL_PETCH_K = 18.0          # MPa*mm^0.5, grain-boundary strengthening coefficient


def _base_hardness_hb(comp: AlloyComposition, cooling_rate_c_per_s: float) -> float:
    """Simplified Maynier-type additive hardness model (Brinell hardness),
    driven by carbon content, alloying (hardenability), and cooling rate.

    Blends between a slow-cooled/normalised pearlitic hardness curve and a
    fast-cooled/quenched martensitic hardness curve using
    `cooling_response` (0 = fully pearlitic, 1 = fully martensitic) -- the
    carbon contribution has to be split this way because a 0.8%C steel is
    ~200-230 HB normalised but ~600+ HB as-quenched; a single carbon
    coefficient can't represent both regimes at once.
    """
    c_eutectoid = min(max(comp.C, 0.01), 0.80)
    excess_c = max(0.0, comp.C - 0.80)

    pearlite_hb = 90 + 150 * c_eutectoid + 60 * excess_c
    martensite_hb = 90 + 640 * c_eutectoid + 60 * excess_c

    cooling_response = min(1.0, math.log1p(max(cooling_rate_c_per_s, 0.01)) / math.log1p(50))
    base = pearlite_hb + cooling_response * (martensite_hb - pearlite_hb)

    # Alloying elements raise hardenability -- their effect on realised
    # hardness grows with faster cooling (more martensite retained) but
    # still contributes modestly via solid-solution strengthening even
    # when slow-cooled.
    alloy_factor = (
        comp.Mn * 25 + comp.Cr * 30 + comp.Ni * 12 + comp.Mo * 40
        + comp.Si * 10 + comp.V * 35 + comp.W * 15 + comp.B * 400
    )
    hardness = base + alloy_factor * (0.3 + 0.7 * cooling_response)
    return max(80.0, hardness)


def predict_mechanical_properties(comp: AlloyComposition,
                                   grain_size_mm: float = 0.02,
                                   cooling_rate_c_per_s: float = 1.0,
                                   ) -> MechanicalProperties:
    """Predict bulk mechanical properties for a steel of given chemistry,
    grain size (post rolling/heat-treat) and cooling rate through the
    austenite decomposition range (roughly 800->500 C).

    grain_size_mm: ASTM-like grain diameter in mm (finer = higher strength &
    toughness via Hall-Petch).
    """
    hb = _base_hardness_hb(comp, cooling_rate_c_per_s)

    # Empirical hardness -> tensile strength correlation for steels.
    uts = 3.45 * hb

    # Hall-Petch yield strength, refined by solid-solution strengthening from
    # Mn/Si/Cr and reduced by embrittling residuals (P, S promote
    # grain-boundary fracture rather than raising yield, handled below).
    solid_solution = comp.Mn * 30 + comp.Si * 40 + comp.Cr * 15 + comp.Ni * 8
    sigma_y = HALL_PETCH_SIGMA0 + HALL_PETCH_K / math.sqrt(max(grain_size_mm, 1e-4)) \
        + solid_solution
    sigma_y = min(sigma_y, uts * 0.95)  # yield can't exceed UTS

    # Ductility: elongation falls as strength rises and as impurities (P, S)
    # and carbon rise (classic strength-ductility trade-off). P/S are wt%
    # (e.g. 0.03 = 0.03%); each 0.01wt% of P/S costs a fraction of an
    # elongation percentage-point, consistent with real embrittlement
    # sensitivity rather than swamping the whole ductility budget.
    impurity_penalty = comp.P * 8.0 + comp.S * 6.0
    elongation = max(2.0, 45.0 - 0.02 * (uts - 300) - impurity_penalty
                      - comp.C * 15.0)
    elongation = min(elongation, 55.0)

    # Fatigue endurance limit: classic Se/Su ~ 0.45-0.5 for wrought steel,
    # degraded by sulfur (inclusions nucleate fatigue cracks).
    fatigue_ratio = 0.5 - min(0.15, comp.S * 20.0)
    fatigue_limit = uts * fatigue_ratio

    # Charpy impact toughness proxy: finer grain & lower carbon/impurities
    # raise toughness (ductile-brittle transition improves with grain
    # refinement, per Hall-Petch analogue for toughness).
    toughness = max(
        2.0,
        120.0 / math.sqrt(max(grain_size_mm, 1e-4)) / 10.0
        - comp.C * 40.0 - impurity_penalty * 0.3 - comp.Cr * 1.5,
    )

    brittleness = max(0.0, min(1.0, 1.0 - (toughness / 60.0)))

    return MechanicalProperties(
        hardness_hb=round(hb, 1),
        tensile_strength_mpa=round(uts, 1),
        yield_strength_mpa=round(sigma_y, 1),
        elongation_pct=round(elongation, 2),
        fatigue_limit_mpa=round(fatigue_limit, 1),
        impact_toughness_j=round(toughness, 1),
        brittleness_index=round(brittleness, 3),
    )


_IMPURITY_ELEMENTS = {"P", "S"}


def contamination_risk_score(comp: AlloyComposition, target: AlloyComposition,
                              tolerance_pct: float = 0.15) -> float:
    """0-1 risk score for a heat's chemistry drifting outside grade
    tolerance (used by the ML quality-prediction layer as a feature and
    standalone heuristic check).

    Alloying elements are scored on symmetric relative deviation from
    target (too little *or* too much is off-spec). P and S are a
    not-to-exceed ceiling: being under it contributes no risk at all, only
    exceeding it does.
    """
    deviations = []
    for el, tgt in target.as_dict().items():
        if tgt <= 0:
            continue
        actual = getattr(comp, el, 0.0)
        if el in _IMPURITY_ELEMENTS:
            rel_dev = max(0.0, actual - tgt) / max(tgt, 1e-6)
        else:
            rel_dev = abs(actual - tgt) / max(tgt, 1e-6)
        deviations.append(rel_dev)
    if not deviations:
        return 0.0
    mean_dev = sum(deviations) / len(deviations)
    return max(0.0, min(1.0, mean_dev / max(tolerance_pct, 1e-6) * 0.5))
