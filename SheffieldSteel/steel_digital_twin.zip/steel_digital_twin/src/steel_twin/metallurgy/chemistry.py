"""
Alloy and slag chemistry.

Implements standard ferrous-metallurgy engineering relations:
  * IIW carbon equivalent (weldability / hardenability screening)
  * Slag basicity (B2, B4) and metal/slag oxygen partition
  * Stoichiometric oxygen demand for BOF decarburization
  * Simple mass-balance alloy trimming for ladle additions

References (standard textbook relations, implemented directly, no external
data files required):
  - International Institute of Welding carbon-equivalent formula
  - Turkdogan, "Fundamentals of Steelmaking" for slag basicity / oxygen balance
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class AlloyComposition:
    """Weight-percent chemistry of a steel melt/heat.

    All elements default to 0.0 wt%. Fe is not tracked explicitly (assumed
    balance).
    """

    C: float = 0.0
    Mn: float = 0.0
    Si: float = 0.0
    P: float = 0.0
    S: float = 0.0
    Cr: float = 0.0
    Ni: float = 0.0
    Mo: float = 0.0
    V: float = 0.0
    Cu: float = 0.0
    Al: float = 0.0
    Nb: float = 0.0
    Ti: float = 0.0
    N: float = 0.0
    B: float = 0.0
    W: float = 0.0  # tungsten, for tool steels

    def as_dict(self) -> Dict[str, float]:
        return {k: v for k, v in self.__dict__.items()}

    def carbon_equivalent_iiw(self) -> float:
        """IIW carbon equivalent:
        CE = C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15
        Higher CE => higher hardenability, higher cracking risk when welding.
        """
        return (
            self.C
            + self.Mn / 6.0
            + (self.Cr + self.Mo + self.V) / 5.0
            + (self.Ni + self.Cu) / 15.0
        )

    def alloying_addition_needed(self, target: "AlloyComposition", heat_mass_t: float
                                  ) -> Dict[str, float]:
        """Mass (kg) of each element that must be added to move this heat's
        chemistry toward `target`, via simple linear mass balance
        (ignores recovery losses — see processes.eaf for recovery-adjusted
        version).
        """
        additions = {}
        for el, tgt in target.as_dict().items():
            current = getattr(self, el, 0.0)
            delta_wt_pct = tgt - current
            if delta_wt_pct > 1e-6:
                additions[el] = delta_wt_pct / 100.0 * heat_mass_t * 1000.0  # kg
        return additions


@dataclass
class SlagChemistry:
    """Basic-oxygen/EAF slag composition, wt%, used for basicity and
    dephosphorization/desulfurization capacity estimates.
    """

    CaO: float = 45.0
    SiO2: float = 15.0
    MgO: float = 8.0
    FeO: float = 20.0
    Al2O3: float = 5.0
    MnO: float = 4.0
    P2O5: float = 1.0

    def basicity_b2(self) -> float:
        """B2 = %CaO / %SiO2. Typical BOF operating range ~2.5-4.0."""
        return self.CaO / max(self.SiO2, 1e-6)

    def basicity_b4(self) -> float:
        """B4 = (%CaO + %MgO) / (%SiO2 + %Al2O3), a more complete basicity
        index accounting for amphoteric alumina.
        """
        return (self.CaO + self.MgO) / max(self.SiO2 + self.Al2O3, 1e-6)

    def dephosphorization_potential(self) -> float:
        """Simplified phosphorus partition ratio Lp = (%P2O5 in slag)/(%P in
        metal) proxy, increasing with basicity and FeO (oxidizing potential),
        after Turkdogan's empirical correlation form:
            log10(Lp) = 0.08*B2 + 0.04*FeO - 2.5  (engineering approximation)
        Returns a dimensionless capacity index (higher = better P removal).
        """
        import math
        log_lp = 0.08 * self.basicity_b2() * 10 + 0.04 * self.FeO - 2.5
        return 10 ** (log_lp / 10.0)


def oxygen_for_decarburization(hot_metal_mass_t: float, carbon_start_pct: float,
                                 carbon_target_pct: float,
                                 oxygen_efficiency: float = 0.90) -> float:
    """Stoichiometric O2 (Nm^3) required to oxidize carbon from
    `carbon_start_pct` to `carbon_target_pct` in a BOF blow.

    Reaction (dominant at high %C): C + 1/2 O2 -> CO
      Molar mass C = 12.011 g/mol, 1 mol O2 -> 22.414 Nm^3/kmol
      => 1 kg C removed requires (0.5 * 22.414 / 12.011) = 0.933 Nm3 O2 (to CO)

    `oxygen_efficiency` accounts for post-combustion losses / oxygen not
    reacting with carbon (going to Fe, Mn, Si oxidation instead), typically
    0.85-0.95 in a well-run BOF blow.
    """
    delta_c_pct = max(0.0, carbon_start_pct - carbon_target_pct)
    carbon_removed_kg = delta_c_pct / 100.0 * hot_metal_mass_t * 1000.0
    o2_per_kg_c = 0.5 * 22.414 / 12.011  # Nm3 O2 per kg C -> CO
    return carbon_removed_kg * o2_per_kg_c / max(oxygen_efficiency, 1e-6)


def ladle_alloy_trim(current: AlloyComposition, target: AlloyComposition,
                      alloying_efficiency: float = 0.94,
                      impurity_removal_efficiency: float = 0.35,
                      process_noise_pct: float = 0.05) -> AlloyComposition:
    """Ladle metallurgy / alloy-balancing station: represents the ladle
    furnace + wire-feed alloy additions that trim BOF/EAF tap chemistry
    onto the target grade before casting (production-flow step 7,
    "alloy balancing").

    Alloying elements (Mn, Si, Cr, Ni, Mo, V, Nb, Ti, W, B, Al) can be
    added fairly precisely -- modelled as closing most of the gap to
    target, scaled by `alloying_efficiency`, plus small residual process
    noise. Carbon is trimmed the same way (recarburization/decarburization
    in the ladle/AOD is routine for hitting a carbon-grade target).

    P and S are a *not-to-exceed* spec ceiling, not a value to aim for:
    ladle refining/desulfurization can only pull excess impurity down
    toward that ceiling (at the much lower `impurity_removal_efficiency`,
    since you can't "add" your way to lower P or S) and is left untouched
    if it's already under the limit -- pushing it up toward the ceiling
    from below would be backwards.
    """
    import random

    impurity_elements = {"P", "S"}
    result = AlloyComposition(**current.as_dict())
    for el, tgt in target.as_dict().items():
        cur = getattr(current, el, 0.0)
        if el in impurity_elements:
            trimmed = cur - max(0.0, cur - tgt) * impurity_removal_efficiency
        else:
            gap = tgt - cur
            trimmed = cur + gap * alloying_efficiency
        trimmed *= 1.0 + random.gauss(0, process_noise_pct)
        setattr(result, el, max(0.0, trimmed))
    return result


def blast_furnace_reducing_gas_demand(hot_metal_mass_t: float,
                                       ore_fe2o3_fraction: float = 0.95) -> float:
    """Approximate CO (Nm^3) needed for indirect reduction of hematite to
    iron in the blast furnace shaft:
        Fe2O3 + 3CO -> 2Fe + 3CO2
    Molar mass Fe2O3 = 159.69 g/mol, 2 mol Fe (111.7 g) per mol Fe2O3.
    """
    fe_mass_kg = hot_metal_mass_t * 1000.0 * 0.94  # ~94% Fe in hot metal
    fe2o3_needed_kg = fe_mass_kg / (2 * 55.845) * 159.69 / max(ore_fe2o3_fraction, 1e-6)
    mol_fe2o3 = fe2o3_needed_kg * 1000.0 / 159.69
    mol_co = 3 * mol_fe2o3
    return mol_co * 22.414 / 1000.0  # Nm3
