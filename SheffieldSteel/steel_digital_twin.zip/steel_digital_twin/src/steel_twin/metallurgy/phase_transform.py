"""
Phase transformation kinetics.

Implements the Johnson-Mehl-Avrami-Kolmogorov (JMAK) isothermal
transformation model, used to predict the austenite -> ferrite/pearlite/
bainite/martensite fraction transformed as a function of time and
temperature, and a simplified continuous-cooling-transformation (CCT)
lookup that maps cooling rate to resulting microstructure and effective
grain size (feeding `metallurgy.properties`).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict


def jmak_fraction_transformed(time_s: float, k: float, n: float) -> float:
    """JMAK equation: X(t) = 1 - exp(-k * t^n)

    X: fraction transformed (0-1)
    k: rate constant (temperature dependent, s^-n)
    n: Avrami exponent (nucleation/growth mechanism dependent, typically 1-4)
    """
    if time_s <= 0:
        return 0.0
    return 1.0 - math.exp(-k * (time_s ** n))


def jmak_rate_constant(temperature_c: float, activation_energy_j_per_mol: float = 150_000.0,
                        k0: float = 1.0e8) -> float:
    """Arrhenius temperature dependence of the JMAK rate constant:
        k(T) = k0 * exp(-Q / (R*T))
    with R = 8.314 J/(mol K), T in Kelvin.
    """
    r = 8.314
    t_kelvin = temperature_c + 273.15
    return k0 * math.exp(-activation_energy_j_per_mol / (r * t_kelvin))


@dataclass
class Microstructure:
    phase: str                  # dominant phase
    grain_size_mm: float
    martensite_fraction: float
    bainite_fraction: float
    pearlite_fraction: float
    ferrite_fraction: float


# Simplified CCT thresholds (deg C/s) for a generic low/medium alloy steel.
# Real plants calibrate this per-grade from dilatometry; these are
# representative engineering defaults.
_CCT_MARTENSITE_RATE = 20.0   # >= this cooling rate -> fully martensitic
_CCT_BAINITE_RATE = 5.0
_CCT_PEARLITE_RATE = 1.0
# below _CCT_PEARLITE_RATE -> coarse ferrite/pearlite


def cooling_rate_to_microstructure(cooling_rate_c_per_s: float,
                                    austenite_grain_size_mm: float = 0.05,
                                    carbon_pct: float = 0.2) -> Microstructure:
    """Map a cooling rate through the transformation range to a resulting
    microstructure using CCT-style thresholds, with final grain size
    refined by cooling rate (rapid cooling suppresses grain growth,
    consistent with the physical picture behind Hall-Petch strengthening).
    """
    r = max(0.0, cooling_rate_c_per_s)

    if r >= _CCT_MARTENSITE_RATE:
        martensite, bainite, pearlite, ferrite = 0.95, 0.05, 0.0, 0.0
        phase = "martensite"
    elif r >= _CCT_BAINITE_RATE:
        frac = (r - _CCT_BAINITE_RATE) / (_CCT_MARTENSITE_RATE - _CCT_BAINITE_RATE)
        martensite = 0.6 * frac
        bainite = 0.9 - 0.5 * frac
        pearlite = 1.0 - martensite - bainite
        ferrite = 0.0
        phase = "bainite"
    elif r >= _CCT_PEARLITE_RATE:
        frac = (r - _CCT_PEARLITE_RATE) / (_CCT_BAINITE_RATE - _CCT_PEARLITE_RATE)
        bainite = 0.3 * frac
        pearlite = min(0.95, carbon_pct / 0.8) * (0.5 + 0.5 * frac)
        ferrite = 1.0 - bainite - pearlite
        martensite = 0.0
        phase = "fine pearlite + ferrite"
    else:
        martensite, bainite = 0.0, 0.0
        pearlite = min(0.95, carbon_pct / 0.8)
        ferrite = 1.0 - pearlite
        phase = "coarse ferrite + pearlite"

    # Grain refinement with cooling rate: d ~ d0 / (1 + log1p(rate))
    grain_size = austenite_grain_size_mm / (1.0 + 0.35 * math.log1p(r))

    return Microstructure(
        phase=phase,
        grain_size_mm=round(max(grain_size, 0.002), 4),
        martensite_fraction=round(max(0.0, martensite), 3),
        bainite_fraction=round(max(0.0, bainite), 3),
        pearlite_fraction=round(max(0.0, pearlite), 3),
        ferrite_fraction=round(max(0.0, ferrite), 3),
    )
