"""
Base class for every unit process in the production flow (raw materials ->
coke -> blast furnace -> steel conversion -> casting -> rolling -> finishing
-> shipping).

Each `ProcessUnit`:
  * consumes resources from upstream buffers
  * requires energy
  * generates waste/emissions
  * produces output that becomes the next stage's input (creating
    operational constraints/backpressure when downstream is blocked)
  * publishes events onto the shared EventBus so other modules (economics,
    maintenance, ML) can react without tight coupling.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus


@dataclass
class Buffer:
    """A finite-capacity material buffer between two process stages
    (stockpile, ladle queue, coil yard...). Models starvation/blocking."""

    name: str
    capacity: float
    level: float = 0.0
    unit: str = "tonnes"

    def add(self, amount: float) -> float:
        """Add material; returns amount actually accepted (rest is spilled/
        rejected, representing a full-buffer blocking condition)."""
        accepted = min(amount, self.capacity - self.level)
        accepted = max(0.0, accepted)
        self.level += accepted
        return accepted

    def take(self, amount: float) -> float:
        """Remove material; returns amount actually available (starvation
        if less than requested)."""
        available = min(amount, self.level)
        available = max(0.0, available)
        self.level -= available
        return available

    @property
    def fill_pct(self) -> float:
        return 0.0 if self.capacity <= 0 else 100.0 * self.level / self.capacity

    @property
    def available_capacity(self) -> float:
        """Headroom before this buffer is full -- upstream stages should
        cap their production to this (see `ProcessUnit` subclasses) so a
        blocked downstream stage actually throttles output rather than
        silently discarding whatever `add()` can't accept.
        """
        return max(0.0, self.capacity - self.level)


class ProcessUnit:
    """Base for a single production stage."""

    def __init__(self, name: str, equipment: Equipment, bus: EventBus):
        self.name = name
        self.equipment = equipment
        self.bus = bus
        self.waste_generated_kg: float = 0.0
        self.energy_consumed_kwh: float = 0.0
        self.output_this_tick: float = 0.0
        self.emissions_co2_kg: float = 0.0

    def publish(self, suffix: str, payload: Dict, severity: str = "info") -> None:
        self.bus.publish(f"process.{self.name}.{suffix}", payload,
                          source=self.name, severity=severity)

    def tick(self, dt_hours: float) -> Dict:  # pragma: no cover - abstract
        raise NotImplementedError

    def oee(self) -> float:
        """Overall Equipment Effectiveness proxy = availability x
        performance, purely from current equipment health/status."""
        avail = 1.0 if self.equipment.status == EquipmentStatus.RUNNING else 0.0
        perf = self.equipment.availability_derate
        return avail * perf
