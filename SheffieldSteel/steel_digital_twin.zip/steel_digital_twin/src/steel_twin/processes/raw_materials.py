"""Raw material arrival and ore processing (sintering/pelletizing +
crushing/screening) -- stage 1-2 of the production flow.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from .base_process import Buffer, ProcessUnit


class RawMaterialsYard(ProcessUnit):
    """Receives bulk ore/coal/limestone deliveries (rail/port, see
    logistics module) into stockpiles, subject to weather-driven delivery
    variance.
    """

    def __init__(self, bus: EventBus, ore_capacity_t: float = 500_000,
                 coal_capacity_t: float = 200_000, limestone_capacity_t: float = 100_000):
        equipment = Equipment(name="raw_materials_yard", nameplate_capacity=20_000)
        super().__init__("raw_materials_yard", equipment, bus)
        self.ore = Buffer("iron_ore", ore_capacity_t, level=ore_capacity_t * 0.6)
        self.coal = Buffer("coking_coal", coal_capacity_t, level=coal_capacity_t * 0.6)
        self.limestone = Buffer("limestone", limestone_capacity_t, level=limestone_capacity_t * 0.6)

    def receive_delivery(self, material: str, amount_t: float) -> float:
        buf = {"ore": self.ore, "coal": self.coal, "limestone": self.limestone}[material]
        accepted = buf.add(amount_t)
        if accepted < amount_t:
            self.publish("stockpile_full", {"material": material, "rejected_t": amount_t - accepted},
                         severity="warning")
        return accepted

    def tick(self, dt_hours: float) -> dict:
        self.equipment.status = EquipmentStatus.RUNNING
        return {
            "ore_pct": round(self.ore.fill_pct, 1),
            "coal_pct": round(self.coal.fill_pct, 1),
            "limestone_pct": round(self.limestone.fill_pct, 1),
        }


class OreProcessingPlant(ProcessUnit):
    """Crushing, screening, and sintering/pelletizing of raw ore into
    blast-furnace-ready sinter/pellets.
    """

    def __init__(self, bus: EventBus, yard: RawMaterialsYard,
                 nameplate_t_per_h: float = 500.0):
        equipment = Equipment(name="ore_processing", nameplate_capacity=nameplate_t_per_h)
        super().__init__("ore_processing", equipment, bus)
        self.yard = yard
        self.sinter_buffer = Buffer("sinter", capacity=nameplate_t_per_h * 24, level=0.0)
        # energy intensity, kWh/tonne sinter (typical industrial figure)
        self.energy_intensity_kwh_per_t = 45.0
        self.yield_fraction = 0.96  # mass loss to fines/dust

    def tick(self, dt_hours: float) -> dict:
        target = self.equipment.effective_capacity * dt_hours
        # cap production so it never exceeds the downstream sinter buffer's
        # headroom -- a full buffer throttles this stage (backpressure)
        # rather than silently discarding the excess.
        max_by_downstream = self.sinter_buffer.available_capacity / self.yield_fraction
        effective_target = min(target, max_by_downstream)

        ore_used = self.yard.ore.take(effective_target)
        sinter_out = ore_used * self.yield_fraction
        accepted = self.sinter_buffer.add(sinter_out)
        starved = ore_used < effective_target * 0.99
        blocked = (not starved) and effective_target < target * 0.99
        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        self.energy_consumed_kwh = ore_used * self.energy_intensity_kwh_per_t
        self.waste_generated_kg = (ore_used - sinter_out) * 1000.0
        self.output_this_tick = accepted
        # CO2 from fuel used in sintering, ~0.2 t CO2 / t sinter (typical)
        self.emissions_co2_kg = sinter_out * 200.0

        if starved:
            self.publish("starved", {"ore_available_t": self.yard.ore.level}, severity="warning")
        if blocked:
            self.publish("blocked", {"sinter_buffer_pct": self.sinter_buffer.fill_pct}, severity="warning")

        return {
            "sinter_produced_t": round(sinter_out, 2),
            "sinter_buffer_pct": round(self.sinter_buffer.fill_pct, 1),
            "energy_kwh": round(self.energy_consumed_kwh, 1),
            "status": self.equipment.status.value,
        }
