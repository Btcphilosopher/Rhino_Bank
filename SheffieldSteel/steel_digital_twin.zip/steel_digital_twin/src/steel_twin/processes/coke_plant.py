"""Coke production -- carbonises coking coal in coke ovens to produce
metallurgical coke (the blast furnace's primary reductant/fuel) plus
coke-oven gas, tar and other byproducts.
"""
from __future__ import annotations

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from .base_process import Buffer, ProcessUnit
from .raw_materials import RawMaterialsYard


class CokePlant(ProcessUnit):
    # Coking yield: ~0.70-0.75 t coke per t coal, remainder becomes gas/tar/water
    COKE_YIELD = 0.72
    COG_YIELD_NM3_PER_T_COAL = 320.0  # coke oven gas, Nm3/t coal charged
    OVEN_CYCLE_HOURS = 18.0           # typical coking time per push

    def __init__(self, bus: EventBus, yard: RawMaterialsYard,
                 nameplate_t_per_h: float = 150.0, n_ovens: int = 60):
        equipment = Equipment(name="coke_plant", nameplate_capacity=nameplate_t_per_h)
        super().__init__("coke_plant", equipment, bus)
        self.yard = yard
        self.n_ovens = n_ovens
        self.coke_buffer = Buffer("coke", capacity=nameplate_t_per_h * 48, level=nameplate_t_per_h * 24)
        self.coke_oven_gas_nm3_this_tick = 0.0
        self.refractory_wear = 0.0  # 0-1, oven brickwork wear from thermal cycling

    def tick(self, dt_hours: float) -> dict:
        target = self.equipment.effective_capacity * dt_hours
        max_by_downstream = self.coke_buffer.available_capacity / self.COKE_YIELD
        effective_target = min(target, max_by_downstream)

        coal_used = self.yard.coal.take(effective_target)
        starved = coal_used < effective_target * 0.99
        blocked = (not starved) and effective_target < target * 0.99
        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        coke_out = coal_used * self.COKE_YIELD
        accepted = self.coke_buffer.add(coke_out)
        self.coke_oven_gas_nm3_this_tick = coal_used * self.COG_YIELD_NM3_PER_T_COAL

        # refractory wear accumulates slowly with thermal cycling, accelerated
        # by running hotter than target (proxy: derated equipment => more thermal stress)
        wear_rate_per_hour = 1.0 / (25 * 365 * 24)  # ~25 year campaign life
        self.refractory_wear = min(1.0, self.refractory_wear + wear_rate_per_hour * dt_hours *
                                    (1.3 if self.equipment.health_index < 0.7 else 1.0))

        self.energy_consumed_kwh = coal_used * 15.0  # electrical aux load, kWh/t
        self.waste_generated_kg = (coal_used - coke_out) * 1000.0 * 0.15  # tar/sludge fraction
        self.output_this_tick = accepted
        # CO2 from coking + underfiring, ~0.5-0.6 t CO2/t coke (process + combustion)
        self.emissions_co2_kg = coke_out * 550.0

        if starved:
            self.publish("starved", {"coal_available_t": self.yard.coal.level}, severity="warning")

        return {
            "coke_produced_t": round(coke_out, 2),
            "coke_buffer_pct": round(self.coke_buffer.fill_pct, 1),
            "coke_oven_gas_nm3": round(self.coke_oven_gas_nm3_this_tick, 1),
            "refractory_wear_pct": round(self.refractory_wear * 100, 3),
            "status": self.equipment.status.value,
        }
