"""
Rolling mill simulation: hot/cold rolls slabs/billets into finished
sections (plate, coil, bar) tracking roll-force, mill speed, gauge
control, and fatigue accumulation in the work rolls.
"""
from __future__ import annotations

import math
import random

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from ..metallurgy.properties import MechanicalProperties, predict_mechanical_properties
from ..metallurgy.chemistry import AlloyComposition
from .base_process import Buffer, ProcessUnit


class RollingMill(ProcessUnit):
    YIELD_FRACTION = 0.965
    TARGET_GAUGE_MM = 3.0
    ROLL_FATIGUE_LIFE_CYCLES = 2_000_000

    def __init__(self, bus: EventBus, slab_source: Buffer, name: str = "hot_strip_mill",
                 nameplate_t_per_h: float = 300.0, mill_speed_m_per_min: float = 900.0):
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.slab_source = slab_source
        self.product_buffer = Buffer(f"{name}_coil", capacity=nameplate_t_per_h * 24, level=0.0)
        self.mill_speed_m_per_min = mill_speed_m_per_min
        self.roll_force_kn = 0.0
        self.roll_fatigue_cycles = 0.0
        self.gauge_deviation_mm = 0.0

    def tick(self, dt_hours: float, chemistry: AlloyComposition | None = None,
              grain_size_mm: float = 0.02) -> dict:
        target = self.equipment.effective_capacity * dt_hours
        max_by_downstream = self.product_buffer.available_capacity / self.YIELD_FRACTION
        effective_target = min(target, max_by_downstream)

        slab_in = self.slab_source.take(effective_target)
        starved = slab_in < effective_target * 0.95
        blocked = (not starved) and effective_target < target * 0.99

        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        product_out = slab_in * self.YIELD_FRACTION
        accepted = self.product_buffer.add(product_out)

        # Roll force model (simplified Sims' rolling load equation form):
        #   F = Lp * w * k_mean   where Lp = contact length, k_mean = mean
        # flow stress (increases with alloy strength / lower temperature).
        chem = chemistry or AlloyComposition(C=0.15)
        props: MechanicalProperties = predict_mechanical_properties(
            chem, grain_size_mm=grain_size_mm, cooling_rate_c_per_s=5.0,
        )
        mean_flow_stress_mpa = 0.6 * props.yield_strength_mpa  # hot strength << cold yield
        contact_length_m = 0.05
        width_m = 1.6
        self.roll_force_kn = mean_flow_stress_mpa * 1000.0 * contact_length_m * width_m / 1000.0

        # roll fatigue accumulates with load cycles (bites); simplistic
        # Miner's-rule-style linear damage accrual scaled by force.
        cycles_this_tick = (self.mill_speed_m_per_min * dt_hours * 60) / 25.0  # ~25m/bite proxy
        damage_scale = self.roll_force_kn / 6000.0
        self.roll_fatigue_cycles += cycles_this_tick * damage_scale
        fatigue_fraction = min(1.0, self.roll_fatigue_cycles / self.ROLL_FATIGUE_LIFE_CYCLES)
        self.equipment.health_index = max(0.05, 1.0 - fatigue_fraction)

        # gauge control deviation: PID-controlled in practice; residual noise
        # grows as roll wear (health) degrades.
        self.gauge_deviation_mm = random.gauss(0, 0.02 + (1 - self.equipment.health_index) * 0.15)

        self.energy_consumed_kwh = product_out * 130.0  # reheat + rolling drive energy, kWh/t
        self.waste_generated_kg = (slab_in - product_out) * 1000.0  # crop/trim scrap (recycled)
        self.output_this_tick = accepted
        self.emissions_co2_kg = product_out * 60.0

        if abs(self.gauge_deviation_mm) > 0.3:
            self.publish("gauge_out_of_spec", {"deviation_mm": round(self.gauge_deviation_mm, 3)},
                         severity="warning")
        if starved:
            self.publish("starved", {"slab_available_t": self.slab_source.level}, severity="warning")

        return {
            "product_out_t": round(product_out, 2),
            "product_buffer_t": round(self.product_buffer.level, 1),
            "mill_speed_m_per_min": self.mill_speed_m_per_min,
            "roll_force_kn": round(self.roll_force_kn, 1),
            "roll_fatigue_pct": round(fatigue_fraction * 100, 2),
            "gauge_deviation_mm": round(self.gauge_deviation_mm, 3),
            "tensile_strength_mpa": props.tensile_strength_mpa,
            "status": self.equipment.status.value,
        }
