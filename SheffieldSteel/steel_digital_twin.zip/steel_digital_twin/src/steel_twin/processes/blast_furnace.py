"""
Blast furnace simulation: charges sinter/coke/limestone, blows hot air
(with oxygen enrichment), and produces molten hot metal (pig iron) + slag +
blast furnace gas, with a thermal state model driving hearth temperature
and refractory wear.
"""
from __future__ import annotations

import math
import random

from ..core.entities import Equipment, EquipmentStatus, Sensor
from ..core.event_bus import EventBus
from ..metallurgy.chemistry import blast_furnace_reducing_gas_demand
from ..thermodynamics.combustion import combust_fuel
from .base_process import Buffer, ProcessUnit
from .coke_plant import CokePlant
from .raw_materials import RawMaterialsYard


class BlastFurnace(ProcessUnit):
    """A single blast furnace campaign.

    Mass balance (simplified, per tonne hot metal):
        1.55 t sinter/ore, 0.38 t coke, 0.25 t limestone -> 1.0 t hot metal
        + ~0.3 t slag + ~1500 Nm3 blast furnace gas (BFG)
    """

    COKE_RATE_T_PER_T_HM = 0.38          # coke consumption rate
    ORE_RATE_T_PER_T_HM = 1.55
    FLUX_RATE_T_PER_T_HM = 0.25
    SLAG_RATE_T_PER_T_HM = 0.30
    BFG_NM3_PER_T_HM = 1500.0
    TARGET_HEARTH_TEMP_C = 1500.0
    HOT_METAL_CARBON_PCT = 4.5            # typical hot metal carbon saturation

    def __init__(self, bus: EventBus, yard: RawMaterialsYard, coke_plant: CokePlant,
                 name: str = "blast_furnace_1", nameplate_t_per_day: float = 8000.0):
        nameplate_t_per_h = nameplate_t_per_day / 24.0
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.yard = yard
        self.coke_plant = coke_plant
        self.hot_metal_buffer = Buffer(f"{name}_hot_metal", capacity=nameplate_t_per_h * 6, level=0.0)
        self.hearth_temp_c = self.TARGET_HEARTH_TEMP_C
        self.oxygen_enrichment_pct = 3.0   # % O2 enrichment above ambient air (21%)
        self.hearth_temp_sensor = Sensor("hearth_temp", "C", noise_std=3.0, drift_per_hour=0.02)
        self.refractory_wear = 0.0
        self.campaign_days = 0.0

    def tick(self, dt_hours: float) -> dict:
        target_hm = self.equipment.effective_capacity * dt_hours
        # cap by downstream hot-metal buffer headroom before drawing any
        # upstream resource, so a full buffer throttles the furnace rather
        # than burning coke/ore that then has nowhere to go.
        target_hm = min(target_hm, self.hot_metal_buffer.available_capacity)

        coke_needed = target_hm * self.COKE_RATE_T_PER_T_HM
        ore_needed = target_hm * self.ORE_RATE_T_PER_T_HM
        flux_needed = target_hm * self.FLUX_RATE_T_PER_T_HM

        coke_avail = self.coke_plant.coke_buffer.take(coke_needed)
        ore_avail = self.yard.ore.take(ore_needed) if hasattr(self.yard, "ore") else ore_needed
        flux_avail = self.yard.limestone.take(flux_needed)

        limiting_ratio = min(
            coke_avail / max(coke_needed, 1e-6),
            ore_avail / max(ore_needed, 1e-6),
            flux_avail / max(flux_needed, 1e-6),
            1.0,
        )
        hot_metal_produced = target_hm * limiting_ratio
        starved = limiting_ratio < 0.99
        blocked = (not starved) and target_hm < (self.equipment.effective_capacity * dt_hours) * 0.99

        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)
        self.campaign_days += dt_hours / 24.0

        # -- thermal model: hearth temperature relaxes toward a target driven by
        # coke rate & oxygen enrichment, with process noise, feeding a simple
        # first-order thermal lag (represents huge thermal mass of the furnace).
        coke_rate_actual = coke_avail / max(hot_metal_produced, 1e-6) if hot_metal_produced > 0 else self.COKE_RATE_T_PER_T_HM
        target_temp = self.TARGET_HEARTH_TEMP_C + (coke_rate_actual - self.COKE_RATE_T_PER_T_HM) * 400 \
            + self.oxygen_enrichment_pct * 15
        tau_hours = 4.0  # thermal time constant of the hearth
        self.hearth_temp_c += (target_temp - self.hearth_temp_c) * (1 - math.exp(-dt_hours / tau_hours))
        self.hearth_temp_c += random.gauss(0, 1.5)

        measured_temp = self.hearth_temp_sensor.read(self.hearth_temp_c, dt_hours)

        slag_out = hot_metal_produced * self.SLAG_RATE_T_PER_T_HM
        bfg_out_nm3 = hot_metal_produced * self.BFG_NM3_PER_T_HM
        accepted_hm = self.hot_metal_buffer.add(hot_metal_produced)

        # refractory wear accelerates with hearth overheating and campaign age
        overheat_factor = max(0.0, (self.hearth_temp_c - self.TARGET_HEARTH_TEMP_C) / 200.0)
        wear_rate_per_day = 1.0 / (15 * 365)  # ~15yr campaign life nominal
        self.refractory_wear = min(1.0, self.refractory_wear +
                                    wear_rate_per_day * (dt_hours / 24.0) * (1 + overheat_factor))
        self.equipment.health_index = max(0.05, 1.0 - self.refractory_wear)

        self.energy_consumed_kwh = hot_metal_produced * 30.0  # blowers/aux electrical, kWh/t
        self.waste_generated_kg = slag_out * 1000.0
        self.output_this_tick = accepted_hm
        # Process CO2, ~1.6-1.8 t CO2/t hot metal for a coke-based BF route
        self.emissions_co2_kg = hot_metal_produced * 1700.0

        if measured_temp is not None and (measured_temp > 1600 or measured_temp < 1400):
            self.publish("hearth_temp_excursion", {"temp_c": measured_temp}, severity="alarm")
        if starved:
            self.publish("starved", {
                "coke_ratio": round(coke_avail / max(coke_needed, 1e-6), 2),
                "ore_ratio": round(ore_avail / max(ore_needed, 1e-6), 2),
            }, severity="warning")

        return {
            "hot_metal_produced_t": round(hot_metal_produced, 2),
            "hot_metal_buffer_t": round(self.hot_metal_buffer.level, 1),
            "hearth_temp_c": round(measured_temp, 1) if measured_temp else None,
            "slag_produced_t": round(slag_out, 2),
            "bfg_nm3": round(bfg_out_nm3, 1),
            "refractory_wear_pct": round(self.refractory_wear * 100, 3),
            "campaign_days": round(self.campaign_days, 1),
            "status": self.equipment.status.value,
            "hot_metal_carbon_pct": self.HOT_METAL_CARBON_PCT,
        }
