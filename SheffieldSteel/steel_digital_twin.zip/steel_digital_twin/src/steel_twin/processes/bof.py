"""
Basic Oxygen Furnace (BOF) simulation: converts blast-furnace hot metal
(+ scrap) into steel by blowing high-purity oxygen through a lance to
decarburize and refine the melt.
"""
from __future__ import annotations

import random

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from ..metallurgy.chemistry import AlloyComposition, SlagChemistry, oxygen_for_decarburization
from .base_process import Buffer, ProcessUnit
from .blast_furnace import BlastFurnace


class BasicOxygenFurnace(ProcessUnit):
    HEAT_SIZE_T = 250.0            # typical BOF heat/tap size
    BLOW_TIME_MIN = 18.0           # oxygen blow duration
    SCRAP_CHARGE_RATIO = 0.18      # scrap as fraction of heat mass
    TARGET_CARBON_PCT = 0.05       # tap carbon target before ladle alloying
    YIELD_FRACTION = 0.895         # steel yield vs. total charge (losses to slag/fume)

    def __init__(self, bus: EventBus, blast_furnace: BlastFurnace, name: str = "bof_1",
                 heats_per_day: float = 30.0):
        nameplate_t_per_h = (heats_per_day * self.HEAT_SIZE_T) / 24.0
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.bf = blast_furnace
        self.liquid_steel_buffer = Buffer(f"{name}_steel", capacity=nameplate_t_per_h * 4, level=0.0)
        self.scrap_buffer = Buffer(f"{name}_scrap", capacity=5000, level=2000)
        self.heats_completed = 0
        self.last_chemistry = AlloyComposition(C=self.TARGET_CARBON_PCT)
        self.last_slag = SlagChemistry()

    def tick(self, dt_hours: float) -> dict:
        heat_capacity_this_tick = self.equipment.effective_capacity * dt_hours
        # cap by downstream liquid-steel buffer headroom (the caster's
        # intake rate) before charging any hot metal/scrap.
        max_charge_by_downstream = self.liquid_steel_buffer.available_capacity / self.YIELD_FRACTION
        heat_capacity_this_tick = min(heat_capacity_this_tick, max_charge_by_downstream)

        n_heats_possible = heat_capacity_this_tick / self.HEAT_SIZE_T
        hot_metal_needed = n_heats_possible * self.HEAT_SIZE_T * (1 - self.SCRAP_CHARGE_RATIO)
        scrap_needed = n_heats_possible * self.HEAT_SIZE_T * self.SCRAP_CHARGE_RATIO

        hot_metal = self.bf.hot_metal_buffer.take(hot_metal_needed)
        scrap = self.scrap_buffer.take(scrap_needed)

        limiting_ratio = min(
            hot_metal / max(hot_metal_needed, 1e-6),
            scrap / max(scrap_needed, 1e-6),
            1.0,
        )
        charge_mass = (hot_metal + scrap)
        starved = limiting_ratio < 0.95
        nominal_capacity = self.equipment.effective_capacity * dt_hours
        blocked = (not starved) and heat_capacity_this_tick < nominal_capacity * 0.99

        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        steel_out = charge_mass * self.YIELD_FRACTION
        accepted = self.liquid_steel_buffer.add(steel_out)

        # oxygen consumption from stoichiometric decarburization
        o2_nm3 = oxygen_for_decarburization(
            hot_metal_mass_t=hot_metal, carbon_start_pct=4.5,
            carbon_target_pct=self.TARGET_CARBON_PCT,
        ) if hot_metal > 0 else 0.0

        # simple end-point chemistry model with process noise around target
        carbon_actual = max(0.01, self.TARGET_CARBON_PCT + random.gauss(0, 0.01))
        self.last_chemistry = AlloyComposition(
            C=carbon_actual, Mn=0.15 + random.gauss(0, 0.02),
            Si=0.02, P=0.015 + random.gauss(0, 0.003), S=0.02 + random.gauss(0, 0.004),
        )
        self.last_slag = SlagChemistry(
            CaO=45 + random.gauss(0, 1.5), SiO2=14 + random.gauss(0, 1.0),
            FeO=18 + random.gauss(0, 2.0),
        )

        n_heats_this_tick = steel_out / self.HEAT_SIZE_T
        self.heats_completed += n_heats_this_tick

        self.energy_consumed_kwh = charge_mass * 12.0  # aux electrical/oxygen compression
        slag_generated = charge_mass * 0.12
        self.waste_generated_kg = slag_generated * 1000.0
        self.output_this_tick = accepted
        # process CO2 mainly from lime calcination + minor combustion, ~0.15-0.2 t/t
        self.emissions_co2_kg = steel_out * 180.0

        if starved:
            self.publish("starved", {"hot_metal_ratio": round(limiting_ratio, 2)}, severity="warning")

        return {
            "steel_produced_t": round(steel_out, 2),
            "steel_buffer_t": round(self.liquid_steel_buffer.level, 1),
            "heats_completed": round(self.heats_completed, 1),
            "oxygen_used_nm3": round(o2_nm3, 1),
            "tap_carbon_pct": round(carbon_actual, 3),
            "slag_basicity_b2": round(self.last_slag.basicity_b2(), 2),
            "status": self.equipment.status.value,
        }
