"""
Continuous casting simulation: casts liquid steel into slabs/billets/blooms
through a water-cooled mould and spray-cooling secondary zone, tracking
solidification and the resulting cooling-rate-driven microstructure.
"""
from __future__ import annotations

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from ..metallurgy.chemistry import AlloyComposition
from ..metallurgy.phase_transform import cooling_rate_to_microstructure
from ..thermodynamics.heat_transfer import lumped_cooling_curve, average_cooling_rate_c_per_s
from .base_process import Buffer, ProcessUnit


class ContinuousCaster(ProcessUnit):
    CASTING_SPEED_M_PER_MIN = 1.4
    SLAB_CROSS_SECTION_M2 = 0.25 * 1.6   # thickness x width
    STEEL_DENSITY_T_PER_M3 = 7.85
    LIQUIDUS_TEMP_C = 1520.0
    YIELD_FRACTION = 0.97               # losses to crop ends/scrap

    def __init__(self, bus: EventBus, steel_source: Buffer, name: str = "caster_1",
                 nameplate_t_per_h: float = 220.0):
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.steel_source = steel_source
        self.slab_buffer = Buffer(f"{name}_slab", capacity=nameplate_t_per_h * 8, level=0.0)
        self.breakout_risk = 0.0     # 0-1, risk of a shell breakout (mould level instability)
        self.last_cooling_rate_c_per_s = 5.0

    def tick(self, dt_hours: float, chemistry: AlloyComposition | None = None) -> dict:
        target = self.equipment.effective_capacity * dt_hours
        max_by_downstream = self.slab_buffer.available_capacity / self.YIELD_FRACTION
        effective_target = min(target, max_by_downstream)

        liquid_steel = self.steel_source.take(effective_target)
        starved = liquid_steel < effective_target * 0.95
        blocked = (not starved) and effective_target < target * 0.99

        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        cast_mass = liquid_steel * self.YIELD_FRACTION
        accepted = self.slab_buffer.add(cast_mass)

        # Solidification thermal model: lumped-capacitance cooling of a slab
        # segment from liquidus down through the transformation window,
        # driven by mould+spray heat extraction (h effectively very high in
        # secondary cooling relative to still air).
        segment_mass_kg = 5000.0  # representative slab segment
        surface_area_m2 = 8.0
        cp_steel = 680.0  # J/(kg K), typical for steel near solidification
        t, temp = lumped_cooling_curve(
            initial_temp_c=self.LIQUIDUS_TEMP_C, ambient_temp_c=25.0,
            mass_kg=segment_mass_kg, specific_heat_j_per_kgK=cp_steel,
            surface_area_m2=surface_area_m2, h_w_per_m2K=350.0, emissivity=0.85,
            duration_s=1800, n_points=60,
        )
        self.last_cooling_rate_c_per_s = average_cooling_rate_c_per_s(t, temp)
        micro = cooling_rate_to_microstructure(
            self.last_cooling_rate_c_per_s,
            carbon_pct=(chemistry.C if chemistry else 0.15),
        )

        # breakout risk rises with casting speed vs. mould heat-extraction
        # capacity (a crude but representative proxy) and equipment health.
        self.breakout_risk = max(0.0, min(1.0,
            0.02 + (1.0 - self.equipment.health_index) * 0.3
            + max(0.0, self.CASTING_SPEED_M_PER_MIN - 1.6) * 0.15
        ))

        self.energy_consumed_kwh = cast_mass * 8.0  # cooling water pumps, hydraulics
        self.waste_generated_kg = (liquid_steel - cast_mass) * 1000.0
        self.output_this_tick = accepted
        self.emissions_co2_kg = cast_mass * 5.0

        if self.breakout_risk > 0.35:
            self.publish("breakout_risk_high", {"risk": round(self.breakout_risk, 3)},
                         severity="alarm")
        if starved:
            self.publish("starved", {"liquid_steel_available_t": self.steel_source.level},
                         severity="warning")

        return {
            "slab_cast_t": round(cast_mass, 2),
            "slab_buffer_t": round(self.slab_buffer.level, 1),
            "cooling_rate_c_per_s": round(self.last_cooling_rate_c_per_s, 2),
            "microstructure_phase": micro.phase,
            "grain_size_mm": micro.grain_size_mm,
            "breakout_risk": round(self.breakout_risk, 3),
            "status": self.equipment.status.value,
        }
