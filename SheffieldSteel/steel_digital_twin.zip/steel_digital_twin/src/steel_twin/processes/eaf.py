"""
Electric Arc Furnace (EAF) simulation: melts scrap (+DRI/pig iron) using
three-phase AC arcs, with a power-vs-melt-rate thermal model and alloy
trim/ladle-refining chemistry adjustment. This is the primary route for
recycled-scrap-based steelmaking (mini-mills).
"""
from __future__ import annotations

import random

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from ..metallurgy.chemistry import AlloyComposition
from .base_process import Buffer, ProcessUnit


class ElectricArcFurnace(ProcessUnit):
    HEAT_SIZE_T = 150.0
    ENERGY_PER_TONNE_KWH = 400.0     # electrical energy intensity, kWh/t liquid steel
    ELECTRODE_CONSUMPTION_KG_PER_T = 1.8
    YIELD_FRACTION = 0.92
    TAP_TO_TAP_MIN = 55.0

    def __init__(self, bus: EventBus, name: str = "eaf_1", heats_per_day: float = 22.0,
                 transformer_mva: float = 120.0):
        nameplate_t_per_h = (heats_per_day * self.HEAT_SIZE_T) / 24.0
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.transformer_mva = transformer_mva
        self.scrap_buffer = Buffer(f"{name}_scrap", capacity=nameplate_t_per_h * 12, level=nameplate_t_per_h * 6)
        self.liquid_steel_buffer = Buffer(f"{name}_steel", capacity=nameplate_t_per_h * 4, level=0.0)
        self.electrode_wear_kg = 0.0
        self.power_demand_mw = 0.0
        self.last_chemistry = AlloyComposition(C=0.08)

    def tick(self, dt_hours: float) -> dict:
        target = self.equipment.effective_capacity * dt_hours
        target = min(target, self.liquid_steel_buffer.available_capacity)

        scrap_needed = target / self.YIELD_FRACTION
        scrap_used = self.scrap_buffer.take(scrap_needed)
        starved = scrap_used < scrap_needed * 0.95
        nominal = self.equipment.effective_capacity * dt_hours
        blocked = (not starved) and target < nominal * 0.99

        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        steel_out = scrap_used * self.YIELD_FRACTION
        accepted = self.liquid_steel_buffer.add(steel_out)

        energy_kwh = steel_out * self.ENERGY_PER_TONNE_KWH
        self.power_demand_mw = (energy_kwh / dt_hours / 1000.0) if dt_hours > 0 else 0.0
        # cap by transformer rating -> if exceeded, derate throughput (power constraint)
        if self.power_demand_mw > self.transformer_mva * 0.92:
            derate = (self.transformer_mva * 0.92) / max(self.power_demand_mw, 1e-6)
            steel_out *= derate
            energy_kwh *= derate
            self.power_demand_mw = self.transformer_mva * 0.92
            self.publish("power_limited", {"requested_mw": self.power_demand_mw / derate},
                         severity="warning")

        electrode_wear = steel_out * self.ELECTRODE_CONSUMPTION_KG_PER_T
        self.electrode_wear_kg += electrode_wear

        # scrap-based EAF steel carries more residual trace elements (Cu, Sn)
        # than BOF hot-metal-based steel -- modelled as slightly elevated Cu.
        self.last_chemistry = AlloyComposition(
            C=0.08 + random.gauss(0, 0.015),
            Mn=0.3 + random.gauss(0, 0.03),
            Cu=0.15 + random.gauss(0, 0.03),
            P=0.02 + random.gauss(0, 0.004),
            S=0.03 + random.gauss(0, 0.005),
        )

        self.energy_consumed_kwh = energy_kwh
        self.waste_generated_kg = steel_out * 120.0  # EAF dust + slag, kg/t
        self.output_this_tick = accepted
        # EAF is far lower carbon than BF-BOF route (mostly grid-electricity indirect)
        self.emissions_co2_kg = steel_out * 100.0

        if starved:
            self.publish("starved", {"scrap_available_t": self.scrap_buffer.level}, severity="warning")

        return {
            "steel_produced_t": round(steel_out, 2),
            "steel_buffer_t": round(self.liquid_steel_buffer.level, 1),
            "power_demand_mw": round(self.power_demand_mw, 1),
            "electrode_wear_kg_cum": round(self.electrode_wear_kg, 1),
            "scrap_buffer_pct": round(self.scrap_buffer.fill_pct, 1),
            "status": self.equipment.status.value,
        }
