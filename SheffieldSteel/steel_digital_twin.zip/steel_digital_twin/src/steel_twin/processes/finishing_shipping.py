"""
Finishing (inspection, cutting-to-length/coiling, surface treatment) and
shipping -- the final production stages before product leaves the plant
into logistics (rail/port).
"""
from __future__ import annotations

import random

from ..core.entities import Equipment, EquipmentStatus
from ..core.event_bus import EventBus
from ..metallurgy.properties import MechanicalProperties, contamination_risk_score
from ..metallurgy.chemistry import AlloyComposition
from ..metallurgy.grades import SteelGrade
from .base_process import Buffer, ProcessUnit


class FinishingLine(ProcessUnit):
    """Surface inspection + finishing; rejects/downgrades product that
    fails quality gates (feeds the ML quality-prediction layer).
    """

    def __init__(self, bus: EventBus, source: Buffer, name: str = "finishing_line",
                 nameplate_t_per_h: float = 280.0):
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.source = source
        self.finished_goods = Buffer(f"{name}_fg", capacity=nameplate_t_per_h * 48, level=0.0)
        self.reject_buffer = Buffer(f"{name}_reject", capacity=nameplate_t_per_h * 10, level=0.0)
        self.defect_rate_pct = 1.5

    def tick(self, dt_hours: float, chemistry: AlloyComposition | None = None,
              grade: SteelGrade | None = None,
              mech_props: MechanicalProperties | None = None) -> dict:
        # quality gate is evaluated on chemistry/mech-props, which don't
        # depend on the throughput volume -- so we can compute the reject
        # fraction first, then size intake so neither the finished-goods
        # nor the reject buffer overflow (backpressure).
        risk = 0.0
        if chemistry and grade:
            risk = contamination_risk_score(chemistry, grade.target_composition,
                                             grade.tolerance_pct)
        spec_fail = False
        if mech_props and grade:
            spec_fail = (mech_props.tensile_strength_mpa < grade.min_tensile_mpa or
                         mech_props.elongation_pct < grade.min_elongation_pct)

        base_defect = self.defect_rate_pct / 100.0
        total_reject_fraction = min(0.5, base_defect + risk * 0.4 + (0.15 if spec_fail else 0.0))

        target = self.equipment.effective_capacity * dt_hours
        max_by_finished_goods = self.finished_goods.available_capacity / max(1 - total_reject_fraction, 1e-6)
        max_by_reject = self.reject_buffer.available_capacity / max(total_reject_fraction, 1e-6)
        effective_target = min(target, max_by_finished_goods, max_by_reject)

        wip_in = self.source.take(effective_target)
        starved = wip_in < effective_target * 0.95
        blocked = (not starved) and effective_target < target * 0.99

        if blocked:
            self.equipment.status = EquipmentStatus.BLOCKED
        elif starved:
            self.equipment.status = EquipmentStatus.STARVED
        else:
            self.equipment.status = EquipmentStatus.RUNNING
        self.equipment.step(dt_hours, running=not starved)

        good = wip_in * (1 - total_reject_fraction)
        rejected = wip_in * total_reject_fraction

        self.finished_goods.add(good)
        self.reject_buffer.add(rejected)

        self.energy_consumed_kwh = wip_in * 25.0
        self.waste_generated_kg = rejected * 1000.0
        self.output_this_tick = good
        self.emissions_co2_kg = wip_in * 15.0

        if total_reject_fraction > 0.08:
            self.publish("quality_excursion", {"reject_fraction": round(total_reject_fraction, 3)},
                         severity="warning")
        if starved:
            self.publish("starved", {"wip_available_t": self.source.level}, severity="warning")

        return {
            "finished_goods_t": round(good, 2),
            "rejected_t": round(rejected, 2),
            "reject_fraction_pct": round(total_reject_fraction * 100, 2),
            "finished_buffer_t": round(self.finished_goods.level, 1),
            "contamination_risk": round(risk, 3),
            "status": self.equipment.status.value,
        }


class ShippingDock(ProcessUnit):
    """Loads finished goods onto rail/ship for outbound logistics (see
    logistics.rail_port for the transport-side simulation)."""

    def __init__(self, bus: EventBus, source: Buffer, name: str = "shipping_dock",
                 nameplate_t_per_h: float = 400.0):
        equipment = Equipment(name=name, nameplate_capacity=nameplate_t_per_h)
        super().__init__(name, equipment, bus)
        self.source = source
        self.shipped_total_t = 0.0
        self.backlog_orders_t = 0.0

    def tick(self, dt_hours: float, demand_t: float = 0.0) -> dict:
        target = min(self.equipment.effective_capacity * dt_hours, demand_t + self.backlog_orders_t)
        shipped = self.source.take(target)
        unmet = max(0.0, demand_t - shipped)
        self.backlog_orders_t = max(0.0, self.backlog_orders_t + demand_t - shipped)
        self.shipped_total_t += shipped

        self.equipment.status = EquipmentStatus.RUNNING if shipped > 0 else EquipmentStatus.IDLE
        self.equipment.step(dt_hours, running=shipped > 0)

        self.energy_consumed_kwh = shipped * 4.0
        self.output_this_tick = shipped

        if unmet > 0:
            self.publish("order_backlog", {"unmet_t": round(unmet, 2)}, severity="warning")

        return {
            "shipped_t": round(shipped, 2),
            "shipped_total_t": round(self.shipped_total_t, 1),
            "backlog_orders_t": round(self.backlog_orders_t, 1),
            "status": self.equipment.status.value,
        }
