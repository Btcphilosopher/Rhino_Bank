"""
Genetic algorithm for production optimisation problems with real-valued or
mixed chromosomes -- e.g. alloy-addition balancing (minimise cost subject
to chemistry tolerance), furnace charge-mix optimisation, or multi-unit
production-rate allocation to maximise throughput within energy/labour
constraints.

Dependency-free (NumPy only) implementation: tournament selection,
blend crossover (BLX-alpha), Gaussian mutation, elitism.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class GAResult:
    best_chromosome: np.ndarray
    best_fitness: float
    history_best: List[float]
    history_mean: List[float]
    generations_run: int


class GeneticAlgorithm:
    def __init__(self, fitness_fn: Callable[[np.ndarray], float],
                 bounds: Sequence[Tuple[float, float]],
                 population_size: int = 80, elite_fraction: float = 0.1,
                 mutation_rate: float = 0.15, mutation_scale: float = 0.1,
                 crossover_alpha: float = 0.4, seed: Optional[int] = None):
        self.fitness_fn = fitness_fn
        self.bounds = np.array(bounds, dtype=float)
        self.n_genes = len(bounds)
        self.population_size = population_size
        self.elite_n = max(1, int(population_size * elite_fraction))
        self.mutation_rate = mutation_rate
        self.mutation_scale = mutation_scale
        self.crossover_alpha = crossover_alpha
        self.rng = np.random.default_rng(seed)

    def _init_population(self) -> np.ndarray:
        lo, hi = self.bounds[:, 0], self.bounds[:, 1]
        return self.rng.uniform(lo, hi, size=(self.population_size, self.n_genes))

    def _clip(self, pop: np.ndarray) -> np.ndarray:
        return np.clip(pop, self.bounds[:, 0], self.bounds[:, 1])

    def _tournament_select(self, pop: np.ndarray, fitness: np.ndarray, k: int = 3) -> np.ndarray:
        idx = self.rng.integers(0, len(pop), size=k)
        best_idx = idx[np.argmax(fitness[idx])]
        return pop[best_idx]

    def _crossover(self, p1: np.ndarray, p2: np.ndarray) -> np.ndarray:
        # BLX-alpha crossover
        lo = np.minimum(p1, p2) - self.crossover_alpha * np.abs(p1 - p2)
        hi = np.maximum(p1, p2) + self.crossover_alpha * np.abs(p1 - p2)
        return self.rng.uniform(lo, hi)

    def _mutate(self, chrom: np.ndarray) -> np.ndarray:
        mask = self.rng.random(self.n_genes) < self.mutation_rate
        span = self.bounds[:, 1] - self.bounds[:, 0]
        noise = self.rng.normal(0, self.mutation_scale, self.n_genes) * span
        return np.where(mask, chrom + noise, chrom)

    def run(self, generations: int = 100, patience: Optional[int] = None) -> GAResult:
        pop = self._init_population()
        history_best: List[float] = []
        history_mean: List[float] = []
        best_ever = None
        best_ever_fit = -np.inf
        no_improve = 0

        for gen in range(generations):
            fitness = np.array([self.fitness_fn(ind) for ind in pop])
            order = np.argsort(-fitness)
            pop = pop[order]
            fitness = fitness[order]

            history_best.append(float(fitness[0]))
            history_mean.append(float(fitness.mean()))

            if fitness[0] > best_ever_fit:
                best_ever_fit = float(fitness[0])
                best_ever = pop[0].copy()
                no_improve = 0
            else:
                no_improve += 1

            if patience is not None and no_improve >= patience:
                return GAResult(best_ever, best_ever_fit, history_best, history_mean, gen + 1)

            new_pop = [pop[i].copy() for i in range(self.elite_n)]  # elitism
            while len(new_pop) < self.population_size:
                p1 = self._tournament_select(pop, fitness)
                p2 = self._tournament_select(pop, fitness)
                child = self._crossover(p1, p2)
                child = self._mutate(child)
                new_pop.append(child)
            pop = self._clip(np.array(new_pop))

        return GAResult(best_ever, best_ever_fit, history_best, history_mean, generations)


def optimise_alloy_addition(target_composition: dict, current_composition: dict,
                             element_costs_usd_per_kg: dict, heat_mass_t: float,
                             tolerance_pct: float = 0.1) -> GAResult:
    """Example application: choose alloy addition masses (kg) for each
    trim element to hit target chemistry at minimum cost, penalising any
    element left outside tolerance.
    """
    elements = list(target_composition.keys())
    bounds = [(0.0, heat_mass_t * 1000 * 0.05) for _ in elements]  # up to 5% of heat mass, kg

    def fitness(chrom: np.ndarray) -> float:
        cost = 0.0
        penalty = 0.0
        for i, el in enumerate(elements):
            added_pct = chrom[i] / (heat_mass_t * 1000.0) * 100.0
            resulting_pct = current_composition.get(el, 0.0) + added_pct
            target = target_composition[el]
            dev = abs(resulting_pct - target) / max(target, 1e-6)
            cost += chrom[i] * element_costs_usd_per_kg.get(el, 5.0)
            if dev > tolerance_pct:
                penalty += (dev - tolerance_pct) * 10000
        return -(cost + penalty)  # GA maximises fitness -> minimise cost+penalty

    ga = GeneticAlgorithm(fitness, bounds, population_size=60)
    return ga.run(generations=80, patience=20)
