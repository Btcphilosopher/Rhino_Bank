"""
Monte Carlo simulation engine for risk analysis: propagates uncertainty in
inputs (commodity prices, demand, disruption frequency, equipment
reliability) through a scenario function to build an output distribution --
used for stress-testing supply chains and financial forecasting under
uncertainty.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List

import numpy as np


@dataclass
class MonteCarloResult:
    samples: np.ndarray
    mean: float
    std: float
    p5: float
    p50: float
    p95: float
    var_95: float          # value-at-risk (5th percentile loss)
    prob_below_zero: float


def monte_carlo_simulate(scenario_fn: Callable[[np.random.Generator], float],
                          n_trials: int = 5000, seed: int | None = None) -> MonteCarloResult:
    """Run `scenario_fn` (which draws its own random inputs from the
    supplied Generator and returns a single scalar outcome, e.g. annual
    EBITDA or total tonnes shipped) `n_trials` times and summarise the
    resulting distribution.
    """
    rng = np.random.default_rng(seed)
    samples = np.array([scenario_fn(rng) for _ in range(n_trials)])
    return MonteCarloResult(
        samples=samples,
        mean=float(samples.mean()),
        std=float(samples.std()),
        p5=float(np.percentile(samples, 5)),
        p50=float(np.percentile(samples, 50)),
        p95=float(np.percentile(samples, 95)),
        var_95=float(samples.mean() - np.percentile(samples, 5)),
        prob_below_zero=float(np.mean(samples < 0)),
    )


def supply_chain_stress_test(n_trials: int = 2000,
                              base_annual_output_t: float = 6_500_000,
                              disruption_prob_range=(0.05, 0.30),
                              disruption_impact_range=(0.1, 0.6),
                              seed: int | None = None) -> MonteCarloResult:
    """Example Monte Carlo application: simulate annual production loss
    from stacking multiple stochastic disruption events (rail, port,
    power) of random frequency/severity across a year, sampled from
    uniform priors over plausible engineering ranges.
    """
    def scenario(rng: np.random.Generator) -> float:
        n_events = rng.poisson(lam=rng.uniform(2, 14))
        total_loss_fraction = 0.0
        for _ in range(n_events):
            duration_days = rng.exponential(3.0)
            impact = rng.uniform(*disruption_impact_range)
            total_loss_fraction += (duration_days / 365.0) * impact
        total_loss_fraction = min(0.9, total_loss_fraction)
        return base_annual_output_t * (1 - total_loss_fraction)

    return monte_carlo_simulate(scenario, n_trials=n_trials, seed=seed)
