"""
Heuristic scheduling/optimisation: workforce shift scheduling, maintenance
downtime-window allocation, and logistics route selection. These use
greedy/heuristic algorithms (fast, explainable, good-enough for
operational decisions) rather than full metaheuristic search, complementing
the genetic algorithm and Monte Carlo engines for harder combinatorial or
stochastic problems.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class ShiftAssignment:
    worker_id: str
    shift: str  # "A" | "B" | "C"
    role: str
    overtime_hours: float = 0.0


class WorkforceScheduler:
    """Greedy shift-fill scheduler: assigns available workers to shifts by
    role requirement, minimising overtime and respecting max-consecutive-
    shift labour rules.
    """

    def __init__(self, shift_requirements: Dict[str, Dict[str, int]]):
        """shift_requirements: {shift: {role: headcount_needed}}"""
        self.shift_requirements = shift_requirements
        self.max_consecutive_shifts = 5

    def schedule(self, available_workers: List[Dict]) -> Tuple[List[ShiftAssignment], List[str]]:
        """available_workers: [{"id": str, "role": str,
        "consecutive_shifts": int, "available": bool}, ...]
        Returns (assignments, understaffed_warnings).
        """
        assignments: List[ShiftAssignment] = []
        warnings: List[str] = []
        pool = {w["id"]: w for w in available_workers if w.get("available", True)}
        used = set()

        for shift, roles in self.shift_requirements.items():
            for role, needed in roles.items():
                candidates = [
                    w for w in pool.values()
                    if w["role"] == role and w["id"] not in used
                    and w.get("consecutive_shifts", 0) < self.max_consecutive_shifts
                ]
                # prioritise workers with fewer recent consecutive shifts (fairness)
                candidates.sort(key=lambda w: w.get("consecutive_shifts", 0))
                chosen = candidates[:needed]
                start_idx = len(assignments)
                for w in chosen:
                    assignments.append(ShiftAssignment(w["id"], shift, role))
                    used.add(w["id"])
                shortfall = needed - len(chosen)
                if shortfall > 0:
                    warnings.append(
                        f"Shift {shift} short {shortfall} x {role} -- overtime/agency required"
                    )
                    # cover part of the gap by extending already-assigned
                    # workers onto overtime (marks their existing
                    # assignment, rather than double-booking them onto a
                    # second concurrent assignment for the same shift).
                    for i in range(min(shortfall, len(chosen))):
                        assignments[start_idx + i].overtime_hours = 8.0
        return assignments, warnings


@dataclass
class MaintenanceWindow:
    equipment: str
    start_hour_offset: float
    duration_hours: float
    crew_size: int


class MaintenanceWindowOptimizer:
    """Greedy interval scheduler: packs the prioritised maintenance backlog
    (from maintenance.MaintenanceScheduleOptimizer) into available downtime
    windows, respecting crew-size capacity, favouring the most urgent work
    orders first (earliest-deadline-first with capacity constraint --
    a well-known effective heuristic for resource-constrained scheduling).
    """

    def __init__(self, crew_capacity: int = 24, planning_horizon_hours: float = 168.0):
        self.crew_capacity = crew_capacity
        self.planning_horizon_hours = planning_horizon_hours

    def schedule(self, backlog: List, default_duration_hours: float = 6.0,
                 default_crew_size: int = 4) -> List[MaintenanceWindow]:
        windows: List[MaintenanceWindow] = []
        crew_timeline: Dict[int, int] = {}  # hour-bucket -> crew used
        for order in backlog:
            placed = False
            for start in range(0, int(self.planning_horizon_hours), 2):
                bucket_ok = all(
                    crew_timeline.get(start + h, 0) + default_crew_size <= self.crew_capacity
                    for h in range(int(default_duration_hours))
                )
                # urgent work (RUL < 72h) must be scheduled immediately
                if getattr(order, "rul_hours", 999) < 72 and start > 12:
                    continue
                if bucket_ok:
                    for h in range(int(default_duration_hours)):
                        crew_timeline[start + h] = crew_timeline.get(start + h, 0) + default_crew_size
                    windows.append(MaintenanceWindow(
                        equipment=getattr(order, "equipment", str(order)),
                        start_hour_offset=start, duration_hours=default_duration_hours,
                        crew_size=default_crew_size,
                    ))
                    placed = True
                    break
            if not placed:
                windows.append(MaintenanceWindow(
                    equipment=getattr(order, "equipment", str(order)),
                    start_hour_offset=self.planning_horizon_hours, duration_hours=default_duration_hours,
                    crew_size=default_crew_size,
                ))  # deferred beyond horizon
        return windows


class LogisticsRouteOptimizer:
    """Greedy cheapest-feasible-route selector across candidate rail/port
    routings, accounting for a per-route disruption-derated capacity --
    a lightweight stand-in for a full vehicle-routing / min-cost-flow
    solver, adequate for route-level (not load-level) decisions.
    """

    def choose_route(self, routes: List[Dict], tonnes_to_move: float) -> Dict:
        """routes: [{"name": str, "capacity_t_per_day": float,
        "cost_usd_per_t": float, "disruption_multiplier": float}]
        Returns the cheapest route with sufficient derated capacity, else
        the highest-capacity route (best-effort) with a warning flag.
        """
        feasible = [
            r for r in routes
            if r["capacity_t_per_day"] * r.get("disruption_multiplier", 1.0) >= tonnes_to_move
        ]
        if feasible:
            best = min(feasible, key=lambda r: r["cost_usd_per_t"])
            return {**best, "feasible": True}
        best_effort = max(routes, key=lambda r: r["capacity_t_per_day"] * r.get("disruption_multiplier", 1.0))
        return {**best_effort, "feasible": False}
