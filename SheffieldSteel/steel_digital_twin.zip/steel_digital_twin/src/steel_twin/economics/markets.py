"""
Economic model: commodity pricing, electricity markets, carbon taxes, and
currency fluctuations.

Prices are simulated with a mean-reverting Ornstein-Uhlenbeck (OU) process,
the standard quantitative-finance model for commodity spot prices, plus
(for electricity) an intraday sinusoidal demand pattern layered on top to
capture peak/off-peak pricing.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Deque, List
from collections import deque


@dataclass
class OrnsteinUhlenbeckPrice:
    """dX = theta*(mu - X)*dt + sigma*dW  -- mean-reverting stochastic price."""

    mu: float                 # long-run mean price
    theta: float = 0.02       # mean-reversion speed
    sigma: float = 0.5        # volatility
    value: float = field(default=0.0)

    def __post_init__(self):
        if self.value == 0.0:
            self.value = self.mu

    def step(self, dt_hours: float = 1.0) -> float:
        dt = dt_hours / 24.0  # in days, calibrated for daily-scale vol
        dw = random.gauss(0, math.sqrt(dt))
        self.value += self.theta * (self.mu - self.value) * dt + self.sigma * dw
        self.value = max(0.01, self.value)
        return self.value


class CommodityMarket:
    """Tracks spot prices for the plant's key commodity inputs/outputs."""

    def __init__(self):
        self.prices = {
            "iron_ore_usd_per_t": OrnsteinUhlenbeckPrice(mu=110.0, theta=0.015, sigma=2.5),
            "coking_coal_usd_per_t": OrnsteinUhlenbeckPrice(mu=220.0, theta=0.02, sigma=5.0),
            "scrap_steel_usd_per_t": OrnsteinUhlenbeckPrice(mu=380.0, theta=0.02, sigma=6.0),
            "steel_product_usd_per_t": OrnsteinUhlenbeckPrice(mu=780.0, theta=0.01, sigma=8.0),
        }
        self.history: dict[str, Deque[float]] = {k: deque(maxlen=2000) for k in self.prices}

    def tick(self, dt_hours: float = 1.0) -> dict:
        out = {}
        for k, proc in self.prices.items():
            v = proc.step(dt_hours)
            self.history[k].append(v)
            out[k] = round(v, 2)
        return out


class ElectricityMarket:
    """Industrial electricity spot price: OU-driven base price modulated by
    an intraday peak/off-peak sinusoid (daytime peaks, overnight troughs)
    plus a demand-response penalty when grid stress is high.
    """

    def __init__(self, base_usd_per_mwh: float = 65.0):
        self.base_process = OrnsteinUhlenbeckPrice(mu=base_usd_per_mwh, theta=0.05, sigma=4.0)
        self.grid_stress = 0.0  # 0-1, set externally by power.grid_control

    def price_usd_per_mwh(self, hour_of_day: int, dt_hours: float = 1.0) -> float:
        base = self.base_process.step(dt_hours)
        peak_factor = 1.0 + 0.35 * math.sin(math.pi * (hour_of_day - 6) / 12) \
            if 6 <= hour_of_day <= 22 else 0.75
        stress_surcharge = 1.0 + self.grid_stress * 1.5
        return max(5.0, base * peak_factor * stress_surcharge)


class CarbonMarket:
    """Carbon tax / cap-and-trade price (USD per tonne CO2), OU process with
    slow long-run drift representing policy tightening.
    """

    def __init__(self, base_usd_per_t_co2: float = 80.0, annual_drift_usd: float = 3.0):
        self.process = OrnsteinUhlenbeckPrice(mu=base_usd_per_t_co2, theta=0.005, sigma=1.5)
        self.annual_drift_usd = annual_drift_usd
        self._elapsed_years = 0.0

    def price_usd_per_tonne(self, dt_hours: float = 1.0) -> float:
        self._elapsed_years += dt_hours / (365.25 * 24)
        self.process.mu += self.annual_drift_usd * (dt_hours / (365.25 * 24))
        return self.process.step(dt_hours)


class CurrencyMarket:
    """FX rate simulation (e.g. USD per unit local currency) for export
    demand / tariff sensitivity analysis.
    """

    def __init__(self, base_rate: float = 1.0, volatility: float = 0.008):
        self.process = OrnsteinUhlenbeckPrice(mu=base_rate, theta=0.01, sigma=volatility)

    def rate(self, dt_hours: float = 1.0) -> float:
        return self.process.step(dt_hours)
