"""
Plant economics: cost accounting, labour/maintenance budgets, tariffs, and
standard corporate-finance evaluation functions (NPV, ROI, payback) for
expansion-scenario / investment modelling.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class CostLedger:
    """Accumulates operating costs by category over the run, in USD."""

    raw_materials: float = 0.0
    energy: float = 0.0
    labour: float = 0.0
    maintenance: float = 0.0
    carbon_tax: float = 0.0
    logistics: float = 0.0
    tariffs: float = 0.0
    other: float = 0.0

    revenue: float = 0.0

    def total_cost(self) -> float:
        return (self.raw_materials + self.energy + self.labour + self.maintenance
                + self.carbon_tax + self.logistics + self.tariffs + self.other)

    def gross_margin(self) -> float:
        return self.revenue - self.total_cost()

    def as_dict(self) -> Dict[str, float]:
        d = self.__dict__.copy()
        d["total_cost"] = self.total_cost()
        d["gross_margin"] = self.gross_margin()
        return {k: round(v, 2) for k, v in d.items()}


class PlantEconomics:
    """Ties production tonnages to the market module to accrue the cost
    ledger tick by tick.
    """

    def __init__(self, labour_headcount: int = 1800, avg_wage_usd_per_hour: float = 38.0,
                 tariff_rate: float = 0.0):
        self.ledger = CostLedger()
        self.labour_headcount = labour_headcount
        self.avg_wage_usd_per_hour = avg_wage_usd_per_hour
        self.tariff_rate = tariff_rate

    def accrue_tick(self, dt_hours: float, *, ore_used_t: float, coal_used_t: float,
                     scrap_used_t: float, energy_mwh: float, energy_price_usd_per_mwh: float,
                     co2_tonnes: float, carbon_price_usd_per_t: float,
                     maintenance_cost_usd: float, logistics_cost_usd: float,
                     steel_shipped_t: float, steel_price_usd_per_t: float,
                     prices: Dict[str, float]) -> None:
        self.ledger.raw_materials += (
            ore_used_t * prices.get("iron_ore_usd_per_t", 110.0)
            + coal_used_t * prices.get("coking_coal_usd_per_t", 220.0)
            + scrap_used_t * prices.get("scrap_steel_usd_per_t", 380.0)
        )
        self.ledger.energy += energy_mwh * energy_price_usd_per_mwh
        self.ledger.labour += self.labour_headcount * self.avg_wage_usd_per_hour * dt_hours / 24.0 / 3.0
        # (headcount split across ~3 shifts of dt_hours each, simplified continuous accrual)
        self.ledger.maintenance += maintenance_cost_usd
        self.ledger.carbon_tax += co2_tonnes * carbon_price_usd_per_t
        self.ledger.logistics += logistics_cost_usd

        revenue_this_tick = steel_shipped_t * steel_price_usd_per_t
        tariff_cost = revenue_this_tick * self.tariff_rate
        self.ledger.tariffs += tariff_cost
        self.ledger.revenue += revenue_this_tick


def npv(cash_flows: List[float], discount_rate: float) -> float:
    """Net present value of a series of annual cash flows (index 0 = year 0,
    the initial investment, typically negative)."""
    return sum(cf / (1 + discount_rate) ** t for t, cf in enumerate(cash_flows))


def roi(total_gain: float, total_cost: float) -> float:
    if total_cost == 0:
        return 0.0
    return (total_gain - total_cost) / total_cost


def payback_period_years(initial_investment: float, annual_cash_flow: float) -> float:
    if annual_cash_flow <= 0:
        return float("inf")
    return initial_investment / annual_cash_flow


def irr(cash_flows: List[float], guess: float = 0.1, iterations: int = 200) -> float:
    """Internal rate of return via Newton-Raphson on the NPV function."""
    rate = guess
    for _ in range(iterations):
        npv_val = sum(cf / (1 + rate) ** t for t, cf in enumerate(cash_flows))
        d_npv = sum(-t * cf / (1 + rate) ** (t + 1) for t, cf in enumerate(cash_flows))
        if abs(d_npv) < 1e-9:
            break
        new_rate = rate - npv_val / d_npv
        if abs(new_rate - rate) < 1e-7:
            rate = new_rate
            break
        rate = new_rate
    return rate


def expansion_scenario_npv(capex_usd: float, incremental_annual_ebitda_usd: float,
                            years: int, discount_rate: float = 0.09,
                            terminal_growth: float = 0.0) -> Dict[str, float]:
    """Evaluate a capacity-expansion investment: NPV, simple ROI over the
    horizon, and payback period, from a flat (or growing) incremental
    EBITDA stream.
    """
    flows = [-capex_usd]
    cf = incremental_annual_ebitda_usd
    for _ in range(years):
        flows.append(cf)
        cf *= (1 + terminal_growth)
    return {
        "npv_usd": round(npv(flows, discount_rate), 0),
        "roi": round(roi(sum(flows[1:]), capex_usd), 3),
        "payback_years": round(payback_period_years(capex_usd, incremental_annual_ebitda_usd), 2),
        "irr": round(irr(flows), 4),
    }
