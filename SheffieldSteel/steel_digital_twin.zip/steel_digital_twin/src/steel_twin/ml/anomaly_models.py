"""
ML anomaly-detection models for predictive maintenance (bearing failure,
furnace degradation, conveyor wear, rolling-mill fatigue, cooling-system
faults), complementing the lightweight EWMA detector in
`maintenance.predictive` with two additional NumPy-native techniques:

  * IsolationForestLite: a from-scratch isolation-forest implementation
    (random recursive partitioning; anomalies isolate faster, i.e. at
    shallower tree depth -- the core idea behind Liu et al.'s Isolation
    Forest), for multivariate sensor anomaly detection.
  * ReconstructionAnomalyDetector: PCA-reconstruction-error anomaly
    detector (fit a low-rank subspace on normal operating data via SVD;
    flag points with high reconstruction error) -- a classical,
    dependency-free analogue of an autoencoder-based anomaly detector.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np


class _ITreeNode:
    __slots__ = ("split_feature", "split_value", "left", "right", "size", "is_leaf")

    def __init__(self):
        self.split_feature: Optional[int] = None
        self.split_value: Optional[float] = None
        self.left: Optional["_ITreeNode"] = None
        self.right: Optional["_ITreeNode"] = None
        self.size = 0
        self.is_leaf = False


def _c_factor(n: int) -> float:
    """Average path length of unsuccessful BST search, used to normalise
    isolation-forest path lengths into an anomaly score (Liu et al. 2008)."""
    if n <= 1:
        return 0.0
    euler_gamma = 0.5772156649
    return 2.0 * (np.log(n - 1) + euler_gamma) - (2.0 * (n - 1) / n)


class IsolationForestLite:
    def __init__(self, n_trees: int = 100, subsample_size: int = 256,
                 max_depth: Optional[int] = None, seed: Optional[int] = None):
        self.n_trees = n_trees
        self.subsample_size = subsample_size
        self.max_depth = max_depth
        self.rng = np.random.default_rng(seed)
        self.trees: List[_ITreeNode] = []
        self._c = 1.0

    def fit(self, X: np.ndarray) -> "IsolationForestLite":
        X = np.asarray(X, dtype=float)
        n = X.shape[0]
        sub_n = min(self.subsample_size, n)
        depth_limit = self.max_depth or int(np.ceil(np.log2(max(sub_n, 2))))
        self.trees = []
        for _ in range(self.n_trees):
            idx = self.rng.choice(n, size=sub_n, replace=False)
            self.trees.append(self._build(X[idx], 0, depth_limit))
        self._c = _c_factor(sub_n)
        return self

    def _build(self, X: np.ndarray, depth: int, depth_limit: int) -> _ITreeNode:
        node = _ITreeNode()
        node.size = X.shape[0]
        if depth >= depth_limit or X.shape[0] <= 1:
            node.is_leaf = True
            return node
        n_features = X.shape[1]
        feature = self.rng.integers(0, n_features)
        col = X[:, feature]
        lo, hi = col.min(), col.max()
        if lo == hi:
            node.is_leaf = True
            return node
        split = self.rng.uniform(lo, hi)
        left_mask = col < split
        node.split_feature = feature
        node.split_value = split
        node.left = self._build(X[left_mask], depth + 1, depth_limit)
        node.right = self._build(X[~left_mask], depth + 1, depth_limit)
        return node

    def _path_length(self, x: np.ndarray, node: _ITreeNode, depth: int = 0) -> float:
        if node.is_leaf or node.split_feature is None:
            return depth + _c_factor(node.size)
        if x[node.split_feature] < node.split_value:
            return self._path_length(x, node.left, depth + 1)
        return self._path_length(x, node.right, depth + 1)

    def anomaly_score(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        scores = np.zeros(X.shape[0])
        for i, x in enumerate(X):
            avg_path = np.mean([self._path_length(x, tree) for tree in self.trees])
            scores[i] = 2 ** (-avg_path / max(self._c, 1e-9))  # ~0.5 normal, ->1 anomalous
        return scores

    def predict(self, X: np.ndarray, threshold: float = 0.62) -> np.ndarray:
        return self.anomaly_score(X) >= threshold


@dataclass
class ReconstructionAnomalyDetector:
    """PCA-subspace reconstruction-error anomaly detector."""

    n_components: int = 3
    _mean: Optional[np.ndarray] = field(default=None, init=False)
    _components: Optional[np.ndarray] = field(default=None, init=False)  # (n_components, n_features)
    _threshold: float = field(default=0.0, init=False)

    def fit(self, X: np.ndarray, threshold_percentile: float = 97.5) -> "ReconstructionAnomalyDetector":
        X = np.asarray(X, dtype=float)
        self._mean = X.mean(axis=0)
        Xc = X - self._mean
        u, s, vt = np.linalg.svd(Xc, full_matrices=False)
        k = min(self.n_components, vt.shape[0])
        self._components = vt[:k]
        errors = self._reconstruction_error(X)
        self._threshold = float(np.percentile(errors, threshold_percentile))
        return self

    def _reconstruction_error(self, X: np.ndarray) -> np.ndarray:
        Xc = X - self._mean
        projected = Xc @ self._components.T
        reconstructed = projected @ self._components
        return np.sum((Xc - reconstructed) ** 2, axis=1)

    def score(self, X: np.ndarray) -> np.ndarray:
        return self._reconstruction_error(np.asarray(X, dtype=float))

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.score(X) >= self._threshold
