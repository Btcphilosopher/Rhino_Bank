"""
Time-series forecasting models for production/maintenance/demand
forecasting: Holt's linear exponential smoothing (level + trend) and a
simple ordinary-least-squares linear trend forecaster with prediction
intervals.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np


@dataclass
class ExponentialSmoothingForecaster:
    """Holt's linear trend method (double exponential smoothing):
        level_t = alpha*y_t + (1-alpha)*(level_{t-1} + trend_{t-1})
        trend_t = beta*(level_t - level_{t-1}) + (1-beta)*trend_{t-1}
        forecast(h) = level_t + h*trend_t
    """

    alpha: float = 0.3
    beta: float = 0.1
    _level: Optional[float] = field(default=None, init=False)
    _trend: float = field(default=0.0, init=False)
    _residuals: List[float] = field(default_factory=list, init=False)

    def fit(self, series: List[float]) -> "ExponentialSmoothingForecaster":
        if len(series) < 2:
            raise ValueError("Need at least 2 points to fit trend.")
        self._level = series[0]
        self._trend = series[1] - series[0]
        self._residuals = []
        for y in series[1:]:
            forecast = self._level + self._trend
            self._residuals.append(y - forecast)
            new_level = self.alpha * y + (1 - self.alpha) * (self._level + self._trend)
            self._trend = self.beta * (new_level - self._level) + (1 - self.beta) * self._trend
            self._level = new_level
        return self

    def update(self, y: float) -> None:
        if self._level is None:
            self._level = y
            return
        forecast = self._level + self._trend
        self._residuals.append(y - forecast)
        if len(self._residuals) > 500:
            self._residuals.pop(0)
        new_level = self.alpha * y + (1 - self.alpha) * (self._level + self._trend)
        self._trend = self.beta * (new_level - self._level) + (1 - self.beta) * self._trend
        self._level = new_level

    def forecast(self, horizon: int) -> np.ndarray:
        if self._level is None:
            raise RuntimeError("Call fit() first.")
        return np.array([self._level + h * self._trend for h in range(1, horizon + 1)])

    def forecast_with_interval(self, horizon: int, z: float = 1.96) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        point = self.forecast(horizon)
        resid_std = float(np.std(self._residuals)) if self._residuals else 0.0
        # interval widens with sqrt(horizon), standard for random-walk-type
        # forecast error growth
        widths = z * resid_std * np.sqrt(np.arange(1, horizon + 1))
        return point, point - widths, point + widths


@dataclass
class LinearTrendForecaster:
    """OLS linear regression forecaster with prediction interval, suitable
    for slower-moving trends (e.g. multi-week degradation trend, quarterly
    demand)."""

    slope: float = field(default=0.0, init=False)
    intercept: float = field(default=0.0, init=False)
    resid_std: float = field(default=0.0, init=False)
    n: int = field(default=0, init=False)

    def fit(self, x: List[float], y: List[float]) -> "LinearTrendForecaster":
        x_arr = np.asarray(x, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        A = np.vstack([x_arr, np.ones_like(x_arr)]).T
        self.slope, self.intercept = np.linalg.lstsq(A, y_arr, rcond=None)[0]
        residuals = y_arr - (self.slope * x_arr + self.intercept)
        self.resid_std = float(np.std(residuals))
        self.n = len(x_arr)
        return self

    def predict(self, x: List[float]) -> np.ndarray:
        x_arr = np.asarray(x, dtype=float)
        return self.slope * x_arr + self.intercept

    def predict_with_interval(self, x: List[float], z: float = 1.96
                               ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        point = self.predict(x)
        return point, point - z * self.resid_std, point + z * self.resid_std
