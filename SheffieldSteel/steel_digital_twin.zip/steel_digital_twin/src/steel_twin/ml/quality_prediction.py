"""
Quality prediction: predicts output quality / defect probability /
contamination risk / structural weakness from process telemetry, trained
on historical (or simulated) process data.

Implemented as a ridge-regularised linear regression solved in closed form
with NumPy (no heavyweight ML framework required to run the simulator
out of the box). The `QualityPredictor` interface is deliberately
scikit-learn-shaped (`fit(X, y)` / `predict(X)`) so a real gradient-boosted
tree or PyTorch model can be dropped in behind the same interface for a
production deployment -- see README "Extending the ML layer".
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

import numpy as np


@dataclass
class QualityPrediction:
    defect_probability: float
    predicted_tensile_mpa: float
    contamination_risk: float
    structural_weakness_score: float
    confidence: float


class QualityPredictor:
    """Ridge regression quality model.

    Features (per heat/cast): [carbon_pct, mn_pct, p_pct, s_pct,
    cooling_rate_c_per_s, tap_temp_c, oxygen_blow_time_min,
    slag_basicity, equipment_health_index]
    Targets: multi-output [defect_probability, tensile_mpa,
    contamination_risk, structural_weakness]
    """

    FEATURE_NAMES = [
        "carbon_pct", "mn_pct", "p_pct", "s_pct", "cooling_rate_c_per_s",
        "tap_temp_c", "blow_time_min", "slag_basicity", "equipment_health",
    ]

    def __init__(self, ridge_lambda: float = 1.0):
        self.ridge_lambda = ridge_lambda
        self.weights: Optional[np.ndarray] = None  # (n_features+1, n_targets)
        self._feature_mean: Optional[np.ndarray] = None
        self._feature_std: Optional[np.ndarray] = None
        self.n_train_samples = 0

    def fit(self, X: np.ndarray, y: np.ndarray) -> "QualityPredictor":
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        self._feature_mean = X.mean(axis=0)
        self._feature_std = X.std(axis=0) + 1e-8
        Xn = (X - self._feature_mean) / self._feature_std
        Xb = np.hstack([np.ones((Xn.shape[0], 1)), Xn])  # bias column

        n_features = Xb.shape[1]
        reg = self.ridge_lambda * np.eye(n_features)
        reg[0, 0] = 0.0  # don't regularise bias
        self.weights = np.linalg.solve(Xb.T @ Xb + reg, Xb.T @ y)
        self.n_train_samples = X.shape[0]
        return self

    def predict_raw(self, X: np.ndarray) -> np.ndarray:
        if self.weights is None:
            raise RuntimeError("QualityPredictor.fit() must be called before predict().")
        X = np.asarray(X, dtype=float)
        Xn = (X - self._feature_mean) / self._feature_std
        Xb = np.hstack([np.ones((Xn.shape[0], 1)), Xn])
        return Xb @ self.weights

    def predict(self, features: Sequence[float]) -> QualityPrediction:
        raw = self.predict_raw(np.array([features]))[0]
        defect_prob = float(np.clip(raw[0], 0.0, 1.0))
        tensile = float(max(0.0, raw[1]))
        contamination = float(np.clip(raw[2], 0.0, 1.0))
        weakness = float(np.clip(raw[3], 0.0, 1.0))
        # confidence proxy: shrinks with distance from training-set feature
        # centroid (a cheap analogue of predictive-interval width)
        dist = float(np.linalg.norm((np.array(features) - self._feature_mean) / self._feature_std))
        confidence = float(np.clip(1.0 - dist / 10.0, 0.05, 0.99))
        return QualityPrediction(defect_prob, tensile, contamination, weakness, confidence)

    @staticmethod
    def synthesize_training_data(n_samples: int = 2000, seed: int = 42):
        """Generate physically-plausible synthetic training data (used when
        no historical plant data file is supplied) so the model is usable
        out of the box; swap for a real historical dataset in production.
        """
        rng = np.random.default_rng(seed)
        carbon = rng.uniform(0.02, 1.2, n_samples)
        mn = rng.uniform(0.1, 1.8, n_samples)
        p = rng.uniform(0.005, 0.05, n_samples)
        s = rng.uniform(0.005, 0.05, n_samples)
        cooling_rate = rng.uniform(0.5, 40, n_samples)
        tap_temp = rng.uniform(1580, 1680, n_samples)
        blow_time = rng.uniform(12, 22, n_samples)
        basicity = rng.uniform(1.5, 4.5, n_samples)
        health = rng.uniform(0.4, 1.0, n_samples)

        X = np.column_stack([carbon, mn, p, s, cooling_rate, tap_temp, blow_time, basicity, health])

        tensile = 300 + 700 * carbon + 15 * mn + 3 * cooling_rate - 50 * (1 - health) \
            + rng.normal(0, 20, n_samples)
        defect_prob = np.clip(
            0.02 + 3.0 * p + 2.5 * s + 0.15 * (1 - health) + 0.01 * np.abs(cooling_rate - 10) / 10
            + rng.normal(0, 0.02, n_samples), 0, 1)
        contamination = np.clip(0.05 + 4.0 * p + 3.0 * s + rng.normal(0, 0.03, n_samples), 0, 1)
        weakness = np.clip(0.1 + 0.3 * (1 - health) + 1.5 * s + rng.normal(0, 0.05, n_samples), 0, 1)

        y = np.column_stack([defect_prob, tensile, contamination, weakness])
        return X, y
