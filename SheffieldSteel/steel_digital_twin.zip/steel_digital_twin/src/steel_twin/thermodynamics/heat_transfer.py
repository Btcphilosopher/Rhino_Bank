"""
Heat transfer modelling: conduction, convection, radiation, and a
lumped-capacitance transient cooling solver (used for casting/rolling
cooling-rate predictions that feed metallurgy.phase_transform).

Uses NumPy for vectorised evaluation and SciPy's ODE integrator for the
transient (differential-equation) cooling model.
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp

STEFAN_BOLTZMANN = 5.670374419e-8  # W/(m^2 K^4)


def conduction_flux(k_w_per_mK: float, area_m2: float, dt_c: float,
                     thickness_m: float) -> float:
    """Fourier's law of steady conduction:
        Q = k * A * dT / L   [W]
    k: thermal conductivity, A: cross-section area, dT: temperature
    difference, L: path length.
    """
    return k_w_per_mK * area_m2 * dt_c / max(thickness_m, 1e-6)


def convection_flux(h_w_per_m2K: float, area_m2: float,
                     surface_temp_c: float, fluid_temp_c: float) -> float:
    """Newton's law of cooling:
        Q = h * A * (Ts - Tf)   [W]
    """
    return h_w_per_m2K * area_m2 * (surface_temp_c - fluid_temp_c)


def radiation_flux(area_m2: float, surface_temp_c: float, ambient_temp_c: float,
                    emissivity: float = 0.8) -> float:
    """Stefan-Boltzmann radiative heat loss:
        Q = eps * sigma * A * (Ts^4 - Tamb^4)   [W], temperatures in Kelvin.
    """
    ts_k = surface_temp_c + 273.15
    ta_k = ambient_temp_c + 273.15
    return emissivity * STEFAN_BOLTZMANN * area_m2 * (ts_k ** 4 - ta_k ** 4)


def lumped_cooling_curve(initial_temp_c: float, ambient_temp_c: float,
                          mass_kg: float, specific_heat_j_per_kgK: float,
                          surface_area_m2: float, h_w_per_m2K: float,
                          emissivity: float, duration_s: float,
                          n_points: int = 100) -> tuple[np.ndarray, np.ndarray]:
    """Solve the lumped-capacitance transient cooling ODE (Newtonian +
    radiative losses combined) for a billet/slab/ingot cooling in air or
    on a runout table:

        m * cp * dT/dt = -h*A*(T - Tamb) - eps*sigma*A*(T_K^4 - Tamb_K^4)

    Returns (time_s, temperature_c) arrays sampled at n_points, and is the
    basis for computing the average cooling rate fed into
    metallurgy.phase_transform.cooling_rate_to_microstructure.
    """
    def rhs(t, y):
        t_c = y[0]
        q_conv = h_w_per_m2K * surface_area_m2 * (t_c - ambient_temp_c)
        t_k = t_c + 273.15
        amb_k = ambient_temp_c + 273.15
        q_rad = emissivity * STEFAN_BOLTZMANN * surface_area_m2 * (t_k ** 4 - amb_k ** 4)
        dTdt = -(q_conv + q_rad) / (mass_kg * specific_heat_j_per_kgK)
        return [dTdt]

    t_eval = np.linspace(0, duration_s, n_points)
    sol = solve_ivp(rhs, [0, duration_s], [initial_temp_c], t_eval=t_eval, method="RK45")
    return sol.t, sol.y[0]


def average_cooling_rate_c_per_s(time_s: np.ndarray, temp_c: np.ndarray,
                                  t_hi: float = 800.0, t_lo: float = 500.0) -> float:
    """Average cooling rate through the technologically important
    austenite-decomposition window (default 800->500 C), computed from a
    solved cooling curve by linear interpolation of crossing times.
    """
    if temp_c[0] < t_hi or temp_c[-1] > t_lo:
        # window not fully spanned by the curve; fall back to endpoints
        dt = temp_c[0] - temp_c[-1]
        dtime = max(time_s[-1] - time_s[0], 1e-6)
        return max(dt / dtime, 0.0)
    t_at_hi = float(np.interp(t_hi, temp_c[::-1], time_s[::-1]))
    t_at_lo = float(np.interp(t_lo, temp_c[::-1], time_s[::-1]))
    dtime = max(t_at_lo - t_at_hi, 1e-6)
    return (t_hi - t_lo) / dtime
