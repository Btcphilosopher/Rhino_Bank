"""
Simplified steam system model for waste-heat-recovery boilers (BOF/EAF
off-gas heat recovery, blast furnace stove exhaust) feeding site steam
demand / turbo-generators.

Uses a linearised steam-table approximation (sufficient for plant-level
energy balances; swap in CoolProp/IAPWS-IF97 for certification-grade
thermodynamics).
"""
from __future__ import annotations

from dataclasses import dataclass

WATER_CP_KJ_PER_KGK = 4.186
LATENT_HEAT_VAPORIZATION_KJ_PER_KG = 2257.0  # at 1 atm, approx for engineering use
STEAM_CP_KJ_PER_KGK = 2.08


@dataclass
class SteamState:
    pressure_bar: float
    temperature_c: float
    mass_flow_kg_per_s: float
    quality: float = 1.0  # 1.0 = dry saturated/superheated, <1 = wet steam


def saturation_temperature_c(pressure_bar: float) -> float:
    """Rough Antoine-style saturation temperature approximation for water,
    valid roughly 1-100 bar (engineering approximation, not IAPWS-grade).
    """
    import math
    p_kpa = pressure_bar * 100.0
    # Antoine equation coefficients for water (kPa, C), valid ~1-200 kPa;
    # extended here for plant engineering approximations up to ~100 bar.
    a, b, c = 8.07131, 1730.63, 233.426  # mmHg/degC units variant transformed below
    p_mmhg = p_kpa * 7.50062
    try:
        t = b / (a - math.log10(p_mmhg)) - c
    except ValueError:
        t = 100.0
    return max(20.0, t)


def steam_energy_content(feedwater_temp_c: float, state: SteamState) -> float:
    """Total thermal energy rate (kW) to raise feedwater to the given steam
    state: sensible heat to saturation + latent heat (scaled by quality) +
    any superheat above saturation.
    """
    t_sat = saturation_temperature_c(state.pressure_bar)
    sensible = WATER_CP_KJ_PER_KGK * max(0.0, t_sat - feedwater_temp_c)
    latent = LATENT_HEAT_VAPORIZATION_KJ_PER_KG * state.quality
    superheat = STEAM_CP_KJ_PER_KGK * max(0.0, state.temperature_c - t_sat)
    specific_enthalpy_gain = sensible + latent + superheat  # kJ/kg
    return specific_enthalpy_gain * state.mass_flow_kg_per_s  # kW


def waste_heat_recovery_steam_rate(off_gas_temp_c: float, off_gas_flow_kg_per_s: float,
                                    off_gas_cp_kj_per_kgK: float = 1.1,
                                    stack_temp_c: float = 180.0,
                                    boiler_efficiency: float = 0.75) -> float:
    """Estimate steam-raising capacity (kg/s of steam at ~40 bar/380C) from
    recovering heat out of hot process off-gas (BOF/EAF/BF stove exhaust)
    down to a stack temperature limited by acid dew point.
    """
    recoverable_kw = off_gas_flow_kg_per_s * off_gas_cp_kj_per_kgK * \
        max(0.0, off_gas_temp_c - stack_temp_c) * boiler_efficiency
    target_state = SteamState(pressure_bar=40.0, temperature_c=380.0, mass_flow_kg_per_s=1.0)
    specific_energy = steam_energy_content(feedwater_temp_c=105.0, state=target_state)
    if specific_energy <= 0:
        return 0.0
    return recoverable_kw / specific_energy
