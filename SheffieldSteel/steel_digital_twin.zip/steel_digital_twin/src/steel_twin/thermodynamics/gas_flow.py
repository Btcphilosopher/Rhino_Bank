"""
Gas flow and pressure modelling: orifice/valve flow, pipe pressure drop
(Darcy-Weisbach), and ideal gas density -- used for blast air, oxygen
lances, and furnace off-gas systems.
"""
from __future__ import annotations

import math

R_UNIVERSAL = 8.314  # J/(mol K)


def ideal_gas_density(pressure_pa: float, temperature_c: float,
                       molar_mass_kg_per_mol: float = 0.02896) -> float:
    """Ideal gas law density: rho = P*M / (R*T). Default molar mass is dry
    air (~28.96 g/mol).
    """
    t_k = temperature_c + 273.15
    return pressure_pa * molar_mass_kg_per_mol / (R_UNIVERSAL * t_k)


def orifice_flow_rate(discharge_coeff: float, area_m2: float,
                       upstream_pressure_pa: float, downstream_pressure_pa: float,
                       density_kg_per_m3: float) -> float:
    """Incompressible orifice/valve flow (sufficient for the pressure
    ratios typical of plant instrument air / cooling water lines):
        Q = Cd * A * sqrt(2*dP/rho)   [m^3/s]
    """
    dp = max(0.0, upstream_pressure_pa - downstream_pressure_pa)
    return discharge_coeff * area_m2 * math.sqrt(2 * dp / max(density_kg_per_m3, 1e-6))


def pipe_pressure_drop(friction_factor: float, length_m: float, diameter_m: float,
                        density_kg_per_m3: float, velocity_m_per_s: float) -> float:
    """Darcy-Weisbach pressure drop along a duct/pipe run:
        dP = f * (L/D) * rho * v^2 / 2   [Pa]
    """
    return friction_factor * (length_m / max(diameter_m, 1e-6)) * density_kg_per_m3 * \
        velocity_m_per_s ** 2 / 2.0


def reynolds_number(density_kg_per_m3: float, velocity_m_per_s: float,
                     diameter_m: float, dynamic_viscosity_pa_s: float) -> float:
    return density_kg_per_m3 * velocity_m_per_s * diameter_m / max(dynamic_viscosity_pa_s, 1e-9)


def colebrook_friction_factor(reynolds: float, relative_roughness: float,
                               iterations: int = 20) -> float:
    """Iterative solution of the Colebrook-White equation for the
    Darcy friction factor in turbulent flow.
    """
    if reynolds < 2300:
        return 64.0 / max(reynolds, 1e-6)  # laminar
    f = 0.02  # initial guess
    for _ in range(iterations):
        rhs = -2.0 * math.log10(relative_roughness / 3.7 + 2.51 / (reynolds * math.sqrt(f)))
        f_new = 1.0 / (rhs ** 2)
        if abs(f_new - f) < 1e-8:
            f = f_new
            break
        f = f_new
    return f
