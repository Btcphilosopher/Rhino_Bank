"""
Combustion systems: fuel heating values, stoichiometric air demand, and
adiabatic flame temperature -- used by the blast furnace hot-blast stoves,
reheat furnaces and the coke plant.
"""
from __future__ import annotations

from dataclasses import dataclass

# Lower heating values (LHV), MJ/Nm3 (gas) or MJ/kg (solid/liquid)
FUEL_LHV = {
    "coke_oven_gas": 17.5,     # MJ/Nm3
    "blast_furnace_gas": 3.3,  # MJ/Nm3 (low calorific, high N2/CO2)
    "natural_gas": 35.8,       # MJ/Nm3
    "coke": 28.0,              # MJ/kg
}

# Approximate stoichiometric air requirement (Nm3 air / Nm3 or kg fuel)
STOICHIOMETRIC_AIR = {
    "coke_oven_gas": 4.5,
    "blast_furnace_gas": 0.7,
    "natural_gas": 9.5,
    "coke": 7.6,               # Nm3 air / kg coke
}

AVERAGE_FLUE_GAS_CP = 1.35  # kJ/(Nm3 K), typical for combustion products


@dataclass
class CombustionResult:
    fuel: str
    fuel_flow: float
    excess_air_ratio: float
    heat_released_mj: float
    air_used_nm3: float
    flue_gas_nm3: float
    flame_temp_c: float


def combust_fuel(fuel: str, flow_rate: float, excess_air_ratio: float = 1.15,
                  air_preheat_c: float = 25.0) -> CombustionResult:
    """Simulate one tick of combustion for a given fuel and flow rate
    (Nm3/h for gases, kg/h for coke).

    excess_air_ratio: actual air / stoichiometric air (>1 = excess air,
    typical industrial burners run 1.05-1.3 for complete combustion with
    controlled NOx).
    """
    if fuel not in FUEL_LHV:
        raise ValueError(f"Unknown fuel '{fuel}'. Known: {list(FUEL_LHV)}")

    lhv = FUEL_LHV[fuel]
    heat_released = flow_rate * lhv  # MJ per hour
    stoich_air = STOICHIOMETRIC_AIR[fuel] * flow_rate
    air_used = stoich_air * excess_air_ratio
    flue_gas = flow_rate + air_used  # crude mass/volume balance approximation

    flame_temp = adiabatic_flame_temperature(
        heat_released_mj=heat_released, flue_gas_nm3=flue_gas,
        air_preheat_c=air_preheat_c,
    )

    return CombustionResult(
        fuel=fuel,
        fuel_flow=flow_rate,
        excess_air_ratio=excess_air_ratio,
        heat_released_mj=heat_released,
        air_used_nm3=air_used,
        flue_gas_nm3=flue_gas,
        flame_temp_c=flame_temp,
    )


def adiabatic_flame_temperature(heat_released_mj: float, flue_gas_nm3: float,
                                 ambient_temp_c: float = 25.0,
                                 air_preheat_c: float = 25.0) -> float:
    """Simplified adiabatic flame temperature:
        T_flame = Tambient + Q / (V_flue * cp_flue)
    with Q in kJ, V_flue in Nm3, cp in kJ/(Nm3 K).

    Air preheat (regenerative stoves / recuperators) raises the flame
    temperature roughly in proportion to the preheat above ambient.
    """
    if flue_gas_nm3 <= 0:
        return ambient_temp_c
    q_kj = heat_released_mj * 1000.0
    delta_t = q_kj / (flue_gas_nm3 * AVERAGE_FLUE_GAS_CP)
    preheat_gain = max(0.0, air_preheat_c - ambient_temp_c) * 0.6
    return ambient_temp_c + delta_t + preheat_gain


def thermal_efficiency(useful_heat_mj: float, fuel_input_mj: float) -> float:
    """Overall thermal efficiency (0-1) of a combustion process."""
    if fuel_input_mj <= 0:
        return 0.0
    return max(0.0, min(1.0, useful_heat_mj / fuel_input_mj))
