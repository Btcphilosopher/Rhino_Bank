"""
Simulation clock.

Drives the whole digital twin on a fixed logical tick (default: 1 simulated
minute) and can run for multi-year horizons at whatever wall-clock speed the
host can sustain (vectorised/headless) or in near-real-time for live
dashboard playback.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, List


@dataclass
class SimulationClock:
    """Logical clock for the plant simulation.

    Parameters
    ----------
    start_time:
        Wall-clock timestamp the simulation begins at (used for calendars,
        shift rosters, seasonal energy pricing, weather, etc).
    tick_seconds:
        Simulated seconds advanced per tick. 60 = minute-by-minute ticks,
        matching the "minute-by-minute simulation ticks" requirement.
    realtime_factor:
        If > 0, the clock sleeps between ticks so that
        `tick_seconds / realtime_factor` wall-clock seconds elapse per tick,
        enabling real-time (or slowed/accelerated) dashboard playback.
        If 0 (default), the clock runs as fast as the host allows
        ("headless"/batch mode) which is what multi-year runs require.
    """

    start_time: datetime = field(default_factory=datetime.utcnow)
    tick_seconds: float = 60.0
    realtime_factor: float = 0.0

    _tick_count: int = field(default=0, init=False)
    _listeners: List[Callable[["SimulationClock"], None]] = field(
        default_factory=list, init=False
    )

    @property
    def tick_count(self) -> int:
        return self._tick_count

    @property
    def now(self) -> datetime:
        return self.start_time + timedelta(seconds=self._tick_count * self.tick_seconds)

    @property
    def elapsed_hours(self) -> float:
        return self._tick_count * self.tick_seconds / 3600.0

    @property
    def elapsed_days(self) -> float:
        return self.elapsed_hours / 24.0

    @property
    def elapsed_years(self) -> float:
        return self.elapsed_days / 365.25

    def on_tick(self, callback: Callable[["SimulationClock"], None]) -> None:
        self._listeners.append(callback)

    def tick(self) -> None:
        """Advance the clock by one tick and pace real-time playback."""
        if self.realtime_factor > 0:
            wall_seconds = self.tick_seconds / self.realtime_factor
            t0 = time.monotonic()
        self._tick_count += 1
        for cb in self._listeners:
            cb(self)
        if self.realtime_factor > 0:
            elapsed = time.monotonic() - t0
            remaining = wall_seconds - elapsed
            if remaining > 0:
                time.sleep(remaining)

    def run(self, n_ticks: int) -> None:
        for _ in range(n_ticks):
            self.tick()

    def run_for(self, *, minutes: float = 0, hours: float = 0, days: float = 0,
                years: float = 0) -> None:
        total_seconds = (minutes * 60) + (hours * 3600) + (days * 86400) + (
            years * 365.25 * 86400
        )
        n_ticks = max(1, int(total_seconds / self.tick_seconds))
        self.run(n_ticks)

    def shift_of(self, dt: datetime | None = None) -> str:
        """Return which 8h shift (A/B/C) the given (or current) time falls in."""
        dt = dt or self.now
        hour = dt.hour
        if 6 <= hour < 14:
            return "A"
        if 14 <= hour < 22:
            return "B"
        return "C"
