"""
Shared process state.

`PlantState` is the single source of truth that every simulation engine
reads from and writes into on each tick. `StateStore` layers lightweight
event-sourcing on top: every mutation is captured as a diff so the plant
state at any past tick can be reconstructed (replayable production runs /
simulation snapshots), independent of the EventBus's rolling window.
"""
from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class PlantState:
    """Mutable nested dict of the entire plant's live process state.

    Namespaced by module, e.g.:
        state["blast_furnace_1"]["hearth_temp_c"]
        state["inventory"]["iron_ore_tonnes"]
        state["economics"]["steel_price_usd_per_tonne"]
    """

    tick: int = 0
    sim_time_iso: str = ""
    data: Dict[str, Any] = field(default_factory=dict)

    def get(self, namespace: str) -> Dict[str, Any]:
        return self.data.setdefault(namespace, {})

    def snapshot(self) -> Dict[str, Any]:
        return {
            "tick": self.tick,
            "sim_time_iso": self.sim_time_iso,
            "data": copy.deepcopy(self.data),
        }

    def to_json(self) -> str:
        return json.dumps(self.snapshot(), default=str)


class StateStore:
    """Event-sourced state history with periodic snapshotting.

    Keeps the full timeline replayable without holding every tick's full
    state in memory: full snapshots every `snapshot_interval` ticks, plus
    the diff for every tick in between.
    """

    def __init__(self, snapshot_interval: int = 1440):  # default: daily @1min ticks
        self.state = PlantState()
        self.snapshot_interval = snapshot_interval
        self._snapshots: Dict[int, Dict[str, Any]] = {}
        self._diffs: Dict[int, Dict[str, Any]] = {}
        self._last_full: Dict[str, Any] = {}

    def commit(self, tick: int, sim_time_iso: str) -> None:
        self.state.tick = tick
        self.state.sim_time_iso = sim_time_iso
        current = copy.deepcopy(self.state.data)
        if tick % self.snapshot_interval == 0 or not self._snapshots:
            self._snapshots[tick] = self.state.snapshot()
        else:
            self._diffs[tick] = _diff(self._last_full, current)
        self._last_full = current

    def export_snapshot(self, path: str | Path) -> None:
        Path(path).write_text(self.state.to_json())

    def load_snapshot(self, path: str | Path) -> None:
        payload = json.loads(Path(path).read_text())
        self.state = PlantState(
            tick=payload["tick"], sim_time_iso=payload["sim_time_iso"], data=payload["data"]
        )

    def nearest_snapshot_tick(self, tick: int) -> Optional[int]:
        candidates = [t for t in self._snapshots if t <= tick]
        return max(candidates) if candidates else None


def _diff(old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
    """Shallow-ish diff sufficient for telemetry auditing/replays."""
    changes: Dict[str, Any] = {}
    keys = set(old.keys()) | set(new.keys())
    for k in keys:
        if old.get(k) != new.get(k):
            changes[k] = new.get(k)
    return changes
