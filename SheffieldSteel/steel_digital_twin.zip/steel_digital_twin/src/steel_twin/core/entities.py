"""
Base entity classes shared by every physical asset in the plant:
equipment, sensors and actuators. Provides realistic instrumentation
behaviour (noise, drift, latency, faults) rather than idealised numbers.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional


class EquipmentStatus(str, Enum):
    RUNNING = "running"
    IDLE = "idle"
    STARVED = "starved"      # waiting on upstream material
    BLOCKED = "blocked"      # downstream congestion
    DEGRADED = "degraded"    # running but below nameplate performance
    MAINTENANCE = "maintenance"
    FAULTED = "faulted"
    SHUTDOWN = "shutdown"


@dataclass
class Equipment:
    """Base class for any physical asset (furnace, mill, conveyor, crane...).

    Tracks operating hours, a 0-1 health index, and status, which downstream
    predictive-maintenance and OEE calculations consume.
    """

    name: str
    nameplate_capacity: float  # tonnes/hour or equivalent throughput unit
    status: EquipmentStatus = EquipmentStatus.IDLE
    health_index: float = 1.0          # 1.0 = as-new, 0.0 = failed
    operating_hours: float = 0.0
    cumulative_cycles: int = 0
    install_date_tick: int = 0

    def step(self, dt_hours: float, running: bool) -> None:
        if running:
            self.operating_hours += dt_hours
            self.status = EquipmentStatus.RUNNING if self.status not in (
                EquipmentStatus.FAULTED, EquipmentStatus.MAINTENANCE
            ) else self.status

    @property
    def availability_derate(self) -> float:
        """Effective throughput multiplier implied by current health."""
        if self.status in (EquipmentStatus.FAULTED, EquipmentStatus.MAINTENANCE,
                            EquipmentStatus.SHUTDOWN):
            return 0.0
        # health below 0.6 starts derating output non-linearly
        if self.health_index >= 0.6:
            return 1.0
        return max(0.0, self.health_index / 0.6)

    @property
    def effective_capacity(self) -> float:
        return self.nameplate_capacity * self.availability_derate


@dataclass
class Sensor:
    """A simulated instrument reading a physical quantity from a 'true'
    process value, with realistic noise, slow drift and stochastic dropout,
    matching the requirement for 'instrumentation drift' and 'sensor
    simulation'.
    """

    name: str
    unit: str
    noise_std: float = 0.0          # gaussian measurement noise, in `unit`
    drift_per_hour: float = 0.0     # slow bias drift, in `unit`/hour
    dropout_probability: float = 0.0
    _drift_accum: float = field(default=0.0, init=False)
    last_value: Optional[float] = field(default=None, init=False)

    def read(self, true_value: float, dt_hours: float = 1 / 60) -> Optional[float]:
        if random.random() < self.dropout_probability:
            return self.last_value  # stale/held value, mimicking a comms dropout
        self._drift_accum += self.drift_per_hour * dt_hours
        noisy = true_value + self._drift_accum + random.gauss(0.0, self.noise_std)
        self.last_value = noisy
        return noisy

    def reset_drift(self) -> None:
        """Simulate instrument re-calibration."""
        self._drift_accum = 0.0


@dataclass
class Actuator:
    """A simulated final control element (valve, damper, VFD, lance) with
    finite slew rate and simple fault injection.
    """

    name: str
    min_value: float
    max_value: float
    slew_rate_per_min: float  # max change in output units per minute
    current_value: float = 0.0
    stuck: bool = False

    def command(self, setpoint: float, dt_minutes: float = 1.0) -> float:
        if self.stuck:
            return self.current_value
        setpoint = max(self.min_value, min(self.max_value, setpoint))
        max_delta = self.slew_rate_per_min * dt_minutes
        delta = max(-max_delta, min(max_delta, setpoint - self.current_value))
        self.current_value += delta
        return self.current_value
