"""
Industrial control-systems primitives: PID control loops and an alarm /
emergency-shutdown (ESD) manager with realistic control latency.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Deque, Dict, List, Optional, Tuple


@dataclass
class PIDController:
    """Standard velocity-form PID with anti-windup and simulated actuation
    latency (a ring buffer delays the command by `deadtime_ticks` ticks,
    matching real DCS/PLC scan + actuator response lag).
    """

    kp: float
    ki: float
    kd: float
    setpoint: float
    output_min: float = 0.0
    output_max: float = 100.0
    deadtime_ticks: int = 0

    _integral: float = field(default=0.0, init=False)
    _prev_error: Optional[float] = field(default=None, init=False)
    _delay_buffer: Deque[float] = field(default_factory=deque, init=False)

    def update(self, process_value: float, dt: float = 1.0) -> float:
        error = self.setpoint - process_value
        self._integral += error * dt
        derivative = 0.0 if self._prev_error is None else (error - self._prev_error) / dt
        self._prev_error = error

        raw_output = self.kp * error + self.ki * self._integral + self.kd * derivative
        output = max(self.output_min, min(self.output_max, raw_output))

        # anti-windup: back-calculate integral if saturated
        if raw_output != output and self.ki != 0:
            self._integral -= (raw_output - output) / self.ki

        if self.deadtime_ticks > 0:
            self._delay_buffer.append(output)
            if len(self._delay_buffer) > self.deadtime_ticks:
                return self._delay_buffer.popleft()
            return 0.0
        return output

    def reset(self) -> None:
        self._integral = 0.0
        self._prev_error = None
        self._delay_buffer.clear()


class AlarmSeverity(IntEnum):
    INFO = 0
    WARNING = 1
    ALARM = 2
    CRITICAL = 3  # triggers automated ESD logic


@dataclass
class AlarmDefinition:
    tag: str
    description: str
    low: Optional[float] = None
    high: Optional[float] = None
    severity: AlarmSeverity = AlarmSeverity.WARNING
    esd_action: Optional[str] = None  # what the ESD system does on trip


@dataclass
class AlarmEvent:
    tag: str
    description: str
    value: float
    severity: AlarmSeverity
    tick: int


class AlarmSystem:
    """Evaluates measured values against configured alarm limits and raises
    events on breach; CRITICAL alarms are escalated to emergency shutdown
    handlers registered on the equipment.
    """

    def __init__(self) -> None:
        self._defs: Dict[str, AlarmDefinition] = {}
        self._active: Dict[str, AlarmEvent] = {}
        self.log: List[AlarmEvent] = []

    def register(self, definition: AlarmDefinition) -> None:
        self._defs[definition.tag] = definition

    def evaluate(self, tag: str, value: float, tick: int) -> Optional[AlarmEvent]:
        d = self._defs.get(tag)
        if d is None:
            return None
        breached = (d.low is not None and value < d.low) or (
            d.high is not None and value > d.high
        )
        if breached:
            event = AlarmEvent(tag, d.description, value, d.severity, tick)
            self._active[tag] = event
            self.log.append(event)
            return event
        self._active.pop(tag, None)
        return None

    @property
    def active_alarms(self) -> List[AlarmEvent]:
        return list(self._active.values())

    def is_esd_required(self, tag: str) -> Tuple[bool, Optional[str]]:
        d = self._defs.get(tag)
        active = self._active.get(tag)
        if d and active and d.severity == AlarmSeverity.CRITICAL:
            return True, d.esd_action
        return False, None
