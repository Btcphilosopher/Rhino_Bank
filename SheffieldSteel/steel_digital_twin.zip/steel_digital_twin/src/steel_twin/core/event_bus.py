"""
Asynchronous, event-driven industrial data bus.

Every module (furnaces, casters, logistics, maintenance, economics...)
publishes structured `Event`s onto a shared `EventBus` instead of calling
each other directly. This is the backbone that lets independent simulation
engines stay decoupled while still reacting to one another (e.g. the
maintenance module reacting to a `equipment.vibration` event published by
the rolling mill, or the economics module reacting to `production.heat_tapped`).

The bus supports both synchronous callback subscribers (used heavily inside
a single-process simulation tick) and async subscribers / an async queue
consumer for the FastAPI/WebSocket dashboard layer.
"""
from __future__ import annotations

import asyncio
import fnmatch
import itertools
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Deque, Dict, List, Optional

_id_counter = itertools.count(1)


@dataclass
class Event:
    """A single fact broadcast on the industrial data bus."""

    topic: str
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: Optional[datetime] = None
    source: str = "unknown"
    id: int = field(default_factory=lambda: next(_id_counter))
    severity: str = "info"  # info | warning | alarm | critical

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "topic": self.topic,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "source": self.source,
            "severity": self.severity,
        }


Callback = Callable[[Event], None]


class EventBus:
    """Pub/sub bus with glob-style topic matching (e.g. 'furnace.*.temperature').

    Also retains a bounded in-memory event log (event sourcing lite) so that
    the state store / dashboard can replay recent history, and offers an
    asyncio.Queue bridge for streaming events out over WebSockets.
    """

    def __init__(self, history_size: int = 50_000):
        self._subscribers: Dict[str, List[Callback]] = defaultdict(list)
        self._history: Deque[Event] = deque(maxlen=history_size)
        self._async_queues: List[asyncio.Queue] = []

    # -- publishing -----------------------------------------------------
    def publish(self, topic: str, payload: Optional[Dict[str, Any]] = None,
                *, source: str = "unknown", severity: str = "info",
                timestamp: Optional[datetime] = None) -> Event:
        event = Event(
            topic=topic,
            payload=payload or {},
            timestamp=timestamp or datetime.utcnow(),
            source=source,
            severity=severity,
        )
        self._history.append(event)
        for pattern, callbacks in self._subscribers.items():
            if fnmatch.fnmatch(topic, pattern):
                for cb in callbacks:
                    cb(event)
        for q in self._async_queues:
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass
        return event

    # -- subscribing ------------------------------------------------------
    def subscribe(self, topic_pattern: str, callback: Callback) -> None:
        self._subscribers[topic_pattern].append(callback)

    def unsubscribe(self, topic_pattern: str, callback: Callback) -> None:
        if callback in self._subscribers.get(topic_pattern, []):
            self._subscribers[topic_pattern].remove(callback)

    def async_stream(self, maxsize: int = 1000) -> asyncio.Queue:
        """Return a fresh asyncio.Queue that receives every future event.

        Intended for the FastAPI WebSocket endpoint: one queue per connected
        client.
        """
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._async_queues.append(q)
        return q

    def close_stream(self, q: asyncio.Queue) -> None:
        if q in self._async_queues:
            self._async_queues.remove(q)

    # -- replay / query -----------------------------------------------------
    def history(self, topic_pattern: str = "*", limit: int = 200) -> List[Event]:
        matched = [e for e in self._history if fnmatch.fnmatch(e.topic, topic_pattern)]
        return matched[-limit:]

    def clear_history(self) -> None:
        self._history.clear()
