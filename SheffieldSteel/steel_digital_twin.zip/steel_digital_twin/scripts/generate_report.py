#!/usr/bin/env python3
"""
Runs a short simulation, then exercises the optimisation & expansion-
scenario tooling to produce a text engineering/operations report --
demonstrates the optimisation engine, Monte Carlo stress test, and
finance module end to end.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from steel_twin.plant.digital_twin import SteelworksDigitalTwin, PlantConfig  # noqa: E402
from steel_twin.optimization.monte_carlo import supply_chain_stress_test  # noqa: E402
from steel_twin.optimization.genetic import optimise_alloy_addition  # noqa: E402
from steel_twin.economics.finance import expansion_scenario_npv  # noqa: E402


def main() -> None:
    twin = SteelworksDigitalTwin(PlantConfig(seed=11))
    n_ticks = 2880  # 2 sim-days
    for _ in range(n_ticks):
        twin.tick()
    final = twin.last_snapshot

    print("=" * 70)
    print("STEEL DIGITAL TWIN — OPERATIONS REPORT")
    print("=" * 70)
    print(f"Simulated horizon: {n_ticks} ticks ({n_ticks/1440:.1f} days)")
    print(f"Steel shipped: {final['shipping']['shipped_total_t']:.0f} t")
    print(f"Gross margin: ${final['economics']['gross_margin']:,.0f}")
    print(f"CO2 emitted: {final['emissions']['total_co2_tonnes']:.0f} t "
          f"({final['emissions']['carbon_intensity_t_co2_per_t_steel']:.3f} t/t)")
    print(f"Active alarms: {len(final['active_alarms'])}")

    print("\n--- Maintenance backlog (top 5) ---")
    for order in final["maintenance_backlog"][:5]:
        print(f"  {order['equipment']:<20} RUL={order['rul_hours']:>8.1f}h  {order['action']}")

    print("\n--- Monte Carlo supply-chain stress test (2000 trials, 1yr horizon) ---")
    mc = supply_chain_stress_test(n_trials=2000, seed=3)
    print(f"  Mean annual output: {mc.mean:,.0f} t")
    print(f"  P5 / P50 / P95:     {mc.p5:,.0f} / {mc.p50:,.0f} / {mc.p95:,.0f} t")
    print(f"  Value at risk (95%): {mc.var_95:,.0f} t below mean")

    print("\n--- Genetic algorithm: alloy addition optimisation (SAE 1045 trim) ---")
    ga_result = optimise_alloy_addition(
        target_composition={"Mn": 0.75, "Si": 0.25},
        current_composition={"Mn": 0.30, "Si": 0.02},
        element_costs_usd_per_kg={"Mn": 1.8, "Si": 1.2},
        heat_mass_t=150.0,
    )
    print(f"  Best fitness (−cost−penalty): {ga_result.best_fitness:.1f}")
    print(f"  Recommended additions (kg):   Mn={ga_result.best_chromosome[0]:.1f}, "
          f"Si={ga_result.best_chromosome[1]:.1f}")

    print("\n--- Expansion scenario: new rolling mill line ---")
    scenario = expansion_scenario_npv(
        capex_usd=180_000_000, incremental_annual_ebitda_usd=32_000_000,
        years=15, discount_rate=0.09,
    )
    for k, v in scenario.items():
        print(f"  {k}: {v:,}")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
