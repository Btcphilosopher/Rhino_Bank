#!/usr/bin/env python3
"""
CLI entrypoint for the Steel Digital Twin.

Usage:
    python scripts/run_simulation.py --ticks 10080                 # headless, ~1 week @1min ticks
    python scripts/run_simulation.py --years 1 --route eaf          # multi-year mini-mill run
    python scripts/run_simulation.py --dashboard --port 8000        # live SCADA dashboard
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from steel_twin.plant.digital_twin import SteelworksDigitalTwin, PlantConfig  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Steel Digital Twin simulator")
    parser.add_argument("--ticks", type=int, default=1440, help="Number of 1-minute ticks to run headless")
    parser.add_argument("--days", type=float, default=None, help="Run for N simulated days instead of --ticks")
    parser.add_argument("--years", type=float, default=None, help="Run for N simulated years instead of --ticks")
    parser.add_argument("--route", choices=["integrated", "eaf"], default="integrated")
    parser.add_argument("--grade", default="SAE_1045_automotive")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--dashboard", action="store_true", help="Launch the live FastAPI/WebSocket dashboard")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--report", type=str, default=None, help="Write a JSON summary report to this path")
    args = parser.parse_args()

    config = PlantConfig(steel_route=args.route, grade_key=args.grade, seed=args.seed)

    if args.dashboard:
        import uvicorn
        from steel_twin.dashboard.app import create_app
        app = create_app(config)
        uvicorn.run(app, host=args.host, port=args.port)
        return

    twin = SteelworksDigitalTwin(config)

    if args.years:
        n_ticks = int(args.years * 365.25 * 24 * 60)
    elif args.days:
        n_ticks = int(args.days * 24 * 60)
    else:
        n_ticks = args.ticks

    print(f"Running headless simulation for {n_ticks} ticks "
          f"({n_ticks / 1440:.1f} sim-days) on the '{args.route}' route...")

    checkpoint = max(1, n_ticks // 20)
    for i in range(n_ticks):
        snapshot = twin.tick()
        if (i + 1) % checkpoint == 0 or i == n_ticks - 1:
            pct = 100 * (i + 1) / n_ticks
            print(f"  [{pct:5.1f}%] tick={snapshot['tick']:>8} "
                  f"sim_time={snapshot['sim_time']} "
                  f"shipped_total={snapshot['shipping']['shipped_total_t']:.0f}t "
                  f"margin=${snapshot['economics']['gross_margin']:,.0f} "
                  f"co2={snapshot['emissions']['total_co2_tonnes']:.0f}t")

    final = twin.last_snapshot
    print("\n=== Run complete ===")
    print(json.dumps({
        "shipped_total_t": final["shipping"]["shipped_total_t"],
        "gross_margin_usd": final["economics"]["gross_margin"],
        "total_co2_tonnes": final["emissions"]["total_co2_tonnes"],
        "carbon_intensity": final["emissions"]["carbon_intensity_t_co2_per_t_steel"],
        "active_alarms": len(final["active_alarms"]),
    }, indent=2))

    if args.report:
        Path(args.report).write_text(json.dumps(final, indent=2, default=str))
        print(f"\nFull snapshot written to {args.report}")


if __name__ == "__main__":
    main()
