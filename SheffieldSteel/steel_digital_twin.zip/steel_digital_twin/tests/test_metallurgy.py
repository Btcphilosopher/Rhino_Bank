from steel_twin.metallurgy.chemistry import (
    AlloyComposition, SlagChemistry, oxygen_for_decarburization,
)
from steel_twin.metallurgy.properties import predict_mechanical_properties
from steel_twin.metallurgy.phase_transform import (
    jmak_fraction_transformed, cooling_rate_to_microstructure,
)
from steel_twin.metallurgy.grades import STEEL_GRADES, grade_by_name


def test_carbon_equivalent_increases_with_carbon():
    low = AlloyComposition(C=0.1, Mn=0.5)
    high = AlloyComposition(C=0.6, Mn=0.5)
    assert high.carbon_equivalent_iiw() > low.carbon_equivalent_iiw()


def test_slag_basicity():
    slag = SlagChemistry(CaO=40, SiO2=10)
    assert slag.basicity_b2() == 4.0


def test_oxygen_for_decarburization_scales_with_carbon_removed():
    o2_small = oxygen_for_decarburization(100, 4.5, 4.0)
    o2_large = oxygen_for_decarburization(100, 4.5, 0.05)
    assert o2_large > o2_small > 0


def test_mechanical_properties_carbon_raises_hardness_and_strength():
    low_c = predict_mechanical_properties(AlloyComposition(C=0.1))
    high_c = predict_mechanical_properties(AlloyComposition(C=0.8))
    assert high_c.hardness_hb > low_c.hardness_hb
    assert high_c.tensile_strength_mpa > low_c.tensile_strength_mpa
    # ductility trade-off: higher carbon => lower elongation
    assert high_c.elongation_pct < low_c.elongation_pct


def test_hall_petch_grain_refinement_raises_yield():
    coarse = predict_mechanical_properties(AlloyComposition(C=0.2), grain_size_mm=0.1)
    fine = predict_mechanical_properties(AlloyComposition(C=0.2), grain_size_mm=0.005)
    assert fine.yield_strength_mpa > coarse.yield_strength_mpa


def test_jmak_bounds():
    assert jmak_fraction_transformed(0, k=0.01, n=2) == 0.0
    x = jmak_fraction_transformed(100, k=0.001, n=2)
    assert 0.0 <= x <= 1.0


def test_cooling_rate_drives_martensite_fraction():
    fast = cooling_rate_to_microstructure(30.0, carbon_pct=0.4)
    slow = cooling_rate_to_microstructure(0.2, carbon_pct=0.4)
    assert fast.martensite_fraction > slow.martensite_fraction
    assert fast.grain_size_mm < slow.grain_size_mm


def test_grade_catalogue_has_required_families():
    families = {g.family for g in STEEL_GRADES.values()}
    for expected in ["structural", "stainless", "tool_steel", "automotive", "military", "aerospace"]:
        assert expected in families
    assert grade_by_name("A36_structural").name == "A36 Structural"
