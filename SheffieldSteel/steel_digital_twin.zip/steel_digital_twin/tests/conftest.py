import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


@pytest.fixture
def twin():
    from steel_twin.plant.digital_twin import SteelworksDigitalTwin, PlantConfig
    return SteelworksDigitalTwin(PlantConfig(seed=1))
