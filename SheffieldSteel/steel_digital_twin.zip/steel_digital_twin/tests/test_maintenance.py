import numpy as np

from steel_twin.maintenance.predictive import (
    WeibullDegradationModel, EWMAAnomalyDetector, RemainingUsefulLifeForecaster,
    MaintenanceScheduleOptimizer,
)
from steel_twin.ml.anomaly_models import IsolationForestLite, ReconstructionAnomalyDetector
from steel_twin.ml.forecasting import ExponentialSmoothingForecaster, LinearTrendForecaster
from steel_twin.ml.quality_prediction import QualityPredictor


def test_weibull_survival_decreases_with_age():
    model = WeibullDegradationModel(eta_hours=10000, beta=2.2)
    assert model.survival(0) == 1.0
    assert model.survival(5000) > model.survival(15000)


def test_weibull_expected_remaining_life_decreases_with_age():
    model = WeibullDegradationModel(eta_hours=10000, beta=2.2)
    rul_early = model.expected_remaining_life(1000)
    rul_late = model.expected_remaining_life(9000)
    assert rul_early > rul_late


def test_ewma_detects_shift():
    detector = EWMAAnomalyDetector(lam=0.3, n_sigma=3.0)
    for _ in range(50):
        detector.update(10 + np.random.normal(0, 0.2))
    result = detector.update(50.0)  # huge spike
    assert result["is_anomaly"] is True


def test_rul_forecaster_produces_blended_estimate():
    model = WeibullDegradationModel(eta_hours=5000, beta=2.0, equipment_name="test_eq")
    forecaster = RemainingUsefulLifeForecaster(model)
    for i in range(20):
        forecaster.observe(i * 10, max(0.05, 1.0 - i * 0.04))
    forecast = forecaster.forecast(operating_hours=200)
    assert forecast["blended_rul_hours"] >= 0
    assert forecast["equipment"] == "test_eq"


def test_maintenance_backlog_prioritises_low_rul():
    optimizer = MaintenanceScheduleOptimizer()
    optimizer.set_criticality("bf1", 2.0)
    backlog = optimizer.build_backlog([
        {"equipment": "bf1", "blended_rul_hours": 10},
        {"equipment": "caster1", "blended_rul_hours": 5000},
    ])
    assert backlog[0].equipment == "bf1"


def test_isolation_forest_flags_outlier():
    rng = np.random.default_rng(0)
    normal = rng.normal(0, 1, size=(200, 2))
    outlier = np.array([[20, 20]])
    forest = IsolationForestLite(n_trees=50, seed=0).fit(normal)
    scores_normal = forest.anomaly_score(normal[:20])
    scores_outlier = forest.anomaly_score(outlier)
    assert scores_outlier[0] > scores_normal.mean()


def test_reconstruction_anomaly_detector_flags_outlier():
    rng = np.random.default_rng(1)
    normal = rng.normal(0, 1, size=(300, 4))
    detector = ReconstructionAnomalyDetector(n_components=2).fit(normal)
    outlier = np.array([[10, -10, 10, -10]])
    assert detector.predict(outlier)[0] == True  # noqa: E712


def test_exponential_smoothing_forecast_trend():
    series = [float(x) for x in range(20)]  # perfect linear trend
    model = ExponentialSmoothingForecaster(alpha=0.5, beta=0.5).fit(series)
    forecast = model.forecast(5)
    assert forecast[0] > series[-1]
    assert np.all(np.diff(forecast) > 0)


def test_linear_trend_forecaster_recovers_slope():
    x = list(range(50))
    y = [3 * xi + 7 for xi in x]
    model = LinearTrendForecaster().fit(x, y)
    assert abs(model.slope - 3) < 1e-6
    assert abs(model.intercept - 7) < 1e-6


def test_quality_predictor_end_to_end():
    predictor = QualityPredictor(ridge_lambda=1.0)
    X, y = QualityPredictor.synthesize_training_data(n_samples=500, seed=1)
    predictor.fit(X, y)
    prediction = predictor.predict([0.2, 0.5, 0.02, 0.02, 10, 1620, 18, 3.0, 0.9])
    assert 0.0 <= prediction.defect_probability <= 1.0
    assert prediction.predicted_tensile_mpa > 0
