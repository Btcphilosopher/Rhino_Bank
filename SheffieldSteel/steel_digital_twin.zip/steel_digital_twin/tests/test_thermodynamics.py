import numpy as np

from steel_twin.thermodynamics.heat_transfer import (
    conduction_flux, convection_flux, radiation_flux,
    lumped_cooling_curve, average_cooling_rate_c_per_s,
)
from steel_twin.thermodynamics.combustion import combust_fuel, thermal_efficiency
from steel_twin.thermodynamics.gas_flow import (
    ideal_gas_density, orifice_flow_rate, pipe_pressure_drop, colebrook_friction_factor,
)


def test_conduction_flux_positive_for_positive_gradient():
    q = conduction_flux(k_w_per_mK=50, area_m2=2, dt_c=100, thickness_m=0.1)
    assert q > 0


def test_convection_and_radiation_flux_scale_with_temperature_difference():
    q_conv_small = convection_flux(25, 1, 100, 25)
    q_conv_large = convection_flux(25, 1, 500, 25)
    assert q_conv_large > q_conv_small

    q_rad = radiation_flux(1, 800, 25)
    assert q_rad > 0


def test_lumped_cooling_curve_monotonic_decrease():
    t, temp = lumped_cooling_curve(
        initial_temp_c=1500, ambient_temp_c=25, mass_kg=5000,
        specific_heat_j_per_kgK=680, surface_area_m2=8, h_w_per_m2K=350,
        emissivity=0.85, duration_s=1800,
    )
    assert temp[0] > temp[-1]
    assert np.all(np.diff(temp) <= 1e-6)


def test_average_cooling_rate_positive():
    t, temp = lumped_cooling_curve(1500, 25, 5000, 680, 8, 350, 0.85, 1800)
    rate = average_cooling_rate_c_per_s(t, temp)
    assert rate > 0


def test_combustion_flame_temp_reasonable():
    result = combust_fuel("natural_gas", flow_rate=1000, excess_air_ratio=1.15)
    assert result.heat_released_mj > 0
    assert 500 < result.flame_temp_c < 3000


def test_thermal_efficiency_bounds():
    assert thermal_efficiency(80, 100) == 0.8
    assert thermal_efficiency(150, 100) == 1.0  # clipped
    assert thermal_efficiency(10, 0) == 0.0


def test_ideal_gas_density_positive():
    rho = ideal_gas_density(101325, 25)
    assert 1.0 < rho < 1.5  # ~1.18 kg/m3 for air at 25C


def test_orifice_flow_increases_with_pressure_drop():
    low = orifice_flow_rate(0.6, 0.01, 200000, 190000, 1.2)
    high = orifice_flow_rate(0.6, 0.01, 300000, 100000, 1.2)
    assert high > low


def test_pipe_pressure_drop_scales_with_velocity_squared():
    dp1 = pipe_pressure_drop(0.02, 100, 0.5, 1000, 1.0)
    dp2 = pipe_pressure_drop(0.02, 100, 0.5, 1000, 2.0)
    assert dp2 == 4 * dp1


def test_colebrook_laminar_regime():
    f = colebrook_friction_factor(1000, 0.0001)
    assert abs(f - 64.0 / 1000) < 1e-9
