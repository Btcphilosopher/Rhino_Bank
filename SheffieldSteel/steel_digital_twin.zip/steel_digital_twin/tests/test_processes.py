def test_plant_ticks_without_error(twin):
    snapshot = twin.tick()
    assert snapshot["tick"] == 1
    assert "blast_furnace" in snapshot
    assert "economics" in snapshot


def test_plant_runs_multiple_ticks_and_accumulates_production(twin):
    for _ in range(120):  # 2 sim-hours
        twin.tick()
    final = twin.last_snapshot
    assert final["tick"] == 120
    assert final["port"]["total_unloaded_t"] >= 0
    assert final["rail"]["delivered_total_t"] >= 0


def test_buffers_never_go_negative(twin):
    for _ in range(500):
        twin.tick()
    assert twin.yard.ore.level >= 0
    assert twin.blast_furnace.hot_metal_buffer.level >= 0
    assert twin.bof.liquid_steel_buffer.level >= 0
    assert twin.caster.slab_buffer.level >= 0
    assert twin.rolling_mill.product_buffer.level >= 0


def test_eaf_route_config():
    from steel_twin.plant.digital_twin import SteelworksDigitalTwin, PlantConfig
    twin = SteelworksDigitalTwin(PlantConfig(steel_route="eaf", seed=2))
    for _ in range(50):
        snapshot = twin.tick()
    assert snapshot["route"] == "eaf"
    assert "steel_produced_t" in snapshot["eaf"]


def test_emissions_ledger_accumulates(twin):
    for _ in range(200):
        twin.tick()
    summary = twin.emissions.summary()
    assert summary["total_co2_tonnes"] >= 0
