import numpy as np

from steel_twin.optimization.genetic import GeneticAlgorithm
from steel_twin.optimization.monte_carlo import monte_carlo_simulate, supply_chain_stress_test
from steel_twin.optimization.scheduler import (
    WorkforceScheduler, MaintenanceWindowOptimizer, LogisticsRouteOptimizer,
)


def test_genetic_algorithm_finds_sphere_minimum():
    # maximise -sum(x^2) => optimum at x=0 for all genes
    def fitness(x):
        return -float(np.sum(x ** 2))

    ga = GeneticAlgorithm(fitness, bounds=[(-10, 10)] * 3, population_size=40, seed=0)
    result = ga.run(generations=60)
    assert result.best_fitness > -1.0  # close to the true optimum of 0
    assert np.all(np.abs(result.best_chromosome) < 2.0)


def test_monte_carlo_summary_statistics():
    def scenario(rng):
        return rng.normal(100, 10)

    result = monte_carlo_simulate(scenario, n_trials=3000, seed=1)
    assert 95 < result.mean < 105
    assert result.p5 < result.p50 < result.p95


def test_supply_chain_stress_test_reduces_output_below_baseline():
    result = supply_chain_stress_test(n_trials=500, base_annual_output_t=1_000_000, seed=2)
    assert result.mean <= 1_000_000
    assert result.p5 <= result.p50


def test_workforce_scheduler_flags_shortfall():
    scheduler = WorkforceScheduler({"A": {"operator": 3}})
    assignments, warnings = scheduler.schedule([
        {"id": "w1", "role": "operator", "consecutive_shifts": 0},
    ])
    assert len(assignments) == 1
    assert any("short" in w for w in warnings)


def test_maintenance_window_optimizer_places_urgent_work_first():
    class FakeOrder:
        def __init__(self, equipment, rul):
            self.equipment = equipment
            self.rul_hours = rul

    optimizer = MaintenanceWindowOptimizer(crew_capacity=100, planning_horizon_hours=48)
    backlog = [FakeOrder("bf1", 20), FakeOrder("caster1", 500)]
    windows = optimizer.schedule(backlog)
    urgent_window = next(w for w in windows if w.equipment == "bf1")
    assert urgent_window.start_hour_offset <= 12


def test_logistics_route_optimizer_prefers_cheapest_feasible():
    routes = [
        {"name": "rail_a", "capacity_t_per_day": 5000, "cost_usd_per_t": 12},
        {"name": "rail_b", "capacity_t_per_day": 6000, "cost_usd_per_t": 9},
    ]
    optimizer = LogisticsRouteOptimizer()
    chosen = optimizer.choose_route(routes, tonnes_to_move=4000)
    assert chosen["name"] == "rail_b"
    assert chosen["feasible"] is True
