import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

import { getDefaultSOFRCurve, getMarketBenchmarks, getSwaptionVolGrid } from './src/engine/syntheticMarket';
import { priceSwap } from './src/engine/swapPricer';
import { calculateFuturesHedge } from './src/engine/hedgeEngine';
import { priceSwaption } from './src/engine/swaptionPricer';
import { runMonteCarloShortRate, calculatePnLAttribution } from './src/engine/analyticsEngine';
import { SwapTradeSpec } from './src/types/swap';

const SIGNATURE_DEAL: SwapTradeSpec = {
  tradeId: 'RHINO-DEAL-10Y-SOFR',
  counterparty: 'BARCLAYS_CAPITAL_NY',
  notional: 100000000,
  currency: 'USD',
  type: 'SOFR_OIS',
  direction: 'PAY_FIXED',
  effectiveDate: '2026-09-24',
  maturityTenor: '10Y',
  maturityDate: '2036-09-24',
  fixedRate: 0.041875,
  floatingIndex: 'SOFR',
  fixedLegFrequency: 'SEMI_ANNUAL',
  floatingLegFrequency: 'QUARTERLY',
  fixedDayCount: '30/360',
  floatingDayCount: 'ACT/360',
  businessDayConvention: 'MODIFIED_FOLLOWING',
  calendar: 'USNY',
  paymentLagDays: 2,
  resetLagDays: 0,
  compoundingMethod: 'DAILY_COMPOUNDED',
  notionalAmortization: 'BULLET',
  collateralCurrency: 'USD',
  tradeDate: '2026-09-22',
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Endpoints
  app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', system: 'RHINOSWAPS.OS Quantitative Engine v3.6', time: new Date().toISOString() });
  });

  app.get('/api/market', (req, res) => {
    res.json({ benchmarks: getMarketBenchmarks(), dataStatus: 'SYNTHETIC_DETERMINISTIC' });
  });

  app.get('/api/curves/sofr', (req, res) => {
    const curve = getDefaultSOFRCurve();
    res.json(curve.definition);
  });

  app.get('/api/signature-deal', (req, res) => {
    const curve = getDefaultSOFRCurve();
    const result = priceSwap(SIGNATURE_DEAL, curve, curve);
    const hedge = calculateFuturesHedge(SIGNATURE_DEAL.tradeId, result.valuation.dv01);

    res.json({
      trade: SIGNATURE_DEAL,
      valuation: result.valuation,
      schedule: result.schedule,
      hedge,
    });
  });

  app.post('/api/pricing', (req, res) => {
    const tradeSpec: SwapTradeSpec = req.body.trade || SIGNATURE_DEAL;
    const curve = getDefaultSOFRCurve();
    const result = priceSwap(tradeSpec, curve, curve);
    res.json(result);
  });

  app.get('/api/swaptions', (req, res) => {
    const volGrid = getSwaptionVolGrid();
    const sampleSwaption = priceSwaption(
      {
        tradeId: 'SWAPTION-1Y10Y',
        type: 'PAYER',
        expiryTenor: '1Y',
        underlyingTenor: '10Y',
        notional: 100000000,
        strike: 0.041875,
        impliedVol: 0.0081, // 81bps normal vol
        modelType: 'BACHELIER_NORMAL',
      },
      0.041875,
      8.4312
    );

    res.json({ volGrid, sampleSwaption });
  });

  app.get('/api/monte-carlo', (req, res) => {
    const paths = parseInt(req.query.paths as string, 10) || 1000;
    const model = (req.query.model as 'Vasicek' | 'Hull-White' | 'CIR') || 'Hull-White';
    const result = runMonteCarloShortRate(model, paths);
    res.json(result);
  });

  app.get('/api/pnl-attribution', (req, res) => {
    const attribution = calculatePnLAttribution(100000000);
    res.json(attribution);
  });

  // Vite middleware for dev or static server for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RHINOSWAPS.OS] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[RHINOSWAPS.OS] Failed to start server:', err);
});
