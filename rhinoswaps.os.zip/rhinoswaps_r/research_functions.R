# RHINOSWAPS.OS - Institutional R Research & Validation Module
# RhinoBank / RhinoQuant Quantitative Research Layer

library(data.table)
library(stats)

#' Calculate Par Swap Rate and Annuity
#' @param discount_factors Vector of discount factors
#' @param accrual_fractions Vector of accrual period year fractions
#' @return List containing par_rate and annuity
price_swap <- function(discount_factors, accrual_fractions) {
  annuity <- sum(discount_factors * accrual_fractions)
  df_start <- 1.0
  df_end <- discount_factors[length(discount_factors)]
  par_rate <- (df_start - df_end) / annuity
  return(list(par_rate = par_rate, annuity = annuity))
}

#' Calculate DV01 (Dollar Value of 01)
#' @param notional Swap notional amount
#' @param fixed_rate Fixed rate of swap
#' @param discount_factors Vector of discount factors
#' @param accrual_fractions Vector of accrual period year fractions
#' @return DV01 value in currency units
calculate_dv01 <- function(notional, fixed_rate, discount_factors, accrual_fractions) {
  # +1bp parallel shift on zero curve
  tenors <- cumsum(accrual_fractions)
  zero_rates <- -log(discount_factors) / tenors
  shifted_zeros <- zero_rates + 0.0001
  shifted_dfs <- exp(-shifted_zeros * tenors)
  
  annuity_base <- sum(discount_factors * accrual_fractions)
  annuity_shifted <- sum(shifted_dfs * accrual_fractions)
  
  pv_base <- notional * (fixed_rate * annuity_base)
  pv_shifted <- notional * (fixed_rate * annuity_shifted)
  
  dv01 <- abs(pv_shifted - pv_base)
  return(dv01)
}

#' Calculate Swap Curve Principal Components Analysis (PCA)
#' @param yield_matrix Matrix of historical yields (columns = tenors, rows = dates)
#' @return List containing eigenvalues, eigenvectors (Level, Slope, Curvature), and variance explained
calculate_pca <- function(yield_matrix) {
  pca_res <- prcomp(yield_matrix, center = TRUE, scale. = FALSE)
  variance_explained <- (pca_res$sdev^2) / sum(pca_res$sdev^2)
  return(list(
    eigenvectors = pca_res$rotation[, 1:3], # PC1: Level, PC2: Slope, PC3: Curvature
    variance_explained = variance_explained[1:3]
  ))
}

cat("[RHINOSWAPS.OS R Module] Loaded R research functions successfully.\n")
