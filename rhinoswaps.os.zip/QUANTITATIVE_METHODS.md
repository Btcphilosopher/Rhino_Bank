# QUANTITATIVE_METHODS.md

## Mathematical Methods & Formulas in RHINOSWAPS.OS

### 1. Swap Annuity & Par Rate
For a fixed leg with accrual fractions $\alpha_i$ and discount factors $\text{DF}_i$:
$$\text{Annuity} (A) = \sum_{i=1}^N \alpha_i \cdot \text{DF}(t_i)$$

The Par Swap Rate $S_{\text{par}}$ solves $PV_{\text{Fixed}} = PV_{\text{Float}}$:
$$S_{\text{par}} = \frac{\text{DF}(t_0) - \text{DF}(t_N)}{A} = \frac{\text{PV}_{\text{Float}}}{N \cdot A}$$

### 2. Daily SOFR Compounding
Over an observation period with daily SOFR fixings $r_k$ and daily day count fractions $d_k = \frac{1}{360}$:
$$\text{Compounded Index} = \left[ \prod_{k=1}^M \left(1 + \frac{r_k \cdot d_k}{360}\right) \right] - 1$$
$$\text{Annualized Rate} R_{\text{SOFR}} = \text{Compounded Index} \times \frac{360}{\sum d_k}$$

### 3. Risk Measures
#### DV01 (Dollar Value of a Basis Point)
$$\text{DV01} = -\left[ PV(C + 1\text{bp}) - PV(C) \right]$$

#### Second-Order Convexity
$$\text{Convexity} = \frac{PV(C + \Delta) + PV(C - \Delta) - 2PV(C)}{\Delta^2}$$

### 4. Swaption Pricing Models
#### Black-76 (Lognormal Volatility $\sigma_L$)
$$C_{\text{Black}} = N \cdot A \cdot \left[ F \cdot N(d_1) - K \cdot N(d_2) \right]$$
$$d_1 = \frac{\ln(F/K) + \frac{1}{2}\sigma_L^2 T}{\sigma_L \sqrt{T}}, \quad d_2 = d_1 - \sigma_L \sqrt{T}$$

#### Bachelier / Normal Model (Normal Volatility $\sigma_N$)
$$C_{\text{Bachelier}} = N \cdot A \cdot \left[ (F - K) N(d) + \sigma_N \sqrt{T} n(d) \right], \quad d = \frac{F - K}{\sigma_N \sqrt{T}}$$

### 5. Short-Rate Models (Hull-White / Vasicek)
Vasicek SDE:
$$dr_t = k(\theta - r_t) dt + \sigma dW_t$$

Hull-White SDE (Time-dependent theta $\theta(t)$ matching initial yield curve):
$$dr_t = [\theta(t) - a r_t] dt + \sigma dW_t$$
