# RHINOSWAPS.OS

### USD INTEREST-RATE SWAPS • OIS • SOFR • BASIS • CURVES • PRICING • HEDGING • RISK
**Institutional Quantitative Operating System for Fixed-Income Derivatives**
*A RhinoBank / RhinoQuant Product*

---

## 1. Executive Summary

A swap is not merely a contract. A swap is a position on:
$$\text{TIME} + \text{INTEREST} + \text{CURVE} + \text{FUNDING} + \text{VOLATILITY} + \text{CREDIT} + \text{COLLATERAL} + \text{LIQUIDITY}$$

**RHINOSWAPS.OS** is an institutional quantitative operating system designed for rates traders, quantitative analysts, risk managers, and fixed-income engineers to price, value, hedge, stress-test, and research USD interest-rate swaps, SOFR OIS, basis swaps, swaptions, and rate curves.

---

## 2. Quantitative Workflow Architecture

```
TRADE → CONVENTIONS → SCHEDULE → CURVE → DISCOUNT → FORECAST → CASH FLOWS → PV → PAR RATE → DV01 → CONVEXITY → SCENARIO → HEDGE → PORTFOLIO RISK
```

1. **Trade Specification**: 20+ parameters (Notional, Tenor, Direction, Index, Day Count, Business Day conventions, Lags, Compounding).
2. **Schedule Engine**: Exact business day adjustments (Modified Following, Following, Preceding), USNY/USGS calendars, Actual/360, 30/360, Actual/365 accruals, stub handling.
3. **SOFR OIS Engine**: Daily SOFR compounding observations, compound index construction, annualized effective rates, lookback/lockout.
4. **Curve Engine**: Bootstrapping USD SOFR Discount and Forecast Curves using Monotonic Cubic Spline, Log-Linear, Linear, and Nelson-Siegel-Svensson interpolations.
5. **Par Swap Rate & PV**: Exact annuity valuation $A = \sum \alpha_i \cdot \text{DF}_i$, solving $PV_{\text{Fixed}} = PV_{\text{Float}}$ for $S_{\text{Par}}$.
6. **Risk Engine**: Finite-difference parallel $\pm 1\text{bp}$ revaluation DV01, 8-bucket key-rate DV01s (2Y, 3Y, 5Y, 7Y, 10Y, 15Y, 20Y, 30Y), second-order convexity $\frac{PV(\Delta) + PV(-\Delta) - 2PV(0)}{\Delta^2}$.
7. **Hedging Engine**: CME SOFR Futures strip (SR1/SR3) and Treasury futures hedge optimizer, contract count calculation, residual curve risk.
8. **Volatility & Swaptions**: Black-76 lognormal model vs. Bachelier normal model, full Greeks ($\Delta, \Gamma, \mathcal{V}, \Theta, \rho$), SABR volatility surfaces.
9. **Analytics & Scenarios**: Carry & Roll lab, Swap Spreads (Swap minus Treasury), Basis Swaps, Monte Carlo short-rate simulation (Vasicek, Hull-White, CIR), P&L Attribution.

---

## 3. Technology Stack

* **Quantitative Engine**: TypeScript (browser & server), Python 3.12+ (`NumPy`, `SciPy`, `pandas`, `Polars`, `Pydantic`, `FastAPI`).
* **Research Layer**: R (`data.table`, `stats`, `ggplot2`) for curve PCA, historical regime analysis, model validation.
* **UI Terminal**: Supermodernist British institutional finance aesthetic (Graphite `#0b0e14`, Steel `#334155`, Off-White `#f8fafc`, JetBrains Mono & Plus Jakarta Sans typography, Recharts interactive vector graphs).

---

## 4. First Vertical Slice: "THE RHINOSWAPS DEAL"

Default demonstration:
* **Trade**: USD $100,000,000 10Y SOFR OIS (Pay Fixed 4.1875% / Receive Floating SOFR Compounded)
* **Par Rate**: 4.1875%
* **Annuity**: 8.4312
* **DV01**: $84,312 / bp
* **Hedge**: 3,372 CME SR3 3M SOFR Futures contracts.

---

## 5. Quantitative Methods & Documentation

See the full documentation suite:
* [`ARCHITECTURE.md`](ARCHITECTURE.md)
* [`QUANTITATIVE_METHODS.md`](QUANTITATIVE_METHODS.md)
* [`SWAP_CONVENTIONS.md`](SWAP_CONVENTIONS.md)
* [`CURVE_ENGINE.md`](CURVE_ENGINE.md)
* [`RISK_ENGINE.md`](RISK_ENGINE.md)
* [`VOLATILITY.md`](VOLATILITY.md)
* [`DATA_MODEL.md`](DATA_MODEL.md)
* [`API.md`](API.md)
* [`RESEARCH_GUIDE.md`](RESEARCH_GUIDE.md)

---

*RhinoBank / RhinoQuant © 2026. All Rights Reserved.*
