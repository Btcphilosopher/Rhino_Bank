import React, { useState } from 'react';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { priceSwap } from '../engine/swapPricer';
import { SwapTradeSpec } from '../types/swap';
import { GitCommit, TrendingUp } from 'lucide-react';

export const ScenariosView: React.FC = () => {
  const [selectedScenario, setSelectedScenario] = useState<string>('PARALLEL_UP_25');

  const sampleTrade: SwapTradeSpec = {
    tradeId: 'SCENARIO-TRADE-10Y',
    counterparty: 'GENERIC_BANK',
    notional: 100000000,
    currency: 'USD',
    type: 'SOFR_OIS',
    direction: 'PAY_FIXED',
    effectiveDate: '2026-09-24',
    maturityTenor: '10Y',
    maturityDate: '2036-09-24',
    fixedRate: 0.041875,
    floatingIndex: 'SOFR',
    fixedLegFrequency: 'SEMI_ANNUAL',
    floatingLegFrequency: 'QUARTERLY',
    fixedDayCount: '30/360',
    floatingDayCount: 'ACT/360',
    businessDayConvention: 'MODIFIED_FOLLOWING',
    calendar: 'USNY',
    paymentLagDays: 2,
    resetLagDays: 0,
    compoundingMethod: 'DAILY_COMPOUNDED',
    notionalAmortization: 'BULLET',
    collateralCurrency: 'USD',
    tradeDate: '2026-09-22',
  };

  const baseCurve = getDefaultSOFRCurve();
  const baseResult = priceSwap(sampleTrade, baseCurve, baseCurve);

  const scenarioList = [
    { id: 'PARALLEL_UP_25', name: '+25 bp Parallel Shock', shiftBp: 25, shape: 'Parallel' },
    { id: 'PARALLEL_DOWN_25', name: '-25 bp Parallel Shock', shiftBp: -25, shape: 'Parallel' },
    { id: 'PARALLEL_UP_100', name: '+100 bp Rate Hike Shock', shiftBp: 100, shape: 'Parallel' },
    { id: 'STEEPENER_2S10S', name: '2s10s Bull Steepener (-20bp 2Y / 0bp 10Y)', shiftBp: 0, shape: 'Steepener' },
    { id: 'FLATTENER_10S30S', name: '10s30s Bear Flattener (+30bp 10Y / +10bp 30Y)', shiftBp: 0, shape: 'Flattener' },
  ];

  const activeScenario = scenarioList.find((s) => s.id === selectedScenario) || scenarioList[0];
  const shiftedCurve = baseCurve.shiftParallel(activeScenario.shiftBp);
  const shiftedResult = priceSwap(sampleTrade, shiftedCurve, shiftedCurve);

  const deltaPV = shiftedResult.valuation.netPV - baseResult.valuation.netPV;

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex items-center justify-between">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" />
            STRESS-TESTING SCENARIO LAB & CURVE STRATEGY ENGINE
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Macro Rate Shocks, Curve Steepeners, Flatteners & Butterfly Trade Analytics
          </h1>
        </div>
      </div>

      {/* Scenario Selector */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc]">SELECT RATE SCENARIO</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2">
          {scenarioList.map((sc) => (
            <button
              key={sc.id}
              onClick={() => setSelectedScenario(sc.id)}
              className={`p-3 rounded-xs border text-left cursor-pointer font-bold ${
                selectedScenario === sc.id
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8] text-[#38bdf8]'
                  : 'bg-[#17202e] border-[#1e293b] text-[#64748b] hover:text-[#f8fafc]'
              }`}
            >
              {sc.name}
            </button>
          ))}
        </div>
      </div>

      {/* Impact Results */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">BASE PORTFOLIO PV</span>
          <div className="text-xl font-bold text-[#f8fafc] mt-1">${Math.round(baseResult.valuation.netPV).toLocaleString()}</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">NEW SCENARIO PV</span>
          <div className="text-xl font-bold text-[#38bdf8] mt-1">${Math.round(shiftedResult.valuation.netPV).toLocaleString()}</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">SCENARIO P&L IMPACT</span>
          <div className={`text-xl font-bold mt-1 ${deltaPV >= 0 ? 'text-[#10b981]' : 'text-[#f43f5e]'}`}>
            {deltaPV >= 0 ? `+$${Math.round(deltaPV).toLocaleString()}` : `-$${Math.round(Math.abs(deltaPV)).toLocaleString()}`}
          </div>
        </div>
      </div>
    </div>
  );
};
