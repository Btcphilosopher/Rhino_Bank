import React, { useState } from 'react';
import { SwapTradeSpec, Currency, DayCountConvention, BusinessDayConvention, Frequency, SwapType, PayReceive } from '../types/swap';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { priceSwap } from '../engine/swapPricer';
import { Download, Check, RefreshCw } from 'lucide-react';

export const SwapTicketView: React.FC = () => {
  const [trade, setTrade] = useState<SwapTradeSpec>({
    tradeId: 'RHINO-TICKET-2026-001',
    counterparty: 'GOLDMAN_SACHS_NY',
    notional: 100000000,
    currency: 'USD',
    type: 'SOFR_OIS',
    direction: 'PAY_FIXED',
    effectiveDate: '2026-09-24',
    maturityTenor: '10Y',
    maturityDate: '2036-09-24',
    fixedRate: 0.041875,
    floatingIndex: 'SOFR',
    fixedLegFrequency: 'SEMI_ANNUAL',
    floatingLegFrequency: 'QUARTERLY',
    fixedDayCount: '30/360',
    floatingDayCount: 'ACT/360',
    businessDayConvention: 'MODIFIED_FOLLOWING',
    calendar: 'USNY',
    paymentLagDays: 2,
    resetLagDays: 0,
    compoundingMethod: 'DAILY_COMPOUNDED',
    notionalAmortization: 'BULLET',
    collateralCurrency: 'USD',
    tradeDate: '2026-09-22',
  });

  const curve = getDefaultSOFRCurve();
  const { valuation, schedule } = priceSwap(trade, curve, curve);
  const [activeLeg, setActiveLeg] = useState<'FIXED' | 'FLOATING'>('FIXED');

  const updateField = (field: keyof SwapTradeSpec, value: any) => {
    setTrade((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase">INSTITUTIONAL SWAP TRADE TICKET</div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Trade ID: {trade.tradeId} | {trade.currency} ${trade.notional.toLocaleString()} {trade.maturityTenor} {trade.type}
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <button className="bg-[#10b981] hover:bg-[#059669] text-[#0b0e14] px-4 py-1.5 font-bold rounded-xs cursor-pointer flex items-center gap-1.5 transition-colors">
            <Check className="w-4 h-4" />
            BOOK TRADE
          </button>
        </div>
      </div>

      {/* Ticket Grid Inputs: 20+ Fields */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-4">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc]">
          1. INSTRUMENT SPECIFICATION & CONVENTIONS
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="text-[#64748b] block mb-1">TRADE ID</label>
            <input
              type="text"
              value={trade.tradeId}
              onChange={(e) => updateField('tradeId', e.target.value)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">COUNTERPARTY</label>
            <input
              type="text"
              value={trade.counterparty}
              onChange={(e) => updateField('counterparty', e.target.value)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">NOTIONAL ($)</label>
            <input
              type="number"
              value={trade.notional}
              onChange={(e) => updateField('notional', Number(e.target.value))}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none font-bold"
            />
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">DIRECTION</label>
            <select
              value={trade.direction}
              onChange={(e) => updateField('direction', e.target.value as PayReceive)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#38bdf8] font-bold rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="PAY_FIXED">PAY FIXED / RECEIVE FLOAT</option>
              <option value="RECEIVE_FIXED">RECEIVE FIXED / PAY FLOAT</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">MATURITY TENOR</label>
            <select
              value={trade.maturityTenor}
              onChange={(e) => updateField('maturityTenor', e.target.value)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="2Y">2Y</option>
              <option value="3Y">3Y</option>
              <option value="5Y">5Y</option>
              <option value="7Y">7Y</option>
              <option value="10Y">10Y</option>
              <option value="15Y">15Y</option>
              <option value="20Y">20Y</option>
              <option value="30Y">30Y</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">FIXED RATE (%)</label>
            <input
              type="number"
              step="0.0001"
              value={trade.fixedRate * 100}
              onChange={(e) => updateField('fixedRate', Number(e.target.value) / 100.0)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#10b981] font-bold rounded-xs focus:border-[#38bdf8] focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">FLOATING INDEX</label>
            <select
              value={trade.floatingIndex}
              onChange={(e) => updateField('floatingIndex', e.target.value)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="SOFR">SOFR (CME Daily Compounded)</option>
              <option value="TERM_SOFR">Term SOFR 3M</option>
              <option value="FED_FUNDS">Fed Funds Effective</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">FIXED LEG FREQ</label>
            <select
              value={trade.fixedLegFrequency}
              onChange={(e) => updateField('fixedLegFrequency', e.target.value as Frequency)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="SEMI_ANNUAL">SEMI-ANNUAL (6M)</option>
              <option value="ANNUAL">ANNUAL (12M)</option>
              <option value="QUARTERLY">QUARTERLY (3M)</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">FIXED DAY COUNT</label>
            <select
              value={trade.fixedDayCount}
              onChange={(e) => updateField('fixedDayCount', e.target.value as DayCountConvention)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="30/360">30/360</option>
              <option value="ACT/360">ACT/360</option>
              <option value="ACT/365">ACT/365</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">FLOATING DAY COUNT</label>
            <select
              value={trade.floatingDayCount}
              onChange={(e) => updateField('floatingDayCount', e.target.value as DayCountConvention)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="ACT/360">ACT/360</option>
              <option value="ACT/365">ACT/365</option>
              <option value="30/360">30/360</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">BUSINESS DAY CONVENTION</label>
            <select
              value={trade.businessDayConvention}
              onChange={(e) => updateField('businessDayConvention', e.target.value as BusinessDayConvention)}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            >
              <option value="MODIFIED_FOLLOWING">MODIFIED FOLLOWING</option>
              <option value="FOLLOWING">FOLLOWING</option>
              <option value="PRECEDING">PRECEDING</option>
            </select>
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">PAYMENT LAG (DAYS)</label>
            <input
              type="number"
              value={trade.paymentLagDays}
              onChange={(e) => updateField('paymentLagDays', Number(e.target.value))}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#f8fafc] rounded-xs focus:border-[#38bdf8] focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Generated Schedule Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] p-3 border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-bold text-[#f8fafc]">GENERATED CASH-FLOW SCHEDULE</span>
            <div className="flex bg-[#0f141c] p-0.5 rounded-xs border border-[#1e293b]">
              <button
                onClick={() => setActiveLeg('FIXED')}
                className={`px-3 py-1 text-[11px] rounded-xs cursor-pointer ${
                  activeLeg === 'FIXED' ? 'bg-[#38bdf8] text-[#0b0e14] font-bold' : 'text-[#64748b]'
                }`}
              >
                FIXED LEG ({schedule.fixedLegPeriods.length} PERIODS)
              </button>
              <button
                onClick={() => setActiveLeg('FLOATING')}
                className={`px-3 py-1 text-[11px] rounded-xs cursor-pointer ${
                  activeLeg === 'FLOATING' ? 'bg-[#38bdf8] text-[#0b0e14] font-bold' : 'text-[#64748b]'
                }`}
              >
                FLOATING LEG ({schedule.floatingLegPeriods.length} PERIODS)
              </button>
            </div>
          </div>
          <button className="text-[#38bdf8] hover:text-[#7dd3fc] cursor-pointer flex items-center gap-1">
            <Download className="w-3.5 h-3.5" />
            EXPORT CSV
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] text-[10px] uppercase">
                <th className="p-3">#</th>
                <th className="p-3">START DATE</th>
                <th className="p-3">END DATE</th>
                <th className="p-3">PAYMENT DATE</th>
                <th className="p-3 text-right">ACCRUAL α</th>
                <th className="p-3 text-right">RATE</th>
                <th className="p-3 text-right">DISCOUNT FACTOR</th>
                <th className="p-3 text-right">CASH FLOW ($)</th>
                <th className="p-3 text-right">DISCOUNTED PV ($)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {(activeLeg === 'FIXED' ? schedule.fixedLegPeriods : schedule.floatingLegPeriods).map((p) => (
                <tr key={p.periodNumber} className="hover:bg-[#17202e]/60">
                  <td className="p-3 text-[#64748b] font-bold">{p.periodNumber}</td>
                  <td className="p-3 text-[#f8fafc]">{p.startDate}</td>
                  <td className="p-3 text-[#f8fafc]">{p.endDate}</td>
                  <td className="p-3 text-[#38bdf8] font-semibold">{p.paymentDate}</td>
                  <td className="p-3 text-right text-[#94a3b8]">{p.accrualFraction.toFixed(4)}</td>
                  <td className="p-3 text-right font-bold text-[#10b981]">
                    {((p.fixedRate || p.forecastRate || 0) * 100).toFixed(4)}%
                  </td>
                  <td className="p-3 text-right text-[#94a3b8]">{p.discountFactor.toFixed(6)}</td>
                  <td className="p-3 text-right font-semibold text-[#f8fafc]">
                    ${Math.round(p.cashFlowAmount).toLocaleString()}
                  </td>
                  <td className="p-3 text-right font-bold text-[#38bdf8]">
                    ${Math.round(p.discountedCashFlow).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
