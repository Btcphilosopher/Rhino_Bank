import React, { useState } from 'react';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { priceSwap } from '../engine/swapPricer';
import { calculateFuturesHedge } from '../engine/hedgeEngine';
import { SwapTradeSpec } from '../types/swap';
import { ChevronRight, ArrowRight, CheckCircle2, ShieldAlert, Cpu } from 'lucide-react';

const SIGNATURE_TRADE: SwapTradeSpec = {
  tradeId: 'RHINO-DEAL-10Y-SOFR',
  counterparty: 'BARCLAYS_CAPITAL_NY',
  notional: 100000000,
  currency: 'USD',
  type: 'SOFR_OIS',
  direction: 'PAY_FIXED',
  effectiveDate: '2026-09-24',
  maturityTenor: '10Y',
  maturityDate: '2036-09-24',
  fixedRate: 0.041875,
  floatingIndex: 'SOFR',
  fixedLegFrequency: 'SEMI_ANNUAL',
  floatingLegFrequency: 'QUARTERLY',
  fixedDayCount: '30/360',
  floatingDayCount: 'ACT/360',
  businessDayConvention: 'MODIFIED_FOLLOWING',
  calendar: 'USNY',
  paymentLagDays: 2,
  resetLagDays: 0,
  compoundingMethod: 'DAILY_COMPOUNDED',
  notionalAmortization: 'BULLET',
  collateralCurrency: 'USD',
  tradeDate: '2026-09-22',
};

export const SignatureDemoView: React.FC = () => {
  const curve = getDefaultSOFRCurve();
  const { valuation, schedule } = priceSwap(SIGNATURE_TRADE, curve, curve);
  const hedge = calculateFuturesHedge(SIGNATURE_TRADE.tradeId, valuation.dv01);

  const [activeStage, setActiveStage] = useState<number>(0);

  const STAGES = [
    { name: '1. TRADE', desc: 'USD $100,000,000 10Y SOFR OIS (Pay Fixed / Receive Float)', detail: 'Trade specification registered with 20+ terms including USNY calendar & 2-day payment lag.' },
    { name: '2. CONVENTIONS', desc: '30/360 Fixed vs ACT/360 Floating Modified Following', detail: 'Market standard US SOFR OIS conventions enforced.' },
    { name: '3. SCHEDULE', desc: '20 Fixed Cash-Flow Periods / 40 Floating Periods', detail: 'Generated full cash-flow schedule with business-day payment date shifts.' },
    { name: '4. CURVE', desc: 'USD SOFR Bootstrapped Monotonic Cubic Curve', detail: 'Discount factors derived from deposit, futures, and swap rate market inputs.' },
    { name: '5. DISCOUNTING', desc: 'Continuous Discounting DF(t) = exp(-r*t)', detail: `10Y Discount Factor: ${curve.getDiscountFactor(10.0).toFixed(6)}` },
    { name: '6. CASH FLOWS', desc: `Fixed: $2,093,750 / Semi-Annual | Float: SOFR Compounded`, detail: `Total expected fixed leg undiscounted cash flow: $${schedule.totalFixedCashFlow.toLocaleString()}` },
    { name: '7. PV & PAR RATE', desc: `Par Swap Rate: ${(valuation.parRate * 100).toFixed(4)}% | Net PV: $${valuation.netPV.toLocaleString()}`, detail: `Annuity A = ${valuation.fixedAnnuity.toFixed(4)}. Exact par rate solved.` },
    { name: '8. RISK & DV01', desc: `DV01: $${Math.round(valuation.dv01).toLocaleString()} / bp | Convexity: ${valuation.convexity.toFixed(2)}`, detail: 'Parallel +1bp / -1bp revaluation sensitivity analysis.' },
    { name: '9. HEDGE', desc: `SOFR Futures Hedge: ${hedge.recommendedFuturesContracts[0].quantity} SR3 contracts`, detail: `Residual DV01: $${Math.round(hedge.residualDV01).toLocaleString()} | Efficiency: ${hedge.hedgeEfficiencyPct.toFixed(1)}%` },
  ];

  return (
    <div className="p-4 space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-[#38bdf8] font-bold tracking-widest uppercase flex items-center gap-2">
            <Cpu className="w-4 h-4" />
            THE RHINOSWAPS DEAL • SIGNATURE VERTICAL SLICE
          </div>
          <h1 className="text-xl font-bold text-[#f8fafc] font-mono tracking-tight mt-1">
            USD $100,000,000 10Y SOFR OIS (Pay Fixed 4.1875% / Receive Floating SOFR)
          </h1>
        </div>
        <div className="flex items-center gap-3 font-mono text-xs">
          <span className="bg-[#38bdf8]/10 text-[#38bdf8] border border-[#38bdf8]/30 px-3 py-1 font-semibold rounded-xs">
            VERIFIED QUANT PIPELINE
          </span>
        </div>
      </div>

      {/* Signature Visualisation: THE SWAP ANATOMY */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#1e293b] pb-3">
          <div>
            <h2 className="text-sm font-mono font-bold text-[#f8fafc]">THE SWAP ANATOMY</h2>
            <p className="text-[11px] text-[#64748b] font-mono">
              Click any stage in the horizontal quantitative pipeline to inspect mathematical calculations
            </p>
          </div>
        </div>

        {/* Horizontal Pipeline Stages */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-1.5 font-mono text-xs">
          {STAGES.map((s, idx) => {
            const isActive = activeStage === idx;
            return (
              <button
                key={idx}
                onClick={() => setActiveStage(idx)}
                className={`p-2 rounded-xs border text-left transition-all cursor-pointer flex flex-col justify-between h-20 ${
                  isActive
                    ? 'bg-[#17202e] border-[#38bdf8] text-[#f8fafc] shadow-lg shadow-[#38bdf8]/10'
                    : 'bg-[#121824] border-[#1e293b] text-[#64748b] hover:border-[#334155] hover:text-[#94a3b8]'
                }`}
              >
                <div className="text-[10px] font-bold text-[#38bdf8] uppercase truncate">{s.name}</div>
                <div className="text-[9px] font-medium leading-tight line-clamp-2 mt-1">{s.desc}</div>
                <div className="flex justify-end mt-1">
                  <ChevronRight className={`w-3 h-3 ${isActive ? 'text-[#38bdf8]' : 'text-[#334155]'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Stage Inspection Card */}
        <div className="bg-[#121824] border border-[#38bdf8]/30 p-4 rounded-xs font-mono space-y-2">
          <div className="text-xs font-bold text-[#38bdf8] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            STAGE {activeStage + 1} EXPLANATION & CALCULATION LOGIC: {STAGES[activeStage].name}
          </div>
          <p className="text-xs text-[#e2e8f0]">{STAGES[activeStage].desc}</p>
          <div className="bg-[#0b0e14] border border-[#1e293b] p-3 rounded-xs text-xs text-[#38bdf8] font-mono leading-relaxed">
            {STAGES[activeStage].detail}
          </div>
        </div>
      </div>

      {/* Quantitative Summary Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">PAR SWAP RATE</span>
          <div className="text-xl font-bold text-[#38bdf8] mt-1">
            {(valuation.parRate * 100).toFixed(4)}%
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Rate Difference: {valuation.rateDifferenceBp.toFixed(2)} bp</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">FIXED LEG ANNUITY (A)</span>
          <div className="text-xl font-bold text-[#f8fafc] mt-1">
            {valuation.fixedAnnuity.toFixed(4)}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">PV = Notional × Rate × Annuity</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">NET PRESENT VALUE (PV)</span>
          <div className="text-xl font-bold text-[#10b981] mt-1">
            ${valuation.netPV.toLocaleString()}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Clean & Dirty PV Matched</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">DV01 (DOLLAR VALUE OF 1BP)</span>
          <div className="text-xl font-bold text-[#f59e0b] mt-1">
            ${Math.round(valuation.dv01).toLocaleString()}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Parallel +1bp Shift Revaluation</div>
        </div>
      </div>
    </div>
  );
};
