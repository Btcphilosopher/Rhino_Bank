import React, { useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { BenchmarkSpread, getMarketBenchmarks } from '../engine/syntheticMarket';
import { BASE_SOFR_MARKET_INPUTS, BASE_TREASURY_MARKET_INPUTS } from '../engine/curveEngine';

export const OverviewView: React.FC = () => {
  const benchmarks = getMarketBenchmarks();
  const [selectedOverlay, setSelectedOverlay] = useState<'ALL' | 'SOFR_ONLY' | 'TREASURY_ONLY'>('ALL');

  // Prepare chart data combining SOFR OIS and Treasury yields
  const chartData = BASE_SOFR_MARKET_INPUTS.map((p) => {
    const treasuryMatch = BASE_TREASURY_MARKET_INPUTS.find((t) => t.tenor === p.tenor);
    const treasuryRate = treasuryMatch ? treasuryMatch.rate * 100 : p.rate * 100 + 0.1;
    const sofrRate = p.rate * 100;
    const spreadBp = (sofrRate - treasuryRate) * 100;

    return {
      tenor: p.tenor,
      months: p.months,
      sofrRate,
      treasuryRate,
      spreadBp,
    };
  });

  return (
    <div className="p-4 space-y-6">
      {/* Top Section Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-[#38bdf8] font-bold tracking-widest uppercase">
            RHINOSWAPS • USD SWAP MARKET
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] font-mono tracking-tight mt-0.5">
            USD Interest-Rate Swap Benchmarks & Term Structure
          </h1>
        </div>
        <div className="flex items-center gap-3 font-mono text-xs">
          <span className="text-[#64748b]">STATUS:</span>
          <span className="bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/30 px-2 py-0.5 font-semibold rounded-xs">
            DETERMINISTIC MARKET SNAPSHOT
          </span>
        </div>
      </div>

      {/* Benchmark Dense Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] px-4 py-2 border-b border-[#1e293b] font-mono text-xs font-bold text-[#f8fafc] flex justify-between items-center">
          <span>USD BENCHMARK RATES & SWAP SPREADS</span>
          <span className="text-[10px] text-[#64748b]">AS OF: 2026-09-22 03:27 EST</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] uppercase tracking-wider text-[10px]">
                <th className="p-3">INSTRUMENT</th>
                <th className="p-3 text-right">RATE / YIELD</th>
                <th className="p-3 text-right">DAY CHANGE</th>
                <th className="p-3 text-right">TREASURY YIELD</th>
                <th className="p-3 text-right">SWAP SPREAD (BP)</th>
                <th className="p-3 text-right">DV01 / $100M</th>
                <th className="p-3 text-center">CURVE POSITION</th>
                <th className="p-3 text-center">DATA STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {benchmarks.map((b) => (
                <tr key={b.tenor} className="hover:bg-[#17202e]/60 transition-colors">
                  <td className="p-3 font-bold text-[#f8fafc] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#38bdf8]" />
                    {b.tenor}
                  </td>
                  <td className="p-3 text-right font-semibold text-[#38bdf8]">
                    {(b.sofrRate * 100).toFixed(4)}%
                  </td>
                  <td
                    className={`p-3 text-right font-medium ${
                      b.changeBp >= 0 ? 'text-[#10b981]' : 'text-[#f43f5e]'
                    }`}
                  >
                    {b.changeBp >= 0 ? `+${b.changeBp.toFixed(1)}` : b.changeBp.toFixed(1)} bp
                  </td>
                  <td className="p-3 text-right text-[#94a3b8]">
                    {b.treasuryYield > 0 ? `${(b.treasuryYield * 100).toFixed(3)}%` : '—'}
                  </td>
                  <td className="p-3 text-right font-semibold text-[#f59e0b]">
                    {b.swapSpreadBp !== 0 ? `${b.swapSpreadBp.toFixed(2)} bp` : '—'}
                  </td>
                  <td className="p-3 text-right text-[#e2e8f0]">
                    {b.dv01Per100M > 0 ? `$${b.dv01Per100M.toLocaleString()}` : '—'}
                  </td>
                  <td className="p-3 text-center text-[10px] text-[#64748b]">
                    BENCHMARK NODE
                  </td>
                  <td className="p-3 text-center">
                    <span className="text-[9px] bg-[#1e293b] text-[#94a3b8] px-1.5 py-0.5 rounded-xs">
                      {b.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Main Chart Section: USD SWAP CURVE OVERLAY */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-3">
          <div>
            <h2 className="text-sm font-mono font-bold text-[#f8fafc]">
              USD SWAP CURVE OVERLAY (SOFR OIS vs TREASURY YIELDS)
            </h2>
            <p className="text-[11px] text-[#64748b] font-mono">
              Comparing SOFR OIS Benchmark Swap Curve against US Treasury Yield Curve
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <button
              onClick={() => setSelectedOverlay('ALL')}
              className={`px-2.5 py-1 rounded-xs border text-[11px] cursor-pointer ${
                selectedOverlay === 'ALL'
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8] text-[#38bdf8]'
                  : 'bg-[#17202e] border-[#1e293b] text-[#64748b]'
              }`}
            >
              OVERLAY ALL
            </button>
            <button
              onClick={() => setSelectedOverlay('SOFR_ONLY')}
              className={`px-2.5 py-1 rounded-xs border text-[11px] cursor-pointer ${
                selectedOverlay === 'SOFR_ONLY'
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8] text-[#38bdf8]'
                  : 'bg-[#17202e] border-[#1e293b] text-[#64748b]'
              }`}
            >
              SOFR OIS ONLY
            </button>
            <button
              onClick={() => setSelectedOverlay('TREASURY_ONLY')}
              className={`px-2.5 py-1 rounded-xs border text-[11px] cursor-pointer ${
                selectedOverlay === 'TREASURY_ONLY'
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8] text-[#38bdf8]'
                  : 'bg-[#17202e] border-[#1e293b] text-[#64748b]'
              }`}
            >
              TREASURY ONLY
            </button>
          </div>
        </div>

        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="tenor" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }} />
              <YAxis
                stroke="#64748b"
                tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }}
                domain={['dataMin - 0.2', 'dataMax + 0.2']}
                unit="%"
              />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f141c', borderColor: '#334155', color: '#f8fafc', fontFamily: 'monospace', fontSize: 11 }}
                formatter={(val: any) => [`${Number(val).toFixed(4)}%`, '']}
              />
              <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 11, color: '#94a3b8' }} />
              {(selectedOverlay === 'ALL' || selectedOverlay === 'SOFR_ONLY') && (
                <Line
                  type="monotone"
                  dataKey="sofrRate"
                  name="USD SOFR OIS Curve"
                  stroke="#38bdf8"
                  strokeWidth={2}
                  dot={{ r: 3, fill: '#38bdf8' }}
                />
              )}
              {(selectedOverlay === 'ALL' || selectedOverlay === 'TREASURY_ONLY') && (
                <Line
                  type="monotone"
                  dataKey="treasuryRate"
                  name="USD Treasury Curve"
                  stroke="#10b981"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={{ r: 3, fill: '#10b981' }}
                />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
