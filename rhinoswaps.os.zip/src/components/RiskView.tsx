import React, { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { priceSwap } from '../engine/swapPricer';
import { SwapTradeSpec } from '../types/swap';
import { ShieldAlert, BarChart2 } from 'lucide-react';

export const RiskView: React.FC = () => {
  const [shockBp, setShockBp] = useState<number>(1);

  const sampleTrade: SwapTradeSpec = {
    tradeId: 'RISK-PORTFOLIO-10Y',
    counterparty: 'GENERIC_BANK',
    notional: 100000000,
    currency: 'USD',
    type: 'SOFR_OIS',
    direction: 'PAY_FIXED',
    effectiveDate: '2026-09-24',
    maturityTenor: '10Y',
    maturityDate: '2036-09-24',
    fixedRate: 0.041875,
    floatingIndex: 'SOFR',
    fixedLegFrequency: 'SEMI_ANNUAL',
    floatingLegFrequency: 'QUARTERLY',
    fixedDayCount: '30/360',
    floatingDayCount: 'ACT/360',
    businessDayConvention: 'MODIFIED_FOLLOWING',
    calendar: 'USNY',
    paymentLagDays: 2,
    resetLagDays: 0,
    compoundingMethod: 'DAILY_COMPOUNDED',
    notionalAmortization: 'BULLET',
    collateralCurrency: 'USD',
    tradeDate: '2026-09-22',
  };

  const curve = getDefaultSOFRCurve();
  const { valuation } = priceSwap(sampleTrade, curve, curve);

  const keyRateData = Object.entries(valuation.keyRateDV01).map(([tenor, dv01]) => ({
    tenor,
    dv01: Math.round(dv01),
  }));

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4" />
            RHINOSWAPS RISK ENGINE & KEY-RATE DV01 BUCKETING
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            First & Second Order Interest Rate Sensitivity Analysis
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-[#64748b]">SHOCK SIZE:</span>
          {[1, 5, 10].map((s) => (
            <button
              key={s}
              onClick={() => setShockBp(s)}
              className={`px-3 py-1 rounded-xs font-bold border cursor-pointer ${
                shockBp === s ? 'bg-[#38bdf8] text-[#0b0e14] border-[#38bdf8]' : 'bg-[#17202e] text-[#64748b] border-[#1e293b]'
              }`}
            >
              ±{s} BP
            </button>
          ))}
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">TOTAL NET DV01</span>
          <div className="text-2xl font-bold text-[#38bdf8] mt-1">
            ${Math.round(valuation.dv01 * shockBp).toLocaleString()}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">For ±{shockBp}bp parallel shift</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">PV01 (DOLLAR VALUE OF 100BP)</span>
          <div className="text-2xl font-bold text-[#f8fafc] mt-1">
            ${Math.round(valuation.pv01).toLocaleString()}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Full 100bp curve revaluation</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">CONVEXITY (2ND DERIVATIVE)</span>
          <div className="text-2xl font-bold text-[#10b981] mt-1">
            {valuation.convexity.toFixed(2)}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Second order non-linearity</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">NONLINEARITY ERROR</span>
          <div className="text-2xl font-bold text-[#f59e0b] mt-1">
            ${Math.round(valuation.convexity * shockBp * shockBp).toLocaleString()}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Gamma correction amount</div>
        </div>
      </div>

      {/* Key Rate DV01 Chart */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc] flex items-center justify-between">
          <span>KEY-RATE DV01 BUCKETED PROFILE</span>
          <span className="text-[#38bdf8] text-[11px]">8 TENOR BUCKETS</span>
        </div>

        <div className="h-64 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={keyRateData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="tenor" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }} />
              <YAxis stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f141c', borderColor: '#334155', color: '#f8fafc', fontFamily: 'monospace', fontSize: 11 }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'DV01']}
              />
              <Bar dataKey="dv01" fill="#38bdf8" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
