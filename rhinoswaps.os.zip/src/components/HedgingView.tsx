import React, { useState } from 'react';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { priceSwap } from '../engine/swapPricer';
import { calculateFuturesHedge, SAMPLE_SOFR_FUTURES } from '../engine/hedgeEngine';
import { SwapTradeSpec } from '../types/swap';
import { ShieldCheck, Crosshair } from 'lucide-react';

export const HedgingView: React.FC = () => {
  const [swapNotional, setSwapNotional] = useState<number>(100000000);

  const targetTrade: SwapTradeSpec = {
    tradeId: 'HEDGE-TARGET-SWAP',
    counterparty: 'CLIENT_FUND',
    notional: swapNotional,
    currency: 'USD',
    type: 'SOFR_OIS',
    direction: 'PAY_FIXED',
    effectiveDate: '2026-09-24',
    maturityTenor: '10Y',
    maturityDate: '2036-09-24',
    fixedRate: 0.041875,
    floatingIndex: 'SOFR',
    fixedLegFrequency: 'SEMI_ANNUAL',
    floatingLegFrequency: 'QUARTERLY',
    fixedDayCount: '30/360',
    floatingDayCount: 'ACT/360',
    businessDayConvention: 'MODIFIED_FOLLOWING',
    calendar: 'USNY',
    paymentLagDays: 2,
    resetLagDays: 0,
    compoundingMethod: 'DAILY_COMPOUNDED',
    notionalAmortization: 'BULLET',
    collateralCurrency: 'USD',
    tradeDate: '2026-09-22',
  };

  const curve = getDefaultSOFRCurve();
  const { valuation } = priceSwap(targetTrade, curve, curve);
  const hedge = calculateFuturesHedge(targetTrade.tradeId, valuation.dv01);

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <Crosshair className="w-4 h-4" />
            HEDGE LAB • CME SOFR FUTURES (SR1/SR3) STRIP OPTIMIZER
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Exact Economic Replication vs. Residual Curve Risk
          </h1>
        </div>
      </div>

      {/* Target Position Control */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc]">
          UNHEDGED TARGET POSITION SPECIFICATION
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-[#64748b] block mb-1">TARGET NOTIONAL ($)</label>
            <input
              type="number"
              step="10000000"
              value={swapNotional}
              onChange={(e) => setSwapNotional(Number(e.target.value))}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#38bdf8] font-bold rounded-xs focus:border-[#38bdf8] focus:outline-none"
            />
          </div>
          <div>
            <span className="text-[#64748b] block mb-1">UNHEDGED SWAP DV01</span>
            <div className="text-lg font-bold text-[#f59e0b] bg-[#17202e] p-1.5 rounded-xs border border-[#1e293b]">
              ${Math.round(valuation.dv01).toLocaleString()} / bp
            </div>
          </div>
          <div>
            <span className="text-[#64748b] block mb-1">HEDGE EFFICIENCY</span>
            <div className="text-lg font-bold text-[#10b981] bg-[#17202e] p-1.5 rounded-xs border border-[#1e293b]">
              {hedge.hedgeEfficiencyPct.toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Futures Contracts Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] p-3 border-b border-[#1e293b] font-bold text-[#f8fafc]">
          OPTIMAL CME 3M SOFR FUTURES STRIP HEDGE RECOMMENDATION
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] text-[10px] uppercase">
                <th className="p-3">CONTRACT CODE</th>
                <th className="p-3">DESCRIPTION</th>
                <th className="p-3 text-right">FUTURES PRICE</th>
                <th className="p-3 text-right">IMPLIED RATE</th>
                <th className="p-3 text-right">DV01 / CONTRACT</th>
                <th className="p-3 text-right">RECOMMENDED CONTRACTS</th>
                <th className="p-3 text-right">TOTAL HEDGE DV01</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {SAMPLE_SOFR_FUTURES.slice(0, 6).map((c) => {
                const isPrimary = c.code === 'SR3H26';
                const recQuantity = isPrimary ? Math.round(-valuation.dv01 / c.dv01PerContract) : 0;
                return (
                  <tr key={c.code} className="hover:bg-[#17202e]/60">
                    <td className="p-3 font-bold text-[#38bdf8]">{c.code}</td>
                    <td className="p-3 text-[#f8fafc]">{c.description}</td>
                    <td className="p-3 text-right text-[#e2e8f0]">{c.price.toFixed(2)}</td>
                    <td className="p-3 text-right text-[#10b981]">{(c.impliedRate * 100).toFixed(2)}%</td>
                    <td className="p-3 text-right text-[#94a3b8]">${c.dv01PerContract.toFixed(2)}</td>
                    <td className="p-3 text-right font-bold text-[#f59e0b]">
                      {recQuantity !== 0 ? `${recQuantity} contracts` : '0'}
                    </td>
                    <td className="p-3 text-right font-bold text-[#38bdf8]">
                      ${(recQuantity * c.dv01PerContract).toLocaleString()}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
