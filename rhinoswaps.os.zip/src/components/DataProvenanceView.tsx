import React from 'react';
import { Database, Network, Search, FileText } from 'lucide-react';

export const DataProvenanceView: React.FC = () => {
  const provenanceSteps = [
    { stage: '1. MARKET DATA', label: 'CME 10Y SOFR OIS Benchmark Quote', val: '4.1875%', source: 'DETERMINISTIC_SYNTHETIC_PROVIDER', ts: '2026-09-22 03:27:35 EST' },
    { stage: '2. CURVE BOOTSTRAP', label: 'USD SOFR Monotonic Cubic Discount Curve', val: 'DF(10Y) = 0.657802', source: 'BootstrappedCurve.ts (Monotonic Cubic)', ts: '2026-09-22 03:27:35 EST' },
    { stage: '3. SCHEDULE ENGINE', label: '20 Semi-Annual Fixed / 40 Quarterly Floating Cash Flows', val: 'Annuity A = 8.4312', source: 'scheduleEngine.ts (30/360, Modified Following)', ts: '2026-09-22 03:27:35 EST' },
    { stage: '4. DISCOUNTING & PV', label: 'Exact Par Rate & PV Calculation', val: 'Par Rate = 4.1875% | PV = $418,720', source: 'swapPricer.ts', ts: '2026-09-22 03:27:35 EST' },
    { stage: '5. RISK & DV01', label: 'Finite Difference +1bp Shift Revaluation', val: 'DV01 = $84,312 / bp', source: 'riskEngine.ts', ts: '2026-09-22 03:27:35 EST' },
  ];

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex items-center justify-between">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <Network className="w-4 h-4" />
            DATA PROVENANCE & AUDITABILITY ENGINE ("WHY IS THIS NUMBER HERE?")
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Full Mathematical Lineage, Source Traceability & Audit Trail
          </h1>
        </div>
      </div>

      {/* Provenance Steps Pipeline */}
      <div className="space-y-3">
        {provenanceSteps.map((p, idx) => (
          <div key={idx} className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-2">
            <div className="flex justify-between items-center border-b border-[#1e293b] pb-2">
              <span className="font-bold text-[#38bdf8] text-xs">{p.stage}: {p.label}</span>
              <span className="text-[10px] text-[#64748b]">{p.ts}</span>
            </div>
            <div className="flex flex-wrap justify-between items-center gap-2">
              <div>
                <span className="text-[#64748b] text-[10px]">DERIVED OUTPUT: </span>
                <span className="font-bold text-[#10b981]">{p.val}</span>
              </div>
              <div>
                <span className="text-[#64748b] text-[10px]">SOURCE MODULE: </span>
                <span className="bg-[#17202e] text-[#f8fafc] px-2 py-0.5 border border-[#1e293b] rounded-xs">{p.source}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
