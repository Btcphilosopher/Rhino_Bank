import React, { useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { runMonteCarloShortRate, calculatePnLAttribution } from '../engine/analyticsEngine';
import { getHistoricalReplaySnapshots } from '../engine/syntheticMarket';
import { BookOpen, Cpu, History } from 'lucide-react';

export const ResearchView: React.FC = () => {
  const [modelName, setModelName] = useState<'Vasicek' | 'Hull-White' | 'CIR'>('Hull-White');
  const [numPaths, setNumPaths] = useState<number>(1000);
  const [selectedHistDate, setSelectedHistDate] = useState<string>('2026-09-22');

  const mcResult = runMonteCarloShortRate(modelName, numPaths);
  const pnlAttr = calculatePnLAttribution();
  const histSnapshots = getHistoricalReplaySnapshots();

  const chartData = mcResult.timeHorizonsYears.map((t, idx) => ({
    timeYears: t.toFixed(1),
    meanRate: mcResult.meanRateProfile[idx] * 100,
    p5: mcResult.percentile5Profile[idx] * 100,
    p95: mcResult.percentile95Profile[idx] * 100,
  }));

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex items-center justify-between">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <BookOpen className="w-4 h-4" />
            RHINOSWAPS RESEARCH LABORATORY & MONTE CARLO ENGINE
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Vasicek, Hull-White & CIR Short-Rate Path Simulations, VaR & P&L Attribution
          </h1>
        </div>
      </div>

      {/* Historical Replay Date Selection */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
        <div className="text-[#38bdf8] font-bold border-b border-[#1e293b] pb-2 flex items-center gap-1.5">
          <History className="w-4 h-4" />
          HISTORICAL REPLAY MARKET RECONSTRUCTOR
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
          {histSnapshots.map((snap) => (
            <button
              key={snap.date}
              onClick={() => setSelectedHistDate(snap.date)}
              className={`p-3 rounded-xs border text-left cursor-pointer ${
                selectedHistDate === snap.date
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8] text-[#38bdf8] font-bold'
                  : 'bg-[#17202e] border-[#1e293b] text-[#64748b] hover:text-[#f8fafc]'
              }`}
            >
              <div className="text-[10px] text-[#f8fafc]">{snap.date}</div>
              <div className="text-[11px] mt-0.5">{snap.name}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Monte Carlo Simulator Controls */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-4">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc] flex justify-between items-center">
          <span>SHORT-RATE MODEL MONTE CARLO SIMULATION</span>
          <div className="flex gap-2">
            {(['Hull-White', 'Vasicek', 'CIR'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setModelName(m)}
                className={`px-3 py-1 rounded-xs font-bold border cursor-pointer ${
                  modelName === m ? 'bg-[#38bdf8] text-[#0b0e14] border-[#38bdf8]' : 'bg-[#17202e] text-[#64748b] border-[#1e293b]'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <span className="text-[#64748b] block mb-1">NUM PATHS</span>
            <select
              value={numPaths}
              onChange={(e) => setNumPaths(Number(e.target.value))}
              className="w-full bg-[#17202e] border border-[#1e293b] p-2 text-[#38bdf8] font-bold rounded-xs focus:outline-none"
            >
              <option value="1000">1,000 PATHS</option>
              <option value="10000">10,000 PATHS</option>
            </select>
          </div>

          <div>
            <span className="text-[#64748b] block mb-1">95% VALUE-AT-RISK (VAR)</span>
            <div className="text-lg font-bold text-[#f43f5e] bg-[#17202e] p-1.5 rounded-xs border border-[#1e293b]">
              {mcResult.var95Pct.toFixed(1)} bp
            </div>
          </div>

          <div>
            <span className="text-[#64748b] block mb-1">95% EXPECTED SHORTFALL (ES)</span>
            <div className="text-lg font-bold text-[#f59e0b] bg-[#17202e] p-1.5 rounded-xs border border-[#1e293b]">
              {mcResult.expectedShortfall95Pct.toFixed(1)} bp
            </div>
          </div>
        </div>

        <div className="h-64 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="timeYears" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }} />
              <YAxis stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }} unit="%" />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f141c', borderColor: '#334155', color: '#f8fafc', fontFamily: 'monospace', fontSize: 11 }}
                formatter={(val: any) => [`${Number(val).toFixed(2)}%`, '']}
              />
              <Line type="monotone" dataKey="meanRate" name="Expected Rate Path" stroke="#38bdf8" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="p5" name="5th Percentile" stroke="#10b981" strokeDasharray="4 4" dot={false} />
              <Line type="monotone" dataKey="p95" name="95th Percentile" stroke="#f43f5e" strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
