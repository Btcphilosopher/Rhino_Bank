import React from 'react';
import { getMarketBenchmarks } from '../engine/syntheticMarket';
import { Layers } from 'lucide-react';

export const BasisView: React.FC = () => {
  const benchmarks = getMarketBenchmarks();

  const basisPairs = [
    { name: 'SOFR OIS vs Term SOFR 3M', tenor: '10Y', spreadBp: +2.5, changeBp: +0.2, zScore: +0.45, pct95: '+4.0 bp' },
    { name: 'SOFR OIS vs Fed Funds Effective', tenor: '10Y', spreadBp: -1.2, changeBp: -0.1, zScore: -0.22, pct95: '+1.5 bp' },
    { name: 'USD 10Y Swap Spread (SOFR vs UST)', tenor: '10Y', spreadBp: -6.25, changeBp: +2.1, zScore: +1.15, pct95: '-12.0 bp' },
    { name: 'USD 30Y Swap Spread (SOFR vs UST)', tenor: '30Y', spreadBp: -7.0, changeBp: -1.4, zScore: -0.85, pct95: '-18.0 bp' },
  ];

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex items-center justify-between">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <Layers className="w-4 h-4" />
            SWAP SPREAD & BASIS LAB
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            SOFR Basis Swaps, Treasury Swap Spreads & Statistical Z-Scores
          </h1>
        </div>
      </div>

      {/* Basis Pairs Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] p-3 border-b border-[#1e293b] font-bold text-[#f8fafc]">
          USD FLOATING INDEX BASIS & TREASURY SWAP SPREADS
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] text-[10px] uppercase">
                <th className="p-3">BASIS INSTRUMENT PAIR</th>
                <th className="p-3">TENOR</th>
                <th className="p-3 text-right">BASIS SPREAD (BP)</th>
                <th className="p-3 text-right">DAY CHANGE</th>
                <th className="p-3 text-right">HISTORICAL Z-SCORE</th>
                <th className="p-3 text-right">95TH PERCENTILE BOUND</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {basisPairs.map((b) => (
                <tr key={b.name} className="hover:bg-[#17202e]/60">
                  <td className="p-3 font-bold text-[#f8fafc]">{b.name}</td>
                  <td className="p-3 text-[#38bdf8] font-semibold">{b.tenor}</td>
                  <td className="p-3 text-right font-bold text-[#f59e0b]">{b.spreadBp.toFixed(2)} bp</td>
                  <td className={`p-3 text-right font-semibold ${b.changeBp >= 0 ? 'text-[#10b981]' : 'text-[#f43f5e]'}`}>
                    {b.changeBp >= 0 ? `+${b.changeBp.toFixed(1)}` : b.changeBp.toFixed(1)} bp
                  </td>
                  <td className="p-3 text-right text-[#e2e8f0] font-bold">{b.zScore.toFixed(2)}</td>
                  <td className="p-3 text-right text-[#94a3b8]">{b.pct95}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
