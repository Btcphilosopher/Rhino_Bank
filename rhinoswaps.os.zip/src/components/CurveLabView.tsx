import React, { useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { InterpolationMethod } from '../types/swap';
import { BootstrappedCurve } from '../engine/curveEngine';

export const CurveLabView: React.FC = () => {
  const [method, setMethod] = useState<InterpolationMethod>('MONOTONIC_CUBIC');
  const baseCurve = getDefaultSOFRCurve();

  // Create curve instance with selected interpolation method
  const curve = new BootstrappedCurve({
    ...baseCurve.definition,
    interpolation: method,
  });

  const tenorsToChart = [0.1, 0.25, 0.5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30];
  const chartData = tenorsToChart.map((t) => {
    const df = curve.getDiscountFactor(t);
    const zeroRate = curve.getZeroRate(t) * 100;
    const fwdRate = curve.getForwardRate(Math.max(0, t - 0.25), t) * 100;

    return {
      tYears: t,
      tenorLabel: `${t}Y`,
      discountFactor: df,
      zeroRate,
      fwdRate,
    };
  });

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase">QUANTITATIVE CURVE ENGINE</div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            USD SOFR OIS Discount & Forward Rate Curve Bootstrapper
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-[#64748b]">INTERPOLATION METHOD:</span>
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value as InterpolationMethod)}
            className="bg-[#17202e] border border-[#1e293b] p-2 text-[#38bdf8] font-bold rounded-xs focus:border-[#38bdf8] focus:outline-none cursor-pointer"
          >
            <option value="MONOTONIC_CUBIC">MONOTONIC CUBIC SPLINE</option>
            <option value="LOG_LINEAR">LOG-LINEAR DISCOUNT FACTORS</option>
            <option value="LINEAR">LINEAR ZERO RATES</option>
            <option value="NELSON_SIEGEL">NELSON-SIEGEL PARRAMETRIC</option>
          </select>
        </div>
      </div>

      {/* Curve Chart */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc]">
          ZERO RATE & 3M FORWARD RATE TERM STRUCTURE (%)
        </div>
        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="tenorLabel" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }} />
              <YAxis
                stroke="#64748b"
                tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }}
                domain={['dataMin - 0.2', 'dataMax + 0.2']}
                unit="%"
              />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f141c', borderColor: '#334155', color: '#f8fafc', fontFamily: 'monospace', fontSize: 11 }}
                formatter={(val: any) => [`${Number(val).toFixed(4)}%`, '']}
              />
              <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 11, color: '#94a3b8' }} />
              <Line type="monotone" dataKey="zeroRate" name="Zero Rate r(t)" stroke="#38bdf8" strokeWidth={2} dot={{ r: 2 }} />
              <Line type="monotone" dataKey="fwdRate" name="Instantaneous / Forward Rate f(t)" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Observed Market Inputs Trace Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] p-3 border-b border-[#1e293b] font-bold text-[#f8fafc]">
          OBSERVED MARKET INPUTS & CALIBRATION NODES
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] text-[10px] uppercase">
                <th className="p-3">TENOR</th>
                <th className="p-3">INSTRUMENT TYPE</th>
                <th className="p-3 text-right">MARKET QUOTE (%)</th>
                <th className="p-3 text-right">ZERO RATE (%)</th>
                <th className="p-3 text-right">DISCOUNT FACTOR DF(t)</th>
                <th className="p-3 text-center">PROVENANCE STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {baseCurve.definition.points.map((pt) => (
                <tr key={pt.tenor} className="hover:bg-[#17202e]/60">
                  <td className="p-3 font-bold text-[#f8fafc]">{pt.tenor}</td>
                  <td className="p-3 text-[#38bdf8] font-semibold">{pt.instrumentType}</td>
                  <td className="p-3 text-right font-bold text-[#10b981]">{(pt.rate * 100).toFixed(4)}%</td>
                  <td className="p-3 text-right text-[#e2e8f0]">{(pt.zeroRate * 100).toFixed(4)}%</td>
                  <td className="p-3 text-right text-[#f59e0b] font-mono">{pt.discountFactor.toFixed(6)}</td>
                  <td className="p-3 text-center">
                    <span className="bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/30 px-2 py-0.5 rounded-xs text-[9px]">
                      OBSERVED MARKET NODE
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
