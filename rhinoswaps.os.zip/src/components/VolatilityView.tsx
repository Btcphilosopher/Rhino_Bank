import React, { useState } from 'react';
import { getSwaptionVolGrid } from '../engine/syntheticMarket';
import { priceSwaption } from '../engine/swaptionPricer';
import { SwaptionSpec } from '../types/swap';
import { Sliders, Flame } from 'lucide-react';

export const VolatilityView: React.FC = () => {
  const { expiries, tenors, grid } = getSwaptionVolGrid();
  const [modelType, setModelType] = useState<'BACHELIER_NORMAL' | 'BLACK_76'>('BACHELIER_NORMAL');
  const [swaptionType, setSwaptionType] = useState<'PAYER' | 'RECEIVER'>('PAYER');
  const [notional, setNotional] = useState<number>(100000000);
  const [strikeRate, setStrikeRate] = useState<number>(4.1875);

  const spec: SwaptionSpec = {
    tradeId: 'SWAPTION-1Y10Y',
    type: swaptionType,
    expiryTenor: '1Y',
    underlyingTenor: '10Y',
    notional,
    strike: strikeRate / 100.0,
    impliedVol: modelType === 'BACHELIER_NORMAL' ? 0.0081 : 0.22, // 81bps normal or 22% lognormal
    modelType,
  };

  const greeks = priceSwaption(spec, 0.041875, 8.4312);

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex items-center justify-between">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <Flame className="w-4 h-4" />
            USD SWAPTION VOLATILITY SURFACE & PRICING LAB
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Black-76 Lognormal & Bachelier Normal Swaption Pricing Engines
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setModelType('BACHELIER_NORMAL')}
            className={`px-3 py-1 rounded-xs font-bold border cursor-pointer ${
              modelType === 'BACHELIER_NORMAL' ? 'bg-[#38bdf8] text-[#0b0e14] border-[#38bdf8]' : 'bg-[#17202e] text-[#64748b] border-[#1e293b]'
            }`}
          >
            BACHELIER (NORMAL VOL)
          </button>
          <button
            onClick={() => setModelType('BLACK_76')}
            className={`px-3 py-1 rounded-xs font-bold border cursor-pointer ${
              modelType === 'BLACK_76' ? 'bg-[#38bdf8] text-[#0b0e14] border-[#38bdf8]' : 'bg-[#17202e] text-[#64748b] border-[#1e293b]'
            }`}
          >
            BLACK-76 (LOGNORMAL)
          </button>
        </div>
      </div>

      {/* Pricing Greeks Summary */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">SWAPTION PREMIUM</span>
          <div className="text-xl font-bold text-[#10b981] mt-1">
            ${Math.round(greeks.price).toLocaleString()}
          </div>
          <div className="text-[10px] text-[#94a3b8] mt-1">{greeks.premiumPct.toFixed(3)}% of Notional</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">DELTA (∂V / ∂F)</span>
          <div className="text-xl font-bold text-[#38bdf8] mt-1">
            ${Math.round(greeks.delta).toLocaleString()}
          </div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">GAMMA (∂²V / ∂F²)</span>
          <div className="text-xl font-bold text-[#f59e0b] mt-1">
            {Math.round(greeks.gamma).toLocaleString()}
          </div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">VEGA (∂V / ∂σ)</span>
          <div className="text-xl font-bold text-[#f8fafc] mt-1">
            ${Math.round(greeks.vega / 100).toLocaleString()} / bp
          </div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">THETA (∂V / ∂t)</span>
          <div className="text-xl font-bold text-[#f43f5e] mt-1">
            ${Math.round(greeks.theta / 365).toLocaleString()} / day
          </div>
        </div>
      </div>

      {/* Volatility Surface Heatmap Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] p-3 border-b border-[#1e293b] font-bold text-[#f8fafc]">
          USD ATM SWAPTION NORMAL VOLATILITY SURFACE GRID (BPS / YEAR)
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] text-[10px] uppercase">
                <th className="p-3 text-left">EXPIRY \ TENOR</th>
                {tenors.map((t) => (
                  <th key={t} className="p-3">{t}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {expiries.map((exp) => (
                <tr key={exp} className="hover:bg-[#17202e]/60">
                  <td className="p-3 font-bold text-[#38bdf8] text-left">{exp}</td>
                  {tenors.map((t) => {
                    const vol = grid[exp]?.[t] || 80;
                    return (
                      <td key={t} className="p-3 font-mono font-bold text-[#f8fafc] bg-[#17202e]/40">
                        {vol} bp
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
