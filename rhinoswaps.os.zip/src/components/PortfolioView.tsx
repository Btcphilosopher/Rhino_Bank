import React from 'react';
import { Briefcase, Shield, PieChart } from 'lucide-react';

export const PortfolioView: React.FC = () => {
  const portfolioPositions = [
    { id: 'POS-001', counterparty: 'BARCLAYS_CAPITAL_NY', type: '10Y SOFR OIS', notional: 100000000, dir: 'PAY_FIXED', pv: 418720, dv01: 84312, csa: 'ISDA 2016 VM (USD Cash)' },
    { id: 'POS-002', counterparty: 'GOLDMAN_SACHS_NY', type: '5Y SOFR OIS', notional: 250000000, dir: 'RECEIVE_FIXED', pv: -312000, dv01: -115500, csa: 'ISDA 2016 VM (USD Cash)' },
    { id: 'POS-003', counterparty: 'JP_MORGAN_CHASE', type: '2Y SOFR OIS', notional: 500000000, dir: 'PAY_FIXED', pv: 890000, dv01: 97250, csa: 'ISDA 2016 VM (USD Cash)' },
    { id: 'POS-004', counterparty: 'CITIGROUP_GLOBAL', type: '30Y SOFR OIS', notional: 50000000, dir: 'RECEIVE_FIXED', pv: -125000, dv01: -99250, csa: 'ISDA 2016 VM (USD Cash)' },
  ];

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex items-center justify-between">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <Briefcase className="w-4 h-4" />
            RHINOSWAPS PORTFOLIO & CREDIT RISK AGGREGATOR
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Institutional Portfolio Positions, Counterparty Exposure & XVA Breakdown
          </h1>
        </div>
      </div>

      {/* Aggregate Portfolio Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">TOTAL AGGREGATE NOTIONAL</span>
          <div className="text-xl font-bold text-[#f8fafc] mt-1">$900,000,000</div>
          <div className="text-[10px] text-[#94a3b8] mt-1">4 Open Institutional Positions</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">NET PORTFOLIO PV</span>
          <div className="text-xl font-bold text-[#10b981] mt-1">+$871,720</div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Gross PV: $1,745,720</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">NET PORTFOLIO DV01</span>
          <div className="text-xl font-bold text-[#38bdf8] mt-1">+$66,812 / bp</div>
          <div className="text-[10px] text-[#94a3b8] mt-1">Key-rate balanced</div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs">
          <span className="text-[#64748b] text-[10px] uppercase">CREDIT VALUATION ADJUSTMENT (CVA)</span>
          <div className="text-xl font-bold text-[#f59e0b] mt-1">-$42,350</div>
          <div className="text-[10px] text-[#94a3b8] mt-1">FVA: -$18,200 | MVA: -$9,100</div>
        </div>
      </div>

      {/* Positions Table */}
      <div className="bg-[#0f141c] border border-[#1e293b] rounded-xs overflow-hidden">
        <div className="bg-[#17202e] p-3 border-b border-[#1e293b] font-bold text-[#f8fafc]">
          PORTFOLIO POSITIONS LIST
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#121824] text-[#64748b] border-b border-[#1e293b] text-[10px] uppercase">
                <th className="p-3">TRADE ID</th>
                <th className="p-3">COUNTERPARTY</th>
                <th className="p-3">INSTRUMENT</th>
                <th className="p-3 text-right">NOTIONAL ($)</th>
                <th className="p-3 text-center">DIRECTION</th>
                <th className="p-3 text-right">NET PV ($)</th>
                <th className="p-3 text-right">DV01 ($/BP)</th>
                <th className="p-3">COLLATERAL CSA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {portfolioPositions.map((p) => (
                <tr key={p.id} className="hover:bg-[#17202e]/60">
                  <td className="p-3 font-bold text-[#38bdf8]">{p.id}</td>
                  <td className="p-3 text-[#f8fafc]">{p.counterparty}</td>
                  <td className="p-3 text-[#94a3b8]">{p.type}</td>
                  <td className="p-3 text-right font-semibold text-[#f8fafc]">${p.notional.toLocaleString()}</td>
                  <td className="p-3 text-center font-bold text-[#10b981]">{p.dir}</td>
                  <td className={`p-3 text-right font-bold ${p.pv >= 0 ? 'text-[#10b981]' : 'text-[#f43f5e]'}`}>
                    ${p.pv.toLocaleString()}
                  </td>
                  <td className="p-3 text-right text-[#f59e0b] font-bold">${p.dv01.toLocaleString()}</td>
                  <td className="p-3 text-[#64748b] text-[10px]">{p.csa}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
