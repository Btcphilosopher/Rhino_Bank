import React from 'react';
import { Activity, ShieldCheck, Database, Calendar, Server, ChevronRight } from 'lucide-react';

interface HeaderProps {
  valuationDate: string;
  onValuationDateChange: (date: string) => void;
  onOpenSignatureDeal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  valuationDate,
  onValuationDateChange,
  onOpenSignatureDeal,
}) => {
  return (
    <header className="bg-[#0f141c] border-b border-[#1e293b] px-4 py-2 text-xs text-[#94a3b8] flex flex-wrap items-center justify-between gap-3">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-[#1e293b] border border-[#334155] flex items-center justify-center font-bold text-xs text-[#f8fafc] rounded-xs">
            R
          </div>
          <span className="font-mono text-sm font-bold tracking-wider text-[#f8fafc]">
            RHINOSWAPS<span className="text-[#38bdf8]">.OS</span>
          </span>
        </div>
        <span className="text-[#475569] hidden md:inline">|</span>
        <span className="hidden md:inline font-mono text-[10px] text-[#64748b] tracking-widest uppercase">
          RhinoBank Institutional Rates Engine
        </span>
      </div>

      {/* Market Indicators */}
      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-1.5 bg-[#17202e] px-2.5 py-1 rounded-xs border border-[#1e293b]">
          <span className="text-[#64748b]">CURRENCY:</span>
          <span className="font-mono font-semibold text-[#f8fafc]">USD</span>
        </div>

        <div className="flex items-center gap-1.5 bg-[#17202e] px-2.5 py-1 rounded-xs border border-[#1e293b]">
          <span className="text-[#64748b]">SOFR FIXING:</span>
          <span className="font-mono font-semibold text-[#10b981]">4.3500%</span>
        </div>

        <div className="flex items-center gap-1.5 bg-[#17202e] px-2.5 py-1 rounded-xs border border-[#1e293b]">
          <Calendar className="w-3.5 h-3.5 text-[#38bdf8]" />
          <span className="text-[#64748b]">VALUATION DATE:</span>
          <input
            type="date"
            value={valuationDate}
            onChange={(e) => onValuationDateChange(e.target.value)}
            className="bg-transparent font-mono font-medium text-[#f8fafc] focus:outline-none cursor-pointer"
          />
        </div>

        <div className="flex items-center gap-1.5 bg-[#17202e] px-2.5 py-1 rounded-xs border border-[#1e293b]">
          <Database className="w-3.5 h-3.5 text-[#eab308]" />
          <span className="text-[#64748b]">DATA:</span>
          <span className="font-mono font-medium text-[#eab308] uppercase">SYNTHETIC (DETERMINISTIC)</span>
        </div>

        <button
          onClick={onOpenSignatureDeal}
          className="flex items-center gap-1 bg-[#1e293b] hover:bg-[#334155] text-[#f8fafc] px-3 py-1 rounded-xs border border-[#38bdf8]/40 font-mono text-[11px] font-semibold transition-colors cursor-pointer"
        >
          <span>THE RHINOSWAPS DEAL</span>
          <ChevronRight className="w-3 h-3 text-[#38bdf8]" />
        </button>
      </div>
    </header>
  );
};
