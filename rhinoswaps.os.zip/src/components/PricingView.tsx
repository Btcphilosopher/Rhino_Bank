import React, { useState } from 'react';
import { getDefaultSOFRCurve } from '../engine/syntheticMarket';
import { priceSwap } from '../engine/swapPricer';
import { SwapTradeSpec } from '../types/swap';
import { Calculator, ArrowDownUp } from 'lucide-react';

export const PricingView: React.FC = () => {
  const [notional, setNotional] = useState<number>(100000000);
  const [fixedRatePct, setFixedRatePct] = useState<number>(4.1875);
  const [tenorStr, setTenorStr] = useState<string>('10Y');

  const tradeSpec: SwapTradeSpec = {
    tradeId: 'PRICING-EXPLORER-01',
    counterparty: 'GENERIC_BANK',
    notional,
    currency: 'USD',
    type: 'SOFR_OIS',
    direction: 'PAY_FIXED',
    effectiveDate: '2026-09-24',
    maturityTenor: tenorStr,
    maturityDate: '2036-09-24',
    fixedRate: fixedRatePct / 100.0,
    floatingIndex: 'SOFR',
    fixedLegFrequency: 'SEMI_ANNUAL',
    floatingLegFrequency: 'QUARTERLY',
    fixedDayCount: '30/360',
    floatingDayCount: 'ACT/360',
    businessDayConvention: 'MODIFIED_FOLLOWING',
    calendar: 'USNY',
    paymentLagDays: 2,
    resetLagDays: 0,
    compoundingMethod: 'DAILY_COMPOUNDED',
    notionalAmortization: 'BULLET',
    collateralCurrency: 'USD',
    tradeDate: '2026-09-22',
  };

  const curve = getDefaultSOFRCurve();
  const { valuation } = priceSwap(tradeSpec, curve, curve);

  return (
    <div className="p-4 space-y-6 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-[#38bdf8] font-bold uppercase flex items-center gap-1.5">
            <Calculator className="w-4 h-4" />
            SWAP CALCULATION EXPLORER & PAR RATE SOLVER
          </div>
          <h1 className="text-lg font-bold text-[#f8fafc] mt-0.5">
            Interactive Analytical Valuation Engine
          </h1>
        </div>
      </div>

      {/* Control Sliders & Inputs */}
      <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-4">
        <div className="border-b border-[#1e293b] pb-2 font-bold text-[#f8fafc]">
          TRADE PARAMETERS
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="text-[#64748b] block mb-1">NOTIONAL: ${notional.toLocaleString()}</label>
            <input
              type="range"
              min="10000000"
              max="1000000000"
              step="10000000"
              value={notional}
              onChange={(e) => setNotional(Number(e.target.value))}
              className="w-full accent-[#38bdf8] cursor-pointer"
            />
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">FIXED RATE: {fixedRatePct.toFixed(4)}%</label>
            <input
              type="range"
              min="1.0"
              max="8.0"
              step="0.01"
              value={fixedRatePct}
              onChange={(e) => setFixedRatePct(Number(e.target.value))}
              className="w-full accent-[#10b981] cursor-pointer"
            />
          </div>

          <div>
            <label className="text-[#64748b] block mb-1">MATURITY TENOR</label>
            <div className="flex gap-2">
              {['2Y', '5Y', '10Y', '30Y'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTenorStr(t)}
                  className={`flex-1 py-1.5 rounded-xs font-bold border cursor-pointer ${
                    tenorStr === t ? 'bg-[#38bdf8] text-[#0b0e14] border-[#38bdf8]' : 'bg-[#17202e] text-[#64748b] border-[#1e293b]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Valuation Outputs Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
          <div className="text-[#38bdf8] font-bold border-b border-[#1e293b] pb-2">
            FIXED LEG VALUATION
          </div>
          <div className="flex justify-between py-1 border-b border-[#1e293b]">
            <span className="text-[#64748b]">FIXED RATE</span>
            <span className="font-bold text-[#f8fafc]">{(tradeSpec.fixedRate * 100).toFixed(4)}%</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#1e293b]">
            <span className="text-[#64748b]">ANNUITY A = Σ(α_i * DF_i)</span>
            <span className="font-bold text-[#f8fafc]">{valuation.fixedAnnuity.toFixed(4)}</span>
          </div>
          <div className="flex justify-between py-1 text-sm font-bold text-[#38bdf8]">
            <span>PV FIXED LEG</span>
            <span>${Math.round(valuation.fixedLegPV).toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-[#0f141c] border border-[#1e293b] p-4 rounded-xs space-y-3">
          <div className="text-[#10b981] font-bold border-b border-[#1e293b] pb-2">
            FLOATING LEG VALUATION
          </div>
          <div className="flex justify-between py-1 border-b border-[#1e293b]">
            <span className="text-[#64748b]">PAR SWAP RATE SOLVED</span>
            <span className="font-bold text-[#10b981]">{(valuation.parRate * 100).toFixed(4)}%</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#1e293b]">
            <span className="text-[#64748b]">RATE DIFFERENCE</span>
            <span className="font-bold text-[#f59e0b]">{valuation.rateDifferenceBp.toFixed(2)} bp</span>
          </div>
          <div className="flex justify-between py-1 text-sm font-bold text-[#10b981]">
            <span>PV FLOATING LEG</span>
            <span>${Math.round(valuation.floatingLegPV).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Net PV Summary Box */}
      <div className="bg-[#121824] border border-[#38bdf8]/40 p-4 rounded-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[#64748b] text-[10px] uppercase block">NET PRESENT VALUE (PAY FIXED DIRECTION)</span>
          <div className="text-2xl font-bold text-[#10b981] mt-1">
            ${Math.round(valuation.netPV).toLocaleString()}
          </div>
        </div>
        <div className="flex gap-4">
          <div className="text-right">
            <span className="text-[#64748b] text-[10px] uppercase block">DV01 (+1BP)</span>
            <span className="text-base font-bold text-[#f59e0b]">${Math.round(valuation.dv01).toLocaleString()}</span>
          </div>
          <div className="text-right">
            <span className="text-[#64748b] text-[10px] uppercase block">CONVEXITY</span>
            <span className="text-base font-bold text-[#38bdf8]">{valuation.convexity.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
