import React from 'react';

export type TabType = 
  | 'OVERVIEW'
  | 'SWAP_TICKET'
  | 'CURVES'
  | 'PRICING'
  | 'RISK'
  | 'HEDGING'
  | 'BASIS'
  | 'VOLATILITY'
  | 'PORTFOLIO'
  | 'SCENARIOS'
  | 'RESEARCH'
  | 'DATA_PROVENANCE'
  | 'SIGNATURE_DEMO';

interface NavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const TABS: { id: TabType; label: string; shortcut: string }[] = [
  { id: 'OVERVIEW', label: 'MARKET', shortcut: 'F1' },
  { id: 'SIGNATURE_DEMO', label: 'SIGNATURE DEMO', shortcut: 'F2' },
  { id: 'SWAP_TICKET', label: 'SWAP TICKET', shortcut: 'F3' },
  { id: 'CURVES', label: 'CURVES', shortcut: 'F4' },
  { id: 'PRICING', label: 'PRICING', shortcut: 'F5' },
  { id: 'RISK', label: 'RISK', shortcut: 'F6' },
  { id: 'HEDGING', label: 'HEDGING', shortcut: 'F7' },
  { id: 'BASIS', label: 'BASIS', shortcut: 'F8' },
  { id: 'VOLATILITY', label: 'VOLATILITY', shortcut: 'F9' },
  { id: 'PORTFOLIO', label: 'PORTFOLIO', shortcut: 'F10' },
  { id: 'SCENARIOS', label: 'SCENARIOS', shortcut: 'F11' },
  { id: 'RESEARCH', label: 'RESEARCH', shortcut: 'F12' },
  { id: 'DATA_PROVENANCE', label: 'DATA PROVENANCE', shortcut: 'P' },
];

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="bg-[#0b0e14] border-b border-[#1e293b] px-3 pt-1 overflow-x-auto scrollbar-none flex items-center space-x-1">
      {TABS.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`px-3 py-2 text-[11px] font-mono font-semibold tracking-wider whitespace-nowrap border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              isActive
                ? 'border-[#38bdf8] text-[#f8fafc] bg-[#17202e]'
                : 'border-transparent text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#0f141c]'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`text-[9px] px-1 py-0.2 rounded-xs font-normal ${
                isActive ? 'bg-[#38bdf8]/20 text-[#38bdf8]' : 'bg-[#1e293b] text-[#64748b]'
              }`}
            >
              {tab.shortcut}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
