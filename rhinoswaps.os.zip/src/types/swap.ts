export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF' | 'CAD' | 'AUD';

export type SwapType = 'SOFR_OIS' | 'FIXED_FLOAT_IRS' | 'SOFR_BASIS' | 'TERM_SOFR' | 'FED_FUNDS';

export type PayReceive = 'PAY_FIXED' | 'RECEIVE_FIXED';

export type DayCountConvention = 'ACT/360' | 'ACT/365' | '30/360' | '30E/360';

export type BusinessDayConvention = 
  | 'FOLLOWING' 
  | 'MODIFIED_FOLLOWING' 
  | 'PRECEDING' 
  | 'MODIFIED_PRECEDING' 
  | 'UNADJUSTED';

export type Frequency = 'ANNUAL' | 'SEMI_ANNUAL' | 'QUARTERLY' | 'MONTHLY' | 'DAILY';

export type InterpolationMethod = 
  | 'LINEAR' 
  | 'LOG_LINEAR' 
  | 'CUBIC_SPLINE' 
  | 'MONOTONIC_CUBIC' 
  | 'NELSON_SIEGEL' 
  | 'NELSON_SIEGEL_SVENSSON';

export interface CalendarHoliday {
  date: string;
  name: string;
}

export interface SwapTradeSpec {
  tradeId: string;
  counterparty: string;
  notional: number;
  currency: Currency;
  type: SwapType;
  direction: PayReceive;
  effectiveDate: string;
  maturityTenor: string; // e.g. "10Y", "5Y"
  maturityDate: string;
  fixedRate: number; // e.g., 0.041875 for 4.1875%
  floatingIndex: string; // e.g., "SOFR"
  fixedLegFrequency: Frequency;
  floatingLegFrequency: Frequency;
  fixedDayCount: DayCountConvention;
  floatingDayCount: DayCountConvention;
  businessDayConvention: BusinessDayConvention;
  calendar: string; // e.g., "USNY"
  paymentLagDays: number;
  resetLagDays: number;
  compoundingMethod: 'DAILY_COMPOUNDED' | 'SIMPLE' | 'NONE';
  notionalAmortization: 'BULLET' | 'AMORTIZING' | 'ACCRETING';
  collateralCurrency: Currency;
  tradeDate: string;
}

export interface CashFlowPeriod {
  periodNumber: number;
  startDate: string;
  endDate: string;
  paymentDate: string;
  fixingDate: string;
  accrualFraction: number; // e.g. 0.5000
  notional: number;
  fixedRate?: number;
  forecastRate?: number;
  discountFactor: number;
  cashFlowAmount: number;
  discountedCashFlow: number;
  legType: 'FIXED' | 'FLOATING';
  compoundedObservations?: DailyObservation[];
}

export interface DailyObservation {
  date: string;
  sofrRate: number;
  weight: number;
  compoundedFactor: number;
}

export interface SwapSchedule {
  tradeId: string;
  fixedLegPeriods: CashFlowPeriod[];
  floatingLegPeriods: CashFlowPeriod[];
  totalFixedCashFlow: number;
  totalFloatingCashFlow: number;
}

export interface CurvePoint {
  tenor: string;
  months: number;
  rate: number; // Annualized rate e.g. 0.042
  discountFactor: number;
  zeroRate: number;
  forwardRate: number;
  instrumentType: 'SOFR_DEPOSIT' | 'SOFR_FUTURE' | 'OIS_SWAP';
  isObserved: boolean;
}

export interface CurveDefinition {
  name: string;
  asOfDate: string;
  currency: Currency;
  interpolation: InterpolationMethod;
  points: CurvePoint[];
}

export interface SwapValuationResult {
  tradeId: string;
  valuationDate: string;
  parRate: number;
  fixedLegPV: number;
  floatingLegPV: number;
  netPV: number;
  cleanPV: number;
  dirtyPV: number;
  accruedInterest: number;
  fixedAnnuity: number;
  rateDifferenceBp: number;
  dv01: number;
  pv01: number;
  convexity: number;
  keyRateDV01: Record<string, number>;
  carry1M: number;
  roll1M: number;
}

export interface KeyRateRiskBucket {
  tenor: string; // "2Y", "3Y", "5Y", "7Y", "10Y", "15Y", "20Y", "30Y"
  dv01: number;
  percentage: number;
}

export interface SwaptionSpec {
  tradeId: string;
  type: 'PAYER' | 'RECEIVER';
  expiryTenor: string; // "1Y"
  underlyingTenor: string; // "10Y"
  notional: number;
  strike: number;
  impliedVol: number; // e.g. 0.22 (22% lognormal) or 0.0075 (75bps normal)
  modelType: 'BLACK_76' | 'BACHELIER_NORMAL' | 'SABR';
}

export interface SwaptionGreeks {
  price: number;
  premiumPct: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  annuity: number;
  forwardSwapRate: number;
}

export interface SOFRFuturesContract {
  code: string; // e.g. "SR3H26"
  description: string;
  expiryDate: string;
  price: number; // e.g. 95.80
  impliedRate: number; // 4.20%
  dv01PerContract: number; // $25
}

export interface HedgeResult {
  targetTradeId: string;
  unhedgedDV01: number;
  recommendedFuturesContracts: {
    contract: SOFRFuturesContract;
    quantity: number;
    hedgeDV01: number;
  }[];
  totalHedgeDV01: number;
  residualDV01: number;
  hedgeEfficiencyPct: number;
}

export interface ScenarioImpact {
  scenarioName: string;
  curveShiftDescription: string;
  pvChange: number;
  dv01Change: number;
  newNetPV: number;
  newParRate: number;
}

export interface PortfolioSummary {
  totalPositions: number;
  totalNotional: number;
  netPV: number;
  grossPV: number;
  netDV01: number;
  keyRates: Record<string, number>;
  expectedExposure: number;
  potentialFutureExposure95: number;
  cva: number;
  fva: number;
  dva: number;
}

export interface DataProvenanceNode {
  id: string;
  label: string;
  stage: 'MARKET_DATA' | 'CURVE' | 'SCHEDULE' | 'DISCOUNT_FACTORS' | 'CASH_FLOWS' | 'PV' | 'RISK' | 'HEDGE';
  inputs: Record<string, any>;
  formula: string;
  outputValue: string;
  source: string;
  timestamp: string;
}
