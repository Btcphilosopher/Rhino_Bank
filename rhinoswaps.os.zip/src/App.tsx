import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation, TabType } from './components/Navigation';
import { OverviewView } from './components/OverviewView';
import { SignatureDemoView } from './components/SignatureDemoView';
import { SwapTicketView } from './components/SwapTicketView';
import { CurveLabView } from './components/CurveLabView';
import { PricingView } from './components/PricingView';
import { RiskView } from './components/RiskView';
import { HedgingView } from './components/HedgingView';
import { BasisView } from './components/BasisView';
import { VolatilityView } from './components/VolatilityView';
import { PortfolioView } from './components/PortfolioView';
import { ScenariosView } from './components/ScenariosView';
import { ResearchView } from './components/ResearchView';
import { DataProvenanceView } from './components/DataProvenanceView';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('OVERVIEW');
  const [valuationDate, setValuationDate] = useState<string>('2026-09-22');

  // Keyboard shortcut handlers for institutional navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F1') { e.preventDefault(); setActiveTab('OVERVIEW'); }
      if (e.key === 'F2') { e.preventDefault(); setActiveTab('SIGNATURE_DEMO'); }
      if (e.key === 'F3') { e.preventDefault(); setActiveTab('SWAP_TICKET'); }
      if (e.key === 'F4') { e.preventDefault(); setActiveTab('CURVES'); }
      if (e.key === 'F5') { e.preventDefault(); setActiveTab('PRICING'); }
      if (e.key === 'F6') { e.preventDefault(); setActiveTab('RISK'); }
      if (e.key === 'F7') { e.preventDefault(); setActiveTab('HEDGING'); }
      if (e.key === 'F8') { e.preventDefault(); setActiveTab('BASIS'); }
      if (e.key === 'F9') { e.preventDefault(); setActiveTab('VOLATILITY'); }
      if (e.key === 'F10') { e.preventDefault(); setActiveTab('PORTFOLIO'); }
      if (e.key === 'F11') { e.preventDefault(); setActiveTab('SCENARIOS'); }
      if (e.key === 'F12') { e.preventDefault(); setActiveTab('RESEARCH'); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-[#0b0e14] text-[#d1d5db] flex flex-col font-sans selection:bg-[#1e293b] selection:text-[#f8fafc]">
      {/* Institutional Top Header */}
      <Header
        valuationDate={valuationDate}
        onValuationDateChange={setValuationDate}
        onOpenSignatureDeal={() => setActiveTab('SIGNATURE_DEMO')}
      />

      {/* Primary Navigation Bar */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto">
        {activeTab === 'OVERVIEW' && <OverviewView />}
        {activeTab === 'SIGNATURE_DEMO' && <SignatureDemoView />}
        {activeTab === 'SWAP_TICKET' && <SwapTicketView />}
        {activeTab === 'CURVES' && <CurveLabView />}
        {activeTab === 'PRICING' && <PricingView />}
        {activeTab === 'RISK' && <RiskView />}
        {activeTab === 'HEDGING' && <HedgingView />}
        {activeTab === 'BASIS' && <BasisView />}
        {activeTab === 'VOLATILITY' && <VolatilityView />}
        {activeTab === 'PORTFOLIO' && <PortfolioView />}
        {activeTab === 'SCENARIOS' && <ScenariosView />}
        {activeTab === 'RESEARCH' && <ResearchView />}
        {activeTab === 'DATA_PROVENANCE' && <DataProvenanceView />}
      </main>

      {/* Institutional Footer */}
      <footer className="bg-[#0f141c] border-t border-[#1e293b] px-4 py-2 text-[10px] font-mono text-[#64748b] flex flex-wrap justify-between items-center">
        <div>RHINOSWAPS.OS v3.6.0 • RhinoBank / RhinoQuant Quantitative Engineering</div>
        <div className="flex gap-4">
          <span>MODEL: MONOTONIC CUBIC OIS</span>
          <span>CALENDAR: USNY</span>
          <span>SYSTEM STATUS: ONLINE</span>
        </div>
      </footer>
    </div>
  );
}
