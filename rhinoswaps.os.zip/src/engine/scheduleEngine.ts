import { SwapTradeSpec, CashFlowPeriod, SwapSchedule, Frequency } from '../types/swap';
import { addMonths, adjustBusinessDay, calculateYearFraction, addDays } from './dayCount';
import { calculateCompoundedSOFR } from './sofrCompounding';

function frequencyToMonths(freq: Frequency): number {
  switch (freq) {
    case 'ANNUAL': return 12;
    case 'SEMI_ANNUAL': return 6;
    case 'QUARTERLY': return 3;
    case 'MONTHLY': return 1;
    case 'DAILY': return 0.033;
    default: return 6;
  }
}

export function generateSwapSchedule(
  trade: SwapTradeSpec,
  discountCurveFn: (tYears: number) => number,
  forecastCurveFn: (tYears: number) => number
): SwapSchedule {
  const fixedLegPeriods: CashFlowPeriod[] = [];
  const floatingLegPeriods: CashFlowPeriod[] = [];

  // Parse tenor e.g. "10Y" -> 10 years
  const tenorYears = parseInt(trade.maturityTenor.replace('Y', ''), 10) || 10;
  const fixedMonths = frequencyToMonths(trade.fixedLegFrequency);
  const floatMonths = frequencyToMonths(trade.floatingLegFrequency);

  const numFixedPeriods = Math.round((tenorYears * 12) / fixedMonths);
  const numFloatPeriods = Math.round((tenorYears * 12) / floatMonths);

  let totalFixedCashFlow = 0;
  let totalFloatingCashFlow = 0;

  // 1. Generate Fixed Leg
  let pStart = trade.effectiveDate;
  for (let i = 1; i <= numFixedPeriods; i++) {
    let pEnd = addMonths(trade.effectiveDate, i * fixedMonths);
    if (i === numFixedPeriods) pEnd = trade.maturityDate || pEnd;

    const unadjustedPaymentDate = pEnd;
    const paymentDate = adjustBusinessDay(unadjustedPaymentDate, trade.businessDayConvention);
    const accrualFraction = calculateYearFraction(pStart, pEnd, trade.fixedDayCount);

    const tYears = calculateYearFraction(trade.effectiveDate, paymentDate, 'ACT/365');
    const df = discountCurveFn(tYears);

    const cashFlow = trade.notional * trade.fixedRate * accrualFraction;
    const discountedCashFlow = cashFlow * df;

    totalFixedCashFlow += cashFlow;

    fixedLegPeriods.push({
      periodNumber: i,
      startDate: pStart,
      endDate: pEnd,
      paymentDate,
      fixingDate: pStart,
      accrualFraction,
      notional: trade.notional,
      fixedRate: trade.fixedRate,
      discountFactor: df,
      cashFlowAmount: cashFlow,
      discountedCashFlow,
      legType: 'FIXED',
    });

    pStart = pEnd;
  }

  // 2. Generate Floating Leg (SOFR OIS)
  pStart = trade.effectiveDate;
  for (let j = 1; j <= numFloatPeriods; j++) {
    let pEnd = addMonths(trade.effectiveDate, j * floatMonths);
    if (j === numFloatPeriods) pEnd = trade.maturityDate || pEnd;

    const unadjustedPaymentDate = pEnd;
    const paymentDate = adjustBusinessDay(unadjustedPaymentDate, trade.businessDayConvention);
    const accrualFraction = calculateYearFraction(pStart, pEnd, trade.floatingDayCount);

    const tYears = calculateYearFraction(trade.effectiveDate, paymentDate, 'ACT/365');
    const df = discountCurveFn(tYears);

    // Get expected forecast rate from forward curve
    const tStartYears = calculateYearFraction(trade.effectiveDate, pStart, 'ACT/365');
    const forecastRate = forecastCurveFn(tYears > 0 ? (tStartYears + tYears) / 2 : 0.04);

    const compResult = calculateCompoundedSOFR(pStart, pEnd, forecastRate);
    const cashFlow = trade.notional * compResult.compoundedRate * accrualFraction;
    const discountedCashFlow = cashFlow * df;

    totalFloatingCashFlow += cashFlow;

    floatingLegPeriods.push({
      periodNumber: j,
      startDate: pStart,
      endDate: pEnd,
      paymentDate,
      fixingDate: pStart,
      accrualFraction,
      notional: trade.notional,
      forecastRate: compResult.compoundedRate,
      discountFactor: df,
      cashFlowAmount: cashFlow,
      discountedCashFlow,
      legType: 'FLOATING',
      compoundedObservations: compResult.observations.slice(0, 10), // keep top observations
    });

    pStart = pEnd;
  }

  return {
    tradeId: trade.tradeId,
    fixedLegPeriods,
    floatingLegPeriods,
    totalFixedCashFlow,
    totalFloatingCashFlow,
  };
}
