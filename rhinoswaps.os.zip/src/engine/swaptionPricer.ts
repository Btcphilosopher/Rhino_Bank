import { SwaptionSpec, SwaptionGreeks } from '../types/swap';

/**
 * Standard Normal Cumulative Distribution Function (CDF)
 */
function normCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.sqrt(2.0);
  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

/**
 * Standard Normal Probability Density Function (PDF)
 */
function normPDF(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

/**
 * Prices a Swaption using Black-76 or Bachelier (Normal) model
 */
export function priceSwaption(
  spec: SwaptionSpec,
  forwardSwapRate: number = 0.041875,
  annuity: number = 8.4312
): SwaptionGreeks {
  const T = parseFloat(spec.expiryTenor.replace('Y', '')) || 1.0;
  const F = forwardSwapRate;
  const K = spec.strike || F;
  const sigma = spec.impliedVol;
  const isPayer = spec.type === 'PAYER';
  const omega = isPayer ? 1 : -1;

  if (spec.modelType === 'BACHELIER_NORMAL') {
    // Bachelier / Normal Model:
    // d = (F - K) / (sigma * sqrt(T))
    const sigmaSqrtT = sigma * Math.sqrt(T);
    const d = (F - K) / (sigmaSqrtT || 1e-6);

    const price = spec.notional * annuity * ((F - K) * omega * normCDF(omega * d) + sigmaSqrtT * normPDF(d));
    const premiumPct = (price / spec.notional) * 100.0;

    const delta = spec.notional * annuity * omega * normCDF(omega * d);
    const gamma = (spec.notional * annuity * normPDF(d)) / sigmaSqrtT;
    const vega = spec.notional * annuity * Math.sqrt(T) * normPDF(d);
    const theta = -(spec.notional * annuity * sigma * normPDF(d)) / (2 * Math.sqrt(T));
    const rho = spec.notional * annuity * T * normCDF(omega * d);

    return {
      price,
      premiumPct,
      delta,
      gamma,
      vega,
      theta,
      rho,
      annuity,
      forwardSwapRate: F,
    };
  } else {
    // Black-76 Lognormal Model:
    // d1 = [ln(F/K) + 0.5*sigma^2*T] / (sigma * sqrt(T))
    // d2 = d1 - sigma * sqrt(T)
    const sigmaSqrtT = sigma * Math.sqrt(T);
    const d1 = (Math.log(F / K) + 0.5 * sigma * sigma * T) / (sigmaSqrtT || 1e-6);
    const d2 = d1 - sigmaSqrtT;

    const price = spec.notional * annuity * omega * (F * normCDF(omega * d1) - K * normCDF(omega * d2));
    const premiumPct = (price / spec.notional) * 100.0;

    const delta = spec.notional * annuity * omega * normCDF(omega * d1);
    const gamma = (spec.notional * annuity * normPDF(d1)) / (F * sigmaSqrtT);
    const vega = spec.notional * annuity * F * Math.sqrt(T) * normPDF(d1);
    const theta = -(spec.notional * annuity * F * sigma * normPDF(d1)) / (2 * Math.sqrt(T));
    const rho = spec.notional * annuity * K * T * normCDF(omega * d2);

    return {
      price,
      premiumPct,
      delta,
      gamma,
      vega,
      theta,
      rho,
      annuity,
      forwardSwapRate: F,
    };
  }
}
