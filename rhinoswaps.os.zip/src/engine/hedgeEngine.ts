import { SOFRFuturesContract, HedgeResult } from '../types/swap';

export const SAMPLE_SOFR_FUTURES: SOFRFuturesContract[] = [
  { code: 'SR3Z25', description: 'CME 3M SOFR Dec 2025', expiryDate: '2025-12-16', price: 95.72, impliedRate: 0.0428, dv01PerContract: 25.0 },
  { code: 'SR3H26', description: 'CME 3M SOFR Mar 2026', expiryDate: '2026-03-17', price: 95.82, impliedRate: 0.0418, dv01PerContract: 25.0 },
  { code: 'SR3M26', description: 'CME 3M SOFR Jun 2026', expiryDate: '2026-06-16', price: 95.95, impliedRate: 0.0405, dv01PerContract: 25.0 },
  { code: 'SR3U26', description: 'CME 3M SOFR Sep 2026', expiryDate: '2026-09-15', price: 96.08, impliedRate: 0.0392, dv01PerContract: 25.0 },
  { code: 'SR3Z26', description: 'CME 3M SOFR Dec 2026', expiryDate: '2026-12-15', price: 96.12, impliedRate: 0.0388, dv01PerContract: 25.0 },
  { code: 'SR3H27', description: 'CME 3M SOFR Mar 2027', expiryDate: '2027-03-16', price: 96.10, impliedRate: 0.0390, dv01PerContract: 25.0 },
  { code: 'SR3M27', description: 'CME 3M SOFR Jun 2027', expiryDate: '2027-06-15', price: 96.05, impliedRate: 0.0395, dv01PerContract: 25.0 },
  { code: 'SR3U27', description: 'CME 3M SOFR Sep 2027', expiryDate: '2027-09-21', price: 95.98, impliedRate: 0.0402, dv01PerContract: 25.0 },
];

export function calculateFuturesHedge(
  targetTradeId: string,
  targetDV01: number
): HedgeResult {
  // Number of futures contracts needed: N = - TargetDV01 / DV01_Contract
  // For 3M SOFR Futures, $1m notional per contract = $25 DV01 per contract.
  const primaryContract = SAMPLE_SOFR_FUTURES[1]; // SR3H26
  const rawQuantity = -targetDV01 / primaryContract.dv01PerContract;
  const numContracts = Math.round(rawQuantity);

  const totalHedgeDV01 = numContracts * primaryContract.dv01PerContract;
  const residualDV01 = targetDV01 + totalHedgeDV01;

  const hedgeEfficiencyPct = Math.min(100.0, Math.max(0, (1 - Math.abs(residualDV01) / Math.abs(targetDV01 || 1)) * 100));

  return {
    targetTradeId,
    unhedgedDV01: targetDV01,
    recommendedFuturesContracts: [
      {
        contract: primaryContract,
        quantity: numContracts,
        hedgeDV01: totalHedgeDV01,
      },
      {
        contract: SAMPLE_SOFR_FUTURES[3], // SR3U26
        quantity: Math.round(numContracts * 0.5),
        hedgeDV01: Math.round(numContracts * 0.5) * 25.0,
      }
    ],
    totalHedgeDV01,
    residualDV01,
    hedgeEfficiencyPct,
  };
}
