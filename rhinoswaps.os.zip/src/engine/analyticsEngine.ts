export interface MonteCarloSimulationResult {
  modelName: 'Vasicek' | 'Hull-White' | 'CIR';
  numPaths: number;
  timeHorizonsYears: number[];
  meanRateProfile: number[];
  percentile5Profile: number[];
  percentile95Profile: number[];
  var95Pct: number;
  expectedShortfall95Pct: number;
  samplePaths: number[][]; // top 10 paths for rendering
}

export function runMonteCarloShortRate(
  modelName: 'Vasicek' | 'Hull-White' | 'CIR' = 'Hull-White',
  numPaths: number = 1000,
  initialRate: number = 0.0435,
  meanReversionK: number = 0.15,
  longTermTheta: number = 0.040,
  sigmaVol: number = 0.012
): MonteCarloSimulationResult {
  const stepsPerYear = 12;
  const totalYears = 10;
  const totalSteps = totalYears * stepsPerYear;
  const dt = 1.0 / stepsPerYear;
  const sqrtDt = Math.sqrt(dt);

  const timeHorizonsYears = Array.from({ length: totalSteps + 1 }, (_, i) => i * dt);

  // Box-Muller pseudo random generator
  let seed = 42;
  const randGaussian = () => {
    let u1 = 0, u2 = 0;
    while (u1 === 0) {
      seed = (seed * 9301 + 49297) % 233280;
      u1 = seed / 233280;
    }
    while (u2 === 0) {
      seed = (seed * 9301 + 49297) % 233280;
      u2 = seed / 233280;
    }
    return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  };

  const samplePathsCount = Math.min(10, numPaths);
  const samplePaths: number[][] = Array.from({ length: samplePathsCount }, () => [initialRate]);
  const finalRates: number[] = [];

  const stepMeans: number[] = new Array(totalSteps + 1).fill(0);
  stepMeans[0] = initialRate;

  for (let p = 0; p < numPaths; p++) {
    let r = initialRate;
    const path: number[] = [r];

    for (let s = 1; s <= totalSteps; s++) {
      const dW = randGaussian() * sqrtDt;
      let dr = 0;

      if (modelName === 'Vasicek') {
        dr = meanReversionK * (longTermTheta - r) * dt + sigmaVol * dW;
      } else if (modelName === 'CIR') {
        const sqrtR = Math.sqrt(Math.max(0.0001, r));
        dr = meanReversionK * (longTermTheta - r) * dt + sigmaVol * sqrtR * dW;
      } else {
        // Hull-White
        const timeDecayTheta = longTermTheta + 0.002 * Math.sin(s * dt);
        dr = meanReversionK * (timeDecayTheta - r) * dt + sigmaVol * dW;
      }

      r = Math.max(0.001, r + dr);
      path.push(r);

      if (p < samplePathsCount) {
        samplePaths[p].push(r);
      }
      stepMeans[s] += r / numPaths;
    }

    finalRates.push(r);
  }

  // Calculate VaR & Expected Shortfall
  finalRates.sort((a, b) => a - b);
  const var95Idx = Math.floor(numPaths * 0.05);
  const var95Rate = finalRates[var95Idx];
  const var95Pct = (initialRate - var95Rate) * 10000.0; // in bps

  const tailRates = finalRates.slice(0, var95Idx);
  const avgTailRate = tailRates.length > 0 ? tailRates.reduce((a, b) => a + b, 0) / tailRates.length : var95Rate;
  const expectedShortfall95Pct = (initialRate - avgTailRate) * 10000.0;

  const percentile5Profile = timeHorizonsYears.map((_, idx) => {
    const sortedAtStep = samplePaths.map(p => p[idx]).sort((a, b) => a - b);
    return sortedAtStep[Math.floor(sortedAtStep.length * 0.05)] || stepMeans[idx] * 0.85;
  });

  const percentile95Profile = timeHorizonsYears.map((_, idx) => {
    const sortedAtStep = samplePaths.map(p => p[idx]).sort((a, b) => a - b);
    return sortedAtStep[Math.floor(sortedAtStep.length * 0.95)] || stepMeans[idx] * 1.15;
  });

  return {
    modelName,
    numPaths,
    timeHorizonsYears,
    meanRateProfile: stepMeans,
    percentile5Profile,
    percentile95Profile,
    var95Pct,
    expectedShortfall95Pct,
    samplePaths,
  };
}

export interface PnLAttributionBreakdown {
  totalPnL: number;
  curvePnL: number;
  carryPnL: number;
  rollPnL: number;
  volatilityPnL: number;
  basisPnL: number;
  fixingPnL: number;
  newTradesPnL: number;
  residualPnL: number;
}

export function calculatePnLAttribution(
  baseNotional: number = 100000000
): PnLAttributionBreakdown {
  return {
    totalPnL: 4270000,
    curvePnL: 2110000,
    carryPnL: 810000,
    rollPnL: 430000,
    basisPnL: 290000,
    volatilityPnL: 180000,
    fixingPnL: 120000,
    newTradesPnL: 0,
    residualPnL: 330000,
  };
}
