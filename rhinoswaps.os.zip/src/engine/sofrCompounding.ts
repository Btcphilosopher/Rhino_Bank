import { DailyObservation } from '../types/swap';
import { calculateYearFraction, addDays } from './dayCount';

/**
 * Calculates compounded SOFR rate over an observation period
 * Compounded Index = Π (1 + r_i * n_i / 360) - 1
 * Annualized Effective Rate = [Compounded Index] * (360 / N_total)
 */
export function calculateCompoundedSOFR(
  startDateStr: string,
  endDateStr: string,
  baseSOFRRate: number = 0.0435, // e.g. 4.35%
  rateNoiseSpread: number = 0.0005 // realistic slight daily fluctuation
): {
  compoundedRate: number;
  compoundedIndex: number;
  totalAccrualDays: number;
  observations: DailyObservation[];
} {
  const observations: DailyObservation[] = [];
  let currentDate = startDateStr;
  let runningFactor = 1.0;
  let totalDays = 0;

  let seed = 12345;
  const pseudoRandom = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  while (currentDate < endDateStr) {
    const nextDate = addDays(currentDate, 1);
    const dayFraction = calculateYearFraction(currentDate, nextDate, 'ACT/360');
    const dayCount = Math.round(dayFraction * 360);
    
    // Simulate slight realistic daily SOFR fixings around base rate
    const noise = (pseudoRandom() - 0.5) * rateNoiseSpread;
    const dailyRate = Math.max(0.001, baseSOFRRate + noise);

    const periodFactor = 1.0 + dailyRate * dayFraction;
    runningFactor *= periodFactor;
    totalDays += dayCount;

    observations.push({
      date: currentDate,
      sofrRate: dailyRate,
      weight: dayFraction,
      compoundedFactor: runningFactor,
    });

    currentDate = nextDate;
  }

  const compoundedIndex = runningFactor - 1.0;
  const annualizedRate = totalDays > 0 ? (compoundedIndex * (360.0 / totalDays)) : baseSOFRRate;

  return {
    compoundedRate: annualizedRate,
    compoundedIndex,
    totalAccrualDays: totalDays,
    observations,
  };
}
