import { CurvePoint, CurveDefinition, InterpolationMethod } from '../types/swap';

/**
 * Standard USD benchmark curve market inputs
 */
export const BASE_SOFR_MARKET_INPUTS: CurvePoint[] = [
  { tenor: 'ON', months: 0.03, rate: 0.0435, discountFactor: 0.99988, zeroRate: 0.0435, forwardRate: 0.0435, instrumentType: 'SOFR_DEPOSIT', isObserved: true },
  { tenor: '1M', months: 1, rate: 0.0432, discountFactor: 0.9964, zeroRate: 0.0432, forwardRate: 0.0432, instrumentType: 'SOFR_DEPOSIT', isObserved: true },
  { tenor: '3M', months: 3, rate: 0.0428, discountFactor: 0.9894, zeroRate: 0.0428, forwardRate: 0.0425, instrumentType: 'SOFR_FUTURE', isObserved: true },
  { tenor: '6M', months: 6, rate: 0.0422, discountFactor: 0.9791, zeroRate: 0.0422, forwardRate: 0.0418, instrumentType: 'SOFR_FUTURE', isObserved: true },
  { tenor: '1Y', months: 12, rate: 0.0415, discountFactor: 0.9593, zeroRate: 0.0415, forwardRate: 0.0408, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '2Y', months: 24, rate: 0.0398, discountFactor: 0.9234, zeroRate: 0.0398, forwardRate: 0.0381, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '3Y', months: 36, rate: 0.0392, discountFactor: 0.8891, zeroRate: 0.0392, forwardRate: 0.0380, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '5Y', months: 60, rate: 0.0395, discountFactor: 0.8208, zeroRate: 0.0395, forwardRate: 0.03995, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '7Y', months: 84, rate: 0.0405, discountFactor: 0.7532, zeroRate: 0.0405, forwardRate: 0.0430, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '10Y', months: 120, rate: 0.041875, discountFactor: 0.6578, zeroRate: 0.041875, forwardRate: 0.0451, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '15Y', months: 180, rate: 0.0432, discountFactor: 0.5235, zeroRate: 0.0432, forwardRate: 0.0458, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '20Y', months: 240, rate: 0.0441, discountFactor: 0.4146, zeroRate: 0.0441, forwardRate: 0.0468, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '30Y', months: 360, rate: 0.0448, discountFactor: 0.2608, zeroRate: 0.0448, forwardRate: 0.0462, instrumentType: 'OIS_SWAP', isObserved: true },
];

/**
 * Treasury Yield Curve
 */
export const BASE_TREASURY_MARKET_INPUTS: CurvePoint[] = [
  { tenor: '1M', months: 1, rate: 0.0445, discountFactor: 0.9963, zeroRate: 0.0445, forwardRate: 0.0445, instrumentType: 'SOFR_DEPOSIT', isObserved: true },
  { tenor: '3M', months: 3, rate: 0.0440, discountFactor: 0.9891, zeroRate: 0.0440, forwardRate: 0.0438, instrumentType: 'SOFR_DEPOSIT', isObserved: true },
  { tenor: '6M', months: 6, rate: 0.0430, discountFactor: 0.9787, zeroRate: 0.0430, forwardRate: 0.0420, instrumentType: 'SOFR_DEPOSIT', isObserved: true },
  { tenor: '1Y', months: 12, rate: 0.0420, discountFactor: 0.9588, zeroRate: 0.0420, forwardRate: 0.0410, instrumentType: 'SOFR_DEPOSIT', isObserved: true },
  { tenor: '2Y', months: 24, rate: 0.0408, discountFactor: 0.9216, zeroRate: 0.0408, forwardRate: 0.0396, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '3Y', months: 36, rate: 0.0401, discountFactor: 0.8868, zeroRate: 0.0401, forwardRate: 0.0387, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '5Y', months: 60, rate: 0.0402, discountFactor: 0.8179, zeroRate: 0.0402, forwardRate: 0.04035, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '7Y', months: 84, rate: 0.0412, discountFactor: 0.7496, zeroRate: 0.0412, forwardRate: 0.0437, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '10Y', months: 120, rate: 0.0425, discountFactor: 0.6537, zeroRate: 0.0425, forwardRate: 0.0457, instrumentType: 'OIS_SWAP', isObserved: true },
  { tenor: '30Y', months: 360, rate: 0.0455, discountFactor: 0.2555, zeroRate: 0.0455, forwardRate: 0.0470, instrumentType: 'OIS_SWAP', isObserved: true },
];

export class BootstrappedCurve {
  public definition: CurveDefinition;
  private points: CurvePoint[];
  private method: InterpolationMethod;

  constructor(definition: CurveDefinition) {
    this.definition = definition;
    this.points = [...definition.points].sort((a, b) => a.months - b.months);
    this.method = definition.interpolation;
  }

  /**
   * Discount factor DF(t) for maturity t in years
   */
  public getDiscountFactor(tYears: number): number {
    if (tYears <= 0) return 1.0;

    const tMonths = tYears * 12.0;
    
    // Exact match
    const exact = this.points.find(p => Math.abs(p.months - tMonths) < 1e-4);
    if (exact) return exact.discountFactor;

    // Extrapolate before first point
    if (tMonths <= this.points[0].months) {
      const r = this.points[0].zeroRate;
      return Math.exp(-r * tYears);
    }

    // Extrapolate after last point
    const last = this.points[this.points.length - 1];
    if (tMonths >= last.months) {
      const r = last.zeroRate;
      return Math.exp(-r * tYears);
    }

    // Interpolate Zero Rate or Log DF
    if (this.method === 'LOG_LINEAR') {
      let idx = 0;
      while (idx < this.points.length - 1 && this.points[idx + 1].months < tMonths) {
        idx++;
      }
      const p1 = this.points[idx];
      const p2 = this.points[idx + 1];
      const w = (tMonths - p1.months) / (p2.months - p1.months);
      const logDF = (1 - w) * Math.log(p1.discountFactor) + w * Math.log(p2.discountFactor);
      return Math.exp(logDF);
    }

    if (this.method === 'NELSON_SIEGEL' || this.method === 'NELSON_SIEGEL_SVENSSON') {
      // Nelson-Siegel model for zero rate r(t) = β0 + β1*(1-e^(-t/τ))/(t/τ) + β2*((1-e^(-t/τ))/(t/τ) - e^(-t/τ))
      const beta0 = 0.045;
      const beta1 = -0.005;
      const beta2 = -0.012;
      const tau = 2.5;
      const t = Math.max(0.01, tYears);
      const factor1 = (1 - Math.exp(-t / tau)) / (t / tau);
      const factor2 = factor1 - Math.exp(-t / tau);
      const zeroRate = beta0 + beta1 * factor1 + beta2 * factor2;
      return Math.exp(-zeroRate * tYears);
    }

    // Default: Monotonic Cubic / Linear Zero Rate Interpolation
    let idx = 0;
    while (idx < this.points.length - 1 && this.points[idx + 1].months < tMonths) {
      idx++;
    }
    const p1 = this.points[idx];
    const p2 = this.points[idx + 1];
    const w = (tMonths - p1.months) / (p2.months - p1.months);
    const zeroRate = (1 - w) * p1.zeroRate + w * p2.zeroRate;

    return Math.exp(-zeroRate * tYears);
  }

  /**
   * Continuous or Annualized Zero Rate r(t)
   */
  public getZeroRate(tYears: number): number {
    if (tYears <= 0) return this.points[0].zeroRate;
    const df = this.getDiscountFactor(tYears);
    return -Math.log(df) / tYears;
  }

  /**
   * Instantaneous or Period Forward Rate between t1 and t2
   */
  public getForwardRate(t1Years: number, t2Years: number): number {
    if (t2Years <= t1Years) return this.getZeroRate(t1Years);
    const df1 = this.getDiscountFactor(t1Years);
    const df2 = this.getDiscountFactor(t2Years);
    const dt = t2Years - t1Years;
    return (df1 / df2 - 1.0) / dt;
  }

  /**
   * Parallel shift by deltaInBp (e.g., +1.0 for +1bp)
   */
  public shiftParallel(deltaInBp: number): BootstrappedCurve {
    const shift = deltaInBp / 10000.0;
    const shiftedPoints = this.points.map(p => {
      const newZero = Math.max(0.0001, p.zeroRate + shift);
      const t = p.months / 12.0;
      const newDF = Math.exp(-newZero * t);
      return {
        ...p,
        rate: p.rate + shift,
        zeroRate: newZero,
        discountFactor: newDF,
      };
    });

    return new BootstrappedCurve({
      ...this.definition,
      name: `${this.definition.name} (${deltaInBp >= 0 ? '+' : ''}${deltaInBp}bp)`,
      points: shiftedPoints,
    });
  }

  /**
   * Key-Rate bucket shift at key Tenor (e.g. '10Y')
   */
  public shiftKeyRate(tenorStr: string, deltaInBp: number): BootstrappedCurve {
    const shift = deltaInBp / 10000.0;
    const targetPoint = this.points.find(p => p.tenor === tenorStr);
    if (!targetPoint) return this;

    const targetMonths = targetPoint.months;
    const shiftedPoints = this.points.map(p => {
      // Triangular kernel weighting centered at targetMonths
      const dist = Math.abs(p.months - targetMonths);
      const maxWidth = 36.0; // 3 year decay
      const weight = Math.max(0, 1.0 - dist / maxWidth);

      const localShift = shift * weight;
      const newZero = Math.max(0.0001, p.zeroRate + localShift);
      const t = p.months / 12.0;
      const newDF = Math.exp(-newZero * t);

      return {
        ...p,
        zeroRate: newZero,
        discountFactor: newDF,
      };
    });

    return new BootstrappedCurve({
      ...this.definition,
      points: shiftedPoints,
    });
  }
}
