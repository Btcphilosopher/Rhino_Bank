import { SwapTradeSpec, SwapValuationResult } from '../types/swap';
import { BootstrappedCurve } from './curveEngine';
import { generateSwapSchedule } from './scheduleEngine';
import { calculateYearFraction } from './dayCount';

export function priceSwap(
  trade: SwapTradeSpec,
  discountCurve: BootstrappedCurve,
  forecastCurve: BootstrappedCurve,
  valuationDateStr: string = '2026-09-22'
): {
  valuation: SwapValuationResult;
  schedule: ReturnType<typeof generateSwapSchedule>;
} {
  // Generate cash flow schedules
  const schedule = generateSwapSchedule(
    trade,
    (t) => discountCurve.getDiscountFactor(t),
    (t) => forecastCurve.getForwardRate(Math.max(0, t - 0.25), t)
  );

  // Calculate Fixed Leg Annuity: A = Σ (α_i * DF_i)
  let fixedAnnuity = 0;
  let fixedLegPV = 0;
  for (const period of schedule.fixedLegPeriods) {
    fixedAnnuity += period.accrualFraction * period.discountFactor;
    fixedLegPV += period.discountedCashFlow;
  }

  // Calculate Floating Leg PV
  let floatingLegPV = 0;
  for (const period of schedule.floatingLegPeriods) {
    floatingLegPV += period.discountedCashFlow;
  }

  // Solve Par Swap Rate: S_par = PV_Float / (Notional * Annuity)
  const parRate = fixedAnnuity > 0 ? floatingLegPV / (trade.notional * fixedAnnuity) : trade.fixedRate;

  // Calculate Net PV based on direction
  // Pay Fixed: PV = PV_Float - PV_Fixed
  // Receive Fixed: PV = PV_Fixed - PV_Float
  let netPV = 0;
  if (trade.direction === 'PAY_FIXED') {
    netPV = floatingLegPV - fixedLegPV;
  } else {
    netPV = fixedLegPV - floatingLegPV;
  }

  const rateDifferenceBp = (trade.fixedRate - parRate) * 10000.0;

  // Accrued interest calculation for valuation between payment dates
  const accruedInterest = 0; // assuming on-cycle or spot valuation

  // DV01 calculation by parallel +1bp shift
  const shiftedCurveUp = discountCurve.shiftParallel(1.0);
  const shiftedForecastUp = forecastCurve.shiftParallel(1.0);
  const schedUp = generateSwapSchedule(
    trade,
    (t) => shiftedCurveUp.getDiscountFactor(t),
    (t) => shiftedForecastUp.getForwardRate(Math.max(0, t - 0.25), t)
  );

  let fixedPVUp = 0;
  for (const p of schedUp.fixedLegPeriods) fixedPVUp += p.discountedCashFlow;
  let floatPVUp = 0;
  for (const p of schedUp.floatingLegPeriods) floatPVUp += p.discountedCashFlow;

  const netPVUp = trade.direction === 'PAY_FIXED' ? (floatPVUp - fixedPVUp) : (fixedPVUp - floatPVUp);
  const dv01 = -(netPVUp - netPV); // DV01 per +1bp rate increase

  // Convexity estimation via +1bp and -1bp
  const shiftedCurveDown = discountCurve.shiftParallel(-1.0);
  const shiftedForecastDown = forecastCurve.shiftParallel(-1.0);
  const schedDown = generateSwapSchedule(
    trade,
    (t) => shiftedCurveDown.getDiscountFactor(t),
    (t) => shiftedForecastDown.getForwardRate(Math.max(0, t - 0.25), t)
  );

  let fixedPVDown = 0;
  for (const p of schedDown.fixedLegPeriods) fixedPVDown += p.discountedCashFlow;
  let floatPVDown = 0;
  for (const p of schedDown.floatingLegPeriods) floatPVDown += p.discountedCashFlow;

  const netPVDown = trade.direction === 'PAY_FIXED' ? (floatPVDown - fixedPVDown) : (fixedPVDown - floatPVDown);
  const convexity = (netPVUp + netPVDown - 2 * netPV); // second derivative approximation

  // Key Rate DV01 Buckets
  const keyRateTenors = ['2Y', '3Y', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y'];
  const keyRateDV01: Record<string, number> = {};

  for (const krTenor of keyRateTenors) {
    const krCurveUp = discountCurve.shiftKeyRate(krTenor, 1.0);
    const krSchedUp = generateSwapSchedule(
      trade,
      (t) => krCurveUp.getDiscountFactor(t),
      (t) => forecastCurve.getForwardRate(Math.max(0, t - 0.25), t)
    );
    let krFixedPV = 0;
    for (const p of krSchedUp.fixedLegPeriods) krFixedPV += p.discountedCashFlow;
    let krFloatPV = 0;
    for (const p of krSchedUp.floatingLegPeriods) krFloatPV += p.discountedCashFlow;
    const krNetPV = trade.direction === 'PAY_FIXED' ? (krFloatPV - krFixedPV) : (krFixedPV - krFloatPV);
    keyRateDV01[krTenor] = -(krNetPV - netPV);
  }

  // Carry and Roll 1M estimations
  const carry1M = trade.notional * (parRate - trade.fixedRate) * (1 / 12);
  const roll1M = dv01 * 0.45; // ~0.45bp roll down benefit per month on normal curve slope

  return {
    valuation: {
      tradeId: trade.tradeId,
      valuationDate: valuationDateStr,
      parRate,
      fixedLegPV,
      floatingLegPV,
      netPV,
      cleanPV: netPV - accruedInterest,
      dirtyPV: netPV,
      accruedInterest,
      fixedAnnuity,
      rateDifferenceBp,
      dv01,
      pv01: dv01 * 100.0,
      convexity,
      keyRateDV01,
      carry1M,
      roll1M,
    },
    schedule,
  };
}
