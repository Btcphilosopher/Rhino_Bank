import { BootstrappedCurve, BASE_SOFR_MARKET_INPUTS, BASE_TREASURY_MARKET_INPUTS } from './curveEngine';

export interface BenchmarkSpread {
  tenor: string;
  sofrRate: number;
  treasuryYield: number;
  swapSpreadBp: number;
  changeBp: number;
  dv01Per100M: number;
  status: 'LIVE' | 'HISTORICAL' | 'SYNTHETIC';
}

export function getMarketBenchmarks(): BenchmarkSpread[] {
  return [
    { tenor: 'SOFR', sofrRate: 0.0435, treasuryYield: 0.0445, swapSpreadBp: -10.0, changeBp: -0.5, dv01Per100M: 0, status: 'SYNTHETIC' },
    { tenor: '2Y SWAP', sofrRate: 0.0398, treasuryYield: 0.0408, swapSpreadBp: -10.0, changeBp: +1.2, dv01Per100M: 19450, status: 'SYNTHETIC' },
    { tenor: '5Y SWAP', sofrRate: 0.0395, treasuryYield: 0.0402, swapSpreadBp: -7.0, changeBp: -0.8, dv01Per100M: 46200, status: 'SYNTHETIC' },
    { tenor: '10Y SWAP', sofrRate: 0.041875, treasuryYield: 0.0425, swapSpreadBp: -6.25, changeBp: +2.1, dv01Per100M: 84310, status: 'SYNTHETIC' },
    { tenor: '30Y SWAP', sofrRate: 0.0448, treasuryYield: 0.0455, swapSpreadBp: -7.0, changeBp: -1.4, dv01Per100M: 198500, status: 'SYNTHETIC' },
  ];
}

export function getSwaptionVolGrid() {
  const expiries = ['1M', '3M', '6M', '1Y', '2Y', '5Y'];
  const tenors = ['1Y', '2Y', '5Y', '10Y', '20Y', '30Y'];

  // Normal Volatility in bps
  const grid: Record<string, Record<string, number>> = {
    '1M': { '1Y': 85, '2Y': 88, '5Y': 84, '10Y': 78, '20Y': 72, '30Y': 68 },
    '3M': { '1Y': 87, '2Y': 89, '5Y': 85, '10Y': 79, '20Y': 73, '30Y': 69 },
    '6M': { '1Y': 89, '2Y': 90, '5Y': 86, '10Y': 80, '20Y': 74, '30Y': 70 },
    '1Y': { '1Y': 91, '2Y': 92, '5Y': 87, '10Y': 81, '20Y': 75, '30Y': 71 },
    '2Y': { '1Y': 88, '2Y': 89, '5Y': 84, '10Y': 78, '20Y': 72, '30Y': 68 },
    '5Y': { '1Y': 82, '2Y': 83, '5Y': 79, '10Y': 74, '20Y': 68, '30Y': 64 },
  };

  return { expiries, tenors, grid };
}

export function getHistoricalReplaySnapshots() {
  return [
    { date: '2026-09-22', name: 'Current Spot Market (SOFR 4.35%)', sofrRate: 0.0435, swap10Y: 0.041875, shiftBp: 0 },
    { date: '2026-06-15', name: 'Summer Fed Pivot (+25bp Hawk Shock)', sofrRate: 0.0460, swap10Y: 0.044375, shiftBp: +25 },
    { date: '2026-03-20', name: 'Q1 Banking Liquidity Rally (-50bp Shock)', sofrRate: 0.0385, swap10Y: 0.036875, shiftBp: -50 },
    { date: '2025-11-10', name: 'Late 2025 Soft Landing Curve Flattening', sofrRate: 0.0510, swap10Y: 0.0420, shiftBp: +75 },
  ];
}

export function getDefaultSOFRCurve(): BootstrappedCurve {
  return new BootstrappedCurve({
    name: 'USD SOFR OIS Discount & Forecast Curve',
    asOfDate: '2026-09-22',
    currency: 'USD',
    interpolation: 'MONOTONIC_CUBIC',
    points: BASE_SOFR_MARKET_INPUTS,
  });
}

export function getDefaultTreasuryCurve(): BootstrappedCurve {
  return new BootstrappedCurve({
    name: 'USD Treasury Benchmark Curve',
    asOfDate: '2026-09-22',
    currency: 'USD',
    interpolation: 'LINEAR',
    points: BASE_TREASURY_MARKET_INPUTS,
  });
}
