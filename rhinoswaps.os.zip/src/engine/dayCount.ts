import { DayCountConvention, BusinessDayConvention } from '../types/swap';

/**
 * Parses date string YYYY-MM-DD to Date object
 */
export function parseDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

/**
 * Formats Date to YYYY-MM-DD
 */
export function formatDate(date: Date): string {
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Adds months to a date
 */
export function addMonths(dateStr: string, months: number): string {
  const d = parseDate(dateStr);
  const origDay = d.getUTCDate();
  d.setUTCMonth(d.getUTCMonth() + months);
  if (d.getUTCDate() !== origDay) {
    d.setUTCDate(0); // handle month end overflow
  }
  return formatDate(d);
}

/**
 * Adds days to a date
 */
export function addDays(dateStr: string, days: number): string {
  const d = parseDate(dateStr);
  d.setUTCDate(d.getUTCDate() + days);
  return formatDate(d);
}

/**
 * Checks if a date is a weekend (Saturday or Sunday)
 */
export function isWeekend(dateStr: string): boolean {
  const d = parseDate(dateStr);
  const day = d.getUTCDay();
  return day === 0 || day === 6;
}

/**
 * Applies Business Day Convention (Following, Modified Following, Preceding)
 */
export function adjustBusinessDay(
  dateStr: string,
  convention: BusinessDayConvention = 'MODIFIED_FOLLOWING'
): string {
  if (convention === 'UNADJUSTED') return dateStr;

  let current = parseDate(dateStr);
  const origMonth = current.getUTCMonth();

  if (convention === 'FOLLOWING' || convention === 'MODIFIED_FOLLOWING') {
    while (current.getUTCDay() === 0 || current.getUTCDay() === 6) {
      current.setUTCDate(current.getUTCDate() + 1);
    }
    if (convention === 'MODIFIED_FOLLOWING' && current.getUTCMonth() !== origMonth) {
      // Roll back if modified following crosses into next month
      current = parseDate(dateStr);
      while (current.getUTCDay() === 0 || current.getUTCDay() === 6) {
        current.setUTCDate(current.getUTCDate() - 1);
      }
    }
  } else if (convention === 'PRECEDING' || convention === 'MODIFIED_PRECEDING') {
    while (current.getUTCDay() === 0 || current.getUTCDay() === 6) {
      current.setUTCDate(current.getUTCDate() - 1);
    }
    if (convention === 'MODIFIED_PRECEDING' && current.getUTCMonth() !== origMonth) {
      current = parseDate(dateStr);
      while (current.getUTCDay() === 0 || current.getUTCDay() === 6) {
        current.setUTCDate(current.getUTCDate() + 1);
      }
    }
  }

  return formatDate(current);
}

/**
 * Calculates Day Count Fraction between start date and end date
 */
export function calculateYearFraction(
  startDateStr: string,
  endDateStr: string,
  convention: DayCountConvention
): number {
  const d1 = parseDate(startDateStr);
  const d2 = parseDate(endDateStr);
  const diffTime = d2.getTime() - d1.getTime();
  const diffDays = Math.round(diffTime / (1000 * 3600 * 24));

  if (convention === 'ACT/360') {
    return diffDays / 360.0;
  }
  if (convention === 'ACT/365') {
    return diffDays / 365.0;
  }
  if (convention === '30/360' || convention === '30E/360') {
    let day1 = d1.getUTCDate();
    let day2 = d2.getUTCDate();
    const month1 = d1.getUTCMonth() + 1;
    const month2 = d2.getUTCMonth() + 1;
    const year1 = d1.getUTCFullYear();
    const year2 = d2.getUTCFullYear();

    if (day1 === 31) day1 = 30;
    if (day2 === 31 && day1 >= 30) day2 = 30;

    return (360 * (year2 - year1) + 30 * (month2 - month1) + (day2 - day1)) / 360.0;
  }

  return diffDays / 360.0;
}
