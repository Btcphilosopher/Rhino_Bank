"""
RHINOSWAPS.OS - Core Market Conventions
"""

from enum import Enum
from dataclasses import dataclass

class Currency(str, Enum):
    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    JPY = "JPY"
    CHF = "CHF"

class DayCountConvention(str, Enum):
    ACT_360 = "ACT/360"
    ACT_365 = "ACT/365"
    THIRTY_360 = "30/360"

class BusinessDayConvention(str, Enum):
    MODIFIED_FOLLOWING = "MODIFIED_FOLLOWING"
    FOLLOWING = "FOLLOWING"
    PRECEDING = "PRECEDING"

class FloatingIndex(str, Enum):
    SOFR = "SOFR"
    TERM_SOFR = "TERM_SOFR"
    FED_FUNDS = "FED_FUNDS"
    ESTR = "€STR"
    SONIA = "SONIA"

@dataclass
class SwapConvention:
    currency: Currency
    index: FloatingIndex
    fixed_day_count: DayCountConvention
    floating_day_count: DayCountConvention
    fixed_frequency_months: int
    floating_frequency_months: int
    business_day: BusinessDayConvention
    payment_lag_days: int
    reset_lag_days: int

USD_SOFR_OIS_CONVENTION = SwapConvention(
    currency=Currency.USD,
    index=FloatingIndex.SOFR,
    fixed_day_count=DayCountConvention.THIRTY_360,
    floating_day_count=DayCountConvention.ACT_360,
    fixed_frequency_months=6,
    floating_frequency_months=3,
    business_day=BusinessDayConvention.MODIFIED_FOLLOWING,
    payment_lag_days=2,
    reset_lag_days=0,
)
