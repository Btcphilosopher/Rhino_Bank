"""
RHINOSWAPS.OS - Quantitative Swap Pricing & Valuation Engine
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Dict

@dataclass
class SwapLegPeriod:
    period_num: int
    start_date: str
    end_date: str
    accrual_fraction: float
    notional: float
    rate: float
    discount_factor: float
    cash_flow: float
    discounted_cash_flow: float

class SOFRSwapPricer:
    def __init__(self, notional: float = 100_000_000.0, fixed_rate: float = 0.041875, tenor_years: int = 10):
        self.notional = notional
        self.fixed_rate = fixed_rate
        self.tenor_years = tenor_years

    def calculate_par_rate(self, discount_factors: np.ndarray, accrual_fractions: np.ndarray) -> float:
        """
        Calculates exact Par Swap Rate:
        S_par = (DF_start - DF_end) / Annuity
        Annuity = sum(alpha_i * DF_i)
        """
        annuity = np.sum(accrual_fractions * discount_factors)
        if annuity <= 0:
            return self.fixed_rate
        df_start = 1.0
        df_end = discount_factors[-1]
        return (df_start - df_end) / annuity

    def price_swap(self, discount_factors: np.ndarray, accrual_fractions: np.ndarray) -> Dict[str, float]:
        annuity = np.sum(accrual_fractions * discount_factors)
        pv_fixed = self.notional * self.fixed_rate * annuity
        par_rate = self.calculate_par_rate(discount_factors, accrual_fractions)
        pv_float = self.notional * par_rate * annuity
        net_pv = pv_float - pv_fixed

        # Finite difference DV01 (+1bp shift)
        shifted_dfs = discount_factors * np.exp(-0.0001 * np.linspace(0.5, self.tenor_years, len(discount_factors)))
        annuity_up = np.sum(accrual_fractions * shifted_dfs)
        pv_fixed_up = self.notional * self.fixed_rate * annuity_up
        pv_float_up = self.notional * par_rate * annuity_up
        net_pv_up = pv_float_up - pv_fixed_up
        dv01 = -(net_pv_up - net_pv)

        return {
            "notional": self.notional,
            "fixed_rate": self.fixed_rate,
            "par_rate": par_rate,
            "annuity": float(annuity),
            "pv_fixed": float(pv_fixed),
            "pv_float": float(pv_float),
            "net_pv": float(net_pv),
            "dv01": float(dv01),
        }
