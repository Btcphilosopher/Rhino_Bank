# RHINO SYNTHETIC INFRASTRUCTURE
**Codename:** RHINOSYNTH’s INFRA  
**Tagline:** DESIGN THE INFRASTRUCTURE BEFORE YOU BUILD IT.

---

## Executive Overview

**RHINO SYNTHETIC INFRASTRUCTURE** is an institutional software platform combining:
**Infrastructure Digital Twin × Project Finance × Procurement × Engineering × Asset Management × Infrastructure Securities × Scenario Modelling × Construction Simulation**.

An infrastructure project can exist digitally, economically, and financially before it exists physically.

Built to Rhino Bank standards, the platform operates as an institutional software suite used simultaneously by major infrastructure banks, sovereign wealth funds, engineering conglomerates, and asset managers.

---

## Core Capabilities

1. **Synthetic Infrastructure Creation Engine**: Generate structured projects via natural language or parameter composition across Transport, Energy, Water, Digital, Urban, and Industrial sectors.
2. **Causal 3D Digital Twin**: WebGL (Three.js) interactive physical twin linked directly to financial models (CAPEX, OPEX, IRR, DSCR, NPV).
3. **Project Finance & Securitisation**: Senior Debt, Mezzanine, Subordinated Debt, Cashflow Waterfall, DSCR/LLCR/PLCR calculations, and Refinancing Simulator.
4. **Synthetic Infrastructure CDO**: Multi-asset credit pool tranching (Super Senior to Equity) with loss waterfall simulation.
5. **Construction Simulator & Project Control**: Gantt charts, Critical Path Method (CPM), machinery fleet telemetry, and delay cost propagation.
6. **Scenario Lab & Monte Carlo Engine**: Stochastic Monte Carlo distributions (P5/P50/P95) and deterministic macro stress testing.
7. **Rhino AI Infra Intelligence**: Grounded institutional AI assistant powered by Gemini 3.6 (`@google/genai`).

---

## Quick Start

```bash
# Install dependencies
npm install

# Run application server
npm run dev
```

Visit `http://localhost:3000` to access the platform.
