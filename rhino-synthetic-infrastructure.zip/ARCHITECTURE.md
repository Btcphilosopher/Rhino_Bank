# SYSTEM ARCHITECTURE

```
                         RHINO BANK
                              │
                    ┌─────────┴─────────┐
                    │                   │
             RHINOQUANT          RHINO INFRA
                    │                   │
             FINANCIAL               PHYSICAL
             PRODUCTS                ASSETS
                    │                   │
                    └─────────┬─────────┘
                              │
                    RHINO SYNTHETIC MARKET
                              │
               ┌──────────────┼──────────────┐
               │              │              │
            CAPITAL        INFRASTRUCTURE   RISK
               │              │              │
               └──────────────┼──────────────┘
                              │
                       DIGITAL ECONOMY
```

## Architectural Layers

1. **Client / Frontend Layer**: React 19, TypeScript, Tailwind CSS, WebGL Three.js 3D Digital Twin, Lucide Icons.
2. **Causal Simulation Layer**:
   - `causalEngine`: Real-time bi-directional propagation between physical parameters and financial metrics.
   - `financeEngine`: Debt amortization, cashflow waterfall, DSCR/LLCR/PLCR calculations.
   - `riskEngine`: Monte Carlo simulator (1,000+ iterations) and Macro Scenario Lab.
   - `marketEngine`: Orderbook, Rhino Infra-100 Index, securitised bonds trading.
3. **AI Generation Layer**: `@google/genai` TypeScript SDK with Gemini 3.6 / 2.5 Flash for project synthesis and natural language analytics.
4. **Backend / API Server**: Node.js Express server mounting Vite middleware in dev and API endpoints for simulation and risk analytics.
