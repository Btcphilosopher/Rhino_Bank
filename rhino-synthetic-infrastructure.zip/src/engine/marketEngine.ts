import { SecuritisedBond } from '../types/infrastructure';

export interface MarketOrder {
  orderId: string;
  bondId: string;
  side: 'BUY' | 'SELL';
  price: number;
  quantityNotional: number;
  timestamp: string;
  status: 'OPEN' | 'FILLED' | 'CANCELLED';
}

export interface InfraIndexComponent {
  sector: string;
  weightPercent: number;
  indexValue: number;
  dailyChangePct: number;
  volatilityAnnual: number;
}

export const RHINO_INFRA_INDEX: InfraIndexComponent[] = [
  { sector: 'ENERGY & DECARBONISATION', weightPercent: 30, indexValue: 1482.40, dailyChangePct: +0.85, volatilityAnnual: 0.14 },
  { sector: 'RAIL & TRANSPORTATION', weightPercent: 25, indexValue: 1240.10, dailyChangePct: +0.42, volatilityAnnual: 0.11 },
  { sector: 'PORTS & MARITIME LOGISTICS', weightPercent: 15, indexValue: 1105.80, dailyChangePct: -0.15, volatilityAnnual: 0.16 },
  { sector: 'WATER & ENVIRONMENTAL', weightPercent: 10, indexValue: 980.20, dailyChangePct: +0.20, volatilityAnnual: 0.08 },
  { sector: 'DIGITAL & TELECOMMUNICATIONS', weightPercent: 10, indexValue: 1650.90, dailyChangePct: +1.20, volatilityAnnual: 0.18 },
  { sector: 'INDUSTRIAL & FABRICATING', weightPercent: 10, indexValue: 1310.50, dailyChangePct: +0.65, volatilityAnnual: 0.15 },
];

export function calculateCompositeIndexValue(): { value: number; dailyChange: number } {
  let totalValue = 0;
  let totalChange = 0;
  RHINO_INFRA_INDEX.forEach(c => {
    totalValue += c.indexValue * (c.weightPercent / 100);
    totalChange += c.dailyChangePct * (c.weightPercent / 100);
  });
  return {
    value: parseFloat(totalValue.toFixed(2)),
    dailyChange: parseFloat(totalChange.toFixed(2))
  };
}

export function executeSimulatedTrade(
  bond: SecuritisedBond,
  side: 'BUY' | 'SELL',
  notional: number
): { success: boolean; executedPrice: number; pnlImpact: number; msg: string } {
  const executedPrice = side === 'BUY' ? bond.askPrice : bond.bidPrice;
  const pnlImpact = (executedPrice - bond.pricePercent) * (notional / 100);

  return {
    success: true,
    executedPrice,
    pnlImpact: Math.round(pnlImpact),
    msg: `Executed ${side} order for £${(notional / 1e6).toFixed(1)}M notional of ${bond.trancheName} @ ${executedPrice}%`
  };
}
