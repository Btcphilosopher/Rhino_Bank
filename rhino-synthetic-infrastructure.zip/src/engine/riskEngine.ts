import { SyntheticInfrastructureAsset, ScenarioResult } from '../types/infrastructure';
import { calculateFinancingStructure } from './financeEngine';

export function runMonteCarloSimulation(
  asset: SyntheticInfrastructureAsset,
  iterations: number = 1000
): {
  p5Capex: number;
  p50Capex: number;
  p95Capex: number;
  p5Irr: number;
  p50Irr: number;
  p95Irr: number;
  p5Dscr: number;
  p50Dscr: number;
  p95Dscr: number;
  completionDateDist: { month: number; prob: number }[];
} {
  const baseCapex = asset.construction_cost;
  const baseIrr = asset.financing_structure.projectIrr;
  const baseDscr = asset.financing_structure.dscr;

  const capexResults: number[] = [];
  const irrResults: number[] = [];
  const dscrResults: number[] = [];

  for (let i = 0; i < iterations; i++) {
    // Normal / Triangular random distributions
    const capexNoise = (Math.random() + Math.random() + Math.random() - 1.5) * 0.25; // -0.375 to +0.375
    const demandNoise = (Math.random() + Math.random() - 1.0) * 0.20;
    const interestNoise = (Math.random() - 0.5) * 0.03; // +/- 1.5%

    const simCapex = Math.round(baseCapex * (1 + capexNoise));
    const simRevenue = asset.revenue_streams.reduce((a, r) => a + r.annualRevenue, 0) * (1 + demandNoise);
    const simOpex = asset.operating_cost_annual * (1 + capexNoise * 0.5);
    const simEbitda = simRevenue - simOpex;

    const simFinancing = calculateFinancingStructure(
      simCapex,
      asset.land_cost,
      asset.engineering_cost,
      asset.revenue_streams,
      asset.opex_breakdown,
      interestNoise * 10000,
      Math.round(capexNoise * 12)
    );

    capexResults.push(simCapex);
    irrResults.push(simFinancing.projectIrr);
    dscrResults.push(simFinancing.dscr);
  }

  // Sort results to extract quantiles
  capexResults.sort((a, b) => a - b);
  irrResults.sort((a, b) => a - b);
  dscrResults.sort((a, b) => a - b);

  const getPercentile = (arr: number[], p: number) => arr[Math.floor(arr.length * p)];

  return {
    p5Capex: getPercentile(capexResults, 0.05),
    p50Capex: getPercentile(capexResults, 0.50),
    p95Capex: getPercentile(capexResults, 0.95),
    p5Irr: getPercentile(irrResults, 0.05),
    p50Irr: getPercentile(irrResults, 0.50),
    p95Irr: getPercentile(irrResults, 0.95),
    p5Dscr: getPercentile(dscrResults, 0.05),
    p50Dscr: getPercentile(dscrResults, 0.50),
    p95Dscr: getPercentile(dscrResults, 0.95),
    completionDateDist: [
      { month: 60, prob: 0.10 },
      { month: 66, prob: 0.35 },
      { month: 72, prob: 0.40 },
      { month: 84, prob: 0.15 },
    ]
  };
}

export function runScenarioLab(asset: SyntheticInfrastructureAsset): ScenarioResult[] {
  const baseCapex = asset.construction_cost;

  const scenarios = [
    {
      name: 'BASE CASE',
      desc: 'Nominal engineering and market parameters',
      capexChg: 0,
      demandChg: 0,
      rateBps: 0,
      delayMonths: 0
    },
    {
      name: 'CONSTRUCTION DELAY (+18 MONTHS)',
      desc: 'Critical path tunnelling slip & supply chain bottleneck',
      capexChg: 0.08,
      demandChg: 0,
      rateBps: 50,
      delayMonths: 18
    },
    {
      name: 'CAPEX OVERRUN +20%',
      desc: 'Raw steel & cement price spike during procurement',
      capexChg: 0.20,
      demandChg: 0,
      rateBps: 0,
      delayMonths: 6
    },
    {
      name: 'CAPEX OVERRUN +40%',
      desc: 'Systemic EPC contractor failure and redesign required',
      capexChg: 0.40,
      demandChg: -0.05,
      rateBps: 100,
      delayMonths: 24
    },
    {
      name: 'DEMAND SHORTFALL -20%',
      desc: 'Macroeconomic downturn reducing passenger/freight throughput',
      capexChg: 0,
      demandChg: -0.20,
      rateBps: 0,
      delayMonths: 0
    },
    {
      name: 'INTEREST RATES +200BP SHOCK',
      desc: 'Central bank tightening elevating senior debt service costs',
      capexChg: 0,
      demandChg: 0,
      rateBps: 200,
      delayMonths: 0
    },
    {
      name: 'ENERGY PRICE SHOCK (+35%)',
      desc: 'Wholesale power price escalation impacting hydrogen electrolysers',
      capexChg: 0.05,
      demandChg: 0.12,
      rateBps: 75,
      delayMonths: 0
    },
    {
      name: 'SYSTEMIC INFRASTRUCTURE SHOCK',
      desc: 'Combined CAPEX +25%, Demand -25%, Interest +250bps, Delay +24m',
      capexChg: 0.25,
      demandChg: -0.25,
      rateBps: 250,
      delayMonths: 24
    }
  ];

  return scenarios.map(sc => {
    const simCapex = Math.round(baseCapex * (1 + sc.capexChg));
    const simRevenueStreams = asset.revenue_streams.map(r => ({
      ...r,
      annualRevenue: Math.round(r.annualRevenue * (1 + sc.demandChg))
    }));

    const simFinancing = calculateFinancingStructure(
      simCapex,
      asset.land_cost,
      asset.engineering_cost,
      simRevenueStreams,
      asset.opex_breakdown,
      sc.rateBps,
      sc.delayMonths
    );

    const baseCompletionYr = 2031;
    const completionYear = baseCompletionYr + Math.floor(sc.delayMonths / 12);
    const completionMonth = (sc.delayMonths % 12) + 6;

    return {
      scenarioName: sc.name,
      description: sc.desc,
      capexChangePercent: sc.capexChg * 100,
      demandChangePercent: sc.demandChg * 100,
      interestRateChangeBps: sc.rateBps,
      delayMonths: sc.delayMonths,
      newNpv: simFinancing.npv7Percent,
      newIrr: simFinancing.projectIrr,
      newDscr: simFinancing.dscr,
      newCompletionDate: `Q${Math.ceil(completionMonth / 3)} ${completionYear}`,
      financingDeficit: simFinancing.dscr < 1.10 ? Math.round(simFinancing.totalProjectCost * 0.12) : 0
    };
  });
}
