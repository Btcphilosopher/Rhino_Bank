import { BOMCategory, MaterialCostItem, SubType } from '../types/infrastructure';

export const COMMODITY_MARKET_PRICES = [
  { id: 'COMM-STEEL', name: 'Structural Steel (BS EN 10025)', symbol: 'STL-UK', currentPrice: 1420, unit: 'Tonne', change24hPct: +1.8, volatility: 0.18, carbonKg: 1850 },
  { id: 'COMM-CONCRETE', name: 'Ready-Mix C50/60 Structural Concrete', symbol: 'CNC-UK', currentPrice: 185, unit: 'm³', change24hPct: -0.4, volatility: 0.08, carbonKg: 320 },
  { id: 'COMM-COPPER', name: 'LME Electrolytic Copper Cathode', symbol: 'CU-LME', currentPrice: 8850, unit: 'Tonne', change24hPct: +3.2, volatility: 0.22, carbonKg: 3800 },
  { id: 'COMM-ALUMINIUM', name: 'High-Purity Aluminium Ingot', symbol: 'AL-LME', currentPrice: 2450, unit: 'Tonne', change24hPct: +0.6, volatility: 0.15, carbonKg: 4200 },
  { id: 'COMM-HYDROGEN', name: 'Green Hydrogen Industrial Wholesale', symbol: 'H2-UK', currentPrice: 4.80, unit: 'kg', change24hPct: -1.2, volatility: 0.28, carbonKg: 0.8 },
  { id: 'COMM-POWER', name: 'UK Base Load Power Forward', symbol: 'PWR-UK', currentPrice: 84.50, unit: 'MWh', change24hPct: +2.1, volatility: 0.35, carbonKg: 110 },
];

export function generateBOMForSubType(subType: SubType, capacityVal: number, lengthKm: number = 50): BOMCategory[] {
  switch (subType) {
    case 'hydrogen_rail':
    case 'railway':
    case 'high_speed_rail':
      return [
        {
          category: 'PERMANENT WAY & TRACKWORK',
          totalCost: Math.round(lengthKm * 18000000),
          items: [
            { id: 'M-RL-01', name: 'Heavy Structural Steel Rails 60E1', quantity: Math.round(lengthKm * 200), unit: 'Tonnes', unitPrice: 1420, volatility: 0.18, supplierRegion: 'British Steel Scunthorpe', leadTimeWeeks: 16, carbonIntensityKgPerUnit: 1850, totalCost: Math.round(lengthKm * 200 * 1420) },
            { id: 'M-RL-02', name: 'Monoblock Concrete Rail Sleepers', quantity: Math.round(lengthKm * 1600), unit: 'Units', unitPrice: 85, volatility: 0.08, supplierRegion: 'UK Concrete Rail', leadTimeWeeks: 10, carbonIntensityKgPerUnit: 140, totalCost: Math.round(lengthKm * 1600 * 85) },
          ]
        },
        {
          category: 'ROLLING STOCK & POWER',
          totalCost: Math.round(capacityVal * 450000),
          items: [
            { id: 'M-RL-03', name: 'Hydrail Zero-Emission Trainsets 200km/h', quantity: Math.round(capacityVal / 500), unit: 'Trainsets', unitPrice: 42000000, volatility: 0.12, supplierRegion: 'Siemens / Alstom Joint Venture', leadTimeWeeks: 36, carbonIntensityKgPerUnit: 680000, totalCost: Math.round((capacityVal / 500) * 42000000) }
          ]
        }
      ];

    case 'offshore_wind':
    case 'power_station':
      return [
        {
          category: 'TURBINES & GENERATION',
          totalCost: Math.round(capacityVal * 1200000),
          items: [
            { id: 'M-EN-01', name: 'Offshore Direct Drive Turbines 15MW', quantity: Math.round(capacityVal / 15), unit: 'Units', unitPrice: 38000000, volatility: 0.14, supplierRegion: 'North Sea Wind Consortium', leadTimeWeeks: 40, carbonIntensityKgPerUnit: 1400000, totalCost: Math.round((capacityVal / 15) * 38000000) },
            { id: 'M-EN-02', name: 'Subsea Inter-Array Cables 66kV', quantity: Math.round(lengthKm * 4), unit: 'km', unitPrice: 320000, volatility: 0.20, supplierRegion: 'Prysmian / NKT Cables', leadTimeWeeks: 24, carbonIntensityKgPerUnit: 12000, totalCost: Math.round(lengthKm * 4 * 320000) }
          ]
        }
      ];

    default:
      return [
        {
          category: 'GENERAL CIVIL & STRUCTURES',
          totalCost: Math.round(capacityVal * 1000000 || 500000000),
          items: [
            { id: 'M-GEN-01', name: 'High-Strength Structural Steel Girders', quantity: 120000, unit: 'Tonnes', unitPrice: 1420, volatility: 0.15, supplierRegion: 'UK Steel Mills', leadTimeWeeks: 14, carbonIntensityKgPerUnit: 1850, totalCost: 170400000 },
            { id: 'M-GEN-02', name: 'Prestressed Concrete Foundations', quantity: 250000, unit: 'm³', unitPrice: 185, volatility: 0.08, supplierRegion: 'Regional Concrete Supplier', leadTimeWeeks: 8, carbonIntensityKgPerUnit: 320, totalCost: 46250000 }
          ]
        }
      ];
  }
}
