import { FinancingStructure, DebtTranche, RevenueStream, OpexItem } from '../types/infrastructure';

export function calculateFinancingStructure(
  capex: number,
  landCost: number,
  engineeringCost: number,
  revenueStreams: RevenueStream[],
  opexBreakdown: OpexItem[],
  interestRateShiftBps: number = 0,
  delayMonths: number = 0
): FinancingStructure {
  const baseCost = capex + landCost + engineeringCost;
  
  // Construction period delay adds interest during construction
  const interestShiftPct = interestRateShiftBps / 10000;
  const constrInterestRate = 0.0525 + interestShiftPct;
  const constructionYears = 5 + (delayMonths / 12);
  const financingCostDuringConstruction = Math.round(baseCost * (constrInterestRate * (constructionYears / 2)));
  
  const contingencyAllowance = Math.round(baseCost * 0.07);
  const totalProjectCost = baseCost + financingCostDuringConstruction + contingencyAllowance;

  // Capital Structure: 30% Equity, 70% Debt
  const equityPercent = 31.0;
  const equityAmount = Math.round(totalProjectCost * (equityPercent / 100));
  const totalDebtAmount = totalProjectCost - equityAmount;

  // Debt Tranches
  const seniorAmount = Math.round(totalDebtAmount * 0.70);
  const mezzaAmount = Math.round(totalDebtAmount * 0.20);
  const subAmount = totalDebtAmount - seniorAmount - mezzaAmount;

  const seniorRate = Math.max(0.02, 0.0525 + interestShiftPct);
  const mezzaRate = Math.max(0.04, 0.0780 + interestShiftPct * 1.2);
  const subRate = Math.max(0.05, 0.0890 + interestShiftPct * 1.5);

  const seniorService = Math.round(seniorAmount * (seniorRate / (1 - Math.pow(1 + seniorRate, -25))));
  const mezzaService = Math.round(mezzaAmount * mezzaRate);
  const subService = Math.round(subAmount * subRate);

  const totalAnnualDebtService = seniorService + mezzaService + subService;

  // Revenues & OPEX
  const totalAnnualRevenue = revenueStreams.reduce((acc, r) => acc + r.annualRevenue, 0);
  const totalAnnualOpex = opexBreakdown.reduce((acc, o) => acc + o.annualCost, 0);
  const ebitda = totalAnnualRevenue - totalAnnualOpex;

  // DSCR = Net Operating Income (EBITDA) / Total Debt Service
  const dscr = totalAnnualDebtService > 0 ? parseFloat((ebitda / totalAnnualDebtService).toFixed(2)) : 2.50;
  const llcr = parseFloat((dscr * 1.10).toFixed(2));
  const plcr = parseFloat((dscr * 1.25).toFixed(2));

  // Project IRR & Equity IRR
  // Net cashflow after debt service = EBITDA - Debt Service
  const freeCashToEquity = ebitda - totalAnnualDebtService;
  const equityIrr = Math.max(0.02, Math.min(0.28, (freeCashToEquity / equityAmount) + 0.06));
  const projectIrr = Math.max(0.03, Math.min(0.20, (ebitda / totalProjectCost) + 0.04));

  // NPV @ 7%
  const annualDiscountRate = 0.07;
  const operationalYears = 50;
  let npv7Percent = -totalProjectCost;
  for (let yr = 1; yr <= operationalYears; yr++) {
    const cf = ebitda * Math.pow(1.02, yr); // 2% growth
    npv7Percent += cf / Math.pow(1 + annualDiscountRate, yr);
  }
  npv7Percent = Math.round(npv7Percent);

  const paybackPeriodYears = parseFloat((totalProjectCost / (ebitda || 1)).toFixed(1));

  const debtTranches: DebtTranche[] = [
    {
      id: 'DEBT-01-SR',
      name: 'Senior Infrastructure Debt Facility A1',
      type: 'SENIOR_DEBT',
      amount: seniorAmount,
      interestRate: parseFloat(seniorRate.toFixed(4)),
      tenureYears: 25,
      gracePeriodYears: 5,
      amortizationType: 'AMORTIZING',
      annualServiceCost: seniorService
    },
    {
      id: 'DEBT-02-MZ',
      name: 'Mezzanine Subordinated Facility M1',
      type: 'MEZZANINE',
      amount: mezzaAmount,
      interestRate: parseFloat(mezzaRate.toFixed(4)),
      tenureYears: 15,
      gracePeriodYears: 3,
      amortizationType: 'PERCENTAGE_SWEEP',
      annualServiceCost: mezzaService
    },
    {
      id: 'DEBT-03-SB',
      name: 'Subordinated Debt B1',
      type: 'SUBORDINATED_DEBT',
      amount: subAmount,
      interestRate: parseFloat(subRate.toFixed(4)),
      tenureYears: 12,
      gracePeriodYears: 2,
      amortizationType: 'BULLET',
      annualServiceCost: subService
    }
  ];

  return {
    totalCapex: capex,
    financingCostDuringConstruction,
    contingencyAllowance,
    totalProjectCost,
    equityAmount,
    equityPercent,
    totalDebtAmount,
    gearingRatio: parseFloat((totalDebtAmount / totalProjectCost).toFixed(3)),
    debtTranches,
    dscr,
    llcr,
    plcr,
    projectIrr: parseFloat(projectIrr.toFixed(4)),
    equityIrr: parseFloat(equityIrr.toFixed(4)),
    npv7Percent,
    paybackPeriodYears,
    refinancingRisk: dscr < 1.25 ? 'HIGH' : dscr < 1.55 ? 'MEDIUM' : 'LOW'
  };
}
