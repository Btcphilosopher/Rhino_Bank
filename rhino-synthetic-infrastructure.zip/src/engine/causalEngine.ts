import { SyntheticInfrastructureAsset, BOMCategory, ConstructionTask } from '../types/infrastructure';
import { calculateFinancingStructure } from './financeEngine';

export function propagateCausalChanges(
  asset: SyntheticInfrastructureAsset,
  overrides: {
    materialPriceMultiplier?: { [materialId: string]: number };
    capacityMultiplier?: number;
    delayMonthsAdd?: number;
    demandMultiplier?: number;
    interestRateShiftBps?: number;
  }
): SyntheticInfrastructureAsset {
  const updatedAsset: SyntheticInfrastructureAsset = JSON.parse(JSON.stringify(asset));
  
  // 1. Update BOM Material Costs if multipliers present
  if (overrides.materialPriceMultiplier) {
    let totalBomCost = 0;
    updatedAsset.bom.forEach((cat: BOMCategory) => {
      let catCost = 0;
      cat.items.forEach(item => {
        const mult = overrides.materialPriceMultiplier?.[item.id] || 1.0;
        item.unitPrice = Math.round(item.unitPrice * mult);
        item.totalCost = Math.round(item.quantity * item.unitPrice);
        catCost += item.totalCost;
      });
      cat.totalCost = catCost;
      totalBomCost += catCost;
    });
  }

  // 2. Capacity change propagates into Engineering Specs and Revenue Streams
  if (overrides.capacityMultiplier) {
    const mult = overrides.capacityMultiplier;
    if (updatedAsset.specs.capacityValue) {
      updatedAsset.specs.capacityValue = Math.round(updatedAsset.specs.capacityValue * mult);
    }
    // Update revenue streams based on capacity elasticity
    updatedAsset.revenue_streams.forEach(rev => {
      rev.annualVolume = Math.round(rev.annualVolume * (1 + (mult - 1) * rev.elasticityToDemand));
      rev.annualRevenue = Math.round(rev.annualVolume * rev.unitTariff);
    });
  }

  // 3. Demand multiplier shift
  if (overrides.demandMultiplier) {
    const mult = overrides.demandMultiplier;
    updatedAsset.revenue_streams.forEach(rev => {
      rev.annualVolume = Math.round(rev.annualVolume * mult);
      rev.annualRevenue = Math.round(rev.annualVolume * rev.unitTariff);
    });
  }

  // 4. Construction Schedule Delays
  if (overrides.delayMonthsAdd) {
    const delay = overrides.delayMonthsAdd;
    updatedAsset.construction_schedule.forEach((task: ConstructionTask) => {
      if (task.isCriticalPath) {
        task.durationMonths += delay;
        task.delayDays += delay * 30;
        if (delay > 0 && task.status === 'IN_PROGRESS') {
          task.status = 'DELAYED';
        }
      }
    });
  }

  // 5. Recalculate Total CAPEX from BOM + Civil Costs
  const bomTotal = updatedAsset.bom.reduce((acc, cat) => acc + cat.totalCost, 0);
  updatedAsset.construction_cost = Math.round(bomTotal * 1.15); // Base Capex from BOM + Civil engineering

  // 6. Recalculate Financial Structure (Debt, Equity, Interest during construction, DSCR, IRR, NPV)
  const interestShiftBps = overrides.interestRateShiftBps || 0;
  updatedAsset.financing_structure = calculateFinancingStructure(
    updatedAsset.construction_cost,
    updatedAsset.land_cost,
    updatedAsset.engineering_cost,
    updatedAsset.revenue_streams,
    updatedAsset.opex_breakdown,
    interestShiftBps,
    overrides.delayMonthsAdd || 0
  );

  // 7. Update Version & Audit Provenance
  updatedAsset.version = parseFloat((updatedAsset.version + 0.1).toFixed(1));
  updatedAsset.provenance = {
    source: 'STRESS_ENGINE',
    modelVersion: 'RHINOSYNTH-ENGINE-v3.6.4',
    timestamp: new Date().toISOString(),
    calculationId: `CALC-CAUSAL-${Math.floor(Math.random() * 899999 + 100000)}`,
    assumptions: [
      `Causal propagation triggered at ${new Date().toLocaleTimeString()}`,
      overrides.capacityMultiplier ? `Capacity adjusted by x${overrides.capacityMultiplier.toFixed(2)}` : 'Capacity nominal',
      overrides.delayMonthsAdd ? `Critical path schedule delay of +${overrides.delayMonthsAdd} months applied` : 'Schedule nominal',
      interestShiftBps ? `Interest rate shift of ${interestShiftBps > 0 ? '+' : ''}${interestShiftBps} bps applied` : 'Base interest rates'
    ]
  };

  return updatedAsset;
}
