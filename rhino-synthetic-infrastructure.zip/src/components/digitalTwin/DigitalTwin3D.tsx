import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { SyntheticInfrastructureAsset, DigitalTwinLayer } from '../../types/infrastructure';
import { Layers, RotateCcw, ZoomIn, ZoomOut, Activity, DollarSign, ShieldAlert, Cpu } from 'lucide-react';

interface DigitalTwin3DProps {
  asset: SyntheticInfrastructureAsset;
  activeLayers: DigitalTwinLayer[];
  onToggleLayer: (layer: DigitalTwinLayer) => void;
  selectedNodeId: string | null;
  onSelectNode: (nodeId: string | null) => void;
}

export const DigitalTwin3D: React.FC<DigitalTwin3DProps> = ({
  asset,
  activeLayers,
  onToggleLayer,
  selectedNodeId,
  onSelectNode,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);

  // Animation refs
  const turbineGroupRef = useRef<THREE.Group[]>([]);
  const trainRef = useRef<THREE.Mesh | null>(null);

  const [overlayMode, setOverlayMode] = useState<'ENGINEERING' | 'FINANCIAL' | 'RISK'>('ENGINEERING');

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b111e); // Graphite / Dark Navy
    scene.fog = new THREE.FogExp2(0x0b111e, 0.008);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(40, 30, 50);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xe0f2fe, 1.2);
    dirLight.position.set(50, 80, 30);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const gridHelper = new THREE.GridHelper(120, 60, 0x334155, 0x1e293b);
    gridHelper.position.y = -0.1;
    scene.add(gridHelper);

    // Build Infrastructure 3D Twin Nodes
    const turbineGroups: THREE.Group[] = [];

    // 1. Water / Sea Base
    const seaGeometry = new THREE.PlaneGeometry(120, 120);
    const seaMaterial = new THREE.MeshStandardMaterial({
      color: 0x0369a1,
      roughness: 0.1,
      metalness: 0.8,
      transparent: true,
      opacity: 0.7
    });
    const seaMesh = new THREE.Mesh(seaGeometry, seaMaterial);
    seaMesh.rotation.x = -Math.PI / 2;
    seaMesh.position.set(25, -0.2, 0);
    scene.add(seaMesh);

    // 2. Offshore Wind Array (ENERGY / STRUCTURAL)
    if (activeLayers.includes('ENERGY') || activeLayers.includes('STRUCTURAL')) {
      for (let i = 0; i < 6; i++) {
        const turbineGroup = new THREE.Group();
        const xPos = 20 + (i % 3) * 12;
        const zPos = -20 + Math.floor(i / 3) * 15;
        turbineGroup.position.set(xPos, 0, zPos);

        // Tower
        const towerGeo = new THREE.CylinderGeometry(0.3, 0.6, 12, 16);
        const towerMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.5 });
        const tower = new THREE.Mesh(towerGeo, towerMat);
        tower.position.y = 6;
        turbineGroup.add(tower);

        // Rotor Head & Blades
        const nacelleGeo = new THREE.BoxGeometry(1.2, 0.8, 2);
        const nacelleMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });
        const nacelle = new THREE.Mesh(nacelleGeo, nacelleMat);
        nacelle.position.y = 12;
        turbineGroup.add(nacelle);

        const bladeGroup = new THREE.Group();
        bladeGroup.position.set(0, 12, 1.1);

        for (let b = 0; b < 3; b++) {
          const bladeGeo = new THREE.BoxGeometry(0.2, 5.5, 0.08);
          const bladeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc });
          const blade = new THREE.Mesh(bladeGeo, bladeMat);
          blade.position.y = 2.75;
          blade.rotation.z = (b * Math.PI * 2) / 3;
          bladeGroup.add(blade);
        }

        turbineGroup.add(bladeGroup);
        scene.add(turbineGroup);
        turbineGroups.push(bladeGroup);
      }
    }
    turbineGroupRef.current = turbineGroups;

    // 3. Railway Track & Tunnel (CIVIL / TRANSPORT)
    if (activeLayers.includes('CIVIL') || activeLayers.includes('LOGISTICS')) {
      const trackCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-40, 0, -25),
        new THREE.Vector3(-20, 0, -10),
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(15, 0, 15),
        new THREE.Vector3(35, 0, 25),
      ]);

      const tubeGeo = new THREE.TubeGeometry(trackCurve, 60, 0.4, 8, false);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: overlayMode === 'FINANCIAL' ? 0x10b981 : 0xd97706,
        wireframe: false,
        metalness: 0.6
      });
      const trackMesh = new THREE.Mesh(tubeGeo, tubeMat);
      scene.add(trackMesh);

      // Moving Train
      const trainGeo = new THREE.BoxGeometry(4, 1.2, 1.2);
      const trainMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
      const train = new THREE.Mesh(trainGeo, trainMat);
      scene.add(train);
      trainRef.current = train;
    }

    // 4. Hydrogen Plant & Storage Spheres (MECHANICAL / ENERGY)
    if (activeLayers.includes('MECHANICAL') || activeLayers.includes('ENERGY')) {
      const plantGroup = new THREE.Group();
      plantGroup.position.set(-20, 0, 15);

      const sphereGeo = new THREE.SphereGeometry(3, 32, 32);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: overlayMode === 'RISK' ? 0xf59e0b : 0x06b6d4,
        roughness: 0.2,
        metalness: 0.9
      });
      const tank1 = new THREE.Mesh(sphereGeo, sphereMat);
      tank1.position.set(0, 3, 0);
      plantGroup.add(tank1);

      const tank2 = new THREE.Mesh(sphereGeo, sphereMat);
      tank2.position.set(8, 3, 0);
      plantGroup.add(tank2);

      // Main Plant Building
      const bldgGeo = new THREE.BoxGeometry(10, 6, 12);
      const bldgMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.4 });
      const bldg = new THREE.Mesh(bldgGeo, bldgMat);
      bldg.position.set(4, 3, -10);
      plantGroup.add(bldg);

      scene.add(plantGroup);
    }

    // 5. Subsea Fibre Cable (DIGITAL)
    if (activeLayers.includes('DIGITAL')) {
      const fibreCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-35, -0.1, 30),
        new THREE.Vector3(-10, -0.1, 20),
        new THREE.Vector3(10, -0.1, 10),
        new THREE.Vector3(30, -0.1, -15),
      ]);
      const fibreGeo = new THREE.TubeGeometry(fibreCurve, 40, 0.2, 8, false);
      const fibreMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, wireframe: true });
      const fibreMesh = new THREE.Mesh(fibreGeo, fibreMat);
      scene.add(fibreMesh);
    }

    // Interactive Drag Controls (Simplified Orbit)
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !cameraRef.current) return;
      const deltaX = e.clientX - previousMousePosition.x;
      const deltaY = e.clientY - previousMousePosition.y;

      const rotSpeed = 0.005;
      cameraRef.current.position.x = cameraRef.current.position.x * Math.cos(deltaX * rotSpeed) - cameraRef.current.position.z * Math.sin(deltaX * rotSpeed);
      cameraRef.current.position.z = cameraRef.current.position.z * Math.cos(deltaX * rotSpeed) + cameraRef.current.position.x * Math.sin(deltaX * rotSpeed);
      cameraRef.current.position.y += deltaY * rotSpeed * 10;
      cameraRef.current.lookAt(0, 0, 0);

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => { isDragging = false; };

    const domElem = renderer.domElement;
    domElem.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Rotate turbine blades
      turbineGroupRef.current.forEach((bladeGroup) => {
        bladeGroup.rotation.z += 0.03;
      });

      // Move train along path
      if (trainRef.current) {
        const t = (elapsedTime * 0.1) % 1;
        trainRef.current.position.x = -40 + t * 75;
        trainRef.current.position.z = -25 + t * 50;
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      domElem.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('resize', handleResize);
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [activeLayers, overlayMode, asset]);

  const layersList: DigitalTwinLayer[] = ['CIVIL', 'STRUCTURAL', 'MECHANICAL', 'ELECTRICAL', 'DIGITAL', 'ENERGY', 'LOGISTICS', 'FINANCIAL'];

  return (
    <div className="relative w-full h-full min-h-[480px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
      {/* HUD Header */}
      <div className="absolute top-3 left-3 right-3 z-10 flex flex-wrap justify-between items-center bg-slate-900/90 backdrop-blur-md px-4 py-2.5 rounded-lg border border-slate-800 text-xs font-mono">
        <div className="flex items-center space-x-3">
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
            3D DIGITAL TWIN CAUSAL ENGINE
          </span>
          <span className="text-slate-300 font-semibold">{asset.codename}</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">FPS: 60.0 | Render: WebGL</span>
        </div>

        {/* Overlay Mode Switcher */}
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-md border border-slate-800">
          <button
            onClick={() => setOverlayMode('ENGINEERING')}
            className={`px-2.5 py-1 rounded transition text-[11px] font-semibold flex items-center space-x-1 ${
              overlayMode === 'ENGINEERING' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3 h-3 mr-1" /> Engineering
          </button>
          <button
            onClick={() => setOverlayMode('FINANCIAL')}
            className={`px-2.5 py-1 rounded transition text-[11px] font-semibold flex items-center space-x-1 ${
              overlayMode === 'FINANCIAL' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="w-3 h-3 mr-1" /> Financial
          </button>
          <button
            onClick={() => setOverlayMode('RISK')}
            className={`px-2.5 py-1 rounded transition text-[11px] font-semibold flex items-center space-x-1 ${
              overlayMode === 'RISK' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3 h-3 mr-1" /> Risk Heatmap
          </button>
        </div>
      </div>

      {/* 3D Canvas Canvas Container */}
      <div ref={containerRef} className="w-full h-full flex-1 cursor-grab active:cursor-grabbing" />

      {/* HUD Layer Selector Overlay */}
      <div className="absolute bottom-3 left-3 z-10 bg-slate-900/90 backdrop-blur-md p-3 rounded-lg border border-slate-800 max-w-md">
        <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-2 flex items-center">
          <Layers className="w-3 h-3 mr-1.5 text-sky-400" /> Layer Visibility Filter
        </div>
        <div className="flex flex-wrap gap-1.5">
          {layersList.map((layer) => {
            const isActive = activeLayers.includes(layer);
            return (
              <button
                key={layer}
                onClick={() => onToggleLayer(layer)}
                className={`px-2 py-1 rounded text-[10px] font-mono font-semibold transition border ${
                  isActive
                    ? 'bg-slate-800 text-sky-300 border-sky-500/50 shadow-sm'
                    : 'bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-400'
                }`}
              >
                {layer}
              </button>
            );
          })}
        </div>
      </div>

      {/* Camera Reset Controls */}
      <div className="absolute bottom-3 right-3 z-10 flex space-x-1 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-lg border border-slate-800">
        <button
          onClick={() => {
            if (cameraRef.current) {
              cameraRef.current.position.set(40, 30, 50);
              cameraRef.current.lookAt(0, 0, 0);
            }
          }}
          className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800"
          title="Reset Camera View"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
