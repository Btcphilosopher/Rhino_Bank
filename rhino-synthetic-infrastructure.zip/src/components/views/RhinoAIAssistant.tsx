import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { queryRhinoAIAssistant } from '../../services/aiService';
import { Sparkles, Send, Bot, User, RefreshCw, Cpu } from 'lucide-react';

interface RhinoAIAssistantProps {
  currentProject: SyntheticInfrastructureAsset;
}

interface ChatMessage {
  id: string;
  sender: 'USER' | 'AI';
  text: string;
  timestamp: string;
}

export const RhinoAIAssistant: React.FC<RhinoAIAssistantProps> = ({ currentProject }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'AI',
      text: `Greetings. I am Rhino Infra Intelligence, initialized with Model Version ${currentProject.provenance.modelVersion}. Ask me any complex project finance, critical path, risk or sensitivity questions regarding ${currentProject.name}.`,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputQuery.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'USER',
      text: inputQuery,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    const query = inputQuery;
    setInputQuery('');
    setIsLoading(true);

    try {
      const aiReplyText = await queryRhinoAIAssistant(query, currentProject);
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'AI',
        text: aiReplyText,
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error('AI assistant query error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4 font-sans font-mono max-w-4xl mx-auto h-[calc(100vh-180px)] min-h-[580px] flex flex-col">
      {/* Header */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-xl flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded bg-amber-950 border border-amber-800 text-amber-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-100 uppercase tracking-tight">
              RHINO AI INFRA INTELLIGENCE
            </h1>
            <p className="text-[10px] text-slate-400">
              Grounded Institutional Model Analytics • Gemini 3.6
            </p>
          </div>
        </div>

        <span className="text-xs text-emerald-400 font-bold bg-emerald-950 px-3 py-1 rounded border border-emerald-800">
          Context Loaded: {currentProject.codename}
        </span>
      </div>

      {/* Chat Messages Box */}
      <div className="flex-1 bg-slate-900 rounded-xl border border-slate-800 p-4 overflow-y-auto space-y-4 shadow-xl">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex items-start space-x-3 ${msg.sender === 'USER' ? 'flex-row-reverse space-x-reverse' : ''}`}
          >
            <div className={`p-2 rounded-lg ${msg.sender === 'USER' ? 'bg-sky-900 text-sky-200' : 'bg-slate-950 text-amber-400 border border-slate-800'}`}>
              {msg.sender === 'USER' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`max-w-[80%] p-3.5 rounded-xl text-xs leading-relaxed ${
              msg.sender === 'USER'
                ? 'bg-sky-600 text-white rounded-tr-none'
                : 'bg-slate-950 text-slate-200 border border-slate-800 rounded-tl-none shadow-inner'
            }`}>
              <div className="text-[9px] text-slate-400 mb-1 font-bold flex justify-between">
                <span>{msg.sender === 'USER' ? 'YOU' : 'RHINO INFRA INTELLIGENCE'}</span>
                <span className="ml-2 text-slate-500">{msg.timestamp}</span>
              </div>
              <div className="whitespace-pre-wrap">{msg.text}</div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center space-x-2 text-xs text-amber-400 bg-slate-950 p-3 rounded border border-slate-800 w-max">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Consulting Model Audit Logs & Cashflow Engine...</span>
          </div>
        )}
      </div>

      {/* Suggested Queries */}
      <div className="flex flex-wrap gap-2 text-[10px]">
        {[
          "Why did the project IRR fall?",
          "What is on the critical path?",
          "What happens if demand falls 20%?",
          "How much additional debt can the project support?"
        ].map((q, idx) => (
          <button
            key={idx}
            onClick={() => setInputQuery(q)}
            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Query Input Bar */}
      <form onSubmit={handleSendMessage} className="flex gap-2">
        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          placeholder="Ask Rhino AI Intelligence about project IRR, debt service, critical path or sensitivity..."
          className="flex-1 bg-slate-900 border border-slate-700 text-slate-100 px-4 py-3 rounded-xl text-xs font-mono focus:outline-none focus:border-amber-500 placeholder-slate-500 shadow-xl"
        />
        <button
          type="submit"
          disabled={isLoading || !inputQuery.trim()}
          className="px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:bg-slate-800 text-white font-bold text-xs shadow flex items-center justify-center"
        >
          <Send className="w-4 h-4 mr-1.5" /> Submit Query
        </button>
      </form>
    </div>
  );
};
