import React from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { FileText, ShieldCheck, Download, Award, CheckCircle } from 'lucide-react';

interface InvestmentCommitteeProps {
  currentProject: SyntheticInfrastructureAsset;
}

export const InvestmentCommittee: React.FC<InvestmentCommitteeProps> = ({ currentProject }) => {
  const fin = currentProject.financing_structure;

  return (
    <div className="space-y-6 font-sans font-mono max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <div className="flex items-center space-x-2 text-[10px] text-amber-400 font-bold uppercase mb-1">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Rhino Bank Investment Committee Governance</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 uppercase tracking-tight">
            AUDITABLE INVESTMENT COMMITTEE MEMORANDUM
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Generated directly from underlying model outputs • Reproducible Audit Trail
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition border border-slate-700 flex items-center"
        >
          <Download className="w-4 h-4 mr-2" /> Export PDF Memo
        </button>
      </div>

      {/* Formal Investment Memo Document */}
      <div className="bg-slate-900 p-8 rounded-xl border border-slate-800 shadow-2xl space-y-6 text-slate-200">
        <div className="border-b border-slate-800 pb-4 flex justify-between items-start">
          <div>
            <div className="text-xs text-amber-400 font-bold uppercase">CONFIDENTIAL MEMORANDUM</div>
            <h2 className="text-xl font-serif font-bold text-slate-100 mt-1">{currentProject.name}</h2>
            <div className="text-xs text-slate-400 mt-1">Asset Codename: {currentProject.codename} • Version {currentProject.version}</div>
          </div>
          <div className="text-right text-xs text-slate-400 space-y-1">
            <div>DATE: {new Date().toLocaleDateString('en-GB')}</div>
            <div>CALCULATION ID: <span className="text-sky-400 font-bold">{currentProject.provenance.calculationId}</span></div>
            <div>MODEL: <span className="text-emerald-400 font-bold">{currentProject.provenance.modelVersion}</span></div>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-sky-400 uppercase tracking-wider">1. EXECUTIVE PROPOSAL & RECOMMENDATION</h3>
          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-4 rounded border border-slate-800">
            The Infrastructure Investment Committee is requested to approve a senior debt underwriting facility of <strong className="text-emerald-400">£{(fin.totalDebtAmount / 1e9).toFixed(2)}bn</strong> and equity co-investment of <strong className="text-amber-400">£{(fin.equityAmount / 1e9).toFixed(2)}bn</strong> for the construction and operation of {currentProject.name}. Total required project capital is £{(fin.totalProjectCost / 1e9).toFixed(2)}bn.
          </p>
        </div>

        {/* Model Metrics Key Matrix */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-sky-400 uppercase tracking-wider">2. AUDITED MODEL OUTPUT METRICS</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">CAPEX Base</div>
              <div className="text-sm font-bold text-emerald-400">£{(currentProject.construction_cost / 1e9).toFixed(2)}bn</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">Project IRR</div>
              <div className="text-sm font-bold text-amber-400">{(fin.projectIrr * 100).toFixed(2)}%</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">DSCR Coverage</div>
              <div className="text-sm font-bold text-sky-400">{fin.dscr}x</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">Net Present Value (7%)</div>
              <div className="text-sm font-bold text-purple-400">£{(fin.npv7Percent / 1e9).toFixed(2)}bn</div>
            </div>
          </div>
        </div>

        {/* Model Provenance & Governance */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-sky-400 uppercase tracking-wider">3. MODEL PROVENANCE & AUDIT TRAIL</h3>
          <div className="bg-slate-950 p-4 rounded border border-slate-800 text-xs space-y-2 text-slate-400">
            <div className="flex items-center text-emerald-400 font-bold">
              <CheckCircle className="w-4 h-4 mr-2" /> Model State Provenance: {currentProject.provenance.source}
            </div>
            <div>Generated At: {currentProject.provenance.timestamp}</div>
            <div className="text-slate-300 font-bold mt-2">Key Model Assumptions:</div>
            <ul className="list-disc list-inside space-y-1 pl-2 text-slate-400">
              {currentProject.provenance.assumptions.map((a, i) => (
                <li key={i}>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
