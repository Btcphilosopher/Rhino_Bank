import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { runMonteCarloSimulation, runScenarioLab } from '../../engine/riskEngine';
import { ShieldAlert, Play, Cpu, TrendingDown, DollarSign, Activity, Zap } from 'lucide-react';

interface ScenarioLabProps {
  currentProject: SyntheticInfrastructureAsset;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({ currentProject }) => {
  const [mcIterations, setMcIterations] = useState<number>(1000);
  const [mcResults, setMcResults] = useState<any>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const scenarioResults = runScenarioLab(currentProject);

  const handleRunMonteCarlo = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = runMonteCarloSimulation(currentProject, mcIterations);
      setMcResults(res);
      setIsSimulating(false);
    }, 300);
  };

  return (
    <div className="space-y-6 font-sans font-mono">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <ShieldAlert className="w-5 h-5 text-amber-400 mr-2" />
            RHINO INFRASTRUCTURE SCENARIO LAB & MONTE CARLO ENGINE
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Macroeconomic Stress Scenarios • Stochastic Monte Carlo Distributions (P5 / P50 / P95)
          </p>
        </div>

        <button
          onClick={handleRunMonteCarlo}
          disabled={isSimulating}
          className="px-5 py-2.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition shadow flex items-center space-x-2"
        >
          <Play className="w-4 h-4 mr-1.5" />
          {isSimulating ? 'Running 1,000 Iterations...' : 'Run Monte Carlo (1,000 Scenarios)'}
        </button>
      </div>

      {/* Monte Carlo Output Results (If Run) */}
      {mcResults && (
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg space-y-3">
          <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center">
            <Activity className="w-4 h-4 mr-2" /> Monte Carlo Stochastic Output (1,000 Iterations)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">CAPEX P5 / P50 / P95</div>
              <div className="text-sm font-bold text-slate-100 mt-1">
                P5: £{(mcResults.p5Capex / 1e9).toFixed(2)}bn | P50: £{(mcResults.p50Capex / 1e9).toFixed(2)}bn | P95: £{(mcResults.p95Capex / 1e9).toFixed(2)}bn
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">Project IRR P5 / P50 / P95</div>
              <div className="text-sm font-bold text-amber-400 mt-1">
                P5: {(mcResults.p5Irr * 100).toFixed(1)}% | P50: {(mcResults.p50Irr * 100).toFixed(1)}% | P95: {(mcResults.p95Irr * 100).toFixed(1)}%
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">DSCR Coverage P5 / P50 / P95</div>
              <div className="text-sm font-bold text-sky-400 mt-1">
                P5: {mcResults.p5Dscr}x | P50: {mcResults.p50Dscr}x | P95: {mcResults.p95Dscr}x
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scenario Lab Stress Tests Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Deterministic Macro & Systemic Stress Scenarios
          </span>
          <span className="text-xs text-slate-500">{scenarioResults.length} Scenarios Evaluated</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-3 px-4">Scenario Name</th>
                <th className="py-3 px-4">Shocks Applied</th>
                <th className="py-3 px-4">New Project NPV @ 7%</th>
                <th className="py-3 px-4">New IRR</th>
                <th className="py-3 px-4">New DSCR</th>
                <th className="py-3 px-4">Completion Date</th>
                <th className="py-3 px-4 text-right">Financing Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {scenarioResults.map((s, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-semibold text-slate-100 flex flex-col">
                    <span>{s.scenarioName}</span>
                    <span className="text-[9px] text-slate-500">{s.description}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    CAPEX {s.capexChangePercent > 0 ? `+${s.capexChangePercent}%` : '0%'}, Rates {s.interestRateChangeBps > 0 ? `+${s.interestRateChangeBps}bps` : '0'}
                  </td>
                  <td className="py-3 px-4 font-bold text-purple-400">
                    £{(s.newNpv / 1e9).toFixed(2)}bn
                  </td>
                  <td className="py-3 px-4 font-bold text-amber-400">
                    {(s.newIrr * 100).toFixed(2)}%
                  </td>
                  <td className="py-3 px-4 font-bold text-sky-400">
                    {s.newDscr}x
                  </td>
                  <td className="py-3 px-4 text-slate-300">{s.newCompletionDate}</td>
                  <td className="py-3 px-4 text-right">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      s.newDscr < 1.25 ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}>
                      {s.newDscr < 1.25 ? 'DEFICIT RISK' : 'SOLVENT'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
