import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { Activity, Clock, AlertOctagon, Cpu, Play, FastForward, ShieldAlert } from 'lucide-react';

interface ConstructionSimulatorProps {
  currentProject: SyntheticInfrastructureAsset;
  onUpdateProject: (p: SyntheticInfrastructureAsset) => void;
}

export const ConstructionSimulator: React.FC<ConstructionSimulatorProps> = ({ currentProject, onUpdateProject }) => {
  const [selectedPhaseFilter, setSelectedPhaseFilter] = useState<string>('ALL');

  const tasks = currentProject.construction_schedule;
  const filteredTasks = selectedPhaseFilter === 'ALL' ? tasks : tasks.filter(t => t.phase === selectedPhaseFilter);

  const handleSimulateDelay = (taskId: string) => {
    const updated = JSON.parse(JSON.stringify(currentProject)) as SyntheticInfrastructureAsset;
    const task = updated.construction_schedule.find(t => t.id === taskId);
    if (task) {
      task.delayDays += 60; // 2 months slip
      task.status = 'DELAYED';

      // Propagate critical path delays to financing
      if (task.isCriticalPath) {
        updated.financing_structure.financingCostDuringConstruction += 150000000; // £150m extra interest during construction
        updated.financing_structure.totalProjectCost += 150000000;
        updated.financing_structure.dscr = parseFloat((updated.financing_structure.dscr - 0.08).toFixed(2));
      }
    }
    onUpdateProject(updated);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-mono font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <Clock className="w-5 h-5 text-amber-400 mr-2" />
            RHINO PROJECT CONTROL & CONSTRUCTION SIMULATOR
          </h1>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Critical Path Method (CPM) • Machine Utilisation Telemetry • Delay Cost Propagation
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Schedule Completion: </span>
            <span className="text-emerald-400 font-bold ml-1">{currentProject.constructionProgressPercent}%</span>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Critical Path Tasks: </span>
            <span className="text-amber-400 font-bold ml-1">{tasks.filter(t => t.isCriticalPath).length} Active</span>
          </div>
        </div>
      </div>

      {/* Active Construction Machines Live Status */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
        <div className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center justify-between">
          <span>Active Construction Machines & Machinery Fleet Utilisation</span>
          <span className="text-[10px] text-emerald-400">Real-time Telemetry Active</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 font-mono">
          {currentProject.machines.map(m => (
            <div key={m.id} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
              <div className="text-[10px] font-bold text-sky-400 truncate">{m.name}</div>
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>Fleet Count: {m.count}</span>
                <span className="text-amber-400 font-bold">{m.utilizationRate}% Utilized</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full" style={{ width: `${m.utilizationRate}%` }}></div>
              </div>
              <div className="text-[9px] text-slate-500 flex justify-between">
                <span>£{m.hourlyCost}/hr</span>
                <span className="text-emerald-400 font-bold">{m.operationalStatus}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Gantt Schedule & Critical Path Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl font-mono">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center">
            <Activity className="w-4 h-4 text-purple-400 mr-2" /> Gantt Timeline & Schedule Breakdown
          </span>

          {/* Phase Filter Buttons */}
          <div className="flex space-x-1">
            {['ALL', 'LAND', 'FOUNDATIONS', 'CIVIL', 'STRUCTURES', 'SYSTEMS', 'TESTING'].map(phase => (
              <button
                key={phase}
                onClick={() => setSelectedPhaseFilter(phase)}
                className={`px-2 py-0.5 rounded text-[10px] font-bold border transition ${
                  selectedPhaseFilter === phase
                    ? 'bg-sky-600 text-white border-sky-500'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                {phase}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-3 px-4">Task Name</th>
                <th className="py-3 px-4">Phase</th>
                <th className="py-3 px-4">Timeline</th>
                <th className="py-3 px-4">Progress</th>
                <th className="py-3 px-4">Critical Path</th>
                <th className="py-3 px-4">Contractor</th>
                <th className="py-3 px-4">Cost (Estimated / Actual)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Stress Test</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {filteredTasks.map(t => (
                <tr key={t.id} className="hover:bg-slate-800/50">
                  <td className="py-3 px-4 font-semibold text-slate-200 flex flex-col">
                    <span>{t.name}</span>
                    <span className="text-[9px] text-slate-500">ID: {t.id}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-sky-400 border border-slate-700">
                      {t.phase}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    M{t.startMonth} - M{t.startMonth + t.durationMonths} ({t.durationMonths} mos)
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full" style={{ width: `${t.completionPercent}%` }}></div>
                      </div>
                      <span className="text-[10px] text-slate-400">{t.completionPercent}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    {t.isCriticalPath ? (
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-amber-950 text-amber-400 border border-amber-800">
                        CRITICAL
                      </span>
                    ) : (
                      <span className="text-slate-500 text-[10px]">Standard</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-400">{t.assignedContractor}</td>
                  <td className="py-3 px-4">
                    <span className="text-slate-200 font-bold">£{(t.estimatedCost / 1e6).toFixed(1)}m</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      t.status === 'COMPLETED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                      t.status === 'DELAYED' ? 'bg-rose-950 text-rose-400 border border-rose-800' :
                      'bg-slate-800 text-sky-400 border border-slate-700'
                    }`}>
                      {t.status} {t.delayDays > 0 ? `(+${t.delayDays}d)` : ''}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleSimulateDelay(t.id)}
                      className="px-2.5 py-1 bg-amber-950 hover:bg-amber-900 text-amber-300 rounded text-[9px] font-bold transition border border-amber-800 flex items-center ml-auto"
                    >
                      <AlertOctagon className="w-3 h-3 mr-1" /> +60d Slip
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
