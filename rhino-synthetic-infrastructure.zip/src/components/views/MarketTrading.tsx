import React, { useState } from 'react';
import { SEED_SECURITISED_BONDS } from '../../data/flagshipProject';
import { calculateCompositeIndexValue, executeSimulatedTrade, RHINO_INFRA_INDEX } from '../../engine/marketEngine';
import { SecuritisedBond } from '../../types/infrastructure';
import { TrendingUp, ShoppingBag, DollarSign, Shield, ArrowUpRight, ArrowDownRight } from 'lucide-react';

export const MarketTrading: React.FC = () => {
  const [bonds, setBonds] = useState<SecuritisedBond[]>(SEED_SECURITISED_BONDS);
  const [selectedBond, setSelectedBond] = useState<SecuritisedBond>(SEED_SECURITISED_BONDS[0]);
  const [orderNotional, setOrderNotional] = useState<number>(50000000); // £50m
  const [tradeLogs, setTradeLogs] = useState<string[]>([]);

  const indexData = calculateCompositeIndexValue();

  const handleExecuteTrade = (side: 'BUY' | 'SELL') => {
    const res = executeSimulatedTrade(selectedBond, side, orderNotional);
    if (res.success) {
      setTradeLogs([`[${new Date().toLocaleTimeString()}] ${res.msg}`, ...tradeLogs]);
    }
  };

  return (
    <div className="space-y-6 font-sans font-mono">
      {/* Top Banner & Index Ticker */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <TrendingUp className="w-5 h-5 text-emerald-400 mr-2" />
            RHINO INFRASTRUCTURE MARKETS & TRADING DESK
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Simulated Trading of Infrastructure Debt, Revenue Bonds, Index Swaps & Hedges
          </p>
        </div>

        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div>
            <div className="text-[10px] text-slate-500 uppercase">RHINO-INFRA-100 INDEX</div>
            <div className="text-lg font-bold text-slate-100">{indexData.value}</div>
          </div>
          <span className={`px-2 py-0.5 rounded text-xs font-bold ${indexData.dailyChange >= 0 ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'}`}>
            {indexData.dailyChange >= 0 ? '+' : ''}{indexData.dailyChange}% 24H
          </span>
        </div>
      </div>

      {/* Index Sector Components */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
          RHINO INFRA-100 Sector Index Components
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {RHINO_INFRA_INDEX.map((sec, idx) => (
            <div key={idx} className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 font-bold truncate">{sec.sector}</div>
              <div className="flex justify-between items-baseline mt-1">
                <span className="text-sm font-bold text-slate-100">{sec.indexValue}</span>
                <span className={`text-[10px] font-bold ${sec.dailyChangePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {sec.dailyChangePct >= 0 ? '+' : ''}{sec.dailyChangePct}%
                </span>
              </div>
              <div className="text-[9px] text-slate-500 mt-0.5">Weight: {sec.weightPercent}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Orderbook & Execution Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Bonds Orderbook Table (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Securitised Infrastructure Debt & Bond Market
            </span>
            <span className="text-xs text-slate-500">{bonds.length} Active Securities Listed</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
                <tr>
                  <th className="py-3 px-4">Bond / Tranche</th>
                  <th className="py-3 px-4">Rating</th>
                  <th className="py-3 px-4">Bid Price</th>
                  <th className="py-3 px-4">Ask Price</th>
                  <th className="py-3 px-4">Spread</th>
                  <th className="py-3 px-4">Yield</th>
                  <th className="py-3 px-4 text-right">Select</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {bonds.map(b => (
                  <tr
                    key={b.bondId}
                    onClick={() => setSelectedBond(b)}
                    className={`hover:bg-slate-800/50 cursor-pointer ${
                      selectedBond.bondId === b.bondId ? 'bg-slate-800/80 border-l-2 border-emerald-400' : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-semibold text-slate-100 flex flex-col">
                      <span>{b.trancheName}</span>
                      <span className="text-[9px] text-slate-500">{b.projectName}</span>
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-400">{b.rating}</td>
                    <td className="py-3 px-4 font-bold text-emerald-400">{b.bidPrice}%</td>
                    <td className="py-3 px-4 font-bold text-rose-400">{b.askPrice}%</td>
                    <td className="py-3 px-4 text-slate-400">{b.spreadBps} bps</td>
                    <td className="py-3 px-4 font-bold text-amber-400">{(b.currentYield * 100).toFixed(2)}%</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedBond(b)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-bold"
                      >
                        Trade
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Order Execution Form & Trade Audit Log (4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-xl space-y-3">
            <div className="text-xs font-bold text-slate-200 uppercase tracking-wider pb-2 border-b border-slate-800 flex justify-between">
              <span>Order Execution Ticket</span>
              <span className="text-emerald-400 font-bold">{selectedBond.rating}</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
              <div className="text-[10px] text-slate-400 font-bold">{selectedBond.trancheName}</div>
              <div className="text-[9px] text-slate-500">{selectedBond.projectName}</div>
              <div className="flex justify-between text-xs font-bold mt-1">
                <span className="text-emerald-400">Bid: {selectedBond.bidPrice}%</span>
                <span className="text-rose-400">Ask: {selectedBond.askPrice}%</span>
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase block mb-1">Notional Amount (GBP)</label>
              <input
                type="number"
                step="1000000"
                value={orderNotional}
                onChange={(e) => setOrderNotional(parseFloat(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-3 py-2 rounded text-xs font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => handleExecuteTrade('BUY')}
                className="py-2.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow flex items-center justify-center"
              >
                <ArrowUpRight className="w-4 h-4 mr-1" /> BUY NOTIONAL
              </button>
              <button
                onClick={() => handleExecuteTrade('SELL')}
                className="py-2.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow flex items-center justify-center"
              >
                <ArrowDownRight className="w-4 h-4 mr-1" /> SELL NOTIONAL
              </button>
            </div>
          </div>

          {/* Trade Execution Log */}
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-xl space-y-2">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Simulated Execution Log
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 h-32 overflow-y-auto space-y-1 text-[10px] text-slate-300">
              {tradeLogs.length === 0 ? (
                <div className="text-slate-600 italic">No simulated trades executed yet.</div>
              ) : (
                tradeLogs.map((log, i) => <div key={i}>{log}</div>)
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
