import React, { useState } from 'react';
import { SyntheticInfrastructureAsset, PhysicalComponentState } from '../../types/infrastructure';
import { Activity, ShieldAlert, Cpu, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';

interface AssetManagementProps {
  currentProject: SyntheticInfrastructureAsset;
  onUpdateProject: (p: SyntheticInfrastructureAsset) => void;
}

export const AssetManagement: React.FC<AssetManagementProps> = ({ currentProject, onUpdateProject }) => {
  const [components, setComponents] = useState<PhysicalComponentState[]>(currentProject.physical_components);

  const handleSimulateComponentFailure = (comp: PhysicalComponentState) => {
    const updatedProject = JSON.parse(JSON.stringify(currentProject)) as SyntheticInfrastructureAsset;
    const targetComp = updatedProject.physical_components.find(c => c.componentId === comp.componentId);

    if (targetComp) {
      targetComp.structuralConditionScore = 42;
      targetComp.maintenanceStatus = 'CRITICAL';
      targetComp.predictedFailureRisk = 0.88;

      // Failure reduces revenue and increases OPEX
      updatedProject.revenue_streams.forEach(r => {
        r.annualRevenue = Math.round(r.annualRevenue * 0.82); // -18% revenue drop
      });
      updatedProject.operating_cost_annual += 45000000; // £45m emergency repair
      updatedProject.financing_structure.dscr = parseFloat((updatedProject.financing_structure.dscr - 0.22).toFixed(2));
    }

    onUpdateProject(updatedProject);
    setComponents(updatedProject.physical_components);
  };

  return (
    <div className="space-y-6 font-sans font-mono">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <Activity className="w-5 h-5 text-sky-400 mr-2" />
            OPERATIONAL ASSET MANAGEMENT & PREDICTIVE MAINTENANCE TWIN
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Component Structural Health Monitoring • ML Failure Risk vs Measured Condition • Causal Failure Propagation
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-xs">
          <span className="text-slate-400">Total Asset Components Monitored: </span>
          <span className="text-sky-400 font-bold ml-1">{components.length} Digital Twins</span>
        </div>
      </div>

      {/* Components Health Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Physical Asset Component Structural Telemetry
          </span>
          <span className="text-xs text-emerald-400">ML Model Version: v3.6.4</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-3 px-4">Component Name</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Structural Score</th>
                <th className="py-3 px-4">Design Life</th>
                <th className="py-3 px-4">ML Failure Risk</th>
                <th className="py-3 px-4">ML Confidence</th>
                <th className="py-3 px-4">Maintenance</th>
                <th className="py-3 px-4 text-right">Stress Test</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {components.map(c => (
                <tr key={c.componentId} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-semibold text-slate-100 flex flex-col">
                    <span>{c.name}</span>
                    <span className="text-[9px] text-slate-500">ID: {c.componentId}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{c.type}</td>
                  <td className="py-3 px-4">
                    <span className={`font-bold ${c.structuralConditionScore > 80 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {c.structuralConditionScore}%
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">{c.remainingDesignLifeYears} Years Remaining</td>
                  <td className="py-3 px-4">
                    <span className={`font-bold ${c.predictedFailureRisk > 0.15 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {(c.predictedFailureRisk * 100).toFixed(1)}%
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sky-400 font-bold">{(c.mlConfidence * 100).toFixed(0)}%</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      c.maintenanceStatus === 'OPTIMAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                      c.maintenanceStatus === 'CRITICAL' ? 'bg-rose-950 text-rose-400 border border-rose-800' :
                      'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      {c.maintenanceStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleSimulateComponentFailure(c)}
                      className="px-2 py-1 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded text-[9px] font-bold transition border border-rose-800 ml-auto flex items-center"
                    >
                      <AlertTriangle className="w-3 h-3 mr-1" /> Simulate Failure
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
