import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { DollarSign, TrendingUp, RefreshCw, Layers, ShieldCheck, ArrowDownRight, Award } from 'lucide-react';

interface ProjectFinanceProps {
  currentProject: SyntheticInfrastructureAsset;
  onUpdateProject: (p: SyntheticInfrastructureAsset) => void;
}

export const ProjectFinance: React.FC<ProjectFinanceProps> = ({ currentProject, onUpdateProject }) => {
  const fin = currentProject.financing_structure;

  const [refinanceRate, setRefinanceRate] = useState<number>(4.25);
  const [refinanceTenure, setRefinanceTenure] = useState<number>(30);
  const [isRefinanced, setIsRefinanced] = useState<boolean>(false);

  const handleExecuteRefinancing = () => {
    const updated = JSON.parse(JSON.stringify(currentProject)) as SyntheticInfrastructureAsset;
    
    // Recalculate senior debt service at new refinance rate
    const newSeniorRate = refinanceRate / 100;
    const seniorTranche = updated.financing_structure.debtTranches[0];
    if (seniorTranche) {
      seniorTranche.interestRate = newSeniorRate;
      seniorTranche.tenureYears = refinanceTenure;
      seniorTranche.annualServiceCost = Math.round(
        seniorTranche.amount * (newSeniorRate / (1 - Math.pow(1 + newSeniorRate, -refinanceTenure)))
      );
    }

    // Improve DSCR and Equity IRR post-refinancing
    updated.financing_structure.dscr = parseFloat((updated.financing_structure.dscr + 0.35).toFixed(2));
    updated.financing_structure.equityIrr = parseFloat((updated.financing_structure.equityIrr + 0.024).toFixed(4));
    updated.operational_state = 'REFINANCED';

    setIsRefinanced(true);
    onUpdateProject(updated);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-mono font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <DollarSign className="w-5 h-5 text-emerald-400 mr-2" />
            PROJECT FINANCE & SECURITISATION ENGINE
          </h1>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Institutional Debt Structuring • Debt Service Coverage (DSCR / LLCR / PLCR) • Refinancing Simulator
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-xs font-mono">
          <span className="text-slate-400">Total Capital Raised: </span>
          <span className="text-emerald-400 font-bold ml-1">£{(fin.totalProjectCost / 1e9).toFixed(2)}bn</span>
        </div>
      </div>

      {/* Primary Key Ratios Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 font-mono">
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[10px] text-slate-400 uppercase">DSCR (Debt Service Coverage)</div>
          <div className="text-2xl font-bold text-emerald-400">{fin.dscr}x</div>
          <div className="text-[9px] text-slate-500 mt-1">Min Target: 1.30x</div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[10px] text-slate-400 uppercase">LLCR (Loan Life Coverage)</div>
          <div className="text-2xl font-bold text-sky-400">{fin.llcr}x</div>
          <div className="text-[9px] text-slate-500 mt-1">Min Target: 1.45x</div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[10px] text-slate-400 uppercase">Project IRR</div>
          <div className="text-2xl font-bold text-amber-400">{(fin.projectIrr * 100).toFixed(2)}%</div>
          <div className="text-[9px] text-slate-500 mt-1">Unlevered Return</div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[10px] text-slate-400 uppercase">Equity IRR</div>
          <div className="text-2xl font-bold text-purple-400">{(fin.equityIrr * 100).toFixed(2)}%</div>
          <div className="text-[9px] text-slate-500 mt-1">Levered Equity Yield</div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[10px] text-slate-400 uppercase">NPV @ 7% Discount</div>
          <div className="text-2xl font-bold text-emerald-400">£{(fin.npv7Percent / 1e9).toFixed(2)}bn</div>
          <div className="text-[9px] text-slate-500 mt-1">50-Year Concession Net Present Value</div>
        </div>
      </div>

      {/* Debt Tranches Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl font-mono">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center">
            <Layers className="w-4 h-4 text-sky-400 mr-2" /> Capital Structure & Debt Tranche Facilities
          </span>
          <span className="text-xs font-bold text-sky-400">
            Total Debt: £{(fin.totalDebtAmount / 1e9).toFixed(2)}bn ({((1 - fin.equityPercent / 100) * 100).toFixed(1)}%)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-3 px-4">Facility Name</th>
                <th className="py-3 px-4">Tier / Type</th>
                <th className="py-3 px-4">Principal Amount</th>
                <th className="py-3 px-4">Coupon / Interest</th>
                <th className="py-3 px-4">Tenure</th>
                <th className="py-3 px-4">Amortization</th>
                <th className="py-3 px-4 text-right">Annual Debt Service</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {fin.debtTranches.map(d => (
                <tr key={d.id} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-semibold text-slate-200">{d.name}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-sky-400 border border-slate-700">
                      {d.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-100">
                    £{(d.amount / 1e9).toFixed(2)}bn
                  </td>
                  <td className="py-3 px-4 text-amber-400 font-bold">
                    {(d.interestRate * 100).toFixed(2)}%
                  </td>
                  <td className="py-3 px-4 text-slate-400">{d.tenureYears} Years ({d.gracePeriodYears}y Grace)</td>
                  <td className="py-3 px-4 text-slate-400">{d.amortizationType}</td>
                  <td className="py-3 px-4 text-right font-bold text-emerald-400">
                    £{(d.annualServiceCost / 1e6).toFixed(1)}m/yr
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Refinancing Simulator Box */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl space-y-4 font-mono">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider flex items-center">
              <RefreshCw className="w-4 h-4 text-emerald-400 mr-2" />
              Post-Commissioning Infrastructure Refinancing Simulator
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Refinance construction debt with long-term institutional infrastructure bonds to lower interest & boost Equity IRR
            </p>
          </div>

          {isRefinanced && (
            <span className="px-3 py-1 rounded text-xs font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center">
              <Award className="w-4 h-4 mr-1.5" /> REFINANCING EXECUTED
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          <div>
            <label className="text-[10px] text-slate-400 uppercase block mb-1">Target Refinance Senior Coupon (%)</label>
            <input
              type="number"
              step="0.05"
              value={refinanceRate}
              onChange={(e) => setRefinanceRate(parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-3 py-2 rounded text-xs font-bold"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase block mb-1">Extended Bond Maturity (Years)</label>
            <input
              type="number"
              value={refinanceTenure}
              onChange={(e) => setRefinanceTenure(parseInt(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-3 py-2 rounded text-xs font-bold"
            />
          </div>

          <div className="pt-4">
            <button
              onClick={handleExecuteRefinancing}
              className="w-full py-2.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow flex items-center justify-center"
            >
              <RefreshCw className="w-4 h-4 mr-2" /> Execute Refinancing Optimization
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
