import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { ShoppingCart, Truck, CheckCircle2, FileText, Send } from 'lucide-react';

interface ProcurementProps {
  currentProject: SyntheticInfrastructureAsset;
}

export const Procurement: React.FC<ProcurementProps> = ({ currentProject }) => {
  const [rfqSubmitted, setRfqSubmitted] = useState<boolean>(false);
  const [selectedSupplier, setSelectedSupplier] = useState<string>('British Steel Scunthorpe PLC');

  return (
    <div className="space-y-6 font-sans font-mono">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <ShoppingCart className="w-5 h-5 text-emerald-400 mr-2" />
            INFRASTRUCTURE PROCUREMENT & SUPPLY CHAIN SIMULATOR
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Supplier RFQs • Purchase Order Matching • Delivery Schedule Propagation
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-xs">
          <span className="text-slate-400">Total Purchase Orders Logged: </span>
          <span className="text-emerald-400 font-bold ml-1">18 Contracts Active</span>
        </div>
      </div>

      {/* RFQ Generator Form */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl space-y-4">
        <div className="text-xs font-bold text-slate-200 uppercase tracking-wider pb-2 border-b border-slate-800 flex justify-between">
          <span>Request for Quote (RFQ) & Supplier Bidding</span>
          <span className="text-sky-400">Project: {currentProject.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="text-[10px] text-slate-400 uppercase block mb-1">Target Supplier</label>
            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-3 py-2 rounded text-xs font-bold"
            >
              <option>British Steel Scunthorpe PLC</option>
              <option>Siemens Mobility UK</option>
              <option>Alstom Transport Europe</option>
              <option>Orsted North Sea Heavy Infra</option>
              <option>Subsea Cables Ltd</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase block mb-1">Order Volume & Material</label>
            <input
              type="text"
              readOnly
              value="50,000 Tonnes Structural Steel Rail 60E1"
              className="w-full bg-slate-950 border border-slate-800 text-slate-400 px-3 py-2 rounded text-xs"
            />
          </div>

          <div className="pt-4">
            <button
              onClick={() => setRfqSubmitted(true)}
              className="w-full py-2.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow flex items-center justify-center"
            >
              <Send className="w-4 h-4 mr-2" /> Issue Formal RFQ Order
            </button>
          </div>
        </div>

        {rfqSubmitted && (
          <div className="bg-emerald-950/80 border border-emerald-800 p-3 rounded text-emerald-300 text-xs flex items-center">
            <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-400" />
            RFQ successfully issued to {selectedSupplier}. Quote accepted at £1,420/Tonne with 16-week delivery guarantee.
          </div>
        )}
      </div>
    </div>
  );
};
