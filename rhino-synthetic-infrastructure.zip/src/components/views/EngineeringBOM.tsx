import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { COMMODITY_MARKET_PRICES } from '../../engine/engineeringEngine';
import { Cpu, DollarSign, Layers, TrendingUp, AlertCircle, ShoppingCart } from 'lucide-react';

interface EngineeringBOMProps {
  currentProject: SyntheticInfrastructureAsset;
  onUpdateProject: (p: SyntheticInfrastructureAsset) => void;
}

export const EngineeringBOM: React.FC<EngineeringBOMProps> = ({ currentProject, onUpdateProject }) => {
  const [commodityPrices, setCommodityPrices] = useState(COMMODITY_MARKET_PRICES);

  const totalBomCost = currentProject.bom.reduce((acc, cat) => acc + cat.totalCost, 0);

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-mono font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <Cpu className="w-5 h-5 text-sky-400 mr-2" />
            ENGINEERING & BILL OF MATERIALS (BOM) ENGINE
          </h1>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Physical Asset Decomposition • Commodity Market Sensitivity • Carbon Intensity Accounting
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-xs font-mono">
          <span className="text-slate-400">Total Asset BOM CAPEX: </span>
          <span className="text-emerald-400 font-bold ml-1">£{(totalBomCost / 1e9).toFixed(2)}bn</span>
        </div>
      </div>

      {/* Synthetic Commodity Markets Ticker */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
        <div className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center justify-between">
          <span>Live Synthetic Commodities Market Benchmarks</span>
          <span className="text-[10px] text-slate-500">Auto-Propagating into CAPEX Model</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {commodityPrices.map(c => (
            <div key={c.id} className="bg-slate-950 p-2.5 rounded border border-slate-800 font-mono">
              <div className="text-[10px] text-slate-400 font-bold truncate">{c.name}</div>
              <div className="flex justify-between items-baseline mt-1">
                <span className="text-sm font-bold text-slate-100">£{c.currentPrice}</span>
                <span className={`text-[10px] font-bold ${c.change24hPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {c.change24hPct >= 0 ? '+' : ''}{c.change24hPct}%
                </span>
              </div>
              <div className="text-[9px] text-slate-500 mt-0.5">/{c.unit} • Carbon: {c.carbonKg}kg</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bill of Materials Categories Breakdown */}
      <div className="space-y-4">
        {currentProject.bom.map((cat, idx) => (
          <div key={idx} className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-lg font-mono">
            <div className="bg-slate-950 p-3.5 border-b border-slate-800 flex justify-between items-center">
              <span className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center">
                <Layers className="w-4 h-4 mr-2" /> {cat.category}
              </span>
              <span className="text-xs font-bold text-emerald-400">Category CAPEX: £{(cat.totalCost / 1e6).toFixed(1)}m</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
                  <tr>
                    <th className="py-2.5 px-4">Material / Component Item</th>
                    <th className="py-2.5 px-4">Quantity</th>
                    <th className="py-2.5 px-4">Unit Price</th>
                    <th className="py-2.5 px-4">Supplier Region</th>
                    <th className="py-2.5 px-4">Lead Time</th>
                    <th className="py-2.5 px-4">Carbon Intensity</th>
                    <th className="py-2.5 px-4 text-right">Total Material Cost</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {cat.items.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-semibold text-slate-200">{item.name}</td>
                      <td className="py-3 px-4">{item.quantity.toLocaleString()} {item.unit}</td>
                      <td className="py-3 px-4 font-mono text-amber-400">£{item.unitPrice.toLocaleString()}</td>
                      <td className="py-3 px-4 text-slate-400">{item.supplierRegion}</td>
                      <td className="py-3 px-4 text-sky-400 font-bold">{item.leadTimeWeeks} weeks</td>
                      <td className="py-3 px-4 text-slate-400">{item.carbonIntensityKgPerUnit} kg/unit</td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-400">
                        £{(item.totalCost / 1e6).toFixed(2)}m
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
