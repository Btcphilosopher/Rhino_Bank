import React, { useState } from 'react';
import { SyntheticInfrastructureAsset, DigitalTwinLayer } from '../../types/infrastructure';
import { DigitalTwin3D } from '../digitalTwin/DigitalTwin3D';
import { generateProjectFromNaturalLanguage } from '../../services/aiService';
import { Sparkles, Layers, DollarSign, Cpu, FolderTree, RefreshCw, AlertTriangle, ArrowRight } from 'lucide-react';

interface CreationStudioProps {
  currentProject: SyntheticInfrastructureAsset;
  onUpdateProject: (p: SyntheticInfrastructureAsset) => void;
}

export const CreationStudio: React.FC<CreationStudioProps> = ({ currentProject, onUpdateProject }) => {
  const [naturalLanguagePrompt, setNaturalLanguagePrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeLayers, setActiveLayers] = useState<DigitalTwinLayer[]>([
    'CIVIL', 'STRUCTURAL', 'MECHANICAL', 'ENERGY', 'LOGISTICS', 'FINANCIAL'
  ]);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

  const handleToggleLayer = (layer: DigitalTwinLayer) => {
    if (activeLayers.includes(layer)) {
      setActiveLayers(activeLayers.filter(l => l !== layer));
    } else {
      setActiveLayers([...activeLayers, layer]);
    }
  };

  const handleGenerateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!naturalLanguagePrompt.trim()) return;

    setIsGenerating(true);
    try {
      const generated = await generateProjectFromNaturalLanguage(naturalLanguagePrompt);
      onUpdateProject(generated);
    } catch (err) {
      console.error('Error generating synthetic asset:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Top Creation Bar (Gemini AI Prompt) */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-xl">
        <form onSubmit={handleGenerateProject} className="flex flex-col md:flex-row items-center gap-3">
          <div className="flex items-center space-x-2 text-xs font-mono text-amber-400 font-bold whitespace-nowrap">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>AI SYNTHESIS ENGINE:</span>
          </div>

          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={naturalLanguagePrompt}
              onChange={(e) => setNaturalLanguagePrompt(e.target.value)}
              placeholder="e.g., Build a 120 km hydrogen railway connecting Manchester, Sheffield and Leeds..."
              className="w-full bg-slate-950 border border-slate-700 text-slate-100 px-4 py-2.5 rounded-lg text-xs font-mono focus:outline-none focus:border-amber-500 placeholder-slate-500 shadow-inner"
            />
          </div>

          <button
            type="submit"
            disabled={isGenerating || !naturalLanguagePrompt.trim()}
            className="w-full md:w-auto px-5 py-2.5 rounded-lg bg-amber-600 hover:bg-amber-500 disabled:bg-slate-800 text-white font-mono text-xs font-bold transition shadow-lg flex items-center justify-center space-x-2 whitespace-nowrap"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin mr-1.5" />
                Synthesizing Project...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-1.5" />
                Generate Infrastructure Asset
              </>
            )}
          </button>
        </form>
        <div className="mt-2 text-[10px] font-mono text-slate-500 flex justify-between">
          <span>AI Gemini 3.6 Synthetic Parameter Engine Active</span>
          <span className="text-amber-500/80">Synthetic Model Outputs — Explicitly Simulated Demonstration</span>
        </div>
      </div>

      {/* THREE-COLUMN CREATION STUDIO MAIN CONTAINER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[calc(100vh-220px)] min-h-[640px]">
        {/* LEFT COLUMN: PROJECT TREE STRUCTURE (3 Cols) */}
        <div className="lg:col-span-3 bg-slate-900 rounded-xl border border-slate-800 p-4 overflow-y-auto flex flex-col font-mono">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 pb-2 border-b border-slate-800 flex items-center">
            <FolderTree className="w-4 h-4 text-sky-400 mr-2" />
            Project Structure Tree
          </div>

          <div className="space-y-2 text-xs text-slate-300 flex-1">
            <div className="font-bold text-sky-400 flex items-center space-x-1.5">
              <span>PROJECT: {currentProject.name}</span>
            </div>

            <div className="pl-3 space-y-1.5 border-l border-slate-800 ml-1.5">
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── 📍 LAND & GEOTECH (£{(currentProject.land_cost / 1e6).toFixed(0)}m)
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── 🏗️ CIVIL & EARTHWORKS
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── 🏙️ STRUCTURES & BUILDINGS
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── ⚙️ SYSTEMS & SIGNALLING
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── ⚡ ENERGY & HYDROGEN (£{(currentProject.specs.powerDemandMW || 0)} MW)
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── 📡 DIGITAL & OPTICAL FIBRE
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition">
                ├── 🚚 OPERATIONS & FLEET ({currentProject.machines.length} Machines)
              </div>
              <div className="hover:text-emerald-400 cursor-pointer p-1 rounded hover:bg-slate-800 transition font-bold text-emerald-400">
                └── 💰 FINANCE STRUCTURE (£{(currentProject.financing_structure.totalProjectCost / 1e9).toFixed(2)}bn)
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono space-y-1">
            <div>Model Version: {currentProject.provenance.modelVersion}</div>
            <div>Calculation ID: {currentProject.provenance.calculationId}</div>
            <div className="text-emerald-400">Audit Status: REPRODUCIBLE</div>
          </div>
        </div>

        {/* CENTRE COLUMN: 3D DIGITAL TWIN (6 Cols) */}
        <div className="lg:col-span-6 flex flex-col">
          <DigitalTwin3D
            asset={currentProject}
            activeLayers={activeLayers}
            onToggleLayer={handleToggleLayer}
            selectedNodeId={selectedNodeId}
            onSelectNode={setSelectedNodeId}
          />
        </div>

        {/* RIGHT COLUMN: LIVE ENGINEERING & FINANCIAL PANEL (3 Cols) */}
        <div className="lg:col-span-3 bg-slate-900 rounded-xl border border-slate-800 p-4 overflow-y-auto flex flex-col font-mono text-xs space-y-4">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider pb-2 border-b border-slate-800 flex items-center">
            <DollarSign className="w-4 h-4 text-emerald-400 mr-1.5" />
            Engineering & Financial Model
          </div>

          {/* CAPEX / OPEX Cards */}
          <div className="space-y-2">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">CAPEX Base (Engineering & BOM)</div>
              <div className="text-lg font-bold text-emerald-400">
                £{(currentProject.construction_cost / 1e9).toFixed(2)}bn
              </div>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Total Project Cost (Inc Fin & Cont)</div>
              <div className="text-lg font-bold text-sky-400">
                £{(currentProject.financing_structure.totalProjectCost / 1e9).toFixed(2)}bn
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <div className="text-[9px] text-slate-500 uppercase">Project IRR</div>
                <div className="text-sm font-bold text-amber-400">
                  {(currentProject.financing_structure.projectIrr * 100).toFixed(2)}%
                </div>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <div className="text-[9px] text-slate-500 uppercase">Equity IRR</div>
                <div className="text-sm font-bold text-emerald-400">
                  {(currentProject.financing_structure.equityIrr * 100).toFixed(2)}%
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <div className="text-[9px] text-slate-500 uppercase">DSCR</div>
                <div className="text-sm font-bold text-sky-300">
                  {currentProject.financing_structure.dscr}x
                </div>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <div className="text-[9px] text-slate-500 uppercase">NPV @ 7%</div>
                <div className="text-sm font-bold text-purple-400">
                  £{(currentProject.financing_structure.npv7Percent / 1e9).toFixed(2)}bn
                </div>
              </div>
            </div>
          </div>

          {/* Debt vs Equity Breakdown */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Financing Structure</div>
            <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden flex">
              <div
                className="bg-sky-500 h-full"
                style={{ width: `${100 - currentProject.financing_structure.equityPercent}%` }}
                title="Debt"
              ></div>
              <div
                className="bg-amber-500 h-full"
                style={{ width: `${currentProject.financing_structure.equityPercent}%` }}
                title="Equity"
              ></div>
            </div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span className="text-sky-400 font-bold">
                Debt: £{(currentProject.financing_structure.totalDebtAmount / 1e9).toFixed(2)}bn ({(100 - currentProject.financing_structure.equityPercent).toFixed(1)}%)
              </span>
              <span className="text-amber-400 font-bold">
                Equity: £{(currentProject.financing_structure.equityAmount / 1e9).toFixed(2)}bn ({currentProject.financing_structure.equityPercent.toFixed(1)}%)
              </span>
            </div>
          </div>

          {/* Revenue Streams Preview */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Annual Revenue Streams</div>
            {currentProject.revenue_streams.map(r => (
              <div key={r.id} className="flex justify-between items-center text-[10px] border-b border-slate-900 pb-1">
                <span className="text-slate-300 truncate max-w-[140px]">{r.name}</span>
                <span className="text-emerald-400 font-bold">£{(r.annualRevenue / 1e6).toFixed(1)}m/yr</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
