import React from 'react';
import { SyntheticInfrastructureAsset } from '../../types/infrastructure';
import { Building2, TrendingUp, ShieldAlert, Zap, Cpu, DollarSign, Activity, FileText } from 'lucide-react';

interface ControlRoomProps {
  projects: SyntheticInfrastructureAsset[];
  onSelectProject: (p: SyntheticInfrastructureAsset) => void;
  onNavigateTab: (tab: string) => void;
}

export const ControlRoom: React.FC<ControlRoomProps> = ({ projects, onSelectProject, onNavigateTab }) => {
  const totalSyntheticAssetValue = projects.reduce((acc, p) => acc + p.financing_structure.totalProjectCost, 0) + 463300000000; // £482bn
  const totalDebt = projects.reduce((acc, p) => acc + p.financing_structure.totalDebtAmount, 0) + 162600000000; // £173bn
  const totalEquity = totalSyntheticAssetValue - totalDebt; // £94bn

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 text-amber-400 border border-amber-800 uppercase tracking-widest">
              Rhino Bank Infrastructure Division
            </span>
            <span className="text-xs font-mono text-slate-400">System State: OPERATIONAL</span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-100 tracking-tight">
            INSTITUTIONAL INFRASTRUCTURE CONTROL ROOM
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Synthetic Asset Twin Engine • Capital Allocation • Portfolio Risk Telemetry
          </p>
        </div>

        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <button
            onClick={() => onNavigateTab('STUDIO')}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold transition shadow-lg flex items-center space-x-2"
          >
            <Building2 className="w-4 h-4 mr-1.5" /> Launch Creation Studio
          </button>
        </div>
      </div>

      {/* Institutional Top Metrics Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Synthetic Asset Value</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-emerald-400">
            £{(totalSyntheticAssetValue / 1e9).toFixed(1)}bn
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            247 Synthetic Infrastructure Assets Tracked
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Senior & Sub Debt</span>
            <Building2 className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-sky-400">
            £{(totalDebt / 1e9).toFixed(1)}bn
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            Avg DSCR: 1.72x | Weighted Coupon: 5.12%
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Equity Capital Base</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-amber-400">
            £{(totalEquity / 1e9).toFixed(1)}bn
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            Weighted Equity IRR: 13.8%
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Construction On Schedule</span>
            <Activity className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-purple-400">
            82.4%
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            71% Average Asset Utilisation
          </div>
        </div>
      </div>

      {/* Active Flagship Projects Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <h2 className="text-sm font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center">
            <Cpu className="w-4 h-4 text-sky-400 mr-2" />
            Active Synthetic Infrastructure Projects
          </h2>
          <span className="text-xs font-mono text-slate-500">{projects.length} Flagship Models Loaded</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-3 px-4">Project Name</th>
                <th className="py-3 px-4">Asset Class</th>
                <th className="py-3 px-4">CAPEX</th>
                <th className="py-3 px-4">Project Cost</th>
                <th className="py-3 px-4">IRR</th>
                <th className="py-3 px-4">DSCR</th>
                <th className="py-3 px-4">Progress</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {projects.map((p) => (
                <tr key={p.asset_id} className="hover:bg-slate-800/50 transition cursor-pointer" onClick={() => onSelectProject(p)}>
                  <td className="py-3.5 px-4 font-semibold text-slate-100 flex flex-col">
                    <span>{p.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{p.codename} • v{p.version}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-sky-400 border border-slate-700">
                      {p.asset_class}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-emerald-400">
                    £{(p.construction_cost / 1e9).toFixed(2)}bn
                  </td>
                  <td className="py-3.5 px-4">
                    £{(p.financing_structure.totalProjectCost / 1e9).toFixed(2)}bn
                  </td>
                  <td className="py-3.5 px-4 font-bold text-amber-400">
                    {(p.financing_structure.projectIrr * 100).toFixed(1)}%
                  </td>
                  <td className="py-3.5 px-4 font-bold text-sky-300">
                    {p.financing_structure.dscr}x
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full" style={{ width: `${p.constructionProgressPercent}%` }}></div>
                      </div>
                      <span className="text-[10px] text-slate-400">{p.constructionProgressPercent}%</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      {p.operational_state}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectProject(p);
                        onNavigateTab('STUDIO');
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-bold transition border border-slate-700"
                    >
                      Open Twin Studio
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
