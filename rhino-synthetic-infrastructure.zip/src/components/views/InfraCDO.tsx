import React, { useState } from 'react';
import { SEED_CDO_POOL } from '../../data/flagshipProject';
import { ShieldAlert, DollarSign, Layers, Play, AlertCircle } from 'lucide-react';

export const InfraCDO: React.FC = () => {
  const [cdoPool, setCdoPool] = useState(SEED_CDO_POOL);
  const [simulatedDefaultLossPct, setSimulatedDefaultLossPct] = useState<number>(1.8);

  const handleRunCDOLossWaterfall = (lossPct: number) => {
    setSimulatedDefaultLossPct(lossPct);
    const updated = JSON.parse(JSON.stringify(cdoPool));

    let remainingLossPct = lossPct;

    // Loss waterfall propagates from Equity (first loss) -> Junior -> Mezzanine -> Senior -> Super Senior
    updated.tranches.reverse().forEach((tranche: any) => {
      const trancheThickness = tranche.detachmentPointPercent - tranche.attachmentPointPercent;
      if (remainingLossPct > 0) {
        const lossInTranche = Math.min(remainingLossPct, trancheThickness);
        tranche.simulatedLossPercent = parseFloat(((lossInTranche / trancheThickness) * 100).toFixed(1));
        remainingLossPct -= lossInTranche;
      } else {
        tranche.simulatedLossPercent = 0.0;
      }
    });

    updated.tranches.reverse();
    setCdoPool(updated);
  };

  return (
    <div className="space-y-6 font-sans font-mono">
      {/* Top Banner */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-slate-100 uppercase tracking-tight flex items-center">
            <Layers className="w-5 h-5 text-purple-400 mr-2" />
            SYNTHETIC INFRASTRUCTURE CREDIT & CDO SECURITISATION
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Multi-Project Credit Pool Tranching • Loss Waterfall Simulator • Subordination Protection
          </p>
        </div>

        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-xs">
          <span className="text-slate-400">Total CDO Pool Notional: </span>
          <span className="text-purple-400 font-bold ml-1">£{(cdoPool.totalNotional / 1e9).toFixed(1)}bn</span>
        </div>
      </div>

      {/* Asset Class Allocation Bar */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg space-y-3">
        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Pool Collateral Asset Class Allocation
        </div>

        <div className="w-full bg-slate-950 h-4 rounded-full overflow-hidden flex border border-slate-800">
          <div className="bg-emerald-500 h-full" style={{ width: '25%' }} title="Energy 25%"></div>
          <div className="bg-sky-500 h-full" style={{ width: '20%' }} title="Rail 20%"></div>
          <div className="bg-amber-500 h-full" style={{ width: '15%' }} title="Water 15%"></div>
          <div className="bg-purple-500 h-full" style={{ width: '15%' }} title="Digital 15%"></div>
          <div className="bg-blue-500 h-full" style={{ width: '15%' }} title="Urban 15%"></div>
          <div className="bg-slate-500 h-full" style={{ width: '10%' }} title="Industrial 10%"></div>
        </div>

        <div className="flex flex-wrap gap-4 text-[11px] text-slate-400">
          <span className="text-emerald-400 font-bold">● Energy: 25%</span>
          <span className="text-sky-400 font-bold">● Rail: 20%</span>
          <span className="text-amber-400 font-bold">● Water: 15%</span>
          <span className="text-purple-400 font-bold">● Digital: 15%</span>
          <span className="text-blue-400 font-bold">● Urban: 15%</span>
          <span className="text-slate-400 font-bold">● Industrial: 10%</span>
        </div>
      </div>

      {/* Loss Waterfall Simulator Bar */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-lg space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-xs font-bold text-slate-200 uppercase flex items-center">
            <ShieldAlert className="w-4 h-4 text-amber-400 mr-2" />
            Simulated Portfolio Loss Shock: {simulatedDefaultLossPct.toFixed(1)}% of Pool
          </span>
          <span className="text-[10px] text-slate-500">First-Loss Equity Absorbs Initial Loss</span>
        </div>

        <div className="flex items-center space-x-4">
          <input
            type="range"
            min="0"
            max="15"
            step="0.2"
            value={simulatedDefaultLossPct}
            onChange={(e) => handleRunCDOLossWaterfall(parseFloat(e.target.value))}
            className="w-full accent-purple-500 bg-slate-950"
          />
        </div>
      </div>

      {/* CDO Tranches Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            CDO Capital Tranche Structure & Credit Ratings
          </span>
          <span className="text-xs text-slate-500">{cdoPool.tranches.length} Tranches Modelled</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-3 px-4">Tranche Name</th>
                <th className="py-3 px-4">Credit Tier</th>
                <th className="py-3 px-4">Attach / Detach</th>
                <th className="py-3 px-4">Subordination</th>
                <th className="py-3 px-4">Coupon</th>
                <th className="py-3 px-4">Rating</th>
                <th className="py-3 px-4 text-right">Simulated Loss Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {cdoPool.tranches.map((t, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-semibold text-slate-100">{t.name}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-purple-400 border border-slate-700">
                      {t.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {t.attachmentPointPercent}% - {t.detachmentPointPercent}%
                  </td>
                  <td className="py-3 px-4 font-bold text-sky-400">{t.subordinationPercent}%</td>
                  <td className="py-3 px-4 text-amber-400 font-bold">{(t.coupon * 100).toFixed(2)}%</td>
                  <td className="py-3 px-4 font-bold text-emerald-400">{t.rating}</td>
                  <td className="py-3 px-4 text-right">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      t.simulatedLossPercent > 0 ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}>
                      {t.simulatedLossPercent.toFixed(1)}% Impaired
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
