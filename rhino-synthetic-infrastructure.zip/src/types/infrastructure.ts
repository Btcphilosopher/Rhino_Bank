export type AssetClass = 
  | 'TRANSPORT'
  | 'ENERGY'
  | 'WATER'
  | 'DIGITAL'
  | 'URBAN'
  | 'INDUSTRIAL';

export type TransportSubType = 'railway' | 'metro' | 'high_speed_rail' | 'hydrogen_rail' | 'maglev' | 'station' | 'tunnel' | 'bridge' | 'road' | 'port' | 'airport' | 'logistics_terminal';
export type EnergySubType = 'power_station' | 'hydrogen_plant' | 'electrolyser_network' | 'battery_storage' | 'substation' | 'transmission' | 'offshore_wind' | 'solar' | 'nuclear' | 'district_heating';
export type WaterSubType = 'reservoir' | 'treatment_plant' | 'pumping_station' | 'desalination' | 'pipeline' | 'flood_defense';
export type DigitalSubType = 'fibre_network' | 'data_centre' | 'edge_computing' | 'telecom_tower' | 'satellite_ground';
export type UrbanSubType = 'housing' | 'hospital' | 'university' | 'civic' | 'mixed_use';
export type IndustrialSubType = 'factory' | 'steel_plant' | 'semiconductor_fab' | 'chemical_plant' | 'manufacturing_campus';

export type SubType = TransportSubType | EnergySubType | WaterSubType | DigitalSubType | UrbanSubType | IndustrialSubType;

export interface MaterialCostItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  unitPrice: number; // in GBP
  volatility: number; // e.g. 0.15 = 15%
  supplierRegion: string;
  leadTimeWeeks: number;
  carbonIntensityKgPerUnit: number;
  totalCost: number;
}

export interface BOMCategory {
  category: string;
  items: MaterialCostItem[];
  totalCost: number;
}

export interface EngineeringSpecs {
  lengthKm?: number;
  capacityUnits?: string;
  capacityValue?: number;
  designLifeYears: number;
  keyComponentsCount: number;
  powerDemandMW?: number;
  efficiencyPercent?: number;
  gradientMaxPercent?: number;
  headwayMinutes?: number;
  throughputPerYear?: number;
  bandwidthGbps?: number;
  storageMWh?: number;
}

export interface ConstructionTask {
  id: string;
  name: string;
  phase: 'LAND' | 'SITE_PREP' | 'FOUNDATIONS' | 'CIVIL' | 'STRUCTURES' | 'SYSTEMS' | 'EQUIPMENT' | 'TESTING' | 'COMMISSIONING';
  startMonth: number;
  durationMonths: number;
  completionPercent: number;
  dependencies: string[]; // task ids
  isCriticalPath: boolean;
  assignedMachines: string[];
  assignedContractor: string;
  estimatedCost: number;
  actualCost: number;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'DELAYED';
  delayDays: number;
}

export interface MachineUtilization {
  id: string;
  name: string;
  type: 'crane' | 'excavator' | 'tunnel_boring_machine' | 'concrete_pump' | 'train' | 'truck' | 'robotic_welder';
  count: number;
  utilizationRate: number; // 0..100
  hourlyCost: number;
  operationalStatus: 'ACTIVE' | 'MAINTENANCE' | 'IDLE' | 'FAILED';
}

export interface DebtTranche {
  id: string;
  name: string;
  type: 'SENIOR_DEBT' | 'MEZZANINE' | 'SUBORDINATED_DEBT';
  amount: number; // GBP
  interestRate: number; // e.g. 0.055 = 5.5%
  tenureYears: number;
  gracePeriodYears: number;
  amortizationType: 'AMORTIZING' | 'BULLET' | 'PERCENTAGE_SWEEP';
  annualServiceCost: number;
}

export interface FinancingStructure {
  totalCapex: number;
  financingCostDuringConstruction: number;
  contingencyAllowance: number;
  totalProjectCost: number;
  equityAmount: number;
  equityPercent: number;
  debtTranches: DebtTranche[];
  totalDebtAmount: number;
  gearingRatio: number; // Debt / Total
  // Key Ratios
  dscr: number; // Debt Service Coverage Ratio
  llcr: number; // Loan Life Coverage Ratio
  plcr: number; // Project Life Coverage Ratio
  projectIrr: number; // e.g. 0.088 = 8.8%
  equityIrr: number;
  npv7Percent: number; // NPV at 7% discount
  paybackPeriodYears: number;
  refinancingRisk: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface RevenueStream {
  id: string;
  name: string;
  unitType: string;
  annualVolume: number;
  unitTariff: number; // GBP
  annualRevenue: number;
  escalationPercent: number;
  elasticityToDemand: number;
}

export interface OpexItem {
  id: string;
  category: 'MAINTENANCE' | 'STAFF' | 'ENERGY' | 'INSURANCE' | 'MANAGEMENT' | 'COMMODITIES';
  annualCost: number;
  fixedRatio: number; // 0..1
}

export interface PhysicalComponentState {
  componentId: string;
  name: string;
  type: string;
  ageYears: number;
  structuralConditionScore: number; // 0..100
  lastInspectionDaysAgo: number;
  remainingDesignLifeYears: number;
  maintenanceStatus: 'OPTIMAL' | 'DUE' | 'CRITICAL' | 'FAILED';
  nextMaintenanceDays: number;
  predictedFailureRisk: number; // ML prediction 0..1
  mlConfidence: number; // 0..1
}

export interface RiskMetrics {
  constructionRiskScore: number; // 1..10
  demandRiskScore: number;
  marketRiskScore: number;
  interestRateRiskScore: number;
  creditRiskScore: number;
  counterpartyRiskScore: number;
  climateRiskScore: number;
  overallRiskScore: number;
  var95Annual: number; // Value at Risk 95%
  expectedShortfall95: number;
  dscrAtRisk10Pct: number;
  cashflowAtRisk: number;
}

export type DigitalTwinLayer = 'CIVIL' | 'STRUCTURAL' | 'MECHANICAL' | 'ELECTRICAL' | 'DIGITAL' | 'ENERGY' | 'LOGISTICS' | 'FINANCIAL';

export interface SyntheticInfrastructureAsset {
  asset_id: string;
  project_id: string;
  name: string;
  codename: string;
  version: number;
  asset_class: AssetClass;
  subType: SubType;
  location: string;
  coordinates: { lat: number; lng: number };
  description: string;
  
  // Physical & Engineering
  capacity: string;
  specs: EngineeringSpecs;
  bom: BOMCategory[];
  
  // Financials & Economics
  construction_cost: number; // CAPEX base
  land_cost: number;
  engineering_cost: number;
  operating_cost_annual: number; // OPEX
  financing_structure: FinancingStructure;
  revenue_streams: RevenueStream[];
  opex_breakdown: OpexItem[];
  
  // Schedule & Operations
  construction_schedule: ConstructionTask[];
  machines: MachineUtilization[];
  operational_state: 'DESIGN' | 'ENGINEERING' | 'CONSTRUCTION' | 'COMMISSIONING' | 'OPERATIONAL' | 'REFINANCED' | 'RETIRED';
  constructionProgressPercent: number;
  
  // Asset Management Twin
  physical_components: PhysicalComponentState[];
  
  // Risk & Audit
  risk_metrics: RiskMetrics;
  provenance: {
    source: 'SYNTHETIC_MODEL' | 'GEMINI_AI_GEN' | 'STRESS_ENGINE';
    modelVersion: string;
    timestamp: string;
    calculationId: string;
    assumptions: string[];
  };
}

export interface SecuritisedBond {
  bondId: string;
  projectId: string;
  projectName: string;
  trancheName: string;
  tier: 'SUPER_SENIOR' | 'SENIOR' | 'MEZZANINE' | 'JUNIOR' | 'EQUITY_TRANCHE';
  notionalAmount: number;
  couponRate: number;
  maturityYears: number;
  rating: 'AAA' | 'AA+' | 'A' | 'BBB+' | 'BBB' | 'BB' | 'B';
  pricePercent: number; // e.g. 99.8%
  currentYield: number;
  bidPrice: number;
  askPrice: number;
  spreadBps: number;
}

export interface CDOPool {
  poolId: string;
  poolName: string;
  totalNotional: number;
  assetAllocation: { [key in AssetClass]: number }; // percentage
  tranches: {
    name: string;
    type: 'SUPER_SENIOR' | 'SENIOR' | 'MEZZANINE' | 'JUNIOR' | 'EQUITY';
    attachmentPointPercent: number; // e.g. 0 to 10
    detachmentPointPercent: number; // e.g. 10 to 25
    coupon: number;
    rating: string;
    subordinationPercent: number;
    simulatedLossPercent: number;
  }[];
}

export interface PortfolioPosition {
  id: string;
  projectId: string;
  projectName: string;
  assetClass: AssetClass;
  holdingType: 'PROJECT_EQUITY' | 'SENIOR_DEBT' | 'INFRA_BOND' | 'MEZZANINE' | 'CDO_TRANCHE';
  notional: number;
  acquisitionCost: number;
  currentValuation: number;
  unrealizedGains: number;
  yieldPercent: number;
}

export interface ScenarioResult {
  scenarioName: string;
  description: string;
  capexChangePercent: number;
  demandChangePercent: number;
  interestRateChangeBps: number;
  delayMonths: number;
  newNpv: number;
  newIrr: number;
  newDscr: number;
  newCompletionDate: string;
  financingDeficit: number;
}

export interface AuditEvent {
  id: string;
  user: string;
  timestamp: string;
  action: string;
  targetObject: string;
  previousState: string;
  newState: string;
  modelVersion: string;
  calculationId: string;
}
