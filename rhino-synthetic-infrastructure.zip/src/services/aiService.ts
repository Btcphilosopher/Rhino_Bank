import { GoogleGenAI } from '@google/genai';
import { SyntheticInfrastructureAsset } from '../types/infrastructure';
import { generateBOMForSubType } from '../engine/engineeringEngine';
import { calculateFinancingStructure } from '../engine/financeEngine';

// Initialize Gemini Client
const getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY || '';
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export async function generateProjectFromNaturalLanguage(userPrompt: string): Promise<SyntheticInfrastructureAsset> {
  const ai = getAiClient();

  if (ai) {
    try {
      const systemInstruction = `You are the Rhino Synthetic Infrastructure Creation Engine.
Given a user prompt describing an infrastructure project, extract and generate structured JSON metadata following this exact shape:
{
  "name": "Project Name",
  "codename": "RHINOSYNTH-...",
  "asset_class": "TRANSPORT" | "ENERGY" | "WATER" | "DIGITAL" | "URBAN" | "INDUSTRIAL",
  "subType": "hydrogen_rail" | "offshore_wind" | "pipeline" | "fibre_network" | "port" | "housing" | "power_station" | etc.,
  "location": "Location string",
  "capacity": "Formatted capacity string e.g. 120 km | 18,400 PAX/H",
  "description": "Executive overview of project",
  "lengthKm": number,
  "capacityVal": number,
  "estimatedCapex": number (in GBP),
  "constructionYears": number,
  "operatingLifeYears": number
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Create a structured synthetic infrastructure proposal for: "${userPrompt}"`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json'
        }
      });

      const text = response.text;
      if (text) {
        const parsed = JSON.parse(text);
        return assembleAssetFromParsed(parsed);
      }
    } catch (err) {
      console.warn('Gemini API call failed, falling back to rule-based engine:', err);
    }
  }

  // Fallback Rule-Based Creation Engine if API key is not present or error occurs
  return generateFallbackProject(userPrompt);
}

function assembleAssetFromParsed(parsed: any): SyntheticInfrastructureAsset {
  const capex = parsed.estimatedCapex || 12500000000;
  const landCost = Math.round(capex * 0.05);
  const engineeringCost = Math.round(capex * 0.08);
  const lengthKm = parsed.lengthKm || 100;
  const capacityVal = parsed.capacityVal || 10000;

  const revenueStreams = [
    { id: 'REV-GEN-01', name: 'Primary Operational Services Tariff', unitType: 'Units', annualVolume: capacityVal * 120, unitTariff: 42, annualRevenue: Math.round(capacityVal * 120 * 42), escalationPercent: 0.025, elasticityToDemand: 0.80 }
  ];

  const opexBreakdown = [
    { id: 'OPEX-GEN-01', category: 'MAINTENANCE' as const, annualCost: Math.round(capex * 0.02), fixedRatio: 0.60 },
    { id: 'OPEX-GEN-02', category: 'STAFF' as const, annualCost: Math.round(capex * 0.01), fixedRatio: 0.85 }
  ];

  const financing = calculateFinancingStructure(capex, landCost, engineeringCost, revenueStreams, opexBreakdown, 0, 0);

  return {
    asset_id: `ASSET-RHINO-GEN-${Math.floor(Math.random() * 8999 + 1000)}`,
    project_id: `PROJ-GEN-${Math.floor(Math.random() * 8999 + 1000)}`,
    name: parsed.name || 'RHINO SYNTHETIC PROJECT',
    codename: parsed.codename || 'RHINOSYNTH-CUSTOM-INFRA',
    version: 1.0,
    asset_class: parsed.asset_class || 'TRANSPORT',
    subType: parsed.subType || 'railway',
    location: parsed.location || 'United Kingdom Network',
    coordinates: { lat: 53.48, lng: -2.24 },
    description: parsed.description || 'Custom generated synthetic infrastructure asset created by Rhino Engine.',
    capacity: parsed.capacity || `${lengthKm} km | ${capacityVal} Units/Day`,
    specs: {
      lengthKm,
      capacityUnits: 'Units/Day',
      capacityValue: capacityVal,
      designLifeYears: parsed.operatingLifeYears || 60,
      keyComponentsCount: 350,
      powerDemandMW: 120,
      efficiencyPercent: 91.0,
    },
    construction_cost: capex,
    land_cost: landCost,
    engineering_cost: engineeringCost,
    operating_cost_annual: Math.round(capex * 0.03),
    financing_structure: financing,
    revenue_streams: revenueStreams,
    opex_breakdown: opexBreakdown,
    bom: generateBOMForSubType(parsed.subType || 'railway', capacityVal, lengthKm),
    construction_schedule: [
      { id: 'GEN-TSK-01', name: 'Site Access & Environmental Works', phase: 'LAND', startMonth: 1, durationMonths: 12, completionPercent: 100, dependencies: [], isCriticalPath: true, assignedMachines: ['MCH-EXCAVATOR-01'], assignedContractor: 'Rhino Primary Infra', estimatedCost: landCost, actualCost: landCost, status: 'COMPLETED', delayDays: 0 },
      { id: 'GEN-TSK-02', name: 'Main Civil & Structural Construction', phase: 'CIVIL', startMonth: 10, durationMonths: 36, completionPercent: 45, dependencies: ['GEN-TSK-01'], isCriticalPath: true, assignedMachines: ['MCH-TBM-PENNINE-HERCULES'], assignedContractor: 'Rhino Civil JV', estimatedCost: Math.round(capex * 0.60), actualCost: Math.round(capex * 0.60), status: 'IN_PROGRESS', delayDays: 0 },
      { id: 'GEN-TSK-03', name: 'System Integration & Testing', phase: 'TESTING', startMonth: 42, durationMonths: 12, completionPercent: 0, dependencies: ['GEN-TSK-02'], isCriticalPath: true, assignedMachines: [], assignedContractor: 'Rhino Systems Ltd', estimatedCost: Math.round(capex * 0.15), actualCost: 0, status: 'NOT_STARTED', delayDays: 0 }
    ],
    machines: [
      { id: 'MCH-EXCAVATOR-01', name: 'Heavy Duty Construction Machine Unit', type: 'excavator', count: 14, utilizationRate: 88, hourlyCost: 220, operationalStatus: 'ACTIVE' }
    ],
    operational_state: 'ENGINEERING',
    constructionProgressPercent: 32.5,
    physical_components: [
      { componentId: 'GEN-CMP-01', name: 'Primary Infrastructure Node Alpha', type: 'Core Structure', ageYears: 1, structuralConditionScore: 100, lastInspectionDaysAgo: 5, remainingDesignLifeYears: 59, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 180, predictedFailureRisk: 0.001, mlConfidence: 0.99 }
    ],
    risk_metrics: {
      constructionRiskScore: 3.2,
      demandRiskScore: 2.8,
      marketRiskScore: 3.0,
      interestRateRiskScore: 3.5,
      creditRiskScore: 2.1,
      counterpartyRiskScore: 2.0,
      climateRiskScore: 2.5,
      overallRiskScore: 2.9,
      var95Annual: Math.round(capex * 0.03),
      expectedShortfall95: Math.round(capex * 0.045),
      dscrAtRisk10Pct: 1.45,
      cashflowAtRisk: Math.round(capex * 0.01)
    },
    provenance: {
      source: 'GEMINI_AI_GEN',
      modelVersion: 'RHINOSYNTH-ENGINE-v3.6.4 + GEMINI-2.5-FLASH',
      timestamp: new Date().toISOString(),
      calculationId: `CALC-AI-${Math.floor(Math.random() * 899999 + 100000)}`,
      assumptions: ['Structured synthetic project generated directly from user natural language prompt.']
    }
  };
}

function generateFallbackProject(prompt: string): SyntheticInfrastructureAsset {
  const isRail = prompt.toLowerCase().includes('rail') || prompt.toLowerCase().includes('train');
  const isWind = prompt.toLowerCase().includes('wind') || prompt.toLowerCase().includes('energy');

  return assembleAssetFromParsed({
    name: isRail ? 'RHINO HYDROGEN PENNINE EXPRESS' : isWind ? 'SCOTTISH FLOATING OFFSHORE WIND' : 'RHINO SYNTHETIC INFRA PROJECT',
    codename: 'RHINOSYNTH-NL-PROJECT',
    asset_class: isRail ? 'TRANSPORT' : 'ENERGY',
    subType: isRail ? 'hydrogen_rail' : 'offshore_wind',
    location: 'United Kingdom Infrastructure Corridor',
    capacity: isRail ? '120 km | 14 Stations | 18,400 PAX/H' : '800 MW Floating Wind | 120 Turbines',
    description: `Synthetically synthesized infrastructure asset based on: "${prompt}"`,
    lengthKm: 120,
    capacityVal: 18400,
    estimatedCapex: 18700000000,
    constructionYears: 7,
    operatingLifeYears: 60
  });
}

export async function queryRhinoAIAssistant(
  userQuery: string,
  asset: SyntheticInfrastructureAsset
): Promise<string> {
  const ai = getAiClient();

  const assetSummary = `
PROJECT NAME: ${asset.name}
CAPEX: £${(asset.construction_cost / 1e9).toFixed(2)}bn
TOTAL PROJECT COST: £${(asset.financing_structure.totalProjectCost / 1e9).toFixed(2)}bn
DEBT: £${(asset.financing_structure.totalDebtAmount / 1e9).toFixed(2)}bn | EQUITY: £${(asset.financing_structure.equityAmount / 1e9).toFixed(2)}bn
PROJECT IRR: ${(asset.financing_structure.projectIrr * 100).toFixed(2)}% | EQUITY IRR: ${(asset.financing_structure.equityIrr * 100).toFixed(2)}%
DSCR: ${asset.financing_structure.dscr}x | LLCR: ${asset.financing_structure.llcr}x | PLCR: ${asset.financing_structure.plcr}x
NPV @ 7%: £${(asset.financing_structure.npv7Percent / 1e9).toFixed(2)}bn
CONSTRUCTION PROGRESS: ${asset.constructionProgressPercent}%
CRITICAL PATH TASKS: ${asset.construction_schedule.filter(t => t.isCriticalPath).map(t => t.name).join(', ')}
KEY REVENUE STREAMS: ${asset.revenue_streams.map(r => `${r.name}: £${(r.annualRevenue / 1e6).toFixed(1)}m`).join('; ')}
OVERALL RISK SCORE: ${asset.risk_metrics.overallRiskScore}/10 | VaR 95%: £${(asset.risk_metrics.var95Annual / 1e6).toFixed(1)}m
  `;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `User Query: "${userQuery}"\n\nCurrent Project Model Context:\n${assetSummary}\n\nProvide an authoritative, institutional response as the Rhino Infra AI Intelligence system. Cite exact figures from the model output.`,
        config: {
          systemInstruction: 'You are Rhino Infra Intelligence, an expert institutional project finance, engineering and risk analyst for a major sovereign infrastructure bank. Always ground responses in exact numbers provided in context.'
        }
      });
      return response.text || 'Analysis complete based on model outputs.';
    } catch (err) {
      console.warn('Gemini query error:', err);
    }
  }

  // Fallback response generator if API key is not present
  if (userQuery.toLowerCase().includes('irr')) {
    return `Project IRR currently stands at ${(asset.financing_structure.projectIrr * 100).toFixed(2)}% (Equity IRR ${(asset.financing_structure.equityIrr * 100).toFixed(2)}%). Sensitivity analysis indicates IRR shifts by -0.42% for every +10% increase in total CAPEX (£${(asset.construction_cost / 1e9).toFixed(2)}bn base) or +50bps shift in senior debt financing rates.`;
  }
  if (userQuery.toLowerCase().includes('critical path')) {
    const cp = asset.construction_schedule.filter(t => t.isCriticalPath);
    return `The current critical path comprises ${cp.length} key tasks: ${cp.map(t => `[${t.name} - Status: ${t.status}]`).join(', ')}. Tunnelling and grid integration present the highest schedule slip vulnerability.`;
  }
  return `Rhino Infra Intelligence Analysis: Based on Model Version ${asset.provenance.modelVersion} (Calculation ID: ${asset.provenance.calculationId}), ${asset.name} maintains a strong Debt Service Coverage Ratio (DSCR) of ${asset.financing_structure.dscr}x against total debt of £${(asset.financing_structure.totalDebtAmount / 1e9).toFixed(2)}bn. Net Present Value (NPV @ 7%) is evaluated at £${(asset.financing_structure.npv7Percent / 1e9).toFixed(2)}bn.`;
}
