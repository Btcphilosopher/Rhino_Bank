import { SyntheticInfrastructureAsset, SecuritisedBond, CDOPool, PortfolioPosition } from '../types/infrastructure';

export const FLAGSHIP_NORTH_SEA_CORRIDOR: SyntheticInfrastructureAsset = {
  asset_id: 'ASSET-RHINO-NSC-001',
  project_id: 'PROJ-NORTH-SEA-CORRIDOR',
  name: 'RHINO NORTH SEA ENERGY & LOGISTICS CORRIDOR',
  codename: 'RHINOSYNTH-NSC-FLAGSHIP',
  version: 4.2,
  asset_class: 'ENERGY',
  subType: 'offshore_wind',
  location: 'Humber Estuary & North Sea Basin, UK',
  coordinates: { lat: 53.64, lng: 0.15 },
  description: 'Flagship multi-sector synthetic infrastructure platform linking offshore wind (1.2GW), green hydrogen electrolysers (400MW), electrified heavy rail freight, deepwater container port, subsea fibre, and green industrial campus.',
  capacity: '1.2 GW Power | 400 MW H2 | 28M Tonnes/Yr Freight | 180 km Rail | 200 Gbps Fibre',
  
  specs: {
    lengthKm: 180,
    capacityUnits: 'GW / MWh / TEU',
    capacityValue: 1200,
    designLifeYears: 60,
    keyComponentsCount: 1420,
    powerDemandMW: 400,
    efficiencyPercent: 92.5,
    gradientMaxPercent: 1.8,
    headwayMinutes: 8,
    throughputPerYear: 28000000, // 28M tonnes
    bandwidthGbps: 200,
    storageMWh: 15000,
  },

  construction_cost: 16200000000, // £16.2bn CAPEX
  land_cost: 850000000,           // £850m
  engineering_cost: 1150000000,   // £1.15bn
  operating_cost_annual: 480000000, // £480m OPEX

  financing_structure: {
    totalCapex: 16200000000,
    financingCostDuringConstruction: 1400000000,
    contingencyAllowance: 1100000000,
    totalProjectCost: 18700000000, // £18.7bn
    equityAmount: 5800000000,       // £5.8bn equity
    equityPercent: 31.0,
    totalDebtAmount: 10400000000,   // £10.4bn debt
    gearingRatio: 0.556,
    debtTranches: [
      {
        id: 'DEBT-01',
        name: 'Senior Secured Infrastructure Notes A1',
        type: 'SENIOR_DEBT',
        amount: 7200000000,
        interestRate: 0.0525,
        tenureYears: 25,
        gracePeriodYears: 5,
        amortizationType: 'AMORTIZING',
        annualServiceCost: 520000000,
      },
      {
        id: 'DEBT-02',
        name: 'Mezzanine Growth Subordinate Facility',
        type: 'MEZZANINE',
        amount: 2100000000,
        interestRate: 0.0780,
        tenureYears: 15,
        gracePeriodYears: 3,
        amortizationType: 'PERCENTAGE_SWEEP',
        annualServiceCost: 210000000,
      },
      {
        id: 'DEBT-03',
        name: 'Green Transition Subordinated Debt B2',
        type: 'SUBORDINATED_DEBT',
        amount: 1100000000,
        interestRate: 0.0890,
        tenureYears: 12,
        gracePeriodYears: 2,
        amortizationType: 'BULLET',
        annualServiceCost: 98000000,
      }
    ],
    dscr: 1.72,
    llcr: 1.89,
    plcr: 2.14,
    projectIrr: 0.084, // 8.4%
    equityIrr: 0.138,  // 13.8%
    npv7Percent: 4850000000, // £4.85bn NPV
    paybackPeriodYears: 11.4,
    refinancingRisk: 'LOW',
  },

  revenue_streams: [
    {
      id: 'REV-01',
      name: 'Offshore Wind Power Purchase Agreements (PPA)',
      unitType: 'MWh',
      annualVolume: 4200000,
      unitTariff: 110, // £110 / MWh
      annualRevenue: 462000000,
      escalationPercent: 0.025,
      elasticityToDemand: 0.85,
    },
    {
      id: 'REV-02',
      name: 'Green Hydrogen Supply Contracts (Steel & Transport)',
      unitType: 'Tonnes H2',
      annualVolume: 75000,
      unitTariff: 4800, // £4800 / Tonne
      annualRevenue: 360000000,
      escalationPercent: 0.030,
      elasticityToDemand: 0.92,
    },
    {
      id: 'REV-03',
      name: 'Freight Rail Corridor Tariffs & Container Tolls',
      unitType: 'Net Tonne-Km',
      annualVolume: 28000000,
      unitTariff: 18.5,
      annualRevenue: 518000000,
      escalationPercent: 0.022,
      elasticityToDemand: 0.70,
    },
    {
      id: 'REV-04',
      name: 'Deepwater Port Container Terminal Dues & Berthing',
      unitType: 'TEU Container',
      annualVolume: 2400000,
      unitTariff: 145,
      annualRevenue: 348000000,
      escalationPercent: 0.028,
      elasticityToDemand: 0.80,
    },
    {
      id: 'REV-05',
      name: 'Subsea Fibre Connectivity Bandwidth Leases',
      unitType: 'Gbps Circuits',
      annualVolume: 180,
      unitTariff: 450000,
      annualRevenue: 81000000,
      escalationPercent: 0.015,
      elasticityToDemand: 0.50,
    }
  ],

  opex_breakdown: [
    { id: 'OPEX-01', category: 'MAINTENANCE', annualCost: 180000000, fixedRatio: 0.60 },
    { id: 'OPEX-02', category: 'STAFF', annualCost: 120000000, fixedRatio: 0.85 },
    { id: 'OPEX-03', category: 'ENERGY', annualCost: 90000000, fixedRatio: 0.30 },
    { id: 'OPEX-04', category: 'INSURANCE', annualCost: 55000000, fixedRatio: 0.95 },
    { id: 'OPEX-05', category: 'COMMODITIES', annualCost: 35000000, fixedRatio: 0.20 },
  ],

  bom: [
    {
      category: 'ENERGY & TURBINES',
      totalCost: 5400000000,
      items: [
        { id: 'M-01', name: 'Offshore Direct-Drive Wind Turbines 15MW', quantity: 80, unit: 'Units', unitPrice: 38000000, volatility: 0.12, supplierRegion: 'North Sea Industrial Consortium', leadTimeWeeks: 42, carbonIntensityKgPerUnit: 1400000, totalCost: 3040000000 },
        { id: 'M-02', name: 'PEM Hydrogen Electrolyser Stacks 50MW', quantity: 8, unit: 'Modules', unitPrice: 195000000, volatility: 0.18, supplierRegion: 'UK Hydrogen Tech', leadTimeWeeks: 36, carbonIntensityKgPerUnit: 850000, totalCost: 1560000000 },
        { id: 'M-03', name: 'HVDC Converter Offshore Substation 1.2GW', quantity: 2, unit: 'Platforms', unitPrice: 400000000, volatility: 0.15, supplierRegion: 'Scandinavia Energy Heavy', leadTimeWeeks: 52, carbonIntensityKgPerUnit: 3200000, totalCost: 800000000 },
      ]
    },
    {
      category: 'CIVIL & RAIL INFRASTRUCTURE',
      totalCost: 4800000000,
      items: [
        { id: 'M-04', name: 'High-Tensile Structural Steel Rails (60E1)', quantity: 360000, unit: 'Tonnes', unitPrice: 1420, volatility: 0.22, supplierRegion: 'British Steel Scunthorpe', leadTimeWeeks: 18, carbonIntensityKgPerUnit: 1850, totalCost: 511200000 },
        { id: 'M-05', name: 'Prestressed Monoblock Concrete Sleepers', quantity: 720000, unit: 'Units', unitPrice: 85, volatility: 0.08, supplierRegion: 'Yorkshire Concrete Works', leadTimeWeeks: 12, carbonIntensityKgPerUnit: 140, totalCost: 61200000 },
        { id: 'M-06', name: 'Granite Track Ballast & Earthworks', quantity: 2400000, unit: 'Tonnes', unitPrice: 32, volatility: 0.05, supplierRegion: 'Midlands Quarrying', leadTimeWeeks: 6, carbonIntensityKgPerUnit: 18, totalCost: 76800000 },
        { id: 'M-07', name: 'High-Capacity Rail Tunnels & Cut-and-Cover', quantity: 18, unit: 'km', unitPrice: 220000000, volatility: 0.25, supplierRegion: 'Global Tunnelling Joint Venture', leadTimeWeeks: 104, carbonIntensityKgPerUnit: 12000000, totalCost: 3960000000 },
      ]
    },
    {
      category: 'PORT & LOGISTICS',
      totalCost: 3600000000,
      items: [
        { id: 'M-08', name: 'Automated Stacking Cranes (ASC)', quantity: 36, unit: 'Cranes', unitPrice: 18500000, volatility: 0.14, supplierRegion: 'Northern Europe Cranes', leadTimeWeeks: 28, carbonIntensityKgPerUnit: 240000, totalCost: 666000000 },
        { id: 'M-09', name: 'Deepwater Berth Quayside Concrete Caissons', quantity: 2400, unit: 'Meters', unitPrice: 950000, volatility: 0.10, supplierRegion: 'UK Marine Infra', leadTimeWeeks: 40, carbonIntensityKgPerUnit: 8500, totalCost: 2280000000 },
        { id: 'M-10', name: 'Hydrogen Fuel-Cell Yard Shunters & Trucks', quantity: 120, unit: 'Vehicles', unitPrice: 540000, volatility: 0.15, supplierRegion: 'Midlands Logistics Robotics', leadTimeWeeks: 20, carbonIntensityKgPerUnit: 12000, totalCost: 64800000 },
      ]
    },
    {
      category: 'DIGITAL & TELECOM',
      totalCost: 2400000000,
      items: [
        { id: 'M-11', name: 'Double-Armoured Subsea Optical Fibre Cable', quantity: 450, unit: 'km', unitPrice: 185000, volatility: 0.18, supplierRegion: 'Subsea Systems Europe', leadTimeWeeks: 24, carbonIntensityKgPerUnit: 4200, totalCost: 83250000 },
        { id: 'M-12', name: 'Modular Edge Computing Micro Data Centers', quantity: 24, unit: 'Centers', unitPrice: 85000000, volatility: 0.16, supplierRegion: 'Global Digital Infra', leadTimeWeeks: 30, carbonIntensityKgPerUnit: 450000, totalCost: 2040000000 },
      ]
    }
  ],

  construction_schedule: [
    { id: 'T-01', name: 'Marine & Land Site Prep & Geotechnical Survey', phase: 'LAND', startMonth: 1, durationMonths: 12, completionPercent: 100, dependencies: [], isCriticalPath: true, assignedMachines: ['MCH-EXCAVATOR-01', 'MCH-SURVEY-SHIP-02'], assignedContractor: 'Rhino Marine Engineering PLC', estimatedCost: 450000000, actualCost: 442000000, status: 'COMPLETED', delayDays: 0 },
    { id: 'T-02', name: 'Offshore Substation Foundations & Piling', phase: 'FOUNDATIONS', startMonth: 10, durationMonths: 18, completionPercent: 100, dependencies: ['T-01'], isCriticalPath: true, assignedMachines: ['MCH-HEAVY-LIFT-VESSEL'], assignedContractor: 'North Sea Foundations Ltd', estimatedCost: 1200000000, actualCost: 1215000000, status: 'COMPLETED', delayDays: 4 },
    { id: 'T-03', name: 'Rail Corridor Earthworks & Tunnelling (Humber Loop)', phase: 'CIVIL', startMonth: 14, durationMonths: 36, completionPercent: 78, dependencies: ['T-01'], isCriticalPath: true, assignedMachines: ['MCH-TBM-PENNINE-HERCULES'], assignedContractor: 'Balfour Rhino Rail Joint Venture', estimatedCost: 3800000000, actualCost: 3820000000, status: 'IN_PROGRESS', delayDays: 12 },
    { id: 'T-04', name: 'Offshore Wind Turbine Erection & Cabling', phase: 'STRUCTURES', startMonth: 24, durationMonths: 24, completionPercent: 65, dependencies: ['T-02'], isCriticalPath: false, assignedMachines: ['MCH-JACKUP-RIG-01'], assignedContractor: 'Orsted Rhino Offshore', estimatedCost: 2900000000, actualCost: 2880000000, status: 'IN_PROGRESS', delayDays: -5 },
    { id: 'T-05', name: 'Hydrogen Electrolyser Plant Civil & Structural Build', phase: 'CIVIL', startMonth: 28, durationMonths: 20, completionPercent: 50, dependencies: ['T-01'], isCriticalPath: false, assignedMachines: ['MCH-CONCRETE-PUMP-04', 'MCH-CRANE-80T'], assignedContractor: 'Humber Clean Energy Infra', estimatedCost: 1800000000, actualCost: 1790000000, status: 'IN_PROGRESS', delayDays: 0 },
    { id: 'T-06', name: 'Electrified Rail Overhead Catenary & Signalling System', phase: 'SYSTEMS', startMonth: 38, durationMonths: 22, completionPercent: 30, dependencies: ['T-03'], isCriticalPath: true, assignedMachines: ['MCH-RAIL-WIRING-TRAIN'], assignedContractor: 'Siemens Rhino Systems', estimatedCost: 1400000000, actualCost: 1400000000, status: 'IN_PROGRESS', delayDays: 0 },
    { id: 'T-07', name: 'Deepwater Container Berth Quay Wall & Crane Assembly', phase: 'EQUIPMENT', startMonth: 42, durationMonths: 18, completionPercent: 15, dependencies: ['T-01'], isCriticalPath: false, assignedMachines: ['MCH-QUAYSIDE-CRANE-01'], assignedContractor: 'Hull Port Engineering', estimatedCost: 1600000000, actualCost: 1600000000, status: 'IN_PROGRESS', delayDays: 0 },
    { id: 'T-08', name: 'Grid Interconnect Integration & System Testing', phase: 'TESTING', startMonth: 56, durationMonths: 12, completionPercent: 0, dependencies: ['T-04', 'T-05', 'T-06'], isCriticalPath: true, assignedMachines: [], assignedContractor: 'National Grid Rhino Power', estimatedCost: 650000000, actualCost: 0, status: 'NOT_STARTED', delayDays: 0 },
    { id: 'T-09', name: 'Full Network Commissioning & Safety Certification', phase: 'COMMISSIONING', startMonth: 66, durationMonths: 8, completionPercent: 0, dependencies: ['T-08'], isCriticalPath: true, assignedMachines: [], assignedContractor: 'UK Infra Regulator Approved Inspector', estimatedCost: 400000000, actualCost: 0, status: 'NOT_STARTED', delayDays: 0 },
  ],

  machines: [
    { id: 'MCH-TBM-PENNINE-HERCULES', name: 'Tunnel Boring Machine (Pennine Hercules 14m)', type: 'tunnel_boring_machine', count: 2, utilizationRate: 94, hourlyCost: 4200, operationalStatus: 'ACTIVE' },
    { id: 'MCH-JACKUP-RIG-01', name: 'Offshore Heavy Jack-up Installation Vessel', type: 'crane', count: 3, utilizationRate: 88, hourlyCost: 12500, operationalStatus: 'ACTIVE' },
    { id: 'MCH-QUAYSIDE-CRANE-01', name: 'Automated Post-Panamax Quayside Gantry Crane', type: 'crane', count: 12, utilizationRate: 72, hourlyCost: 850, operationalStatus: 'ACTIVE' },
    { id: 'MCH-EXCAVATOR-01', name: 'Heavy Caterpillar Excavator Fleet 395', type: 'excavator', count: 28, utilizationRate: 82, hourlyCost: 185, operationalStatus: 'ACTIVE' },
    { id: 'MCH-RAIL-WIRING-TRAIN', name: 'High-Speed Catenary Wiring & Track Layer Train', type: 'train', count: 2, utilizationRate: 90, hourlyCost: 2800, operationalStatus: 'ACTIVE' },
  ],

  operational_state: 'CONSTRUCTION',
  constructionProgressPercent: 63.4,

  physical_components: [
    { componentId: 'CMP-OFFSHORE-01', name: 'Offshore Wind Array Sector Alpha (Turbines 1-40)', type: 'Turbines', ageYears: 2, structuralConditionScore: 98, lastInspectionDaysAgo: 14, remainingDesignLifeYears: 28, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 120, predictedFailureRisk: 0.02, mlConfidence: 0.96 },
    { componentId: 'CMP-H2-ELEC-01', name: 'Green Hydrogen Electrolyser Stack Alpha (100MW)', type: 'Electrolyser', ageYears: 1, structuralConditionScore: 99, lastInspectionDaysAgo: 5, remainingDesignLifeYears: 19, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 60, predictedFailureRisk: 0.01, mlConfidence: 0.98 },
    { componentId: 'CMP-BRIDGE-B001', name: 'Humber Approach Rail Viaduct Bridge B-001', type: 'Structural Steel Viaduct', ageYears: 3, structuralConditionScore: 94, lastInspectionDaysAgo: 12, remainingDesignLifeYears: 88, maintenanceStatus: 'DUE', nextMaintenanceDays: 47, predictedFailureRisk: 0.06, mlConfidence: 0.92 },
    { componentId: 'CMP-PORT-QUAY-01', name: 'Deepwater Container Terminal Quay Wall Section 1', type: 'Reinforced Concrete Berth', ageYears: 2, structuralConditionScore: 96, lastInspectionDaysAgo: 22, remainingDesignLifeYears: 73, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 180, predictedFailureRisk: 0.03, mlConfidence: 0.95 },
    { componentId: 'CMP-SUBSEA-FIBRE-01', name: 'North Sea Optical Fibre Trunk Strand A', type: 'Armoured Subsea Fibre', ageYears: 1, structuralConditionScore: 100, lastInspectionDaysAgo: 30, remainingDesignLifeYears: 34, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 300, predictedFailureRisk: 0.005, mlConfidence: 0.99 },
  ],

  risk_metrics: {
    constructionRiskScore: 3.8,
    demandRiskScore: 2.9,
    marketRiskScore: 3.2,
    interestRateRiskScore: 4.1,
    creditRiskScore: 2.1,
    counterpartyRiskScore: 2.4,
    climateRiskScore: 3.5,
    overallRiskScore: 3.2, // out of 10
    var95Annual: 480000000,
    expectedShortfall95: 720000000,
    dscrAtRisk10Pct: 1.38,
    cashflowAtRisk: 185000000,
  },

  provenance: {
    source: 'SYNTHETIC_MODEL',
    modelVersion: 'RHINOSYNTH-ENGINE-v3.6.4',
    timestamp: '2026-09-27T00:12:00Z',
    calculationId: 'CALC-NSC-9948210-AUDIT',
    assumptions: [
      'Offshore Wind capacity factor assumed at 48.5% in North Sea Sector IV',
      'Hydrogen PPA indexed to UK Wholesale Industrial Energy Benchmark + £20/tonne clean premium',
      'Freight rail demand derived from Humber Gateway Port throughput projections 2026-2050',
      'Construction interest calculated at 5.25% SOFR equivalent swap rate'
    ]
  }
};

export const OTHER_SEED_PROJECTS: SyntheticInfrastructureAsset[] = [
  {
    asset_id: 'ASSET-RHINO-MPE-002',
    project_id: 'PROJ-MANCHESTER-H2-RAIL',
    name: 'RHINO HYDROGEN PENNINE EXPRESS',
    codename: 'RHINOSYNTH-MPE-RAIL',
    version: 2.1,
    asset_class: 'TRANSPORT',
    subType: 'hydrogen_rail',
    location: 'Manchester - Sheffield - Leeds Corridor, UK',
    coordinates: { lat: 53.48, lng: -2.24 },
    description: '120 km zero-emission hydrogen fuel-cell rail link across the Pennines connecting Greater Manchester, South Yorkshire and West Yorkshire.',
    capacity: '120 km Line | 14 Stations | 32 Trains | 18,400 PAX/Hour Peak',
    specs: {
      lengthKm: 120,
      capacityUnits: 'Passengers / Hour',
      capacityValue: 18400,
      designLifeYears: 60,
      keyComponentsCount: 420,
      powerDemandMW: 85,
      efficiencyPercent: 88.0,
      headwayMinutes: 5,
      throughputPerYear: 32000000,
    },
    construction_cost: 16200000000,
    land_cost: 650000000,
    engineering_cost: 850000000,
    operating_cost_annual: 320000000,
    financing_structure: {
      totalCapex: 16200000000,
      financingCostDuringConstruction: 1500000000,
      contingencyAllowance: 1000000000,
      totalProjectCost: 18700000000,
      equityAmount: 5800000000,
      equityPercent: 31.0,
      totalDebtAmount: 10400000000,
      gearingRatio: 0.556,
      debtTranches: [
        { id: 'MPE-DEBT-01', name: 'Senior Railway Revenue Bonds 2030', type: 'SENIOR_DEBT', amount: 8000000000, interestRate: 0.048, tenureYears: 30, gracePeriodYears: 5, amortizationType: 'AMORTIZING', annualServiceCost: 510000000 },
        { id: 'MPE-DEBT-02', name: 'Northern Powerhouse Subordinated Debt', type: 'SUBORDINATED_DEBT', amount: 2400000000, interestRate: 0.072, tenureYears: 15, gracePeriodYears: 3, amortizationType: 'BULLET', annualServiceCost: 172000000 }
      ],
      dscr: 1.65,
      llcr: 1.82,
      plcr: 2.05,
      projectIrr: 0.088,
      equityIrr: 0.142,
      npv7Percent: 3950000000,
      paybackPeriodYears: 12.1,
      refinancingRisk: 'LOW',
    },
    revenue_streams: [
      { id: 'REV-MPE-01', name: 'Passenger Ticket Fares', unitType: 'Passengers', annualVolume: 32000000, unitTariff: 18.50, annualRevenue: 592000000, escalationPercent: 0.025, elasticityToDemand: 0.82 },
      { id: 'REV-MPE-02', name: 'Station Retail & Commercial Leases', unitType: 'Facilities', annualVolume: 14, unitTariff: 3200000, annualRevenue: 44800000, escalationPercent: 0.02, elasticityToDemand: 0.40 }
    ],
    opex_breakdown: [
      { id: 'OPEX-MPE-01', category: 'STAFF', annualCost: 110000000, fixedRatio: 0.80 },
      { id: 'OPEX-MPE-02', category: 'ENERGY', annualCost: 130000000, fixedRatio: 0.25 },
      { id: 'OPEX-MPE-03', category: 'MAINTENANCE', annualCost: 80000000, fixedRatio: 0.65 }
    ],
    bom: [
      { category: 'ROLLING STOCK & HYDROGEN', totalCost: 1800000000, items: [{ id: 'BM-MPE-01', name: 'Hydrail 200 Express Trainsets', quantity: 32, unit: 'Trains', unitPrice: 42000000, volatility: 0.12, supplierRegion: 'Alstom UK / Siemens', leadTimeWeeks: 32, carbonIntensityKgPerUnit: 650000, totalCost: 1344000000 }] }
    ],
    construction_schedule: [
      { id: 'TSK-MPE-01', name: 'Pennine Tunnel Excavation & Boring', phase: 'CIVIL', startMonth: 1, durationMonths: 42, completionPercent: 85, dependencies: [], isCriticalPath: true, assignedMachines: ['MCH-TBM-PENNINE-HERCULES'], assignedContractor: 'Northern Rail Civil', estimatedCost: 6500000000, actualCost: 6520000000, status: 'IN_PROGRESS', delayDays: 8 }
    ],
    machines: [
      { id: 'MCH-TBM-PENNINE-HERCULES', name: 'Tunnel Boring Machine (Pennine Hercules)', type: 'tunnel_boring_machine', count: 4, utilizationRate: 91, hourlyCost: 4500, operationalStatus: 'ACTIVE' }
    ],
    operational_state: 'CONSTRUCTION',
    constructionProgressPercent: 71.2,
    physical_components: [
      { componentId: 'CMP-MPE-01', name: 'Woodhead Pass Railway Tunnel Bore #1', type: 'Tunnel', ageYears: 2, structuralConditionScore: 97, lastInspectionDaysAgo: 10, remainingDesignLifeYears: 118, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 90, predictedFailureRisk: 0.01, mlConfidence: 0.97 }
    ],
    risk_metrics: {
      constructionRiskScore: 4.1,
      demandRiskScore: 2.8,
      marketRiskScore: 3.0,
      interestRateRiskScore: 3.5,
      creditRiskScore: 2.0,
      counterpartyRiskScore: 2.2,
      climateRiskScore: 2.9,
      overallRiskScore: 3.1,
      var95Annual: 310000000,
      expectedShortfall95: 480000000,
      dscrAtRisk10Pct: 1.41,
      cashflowAtRisk: 120000000,
    },
    provenance: {
      source: 'SYNTHETIC_MODEL',
      modelVersion: 'RHINOSYNTH-ENGINE-v3.6.4',
      timestamp: '2026-09-27T00:12:00Z',
      calculationId: 'CALC-MPE-8839201-AUDIT',
      assumptions: ['Pennine tunnelling geology model based on British Geological Survey synthetic rock profile']
    }
  },
  {
    asset_id: 'ASSET-RHINO-THAMES-003',
    project_id: 'PROJ-THAMES-TIDEWAY-WATER',
    name: 'RHINO THAMES CLEAN WATER & RESILIENCE GRID',
    codename: 'RHINOSYNTH-THAMES-WATER',
    version: 3.0,
    asset_class: 'WATER',
    subType: 'pipeline',
    location: 'London & Thames Estuary, UK',
    coordinates: { lat: 51.50, lng: -0.08 },
    description: 'Deep tunnel water transfer and flood defense infrastructure protecting Greater London with 1.8 million m³/day purification and storm overflow buffer.',
    capacity: '1.8M m³/day Purification | 25 km Main Tunnel | 12 Pumping Hubs',
    specs: {
      lengthKm: 25,
      capacityUnits: 'm³ / day',
      capacityValue: 1800000,
      designLifeYears: 120,
      keyComponentsCount: 380,
      powerDemandMW: 45,
      efficiencyPercent: 96.2,
    },
    construction_cost: 5400000000,
    land_cost: 320000000,
    engineering_cost: 410000000,
    operating_cost_annual: 110000000,
    financing_structure: {
      totalCapex: 5400000000,
      financingCostDuringConstruction: 480000000,
      contingencyAllowance: 320000000,
      totalProjectCost: 6200000000,
      equityAmount: 1860000000,
      equityPercent: 30.0,
      totalDebtAmount: 4340000000,
      gearingRatio: 0.70,
      debtTranches: [
        { id: 'TMW-DEBT-01', name: 'Regulated Asset Base (RAB) Senior Notes', type: 'SENIOR_DEBT', amount: 3500000000, interestRate: 0.042, tenureYears: 35, gracePeriodYears: 5, amortizationType: 'AMORTIZING', annualServiceCost: 195000000 }
      ],
      dscr: 1.88,
      llcr: 2.10,
      plcr: 2.45,
      projectIrr: 0.076,
      equityIrr: 0.121,
      npv7Percent: 1850000000,
      paybackPeriodYears: 14.2,
      refinancingRisk: 'LOW',
    },
    revenue_streams: [
      { id: 'REV-TMW-01', name: 'Ofwat Regulated Asset Base Water Tariff', unitType: 'm³ Volume', annualVolume: 650000000, unitTariff: 0.85, annualRevenue: 552500000, escalationPercent: 0.028, elasticityToDemand: 0.15 }
    ],
    opex_breakdown: [
      { id: 'OPEX-TMW-01', category: 'MAINTENANCE', annualCost: 45000000, fixedRatio: 0.75 },
      { id: 'OPEX-TMW-02', category: 'ENERGY', annualCost: 35000000, fixedRatio: 0.20 }
    ],
    bom: [
      { category: 'TUNNELLING & PUMPS', totalCost: 2800000000, items: [{ id: 'BM-TMW-01', name: 'High-Pressure Submersible Pumps 12MW', quantity: 24, unit: 'Units', unitPrice: 18500000, volatility: 0.08, supplierRegion: 'KSB / Sulzer', leadTimeWeeks: 26, carbonIntensityKgPerUnit: 180000, totalCost: 444000000 }] }
    ],
    construction_schedule: [
      { id: 'TSK-TMW-01', name: 'Thames Deep Storage Shaft sinking', phase: 'FOUNDATIONS', startMonth: 1, durationMonths: 24, completionPercent: 100, dependencies: [], isCriticalPath: true, assignedMachines: ['MCH-EXCAVATOR-01'], assignedContractor: 'Thames Infra Civil', estimatedCost: 1200000000, actualCost: 1195000000, status: 'COMPLETED', delayDays: 0 }
    ],
    machines: [
      { id: 'MCH-EXCAVATOR-01', name: 'Shaft Heavy Excavator Unit', type: 'excavator', count: 8, utilizationRate: 85, hourlyCost: 320, operationalStatus: 'ACTIVE' }
    ],
    operational_state: 'OPERATIONAL',
    constructionProgressPercent: 100.0,
    physical_components: [
      { componentId: 'CMP-TMW-01', name: 'Blackfriars Deep Intake Shaft & Buffer Tank', type: 'Intake Shaft', ageYears: 4, structuralConditionScore: 99, lastInspectionDaysAgo: 8, remainingDesignLifeYears: 116, maintenanceStatus: 'OPTIMAL', nextMaintenanceDays: 180, predictedFailureRisk: 0.005, mlConfidence: 0.99 }
    ],
    risk_metrics: {
      constructionRiskScore: 1.5,
      demandRiskScore: 1.2,
      marketRiskScore: 1.8,
      interestRateRiskScore: 2.2,
      creditRiskScore: 1.1,
      counterpartyRiskScore: 1.3,
      climateRiskScore: 3.8,
      overallRiskScore: 1.8,
      var95Annual: 85000000,
      expectedShortfall95: 120000000,
      dscrAtRisk10Pct: 1.62,
      cashflowAtRisk: 35000000,
    },
    provenance: {
      source: 'SYNTHETIC_MODEL',
      modelVersion: 'RHINOSYNTH-ENGINE-v3.6.4',
      timestamp: '2026-09-27T00:12:00Z',
      calculationId: 'CALC-TMW-1002931-AUDIT',
      assumptions: ['Regulated Return on Capital Equity set at 5.4% real + CPI-H inflation indexation']
    }
  }
];

export const SEED_SECURITISED_BONDS: SecuritisedBond[] = [
  { bondId: 'BOND-RHINO-NSC-A1', projectId: 'PROJ-NORTH-SEA-CORRIDOR', projectName: 'RHINO NORTH SEA CORRIDOR', trancheName: 'Senior Secured Infra Notes A1', tier: 'SUPER_SENIOR', notionalAmount: 7200000000, couponRate: 0.0525, maturityYears: 25, rating: 'AAA', pricePercent: 101.2, currentYield: 0.0518, bidPrice: 101.1, askPrice: 101.3, spreadBps: 115 },
  { bondId: 'BOND-RHINO-NSC-M1', projectId: 'PROJ-NORTH-SEA-CORRIDOR', projectName: 'RHINO NORTH SEA CORRIDOR', trancheName: 'Mezzanine Growth Subordinate', tier: 'MEZZANINE', notionalAmount: 2100000000, couponRate: 0.0780, maturityYears: 15, rating: 'A', pricePercent: 99.4, currentYield: 0.0785, bidPrice: 99.2, askPrice: 99.6, spreadBps: 340 },
  { bondId: 'BOND-RHINO-MPE-SR', projectId: 'PROJ-MANCHESTER-H2-RAIL', projectName: 'RHINO HYDROGEN PENNINE EXPRESS', trancheName: 'Senior Rail Revenue Bond 2030', tier: 'SENIOR', notionalAmount: 8000000000, couponRate: 0.0480, maturityYears: 30, rating: 'AA+', pricePercent: 100.5, currentYield: 0.0477, bidPrice: 100.4, askPrice: 100.6, spreadBps: 98 },
  { bondId: 'BOND-RHINO-TMW-RAB', projectId: 'PROJ-THAMES-TIDEWAY-WATER', projectName: 'RHINO THAMES CLEAN WATER', trancheName: 'Regulated Asset Base RAB Senior', tier: 'SUPER_SENIOR', notionalAmount: 3500000000, couponRate: 0.0420, maturityYears: 35, rating: 'AAA', pricePercent: 102.4, currentYield: 0.0410, bidPrice: 102.3, askPrice: 102.5, spreadBps: 72 },
];

export const SEED_CDO_POOL: CDOPool = {
  poolId: 'RHINO-INFRA-CREDIT-POOL-01',
  poolName: 'RHINO INSTITUTIONAL SYNTHETIC INFRA CDO I',
  totalNotional: 25000000000, // £25bn
  assetAllocation: {
    ENERGY: 25,
    TRANSPORT: 20,
    WATER: 15,
    DIGITAL: 15,
    URBAN: 15,
    INDUSTRIAL: 10
  },
  tranches: [
    { name: 'SUPER SENIOR TRANCHE A', type: 'SUPER_SENIOR', attachmentPointPercent: 25, detachmentPointPercent: 100, coupon: 0.044, rating: 'AAA', subordinationPercent: 25, simulatedLossPercent: 0.0 },
    { name: 'SENIOR TRANCHE B', type: 'SENIOR', attachmentPointPercent: 15, detachmentPointPercent: 25, coupon: 0.058, rating: 'AA', subordinationPercent: 15, simulatedLossPercent: 0.0 },
    { name: 'MEZZANINE TRANCHE C', type: 'MEZZANINE', attachmentPointPercent: 8, detachmentPointPercent: 15, coupon: 0.082, rating: 'BBB', subordinationPercent: 8, simulatedLossPercent: 0.12 },
    { name: 'JUNIOR TRANCHE D', type: 'JUNIOR', attachmentPointPercent: 3, detachmentPointPercent: 8, coupon: 0.115, rating: 'BB', subordinationPercent: 3, simulatedLossPercent: 1.40 },
    { name: 'EQUITY FIRST LOSS TRANCHE', type: 'EQUITY', attachmentPointPercent: 0, detachmentPointPercent: 3, coupon: 0.185, rating: 'NR', subordinationPercent: 0, simulatedLossPercent: 6.80 },
  ]
};

export const SEED_PORTFOLIO: PortfolioPosition[] = [
  { id: 'POS-01', projectId: 'PROJ-NORTH-SEA-CORRIDOR', projectName: 'RHINO NORTH SEA CORRIDOR', assetClass: 'ENERGY', holdingType: 'PROJECT_EQUITY', notional: 1800000000, acquisitionCost: 1800000000, currentValuation: 2150000000, unrealizedGains: 350000000, yieldPercent: 0.138 },
  { id: 'POS-02', projectId: 'PROJ-NORTH-SEA-CORRIDOR', projectName: 'RHINO NORTH SEA CORRIDOR', assetClass: 'ENERGY', holdingType: 'INFRA_BOND', notional: 2500000000, acquisitionCost: 2500000000, currentValuation: 2530000000, unrealizedGains: 30000000, yieldPercent: 0.0525 },
  { id: 'POS-03', projectId: 'PROJ-MANCHESTER-H2-RAIL', projectName: 'RHINO HYDROGEN PENNINE EXPRESS', assetClass: 'TRANSPORT', holdingType: 'SENIOR_DEBT', notional: 1500000000, acquisitionCost: 1500000000, currentValuation: 1515000000, unrealizedGains: 15000000, yieldPercent: 0.0480 },
  { id: 'POS-04', projectId: 'PROJ-THAMES-TIDEWAY-WATER', projectName: 'RHINO THAMES CLEAN WATER', assetClass: 'WATER', holdingType: 'INFRA_BOND', notional: 800000000, acquisitionCost: 800000000, currentValuation: 819200000, unrealizedGains: 19200000, yieldPercent: 0.0420 },
];
