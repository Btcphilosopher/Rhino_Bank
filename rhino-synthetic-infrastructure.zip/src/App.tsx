import React, { useState } from 'react';
import { SyntheticInfrastructureAsset } from './types/infrastructure';
import { FLAGSHIP_NORTH_SEA_CORRIDOR, OTHER_SEED_PROJECTS } from './data/flagshipProject';
import { ControlRoom } from './components/views/ControlRoom';
import { CreationStudio } from './components/views/CreationStudio';
import { EngineeringBOM } from './components/views/EngineeringBOM';
import { ConstructionSimulator } from './components/views/ConstructionSimulator';
import { ProjectFinance } from './components/views/ProjectFinance';
import { InfraCDO } from './components/views/InfraCDO';
import { MarketTrading } from './components/views/MarketTrading';
import { AssetManagement } from './components/views/AssetManagement';
import { ScenarioLab } from './components/views/ScenarioLab';
import { Procurement } from './components/views/Procurement';
import { InvestmentCommittee } from './components/views/InvestmentCommittee';
import { RhinoAIAssistant } from './components/views/RhinoAIAssistant';
import { Building2, Cpu, Clock, DollarSign, Layers, TrendingUp, Activity, ShieldAlert, ShoppingCart, FileText, Bot, ChevronRight, RefreshCw, Folder } from 'lucide-react';

export default function App() {
  const [projects, setProjects] = useState<SyntheticInfrastructureAsset[]>([
    FLAGSHIP_NORTH_SEA_CORRIDOR,
    ...OTHER_SEED_PROJECTS
  ]);
  const [currentProject, setCurrentProject] = useState<SyntheticInfrastructureAsset>(FLAGSHIP_NORTH_SEA_CORRIDOR);
  const [activeTab, setActiveTab] = useState<string>('CONTROL_ROOM');

  const handleUpdateProject = (updated: SyntheticInfrastructureAsset) => {
    setCurrentProject(updated);
    setProjects(prev => prev.map(p => p.asset_id === updated.asset_id ? updated : p));
  };

  const tabs = [
    { id: 'CONTROL_ROOM', label: 'CONTROL ROOM', icon: Building2 },
    { id: 'STUDIO', label: 'CREATION STUDIO', icon: Cpu },
    { id: 'BOM', label: 'ENGINEERING & BOM', icon: Layers },
    { id: 'CONSTRUCTION', label: 'CONSTRUCTION', icon: Clock },
    { id: 'FINANCE', label: 'PROJECT FINANCE', icon: DollarSign },
    { id: 'CDO', label: 'INFRA CDO', icon: Layers },
    { id: 'MARKET', label: 'MARKETS & TRADING', icon: TrendingUp },
    { id: 'ASSET_MGMT', label: 'ASSET MANAGEMENT', icon: Activity },
    { id: 'SCENARIO', label: 'SCENARIO LAB', icon: ShieldAlert },
    { id: 'PROCUREMENT', label: 'PROCUREMENT', icon: ShoppingCart },
    { id: 'IC_MEMO', label: 'INVESTMENT MEMO', icon: FileText },
    { id: 'AI_ASSISTANT', label: 'RHINO AI INTELLIGENCE', icon: Bot },
  ];

  return (
    <div className="min-h-screen bg-[#0b111e] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Main Navigation Header */}
      <header className="bg-slate-950 border-b border-slate-800 px-6 py-3 sticky top-0 z-50 shadow-2xl">
        <div className="flex flex-col lg:flex-row justify-between items-center gap-3">
          {/* Brand Logo & Name */}
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded bg-amber-500 flex items-center justify-center text-slate-950 font-black font-mono text-xl tracking-tighter shadow-lg">
              RH
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-serif font-bold text-base text-slate-100 tracking-tight">
                  RHINO SYNTHETIC INFRASTRUCTURE
                </span>
                <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-950 text-amber-400 border border-amber-800 uppercase">
                  Rhino Bank Grade
                </span>
              </div>
              <p className="text-[10px] font-mono text-slate-500">
                Institutional Infrastructure Creation, Financing, Simulation & Trading Platform
              </p>
            </div>
          </div>

          {/* Active Project Selector Dropdown */}
          <div className="flex items-center space-x-3 w-full lg:w-auto">
            <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-xs font-mono w-full lg:w-80">
              <Folder className="w-4 h-4 text-amber-400 shrink-0" />
              <select
                value={currentProject.asset_id}
                onChange={(e) => {
                  const found = projects.find(p => p.asset_id === e.target.value);
                  if (found) setCurrentProject(found);
                }}
                className="bg-transparent text-slate-200 font-bold focus:outline-none w-full cursor-pointer"
              >
                {projects.map(p => (
                  <option key={p.asset_id} value={p.asset_id} className="bg-slate-900 text-slate-200">
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Secondary Module Navigation Tabs */}
        <div className="flex items-center space-x-1 overflow-x-auto mt-3 pt-2 border-t border-slate-900 font-mono text-[11px] scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-2 rounded-t-md font-bold whitespace-nowrap transition flex items-center space-x-1.5 border-b-2 ${
                  isActive
                    ? 'bg-slate-900 text-amber-400 border-amber-500 shadow-inner'
                    : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Main App Content View Switcher */}
      <main className="flex-1 p-6 max-w-[1800px] w-full mx-auto">
        {activeTab === 'CONTROL_ROOM' && (
          <ControlRoom
            projects={projects}
            onSelectProject={(p) => setCurrentProject(p)}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'STUDIO' && (
          <CreationStudio
            currentProject={currentProject}
            onUpdateProject={handleUpdateProject}
          />
        )}

        {activeTab === 'BOM' && (
          <EngineeringBOM
            currentProject={currentProject}
            onUpdateProject={handleUpdateProject}
          />
        )}

        {activeTab === 'CONSTRUCTION' && (
          <ConstructionSimulator
            currentProject={currentProject}
            onUpdateProject={handleUpdateProject}
          />
        )}

        {activeTab === 'FINANCE' && (
          <ProjectFinance
            currentProject={currentProject}
            onUpdateProject={handleUpdateProject}
          />
        )}

        {activeTab === 'CDO' && <InfraCDO />}

        {activeTab === 'MARKET' && <MarketTrading />}

        {activeTab === 'ASSET_MGMT' && (
          <AssetManagement
            currentProject={currentProject}
            onUpdateProject={handleUpdateProject}
          />
        )}

        {activeTab === 'SCENARIO' && <ScenarioLab currentProject={currentProject} />}

        {activeTab === 'PROCUREMENT' && <Procurement currentProject={currentProject} />}

        {activeTab === 'IC_MEMO' && <InvestmentCommittee currentProject={currentProject} />}

        {activeTab === 'AI_ASSISTANT' && <RhinoAIAssistant currentProject={currentProject} />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 px-6 py-3 font-mono text-[10px] text-slate-500 flex flex-wrap justify-between items-center">
        <div>
          RHINOSYNTH’S INFRA • RHINO BANK INSTITUTIONAL PLATFORM
        </div>
        <div>
          DESIGN THE INFRASTRUCTURE BEFORE YOU BUILD IT.
        </div>
      </footer>
    </div>
  );
}
