# SECURITY & COMPLIANCE

## Security Standards

1. **API Key Isolation**: All Gemini API keys are maintained strictly server-side or via injected environment variables (`GEMINI_API_KEY`).
2. **Access Controls**: Role-Based Access Control (RBAC) separation between Engineering, Risk, Procurement, and Investment Committee roles.
3. **Data Integrity**: Input validation via TypeScript interfaces and runtime schema checks.
4. **Audit Logging**: All model parameter modifications are recorded in the audit event log with timestamps and user identifiers.
