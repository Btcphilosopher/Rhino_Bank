# ENGINEERING MODELS & BILL OF MATERIALS (BOM)

## Sector Engineering Specs

- **Transport**: Track geometry, gradients, rolling stock, station capacity, headways, passenger/freight throughput.
- **Energy**: Offshore wind turbine array sizing, HVDC cabling, electrolyser stack efficiency, hydrogen output.
- **Water**: Pipe pressure, deep tunnel storage buffer, pumping station megawatt requirements.
- **Digital**: Subsea optical fibre strand attenuation, bandwidth capacity, modular edge data center power draw.

## Commodity Materials Engine

Integrates live synthetic commodity prices:
- Structural Steel (`COMM-STEEL`)
- Ready-Mix Concrete (`COMM-CONCRETE`)
- LME Copper (`COMM-COPPER`)
- Aluminium (`COMM-ALUMINIUM`)
- Green Hydrogen (`COMM-HYDROGEN`)
- UK Base Power (`COMM-POWER`)

Price shifts in commodity benchmarks directly propagate into project CAPEX and financing requirements.
