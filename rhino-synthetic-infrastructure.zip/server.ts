import express from 'express';
import { createServer as createViteServer } from 'vite';
import { FLAGSHIP_NORTH_SEA_CORRIDOR, OTHER_SEED_PROJECTS, SEED_SECURITISED_BONDS, SEED_CDO_POOL, SEED_PORTFOLIO } from './src/data/flagshipProject';
import { runScenarioLab, runMonteCarloSimulation } from './src/engine/riskEngine';
import { calculateFinancingStructure } from './src/engine/financeEngine';
import { calculateCompositeIndexValue } from './src/engine/marketEngine';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Store in-memory projects database
  let projectsDb = [FLAGSHIP_NORTH_SEA_CORRIDOR, ...OTHER_SEED_PROJECTS];

  // API Routes
  app.get('/api/projects', (req, res) => {
    res.json(projectsDb);
  });

  app.get('/api/projects/:id', (req, res) => {
    const proj = projectsDb.find(p => p.asset_id === req.params.id || p.project_id === req.params.id);
    if (!proj) return res.status(404).json({ error: 'Project not found' });
    res.json(proj);
  });

  app.post('/api/projects/:id/simulate', (req, res) => {
    const proj = projectsDb.find(p => p.asset_id === req.params.id);
    if (!proj) return res.status(404).json({ error: 'Project not found' });
    const mc = runMonteCarloSimulation(proj, req.body.iterations || 1000);
    res.json(mc);
  });

  app.post('/api/projects/:id/stress', (req, res) => {
    const proj = projectsDb.find(p => p.asset_id === req.params.id);
    if (!proj) return res.status(404).json({ error: 'Project not found' });
    const scenarios = runScenarioLab(proj);
    res.json(scenarios);
  });

  app.get('/api/market', (req, res) => {
    const indexData = calculateCompositeIndexValue();
    res.json({
      index: indexData,
      securities: SEED_SECURITISED_BONDS,
      cdoPool: SEED_CDO_POOL
    });
  });

  app.get('/api/portfolio', (req, res) => {
    res.json({
      portfolio: SEED_PORTFOLIO,
      totalNotional: SEED_PORTFOLIO.reduce((a, b) => a + b.notional, 0)
    });
  });

  // Mount Vite development middleware in dev mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Rhino Synthetic Infrastructure Server running on port ${PORT}`);
  });
}

startServer();
