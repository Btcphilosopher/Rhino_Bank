# PROJECT FINANCE & SECURITISATION ENGINE

## Capital Structure

Total Project Cost = Base CAPEX + Land + Engineering + Interest During Construction + Contingency

Financed via:
- **Senior Debt**: 25-year amortizing facility with grace period during construction.
- **Mezzanine**: 15-year subordinated facility.
- **Subordinated Debt**: 12-year bullet facility.
- **Equity**: Sponsor equity providing first-loss protection.

## Key Financial Ratios

$$\text{DSCR} = \frac{\text{EBITDA}}{\text{Total Annual Debt Service}}$$

Target minimum DSCR: **1.30x**.

- **LLCR**: Loan Life Coverage Ratio.
- **PLCR**: Project Life Coverage Ratio.
- **NPV**: Discounted Cashflow Net Present Value at 7% hurdle rate over 50-year concession.
- **Equity IRR**: Levered equity return after debt service.

## Securitisation & Refinancing

Projects generate securitised senior notes and infrastructure bonds tradable on the Rhino Infra Desk. Operational assets can execute refinancing to replace construction debt with lower-coupon long-term bonds.
