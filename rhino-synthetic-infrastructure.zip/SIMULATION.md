# CAUSAL SIMULATION & SCENARIO LAB

## Causal Twin Engine

When physical or schedule parameters change, the causal engine automatically recalculates:
$$\text{Bridge Length} \rightarrow \text{Steel/Concrete Volume} \rightarrow \text{CAPEX} \rightarrow \text{Interest During Construction} \rightarrow \text{Debt Service} \rightarrow \text{DSCR / IRR}$$

## Monte Carlo Stochastic Engine

Runs 1,000+ iterations across triangular distributions for:
- CAPEX Noise (-37.5% to +37.5%)
- Demand Elasticity (-20% to +20%)
- Interest Rate Shifts (+/- 150bps)

Outputs **P5 (Downside)**, **P50 (Median)**, and **P95 (Upside)** metrics for CAPEX, IRR, and DSCR.

## Deterministic Macro Stress Scenarios

Includes predefined shocks:
1. Construction Delay (+18 Months)
2. CAPEX Overrun (+20% / +40%)
3. Demand Shortfall (-20%)
4. Interest Rates (+200bps Shock)
5. Energy Price Shock (+35%)
6. Systemic Infrastructure Shock
