# API DOCUMENTATION

## Endpoints

- `GET /api/projects`: List all active synthetic projects.
- `GET /api/projects/:id`: Get detailed metadata, BOM, schedule, and financials for project ID.
- `POST /api/projects/:id/simulate`: Run Monte Carlo simulation (Pass `{ "iterations": 1000 }`).
- `POST /api/projects/:id/stress`: Run scenario lab stress tests.
- `GET /api/market`: Get Rhino Infra-100 Index value, listed bonds, and CDO pool.
- `GET /api/portfolio`: Get institutional portfolio holdings and valuation.
