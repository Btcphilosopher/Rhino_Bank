# DATABASE & DATA PROVENANCE SCHEMA

## Core Entity Schemas

- `projects`: Master project records.
- `assets`: SyntheticInfrastructureAsset versioned records.
- `bom_items`: Material items, quantities, unit prices, supplier regions, carbon intensity.
- `debt_tranches`: Facility amounts, interest rates, tenures, amortization schedules.
- `revenue_streams`: Annual volumes, unit tariffs, demand elasticities.
- `construction_tasks`: Gantt tasks, phases, dependencies, critical path flags, delays.
- `machines`: Machinery fleet count, hourly rates, operational status.
- `physical_components`: Asset twin condition scores, inspection logs, ML failure risks.
- `audit_events`: Version, timestamp, calculation ID, user, previous state, new state.

## Data Provenance Policy

Every synthetic value is tagged with `source: SYNTHETIC_MODEL` or `GEMINI_AI_GEN`, alongside a unique `calculationId` and timestamp to ensure 100% reproducibility.
