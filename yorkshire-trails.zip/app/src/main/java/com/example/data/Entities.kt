package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routes")
data class RouteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val riding: String, // "West Riding", "North Riding", "East Riding"
    val distanceMiles: Double,
    val durationHours: Double,
    val elevationGainFeet: Int,
    val difficulty: String, // "Easy", "Moderate", "Challenging"
    val isCircular: Boolean,
    val surfaceType: String,
    val publicTransport: String,
    val parking: String,
    val description: String,
    val longDescription: String,
    val hazards: String, // Comma separated list
    val bestSeason: String,
    val suitableDogs: Boolean,
    val suitableChildren: Boolean,
    val wheelchairAccessible: Boolean,
    val wildSwimming: Boolean,
    val startCoords: String, // "lat,lng"
    val stopsCount: Int = 4
)

@Entity(tableName = "saved_routes")
data class SavedRouteEntity(
    @PrimaryKey val routeId: String,
    val isFavorite: Boolean,
    val isDownloaded: Boolean,
    val downloadedAt: Long = 0L
)

@Entity(tableName = "passport_stamps")
data class PassportStampEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // "Three Peaks", "National Trails", "National Parks", "Abbeys", "Castles"
    val description: String,
    val points: Int,
    val isUnlocked: Boolean,
    val unlockDate: Long = 0L
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String, // "user", "model"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profile")
data class ProfileEntity(
    @PrimaryKey val id: String = "current_user",
    val name: String,
    val subscriptionTier: String, // "Free", "Trails+", "Explorer+"
    val milesWalked: Double = 0.0,
    val stampsCollected: Int = 0
)
