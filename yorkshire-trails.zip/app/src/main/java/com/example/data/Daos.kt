package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RouteDao {
    @Query("SELECT * FROM routes")
    fun getAllRoutes(): Flow<List<RouteEntity>>

    @Query("SELECT * FROM routes WHERE id = :id")
    fun getRouteById(id: String): Flow<RouteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutes(routes: List<RouteEntity>)

    @Query("SELECT COUNT(*) FROM routes")
    suspend fun getRoutesCount(): Int
}

@Dao
interface SavedRouteDao {
    @Query("SELECT * FROM saved_routes")
    fun getSavedRoutes(): Flow<List<SavedRouteEntity>>

    @Query("SELECT * FROM saved_routes WHERE routeId = :routeId")
    fun getSavedRoute(routeId: String): Flow<SavedRouteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedRoute(savedRoute: SavedRouteEntity)

    @Delete
    suspend fun deleteSavedRoute(savedRoute: SavedRouteEntity)

    @Query("UPDATE saved_routes SET isDownloaded = :isDownloaded, downloadedAt = :time WHERE routeId = :routeId")
    suspend fun updateDownloadState(routeId: String, isDownloaded: Boolean, time: Long)
}

@Dao
interface PassportStampDao {
    @Query("SELECT * FROM passport_stamps")
    fun getAllStamps(): Flow<List<PassportStampEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStamps(stamps: List<PassportStampEntity>)

    @Update
    suspend fun updateStamp(stamp: PassportStampEntity)

    @Query("UPDATE passport_stamps SET isUnlocked = :isUnlocked, unlockDate = :time WHERE id = :id")
    suspend fun updateStampUnlockState(id: String, isUnlocked: Boolean, time: Long)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getChatHistory(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatHistory()
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 'current_user'")
    fun getProfile(): Flow<ProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity)

    @Update
    suspend fun updateProfile(profile: ProfileEntity)
}
