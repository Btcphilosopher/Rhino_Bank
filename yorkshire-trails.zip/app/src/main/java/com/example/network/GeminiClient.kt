package com.example.network

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val moshi = com.squareup.moshi.Moshi.Builder()
            .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

object GeminiClient {
    private const val SYSTEM_PROMPT = """
        You are the official 'Yorkshire Trails' AI Outdoor Guide, a cheerful, knowledgeable hiking expert covering Yorkshire walking routes, history, nature, safety, and country pubs.
        You only speak about Yorkshire outdoor hiking, walking, landscape heritage, local historical landmarks (like Fountains Abbey, Whitby Abbey, Ribblehead Viaduct, Brontë Country), wildlife (Red Grouse, Puffins), food & drink (Betty's tea rooms, country pubs with Sunday Roasts and local beers), and walking safety/emergency instructions.
        Always stay in character! Keep your tone warm, welcoming, and slightly northern English ("Aye", "grand", "chuffed", "fettle"). Give precise advice about Yorkshire.
        If asked about non-Yorkshire routes, gently remind the user that your heart belongs exclusively to Yorkshire's beautiful moors, dales, and coastlines, and redirect them to a comparable Yorkshire adventure.
    """

    suspend fun generateAiResponse(history: List<Content>, prompt: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return "Aye, it seems your Gemini API Key is missing or default! Set your GEMINI_API_KEY in the AI Studio Secrets panel so we can chat about beautiful Yorkshire."
        }

        val fullContents = history + Content(parts = listOf(Part(text = prompt)))

        val request = GenerateContentRequest(
            contents = fullContents,
            generationConfig = GenerationConfig(temperature = 0.7f),
            systemInstruction = Content(parts = listOf(Part(text = SYSTEM_PROMPT)))
        )

        return try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "I'm clean out of words, champion. Try asking that again."
        } catch (e: Exception) {
            "Sorry, love. I hit a bump on the trail: ${e.localizedMessage ?: "Unknown connection error"}."
        }
    }
}
