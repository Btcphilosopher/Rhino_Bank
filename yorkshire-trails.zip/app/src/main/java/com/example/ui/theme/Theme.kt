package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = BronzeWaymarkerLight,
    secondary = MoorlandGreenLight,
    tertiary = HeatherPurpleLight,
    background = MoorlandGreenDark,
    surface = DarkSurface,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = StoneGrey,
    onSurface = YorkshireStoneLight,
    surfaceVariant = LightSurfaceVariant
  )

private val LightColorScheme =
  darkColorScheme( // Force the premium dark bento theme for consistency as Yorkshire Trails is a custom experience
    primary = BronzeWaymarkerLight,
    secondary = MoorlandGreenLight,
    tertiary = HeatherPurpleLight,
    background = MoorlandGreenDark,
    surface = DarkSurface,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = StoneGrey,
    onSurface = YorkshireStoneLight,
    surfaceVariant = LightSurfaceVariant
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Set to false to preserve Yorkshire Trails Bento branding
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
