package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RouteEntity
import com.example.ui.components.SectionHeader
import com.example.ui.components.TrailWaymarkerBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun HomeScreen(
    viewModel: TrailsViewModel,
    onNavigateToRoute: (String) -> Unit,
    onNavigateToRoutesTab: (riding: String?) -> Unit,
    onNavigateToAiGuide: () -> Unit,
    onNavigateToEmergency: () -> Unit
) {
    val routes by viewModel.routes.collectAsState()
    val stamps by viewModel.stamps.collectAsState()
    val scrollState = rememberScrollState()

    val totalStamps = stamps.size
    val unlockedStamps = stamps.count { it.isUnlocked }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoorlandGreenDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 96.dp) // padding for bottom bar and edge-to-edge
        ) {
            // Bento Header (Yorkshire Trails, weather badge)
            HomeBentoHeader()

            Spacer(modifier = Modifier.height(12.dp))

            // AI Trail Assistant & Emergency SOS (Interactive Bento blocks)
            HomeHeroSection(onNavigateToAiGuide, onNavigateToEmergency)

            Spacer(modifier = Modifier.height(16.dp))

            // Weather & Sunrise/Sunset Details Card
            HomeWeatherSection()

            Spacer(modifier = Modifier.height(16.dp))

            // Today's Suggested Walk (Bento styled!)
            val suggested = routes.find { it.id == "yorkshire_three_peaks" } ?: routes.firstOrNull()
            if (suggested != null) {
                SuggestedWalkSection(route = suggested, onClick = { onNavigateToRoute(suggested.id) })
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Passport Peaks & History Info (Interactive Bento Blocks!)
            PassportHistoryBentoSection(
                unlockedCount = unlockedStamps,
                totalCount = totalStamps,
                onPassportClick = { onNavigateToRoutesTab(null) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Historic Ridings Explorer
            RidingsExplorerSection(onNavigateToRoutesTab)

            Spacer(modifier = Modifier.height(16.dp))

            // Trail Conditions Ticker
            TrailConditionsSection()

            Spacer(modifier = Modifier.height(16.dp))

            // Recent Community Photos
            CommunityPhotosSection()

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun HomeBentoHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, start = 16.dp, end = 16.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "OFFICIAL GUIDE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = BronzeWaymarkerLight,
                    letterSpacing = 2.sp
                )
            )
            Text(
                text = "Yorkshire Trails",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = YorkshireStoneLight
                )
            )
        }

        Row(
            modifier = Modifier
                .background(MoorlandGreenMedium, RoundedCornerShape(50))
                .border(BorderStroke(1.dp, MoorlandGreenLight), RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "14°C",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = YorkshireStoneLight,
                    fontWeight = FontWeight.Bold
                )
            )
            Icon(
                imageVector = Icons.Default.WbSunny,
                contentDescription = null,
                tint = Color(0xFFFFD700),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun HomeHeroSection(
    onNavigateToAiGuide: () -> Unit,
    onNavigateToEmergency: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // AI Trail Assistant Bento Box
        Card(
            modifier = Modifier
                .weight(2.3f)
                .height(130.dp)
                .clickable(onClick = onNavigateToAiGuide)
                .testTag("hero_chat_guide_button"),
            colors = CardDefaults.cardColors(containerColor = MoorlandGreenMedium),
            border = BorderStroke(1.dp, MoorlandGreenLight),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(BronzeWaymarkerLight.copy(alpha = 0.15f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = BronzeWaymarkerLight,
                            modifier = Modifier
                                .size(18.dp)
                                .align(Alignment.Center)
                        )
                    }
                    Text(
                        text = "Moorland AI",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BronzeWaymarkerLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Column {
                    Text(
                        text = "AI Trail Assistant",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = YorkshireStoneLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Ask about trail bogs & historic pubs",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StoneGrey,
                            fontSize = 10.sp
                        ),
                        maxLines = 1
                    )
                }
            }
        }

        // SOS Emergency Hotlink Bento Box
        Card(
            modifier = Modifier
                .weight(1f)
                .height(130.dp)
                .clickable(onClick = onNavigateToEmergency)
                .testTag("sos_direct_button"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF331616)),
            border = BorderStroke(1.dp, Color(0xFFD62828).copy(alpha = 0.5f)),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFD62828).copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "One-tap SOS Emergency",
                        tint = Color(0xFFF94A4A),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "EMERGENCY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFF94A4A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Text(
                        text = "SOS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun HomeWeatherSection() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MoorlandGreenMedium),
        border = BorderStroke(1.dp, MoorlandGreenLight),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = "Sun weather icon",
                        tint = BronzeWaymarkerLight,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "HORTON-IN-RIBBLESDALE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = BronzeWaymarkerLight,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = "17°C • Clear Skies",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = YorkshireStoneLight
                            )
                        )
                    }
                }
                Text(
                    text = "GRAND FETTLE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF90A955),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier
                        .background(MoorlandGreenLight.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MoorlandGreenLight, thickness = 1.dp)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                WeatherInfoItem(icon = Icons.Default.LightMode, label = "Sunrise", value = "04:58 AM")
                WeatherInfoItem(icon = Icons.Default.DarkMode, label = "Sunset", value = "09:14 PM")
                WeatherInfoItem(icon = Icons.Default.Air, label = "Wind", value = "8 mph NW")
            }
        }
    }
}

@Composable
fun WeatherInfoItem(icon: ImageVector, label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(imageVector = icon, contentDescription = label, tint = StoneGrey, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey))
        Text(text = value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = YorkshireStoneLight))
    }
}

@Composable
fun SuggestedWalkSection(route: RouteEntity, onClick: () -> Unit) {
    Column(modifier = Modifier.padding(top = 4.dp)) {
        SectionHeader(title = "Route of the Day", subtitle = "Hand-picked for today's weather")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .padding(horizontal = 16.dp)
                .clickable(onClick = onClick)
                .testTag("suggested_walk_card"),
            border = BorderStroke(1.dp, MoorlandGreenLight),
            shape = RoundedCornerShape(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(MoorlandGreenMedium, Color(0xFF141A12))
                        )
                    )
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = BronzeWaymarkerLight.copy(alpha = 0.08f),
                        radius = 350f,
                        center = Offset(size.width * 0.8f, size.height * 0.3f)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "ROUTE OF THE DAY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp
                            ),
                            modifier = Modifier
                                .background(BronzeWaymarkerLight, RoundedCornerShape(50))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )

                        TrailWaymarkerBadge(difficulty = route.difficulty)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = route.name,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    color = YorkshireStoneLight,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${route.distanceMiles} Miles • ${route.riding} • ${route.durationHours} hrs",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = StoneGrey,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.12f))
                                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Navigation,
                                contentDescription = "Go",
                                tint = YorkshireStoneLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PassportHistoryBentoSection(
    unlockedCount: Int,
    totalCount: Int,
    onPassportClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Passport Peaks Box
        Card(
            modifier = Modifier
                .weight(1f)
                .height(140.dp)
                .clickable(onClick = onPassportClick),
            colors = CardDefaults.cardColors(containerColor = MoorlandGreenMedium),
            border = BorderStroke(1.dp, MoorlandGreenLight),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BronzeWaymarkerLight.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MilitaryTech,
                            contentDescription = null,
                            tint = BronzeWaymarkerLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    val pct = if (totalCount > 0) (unlockedCount * 100) / totalCount else 0
                    Text(
                        text = "$pct%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BronzeWaymarkerLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Column {
                    Text(
                        text = "PASSPORT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StoneGrey,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "$unlockedCount/$totalCount Peaks",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = YorkshireStoneLight,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                }
            }
        }

        // History Abbeys & Priories Box
        Card(
            modifier = Modifier
                .weight(1f)
                .height(140.dp)
                .clickable(onClick = onPassportClick),
            colors = CardDefaults.cardColors(containerColor = HeatherPurple),
            border = BorderStroke(1.dp, HeatherPurpleBorder),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(HeatherPurpleLight.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = HeatherPurpleLight,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = "HISTORY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = HeatherPurpleLight,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Abbeys & Priories",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = YorkshireStoneLight,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun RidingsExplorerSection(onNavigateToRoutesTab: (String?) -> Unit) {
    Column {
        SectionHeader(title = "Three Ridings Explorer", subtitle = "Explore Yorkshire's historic kingdoms")

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val ridings = listOf(
                RidingItem("West Riding", "Dales & Fells", MoorlandGreenMedium, MoorlandGreenLight, "West Riding"),
                RidingItem("North Riding", "Moors & Coast", HeatherPurple, HeatherPurpleBorder, "North Riding"),
                RidingItem("East Riding", "Wolds & Cliffs", BronzeWaymarkerSurface, BronzeWaymarkerBorder, "East Riding")
            )

            ridings.forEach { item ->
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(115.dp)
                        .clickable { onNavigateToRoutesTab(item.filterValue) }
                        .testTag("riding_card_${item.name}"),
                    colors = CardDefaults.cardColors(containerColor = item.bgColor),
                    border = BorderStroke(1.dp, item.borderColor),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        val iconColor = when (item.name) {
                            "West Riding" -> MoorlandGreenPale
                            "North Riding" -> HeatherPurpleLight
                            else -> BronzeWaymarkerLight
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(iconColor.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terrain,
                                contentDescription = null,
                                tint = iconColor,
                                modifier = Modifier
                                    .size(16.dp)
                                    .align(Alignment.Center)
                            )
                        }

                        Column {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = YorkshireStoneLight
                                )
                            )
                            Text(
                                text = item.desc,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StoneGrey,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

data class RidingItem(
    val name: String,
    val desc: String,
    val bgColor: Color,
    val borderColor: Color,
    val filterValue: String
)

@Composable
fun TrailConditionsSection() {
    Column {
        SectionHeader(title = "Live Trail Conditions", subtitle = "Live community updates")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D241A)),
            border = BorderStroke(1.dp, MoorlandGreenLight),
            shape = RoundedCornerShape(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Terrain,
                    contentDescription = null,
                    tint = BronzeWaymarkerLight.copy(alpha = 0.04f),
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.BottomEnd)
                        .offset(x = 20.dp, y = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "LIVE CONDITIONS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StoneGrey,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Cleveland Way & Peaks",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = YorkshireStoneLight,
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                            val alpha by infiniteTransition.animateFloat(
                                initialValue = 0.4f,
                                targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1000, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "pulse_alpha"
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0xFF4CAF50).copy(alpha = alpha))
                            )
                            Text(
                                text = "Good trail conditions generally",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StoneGrey,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "“Pen-y-ghent summit path is fully dry. Peat section near Ribblehead is extremely boggy today. Gaiters recommended!”",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                color = StoneGrey
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(50))
                            .background(BronzeWaymarkerLight)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = "Map",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CommunityPhotosSection() {
    Column {
        SectionHeader(title = "Recent Community Photos", subtitle = "Shared by Yorkshire hikers")

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val photos = listOf(
                PhotoData("Ribblehead Viaduct Sunset", MoorlandGreenDark, HeatherPurpleBorder),
                PhotoData("Whitby Abbey Gothic Arch", HeatherPurple, YorkshireStoneLight),
                PhotoData("Moorland Purple Heather", MoorlandGreenLight, BronzeWaymarkerLight),
                PhotoData("Malham Cove Limestone", StoneGrey, MoorlandGreenMedium)
            )

            items(photos) { photo ->
                Column(
                    modifier = Modifier.width(130.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .border(BorderStroke(1.dp, MoorlandGreenLight), RoundedCornerShape(24.dp))
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(photo.color1, photo.color2)
                                )
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.4f),
                            modifier = Modifier
                                .size(28.dp)
                                .align(Alignment.Center)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = photo.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = YorkshireStoneLight
                        ),
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

data class PhotoData(val title: String, val color1: Color, val color2: Color)
