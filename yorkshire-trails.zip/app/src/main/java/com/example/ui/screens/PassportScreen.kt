package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PassportStampEntity
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun PassportScreen(viewModel: TrailsViewModel) {
    val stamps by viewModel.stamps.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val categories = listOf("All Stamps", "Three Peaks", "National Trails", "Abbeys", "Castles")

    var selectedStamp by remember { mutableStateOf<PassportStampEntity?>(null) }

    val filteredStamps = when (selectedTab) {
        0 -> stamps
        else -> stamps.filter { it.category.equals(categories[selectedTab], ignoreCase = true) }
    }

    val totalPoints = stamps.filter { it.isUnlocked }.sumOf { it.points }
    val unlockedCount = stamps.count { it.isUnlocked }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MoorlandGreenDark)
            .padding(bottom = 80.dp) // space for bottom nav
    ) {
        // Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MoorlandGreenDark)
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "YORKSHIRE PASSPORT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = BronzeWaymarkerLight,
                            letterSpacing = 1.5.sp
                        )
                    )
                    Text(
                        text = "Collect stamps & earn digital medals",
                        style = MaterialTheme.typography.labelSmall.copy(color = YorkshireStoneLight.copy(alpha = 0.7f))
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(BronzeWaymarker)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "$totalPoints XP",
                        style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // Stats Dashboard
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STAMPS UNLOCKED", style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold))
                    Text("$unlockedCount / ${stamps.size}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = YorkshireStoneLight))
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MILES RECORDED", style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold))
                    Text(String.format("%.1f mi", userProfile?.milesWalked ?: 0.0), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = YorkshireStoneLight))
                }
            }
        }

        // Categories Scrollbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEachIndexed { index, cat ->
                FilterChip(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    label = { Text(cat) },
                    modifier = Modifier.testTag("passport_category_chip_$cat")
                )
            }
        }

        // Stamps Grid
        if (filteredStamps.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No stamps in this category, love.", style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey))
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(filteredStamps) { stamp ->
                    PassportStampCard(stamp = stamp, onClick = { selectedStamp = stamp })
                }
            }
        }
    }

    // Stamp Details popup
    if (selectedStamp != null) {
        val s = selectedStamp!!
        AlertDialog(
            onDismissRequest = { selectedStamp = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MilitaryTech, contentDescription = null, tint = BronzeWaymarker)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
                }
            },
            text = {
                Column {
                    Text("CATEGORY: ${s.category.uppercase()}", style = MaterialTheme.typography.labelSmall.copy(color = BronzeWaymarker, fontWeight = FontWeight.Bold))
                    Text("POINTS: ${s.points} XP", style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(s.description, style = MaterialTheme.typography.bodyMedium, lineHeight = 20.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    if (s.isUnlocked) {
                        Text(
                            text = "✅ Officially Stamped on your passport!\nPoints added to your Yorkshire Rank.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MoorlandGreenMedium, fontWeight = FontWeight.Bold)
                        )
                    } else {
                        Text(
                            text = "🔒 Currently Locked. Walk associated trails or click Stamp Now to manually log your arrival for testing purposes.",
                            style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            },
            confirmButton = {
                if (!s.isUnlocked) {
                    Button(
                        onClick = {
                            viewModel.checkInLandmark(s.id)
                            selectedStamp = selectedStamp?.copy(isUnlocked = true) // immediate visual refresh in popup
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BronzeWaymarker)
                    ) {
                        Text("STAMP PASSPORT NOW", style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                    }
                }
                TextButton(onClick = { selectedStamp = null }) {
                    Text("CLOSE", style = MaterialTheme.typography.labelMedium.copy(color = StoneGrey))
                }
            },
            containerColor = YorkshireStoneLight
        )
    }
}

@Composable
fun PassportStampCard(
    stamp: PassportStampEntity,
    onClick: () -> Unit
) {
    val alphaFactor = if (stamp.isUnlocked) 1.0f else 0.4f
    val borderBrush = if (stamp.isUnlocked) {
        BorderStroke(2.dp, BronzeWaymarker)
    } else {
        BorderStroke(1.dp, StoneGrey.copy(alpha = 0.5f))
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .alpha(alphaFactor)
            .testTag("passport_stamp_card_${stamp.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Wooden Circle Stamp shape
        Box(
            modifier = Modifier
                .aspectRatio(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(50))
                .background(if (stamp.isUnlocked) YorkshireStoneLight else LightSurfaceVariant)
                .border(borderBrush, RoundedCornerShape(50))
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(
                    imageVector = if (stamp.isUnlocked) Icons.Default.Celebration else Icons.Default.MilitaryTech,
                    contentDescription = null,
                    tint = if (stamp.isUnlocked) BronzeWaymarker else StoneGrey,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${stamp.points} XP",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = if (stamp.isUnlocked) BronzeWaymarker else StoneGrey),
                    fontSize = 10.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = stamp.title,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
            maxLines = 1,
            lineHeight = 12.sp
        )
    }
}
