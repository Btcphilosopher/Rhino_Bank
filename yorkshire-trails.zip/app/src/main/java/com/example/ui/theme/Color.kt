package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Yorkshire Trails Premium Palette
val MoorlandGreenDark = Color(0xFF141A12) // Bento background
val MoorlandGreenMedium = Color(0xFF262F21) // Bento Surface Green
val MoorlandGreenLight = Color(0xFF3A4633) // Bento Border Green
val MoorlandGreenPale = Color(0xFF90A955)

val HeatherPurple = Color(0xFF332530) // Bento Surface Purple
val HeatherPurpleLight = Color(0xFFC4A4BE) // Bento Text Purple
val HeatherPurpleBorder = Color(0xFF4D3949) // Bento Border Purple

val BronzeWaymarker = Color(0xFFB27A29)
val BronzeWaymarkerLight = Color(0xFFA68A56) // Bento Accent Gold/Bronze
val BronzeWaymarkerSurface = Color(0xFF2A2118) // Bento Surface Bronze
val BronzeWaymarkerBorder = Color(0xFF413426) // Bento Border Bronze

val YorkshireStoneLight = Color(0xFFF2EFE9) // Bento Bright Warm White
val YorkshireStoneDark = Color(0xFF141A12) // Bento Background
val StoneGrey = Color(0xFFE0DDD5) // Bento Warm Cream Text

val DarkSurface = Color(0xFF262F21)
val LightSurface = Color(0xFF262F21)
val LightSurfaceVariant = Color(0xFF3A4633)


