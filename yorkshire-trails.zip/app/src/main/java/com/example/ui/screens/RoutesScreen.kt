package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RouteEntity
import com.example.ui.components.InfoChip
import com.example.ui.components.PremiumBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.TrailWaymarkerBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun RoutesScreen(
    viewModel: TrailsViewModel,
    onNavigateToActiveNav: () -> Unit,
    onUpgradeClick: () -> Unit
) {
    val selectedRoute by viewModel.selectedRoute.collectAsState()

    if (selectedRoute == null) {
        RoutesListScreen(viewModel = viewModel, onRouteClick = { viewModel.selectRoute(it.id) })
    } else {
        RouteDetailScreen(
            route = selectedRoute!!,
            viewModel = viewModel,
            onBack = { viewModel.selectRoute(null) },
            onNavigateToActiveNav = onNavigateToActiveNav,
            onUpgradeClick = onUpgradeClick
        )
    }
}

@Composable
fun RoutesListScreen(
    viewModel: TrailsViewModel,
    onRouteClick: (RouteEntity) -> Unit
) {
    val searchQuery by viewModel.routeSearchQuery.collectAsState()
    val routesList by viewModel.filteredRoutes.collectAsState()

    val currentDiffFilter by viewModel.difficultyFilter.collectAsState()
    val currentRidingFilter by viewModel.ridingFilter.collectAsState()
    val currentTagFilter by viewModel.tagFilter.collectAsState()

    var showFilters by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp) // space for bottom nav
    ) {
        // App Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MoorlandGreenDark)
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "YORKSHIRE TRAILS ROUTE LIBRARY",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = BronzeWaymarkerLight,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "Thousands of miles, waymarked & offline",
                        style = MaterialTheme.typography.labelSmall.copy(color = YorkshireStoneLight.copy(alpha = 0.7f))
                    )
                }

                IconButton(
                    onClick = { showFilters = !showFilters },
                    modifier = Modifier.testTag("filter_toggle_button")
                ) {
                    Icon(
                        imageVector = if (showFilters) Icons.Default.Close else Icons.Default.FilterList,
                        contentDescription = "Toggle Filter Options",
                        tint = YorkshireStoneLight
                    )
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setRouteSearchQuery(it) },
            label = { Text("Search routes by keyword...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("route_search_field"),
            shape = RoundedCornerShape(12.dp)
        )

        // Collapsing Filter Options Layout
        if (showFilters) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LightSurfaceVariant.copy(alpha = 0.5f))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("FILTER BY DIFFICULTY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = StoneGrey))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Easy", "Moderate", "Challenging").forEach { diff ->
                        FilterChip(
                            selected = currentDiffFilter == diff,
                            onClick = { viewModel.setDifficultyFilter(if (currentDiffFilter == diff) null else diff) },
                            label = { Text(diff) },
                            modifier = Modifier.testTag("chip_diff_$diff")
                        )
                    }
                }

                Text("FILTER BY REGION", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = StoneGrey))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("West Riding", "North Riding", "East Riding").forEach { riding ->
                        FilterChip(
                            selected = currentRidingFilter == riding,
                            onClick = { viewModel.setRidingFilter(if (currentRidingFilter == riding) null else riding) },
                            label = { Text(riding) },
                            modifier = Modifier.testTag("chip_riding_$riding")
                        )
                    }
                }

                Text("SUITABILITY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = StoneGrey))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Dog Friendly", "Family Friendly", "Wheelchair", "Wild Swimming").forEach { tag ->
                        FilterChip(
                            selected = currentTagFilter == tag,
                            onClick = { viewModel.setTagFilter(if (currentTagFilter == tag) null else tag) },
                            label = { Text(tag) },
                            modifier = Modifier.testTag("chip_tag_$tag")
                        )
                    }
                }
            }
        }

        // Active filter status indicator
        if (currentDiffFilter != null || currentRidingFilter != null || currentTagFilter != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Active filters in place",
                    style = MaterialTheme.typography.labelSmall.copy(color = MoorlandGreenMedium, fontWeight = FontWeight.Bold)
                )
                TextButton(
                    onClick = {
                        viewModel.setDifficultyFilter(null)
                        viewModel.setRidingFilter(null)
                        viewModel.setTagFilter(null)
                    },
                    modifier = Modifier.testTag("clear_filters_button")
                ) {
                    Text("Clear All", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                }
            }
        }

        // Route list results
        if (routesList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.DirectionsWalk,
                        contentDescription = "Empty routes",
                        tint = StoneGrey,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No Yorkshire routes match your criteria.", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Try clearing some filter tags, love.", style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey))
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(routesList) { route ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .clickable { onRouteClick(route) }
                            .testTag("route_list_card_${route.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = route.name,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold, color = MoorlandGreenDark)
                                    )
                                    Text(
                                        text = route.riding.uppercase(),
                                        style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold)
                                    )
                                }
                                TrailWaymarkerBadge(difficulty = route.difficulty)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = route.description,
                                style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey),
                                lineHeight = 16.sp,
                                maxLines = 2
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.TrendingUp, contentDescription = null, modifier = Modifier.size(16.dp), tint = StoneGrey)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${route.distanceMiles} mi", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(16.dp), tint = StoneGrey)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${route.durationHours} hrs", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Terrain, contentDescription = null, modifier = Modifier.size(16.dp), tint = StoneGrey)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${route.elevationGainFeet} ft climb", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RouteDetailScreen(
    route: RouteEntity,
    viewModel: TrailsViewModel,
    onBack: () -> Unit,
    onNavigateToActiveNav: () -> Unit,
    onUpgradeClick: () -> Unit
) {
    val savedState by viewModel.selectedRouteSavedState.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val scrollState = rememberScrollState()

    val isFavorite = savedState?.isFavorite ?: false
    val isDownloaded = savedState?.isDownloaded ?: false

    val subscriptionTier = userProfile?.subscriptionTier ?: "Free"
    val isPremiumUnlocked = subscriptionTier != "Free"

    Column(modifier = Modifier.fillMaxSize()) {
        // Detailed screen top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MoorlandGreenDark)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("route_detail_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to List", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TRAIL DETAILS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = BronzeWaymarkerLight,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Favorite Button
                IconButton(
                    onClick = { viewModel.toggleFavorite(route.id) },
                    modifier = Modifier.testTag("favorite_button")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite Trail",
                        tint = if (isFavorite) Color(0xFFD62828) else Color.White
                    )
                }

                // Offline Download Map Button
                IconButton(
                    onClick = {
                        if (isPremiumUnlocked) {
                            viewModel.toggleDownload(route.id)
                        } else {
                            onUpgradeClick()
                        }
                    },
                    modifier = Modifier.testTag("download_button")
                ) {
                    Icon(
                        imageVector = if (isDownloaded) Icons.Default.OfflinePin else Icons.Default.CloudDownload,
                        contentDescription = "Download Offline OS Map",
                        tint = if (isDownloaded) MoorlandGreenPale else Color.White
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(bottom = 80.dp)
        ) {
            // Visual Banner using clean typography and color gradient representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(MoorlandGreenMedium, HeatherPurple)
                        )
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    TrailWaymarkerBadge(difficulty = route.difficulty)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = route.name,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold, color = Color.White)
                    )
                    Text(
                        text = route.riding.uppercase() + " • YORKSHIRE",
                        style = MaterialTheme.typography.labelSmall.copy(color = YorkshireStoneLight.copy(alpha = 0.8f), fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    )
                }
            }

            // Quick Stats Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoChip(label = "Distance", value = "${route.distanceMiles} mi", icon = { Icon(Icons.Default.TrendingUp, contentDescription = null, tint = MoorlandGreenMedium) }, modifier = Modifier.weight(1f))
                InfoChip(label = "Ascent", value = "${route.elevationGainFeet} ft", icon = { Icon(Icons.Default.Terrain, contentDescription = null, tint = MoorlandGreenMedium) }, modifier = Modifier.weight(1f))
                InfoChip(label = "Duration", value = "${route.durationHours} h", icon = { Icon(Icons.Default.Timer, contentDescription = null, tint = MoorlandGreenMedium) }, modifier = Modifier.weight(1f))
            }

            // Hazard Alert Display
            if (route.hazards.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE3E3)),
                    border = BorderStroke(1.dp, Color(0xFFD62828).copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Hazard Alert", tint = Color(0xFFD62828))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "OFFICIAL ROUTE HAZARDS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFFD62828))
                            )
                            Text(
                                text = route.hazards,
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Black),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // Narrative Long Description
            SectionHeader(title = "Trail Story", subtitle = "Every mile tells a story")
            Text(
                text = route.longDescription,
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground),
                modifier = Modifier.padding(horizontal = 16.dp),
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Trail Attributes
            SectionHeader(title = "Logistics & Access", subtitle = "Wayfinding resources")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LightSurfaceVariant)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LogisticsRow(label = "Surface Material", value = route.surfaceType)
                LogisticsRow(label = "Public Transport Links", value = route.publicTransport)
                LogisticsRow(label = "Car Parking", value = route.parking)
                LogisticsRow(label = "Best Walking Season", value = route.bestSeason)
                LogisticsRow(label = "Water Availability", value = "Pubs & natural streams on trail")
                LogisticsRow(label = "Public Toilets", value = "At trailhead and towns")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Suitabilities Display
            SectionHeader(title = "Suitability Checklist")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SuitabilityBadge(label = "Dog Friendly", checked = route.suitableDogs)
                SuitabilityBadge(label = "Kids Friendly", checked = route.suitableChildren)
                SuitabilityBadge(label = "Wheelchair", checked = route.wheelchairAccessible)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Non-Premium warning banner if lock
            if (!isPremiumUnlocked) {
                PremiumBanner(onUpgradeClick = onUpgradeClick)
            } else {
                // PREMIUM: Start Navigation Button
                Button(
                    onClick = {
                        viewModel.startNavigation(route)
                        onNavigateToActiveNav()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoorlandGreenMedium),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .height(52.dp)
                        .testTag("start_nav_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "START INTERACTIVE NAVIGATION",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = Color.White)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun LogisticsRow(label: String, value: String) {
    Column {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = StoneGrey, letterSpacing = 0.5.sp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            lineHeight = 15.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
    }
}

@Composable
fun SuitabilityBadge(label: String, checked: Boolean) {
    val color = if (checked) MoorlandGreenMedium else StoneGrey.copy(alpha = 0.5f)
    Row(
        modifier = Modifier
            .border(1.dp, color, RoundedCornerShape(6.dp))
            .background(if (checked) color.copy(alpha = 0.08f) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.Cancel,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (checked) MoorlandGreenDark else StoneGrey
            )
        )
    }
}
