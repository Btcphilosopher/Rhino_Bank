package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repository.FoodDrinkItem
import com.example.repository.HistoricLandmark
import com.example.repository.WildlifeItem
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun DiscoverScreen(
    viewModel: TrailsViewModel,
    onNavigateToAiGuide: (initialPrompt: String?) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("History", "Wildlife", "Food & Drink")

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Screen Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MoorlandGreenDark)
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Column {
                    Text(
                        text = "DISCOVER YORKSHIRE",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = BronzeWaymarkerLight,
                            letterSpacing = 1.5.sp
                        )
                    )
                    Text(
                        text = "History, nature, and country pubs",
                        style = MaterialTheme.typography.labelMedium.copy(color = YorkshireStoneLight.copy(alpha = 0.7f))
                    )
                }
            }

            // Scrollable tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        },
                        modifier = Modifier.testTag("discover_tab_$title")
                    )
                }
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(bottom = 80.dp) // padding for bottom bar
            ) {
                when (selectedTab) {
                    0 -> HistoryTab(viewModel)
                    1 -> WildlifeTab(viewModel, onNavigateToAiGuide)
                    2 -> FoodDrinkTab(viewModel)
                }
            }
        }
    }
}

@Composable
fun HistoryTab(viewModel: TrailsViewModel) {
    val searchQuery by viewModel.landmarkSearch.collectAsState()
    val landmarks = viewModel.historicLandmarks
    var selectedLandmark by remember { mutableStateOf<HistoricLandmark?>(null) }

    val filtered = landmarks.filter {
        it.name.contains(searchQuery, ignoreCase = true) || 
        it.description.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setLandmarkSearch(it) },
            label = { Text("Search historic abbeys, castles, Roman roads...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("history_search_input"),
            shape = RoundedCornerShape(12.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(filtered) { landmark ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clickable { selectedLandmark = landmark }
                        .testTag("landmark_card_${landmark.name}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BronzeWaymarker.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            val icon = when (landmark.category.lowercase()) {
                                "abbey" -> Icons.Default.AccountBalance
                                "castle" -> Icons.Default.Fort
                                else -> Icons.Default.HistoryEdu
                            }
                            Icon(imageVector = icon, contentDescription = null, tint = BronzeWaymarker)
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = landmark.name,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = landmark.riding,
                                style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = landmark.description,
                                style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey),
                                maxLines = 2
                            )
                        }

                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = StoneGrey)
                    }
                }
            }
        }
    }

    // Historical details dialog
    if (selectedLandmark != null) {
        val l = selectedLandmark!!
        AlertDialog(
            onDismissRequest = { selectedLandmark = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = BronzeWaymarker)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(l.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
                }
            },
            text = {
                Column {
                    Text("RIDING: ${l.riding.uppercase()}", style = MaterialTheme.typography.labelSmall.copy(color = BronzeWaymarker, fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This location forms an integral part of Yorkshire's heritage. " +
                               "Whether it's the towering stone masonry of the Cistercian abbeys or the Victorian engineering triumphs on the moors, " +
                               "every stone here has survived centuries of history.\n\n" +
                               l.description + "\n\nPlan your walking routes around this landmark to scan it in your Yorkshire Passport!",
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedLandmark = null }) {
                    Text("CLOSE", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                }
            },
            containerColor = YorkshireStoneLight
        )
    }
}

@Composable
fun WildlifeTab(
    viewModel: TrailsViewModel,
    onNavigateToAiGuide: (initialPrompt: String?) -> Unit
) {
    val searchQuery by viewModel.wildlifeSearch.collectAsState()
    val wildlife = viewModel.wildlifeGuideList
    var selectedItem by remember { mutableStateOf<WildlifeItem?>(null) }

    val filtered = wildlife.filter {
        it.name.contains(searchQuery, ignoreCase = true) || 
        it.description.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // AI Recognition banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MoorlandGreenLight.copy(alpha = 0.12f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MoorlandGreenMedium, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("AI Naturalist Identifier", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MoorlandGreenDark))
                    Text("Spotted something on the trail? Ask the AI Assistant to identify plants, birds, or mushrooms.", style = MaterialTheme.typography.bodySmall.copy(color = MoorlandGreenDark))
                }
                IconButton(
                    onClick = { onNavigateToAiGuide("Help me identify a bird/plant/mushroom I spotted on my Yorkshire trail.") },
                    modifier = Modifier.testTag("ai_naturalist_button")
                ) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "Ask AI Naturalist", tint = MoorlandGreenMedium)
                }
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setWildlifeSearch(it) },
            label = { Text("Search birds, wildflowers, mammals, trees...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("wildlife_search_input"),
            shape = RoundedCornerShape(12.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(filtered) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { selectedItem = item }
                        .testTag("wildlife_card_${item.name}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MoorlandGreenLight.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            val icon = when (item.category.lowercase()) {
                                "birds" -> Icons.Default.FlutterDash
                                "wildflowers" -> Icons.Default.LocalFlorist
                                "mushrooms" -> Icons.Default.Spa
                                else -> Icons.Default.Pets
                            }
                            Icon(imageVector = icon, contentDescription = null, tint = MoorlandGreenMedium)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text(
                                "Category: ${item.category} • Habitat: ${item.preferredHabitat}",
                                style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey)
                            )
                        }

                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = StoneGrey)
                    }
                }
            }
        }
    }

    // Wildlife details dialog
    if (selectedItem != null) {
        val w = selectedItem!!
        AlertDialog(
            onDismissRequest = { selectedItem = null },
            title = { Text(w.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)) },
            text = {
                Column {
                    Text("CATEGORY: ${w.category.uppercase()}", style = MaterialTheme.typography.labelSmall.copy(color = MoorlandGreenMedium, fontWeight = FontWeight.Bold))
                    Text("PREFERRED HABITAT: ${w.preferredHabitat.uppercase()}", style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = w.description + "\n\nThis species is native to Yorkshire. Ensure you preserve our beautiful parks by sticking to public footpaths and carrying trash home.",
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { onNavigateToAiGuide("Tell me more about the ${w.name} species found in Yorkshire.") }) {
                    Text("ASK AI MORE", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                }
                TextButton(onClick = { selectedItem = null }) {
                    Text("CLOSE", style = MaterialTheme.typography.labelMedium.copy(color = StoneGrey))
                }
            },
            containerColor = YorkshireStoneLight
        )
    }
}

@Composable
fun FoodDrinkTab(viewModel: TrailsViewModel) {
    val searchQuery by viewModel.foodSearch.collectAsState()
    val filterRoast by viewModel.foodFilterSundayRoast.collectAsState()
    val filterBeer by viewModel.foodFilterLocalBeer.collectAsState()
    val foodList = viewModel.foodDrinkList

    val filtered = foodList.filter { item ->
        val matchesQuery = item.name.contains(searchQuery, ignoreCase = true) || 
                            item.description.contains(searchQuery, ignoreCase = true)
        val matchesRoast = !filterRoast || item.hasSundayRoast
        val matchesBeer = !filterBeer || item.hasLocalBeer
        matchesQuery && matchesRoast && matchesBeer
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setFoodSearch(it) },
            label = { Text("Search country pubs, cafés, bakeries...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("food_search_input"),
            shape = RoundedCornerShape(12.dp)
        )

        // Filter Tags
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterRoast,
                onClick = { viewModel.toggleFoodFilterSundayRoast() },
                label = { Text("Sunday Roast 🥩") },
                modifier = Modifier.testTag("filter_roast_chip")
            )
            FilterChip(
                selected = filterBeer,
                onClick = { viewModel.toggleFoodFilterLocalBeer() },
                label = { Text("Local Beer 🍺") },
                modifier = Modifier.testTag("filter_beer_chip")
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(filtered) { pub ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("food_card_${pub.name}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(BronzeWaymarker.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                               ) {
                                    Icon(
                                        imageVector = if (pub.type == "Pub") Icons.Default.SportsBar else Icons.Default.LocalCafe,
                                        contentDescription = null,
                                        tint = BronzeWaymarker
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(pub.name, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                                    Text(pub.location, style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey, fontWeight = FontWeight.Bold))
                                }
                            }
                            Text(
                                text = pub.type.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = BronzeWaymarker,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(pub.description, style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey), lineHeight = 16.sp)

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (pub.hasSundayRoast) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MoorlandGreenLight.copy(alpha = 0.12f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("Famous Sunday Roast", style = MaterialTheme.typography.labelSmall.copy(color = MoorlandGreenDark, fontWeight = FontWeight.Bold))
                                }
                            }
                            if (pub.hasLocalBeer) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(BronzeWaymarker.copy(alpha = 0.12f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("Real Yorkshire Cask Ale", style = MaterialTheme.typography.labelSmall.copy(color = BronzeWaymarker, fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
