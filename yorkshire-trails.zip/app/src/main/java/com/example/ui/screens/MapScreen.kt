package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun MapScreen(
    viewModel: TrailsViewModel,
    onUpgradeClick: () -> Unit
) {
    // Layer toggles
    var contourToggled by remember { mutableStateOf(true) }
    var satelliteToggled by remember { mutableStateOf(false) }
    var bridlewaysToggled by remember { mutableStateOf(true) }
    var woodlandToggled by remember { mutableStateOf(true) }
    var historicToggled by remember { mutableStateOf(true) }

    val userProfile by viewModel.userProfile.collectAsState()
    val isPremiumUnlocked = (userProfile?.subscriptionTier ?: "Free") != "Free"

    Box(modifier = Modifier.fillMaxSize()) {
        // Core Custom Map Renderer Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .background(if (satelliteToggled) Color(0xFF1E281E) else YorkshireStoneLight)
                .clickable { /* Simulate map tap to drop a waymarker */ }
                .testTag("map_cartography_canvas")
        ) {
            val w = size.width
            val h = size.height

            // 1. Draw Woodlands
            if (woodlandToggled) {
                drawCircle(color = if (satelliteToggled) Color(0xFF132A13) else Color(0xFFE2EFE0), radius = 180f, center = Offset(w * 0.25f, h * 0.35f))
                drawCircle(color = if (satelliteToggled) Color(0xFF132A13) else Color(0xFFE2EFE0), radius = 240f, center = Offset(w * 0.75f, h * 0.7f))
            }

            // 2. Draw Rivers
            val riverPath = Path()
            riverPath.moveTo(0f, h * 0.5f)
            riverPath.cubicTo(w * 0.3f, h * 0.4f, w * 0.6f, h * 0.7f, w, h * 0.6f)
            drawPath(
                path = riverPath,
                color = Color(0xFF5E97F6),
                style = Stroke(width = 12f)
            )

            // 3. Draw OS-Style Contour Lines (orange concentric height lines)
            if (contourToggled) {
                val contourColor = if (satelliteToggled) Color(0xFFD4A359).copy(alpha = 0.25f) else Color(0xFFE5C185)
                // Summit 1
                for (r in 1..5) {
                    drawCircle(color = contourColor, radius = r * 45f, center = Offset(w * 0.5f, h * 0.3f), style = Stroke(width = 2f))
                }
                // Summit 2 (Ingleborough Tabletop Style)
                for (r in 1..4) {
                    drawRect(color = contourColor, size = androidx.compose.ui.geometry.Size(r * 50f, r * 45f), topLeft = Offset(w * 0.15f - (r * 25f), h * 0.75f - (r * 22f)), style = Stroke(width = 2f))
                }
            }

            // 4. Draw Bridleways (red dashed path)
            if (bridlewaysToggled) {
                val path = Path()
                path.moveTo(w * 0.1f, h * 0.9f)
                path.lineTo(w * 0.3f, h * 0.75f)
                path.lineTo(w * 0.5f, h * 0.85f)
                path.lineTo(w * 0.9f, h * 0.65f)

                drawPath(
                    path = path,
                    color = Color(0xFFD62828),
                    style = Stroke(
                        width = 4f,
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    )
                )
            }
        }

        // Layer Toggles Floating Card (Anglo-Futurist styled)
        Card(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .statusBarsPadding()
                .testTag("map_layer_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "OS CARTOGRAPHY LAYERS",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold, color = BronzeWaymarker, letterSpacing = 1.sp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = contourToggled,
                        onClick = { contourToggled = !contourToggled },
                        label = { Text("Contours ⛰") },
                        modifier = Modifier.testTag("toggle_contours")
                    )
                    FilterChip(
                        selected = satelliteToggled,
                        onClick = { satelliteToggled = !satelliteToggled },
                        label = { Text("Satellite 🛰") },
                        modifier = Modifier.testTag("toggle_satellite")
                    )
                    FilterChip(
                        selected = bridlewaysToggled,
                        onClick = { bridlewaysToggled = !bridlewaysToggled },
                        label = { Text("Footpaths 🥾") },
                        modifier = Modifier.testTag("toggle_bridleways")
                    )
                    FilterChip(
                        selected = woodlandToggled,
                        onClick = { woodlandToggled = !woodlandToggled },
                        label = { Text("Woodlands 🌲") },
                        modifier = Modifier.testTag("toggle_woodland")
                    )
                }
            }
        }

        // Historic Sites Labels overlaid on Map
        if (historicToggled) {
            MapHistoricLabel(
                name = "Whitby Abbey Ruins",
                xOffset = 0.7f,
                yOffset = 0.45f,
                onClick = { /* Detail trigger */ }
            )
            MapHistoricLabel(
                name = "Ribblehead Viaduct",
                xOffset = 0.22f,
                yOffset = 0.62f,
                onClick = { /* Detail trigger */ }
            )
        }

        // Floating Calibration/Compass Indicator
        Box(
            modifier = Modifier
                .padding(bottom = 96.dp, end = 16.dp)
                .size(48.dp)
                .clip(RoundedCornerShape(50))
                .background(MoorlandGreenDark)
                .align(Alignment.BottomEnd)
                .border(1.dp, BronzeWaymarker, RoundedCornerShape(50))
                .clickable { /* Calibrate simulated GPS orientation */ },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.MyLocation,
                contentDescription = "Recenter GPS",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        // Non-premium offline message bar
        if (!isPremiumUnlocked) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 96.dp)
                    .align(Alignment.BottomCenter)
                    .clickable { onUpgradeClick() }
                    .testTag("offline_map_promo"),
                colors = CardDefaults.cardColors(containerColor = MoorlandGreenDark),
                border = BorderStroke(1.dp, BronzeWaymarker)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = BronzeWaymarkerLight)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("OFFLINE OS MAPS DETECTED", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BronzeWaymarkerLight))
                        Text("Upgrade to download full high-resolution Yorkshire offline map tiles.", style = MaterialTheme.typography.bodySmall.copy(color = YorkshireStoneLight), fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = YorkshireStoneLight)
                }
            }
        } else {
            // Premium offline success banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 96.dp)
                    .align(Alignment.BottomCenter),
                colors = CardDefaults.cardColors(containerColor = MoorlandGreenMedium),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Full offline vector map tiles cached (5.4 GB). You can safely head into areas with limited cell signal, champion!",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontWeight = FontWeight.Bold),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun BoxScope.MapHistoricLabel(
    name: String,
    xOffset: Float,
    yOffset: Float,
    onClick: () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val pxX = maxWidth * xOffset
        val pxY = maxHeight * yOffset

        Box(
            modifier = Modifier
                .absoluteOffset(x = pxX, y = pxY)
                .clip(RoundedCornerShape(8.dp))
                .background(BronzeWaymarker)
                .border(1.dp, Color.White, RoundedCornerShape(8.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(Icons.Default.Fort, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                Text(name, style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold), fontSize = 9.sp)
            }
        }
    }
}
