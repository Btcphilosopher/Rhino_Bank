package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun EmergencyScreen(viewModel: TrailsViewModel) {
    val scrollState = rememberScrollState()
    var isSosFlashing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MoorlandGreenDark)
            .verticalScroll(scrollState)
            .padding(bottom = 80.dp) // space for bottom nav
    ) {
        // SOS Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFD62828))
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Column {
                Text(
                    text = "EMERGENCY SAFETY HUBS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = 1.5.sp
                    )
                )
                Text(
                    text = "Offline coordinates & Mountain Rescue guides",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.8f))
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large One-Tap SOS Flasher Button
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isSosFlashing) Color(0xFFFFD6D6) else MaterialTheme.colorScheme.surface
            ),
            border = BorderStroke(2.dp, Color(0xFFD62828)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = { isSosFlashing = !isSosFlashing },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD62828)),
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(50))
                        .testTag("one_tap_sos_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Trigger Emergency Flasher",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isSosFlashing) "SOS EMERGENCY SIGNAL TRANSMITTING (SIMULATED)" else "ONE-TAP SOS BEACON",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = Color(0xFFD62828)),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Tapping flashes screen and triggers a loud safety whistle sound from your handset.",
                    style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey),
                    textAlign = TextAlign.Center,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Real-Time GPS / OS Grid Coordinates Card (Crucial for Mountain Rescue)
        SectionHeader(title = "Your Coordinates", subtitle = "These are compiled offline via device GPS")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("emergency_coords_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                CoordinateRow(label = "Ordnance Survey Grid Ref", value = "SE 0825 5410", isHighlighted = true)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                CoordinateRow(label = "GPS Lat/Long", value = "54.1492° N, 2.2858° W", isHighlighted = false)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                CoordinateRow(label = "Altitude Above Sea Level", value = "1,040 feet (317 meters)", isHighlighted = false)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                CoordinateRow(label = "Nearest Public Road", value = "B6255 Road Access (1.2 miles East)", isHighlighted = false)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                CoordinateRow(label = "Nearest Emergency Extraction Park", value = "Ribblehead Viaduct Car Park (1.5 miles North)", isHighlighted = false)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mountain Rescue Information
        SectionHeader(title = "Contacting Rescue Services", subtitle = "Dial 999 or 112")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MoorlandGreenDark),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = BronzeWaymarkerLight)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        "MOUNTAIN RESCUE INSTRUCTIONS",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BronzeWaymarkerLight, letterSpacing = 1.sp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "If you or your party are in immediate danger or severely injured on the fells:\n\n" +
                           "1. Dial 999 or 112 (Even if your network has 'No Service', your phone will try other networks for emergency).\n" +
                           "2. Ask for the POLICE.\n" +
                           "3. Once connected, ask for MOUNTAIN RESCUE.\n" +
                           "4. State your OS Grid Reference (SE 0825 5410) and your altitude.",
                    style = MaterialTheme.typography.bodySmall.copy(color = YorkshireStoneLight),
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Offline Emergency instructions
        SectionHeader(title = "Distress Signals & Protocols", subtitle = "How to call for help offline")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(LightSurfaceVariant)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ProtocolItem(
                title = "Whistle Distress Code",
                desc = "Blow your whistle 6 times in rapid succession, wait 1 minute, and repeat. Continue this until rescue arrive. Do not stop even if you hear a reply."
            )
            ProtocolItem(
                title = "Exposure / Hypothermia Safety",
                desc = "Find shelter out of the wind. Put on dry wool layers. Huddle together to preserve core body warmth. Put on waterproof shells even if it is not raining to trap heat."
            )
            ProtocolItem(
                title = "Peat Bog Rescue",
                desc = "If trapped in boggy peat, do not thrash. Lay flat on your back to distribute your weight across the grass. Use your walking poles to push yourself up slowly."
            )
            ProtocolItem(
                title = "Livestock Safety",
                desc = "When crossing sheep or cattle fields, walk calmly and keep your dog on a short lead. If cattle charge you, let go of the lead so your dog can escape safely."
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CoordinateRow(label: String, value: String, isHighlighted: Boolean) {
    Column {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (isHighlighted) BronzeWaymarker else StoneGrey,
                letterSpacing = 0.5.sp
            )
        )
        Text(
            text = value,
            style = if (isHighlighted) {
                MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = MoorlandGreenDark)
            } else {
                MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            }
        )
    }
}

@Composable
fun ProtocolItem(title: String, desc: String) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = MoorlandGreenDark)
        )
        Text(
            text = desc,
            style = MaterialTheme.typography.bodySmall.copy(color = MoorlandGreenDark.copy(alpha = 0.8f)),
            lineHeight = 15.sp
        )
    }
}
