package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.network.GeminiClient
import com.example.network.Content as GeminiContent
import com.example.network.Part as GeminiPart
import com.example.repository.TrailsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TrailsViewModel(
    application: Application,
    private val repository: TrailsRepository
) : AndroidViewModel(application) {

    // --- Database Data ---
    val routes: StateFlow<List<RouteEntity>> = repository.allRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedRoutes: StateFlow<List<SavedRouteEntity>> = repository.savedRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stamps: StateFlow<List<PassportStampEntity>> = repository.allStamps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatHistory: StateFlow<List<ChatMessageEntity>> = repository.chatHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<ProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- Search & Filters States ---
    private val _routeSearchQuery = MutableStateFlow("")
    val routeSearchQuery = _routeSearchQuery.asStateFlow()

    private val _difficultyFilter = MutableStateFlow<String?>(null) // "Easy", "Moderate", "Challenging"
    val difficultyFilter = _difficultyFilter.asStateFlow()

    private val _ridingFilter = MutableStateFlow<String?>(null) // "West Riding", "North Riding", "East Riding"
    val ridingFilter = _ridingFilter.asStateFlow()

    private val _tagFilter = MutableStateFlow<String?>(null) // "Dog Friendly", "Family Friendly", "Wheelchair", "Wild Swimming"
    val tagFilter = _tagFilter.asStateFlow()

    // Filtered Routes List
    val filteredRoutes: StateFlow<List<RouteEntity>> = combine(
        routes, _routeSearchQuery, _difficultyFilter, _ridingFilter, _tagFilter
    ) { routeList, query, diff, riding, tag ->
        routeList.filter { route ->
            val matchesQuery = route.name.contains(query, ignoreCase = true) || 
                               route.description.contains(query, ignoreCase = true)
            val matchesDiff = diff == null || route.difficulty.equals(diff, ignoreCase = true)
            val matchesRiding = riding == null || route.riding.equals(riding, ignoreCase = true)
            val matchesTag = when (tag) {
                "Dog Friendly" -> route.suitableDogs
                "Family Friendly" -> route.suitableChildren
                "Wheelchair" -> route.wheelchairAccessible
                "Wild Swimming" -> route.wildSwimming
                else -> true
            }
            matchesQuery && matchesDiff && matchesRiding && matchesTag
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Active Selection ---
    private val _selectedRouteId = MutableStateFlow<String?>(null)
    val selectedRouteId = _selectedRouteId.asStateFlow()

    val selectedRoute: StateFlow<RouteEntity?> = _selectedRouteId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getRouteById(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedRouteSavedState: StateFlow<SavedRouteEntity?> = _selectedRouteId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getSavedRouteState(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- AI Walking Guide States ---
    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading = _isAiLoading.asStateFlow()

    private val _aiError = MutableStateFlow<String?>(null)
    val aiError = _aiError.asStateFlow()

    // --- Interactive Navigation State ---
    private val _activeNavState = MutableStateFlow<ActiveNavigationState?>(null)
    val activeNavState = _activeNavState.asStateFlow()

    // --- Simulated Compass heading ---
    private val _compassHeading = MutableStateFlow(45f)
    val compassHeading = _compassHeading.asStateFlow()

    // --- Static local lists (from Repository) ---
    val historicLandmarks = repository.getHistoricLandmarks()
    val foodDrinkList = repository.getFoodAndDrinkList()
    val wildlifeGuideList = repository.getWildlifeGuide()

    // Search filters for Discover Section
    private val _landmarkSearch = MutableStateFlow("")
    val landmarkSearch = _landmarkSearch.asStateFlow()

    private val _foodSearch = MutableStateFlow("")
    val foodSearch = _foodSearch.asStateFlow()

    private val _foodFilterSundayRoast = MutableStateFlow(false)
    val foodFilterSundayRoast = _foodFilterSundayRoast.asStateFlow()

    private val _foodFilterLocalBeer = MutableStateFlow(false)
    val foodFilterLocalBeer = _foodFilterLocalBeer.asStateFlow()

    private val _wildlifeSearch = MutableStateFlow("")
    val wildlifeSearch = _wildlifeSearch.asStateFlow()

    // --- Initialization ---
    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.checkAndPrepopulate()
            // Randomly rotate compass for fidelity
            launch {
                while (true) {
                    delay(2000)
                    val base = _compassHeading.value
                    val delta = (-5..5).random().toFloat()
                    _compassHeading.value = (base + delta + 360) % 360
                }
            }
        }
    }

    // --- Route Selection ---
    fun selectRoute(routeId: String?) {
        _selectedRouteId.value = routeId
    }

    // --- Saved Route Controls ---
    fun toggleFavorite(routeId: String) = viewModelScope.launch(Dispatchers.IO) {
        repository.toggleFavorite(routeId)
    }

    fun toggleDownload(routeId: String) = viewModelScope.launch(Dispatchers.IO) {
        repository.toggleDownload(routeId)
    }

    // --- Search & Filters Controls ---
    fun setRouteSearchQuery(query: String) { _routeSearchQuery.value = query }
    fun setDifficultyFilter(diff: String?) { _difficultyFilter.value = diff }
    fun setRidingFilter(riding: String?) { _ridingFilter.value = riding }
    fun setTagFilter(tag: String?) { _tagFilter.value = tag }

    fun setLandmarkSearch(query: String) { _landmarkSearch.value = query }
    fun setFoodSearch(query: String) { _foodSearch.value = query }
    fun toggleFoodFilterSundayRoast() { _foodFilterSundayRoast.value = !_foodFilterSundayRoast.value }
    fun toggleFoodFilterLocalBeer() { _foodFilterLocalBeer.value = !_foodFilterLocalBeer.value }
    fun setWildlifeSearch(query: String) { _wildlifeSearch.value = query }

    // --- Passport Gamification ---
    fun checkInLandmark(stampId: String) = viewModelScope.launch(Dispatchers.IO) {
        repository.unlockStamp(stampId)
    }

    fun manualResetStamps() = viewModelScope.launch(Dispatchers.IO) {
        // Simple helper to reset progress if testing
        stamps.value.forEach { stamp ->
            repository.unlockStamp(stamp.id)
        }
    }

    // --- AI Chat Assistant Integration ---
    fun sendAiMessage(prompt: String) = viewModelScope.launch(Dispatchers.IO) {
        if (prompt.isBlank() || _isAiLoading.value) return@launch
        _isAiLoading.value = true
        _aiError.value = null

        // Add user message to DB
        repository.addChatMessage("user", prompt)

        // Get past chat messages to supply as context
        val rawHistory = chatHistory.value
        val historyToSend = rawHistory.map {
            GeminiContent(parts = listOf(GeminiPart(text = it.content)))
        }

        val responseText = GeminiClient.generateAiResponse(historyToSend, prompt)

        // Save model message
        repository.addChatMessage("model", responseText)
        _isAiLoading.value = false
    }

    fun clearAiChat() = viewModelScope.launch(Dispatchers.IO) {
        repository.clearChat()
    }

    // --- Simulated Interactive Navigation ---
    fun startNavigation(route: RouteEntity) {
        val stops = listOf(
            "Trailhead Start",
            "Waymarker Post 1 (${route.riding})",
            "Halfway Viewpoint Scramble",
            "Final Summit Peak / High Edge",
            "Trail End Finish"
        )
        _activeNavState.value = ActiveNavigationState(
            route = route,
            isNavigating = true,
            currentStopIndex = 0,
            distanceRemainingMiles = route.distanceMiles,
            timeRemainingHours = route.durationHours,
            stopsList = stops,
            voiceInstruction = "Aye up! Welcome to ${route.name}. Stand by the starting point and head North toward the first marker.",
            compassDirection = "North",
            hazardWarning = null
        )
    }

    fun stopNavigation() {
        _activeNavState.value = null
    }

    fun advanceNavigation() = viewModelScope.launch(Dispatchers.IO) {
        val current = _activeNavState.value ?: return@launch
        val nextIndex = current.currentStopIndex + 1
        
        if (nextIndex >= current.stopsList.size) {
            // Completed Hike!
            repository.recordHikeCompleted(current.route.id, current.route.distanceMiles)
            _activeNavState.value = current.copy(
                currentStopIndex = nextIndex,
                distanceRemainingMiles = 0.0,
                timeRemainingHours = 0.0,
                isNavigating = false,
                voiceInstruction = "Grand job, champion! You've walked every mile of ${current.route.name}. Passport stamp unlocked!"
            )
        } else {
            val progressFactor = (current.stopsList.size - nextIndex).toDouble() / current.stopsList.size.toDouble()
            val newDist = current.route.distanceMiles * progressFactor
            val newTime = current.route.durationHours * progressFactor
            
            // Randomly trigger seasonal/terrain hazard warning for realism
            val randomHazard = if (nextIndex == 2 && current.route.hazards.isNotBlank()) {
                val list = current.route.hazards.split(",")
                "⚠ Caution: ${list.random().trim()}"
            } else null

            val instructions = listOf(
                "Keep going, grand pace. Follow the acorn path markers along the hillside.",
                "Slight scramble here, love. Mind your footing on the limestone pavement.",
                "You're near the high viewpoint. Take a minute to soak in the views across the dales.",
                "Heading down now. Follow the drystone wall straight to the finish gate."
            )
            val nextInstruction = instructions.getOrNull(nextIndex - 1) ?: "Proceed to the next waymarker."

            _activeNavState.value = current.copy(
                currentStopIndex = nextIndex,
                distanceRemainingMiles = Math.round(newDist * 10.0) / 10.0,
                timeRemainingHours = Math.round(newTime * 10.0) / 10.0,
                voiceInstruction = nextInstruction,
                hazardWarning = randomHazard,
                compassDirection = listOf("North", "North East", "East", "South East", "West").random()
            )
        }
    }

    // --- Profile Actions ---
    fun updateProfileName(name: String) = viewModelScope.launch(Dispatchers.IO) {
        repository.updateProfileName(name)
    }

    fun upgradeSubscription(tier: String) = viewModelScope.launch(Dispatchers.IO) {
        repository.updateSubscriptionTier(tier)
    }
}

data class ActiveNavigationState(
    val route: RouteEntity,
    val isNavigating: Boolean,
    val currentStopIndex: Int,
    val distanceRemainingMiles: Double,
    val timeRemainingHours: Double,
    val stopsList: List<String>,
    val voiceInstruction: String,
    val compassDirection: String,
    val hazardWarning: String? = null
)

class TrailsViewModelFactory(
    private val application: Application,
    private val repository: TrailsRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TrailsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TrailsViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
