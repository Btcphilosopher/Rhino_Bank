package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TopographicBackground
import com.example.ui.theme.*
import com.example.ui.viewmodel.ActiveNavigationState
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun NavigationActiveScreen(
    viewModel: TrailsViewModel,
    onBackToRoutes: () -> Unit
) {
    val navState by viewModel.activeNavState.collectAsState()
    val compassAngle by viewModel.compassHeading.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseOutQuad),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_radius"
    )

    if (navState == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active hike navigation. Choose a route and tap Start!", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    val state = navState!!

    Box(modifier = Modifier.fillMaxSize()) {
        // Fullscreen Topographic background mapping
        TopographicBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE NAVIGATION ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = BronzeWaymarker,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = state.route.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                    )
                }
                IconButton(
                    onClick = {
                        viewModel.stopNavigation()
                        onBackToRoutes()
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(50))
                        .testTag("exit_nav_button")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Exit Navigation", tint = Color.Black)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Hazard warning flashers
            if (state.hazardWarning != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFD6D6)),
                    border = BorderStroke(1.5.dp, Color.Red),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.hazardWarning,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = Color.Red)
                        )
                    }
                }
            }

            // Simulated GPS Map and Compass Screen Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Custom Breadcrumb Trail Drawing on Canvas
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Path representing route
                        val routePath = Path()
                        routePath.moveTo(w * 0.2f, h * 0.8f)
                        routePath.quadraticTo(w * 0.4f, h * 0.4f, w * 0.6f, h * 0.5f)
                        routePath.quadraticTo(w * 0.7f, h * 0.6f, w * 0.8f, h * 0.2f)

                        drawPath(
                            path = routePath,
                            color = MoorlandGreenLight,
                            style = Stroke(width = 8f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(20f, 10f), 0f))
                        )

                        // Draw static stops along the way
                        val stopCoords = listOf(
                            Offset(w * 0.2f, h * 0.8f),
                            Offset(w * 0.38f, h * 0.48f),
                            Offset(w * 0.62f, h * 0.52f),
                            Offset(w * 0.8f, h * 0.2f)
                        )

                        stopCoords.forEachIndexed { index, coord ->
                            val color = if (index <= state.currentStopIndex) MoorlandGreenMedium else StoneGrey.copy(alpha = 0.5f)
                            drawCircle(color = color, radius = 12f, center = coord)
                            drawCircle(color = Color.White, radius = 6f, center = coord)
                        }

                        // Current animated user blue dot location
                        val userCoord = stopCoords.getOrNull(state.currentStopIndex) ?: stopCoords.last()
                        drawCircle(
                            color = Color(0xFF2F80ED).copy(alpha = 1f - (pulseRadius - 10f) / 30f),
                            radius = pulseRadius,
                            center = userCoord
                        )
                        drawCircle(color = Color(0xFF2F80ED), radius = 14f, center = userCoord)
                        drawCircle(color = Color.White, radius = 6f, center = userCoord)
                    }

                    // Floating OS-style Compass Mode Card
                    Box(
                        modifier = Modifier
                            .padding(16.dp)
                            .size(100.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MoorlandGreenDark)
                            .align(Alignment.TopEnd)
                            .border(2.dp, BronzeWaymarkerLight, RoundedCornerShape(50)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.rotate(-compassAngle)
                        ) {
                            Text("N", style = MaterialTheme.typography.labelSmall.copy(color = Color.Red, fontWeight = FontWeight.ExtraBold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Icon(
                                imageVector = Icons.Default.Navigation,
                                contentDescription = "Compass arrow",
                                tint = BronzeWaymarkerLight,
                                modifier = Modifier
                                    .size(24.dp)
                                    .rotate(180f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(state.compassDirection, style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                        }
                    }

                    // Bottom info overlays
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "CURRENT WAYPOINT: ${state.stopsList.getOrNull(state.currentStopIndex) ?: "Finished"}",
                            style = MaterialTheme.typography.labelMedium.copy(color = BronzeWaymarkerLight, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = state.voiceInstruction,
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Statistics Dashboard
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavStatColumn(
                        icon = Icons.Default.TrendingDown,
                        label = "Remaining",
                        value = "${state.distanceRemainingMiles} mi"
                    )
                    NavStatColumn(
                        icon = Icons.Default.HourglassEmpty,
                        label = "ETA Finish",
                        value = if (state.timeRemainingHours > 0) "${state.timeRemainingHours} hrs" else "Arrived!"
                    )
                    NavStatColumn(
                        icon = Icons.Default.SettingsVoice,
                        label = "Voice Assist",
                        value = "ON • English"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Simulated controls to advance GPS
            if (state.currentStopIndex < state.stopsList.size) {
                Button(
                    onClick = { viewModel.advanceNavigation() },
                    colors = ButtonDefaults.buttonColors(containerColor = BronzeWaymarker),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("advance_gps_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "ADVANCE SIMULATED GPS POSITION",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = Color.White)
                    )
                }
            } else {
                Button(
                    onClick = {
                        viewModel.stopNavigation()
                        onBackToRoutes()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoorlandGreenMedium),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("complete_hike_return_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Celebration, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("HIKE COMPLETED! GO TO PASSPORT", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                }
            }
        }
    }
}

@Composable
fun NavStatColumn(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(imageVector = icon, contentDescription = null, tint = StoneGrey, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = StoneGrey))
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MoorlandGreenDark))
    }
}
