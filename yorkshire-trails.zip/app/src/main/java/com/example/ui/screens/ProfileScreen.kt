package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel

@Composable
fun ProfileScreen(viewModel: TrailsViewModel) {
    val userProfile by viewModel.userProfile.collectAsState()

    var showEditName by remember { mutableStateOf(false) }
    var currentInputName by remember { mutableStateOf("") }

    val nameToShow = userProfile?.name ?: "Yorkshire Rambler"
    val subTier = userProfile?.subscriptionTier ?: "Free"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MoorlandGreenDark)
            .padding(bottom = 80.dp) // space for bottom nav
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MoorlandGreenDark)
                .padding(horizontal = 16.dp, vertical = 24.dp)
        ) {
            Column {
                Text(
                    text = "WALKER PROFILE",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = BronzeWaymarkerLight,
                        letterSpacing = 1.5.sp
                    )
                )
                Text(
                    text = "Manage your hiking log and subscriptions",
                    style = MaterialTheme.typography.labelSmall.copy(color = YorkshireStoneLight.copy(alpha = 0.7f))
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Profile details card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AYE UP,",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = StoneGrey, letterSpacing = 1.sp)
                        )
                        Text(
                            text = nameToShow.uppercase(),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold, color = MoorlandGreenDark),
                            modifier = Modifier.testTag("profile_walker_name")
                        )
                    }

                    IconButton(
                        onClick = {
                            currentInputName = nameToShow
                            showEditName = true
                        },
                        modifier = Modifier.testTag("edit_name_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit walker name", tint = BronzeWaymarker)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = BronzeWaymarker)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Current Tier: $subTier Account",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = MoorlandGreenMedium)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Subscription Tier Selector (Interactive pricing cards)
        SectionHeader(title = "Yorkshire Membership Plans", subtitle = "Unlock navigation and offline topographical OS maps")
        
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val plans = listOf(
                SubscriptionPlan("Free", "Basic routes, GPS coordinates, weather reports", "Free of Charge"),
                SubscriptionPlan("Trails+", "Everything above, Offline OS maps, AI guide assistant, GPS Navigation", "£29 / year"),
                SubscriptionPlan("Explorer+", "Everything above, Audio hiking tours, walking challenges, emergency satellite assist", "£59 / year")
            )

            plans.forEach { plan ->
                val isCurrentPlan = subTier.equals(plan.name, ignoreCase = true)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.upgradeSubscription(plan.name) }
                        .testTag("subscription_plan_${plan.name}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCurrentPlan) MoorlandGreenMedium.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        width = if (isCurrentPlan) 2.dp else 1.dp,
                        color = if (isCurrentPlan) MoorlandGreenMedium else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = plan.name.uppercase(),
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isCurrentPlan) MoorlandGreenDark else MaterialTheme.colorScheme.onBackground
                                    )
                                )
                                if (isCurrentPlan) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Active plan",
                                        tint = MoorlandGreenMedium,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Text(
                                text = plan.desc,
                                style = MaterialTheme.typography.bodySmall.copy(color = StoneGrey),
                                lineHeight = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Text(
                            text = plan.price,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = BronzeWaymarker
                            )
                        )
                    }
                }
            }
        }
    }

    // Name Editor dialog
    if (showEditName) {
        AlertDialog(
            onDismissRequest = { showEditName = false },
            title = { Text("Update Walker Name", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) },
            text = {
                OutlinedTextField(
                    value = currentInputName,
                    onValueChange = { currentInputName = it },
                    label = { Text("Your Walker Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("name_edit_input"),
                    shape = RoundedCornerShape(8.dp)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (currentInputName.isNotBlank()) {
                            viewModel.updateProfileName(currentInputName)
                            showEditName = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BronzeWaymarker),
                    modifier = Modifier.testTag("save_name_button")
                ) {
                    Text("SAVE", style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                }
                TextButton(onClick = { showEditName = false }) {
                    Text("CANCEL", style = MaterialTheme.typography.labelMedium.copy(color = StoneGrey))
                }
            },
            containerColor = YorkshireStoneLight
        )
    }
}

data class SubscriptionPlan(val name: String, val desc: String, val price: String)
