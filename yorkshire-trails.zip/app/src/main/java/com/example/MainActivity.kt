package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.AppDatabase
import com.example.repository.TrailsRepository
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TrailsViewModel
import com.example.ui.viewmodel.TrailsViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = TrailsRepository(database)

        setContent {
            MyApplicationTheme {
                MainAppScreen(repository)
            }
        }
    }
}

data class BottomNavItem(
    val title: String,
    val route: String,
    val icon: ImageVector
)

@Composable
fun MainAppScreen(repository: TrailsRepository) {
    val navController = rememberNavController()
    val viewModel: TrailsViewModel = viewModel(
        factory = TrailsViewModelFactory(
            application = androidx.compose.ui.platform.LocalContext.current.applicationContext as android.app.Application,
            repository = repository
        )
    )

    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route

    val navItems = listOf(
        BottomNavItem("Home", "home", Icons.Default.Home),
        BottomNavItem("Discover", "discover", Icons.Default.Explore),
        BottomNavItem("Map", "map", Icons.Default.Map),
        BottomNavItem("Routes", "routes", Icons.Default.DirectionsWalk),
        BottomNavItem("Passport", "passport", Icons.Default.MilitaryTech),
        BottomNavItem("Profile", "profile", Icons.Default.Person)
    )

    // Only show bottom navigation on the 6 primary tabs
    val showBottomBar = currentRoute in listOf("home", "discover", "map", "routes", "passport", "profile")

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = Color(0xFF1B2217),
                    contentColor = BronzeWaymarkerLight,
                    modifier = Modifier.testTag("main_bottom_nav_bar")
                ) {
                    navItems.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BronzeWaymarkerLight,
                                selectedTextColor = BronzeWaymarkerLight,
                                unselectedIconColor = Color(0xFF5E6C58),
                                unselectedTextColor = Color(0xFF5E6C58),
                                indicatorColor = Color(0xFF262F21)
                            ),
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            },
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToRoute = { routeId ->
                        viewModel.selectRoute(routeId)
                        navController.navigate("routes")
                    },
                    onNavigateToRoutesTab = { riding ->
                        viewModel.setRidingFilter(riding)
                        navController.navigate("routes")
                    },
                    onNavigateToAiGuide = {
                        navController.navigate("ai_guide")
                    },
                    onNavigateToEmergency = {
                        navController.navigate("emergency")
                    }
                )
            }
            composable("discover") {
                DiscoverScreen(
                    viewModel = viewModel,
                    onNavigateToAiGuide = { initialPrompt ->
                        navController.navigate("ai_guide")
                    }
                )
            }
            composable("map") {
                MapScreen(
                    viewModel = viewModel,
                    onUpgradeClick = { navController.navigate("profile") }
                )
            }
            composable("routes") {
                RoutesScreen(
                    viewModel = viewModel,
                    onNavigateToActiveNav = { navController.navigate("active_nav") },
                    onUpgradeClick = { navController.navigate("profile") }
                )
            }
            composable("passport") {
                PassportScreen(viewModel = viewModel)
            }
            composable("profile") {
                ProfileScreen(viewModel = viewModel)
            }
            composable("ai_guide") {
                AIGuideScreen(viewModel = viewModel)
            }
            composable("emergency") {
                EmergencyScreen(viewModel = viewModel)
            }
            composable("active_nav") {
                NavigationActiveScreen(
                    viewModel = viewModel,
                    onBackToRoutes = { navController.popBackStack() }
                )
            }
        }
    }
}
