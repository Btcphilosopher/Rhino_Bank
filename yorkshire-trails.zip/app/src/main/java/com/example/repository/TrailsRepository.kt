package com.example.repository

import com.example.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map

class TrailsRepository(private val database: AppDatabase) {

    private val routeDao = database.routeDao()
    private val savedRouteDao = database.savedRouteDao()
    private val passportStampDao = database.passportStampDao()
    private val chatMessageDao = database.chatMessageDao()
    private val profileDao = database.profileDao()

    val allRoutes: Flow<List<RouteEntity>> = routeDao.getAllRoutes()
    val savedRoutes: Flow<List<SavedRouteEntity>> = savedRouteDao.getSavedRoutes()
    val allStamps: Flow<List<PassportStampEntity>> = passportStampDao.getAllStamps()
    val chatHistory: Flow<List<ChatMessageEntity>> = chatMessageDao.getChatHistory()
    val userProfile: Flow<ProfileEntity?> = profileDao.getProfile()

    fun getRouteById(id: String): Flow<RouteEntity?> = routeDao.getRouteById(id)
    fun getSavedRouteState(routeId: String): Flow<SavedRouteEntity?> = savedRouteDao.getSavedRoute(routeId)

    suspend fun toggleFavorite(routeId: String) {
        val currentState = savedRouteDao.getSavedRoute(routeId).firstOrNull()
        if (currentState == null) {
            savedRouteDao.insertSavedRoute(SavedRouteEntity(routeId = routeId, isFavorite = true, isDownloaded = false))
        } else {
            savedRouteDao.insertSavedRoute(currentState.copy(isFavorite = !currentState.isFavorite))
        }
    }

    suspend fun toggleDownload(routeId: String) {
        val currentState = savedRouteDao.getSavedRoute(routeId).firstOrNull()
        if (currentState == null) {
            savedRouteDao.insertSavedRoute(SavedRouteEntity(routeId = routeId, isFavorite = false, isDownloaded = true, downloadedAt = System.currentTimeMillis()))
        } else {
            savedRouteDao.insertSavedRoute(currentState.copy(
                isDownloaded = !currentState.isDownloaded,
                downloadedAt = if (!currentState.isDownloaded) System.currentTimeMillis() else 0L
            ))
        }
    }

    suspend fun unlockStamp(stampId: String) {
        val currentStamp = passportStampDao.getAllStamps().firstOrNull()?.find { it.id == stampId }
        if (currentStamp != null && !currentStamp.isUnlocked) {
            passportStampDao.updateStampUnlockState(stampId, true, System.currentTimeMillis())
            // Also update user profile stamps count & miles if appropriate
            updateProfileStats()
        }
    }

    suspend fun addChatMessage(role: String, content: String) {
        chatMessageDao.insertMessage(ChatMessageEntity(role = role, content = content))
    }

    suspend fun clearChat() {
        chatMessageDao.clearChatHistory()
    }

    suspend fun updateProfileName(newName: String) {
        val current = profileDao.getProfile().firstOrNull()
        if (current != null) {
            profileDao.updateProfile(current.copy(name = newName))
        } else {
            profileDao.insertProfile(ProfileEntity(name = newName, subscriptionTier = "Free"))
        }
    }

    suspend fun updateSubscriptionTier(newTier: String) {
        val current = profileDao.getProfile().firstOrNull()
        if (current != null) {
            profileDao.updateProfile(current.copy(subscriptionTier = newTier))
        } else {
            profileDao.insertProfile(ProfileEntity(name = "Yorkshire Explorer", subscriptionTier = newTier))
        }
    }

    suspend fun recordHikeCompleted(routeId: String, miles: Double) {
        val current = profileDao.getProfile().firstOrNull()
        if (current != null) {
            profileDao.updateProfile(current.copy(milesWalked = current.milesWalked + miles))
        } else {
            profileDao.insertProfile(ProfileEntity(name = "Yorkshire Explorer", subscriptionTier = "Free", milesWalked = miles))
        }
        // Unlock associated stamp if matching
        when (routeId) {
            "cleveland_way" -> unlockStamp("cleveland_way_trail")
            "yorkshire_wolds_way" -> unlockStamp("wolds_way_trail")
            "pennine_way_dales" -> unlockStamp("pennine_way_trail")
            "yorkshire_three_peaks" -> {
                unlockStamp("y3p")
                unlockStamp("penyghent")
                unlockStamp("whernside")
                unlockStamp("ingleborough")
            }
        }
    }

    private suspend fun updateProfileStats() {
        val currentProfile = profileDao.getProfile().firstOrNull()
        val stamps = passportStampDao.getAllStamps().firstOrNull() ?: emptyList()
        val unlockedCount = stamps.count { it.isUnlocked }
        if (currentProfile != null) {
            profileDao.updateProfile(currentProfile.copy(stampsCollected = unlockedCount))
        }
    }

    suspend fun checkAndPrepopulate() {
        if (routeDao.getRoutesCount() == 0) {
            // Populate standard Trails
            routeDao.insertRoutes(getPrepopulatedRoutes())
            // Populate standard Passport Stamps
            passportStampDao.insertStamps(getPrepopulatedStamps())
            // Initialize default Profile
            profileDao.insertProfile(ProfileEntity(name = "Yorkshire Rambler", subscriptionTier = "Free"))
        }
    }

    private fun getPrepopulatedRoutes(): List<RouteEntity> {
        return listOf(
            RouteEntity(
                id = "cleveland_way",
                name = "Cleveland Way National Trail",
                riding = "North Riding",
                distanceMiles = 109.0,
                durationHours = 45.0,
                elevationGainFeet = 10500,
                difficulty = "Challenging",
                isCircular = false,
                surfaceType = "Earth, coastal sandstone tracks & rocky cliff steps",
                publicTransport = "Direct trains from York to Scarborough/Whitby, Coastliner buses",
                parking = "Multiple public car parks at Helmsley and coastal towns",
                description = "A spectacular 109-mile journey crossing the wild purple heather of the North York Moors before tracing the high dramatic sandstone coastline from Whitby to Filey.",
                longDescription = "The Cleveland Way offers some of the most dynamic hiking in Britain. Starting in the pleasant market town of Helmsley, the trail leads past Rievaulx Abbey and across the sweeping heights of Sutton Bank. It soon plunges into the northern edge of the North York Moors National Park, climbing Roseberry Topping before meeting the North Sea at Saltburn. From there, it follows dramatic coastlines past Staithes, Whitby Abbey, and Robin Hood's Bay, ending peacefully at Filey Brigg. It is well-waymarked with the acorn symbol of England's National Trails.",
                hazards = "Cliff edges, slippery steps, seasonal high winds, limited coastal mobile signal",
                bestSeason = "Summer & Autumn",
                suitableDogs = true,
                suitableChildren = false,
                wheelchairAccessible = false,
                wildSwimming = true,
                startCoords = "54.2464,-1.0264"
            ),
            RouteEntity(
                id = "yorkshire_wolds_way",
                name = "Yorkshire Wolds Way National Trail",
                riding = "East Riding",
                distanceMiles = 79.0,
                durationHours = 32.0,
                elevationGainFeet = 4200,
                difficulty = "Moderate",
                isCircular = false,
                surfaceType = "Chalk woodland tracks, rolling grass valleys, and farm fields",
                publicTransport = "Train to Hessle, local buses to Thixendale and Filey",
                parking = "Hessle Foreshore car park, street parking in Wolds villages",
                description = "A peaceful 79-mile walk through the quietest corner of Yorkshire, tracing rolling chalk hills, deep dry valleys, and tranquil agricultural tablelands.",
                longDescription = "Starting under the massive Humber Bridge at Hessle, the Yorkshire Wolds Way winds northward through open agricultural valleys, peaceful woodland slopes, and picturesque villages like South Cave and Thixendale. This is the chalk heartland immortalized by artist David Hockney. The walking is gentle but rewarding, offering panoramic vistas of the Vale of York and the North Sea coast. The route finishes at the limestone outcrop of Filey Brigg, merging beautifully with the end of the Cleveland Way.",
                hazards = "Boggy fields in winter, livestock in pastures, isolated villages with limited water",
                bestSeason = "Spring & Summer",
                suitableDogs = true,
                suitableChildren = true,
                wheelchairAccessible = false,
                wildSwimming = false,
                startCoords = "53.7175,-0.4346"
            ),
            RouteEntity(
                id = "yorkshire_three_peaks",
                name = "Yorkshire Three Peaks Challenge",
                riding = "West Riding",
                distanceMiles = 24.0,
                durationHours = 12.0,
                elevationGainFeet = 5200,
                difficulty = "Challenging",
                isCircular = true,
                surfaceType = "Flagged stone pathways, scree slopes, and peat bogs",
                publicTransport = "Ribblehead or Horton-in-Ribblesdale railway stations (Settle-Carlisle line)",
                parking = "Large public car parks in Horton-in-Ribblesdale and Ribblehead",
                description = "The classic Yorkshire challenge. Climb Pen-y-ghent, Whernside, and Ingleborough in a single 24-mile circular trail.",
                longDescription = "The Yorkshire Three Peaks Challenge takes in the peaks of Pen-y-ghent (2,277 ft), Whernside (2,415 ft), and Ingleborough (2,372 ft), usually completed in under 12 hours. Starting from the charming stone village of Horton-in-Ribblesdale, walkers head up the crouched giant profile of Pen-y-ghent, descend past the massive Ribblehead Viaduct, climb the ridge of Whernside (the highest peak in Yorkshire), and face the steep limestone scramble of Ingleborough before returning. The views across the Settle-Carlisle railway line and the limestone scars are legendary.",
                hazards = "Steep craggy scrambles, boggy peat ground, extreme weather changes, limited water stations",
                bestSeason = "Spring to Autumn",
                suitableDogs = true,
                suitableChildren = false,
                wheelchairAccessible = false,
                wildSwimming = false,
                startCoords = "54.1492,-2.2858"
            ),
            RouteEntity(
                id = "pennine_way_dales",
                name = "Pennine Way (Yorkshire Dales Section)",
                riding = "West Riding",
                distanceMiles = 55.0,
                durationHours = 24.0,
                elevationGainFeet = 6500,
                difficulty = "Challenging",
                isCircular = false,
                surfaceType = "Limestone paving, rough moorland grass, and flagged stone paths",
                publicTransport = "Train to Gargrave, buses to Malham and Hawes",
                parking = "Malham National Park Centre car park, Hawes car parks",
                description = "A rugged section of England's first National Trail, spanning Gargrave up to Tan Hill, taking in Malham Cove, Pen-y-ghent, and Hawes.",
                longDescription = "The Pennine Way represents the backbone of England, and its Yorkshire Dales section is arguably its most visually breathtaking. Beginning in Gargrave, the trail wanders past Malham's iconic limestone amphitheater (Malham Cove) and Malham Tarn. From there, it ascends the dramatic west face of Pen-y-ghent, descends into the gorgeous stone market town of Hawes (home of Wensleydale Cheese), and climbs over Great Shunner Fell to finish at the legendary Tan Hill Inn, the highest pub in Great Britain.",
                hazards = "Deep boggy moss, extreme weather on fells, steep vertical drops at Malham, navigation in mist",
                bestSeason = "Summer",
                suitableDogs = true,
                suitableChildren = false,
                wheelchairAccessible = false,
                wildSwimming = true,
                startCoords = "53.9877,-2.1028"
            ),
            RouteEntity(
                id = "dales_way_wharfedale",
                name = "The Dales Way: Wharfedale Rambler",
                riding = "West Riding",
                distanceMiles = 30.0,
                durationHours = 12.5,
                elevationGainFeet = 1800,
                difficulty = "Moderate",
                isCircular = false,
                surfaceType = "Riverside grass tracks, stone stile steps, and gravel lanes",
                publicTransport = "Regular trains to Ilkley, bus service connecting Grassington",
                parking = "Ilkley main car park, Yorkshire Dales National Park car park in Grassington",
                description = "A classic and picturesque riverside walk tracing the elegant curves of the River Wharfe from Ilkley to Kettlewell.",
                longDescription = "The Dales Way is a highly popular 80-mile trail, but its prime Yorkshire portion runs 30 miles from the Victorian spa town of Ilkley to the higher dales villages. Walkers trace the banks of the bubbling River Wharfe, passing the majestic ruins of Bolton Priory, the dangerous and narrow 'Strid' channel, the limestone gorge of Burnsall, and the stone-walled village of Grassington. The trail is framed by green dry-stone-walled meadows, grazing sheep, and broad fells.",
                hazards = "Slippery river stones, narrow stiles, seasonal breeding livestock in pastures",
                bestSeason = "Spring & Summer",
                suitableDogs = true,
                suitableChildren = true,
                wheelchairAccessible = true, // portions near Bolton Priory are accessible
                wildSwimming = true,
                startCoords = "53.9298,-1.8211"
            ),
            RouteEntity(
                id = "roseberry_topping",
                name = "Roseberry Topping & Captain Cook's Circular",
                riding = "North Riding",
                distanceMiles = 7.5,
                durationHours = 3.5,
                elevationGainFeet = 1150,
                difficulty = "Moderate",
                isCircular = true,
                surfaceType = "Stone step paths, pine woodland tracks, and heather paths",
                publicTransport = "Train to Great Ayton railway station",
                parking = "Newton-under-Roseberry car park",
                description = "Hike the iconic 'Yorkshire Matterhorn' before walking the high heather ridges of Easby Moor to Captain Cook's Monument.",
                longDescription = "Roseberry Topping is an iconic conical hill with a dramatic half-collapsed profile caused by a landslip in 1912. This route climbs steeply up its well-paved stone stairs to reveal spectacular 360-degree views of Cleveland and the North York Moors. It then descends through peaceful oak woodlands, crosses heather-rich Cleveland hillsides, and climbs to Captain Cook's Monument, a massive sandstone obelisk erected in memory of the famous explorer who grew up in the valleys below.",
                hazards = "Steep slippery steps near summit, gusty winds at the peak",
                bestSeason = "Spring & Autumn",
                suitableDogs = true,
                suitableChildren = true,
                wheelchairAccessible = false,
                wildSwimming = false,
                startCoords = "54.4983,-1.1119"
            ),
            RouteEntity(
                id = "flamborough_cliffs",
                name = "Flamborough Head & Bempton Sea Caves",
                riding = "East Riding",
                distanceMiles = 8.0,
                durationHours = 3.5,
                elevationGainFeet = 650,
                difficulty = "Easy",
                isCircular = true,
                surfaceType = "Clifftop soil paths, wooden boardwalks, and coastal farm lanes",
                publicTransport = "Train to Bridlington, local explorer bus to Flamborough lighthouse",
                parking = "Flamborough Head Lighthouse car park",
                description = "Explore dramatic chalk arches, active sea caves, and England's premier nesting puffin colonies on Bempton Cliffs.",
                longDescription = "A flat but breathtaking clifftop circular starting at the historic Flamborough Head Lighthouse. Hike along the bright white chalk cliffs overlooking the churning North Sea. Watch out for massive chalk stacks (such as 'Drinking Dinosaur') and explore secluded rockpools at Selwicks Bay. The path goes north to RSPB Bempton Cliffs, where over half a million seabirds nest on the sheer vertical rock walls. Between April and July, puffins, gannets, and kittiwakes are easily spotted from the timber viewing platforms.",
                hazards = "Unfenced cliff edges, crumbling chalk margins, steep beach access steps",
                bestSeason = "Spring (for puffins) & Summer",
                suitableDogs = true,
                suitableChildren = true,
                wheelchairAccessible = true, // RSPB Bempton boardwalks are highly accessible
                wildSwimming = true,
                startCoords = "54.1162,-0.0818"
            ),
            RouteEntity(
                id = "bronte_waterfall",
                name = "Brontë Waterfall & Top Withens Moorland",
                riding = "West Riding",
                distanceMiles = 6.8,
                durationHours = 3.0,
                elevationGainFeet = 850,
                difficulty = "Moderate",
                isCircular = true,
                surfaceType = "Moorland sand tracks, stone-flagged bog routes, and village streets",
                publicTransport = "Haworth steam railway from Keighley, local buses to Haworth Main Street",
                parking = "Haworth Bronte Parsonage Museum car park",
                description = "Walk from Haworth across atmospheric heather moors to the Brontë Waterfall and the desolate ruins of Top Withens.",
                longDescription = "A literary pilgrimage through the landscape that inspired the Brontë sisters. Starting in Haworth with its historic steep cobbled main street, the trail climbs onto Haworth Moor, following a stream up to the wooden footbridge and rock cascades of the Brontë Waterfall. The path continues climbing through the wild heather to Top Withens, a derelict, wind-battered farmhouse believed to be the inspiration for Heathcliff's home in Emily Brontë's 'Wuthering Heights'. Returns via Penistone Hill country park.",
                hazards = "Exposure to high winds, cold driving rain, peat bogs off-trail",
                bestSeason = "Autumn (when heather is bright purple)",
                suitableDogs = true,
                suitableChildren = true,
                wheelchairAccessible = false,
                wildSwimming = false,
                startCoords = "53.8315,-1.9613"
            )
        )
    }

    private fun getPrepopulatedStamps(): List<PassportStampEntity> {
        return listOf(
            PassportStampEntity("y3p", "Yorkshire Three Peaks", "Three Peaks", "Complete the full 24-mile circular hike of Pen-y-ghent, Whernside, and Ingleborough under 12 hours.", 50, false),
            PassportStampEntity("penyghent", "Pen-y-ghent Explorer", "Three Peaks", "Climb to the summit of Pen-y-ghent (2,277 ft) and enjoy the view of Settle.", 15, false),
            PassportStampEntity("whernside", "Whernside Explorer", "Three Peaks", "Climb to the summit of Whernside (2,415 ft), the highest peak in Yorkshire.", 15, false),
            PassportStampEntity("ingleborough", "Ingleborough Explorer", "Three Peaks", "Climb the flat-topped limestone plateau of Ingleborough (2,372 ft).", 15, false),

            PassportStampEntity("cleveland_way_trail", "Cleveland Way Master", "National Trails", "Conquer the Cleveland Way from Helmsley around the Moors and coast to Filey.", 100, false),
            PassportStampEntity("wolds_way_trail", "Wolds Way Wanderer", "National Trails", "Hike the rolling chalk valleys of the Yorkshire Wolds Way.", 80, false),
            PassportStampEntity("pennine_way_trail", "Pennine Way Pathfinder", "National Trails", "Hike the wild fells of the Yorkshire Dales on the Pennine Way.", 100, false),

            PassportStampEntity("dales_explorer", "Yorkshire Dales Badge", "National Parks", "Walk any trail in the stunning Yorkshire Dales National Park.", 30, false),
            PassportStampEntity("moors_explorer", "North York Moors Badge", "National Parks", "Hike through the purple heather seas of the North York Moors National Park.", 30, false),

            PassportStampEntity("rievaulx_abbey", "Rievaulx Abbey Stamp", "Abbeys", "Explore the ancient Cistercian arches of Rievaulx Abbey near Helmsley.", 20, false),
            PassportStampEntity("whitby_abbey", "Whitby Abbey Stamp", "Abbeys", "Climb the 199 steps in Whitby to the Gothic cliff ruins of Whitby Abbey.", 25, false),
            PassportStampEntity("fountains_abbey", "Fountains Abbey Stamp", "Abbeys", "Visit the ruins and water gardens of Fountains Abbey World Heritage site.", 25, false),

            PassportStampEntity("richmond_castle", "Richmond Castle Stamp", "Castles", "Walk around the historic Norman keep of Richmond Castle.", 20, false),
            PassportStampEntity("scarborough_castle", "Scarborough Castle Stamp", "Castles", "Climb the clifftop fortress of Scarborough Castle overlooking the twin bays.", 20, false)
        )
    }

    // --- Static content helper to supply local history, food & drink, wildlife ---
    fun getHistoricLandmarks(): List<HistoricLandmark> {
        return listOf(
            HistoricLandmark("Whitby Abbey", "North Riding", "Gothic abbey ruins overlooking the North Sea, famous as Bram Stoker's Dracula inspiration.", "Abbey"),
            HistoricLandmark("Ribblehead Viaduct", "West Riding", "A magnificent 24-arch stone railway viaduct built in 1870 by over 2,300 navvies.", "Industrial"),
            HistoricLandmark("Rievaulx Abbey", "North Riding", "One of England's most complete Cistercian ruins, tucked in a secluded wooded valley.", "Abbey"),
            HistoricLandmark("Top Withens", "West Riding", "The desolate, atmospheric farmhouse ruin on Haworth Moor that inspired Emily Brontë.", "Bronte"),
            HistoricLandmark("Fountains Abbey", "West Riding", "A spectacular ruined Cistercian monastery set inside Studley Royal Water Garden.", "Abbey"),
            HistoricLandmark("Scarborough Castle", "North Riding", "A dominant headland fortress with 3,000 years of history overlooking Scarborough's bays.", "Castle")
        )
    }

    fun getFoodAndDrinkList(): List<FoodDrinkItem> {
        return listOf(
            FoodDrinkItem("Tan Hill Inn", "West Riding (Reeth)", "The highest pub in Great Britain (1,732 ft) offering roaring fires and giant Yorkshire puddings.", "Pub", hasSundayRoast = true, hasLocalBeer = true),
            FoodDrinkItem("Betty's Cafe Tea Rooms", "West Riding (Harrogate)", "Elegant, legendary tea room serving tea and Yorkshire Fat Rascals.", "Tea Room", hasSundayRoast = false, hasLocalBeer = false),
            FoodDrinkItem("The Lister Arms", "West Riding (Malham)", "Cozy, traditional coaching inn offering roaring log fires and excellent Yorkshire puddings.", "Pub", hasSundayRoast = true, hasLocalBeer = true),
            FoodDrinkItem("The Wolds Inn", "East Riding (Huggate)", "A warm 17th-century country pub in the quiet heart of the chalk hills.", "Pub", hasSundayRoast = true, hasLocalBeer = true),
            FoodDrinkItem("Botham's of Whitby", "North Riding (Whitby)", "Traditional Yorkshire family bakery famous for Whitby Gingerbread and plum bread.", "Baker", hasSundayRoast = false, hasLocalBeer = false),
            FoodDrinkItem("The Black Swan", "North Riding (Oldstead)", "World-renowned Michelin-starred farm-to-table dining celebrating regional Yorkshire produce.", "Restaurant", hasSundayRoast = false, hasLocalBeer = true)
        )
    }

    fun getWildlifeGuide(): List<WildlifeItem> {
        return listOf(
            WildlifeItem("Red Grouse", "Birds", "A beautiful red-brown wild game bird unique to heather moorlands. Famous for its dry barking cry.", "moors"),
            WildlifeItem("Atlantic Puffin", "Birds", "A charming clifftop seabird with a brightly colored bill. Nests in deep chalk crevices at Bempton Cliffs.", "cliffs"),
            WildlifeItem("Northern Marsh Orchid", "Wildflowers", "A striking dark magenta-purple orchid blooming in wet Yorkshire dales grasslands.", "meadows"),
            WildlifeItem("Roe Deer", "Mammals", "A graceful, reddish-brown forest deer often spotted silently browsing in rural Yorkshire woodlands.", "woods"),
            WildlifeItem("Scarlet Hood Mushroom", "Mushrooms", "A glossy, scarlet-red cap mushroom found in autumn across unimproved Yorkshire pastures.", "fields")
        )
    }
}

data class HistoricLandmark(val name: String, val riding: String, val description: String, val category: String)
data class FoodDrinkItem(val name: String, val location: String, val description: String, val type: String, val hasSundayRoast: Boolean, val hasLocalBeer: Boolean)
data class WildlifeItem(val name: String, val category: String, val description: String, val preferredHabitat: String)
