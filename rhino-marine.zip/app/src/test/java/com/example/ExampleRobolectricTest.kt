package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Rhino Marine", appName)
    }

    @Test
    fun `launch dashboard switch language to chinese and navigate to parametric designer and api console`() {
        composeTestRule.waitForIdle()

        // Verify English initial title & simulation banner
        composeTestRule.onAllNodesWithText("RHINO MARINE CHINA").onFirst().assertIsDisplayed()
        composeTestRule.onNodeWithTag("simulation_banner").assertIsDisplayed()

        // Switch to Simplified Chinese while preserving state
        composeTestRule.onNodeWithTag("language_switch_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onAllNodesWithText("RHINO MARINE CHINA 犀牛海运中国").onFirst().assertIsDisplayed()

        // Navigate to Parametric Products Designer via bottom bar
        composeTestRule.onNodeWithTag("bottom_nav_parametric_designer").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("parametric_test_payout_readout")
            .performScrollTo()
            .assertIsDisplayed()

        // Navigate to API Console and execute a live request
        composeTestRule.onNodeWithTag("bottom_nav_api_console").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("execute_api_button")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("api_response_card")
            .performScrollTo()
            .assertIsDisplayed()
        composeTestRule.onAllNodesWithText("HTTP 201", substring = true)
            .onFirst()
            .performScrollTo()
            .assertIsDisplayed()
    }
}
