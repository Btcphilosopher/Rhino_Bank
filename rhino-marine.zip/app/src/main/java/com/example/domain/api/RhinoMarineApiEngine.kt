package com.example.domain.api

import com.example.domain.engine.PricingAndParametricEngine
import com.example.domain.engine.StructuredDomainException
import com.example.domain.model.AgentRunRecord
import com.example.domain.model.ApiAuditEntry
import com.example.domain.model.ClaimRecord
import com.example.domain.model.ClaimStage
import com.example.domain.model.CurrencyCode
import com.example.domain.model.FeedStatus
import com.example.domain.model.IssuanceAuthority
import com.example.domain.model.Money
import com.example.domain.model.ObservationEvent
import com.example.domain.model.ObservationFinalisationStatus
import com.example.domain.model.ParametricProductConfig
import com.example.domain.model.PolicyRecord
import com.example.domain.model.ProductFamily
import com.example.domain.model.ProductType
import com.example.domain.model.ProposedSettlement
import com.example.domain.model.QuoteRecord
import com.example.domain.model.QuoteStatus
import com.example.domain.workflow.WorkflowAndCurrencyEngine
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.security.MessageDigest
import java.time.Instant
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class ApiRequest(
    val method: String,
    val path: String,
    val tenantId: String,
    val apiKey: String = "rmc_live_demo_key_cn_01",
    val oauthBearer: String? = null,
    val idempotencyKey: String? = null,
    val authority: IssuanceAuthority = IssuanceAuthority.AUTHORIZED_UNDERWRITER,
    val bodyJson: String = "{}"
)

data class ApiResponse(
    val statusCode: Int,
    val requestId: String,
    val idempotentReplay: Boolean,
    val bodyJson: String,
    val headers: Map<String, String>
)

interface ApiStateStore {
    fun getQuotes(): List<QuoteRecord>
    fun upsertQuote(quote: QuoteRecord)
    fun getPolicies(): List<PolicyRecord>
    fun upsertPolicy(policy: PolicyRecord)
    fun getClaims(): List<ClaimRecord>
    fun upsertClaim(claim: ClaimRecord)
    fun getObservations(): List<ObservationEvent>
    fun upsertObservation(obs: ObservationEvent)
    fun getSettlements(): List<ProposedSettlement>
    fun upsertSettlement(settlement: ProposedSettlement)
    fun getAgentRuns(): List<AgentRunRecord>
}

class RhinoMarineApiEngine(
    private val store: ApiStateStore,
    private val rateLimitPerMinute: Int = 60,
    private val webhookSecret: String = "rmc_whsec_demo_2026_china_terminal"
) {
    private val idempotencyCache = mutableMapOf<String, Pair<String, ApiResponse>>()
    private val tenantRequestCounts = mutableMapOf<String, Int>()
    private val seenWebhookDeliveries = mutableSetOf<String>()

    fun handle(request: ApiRequest, nowInstant: Instant = Instant.now()): ApiResponse {
        val requestId = "req_${UUID.randomUUID().toString().take(12)}"
        val nowUtc = nowInstant.toString()

        // 1. Auth boundary check (API Key or OAuth Bearer)
        if (request.apiKey.isBlank() && request.oauthBearer.isNullOrBlank()) {
            return errorResponse(
                statusCode = 401,
                requestId = requestId,
                errorCode = "ERR_UNAUTHORIZED_CLIENT",
                messageEn = "Missing X-Rhino-Api-Key or OAuth 2.0 Bearer token.",
                messageZh = "缺少 X-Rhino-Api-Key 或 OAuth 2.0 Bearer 令牌。",
                nowUtc = nowUtc
            )
        }

        // 2. Rate limiting check
        val count = (tenantRequestCounts[request.tenantId] ?: 0) + 1
        tenantRequestCounts[request.tenantId] = count
        if (count > rateLimitPerMinute) {
            return errorResponse(
                statusCode = 429,
                requestId = requestId,
                errorCode = "ERR_RATE_LIMIT_EXCEEDED",
                messageEn = "Tenant rate limit ($rateLimitPerMinute/min) exceeded.",
                messageZh = "超出租户接口频率限制 ($rateLimitPerMinute 次/分钟)。",
                nowUtc = nowUtc
            )
        }

        // 3. Idempotency check for consequential POST requests
        val idemScopeKey = request.idempotencyKey?.takeIf { it.isNotBlank() }?.let {
            "${request.tenantId}:${request.method}:${request.path}:$it"
        }
        val bodyHash = sha256(request.bodyJson.trim())
        if (request.method == "POST" && idemScopeKey != null) {
            val cached = idempotencyCache[idemScopeKey]
            if (cached != null) {
                if (cached.first != bodyHash) {
                    return errorResponse(
                        statusCode = 409,
                        requestId = requestId,
                        errorCode = "ERR_IDEMPOTENCY_CONFLICT",
                        messageEn = "Idempotency-Key reused with a different request payload.",
                        messageZh = "幂等键 Idempotency-Key 被用于不同的请求体载荷。",
                        nowUtc = nowUtc
                    )
                }
                return cached.second.copy(
                    requestId = requestId,
                    idempotentReplay = true,
                    headers = cached.second.headers + ("X-Request-Id" to requestId) + ("X-Idempotent-Replay" to "true")
                )
            }
        }

        val response = try {
            dispatch(request, requestId, nowUtc)
        } catch (ex: StructuredDomainException) {
            val code = when (ex.errorCode) {
                "ERR_TENANT_FORBIDDEN" -> 403
                "ERR_UNAUTHORIZED_ISSUANCE" -> 403
                "ERR_NOT_FOUND" -> 404
                "ERR_QUOTE_EXPIRED", "ERR_QUOTE_NOT_APPROVED", "ERR_INVALID_QUOTE_TRANSITION" -> 422
                else -> 400
            }
            errorResponse(code, requestId, ex.errorCode, ex.messageEn, ex.messageZh, nowUtc)
        } catch (ex: Exception) {
            errorResponse(
                400,
                requestId,
                "ERR_BAD_REQUEST",
                ex.message ?: "Invalid request payload.",
                "请求格式或参数无效：${ex.message}",
                nowUtc
            )
        }

        if (request.method == "POST" && idemScopeKey != null && response.statusCode in 200..299) {
            idempotencyCache[idemScopeKey] = bodyHash to response
        }
        return response
    }

    fun resetRateLimitForTest(tenantId: String) {
        tenantRequestCounts.remove(tenantId)
    }

    private fun dispatch(request: ApiRequest, requestId: String, nowUtc: String): ApiResponse {
        val path = request.path.trimEnd('/')
        val body = if (request.bodyJson.isBlank()) JSONObject() else JSONObject(request.bodyJson)

        return when {
            request.method == "POST" && path == "/v1/quotes" -> handleCreateQuote(request, body, requestId, nowUtc)
            request.method == "GET" && path.startsWith("/v1/quotes/") -> {
                val id = path.removePrefix("/v1/quotes/")
                val quote = store.getQuotes().firstOrNull { it.quoteId == id }
                    ?: return errorResponse(404, requestId, "ERR_NOT_FOUND", "Quote $id not found.", "未找到报价 $id。", nowUtc)
                if (quote.tenantId != request.tenantId) {
                    return errorResponse(403, requestId, "ERR_TENANT_FORBIDDEN", "Cross-tenant quote access prohibited.", "禁止跨租户访问报价。", nowUtc)
                }
                okResponse(200, requestId, serializeQuote(quote), nowUtc)
            }
            request.method == "POST" && path.matches(Regex("^/v1/quotes/[^/]+/versions$")) -> {
                val id = path.removePrefix("/v1/quotes/").removeSuffix("/versions")
                handleVersionQuote(request, id, body, requestId, nowUtc)
            }
            request.method == "POST" && path.matches(Regex("^/v1/quotes/[^/]+/submit$")) -> {
                val id = path.removePrefix("/v1/quotes/").removeSuffix("/submit")
                handleSubmitQuote(request, id, requestId, nowUtc)
            }
            request.method == "POST" && path.matches(Regex("^/v1/quotes/[^/]+/approve$")) -> {
                val id = path.removePrefix("/v1/quotes/").removeSuffix("/approve")
                handleApproveQuote(request, id, requestId, nowUtc)
            }
            request.method == "POST" && path == "/v1/policies" -> handleIssuePolicy(request, body, requestId, nowUtc)
            request.method == "GET" && path.startsWith("/v1/policies/") -> {
                val id = path.removePrefix("/v1/policies/")
                val policy = store.getPolicies().firstOrNull { it.policyId == id }
                    ?: return errorResponse(404, requestId, "ERR_NOT_FOUND", "Policy $id not found.", "未找到保单 $id。", nowUtc)
                if (policy.tenantId != request.tenantId) {
                    return errorResponse(403, requestId, "ERR_TENANT_FORBIDDEN", "Cross-tenant policy access prohibited.", "禁止跨租户访问保单。", nowUtc)
                }
                okResponse(200, requestId, serializePolicy(policy), nowUtc)
            }
            request.method == "POST" && path == "/v1/claims" -> handleCreateClaim(request, body, requestId, nowUtc)
            request.method == "POST" && path == "/v1/events/observations" -> handleRecordObservation(request, body, requestId, nowUtc)
            request.method == "POST" && path == "/v1/settlements/calculate" -> handleCalculateSettlement(request, body, requestId, nowUtc)
            request.method == "GET" && path.startsWith("/v1/agent-runs/") -> {
                val runId = path.removePrefix("/v1/agent-runs/")
                val run = store.getAgentRuns().firstOrNull { it.runId == runId }
                    ?: return errorResponse(404, requestId, "ERR_NOT_FOUND", "Agent run $runId not found.", "未找到智能体运行记录 $runId。", nowUtc)
                if (run.tenantId != request.tenantId) {
                    return errorResponse(403, requestId, "ERR_TENANT_FORBIDDEN", "Cross-tenant agent run access prohibited.", "禁止跨租户访问智能体记录。", nowUtc)
                }
                val json = JSONObject()
                    .put("run_id", run.runId)
                    .put("tenant_id", run.tenantId)
                    .put("mode", run.mode)
                    .put("task_type", run.taskType)
                    .put("status", run.status)
                    .put("requires_human_review", run.requiresHumanReview)
                    .put("output_summary", run.outputSummary)
                    .put("created_at_utc", run.createdAtUtc)
                okResponse(200, requestId, json, nowUtc)
            }
            else -> errorResponse(404, requestId, "ERR_ROUTE_NOT_FOUND", "Unsupported endpoint ${request.method} $path", "不支持的接口路径 ${request.method} $path", nowUtc)
        }
    }

    private fun handleCreateQuote(request: ApiRequest, body: JSONObject, requestId: String, nowUtc: String): ApiResponse {
        val familyCode = body.optString("product_family", "VOYAGE_DELAY")
        val family = ProductFamily.entries.firstOrNull { it.code == familyCode }
            ?: throw StructuredDomainException("ERR_INVALID_PRODUCT_FAMILY", "Unknown product_family: $familyCode", "未知险种代码: $familyCode")
        val currencyCode = body.optString("currency", "CNY")
        val currency = CurrencyCode.entries.firstOrNull { it.iso == currencyCode }
            ?: throw StructuredDomainException("ERR_INVALID_CURRENCY", "Unsupported ISO currency: $currencyCode", "不支持的货币代码: $currencyCode")

        val sumInsured = Money.of(body.optString("sum_insured", "1000000.00"), currency)
        val deductible = Money.of(body.optString("deductible", "0.00"), currency)
        val limit = Money.of(body.optString("coverage_limit", "500000.00"), currency)
        val seed = body.optLong("simulation_seed", 20261113L)
        val exposureDays = body.optInt("exposure_days", 20)
        val customer = body.optString("customer_name", "API Client Logistics Co.")
        val quoteId = "Q-API-${UUID.randomUUID().toString().take(6).uppercase()}"

        val paramConfig = if (family.productType == ProductType.PARAMETRIC) {
            val strike = BigDecimal(body.optString("strike_threshold", "48"))
            val exhaustion = BigDecimal(body.optString("exhaustion_threshold", "144"))
            ParametricProductConfig(
                productCode = "RMC-API-${family.code}",
                productFamily = family,
                titleEn = "${family.code} API Cover",
                titleZh = "${family.code} 接口参数保单",
                observableNameEn = body.optString("observable_name", "Measured Trigger Metric"),
                observableNameZh = body.optString("observable_name", "约定可观测触发指标"),
                measurementUnit = body.optString("unit", "hours"),
                observationLocation = body.optString("location", "CNSHA"),
                observationPeriodDays = exposureDays,
                primaryDataSource = "Synthetic Port Call Feed",
                fallbackDataSource = "Harbour Master Bulletin",
                strikeThreshold = strike,
                exhaustionThreshold = exhaustion,
                maxPayout = limit,
                waitingPeriodHours = body.optInt("waiting_period_hours", 12),
                aggregationRuleEn = "Single voyage event",
                aggregationRuleZh = "单航次事件累计",
                repeatEventRuleEn = "Max 1 trigger per voyage",
                repeatEventRuleZh = "每航次最多触发一次",
                finalisationRuleEn = "T+48h after event",
                finalisationRuleZh = "事件结束后48小时确认",
                missingDataRuleEn = "Fallback feed after 24h",
                missingDataRuleZh = "24小时无主源则切换备源",
                disputedDataRuleEn = "Hold payment pending arbiter",
                disputedDataRuleZh = "争议期间暂停赔付"
            )
        } else null

        val breakdown = if (family.productType == ProductType.PARAMETRIC) {
            PricingAndParametricEngine.priceParametricQuote(paramConfig!!, exposureDays, seed = seed)
        } else {
            PricingAndParametricEngine.priceIndemnityQuote(
                productFamily = family,
                sumInsured = sumInsured,
                deductible = deductible,
                perEventLimit = limit,
                aggregateLimit = limit,
                exposureDays = exposureDays,
                vesselAgeYears = body.optInt("vessel_age_years", 8),
                isHighHazardCargo = body.optBoolean("high_hazard_cargo", false),
                seed = seed
            )
        }

        val quote = QuoteRecord(
            quoteId = quoteId,
            tenantId = request.tenantId,
            version = 1,
            status = QuoteStatus.INDICATIVE,
            productType = family.productType,
            productFamily = family,
            customerName = customer,
            vesselId = body.optString("vessel_id", "VSL-SH-01"),
            cargoId = body.optString("cargo_id").takeIf { it.isNotBlank() },
            voyageId = body.optString("voyage_id", "VOY-SH-RTM-01"),
            currency = currency,
            sumInsured = sumInsured,
            deductible = deductible,
            coverageLimit = limit,
            aggregateLimit = limit,
            parametricConfig = paramConfig,
            pricingBreakdown = breakdown,
            referralReasons = if (body.optBoolean("missing_survey", false)) listOf("INSPECTION_MISSING_OR_OVERDUE") else emptyList(),
            underwritingNotes = "Created via POST /v1/quotes ($requestId). Simulation Only — Non-Binding.",
            isBinding = false,
            expiresAtUtc = Instant.parse(nowUtc).plusSeconds(14 * 86400L).toString(),
            createdAtUtc = nowUtc,
            updatedAtUtc = nowUtc,
            inputSnapshotJson = body.toString()
        )
        store.upsertQuote(quote)
        return okResponse(201, requestId, serializeQuote(quote), nowUtc)
    }

    private fun handleVersionQuote(request: ApiRequest, quoteId: String, body: JSONObject, requestId: String, nowUtc: String): ApiResponse {
        val existing = store.getQuotes().firstOrNull { it.quoteId == quoteId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Quote $quoteId not found.", "未找到报价 $quoteId。")
        if (existing.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant quote access prohibited.", "禁止跨租户访问报价。")
        }
        val newStrike = body.optString("strike_threshold").takeIf { it.isNotBlank() }?.let { BigDecimal(it) }
        val newExhaustion = body.optString("exhaustion_threshold").takeIf { it.isNotBlank() }?.let { BigDecimal(it) }
        val updatedConfig = existing.parametricConfig?.let { cfg ->
            cfg.copy(
                strikeThreshold = newStrike ?: cfg.strikeThreshold,
                exhaustionThreshold = newExhaustion ?: cfg.exhaustionThreshold
            )
        }
        val seed = body.optLong("simulation_seed", existing.pricingBreakdown?.simulationSeed ?: 20261113L)
        val newBreakdown = if (updatedConfig != null) {
            PricingAndParametricEngine.priceParametricQuote(updatedConfig, updatedConfig.observationPeriodDays, seed = seed)
        } else {
            PricingAndParametricEngine.priceIndemnityQuote(
                existing.productFamily,
                existing.sumInsured,
                existing.deductible,
                existing.coverageLimit,
                existing.aggregateLimit,
                30,
                8,
                false,
                seed = seed
            )
        }
        val next = existing.copy(
            version = existing.version + 1,
            status = QuoteStatus.INDICATIVE,
            parametricConfig = updatedConfig,
            pricingBreakdown = newBreakdown,
            isBinding = false,
            expiresAtUtc = Instant.parse(nowUtc).plusSeconds(14 * 86400L).toString(),
            updatedAtUtc = nowUtc
        )
        store.upsertQuote(next)
        return okResponse(200, requestId, serializeQuote(next), nowUtc)
    }

    private fun handleSubmitQuote(request: ApiRequest, quoteId: String, requestId: String, nowUtc: String): ApiResponse {
        val existing = store.getQuotes().firstOrNull { it.quoteId == quoteId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Quote $quoteId not found.", "未找到报价 $quoteId。")
        if (existing.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant quote access prohibited.", "禁止跨租户访问报价。")
        }
        if (WorkflowAndCurrencyEngine.isQuoteExpired(existing, nowUtc)) {
            throw StructuredDomainException("ERR_QUOTE_EXPIRED", "Quote $quoteId is expired.", "报价 $quoteId 已过期。")
        }
        val updated = WorkflowAndCurrencyEngine.transitionQuoteState(existing, QuoteStatus.UNDERWRITING_REVIEW, nowUtc)
        store.upsertQuote(updated)
        return okResponse(200, requestId, serializeQuote(updated), nowUtc)
    }

    private fun handleApproveQuote(request: ApiRequest, quoteId: String, requestId: String, nowUtc: String): ApiResponse {
        val existing = store.getQuotes().firstOrNull { it.quoteId == quoteId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Quote $quoteId not found.", "未找到报价 $quoteId。")
        if (existing.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant quote access prohibited.", "禁止跨租户访问报价。")
        }
        if (request.authority != IssuanceAuthority.AUTHORIZED_UNDERWRITER &&
            request.authority != IssuanceAuthority.HEAD_OF_MARINE
        ) {
            throw StructuredDomainException("ERR_UNAUTHORIZED_ISSUANCE", "Underwriter authority required to approve.", "需要核保授权才能核准报价。")
        }
        val updated = WorkflowAndCurrencyEngine.transitionQuoteState(existing, QuoteStatus.APPROVED, nowUtc)
        store.upsertQuote(updated)
        return okResponse(200, requestId, serializeQuote(updated), nowUtc)
    }

    private fun handleIssuePolicy(request: ApiRequest, body: JSONObject, requestId: String, nowUtc: String): ApiResponse {
        val quoteId = body.optString("quote_id")
        val existing = store.getQuotes().firstOrNull { it.quoteId == quoteId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Quote $quoteId not found.", "未找到报价 $quoteId。")
        if (existing.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant policy issuance prohibited.", "禁止跨租户出单。")
        }
        val wording = body.optString("wording_version", "RMC-STD-v3.0")
        val (issuedQuote, policy) = WorkflowAndCurrencyEngine.issuePolicy(
            quote = existing,
            authority = request.authority,
            wordingVersion = wording,
            inceptionUtc = body.optString("inception_utc", nowUtc),
            expiryUtc = body.optString("expiry_utc", Instant.parse(nowUtc).plusSeconds(30 * 86400L).toString()),
            nowUtc = nowUtc
        )
        store.upsertQuote(issuedQuote)
        store.upsertPolicy(policy)
        return okResponse(201, requestId, serializePolicy(policy), nowUtc)
    }

    private fun handleCreateClaim(request: ApiRequest, body: JSONObject, requestId: String, nowUtc: String): ApiResponse {
        val policyId = body.optString("policy_id")
        val policy = store.getPolicies().firstOrNull { it.policyId == policyId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Policy $policyId not found.", "未找到保单 $policyId。")
        if (policy.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant claim filing prohibited.", "禁止跨租户提交理赔。")
        }
        val claimId = "CLM-API-${UUID.randomUUID().toString().take(6).uppercase()}"
        val claim = ClaimRecord(
            claimId = claimId,
            tenantId = request.tenantId,
            policyId = policyId,
            productType = policy.productType,
            stage = ClaimStage.NOTIFICATION,
            incidentSummaryEn = body.optString("summary_en", "API-submitted claim notification."),
            incidentSummaryZh = body.optString("summary_zh", "通过API提交的出险通知。"),
            claimedAmount = Money.of(body.optString("claimed_amount", "50000.00"), policy.currency),
            assessedAmount = null,
            evidenceRefs = listOf(body.optString("evidence_ref", "API-NOTICE-01")),
            assessorNotes = "Awaiting evidence collection & assessment.",
            paymentInstructionRef = null,
            reconciliationRef = null,
            notifiedAtUtc = nowUtc,
            updatedAtUtc = nowUtc
        )
        store.upsertClaim(claim)
        val json = JSONObject()
            .put("claim_id", claim.claimId)
            .put("policy_id", claim.policyId)
            .put("stage", claim.stage.code)
            .put("claimed_amount", claim.claimedAmount.rounded().toPlainString())
            .put("currency", claim.claimedAmount.currency.iso)
            .put("notified_at_utc", claim.notifiedAtUtc)
        return okResponse(201, requestId, json, nowUtc)
    }

    private fun handleRecordObservation(request: ApiRequest, body: JSONObject, requestId: String, nowUtc: String): ApiResponse {
        val policyId = body.optString("policy_id")
        val policy = store.getPolicies().firstOrNull { it.policyId == policyId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Policy $policyId not found.", "未找到保单 $policyId。")
        if (policy.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant observation prohibited.", "禁止跨租户写入观测数据。")
        }
        val statusStr = body.optString("finalisation_status", "FINALISED")
        val finStatus = ObservationFinalisationStatus.entries.firstOrNull { it.code == statusStr }
            ?: ObservationFinalisationStatus.PRELIMINARY
        val obsId = "OBS-${UUID.randomUUID().toString().take(6).uppercase()}"
        val obs = ObservationEvent(
            observationId = obsId,
            tenantId = request.tenantId,
            policyId = policyId,
            productFamily = policy.productFamily,
            observableName = policy.parametricConfig?.observableNameEn ?: "Observed Index",
            observedValue = BigDecimal(body.optString("observed_value", "0")),
            unit = body.optString("unit", policy.parametricConfig?.measurementUnit ?: "hours"),
            location = body.optString("location", policy.parametricConfig?.observationLocation ?: "CNSHA"),
            dataSource = body.optString("data_source", "Synthetic API Feed"),
            feedStatus = FeedStatus.SIMULATED,
            finalisationStatus = finStatus,
            observedAtUtc = nowUtc,
            evidenceCitation = body.optString("evidence_citation", "API-OBS-$obsId")
        )
        store.upsertObservation(obs)
        val json = JSONObject()
            .put("observation_id", obs.observationId)
            .put("policy_id", obs.policyId)
            .put("observed_value", obs.observedValue.toPlainString())
            .put("unit", obs.unit)
            .put("finalisation_status", obs.finalisationStatus.code)
            .put("observed_at_utc", obs.observedAtUtc)
        return okResponse(201, requestId, json, nowUtc)
    }

    private fun handleCalculateSettlement(request: ApiRequest, body: JSONObject, requestId: String, nowUtc: String): ApiResponse {
        val policyId = body.optString("policy_id")
        val obsId = body.optString("observation_id")
        val policy = store.getPolicies().firstOrNull { it.policyId == policyId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Policy $policyId not found.", "未找到保单 $policyId。")
        val obs = store.getObservations().firstOrNull { it.observationId == obsId }
            ?: throw StructuredDomainException("ERR_NOT_FOUND", "Observation $obsId not found.", "未找到观测记录 $obsId。")
        if (policy.tenantId != request.tenantId || obs.tenantId != request.tenantId) {
            throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant settlement calculation prohibited.", "禁止跨租户计算赔付。")
        }
        val settlement = WorkflowAndCurrencyEngine.calculateProposedSettlement(policy, obs, nowUtc)
        store.upsertSettlement(settlement)
        val json = JSONObject()
            .put("settlement_id", settlement.settlementId)
            .put("policy_id", settlement.policyId)
            .put("observation_id", settlement.observationId)
            .put("calculated_payout", settlement.calculatedPayout.rounded().toPlainString())
            .put("currency", settlement.calculatedPayout.currency.iso)
            .put("approval_status", settlement.approvalStatus)
            .put("auto_payment_initiated", settlement.autoPaymentInitiated)
            .put("basis_risk_disclaimer_en", settlement.basisRiskDisclaimerEn)
            .put("basis_risk_disclaimer_zh", settlement.basisRiskDisclaimerZh)
        return okResponse(200, requestId, json, nowUtc)
    }

    fun signWebhookPayload(deliveryId: String, timestampEpochSec: Long, payloadJson: String): Map<String, String> {
        val signedMessage = "$deliveryId.$timestampEpochSec.$payloadJson"
        val sig = hmacSha256(webhookSecret, signedMessage)
        return mapOf(
            "X-Rhino-Delivery-Id" to deliveryId,
            "X-Rhino-Timestamp" to timestampEpochSec.toString(),
            "X-Rhino-Signature" to "v1=$sig"
        )
    }

    fun verifySignedWebhook(
        deliveryId: String,
        timestampEpochSec: Long,
        signatureHeader: String,
        payloadJson: String,
        nowEpochSec: Long = Instant.now().epochSecond
    ): Pair<Boolean, String> {
        if (kotlin.math.abs(nowEpochSec - timestampEpochSec) > 300L) {
            return false to "ERR_WEBHOOK_EXPIRED_TIMESTAMP"
        }
        if (deliveryId in seenWebhookDeliveries) {
            return false to "ERR_WEBHOOK_REPLAY_DETECTED"
        }
        val expected = "v1=${hmacSha256(webhookSecret, "$deliveryId.$timestampEpochSec.$payloadJson")}"
        if (signatureHeader != expected) {
            return false to "ERR_WEBHOOK_INVALID_SIGNATURE"
        }
        seenWebhookDeliveries.add(deliveryId)
        return true to "VERIFIED"
    }

    private fun serializeQuote(q: QuoteRecord): JSONObject {
        val pricingJson = q.pricingBreakdown?.let { p ->
            JSONObject()
                .put("model_version", p.modelVersion)
                .put("simulation_seed", p.simulationSeed)
                .put("simulation_runs", p.simulationRuns)
                .put("expected_payout_or_loss", p.expectedLossOrPayout.rounded().toPlainString())
                .put("risk_loading", p.riskLoading.rounded().toPlainString())
                .put("expense_loading", p.expenseLoading.rounded().toPlainString())
                .put("technical_premium", p.technicalPremium.rounded().toPlainString())
                .put("commercial_adjustment", p.commercialAdjustment.rounded().toPlainString())
                .put("final_quoted_premium", p.finalQuotedPremium.rounded().toPlainString())
                .put("currency", p.finalQuotedPremium.currency.iso)
                .put("is_synthetic_rate", p.isSyntheticRate)
        } ?: JSONObject.NULL

        return JSONObject()
            .put("quote_id", q.quoteId)
            .put("tenant_id", q.tenantId)
            .put("version", q.version)
            .put("status", q.status.code)
            .put("product_type", q.productType.code)
            .put("product_family", q.productFamily.code)
            .put("currency", q.currency.iso)
            .put("sum_insured", q.sumInsured.rounded().toPlainString())
            .put("deductible", q.deductible.rounded().toPlainString())
            .put("coverage_limit", q.coverageLimit.rounded().toPlainString())
            .put("is_binding", q.isBinding)
            .put("simulation_only", true)
            .put("expires_at_utc", q.expiresAtUtc)
            .put("referral_reasons", JSONArray(q.referralReasons))
            .put("pricing_breakdown", pricingJson)
            .put("updated_at_utc", q.updatedAtUtc)
    }

    private fun serializePolicy(p: PolicyRecord): JSONObject {
        return JSONObject()
            .put("policy_id", p.policyId)
            .put("tenant_id", p.tenantId)
            .put("quote_id", p.quoteId)
            .put("quote_version", p.quoteVersion)
            .put("product_type", p.productType.code)
            .put("product_family", p.productFamily.code)
            .put("wording_version", p.wordingVersion)
            .put("currency", p.currency.iso)
            .put("sum_insured", p.sumInsured.rounded().toPlainString())
            .put("issued_premium", p.issuedPremium.rounded().toPlainString())
            .put("inception_utc", p.inceptionUtc)
            .put("expiry_utc", p.expiryUtc)
            .put("issued_at_utc", p.issuedAtUtc)
            .put("endorsement_count", p.endorsements.size)
            .put("status", p.status)
    }

    private fun okResponse(code: Int, requestId: String, json: JSONObject, nowUtc: String): ApiResponse {
        return ApiResponse(
            statusCode = code,
            requestId = requestId,
            idempotentReplay = false,
            bodyJson = json.toString(2),
            headers = mapOf(
                "Content-Type" to "application/json",
                "X-Request-Id" to requestId,
                "X-Timestamp-Utc" to nowUtc,
                "X-Simulation-Only" to "true"
            )
        )
    }

    private fun errorResponse(
        statusCode: Int,
        requestId: String,
        errorCode: String,
        messageEn: String,
        messageZh: String,
        nowUtc: String
    ): ApiResponse {
        val json = JSONObject()
            .put("error_code", errorCode)
            .put("message_en", messageEn)
            .put("message_zh", messageZh)
            .put("request_id", requestId)
            .put("timestamp_utc", nowUtc)
        return ApiResponse(
            statusCode = statusCode,
            requestId = requestId,
            idempotentReplay = false,
            bodyJson = json.toString(2),
            headers = mapOf(
                "Content-Type" to "application/json",
                "X-Request-Id" to requestId,
                "X-Timestamp-Utc" to nowUtc
            )
        )
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hmacSha256(secret: String, data: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    companion object {
        val openApiSpecSnippet: String = """
openapi: 3.1.0
info:
  title: RHINO MARINE CHINA — 航运保险定价与接口平台 API
  version: 1.0.0-sim
  description: |
    Bilingual Shipping Insurance Quotation, Parametric Cover & Underwriting API.
    All indicative rates and feeds are synthetic (Simulation Only / 仅供模拟).
paths:
  /v1/quotes:
    post:
      summary: Create Indicative Quote / 创建参考报价
      parameters:
        - name: X-Tenant-Id
          in: header
          required: true
        - name: Idempotency-Key
          in: header
          required: false
  /v1/quotes/{quote_id}:
    get:
      summary: Get Quote Snapshot / 查询报价快照
  /v1/quotes/{quote_id}/versions:
    post:
      summary: Create New Quote Version / 生成新版本报价
  /v1/quotes/{quote_id}/submit:
    post:
      summary: Submit Quote for Underwriting Review / 提交核保审核
  /v1/quotes/{quote_id}/approve:
    post:
      summary: Approve Quote / 核保通过报价
  /v1/policies:
    post:
      summary: Issue Policy (Requires Approved Quote + Authority) / 正式出单
  /v1/policies/{policy_id}:
    get:
      summary: Get Issued Policy & Endorsements / 查询保单及批单
  /v1/claims:
    post:
      summary: File Claim Notification / 提交出险通知
  /v1/events/observations:
    post:
      summary: Ingest Parametric Event Observation / 录入参数观测事件
  /v1/settlements/calculate:
    post:
      summary: Calculate Proposed Parametric Settlement / 计算拟定参数赔付
  /v1/agent-runs/{run_id}:
    get:
      summary: Inspect AI Underwriting Assistant Run / 查询AI辅助核保运行记录
""".trimIndent()

        val pythonClientExample: String = """
import httpx, uuid

client = httpx.Client(
    base_url="https://api.rhinomarine.cn.sim",
    headers={
        "X-Rhino-Api-Key": "rmc_live_demo_key_cn_01",
        "X-Tenant-Id": "tenant_east_china_logistics",
        "Idempotency-Key": str(uuid.uuid4()),
    },
)

quote = client.post("/v1/quotes", json={
    "product_family": "VOYAGE_DELAY",
    "currency": "CNY",
    "sum_insured": "16500000.00",
    "coverage_limit": "1200000.00",
    "strike_threshold": "48",
    "exhaustion_threshold": "168",
    "simulation_seed": 20260002,
}).json()
print("Indicative Quote (Simulation Only):", quote["quote_id"], quote["pricing_breakdown"]["final_quoted_premium"])
""".trimIndent()

        val typescriptClientExample: String = """
const res = await fetch("https://api.rhinomarine.cn.sim/v1/quotes", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-Rhino-Api-Key": "rmc_live_demo_key_cn_01",
    "X-Tenant-Id": "tenant_east_china_logistics",
    "Idempotency-Key": crypto.randomUUID(),
  },
  body: JSON.stringify({
    product_family: "PORT_CLOSURE",
    currency: "USD",
    coverage_limit: "350000.00",
    strike_threshold: "24",
    exhaustion_threshold: "96",
  }),
});
const quote = await res.json();
console.log(quote.quote_id, quote.is_binding); // false
""".trimIndent()
    }
}
