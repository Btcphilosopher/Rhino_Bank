package com.example.domain.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class CurrencyCode(val iso: String, val symbol: String) {
    USD("USD", "$"),
    CNY("CNY", "¥"),
    EUR("EUR", "€"),
    HKD("HKD", "HK$"),
    SGD("SGD", "S$")
}

data class Money(
    val amount: BigDecimal,
    val currency: CurrencyCode
) {
    init {
        require(amount.scale() <= 4) { "Money precision exceeded" }
    }

    fun rounded(): BigDecimal = amount.setScale(2, RoundingMode.HALF_UP)

    fun formatted(): String = "${currency.iso} ${rounded().toPlainString()}"

    operator fun plus(other: Money): Money {
        require(currency == other.currency) {
            "ERR_CURRENCY_MISMATCH: Cannot silently add ${currency.iso} and ${other.currency.iso}"
        }
        return Money(amount.add(other.amount).setScale(2, RoundingMode.HALF_UP), currency)
    }

    operator fun minus(other: Money): Money {
        require(currency == other.currency) {
            "ERR_CURRENCY_MISMATCH: Cannot subtract ${other.currency.iso} from ${currency.iso}"
        }
        return Money(amount.subtract(other.amount).setScale(2, RoundingMode.HALF_UP), currency)
    }

    companion object {
        fun of(value: String, currency: CurrencyCode): Money =
            Money(BigDecimal(value).setScale(2, RoundingMode.HALF_UP), currency)

        fun of(value: Double, currency: CurrencyCode): Money =
            Money(BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP), currency)

        fun zero(currency: CurrencyCode): Money =
            Money(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP), currency)
    }
}

data class FxRateRecord(
    val from: CurrencyCode,
    val to: CurrencyCode,
    val rate: BigDecimal,
    val source: String,
    val timestampUtc: String,
    val isSimulated: Boolean = true
)

enum class ProductType(val code: String) {
    INDEMNITY("INDEMNITY"),
    PARAMETRIC("PARAMETRIC")
}

enum class ProductFamily(val code: String, val productType: ProductType) {
    CARGO("CARGO", ProductType.INDEMNITY),
    HULL_MACHINERY("HULL_MACHINERY", ProductType.INDEMNITY),
    VOYAGE_DELAY("VOYAGE_DELAY", ProductType.PARAMETRIC),
    PORT_CLOSURE("PORT_CLOSURE", ProductType.PARAMETRIC),
    WEATHER_DISRUPTION("WEATHER_DISRUPTION", ProductType.PARAMETRIC)
}

enum class QuoteStatus(val code: String) {
    DRAFT("DRAFT"),
    CALCULATING("CALCULATING"),
    INDICATIVE("INDICATIVE"),
    UNDERWRITING_REVIEW("UNDERWRITING_REVIEW"),
    APPROVED("APPROVED"),
    ACCEPTED("ACCEPTED"),
    ISSUED("ISSUED"),
    REJECTED("REJECTED"),
    EXPIRED("EXPIRED"),
    CANCELLED("CANCELLED");

    fun canTransitionTo(next: QuoteStatus): Boolean = when (this) {
        DRAFT -> next in setOf(CALCULATING, CANCELLED)
        CALCULATING -> next in setOf(INDICATIVE, DRAFT, CANCELLED)
        INDICATIVE -> next in setOf(UNDERWRITING_REVIEW, EXPIRED, CANCELLED, CALCULATING)
        UNDERWRITING_REVIEW -> next in setOf(APPROVED, REJECTED, EXPIRED, CANCELLED)
        APPROVED -> next in setOf(ACCEPTED, EXPIRED, CANCELLED)
        ACCEPTED -> next in setOf(ISSUED, EXPIRED, CANCELLED)
        ISSUED -> next == CANCELLED
        REJECTED, EXPIRED, CANCELLED -> false
    }
}

enum class ClaimStage(val code: String) {
    NOTIFICATION("NOTIFICATION"),
    EVIDENCE_COLLECTION("EVIDENCE_COLLECTION"),
    ASSESSMENT("ASSESSMENT"),
    APPROVAL("APPROVAL"),
    PAYMENT_INSTRUCTION("PAYMENT_INSTRUCTION"),
    RECONCILIATION("RECONCILIATION"),
    DECLINED("DECLINED")
}

enum class FeedStatus(val code: String) {
    SIMULATED("SIMULATED"),
    STALE("STALE"),
    UNAVAILABLE("UNAVAILABLE"),
    LIVE("LIVE")
}

enum class ObservationFinalisationStatus(val code: String) {
    PRELIMINARY("PRELIMINARY"),
    FINALISED("FINALISED"),
    CORRECTED("CORRECTED"),
    DISPUTED("DISPUTED"),
    MISSING("MISSING")
}

enum class IssuanceAuthority(val code: String) {
    UNAUTHORIZED("UNAUTHORIZED"),
    BROKER_READONLY("BROKER_READONLY"),
    AUTHORIZED_UNDERWRITER("AUTHORIZED_UNDERWRITER"),
    HEAD_OF_MARINE("HEAD_OF_MARINE")
}

data class VesselRecord(
    val id: String,
    val tenantId: String,
    val name: String,
    val imoNumber: String,
    val mmsi: String,
    val vesselType: String,
    val buildYear: Int,
    val capacityDescription: String,
    val dwt: Int,
    val flagState: String,
    val inspectionStatus: String,
    val lastSurveyUtc: String
)

data class CargoRecord(
    val id: String,
    val tenantId: String,
    val description: String,
    val category: String,
    val hazardClass: String,
    val packaging: String,
    val declaredValue: Money
)

data class PortNode(
    val unlocode: String,
    val nameEn: String,
    val nameZh: String,
    val mapX: Float, // normalized 0f..1f for schematic maritime chart
    val mapY: Float,
    val isChineseHub: Boolean
)

data class VoyageRecord(
    val id: String,
    val tenantId: String,
    val voyageCode: String,
    val vesselId: String,
    val originPortCode: String,
    val destinationPortCode: String,
    val intermediatePortCodes: List<String>,
    val plannedDepartureUtc: String,
    val plannedArrivalUtc: String,
    val coverageInceptionUtc: String,
    val coverageExpiryUtc: String,
    val exposureDays: Int,
    val routeExposureAssumptions: String,
    val seaCorridor: String
)

data class ParametricProductConfig(
    val productCode: String,
    val productFamily: ProductFamily,
    val titleEn: String,
    val titleZh: String,
    val observableNameEn: String,
    val observableNameZh: String,
    val measurementUnit: String,
    val observationLocation: String,
    val observationPeriodDays: Int,
    val primaryDataSource: String,
    val fallbackDataSource: String,
    val strikeThreshold: BigDecimal, // K
    val exhaustionThreshold: BigDecimal, // E > K
    val maxPayout: Money, // L
    val waitingPeriodHours: Int,
    val aggregationRuleEn: String,
    val aggregationRuleZh: String,
    val repeatEventRuleEn: String,
    val repeatEventRuleZh: String,
    val finalisationRuleEn: String,
    val finalisationRuleZh: String,
    val missingDataRuleEn: String,
    val missingDataRuleZh: String,
    val disputedDataRuleEn: String,
    val disputedDataRuleZh: String
)

data class BayesianCalibration(
    val modelVersion: String,
    val priorMean: Double,
    val priorStrength: Double,
    val observedCount: Int,
    val observedMean: Double,
    val posteriorMean: Double,
    val isSparseData: Boolean,
    val reliabilityNoteEn: String,
    val reliabilityNoteZh: String
)

data class SimulationConvergencePoint(
    val sampleCount: Int,
    val runningMean: BigDecimal
)

data class SensitivityPoint(
    val parameterLabel: String,
    val expectedPayout: BigDecimal,
    val technicalPremium: BigDecimal
)

data class PricingBreakdown(
    val modelVersion: String,
    val simulationSeed: Long,
    val simulationRuns: Int,
    val expectedLossOrPayout: Money,
    val riskLoading: Money,
    val expenseLoading: Money,
    val technicalPremium: Money,
    val commercialAdjustment: Money,
    val finalQuotedPremium: Money,
    val stdDev: BigDecimal,
    val var95: BigDecimal,
    val isSyntheticRate: Boolean = true,
    val assumptions: List<String>,
    val bayesianCalibration: BayesianCalibration,
    val convergenceCheck: List<SimulationConvergencePoint>,
    val sensitivitySamples: List<SensitivityPoint>,
    val distributionBuckets: List<Int>
)

data class QuoteRecord(
    val quoteId: String,
    val tenantId: String,
    val version: Int,
    val status: QuoteStatus,
    val productType: ProductType,
    val productFamily: ProductFamily,
    val customerName: String,
    val vesselId: String,
    val cargoId: String?,
    val voyageId: String,
    val currency: CurrencyCode,
    val sumInsured: Money,
    val deductible: Money,
    val coverageLimit: Money,
    val aggregateLimit: Money,
    val parametricConfig: ParametricProductConfig?,
    val pricingBreakdown: PricingBreakdown?,
    val referralReasons: List<String>,
    val underwritingNotes: String,
    val isBinding: Boolean,
    val expiresAtUtc: String,
    val createdAtUtc: String,
    val updatedAtUtc: String,
    val inputSnapshotJson: String
)

data class EndorsementRecord(
    val endorsementId: String,
    val sequenceNumber: Int,
    val wordingVersion: String,
    val summaryEn: String,
    val summaryZh: String,
    val premiumDelta: Money,
    val issuedBy: String,
    val issuedAtUtc: String
)

data class PolicyRecord(
    val policyId: String,
    val tenantId: String,
    val quoteId: String,
    val quoteVersion: Int,
    val productType: ProductType,
    val productFamily: ProductFamily,
    val insuredName: String,
    val wordingVersion: String,
    val currency: CurrencyCode,
    val sumInsured: Money,
    val deductible: Money,
    val coverageLimit: Money,
    val issuedPremium: Money,
    val inceptionUtc: String,
    val expiryUtc: String,
    val issuedAtUtc: String,
    val issuedByAuthority: IssuanceAuthority,
    val parametricConfig: ParametricProductConfig?,
    val endorsements: List<EndorsementRecord>,
    val status: String // ACTIVE, ENDORSED, EXPIRED
)

data class ClaimRecord(
    val claimId: String,
    val tenantId: String,
    val policyId: String,
    val productType: ProductType,
    val stage: ClaimStage,
    val incidentSummaryEn: String,
    val incidentSummaryZh: String,
    val claimedAmount: Money,
    val assessedAmount: Money?,
    val evidenceRefs: List<String>,
    val assessorNotes: String,
    val paymentInstructionRef: String?,
    val reconciliationRef: String?,
    val notifiedAtUtc: String,
    val updatedAtUtc: String
)

data class ObservationEvent(
    val observationId: String,
    val tenantId: String,
    val policyId: String,
    val productFamily: ProductFamily,
    val observableName: String,
    val observedValue: BigDecimal,
    val unit: String,
    val location: String,
    val dataSource: String,
    val feedStatus: FeedStatus,
    val finalisationStatus: ObservationFinalisationStatus,
    val observedAtUtc: String,
    val evidenceCitation: String,
    val correctionNote: String? = null
)

data class ProposedSettlement(
    val settlementId: String,
    val tenantId: String,
    val policyId: String,
    val observationId: String,
    val observedValue: BigDecimal,
    val strikeThreshold: BigDecimal,
    val exhaustionThreshold: BigDecimal,
    val maxPayout: Money,
    val calculatedPayout: Money,
    val basisRiskDisclaimerEn: String,
    val basisRiskDisclaimerZh: String,
    val evidenceSummary: String,
    val approvalStatus: String, // PENDING_REVIEW, APPROVED_FOR_PAYMENT, HELD_FOR_DISPUTE
    val autoPaymentInitiated: Boolean = false,
    val createdAtUtc: String
)

data class DataFeedHealth(
    val feedCode: String,
    val nameEn: String,
    val nameZh: String,
    val status: FeedStatus,
    val lastUpdatedUtc: String,
    val latencyMs: Int,
    val noteEn: String,
    val noteZh: String
)

data class ApiAuditEntry(
    val requestId: String,
    val tenantId: String,
    val method: String,
    val path: String,
    val statusCode: Int,
    val idempotencyKey: String?,
    val idempotentReplay: Boolean,
    val requestBodyJson: String,
    val responseBodyJson: String,
    val timestampUtc: String
)

data class AgentRunRecord(
    val runId: String,
    val tenantId: String,
    val mode: String, // GEMINI_FIREBASE_AI | MOCK_ADAPTER
    val taskType: String,
    val status: String,
    val promptSummary: String,
    val outputSummary: String,
    val requiresHumanReview: Boolean = true,
    val appliedToRecord: Boolean = false,
    val createdAtUtc: String
)
