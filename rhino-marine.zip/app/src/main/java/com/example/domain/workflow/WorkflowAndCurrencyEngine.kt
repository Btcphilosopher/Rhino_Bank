package com.example.domain.workflow

import com.example.domain.engine.PricingAndParametricEngine
import com.example.domain.engine.StructuredDomainException
import com.example.domain.model.CurrencyCode
import com.example.domain.model.EndorsementRecord
import com.example.domain.model.FxRateRecord
import com.example.domain.model.IssuanceAuthority
import com.example.domain.model.Money
import com.example.domain.model.ObservationEvent
import com.example.domain.model.ObservationFinalisationStatus
import com.example.domain.model.PolicyRecord
import com.example.domain.model.ProposedSettlement
import com.example.domain.model.QuoteRecord
import com.example.domain.model.QuoteStatus
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

object WorkflowAndCurrencyEngine {

    fun transitionQuoteState(
        quote: QuoteRecord,
        target: QuoteStatus,
        nowUtc: String = Instant.now().toString()
    ): QuoteRecord {
        if (!quote.status.canTransitionTo(target)) {
            throw StructuredDomainException(
                errorCode = "ERR_INVALID_QUOTE_TRANSITION",
                messageEn = "Invalid quote transition from ${quote.status.code} to ${target.code}.",
                messageZh = "无效的报价状态流转：无法从 ${quote.status.code} 变更为 ${target.code}。"
            )
        }
        return quote.copy(
            status = target,
            isBinding = target == QuoteStatus.ISSUED,
            updatedAtUtc = nowUtc
        )
    }

    fun isQuoteExpired(quote: QuoteRecord, nowUtc: String = Instant.now().toString()): Boolean {
        return try {
            Instant.parse(nowUtc).isAfter(Instant.parse(quote.expiresAtUtc))
        } catch (_: Exception) {
            false
        }
    }

    fun issuePolicy(
        quote: QuoteRecord,
        authority: IssuanceAuthority,
        wordingVersion: String,
        inceptionUtc: String,
        expiryUtc: String,
        nowUtc: String = Instant.now().toString()
    ): Pair<QuoteRecord, PolicyRecord> {
        if (authority != IssuanceAuthority.AUTHORIZED_UNDERWRITER &&
            authority != IssuanceAuthority.HEAD_OF_MARINE
        ) {
            throw StructuredDomainException(
                errorCode = "ERR_UNAUTHORIZED_ISSUANCE",
                messageEn = "Issuance authority '${authority.code}' is not permitted to bind or issue policies.",
                messageZh = "当前权限 (${authority.code}) 无权签发正式保单。"
            )
        }
        if (quote.status == QuoteStatus.EXPIRED || isQuoteExpired(quote, nowUtc)) {
            throw StructuredDomainException(
                errorCode = "ERR_QUOTE_EXPIRED",
                messageEn = "Quote ${quote.quoteId} expired at ${quote.expiresAtUtc}. Create a new quote version.",
                messageZh = "报价 ${quote.quoteId} 已于 ${quote.expiresAtUtc} 过期，请先生成新版本报价。"
            )
        }
        if (quote.status != QuoteStatus.APPROVED && quote.status != QuoteStatus.ACCEPTED) {
            throw StructuredDomainException(
                errorCode = "ERR_QUOTE_NOT_APPROVED",
                messageEn = "Quote ${quote.quoteId} must be APPROVED or ACCEPTED before policy issuance (current: ${quote.status.code}).",
                messageZh = "出单前报价 ${quote.quoteId} 须处于已核准或已接受状态（当前：${quote.status.code}）。"
            )
        }
        val premium = quote.pricingBreakdown?.finalQuotedPremium
            ?: throw StructuredDomainException(
                errorCode = "ERR_MISSING_PRICING",
                messageEn = "Cannot issue policy without a calculated pricing breakdown.",
                messageZh = "缺少精算报价明细，无法出单。"
            )

        val acceptedQuote = if (quote.status == QuoteStatus.APPROVED) {
            transitionQuoteState(quote, QuoteStatus.ACCEPTED, nowUtc)
        } else {
            quote
        }
        val issuedQuote = transitionQuoteState(acceptedQuote, QuoteStatus.ISSUED, nowUtc)
        val policyId = "POL-${quote.quoteId.removePrefix("Q-")}-V${quote.version}"

        val policy = PolicyRecord(
            policyId = policyId,
            tenantId = quote.tenantId,
            quoteId = quote.quoteId,
            quoteVersion = quote.version,
            productType = quote.productType,
            productFamily = quote.productFamily,
            insuredName = quote.customerName,
            wordingVersion = wordingVersion,
            currency = quote.currency,
            sumInsured = quote.sumInsured,
            deductible = quote.deductible,
            coverageLimit = quote.coverageLimit,
            issuedPremium = premium,
            inceptionUtc = inceptionUtc,
            expiryUtc = expiryUtc,
            issuedAtUtc = nowUtc,
            issuedByAuthority = authority,
            parametricConfig = quote.parametricConfig,
            endorsements = emptyList(),
            status = "ACTIVE"
        )
        return issuedQuote to policy
    }

    fun appendEndorsement(
        policy: PolicyRecord,
        summaryEn: String,
        summaryZh: String,
        premiumDelta: Money,
        newWordingVersion: String,
        issuedBy: String,
        nowUtc: String = Instant.now().toString()
    ): PolicyRecord {
        if (premiumDelta.currency != policy.currency) {
            throw StructuredDomainException(
                errorCode = "ERR_CURRENCY_MISMATCH",
                messageEn = "Endorsement currency ${premiumDelta.currency.iso} must match policy currency ${policy.currency.iso}.",
                messageZh = "批单币种 ${premiumDelta.currency.iso} 必须与保单币种 ${policy.currency.iso} 一致。"
            )
        }
        val nextSeq = policy.endorsements.size + 1
        val endorsement = EndorsementRecord(
            endorsementId = "${policy.policyId}-END-$nextSeq",
            sequenceNumber = nextSeq,
            wordingVersion = newWordingVersion,
            summaryEn = summaryEn,
            summaryZh = summaryZh,
            premiumDelta = premiumDelta,
            issuedBy = issuedBy,
            issuedAtUtc = nowUtc
        )
        return policy.copy(
            wordingVersion = newWordingVersion,
            endorsements = policy.endorsements + endorsement,
            status = "ENDORSED"
        )
    }

    fun calculateProposedSettlement(
        policy: PolicyRecord,
        observation: ObservationEvent,
        nowUtc: String = Instant.now().toString()
    ): ProposedSettlement {
        if (policy.tenantId != observation.tenantId) {
            throw StructuredDomainException(
                errorCode = "ERR_TENANT_FORBIDDEN",
                messageEn = "Cross-tenant observation settlement is prohibited.",
                messageZh = "禁止跨租户计算参数赔付。"
            )
        }
        val config = policy.parametricConfig ?: throw StructuredDomainException(
            errorCode = "ERR_NOT_PARAMETRIC_POLICY",
            messageEn = "Policy ${policy.policyId} is not a parametric contract.",
            messageZh = "保单 ${policy.policyId} 并非参数型保险合同。"
        )
        val payout = when (observation.finalisationStatus) {
            ObservationFinalisationStatus.MISSING -> Money.zero(policy.currency)
            else -> PricingAndParametricEngine.calculateParametricPayout(
                observedX = observation.observedValue,
                strikeK = config.strikeThreshold,
                exhaustionE = config.exhaustionThreshold,
                maxPayoutL = config.maxPayout
            )
        }
        val approvalStatus = when (observation.finalisationStatus) {
            ObservationFinalisationStatus.DISPUTED, ObservationFinalisationStatus.MISSING -> "HELD_FOR_DISPUTE"
            else -> "PENDING_REVIEW"
        }
        return ProposedSettlement(
            settlementId = "SET-${observation.observationId.removePrefix("OBS-")}",
            tenantId = policy.tenantId,
            policyId = policy.policyId,
            observationId = observation.observationId,
            observedValue = observation.observedValue,
            strikeThreshold = config.strikeThreshold,
            exhaustionThreshold = config.exhaustionThreshold,
            maxPayout = config.maxPayout,
            calculatedPayout = payout,
            basisRiskDisclaimerEn = "Basis Risk: Calculated payout ${payout.formatted()} reflects contractual index ${observation.observedValue} ${observation.unit} and may differ from actual economic loss.",
            basisRiskDisclaimerZh = "基差风险提示：拟定赔付 ${payout.formatted()} 仅依据合同观测指标 ${observation.observedValue} ${observation.unit} 计算，可能与实际经济损失存在差异。",
            evidenceSummary = "${observation.dataSource} (${observation.finalisationStatus.code}) • ${observation.evidenceCitation}",
            approvalStatus = approvalStatus,
            autoPaymentInitiated = false,
            createdAtUtc = nowUtc
        )
    }

    /**
     * Never silently add different currencies; require explicit FxRateRecord per foreign currency.
     */
    fun convertPortfolioTo(
        items: List<Money>,
        targetCurrency: CurrencyCode,
        fxRates: List<FxRateRecord>
    ): Money {
        var total = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
        for (money in items) {
            if (money.currency == targetCurrency) {
                total = total.add(money.amount)
            } else {
                val fx = fxRates.firstOrNull { it.from == money.currency && it.to == targetCurrency }
                    ?: throw StructuredDomainException(
                        errorCode = "ERR_MISSING_FX_RATE",
                        messageEn = "Explicit FX rate required to convert ${money.currency.iso} to ${targetCurrency.iso}.",
                        messageZh = "将 ${money.currency.iso} 折算为 ${targetCurrency.iso} 需要明确提供汇率及来源。"
                    )
                val converted = money.amount.multiply(fx.rate).setScale(2, RoundingMode.HALF_UP)
                total = total.add(converted)
            }
        }
        return Money(total, targetCurrency)
    }
}
