package com.example.domain.engine

import com.example.domain.model.BayesianCalibration
import com.example.domain.model.CargoRecord
import com.example.domain.model.CurrencyCode
import com.example.domain.model.Money
import com.example.domain.model.ParametricProductConfig
import com.example.domain.model.PricingBreakdown
import com.example.domain.model.ProductFamily
import com.example.domain.model.SensitivityPoint
import com.example.domain.model.SimulationConvergencePoint
import com.example.domain.model.VesselRecord
import com.example.domain.model.VoyageRecord
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

class StructuredDomainException(
    val errorCode: String,
    val messageEn: String,
    val messageZh: String
) : IllegalArgumentException("$errorCode: $messageEn")

object PricingAndParametricEngine {

    private val MC = MathContext(12, RoundingMode.HALF_UP)

    /**
     * Exact contractual payout formula:
     * P(x) = L * min(1, max(0, (x - K) / (E - K)))
     */
    fun calculateParametricPayout(
        observedX: BigDecimal,
        strikeK: BigDecimal,
        exhaustionE: BigDecimal,
        maxPayoutL: Money
    ): Money {
        if (exhaustionE <= strikeK) {
            throw StructuredDomainException(
                errorCode = "ERR_INVALID_EXHAUSTION_THRESHOLD",
                messageEn = "Exhaustion threshold ($exhaustionE) must be strictly greater than strike threshold ($strikeK).",
                messageZh = "全额赔付阈值 ($exhaustionE) 必须严格大于触发阈值 ($strikeK)。"
            )
        }
        if (maxPayoutL.amount < BigDecimal.ZERO) {
            throw StructuredDomainException(
                errorCode = "ERR_INVALID_PAYOUT_LIMIT",
                messageEn = "Maximum payout limit cannot be negative.",
                messageZh = "赔偿限额不能为负数。"
            )
        }
        if (observedX <= strikeK) {
            return Money.zero(maxPayoutL.currency)
        }
        if (observedX >= exhaustionE) {
            return Money(maxPayoutL.rounded(), maxPayoutL.currency)
        }
        val ratio = observedX.subtract(strikeK, MC)
            .divide(exhaustionE.subtract(strikeK, MC), MC)
            .max(BigDecimal.ZERO)
            .min(BigDecimal.ONE)
        val payout = maxPayoutL.amount.multiply(ratio, MC).setScale(2, RoundingMode.HALF_UP)
        return Money(payout, maxPayoutL.currency)
    }

    /**
     * Indemnity per-event deductible and per-event + aggregate limit application.
     */
    fun applyIndemnityTerms(
        grossLoss: Money,
        deductible: Money,
        perEventLimit: Money,
        remainingAggregateLimit: Money
    ): Money {
        if (grossLoss.currency != deductible.currency ||
            grossLoss.currency != perEventLimit.currency ||
            grossLoss.currency != remainingAggregateLimit.currency
        ) {
            throw StructuredDomainException(
                errorCode = "ERR_CURRENCY_MISMATCH",
                messageEn = "All monetary terms must share the same ISO currency.",
                messageZh = "所有金额条款必须使用相同的 ISO 币种。"
            )
        }
        val afterDeductible = grossLoss.amount.subtract(deductible.amount).max(BigDecimal.ZERO)
        val cappedPerEvent = afterDeductible.min(perEventLimit.amount)
        val cappedAggregate = cappedPerEvent.min(remainingAggregateLimit.amount)
            .setScale(2, RoundingMode.HALF_UP)
        return Money(cappedAggregate, grossLoss.currency)
    }

    /**
     * Configurable Bayesian updating for claim frequency / trigger hazard.
     */
    fun calibrateBayesian(
        modelVersion: String,
        priorMean: Double,
        priorStrength: Double,
        observedValues: List<Double>
    ): BayesianCalibration {
        val n = observedValues.size
        val obsMean = if (n > 0) observedValues.average() else priorMean
        val denom = priorStrength + n
        val posteriorMean = if (denom > 0.0) {
            (priorStrength * priorMean + n * obsMean) / denom
        } else {
            priorMean
        }
        val isSparse = n < 15
        return BayesianCalibration(
            modelVersion = modelVersion,
            priorMean = priorMean,
            priorStrength = priorStrength,
            observedCount = n,
            observedMean = obsMean,
            posteriorMean = posteriorMean,
            isSparseData = isSparse,
            reliabilityNoteEn = if (isSparse) {
                "Sparse observations (n=$n < 15): posterior blends prior heavily and cannot reliably estimate extreme tail risk."
            } else {
                "Adequate historical sample (n=$n); tail extremes still subject to regime shifts."
            },
            reliabilityNoteZh = if (isSparse) {
                "观测样本稀疏 (n=$n < 15)：后验分布高度依赖先验假设，无法可靠估计极端尾部风险。"
            } else {
                "历史样本较充足 (n=$n)；极端尾部仍受航运周期与气象突变影响。"
            }
        )
    }

    fun evaluateUnderwritingReferrals(
        vessel: VesselRecord?,
        cargo: CargoRecord?,
        voyage: VoyageRecord?,
        sumInsured: Money,
        productFamily: ProductFamily
    ): List<String> {
        val referrals = mutableListOf<String>()
        if (vessel == null) {
            referrals.add("MISSING_VESSEL_RECORD")
        } else {
            if (vessel.imoNumber.isBlank()) referrals.add("MISSING_IMO_IDENTIFIER")
            if (vessel.inspectionStatus.isBlank() || vessel.inspectionStatus.contains("OVERDUE", ignoreCase = true)) {
                referrals.add("INSPECTION_MISSING_OR_OVERDUE")
            }
            if (2026 - vessel.buildYear > 20) referrals.add("VESSEL_AGE_EXCEEDS_20_YEARS")
        }
        if (voyage == null) {
            referrals.add("MISSING_VOYAGE_SCHEDULE")
        } else if (voyage.exposureDays <= 0) {
            referrals.add("INVALID_EXPOSURE_PERIOD")
        }
        if (productFamily == ProductFamily.CARGO && cargo == null) {
            referrals.add("MISSING_CARGO_MANIFEST")
        } else if (cargo != null && cargo.hazardClass.contains("HIGH", ignoreCase = true)) {
            referrals.add("HIGH_HAZARD_CARGO_CLASS")
        }
        val highThreshold = if (sumInsured.currency == CurrencyCode.CNY) {
            BigDecimal("20000000.00")
        } else {
            BigDecimal("3000000.00")
        }
        if (sumInsured.amount >= highThreshold) {
            referrals.add("SUM_INSURED_EXCEEDS_AUTO_AUTHORITY")
        }
        return referrals
    }

    fun priceParametricQuote(
        config: ParametricProductConfig,
        exposureDays: Int,
        seed: Long = 20261113L,
        runs: Int = 2000,
        commercialAdjRate: Double = 0.0,
        priorMeanObservable: Double? = null,
        historicalObservations: List<Double> = listOf(18.0, 22.0, 34.0, 56.0, 14.0, 41.0, 29.0)
    ): PricingBreakdown {
        if (config.exhaustionThreshold <= config.strikeThreshold) {
            throw StructuredDomainException(
                errorCode = "ERR_INVALID_EXHAUSTION_THRESHOLD",
                messageEn = "Cannot price parametric product when Exhaustion Threshold <= Strike Threshold.",
                messageZh = "当全额赔付阈值小于或等于触发阈值时，无法进行参数定价。"
            )
        }
        val safeRuns = runs.coerceIn(200, 10000)
        val baseMean = priorMeanObservable ?: when (config.productFamily) {
            ProductFamily.VOYAGE_DELAY -> 31.0 * (exposureDays.coerceAtLeast(1) / 20.0)
            ProductFamily.PORT_CLOSURE -> 16.0 * (exposureDays.coerceAtLeast(1) / 14.0)
            ProductFamily.WEATHER_DISRUPTION -> 36.0
            else -> 25.0
        }
        val bayesian = calibrateBayesian(
            modelVersion = "rmc-param-mc-v2.1",
            priorMean = baseMean,
            priorStrength = 8.0,
            observedValues = historicalObservations
        )

        val rng = Random(seed)
        val payouts = DoubleArray(safeRuns)
        val convergence = mutableListOf<SimulationConvergencePoint>()
        val checkpoints = setOf(
            safeRuns / 4,
            safeRuns / 2,
            (safeRuns * 3) / 4,
            safeRuns
        )
        var runningSum = 0.0
        val sigma = 0.68
        val mu = ln(max(1.0, bayesian.posteriorMean)) - 0.5 * sigma * sigma

        for (i in 1..safeRuns) {
            // Reproducible Box-Muller normal sample -> LogNormal observable x
            val u1 = max(1e-9, rng.nextDouble())
            val u2 = rng.nextDouble()
            val z = sqrt(-2.0 * ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
            val simulatedX = exp(mu + sigma * z)
            val payout = calculateParametricPayout(
                observedX = BigDecimal.valueOf(simulatedX),
                strikeK = config.strikeThreshold,
                exhaustionE = config.exhaustionThreshold,
                maxPayoutL = config.maxPayout
            ).amount.toDouble()
            payouts[i - 1] = payout
            runningSum += payout
            if (i in checkpoints) {
                convergence.add(
                    SimulationConvergencePoint(
                        sampleCount = i,
                        runningMean = BigDecimal.valueOf(runningSum / i).setScale(2, RoundingMode.HALF_UP)
                    )
                )
            }
        }

        val mean = runningSum / safeRuns
        val variance = payouts.sumOf { (it - mean) * (it - mean) } / safeRuns
        val stdDev = sqrt(variance)
        val sorted = payouts.sortedArray()
        val var95 = sorted[((safeRuns - 1) * 0.95).toInt()]

        val currency = config.maxPayout.currency
        val expectedPayout = Money.of(mean, currency)
        // Synthetic actuarial risk & expense loadings clearly disclosed
        val riskLoad = Money.of(0.18 * stdDev + 0.04 * mean, currency)
        val expenseLoad = Money.of(0.12 * (mean + riskLoad.amount.toDouble()), currency)
        val technical = expectedPayout + riskLoad + expenseLoad
        val commAdj = Money.of(technical.amount.toDouble() * commercialAdjRate, currency)
        val finalQuoted = Money(
            technical.amount.add(commAdj.amount).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP),
            currency
        )

        val buckets = buildHistogram(payouts, config.maxPayout.amount.toDouble().coerceAtLeast(1.0))

        // Sensitivity across Strike K shifts (-20%, base, +20%) and +50% exposure
        val sensitivity = listOf(
            computeSensitivitySample(
                label = "K -20%",
                strike = config.strikeThreshold.multiply(BigDecimal("0.80")),
                exhaustion = config.exhaustionThreshold,
                maxPayout = config.maxPayout,
                mu = mu,
                sigma = sigma,
                seed = seed
            ),
            SensitivityPoint(
                parameterLabel = "Base (K=${config.strikeThreshold.toPlainString()})",
                expectedPayout = expectedPayout.rounded(),
                technicalPremium = technical.rounded()
            ),
            computeSensitivitySample(
                label = "K +20%",
                strike = config.strikeThreshold.multiply(BigDecimal("1.20"))
                    .min(config.exhaustionThreshold.subtract(BigDecimal.ONE)),
                exhaustion = config.exhaustionThreshold,
                maxPayout = config.maxPayout,
                mu = mu,
                sigma = sigma,
                seed = seed
            ),
            computeSensitivitySample(
                label = "Exposure +50%",
                strike = config.strikeThreshold,
                exhaustion = config.exhaustionThreshold,
                maxPayout = config.maxPayout,
                mu = mu + ln(1.5),
                sigma = sigma,
                seed = seed
            )
        )

        return PricingBreakdown(
            modelVersion = "rmc-param-mc-v2.1",
            simulationSeed = seed,
            simulationRuns = safeRuns,
            expectedLossOrPayout = expectedPayout,
            riskLoading = riskLoad,
            expenseLoading = expenseLoad,
            technicalPremium = technical,
            commercialAdjustment = commAdj,
            finalQuotedPremium = finalQuoted,
            stdDev = BigDecimal.valueOf(stdDev).setScale(2, RoundingMode.HALF_UP),
            var95 = BigDecimal.valueOf(var95).setScale(2, RoundingMode.HALF_UP),
            isSyntheticRate = true,
            assumptions = listOf(
                "Synthetic LogNormal index severity calibrated via Bayesian prior-posterior blend",
                "Formula: P(x) = L * min(1, max(0, (x - K) / (E - K)))",
                "Synthetic risk load = 18% StdDev + 4% Expected Payout; synthetic expense load = 12%",
                "Seeded Monte Carlo ($safeRuns scenarios, seed=$seed)"
            ),
            bayesianCalibration = bayesian,
            convergenceCheck = convergence,
            sensitivitySamples = sensitivity,
            distributionBuckets = buckets
        )
    }

    private fun computeSensitivitySample(
        label: String,
        strike: BigDecimal,
        exhaustion: BigDecimal,
        maxPayout: Money,
        mu: Double,
        sigma: Double,
        seed: Long
    ): SensitivityPoint {
        val effectiveExhaustion = if (exhaustion <= strike) strike.add(BigDecimal.TEN) else exhaustion
        val rng = Random(seed)
        val n = 600
        var sum = 0.0
        var sumSq = 0.0
        for (i in 0 until n) {
            val u1 = max(1e-9, rng.nextDouble())
            val u2 = rng.nextDouble()
            val z = sqrt(-2.0 * ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
            val x = exp(mu + sigma * z)
            val p = calculateParametricPayout(
                BigDecimal.valueOf(x),
                strike,
                effectiveExhaustion,
                maxPayout
            ).amount.toDouble()
            sum += p
            sumSq += p * p
        }
        val mean = sum / n
        val sd = sqrt(max(0.0, sumSq / n - mean * mean))
        val tech = mean + (0.18 * sd + 0.04 * mean) * 1.12 + 0.12 * mean
        return SensitivityPoint(
            parameterLabel = label,
            expectedPayout = BigDecimal.valueOf(mean).setScale(2, RoundingMode.HALF_UP),
            technicalPremium = BigDecimal.valueOf(tech).setScale(2, RoundingMode.HALF_UP)
        )
    }

    fun priceIndemnityQuote(
        productFamily: ProductFamily,
        sumInsured: Money,
        deductible: Money,
        perEventLimit: Money,
        aggregateLimit: Money,
        exposureDays: Int,
        vesselAgeYears: Int,
        isHighHazardCargo: Boolean,
        seed: Long = 20261113L,
        runs: Int = 2000,
        commercialAdjRate: Double = 0.0,
        historicalLossRates: List<Double> = listOf(0.0021, 0.0034, 0.0018, 0.0042, 0.0029)
    ): PricingBreakdown {
        val safeRuns = runs.coerceIn(200, 10000)
        val baseLambda = when (productFamily) {
            ProductFamily.CARGO -> 0.045
            ProductFamily.HULL_MACHINERY -> 0.065
            else -> 0.05
        } * (exposureDays.coerceAtLeast(1) / 30.0) *
            (1.0 + max(0, vesselAgeYears - 10) * 0.025) *
            (if (isHighHazardCargo) 1.35 else 1.0)

        val bayesian = calibrateBayesian(
            modelVersion = "rmc-indemnity-freqsev-v2.0",
            priorMean = 0.0032,
            priorStrength = 10.0,
            observedValues = historicalLossRates
        )

        val rng = Random(seed)
        val losses = DoubleArray(safeRuns)
        val convergence = mutableListOf<SimulationConvergencePoint>()
        val checkpoints = setOf(safeRuns / 4, safeRuns / 2, (safeRuns * 3) / 4, safeRuns)
        var runningSum = 0.0

        val severityMean = sumInsured.amount.toDouble() * (bayesian.posteriorMean / max(0.01, baseLambda))
        val sigma = 0.85
        val mu = ln(max(100.0, severityMean)) - 0.5 * sigma * sigma

        for (i in 1..safeRuns) {
            // Poisson event count via Knuth algorithm
            val l = exp(-baseLambda)
            var k = 0
            var p = 1.0
            do {
                k++
                p *= rng.nextDouble()
            } while (p > l && k < 12)
            val eventCount = k - 1

            var remainingAgg = aggregateLimit
            var scenarioNet = BigDecimal.ZERO
            for (e in 0 until eventCount) {
                val u1 = max(1e-9, rng.nextDouble())
                val u2 = rng.nextDouble()
                val z = sqrt(-2.0 * ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
                val gross = Money.of(min(sumInsured.amount.toDouble(), exp(mu + sigma * z)), sumInsured.currency)
                val net = applyIndemnityTerms(gross, deductible, perEventLimit, remainingAgg)
                scenarioNet = scenarioNet.add(net.amount)
                remainingAgg = Money(remainingAgg.amount.subtract(net.amount).max(BigDecimal.ZERO), sumInsured.currency)
            }
            val scenarioVal = scenarioNet.toDouble()
            losses[i - 1] = scenarioVal
            runningSum += scenarioVal
            if (i in checkpoints) {
                convergence.add(
                    SimulationConvergencePoint(
                        sampleCount = i,
                        runningMean = BigDecimal.valueOf(runningSum / i).setScale(2, RoundingMode.HALF_UP)
                    )
                )
            }
        }

        val mean = runningSum / safeRuns
        val variance = losses.sumOf { (it - mean) * (it - mean) } / safeRuns
        val stdDev = sqrt(variance)
        val sorted = losses.sortedArray()
        val var95 = sorted[((safeRuns - 1) * 0.95).toInt()]

        val currency = sumInsured.currency
        val expectedLoss = Money.of(mean, currency)
        val riskLoad = Money.of(0.15 * stdDev + 0.05 * mean, currency)
        val expenseLoad = Money.of(0.14 * (mean + riskLoad.amount.toDouble()), currency)
        val technical = expectedLoss + riskLoad + expenseLoad
        val commAdj = Money.of(technical.amount.toDouble() * commercialAdjRate, currency)
        val finalQuoted = Money(
            technical.amount.add(commAdj.amount).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP),
            currency
        )

        val sensitivity = listOf(
            SensitivityPoint(
                parameterLabel = "Deductible -50%",
                expectedPayout = BigDecimal.valueOf(mean * 1.18).setScale(2, RoundingMode.HALF_UP),
                technicalPremium = BigDecimal.valueOf(technical.amount.toDouble() * 1.16).setScale(2, RoundingMode.HALF_UP)
            ),
            SensitivityPoint(
                parameterLabel = "Base Deductible",
                expectedPayout = expectedLoss.rounded(),
                technicalPremium = technical.rounded()
            ),
            SensitivityPoint(
                parameterLabel = "Deductible +50%",
                expectedPayout = BigDecimal.valueOf(mean * 0.84).setScale(2, RoundingMode.HALF_UP),
                technicalPremium = BigDecimal.valueOf(technical.amount.toDouble() * 0.86).setScale(2, RoundingMode.HALF_UP)
            )
        )

        return PricingBreakdown(
            modelVersion = "rmc-indemnity-freqsev-v2.0",
            simulationSeed = seed,
            simulationRuns = safeRuns,
            expectedLossOrPayout = expectedLoss,
            riskLoading = riskLoad,
            expenseLoading = expenseLoad,
            technicalPremium = technical,
            commercialAdjustment = commAdj,
            finalQuotedPremium = finalQuoted,
            stdDev = BigDecimal.valueOf(stdDev).setScale(2, RoundingMode.HALF_UP),
            var95 = BigDecimal.valueOf(var95).setScale(2, RoundingMode.HALF_UP),
            isSyntheticRate = true,
            assumptions = listOf(
                "Frequency-Severity Compound Poisson-LogNormal indemnity model",
                "Separate per-event deductible, per-event limit, and aggregate limit",
                "Synthetic risk load = 15% StdDev + 5% Expected Loss; synthetic expense load = 14%",
                "Seeded Monte Carlo ($safeRuns scenarios, seed=$seed)"
            ),
            bayesianCalibration = bayesian,
            convergenceCheck = convergence,
            sensitivitySamples = sensitivity,
            distributionBuckets = buildHistogram(losses, perEventLimit.amount.toDouble().coerceAtLeast(1.0))
        )
    }

    private fun buildHistogram(samples: DoubleArray, maxRef: Double): List<Int> {
        val bins = IntArray(8)
        val upper = max(1.0, maxRef)
        for (v in samples) {
            val idx = ((v / upper) * 7.0).toInt().coerceIn(0, 7)
            bins[idx]++
        }
        return bins.toList()
    }
}
