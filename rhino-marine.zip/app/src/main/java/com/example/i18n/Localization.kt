package com.example.i18n

import com.example.domain.model.ClaimStage
import com.example.domain.model.FeedStatus
import com.example.domain.model.ObservationFinalisationStatus
import com.example.domain.model.ProductFamily
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteStatus

enum class AppLanguage(val code: String, val displayName: String) {
    EN("en", "English"),
    ZH_CN("zh-CN", "简体中文")
}

data class TranslationEntry(
    val key: String,
    val en: String,
    val zhCn: String,
    val isContractualWording: Boolean = false,
    val specialistReviewed: Boolean = true,
    val category: String = "UI"
)

object TranslationCatalog {
    val defaults: List<TranslationEntry> = listOf(
        // Required core domain labels
        TranslationEntry("brand_title", "RHINO MARINE CHINA", "RHINO MARINE CHINA 犀牛海运中国", category = "Brand"),
        TranslationEntry("brand_subtitle", "Shipping Insurance Pricing & API Terminal", "航运保险定价与接口平台", category = "Brand"),
        TranslationEntry("term_marine_insurance", "Marine Insurance", "航运保险", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_indicative_quote", "Indicative Quote", "参考报价", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_premium", "Premium", "保险费", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_sum_insured", "Sum Insured", "保险金额", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_deductible", "Deductible", "免赔额", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_coverage_limit", "Coverage Limit", "赔偿限额", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_strike_threshold", "Strike Threshold", "触发阈值", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_exhaustion_threshold", "Exhaustion Threshold", "全额赔付阈值", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_parametric_cover", "Parametric Cover", "参数型保险", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_basis_risk", "Basis Risk", "基差风险", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_underwriting_review", "Underwriting Review", "核保审核", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_claim_notification", "Claim Notification", "出险通知", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_policy_issuance", "Policy Issuance", "出单", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_data_source", "Data Source", "数据来源", isContractualWording = true, category = "Core Glossary"),
        TranslationEntry("term_simulation_only", "Simulation Only", "仅供模拟", isContractualWording = true, category = "Core Glossary"),

        // Navigation items (10 workspaces)
        TranslationEntry("nav_overview", "Overview", "总览", category = "Navigation"),
        TranslationEntry("nav_quote_engine", "Quote Engine", "报价引擎", category = "Navigation"),
        TranslationEntry("nav_voyages", "Voyages", "航次管理", category = "Navigation"),
        TranslationEntry("nav_vessels_cargo", "Vessels & Cargo", "船舶与货物", category = "Navigation"),
        TranslationEntry("nav_parametric", "Parametric Products", "参数型产品", category = "Navigation"),
        TranslationEntry("nav_policies", "Policies", "保单管理", category = "Navigation"),
        TranslationEntry("nav_claims", "Claims", "理赔管理", category = "Navigation"),
        TranslationEntry("nav_analytics", "Risk Analytics", "风险分析", category = "Navigation"),
        TranslationEntry("nav_api_console", "API Console", "API控制台", category = "Navigation"),
        TranslationEntry("nav_admin", "Administration", "系统管理", category = "Navigation"),

        // Banners & disclaimers
        TranslationEntry(
            "banner_non_binding",
            "SIMULATION ONLY — Indicative quotes do not constitute binding insurance cover or regulatory authorisation.",
            "仅供模拟 — 参考报价不构成具有约束力的承保承诺或监管许可。",
            isContractualWording = true,
            specialistReviewed = false,
            category = "Compliance"
        ),
        TranslationEntry(
            "banner_synthetic_rates",
            "All demonstration loss rates, FX rates, and sea-route coordinates are synthetic and versioned.",
            "所有演示费率、汇率及航线坐标均为可复现的模拟数据并受版本控制。",
            isContractualWording = true,
            category = "Compliance"
        ),
        TranslationEntry(
            "explain_strike_distinction",
            "A Strike Threshold (K) is the observable level where parametric payout begins. It is legally and mathematically distinct from Premium, Deductible, Sum Insured, and Coverage Limit.",
            "触发阈值 (K) 是参数型赔付启动的可观测指标水平，在合同与精算上均独立于保险费、免赔额、保险金额及赔偿限额。",
            isContractualWording = true,
            specialistReviewed = false,
            category = "Parametric"
        ),
        TranslationEntry(
            "explain_basis_risk",
            "Basis Risk: A contractual parametric payout P(x) depends solely on the designated index observation and may be higher or lower than the insured's actual economic loss.",
            "基差风险：参数型保险赔付 P(x) 仅取决于指定指数的观测值，可能高于或低于被保险人的实际经济损失。",
            isContractualWording = true,
            specialistReviewed = false,
            category = "Parametric"
        ),
        TranslationEntry(
            "explain_indemnity_vs_parametric",
            "Indemnity claims require covered loss, evidence, policy terms and loss assessment. Parametric payouts depend on a measurable trigger event and contractual formula.",
            "传统补偿型保险理赔取决于承保损失、证明文件、保单条款与定损；参数型保险赔付取决于可量化触发事件及合同公式。",
            isContractualWording = true,
            category = "Compliance"
        ),

        // Dashboard KPIs
        TranslationEntry("kpi_indicative_premium", "Indicative Premium Volume", "参考保费规模", category = "Dashboard"),
        TranslationEntry("kpi_active_exposure", "Active Insured Exposure", "有效承保风险敞口", category = "Dashboard"),
        TranslationEntry("kpi_quotes_review", "Quotes Awaiting Underwriting", "待核保报价", category = "Dashboard"),
        TranslationEntry("kpi_expiring_policies", "Expiring Policies (30d)", "即将到期保单 (30天)", category = "Dashboard"),
        TranslationEntry("kpi_events_pending", "Events Pending Finalisation", "待确认参数事件", category = "Dashboard"),
        TranslationEntry("kpi_claims_review", "Claims Requiring Review", "待审核理赔", category = "Dashboard"),
        TranslationEntry("map_title", "Synthetic Maritime Corridor Map (No Live AIS)", "模拟海运航线图（非实时AIS船位）", category = "Dashboard"),
        TranslationEntry("feed_health_title", "Data Freshness & Integration Health", "数据新鲜度与接口健康度", category = "Dashboard"),

        // Pricing & Quote Engine
        TranslationEntry("pricing_tech_pure", "Expected Payout / Pure Loss", "预期赔付 / 纯风险成本", category = "Pricing"),
        TranslationEntry("pricing_risk_load", "Risk Loading (Synthetic)", "风险附加费（模拟）", category = "Pricing"),
        TranslationEntry("pricing_expense_load", "Expense Loading (Synthetic)", "运营费用附加（模拟）", category = "Pricing"),
        TranslationEntry("pricing_tech_total", "Technical Premium", "精算技术保费", category = "Pricing"),
        TranslationEntry("pricing_comm_adj", "Commercial Adjustment", "商业费率调整", category = "Pricing"),
        TranslationEntry("pricing_final_quote", "Final Quoted Premium", "最终参考报价保费", category = "Pricing"),
        TranslationEntry("pricing_run_mc", "Run Seeded Monte Carlo", "运行固定种子蒙特卡洛模拟", category = "Pricing"),
        TranslationEntry("pricing_bayesian_note", "Sparse data warning: Bayesian updates record priors and observations, but sparse samples cannot reliably estimate tail risk.", "稀疏数据提示：贝叶斯更新记录先验与观测值，但稀疏样本无法可靠估计尾部风险。", isContractualWording = true, category = "Pricing"),

        // Actions & Workflows
        TranslationEntry("action_submit_uw", "Submit for Underwriting", "提交核保审核", category = "Workflow"),
        TranslationEntry("action_approve_quote", "Approve Quote", "核保通过", category = "Workflow"),
        TranslationEntry("action_accept_quote", "Client Accept", "客户确认接受", category = "Workflow"),
        TranslationEntry("action_issue_policy", "Issue Policy", "正式出单", category = "Workflow"),
        TranslationEntry("action_reject", "Reject", "拒保/驳回", category = "Workflow"),
        TranslationEntry("action_cancel", "Cancel", "撤销", category = "Workflow"),
        TranslationEntry("action_endorse", "Create Controlled Endorsement", "签发受控批单", category = "Workflow"),
        TranslationEntry("action_propose_settlement", "Calculate Proposed Settlement", "计算拟定赔付", category = "Workflow"),
        TranslationEntry("action_approve_settlement", "Approve Settlement Instruction", "批准赔付指令", category = "Workflow"),

        // Validation & Error templates
        TranslationEntry("err_exhaustion_invalid", "Exhaustion threshold (E) must be strictly greater than Strike threshold (K).", "全额赔付阈值 (E) 必须严格大于触发阈值 (K)。", category = "Validation"),
        TranslationEntry("err_missing_critical", "Critical underwriting data missing: quote referred for manual Underwriting Review.", "关键核保信息缺失：报价已自动转入人工核保审核。", category = "Validation"),
        TranslationEntry("err_unauthorized_issue", "Policy issuance blocked: requires Approved/Accepted non-expired quote and authorised underwriting authority.", "出单被拒绝：须具备有效已核准/已接受报价及相应出单权限。", category = "Validation"),
        TranslationEntry("err_cross_tenant", "Access denied: cross-tenant policy or quote access is prohibited.", "拒绝访问：禁止跨租户访问保单或报价数据。", category = "Validation"),
        TranslationEntry("err_expired_quote", "Quote expired: create a new quote version before submission or issuance.", "报价已过期：请先生成新版本报价再提交或出单。", category = "Validation"),

        // Email / Webhook Notification Templates
        TranslationEntry(
            "email_quote_template",
            "Subject: [SIMULATION ONLY] Indicative Marine Quote {quoteId} — Non-Binding\nDear Broker, Indicative premium is {premium} (Valid until {expiry}). This quote is non-binding pending Underwriting Review and Policy Issuance.",
            "主题：【仅供模拟】航运保险参考报价 {quoteId} — 非承保约束\n尊敬的经纪人：本参考报价保费为 {premium}（有效期至 {expiry}）。本报价仅供模拟参考，需经核保审核并出单后方生效。",
            isContractualWording = true,
            specialistReviewed = false,
            category = "Templates"
        ),
        TranslationEntry(
            "email_settlement_template",
            "Subject: Parametric Event Observation & Proposed Settlement {settlementId}\nObservation {value} exceeded Strike Threshold {strike}. Proposed payout {payout} is pending human review and does not initiate automatic payment.",
            "主题：参数型事件观测与拟定赔付通知 {settlementId}\n观测值 {value} 已超过触发阈值 {strike}。拟定赔付金额 {payout} 正等待人工复核，系统不会自动发起付款。",
            isContractualWording = true,
            specialistReviewed = false,
            category = "Templates"
        )
    )

    private val byKey: Map<String, TranslationEntry> = defaults.associateBy { it.key }

    fun get(
        key: String,
        language: AppLanguage,
        overrides: Map<String, TranslationEntry> = emptyMap()
    ): String {
        val entry = overrides[key] ?: byKey[key] ?: return key
        return when (language) {
            AppLanguage.EN -> entry.en
            AppLanguage.ZH_CN -> entry.zhCn
        }
    }

    fun productTypeLabel(type: ProductType, language: AppLanguage): String = when (type) {
        ProductType.INDEMNITY -> if (language == AppLanguage.EN) "Indemnity Insurance" else "补偿型保险"
        ProductType.PARAMETRIC -> if (language == AppLanguage.EN) "Parametric Cover" else "参数型保险"
    }

    fun productFamilyLabel(family: ProductFamily, language: AppLanguage): String = when (family) {
        ProductFamily.CARGO -> if (language == AppLanguage.EN) "Cargo Indemnity" else "货运险（补偿型）"
        ProductFamily.HULL_MACHINERY -> if (language == AppLanguage.EN) "Hull & Machinery" else "船舶与机械险"
        ProductFamily.VOYAGE_DELAY -> if (language == AppLanguage.EN) "Excess Voyage Delay" else "航次超期延误参数险"
        ProductFamily.PORT_CLOSURE -> if (language == AppLanguage.EN) "Prolonged Port Closure" else "港口长时间封闭参数险"
        ProductFamily.WEATHER_DISRUPTION -> if (language == AppLanguage.EN) "Approved Weather Disruption" else "核准气象中断参数险"
    }

    fun quoteStatusLabel(status: QuoteStatus, language: AppLanguage): String = when (status) {
        QuoteStatus.DRAFT -> if (language == AppLanguage.EN) "Draft" else "草稿"
        QuoteStatus.CALCULATING -> if (language == AppLanguage.EN) "Calculating" else "计算中"
        QuoteStatus.INDICATIVE -> if (language == AppLanguage.EN) "Indicative" else "参考报价"
        QuoteStatus.UNDERWRITING_REVIEW -> if (language == AppLanguage.EN) "Underwriting Review" else "核保审核"
        QuoteStatus.APPROVED -> if (language == AppLanguage.EN) "Approved" else "已核准"
        QuoteStatus.ACCEPTED -> if (language == AppLanguage.EN) "Accepted" else "已接受"
        QuoteStatus.ISSUED -> if (language == AppLanguage.EN) "Issued" else "已出单"
        QuoteStatus.REJECTED -> if (language == AppLanguage.EN) "Rejected" else "已驳回"
        QuoteStatus.EXPIRED -> if (language == AppLanguage.EN) "Expired" else "已过期"
        QuoteStatus.CANCELLED -> if (language == AppLanguage.EN) "Cancelled" else "已撤销"
    }

    fun claimStageLabel(stage: ClaimStage, language: AppLanguage): String = when (stage) {
        ClaimStage.NOTIFICATION -> if (language == AppLanguage.EN) "Notification" else "出险通知"
        ClaimStage.EVIDENCE_COLLECTION -> if (language == AppLanguage.EN) "Evidence Collection" else "单证收集"
        ClaimStage.ASSESSMENT -> if (language == AppLanguage.EN) "Assessment" else "定损评估"
        ClaimStage.APPROVAL -> if (language == AppLanguage.EN) "Approval" else "理赔审批"
        ClaimStage.PAYMENT_INSTRUCTION -> if (language == AppLanguage.EN) "Payment Instruction" else "付款指令"
        ClaimStage.RECONCILIATION -> if (language == AppLanguage.EN) "Reconciliation" else "财务对账"
        ClaimStage.DECLINED -> if (language == AppLanguage.EN) "Declined" else "已拒赔"
    }

    fun feedStatusLabel(status: FeedStatus, language: AppLanguage): String = when (status) {
        FeedStatus.SIMULATED -> if (language == AppLanguage.EN) "Simulated" else "模拟源"
        FeedStatus.STALE -> if (language == AppLanguage.EN) "Stale" else "数据延迟"
        FeedStatus.UNAVAILABLE -> if (language == AppLanguage.EN) "Unavailable" else "不可用"
        FeedStatus.LIVE -> if (language == AppLanguage.EN) "Live" else "实时"
    }

    fun observationStatusLabel(status: ObservationFinalisationStatus, language: AppLanguage): String = when (status) {
        ObservationFinalisationStatus.PRELIMINARY -> if (language == AppLanguage.EN) "Preliminary" else "初步观测"
        ObservationFinalisationStatus.FINALISED -> if (language == AppLanguage.EN) "Finalised" else "已最终确认"
        ObservationFinalisationStatus.CORRECTED -> if (language == AppLanguage.EN) "Corrected" else "已修正"
        ObservationFinalisationStatus.DISPUTED -> if (language == AppLanguage.EN) "Disputed" else "存在争议"
        ObservationFinalisationStatus.MISSING -> if (language == AppLanguage.EN) "Missing" else "数据缺失"
    }
}
