package com.example.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "translation_overrides")
data class TranslationOverrideEntity(
    @PrimaryKey val key: String,
    val en: String,
    val zhCn: String,
    val isContractualWording: Boolean,
    val specialistReviewed: Boolean,
    val category: String
)

@Entity(tableName = "api_audit_logs")
data class AuditLogEntity(
    @PrimaryKey val requestId: String,
    val tenantId: String,
    val method: String,
    val path: String,
    val statusCode: Int,
    val idempotencyKey: String?,
    val idempotentReplay: Boolean,
    val requestBodyJson: String,
    val responseBodyJson: String,
    val timestampUtc: String
)

@Entity(tableName = "app_preferences")
data class AppPreferenceEntity(
    @PrimaryKey val prefKey: String,
    val prefValue: String
)

@Dao
interface TranslationOverrideDao {
    @Query("SELECT * FROM translation_overrides")
    fun observeAll(): Flow<List<TranslationOverrideEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: TranslationOverrideEntity)

    @Query("DELETE FROM translation_overrides")
    suspend fun clearAll()
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM api_audit_logs ORDER BY timestampUtc DESC LIMIT 50")
    fun observeRecent(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: AuditLogEntity)
}

@Dao
interface AppPreferenceDao {
    @Query("SELECT * FROM app_preferences")
    fun observeAll(): Flow<List<AppPreferenceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(pref: AppPreferenceEntity)
}

@Database(
    entities = [
        TranslationOverrideEntity::class,
        AuditLogEntity::class,
        AppPreferenceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RhinoMarineDatabase : RoomDatabase() {
    abstract fun translationOverrideDao(): TranslationOverrideDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun appPreferenceDao(): AppPreferenceDao

    companion object {
        @Volatile
        private var INSTANCE: RhinoMarineDatabase? = null

        fun getInstance(context: Context): RhinoMarineDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RhinoMarineDatabase::class.java,
                    "rhino_marine_china.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build().also { INSTANCE = it }
            }
        }
    }
}
