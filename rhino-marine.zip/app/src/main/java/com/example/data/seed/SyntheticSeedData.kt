package com.example.data.seed

import com.example.domain.engine.PricingAndParametricEngine
import com.example.domain.model.AgentRunRecord
import com.example.domain.model.CargoRecord
import com.example.domain.model.ClaimRecord
import com.example.domain.model.ClaimStage
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DataFeedHealth
import com.example.domain.model.EndorsementRecord
import com.example.domain.model.FeedStatus
import com.example.domain.model.FxRateRecord
import com.example.domain.model.IssuanceAuthority
import com.example.domain.model.Money
import com.example.domain.model.ObservationEvent
import com.example.domain.model.ObservationFinalisationStatus
import com.example.domain.model.ParametricProductConfig
import com.example.domain.model.PolicyRecord
import com.example.domain.model.PortNode
import com.example.domain.model.ProductFamily
import com.example.domain.model.ProductType
import com.example.domain.model.ProposedSettlement
import com.example.domain.model.QuoteRecord
import com.example.domain.model.QuoteStatus
import com.example.domain.model.VesselRecord
import com.example.domain.model.VoyageRecord
import com.example.domain.workflow.WorkflowAndCurrencyEngine
import java.math.BigDecimal

object SyntheticSeedData {

    const val TENANT_COSCO_BROKER = "tenant_east_china_logistics"
    const val TENANT_PACIFIC_CARGO = "tenant_pacific_freight_ltd"

    val ports: List<PortNode> = listOf(
        PortNode("CNTAO", "Qingdao", "青岛港", 0.34f, 0.30f, true),
        PortNode("CNSHA", "Shanghai (Yangshan)", "上海洋山港", 0.39f, 0.41f, true),
        PortNode("CNNGB", "Ningbo-Zhoushan", "宁波舟山港", 0.40f, 0.47f, true),
        PortNode("CNSZX", "Shenzhen (Yantian)", "深圳盐田港", 0.30f, 0.63f, true),
        PortNode("HKHKG", "Hong Kong", "香港港", 0.33f, 0.67f, true),
        PortNode("SGSIN", "Singapore", "新加坡港", 0.23f, 0.84f, false),
        PortNode("MYPKG", "Port Klang", "巴生港", 0.19f, 0.80f, false),
        PortNode("NLRTM", "Rotterdam", "鹿特丹港", 0.08f, 0.22f, false),
        PortNode("USLAX", "Los Angeles", "洛杉矶港", 0.88f, 0.38f, false)
    )

    val fxRates: List<FxRateRecord> = listOf(
        FxRateRecord(
            from = CurrencyCode.USD,
            to = CurrencyCode.CNY,
            rate = BigDecimal("7.1850"),
            source = "SIMULATED_PBOC_CFETS_FEED",
            timestampUtc = "2026-11-13T12:00:00Z",
            isSimulated = true
        ),
        FxRateRecord(
            from = CurrencyCode.CNY,
            to = CurrencyCode.USD,
            rate = BigDecimal("0.1392"),
            source = "SIMULATED_PBOC_CFETS_FEED",
            timestampUtc = "2026-11-13T12:00:00Z",
            isSimulated = true
        ),
        FxRateRecord(
            from = CurrencyCode.EUR,
            to = CurrencyCode.USD,
            rate = BigDecimal("1.0720"),
            source = "SIMULATED_ECB_SYNTHETIC",
            timestampUtc = "2026-11-13T12:00:00Z",
            isSimulated = true
        ),
        FxRateRecord(
            from = CurrencyCode.EUR,
            to = CurrencyCode.CNY,
            rate = BigDecimal("7.7023"),
            source = "SIMULATED_ECB_SYNTHETIC",
            timestampUtc = "2026-11-13T12:00:00Z",
            isSimulated = true
        )
    )

    val vessels: List<VesselRecord> = listOf(
        VesselRecord(
            id = "VSL-SH-01",
            tenantId = TENANT_COSCO_BROKER,
            name = "MV Yangtze Horizon",
            imoNumber = "9482104",
            mmsi = "413902114",
            vesselType = "Container Ship (Ultra Large)",
            buildYear = 2018,
            capacityDescription = "14,000 TEU",
            dwt = 148500,
            flagState = "China (HK SAR)",
            inspectionStatus = "CCS Class Clean — Valid to 2027-08",
            lastSurveyUtc = "2026-08-19T06:00:00Z"
        ),
        VesselRecord(
            id = "VSL-NB-02",
            tenantId = TENANT_COSCO_BROKER,
            name = "MV Zhoushan Pioneer",
            imoNumber = "9631022",
            mmsi = "413881209",
            vesselType = "Container Ship",
            buildYear = 2021,
            capacityDescription = "10,500 TEU",
            dwt = 112000,
            flagState = "China",
            inspectionStatus = "CCS Annual Survey Completed",
            lastSurveyUtc = "2026-09-02T03:00:00Z"
        ),
        VesselRecord(
            id = "VSL-SZ-03",
            tenantId = TENANT_COSCO_BROKER,
            name = "MV Pearl Estuary",
            imoNumber = "9754219",
            mmsi = "477319044",
            vesselType = "Feeder Container Vessel",
            buildYear = 2022,
            capacityDescription = "4,200 TEU",
            dwt = 52400,
            flagState = "Panama",
            inspectionStatus = "LR Port State Clean",
            lastSurveyUtc = "2026-10-10T08:30:00Z"
        ),
        VesselRecord(
            id = "VSL-QD-04",
            tenantId = TENANT_PACIFIC_CARGO,
            name = "MV Yellow Sea Bulk",
            imoNumber = "9310448",
            mmsi = "412400891",
            vesselType = "Capesize Bulk Carrier",
            buildYear = 2005, // > 20 years triggers referral
            capacityDescription = "175,000 DWT",
            dwt = 175000,
            flagState = "Liberia",
            inspectionStatus = "OVERDUE_SPECIAL_SURVEY",
            lastSurveyUtc = "2024-04-12T00:00:00Z"
        )
    )

    val cargos: List<CargoRecord> = listOf(
        CargoRecord(
            id = "CRG-SH-01",
            tenantId = TENANT_COSCO_BROKER,
            description = "Precision Wafer Metrology & Lithography Modules",
            category = "High-Value Electronics / Semiconductor Equipment",
            hazardClass = "STANDARD_SENSITIVE",
            packaging = "Shock-monitored 40ft HC Climate Containers (x12)",
            declaredValue = Money.of("4800000.00", CurrencyCode.USD)
        ),
        CargoRecord(
            id = "CRG-NB-02",
            tenantId = TENANT_COSCO_BROKER,
            description = "Automotive EV Powertrain Assemblies",
            category = "Industrial Machinery",
            hazardClass = "STANDARD",
            packaging = "40ft Standard ISO Containers (x28)",
            declaredValue = Money.of("16500000.00", CurrencyCode.CNY)
        ),
        CargoRecord(
            id = "CRG-SZ-03",
            tenantId = TENANT_COSCO_BROKER,
            description = "Consumer Optical Modules & Cold-Chain Reagents",
            category = "Electronics & Cold Chain",
            hazardClass = "LOW_TEMP_CONTROLLED",
            packaging = "40ft Reefer Containers (x8)",
            declaredValue = Money.of("1200000.00", CurrencyCode.USD)
        ),
        CargoRecord(
            id = "CRG-QD-04",
            tenantId = TENANT_PACIFIC_CARGO,
            description = "Refined Lithium Carbonate Battery Precursors",
            category = "Chemical / Energy Materials",
            hazardClass = "HIGH_MOISTURE_SENSITIVE",
            packaging = "Moisture-sealed Jumbo FIBC Bags",
            declaredValue = Money.of("2200000.00", CurrencyCode.USD)
        )
    )

    val voyages: List<VoyageRecord> = listOf(
        VoyageRecord(
            id = "VOY-SH-RTM-01",
            tenantId = TENANT_COSCO_BROKER,
            voyageCode = "VYG-2611-CNSHA-NLRTM",
            vesselId = "VSL-SH-01",
            originPortCode = "CNSHA",
            destinationPortCode = "NLRTM",
            intermediatePortCodes = listOf("SGSIN"),
            plannedDepartureUtc = "2026-11-15T04:00:00Z",
            plannedArrivalUtc = "2026-12-19T16:00:00Z",
            coverageInceptionUtc = "2026-11-14T00:00:00Z",
            coverageExpiryUtc = "2026-12-26T23:59:59Z",
            exposureDays = 42,
            routeExposureAssumptions = "East China Sea -> Malacca Strait -> Suez/Cape corridor; winter swell factor 1.08",
            seaCorridor = "Far East – North Europe"
        ),
        VoyageRecord(
            id = "VOY-NB-LAX-02",
            tenantId = TENANT_COSCO_BROKER,
            voyageCode = "VYG-2611-CNNGB-USLAX",
            vesselId = "VSL-NB-02",
            originPortCode = "CNNGB",
            destinationPortCode = "USLAX",
            intermediatePortCodes = emptyList(),
            plannedDepartureUtc = "2026-11-10T02:00:00Z",
            plannedArrivalUtc = "2026-11-26T14:00:00Z",
            coverageInceptionUtc = "2026-11-10T00:00:00Z",
            coverageExpiryUtc = "2026-12-05T23:59:59Z",
            exposureDays = 25,
            routeExposureAssumptions = "Trans-Pacific Eastbound; seasonal North Pacific frontal delay baseline",
            seaCorridor = "Ningbo-Zhoushan – US West Coast"
        ),
        VoyageRecord(
            id = "VOY-SZ-PKG-03",
            tenantId = TENANT_COSCO_BROKER,
            voyageCode = "VYG-2611-CNSZX-MYPKG",
            vesselId = "VSL-SZ-03",
            originPortCode = "CNSZX",
            destinationPortCode = "MYPKG",
            intermediatePortCodes = listOf("HKHKG"),
            plannedDepartureUtc = "2026-11-08T08:00:00Z",
            plannedArrivalUtc = "2026-11-15T20:00:00Z",
            coverageInceptionUtc = "2026-11-07T00:00:00Z",
            coverageExpiryUtc = "2026-11-22T23:59:59Z",
            exposureDays = 15,
            routeExposureAssumptions = "South China Sea feeder leg; late-season tropical cyclone berth suspension risk",
            seaCorridor = "Greater Bay – Malacca Feeder"
        ),
        VoyageRecord(
            id = "VOY-QD-SIN-04",
            tenantId = TENANT_PACIFIC_CARGO,
            voyageCode = "VYG-2611-CNTAO-SGSIN",
            vesselId = "VSL-QD-04",
            originPortCode = "CNTAO",
            destinationPortCode = "SGSIN",
            intermediatePortCodes = listOf("CNSHA"),
            plannedDepartureUtc = "2026-11-18T10:00:00Z",
            plannedArrivalUtc = "2026-11-29T18:00:00Z",
            coverageInceptionUtc = "2026-11-18T00:00:00Z",
            coverageExpiryUtc = "2026-12-06T23:59:59Z",
            exposureDays = 18,
            routeExposureAssumptions = "Yellow Sea & Taiwan Strait transit; dry bulk moisture control required",
            seaCorridor = "Bohai/Yellow Sea – ASEAN"
        )
    )

    val parametricTemplates: List<ParametricProductConfig> = listOf(
        ParametricProductConfig(
            productCode = "RMC-PAR-DELAY-01",
            productFamily = ProductFamily.VOYAGE_DELAY,
            titleEn = "Excess Voyage Delay Parametric Cover",
            titleZh = "航次超期延误参数型保险",
            observableNameEn = "Net Arrival Delay Beyond Scheduled ETA",
            observableNameZh = "实际抵港较计划ETA净延误时长",
            measurementUnit = "hours",
            observationLocation = "Destination Port Pilot Station (USLAX)",
            observationPeriodDays = 25,
            primaryDataSource = "Synthetic Port Call & AIS Arrival Milestone Feed",
            fallbackDataSource = "Harbour Master Official Berth Log",
            strikeThreshold = BigDecimal("48"),
            exhaustionThreshold = BigDecimal("168"),
            maxPayout = Money.of("1200000.00", CurrencyCode.CNY),
            waitingPeriodHours = 24,
            aggregationRuleEn = "Single continuous arrival delay per named voyage.",
            aggregationRuleZh = "单航次按一次连续抵港延误累计计算。",
            repeatEventRuleEn = "Maximum one trigger per insured voyage leg.",
            repeatEventRuleZh = "每一承保航段最多触发一次赔付。",
            finalisationRuleEn = "Finalised 48h after berth-all-fast timestamp.",
            finalisationRuleZh = "靠泊系缆后48小时完成数据最终确认。",
            missingDataRuleEn = "Use Harbour Master berth log fallback after 24h outage.",
            missingDataRuleZh = "主数据源中断超24小时启用港务局靠泊日志备源。",
            disputedDataRuleEn = "Escalate to independent Maritime Data Arbiter; hold payment.",
            disputedDataRuleZh = "存在争议时暂停赔付并提交独立海事数据仲裁。"
        ),
        ParametricProductConfig(
            productCode = "RMC-PAR-PORT-02",
            productFamily = ProductFamily.PORT_CLOSURE,
            titleEn = "Prolonged Port Closure Parametric Cover",
            titleZh = "港口长时间封闭参数型保险",
            observableNameEn = "Cumulative Official Terminal Suspension Duration",
            observableNameZh = "官方公告码头累计封闭暂停作业时长",
            measurementUnit = "hours",
            observationLocation = "Shenzhen Yantian Terminal (CNSZX)",
            observationPeriodDays = 15,
            primaryDataSource = "Synthetic Port Authority Suspension Bulletins",
            fallbackDataSource = "CMA / HKO Tropical Cyclone Signal #8+ Log",
            strikeThreshold = BigDecimal("24"),
            exhaustionThreshold = BigDecimal("96"),
            maxPayout = Money.of("350000.00", CurrencyCode.USD),
            waitingPeriodHours = 12,
            aggregationRuleEn = "Sum of continuous suspension windows > 6 hours within policy period.",
            aggregationRuleZh = "保单期内单次超过6小时的连续停摆时段累计相加。",
            repeatEventRuleEn = "Aggregate payout capped at Coverage Limit L across policy period.",
            repeatEventRuleZh = "整个保单期内累计赔付以赔偿限额 L 为上限。",
            finalisationRuleEn = "Finalised upon official port resumption notice + 24h.",
            finalisationRuleZh = "港口发布正式复工公告后24小时完成数据最终确认。",
            missingDataRuleEn = "Fallback to regional Maritime Safety Administration notices.",
            missingDataRuleZh = "缺失时采用海事局航行通告作为备用数据源。",
            disputedDataRuleEn = "Freeze proposed settlement pending signed terminal bulletin verification.",
            disputedDataRuleZh = "争议期间冻结拟定赔付并核验盖章码头通告。"
        ),
        ParametricProductConfig(
            productCode = "RMC-PAR-WX-03",
            productFamily = ProductFamily.WEATHER_DISRUPTION,
            titleEn = "Approved Weather Disruption Parametric Cover",
            titleZh = "核准气象中断参数型保险",
            observableNameEn = "Peak Sustained Wind Speed in Corridor Box",
            observableNameZh = "指定航道网格内最大持续风速",
            measurementUnit = "knots",
            observationLocation = "South China Sea Grid 21.5N-114.2E",
            observationPeriodDays = 15,
            primaryDataSource = "Synthetic Marine Meteorological Reanalysis Feed",
            fallbackDataSource = "Coastal Buoy Station #46091-SIM",
            strikeThreshold = BigDecimal("45"),
            exhaustionThreshold = BigDecimal("75"),
            maxPayout = Money.of("250000.00", CurrencyCode.USD),
            waitingPeriodHours = 0,
            aggregationRuleEn = "Maximum 10-minute sustained wind recorded during transit.",
            aggregationRuleZh = "取航次过境期间记录的最高10分钟持续风速。",
            repeatEventRuleEn = "One payout per named typhoon/cyclone event.",
            repeatEventRuleZh = "每次命名台风/气旋事件限赔一次。",
            finalisationRuleEn = "Finalised T+72h after storm exit.",
            finalisationRuleZh = "热带气旋移出网格后72小时最终确认。",
            missingDataRuleEn = "Interpolate using nearest verified coastal buoy fallback.",
            missingDataRuleZh = "主源缺失时采用最近核准沿岸浮标数据回补。",
            disputedDataRuleEn = "Hold settlement for meteorological agency re-issuance.",
            disputedDataRuleZh = "存在争议时等待气象机构复核公告。"
        )
    )

    fun createSeededData(): SeedBundle {
        // 1. Example 1: Cargo Indemnity Cover from Shanghai (Approved -> Issued Policy)
        val ex1Pricing = PricingAndParametricEngine.priceIndemnityQuote(
            productFamily = ProductFamily.CARGO,
            sumInsured = Money.of("4800000.00", CurrencyCode.USD),
            deductible = Money.of("50000.00", CurrencyCode.USD),
            perEventLimit = Money.of("4800000.00", CurrencyCode.USD),
            aggregateLimit = Money.of("4800000.00", CurrencyCode.USD),
            exposureDays = 42,
            vesselAgeYears = 8,
            isHighHazardCargo = false,
            seed = 20260001L
        )
        val q1Approved = QuoteRecord(
            quoteId = "Q-SH-2026-001",
            tenantId = TENANT_COSCO_BROKER,
            version = 1,
            status = QuoteStatus.APPROVED,
            productType = ProductType.INDEMNITY,
            productFamily = ProductFamily.CARGO,
            customerName = "Shanghai HuaXin Semiconductor Logistics Co.",
            vesselId = "VSL-SH-01",
            cargoId = "CRG-SH-01",
            voyageId = "VOY-SH-RTM-01",
            currency = CurrencyCode.USD,
            sumInsured = Money.of("4800000.00", CurrencyCode.USD),
            deductible = Money.of("50000.00", CurrencyCode.USD),
            coverageLimit = Money.of("4800000.00", CurrencyCode.USD),
            aggregateLimit = Money.of("4800000.00", CurrencyCode.USD),
            parametricConfig = null,
            pricingBreakdown = ex1Pricing,
            referralReasons = listOf("SUM_INSURED_EXCEEDS_AUTO_AUTHORITY"),
            underwritingNotes = "Shock-logger warranty attached; CCS survey verified clean.",
            isBinding = false,
            expiresAtUtc = "2026-12-01T23:59:59Z",
            createdAtUtc = "2026-11-05T09:15:00Z",
            updatedAtUtc = "2026-11-06T11:30:00Z",
            inputSnapshotJson = "{\"vessel\":\"MV Yangtze Horizon\",\"cargo\":\"Semiconductor Modules\",\"sum_insured\":\"4800000.00\",\"currency\":\"USD\"}"
        )
        val (q1Issued, pol1Base) = WorkflowAndCurrencyEngine.issuePolicy(
            quote = q1Approved,
            authority = IssuanceAuthority.HEAD_OF_MARINE,
            wordingVersion = "RMC-CARGO-IND-v3.1",
            inceptionUtc = "2026-11-14T00:00:00Z",
            expiryUtc = "2026-12-26T23:59:59Z",
            nowUtc = "2026-11-06T14:00:00Z"
        )
        val pol1Endorsed = WorkflowAndCurrencyEngine.appendEndorsement(
            policy = pol1Base,
            summaryEn = "Added Singapore transshipment cold-storage survey clause.",
            summaryZh = "批改增加新加坡中转恒温仓储检验条款。",
            premiumDelta = Money.of("450.00", CurrencyCode.USD),
            newWordingVersion = "RMC-CARGO-IND-v3.2",
            issuedBy = "Lin Wei (Chief Underwriter)",
            nowUtc = "2026-11-09T10:15:00Z"
        )

        // 2. Example 2: Voyage-Delay Parametric Cover departing Ningbo-Zhoushan (Issued Policy + Event Observation + Proposed Settlement)
        val delayConfig = parametricTemplates[0]
        val ex2Pricing = PricingAndParametricEngine.priceParametricQuote(
            config = delayConfig,
            exposureDays = 25,
            seed = 20260002L
        )
        val q2Approved = QuoteRecord(
            quoteId = "Q-NB-2026-002",
            tenantId = TENANT_COSCO_BROKER,
            version = 1,
            status = QuoteStatus.APPROVED,
            productType = ProductType.PARAMETRIC,
            productFamily = ProductFamily.VOYAGE_DELAY,
            customerName = "Ningbo YongGang Auto Supply Chain Ltd.",
            vesselId = "VSL-NB-02",
            cargoId = "CRG-NB-02",
            voyageId = "VOY-NB-LAX-02",
            currency = CurrencyCode.CNY,
            sumInsured = Money.of("16500000.00", CurrencyCode.CNY),
            deductible = Money.zero(CurrencyCode.CNY),
            coverageLimit = delayConfig.maxPayout,
            aggregateLimit = delayConfig.maxPayout,
            parametricConfig = delayConfig,
            pricingBreakdown = ex2Pricing,
            referralReasons = emptyList(),
            underwritingNotes = "Strike K=48h, Exhaustion E=168h, Max Payout CNY 1,200,000.00.",
            isBinding = false,
            expiresAtUtc = "2026-12-10T23:59:59Z",
            createdAtUtc = "2026-11-02T03:00:00Z",
            updatedAtUtc = "2026-11-03T07:20:00Z",
            inputSnapshotJson = "{\"voyage\":\"CNNGB->USLAX\",\"strike_hours\":48,\"exhaustion_hours\":168,\"limit\":\"1200000.00\",\"currency\":\"CNY\"}"
        )
        val (q2Issued, pol2) = WorkflowAndCurrencyEngine.issuePolicy(
            quote = q2Approved,
            authority = IssuanceAuthority.AUTHORIZED_UNDERWRITER,
            wordingVersion = "RMC-PAR-DELAY-v1.8",
            inceptionUtc = "2026-11-10T00:00:00Z",
            expiryUtc = "2026-12-05T23:59:59Z",
            nowUtc = "2026-11-04T09:00:00Z"
        )

        // 3. Example 3: Port-Closure Parametric Cover for Shenzhen Shipment (Underwriting Review + Active Issued Demo)
        val portConfig = parametricTemplates[1]
        val ex3Pricing = PricingAndParametricEngine.priceParametricQuote(
            config = portConfig,
            exposureDays = 15,
            seed = 20260003L
        )
        val q3Review = QuoteRecord(
            quoteId = "Q-SZ-2026-003",
            tenantId = TENANT_COSCO_BROKER,
            version = 1,
            status = QuoteStatus.UNDERWRITING_REVIEW,
            productType = ProductType.PARAMETRIC,
            productFamily = ProductFamily.PORT_CLOSURE,
            customerName = "Shenzhen QianHai Precision Optics Export Co.",
            vesselId = "VSL-SZ-03",
            cargoId = "CRG-SZ-03",
            voyageId = "VOY-SZ-PKG-03",
            currency = CurrencyCode.USD,
            sumInsured = Money.of("1200000.00", CurrencyCode.USD),
            deductible = Money.zero(CurrencyCode.USD),
            coverageLimit = portConfig.maxPayout,
            aggregateLimit = portConfig.maxPayout,
            parametricConfig = portConfig,
            pricingBreakdown = ex3Pricing,
            referralReasons = listOf("LATE_SEASON_TYPHOON_CORRIDOR"),
            underwritingNotes = "Yantian terminal berth-closure trigger K=24h, E=96h; awaiting Senior Underwriter sign-off.",
            isBinding = false,
            expiresAtUtc = "2026-11-30T23:59:59Z",
            createdAtUtc = "2026-11-11T06:00:00Z",
            updatedAtUtc = "2026-11-12T08:45:00Z",
            inputSnapshotJson = "{\"port\":\"CNSZX\",\"strike_hours\":24,\"exhaustion_hours\":96,\"limit\":\"350000.00\",\"currency\":\"USD\"}"
        )

        // 4. Additional Indicative & Expired Quotes for workflow completeness
        val q4Indicative = QuoteRecord(
            quoteId = "Q-SH-2026-004",
            tenantId = TENANT_COSCO_BROKER,
            version = 1,
            status = QuoteStatus.INDICATIVE,
            productType = ProductType.INDEMNITY,
            productFamily = ProductFamily.HULL_MACHINERY,
            customerName = "Yangtze Maritime Fleet Management",
            vesselId = "VSL-SH-01",
            cargoId = null,
            voyageId = "VOY-SH-RTM-01",
            currency = CurrencyCode.CNY,
            sumInsured = Money.of("18000000.00", CurrencyCode.CNY),
            deductible = Money.of("250000.00", CurrencyCode.CNY),
            coverageLimit = Money.of("18000000.00", CurrencyCode.CNY),
            aggregateLimit = Money.of("18000000.00", CurrencyCode.CNY),
            parametricConfig = null,
            pricingBreakdown = PricingAndParametricEngine.priceIndemnityQuote(
                productFamily = ProductFamily.HULL_MACHINERY,
                sumInsured = Money.of("18000000.00", CurrencyCode.CNY),
                deductible = Money.of("250000.00", CurrencyCode.CNY),
                perEventLimit = Money.of("18000000.00", CurrencyCode.CNY),
                aggregateLimit = Money.of("18000000.00", CurrencyCode.CNY),
                exposureDays = 42,
                vesselAgeYears = 8,
                isHighHazardCargo = false,
                seed = 20260004L
            ),
            referralReasons = emptyList(),
            underwritingNotes = "Hull & Machinery voyage extension simulation.",
            isBinding = false,
            expiresAtUtc = "2026-11-28T23:59:59Z",
            createdAtUtc = "2026-11-12T10:00:00Z",
            updatedAtUtc = "2026-11-12T10:05:00Z",
            inputSnapshotJson = "{\"product\":\"HULL_MACHINERY\",\"currency\":\"CNY\"}"
        )

        val q5Expired = QuoteRecord(
            quoteId = "Q-EXP-2026-005",
            tenantId = TENANT_COSCO_BROKER,
            version = 1,
            status = QuoteStatus.EXPIRED,
            productType = ProductType.PARAMETRIC,
            productFamily = ProductFamily.WEATHER_DISRUPTION,
            customerName = "South China Feeder Lines",
            vesselId = "VSL-SZ-03",
            cargoId = "CRG-SZ-03",
            voyageId = "VOY-SZ-PKG-03",
            currency = CurrencyCode.USD,
            sumInsured = Money.of("500000.00", CurrencyCode.USD),
            deductible = Money.zero(CurrencyCode.USD),
            coverageLimit = parametricTemplates[2].maxPayout,
            aggregateLimit = parametricTemplates[2].maxPayout,
            parametricConfig = parametricTemplates[2],
            pricingBreakdown = PricingAndParametricEngine.priceParametricQuote(
                config = parametricTemplates[2],
                exposureDays = 15,
                seed = 20260005L
            ),
            referralReasons = emptyList(),
            underwritingNotes = "Expired quote kept for API/issuance validation demonstration.",
            isBinding = false,
            expiresAtUtc = "2026-11-01T00:00:00Z",
            createdAtUtc = "2026-10-15T09:00:00Z",
            updatedAtUtc = "2026-11-01T00:01:00Z",
            inputSnapshotJson = "{\"expired\":true}"
        )

        // Second tenant quote to demonstrate strict tenant isolation
        val qTenant2 = QuoteRecord(
            quoteId = "Q-PAC-2026-901",
            tenantId = TENANT_PACIFIC_CARGO,
            version = 1,
            status = QuoteStatus.UNDERWRITING_REVIEW,
            productType = ProductType.INDEMNITY,
            productFamily = ProductFamily.CARGO,
            customerName = "Pacific Rim Bulk Traders Ltd.",
            vesselId = "VSL-QD-04",
            cargoId = "CRG-QD-04",
            voyageId = "VOY-QD-SIN-04",
            currency = CurrencyCode.USD,
            sumInsured = Money.of("2200000.00", CurrencyCode.USD),
            deductible = Money.of("75000.00", CurrencyCode.USD),
            coverageLimit = Money.of("2200000.00", CurrencyCode.USD),
            aggregateLimit = Money.of("2200000.00", CurrencyCode.USD),
            parametricConfig = null,
            pricingBreakdown = PricingAndParametricEngine.priceIndemnityQuote(
                productFamily = ProductFamily.CARGO,
                sumInsured = Money.of("2200000.00", CurrencyCode.USD),
                deductible = Money.of("75000.00", CurrencyCode.USD),
                perEventLimit = Money.of("2200000.00", CurrencyCode.USD),
                aggregateLimit = Money.of("2200000.00", CurrencyCode.USD),
                exposureDays = 18,
                vesselAgeYears = 21,
                isHighHazardCargo = true,
                seed = 20260901L
            ),
            referralReasons = listOf("INSPECTION_MISSING_OR_OVERDUE", "VESSEL_AGE_EXCEEDS_20_YEARS", "HIGH_HAZARD_CARGO_CLASS"),
            underwritingNotes = "Isolated tenant record — referred for overdue survey and age > 20y.",
            isBinding = false,
            expiresAtUtc = "2026-12-08T23:59:59Z",
            createdAtUtc = "2026-11-10T04:30:00Z",
            updatedAtUtc = "2026-11-10T04:35:00Z",
            inputSnapshotJson = "{\"tenant\":\"tenant_pacific_freight_ltd\"}"
        )

        val claims = listOf(
            ClaimRecord(
                claimId = "CLM-SH-2026-011",
                tenantId = TENANT_COSCO_BROKER,
                policyId = pol1Endorsed.policyId,
                productType = ProductType.INDEMNITY,
                stage = ClaimStage.ASSESSMENT,
                incidentSummaryEn = "Container #MSCU4829104 shock-logger recorded 6.4G lateral impact during heavy swell off Sri Lanka; preliminary optical alignment check ordered.",
                incidentSummaryZh = "集装箱 #MSCU4829104 在斯里兰卡外海涌浪中触发 6.4G 横向冲击记录，已安排抵港后光学精密校准检测。",
                claimedAmount = Money.of("142000.00", CurrencyCode.USD),
                assessedAmount = Money.of("92000.00", CurrencyCode.USD),
                evidenceRefs = listOf("BOL-CNSHA-9921-v1", "SHOCK-LOG-CSV-v2", "SURVEY-RPT-SGSIN-04"),
                assessorNotes = "Deductible USD 50,000 applies to gross assessed damage USD 142,000 -> net USD 92,000 pending final laboratory calibration invoice.",
                paymentInstructionRef = null,
                reconciliationRef = null,
                notifiedAtUtc = "2026-11-11T15:20:00Z",
                updatedAtUtc = "2026-11-12T18:10:00Z"
            )
        )

        val obsDelay = ObservationEvent(
            observationId = "OBS-NB-2026-101",
            tenantId = TENANT_COSCO_BROKER,
            policyId = pol2.policyId,
            productFamily = ProductFamily.VOYAGE_DELAY,
            observableName = "Net Arrival Delay Beyond Scheduled ETA",
            observedValue = BigDecimal("108"),
            unit = "hours",
            location = "USLAX Pilot Station",
            dataSource = "Synthetic Port Call & AIS Arrival Milestone Feed",
            feedStatus = FeedStatus.SIMULATED,
            finalisationStatus = ObservationFinalisationStatus.FINALISED,
            observedAtUtc = "2026-11-12T22:40:00Z",
            evidenceCitation = "SIM-PORT-CALL-USLAX-20261112-REV2"
        )

        val settlementDelay = WorkflowAndCurrencyEngine.calculateProposedSettlement(
            policy = pol2,
            observation = obsDelay,
            nowUtc = "2026-11-13T01:00:00Z"
        )

        val feedHealth = listOf(
            DataFeedHealth(
                feedCode = "WX_REANALYSIS",
                nameEn = "Maritime Weather Feed",
                nameZh = "海事气象数据源",
                status = FeedStatus.SIMULATED,
                lastUpdatedUtc = "2026-11-13T13:30:00Z",
                latencyMs = 42,
                noteEn = "Synthetic reanalysis adapter active; deterministic seed mode.",
                noteZh = "模拟气象再分析适配器运行中，采用确定性种子模式。"
            ),
            DataFeedHealth(
                feedCode = "AIS_MILESTONE",
                nameEn = "AIS & Berth Milestone Adapter",
                nameZh = "AIS与靠泊节点适配器",
                status = FeedStatus.SIMULATED,
                lastUpdatedUtc = "2026-11-13T13:15:00Z",
                latencyMs = 68,
                noteEn = "No live AIS tracking; synthetic port-call milestones only.",
                noteZh = "非实时AIS船位，仅提供模拟挂靠节点数据。"
            ),
            DataFeedHealth(
                feedCode = "PORT_CLOSURE",
                nameEn = "Port Authority Bulletin Feed",
                nameZh = "港务局封港通告源",
                status = FeedStatus.STALE,
                lastUpdatedUtc = "2026-11-13T08:10:00Z",
                latencyMs = 310,
                noteEn = "Last synthetic bulletin > 4h old; fallback meteorological feed armed.",
                noteZh = "最近模拟通告已超过4小时，已备援气象数据源。"
            ),
            DataFeedHealth(
                feedCode = "FX_RATES",
                nameEn = "Foreign Exchange Feed",
                nameZh = "外汇汇率数据源",
                status = FeedStatus.SIMULATED,
                lastUpdatedUtc = "2026-11-13T12:00:00Z",
                latencyMs = 24,
                noteEn = "Explicit CNY/USD/EUR synthetic rates with UTC timestamps.",
                noteZh = "含UTC时间戳的CNY/USD/EUR显式模拟汇率。"
            ),
            DataFeedHealth(
                feedCode = "INSURER_CORE",
                nameEn = "Insurer Core & Settlement Gateway",
                nameZh = "核心承保与结算网关",
                status = FeedStatus.UNAVAILABLE,
                lastUpdatedUtc = "2026-11-13T13:00:00Z",
                latencyMs = 0,
                noteEn = "Sandbox mode: external payment rails intentionally disconnected.",
                noteZh = "沙箱模式：外部真实支付网关已按安全策略断开。"
            )
        )

        val agentRuns = listOf(
            AgentRunRecord(
                runId = "RUN-AI-2026-001",
                tenantId = TENANT_COSCO_BROKER,
                mode = "MOCK_ADAPTER",
                taskType = "SHIPPING_DOC_EXTRACTION",
                status = "AWAITING_UNDERWRITER_REVIEW",
                promptSummary = "Extract fields from Bill of Lading BOL-CNSHA-9921-v1",
                outputSummary = "Extracted Vessel IMO 9482104, Cargo USD 4,800,000.00, Origin CNSHA -> NLRTM. 0 critical fields missing. Requires underwriter confirmation before binding.",
                requiresHumanReview = true,
                appliedToRecord = false,
                createdAtUtc = "2026-11-12T09:00:00Z"
            )
        )

        return SeedBundle(
            quotes = listOf(q1Issued, q2Issued, q3Review, q4Indicative, q5Expired, qTenant2),
            policies = listOf(pol1Endorsed, pol2),
            claims = claims,
            observations = listOf(obsDelay),
            settlements = listOf(settlementDelay),
            feedHealth = feedHealth,
            agentRuns = agentRuns
        )
    }

    data class SeedBundle(
        val quotes: List<QuoteRecord>,
        val policies: List<PolicyRecord>,
        val claims: List<ClaimRecord>,
        val observations: List<ObservationEvent>,
        val settlements: List<ProposedSettlement>,
        val feedHealth: List<DataFeedHealth>,
        val agentRuns: List<AgentRunRecord>
    )
}
