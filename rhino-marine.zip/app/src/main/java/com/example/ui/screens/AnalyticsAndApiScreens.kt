package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.api.RhinoMarineApiEngine
import com.example.domain.model.CurrencyCode
import com.example.domain.model.Money
import com.example.domain.workflow.WorkflowAndCurrencyEngine
import com.example.i18n.AppLanguage
import com.example.i18n.TranslationCatalog
import com.example.ui.RhinoMarineUiState
import com.example.ui.components.DistributionHistogramCanvas
import com.example.ui.components.SimulationBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.TerminalCard
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.RestrainedVermilion
import java.util.UUID

@Composable
fun RiskAnalyticsScreen(
    state: RhinoMarineUiState,
    t: (String) -> String
) {
    val tenantQuotes = state.quotes.filter { it.tenantId == state.activeTenantId }
    val tenantPolicies = state.policies.filter { it.tenantId == state.activeTenantId }

    val cnyExposure = tenantPolicies.filter { it.currency == CurrencyCode.CNY }
        .fold(Money.zero(CurrencyCode.CNY)) { acc, p -> acc + p.sumInsured }
    val usdExposure = tenantPolicies.filter { it.currency == CurrencyCode.USD }
        .fold(Money.zero(CurrencyCode.USD)) { acc, p -> acc + p.sumInsured }
    val convertedCny = WorkflowAndCurrencyEngine.convertPortfolioTo(
        items = tenantPolicies.map { it.sumInsured },
        targetCurrency = CurrencyCode.CNY,
        fxRates = state.fxRates
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(text = t("banner_synthetic_rates"))
        }

        item {
            TerminalCard(accentColor = MaritimeTeal) {
                Text(
                    text = if (state.language == AppLanguage.EN)
                        "Multi-Currency Exposure Isolation & Explicit FX Conversion"
                    else
                        "分币种风险敞口隔离与显式汇率折算",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text("• CNY Exposure (Standalone): ${cnyExposure.formatted()}", style = MaterialTheme.typography.bodyMedium)
                Text("• USD Exposure (Standalone): ${usdExposure.formatted()}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "• Portfolio Equivalent (CNY): ${convertedCny.formatted()}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaritimeTeal
                )
                Spacer(Modifier.height(4.dp))
                state.fxRates.forEach { fx ->
                    Text(
                        text = "${fx.from.iso}->${fx.to.iso} = ${fx.rate} | Source: ${fx.source} | ${fx.timestampUtc} (${if (fx.isSimulated) "SIMULATED" else "LIVE"})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        tenantQuotes.firstOrNull { it.pricingBreakdown != null }?.let { sampleQuote ->
            val p = sampleQuote.pricingBreakdown!!
            item {
                TerminalCard(accentColor = AmberCaution) {
                    Text(
                        text = "${sampleQuote.quoteId} • Monte Carlo Tail & Convergence (${p.modelVersion})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    DistributionHistogramCanvas(
                        buckets = p.distributionBuckets,
                        currency = sampleQuote.currency
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "StdDev: ${p.stdDev} ${sampleQuote.currency.iso} | 95% VaR: ${p.var95} ${sampleQuote.currency.iso} | Seed: ${p.simulationSeed}",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = if (state.language == AppLanguage.EN) p.bayesianCalibration.reliabilityNoteEn else p.bayesianCalibration.reliabilityNoteZh,
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberCaution
                    )
                }
            }
        }

        item {
            TerminalCard {
                Text(
                    text = t("feed_health_title"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                state.feedHealth.forEach { f ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (state.language == AppLanguage.EN) f.nameEn else f.nameZh, style = MaterialTheme.typography.titleSmall)
                            Text("${f.lastUpdatedUtc} • ${f.latencyMs}ms", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        StatusPill(
                            label = TranslationCatalog.feedStatusLabel(f.status, state.language),
                            color = MaritimeTeal
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ApiConsoleScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onExecuteApi: (method: String, path: String, idempotencyKey: String?, bodyJson: String) -> Unit,
    onTestWebhookReplay: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var method by remember { mutableStateOf("POST") }
    var path by remember { mutableStateOf("/v1/quotes") }
    var idempotencyKey by remember { mutableStateOf("idem_${UUID.randomUUID().toString().take(8)}") }
    var bodyJson by remember {
        mutableStateOf(
            """{
  "product_family": "VOYAGE_DELAY",
  "currency": "CNY",
  "sum_insured": "16500000.00",
  "coverage_limit": "1200000.00",
  "strike_threshold": "48",
  "exhaustion_threshold": "168",
  "simulation_seed": 20260002
}"""
        )
    }

    val tabs = if (state.language == AppLanguage.EN) {
        listOf("Terminal", "OpenAPI 3.1", "Python / TS SDK", "Audit Log")
    } else {
        listOf("接口调试台", "OpenAPI 3.1", "Python / TS 示例", "审计日志")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(
                text = "Tenant: ${state.activeTenantId} | Authority: ${state.activeAuthority.code} | Auth: API Key + OAuth Bearer Boundary"
            )
        }

        item {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { idx, label ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(label, maxLines = 1) }
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> {
                state.lastApiResponse?.let { res ->
                    item {
                        val isErr = res.statusCode >= 400
                        TerminalCard(
                            modifier = Modifier.testTag("api_response_card"),
                            accentColor = if (isErr) RestrainedVermilion else MaritimeTeal
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "HTTP ${res.statusCode} • ${res.requestId}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isErr) RestrainedVermilion else MaritimeTeal
                                )
                                if (res.idempotentReplay) {
                                    StatusPill(label = "IDEMPOTENT REPLAY", color = AmberCaution)
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = res.bodyJson,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.horizontalScroll(rememberScrollState())
                            )
                        }
                    }
                }
                item {
                    TerminalCard(accentColor = MaritimeTeal) {
                        Text(
                            text = if (state.language == AppLanguage.EN) "One-Click Endpoint Presets" else "一键接口测试预设",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = path == "/v1/quotes" && method == "POST",
                                onClick = {
                                    method = "POST"
                                    path = "/v1/quotes"
                                    idempotencyKey = "idem_${UUID.randomUUID().toString().take(8)}"
                                    bodyJson = """{"product_family":"VOYAGE_DELAY","currency":"CNY","sum_insured":"16500000.00","coverage_limit":"1200000.00","strike_threshold":"48","exhaustion_threshold":"168"}"""
                                },
                                label = { Text("POST /v1/quotes") }
                            )
                            FilterChip(
                                selected = path.startsWith("/v1/quotes/") && method == "GET",
                                onClick = {
                                    method = "GET"
                                    path = "/v1/quotes/Q-NB-2026-002"
                                    bodyJson = "{}"
                                },
                                label = { Text("GET /v1/quotes/{id}") }
                            )
                            FilterChip(
                                selected = path.endsWith("/submit"),
                                onClick = {
                                    method = "POST"
                                    path = "/v1/quotes/Q-SH-2026-004/submit"
                                    bodyJson = "{}"
                                },
                                label = { Text("POST /submit") }
                            )
                            FilterChip(
                                selected = path.endsWith("/approve"),
                                onClick = {
                                    method = "POST"
                                    path = "/v1/quotes/Q-SZ-2026-003/approve"
                                    bodyJson = "{}"
                                },
                                label = { Text("POST /approve") }
                            )
                            FilterChip(
                                selected = path == "/v1/policies",
                                onClick = {
                                    method = "POST"
                                    path = "/v1/policies"
                                    bodyJson = """{"quote_id":"Q-SZ-2026-003","wording_version":"RMC-PAR-PORT-v2.0"}"""
                                },
                                label = { Text("POST /v1/policies") }
                            )
                            FilterChip(
                                selected = path == "/v1/events/observations",
                                onClick = {
                                    method = "POST"
                                    path = "/v1/events/observations"
                                    bodyJson = """{"policy_id":"POL-NB-2026-002-V1","observed_value":"132","finalisation_status":"FINALISED"}"""
                                },
                                label = { Text("POST /v1/events/observations") }
                            )
                            FilterChip(
                                selected = path == "/v1/settlements/calculate",
                                onClick = {
                                    method = "POST"
                                    path = "/v1/settlements/calculate"
                                    bodyJson = """{"policy_id":"POL-NB-2026-002-V1","observation_id":"OBS-NB-2026-101"}"""
                                },
                                label = { Text("POST /v1/settlements/calculate") }
                            )
                            FilterChip(
                                selected = path == "/v1/quotes/Q-PAC-2026-901",
                                onClick = {
                                    method = "GET"
                                    path = "/v1/quotes/Q-PAC-2026-901"
                                    bodyJson = "{}"
                                },
                                label = { Text("Cross-Tenant 403 Test") }
                            )
                            FilterChip(
                                selected = path == "/v1/agent-runs/RUN-AI-2026-001",
                                onClick = {
                                    method = "GET"
                                    path = "/v1/agent-runs/RUN-AI-2026-001"
                                    bodyJson = "{}"
                                },
                                label = { Text("GET /v1/agent-runs/{id}") }
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = method,
                                onValueChange = { method = it.uppercase() },
                                label = { Text("Method") },
                                modifier = Modifier.weight(0.7f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = path,
                                onValueChange = { path = it },
                                label = { Text("Endpoint Path") },
                                modifier = Modifier.weight(2f),
                                singleLine = true
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = idempotencyKey,
                            onValueChange = { idempotencyKey = it },
                            label = { Text("Idempotency-Key (Repeat call to verify replay)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = bodyJson,
                            onValueChange = { bodyJson = it },
                            label = { Text("JSON Body") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 4
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onExecuteApi(method, path, idempotencyKey, bodyJson) },
                                modifier = Modifier.testTag("execute_api_button")
                            ) {
                                Text(if (state.language == AppLanguage.EN) "Send Request" else "发送请求")
                            }
                            OutlinedButton(
                                onClick = onTestWebhookReplay,
                                modifier = Modifier.testTag("test_webhook_replay_button")
                            ) {
                                Text(if (state.language == AppLanguage.EN) "Test Webhook Replay" else "测试Webhook防重放")
                            }
                        }

                        state.lastWebhookCheckResult?.let { msg ->
                            Spacer(Modifier.height(6.dp))
                            Text(msg, style = MaterialTheme.typography.labelMedium, color = AmberCaution)
                        }
                    }
                }
            }

            1 -> {
                item {
                    TerminalCard {
                        Text(
                            text = RhinoMarineApiEngine.openApiSpecSnippet,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        )
                    }
                }
            }

            2 -> {
                item {
                    TerminalCard(accentColor = MaritimeTeal) {
                        Text("Python (httpx) Client", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = RhinoMarineApiEngine.pythonClientExample,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        )
                    }
                }
                item {
                    TerminalCard(accentColor = AmberCaution) {
                        Text("TypeScript (fetch) Client", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = RhinoMarineApiEngine.typescriptClientExample,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        )
                    }
                }
            }

            3 -> {
                items(state.apiAuditLogs, key = { it.requestId }) { log ->
                    TerminalCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${log.method} ${log.path}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            StatusPill(
                                label = "${log.statusCode}${if (log.idempotentReplay) " REPLAY" else ""}",
                                color = if (log.statusCode >= 400) RestrainedVermilion else MaritimeTeal
                            )
                        }
                        Text("${log.requestId} | Tenant: ${log.tenantId} | ${log.timestampUtc}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
