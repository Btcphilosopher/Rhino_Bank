package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.ObservationFinalisationStatus
import com.example.domain.model.ProductType
import com.example.i18n.AppLanguage
import com.example.i18n.TranslationCatalog
import com.example.ui.RhinoMarineUiState
import com.example.ui.components.SimulationBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.TerminalCard
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.RestrainedVermilion

@Composable
fun PoliciesScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onAddEndorsement: (policyId: String, summaryEn: String, summaryZh: String, delta: String) -> Unit
) {
    val tenantPolicies = state.policies.filter { it.tenantId == state.activeTenantId }
    var endorseTargetId by remember { mutableStateOf<String?>(null) }
    var endorseSummaryEn by remember { mutableStateOf("Extend arrival window by 72 hours due to port congestion") }
    var endorseSummaryZh by remember { mutableStateOf("因目的港拥堵，批改延长抵港保障期72小时") }
    var endorseDelta by remember { mutableStateOf("250.00") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(
                text = if (state.language == AppLanguage.EN)
                    "Policy Governance: Issued policies are immutable; changes must append a Controlled Endorsement with wording version tracking."
                else
                    "保单治理原则：已出单保单不可静默篡改，任何变更必须生成带条款版本号的受控批单。"
            )
        }

        items(tenantPolicies, key = { it.policyId }) { p ->
            TerminalCard(accentColor = MaritimeTeal) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${p.policyId} • ${TranslationCatalog.productFamilyLabel(p.productFamily, state.language)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${p.insuredName} | Wording: ${p.wordingVersion}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    StatusPill(label = p.status, color = MaritimeTeal)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "${t("term_sum_insured")}: ${p.sumInsured.formatted()} | ${t("term_coverage_limit")}: ${p.coverageLimit.formatted()} | ${t("term_premium")}: ${p.issuedPremium.formatted()}",
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    text = "Period (UTC): ${p.inceptionUtc} -> ${p.expiryUtc} | Authority: ${p.issuedByAuthority.code}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                p.parametricConfig?.let { cfg ->
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${t("term_strike_threshold")}: ${cfg.strikeThreshold} ${cfg.measurementUnit} | ${t("term_exhaustion_threshold")}: ${cfg.exhaustionThreshold} ${cfg.measurementUnit}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberCaution
                    )
                }

                if (p.endorsements.isNotEmpty()) {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(
                        text = if (state.language == AppLanguage.EN) "Endorsement History (${p.endorsements.size})" else "批单历史记录 (${p.endorsements.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    p.endorsements.forEach { end ->
                        Text(
                            text = "#${end.sequenceNumber} [${end.wordingVersion}] ${if (state.language == AppLanguage.EN) end.summaryEn else end.summaryZh} (${end.premiumDelta.formatted()} • ${end.issuedAtUtc})",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { endorseTargetId = if (endorseTargetId == p.policyId) null else p.policyId },
                    modifier = Modifier.testTag("toggle_endorse_${p.policyId}")
                ) {
                    Text(t("action_endorse"))
                }

                if (endorseTargetId == p.policyId) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = endorseSummaryEn,
                        onValueChange = { endorseSummaryEn = it },
                        label = { Text("Endorsement Summary (EN)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = endorseSummaryZh,
                        onValueChange = { endorseSummaryZh = it },
                        label = { Text("批改摘要 (简体中文)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = endorseDelta,
                        onValueChange = { endorseDelta = it },
                        label = { Text("Premium Delta (${p.currency.iso})") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            onAddEndorsement(p.policyId, endorseSummaryEn, endorseSummaryZh, endorseDelta)
                            endorseTargetId = null
                        },
                        modifier = Modifier.testTag("submit_endorse_button")
                    ) {
                        Text(if (state.language == AppLanguage.EN) "Append Endorsement" else "签发批单")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClaimsScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onAdvanceClaimStage: (String) -> Unit,
    onRecordObservationAndPropose: (policyId: String, observedValue: String, status: ObservationFinalisationStatus) -> Unit,
    onApproveSettlement: (String) -> Unit
) {
    val tenantClaims = state.claims.filter { it.tenantId == state.activeTenantId }
    val tenantParamPolicies = state.policies.filter {
        it.tenantId == state.activeTenantId && it.productType == ProductType.PARAMETRIC
    }
    val tenantObservations = state.observations.filter { it.tenantId == state.activeTenantId }
    val tenantSettlements = state.settlements.filter { it.tenantId == state.activeTenantId }

    var obsValueInput by remember { mutableStateOf("120") }
    var obsStatus by remember { mutableStateOf(ObservationFinalisationStatus.FINALISED) }
    val selectedParamPolicy = tenantParamPolicies.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(
                text = if (state.language == AppLanguage.EN)
                    "Indemnity Claims & Parametric Settlements are separated. Observed trigger events NEVER initiate automatic payments without human review."
                else
                    "补偿型理赔与参数型赔付流程严格分离。参数触发观测绝不会自动发起付款，必须经过人工复核批准。"
            )
        }

        // Section 1: Indemnity Claims
        item {
            Text(
                text = if (state.language == AppLanguage.EN)
                    "Indemnity Claims Workflow (Notification -> Reconciliation)"
                else
                    "补偿型理赔流程（出险通知 -> 财务对账）",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        items(tenantClaims, key = { it.claimId }) { c ->
            TerminalCard(accentColor = AmberCaution) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${c.claimId} (${c.policyId})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    StatusPill(
                        label = TranslationCatalog.claimStageLabel(c.stage, state.language),
                        color = AmberCaution
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (state.language == AppLanguage.EN) c.incidentSummaryEn else c.incidentSummaryZh,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Claimed: ${c.claimedAmount.formatted()} | Assessed: ${c.assessedAmount?.formatted() ?: "Pending"} | Evidence: ${c.evidenceRefs.joinToString()}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                c.paymentInstructionRef?.let {
                    Text("Payment Ref: $it | Reconciliation: ${c.reconciliationRef ?: "Pending"}", style = MaterialTheme.typography.labelSmall, color = MaritimeTeal)
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { onAdvanceClaimStage(c.claimId) },
                    modifier = Modifier.testTag("advance_claim_${c.claimId}")
                ) {
                    Text(if (state.language == AppLanguage.EN) "Advance Claim Stage" else "推进理赔阶段")
                }
            }
        }

        // Section 2: Parametric Observations & Proposed Settlements
        item {
            Text(
                text = if (state.language == AppLanguage.EN)
                    "Parametric Event Observations & Proposed Settlements"
                else
                    "参数型事件观测与拟定赔付测算",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (selectedParamPolicy != null) {
            item {
                TerminalCard(accentColor = MaritimeTeal) {
                    Text(
                        text = if (state.language == AppLanguage.EN)
                            "Ingest Observation for ${selectedParamPolicy.policyId}"
                        else
                            "录入参数观测事件 (${selectedParamPolicy.policyId})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = obsValueInput,
                        onValueChange = { obsValueInput = it },
                        label = { Text("Observed Metric (${selectedParamPolicy.parametricConfig?.measurementUnit ?: "hours"})") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            ObservationFinalisationStatus.PRELIMINARY,
                            ObservationFinalisationStatus.FINALISED,
                            ObservationFinalisationStatus.CORRECTED,
                            ObservationFinalisationStatus.DISPUTED,
                            ObservationFinalisationStatus.MISSING
                        ).forEach { st ->
                            FilterChip(
                                selected = obsStatus == st,
                                onClick = { obsStatus = st },
                                label = { Text(TranslationCatalog.observationStatusLabel(st, state.language)) }
                            )
                        }
                    }
                    Button(
                        onClick = { onRecordObservationAndPropose(selectedParamPolicy.policyId, obsValueInput, obsStatus) },
                        modifier = Modifier.testTag("propose_settlement_button")
                    ) {
                        Text(t("action_propose_settlement"))
                    }
                }
            }
        }

        items(tenantSettlements, key = { it.settlementId }) { s ->
            val obs = tenantObservations.firstOrNull { it.observationId == s.observationId }
            val held = s.approvalStatus == "HELD_FOR_DISPUTE"
            val approved = s.approvalStatus == "APPROVED_FOR_PAYMENT"
            TerminalCard(accentColor = if (held) RestrainedVermilion else MaritimeTeal) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${s.settlementId} (${s.policyId})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    StatusPill(
                        label = s.approvalStatus,
                        color = when {
                            approved -> MaritimeTeal
                            held -> RestrainedVermilion
                            else -> AmberCaution
                        }
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Observed x=${s.observedValue} vs K=${s.strikeThreshold} / E=${s.exhaustionThreshold} -> Proposed Payout: ${s.calculatedPayout.formatted()}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Auto-Payment Initiated: ${s.autoPaymentInitiated} | Source: ${obs?.dataSource ?: "-"} (${obs?.finalisationStatus?.code ?: "-"})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (state.language == AppLanguage.EN) s.basisRiskDisclaimerEn else s.basisRiskDisclaimerZh,
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberCaution
                )
                if (!approved) {
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onApproveSettlement(s.settlementId) },
                        modifier = Modifier.testTag("approve_settlement_${s.settlementId}")
                    ) {
                        Text(t("action_approve_settlement"))
                    }
                }
            }
        }
    }
}
