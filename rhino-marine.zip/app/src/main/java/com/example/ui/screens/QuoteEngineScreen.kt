package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.CurrencyCode
import com.example.domain.model.ProductFamily
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteRecord
import com.example.domain.model.QuoteStatus
import com.example.i18n.AppLanguage
import com.example.i18n.TranslationCatalog
import com.example.ui.RhinoMarineUiState
import com.example.ui.components.DistributionHistogramCanvas
import com.example.ui.components.SimulationBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.TerminalCard
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.RestrainedVermilion
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuoteEngineScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onCreateQuote: (
        ProductFamily, String, String, String?, String, CurrencyCode,
        String, String, String, String, String, Long, Int, Double
    ) -> Unit,
    onTransitionQuote: (String, QuoteStatus) -> Unit,
    onIssuePolicy: (String) -> Unit
) {
    var selectedFamily by remember { mutableStateOf(ProductFamily.VOYAGE_DELAY) }
    var customerName by remember { mutableStateOf("Ningbo Coastal Freight Co.") }
    var selectedCurrency by remember { mutableStateOf(CurrencyCode.CNY) }
    var sumInsuredStr by remember { mutableStateOf("12000000.00") }
    var deductibleStr by remember { mutableStateOf("50000.00") }
    var limitStr by remember { mutableStateOf("1000000.00") }
    var strikeStr by remember { mutableStateOf("48") }
    var exhaustionStr by remember { mutableStateOf("168") }
    var seedStr by remember { mutableStateOf("20261113") }
    var commAdjPct by remember { mutableDoubleStateOf(0.0) }
    var selectedQuoteId by remember { mutableStateOf<String?>(null) }
    var showEmailPreviewId by remember { mutableStateOf<String?>(null) }

    val tenantVessels = state.vessels.filter { it.tenantId == state.activeTenantId }
    val tenantCargos = state.cargos.filter { it.tenantId == state.activeTenantId }
    val tenantVoyages = state.voyages.filter { it.tenantId == state.activeTenantId }
    val tenantQuotes = state.quotes.filter { it.tenantId == state.activeTenantId }

    val activeVesselId = tenantVessels.firstOrNull()?.id ?: ""
    val activeCargoId = tenantCargos.firstOrNull()?.id
    val activeVoyageId = tenantVoyages.firstOrNull()?.id ?: ""

    val focusedQuote = tenantQuotes.firstOrNull { it.quoteId == selectedQuoteId } ?: tenantQuotes.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(text = "${t("explain_indemnity_vs_parametric")} • ${t("term_simulation_only")}")
        }

        // Quote Builder Card
        item {
            TerminalCard(accentColor = MaritimeTeal) {
                Text(
                    text = t("nav_quote_engine"),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (state.language == AppLanguage.EN)
                        "Select Product Family (Indemnity vs Parametric separated):"
                    else
                        "选择险种系列（补偿型与参数型严格分离）：",
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProductFamily.entries.forEach { family ->
                        FilterChip(
                            selected = selectedFamily == family,
                            onClick = { selectedFamily = family },
                            label = { Text(TranslationCatalog.productFamilyLabel(family, state.language)) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(CurrencyCode.CNY, CurrencyCode.USD, CurrencyCode.EUR).forEach { ccy ->
                        FilterChip(
                            selected = selectedCurrency == ccy,
                            onClick = { selectedCurrency = ccy },
                            label = { Text(ccy.iso) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text(if (state.language == AppLanguage.EN) "Insured / Customer" else "被保险人 / 客户名称") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sumInsuredStr,
                        onValueChange = { sumInsuredStr = it },
                        label = { Text("${t("term_sum_insured")} (${selectedCurrency.iso})") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = limitStr,
                        onValueChange = { limitStr = it },
                        label = { Text("${t("term_coverage_limit")} (${selectedCurrency.iso})") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                if (selectedFamily.productType == ProductType.INDEMNITY) {
                    OutlinedTextField(
                        value = deductibleStr,
                        onValueChange = { deductibleStr = it },
                        label = { Text("${t("term_deductible")} (${selectedCurrency.iso})") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = strikeStr,
                            onValueChange = { strikeStr = it },
                            label = { Text("${t("term_strike_threshold")} K") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = exhaustionStr,
                            onValueChange = { exhaustionStr = it },
                            label = { Text("${t("term_exhaustion_threshold")} E") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = seedStr,
                        onValueChange = { seedStr = it },
                        label = { Text(if (state.language == AppLanguage.EN) "MC Seed" else "蒙特卡洛种子") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Column(modifier = Modifier.weight(1.4f)) {
                        Text(
                            text = "${t("pricing_comm_adj")}: ${commAdjPct.roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = commAdjPct.toFloat(),
                            onValueChange = { commAdjPct = it.toDouble() },
                            valueRange = -15f..25f
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        onCreateQuote(
                            selectedFamily,
                            customerName,
                            activeVesselId,
                            if (selectedFamily == ProductFamily.CARGO) activeCargoId else null,
                            activeVoyageId,
                            selectedCurrency,
                            sumInsuredStr,
                            deductibleStr,
                            limitStr,
                            strikeStr,
                            exhaustionStr,
                            seedStr.toLongOrNull() ?: 20261113L,
                            2000,
                            commAdjPct
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("run_pricing_button")
                ) {
                    Text(t("pricing_run_mc"))
                }
            }
        }

        // Focused Quote Pricing Transparency & Bayesian Analytics
        focusedQuote?.let { q ->
            item {
                PricingDetailCard(
                    quote = q,
                    language = state.language,
                    t = t,
                    showEmail = showEmailPreviewId == q.quoteId,
                    onToggleEmail = {
                        showEmailPreviewId = if (showEmailPreviewId == q.quoteId) null else q.quoteId
                    },
                    onTransition = { target -> onTransitionQuote(q.quoteId, target) },
                    onIssue = { onIssuePolicy(q.quoteId) }
                )
            }
        }

        // Quote Queue List
        item {
            Text(
                text = if (state.language == AppLanguage.EN) "Tenant Quotes (${tenantQuotes.size})" else "当前租户报价列表 (${tenantQuotes.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        items(tenantQuotes, key = { it.quoteId }) { q ->
            TerminalCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${q.quoteId} (v${q.version}) • ${TranslationCatalog.productTypeLabel(q.productType, state.language)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${q.customerName} | ${q.pricingBreakdown?.finalQuotedPremium?.formatted() ?: "-"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (q.referralReasons.isNotEmpty()) {
                            Text(
                                text = "Referrals: ${q.referralReasons.joinToString()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = RestrainedVermilion
                            )
                        }
                    }
                    StatusPill(
                        label = TranslationCatalog.quoteStatusLabel(q.status, state.language),
                        color = when (q.status) {
                            QuoteStatus.ISSUED, QuoteStatus.APPROVED -> MaritimeTeal
                            QuoteStatus.EXPIRED, QuoteStatus.REJECTED -> RestrainedVermilion
                            else -> AmberCaution
                        }
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { selectedQuoteId = q.quoteId },
                    modifier = Modifier.testTag("inspect_quote_${q.quoteId}")
                ) {
                    Text(if (state.language == AppLanguage.EN) "Inspect Breakdown & Workflow" else "查看报价明细与流转")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PricingDetailCard(
    quote: QuoteRecord,
    language: AppLanguage,
    t: (String) -> String,
    showEmail: Boolean,
    onToggleEmail: () -> Unit,
    onTransition: (QuoteStatus) -> Unit,
    onIssue: () -> Unit
) {
    val p = quote.pricingBreakdown
    TerminalCard(accentColor = AmberCaution) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${quote.quoteId} v${quote.version} • ${TranslationCatalog.productFamilyLabel(quote.productFamily, language)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Binding: ${quote.isBinding} | Expires: ${quote.expiresAtUtc}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            StatusPill(
                label = TranslationCatalog.quoteStatusLabel(quote.status, language),
                color = MaritimeTeal
            )
        }

        if (p != null) {
            Spacer(Modifier.height(10.dp))
            PriceRow(t("pricing_tech_pure"), p.expectedLossOrPayout.formatted())
            PriceRow(t("pricing_risk_load"), p.riskLoading.formatted())
            PriceRow(t("pricing_expense_load"), p.expenseLoading.formatted())
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            PriceRow(t("pricing_tech_total"), p.technicalPremium.formatted(), bold = true)
            PriceRow(t("pricing_comm_adj"), p.commercialAdjustment.formatted())
            PriceRow(t("pricing_final_quote"), "${p.finalQuotedPremium.formatted()} (${t("term_simulation_only")})", bold = true)

            Spacer(Modifier.height(8.dp))
            Text(
                text = "Model ${p.modelVersion} | Seed ${p.simulationSeed} | ${p.simulationRuns} runs | 95% VaR ${p.var95.toPlainString()} ${quote.currency.iso}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            DistributionHistogramCanvas(buckets = p.distributionBuckets, currency = quote.currency)

            Spacer(Modifier.height(8.dp))
            Text(
                text = "Bayesian Calibration: prior=${"%.4f".format(p.bayesianCalibration.priorMean)}, obs(n=${p.bayesianCalibration.observedCount})=${"%.4f".format(p.bayesianCalibration.observedMean)}, posterior=${"%.4f".format(p.bayesianCalibration.posteriorMean)}",
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                text = if (language == AppLanguage.EN) p.bayesianCalibration.reliabilityNoteEn else p.bayesianCalibration.reliabilityNoteZh,
                style = MaterialTheme.typography.bodySmall,
                color = AmberCaution
            )

            Spacer(Modifier.height(6.dp))
            Text(
                text = "Convergence: " + p.convergenceCheck.joinToString(" -> ") { "n=${it.sampleCount}: ${it.runningMean}" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Sensitivity: " + p.sensitivitySamples.joinToString(" | ") { "${it.parameterLabel}: ${it.technicalPremium}" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (quote.status == QuoteStatus.INDICATIVE) {
                Button(onClick = { onTransition(QuoteStatus.UNDERWRITING_REVIEW) }) {
                    Text(t("action_submit_uw"))
                }
            }
            if (quote.status == QuoteStatus.UNDERWRITING_REVIEW) {
                Button(onClick = { onTransition(QuoteStatus.APPROVED) }) {
                    Text(t("action_approve_quote"))
                }
                OutlinedButton(
                    onClick = { onTransition(QuoteStatus.REJECTED) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RestrainedVermilion)
                ) {
                    Text(t("action_reject"))
                }
            }
            if (quote.status == QuoteStatus.APPROVED) {
                OutlinedButton(onClick = { onTransition(QuoteStatus.ACCEPTED) }) {
                    Text(t("action_accept_quote"))
                }
            }
            if (quote.status == QuoteStatus.APPROVED || quote.status == QuoteStatus.ACCEPTED) {
                Button(
                    onClick = onIssue,
                    modifier = Modifier.testTag("issue_policy_button")
                ) {
                    Text(t("action_issue_policy"))
                }
            }
            OutlinedButton(onClick = onToggleEmail) {
                Text(if (language == AppLanguage.EN) "Email Template" else "邮件模板预览")
            }
        }

        if (showEmail && p != null) {
            Spacer(Modifier.height(8.dp))
            val template = t("email_quote_template")
                .replace("{quoteId}", quote.quoteId)
                .replace("{premium}", p.finalQuotedPremium.formatted())
                .replace("{expiry}", quote.expiresAtUtc)
            Text(
                text = template,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PriceRow(label: String, value: String, bold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium
        )
    }
}
