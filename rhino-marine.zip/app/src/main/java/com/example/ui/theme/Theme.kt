package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val RhinoLightColorScheme = lightColorScheme(
    primary = MidnightNavy,
    onPrimary = PorcelainWhite,
    primaryContainer = SlateNavy,
    onPrimaryContainer = PorcelainWhite,
    secondary = MaritimeTeal,
    onSecondary = Color.White,
    secondaryContainer = TealContainerLight,
    onSecondaryContainer = Color(0xFF063A36),
    tertiary = RestrainedVermilion,
    onTertiary = Color.White,
    tertiaryContainer = VermilionSoft,
    onTertiaryContainer = VermilionDark,
    background = PorcelainWhite,
    onBackground = InkPrimary,
    surface = CrispPaper,
    onSurface = InkPrimary,
    surfaceVariant = MistSurface,
    onSurfaceVariant = InkSecondary,
    outline = GridLineLight,
    outlineVariant = Color(0xFFE2E8F0),
    error = RestrainedVermilion,
    onError = Color.White,
    errorContainer = VermilionSoft,
    onErrorContainer = VermilionDark
)

private val RhinoDarkColorScheme = darkColorScheme(
    primary = SeafoamTeal,
    onPrimary = MidnightNavy,
    primaryContainer = DeepMaritimeNavy,
    onPrimaryContainer = PorcelainTextDark,
    secondary = MaritimeTeal,
    onSecondary = Color.White,
    secondaryContainer = TealContainerDark,
    onSecondaryContainer = SeafoamTeal,
    tertiary = Color(0xFFF07160),
    onTertiary = Color(0xFF3B0903),
    tertiaryContainer = VermilionDark,
    onTertiaryContainer = VermilionSoft,
    background = MidnightNavy,
    onBackground = PorcelainTextDark,
    surface = DeepMaritimeNavy,
    onSurface = PorcelainTextDark,
    surfaceVariant = SlateNavy,
    onSurfaceVariant = SlateTextDark,
    outline = SteelBorderDark,
    outlineVariant = Color(0xFF1F385A),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = VermilionDark,
    onErrorContainer = VermilionSoft
)

val RhinoShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
    extraLarge = RoundedCornerShape(18.dp)
)

@Composable
fun RhinoMarineTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) RhinoDarkColorScheme else RhinoLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = RhinoTypography,
        shapes = RhinoShapes,
        content = content
    )
}
