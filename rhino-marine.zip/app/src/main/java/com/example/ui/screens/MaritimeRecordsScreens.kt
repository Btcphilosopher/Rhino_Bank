package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.CurrencyCode
import com.example.i18n.AppLanguage
import com.example.ui.RhinoMarineUiState
import com.example.ui.components.SimulationBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.TerminalCard
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.RestrainedVermilion

@Composable
fun VoyagesScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onAddVoyage: (origin: String, destination: String, vesselId: String, exposureDays: Int, assumptions: String) -> Unit
) {
    val tenantVoyages = state.voyages.filter { it.tenantId == state.activeTenantId }
    val tenantVessels = state.vessels.filter { it.tenantId == state.activeTenantId }
    var origin by remember { mutableStateOf("CNSHA") }
    var destination by remember { mutableStateOf("SGSIN") }
    var daysStr by remember { mutableStateOf("14") }
    var assumptions by remember { mutableStateOf("South China Sea winter monsoon baseline") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(text = t("banner_synthetic_rates"))
        }
        item {
            TerminalCard(accentColor = MaritimeTeal) {
                Text(
                    text = t("nav_voyages"),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = origin,
                        onValueChange = { origin = it.uppercase() },
                        label = { Text(if (state.language == AppLanguage.EN) "Origin UNLOCODE" else "起运港代码") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it.uppercase() },
                        label = { Text(if (state.language == AppLanguage.EN) "Destination UNLOCODE" else "目的港代码") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = daysStr,
                        onValueChange = { daysStr = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Exposure Days" else "承保天数") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = assumptions,
                        onValueChange = { assumptions = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Route Assumptions" else "航线风险假设") },
                        modifier = Modifier.weight(2f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        onAddVoyage(
                            origin,
                            destination,
                            tenantVessels.firstOrNull()?.id ?: "",
                            daysStr.toIntOrNull() ?: 0,
                            assumptions
                        )
                    },
                    modifier = Modifier.testTag("add_voyage_button")
                ) {
                    Text(if (state.language == AppLanguage.EN) "Register Voyage Schedule" else "登记航次计划")
                }
            }
        }
        items(tenantVoyages, key = { it.id }) { v ->
            val vessel = state.vessels.firstOrNull { it.id == v.vesselId }
            TerminalCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${v.voyageCode} • ${v.originPortCode} -> ${v.destinationPortCode}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    StatusPill(label = "${v.exposureDays}d", color = MaritimeTeal)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Vessel: ${vessel?.name ?: v.vesselId} | Via: ${if (v.intermediatePortCodes.isEmpty()) "Direct" else v.intermediatePortCodes.joinToString()}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Departure (UTC): ${v.plannedDepartureUtc} | Arrival (UTC): ${v.plannedArrivalUtc}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Cover Period: ${v.coverageInceptionUtc} .. ${v.coverageExpiryUtc}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = v.routeExposureAssumptions,
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberCaution
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VesselsCargoScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onAddVessel: (name: String, imo: String, type: String, year: Int, cap: String, inspection: String) -> Unit,
    onAddCargo: (desc: String, cat: String, pack: String, value: String, ccy: CurrencyCode, hazard: String) -> Unit
) {
    val tenantVessels = state.vessels.filter { it.tenantId == state.activeTenantId }
    val tenantCargos = state.cargos.filter { it.tenantId == state.activeTenantId }

    var vName by remember { mutableStateOf("") }
    var vImo by remember { mutableStateOf("") }
    var vType by remember { mutableStateOf("Container Ship") }
    var vYear by remember { mutableStateOf("2019") }
    var vCap by remember { mutableStateOf("8,500 TEU") }
    var vInsp by remember { mutableStateOf("CCS Annual Clean") }

    var cDesc by remember { mutableStateOf("") }
    var cCat by remember { mutableStateOf("Precision Machinery") }
    var cPack by remember { mutableStateOf("40ft HC Container") }
    var cVal by remember { mutableStateOf("2500000.00") }
    var cCcy by remember { mutableStateOf(CurrencyCode.CNY) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(
                text = if (state.language == AppLanguage.EN)
                    "Validation Policy: Missing IMO, inspection, or cargo value triggers validation error or underwriting referral (no invented data)."
                else
                    "校验原则：缺少 IMO 编号、船检信息或货值将触发报错或转入核保审核，系统绝不编造数据。"
            )
        }

        // Vessel Entry Form
        item {
            TerminalCard(accentColor = MaritimeTeal) {
                Text(
                    text = if (state.language == AppLanguage.EN) "Register Vessel" else "登记船舶信息",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = vName,
                        onValueChange = { vName = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Vessel Name*" else "船名*") },
                        modifier = Modifier.weight(1.4f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = vImo,
                        onValueChange = { vImo = it },
                        label = { Text("IMO*") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = vType,
                        onValueChange = { vType = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Vessel Type" else "船型") },
                        modifier = Modifier.weight(1.2f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = vYear,
                        onValueChange = { vYear = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Build Year" else "建造年份") },
                        modifier = Modifier.weight(0.8f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = vCap,
                        onValueChange = { vCap = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Capacity" else "载重/箱位") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = vInsp,
                        onValueChange = { vInsp = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Inspection" else "船检状态") },
                        modifier = Modifier.weight(1.3f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { onAddVessel(vName, vImo, vType, vYear.toIntOrNull() ?: 2015, vCap, vInsp) },
                    modifier = Modifier.testTag("add_vessel_button")
                ) {
                    Text(if (state.language == AppLanguage.EN) "Add Vessel" else "保存船舶")
                }
            }
        }

        items(tenantVessels, key = { it.id }) { v ->
            val overdue = v.inspectionStatus.contains("OVERDUE", true)
            TerminalCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("${v.name} (IMO ${v.imoNumber})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    StatusPill(
                        label = "${v.buildYear} • ${v.capacityDescription}",
                        color = if (overdue) RestrainedVermilion else MaritimeTeal
                    )
                }
                Text("${v.vesselType} | Flag: ${v.flagState}", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "Inspection: ${v.inspectionStatus} (${v.lastSurveyUtc})",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (overdue) RestrainedVermilion else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Cargo Entry Form
        item {
            TerminalCard(accentColor = AmberCaution) {
                Text(
                    text = if (state.language == AppLanguage.EN) "Register Cargo Manifest" else "登记货物清单",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = cDesc,
                    onValueChange = { cDesc = it },
                    label = { Text(if (state.language == AppLanguage.EN) "Cargo Description*" else "货物描述*") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = cCat,
                        onValueChange = { cCat = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Category" else "货物类别") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cPack,
                        onValueChange = { cPack = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Packaging" else "包装方式") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = cVal,
                    onValueChange = { cVal = it },
                    label = { Text("${t("term_sum_insured")} (${cCcy.iso})*") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(CurrencyCode.CNY, CurrencyCode.USD, CurrencyCode.EUR).forEach { ccy ->
                        FilterChip(selected = cCcy == ccy, onClick = { cCcy = ccy }, label = { Text(ccy.iso) })
                    }
                }
                Button(
                    onClick = { onAddCargo(cDesc, cCat, cPack, cVal, cCcy, "STANDARD") },
                    modifier = Modifier.testTag("add_cargo_button")
                ) {
                    Text(if (state.language == AppLanguage.EN) "Add Cargo" else "保存货物")
                }
            }
        }

        items(tenantCargos, key = { it.id }) { c ->
            TerminalCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(c.description, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    StatusPill(label = c.declaredValue.formatted(), color = MaritimeTeal)
                }
                Text("${c.category} | ${c.packaging} | Hazard: ${c.hazardClass}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
