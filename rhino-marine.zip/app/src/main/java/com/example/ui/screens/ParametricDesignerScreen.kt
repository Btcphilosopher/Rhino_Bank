package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.engine.PricingAndParametricEngine
import com.example.domain.model.Money
import com.example.domain.model.ParametricProductConfig
import com.example.i18n.AppLanguage
import com.example.ui.RhinoMarineUiState
import com.example.ui.components.ParametricPayoutCurveCanvas
import com.example.ui.components.SimulationBanner
import com.example.ui.components.TerminalCard
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.RestrainedVermilion
import java.math.BigDecimal
import java.math.RoundingMode

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ParametricDesignerScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onUpdateTemplate: (ParametricProductConfig) -> Unit
) {
    var selectedCode by remember { mutableStateOf(state.parametricTemplates.first().productCode) }
    val active = state.parametricTemplates.firstOrNull { it.productCode == selectedCode }
        ?: state.parametricTemplates.first()

    var strikeInput by remember(selectedCode) { mutableStateOf(active.strikeThreshold.toPlainString()) }
    var exhaustionInput by remember(selectedCode) { mutableStateOf(active.exhaustionThreshold.toPlainString()) }
    var maxPayoutInput by remember(selectedCode) { mutableStateOf(active.maxPayout.rounded().toPlainString()) }
    var locationInput by remember(selectedCode) { mutableStateOf(active.observationLocation) }
    var primarySourceInput by remember(selectedCode) { mutableStateOf(active.primaryDataSource) }
    var fallbackSourceInput by remember(selectedCode) { mutableStateOf(active.fallbackDataSource) }
    var waitingPeriodInput by remember(selectedCode) { mutableStateOf(active.waitingPeriodHours.toString()) }
    var testXFloat by remember(selectedCode) {
        mutableFloatStateOf(
            active.strikeThreshold.add(active.exhaustionThreshold).divide(BigDecimal("2")).toFloat()
        )
    }

    LaunchedEffect(active) {
        strikeInput = active.strikeThreshold.toPlainString()
        exhaustionInput = active.exhaustionThreshold.toPlainString()
        maxPayoutInput = active.maxPayout.rounded().toPlainString()
    }

    val kBd = strikeInput.toBigDecimalOrNull() ?: active.strikeThreshold
    val eBd = exhaustionInput.toBigDecimalOrNull() ?: active.exhaustionThreshold
    val lMoney = maxPayoutInput.toBigDecimalOrNull()?.let { Money(it.setScale(2, RoundingMode.HALF_UP), active.maxPayout.currency) }
        ?: active.maxPayout
    val validThresholds = eBd > kBd && lMoney.amount > BigDecimal.ZERO
    val maxSlider = (eBd.toFloat() * 1.25f).coerceAtLeast(10f)
    val testXBd = BigDecimal.valueOf(testXFloat.toDouble()).setScale(1, RoundingMode.HALF_UP)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(text = t("explain_strike_distinction"))
        }

        item {
            TerminalCard(accentColor = MaritimeTeal) {
                Text(
                    text = t("nav_parametric"),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.parametricTemplates.forEach { tpl ->
                        FilterChip(
                            selected = tpl.productCode == selectedCode,
                            onClick = { selectedCode = tpl.productCode },
                            label = { Text(if (state.language == AppLanguage.EN) tpl.titleEn else tpl.titleZh) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "${if (state.language == AppLanguage.EN) active.observableNameEn else active.observableNameZh} (${active.measurementUnit})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))

                // Interactive Payout Curve P(x)
                ParametricPayoutCurveCanvas(
                    strikeK = kBd,
                    exhaustionE = eBd,
                    maxPayoutL = lMoney,
                    testX = testXBd
                )

                if (!validThresholds) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = t("err_exhaustion_invalid"),
                        style = MaterialTheme.typography.bodySmall,
                        color = RestrainedVermilion,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    val testPayout = PricingAndParametricEngine.calculateParametricPayout(
                        testXBd, kBd, eBd, lMoney
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Test Observation x = ${testXBd.toPlainString()} ${active.measurementUnit}  ->  P(x) = ${testPayout.formatted()}",
                        style = MaterialTheme.typography.titleSmall,
                        color = RestrainedVermilion,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("parametric_test_payout_readout")
                    )
                    Slider(
                        value = testXFloat.coerceIn(0f, maxSlider),
                        onValueChange = { testXFloat = it },
                        valueRange = 0f..maxSlider,
                        modifier = Modifier.testTag("parametric_test_x_slider")
                    )
                }
            }
        }

        // Worked Examples Table
        if (validThresholds) {
            item {
                TerminalCard {
                    Text(
                        text = if (state.language == AppLanguage.EN)
                            "Worked Formula Examples: P(x) = L · min(1, max(0, (x − K)/(E − K)))"
                        else
                            "公式演算示例：P(x) = L · min(1, max(0, (x − K)/(E − K)))",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    val mid = kBd.add(eBd).divide(BigDecimal("2"), 1, RoundingMode.HALF_UP)
                    val below = kBd.multiply(BigDecimal("0.7")).setScale(1, RoundingMode.HALF_UP)
                    val above = eBd.multiply(BigDecimal("1.15")).setScale(1, RoundingMode.HALF_UP)
                    listOf(
                        "Below Strike (x=$below)" to below,
                        "At Strike (x=$kBd)" to kBd,
                        "Midpoint (x=$mid)" to mid,
                        "At Exhaustion (x=$eBd)" to eBd,
                        "Above Exhaustion (x=$above)" to above
                    ).forEach { (label, xVal) ->
                        val p = PricingAndParametricEngine.calculateParametricPayout(xVal, kBd, eBd, lMoney)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(label, style = MaterialTheme.typography.bodySmall)
                            Text(p.formatted(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Parametric Configuration Editor
        item {
            TerminalCard {
                Text(
                    text = if (state.language == AppLanguage.EN)
                        "Contractual Trigger & Data Governance Parameters"
                    else
                        "触发参数与数据源治理配置",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = strikeInput,
                        onValueChange = { strikeInput = it },
                        label = { Text("${t("term_strike_threshold")} (K)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = exhaustionInput,
                        onValueChange = { exhaustionInput = it },
                        label = { Text("${t("term_exhaustion_threshold")} (E)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = maxPayoutInput,
                        onValueChange = { maxPayoutInput = it },
                        label = { Text("${t("term_coverage_limit")} L (${active.maxPayout.currency.iso})") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = waitingPeriodInput,
                        onValueChange = { waitingPeriodInput = it },
                        label = { Text(if (state.language == AppLanguage.EN) "Waiting Period (h)" else "等待期 (小时)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = locationInput,
                    onValueChange = { locationInput = it },
                    label = { Text(if (state.language == AppLanguage.EN) "Observation Location" else "观测地点") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = primarySourceInput,
                    onValueChange = { primarySourceInput = it },
                    label = { Text("${t("term_data_source")} (Primary)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = fallbackSourceInput,
                    onValueChange = { fallbackSourceInput = it },
                    label = { Text("${t("term_data_source")} (Fallback)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "• ${if (state.language == AppLanguage.EN) active.aggregationRuleEn else active.aggregationRuleZh}\n" +
                        "• ${if (state.language == AppLanguage.EN) active.repeatEventRuleEn else active.repeatEventRuleZh}\n" +
                        "• ${if (state.language == AppLanguage.EN) active.finalisationRuleEn else active.finalisationRuleZh}\n" +
                        "• ${if (state.language == AppLanguage.EN) active.missingDataRuleEn else active.missingDataRuleZh}\n" +
                        "• ${if (state.language == AppLanguage.EN) active.disputedDataRuleEn else active.disputedDataRuleZh}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        onUpdateTemplate(
                            active.copy(
                                strikeThreshold = kBd,
                                exhaustionThreshold = eBd,
                                maxPayout = lMoney,
                                waitingPeriodHours = waitingPeriodInput.toIntOrNull() ?: active.waitingPeriodHours,
                                observationLocation = locationInput,
                                primaryDataSource = primarySourceInput,
                                fallbackDataSource = fallbackSourceInput
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_parametric_design_button")
                ) {
                    Text(if (state.language == AppLanguage.EN) "Apply Parametric Configuration" else "保存参数产品配置")
                }
            }
        }

        // Basis Risk Explanation Callout
        item {
            TerminalCard(accentColor = AmberCaution) {
                Text(
                    text = t("term_basis_risk"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = AmberCaution
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = t("explain_basis_risk"),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (state.language == AppLanguage.EN)
                        "Governance Rule: An observed trigger event generates a Proposed Settlement with evidence citations; it NEVER automatically initiates a payment."
                    else
                        "合规规则：触发事件观测仅生成附带证据引用的拟定赔付测算，绝不自动发起真实付款。",
                    style = MaterialTheme.typography.bodySmall,
                    color = RestrainedVermilion
                )
            }
        }
    }
}
