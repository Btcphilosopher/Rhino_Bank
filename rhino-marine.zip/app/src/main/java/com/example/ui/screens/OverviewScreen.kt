package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.ClaimStage
import com.example.domain.model.CurrencyCode
import com.example.domain.model.FeedStatus
import com.example.domain.model.Money
import com.example.domain.model.QuoteStatus
import com.example.domain.workflow.WorkflowAndCurrencyEngine
import com.example.i18n.AppLanguage
import com.example.i18n.TranslationCatalog
import com.example.ui.AppDestination
import com.example.ui.RhinoMarineUiState
import com.example.ui.components.MetricTile
import com.example.ui.components.SimulationBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.SyntheticVoyageMapCanvas
import com.example.ui.components.TerminalCard
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.RestrainedVermilion

@Composable
fun OverviewScreen(
    state: RhinoMarineUiState,
    t: (String) -> String,
    onSelectPort: (String) -> Unit,
    onNavigate: (AppDestination) -> Unit
) {
    val tenantQuotes = state.quotes.filter { it.tenantId == state.activeTenantId }
    val tenantPolicies = state.policies.filter { it.tenantId == state.activeTenantId }
    val tenantClaims = state.claims.filter { it.tenantId == state.activeTenantId }
    val tenantSettlements = state.settlements.filter { it.tenantId == state.activeTenantId }

    // Keep currencies strictly separate; compute explicit FX-converted portfolio rollup separately
    val usdQuotes = tenantQuotes.mapNotNull { q ->
        q.pricingBreakdown?.finalQuotedPremium?.takeIf { it.currency == CurrencyCode.USD }
    }
    val cnyQuotes = tenantQuotes.mapNotNull { q ->
        q.pricingBreakdown?.finalQuotedPremium?.takeIf { it.currency == CurrencyCode.CNY }
    }
    val totalUsdPrem = usdQuotes.fold(Money.zero(CurrencyCode.USD)) { acc, m -> acc + m }
    val totalCnyPrem = cnyQuotes.fold(Money.zero(CurrencyCode.CNY)) { acc, m -> acc + m }

    val activeExposureList = tenantPolicies.map { it.sumInsured }
    val usdExposure = activeExposureList.filter { it.currency == CurrencyCode.USD }
        .fold(Money.zero(CurrencyCode.USD)) { acc, m -> acc + m }
    val cnyExposure = activeExposureList.filter { it.currency == CurrencyCode.CNY }
        .fold(Money.zero(CurrencyCode.CNY)) { acc, m -> acc + m }
    val fxPortfolioCny = WorkflowAndCurrencyEngine.convertPortfolioTo(
        items = activeExposureList,
        targetCurrency = CurrencyCode.CNY,
        fxRates = state.fxRates
    )

    val quotesAwaitingUw = tenantQuotes.count { it.status == QuoteStatus.UNDERWRITING_REVIEW }
    val eventsPending = tenantSettlements.count { it.approvalStatus != "APPROVED_FOR_PAYMENT" }
    val claimsReview = tenantClaims.count { it.stage != ClaimStage.RECONCILIATION && it.stage != ClaimStage.DECLINED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SimulationBanner(text = t("banner_non_binding"))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = t("brand_title"),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${t("brand_subtitle")} • Q4 2026 (2026-11-01 .. 2026-11-13 UTC)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusPill(
                    label = t("term_simulation_only"),
                    color = RestrainedVermilion
                )
            }
        }

        item {
            BoxWithConstraints {
                val twoCol = maxWidth >= 600.dp
                if (twoCol) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile(
                                title = t("kpi_indicative_premium"),
                                primaryValue = totalCnyPrem.formatted(),
                                secondaryValue = "+ ${totalUsdPrem.formatted()} (Sep. ISO)",
                                tagLabel = "SIMULATED",
                                modifier = Modifier.weight(1f)
                            )
                            MetricTile(
                                title = t("kpi_active_exposure"),
                                primaryValue = fxPortfolioCny.formatted(),
                                secondaryValue = "${usdExposure.formatted()} | ${cnyExposure.formatted()} @7.185",
                                tagLabel = "FX 12:00Z",
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile(
                                title = t("kpi_quotes_review"),
                                primaryValue = quotesAwaitingUw.toString(),
                                secondaryValue = "${tenantQuotes.size} total quotes",
                                tagLabel = "UW",
                                accentColor = AmberCaution,
                                modifier = Modifier.weight(1f)
                            )
                            MetricTile(
                                title = t("kpi_expiring_policies"),
                                primaryValue = tenantPolicies.size.toString(),
                                secondaryValue = "Within 30-day window",
                                tagLabel = "ACTIVE",
                                modifier = Modifier.weight(1f)
                            )
                            MetricTile(
                                title = t("kpi_events_pending"),
                                primaryValue = eventsPending.toString(),
                                secondaryValue = "$claimsReview ${t("kpi_claims_review")}",
                                tagLabel = "HUMAN GATE",
                                accentColor = RestrainedVermilion,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricTile(
                            title = t("kpi_indicative_premium"),
                            primaryValue = totalCnyPrem.formatted(),
                            secondaryValue = "Separate USD: ${totalUsdPrem.formatted()} • ${t("term_simulation_only")}",
                            tagLabel = "Q4 2026"
                        )
                        MetricTile(
                            title = t("kpi_active_exposure"),
                            primaryValue = "${usdExposure.formatted()} + ${cnyExposure.formatted()}",
                            secondaryValue = "FX Equivalent: ${fxPortfolioCny.formatted()} (USD/CNY 7.1850 SIMULATED_PBOC)",
                            tagLabel = "MULTI-CCY"
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile(
                                title = t("kpi_quotes_review"),
                                primaryValue = "$quotesAwaitingUw",
                                secondaryValue = "${tenantPolicies.size} ${t("kpi_expiring_policies")}",
                                tagLabel = "UW",
                                accentColor = AmberCaution,
                                modifier = Modifier.weight(1f)
                            )
                            MetricTile(
                                title = t("kpi_events_pending"),
                                primaryValue = "$eventsPending",
                                secondaryValue = "$claimsReview ${t("kpi_claims_review")}",
                                tagLabel = "REVIEW",
                                accentColor = RestrainedVermilion,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Interactive Synthetic Voyage Map
        item {
            TerminalCard(accentColor = MaritimeTeal) {
                Text(
                    text = t("map_title"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                SyntheticVoyageMapCanvas(
                    ports = state.ports,
                    selectedPortCode = state.selectedPortCode,
                    language = state.language,
                    onSelectPort = onSelectPort
                )
                Spacer(Modifier.height(8.dp))
                val portVoyages = state.voyages.filter {
                    it.tenantId == state.activeTenantId &&
                        (it.originPortCode == state.selectedPortCode ||
                            it.destinationPortCode == state.selectedPortCode ||
                            state.selectedPortCode in it.intermediatePortCodes)
                }
                Text(
                    text = if (state.language == AppLanguage.EN) {
                        "Port ${state.selectedPortCode}: ${portVoyages.size} synthetic corridor voyage(s) linked. Tap any port node to inspect."
                    } else {
                        "港口 ${state.selectedPortCode}：关联 ${portVoyages.size} 个模拟航次。点击地图港口节点可切换查看。"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onNavigate(AppDestination.QUOTE_ENGINE) },
                        modifier = Modifier.testTag("overview_open_quote_engine")
                    ) {
                        Text(t("nav_quote_engine"))
                    }
                    OutlinedButton(
                        onClick = { onNavigate(AppDestination.PARAMETRIC_DESIGNER) },
                        modifier = Modifier.testTag("overview_open_parametric")
                    ) {
                        Text(t("nav_parametric"))
                    }
                }
            }
        }

        // 3 Seeded Demonstration Scenarios Quick Jump
        item {
            TerminalCard {
                Text(
                    text = if (state.language == AppLanguage.EN)
                        "Synthetic Demonstration Scenarios (3 Core Cases)"
                    else
                        "三大内置合成演示案例",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                tenantQuotes.take(4).forEach { q ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(AppDestination.QUOTE_ENGINE) }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${q.quoteId} • ${TranslationCatalog.productFamilyLabel(q.productFamily, state.language)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${q.customerName} | ${q.pricingBreakdown?.finalQuotedPremium?.formatted() ?: "-"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusPill(
                            label = TranslationCatalog.quoteStatusLabel(q.status, state.language),
                            color = if (q.status == QuoteStatus.ISSUED) MaritimeTeal else AmberCaution
                        )
                    }
                }
            }
        }

        // Data Freshness & Integration Health
        item {
            TerminalCard {
                Text(
                    text = t("feed_health_title"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                state.feedHealth.forEach { feed ->
                    val statusColor = when (feed.status) {
                        FeedStatus.SIMULATED -> MaritimeTeal
                        FeedStatus.STALE -> AmberCaution
                        FeedStatus.UNAVAILABLE -> RestrainedVermilion
                        FeedStatus.LIVE -> MaritimeTeal
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (state.language == AppLanguage.EN) feed.nameEn else feed.nameZh,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${if (state.language == AppLanguage.EN) feed.noteEn else feed.noteZh} (${feed.lastUpdatedUtc})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        StatusPill(
                            label = TranslationCatalog.feedStatusLabel(feed.status, state.language),
                            color = statusColor
                        )
                    }
                }
            }
        }
    }
}
