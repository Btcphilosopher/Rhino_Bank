package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiAssistantRequest
import com.example.ai.AiTaskType
import com.example.ai.AiUiState
import com.example.ai.DeterministicMockAiAdapter
import com.example.ai.FirebaseGeminiAiAdapter
import com.example.data.db.AppPreferenceEntity
import com.example.data.db.AuditLogEntity
import com.example.data.db.RhinoMarineDatabase
import com.example.data.db.TranslationOverrideEntity
import com.example.data.seed.SyntheticSeedData
import com.example.domain.api.ApiRequest
import com.example.domain.api.ApiResponse
import com.example.domain.api.ApiStateStore
import com.example.domain.api.RhinoMarineApiEngine
import com.example.domain.engine.PricingAndParametricEngine
import com.example.domain.engine.StructuredDomainException
import com.example.domain.model.AgentRunRecord
import com.example.domain.model.ApiAuditEntry
import com.example.domain.model.CargoRecord
import com.example.domain.model.ClaimRecord
import com.example.domain.model.ClaimStage
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DataFeedHealth
import com.example.domain.model.FeedStatus
import com.example.domain.model.FxRateRecord
import com.example.domain.model.IssuanceAuthority
import com.example.domain.model.Money
import com.example.domain.model.ObservationEvent
import com.example.domain.model.ObservationFinalisationStatus
import com.example.domain.model.ParametricProductConfig
import com.example.domain.model.PolicyRecord
import com.example.domain.model.PortNode
import com.example.domain.model.ProductFamily
import com.example.domain.model.ProductType
import com.example.domain.model.ProposedSettlement
import com.example.domain.model.QuoteRecord
import com.example.domain.model.QuoteStatus
import com.example.domain.model.VesselRecord
import com.example.domain.model.VoyageRecord
import com.example.domain.workflow.WorkflowAndCurrencyEngine
import com.example.i18n.AppLanguage
import com.example.i18n.TranslationCatalog
import com.example.i18n.TranslationEntry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.time.Instant
import java.util.UUID

enum class AppDestination(val key: String) {
    OVERVIEW("nav_overview"),
    QUOTE_ENGINE("nav_quote_engine"),
    VOYAGES("nav_voyages"),
    VESSELS_CARGO("nav_vessels_cargo"),
    PARAMETRIC_DESIGNER("nav_parametric"),
    POLICIES("nav_policies"),
    CLAIMS("nav_claims"),
    RISK_ANALYTICS("nav_analytics"),
    API_CONSOLE("nav_api_console"),
    ADMINISTRATION("nav_admin")
}

data class RhinoMarineUiState(
    val language: AppLanguage = AppLanguage.EN,
    val darkTerminalTheme: Boolean = false,
    val currentDestination: AppDestination = AppDestination.OVERVIEW,
    val activeTenantId: String = SyntheticSeedData.TENANT_COSCO_BROKER,
    val activeAuthority: IssuanceAuthority = IssuanceAuthority.AUTHORIZED_UNDERWRITER,
    val selectedPortCode: String = "CNSHA",
    val ports: List<PortNode> = SyntheticSeedData.ports,
    val fxRates: List<FxRateRecord> = SyntheticSeedData.fxRates,
    val vessels: List<VesselRecord> = SyntheticSeedData.vessels,
    val cargos: List<CargoRecord> = SyntheticSeedData.cargos,
    val voyages: List<VoyageRecord> = SyntheticSeedData.voyages,
    val parametricTemplates: List<ParametricProductConfig> = SyntheticSeedData.parametricTemplates,
    val quotes: List<QuoteRecord> = emptyList(),
    val policies: List<PolicyRecord> = emptyList(),
    val claims: List<ClaimRecord> = emptyList(),
    val observations: List<ObservationEvent> = emptyList(),
    val settlements: List<ProposedSettlement> = emptyList(),
    val feedHealth: List<DataFeedHealth> = emptyList(),
    val agentRuns: List<AgentRunRecord> = emptyList(),
    val translationOverrides: Map<String, TranslationEntry> = emptyMap(),
    val apiAuditLogs: List<ApiAuditEntry> = emptyList(),
    val lastApiResponse: ApiResponse? = null,
    val lastWebhookCheckResult: String? = null,
    val aiUseMockMode: Boolean = true,
    val aiUiState: AiUiState = AiUiState.Idle,
    val bannerMessage: String? = null,
    val bannerIsError: Boolean = false
)

class RhinoMarineViewModel(application: Application) : AndroidViewModel(application), ApiStateStore {

    private val db = RhinoMarineDatabase.getInstance(application)
    private val translationDao = db.translationOverrideDao()
    private val auditDao = db.auditLogDao()
    private val prefDao = db.appPreferenceDao()

    private val mockAiAdapter = DeterministicMockAiAdapter()
    private val geminiAiAdapter = FirebaseGeminiAiAdapter()

    private val _uiState = MutableStateFlow(initSeedState())
    val uiState: StateFlow<RhinoMarineUiState> = _uiState.asStateFlow()

    val apiEngine = RhinoMarineApiEngine(store = this)

    init {
        viewModelScope.launch {
            translationDao.observeAll().collect { rows ->
                val map = rows.associate {
                    it.key to TranslationEntry(
                        key = it.key,
                        en = it.en,
                        zhCn = it.zhCn,
                        isContractualWording = it.isContractualWording,
                        specialistReviewed = it.specialistReviewed,
                        category = it.category
                    )
                }
                _uiState.update { it.copy(translationOverrides = map) }
            }
        }
        viewModelScope.launch {
            auditDao.observeRecent().collect { rows ->
                val entries = rows.map {
                    ApiAuditEntry(
                        requestId = it.requestId,
                        tenantId = it.tenantId,
                        method = it.method,
                        path = it.path,
                        statusCode = it.statusCode,
                        idempotencyKey = it.idempotencyKey,
                        idempotentReplay = it.idempotentReplay,
                        requestBodyJson = it.requestBodyJson,
                        responseBodyJson = it.responseBodyJson,
                        timestampUtc = it.timestampUtc
                    )
                }
                _uiState.update { it.copy(apiAuditLogs = entries) }
            }
        }
        viewModelScope.launch {
            prefDao.observeAll().collect { prefs ->
                val langCode = prefs.firstOrNull { it.prefKey == "language" }?.prefValue
                val dark = prefs.firstOrNull { it.prefKey == "dark_theme" }?.prefValue == "true"
                val lang = AppLanguage.entries.firstOrNull { it.code == langCode } ?: _uiState.value.language
                _uiState.update { it.copy(language = lang, darkTerminalTheme = dark) }
            }
        }
    }

    private fun initSeedState(): RhinoMarineUiState {
        val bundle = SyntheticSeedData.createSeededData()
        return RhinoMarineUiState(
            quotes = bundle.quotes,
            policies = bundle.policies,
            claims = bundle.claims,
            observations = bundle.observations,
            settlements = bundle.settlements,
            feedHealth = bundle.feedHealth,
            agentRuns = bundle.agentRuns
        )
    }

    fun t(key: String): String =
        TranslationCatalog.get(key, _uiState.value.language, _uiState.value.translationOverrides)

    fun setDestination(dest: AppDestination) {
        _uiState.update { it.copy(currentDestination = dest, bannerMessage = null) }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == AppLanguage.EN) AppLanguage.ZH_CN else AppLanguage.EN
        _uiState.update { it.copy(language = next) }
        viewModelScope.launch {
            prefDao.set(AppPreferenceEntity("language", next.code))
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        _uiState.update { it.copy(darkTerminalTheme = enabled) }
        viewModelScope.launch {
            prefDao.set(AppPreferenceEntity("dark_theme", enabled.toString()))
        }
    }

    fun setActiveTenant(tenantId: String) {
        _uiState.update { it.copy(activeTenantId = tenantId, bannerMessage = null) }
    }

    fun setActiveAuthority(authority: IssuanceAuthority) {
        _uiState.update { it.copy(activeAuthority = authority, bannerMessage = null) }
    }

    fun selectPort(unlocode: String) {
        _uiState.update { it.copy(selectedPortCode = unlocode) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }

    // --- ApiStateStore ---
    override fun getQuotes(): List<QuoteRecord> = _uiState.value.quotes
    override fun upsertQuote(quote: QuoteRecord) {
        _uiState.update { state ->
            val updated = state.quotes.filterNot { it.quoteId == quote.quoteId } + quote
            state.copy(quotes = updated.sortedByDescending { it.updatedAtUtc })
        }
    }

    override fun getPolicies(): List<PolicyRecord> = _uiState.value.policies
    override fun upsertPolicy(policy: PolicyRecord) {
        _uiState.update { state ->
            val updated = state.policies.filterNot { it.policyId == policy.policyId } + policy
            state.copy(policies = updated.sortedByDescending { it.issuedAtUtc })
        }
    }

    override fun getClaims(): List<ClaimRecord> = _uiState.value.claims
    override fun upsertClaim(claim: ClaimRecord) {
        _uiState.update { state ->
            val updated = state.claims.filterNot { it.claimId == claim.claimId } + claim
            state.copy(claims = updated.sortedByDescending { it.updatedAtUtc })
        }
    }

    override fun getObservations(): List<ObservationEvent> = _uiState.value.observations
    override fun upsertObservation(obs: ObservationEvent) {
        _uiState.update { state ->
            val updated = state.observations.filterNot { it.observationId == obs.observationId } + obs
            state.copy(observations = updated.sortedByDescending { it.observedAtUtc })
        }
    }

    override fun getSettlements(): List<ProposedSettlement> = _uiState.value.settlements
    override fun upsertSettlement(settlement: ProposedSettlement) {
        _uiState.update { state ->
            val updated = state.settlements.filterNot { it.settlementId == settlement.settlementId } + settlement
            state.copy(settlements = updated.sortedByDescending { it.createdAtUtc })
        }
    }

    override fun getAgentRuns(): List<AgentRunRecord> = _uiState.value.agentRuns

    // --- Quote & Pricing Engine Actions ---
    fun createAndPriceQuote(
        productFamily: ProductFamily,
        customerName: String,
        vesselId: String,
        cargoId: String?,
        voyageId: String,
        currency: CurrencyCode,
        sumInsuredStr: String,
        deductibleStr: String,
        limitStr: String,
        strikeStr: String,
        exhaustionStr: String,
        seed: Long,
        runs: Int,
        commercialAdjPct: Double
    ) {
        try {
            val state = _uiState.value
            val sumVal = sumInsuredStr.toBigDecimalOrNull()
                ?: throw StructuredDomainException("ERR_INVALID_SUM_INSURED", "Sum Insured is missing or invalid.", "保险金额缺失或格式无效。")
            val dedVal = deductibleStr.toBigDecimalOrNull() ?: BigDecimal.ZERO
            val limVal = limitStr.toBigDecimalOrNull()
                ?: throw StructuredDomainException("ERR_INVALID_LIMIT", "Coverage Limit is missing or invalid.", "赔偿限额缺失或格式无效。")

            val vessel = state.vessels.firstOrNull { it.id == vesselId && it.tenantId == state.activeTenantId }
            val cargo = cargoId?.let { id -> state.cargos.firstOrNull { it.id == id && it.tenantId == state.activeTenantId } }
            val voyage = state.voyages.firstOrNull { it.id == voyageId && it.tenantId == state.activeTenantId }

            val sumInsured = Money(sumVal.setScale(2), currency)
            val deductible = Money(dedVal.setScale(2), currency)
            val limit = Money(limVal.setScale(2), currency)

            val referrals = PricingAndParametricEngine.evaluateUnderwritingReferrals(
                vessel = vessel,
                cargo = cargo,
                voyage = voyage,
                sumInsured = sumInsured,
                productFamily = productFamily
            )

            val paramConfig = if (productFamily.productType == ProductType.PARAMETRIC) {
                val strike = strikeStr.toBigDecimalOrNull()
                    ?: throw StructuredDomainException("ERR_INVALID_STRIKE", "Strike threshold K is required.", "必须填写触发阈值 K。")
                val exhaustion = exhaustionStr.toBigDecimalOrNull()
                    ?: throw StructuredDomainException("ERR_INVALID_EXHAUSTION", "Exhaustion threshold E is required.", "必须填写全额赔付阈值 E。")
                if (exhaustion <= strike) {
                    throw StructuredDomainException(
                        "ERR_INVALID_EXHAUSTION_THRESHOLD",
                        "Exhaustion threshold ($exhaustion) must be > Strike threshold ($strike).",
                        "全额赔付阈值 ($exhaustion) 必须严格大于触发阈值 ($strike)。"
                    )
                }
                val baseTemplate = state.parametricTemplates.firstOrNull { it.productFamily == productFamily }
                    ?: state.parametricTemplates.first()
                baseTemplate.copy(
                    strikeThreshold = strike,
                    exhaustionThreshold = exhaustion,
                    maxPayout = limit,
                    observationPeriodDays = voyage?.exposureDays ?: baseTemplate.observationPeriodDays
                )
            } else null

            val breakdown = if (productFamily.productType == ProductType.PARAMETRIC) {
                PricingAndParametricEngine.priceParametricQuote(
                    config = paramConfig!!,
                    exposureDays = voyage?.exposureDays ?: 20,
                    seed = seed,
                    runs = runs,
                    commercialAdjRate = commercialAdjPct / 100.0
                )
            } else {
                PricingAndParametricEngine.priceIndemnityQuote(
                    productFamily = productFamily,
                    sumInsured = sumInsured,
                    deductible = deductible,
                    perEventLimit = limit,
                    aggregateLimit = limit,
                    exposureDays = voyage?.exposureDays ?: 30,
                    vesselAgeYears = vessel?.let { 2026 - it.buildYear } ?: 15,
                    isHighHazardCargo = cargo?.hazardClass?.contains("HIGH", true) == true,
                    seed = seed,
                    runs = runs,
                    commercialAdjRate = commercialAdjPct / 100.0
                )
            }

            val nowUtc = Instant.now().toString()
            val quoteId = "Q-${productFamily.code.take(3)}-${UUID.randomUUID().toString().take(4).uppercase()}"
            val initialStatus = if (referrals.isNotEmpty()) QuoteStatus.UNDERWRITING_REVIEW else QuoteStatus.INDICATIVE
            val quote = QuoteRecord(
                quoteId = quoteId,
                tenantId = state.activeTenantId,
                version = 1,
                status = initialStatus,
                productType = productFamily.productType,
                productFamily = productFamily,
                customerName = customerName.ifBlank { "China Coastal Freight Client" },
                vesselId = vesselId,
                cargoId = cargoId,
                voyageId = voyageId,
                currency = currency,
                sumInsured = sumInsured,
                deductible = deductible,
                coverageLimit = limit,
                aggregateLimit = limit,
                parametricConfig = paramConfig,
                pricingBreakdown = breakdown,
                referralReasons = referrals,
                underwritingNotes = if (referrals.isNotEmpty()) {
                    "Auto-referred due to: ${referrals.joinToString(", ")}"
                } else {
                    "Simulation Only — Indicative quote generated with seed $seed."
                },
                isBinding = false,
                expiresAtUtc = Instant.now().plusSeconds(14 * 86400L).toString(),
                createdAtUtc = nowUtc,
                updatedAtUtc = nowUtc,
                inputSnapshotJson = "{\"family\":\"${productFamily.code}\",\"seed\":$seed,\"runs\":$runs}"
            )
            upsertQuote(quote)
            val msg = if (referrals.isNotEmpty()) {
                "${t("err_missing_critical")} ($quoteId)"
            } else {
                "${t("term_indicative_quote")}: $quoteId — ${breakdown.finalQuotedPremium.formatted()}"
            }
            _uiState.update { it.copy(bannerMessage = msg, bannerIsError = false) }
        } catch (ex: StructuredDomainException) {
            val msg = if (_uiState.value.language == AppLanguage.EN) ex.messageEn else ex.messageZh
            _uiState.update { it.copy(bannerMessage = "${ex.errorCode}: $msg", bannerIsError = true) }
        } catch (ex: Exception) {
            _uiState.update { it.copy(bannerMessage = ex.message ?: "Quote error", bannerIsError = true) }
        }
    }

    fun transitionQuote(quoteId: String, target: QuoteStatus) {
        val state = _uiState.value
        val quote = state.quotes.firstOrNull { it.quoteId == quoteId } ?: return
        try {
            if (quote.tenantId != state.activeTenantId) {
                throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant quote access prohibited.", "禁止跨租户操作报价。")
            }
            if ((target == QuoteStatus.APPROVED || target == QuoteStatus.REJECTED) &&
                state.activeAuthority != IssuanceAuthority.AUTHORIZED_UNDERWRITER &&
                state.activeAuthority != IssuanceAuthority.HEAD_OF_MARINE
            ) {
                throw StructuredDomainException("ERR_UNAUTHORIZED_ISSUANCE", "Underwriter authority required.", "需要核保授权。")
            }
            val updated = WorkflowAndCurrencyEngine.transitionQuoteState(quote, target)
            upsertQuote(updated)
            _uiState.update {
                it.copy(
                    bannerMessage = "$quoteId -> ${TranslationCatalog.quoteStatusLabel(target, state.language)}",
                    bannerIsError = false
                )
            }
        } catch (ex: StructuredDomainException) {
            val msg = if (state.language == AppLanguage.EN) ex.messageEn else ex.messageZh
            _uiState.update { it.copy(bannerMessage = msg, bannerIsError = true) }
        }
    }

    fun issuePolicyFromQuote(quoteId: String) {
        val state = _uiState.value
        val quote = state.quotes.firstOrNull { it.quoteId == quoteId } ?: return
        try {
            if (quote.tenantId != state.activeTenantId) {
                throw StructuredDomainException("ERR_TENANT_FORBIDDEN", "Cross-tenant issuance prohibited.", "禁止跨租户出单。")
            }
            val voyage = state.voyages.firstOrNull { it.id == quote.voyageId }
            val (issuedQuote, policy) = WorkflowAndCurrencyEngine.issuePolicy(
                quote = quote,
                authority = state.activeAuthority,
                wordingVersion = if (quote.productType == ProductType.PARAMETRIC) "RMC-PAR-v2.0" else "RMC-IND-v3.2",
                inceptionUtc = voyage?.coverageInceptionUtc ?: Instant.now().toString(),
                expiryUtc = voyage?.coverageExpiryUtc ?: Instant.now().plusSeconds(30 * 86400L).toString()
            )
            upsertQuote(issuedQuote)
            upsertPolicy(policy)
            _uiState.update {
                it.copy(
                    bannerMessage = "${t("term_policy_issuance")}: ${policy.policyId}",
                    bannerIsError = false
                )
            }
        } catch (ex: StructuredDomainException) {
            val msg = if (state.language == AppLanguage.EN) ex.messageEn else ex.messageZh
            _uiState.update { it.copy(bannerMessage = msg, bannerIsError = true) }
        }
    }

    // --- Parametric Template Designer ---
    fun updateParametricTemplate(updated: ParametricProductConfig) {
        if (updated.exhaustionThreshold <= updated.strikeThreshold) {
            _uiState.update {
                it.copy(
                    bannerMessage = t("err_exhaustion_invalid"),
                    bannerIsError = true
                )
            }
            return
        }
        _uiState.update { state ->
            val list = state.parametricTemplates.map {
                if (it.productCode == updated.productCode) updated else it
            }
            state.copy(
                parametricTemplates = list,
                bannerMessage = "${updated.productCode}: K=${updated.strikeThreshold}, E=${updated.exhaustionThreshold}, L=${updated.maxPayout.formatted()}",
                bannerIsError = false
            )
        }
    }

    // --- Vessels, Cargo & Voyages ---
    fun addVessel(name: String, imo: String, vesselType: String, buildYear: Int, capacity: String, inspectionStatus: String) {
        if (name.isBlank() || imo.isBlank()) {
            _uiState.update {
                it.copy(
                    bannerMessage = if (it.language == AppLanguage.EN)
                        "Validation Error: Vessel name and IMO identifier are required (never invented)."
                    else
                        "校验错误：船舶名称与 IMO 编号为必填项（系统不会虚构生成）。",
                    bannerIsError = true
                )
            }
            return
        }
        val v = VesselRecord(
            id = "VSL-${UUID.randomUUID().toString().take(5).uppercase()}",
            tenantId = _uiState.value.activeTenantId,
            name = name.trim(),
            imoNumber = imo.trim(),
            mmsi = "413000000",
            vesselType = vesselType.ifBlank { "Container Ship" },
            buildYear = buildYear,
            capacityDescription = capacity.ifBlank { "Declared pending" },
            dwt = 85000,
            flagState = "China",
            inspectionStatus = inspectionStatus.ifBlank { "OVERDUE_OR_UNDECLARED" },
            lastSurveyUtc = Instant.now().toString()
        )
        _uiState.update {
            it.copy(
                vessels = listOf(v) + it.vessels,
                bannerMessage = "Added vessel ${v.name} (IMO ${v.imoNumber})",
                bannerIsError = false
            )
        }
    }

    fun addCargo(description: String, category: String, packaging: String, valueStr: String, currency: CurrencyCode, hazard: String) {
        val amount = valueStr.toBigDecimalOrNull()
        if (description.isBlank() || amount == null || amount <= BigDecimal.ZERO) {
            _uiState.update {
                it.copy(
                    bannerMessage = if (it.language == AppLanguage.EN)
                        "Validation Error: Cargo description and positive declared value are required."
                    else
                        "校验错误：货物描述及正数申报价值为必填项。",
                    bannerIsError = true
                )
            }
            return
        }
        val c = CargoRecord(
            id = "CRG-${UUID.randomUUID().toString().take(5).uppercase()}",
            tenantId = _uiState.value.activeTenantId,
            description = description.trim(),
            category = category.ifBlank { "General Marine Cargo" },
            hazardClass = hazard.ifBlank { "STANDARD" },
            packaging = packaging.ifBlank { "40ft ISO Container" },
            declaredValue = Money(amount.setScale(2), currency)
        )
        _uiState.update {
            it.copy(
                cargos = listOf(c) + it.cargos,
                bannerMessage = "Added cargo ${c.description} (${c.declaredValue.formatted()})",
                bannerIsError = false
            )
        }
    }

    fun addVoyage(origin: String, destination: String, vesselId: String, exposureDays: Int, assumptions: String) {
        if (origin.isBlank() || destination.isBlank() || exposureDays <= 0) {
            _uiState.update {
                it.copy(
                    bannerMessage = if (it.language == AppLanguage.EN)
                        "Validation Error: Origin, destination, and exposure days > 0 are required."
                    else
                        "校验错误：起运港、目的港及大于0的承保天数均为必填项。",
                    bannerIsError = true
                )
            }
            return
        }
        val now = Instant.now()
        val voy = VoyageRecord(
            id = "VOY-${UUID.randomUUID().toString().take(5).uppercase()}",
            tenantId = _uiState.value.activeTenantId,
            voyageCode = "VYG-2611-$origin-$destination",
            vesselId = vesselId,
            originPortCode = origin,
            destinationPortCode = destination,
            intermediatePortCodes = emptyList(),
            plannedDepartureUtc = now.plusSeconds(86400L).toString(),
            plannedArrivalUtc = now.plusSeconds((exposureDays + 1) * 86400L).toString(),
            coverageInceptionUtc = now.toString(),
            coverageExpiryUtc = now.plusSeconds((exposureDays + 5) * 86400L).toString(),
            exposureDays = exposureDays,
            routeExposureAssumptions = assumptions.ifBlank { "Standard synthetic corridor schedule" },
            seaCorridor = "$origin – $destination"
        )
        _uiState.update {
            it.copy(
                voyages = listOf(voy) + it.voyages,
                bannerMessage = "Created voyage ${voy.voyageCode}",
                bannerIsError = false
            )
        }
    }

    // --- Endorsements, Claims & Parametric Settlements ---
    fun addEndorsement(policyId: String, summaryEn: String, summaryZh: String, deltaStr: String) {
        val state = _uiState.value
        val policy = state.policies.firstOrNull { it.policyId == policyId } ?: return
        val deltaVal = deltaStr.toBigDecimalOrNull() ?: BigDecimal.ZERO
        val updated = WorkflowAndCurrencyEngine.appendEndorsement(
            policy = policy,
            summaryEn = summaryEn.ifBlank { "Controlled schedule endorsement" },
            summaryZh = summaryZh.ifBlank { "受控保单批改记录" },
            premiumDelta = Money(deltaVal.setScale(2), policy.currency),
            newWordingVersion = "${policy.wordingVersion}-E${policy.endorsements.size + 1}",
            issuedBy = state.activeAuthority.code
        )
        upsertPolicy(updated)
        _uiState.update {
            it.copy(
                bannerMessage = "Endorsement added to ${policy.policyId} (History preserved)",
                bannerIsError = false
            )
        }
    }

    fun advanceClaimStage(claimId: String) {
        val state = _uiState.value
        val claim = state.claims.firstOrNull { it.claimId == claimId } ?: return
        val nextStage = when (claim.stage) {
            ClaimStage.NOTIFICATION -> ClaimStage.EVIDENCE_COLLECTION
            ClaimStage.EVIDENCE_COLLECTION -> ClaimStage.ASSESSMENT
            ClaimStage.ASSESSMENT -> ClaimStage.APPROVAL
            ClaimStage.APPROVAL -> ClaimStage.PAYMENT_INSTRUCTION
            ClaimStage.PAYMENT_INSTRUCTION -> ClaimStage.RECONCILIATION
            ClaimStage.RECONCILIATION, ClaimStage.DECLINED -> claim.stage
        }
        val payRef = if (nextStage == ClaimStage.PAYMENT_INSTRUCTION && claim.paymentInstructionRef == null) {
            "PAY-INST-${UUID.randomUUID().toString().take(6).uppercase()}"
        } else claim.paymentInstructionRef
        val recRef = if (nextStage == ClaimStage.RECONCILIATION && claim.reconciliationRef == null) {
            "RECON-${UUID.randomUUID().toString().take(6).uppercase()}"
        } else claim.reconciliationRef

        upsertClaim(
            claim.copy(
                stage = nextStage,
                paymentInstructionRef = payRef,
                reconciliationRef = recRef,
                updatedAtUtc = Instant.now().toString()
            )
        )
    }

    fun recordAndProposeSettlement(policyId: String, observedValueStr: String, finStatus: ObservationFinalisationStatus) {
        val state = _uiState.value
        val policy = state.policies.firstOrNull { it.policyId == policyId } ?: return
        val valBd = observedValueStr.toBigDecimalOrNull()
        if (valBd == null && finStatus != ObservationFinalisationStatus.MISSING) {
            _uiState.update { it.copy(bannerMessage = "Invalid observation numeric value", bannerIsError = true) }
            return
        }
        val obs = ObservationEvent(
            observationId = "OBS-${UUID.randomUUID().toString().take(5).uppercase()}",
            tenantId = policy.tenantId,
            policyId = policy.policyId,
            productFamily = policy.productFamily,
            observableName = policy.parametricConfig?.observableNameEn ?: "Observed Index",
            observedValue = valBd ?: BigDecimal.ZERO,
            unit = policy.parametricConfig?.measurementUnit ?: "hours",
            location = policy.parametricConfig?.observationLocation ?: "CNSHA",
            dataSource = policy.parametricConfig?.primaryDataSource ?: "Synthetic Feed",
            feedStatus = FeedStatus.SIMULATED,
            finalisationStatus = finStatus,
            observedAtUtc = Instant.now().toString(),
            evidenceCitation = "SIM-OBS-${System.currentTimeMillis()}"
        )
        upsertObservation(obs)
        val settlement = WorkflowAndCurrencyEngine.calculateProposedSettlement(policy, obs)
        upsertSettlement(settlement)
        _uiState.update {
            it.copy(
                bannerMessage = "Proposed settlement ${settlement.settlementId}: ${settlement.calculatedPayout.formatted()} (Pending human approval)",
                bannerIsError = false
            )
        }
    }

    fun approveProposedSettlement(settlementId: String) {
        val state = _uiState.value
        val settlement = state.settlements.firstOrNull { it.settlementId == settlementId } ?: return
        if (settlement.approvalStatus == "HELD_FOR_DISPUTE") {
            _uiState.update {
                it.copy(
                    bannerMessage = if (it.language == AppLanguage.EN)
                        "Cannot approve settlement while observation is DISPUTED or MISSING."
                    else
                        "观测数据处于争议或缺失状态，无法批准赔付指令。",
                    bannerIsError = true
                )
            }
            return
        }
        upsertSettlement(settlement.copy(approvalStatus = "APPROVED_FOR_PAYMENT"))
    }

    // --- API Console Execution ---
    fun executeApiCall(method: String, path: String, idempotencyKey: String?, bodyJson: String) {
        val state = _uiState.value
        val req = ApiRequest(
            method = method,
            path = path,
            tenantId = state.activeTenantId,
            idempotencyKey = idempotencyKey?.takeIf { it.isNotBlank() },
            authority = state.activeAuthority,
            bodyJson = bodyJson
        )
        val res = apiEngine.handle(req)
        _uiState.update { it.copy(lastApiResponse = res) }
        viewModelScope.launch {
            auditDao.insert(
                AuditLogEntity(
                    requestId = res.requestId,
                    tenantId = state.activeTenantId,
                    method = method,
                    path = path,
                    statusCode = res.statusCode,
                    idempotencyKey = idempotencyKey,
                    idempotentReplay = res.idempotentReplay,
                    requestBodyJson = bodyJson,
                    responseBodyJson = res.bodyJson,
                    timestampUtc = Instant.now().toString()
                )
            )
        }
    }

    fun testSignedWebhookReplay() {
        val deliveryId = "wh_del_${UUID.randomUUID().toString().take(8)}"
        val nowSec = Instant.now().epochSecond
        val payload = """{"event":"quote.approved","tenant":"${_uiState.value.activeTenantId}"}"""
        val headers = apiEngine.signWebhookPayload(deliveryId, nowSec, payload)
        val sig = headers["X-Rhino-Signature"]!!
        val firstCheck = apiEngine.verifySignedWebhook(deliveryId, nowSec, sig, payload, nowSec)
        val replayCheck = apiEngine.verifySignedWebhook(deliveryId, nowSec, sig, payload, nowSec + 5)
        _uiState.update {
            it.copy(
                lastWebhookCheckResult = "1st check ($deliveryId): ${firstCheck.second} | 2nd replay attempt: ${replayCheck.second}"
            )
        }
    }

    // --- Editable Translations ---
    fun saveTranslationOverride(entry: TranslationEntry) {
        viewModelScope.launch {
            translationDao.upsert(
                TranslationOverrideEntity(
                    key = entry.key,
                    en = entry.en,
                    zhCn = entry.zhCn,
                    isContractualWording = entry.isContractualWording,
                    specialistReviewed = entry.specialistReviewed,
                    category = entry.category
                )
            )
        }
    }

    fun resetTranslationOverrides() {
        viewModelScope.launch { translationDao.clearAll() }
    }

    // --- AI Underwriting Assistant ---
    fun setAiMockMode(useMock: Boolean) {
        _uiState.update { it.copy(aiUseMockMode = useMock) }
    }

    fun runAiAssistant(
        taskType: AiTaskType,
        documentVersionRef: String,
        documentText: String,
        quoteId: String?,
        claimId: String?
    ) {
        val state = _uiState.value
        val scopedQuote = quoteId?.let { id -> state.quotes.firstOrNull { it.quoteId == id } }
        val scopedClaim = claimId?.let { id -> state.claims.firstOrNull { it.claimId == id } }
        val request = AiAssistantRequest(
            tenantId = state.activeTenantId,
            taskType = taskType,
            documentVersionRef = documentVersionRef.ifBlank { "DOC-V1" },
            untrustedDocumentText = documentText,
            scopedQuote = scopedQuote,
            scopedClaim = scopedClaim,
            authorizedTenantScope = true
        )

        viewModelScope.launch {
            _uiState.update { it.copy(aiUiState = AiUiState.Loading) }
            try {
                val adapter = if (state.aiUseMockMode) mockAiAdapter else geminiAiAdapter
                val run = adapter.execute(request)
                _uiState.update {
                    it.copy(
                        agentRuns = listOf(run) + it.agentRuns,
                        aiUiState = AiUiState.Success(run, run.outputSummary)
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        aiUiState = AiUiState.Error(
                            e.localizedMessage ?: "AI assistant execution failed."
                        )
                    )
                }
            }
        }
    }

    fun markAgentRunReviewed(runId: String) {
        _uiState.update { state ->
            state.copy(
                agentRuns = state.agentRuns.map {
                    if (it.runId == runId) it.copy(status = "UNDERWRITER_REVIEWED", appliedToRecord = true) else it
                },
                bannerMessage = "AI suggestion $runId marked reviewed by Underwriter.",
                bannerIsError = false
            )
        }
    }
}
