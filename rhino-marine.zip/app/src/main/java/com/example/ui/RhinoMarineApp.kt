package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguage
import com.example.i18n.TranslationCatalog
import com.example.ui.components.SimulationBanner
import com.example.ui.screens.AdministrationScreen
import com.example.ui.screens.ApiConsoleScreen
import com.example.ui.screens.ClaimsScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.ParametricDesignerScreen
import com.example.ui.screens.PoliciesScreen
import com.example.ui.screens.QuoteEngineScreen
import com.example.ui.screens.RiskAnalyticsScreen
import com.example.ui.screens.VesselsCargoScreen
import com.example.ui.screens.VoyagesScreen
import com.example.ui.theme.DeepMaritimeNavy
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SeafoamTeal
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RhinoMarineApp(
    state: RhinoMarineUiState,
    viewModel: RhinoMarineViewModel
) {
    val t: (String) -> String = { key ->
        TranslationCatalog.get(key, state.language, state.translationOverrides)
    }

    if (state.currentDestination != AppDestination.OVERVIEW) {
        BackHandler {
            viewModel.setDestination(AppDestination.OVERVIEW)
        }
    }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 720.dp

        if (isWide) {
            // Tablet / Desktop Maritime Terminal Permanent Sidebar + Main Workspace
            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    RhinoTopBar(
                        title = t("brand_title"),
                        subtitle = t(state.currentDestination.key),
                        language = state.language,
                        showMenuButton = false,
                        onMenuClick = {},
                        onToggleLanguage = viewModel::toggleLanguage
                    )
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    TerminalSidebar(
                        current = state.currentDestination,
                        t = t,
                        onSelect = viewModel::setDestination
                    )
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        WorkspaceHost(state = state, t = t, viewModel = viewModel)
                    }
                }
            }
        } else {
            // Mobile Handheld: ModalNavigationDrawer (all 10 tabs) + Bottom Quick Bar (top 4 tabs)
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = MidnightNavy,
                        drawerContentColor = Color.White
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(vertical = 14.dp, horizontal = 10.dp)
                        ) {
                            Text(
                                text = "RHINO MARINE CHINA",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SeafoamTeal,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                            Text(
                                text = t("brand_subtitle"),
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                            )
                            HorizontalDivider(
                                color = DeepMaritimeNavy,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                            AppDestination.entries.forEach { dest ->
                                val selected = dest == state.currentDestination
                                NavigationDrawerItem(
                                    selected = selected,
                                    onClick = {
                                        viewModel.setDestination(dest)
                                        scope.launch { drawerState.close() }
                                    },
                                    icon = { Icon(iconFor(dest), contentDescription = null) },
                                    label = { Text(t(dest.key), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    colors = NavigationDrawerItemDefaults.colors(
                                        selectedContainerColor = DeepMaritimeNavy,
                                        selectedIconColor = SeafoamTeal,
                                        selectedTextColor = Color.White,
                                        unselectedIconColor = Color(0xFF94A3B8),
                                        unselectedTextColor = Color(0xFFE2E8F0)
                                    ),
                                    modifier = Modifier.testTag("drawer_nav_${dest.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) {
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing,
                    topBar = {
                        RhinoTopBar(
                            title = t("brand_title"),
                            subtitle = t(state.currentDestination.key),
                            language = state.language,
                            showMenuButton = true,
                            onMenuClick = { scope.launch { drawerState.open() } },
                            onToggleLanguage = viewModel::toggleLanguage
                        )
                    },
                    bottomBar = {
                        NavigationBar(windowInsets = WindowInsets.navigationBars) {
                            listOf(
                                AppDestination.OVERVIEW,
                                AppDestination.QUOTE_ENGINE,
                                AppDestination.PARAMETRIC_DESIGNER,
                                AppDestination.API_CONSOLE
                            ).forEach { dest ->
                                NavigationBarItem(
                                    selected = state.currentDestination == dest,
                                    onClick = { viewModel.setDestination(dest) },
                                    icon = { Icon(iconFor(dest), contentDescription = t(dest.key)) },
                                    label = { Text(t(dest.key), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.testTag("bottom_nav_${dest.name.lowercase()}")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        WorkspaceHost(state = state, t = t, viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RhinoTopBar(
    title: String,
    subtitle: String,
    language: AppLanguage,
    showMenuButton: Boolean,
    onMenuClick: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MidnightNavy,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        ),
        navigationIcon = {
            if (showMenuButton) {
                IconButton(
                    onClick = onMenuClick,
                    modifier = Modifier.testTag("nav_drawer_button")
                ) {
                    Icon(Icons.Filled.Menu, contentDescription = "Open navigation menu")
                }
            }
        },
        title = {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = SeafoamTeal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        actions = {
            FilterChip(
                selected = true,
                onClick = onToggleLanguage,
                leadingIcon = {
                    Icon(
                        Icons.Outlined.Translate,
                        contentDescription = "Switch language",
                        modifier = Modifier.size(16.dp)
                    )
                },
                label = {
                    Text(
                        text = if (language == AppLanguage.EN) "EN / 简中" else "简体中文 / EN",
                        style = MaterialTheme.typography.labelMedium
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = DeepMaritimeNavy,
                    selectedLabelColor = SeafoamTeal,
                    selectedLeadingIconColor = SeafoamTeal
                ),
                modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("language_switch_button")
            )
        }
    )
}

@Composable
private fun TerminalSidebar(
    current: AppDestination,
    t: (String) -> String,
    onSelect: (AppDestination) -> Unit
) {
    Surface(
        modifier = Modifier
            .width(230.dp)
            .fillMaxHeight(),
        color = MidnightNavy,
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            AppDestination.entries.forEach { dest ->
                val selected = dest == current
                NavigationDrawerItem(
                    selected = selected,
                    onClick = { onSelect(dest) },
                    icon = { Icon(iconFor(dest), contentDescription = null) },
                    label = { Text(t(dest.key), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = DeepMaritimeNavy,
                        selectedIconColor = SeafoamTeal,
                        selectedTextColor = Color.White,
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier.testTag("sidebar_nav_${dest.name.lowercase()}")
                )
            }
        }
    }
}

@Composable
private fun WorkspaceHost(
    state: RhinoMarineUiState,
    t: (String) -> String,
    viewModel: RhinoMarineViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        state.bannerMessage?.let { msg ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SimulationBanner(
                    text = msg,
                    isError = state.bannerIsError,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = viewModel::clearBanner) {
                    Icon(Icons.Outlined.Close, contentDescription = "Dismiss alert")
                }
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (state.currentDestination) {
                AppDestination.OVERVIEW -> OverviewScreen(
                    state = state,
                    t = t,
                    onSelectPort = viewModel::selectPort,
                    onNavigate = viewModel::setDestination
                )
                AppDestination.QUOTE_ENGINE -> QuoteEngineScreen(
                    state = state,
                    t = t,
                    onCreateQuote = viewModel::createAndPriceQuote,
                    onTransitionQuote = viewModel::transitionQuote,
                    onIssuePolicy = viewModel::issuePolicyFromQuote
                )
                AppDestination.VOYAGES -> VoyagesScreen(
                    state = state,
                    t = t,
                    onAddVoyage = viewModel::addVoyage
                )
                AppDestination.VESSELS_CARGO -> VesselsCargoScreen(
                    state = state,
                    t = t,
                    onAddVessel = viewModel::addVessel,
                    onAddCargo = viewModel::addCargo
                )
                AppDestination.PARAMETRIC_DESIGNER -> ParametricDesignerScreen(
                    state = state,
                    t = t,
                    onUpdateTemplate = viewModel::updateParametricTemplate
                )
                AppDestination.POLICIES -> PoliciesScreen(
                    state = state,
                    t = t,
                    onAddEndorsement = viewModel::addEndorsement
                )
                AppDestination.CLAIMS -> ClaimsScreen(
                    state = state,
                    t = t,
                    onAdvanceClaimStage = viewModel::advanceClaimStage,
                    onRecordObservationAndPropose = viewModel::recordAndProposeSettlement,
                    onApproveSettlement = viewModel::approveProposedSettlement
                )
                AppDestination.RISK_ANALYTICS -> RiskAnalyticsScreen(
                    state = state,
                    t = t
                )
                AppDestination.API_CONSOLE -> ApiConsoleScreen(
                    state = state,
                    t = t,
                    onExecuteApi = viewModel::executeApiCall,
                    onTestWebhookReplay = viewModel::testSignedWebhookReplay
                )
                AppDestination.ADMINISTRATION -> AdministrationScreen(
                    state = state,
                    t = t,
                    onSetDarkTheme = viewModel::setDarkTheme,
                    onSetTenant = viewModel::setActiveTenant,
                    onSetAuthority = viewModel::setActiveAuthority,
                    onSetAiMockMode = viewModel::setAiMockMode,
                    onRunAiTask = viewModel::runAiAssistant,
                    onMarkAiReviewed = viewModel::markAgentRunReviewed,
                    onSaveTranslation = viewModel::saveTranslationOverride,
                    onResetTranslations = viewModel::resetTranslationOverrides
                )
            }
        }
    }
}

private fun iconFor(dest: AppDestination): ImageVector = when (dest) {
    AppDestination.OVERVIEW -> Icons.Filled.Dashboard
    AppDestination.QUOTE_ENGINE -> Icons.Filled.Calculate
    AppDestination.VOYAGES -> Icons.Filled.Map
    AppDestination.VESSELS_CARGO -> Icons.Filled.DirectionsBoat
    AppDestination.PARAMETRIC_DESIGNER -> Icons.Filled.Tune
    AppDestination.POLICIES -> Icons.Filled.Assignment
    AppDestination.CLAIMS -> Icons.Filled.Gavel
    AppDestination.RISK_ANALYTICS -> Icons.Filled.Analytics
    AppDestination.API_CONSOLE -> Icons.Filled.Api
    AppDestination.ADMINISTRATION -> Icons.Filled.AdminPanelSettings
}
