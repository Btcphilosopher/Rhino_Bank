package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.domain.engine.PricingAndParametricEngine
import com.example.domain.model.CurrencyCode
import com.example.domain.model.Money
import com.example.domain.model.PortNode
import com.example.i18n.AppLanguage
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.DeepMaritimeNavy
import com.example.ui.theme.MaritimeTeal
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.RestrainedVermilion
import com.example.ui.theme.SeafoamTeal
import java.math.BigDecimal
import kotlin.math.hypot

@Composable
fun SimulationBanner(
    text: String,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    val container = if (isError) {
        MaterialTheme.colorScheme.errorContainer
    } else {
        MaterialTheme.colorScheme.secondaryContainer
    }
    val content = if (isError) {
        MaterialTheme.colorScheme.onErrorContainer
    } else {
        MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("simulation_banner"),
        color = container,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, content.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isError) Icons.Outlined.WarningAmber else Icons.Outlined.Info,
                contentDescription = null,
                tint = content,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = content,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun TerminalCard(
    modifier: Modifier = Modifier,
    accentColor: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column {
            if (accentColor != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(accentColor)
                )
            }
            Column(
                modifier = Modifier.padding(14.dp),
                content = content
            )
        }
    }
}

@Composable
fun StatusPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun MetricTile(
    title: String,
    primaryValue: String,
    secondaryValue: String? = null,
    tagLabel: String,
    accentColor: Color = MaritimeTeal,
    modifier: Modifier = Modifier
) {
    TerminalCard(
        modifier = modifier,
        accentColor = accentColor
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            StatusPill(label = tagLabel, color = accentColor)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = primaryValue,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        if (!secondaryValue.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = secondaryValue,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SyntheticVoyageMapCanvas(
    ports: List<PortNode>,
    selectedPortCode: String,
    language: AppLanguage,
    onSelectPort: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
            .background(MidnightNavy, MaterialTheme.shapes.medium)
            .border(1.dp, DeepMaritimeNavy, MaterialTheme.shapes.medium)
            .onSizeChanged { canvasSize = it }
            .pointerInput(ports, canvasSize) {
                detectTapGestures { offset ->
                    if (canvasSize.width > 0 && canvasSize.height > 0) {
                        val nearest = ports.minByOrNull { port ->
                            val px = port.mapX * canvasSize.width
                            val py = port.mapY * canvasSize.height
                            hypot(offset.x - px, offset.y - py)
                        }
                        if (nearest != null) {
                            val px = nearest.mapX * canvasSize.width
                            val py = nearest.mapY * canvasSize.height
                            if (hypot(offset.x - px, offset.y - py) <= 84f) {
                                onSelectPort(nearest.unlocode)
                            }
                        }
                    }
                }
            }
            .testTag("synthetic_voyage_map")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Container-grid nautical coordinate lines
            val gridColor = Color(0xFF1D3557)
            for (i in 1..7) {
                val x = w * (i / 8f)
                drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
            }
            for (j in 1..4) {
                val y = h * (j / 5f)
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }

            fun pos(code: String): Offset {
                val p = ports.firstOrNull { it.unlocode == code } ?: return Offset.Zero
                return Offset(p.mapX * w, p.mapY * h)
            }

            // Synthetic Shipping Corridors (No live AIS)
            val routes = listOf(
                Triple("CNSHA", "SGSIN", Color(0xFF2DD4BF)),
                Triple("SGSIN", "NLRTM", Color(0xFF2DD4BF)),
                Triple("CNNGB", "USLAX", Color(0xFF38BDF8)),
                Triple("CNSZX", "HKHKG", Color(0xFFF59E0B)),
                Triple("HKHKG", "MYPKG", Color(0xFFF59E0B)),
                Triple("CNTAO", "CNSHA", Color(0xFF94A3B8))
            )

            val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
            for ((from, to, routeColor) in routes) {
                val a = pos(from)
                val b = pos(to)
                val mid = Offset((a.x + b.x) / 2f, ((a.y + b.y) / 2f) - h * 0.08f)
                val path = Path().apply {
                    moveTo(a.x, a.y)
                    quadraticTo(mid.x, mid.y, b.x, b.y)
                }
                drawPath(
                    path = path,
                    color = routeColor.copy(alpha = 0.78f),
                    style = Stroke(width = 3.2f, cap = StrokeCap.Round, pathEffect = dash)
                )
            }

            // Port markers
            for (port in ports) {
                val center = Offset(port.mapX * w, port.mapY * h)
                val isSelected = port.unlocode == selectedPortCode
                val dotColor = when {
                    isSelected -> RestrainedVermilion
                    port.isChineseHub -> SeafoamTeal
                    else -> Color(0xFFE2E8F0)
                }
                if (isSelected) {
                    drawCircle(
                        color = RestrainedVermilion.copy(alpha = 0.30f),
                        radius = 18f,
                        center = center
                    )
                }
                drawCircle(color = dotColor, radius = if (isSelected) 9f else 6.5f, center = center)
                drawCircle(
                    color = MidnightNavy,
                    radius = if (isSelected) 3.5f else 2.2f,
                    center = center
                )
            }
        }

        // Top-left synthetic disclaimer badge
        Surface(
            color = Color(0xCC0A1628),
            shape = RoundedCornerShape(4.dp),
            border = BorderStroke(1.dp, Color(0xFF28456B)),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
        ) {
            Text(
                text = if (language == AppLanguage.EN) {
                    "SYNTHETIC CORRIDORS • NO LIVE VESSEL AIS"
                } else {
                    "模拟航道示意图 • 非实时船舶AIS位置"
                },
                style = MaterialTheme.typography.labelSmall,
                color = SeafoamTeal,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        // Bottom-right selected port callout
        val selected = ports.firstOrNull { it.unlocode == selectedPortCode }
        if (selected != null) {
            Surface(
                color = Color(0xE611223D),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, SeafoamTeal.copy(alpha = 0.5f)),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(RestrainedVermilion, CircleShape)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "${selected.unlocode} • ${if (language == AppLanguage.EN) selected.nameEn else selected.nameZh}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ParametricPayoutCurveCanvas(
    strikeK: BigDecimal,
    exhaustionE: BigDecimal,
    maxPayoutL: Money,
    testX: BigDecimal,
    modifier: Modifier = Modifier
) {
    val valid = exhaustionE > strikeK && maxPayoutL.amount > BigDecimal.ZERO
    val curveColor = MaritimeTeal
    val strikeColor = AmberCaution
    val markerColor = RestrainedVermilion
    val gridColor = MaterialTheme.colorScheme.outline

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small)
                .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.small)
                .padding(14.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val leftPad = 14f
                val bottomPad = 14f
                val plotW = w - leftPad - 8f
                val plotH = h - bottomPad - 8f

                // Grid lines
                for (i in 0..4) {
                    val y = 8f + plotH * (i / 4f)
                    drawLine(gridColor, Offset(leftPad, y), Offset(w - 8f, y), strokeWidth = 1f)
                }
                // Axes
                drawLine(gridColor, Offset(leftPad, 8f), Offset(leftPad, h - bottomPad), strokeWidth = 2f)
                drawLine(gridColor, Offset(leftPad, h - bottomPad), Offset(w - 8f, h - bottomPad), strokeWidth = 2f)

                if (valid) {
                    val maxX = exhaustionE.toDouble() * 1.25
                    fun mapX(v: Double): Float =
                        leftPad + ((v / maxX).coerceIn(0.0, 1.0)).toFloat() * plotW

                    fun mapY(payout: Double): Float =
                        (h - bottomPad) - ((payout / maxPayoutL.amount.toDouble()).coerceIn(0.0, 1.0)).toFloat() * plotH

                    val kX = mapX(strikeK.toDouble())
                    val eX = mapX(exhaustionE.toDouble())
                    val zeroY = mapY(0.0)
                    val maxY = mapY(maxPayoutL.amount.toDouble())

                    val path = Path().apply {
                        moveTo(leftPad, zeroY)
                        lineTo(kX, zeroY)
                        lineTo(eX, maxY)
                        lineTo(w - 8f, maxY)
                    }
                    drawPath(
                        path = path,
                        color = curveColor,
                        style = Stroke(width = 5f, cap = StrokeCap.Round)
                    )

                    // Vertical dashed markers for K and E
                    val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                    drawLine(strikeColor, Offset(kX, 8f), Offset(kX, h - bottomPad), strokeWidth = 2f, pathEffect = dash)
                    drawLine(curveColor, Offset(eX, 8f), Offset(eX, h - bottomPad), strokeWidth = 2f, pathEffect = dash)

                    // Interactive test value x dot
                    val testPayout = PricingAndParametricEngine.calculateParametricPayout(
                        testX, strikeK, exhaustionE, maxPayoutL
                    ).amount.toDouble()
                    val dotX = mapX(testX.toDouble())
                    val dotY = mapY(testPayout)
                    drawLine(
                        markerColor.copy(alpha = 0.55f),
                        Offset(dotX, h - bottomPad),
                        Offset(dotX, dotY),
                        strokeWidth = 2f
                    )
                    drawCircle(markerColor, radius = 9f, center = Offset(dotX, dotY))
                    drawCircle(Color.White, radius = 4f, center = Offset(dotX, dotY))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "K = ${strikeK.toPlainString()}",
                style = MaterialTheme.typography.labelMedium,
                color = AmberCaution
            )
            Text(
                text = "E = ${exhaustionE.toPlainString()}",
                style = MaterialTheme.typography.labelMedium,
                color = MaritimeTeal
            )
            Text(
                text = "L = ${maxPayoutL.formatted()}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun DistributionHistogramCanvas(
    buckets: List<Int>,
    currency: CurrencyCode,
    modifier: Modifier = Modifier
) {
    val barColor = MaritimeTeal
    val border = MaterialTheme.colorScheme.outline
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small)
            .border(1.dp, border, MaterialTheme.shapes.small)
            .padding(10.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (buckets.isEmpty()) return@Canvas
            val maxCount = (buckets.maxOrNull() ?: 1).coerceAtLeast(1)
            val gap = 8f
            val barW = (size.width - gap * (buckets.size - 1)) / buckets.size
            buckets.forEachIndexed { idx, count ->
                val barH = (count.toFloat() / maxCount.toFloat()) * (size.height - 6f)
                val x = idx * (barW + gap)
                val y = size.height - barH
                drawRect(
                    color = if (idx >= buckets.size - 2) RestrainedVermilion else barColor,
                    topLeft = Offset(x, y),
                    size = Size(barW, barH)
                )
            }
        }
        Text(
            text = "Monte Carlo Scenario Density (${currency.iso})",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.TopEnd)
        )
    }
}
