package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Maritime Finance Terminal Palette
val MidnightNavy = Color(0xFF0A1628)
val DeepMaritimeNavy = Color(0xFF11223D)
val SlateNavy = Color(0xFF1A3152)
val SteelBorderDark = Color(0xFF28456B)

val PorcelainWhite = Color(0xFFF6F8FB)
val CrispPaper = Color(0xFFFFFFFF)
val MistSurface = Color(0xFFEEF2F7)
val GridLineLight = Color(0xFFD5DEE9)

val MaritimeTeal = Color(0xFF0D7C75)
val SeafoamTeal = Color(0xFF2DD4BF)
val TealContainerLight = Color(0xFFD6F2EE)
val TealContainerDark = Color(0xFF0C3B38)

val RestrainedVermilion = Color(0xFFC83E2B)
val VermilionSoft = Color(0xFFFFDAD5)
val VermilionDark = Color(0xFF5C1910)

val AmberCaution = Color(0xFFB45309)
val AmberContainerLight = Color(0xFFFEF3C7)
val AmberContainerDark = Color(0xFF452408)

val InkPrimary = Color(0xFF0D1B2A)
val InkSecondary = Color(0xFF475569)
val InkMuted = Color(0xFF64748B)

val PorcelainTextDark = Color(0xFFF1F5F9)
val SlateTextDark = Color(0xFFCBD5E1)
