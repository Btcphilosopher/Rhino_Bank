package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.configureAppCheck
import com.example.ui.RhinoMarineApp
import com.example.ui.RhinoMarineViewModel
import com.example.ui.theme.RhinoMarineTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent before any UI or ViewModels
        configureAppCheck(this, intent)

        // STEP 2: Enable Edge-to-Edge and render Rhino Marine China Terminal
        enableEdgeToEdge()
        setContent {
            val viewModel: RhinoMarineViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            RhinoMarineTheme(darkTheme = uiState.darkTerminalTheme) {
                RhinoMarineApp(
                    state = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}
