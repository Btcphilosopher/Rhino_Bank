/**
 * RhinoQuant Synthetic IRR - Master Application Entry Point
 * Institutional Financial Engineering Terminal for Synthetic Return Construction,
 * Cross-Market Yield Engineering, Funding Curve Analysis, and Structured Cash-Flow Modeling.
 */

import React, { useState, useMemo } from 'react';
import { Header, ActiveTab } from './components/Header';
import { KpiBanner } from './components/KpiBanner';
import { OverviewView } from './components/views/OverviewView';
import { SyntheticBuilderView } from './components/views/SyntheticBuilderView';
import { RateLabView } from './components/views/RateLabView';
import { CurveEngineView } from './components/views/CurveEngineView';
import { CarryStrategiesView } from './components/views/CarryStrategiesView';
import { StructuredCreditView } from './components/views/StructuredCreditView';
import { ScenarioRiskView } from './components/views/ScenarioRiskView';
import { ReportsAuditView } from './components/views/ReportsAuditView';
import { TestSuiteView } from './components/views/TestSuiteView';
import { CalculationInspectorModal } from './components/CalculationInspectorModal';

import { INSTITUTIONAL_TEMPLATES } from './data/templates';
import { buildSyntheticLedger } from './math/syntheticBuilder';
import { FinancialInstrument, SyntheticMode, StrategyTemplate } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [selectedTemplate, setSelectedTemplate] = useState<StrategyTemplate>(
    INSTITUTIONAL_TEMPLATES[0]
  );
  const [currentMode, setCurrentMode] = useState<SyntheticMode>(
    INSTITUTIONAL_TEMPLATES[0].mode
  );
  const [instruments, setInstruments] = useState<FinancialInstrument[]>(
    INSTITUTIONAL_TEMPLATES[0].instruments
  );
  const [assumedBenchmarkRate, setAssumedBenchmarkRate] = useState<number>(
    INSTITUTIONAL_TEMPLATES[0].assumedBenchmarkRate
  );
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(false);

  // Switch template
  const handleSelectTemplate = (template: StrategyTemplate) => {
    setSelectedTemplate(template);
    setCurrentMode(template.mode);
    setInstruments(template.instruments);
    setAssumedBenchmarkRate(template.assumedBenchmarkRate);
  };

  // Switch mode
  const handleChangeMode = (mode: SyntheticMode) => {
    setCurrentMode(mode);
  };

  // Recalculate model
  const { ledger, summary } = useMemo(() => {
    return buildSyntheticLedger({
      referenceStartDate: instruments[0]?.startDate || '2026-01-01',
      instruments,
      mode: currentMode,
      assumedBenchmarkRate,
      exitValuationOverride: selectedTemplate.exitValuation,
      exitDateOverride: selectedTemplate.exitDate,
    });
  }, [instruments, currentMode, assumedBenchmarkRate, selectedTemplate]);

  // Export CSV
  const handleExportCsv = () => {
    const headers = [
      'ID',
      'Date',
      'YearFraction',
      'Period',
      'Category',
      'Description',
      'GrossAssetFlow',
      'FinancingFlow',
      'HedgingFlow',
      'FeeFlow',
      'CollateralFlow',
      'NetInvestorFlow',
      'DiscountFactor',
      'DiscountedNetFlow',
    ];

    const rows = ledger.map((r) => [
      r.id,
      r.date,
      r.yearFraction.toFixed(4),
      r.period,
      r.category,
      `"${r.description.replace(/"/g, '""')}"`,
      r.grossAssetFlow.toFixed(2),
      r.financingFlow.toFixed(2),
      r.hedgingFlow.toFixed(2),
      r.feeFlow.toFixed(2),
      r.collateralFlow.toFixed(2),
      r.netInvestorFlow.toFixed(2),
      r.discountFactor.toFixed(6),
      r.discountedNetFlow.toFixed(2),
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `rhinoquant_synthetic_irr_${selectedTemplate.code.toLowerCase()}_${Date.now()}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export JSON
  const handleExportJson = () => {
    const data = {
      project: 'RhinoQuant Synthetic IRR',
      template: selectedTemplate,
      mode: currentMode,
      assumedBenchmarkRate,
      summary,
      instruments,
      ledger,
      exportedAt: new Date().toISOString(),
    };

    const jsonStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', jsonStr);
    link.setAttribute(
      'download',
      `rhinoquant_model_${selectedTemplate.code.toLowerCase()}_${Date.now()}.json`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-200 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      
      {/* 1. Header (Top Bar Contract: 3 zones separated by gap-8) */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onRecalculate={() => {
          // Trigger slight micro-recalculation notification
          setInstruments([...instruments]);
        }}
        onOpenAudit={() => setActiveTab('reports')}
      />

      {/* 2. Headline Institutional KPI Banner */}
      <KpiBanner
        summary={summary}
        onInspect={() => setIsInspectorOpen(true)}
      />

      {/* 3. Main Workstation Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-6">
        {activeTab === 'overview' && (
          <OverviewView
            currentMode={currentMode}
            onChangeMode={handleChangeMode}
            selectedTemplate={selectedTemplate}
            onSelectTemplate={handleSelectTemplate}
            summary={summary}
            ledger={ledger}
            instruments={instruments}
            onOpenInspector={() => setIsInspectorOpen(true)}
            onNavigateToBuilder={() => setActiveTab('builder')}
          />
        )}

        {activeTab === 'builder' && (
          <SyntheticBuilderView
            instruments={instruments}
            onUpdateInstruments={setInstruments}
            ledger={ledger}
            summary={summary}
            assumedBenchmarkRate={assumedBenchmarkRate}
            onChangeBenchmarkRate={setAssumedBenchmarkRate}
            onExportCsv={handleExportCsv}
          />
        )}

        {activeTab === 'ratelab' && <RateLabView />}

        {activeTab === 'curves' && <CurveEngineView />}

        {activeTab === 'carry' && <CarryStrategiesView />}

        {activeTab === 'credit' && <StructuredCreditView />}

        {activeTab === 'risk' && (
          <ScenarioRiskView baseLedger={ledger} summary={summary} />
        )}

        {activeTab === 'reports' && (
          <ReportsAuditView
            template={selectedTemplate}
            summary={summary}
            ledger={ledger}
            instruments={instruments}
            assumedBenchmarkRate={assumedBenchmarkRate}
            onExportCsv={handleExportCsv}
            onExportJson={handleExportJson}
          />
        )}

        {activeTab === 'tests' && <TestSuiteView />}
      </main>

      {/* 4. Calculation Inspector Modal */}
      <CalculationInspectorModal
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
        summary={summary}
      />

      {/* 5. Institutional Footer */}
      <footer className="border-t border-slate-800/80 bg-[#080c14] px-6 py-4 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500">
          <div>
            <span>RhinoQuant Quantitative Finance Platform</span>
            <span className="mx-2">·</span>
            <span>Module: Synthetic IRR & Yield Engineering</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveTab('tests')}
              className="text-slate-400 hover:text-amber-400 transition-colors"
            >
              Section 12 Verification Suite (18 Tests)
            </button>
            <span>·</span>
            <span>Brent-Dekker Solver (Residual &lt; 1e-4)</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
