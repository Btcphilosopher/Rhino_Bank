/**
 * RhinoQuant Synthetic IRR - Core Type Definitions
 * Mathematical, financial, and architectural structures for synthetic return engineering.
 */

export type SyntheticMode = 
  | 'MODE_A_SYNTHETIC_CASHFLOW_IRR'
  | 'MODE_B_FINANCING_ADJUSTED_RETURN'
  | 'MODE_C_IMPLIED_RATE_EXTRACTION';

export type DayCountConvention = 'ACT/360' | 'ACT/365' | '30/360' | 'ACT/ACT';

export type PaymentFrequency = 'ANNUAL' | 'SEMI_ANNUAL' | 'QUARTERLY' | 'MONTHLY';

export type InstrumentType = 
  | 'OVERNIGHT_INDEX'
  | 'OIS_SWAP'
  | 'TERM_BENCHMARK'
  | 'GOVERNMENT_BOND'
  | 'CORPORATE_BOND'
  | 'REPO_SECURED'
  | 'COMMERCIAL_PAPER'
  | 'FLOATING_RATE_LOAN'
  | 'FIXED_RATE_DEBT'
  | 'INTEREST_RATE_SWAP'
  | 'CROSS_CURRENCY_SWAP'
  | 'FX_FORWARD_CARRY'
  | 'CREDIT_DEFAULT_SWAP'
  | 'COLLATERAL_MARGIN'
  | 'STRUCTURED_TRANCHE'
  | 'EQUITY_DISTRIBUTION'
  | 'FINANCING_FEE';

export type EconomicRole = 
  | 'UNDERLYING_ASSET'
  | 'PRIMARY_FUNDING'
  | 'SECONDARY_FUNDING'
  | 'RATE_HEDGE'
  | 'CURRENCY_HEDGE'
  | 'CREDIT_HEDGE'
  | 'COLLATERAL_POSTING'
  | 'TRANSACTION_FEE';

export interface FinancialInstrument {
  id: string;
  name: string;
  type: InstrumentType;
  role: EconomicRole;
  currency: string;
  notional: number;
  startDate: string; // YYYY-MM-DD
  maturityDate: string; // YYYY-MM-DD
  frequency: PaymentFrequency;
  dayCount: DayCountConvention;
  rateType: 'FIXED' | 'FLOATING' | 'COMPOSITE';
  fixedRate?: number; // e.g. 0.055 for 5.5%
  floatingBenchmark?: string; // e.g. 'SOFR', 'EURIBOR_3M'
  spreadBps?: number; // Spread over floating benchmark in basis points
  fundingCostRate?: number; // Cost of carrying position
  haircut?: number; // Haircut percentage for repo / collateral (e.g. 0.10 for 10%)
  feesUpfront?: number; // Currency amount
  feesAnnualBps?: number; // Bps per annum
  collateralRemunerationRate?: number; // Rate earned on posted cash margin
  marketPrice?: number; // E.g. clean price 99.50
  notes?: string;
  active: boolean;
}

export type CashFlowCategory = 
  | 'INITIAL_OUTFLOW'
  | 'DRAWDOWN_PROCEEDS'
  | 'INTEREST_PAYMENT'
  | 'INTEREST_RECEIPT'
  | 'PRINCIPAL_REPAYMENT'
  | 'HEDGE_SETTLEMENT'
  | 'COLLATERAL_FLOW'
  | 'FEE_PAYMENT'
  | 'EXIT_PROCEEDS';

export interface CashFlowRecord {
  id: string;
  date: string;
  yearFraction: number; // Elapsed from reference date
  period: number;
  instrumentId: string;
  instrumentName: string;
  category: CashFlowCategory;
  grossAssetFlow: number; // Unlevered cash flow from the asset
  financingFlow: number; // Financing cash flows (borrowing +, interest -, repayment -)
  hedgingFlow: number; // Derivative hedge settlements
  feeFlow: number; // Structuring, commitment & servicing fees (-)
  collateralFlow: number; // Margin deposit (-) or release (+)
  netInvestorFlow: number; // Total net cash flow received/paid by the equity investor
  discountFactor: number; // Term discount factor DF(0, t)
  discountedNetFlow: number; // Net flow * DF
  description: string;
}

export interface SolverDiagnostics {
  status: 'CONVERGED' | 'MULTIPLE_ROOTS' | 'NO_ROOT' | 'MAX_ITERATIONS_EXCEEDED';
  solverMethod: string;
  root: number; // Primary economically meaningful root
  allRoots: number[];
  iterations: number;
  residualNpv: number;
  searchInterval: [number, number];
  hasSignChanges: boolean;
  signChangeCount: number;
  uniqueRootGuaranteed: boolean;
  warning?: string;
}

export interface SyntheticReturnSummary {
  syntheticXirr: number; // Effective annual rate (e.g. 0.124 for 12.4%)
  grossUnleveredIrr: number; // Asset-level IRR before leverage
  financingAdjustedNetReturn: number; // Investor-level levered return
  impliedBenchmarkSpreadBps: number; // Spread to curve in bps
  npv: number; // Present value at benchmark discount curve
  moic: number; // Multiple on Invested Capital
  totalInvestedEquity: number;
  totalDistributions: number;
  netGain: number;
  annualizedFundingCost: number; // Blended financing rate
  hedgeCostBps: number; // Drag from derivatives/hedging
  maxDrawdownPct: number;
  calculationTimestamp: string;
  mode: SyntheticMode;
  diagnostics: SolverDiagnostics;
}

export interface YieldCurvePoint {
  tenorLabel: string;
  tenorYears: number;
  zeroRate: number; // Annual rate e.g. 0.045
  discountFactor: number; // DF(0, t)
  forwardRate: number; // Instantaneous or 1-period forward
  parSwapRate?: number;
}

export interface YieldCurveDefinition {
  id: string;
  name: string;
  currency: string;
  benchmark: string;
  constructionMethod: 'BOOTSTRAP_OIS' | 'PAR_SWAP_SPLINE' | 'LOG_LINEAR_DF' | 'SYNTHETIC_COMPOSITE';
  timestamp: string;
  interpolation: 'LOG_LINEAR_DF' | 'CUBIC_HERMITE' | 'LINEAR_ZERO';
  points: YieldCurvePoint[];
  calibrationResidualRms: number;
}

export interface FXCarryTradeConfig {
  fundingCurrency: string;
  fundingRate: number; // e.g. 0.0025 (JPY 25bps)
  investmentCurrency: string;
  investmentRate: number; // e.g. 0.0460 (USD 4.60%)
  spotFx: number; // e.g. 152.50 USD/JPY
  forwardTenorMonths: number;
  crossCurrencyBasisBps: number; // e.g. -25 bps
  leverage: number; // e.g. 3.0x
  haircutPct: number; // e.g. 10%
  hedgedRatio: number; // 0.0 (unhedged) to 1.0 (fully forward-hedged)
  transactionCostBps: number;
  holdingPeriodMonths: number;
}

export interface CreditTranche {
  id: string;
  name: string;
  seniority: number; // 1 = most senior
  attachmentPoint: number; // e.g. 0.20 (20%)
  detachmentPoint: number; // e.g. 1.00 (100%)
  sizeAmount: number;
  couponSpreadBps: number;
  principalBalance: number;
  cumulativeLoss: number;
  cumulativeInterestReceived: number;
  cashFlows: { date: string; interest: number; principal: number; netFlow: number }[];
  modelIrr: number;
}

export interface SecuritizationWaterfallConfig {
  collateralPoolNotional: number;
  collateralCouponRate: number; // e.g. 0.0825 (8.25%)
  collateralTenorYears: number;
  constantDefaultRateCdr: number; // e.g. 0.025 (2.5% per annum)
  conditionalPrepaymentRateCpr: number; // e.g. 0.08 (8.0% per annum)
  recoveryRate: number; // e.g. 0.65 (65%)
  recoveryLagMonths: number;
  servicingFeeBps: number; // e.g. 50 bps
  tranches: CreditTranche[];
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  rateShiftBps: number; // Parallel curve shift in bps
  curveSteepeningBps: number; // 10Y-2Y steepening
  creditSpreadShiftBps: number; // Corporate / credit spread shift
  repoHaircutShiftPct: number; // Haircut expansion e.g. +5%
  fxShockPct: number; // Currency depreciation e.g. -10%
  defaultRateMultiplier: number; // E.g. 2.0x default rates
  prepaymentMultiplier: number; // E.g. 0.5x CPR
  exitMultipleShiftPct: number; // Exit price haircut
}

export interface MonteCarloResult {
  simulationCount: number;
  meanIrr: number;
  medianIrr: number;
  stdDevIrr: number;
  p5Irr: number;
  p25Irr: number;
  p75Irr: number;
  p95Irr: number;
  var95: number; // Value at Risk at 95% confidence
  cvar95: number; // Conditional VaR / Expected Shortfall
  probNegativeNpv: number; // Proportion of paths with NPV < 0
  probCapitalLoss: number; // Proportion with MOIC < 1.0
  distributionBuckets: { rangeLabel: string; count: number; minVal: number; maxVal: number }[];
}

export interface StrategyTemplate {
  id: string;
  name: string;
  code: string;
  mode: SyntheticMode;
  headlineDescription: string;
  economicPremise: string;
  instruments: FinancialInstrument[];
  assumedBenchmarkRate: number;
  exitValuation: number;
  exitDate: string;
  notes: string;
}
