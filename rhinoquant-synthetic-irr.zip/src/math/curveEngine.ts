/**
 * RhinoQuant Curve Construction & Interpolation Engine
 * Implements log-linear discount factor interpolation, cubic spline,
 * zero rate extraction, forward rate calculation, and cross-currency basis adjustment.
 */

import { YieldCurveDefinition, YieldCurvePoint } from '../types';

/**
 * Standard benchmark curve snapshots (SOFR, EUR OIS/€STR, SONIA, US High Yield, Repo GC)
 */
export const STANDARD_CURVES: Record<string, YieldCurveDefinition> = {
  USD_SOFR: {
    id: 'USD_SOFR',
    name: 'USD SOFR OIS Benchmark Curve',
    currency: 'USD',
    benchmark: 'SOFR',
    constructionMethod: 'BOOTSTRAP_OIS',
    timestamp: '2026-10-15 16:30:00 EST',
    interpolation: 'LOG_LINEAR_DF',
    calibrationResidualRms: 0.00008,
    points: [
      { tenorLabel: 'O/N', tenorYears: 1 / 360, zeroRate: 0.0485, discountFactor: 0.999865, forwardRate: 0.0485, parSwapRate: 0.0485 },
      { tenorLabel: '1M', tenorYears: 1 / 12, zeroRate: 0.0482, discountFactor: 0.995998, forwardRate: 0.0481, parSwapRate: 0.0482 },
      { tenorLabel: '3M', tenorYears: 0.25, zeroRate: 0.0475, discountFactor: 0.988201, forwardRate: 0.0471, parSwapRate: 0.0475 },
      { tenorLabel: '6M', tenorYears: 0.5, zeroRate: 0.0460, discountFactor: 0.977263, forwardRate: 0.0445, parSwapRate: 0.0460 },
      { tenorLabel: '1Y', tenorYears: 1.0, zeroRate: 0.0435, discountFactor: 0.957434, forwardRate: 0.0410, parSwapRate: 0.0435 },
      { tenorLabel: '2Y', tenorYears: 2.0, zeroRate: 0.0410, discountFactor: 0.921268, forwardRate: 0.0385, parSwapRate: 0.0410 },
      { tenorLabel: '3Y', tenorYears: 3.0, zeroRate: 0.0398, discountFactor: 0.887445, forwardRate: 0.0374, parSwapRate: 0.0398 },
      { tenorLabel: '5Y', tenorYears: 5.0, zeroRate: 0.0390, discountFactor: 0.822835, forwardRate: 0.0378, parSwapRate: 0.0390 },
      { tenorLabel: '7Y', tenorYears: 7.0, zeroRate: 0.0395, discountFactor: 0.758428, forwardRate: 0.0408, parSwapRate: 0.0395 },
      { tenorLabel: '10Y', tenorYears: 10.0, zeroRate: 0.0412, discountFactor: 0.662325, forwardRate: 0.0452, parSwapRate: 0.0412 },
    ],
  },
  EUR_ESTR: {
    id: 'EUR_ESTR',
    name: 'EUR €STR Benchmark Curve',
    currency: 'EUR',
    benchmark: '€STR',
    constructionMethod: 'BOOTSTRAP_OIS',
    timestamp: '2026-10-15 16:30:00 CET',
    interpolation: 'LOG_LINEAR_DF',
    calibrationResidualRms: 0.00007,
    points: [
      { tenorLabel: 'O/N', tenorYears: 1 / 360, zeroRate: 0.0315, discountFactor: 0.999912, forwardRate: 0.0315, parSwapRate: 0.0315 },
      { tenorLabel: '1M', tenorYears: 1 / 12, zeroRate: 0.0312, discountFactor: 0.997403, forwardRate: 0.0310, parSwapRate: 0.0312 },
      { tenorLabel: '3M', tenorYears: 0.25, zeroRate: 0.0305, discountFactor: 0.992404, forwardRate: 0.0301, parSwapRate: 0.0305 },
      { tenorLabel: '6M', tenorYears: 0.5, zeroRate: 0.0295, discountFactor: 0.985356, forwardRate: 0.0285, parSwapRate: 0.0295 },
      { tenorLabel: '1Y', tenorYears: 1.0, zeroRate: 0.0275, discountFactor: 0.972872, forwardRate: 0.0255, parSwapRate: 0.0275 },
      { tenorLabel: '2Y', tenorYears: 2.0, zeroRate: 0.0260, discountFactor: 0.949328, forwardRate: 0.0245, parSwapRate: 0.0260 },
      { tenorLabel: '3Y', tenorYears: 3.0, zeroRate: 0.0255, discountFactor: 0.926359, forwardRate: 0.0245, parSwapRate: 0.0255 },
      { tenorLabel: '5Y', tenorYears: 5.0, zeroRate: 0.0265, discountFactor: 0.875904, forwardRate: 0.0280, parSwapRate: 0.0265 },
      { tenorLabel: '7Y', tenorYears: 7.0, zeroRate: 0.0280, discountFactor: 0.822018, forwardRate: 0.0318, parSwapRate: 0.0280 },
      { tenorLabel: '10Y', tenorYears: 10.0, zeroRate: 0.0300, discountFactor: 0.740818, forwardRate: 0.0347, parSwapRate: 0.0300 },
    ],
  },
  USD_REPO_GC: {
    id: 'USD_REPO_GC',
    name: 'US Treasury General Collateral Repo Curve',
    currency: 'USD',
    benchmark: 'US_REPO_GC',
    constructionMethod: 'BOOTSTRAP_OIS',
    timestamp: '2026-10-15 16:30:00 EST',
    interpolation: 'LOG_LINEAR_DF',
    calibrationResidualRms: 0.00009,
    points: [
      { tenorLabel: 'O/N', tenorYears: 1 / 360, zeroRate: 0.0482, discountFactor: 0.999866, forwardRate: 0.0482, parSwapRate: 0.0482 },
      { tenorLabel: '1M', tenorYears: 1 / 12, zeroRate: 0.0478, discountFactor: 0.996032, forwardRate: 0.0476, parSwapRate: 0.0478 },
      { tenorLabel: '3M', tenorYears: 0.25, zeroRate: 0.0470, discountFactor: 0.988323, forwardRate: 0.0465, parSwapRate: 0.0470 },
      { tenorLabel: '6M', tenorYears: 0.5, zeroRate: 0.0454, discountFactor: 0.977556, forwardRate: 0.0438, parSwapRate: 0.0454 },
      { tenorLabel: '1Y', tenorYears: 1.0, zeroRate: 0.0428, discountFactor: 0.958102, forwardRate: 0.0402, parSwapRate: 0.0428 },
      { tenorLabel: '2Y', tenorYears: 2.0, zeroRate: 0.0402, discountFactor: 0.922744, forwardRate: 0.0376, parSwapRate: 0.0402 },
      { tenorLabel: '5Y', tenorYears: 5.0, zeroRate: 0.0382, discountFactor: 0.826132, forwardRate: 0.0369, parSwapRate: 0.0382 },
    ],
  },
};

/**
 * Log-linear discount factor interpolation
 * For t between t1 and t2:
 * DF(t) = exp( ln(DF1) * (t2 - t)/(t2 - t1) + ln(DF2) * (t - t1)/(t2 - t1) )
 */
export function interpolateDiscountFactor(
  curve: YieldCurveDefinition,
  targetTenorYears: number
): { discountFactor: number; zeroRate: number; isExtrapolated: boolean } {
  const pts = curve.points;
  if (!pts || pts.length === 0) {
    return { discountFactor: 1.0, zeroRate: 0.0, isExtrapolated: false };
  }

  if (targetTenorYears <= 0) {
    return { discountFactor: 1.0, zeroRate: pts[0].zeroRate, isExtrapolated: false };
  }

  // Pre-curve extrapolation (shorter than first tenor)
  if (targetTenorYears <= pts[0].tenorYears) {
    const r0 = pts[0].zeroRate;
    const df = Math.exp(-r0 * targetTenorYears);
    return { discountFactor: df, zeroRate: r0, isExtrapolated: targetTenorYears < pts[0].tenorYears };
  }

  // Post-curve extrapolation (longer than last tenor)
  if (targetTenorYears >= pts[pts.length - 1].tenorYears) {
    const last = pts[pts.length - 1];
    const prev = pts[pts.length - 2] || last;
    // Flat forward extrapolation
    const forwardRate = last.forwardRate || last.zeroRate;
    const dt = targetTenorYears - last.tenorYears;
    const df = last.discountFactor * Math.exp(-forwardRate * dt);
    const zeroRate = -Math.log(df) / targetTenorYears;
    return { discountFactor: df, zeroRate, isExtrapolated: true };
  }

  // Bracket within curve points
  let idx = 0;
  while (idx < pts.length - 1 && pts[idx + 1].tenorYears < targetTenorYears) {
    idx++;
  }

  const p1 = pts[idx];
  const p2 = pts[idx + 1];

  const w2 = (targetTenorYears - p1.tenorYears) / (p2.tenorYears - p1.tenorYears);
  const w1 = 1.0 - w2;

  // Log-linear interpolation on discount factors
  const lnDf = w1 * Math.log(p1.discountFactor) + w2 * Math.log(p2.discountFactor);
  const df = Math.exp(lnDf);
  const zeroRate = -lnDf / targetTenorYears;

  return { discountFactor: df, zeroRate, isExtrapolated: false };
}

/**
 * Calculates forward rate between t1 and t2:
 * F(t1, t2) = (DF(t1) / DF(t2) - 1) / (t2 - t1)
 */
export function calculateForwardRate(
  curve: YieldCurveDefinition,
  t1: number,
  t2: number
): number {
  if (t2 <= t1) return 0;
  const df1 = interpolateDiscountFactor(curve, t1).discountFactor;
  const df2 = interpolateDiscountFactor(curve, t2).discountFactor;
  return (df1 / df2 - 1.0) / (t2 - t1);
}

/**
 * Applies a cross-currency basis adjustment to a base discount curve:
 * DF_synth(t) = DF_base(t) * exp(-basisSpread * t)
 */
export function applyCrossCurrencyBasis(
  baseCurve: YieldCurveDefinition,
  basisBps: number,
  syntheticName: string
): YieldCurveDefinition {
  const basisRate = basisBps / 10000.0;
  const newPoints: YieldCurvePoint[] = baseCurve.points.map((p) => {
    const newDf = p.discountFactor * Math.exp(-basisRate * p.tenorYears);
    const newZero = -Math.log(newDf) / (p.tenorYears || 1 / 360);
    return {
      tenorLabel: p.tenorLabel,
      tenorYears: p.tenorYears,
      zeroRate: newZero,
      discountFactor: newDf,
      forwardRate: p.forwardRate + basisRate,
      parSwapRate: (p.parSwapRate || p.zeroRate) + basisRate,
    };
  });

  return {
    id: `${baseCurve.id}_BASIS_${basisBps}`,
    name: syntheticName,
    currency: baseCurve.currency,
    benchmark: `${baseCurve.benchmark} + Basis`,
    constructionMethod: 'SYNTHETIC_COMPOSITE',
    timestamp: baseCurve.timestamp,
    interpolation: baseCurve.interpolation,
    calibrationResidualRms: baseCurve.calibrationResidualRms,
    points: newPoints,
  };
}
