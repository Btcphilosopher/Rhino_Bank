/**
 * RhinoQuant Scenario & Risk Simulation Engine
 * Computes deterministic multi-parameter stress scenarios and
 * Monte Carlo simulations with VaR(95), CVaR(95), and distribution histograms.
 */

import { MonteCarloResult, StressScenario, CashFlowRecord } from '../types';
import { solveSyntheticXIRR } from './xirrSolver';

export const PRESET_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'BASE',
    name: 'Base Scenario (Market Benchmark)',
    description: 'Current market forward curve and contractual financing parameters.',
    rateShiftBps: 0,
    curveSteepeningBps: 0,
    creditSpreadShiftBps: 0,
    repoHaircutShiftPct: 0,
    fxShockPct: 0,
    defaultRateMultiplier: 1.0,
    prepaymentMultiplier: 1.0,
    exitMultipleShiftPct: 0,
  },
  {
    id: 'RATE_SPIKE_200',
    name: 'Central Bank Rate Shock (+200 bps)',
    description: 'Sharp parallel monetary tightening raising benchmark and funding yields by 200 bps.',
    rateShiftBps: 200,
    curveSteepeningBps: -25,
    creditSpreadShiftBps: 45,
    repoHaircutShiftPct: 2.0,
    fxShockPct: -3.0,
    defaultRateMultiplier: 1.3,
    prepaymentMultiplier: 0.6,
    exitMultipleShiftPct: -5.0,
  },
  {
    id: 'REPO_CRUNCH',
    name: 'Secured Funding & Collateral Freeze',
    description: 'Repo haircuts expand by 10%, repo spreads widen by 150 bps, forcing deleveraging.',
    rateShiftBps: 75,
    curveSteepeningBps: 10,
    creditSpreadShiftBps: 120,
    repoHaircutShiftPct: 10.0,
    fxShockPct: -5.0,
    defaultRateMultiplier: 1.5,
    prepaymentMultiplier: 0.4,
    exitMultipleShiftPct: -12.0,
  },
  {
    id: 'CREDIT_CRISIS',
    name: 'Severe Credit Dislocation & Default Surge',
    description: 'Corporate spreads widen +350 bps, defaults jump 2.5x, exit valuations cut by 25%.',
    rateShiftBps: -100, // Flight to safety drops base rates
    curveSteepeningBps: 50,
    creditSpreadShiftBps: 350,
    repoHaircutShiftPct: 15.0,
    fxShockPct: -12.0,
    defaultRateMultiplier: 2.5,
    prepaymentMultiplier: 0.2,
    exitMultipleShiftPct: -25.0,
  },
  {
    id: 'EXPANSION_UPSIDE',
    name: 'Economic Expansion & Yield Tightening',
    description: 'Credit spreads tighten -75 bps, exit multiples rise +15%, prepayment speeds rise.',
    rateShiftBps: -25,
    curveSteepeningBps: 15,
    creditSpreadShiftBps: -75,
    repoHaircutShiftPct: -2.0,
    fxShockPct: 4.0,
    defaultRateMultiplier: 0.6,
    prepaymentMultiplier: 1.4,
    exitMultipleShiftPct: 15.0,
  },
];

/**
 * Pseudo-random generator with seed (Box-Muller transform for normal distribution)
 */
function createPrng(seed = 42) {
  let s = seed;
  return () => {
    s = (s * 16807 + 0) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function sampleNormal(rng: () => number, mean = 0, stdDev = 1): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  const z0 = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + z0 * stdDev;
}

/**
 * Runs a fast Monte Carlo simulation over cash flow trajectories
 */
export function runMonteCarloIRR(
  baseLedger: CashFlowRecord[],
  baseIrr: number,
  simulationCount = 1000,
  seed = 12345
): MonteCarloResult {
  const rng = createPrng(seed);
  const simulatedIrrs: number[] = [];

  // Volatility assumptions:
  // Rate vol = 120 bps, Spread vol = 90 bps, Exit exit value vol = 14%
  const rateVol = 0.012;
  const exitVol = 0.14;

  const validFlows = baseLedger.filter((cf) => Math.abs(cf.netInvestorFlow) > 1e-6);

  for (let s = 0; s < simulationCount; s++) {
    const rateShock = sampleNormal(rng, 0, rateVol);
    const exitShock = sampleNormal(rng, 0, exitVol);

    const simFlows = validFlows.map((cf) => {
      let flow = cf.netInvestorFlow;
      if (cf.category === 'INTEREST_PAYMENT' || cf.category === 'DRAWDOWN_PROCEEDS') {
        // Financing interest shifts with rate shock
        flow += cf.financingFlow * rateShock * cf.yearFraction;
      }
      if (cf.category === 'EXIT_PROCEEDS') {
        // Exit proceeds shocked
        flow = flow * Math.max(0.1, 1.0 + exitShock);
      }
      return { tau: cf.yearFraction, amount: flow };
    });

    const diag = solveSyntheticXIRR(simFlows);
    if (diag.status === 'CONVERGED' && Number.isFinite(diag.root)) {
      simulatedIrrs.push(diag.root);
    } else {
      // Conservative estimate if distressed
      simulatedIrrs.push(baseIrr - 0.12);
    }
  }

  simulatedIrrs.sort((a, b) => a - b);

  const n = simulatedIrrs.length;
  const sum = simulatedIrrs.reduce((acc, val) => acc + val, 0);
  const mean = sum / n;

  const variance = simulatedIrrs.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / n;
  const stdDev = Math.sqrt(variance);

  const p5 = simulatedIrrs[Math.floor(n * 0.05)];
  const p25 = simulatedIrrs[Math.floor(n * 0.25)];
  const median = simulatedIrrs[Math.floor(n * 0.50)];
  const p75 = simulatedIrrs[Math.floor(n * 0.75)];
  const p95 = simulatedIrrs[Math.floor(n * 0.95)];

  // VaR 95%: Distance from mean to 5th percentile
  const var95 = Math.max(0, mean - p5);

  // CVaR (Expected Shortfall): Average of bottom 5% outcomes
  const bottom5Count = Math.floor(n * 0.05);
  const bottom5Sum = simulatedIrrs.slice(0, bottom5Count).reduce((a, b) => a + b, 0);
  const cvar95 = bottom5Count > 0 ? Math.max(0, mean - bottom5Sum / bottom5Count) : var95;

  const countNegativeNpv = simulatedIrrs.filter((r) => r < 0.045).length; // Below 4.5% risk free
  const countCapitalLoss = simulatedIrrs.filter((r) => r <= 0.0).length;

  // Histogram buckets (16 equal bins between min and max)
  const minVal = simulatedIrrs[0];
  const maxVal = simulatedIrrs[simulatedIrrs.length - 1];
  const bucketCount = 14;
  const step = (maxVal - minVal) / bucketCount;

  const distributionBuckets = [];
  for (let b = 0; b < bucketCount; b++) {
    const bMin = minVal + b * step;
    const bMax = bMin + step;
    const count = simulatedIrrs.filter((v) => (b === bucketCount - 1 ? v >= bMin && v <= bMax : v >= bMin && v < bMax)).length;
    distributionBuckets.push({
      rangeLabel: `${(bMin * 100).toFixed(1)}% - ${(bMax * 100).toFixed(1)}%`,
      count,
      minVal: bMin,
      maxVal: bMax,
    });
  }

  return {
    simulationCount: n,
    meanIrr: mean,
    medianIrr: median,
    stdDevIrr: stdDev,
    p5Irr: p5,
    p25Irr: p25,
    p75Irr: p75,
    p95Irr: p95,
    var95,
    cvar95,
    probNegativeNpv: (countNegativeNpv / n) * 100,
    probCapitalLoss: (countCapitalLoss / n) * 100,
    distributionBuckets,
  };
}
