/**
 * RhinoQuant Day Count Fraction Engine
 * Implements standard institutional day-count conventions:
 * ACT/360 (Money Market / US Floating / SOFR)
 * ACT/365 (Sterling / Commonwealth / Money Market Fixed)
 * 30/360 (Bond Basis / ISMA-30/360)
 * ACT/ACT (US Treasury / ISDA)
 */

import { DayCountConvention } from '../types';

export function parseISODate(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day));
}

export function formatISODate(d: Date): string {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

export function getDaysBetween(d1: Date, d2: Date): number {
  const msPerDay = 86400000;
  return Math.round((d2.getTime() - d1.getTime()) / msPerDay);
}

export function calcYearFraction(
  startDateStr: string,
  endDateStr: string,
  convention: DayCountConvention = 'ACT/365'
): number {
  const d1 = parseISODate(startDateStr);
  const d2 = parseISODate(endDateStr);

  if (d1.getTime() === d2.getTime()) return 0;
  if (d2.getTime() < d1.getTime()) {
    return -calcYearFraction(endDateStr, startDateStr, convention);
  }

  const daysDiff = getDaysBetween(d1, d2);

  switch (convention) {
    case 'ACT/360':
      return daysDiff / 360.0;

    case 'ACT/365':
      return daysDiff / 365.0;

    case '30/360': {
      // 30/360 US (ISDA) / Bond Basis convention
      let y1 = d1.getUTCFullYear();
      let m1 = d1.getUTCMonth() + 1;
      let day1 = d1.getUTCDate();

      let y2 = d2.getUTCFullYear();
      let m2 = d2.getUTCMonth() + 1;
      let day2 = d2.getUTCDate();

      if (day1 === 31) day1 = 30;
      if (day2 === 31 && day1 >= 30) day2 = 30;

      const numDays = 360 * (y2 - y1) + 30 * (m2 - m1) + (day2 - day1);
      return numDays / 360.0;
    }

    case 'ACT/ACT': {
      const y1 = d1.getUTCFullYear();
      const y2 = d2.getUTCFullYear();

      if (y1 === y2) {
        const totalYearDays = isLeapYear(y1) ? 366.0 : 365.0;
        return daysDiff / totalYearDays;
      }

      // Span multiple years
      const endOfFirstYear = new Date(Date.UTC(y1, 11, 31));
      const startOfLastYear = new Date(Date.UTC(y2, 0, 1));

      const daysInFirstYear = getDaysBetween(d1, endOfFirstYear) + 1;
      const daysInLastYear = getDaysBetween(startOfLastYear, d2);

      let fraction = daysInFirstYear / (isLeapYear(y1) ? 366.0 : 365.0);
      fraction += daysInLastYear / (isLeapYear(y2) ? 366.0 : 365.0);

      if (y2 - y1 > 1) {
        fraction += y2 - y1 - 1;
      }

      return fraction;
    }

    default:
      return daysDiff / 365.0;
  }
}
