/**
 * RhinoQuant FX Carry & Cross-Market Yield Engineering Engine
 * Models interest rate differentials, forward points under CIP with cross-currency basis,
 * rollover drag, leverage, margin requirements, and currency shock scenarios.
 */

import { FXCarryTradeConfig } from '../types';

export interface FXCarryAnalysisResult {
  spotFx: number;
  forwardPoints: number; // In pips / points
  forwardFx: number;
  grossInterestDifferentialPct: number;
  forwardHedgingCostPct: number;
  netCarryYieldUnleveredPct: number;
  netCarryYieldLeveredPct: number;
  annualizedRolloverCostPct: number;
  totalHedgeDragPct: number;
  syntheticXirrAnnual: number;
  equityRequired: number; // Cash capital deployed
  borrowedAmount: number;
  marginCallThresholdFxPct: number; // Spot move that triggers margin call
  stressScenarios: {
    fxChangePct: number;
    scenarioSpot: number;
    unhedgedPnl: number;
    hedgedPnl: number;
    scenarioNetReturnPct: number;
    isMarginBreached: boolean;
  }[];
}

export function analyzeFXCarryTrade(
  config: FXCarryTradeConfig,
  notionalBase = 10000000 // e.g. 10M USD notional
): FXCarryAnalysisResult {
  const tau = config.holdingPeriodMonths / 12.0;
  const basisRate = config.crossCurrencyBasisBps / 10000.0;
  const transactionCostRate = config.transactionCostBps / 10000.0;

  // Covered Interest Parity (CIP) theoretical forward exchange rate:
  // F = S * (1 + (r_invest + basis) * tau) / (1 + r_fund * tau)
  const num = 1.0 + (config.investmentRate + basisRate) * tau;
  const den = 1.0 + config.fundingRate * tau;
  const theoreticalForward = config.spotFx * (num / den);
  const forwardPoints = theoreticalForward - config.spotFx;

  // Annualized rates
  const interestDifferential = config.investmentRate - config.fundingRate;
  
  // Forward hedging drag (annualized loss from selling investment currency forward at discount)
  const forwardDiscountAnnual = ((config.spotFx - theoreticalForward) / config.spotFx) / tau;

  // Unlevered carry return
  // If unhedged: interest diff - rollover - tx cost
  // If hedged: interest diff - hedge drag - rollover - tx cost
  const rolloverCostAnnual = 0.0020; // 20 bps annual rollover spread
  const effectiveHedgeDragAnnual = config.hedgedRatio * forwardDiscountAnnual;
  const netCarryYieldUnlevered = interestDifferential - effectiveHedgeDragAnnual - rolloverCostAnnual - (transactionCostRate / tau);

  // Leverage and margin math
  // Equity = Notional / Leverage
  const leverage = Math.max(1.0, config.leverage);
  const equityRequired = notionalBase / leverage;
  const borrowedAmount = notionalBase - equityRequired;

  // Levered return: Net yield * leverage - (leverage - 1) * funding spread
  const netCarryYieldLevered = netCarryYieldUnlevered * leverage;

  // Synthetic XIRR: compounded annual return
  const syntheticXirrAnnual = Math.pow(1.0 + netCarryYieldLevered * tau, 1.0 / tau) - 1.0;

  // Margin call threshold: if unhedged currency depreciation exceeds initial equity haircut
  const marginCallThresholdFxPct = -((config.haircutPct / 100.0) / leverage) * 100.0;

  // Scenario stress table: currency shocks from -30% to +15%
  const shockLevels = [-0.30, -0.20, -0.15, -0.10, -0.05, 0.0, 0.05, 0.10];
  const stressScenarios = shockLevels.map((shockPct) => {
    const scenarioSpot = config.spotFx * (1.0 + shockPct);
    const currencyPnl = notionalBase * shockPct;
    const unhedgedTotalPnl = (notionalBase * (interestDifferential * tau)) + currencyPnl;
    
    // Hedged portion protects against spot shock
    const hedgedCurrencyPnl = currencyPnl * (1.0 - config.hedgedRatio);
    const hedgeCost = notionalBase * (effectiveHedgeDragAnnual * tau);
    const hedgedTotalPnl = (notionalBase * (interestDifferential * tau)) + hedgedCurrencyPnl - hedgeCost;

    const finalPnl = config.hedgedRatio > 0 ? hedgedTotalPnl : unhedgedTotalPnl;
    const scenarioNetReturnPct = (finalPnl / equityRequired) * (1.0 / tau);
    const isMarginBreached = !config.hedgedRatio && shockPct <= (marginCallThresholdFxPct / 100.0);

    return {
      fxChangePct: shockPct * 100,
      scenarioSpot,
      unhedgedPnl: unhedgedTotalPnl,
      hedgedPnl: hedgedTotalPnl,
      scenarioNetReturnPct: scenarioNetReturnPct * 100,
      isMarginBreached,
    };
  });

  return {
    spotFx: config.spotFx,
    forwardPoints,
    forwardFx: theoreticalForward,
    grossInterestDifferentialPct: interestDifferential * 100,
    forwardHedgingCostPct: forwardDiscountAnnual * 100,
    netCarryYieldUnleveredPct: netCarryYieldUnlevered * 100,
    netCarryYieldLeveredPct: netCarryYieldLevered * 100,
    annualizedRolloverCostPct: rolloverCostAnnual * 100,
    totalHedgeDragPct: effectiveHedgeDragAnnual * 100,
    syntheticXirrAnnual,
    equityRequired,
    borrowedAmount,
    marginCallThresholdFxPct,
    stressScenarios,
  };
}
