/**
 * RhinoQuant Structured Credit & Securitization Waterfall Engine
 * Models collateral pool monthly amortization, CDR (defaults), CPR (prepayments),
 * recovery timing, and sequential payment/loss waterfall across credit tranches.
 */

import { SecuritizationWaterfallConfig, CreditTranche } from '../types';
import { solveSyntheticXIRR } from './xirrSolver';

export interface WaterfallExecutionResult {
  periods: number;
  totalPoolInterestGenerated: number;
  totalPoolPrincipalRepaid: number;
  totalPoolLosses: number;
  totalPoolPrepayments: number;
  servicingFeesPaid: number;
  tranches: (CreditTranche & {
    calculatedIrr: number;
    realizedMoic: number;
    principalLossPct: number;
  })[];
  monthlyLedger: {
    period: number;
    beginningBalance: number;
    scheduledPrincipal: number;
    prepayments: number;
    defaults: number;
    recoveries: number;
    endingBalance: number;
    interestCollected: number;
    seniorPayment: number;
    mezzPayment: number;
    equityPayment: number;
  }[];
}

export function executeSecuritizationWaterfall(
  config: SecuritizationWaterfallConfig
): WaterfallExecutionResult {
  const totalMonths = Math.round(config.collateralTenorYears * 12);
  const monthlyCoupon = config.collateralCouponRate / 12.0;
  const monthlyServicing = (config.servicingFeeBps / 10000.0) / 12.0;

  // SMM (Single Monthly Mortality) from annual CDR: SMM = 1 - (1 - CDR)^(1/12)
  const smm = 1.0 - Math.pow(1.0 - config.constantDefaultRateCdr, 1.0 / 12.0);
  // SMP (Single Monthly Prepayment) from annual CPR: SMP = 1 - (1 - CPR)^(1/12)
  const smp = 1.0 - Math.pow(1.0 - config.conditionalPrepaymentRateCpr, 1.0 / 12.0);

  let poolBalance = config.collateralPoolNotional;
  let totalInterest = 0;
  let totalPrincipal = 0;
  let totalLosses = 0;
  let totalPrepay = 0;
  let totalFees = 0;

  // Initialize tranches copy
  const liveTranches = config.tranches.map((t) => ({
    ...t,
    principalBalance: t.sizeAmount,
    cumulativeLoss: 0,
    cumulativeInterestReceived: 0,
    cumulativePrincipalReceived: 0,
    cashFlowSeries: [{ tau: 0, amount: -t.sizeAmount }],
  }));

  const monthlyLedger = [];

  for (let m = 1; m <= totalMonths; m++) {
    if (poolBalance <= 1e-4) break;

    const beginningBal = poolBalance;

    // 1. Defaults & Prepayments this month
    const defaultAmount = poolBalance * smm;
    const recoveryAmount = defaultAmount * config.recoveryRate;
    const lossAmount = defaultAmount - recoveryAmount;

    const prepayAmount = (poolBalance - defaultAmount) * smp;

    // 2. Scheduled principal amortization (straight line or balloon)
    const remainingMonths = totalMonths - m + 1;
    const scheduledPrincipal = Math.min(
      poolBalance - defaultAmount - prepayAmount,
      beginningBal / remainingMonths
    );

    // 3. Gross interest collected
    const grossInterest = poolBalance * monthlyCoupon;
    const servicingFee = poolBalance * monthlyServicing;
    const netInterestAvailable = Math.max(0, grossInterest - servicingFee);

    // Total principal cash available to distribute (scheduled + prepayments + recoveries)
    const principalAvailable = scheduledPrincipal + prepayAmount + recoveryAmount;

    // Update pool balance
    poolBalance = Math.max(
      0,
      poolBalance - scheduledPrincipal - prepayAmount - defaultAmount
    );

    totalInterest += grossInterest;
    totalPrincipal += principalAvailable;
    totalLosses += lossAmount;
    totalPrepay += prepayAmount;
    totalFees += servicingFee;

    // 4. Distribute Interest through Seniority Waterfall (Seniority 1 -> 2 -> 3)
    let interestPool = netInterestAvailable;
    const monthPayments: number[] = [0, 0, 0];

    for (let i = 0; i < liveTranches.length; i++) {
      const tr = liveTranches[i];
      if (tr.principalBalance > 0) {
        const trancheMonthlyCoupon = (config.collateralCouponRate + (tr.couponSpreadBps / 10000.0)) / 12.0;
        const interestDue = tr.principalBalance * trancheMonthlyCoupon;
        const interestPaid = Math.min(interestPool, interestDue);
        interestPool -= interestPaid;
        tr.cumulativeInterestReceived += interestPaid;
        monthPayments[i] += interestPaid;
      }
    }

    // Residual interest flows to lowest seniority (Equity / Junior)
    if (interestPool > 0 && liveTranches.length > 0) {
      const equityTranche = liveTranches[liveTranches.length - 1];
      equityTranche.cumulativeInterestReceived += interestPool;
      monthPayments[liveTranches.length - 1] += interestPool;
    }

    // 5. Distribute Principal through Sequential Waterfall (Senior first until paid down)
    let principalPool = principalAvailable;
    for (let i = 0; i < liveTranches.length; i++) {
      const tr = liveTranches[i];
      if (tr.principalBalance > 0 && principalPool > 0) {
        const principalPaid = Math.min(principalPool, tr.principalBalance);
        principalPool -= principalPaid;
        tr.principalBalance -= principalPaid;
        tr.cumulativePrincipalReceived += principalPaid;
        monthPayments[i] += principalPaid;
      }
    }

    // 6. Allocate Losses through Reverse Seniority (Equity absorbs first, then Mezz, then Senior)
    let unabsorbedLoss = lossAmount;
    for (let i = liveTranches.length - 1; i >= 0; i--) {
      const tr = liveTranches[i];
      if (tr.principalBalance > 0 && unabsorbedLoss > 0) {
        const lossToTranche = Math.min(unabsorbedLoss, tr.principalBalance);
        tr.principalBalance -= lossToTranche;
        tr.cumulativeLoss += lossToTranche;
        unabsorbedLoss -= lossToTranche;
      }
    }

    // Record cash flows for each tranche
    const tau = m / 12.0;
    for (let i = 0; i < liveTranches.length; i++) {
      liveTranches[i].cashFlowSeries.push({ tau, amount: monthPayments[i] });
    }

    monthlyLedger.push({
      period: m,
      beginningBalance: beginningBal,
      scheduledPrincipal,
      prepayments: prepayAmount,
      defaults: defaultAmount,
      recoveries: recoveryAmount,
      endingBalance: poolBalance,
      interestCollected: grossInterest,
      seniorPayment: monthPayments[0] || 0,
      mezzPayment: monthPayments[1] || 0,
      equityPayment: monthPayments[2] || 0,
    });
  }

  // Calculate tranche IRRs and return multiples
  const calculatedTranches = liveTranches.map((t) => {
    const totalCashReturned = t.cumulativeInterestReceived + t.cumulativePrincipalReceived;
    const moic = t.sizeAmount > 0 ? totalCashReturned / t.sizeAmount : 0;
    const lossPct = t.sizeAmount > 0 ? (t.cumulativeLoss / t.sizeAmount) * 100 : 0;

    const diag = solveSyntheticXIRR(t.cashFlowSeries);
    const irr = diag.status === 'CONVERGED' ? diag.root : Number.NaN;

    return {
      ...t,
      calculatedIrr: irr,
      realizedMoic: moic,
      principalLossPct: lossPct,
    };
  });

  return {
    periods: monthlyLedger.length,
    totalPoolInterestGenerated: totalInterest,
    totalPoolPrincipalRepaid: totalPrincipal,
    totalPoolLosses: totalLosses,
    totalPoolPrepayments: totalPrepay,
    servicingFeesPaid: totalFees,
    tranches: calculatedTranches,
    monthlyLedger,
  };
}
