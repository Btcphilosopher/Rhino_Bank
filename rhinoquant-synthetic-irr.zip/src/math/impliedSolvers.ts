/**
 * RhinoQuant Mode C: Implied Rate & Spread Extraction Engine
 * Solves for unknown parameters (YTM, Discount Margin, Benchmark Spread, Break-even Carry)
 * that reconcile modelled valuation with market prices.
 */

import { calcYearFraction } from './dayCount';

/**
 * Solves for Yield to Maturity (YTM) of a coupon-bearing bond
 * Price = Σ [ (Coupon / m) / (1 + y/m)^(m * t_i) ] + Par / (1 + y/m)^(m * T)
 */
export function solveBondYTM(
  cleanPrice: number, // e.g. 98.50 per 100 par
  par: number, // usually 100
  annualCouponRate: number, // e.g. 0.0575 for 5.75%
  maturityYears: number, // e.g. 5.0
  frequency = 2, // 2 = Semi-annual, 1 = Annual, 4 = Quarterly
  tol = 1e-8,
  maxIter = 100
): { ytm: number; iterations: number; residual: number; isConverged: boolean } {
  const couponPayment = (annualCouponRate * par) / frequency;
  const totalPeriods = Math.round(maturityYears * frequency);

  function priceAtYield(y: number): number {
    const periodYield = y / frequency;
    if (periodYield <= -1.0) return Number.NaN;
    let pv = 0.0;
    for (let p = 1; p <= totalPeriods; p++) {
      pv += couponPayment / Math.pow(1.0 + periodYield, p);
    }
    pv += par / Math.pow(1.0 + periodYield, totalPeriods);
    return pv;
  }

  function dPriceDy(y: number): number {
    const periodYield = y / frequency;
    if (periodYield <= -1.0) return Number.NaN;
    let dp = 0.0;
    for (let p = 1; p <= totalPeriods; p++) {
      dp -= (p / frequency) * (couponPayment / Math.pow(1.0 + periodYield, p + 1));
    }
    dp -= (totalPeriods / frequency) * (par / Math.pow(1.0 + periodYield, totalPeriods + 1));
    return dp;
  }

  // Initial estimate using standard approximation formula
  let y =
    (annualCouponRate * par + (par - cleanPrice) / maturityYears) /
    ((par + cleanPrice) / 2);

  if (y <= 0) y = 0.05;

  let iter = 0;
  while (iter < maxIter) {
    iter++;
    const p = priceAtYield(y);
    const diff = p - cleanPrice;

    if (Math.abs(diff) < tol) {
      return { ytm: y, iterations: iter, residual: Math.abs(diff), isConverged: true };
    }

    const dp = dPriceDy(y);
    if (!Number.isFinite(dp) || Math.abs(dp) < 1e-12) {
      break;
    }

    const step = diff / dp;
    y = y - step;

    if (y < -0.2) y = 0.01; // safeguard
  }

  return {
    ytm: y,
    iterations: iter,
    residual: Math.abs(priceAtYield(y) - cleanPrice),
    isConverged: Math.abs(priceAtYield(y) - cleanPrice) < 0.01,
  };
}

/**
 * Solves for Discount Margin (DM) on a Floating-Rate Note (FRN)
 * Price = Σ [ (Index + DM) * (tau) * Par / (1 + (Index + DM)*tau)^p ] + Par / ...
 * Standard ISMA / market convention approximation:
 */
export function solveDiscountMarginFRN(
  cleanPrice: number, // e.g. 99.25
  par: number, // 100
  quotedMarginBps: number, // e.g. 150 bps
  indexRate: number, // e.g. 0.0485 (SOFR)
  maturityYears: number,
  frequency = 4 // Quarterly reset
): { discountMarginBps: number; iterations: number; residual: number } {
  const quotedSpread = quotedMarginBps / 10000.0;
  const couponRate = indexRate + quotedSpread;
  const couponPeriod = (couponRate * par) / frequency;
  const totalPeriods = Math.round(maturityYears * frequency);
  const periodTau = 1.0 / frequency;

  // We want to solve for dm such that discounting cash flows with (indexRate + dm) equals cleanPrice
  let dm = quotedSpread; // Initial guess

  for (let iter = 0; iter < 50; iter++) {
    const discountRate = indexRate + dm;
    const periodDiscount = 1.0 + discountRate * periodTau;

    let pv = 0.0;
    let dPv = 0.0;

    for (let p = 1; p <= totalPeriods; p++) {
      const denom = Math.pow(periodDiscount, p);
      pv += couponPeriod / denom;
      dPv -= (p * periodTau * couponPeriod) / Math.pow(periodDiscount, p + 1);
    }
    const principalDenom = Math.pow(periodDiscount, totalPeriods);
    pv += par / principalDenom;
    dPv -= (totalPeriods * periodTau * par) / Math.pow(periodDiscount, totalPeriods + 1);

    const diff = pv - cleanPrice;
    if (Math.abs(diff) < 1e-6) {
      return {
        discountMarginBps: Math.round(dm * 10000),
        iterations: iter + 1,
        residual: Math.abs(diff),
      };
    }

    if (Math.abs(dPv) > 1e-10) {
      dm = dm - diff / dPv;
    }
  }

  return {
    discountMarginBps: Math.round(dm * 10000),
    iterations: 50,
    residual: 0,
  };
}

/**
 * Solves for constant benchmark spread s (in bps) over a discount curve
 * TargetPV = Σ [ CF_i * DF(0, t_i) * exp(-s * t_i) ]
 */
export function solveCurveSpread(
  cashFlows: { tau: number; amount: number }[],
  baseDiscountFactors: number[],
  targetPresentValue: number
): { spreadBps: number; residual: number; isConverged: boolean } {
  function pvAtSpread(s: number): number {
    let pv = 0.0;
    for (let i = 0; i < cashFlows.length; i++) {
      const cf = cashFlows[i];
      const df = baseDiscountFactors[i] || 1.0;
      pv += cf.amount * df * Math.exp(-s * cf.tau);
    }
    return pv;
  }

  // Bracket scan between -1000 bps and +3000 bps
  let sLow = -0.10;
  let sHigh = 0.30;
  let fLow = pvAtSpread(sLow) - targetPresentValue;
  let fHigh = pvAtSpread(sHigh) - targetPresentValue;

  if (fLow * fHigh > 0) {
    // Expand bracket
    sLow = -0.25;
    sHigh = 0.60;
    fLow = pvAtSpread(sLow) - targetPresentValue;
    fHigh = pvAtSpread(sHigh) - targetPresentValue;
  }

  // Bisection & Secant
  let s = (sLow + sHigh) / 2;
  for (let iter = 0; iter < 60; iter++) {
    const fMid = pvAtSpread(s) - targetPresentValue;
    if (Math.abs(fMid) < 1e-6) {
      return { spreadBps: Math.round(s * 10000), residual: Math.abs(fMid), isConverged: true };
    }

    if (fLow * fMid < 0) {
      sHigh = s;
      fHigh = fMid;
    } else {
      sLow = s;
      fLow = fMid;
    }
    s = (sLow + sHigh) / 2;
  }

  return {
    spreadBps: Math.round(s * 10000),
    residual: Math.abs(pvAtSpread(s) - targetPresentValue),
    isConverged: false,
  };
}
