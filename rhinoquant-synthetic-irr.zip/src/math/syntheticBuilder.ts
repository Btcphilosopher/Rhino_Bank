/**
 * RhinoQuant Synthetic Cash-Flow Builder & Return Decomposition Engine
 * Transforms financial instruments, hedges, and funding mechanisms into
 * a transparent dated cash-flow ledger and solves the complete return suite.
 */

import {
  FinancialInstrument,
  CashFlowRecord,
  SyntheticReturnSummary,
  SyntheticMode,
} from '../types';
import { calcYearFraction, parseISODate, formatISODate } from './dayCount';
import { solveSyntheticXIRR } from './xirrSolver';
import { interpolateDiscountFactor, STANDARD_CURVES } from './curveEngine';
import { solveCurveSpread } from './impliedSolvers';

export interface BuildLedgerOptions {
  referenceStartDate: string;
  instruments: FinancialInstrument[];
  mode: SyntheticMode;
  assumedBenchmarkRate?: number;
  curveId?: string;
  exitValuationOverride?: number;
  exitDateOverride?: string;
}

export function buildSyntheticLedger(options: BuildLedgerOptions): {
  ledger: CashFlowRecord[];
  summary: SyntheticReturnSummary;
} {
  const {
    referenceStartDate,
    instruments,
    mode,
    assumedBenchmarkRate = 0.0485,
    curveId = 'USD_SOFR',
    exitValuationOverride,
    exitDateOverride,
  } = options;

  const curve = STANDARD_CURVES[curveId] || STANDARD_CURVES.USD_SOFR;
  const ledger: CashFlowRecord[] = [];

  const activeInstruments = instruments.filter((i) => i.active);

  // 1. Initial Outflow / Deployment at Start Date
  let totalAssetOutflow = 0;
  let totalFinancingDrawdown = 0;
  let totalUpfrontFees = 0;
  let totalCollateralPosted = 0;

  activeInstruments.forEach((inst) => {
    if (inst.role === 'UNDERLYING_ASSET') {
      totalAssetOutflow += inst.notional;
    } else if (inst.role === 'PRIMARY_FUNDING' || inst.role === 'SECONDARY_FUNDING') {
      // In financing-adjusted return, debt drawdown covers asset purchase
      const haircut = inst.haircut || 0;
      const loanAmount = inst.notional * (1.0 - haircut);
      totalFinancingDrawdown += loanAmount;
      if (haircut > 0) {
        totalCollateralPosted += inst.notional * haircut;
      }
    } else if (inst.role === 'COLLATERAL_POSTING') {
      totalCollateralPosted += inst.notional;
    }

    if (inst.feesUpfront) {
      totalUpfrontFees += inst.feesUpfront;
    }
  });

  // Net initial equity deployed by investor:
  // Asset cost - Borrowing proceeds + Upfront fees + Collateral
  const netInitialInvestorOutflow = -(totalAssetOutflow - totalFinancingDrawdown + totalUpfrontFees + totalCollateralPosted);

  ledger.push({
    id: 'CF-T0-INIT',
    date: referenceStartDate,
    yearFraction: 0,
    period: 0,
    instrumentId: 'INIT-SYNTHETIC',
    instrumentName: 'Synthetic Position Initiation',
    category: 'INITIAL_OUTFLOW',
    grossAssetFlow: -totalAssetOutflow,
    financingFlow: totalFinancingDrawdown,
    hedgingFlow: 0,
    feeFlow: -totalUpfrontFees,
    collateralFlow: -totalCollateralPosted,
    netInvestorFlow: netInitialInvestorOutflow,
    discountFactor: 1.0,
    discountedNetFlow: netInitialInvestorOutflow,
    description: `Equity Deployment: $${(-netInitialInvestorOutflow / 1e6).toFixed(2)}M (Asset: -$${(totalAssetOutflow / 1e6).toFixed(2)}M, Debt: +$${(totalFinancingDrawdown / 1e6).toFixed(2)}M, Collateral: -$${(totalCollateralPosted / 1e6).toFixed(2)}M)`,
  });

  // Determine global timeline
  let maxMaturity = referenceStartDate;
  activeInstruments.forEach((i) => {
    if (i.maturityDate > maxMaturity) maxMaturity = i.maturityDate;
  });
  if (exitDateOverride && exitDateOverride > maxMaturity) {
    maxMaturity = exitDateOverride;
  }

  // Generate intermediate coupon/interest payment dates (quarterly or semi-annual)
  const startDateObj = parseISODate(referenceStartDate);
  const endDateObj = parseISODate(maxMaturity);
  const totalMonths = Math.max(
    1,
    (endDateObj.getUTCFullYear() - startDateObj.getUTCFullYear()) * 12 +
      (endDateObj.getUTCMonth() - startDateObj.getUTCMonth())
  );

  const paymentStepMonths = 3; // Quarterly resolution
  const numberOfPeriods = Math.ceil(totalMonths / paymentStepMonths);

  let cumulativeAssetInflow = 0;
  let cumulativeDebtService = 0;

  for (let p = 1; p <= numberOfPeriods; p++) {
    const curDate = new Date(startDateObj.getTime());
    curDate.setUTCMonth(curDate.getUTCMonth() + p * paymentStepMonths);
    if (curDate > endDateObj) {
      curDate.setTime(endDateObj.getTime());
    }
    const dateStr = formatISODate(curDate);
    const tau = calcYearFraction(referenceStartDate, dateStr, 'ACT/365');
    const periodTau = paymentStepMonths / 12.0;

    const { discountFactor } = interpolateDiscountFactor(curve, tau);

    let periodGrossAssetFlow = 0;
    let periodFinancingFlow = 0;
    let periodHedgingFlow = 0;
    let periodFeeFlow = 0;
    let periodCollateralFlow = 0;

    const isFinalPeriod = p === numberOfPeriods;

    activeInstruments.forEach((inst) => {
      // 1. Underlying Asset cash generation (Coupons, rental yield, or operating distribution)
      if (inst.role === 'UNDERLYING_ASSET') {
        const assetRate = inst.rateType === 'FIXED' ? (inst.fixedRate || 0.08) : (assumedBenchmarkRate + (inst.spreadBps || 200) / 10000.0);
        const assetDistribution = inst.notional * assetRate * periodTau;
        periodGrossAssetFlow += assetDistribution;
        cumulativeAssetInflow += assetDistribution;

        // Principal / Exit Proceeds at terminal date
        if (isFinalPeriod) {
          const terminalVal = exitValuationOverride !== undefined ? exitValuationOverride : inst.notional;
          periodGrossAssetFlow += terminalVal;
        }
      }

      // 2. Financing Debt Service (Interest and Principal Repayment)
      if (inst.role === 'PRIMARY_FUNDING' || inst.role === 'SECONDARY_FUNDING') {
        const debtNotional = inst.notional * (1.0 - (inst.haircut || 0));
        let debtRate = 0;
        if (inst.rateType === 'FIXED') {
          debtRate = inst.fixedRate || 0.055;
        } else if (inst.rateType === 'FLOATING') {
          debtRate = assumedBenchmarkRate + (inst.spreadBps || 150) / 10000.0;
        } else {
          // Repo / Secured rate
          debtRate = inst.fundingCostRate || assumedBenchmarkRate;
        }

        const interestDue = -debtNotional * debtRate * periodTau;
        periodFinancingFlow += interestDue;
        cumulativeDebtService += Math.abs(interestDue);

        // Terminal Principal Repayment
        if (isFinalPeriod) {
          periodFinancingFlow -= debtNotional;
        }
      }

      // 3. Rate Hedge Settlements (IRS, Swaps)
      if (inst.role === 'RATE_HEDGE' && inst.type === 'INTEREST_RATE_SWAP') {
        // Assume Pay Fixed, Receive Floating: Net = (Floating - Fixed) * Notional
        const fixedLeg = inst.fixedRate || 0.042;
        const floatingLeg = assumedBenchmarkRate;
        const swapNetSettlement = inst.notional * (floatingLeg - fixedLeg) * periodTau;
        periodHedgingFlow += swapNetSettlement;
      }

      // 4. Ongoing Fees (Management, commitment fees)
      if (inst.feesAnnualBps) {
        const feeAmount = -inst.notional * (inst.feesAnnualBps / 10000.0) * periodTau;
        periodFeeFlow += feeAmount;
      }
    });

    // Release collateral at terminal period
    if (isFinalPeriod && totalCollateralPosted > 0) {
      periodCollateralFlow += totalCollateralPosted;
    }

    const netPeriodInvestorFlow =
      periodGrossAssetFlow +
      periodFinancingFlow +
      periodHedgingFlow +
      periodFeeFlow +
      periodCollateralFlow;

    ledger.push({
      id: `CF-T${p}`,
      date: dateStr,
      yearFraction: tau,
      period: p,
      instrumentId: `PORTFOLIO-P${p}`,
      instrumentName: `Period ${p} Distribution & Debt Service`,
      category: isFinalPeriod ? 'EXIT_PROCEEDS' : 'INTEREST_PAYMENT',
      grossAssetFlow: periodGrossAssetFlow,
      financingFlow: periodFinancingFlow,
      hedgingFlow: periodHedgingFlow,
      feeFlow: periodFeeFlow,
      collateralFlow: periodCollateralFlow,
      netInvestorFlow: netPeriodInvestorFlow,
      discountFactor,
      discountedNetFlow: netPeriodInvestorFlow * discountFactor,
      description: isFinalPeriod
        ? `Terminal Exit & Final Debt Settlement (${dateStr})`
        : `Quarterly Cash Distribution & Debt Service (${dateStr})`,
    });
  }

  // 2. Solve Mathematical Returns
  // A. Investor Net Cash Flow Series (Financing-Adjusted Return)
  const netFlows = ledger.map((r) => ({
    tau: r.yearFraction,
    amount: r.netInvestorFlow,
  }));
  const investorDiag = solveSyntheticXIRR(netFlows);

  // B. Gross Asset Cash Flow Series (Unlevered Return)
  const grossFlows = ledger.map((r) => ({
    tau: r.yearFraction,
    amount: r.grossAssetFlow,
  }));
  const grossDiag = solveSyntheticXIRR(grossFlows);

  // C. Present Value & Spread to Curve
  const npv = ledger.reduce((acc, r) => acc + r.discountedNetFlow, 0);

  // Calculate MOIC (Multiple on Invested Capital)
  const totalInvested = Math.abs(ledger.filter((r) => r.netInvestorFlow < 0).reduce((a, b) => a + b.netInvestorFlow, 0));
  const totalReturned = ledger.filter((r) => r.netInvestorFlow > 0).reduce((a, b) => a + b.netInvestorFlow, 0);
  const moic = totalInvested > 0 ? totalReturned / totalInvested : 1.0;
  const netGain = totalReturned - totalInvested;

  // Implied benchmark spread
  const curveSpreadRes = solveCurveSpread(
    netFlows,
    ledger.map((r) => r.discountFactor),
    0.0 // Par NPV
  );

  // Blended annualized funding cost
  const fundingInstruments = activeInstruments.filter(
    (i) => i.role === 'PRIMARY_FUNDING' || i.role === 'SECONDARY_FUNDING'
  );
  let blendedFundingCost = assumedBenchmarkRate;
  if (fundingInstruments.length > 0) {
    let weightedRate = 0;
    let totalDebt = 0;
    fundingInstruments.forEach((i) => {
      const rate = i.rateType === 'FIXED' ? (i.fixedRate || 0.055) : (assumedBenchmarkRate + (i.spreadBps || 150) / 10000.0);
      weightedRate += rate * i.notional;
      totalDebt += i.notional;
    });
    if (totalDebt > 0) blendedFundingCost = weightedRate / totalDebt;
  }

  // Hedge cost drag in bps
  const totalHedgingPnl = ledger.reduce((a, b) => a + b.hedgingFlow, 0);
  const hedgeCostBps = totalAssetOutflow > 0 ? Math.round((-totalHedgingPnl / totalAssetOutflow / (totalMonths / 12.0)) * 10000) : 0;

  const investorIrr = investorDiag.status === 'CONVERGED' ? investorDiag.root : Number.NaN;
  const grossIrr = grossDiag.status === 'CONVERGED' ? grossDiag.root : Number.NaN;

  return {
    ledger,
    summary: {
      syntheticXirr: investorIrr,
      grossUnleveredIrr: grossIrr,
      financingAdjustedNetReturn: investorIrr,
      impliedBenchmarkSpreadBps: curveSpreadRes.spreadBps,
      npv,
      moic,
      totalInvestedEquity: totalInvested,
      totalDistributions: totalReturned,
      netGain,
      annualizedFundingCost: blendedFundingCost,
      hedgeCostBps,
      maxDrawdownPct: 0.0,
      calculationTimestamp: new Date().toISOString(),
      mode,
      diagnostics: investorDiag,
    },
  };
}
