/**
 * RhinoQuant Robust Multi-Root XIRR Engine
 * Implements bracketed Brent-Dekker solver and safeguarded Newton-Raphson
 * with sign-change analysis, domain scanning, and residual certification.
 */

import { SolverDiagnostics } from '../types';

export interface DatedCashFlow {
  date: string;
  amount: number;
}

export interface InternalCashFlow {
  tau: number; // Elapsed year fraction
  amount: number;
}

/**
 * Computes Net Present Value at rate r
 * NPV(r) = Σ [ CF_i / (1 + r)^tau_i ]
 */
export function computeNPV(flows: InternalCashFlow[], r: number): number {
  if (r <= -1.0) return Number.NaN;
  let npv = 0.0;
  for (const cf of flows) {
    if (cf.tau === 0) {
      npv += cf.amount;
    } else {
      const denom = Math.pow(1.0 + r, cf.tau);
      if (!Number.isFinite(denom) || denom === 0) return Number.NaN;
      npv += cf.amount / denom;
    }
  }
  return npv;
}

/**
 * First derivative dNPV/dr
 * dNPV/dr = - Σ [ tau_i * CF_i / (1 + r)^(tau_i + 1) ]
 */
export function computeDerivative(flows: InternalCashFlow[], r: number): number {
  if (r <= -1.0) return Number.NaN;
  let dNpv = 0.0;
  for (const cf of flows) {
    if (cf.tau !== 0) {
      const denom = Math.pow(1.0 + r, cf.tau + 1.0);
      if (!Number.isFinite(denom) || denom === 0) return Number.NaN;
      dNpv -= (cf.tau * cf.amount) / denom;
    }
  }
  return dNpv;
}

/**
 * Counts sign changes in cash flow sequence
 * Based on Descartes' Rule of Signs to test for root uniqueness
 */
export function countSignChanges(flows: { amount: number }[]): number {
  let changes = 0;
  let lastNonZeroSign = 0;

  for (const cf of flows) {
    if (Math.abs(cf.amount) > 1e-9) {
      const currentSign = cf.amount > 0 ? 1 : -1;
      if (lastNonZeroSign !== 0 && currentSign !== lastNonZeroSign) {
        changes++;
      }
      lastNonZeroSign = currentSign;
    }
  }
  return changes;
}

/**
 * Solves for XIRR using Brent's method within a bracket [a, b]
 */
function brentRoot(
  flows: InternalCashFlow[],
  a: number,
  b: number,
  tol = 1e-9,
  maxIter = 100
): { root: number; iterations: number; residual: number } | null {
  let fa = computeNPV(flows, a);
  let fb = computeNPV(flows, b);

  if (!Number.isFinite(fa) || !Number.isFinite(fb)) return null;
  if (Math.abs(fa) < tol) return { root: a, iterations: 0, residual: Math.abs(fa) };
  if (Math.abs(fb) < tol) return { root: b, iterations: 0, residual: Math.abs(fb) };
  if (fa * fb > 0) return null; // Not bracketed

  if (Math.abs(fa) < Math.abs(fb)) {
    // Swap so b is best estimate
    [a, b] = [b, a];
    [fa, fb] = [fb, fa];
  }

  let c = a;
  let fc = fa;
  let mflag = true;
  let d = 0;
  let iterations = 0;

  while (iterations < maxIter) {
    iterations++;

    let s = 0;
    if (Math.abs(fa - fc) > 1e-14 && Math.abs(fb - fc) > 1e-14) {
      // Inverse quadratic interpolation
      s =
        (a * fb * fc) / ((fa - fb) * (fa - fc)) +
        (b * fa * fc) / ((fb - fa) * (fb - fc)) +
        (c * fa * fb) / ((fc - fa) * (fc - fb));
    } else {
      // Secant method
      s = b - fb * ((b - a) / (fb - fa));
    }

    // Conditions to fall back to bisection
    const condition1 =
      (s < (3 * a + b) / 4 && s < b) || (s > (3 * a + b) / 4 && s > b);
    const condition2 = mflag && Math.abs(s - b) >= Math.abs(b - c) / 2;
    const condition3 = !mflag && Math.abs(s - b) >= Math.abs(c - d) / 2;
    const condition4 = mflag && Math.abs(b - c) < tol;
    const condition5 = !mflag && Math.abs(c - d) < tol;

    if (condition1 || condition2 || condition3 || condition4 || condition5) {
      s = (a + b) / 2;
      mflag = true;
    } else {
      mflag = false;
    }

    const fs = computeNPV(flows, s);
    if (!Number.isFinite(fs)) {
      s = (a + b) / 2;
      mflag = true;
    }

    d = c;
    c = b;
    fc = fb;

    if (fa * fs < 0) {
      b = s;
      fb = fs;
    } else {
      a = s;
      fa = fs;
    }

    if (Math.abs(fa) < Math.abs(fb)) {
      [a, b] = [b, a];
      [fa, fb] = [fb, fa];
    }

    if (Math.abs(fb) < tol || Math.abs(b - a) < tol) {
      return {
        root: b,
        iterations,
        residual: Math.abs(computeNPV(flows, b)),
      };
    }
  }

  return { root: b, iterations, residual: Math.abs(computeNPV(flows, b)) };
}

/**
 * Comprehensive XIRR Engine
 * Evaluates cash-flow intervals to detect unique and multiple roots,
 * certifies numerical residuals, and handles zero/all-positive/all-negative edge cases.
 */
export function solveSyntheticXIRR(
  flows: InternalCashFlow[],
  searchInterval: [number, number] = [-0.99, 10.0]
): SolverDiagnostics {
  const signChanges = countSignChanges(flows);
  const totalFlows = flows.filter((f) => Math.abs(f.amount) > 1e-9);

  // Check 1: Need at least one negative and one positive cash flow
  const hasNegative = totalFlows.some((f) => f.amount < 0);
  const hasPositive = totalFlows.some((f) => f.amount > 0);

  if (!hasNegative || !hasPositive || totalFlows.length < 2) {
    return {
      status: 'NO_ROOT',
      solverMethod: 'N/A',
      root: Number.NaN,
      allRoots: [],
      iterations: 0,
      residualNpv: Number.NaN,
      searchInterval,
      hasSignChanges: false,
      signChangeCount: 0,
      uniqueRootGuaranteed: false,
      warning:
        !hasNegative
          ? 'No initial investment / cash outflow detected. IRR is mathematically undefined.'
          : 'No positive cash distributions / exit proceeds. IRR is mathematically undefined.',
    };
  }

  // Scan interval across grid to find brackets
  const gridSteps = 120;
  const [minR, maxR] = searchInterval;
  const step = (maxR - minR) / gridSteps;
  const brackets: [number, number][] = [];

  let prevR = minR;
  let prevNpv = computeNPV(flows, prevR);

  for (let i = 1; i <= gridSteps; i++) {
    const currR = minR + i * step;
    const currNpv = computeNPV(flows, currR);

    if (Number.isFinite(prevNpv) && Number.isFinite(currNpv)) {
      if (prevNpv * currNpv <= 0) {
        brackets.push([prevR, currR]);
      }
    }
    prevR = currR;
    prevNpv = currNpv;
  }

  const foundRoots: { root: number; iterations: number; residual: number }[] = [];

  for (const [bracketA, bracketB] of brackets) {
    const res = brentRoot(flows, bracketA, bracketB, 1e-9, 100);
    if (res && res.residual < 1e-4) {
      // Avoid duplicate close roots
      const alreadyExists = foundRoots.some((r) => Math.abs(r.root - res.root) < 1e-4);
      if (!alreadyExists) {
        foundRoots.push(res);
      }
    }
  }

  // If no root found from bracket scan, try safeguarded Newton from 10%
  if (foundRoots.length === 0) {
    let r = 0.1; // Initial guess 10%
    let iter = 0;
    let converged = false;

    while (iter < 80) {
      iter++;
      const npv = computeNPV(flows, r);
      const dNpv = computeDerivative(flows, r);

      if (!Number.isFinite(npv) || !Number.isFinite(dNpv) || Math.abs(dNpv) < 1e-12) {
        break;
      }

      const stepR = npv / dNpv;
      let nextR = r - stepR;

      // Safeguard domain
      if (nextR <= -0.999) nextR = (r - 0.999) / 2;
      if (nextR > 20.0) nextR = (r + 20.0) / 2;

      if (Math.abs(nextR - r) < 1e-9 || Math.abs(npv) < 1e-9) {
        r = nextR;
        converged = true;
        break;
      }
      r = nextR;
    }

    const residual = Math.abs(computeNPV(flows, r));
    if (converged && residual < 1e-4 && r > -0.999 && r < 20.0) {
      foundRoots.push({ root: r, iterations: iter, residual });
    }
  }

  if (foundRoots.length === 0) {
    return {
      status: 'NO_ROOT',
      solverMethod: 'BRENT_SCAN_AND_NEWTON',
      root: Number.NaN,
      allRoots: [],
      iterations: gridSteps,
      residualNpv: Number.NaN,
      searchInterval,
      hasSignChanges: signChanges > 0,
      signChangeCount: signChanges,
      uniqueRootGuaranteed: false,
      warning:
        'No real rate of return reconciles the dated cash-flow sequence within the search bounds [-99%, +1000%].',
    };
  }

  // Pick the most economically conventional root (closest to reasonable economic range 0% - 25%)
  foundRoots.sort((a, b) => {
    const distA = Math.abs(a.root - 0.1);
    const distB = Math.abs(b.root - 0.1);
    return distA - distB;
  });

  const best = foundRoots[0];
  const allRootsArr = foundRoots.map((r) => r.root);

  return {
    status: foundRoots.length > 1 ? 'MULTIPLE_ROOTS' : 'CONVERGED',
    solverMethod: 'BRENT_SAFELOCK_WITH_NEWTON_CHECK',
    root: best.root,
    allRoots: allRootsArr,
    iterations: best.iterations,
    residualNpv: best.residual,
    searchInterval,
    hasSignChanges: signChanges > 0,
    signChangeCount: signChanges,
    uniqueRootGuaranteed: signChanges === 1,
    warning:
      foundRoots.length > 1
        ? `Warning: Cash flows have ${signChanges} sign changes. Multiple mathematical roots exist (${allRootsArr.map((r) => (r * 100).toFixed(2) + '%').join(', ')}). The highlighted root is the standard institutional financial solution.`
        : signChanges > 1
        ? `Cash flows exhibit ${signChanges} sign alterations, but a unique single root was verified in the active search domain.`
        : undefined,
  };
}
