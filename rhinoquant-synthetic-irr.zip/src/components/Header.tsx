/**
 * RhinoQuant Header Component
 * Strict Top Bar Contract: 1 row, 3 zones separated by gap-8:
 * Zone 1: Single text wordmark in display face
 * Zone 2: Single-line text navigation links
 * Zone 3: Primary action button
 */

import React from 'react';
import { ShieldCheck, Play, Download, RefreshCw } from 'lucide-react';

export type ActiveTab = 
  | 'overview'
  | 'builder'
  | 'ratelab'
  | 'curves'
  | 'carry'
  | 'credit'
  | 'risk'
  | 'reports'
  | 'tests';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onRecalculate: () => void;
  onOpenAudit: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onRecalculate,
  onOpenAudit,
}) => {
  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'builder', label: 'Synthetic Builder' },
    { id: 'ratelab', label: 'Rate Laboratory' },
    { id: 'curves', label: 'Curve Engine' },
    { id: 'carry', label: 'Carry Strategies' },
    { id: 'credit', label: 'Structured Credit' },
    { id: 'risk', label: 'Scenario & Risk' },
    { id: 'reports', label: 'Reports & Audit' },
    { id: 'tests', label: 'Verification (18 Tests)' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#080c14]/95 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5 flex items-center justify-between gap-8">
      {/* Zone 1: Brand Wordmark (Single text element in display face) */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center shadow-sm border border-amber-400/30">
          <span className="font-extrabold text-slate-950 text-sm tracking-tighter">RQ</span>
        </div>
        <a
          href="#overview"
          onClick={(e) => {
            e.preventDefault();
            onSelectTab('overview');
          }}
          className="text-base font-bold tracking-tight text-white hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span>RhinoQuant</span>
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-500 border-l border-slate-700 pl-2">
            Synthetic IRR
          </span>
        </a>
      </div>

      {/* Zone 2: Navigation Links (Single-line text navigation with clean active states) */}
      <nav className="hidden xl:flex items-center gap-6 text-xs font-medium text-slate-300">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`whitespace-nowrap shrink-0 transition-colors relative py-1 ${
                isActive
                  ? 'text-amber-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Primary Action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onRecalculate}
          title="Recalculate dated cash flows and roots"
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 hover:border-slate-600 hover:bg-slate-800 rounded transition-colors whitespace-nowrap"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
          <span>Recalculate</span>
        </button>
        <button
          onClick={onOpenAudit}
          className="flex items-center gap-2 px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 border border-amber-300 rounded transition-colors whitespace-nowrap shadow-sm shadow-amber-950/20"
        >
          <ShieldCheck className="w-4 h-4 text-slate-950" />
          <span>Committee Report</span>
        </button>
      </div>
    </header>
  );
};
