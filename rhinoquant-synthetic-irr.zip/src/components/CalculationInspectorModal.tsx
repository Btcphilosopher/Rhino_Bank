/**
 * RhinoQuant Calculation Inspector Modal
 * Deep-dive inspector displaying exact mathematical equations, solver iterations,
 * residual tolerances, sign changes, and search intervals.
 */

import React from 'react';
import { SyntheticReturnSummary } from '../types';
import { X, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

interface CalculationInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: SyntheticReturnSummary;
}

export const CalculationInspectorModal: React.FC<CalculationInspectorModalProps> = ({
  isOpen,
  onClose,
  summary,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-[#0b101b] border border-slate-700 w-full max-w-2xl rounded-lg shadow-2xl p-6 space-y-4 text-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              RhinoQuant Mathematical Calculation Inspector
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 text-xs font-mono">
          <div className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-1.5">
            <span className="text-[10px] text-slate-500 uppercase block">Discounted Cash Flow Equation</span>
            <div className="text-amber-300 font-semibold text-sm">
              NPV(r) = Σ [ CF_i / (1 + r)^τ_i ] = 0
            </div>
            <p className="text-[11px] text-slate-400 font-sans mt-1">
              Solves for effective annual discount rate <span className="text-white font-mono">r</span> such that the sum of discounted cash flows equals zero.
            </p>
          </div>

          <div className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-1.5">
            <span className="text-[10px] text-slate-500 uppercase block">Analytical Derivative Equation</span>
            <div className="text-cyan-300 font-semibold text-sm">
              dNPV/dr = - Σ [ τ_i · CF_i / (1 + r)^(τ_i + 1) ]
            </div>
            <p className="text-[11px] text-slate-400 font-sans mt-1">
              Used in safeguarded Newton-Raphson iterations to achieve quadratic convergence near roots.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-[#101726] border border-slate-800 rounded space-y-1">
              <span className="text-[10px] text-slate-500 uppercase block">Solver Algorithm</span>
              <div className="text-white font-bold">{summary.diagnostics.solverMethod}</div>
              <div className="text-slate-500 text-[10px]">Brent-Dekker with Newton verification</div>
            </div>

            <div className="p-3 bg-[#101726] border border-slate-800 rounded space-y-1">
              <span className="text-[10px] text-slate-500 uppercase block">Convergence Status</span>
              <div
                className={`font-bold ${
                  summary.diagnostics.status === 'CONVERGED' ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {summary.diagnostics.status}
              </div>
              <div className="text-slate-500 text-[10px]">
                {summary.diagnostics.iterations} iterations to reach tolerance
              </div>
            </div>

            <div className="p-3 bg-[#101726] border border-slate-800 rounded space-y-1">
              <span className="text-[10px] text-slate-500 uppercase block">Certified Residual |NPV|</span>
              <div className="text-emerald-400 font-bold text-sm">
                {summary.diagnostics.residualNpv.toExponential(4)}
              </div>
              <div className="text-slate-500 text-[10px]">Tolerance bound: &lt; 1e-4</div>
            </div>

            <div className="p-3 bg-[#101726] border border-slate-800 rounded space-y-1">
              <span className="text-[10px] text-slate-500 uppercase block">Descartes Sign Changes</span>
              <div className="text-white font-bold text-sm">
                {summary.diagnostics.signChangeCount} sign alterations
              </div>
              <div className="text-cyan-300 text-[10px]">
                {summary.diagnostics.uniqueRootGuaranteed ? 'Unique root guaranteed' : 'Multi-interval scanned'}
              </div>
            </div>
          </div>

          {summary.diagnostics.warning && (
            <div className="p-2.5 bg-amber-950/20 border border-amber-500/30 rounded text-amber-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>{summary.diagnostics.warning}</span>
            </div>
          )}

          <div className="pt-2 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors cursor-pointer"
            >
              Close Inspector
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
