/**
 * RhinoQuant Carry Strategies & Cross-Market Yield Engineering
 * Models FX carry trades, interest differentials, Covered Interest Parity (CIP),
 * forward hedge points, leverage drag, and tail-risk currency shocks.
 */

import React, { useState } from 'react';
import { FXCarryTradeConfig } from '../../types';
import { analyzeFXCarryTrade } from '../../math/carryEngine';
import { Sliders, AlertTriangle, ShieldCheck, TrendingDown, DollarSign, Info } from 'lucide-react';

export const CarryStrategiesView: React.FC = () => {
  const [config, setConfig] = useState<FXCarryTradeConfig>({
    fundingCurrency: 'JPY',
    fundingRate: 0.0025, // 0.25% JPY rate
    investmentCurrency: 'USD',
    investmentRate: 0.0460, // 4.60% USD rate
    spotFx: 152.50, // USD/JPY
    forwardTenorMonths: 12,
    crossCurrencyBasisBps: -25, // -25 bps basis
    leverage: 3.0, // 3x leverage
    haircutPct: 10, // 10% initial margin haircut
    hedgedRatio: 0.5, // 50% hedged
    transactionCostBps: 15,
    holdingPeriodMonths: 12,
  });

  const analysis = analyzeFXCarryTrade(config, 10000000); // 10M USD notional

  return (
    <div className="space-y-6">
      
      {/* Workspace Header */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Synthetic FX Carry Trade & Cross-Market Yield Workspace
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model interest differentials, CIP forward pricing, rollover drag, leverage, and tail currency shocks.
          </p>
        </div>

        {/* Warning pill */}
        <div className="p-2 bg-amber-950/20 border border-amber-500/30 rounded text-xs text-amber-300 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Economic Rule: Unhedged currency carry is NOT guaranteed synthetic yield.</span>
        </div>
      </div>

      {/* Main Parameters Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Trade Configuration Matrix */}
        <div className="lg:col-span-5 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Carry Trade Parameters
            </h3>
            <p className="text-[11px] text-slate-400">
              Configure currencies, benchmark interest rates, leverage, and forward hedge ratio
            </p>
          </div>

          <div className="space-y-3 text-xs">
            {/* Currencies & Rates */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded space-y-1">
                <span className="text-[10px] text-slate-400 font-mono block">
                  Funding Currency (Borrow)
                </span>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white font-mono">{config.fundingCurrency}</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      step="0.05"
                      value={(config.fundingRate * 100).toFixed(2)}
                      onChange={(e) =>
                        setConfig({ ...config, fundingRate: (parseFloat(e.target.value) || 0) / 100 })
                      }
                      className="w-14 bg-[#101726] border border-slate-700 px-1 py-0.5 text-right font-mono text-amber-400 rounded text-xs font-bold"
                    />
                    <span className="text-slate-400">%</span>
                  </div>
                </div>
              </div>

              <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded space-y-1">
                <span className="text-[10px] text-slate-400 font-mono block">
                  Investment Currency (Deploy)
                </span>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white font-mono">{config.investmentCurrency}</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      step="0.05"
                      value={(config.investmentRate * 100).toFixed(2)}
                      onChange={(e) =>
                        setConfig({ ...config, investmentRate: (parseFloat(e.target.value) || 0) / 100 })
                      }
                      className="w-14 bg-[#101726] border border-slate-700 px-1 py-0.5 text-right font-mono text-emerald-400 rounded text-xs font-bold"
                    />
                    <span className="text-slate-400">%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Spot FX */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Spot FX Exchange Rate ({config.investmentCurrency}/{config.fundingCurrency}):</span>
                <span className="font-mono text-white font-bold">{config.spotFx.toFixed(2)}</span>
              </div>
              <input
                type="number"
                step="0.5"
                value={config.spotFx}
                onChange={(e) => setConfig({ ...config, spotFx: parseFloat(e.target.value) || 150 })}
                className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded font-mono text-white text-xs"
              />
            </div>

            {/* Leverage Slider */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Leverage Multiplier:</span>
                <span className="font-mono text-amber-400 font-bold text-sm">
                  {config.leverage.toFixed(1)}x
                </span>
              </div>
              <input
                type="range"
                min="1.0"
                max="8.0"
                step="0.5"
                value={config.leverage}
                onChange={(e) => setConfig({ ...config, leverage: parseFloat(e.target.value) })}
                className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>1.0x (Cash / Unlevered)</span>
                <span>8.0x (High Risk)</span>
              </div>
            </div>

            {/* Hedged Ratio Slider */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Forward Hedge Ratio (% Covered):</span>
                <span className="font-mono text-cyan-400 font-bold text-sm">
                  {(config.hedgedRatio * 100).toFixed(0)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="1.0"
                step="0.1"
                value={config.hedgedRatio}
                onChange={(e) => setConfig({ ...config, hedgedRatio: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>0% (Full Currency Exposure)</span>
                <span>100% (CIP Hedged)</span>
              </div>
            </div>

            {/* Capital Allocation Breakdown */}
            <div className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Position Notional:</span>
                <span className="text-white font-bold">$10.00M</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Equity Capital Required:</span>
                <span className="text-amber-400 font-bold">
                  ${(analysis.equityRequired / 1e6).toFixed(2)}M
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Borrowed Liabilities:</span>
                <span className="text-slate-300">
                  ${(analysis.borrowedAmount / 1e6).toFixed(2)}M
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-800">
                <span className="text-slate-400">Margin Call Threshold:</span>
                <span className="text-rose-400 font-bold">
                  {analysis.marginCallThresholdFxPct.toFixed(1)}% spot shock
                </span>
              </div>
            </div>

          </div>
        </div>

        {/* Right Column: Analytical Return Decomposition */}
        <div className="lg:col-span-7 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Synthetic Return & CIP Decomposition
            </h3>
            <p className="text-[11px] text-slate-400">
              Breakdown of interest differential, forward discount drag, and levered return
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">Interest Diff</span>
              <span className="text-emerald-400 font-bold text-base mt-1 block">
                +{analysis.grossInterestDifferentialPct.toFixed(2)}%
              </span>
              <span className="text-[9px] text-slate-500">USD - JPY yield</span>
            </div>

            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">CIP Forward Points</span>
              <span className="text-cyan-300 font-bold text-base mt-1 block">
                {analysis.forwardPoints > 0 ? `+${analysis.forwardPoints.toFixed(2)}` : analysis.forwardPoints.toFixed(2)}
              </span>
              <span className="text-[9px] text-slate-500">F: {analysis.forwardFx.toFixed(2)}</span>
            </div>

            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">Hedge Cost Drag</span>
              <span className="text-rose-400 font-bold text-base mt-1 block">
                -{analysis.totalHedgeDragPct.toFixed(2)}%
              </span>
              <span className="text-[9px] text-slate-500">Forward discount</span>
            </div>

            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">Levered Net IRR</span>
              <span className="text-amber-400 font-bold text-base mt-1 block">
                {(analysis.syntheticXirrAnnual * 100).toFixed(2)}%
              </span>
              <span className="text-[9px] text-slate-500">Effective annual</span>
            </div>
          </div>

          {/* Currency Downside Shock Stress Matrix */}
          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-semibold text-slate-300 uppercase font-mono tracking-wider">
              Exchange Rate Scenario Stress Matrix ({config.investmentCurrency}/{config.fundingCurrency} Moves)
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                    <th className="py-2 px-2">Spot Move</th>
                    <th className="py-2 px-2 text-right">Scenario Spot</th>
                    <th className="py-2 px-2 text-right">Unhedged P&L</th>
                    <th className="py-2 px-2 text-right">Hedged P&L</th>
                    <th className="py-2 px-2 text-right text-amber-400 font-bold">Net Return (%)</th>
                    <th className="py-2 px-2 text-center">Margin Breach?</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {analysis.stressScenarios.map((sc) => {
                    const formatPnl = (val: number) => {
                      const sign = val < 0 ? '-' : '+';
                      return `${sign}$${(Math.abs(val) / 1e3).toFixed(0)}k`;
                    };

                    return (
                      <tr
                        key={sc.fxChangePct}
                        className={`hover:bg-slate-900/40 transition-colors ${
                          sc.isMarginBreached ? 'bg-rose-950/20' : ''
                        }`}
                      >
                        <td className="py-1.5 px-2 font-bold text-white">
                          {sc.fxChangePct > 0 ? `+${sc.fxChangePct}%` : `${sc.fxChangePct}%`}
                        </td>
                        <td className="py-1.5 px-2 text-right text-slate-300">
                          {sc.scenarioSpot.toFixed(2)}
                        </td>
                        <td
                          className={`py-1.5 px-2 text-right ${
                            sc.unhedgedPnl < 0 ? 'text-rose-400' : 'text-emerald-400'
                          }`}
                        >
                          {formatPnl(sc.unhedgedPnl)}
                        </td>
                        <td
                          className={`py-1.5 px-2 text-right ${
                            sc.hedgedPnl < 0 ? 'text-rose-400' : 'text-emerald-400'
                          }`}
                        >
                          {formatPnl(sc.hedgedPnl)}
                        </td>
                        <td
                          className={`py-1.5 px-2 text-right font-bold ${
                            sc.scenarioNetReturnPct < 0 ? 'text-rose-400' : 'text-emerald-400'
                          }`}
                        >
                          {sc.scenarioNetReturnPct > 0 ? '+' : ''}
                          {sc.scenarioNetReturnPct.toFixed(1)}%
                        </td>
                        <td className="py-1.5 px-2 text-center">
                          {sc.isMarginBreached ? (
                            <span className="text-rose-400 font-bold text-[10px]">
                              MARGIN CALL
                            </span>
                          ) : (
                            <span className="text-emerald-400 text-[10px]">SOLVENT</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
