/**
 * RhinoQuant Scenario & Risk Simulation Workspace
 * Deterministic multi-factor stress shocks (Rate hikes, Repo crunches, Credit crises)
 * and Monte Carlo simulation with VaR, CVaR, and outcome distribution histogram.
 */

import React, { useState } from 'react';
import { StressScenario, MonteCarloResult, CashFlowRecord, SyntheticReturnSummary } from '../../types';
import { PRESET_STRESS_SCENARIOS, runMonteCarloIRR } from '../../math/scenarioRisk';
import { AlertTriangle, Play, RefreshCw, BarChart2, ShieldAlert, Sliders, Info } from 'lucide-react';

interface ScenarioRiskViewProps {
  baseLedger: CashFlowRecord[];
  summary: SyntheticReturnSummary;
}

export const ScenarioRiskView: React.FC<ScenarioRiskViewProps> = ({ baseLedger, summary }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('BASE');
  const [simulationCount, setSimulationCount] = useState<number>(1000);
  const [randomSeed, setRandomSeed] = useState<number>(12345);
  const [mcResult, setMcResult] = useState<MonteCarloResult>(() =>
    runMonteCarloIRR(baseLedger, summary.syntheticXirr || 0.14, 1000, 12345)
  );

  const selectedScenario =
    PRESET_STRESS_SCENARIOS.find((s) => s.id === selectedScenarioId) ||
    PRESET_STRESS_SCENARIOS[0];

  const handleRunSimulation = () => {
    const res = runMonteCarloIRR(
      baseLedger,
      summary.syntheticXirr || 0.14,
      simulationCount,
      randomSeed
    );
    setMcResult(res);
  };

  const maxBucketCount = Math.max(...mcResult.distributionBuckets.map((b) => b.count), 1);

  return (
    <div className="space-y-6">
      
      {/* Workspace Header */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Scenario Analysis & Monte Carlo Risk Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Evaluate portfolio durability under multi-parameter macroeconomic shocks, repo market freezes, and stochastic return distributions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunSimulation}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>Run Monte Carlo ({simulationCount} Paths)</span>
          </button>
        </div>
      </div>

      {/* 1. Deterministic Multi-Parameter Scenarios */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Deterministic Stress Scenarios
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Select a macroeconomic or funding shock regime
          </span>
        </div>

        {/* Preset Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {PRESET_STRESS_SCENARIOS.map((sc) => {
            const isSelected = sc.id === selectedScenarioId;
            return (
              <button
                key={sc.id}
                onClick={() => setSelectedScenarioId(sc.id)}
                className={`p-3 text-left rounded border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#151f33] border-amber-400 shadow-sm shadow-amber-950/20'
                    : 'bg-[#101726]/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="text-xs font-bold text-white tracking-tight">
                    {sc.name}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-snug">
                    {sc.description}
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono">
                  <span className={sc.rateShiftBps >= 0 ? 'text-rose-400' : 'text-emerald-400'}>
                    Rate: {sc.rateShiftBps > 0 ? `+${sc.rateShiftBps}` : sc.rateShiftBps} bps
                  </span>
                  <span className={isSelected ? 'text-amber-400 font-bold' : 'text-slate-500'}>
                    {isSelected ? 'ACTIVE' : 'SELECT'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Scenario Parameters Matrix */}
        <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-2">
            Shock Parameter Matrix: {selectedScenario.name}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
            <div className="p-2 bg-[#101726] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Curve Shift</span>
              <span className="font-bold text-white">
                {selectedScenario.rateShiftBps > 0 ? `+${selectedScenario.rateShiftBps}` : selectedScenario.rateShiftBps} bps
              </span>
            </div>
            <div className="p-2 bg-[#101726] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Credit Spread</span>
              <span className="font-bold text-white">
                +{selectedScenario.creditSpreadShiftBps} bps
              </span>
            </div>
            <div className="p-2 bg-[#101726] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Repo Haircut</span>
              <span className="font-bold text-amber-400">
                +{selectedScenario.repoHaircutShiftPct}%
              </span>
            </div>
            <div className="p-2 bg-[#101726] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">FX Spot Shock</span>
              <span className="font-bold text-rose-400">
                {selectedScenario.fxShockPct}%
              </span>
            </div>
            <div className="p-2 bg-[#101726] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Default Multiplier</span>
              <span className="font-bold text-white">
                {selectedScenario.defaultRateMultiplier}x
              </span>
            </div>
            <div className="p-2 bg-[#101726] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Exit Haircut</span>
              <span className="font-bold text-white">
                {selectedScenario.exitMultipleShiftPct}%
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Monte Carlo Simulation Engine */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-2">
          <div>
            <div className="flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Monte Carlo Return Distribution ({mcResult.simulationCount} Trajectories)
              </h3>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Empirical return distribution under correlated rate, credit spread, and valuation shocks
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">Simulations:</span>
              <select
                value={simulationCount}
                onChange={(e) => setSimulationCount(parseInt(e.target.value))}
                className="bg-[#080c14] border border-slate-700 px-2 py-1 rounded text-white font-mono text-xs"
              >
                <option value="500">500 paths</option>
                <option value="1000">1,000 paths</option>
                <option value="2500">2,500 paths</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">PRNG Seed:</span>
              <input
                type="number"
                value={randomSeed}
                onChange={(e) => setRandomSeed(parseInt(e.target.value) || 1)}
                className="w-18 bg-[#080c14] border border-slate-700 px-2 py-1 text-right font-mono text-white rounded text-xs"
              />
            </div>
          </div>
        </div>

        {/* Quant Risk Metrics KPI Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase block">Expected Mean IRR</span>
            <span className="text-white font-bold text-base mt-1 block">
              {(mcResult.meanIrr * 100).toFixed(2)}%
            </span>
            <span className="text-[9px] text-slate-500">Median: {(mcResult.medianIrr * 100).toFixed(2)}%</span>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase block">Vol / Std Dev (σ)</span>
            <span className="text-slate-300 font-bold text-base mt-1 block">
              {(mcResult.stdDevIrr * 100).toFixed(2)}%
            </span>
            <span className="text-[9px] text-slate-500">Annualized dispersion</span>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase block">5th Percentile (P5)</span>
            <span className="text-rose-400 font-bold text-base mt-1 block">
              {(mcResult.p5Irr * 100).toFixed(2)}%
            </span>
            <span className="text-[9px] text-slate-500">Tail risk threshold</span>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase block">Value at Risk (VaR 95)</span>
            <span className="text-amber-400 font-bold text-base mt-1 block">
              {(mcResult.var95 * 100).toFixed(2)}%
            </span>
            <span className="text-[9px] text-slate-500">Mean - 5th percentile</span>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase block">CVaR / Exp. Shortfall</span>
            <span className="text-rose-500 font-bold text-base mt-1 block">
              {(mcResult.cvar95 * 100).toFixed(2)}%
            </span>
            <span className="text-[9px] text-slate-500">Tail conditional loss</span>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase block">P(Capital Loss)</span>
            <span className="text-cyan-400 font-bold text-base mt-1 block">
              {mcResult.probCapitalLoss.toFixed(1)}%
            </span>
            <span className="text-[9px] text-slate-500">P(MOIC &lt; 1.0x)</span>
          </div>
        </div>

        {/* Histogram Visualization */}
        <div className="p-4 bg-[#080c14] border border-slate-800 rounded space-y-2">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span>Simulated Outcome Frequency Histogram</span>
            <span>Total Trajectories: {mcResult.simulationCount}</span>
          </div>

          <div className="h-44 flex items-end gap-1.5 pt-4 border-b border-slate-800">
            {mcResult.distributionBuckets.map((bucket, idx) => {
              const heightPct = (bucket.count / maxBucketCount) * 100;
              const isTail = bucket.maxVal < mcResult.p5Irr;
              const isMedian =
                bucket.minVal <= mcResult.medianIrr && bucket.maxVal >= mcResult.medianIrr;

              return (
                <div
                  key={idx}
                  className="flex-1 flex flex-col items-center h-full justify-end group relative"
                >
                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 bg-slate-900 border border-slate-700 text-white text-[10px] font-mono px-2 py-0.5 rounded whitespace-nowrap z-20 pointer-events-none">
                    {bucket.rangeLabel}: {bucket.count} paths ({((bucket.count / mcResult.simulationCount) * 100).toFixed(1)}%)
                  </div>

                  <div
                    style={{ height: `${Math.max(4, heightPct)}%` }}
                    className={`w-full rounded-t transition-all ${
                      isTail
                        ? 'bg-rose-500/70 group-hover:bg-rose-400'
                        : isMedian
                        ? 'bg-amber-400 group-hover:bg-amber-300'
                        : 'bg-slate-700 group-hover:bg-cyan-500'
                    }`}
                  />
                </div>
              );
            })}
          </div>

          <div className="flex justify-between text-[10px] font-mono text-slate-500 pt-1">
            <span>Left Tail (Downside Risk)</span>
            <span className="text-amber-400 font-bold">Median: {(mcResult.medianIrr * 100).toFixed(1)}%</span>
            <span>Right Tail (Upside Outperformance)</span>
          </div>
        </div>

        {/* Statistical vs Physical Disclosure */}
        <div className="p-3 bg-slate-900/40 border border-slate-800 rounded text-xs text-slate-400 flex items-start gap-2">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed text-[11px]">
            <strong className="text-slate-300">Methodological Governance:</strong> Distinguishes physical-probability forecasts from risk-neutral implied quantities. The distributions above represent empirical simulated sample paths derived from parameterized Gaussian-drift volatility shocks and must not be interpreted as arbitrage-free risk-neutral expectations.
          </p>
        </div>
      </section>

    </div>
  );
};
