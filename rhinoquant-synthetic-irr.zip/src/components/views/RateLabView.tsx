/**
 * RhinoQuant Rate Sources Laboratory
 * Compares multi-market rates (Overnight, Term, Repo, Unsecured vs Secured)
 * and constructs synthetic multi-source funding benchmarks with weighting sensitivity.
 */

import React, { useState } from 'react';
import {
  Percent,
  Layers,
  ArrowRight,
  Shield,
  HelpCircle,
  TrendingUp,
  Sliders,
  Info,
} from 'lucide-react';

export interface MarketRateSource {
  id: string;
  name: string;
  category: 'OVERNIGHT' | 'TERM' | 'REPO_SECURED' | 'UNSECURED_CREDIT';
  currency: string;
  tenor: string;
  currentRate: number; // e.g. 0.0485 for 4.85%
  convention: string;
  administrator: string;
  publicationLag: string;
  underlyingVolume: string;
  economicNature: string;
}

export const OBSERVABLE_MARKET_RATES: MarketRateSource[] = [
  {
    id: 'USD_SOFR_ON',
    name: 'Secured Overnight Financing Rate (SOFR)',
    category: 'OVERNIGHT',
    currency: 'USD',
    tenor: 'Overnight (T+0)',
    currentRate: 0.0485,
    convention: 'ACT/360',
    administrator: 'Federal Reserve Bank of New York',
    publicationLag: 'T+1 at 08:00 EST',
    underlyingVolume: '$1.92 Trillion / day',
    economicNature: 'Broad measure of the cost of borrowing cash overnight collateralized by Treasury securities.',
  },
  {
    id: 'EUR_ESTR_ON',
    name: 'Euro Short-Term Rate (€STR)',
    category: 'OVERNIGHT',
    currency: 'EUR',
    tenor: 'Overnight (T+0)',
    currentRate: 0.0315,
    convention: 'ACT/360',
    administrator: 'European Central Bank (ECB)',
    publicationLag: 'T+1 at 08:00 CET',
    underlyingVolume: '€78 Billion / day',
    economicNature: 'Unsecured overnight borrowing costs of banks in the euro area.',
  },
  {
    id: 'GBP_SONIA_ON',
    name: 'Sterling Overnight Index Average (SONIA)',
    category: 'OVERNIGHT',
    currency: 'GBP',
    tenor: 'Overnight (T+0)',
    currentRate: 0.0470,
    convention: 'ACT/365',
    administrator: 'Bank of England',
    publicationLag: 'T+1 at 09:00 GMT',
    underlyingVolume: '£65 Billion / day',
    economicNature: 'Unsecured overnight sterling rate for transactions greater than £25M.',
  },
  {
    id: 'USD_TERM_SOFR_3M',
    name: 'CME 3-Month Term SOFR',
    category: 'TERM',
    currency: 'USD',
    tenor: '3 Months (90 Days)',
    currentRate: 0.0475,
    convention: 'ACT/360',
    administrator: 'CME Benchmark Administration Limited (CBA)',
    publicationLag: 'Real-time forward index',
    underlyingVolume: 'Derived from SOFR futures',
    economicNature: 'Forward-looking term benchmark implied by CME SOFR futures market expectations.',
  },
  {
    id: 'USD_REPO_TRIPARTY',
    name: 'Tri-Party General Collateral Repo (TGCR)',
    category: 'REPO_SECURED',
    currency: 'USD',
    tenor: 'Overnight (T+0)',
    currentRate: 0.0482,
    convention: 'ACT/360',
    administrator: 'Federal Reserve Bank of New York',
    publicationLag: 'T+1 at 08:00 EST',
    underlyingVolume: '$1.10 Trillion / day',
    economicNature: 'Secured tri-party financing backed by US Treasuries with strict haircut requirements.',
  },
  {
    id: 'USD_COMMERCIAL_PAPER_A1',
    name: 'Financial Commercial Paper (30D A1/P1)',
    category: 'UNSECURED_CREDIT',
    currency: 'USD',
    tenor: '30 Days',
    currentRate: 0.0512,
    convention: 'ACT/360',
    administrator: 'Federal Reserve Board H.15 Release',
    publicationLag: 'T+0 End of Day',
    underlyingVolume: '$38 Billion / day',
    economicNature: 'Short-term unsecured promissory note issued by top-tier institutional financial institutions.',
  },
];

export const RateLabView: React.FC = () => {
  // Synthetic Composite Benchmark Config
  const [weights, setWeights] = useState<Record<string, number>>({
    USD_SOFR_ON: 40,
    USD_TERM_SOFR_3M: 25,
    USD_REPO_TRIPARTY: 20,
    USD_COMMERCIAL_PAPER_A1: 15,
  });

  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);

  // Compute composite rate
  const compositeRate =
    totalWeight > 0
      ? Object.entries(weights).reduce((acc, [id, w]) => {
          const src = OBSERVABLE_MARKET_RATES.find((r) => r.id === id);
          return acc + (src ? src.currentRate * (w / totalWeight) : 0);
        }, 0)
      : 0;

  // Unsecured vs Secured spread
  const sofrRate = OBSERVABLE_MARKET_RATES.find((r) => r.id === 'USD_SOFR_ON')?.currentRate || 0.0485;
  const cpRate = OBSERVABLE_MARKET_RATES.find((r) => r.id === 'USD_COMMERCIAL_PAPER_A1')?.currentRate || 0.0512;
  const creditSpreadBps = Math.round((cpRate - sofrRate) * 10000);

  return (
    <div className="space-y-6">
      
      {/* Section Header */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4">
        <h2 className="text-base font-bold text-white tracking-tight">
          Synthetic Rate Sources Laboratory
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Evaluate observable benchmark curves, unsecured versus secured funding spreads, and engineer multi-source funding composites.
        </p>
      </div>

      {/* Grid of Rate Categories */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Card 1: Overnight Secured Benchmarks */}
        <div className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-mono uppercase font-semibold text-slate-200">
              Overnight Benchmark Curves
            </span>
            <span className="text-[10px] text-amber-400 font-mono">T+0 DAILY</span>
          </div>
          <div className="space-y-2">
            {OBSERVABLE_MARKET_RATES.filter((r) => r.category === 'OVERNIGHT').map((r) => (
              <div key={r.id} className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">{r.name}</span>
                  <span className="font-mono font-bold text-amber-400">
                    {(r.currentRate * 100).toFixed(2)}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>{r.convention} · {r.currency}</span>
                  <span>Vol: {r.underlyingVolume}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Card 2: Term Reference Rates */}
        <div className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-mono uppercase font-semibold text-slate-200">
              Term Reference Rates
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">FORWARD IMPLIED</span>
          </div>
          <div className="space-y-2">
            {OBSERVABLE_MARKET_RATES.filter((r) => r.category === 'TERM').map((r) => (
              <div key={r.id} className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">{r.name}</span>
                  <span className="font-mono font-bold text-cyan-300">
                    {(r.currentRate * 100).toFixed(2)}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>{r.convention} · {r.tenor}</span>
                  <span>{r.administrator}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Card 3: Secured vs Unsecured Spread */}
        <div className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-mono uppercase font-semibold text-slate-200">
              Secured vs Unsecured Spread
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">CREDIT & COLLATERAL</span>
          </div>
          <div className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Unsecured CP (A1/P1 30D):</span>
              <span className="font-mono text-white font-bold">{(cpRate * 100).toFixed(2)}%</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Secured SOFR Overnight:</span>
              <span className="font-mono text-white font-bold">{(sofrRate * 100).toFixed(2)}%</span>
            </div>
            <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-300 font-semibold">Net Credit Liquidity Spread:</span>
              <span className="font-mono text-amber-400 font-bold">+{creditSpreadBps} bps</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-tight pt-1">
              Reflects the premium required by market lenders to accept counterparty credit risk versus posting US Treasury collateral.
            </p>
          </div>
        </div>

      </div>

      {/* Synthetic Funding Benchmark Composite Builder (Example 5) */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <div>
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Multi-Source Synthetic Benchmark Constructor (Example 5 Blueprint)
              </h3>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Construct a synthetic reference funding benchmark from weighted rate sources with live sensitivity analysis.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[10px] uppercase font-mono text-slate-400 block">
                Synthetic Composite Benchmark
              </span>
              <span className="text-xl font-bold font-mono text-amber-400">
                {(compositeRate * 100).toFixed(3)}%
              </span>
            </div>
          </div>
        </div>

        {/* Weight Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(weights).map(([id, weightVal]) => {
            const src = OBSERVABLE_MARKET_RATES.find((r) => r.id === id);
            if (!src) return null;
            const pctShare = totalWeight > 0 ? (weightVal / totalWeight) * 100 : 0;

            return (
              <div key={id} className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-semibold text-white block">
                      {src.name}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      Rate: {(src.currentRate * 100).toFixed(2)}%
                    </span>
                  </div>
                  <span className="text-xs font-bold font-mono text-amber-400">
                    {pctShare.toFixed(1)}%
                  </span>
                </div>

                <input
                  type="range"
                  min="0"
                  max="100"
                  value={weightVal}
                  onChange={(e) =>
                    setWeights({
                      ...weights,
                      [id]: parseInt(e.target.value) || 0,
                    })
                  }
                  className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                />

                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>Weight: {weightVal} pts</span>
                  <span>Contrib: +{((src.currentRate * (pctShare / 100)) * 100).toFixed(2)}%</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Regulatory & Institutional Disclosure */}
        <div className="p-3 bg-slate-900/40 border border-slate-800 rounded text-xs text-slate-400 flex items-start gap-2">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="text-slate-300">Methodology & Replicability Disclosure:</strong> This composite rate is an explicitly defined statistical metric constructed from weighted market benchmarks. It must be distinguished from an economically replicable tradable strategy unless an exact portfolio of debt instruments, repo hedges, and rollover agreements is simultaneously traded.
          </p>
        </div>
      </section>

    </div>
  );
};
