/**
 * RhinoQuant Verification & Testing Suite View
 * Runs and certifies all 18 automated mathematical, analytical,
 * and consistency tests specified in Section 12 of the prompt.
 */

import React, { useState } from 'react';
import { runAllInstitutionalTests, TestCaseResult } from '../../math/testSuite';
import { ShieldCheck, Play, CheckCircle2, XCircle, Clock, RefreshCw, Filter } from 'lucide-react';

export const TestSuiteView: React.FC = () => {
  const [testResults, setTestResults] = useState<TestCaseResult[]>(() => runAllInstitutionalTests());
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const handleRunTests = () => {
    setIsRunning(true);
    setTimeout(() => {
      const results = runAllInstitutionalTests();
      setTestResults(results);
      setIsRunning(false);
    }, 150);
  };

  const totalTests = testResults.length;
  const passedTests = testResults.filter((t) => t.passed).length;
  const totalExecutionMs = testResults.reduce((acc, t) => acc + t.executionMs, 0);

  const categories = ['ALL', ...Array.from(new Set(testResults.map((t) => t.category)))];

  const filteredTests = testResults.filter((t) =>
    selectedCategory === 'ALL' ? true : t.category === selectedCategory
  );

  return (
    <div className="space-y-6">
      
      {/* Test Suite Header */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              Institutional Verification & Numerical Test Suite (Section 12)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            18 automated analytical benchmarks, root uniqueness checks, and DuPont leverage reconciliation tests.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunTests}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm shadow-emerald-950/20"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>{isRunning ? 'Executing Tests...' : 'Run All 18 Tests'}</span>
          </button>
        </div>
      </div>

      {/* Summary Scorecard */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-[#0b101b] border border-slate-800 rounded flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 font-mono uppercase block">Total Verified</span>
            <span className="text-xl font-bold font-mono text-white mt-0.5 block">
              {totalTests} Tests
            </span>
          </div>
          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
        </div>

        <div className="p-3 bg-[#0b101b] border border-slate-800 rounded flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 font-mono uppercase block">Status</span>
            <span
              className={`text-xl font-bold font-mono mt-0.5 block ${
                passedTests === totalTests ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {passedTests === totalTests ? '100% PASSED' : `${passedTests}/${totalTests} PASSED`}
            </span>
          </div>
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
        </div>

        <div className="p-3 bg-[#0b101b] border border-slate-800 rounded flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 font-mono uppercase block">Benchmark Standard</span>
            <span className="text-sm font-bold font-mono text-cyan-300 mt-0.5 block">
              1e-6 (0.01 bps)
            </span>
          </div>
          <Clock className="w-6 h-6 text-cyan-400" />
        </div>

        <div className="p-3 bg-[#0b101b] border border-slate-800 rounded flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 font-mono uppercase block">Total Exec Time</span>
            <span className="text-xl font-bold font-mono text-amber-400 mt-0.5 block">
              {totalExecutionMs.toFixed(2)} ms
            </span>
          </div>
          <RefreshCw className="w-6 h-6 text-amber-400" />
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <span className="text-xs text-slate-400 font-medium flex items-center gap-1 shrink-0">
          <Filter className="w-3.5 h-3.5" />
          Filter:
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-amber-400 text-slate-950 font-bold'
                : 'bg-[#0b101b] border border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Test Cases Table */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">#</th>
                <th className="py-2 px-3">Test Requirement (Section 12)</th>
                <th className="py-2 px-3">Category</th>
                <th className="py-2 px-3">Tolerance</th>
                <th className="py-2 px-3">Expected Result</th>
                <th className="py-2 px-3">Actual Result</th>
                <th className="py-2 px-2 text-right">Time</th>
                <th className="py-2 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTests.map((t) => (
                <tr key={t.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-2 px-3 text-slate-500 font-bold">{t.id}</td>
                  <td className="py-2 px-3 text-white font-medium">
                    <div>{t.name}</div>
                    <div className="text-[10px] text-slate-400 font-normal mt-0.5">{t.details}</div>
                  </td>
                  <td className="py-2 px-3 text-slate-400 text-[11px]">{t.category}</td>
                  <td className="py-2 px-3 text-slate-400">{t.tolerance}</td>
                  <td className="py-2 px-3 text-slate-300">{t.expected}</td>
                  <td className="py-2 px-3 text-emerald-400 font-bold">{t.actual}</td>
                  <td className="py-2 px-2 text-right text-slate-400">{t.executionMs.toFixed(2)} ms</td>
                  <td className="py-2 px-3 text-center">
                    {t.passed ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        PASS
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-400">
                        <XCircle className="w-3.5 h-3.5" />
                        FAIL
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
