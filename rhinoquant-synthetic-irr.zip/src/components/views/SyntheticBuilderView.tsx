/**
 * RhinoQuant Synthetic Return Builder View
 * Institutional financial engineering canvas to construct, configure,
 * and decompose synthetic investment exposures and inspect the dated transaction ledger.
 */

import React, { useState } from 'react';
import {
  FinancialInstrument,
  CashFlowRecord,
  SyntheticReturnSummary,
  InstrumentType,
  EconomicRole,
  PaymentFrequency,
  DayCountConvention,
} from '../../types';
import {
  Plus,
  Trash2,
  Download,
  AlertCircle,
  CheckCircle2,
  Sliders,
  DollarSign,
  Calendar,
  Layers,
  Search,
} from 'lucide-react';

interface SyntheticBuilderViewProps {
  instruments: FinancialInstrument[];
  onUpdateInstruments: (instruments: FinancialInstrument[]) => void;
  ledger: CashFlowRecord[];
  summary: SyntheticReturnSummary;
  assumedBenchmarkRate: number;
  onChangeBenchmarkRate: (rate: number) => void;
  onExportCsv: () => void;
}

export const SyntheticBuilderView: React.FC<SyntheticBuilderViewProps> = ({
  instruments,
  onUpdateInstruments,
  ledger,
  summary,
  assumedBenchmarkRate,
  onChangeBenchmarkRate,
  onExportCsv,
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [selectedInstId, setSelectedInstId] = useState<string>(instruments[0]?.id || '');

  // Add new component
  const handleAddInstrument = () => {
    const newInst: FinancialInstrument = {
      id: `INST_${Date.now()}`,
      name: 'New Synthetic Instrument Component',
      type: 'FLOATING_RATE_LOAN',
      role: 'SECONDARY_FUNDING',
      currency: 'USD',
      notional: 5000000,
      startDate: '2026-01-01',
      maturityDate: '2029-01-01',
      frequency: 'QUARTERLY',
      dayCount: 'ACT/360',
      rateType: 'FLOATING',
      spreadBps: 180,
      feesUpfront: 50000,
      active: true,
    };
    const updated = [...instruments, newInst];
    onUpdateInstruments(updated);
    setSelectedInstId(newInst.id);
  };

  // Delete component
  const handleDeleteInstrument = (id: string) => {
    if (instruments.length <= 1) return;
    const updated = instruments.filter((i) => i.id !== id);
    onUpdateInstruments(updated);
    if (selectedInstId === id) {
      setSelectedInstId(updated[0]?.id || '');
    }
  };

  // Toggle active status
  const handleToggleActive = (id: string) => {
    const updated = instruments.map((i) => (i.id === id ? { ...i, active: !i.active } : i));
    onUpdateInstruments(updated);
  };

  // Update specific property
  const handleUpdateProperty = (id: string, updates: Partial<FinancialInstrument>) => {
    const updated = instruments.map((i) => (i.id === id ? { ...i, ...updates } : i));
    onUpdateInstruments(updated);
  };

  const selectedInst = instruments.find((i) => i.id === selectedInstId) || instruments[0];

  const filteredLedger = ledger.filter(
    (row) =>
      row.description.toLowerCase().includes(filterQuery.toLowerCase()) ||
      row.category.toLowerCase().includes(filterQuery.toLowerCase()) ||
      row.date.includes(filterQuery)
  );

  return (
    <div className="space-y-6">
      
      {/* Top Controls: Global Benchmark Index & Actions */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Synthetic Return Construction Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Assemble financial instruments, funding liabilities, and hedging contracts into an institutional cash-flow ledger.
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-[#080c14] border border-slate-800 px-3 py-1.5 rounded text-xs">
            <span className="text-slate-400 font-medium">Underlying Benchmark Index (SOFR):</span>
            <input
              type="number"
              step="0.05"
              value={(assumedBenchmarkRate * 100).toFixed(2)}
              onChange={(e) => onChangeBenchmarkRate(parseFloat(e.target.value) / 100.0 || 0.0485)}
              className="w-16 bg-[#101726] border border-slate-700 px-1.5 py-0.5 text-right font-mono font-bold text-amber-400 rounded focus:outline-none focus:border-amber-400"
            />
            <span className="text-slate-400">%</span>
          </div>

          <button
            onClick={handleAddInstrument}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Instrument</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Split: Instruments List & Selected Property Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Components Stack */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-300 font-mono">
              Portfolio Component Ledger ({instruments.length})
            </span>
            <span className="text-[11px] text-slate-500 font-mono">
              Click to configure properties
            </span>
          </div>

          <div className="space-y-2">
            {instruments.map((inst) => {
              const isSelected = inst.id === selectedInstId;
              return (
                <div
                  key={inst.id}
                  onClick={() => setSelectedInstId(inst.id)}
                  className={`p-3 rounded border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#151f33] border-amber-400/90 shadow-sm shadow-amber-950/20'
                      : inst.active
                      ? 'bg-[#0b101b] border-slate-800 hover:border-slate-700'
                      : 'bg-[#0b101b]/50 border-slate-800/60 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={inst.active}
                        onChange={(e) => {
                          e.stopPropagation();
                          handleToggleActive(inst.id);
                        }}
                        className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-0 cursor-pointer"
                      />
                      <span className="text-xs font-bold text-white">
                        {inst.name}
                      </span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteInstrument(inst.id);
                      }}
                      disabled={instruments.length <= 1}
                      title="Remove instrument"
                      className="text-slate-500 hover:text-rose-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-amber-400/90 font-medium">
                      {inst.role.replace('_', ' ')}
                    </span>
                    <span className="text-slate-300">
                      ${(inst.notional / 1e6).toFixed(2)}M {inst.currency}
                    </span>
                  </div>

                  <div className="mt-1 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>
                      {inst.rateType === 'FIXED'
                        ? `${((inst.fixedRate || 0) * 100).toFixed(2)}% Fixed`
                        : `${inst.floatingBenchmark || 'SOFR'} + ${inst.spreadBps || 0} bps`}
                    </span>
                    <span>
                      {inst.startDate} → {inst.maturityDate}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Instrument Property Editor */}
        <div className="lg:col-span-7 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-[10px] uppercase tracking-wider font-mono text-amber-500">
                Instrument Parameter Matrix
              </span>
              <h3 className="text-sm font-bold text-white tracking-tight mt-0.5">
                {selectedInst?.name || 'Configure Instrument'}
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">
              ID: {selectedInst?.id}
            </span>
          </div>

          {selectedInst && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              
              {/* Instrument Name */}
              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-medium">Instrument Label</label>
                <input
                  type="text"
                  value={selectedInst.name}
                  onChange={(e) => handleUpdateProperty(selectedInst.id, { name: e.target.value })}
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-medium focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Instrument Type */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Instrument Type</label>
                <select
                  value={selectedInst.type}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      type: e.target.value as InstrumentType,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="OVERNIGHT_INDEX">Overnight Index (SOFR/ESTR)</option>
                  <option value="FLOATING_RATE_LOAN">Floating-Rate Loan / Facility</option>
                  <option value="FIXED_RATE_DEBT">Fixed-Rate Debt / Bond</option>
                  <option value="REPO_SECURED">Repo & Secured Funding</option>
                  <option value="INTEREST_RATE_SWAP">Interest Rate Swap (IRS)</option>
                  <option value="CROSS_CURRENCY_SWAP">Cross-Currency Swap (XCCY)</option>
                  <option value="FX_FORWARD_CARRY">FX Forward & Carry</option>
                  <option value="STRUCTURED_TRANCHE">Structured Credit Tranche</option>
                  <option value="COMMERCIAL_PAPER">Commercial Paper</option>
                </select>
              </div>

              {/* Economic Role */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Economic Role</label>
                <select
                  value={selectedInst.role}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      role: e.target.value as EconomicRole,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="UNDERLYING_ASSET">Underlying Asset (Investment Base)</option>
                  <option value="PRIMARY_FUNDING">Primary Debt Funding</option>
                  <option value="SECONDARY_FUNDING">Secondary / Mezzanine Debt</option>
                  <option value="RATE_HEDGE">Interest Rate Hedge</option>
                  <option value="CURRENCY_HEDGE">Currency Risk Hedge</option>
                  <option value="COLLATERAL_POSTING">Collateral / Margin Posting</option>
                </select>
              </div>

              {/* Notional / Principal */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Notional / Principal ($)
                </label>
                <input
                  type="number"
                  step="100000"
                  value={selectedInst.notional}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      notional: Math.max(0, parseFloat(e.target.value) || 0),
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Rate Structure (Fixed vs Floating) */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Interest Structure</label>
                <select
                  value={selectedInst.rateType}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      rateType: e.target.value as 'FIXED' | 'FLOATING',
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="FIXED">Fixed Coupon / Interest Rate</option>
                  <option value="FLOATING">Floating Benchmark Index + Spread</option>
                </select>
              </div>

              {/* Fixed Rate vs Floating Spread */}
              {selectedInst.rateType === 'FIXED' ? (
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Fixed Rate (%)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={((selectedInst.fixedRate || 0) * 100).toFixed(2)}
                    onChange={(e) =>
                      handleUpdateProperty(selectedInst.id, {
                        fixedRate: (parseFloat(e.target.value) || 0) / 100.0,
                      })
                    }
                    className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Spread (Basis Points)</label>
                  <input
                    type="number"
                    step="5"
                    value={selectedInst.spreadBps || 0}
                    onChange={(e) =>
                      handleUpdateProperty(selectedInst.id, {
                        spreadBps: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
              )}

              {/* Payment Frequency */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Payment Frequency</label>
                <select
                  value={selectedInst.frequency}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      frequency: e.target.value as PaymentFrequency,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="QUARTERLY">Quarterly (3 Months)</option>
                  <option value="SEMI_ANNUAL">Semi-Annual (6 Months)</option>
                  <option value="ANNUAL">Annual (12 Months)</option>
                  <option value="MONTHLY">Monthly (1 Month)</option>
                </select>
              </div>

              {/* Day Count Convention */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Day-Count Convention</label>
                <select
                  value={selectedInst.dayCount}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      dayCount: e.target.value as DayCountConvention,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="ACT/360">ACT/360 (Money Market / SOFR)</option>
                  <option value="ACT/365">ACT/365 (Sterling / Standard)</option>
                  <option value="30/360">30/360 (US Bond Basis)</option>
                  <option value="ACT/ACT">ACT/ACT (Treasury / ISDA)</option>
                </select>
              </div>

              {/* Repo Haircut (if funding) */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Repo / Collateral Haircut (%)
                </label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  max="100"
                  value={((selectedInst.haircut || 0) * 100).toFixed(0)}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      haircut: (parseFloat(e.target.value) || 0) / 100.0,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Upfront Fees */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Upfront Fees ($)</label>
                <input
                  type="number"
                  step="5000"
                  value={selectedInst.feesUpfront || 0}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      feesUpfront: parseFloat(e.target.value) || 0,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Maturity Date */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Maturity Date</label>
                <input
                  type="date"
                  value={selectedInst.maturityDate}
                  onChange={(e) =>
                    handleUpdateProperty(selectedInst.id, {
                      maturityDate: e.target.value,
                    })
                  }
                  className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

            </div>
          )}
        </div>
      </div>

      {/* Solver Diagnostics & Convergence Certification */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Numerical Solver Diagnostics (Descartes Sign Analysis & Brent Convergence)
            </h3>
          </div>
          <span className="text-xs font-mono text-emerald-400">
            Certified Residual |NPV| &lt; 1e-4
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase">Solver Algorithm</span>
            <div className="text-white font-semibold mt-0.5">{summary.diagnostics.solverMethod}</div>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase">Convergence Status</span>
            <div
              className={`font-semibold mt-0.5 ${
                summary.diagnostics.status === 'CONVERGED' ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {summary.diagnostics.status}
            </div>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase">Solver Iterations</span>
            <div className="text-white font-semibold mt-0.5">{summary.diagnostics.iterations} iterations</div>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase">NPV Residual</span>
            <div className="text-emerald-400 font-semibold mt-0.5">
              {summary.diagnostics.residualNpv.toExponential(4)}
            </div>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase">Sign Changes (Descartes)</span>
            <div className="text-white font-semibold mt-0.5">
              {summary.diagnostics.signChangeCount} sign changes
            </div>
          </div>

          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <span className="text-[10px] text-slate-500 uppercase">Root Uniqueness</span>
            <div className="text-cyan-400 font-semibold mt-0.5">
              {summary.diagnostics.uniqueRootGuaranteed ? 'GUARANTEED' : 'MULTI-SCAN ACTIVE'}
            </div>
          </div>
        </div>

        {summary.diagnostics.warning && (
          <div className="mt-3 p-2 bg-amber-950/20 border border-amber-500/30 rounded text-xs text-amber-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>{summary.diagnostics.warning}</span>
          </div>
        )}
      </section>

      {/* Comprehensive Dated Cash-Flow Ledger */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Filter transactions by date, description, category..."
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              className="bg-[#080c14] border border-slate-700 px-3 py-1 text-xs text-white rounded w-64 focus:outline-none focus:border-amber-400"
            />
            <span className="text-xs text-slate-500 font-mono">
              ({filteredLedger.length} of {ledger.length})
            </span>
          </div>

          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-slate-300 bg-slate-900 border border-slate-700 hover:bg-slate-800 hover:text-white rounded transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Export CSV Ledger</span>
          </button>
        </div>

        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-left text-xs font-mono">
            <thead className="sticky top-0 bg-[#0b101b] shadow-sm z-10">
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">Date</th>
                <th className="py-2 px-2 text-right">Elapsed (τ)</th>
                <th className="py-2 px-3">Category</th>
                <th className="py-2 px-3">Transaction Description</th>
                <th className="py-2 px-3 text-right">Gross Asset</th>
                <th className="py-2 px-3 text-right">Financing Flow</th>
                <th className="py-2 px-3 text-right">Hedging Flow</th>
                <th className="py-2 px-3 text-right text-amber-400 font-bold">Net Investor CF</th>
                <th className="py-2 px-2 text-right">DF(0, τ)</th>
                <th className="py-2 px-3 text-right">Discounted CF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLedger.map((row) => {
                const formatNum = (v: number) => {
                  if (Math.abs(v) < 1e-6) return '-';
                  return (v < 0 ? '-' : '+') + '$' + Math.abs(v).toLocaleString(undefined, { maximumFractionDigits: 0 });
                };

                return (
                  <tr key={row.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2 px-3 text-slate-200 font-semibold">{row.date}</td>
                    <td className="py-2 px-2 text-right text-slate-400">{row.yearFraction.toFixed(3)}</td>
                    <td className="py-2 px-3 text-slate-400 text-[11px] uppercase">
                      {row.category.replace('_', ' ')}
                    </td>
                    <td className="py-2 px-3 text-slate-300 truncate max-w-sm">{row.description}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{formatNum(row.grossAssetFlow)}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{formatNum(row.financingFlow)}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{formatNum(row.hedgingFlow)}</td>
                    <td
                      className={`py-2 px-3 text-right font-bold ${
                        row.netInvestorFlow < 0 ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {formatNum(row.netInvestorFlow)}
                    </td>
                    <td className="py-2 px-2 text-right text-slate-500">{row.discountFactor.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{formatNum(row.discountedNetFlow)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

    </div>
  );
};
