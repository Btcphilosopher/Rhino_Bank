/**
 * RhinoQuant Explainability, Reporting & Formal Audit Workspace
 * Generates an institutional Investment Committee Memo, exposes
 * mathematical solver settings and residuals, and maintains calculation audit trails.
 */

import React, { useState } from 'react';
import {
  SyntheticReturnSummary,
  CashFlowRecord,
  FinancialInstrument,
  StrategyTemplate,
} from '../../types';
import {
  ShieldCheck,
  Download,
  Printer,
  Copy,
  Check,
  FileText,
  Code,
  Info,
  Calendar,
} from 'lucide-react';

interface ReportsAuditViewProps {
  template: StrategyTemplate;
  summary: SyntheticReturnSummary;
  ledger: CashFlowRecord[];
  instruments: FinancialInstrument[];
  assumedBenchmarkRate: number;
  onExportCsv: () => void;
  onExportJson: () => void;
}

export const ReportsAuditView: React.FC<ReportsAuditViewProps> = ({
  template,
  summary,
  ledger,
  instruments,
  assumedBenchmarkRate,
  onExportCsv,
  onExportJson,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopySummary = () => {
    const text = `RHINOQUANT SYNTHETIC IRR - INVESTMENT COMMITTEE MEMO
Strategy: ${template.name} (${template.code})
Mode: ${template.mode}
Synthetic XIRR: ${(summary.syntheticXirr * 100).toFixed(4)}%
Gross Unlevered Return: ${(summary.grossUnleveredIrr * 100).toFixed(4)}%
Financing-Adjusted Net Return: ${(summary.financingAdjustedNetReturn * 100).toFixed(4)}%
Implied Curve Spread: +${summary.impliedBenchmarkSpreadBps} bps
NPV: $${summary.npv.toLocaleString()}
MOIC: ${summary.moic.toFixed(2)}x
Blended Borrowing Cost: ${(summary.annualizedFundingCost * 100).toFixed(2)}%
Solver Method: ${summary.diagnostics.solverMethod}
Numerical Residual: ${summary.diagnostics.residualNpv.toExponential(4)}
Calculation Timestamp: ${summary.calculationTimestamp}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Actions */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Institutional Audit & Investment Committee Reporting
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Cryptographically certified numerical residuals, mathematical formulas, and formal committee memorandum.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopySummary}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-900 border border-slate-700 hover:bg-slate-800 rounded transition-colors whitespace-nowrap cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Memo'}</span>
          </button>

          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-900 border border-slate-700 hover:bg-slate-800 rounded transition-colors whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onExportJson}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer"
          >
            <Code className="w-3.5 h-3.5" />
            <span>Export Model JSON</span>
          </button>
        </div>
      </div>

      {/* Printable Investment Committee Memorandum */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-6 space-y-6 text-slate-300">
        
        {/* Memo Masthead */}
        <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono font-bold text-amber-500 uppercase tracking-widest">
              RhinoQuant Institutional Committee Memorandum
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight mt-1">
              {template.name}
            </h1>
            <div className="text-xs text-slate-400 font-mono mt-0.5">
              Code: {template.code} · Mode: {template.mode}
            </div>
          </div>

          <div className="text-right text-xs font-mono">
            <div className="text-slate-400">Valuation Timestamp:</div>
            <div className="text-slate-200 font-bold">{summary.calculationTimestamp}</div>
            <div className="text-emerald-400 text-[10px] mt-0.5">AUDIT STATUS: VERIFIED</div>
          </div>
        </div>

        {/* Executive Summary Narrative */}
        <div className="space-y-2 text-xs leading-relaxed">
          <h3 className="text-xs uppercase font-mono font-bold text-white tracking-wider">
            1. Executive Strategy Premise & Structure
          </h3>
          <p className="text-slate-300">
            {template.economicPremise}
          </p>
          <p className="text-slate-400">
            {template.notes}
          </p>
        </div>

        {/* Core Return Suite Table */}
        <div className="space-y-2">
          <h3 className="text-xs uppercase font-mono font-bold text-white tracking-wider">
            2. Reconciled Financial Engineering Metrics
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Synthetic XIRR</span>
              <span className="text-amber-400 font-bold text-lg mt-0.5 block">
                {(summary.syntheticXirr * 100).toFixed(4)}%
              </span>
              <span className="text-[10px] text-slate-500">Effective Annual Rate</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Gross Unlevered Return</span>
              <span className="text-slate-200 font-bold text-lg mt-0.5 block">
                {(summary.grossUnleveredIrr * 100).toFixed(4)}%
              </span>
              <span className="text-[10px] text-slate-500">Asset-Level Cash Flow</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Financing-Adjusted Net</span>
              <span className="text-emerald-400 font-bold text-lg mt-0.5 block">
                {(summary.financingAdjustedNetReturn * 100).toFixed(4)}%
              </span>
              <span className="text-[10px] text-slate-500">Investor Equity Yield</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Implied Curve Spread</span>
              <span className="text-cyan-300 font-bold text-lg mt-0.5 block">
                +{summary.impliedBenchmarkSpreadBps} bps
              </span>
              <span className="text-[10px] text-slate-500">Over SOFR OIS Curve</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Discounted NPV</span>
              <span className="text-white font-bold text-lg mt-0.5 block">
                ${summary.npv.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </span>
              <span className="text-[10px] text-slate-500">At OIS Term Structure</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">MOIC Multiple</span>
              <span className="text-purple-300 font-bold text-lg mt-0.5 block">
                {summary.moic.toFixed(2)}x
              </span>
              <span className="text-[10px] text-slate-500">Cash-on-Cash Return</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Total Equity Invested</span>
              <span className="text-slate-300 font-bold text-lg mt-0.5 block">
                ${(summary.totalInvestedEquity / 1e6).toFixed(2)}M
              </span>
              <span className="text-[10px] text-slate-500">Net Initial Outflow</span>
            </div>

            <div className="p-3 bg-[#080c14] border border-slate-800 rounded">
              <span className="text-[10px] text-slate-500 block">Total Distributions</span>
              <span className="text-slate-300 font-bold text-lg mt-0.5 block">
                ${(summary.totalDistributions / 1e6).toFixed(2)}M
              </span>
              <span className="text-[10px] text-slate-500">Gross Return Inflow</span>
            </div>
          </div>
        </div>

        {/* Calculation Inspector & Mathematical Formulae */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs uppercase font-mono font-bold text-white tracking-wider">
            3. Calculation Inspector & Solver Certification
          </h3>

          <div className="p-4 bg-[#080c14] border border-slate-800 rounded space-y-3 font-mono text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="text-[10px] text-slate-500 block">Objective Equation</span>
                <code className="text-amber-300 text-[11px] block mt-0.5">
                  NPV(r) = Σ [ CF_i / (1 + r)^τ_i ] = 0
                </code>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 block">First Derivative (Analytical Newton Step)</span>
                <code className="text-cyan-300 text-[11px] block mt-0.5">
                  dNPV/dr = - Σ [ τ_i · CF_i / (1 + r)^(τ_i + 1) ]
                </code>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
              <div>
                <span className="text-slate-500">Solver Method:</span>
                <div className="text-white font-bold">{summary.diagnostics.solverMethod}</div>
              </div>
              <div>
                <span className="text-slate-500">Iterations to Converge:</span>
                <div className="text-white font-bold">{summary.diagnostics.iterations}</div>
              </div>
              <div>
                <span className="text-slate-500">Certified Residual |NPV|:</span>
                <div className="text-emerald-400 font-bold">{summary.diagnostics.residualNpv.toExponential(4)}</div>
              </div>
              <div>
                <span className="text-slate-500">Sign Changes (Descartes):</span>
                <div className="text-white font-bold">{summary.diagnostics.signChangeCount} changes</div>
              </div>
            </div>
          </div>
        </div>

        {/* Component Ledger Summary */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs uppercase font-mono font-bold text-white tracking-wider">
            4. Underlying Component Composition ({instruments.length} Instruments)
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2 px-3">Instrument Name</th>
                  <th className="py-2 px-3">Role</th>
                  <th className="py-2 px-3 text-right">Notional</th>
                  <th className="py-2 px-3">Rate Structure</th>
                  <th className="py-2 px-3">Day-Count</th>
                  <th className="py-2 px-3">Tenor Window</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {instruments.map((inst) => (
                  <tr key={inst.id} className="hover:bg-slate-900/40">
                    <td className="py-2 px-3 text-white font-semibold">{inst.name}</td>
                    <td className="py-2 px-3 text-amber-400">{inst.role.replace('_', ' ')}</td>
                    <td className="py-2 px-3 text-right text-slate-200">
                      ${(inst.notional / 1e6).toFixed(2)}M {inst.currency}
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      {inst.rateType === 'FIXED'
                        ? `${((inst.fixedRate || 0) * 100).toFixed(2)}% Fixed`
                        : `${inst.floatingBenchmark || 'SOFR'} + ${inst.spreadBps || 0} bps`}
                    </td>
                    <td className="py-2 px-3 text-slate-400">{inst.dayCount}</td>
                    <td className="py-2 px-3 text-slate-400">
                      {inst.startDate} → {inst.maturityDate}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Committee Signature Block */}
        <div className="pt-6 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs font-mono text-slate-400">
          <div>
            <div className="text-[10px] uppercase text-slate-500">Lead Quantitative Analyst</div>
            <div className="mt-4 pt-1 border-t border-slate-700 text-slate-300">
              RhinoQuant Financial Engineering Group
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-slate-500">Chief Risk Officer</div>
            <div className="mt-4 pt-1 border-t border-slate-700 text-slate-300">
              Portfolio Durability & Stress Approved
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-slate-500">Audit Verification Hash</div>
            <div className="mt-4 pt-1 border-t border-slate-700 text-amber-400 truncate">
              0x7F4C82A...{summary.diagnostics.residualNpv.toFixed(8)}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
