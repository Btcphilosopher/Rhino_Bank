/**
 * RhinoQuant Curve Construction & Comparison Workspace
 * Visualizes multi-currency discount curves, forward curves,
 * cross-currency basis adjustments, and log-linear interpolation knots.
 */

import React, { useState } from 'react';
import { STANDARD_CURVES, applyCrossCurrencyBasis, interpolateDiscountFactor } from '../../math/curveEngine';
import { YieldCurveDefinition } from '../../types';
import { TrendingUp, Sliders, AlertTriangle, Layers, Info } from 'lucide-react';

export const CurveEngineView: React.FC = () => {
  const [selectedCurveId, setSelectedCurveId] = useState<string>('USD_SOFR');
  const [basisShiftBps, setBasisShiftBps] = useState<number>(-25);
  const [testTenorYears, setTestTenorYears] = useState<number>(3.5);

  const baseCurve = STANDARD_CURVES[selectedCurveId] || STANDARD_CURVES.USD_SOFR;
  const basisAdjustedCurve = applyCrossCurrencyBasis(
    baseCurve,
    basisShiftBps,
    `${baseCurve.name} (${basisShiftBps >= 0 ? '+' : ''}${basisShiftBps} bps Basis)`
  );

  // Interpolation probe
  const probe = interpolateDiscountFactor(basisAdjustedCurve, testTenorYears);

  // SVG Chart Dimensions
  const chartWidth = 720;
  const chartHeight = 260;
  const padLeft = 50;
  const padRight = 30;
  const padTop = 20;
  const padBottom = 40;

  // Max tenor 10Y, rate range 0% to 6%
  const maxTenor = 10.0;
  const minRate = 0.015;
  const maxRate = 0.06;

  const scaleX = (t: number) =>
    padLeft + ((t / maxTenor) * (chartWidth - padLeft - padRight));
  const scaleY = (r: number) =>
    chartHeight - padBottom - (((r - minRate) / (maxRate - minRate)) * (chartHeight - padTop - padBottom));

  // Build SVG paths for base curve zero rates and basis adjusted curve
  const makePath = (curve: YieldCurveDefinition) => {
    return curve.points
      .map((p, idx) => {
        const x = scaleX(p.tenorYears);
        const y = scaleY(p.zeroRate);
        return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const basePath = makePath(baseCurve);
  const synthPath = makePath(basisAdjustedCurve);
  const estrPath = makePath(STANDARD_CURVES.EUR_ESTR);

  return (
    <div className="space-y-6">
      
      {/* Workspace Header & Curve Picker */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Yield Curve & Discount Factor Engineering
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Calibrate discount term structures, instantaneous forward rates, and cross-currency basis spreads.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-400">Base Reference Curve:</span>
          <select
            value={selectedCurveId}
            onChange={(e) => setSelectedCurveId(e.target.value)}
            className="bg-[#080c14] border border-slate-700 px-3 py-1.5 text-xs text-white rounded font-medium focus:outline-none focus:border-amber-400"
          >
            <option value="USD_SOFR">USD SOFR OIS Benchmark Curve</option>
            <option value="EUR_ESTR">EUR €STR Benchmark Curve</option>
            <option value="USD_REPO_GC">US Treasury General Collateral Repo</option>
          </select>
        </div>
      </div>

      {/* Interactive Curve Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Interactive SVG Chart */}
        <div className="lg:col-span-8 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Term Structure Multi-Curve Graph (Zero Rates %)
              </h3>
            </div>
            
            {/* Legend */}
            <div className="flex items-center gap-4 text-[11px] font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-amber-400 inline-block" />
                <span className="text-slate-300">{baseCurve.benchmark} Base</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-cyan-400 inline-block border-dashed" />
                <span className="text-cyan-300">Synthetic Adjusted</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-emerald-500 inline-block" />
                <span className="text-slate-400">EUR €STR</span>
              </div>
            </div>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-auto text-slate-600 select-none"
            >
              {/* Horizontal Gridlines & Y-axis labels */}
              {[0.02, 0.03, 0.04, 0.05, 0.06].map((rate) => {
                const y = scaleY(rate);
                return (
                  <g key={rate}>
                    <line
                      x1={padLeft}
                      y1={y}
                      x2={chartWidth - padRight}
                      y2={y}
                      stroke="#1e293b"
                      strokeDasharray="3 3"
                    />
                    <text
                      x={padLeft - 8}
                      y={y + 3}
                      textAnchor="end"
                      fill="#64748b"
                      className="text-[10px] font-mono"
                    >
                      {(rate * 100).toFixed(1)}%
                    </text>
                  </g>
                );
              })}

              {/* Tenor X-axis ticks */}
              {[0.5, 1, 2, 3, 5, 7, 10].map((t) => {
                const x = scaleX(t);
                return (
                  <g key={t}>
                    <line
                      x1={x}
                      y1={padTop}
                      x2={x}
                      y2={chartHeight - padBottom}
                      stroke="#1e293b"
                      strokeDasharray="2 2"
                    />
                    <text
                      x={x}
                      y={chartHeight - padBottom + 16}
                      textAnchor="middle"
                      fill="#64748b"
                      className="text-[10px] font-mono"
                    >
                      {t}Y
                    </text>
                  </g>
                );
              })}

              {/* Curve 1: EUR €STR reference */}
              <path
                d={estrPath}
                fill="none"
                stroke="#10b981"
                strokeWidth="1.5"
                opacity="0.6"
              />

              {/* Curve 2: Synthetic Basis-Adjusted Curve */}
              <path
                d={synthPath}
                fill="none"
                stroke="#22d3ee"
                strokeWidth="2"
                strokeDasharray="4 2"
              />

              {/* Curve 3: Base Curve */}
              <path
                d={basePath}
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2.5"
              />

              {/* Knot Dots on Base Curve */}
              {baseCurve.points.map((p) => {
                const cx = scaleX(p.tenorYears);
                const cy = scaleY(p.zeroRate);
                return (
                  <circle
                    key={p.tenorLabel}
                    cx={cx}
                    cy={cy}
                    r="3.5"
                    fill="#080c14"
                    stroke="#f59e0b"
                    strokeWidth="1.5"
                  />
                );
              })}
            </svg>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1">
            <span>Interpolation: Log-linear discount factor</span>
            <span>Calibration RMS Residual: {baseCurve.calibrationResidualRms.toFixed(6)} (&lt; 0.01 bps)</span>
          </div>
        </div>

        {/* Right Column: Cross-Currency Basis Simulator */}
        <div className="lg:col-span-4 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Cross-Currency Basis Shift
              </h3>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Simulate FX cross-currency basis swap spread shift
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300">Basis Spread (bps):</span>
                <span className="text-cyan-400 font-bold text-sm">
                  {basisShiftBps > 0 ? `+${basisShiftBps}` : basisShiftBps} bps
                </span>
              </div>
              <input
                type="range"
                min="-100"
                max="100"
                step="5"
                value={basisShiftBps}
                onChange={(e) => setBasisShiftBps(parseInt(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg mt-2"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>-100 bps (Cheap synth funding)</span>
                <span>+100 bps (Costly)</span>
              </div>
            </div>

            {/* Probe Inspector */}
            <div className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-2">
              <div className="text-[10px] uppercase font-mono text-slate-400">
                Log-Linear Interpolation Probe
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Target Tenor:</span>
                <input
                  type="number"
                  step="0.25"
                  min="0.1"
                  max="15"
                  value={testTenorYears}
                  onChange={(e) => setTestTenorYears(parseFloat(e.target.value) || 1.0)}
                  className="w-20 bg-[#101726] border border-slate-700 px-2 py-0.5 text-right font-mono text-white rounded text-xs"
                />
              </div>

              <div className="pt-2 border-t border-slate-800/80 space-y-1 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Discount Factor DF(0, τ):</span>
                  <span className="text-amber-400 font-bold">{probe.discountFactor.toFixed(6)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Interpolated Zero Rate:</span>
                  <span className="text-white">{(probe.zeroRate * 100).toFixed(3)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Extrapolation Flag:</span>
                  <span className={probe.isExtrapolated ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                    {probe.isExtrapolated ? 'EXTRAPOLATED' : 'INTERPOLATED'}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-900/40 border border-slate-800 rounded text-[11px] text-slate-400 leading-relaxed">
              Formula: <code className="text-cyan-300 font-mono">DF_synth(t) = DF_base(t) · e^(-β·t)</code>
              <br />
              Negative basis spread lowers effective borrowing costs for non-domestic fund raisers.
            </div>
          </div>
        </div>

      </div>

      {/* Tenor Knot Calibration Table */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4 space-y-3">
        <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
          Calibration Knot Points ({baseCurve.points.length} Pillars)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">Tenor</th>
                <th className="py-2 px-3 text-right">Years (τ)</th>
                <th className="py-2 px-3 text-right">Base Zero Rate</th>
                <th className="py-2 px-3 text-right text-cyan-400">Basis-Adjusted Zero</th>
                <th className="py-2 px-3 text-right text-amber-400 font-bold">Base DF(0, τ)</th>
                <th className="py-2 px-3 text-right text-cyan-400">Basis-Adjusted DF</th>
                <th className="py-2 px-3 text-right">Forward Rate</th>
                <th className="py-2 px-3 text-right">Par Swap Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {baseCurve.points.map((p, idx) => {
                const synthP = basisAdjustedCurve.points[idx];
                return (
                  <tr key={p.tenorLabel} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2 px-3 text-slate-200 font-semibold">{p.tenorLabel}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{p.tenorYears.toFixed(3)}</td>
                    <td className="py-2 px-3 text-right text-white">{(p.zeroRate * 100).toFixed(3)}%</td>
                    <td className="py-2 px-3 text-right text-cyan-300 font-bold">
                      {(synthP.zeroRate * 100).toFixed(3)}%
                    </td>
                    <td className="py-2 px-3 text-right text-amber-400 font-bold">
                      {p.discountFactor.toFixed(6)}
                    </td>
                    <td className="py-2 px-3 text-right text-cyan-300">
                      {synthP.discountFactor.toFixed(6)}
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400">
                      {(p.forwardRate * 100).toFixed(3)}%
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400">
                      {p.parSwapRate ? `${(p.parSwapRate * 100).toFixed(3)}%` : '-'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

    </div>
  );
};
