/**
 * RhinoQuant Overview & Return Decomposition View
 * Master cockpit showing mode distinction, strategy selection,
 * component structure, return waterfall, and dated cash-flow ledger.
 */

import React from 'react';
import {
  SyntheticMode,
  SyntheticReturnSummary,
  CashFlowRecord,
  FinancialInstrument,
  StrategyTemplate,
} from '../../types';
import { INSTITUTIONAL_TEMPLATES } from '../../data/templates';
import {
  Layers,
  ArrowRight,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Info,
  Sliders,
} from 'lucide-react';

interface OverviewViewProps {
  currentMode: SyntheticMode;
  onChangeMode: (m: SyntheticMode) => void;
  selectedTemplate: StrategyTemplate;
  onSelectTemplate: (t: StrategyTemplate) => void;
  summary: SyntheticReturnSummary;
  ledger: CashFlowRecord[];
  instruments: FinancialInstrument[];
  onOpenInspector: () => void;
  onNavigateToBuilder: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  currentMode,
  onChangeMode,
  selectedTemplate,
  onSelectTemplate,
  summary,
  ledger,
  instruments,
  onOpenInspector,
  onNavigateToBuilder,
}) => {
  const modeDescriptions: Record<
    SyntheticMode,
    { title: string; subtitle: string; formula: string; economicMeaning: string }
  > = {
    MODE_A_SYNTHETIC_CASHFLOW_IRR: {
      title: 'Mode A: Synthetic Cash-Flow IRR',
      subtitle: 'Constructs a dated cash-flow series from combined instruments, fees, and hedges.',
      formula: 'NPV(r) = Σ [ CF_i / (1 + r)^τ_i ] = 0',
      economicMeaning:
        'Solves for the single effective annual discount rate that equates the present value of all net synthetic dated cash flows to zero. Reflects investment timing and actual cash generation.',
    },
    MODE_B_FINANCING_ADJUSTED_RETURN: {
      title: 'Mode B: Synthetic Financing-Adjusted Return',
      subtitle: 'Isolates investor equity return after replacing or combining funding sources.',
      formula: 'IRR_equity = f(CF_asset - DebtService_synthetic - Fees)',
      economicMeaning:
        'Evaluates the return of an investment strategy after swapping out underlying funding arrangements (e.g. repo vs floating SOFR loan). Rigorously avoids double-counting debt drawdowns as profit.',
    },
    MODE_C_IMPLIED_RATE_EXTRACTION: {
      title: 'Mode C: Synthetic Implied-Rate Extraction',
      subtitle: 'Infers unknown benchmark spread, exit cap rate, or break-even carry from prices.',
      formula: 'ObservedPrice = Σ [ ContractualCF_i * DF(0, τ_i) * exp(-s * τ_i) ]',
      economicMeaning:
        'Calibrates the unobservable spread, discount margin, or hurdle rate that reconciles the contractual cash flows with market pricing or targeted hurdle NPV.',
    },
  };

  const activeModeInfo = modeDescriptions[currentMode];

  // Waterfall calculation values
  const grossAssetReturn = summary.grossUnleveredIrr || 0.085;
  const fundingCost = summary.annualizedFundingCost || 0.055;
  const netLeveredReturn = summary.financingAdjustedNetReturn || 0.142;
  const hedgeDragPct = (summary.hedgeCostBps || 0) / 10000.0;

  return (
    <div className="space-y-6">
      
      {/* 1. Mode Distinction Selector (Governing Principle: Never combine into one unexplained %) */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-800/80">
          <div>
            <div className="text-xs uppercase tracking-wider font-semibold text-amber-500 font-mono">
              Analytical Mode Architecture
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight mt-0.5">
              {activeModeInfo.title}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {activeModeInfo.subtitle}
            </p>
          </div>

          {/* Mode Switcher Segmented Control */}
          <div className="flex items-center gap-1 p-1 bg-[#101726] border border-slate-700/80 rounded">
            <button
              onClick={() => onChangeMode('MODE_A_SYNTHETIC_CASHFLOW_IRR')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                currentMode === 'MODE_A_SYNTHETIC_CASHFLOW_IRR'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Mode A: Cash-Flow IRR
            </button>
            <button
              onClick={() => onChangeMode('MODE_B_FINANCING_ADJUSTED_RETURN')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                currentMode === 'MODE_B_FINANCING_ADJUSTED_RETURN'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Mode B: Financing-Adjusted
            </button>
            <button
              onClick={() => onChangeMode('MODE_C_IMPLIED_RATE_EXTRACTION')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                currentMode === 'MODE_C_IMPLIED_RATE_EXTRACTION'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Mode C: Implied Extraction
            </button>
          </div>
        </div>

        {/* Methodology & Formula Disclosure */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 text-xs">
          <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
            <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
              Mathematical Equation
            </div>
            <div className="font-mono text-amber-300 font-semibold mt-1 text-[13px] tracking-tight">
              {activeModeInfo.formula}
            </div>
          </div>
          <div className="md:col-span-2 p-2.5 bg-[#080c14] border border-slate-800 rounded flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                Economic Interpretation & Boundary
              </div>
              <p className="text-slate-300 text-xs mt-0.5 leading-relaxed">
                {activeModeInfo.economicMeaning}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Strategy Template Switcher */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Institutional Strategy Blueprints (Section 8 Examples)
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Select a verified quantitative template to inspect synthetic cash flows
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {INSTITUTIONAL_TEMPLATES.map((tmpl) => {
            const isSelected = selectedTemplate.id === tmpl.id;
            return (
              <button
                key={tmpl.id}
                onClick={() => onSelectTemplate(tmpl)}
                className={`p-3 text-left rounded border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#151f33] border-amber-400 shadow-sm shadow-amber-950/20'
                    : 'bg-[#101726]/60 border-slate-800 hover:border-slate-700 hover:bg-[#101726]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                    <span className={isSelected ? 'text-amber-400 font-bold' : 'text-slate-500'}>
                      {tmpl.code}
                    </span>
                    <span className="text-slate-400">
                      {tmpl.mode === 'MODE_A_SYNTHETIC_CASHFLOW_IRR'
                        ? 'Mode A'
                        : tmpl.mode === 'MODE_B_FINANCING_ADJUSTED_RETURN'
                        ? 'Mode B'
                        : 'Mode C'}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-white tracking-tight line-clamp-1">
                    {tmpl.name}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-snug">
                    {tmpl.headlineDescription}
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                  <span className="text-slate-500 font-mono">
                    {tmpl.instruments.length} Instruments
                  </span>
                  <span className={isSelected ? 'text-amber-400 font-medium' : 'text-slate-400'}>
                    {isSelected ? 'ACTIVE' : 'LOAD →'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3. Strategy Decomposition & Component Architecture */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Return Decomposition Waterfall */}
        <div className="lg:col-span-5 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Return Decomposition Waterfall
              </h3>
              <p className="text-[11px] text-slate-400">
                From unlevered asset yield to levered equity return
              </p>
            </div>
            <span className="text-xs font-mono text-amber-400 font-bold">
              +{(summary.financingAdjustedNetReturn * 100).toFixed(2)}% NET
            </span>
          </div>

          <div className="space-y-3 pt-1">
            {/* Step 1: Gross Asset Yield */}
            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">1. Gross Unlevered Asset Return</span>
                <span className="font-mono text-slate-200 font-semibold">
                  +{(grossAssetReturn * 100).toFixed(2)}%
                </span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                Baseline underlying asset cash flow before financing structure
              </p>
            </div>

            {/* Step 2: Debt Financing Spread */}
            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">2. Blended Financing Cost</span>
                <span className="font-mono text-rose-400 font-semibold">
                  -{(fundingCost * 100).toFixed(2)}%
                </span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                Weighted debt service, benchmark reference index + financing margin
              </p>
            </div>

            {/* Step 3: Financial Leverage Multiplier */}
            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">3. Equity Leverage Spread</span>
                <span className="font-mono text-emerald-400 font-semibold">
                  +{(Math.max(0, netLeveredReturn - grossAssetReturn) * 100).toFixed(2)}%
                </span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                Return accretion generated by positive spread on debt capital
              </p>
            </div>

            {/* Step 4: Hedging & Fee Drag */}
            <div className="p-2.5 bg-[#080c14] border border-slate-800 rounded">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">4. Hedging & Structuring Fees</span>
                <span className="font-mono text-amber-400 font-semibold">
                  {summary.hedgeCostBps > 0 ? `-${(summary.hedgeCostBps / 100).toFixed(2)}%` : '0.00%'}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                Cost of rate swaps, forward basis, commitment and servicing fees
              </p>
            </div>

            {/* Final Reconciled Synthetic XIRR */}
            <div className="p-3 bg-gradient-to-r from-amber-950/30 to-[#0e1626] border border-amber-500/40 rounded flex items-center justify-between">
              <div>
                <div className="text-[11px] font-mono text-amber-400 font-semibold">
                  RECONCILED SYNTHETIC XIRR
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  Effective annual investor return
                </div>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold font-mono text-amber-300">
                  {(summary.syntheticXirr * 100).toFixed(2)}%
                </span>
                <div className="text-[9px] text-emerald-400 font-mono mt-0.5">
                  RESIDUAL |NPV| &lt; 1e-4
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Active Synthetic Components & Economic Roles */}
        <div className="lg:col-span-7 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Active Synthetic Components ({instruments.length})
              </h3>
              <p className="text-[11px] text-slate-400">
                Underlying instruments, funding sources, and hedge contracts
              </p>
            </div>
            <button
              onClick={onNavigateToBuilder}
              className="text-xs font-medium text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
            >
              <span>Edit in Builder</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2">
            {instruments.map((inst) => {
              const roleColors: Record<string, string> = {
                UNDERLYING_ASSET: 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20',
                PRIMARY_FUNDING: 'text-amber-400 border-amber-500/30 bg-amber-950/20',
                SECONDARY_FUNDING: 'text-blue-400 border-blue-500/30 bg-blue-950/20',
                RATE_HEDGE: 'text-purple-400 border-purple-500/30 bg-purple-950/20',
                CURRENCY_HEDGE: 'text-cyan-400 border-cyan-500/30 bg-cyan-950/20',
                COLLATERAL_POSTING: 'text-rose-400 border-rose-500/30 bg-rose-950/20',
              };

              return (
                <div
                  key={inst.id}
                  className="p-3 bg-[#080c14] border border-slate-800 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-white">
                        {inst.name}
                      </span>
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                          roleColors[inst.role] || 'text-slate-400 border-slate-700 bg-slate-900'
                        }`}
                      >
                        {inst.role.replace('_', ' ')}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                      <span>Notional: ${(inst.notional / 1e6).toFixed(1)}M {inst.currency}</span>
                      <span>·</span>
                      <span>{inst.dayCount}</span>
                      <span>·</span>
                      <span>{inst.frequency}</span>
                    </div>
                  </div>

                  <div className="text-right font-mono">
                    <div className="text-xs font-bold text-slate-200">
                      {inst.rateType === 'FIXED'
                        ? `${((inst.fixedRate || 0) * 100).toFixed(2)}% Fixed`
                        : `${inst.floatingBenchmark || 'SOFR'} + ${inst.spreadBps || 0} bps`}
                    </div>
                    <div className="text-[10px] text-slate-500">
                      Maturity: {inst.maturityDate}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-[#080c14] border border-slate-800 rounded text-xs text-slate-400 flex items-center justify-between">
            <span className="font-mono text-[11px]">
              Assumed Benchmark Index: {(selectedTemplate.assumedBenchmarkRate * 100).toFixed(2)}% SOFR
            </span>
            <button
              onClick={onOpenInspector}
              className="text-amber-400 hover:text-amber-300 font-medium font-mono text-[11px]"
            >
              Inspect Mathematical Formulas →
            </button>
          </div>
        </div>

      </div>

      {/* 4. Spreadsheet-Grade Cash-Flow Ledger Preview */}
      <section className="bg-[#0b101b] border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-amber-400" />
            <div>
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
                Synthetic Dated Cash-Flow Ledger ({ledger.length} Transactions)
              </h3>
              <p className="text-[11px] text-slate-400">
                Every cash flow entering into the XIRR root-finding equation is explicitly enumerated
              </p>
            </div>
          </div>
          <button
            onClick={onNavigateToBuilder}
            className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1 bg-slate-900 border border-slate-700 rounded transition-colors"
          >
            Open Full Ledger
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">Date</th>
                <th className="py-2 px-2 text-right">Elapsed (τ)</th>
                <th className="py-2 px-3">Event / Category</th>
                <th className="py-2 px-3 text-right">Gross Asset</th>
                <th className="py-2 px-3 text-right">Financing Debt</th>
                <th className="py-2 px-3 text-right">Hedges & Fees</th>
                <th className="py-2 px-3 text-right text-amber-400 font-bold">Net Investor CF</th>
                <th className="py-2 px-2 text-right">DF(0, τ)</th>
                <th className="py-2 px-3 text-right">Discounted CF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {ledger.slice(0, 7).map((row) => {
                const formatNum = (v: number) => {
                  if (Math.abs(v) < 1e-6) return '-';
                  return (v < 0 ? '-' : '+') + '$' + Math.abs(v).toLocaleString(undefined, { maximumFractionDigits: 0 });
                };

                return (
                  <tr key={row.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2 px-3 text-slate-200 font-semibold">{row.date}</td>
                    <td className="py-2 px-2 text-right text-slate-400">{row.yearFraction.toFixed(3)}</td>
                    <td className="py-2 px-3 text-slate-300 truncate max-w-xs">{row.description}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{formatNum(row.grossAssetFlow)}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{formatNum(row.financingFlow)}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{formatNum(row.hedgingFlow + row.feeFlow)}</td>
                    <td
                      className={`py-2 px-3 text-right font-bold ${
                        row.netInvestorFlow < 0 ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {formatNum(row.netInvestorFlow)}
                    </td>
                    <td className="py-2 px-2 text-right text-slate-500">{row.discountFactor.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{formatNum(row.discountedNetFlow)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {ledger.length > 7 && (
          <div className="mt-2 text-center text-xs text-slate-500 font-mono">
            Showing first 7 of {ledger.length} dated transactions. Use Synthetic Builder to view or filter complete schedule.
          </div>
        )}
      </section>

    </div>
  );
};
