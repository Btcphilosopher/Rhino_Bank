/**
 * RhinoQuant Structured Credit & Securitization Waterfall Workspace
 * Models collateral pool cash flows, CPR prepayments, CDR defaults,
 * recovery lags, sequential amortization, and tranche-level realized IRRs.
 */

import React, { useState } from 'react';
import { SecuritizationWaterfallConfig } from '../../types';
import { executeSecuritizationWaterfall } from '../../math/structuredCredit';
import { Layers, AlertTriangle, ShieldCheck, PieChart, TrendingDown, DollarSign } from 'lucide-react';

export const StructuredCreditView: React.FC = () => {
  const [config, setConfig] = useState<SecuritizationWaterfallConfig>({
    collateralPoolNotional: 100000000, // $100M Collateral Pool
    collateralCouponRate: 0.0825, // 8.25% Weighted Average Coupon (WAC)
    collateralTenorYears: 4, // 4-Year Maturity
    constantDefaultRateCdr: 0.030, // 3.0% Annual Default Rate
    conditionalPrepaymentRateCpr: 0.080, // 8.0% Annual CPR
    recoveryRate: 0.65, // 65% Recovery
    recoveryLagMonths: 6,
    servicingFeeBps: 50, // 50 bps servicing fee
    tranches: [
      {
        id: 'TRANCHE_A',
        name: 'Senior Tranche A (AAA/AA)',
        seniority: 1,
        attachmentPoint: 0.25,
        detachmentPoint: 1.0,
        sizeAmount: 75000000, // 75% of pool
        couponSpreadBps: 120, // SOFR + 120 bps
        principalBalance: 75000000,
        cumulativeLoss: 0,
        cumulativeInterestReceived: 0,
        cashFlows: [],
        modelIrr: 0,
      },
      {
        id: 'TRANCHE_B',
        name: 'Mezzanine Tranche B (BBB/BB)',
        seniority: 2,
        attachmentPoint: 0.10,
        detachmentPoint: 0.25,
        sizeAmount: 15000000, // 15% of pool
        couponSpreadBps: 350, // SOFR + 350 bps
        principalBalance: 15000000,
        cumulativeLoss: 0,
        cumulativeInterestReceived: 0,
        cashFlows: [],
        modelIrr: 0,
      },
      {
        id: 'TRANCHE_C',
        name: 'First-Loss Equity Tranche (Subordinated)',
        seniority: 3,
        attachmentPoint: 0.0,
        detachmentPoint: 0.10,
        sizeAmount: 10000000, // 10% of pool
        couponSpreadBps: 0, // Receives residual excess spread
        principalBalance: 10000000,
        cumulativeLoss: 0,
        cumulativeInterestReceived: 0,
        cashFlows: [],
        modelIrr: 0,
      },
    ],
  });

  const waterfallResult = executeSecuritizationWaterfall(config);

  return (
    <div className="space-y-6">
      
      {/* Workspace Header */}
      <div className="bg-[#0b101b] border border-slate-800 rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight">
            Structured Credit Securitization & Waterfall Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model pool-level amortization, constant default rates (CDR), prepayment speeds (CPR), and tranche-level realized IRRs.
          </p>
        </div>

        <div className="p-2 bg-amber-950/20 border border-amber-500/30 rounded text-xs text-amber-300 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Collateral yield ≠ Tranche IRR: Subordination absorbs losses non-linearly.</span>
        </div>
      </div>

      {/* Main Configuration Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Collateral Pool Assumptions */}
        <div className="lg:col-span-5 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Collateral Pool Parameters ($100M)
            </h3>
            <p className="text-[11px] text-slate-400">
              Stress default rates, prepayment speeds, and recovery rates
            </p>
          </div>

          <div className="space-y-3 text-xs">
            {/* WAC (Collateral Coupon) */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Collateral WAC (Gross Coupon):</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {(config.collateralCouponRate * 100).toFixed(2)}%
                </span>
              </div>
              <input
                type="number"
                step="0.25"
                value={(config.collateralCouponRate * 100).toFixed(2)}
                onChange={(e) =>
                  setConfig({ ...config, collateralCouponRate: (parseFloat(e.target.value) || 0) / 100 })
                }
                className="w-full bg-[#080c14] border border-slate-700 px-3 py-1.5 rounded font-mono text-white text-xs"
              />
            </div>

            {/* CDR (Constant Default Rate) */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Constant Default Rate (CDR Annual):</span>
                <span className="font-mono text-rose-400 font-bold text-sm">
                  {(config.constantDefaultRateCdr * 100).toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.15"
                step="0.005"
                value={config.constantDefaultRateCdr}
                onChange={(e) =>
                  setConfig({ ...config, constantDefaultRateCdr: parseFloat(e.target.value) })
                }
                className="w-full accent-rose-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>0% (No Defaults)</span>
                <span>5% (Moderate Stress)</span>
                <span>15% (Severe Crisis)</span>
              </div>
            </div>

            {/* CPR (Prepayment Rate) */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Conditional Prepayment Rate (CPR Annual):</span>
                <span className="font-mono text-cyan-400 font-bold text-sm">
                  {(config.conditionalPrepaymentRateCpr * 100).toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.25"
                step="0.01"
                value={config.conditionalPrepaymentRateCpr}
                onChange={(e) =>
                  setConfig({ ...config, conditionalPrepaymentRateCpr: parseFloat(e.target.value) })
                }
                className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>0% (Zero Prepay)</span>
                <span>8% (Standard)</span>
                <span>25% (Refi Wave)</span>
              </div>
            </div>

            {/* Recovery Rate */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-400">Recovery Rate on Defaulted Assets:</span>
                <span className="font-mono text-amber-400 font-bold text-sm">
                  {(config.recoveryRate * 100).toFixed(0)}%
                </span>
              </div>
              <input
                type="range"
                min="0.20"
                max="0.90"
                step="0.05"
                value={config.recoveryRate}
                onChange={(e) =>
                  setConfig({ ...config, recoveryRate: parseFloat(e.target.value) })
                }
                className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
            </div>

            {/* Pool Aggregates */}
            <div className="p-3 bg-[#080c14] border border-slate-800 rounded space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Cumulative Interest Collected:</span>
                <span className="text-emerald-400 font-bold">
                  ${(waterfallResult.totalPoolInterestGenerated / 1e6).toFixed(2)}M
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Cumulative Prepayments:</span>
                <span className="text-cyan-300">
                  ${(waterfallResult.totalPoolPrepayments / 1e6).toFixed(2)}M
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Cumulative Gross Losses:</span>
                <span className="text-rose-400 font-bold">
                  ${(waterfallResult.totalPoolLosses / 1e6).toFixed(2)}M
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Servicing Fees Paid:</span>
                <span className="text-slate-400">
                  ${(waterfallResult.servicingFeesPaid / 1e6).toFixed(2)}M
                </span>
              </div>
            </div>

          </div>
        </div>

        {/* Right Column: Tranche Performance Table */}
        <div className="lg:col-span-7 bg-[#0b101b] border border-slate-800 rounded p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-200 font-mono">
              Tranche Cash-Flow & Realized Return Breakdown
            </h3>
            <p className="text-[11px] text-slate-400">
              Seniority order (1 Senior to 3 First-Loss Equity) and solved tranche-level XIRRs
            </p>
          </div>

          <div className="space-y-3">
            {waterfallResult.tranches.map((tr) => {
              const formatIrr = (val: number) => {
                if (!Number.isFinite(val)) return 'N/A (Loss)';
                return `${(val * 100).toFixed(2)}%`;
              };

              const isSenior = tr.seniority === 1;
              const isMezz = tr.seniority === 2;
              const isEquity = tr.seniority === 3;

              return (
                <div
                  key={tr.id}
                  className={`p-3.5 rounded border transition-all ${
                    isSenior
                      ? 'bg-[#080c14] border-slate-800'
                      : isMezz
                      ? 'bg-[#080c14] border-blue-900/50'
                      : 'bg-amber-950/15 border-amber-500/40'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{tr.name}</span>
                        <span className="text-[10px] font-mono text-slate-400 px-1.5 py-0.5 bg-slate-900 rounded border border-slate-700">
                          Seniority #{tr.seniority}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                        Attachment: {(tr.attachmentPoint * 100).toFixed(0)}% - Detachment: {(tr.detachmentPoint * 100).toFixed(0)}%
                        · Size: ${(tr.sizeAmount / 1e6).toFixed(1)}M
                      </div>
                    </div>

                    <div className="text-right font-mono">
                      <div className="text-base font-bold text-amber-400">
                        {formatIrr(tr.calculatedIrr)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        MOIC: {tr.realizedMoic.toFixed(2)}x
                      </div>
                    </div>
                  </div>

                  {/* Tranche Loss & Principal Recovery Bar */}
                  <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-slate-400">
                      Interest Received: ${(tr.cumulativeInterestReceived / 1e6).toFixed(2)}M
                    </span>
                    <span
                      className={`font-bold ${
                        tr.principalLossPct > 0 ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      Principal Loss: {tr.principalLossPct.toFixed(1)}% (${(tr.cumulativeLoss / 1e6).toFixed(2)}M)
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Educational Note */}
          <div className="p-3 bg-[#080c14] border border-slate-800 rounded text-xs text-slate-400 space-y-1">
            <div className="font-semibold text-slate-300 font-mono text-[11px]">
              Subordination & Reverse-Loss Waterfall Mechanism:
            </div>
            <p className="leading-relaxed text-[11px]">
              Principal defaults hit the first-loss equity tranche first until the 10% subordination is wiped out. Once equity is exhausted, losses impair the Mezzanine tranche. Senior Tranche A remains insulated until cumulative losses exceed the 25% detachment threshold.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
