/**
 * RhinoQuant Headline KPI Banner
 * Displays the 8 institutional headline metrics required by the Synthetic IRR specification
 * with strict tabular alignment, clear economic labels, and zero vanity pills.
 */

import React from 'react';
import { SyntheticReturnSummary } from '../types';
import { TrendingUp, ArrowUpRight, DollarSign, Layers, Percent, Activity } from 'lucide-react';

interface KpiBannerProps {
  summary: SyntheticReturnSummary;
  onInspect: () => void;
}

export const KpiBanner: React.FC<KpiBannerProps> = ({ summary, onInspect }) => {
  const formatPct = (val: number) => {
    if (!Number.isFinite(val)) return 'N/A';
    return `${(val * 100).toFixed(2)}%`;
  };

  const formatCurrency = (val: number) => {
    if (!Number.isFinite(val)) return 'N/A';
    const absVal = Math.abs(val);
    const sign = val < 0 ? '-' : '';
    if (absVal >= 1e6) {
      return `${sign}$${(absVal / 1e6).toFixed(2)}M`;
    }
    if (absVal >= 1e3) {
      return `${sign}$${(absVal / 1e3).toFixed(1)}k`;
    }
    return `${sign}$${absVal.toFixed(0)}`;
  };

  return (
    <section className="bg-[#0b101b] border-b border-slate-800/80 px-6 py-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          
          {/* 1. Synthetic XIRR */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>Synthetic XIRR</span>
              <span className="text-[9px] text-amber-400 font-mono">ANNUAL</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl font-bold font-mono tracking-tight text-amber-400">
                {formatPct(summary.syntheticXirr)}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Target equation root
            </div>
          </div>

          {/* 2. Gross Unlevered Return */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>Gross Return</span>
              <span className="text-[9px] text-slate-500 font-mono">ASSET</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl font-bold font-mono tracking-tight text-slate-200">
                {formatPct(summary.grossUnleveredIrr)}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Unlevered cash flow
            </div>
          </div>

          {/* 3. Financing-Adjusted Return */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>Financing Return</span>
              <span className="text-[9px] text-emerald-400 font-mono">EQUITY</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl font-bold font-mono tracking-tight text-emerald-400">
                {formatPct(summary.financingAdjustedNetReturn)}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Net levered investor
            </div>
          </div>

          {/* 4. Implied Benchmark Spread */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>Curve Spread</span>
              <span className="text-[9px] text-cyan-400 font-mono">BPS</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl font-bold font-mono tracking-tight text-cyan-300">
                {Number.isFinite(summary.impliedBenchmarkSpreadBps)
                  ? `+${summary.impliedBenchmarkSpreadBps}`
                  : 'N/A'}
              </span>
              <span className="text-xs text-slate-400 font-mono">bps</span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Over SOFR OIS curve
            </div>
          </div>

          {/* 5. Net Present Value (NPV) */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>Discounted NPV</span>
              <span className="text-[9px] text-slate-500 font-mono">PV</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span
                className={`text-xl font-bold font-mono tracking-tight ${
                  summary.npv >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {formatCurrency(summary.npv)}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Discount factor sum
            </div>
          </div>

          {/* 6. MOIC */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>MOIC Multiple</span>
              <span className="text-[9px] text-purple-400 font-mono">CASH</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl font-bold font-mono tracking-tight text-purple-300">
                {Number.isFinite(summary.moic) ? `${summary.moic.toFixed(2)}x` : 'N/A'}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Return on equity cap
            </div>
          </div>

          {/* 7. Blended Funding Cost */}
          <div className="bg-[#101726]/80 border border-slate-800 p-3 rounded flex flex-col justify-between">
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
              <span>Funding Cost</span>
              <span className="text-[9px] text-amber-500/80 font-mono">DEBT</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl font-bold font-mono tracking-tight text-amber-300">
                {formatPct(summary.annualizedFundingCost)}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Weighted borrowing cost
            </div>
          </div>

          {/* 8. Solver Diagnostic Status */}
          <button
            onClick={onInspect}
            className="bg-[#101726]/80 hover:bg-[#151f33] border border-slate-800 hover:border-slate-700 p-3 rounded flex flex-col justify-between text-left transition-colors cursor-pointer group"
          >
            <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between w-full">
              <span>Solver Engine</span>
              <span className="text-[9px] text-slate-400 group-hover:text-amber-400 font-mono">
                DETAILS →
              </span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span
                className={`text-sm font-semibold font-mono tracking-tight ${
                  summary.diagnostics.status === 'CONVERGED'
                    ? 'text-emerald-400'
                    : summary.diagnostics.status === 'MULTIPLE_ROOTS'
                    ? 'text-amber-400'
                    : 'text-rose-400'
                }`}
              >
                {summary.diagnostics.status === 'CONVERGED'
                  ? 'BRENT CONVERGED'
                  : summary.diagnostics.status}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate mt-0.5">
              Res: |NPV| &lt; 1e-4
            </div>
          </button>

        </div>
      </div>
    </section>
  );
};
