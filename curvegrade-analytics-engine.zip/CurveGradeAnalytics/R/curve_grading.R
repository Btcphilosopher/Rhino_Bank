#' Curve Grading Engine
#'
#' @description Implements multiple standard and advanced curve grading methods for assessment scores.
#' Supports standard bell curve, z-score grading, percentile grading, linear scaling, T-score grading,
#' rank-based grading, and custom institutional policies.
#'
#' @importFrom stats sd mean quantile dnorm pnorm
#' @import dplyr
#' @import tidyr
#'
#' @name curve_grading
NULL

#' Standard Bell Curve Grading
#'
#' @param scores Numeric vector of scores.
#' @param target_mean Numeric. The desired mean for the graded scores.
#' @param target_sd Numeric. The desired standard deviation for the graded scores.
#' @param min_grade Numeric. Minimum allowable grade.
#' @param max_grade Numeric. Maximum allowable grade.
#' @param inflation_control Logical. If TRUE, dampens high-end scores if they exceed standard inflation limits.
#'
#' @return A numeric vector of graded scores scaled to the target normal distribution.
#' @export
#' @examples
#' scores <- c(55, 60, 75, 80, 85, 90, 95)
#' grade_bell_curve(scores, target_mean = 75, target_sd = 10)
grade_bell_curve <- function(scores, target_mean = 75, target_sd = 10, min_grade = 0, max_grade = 100, inflation_control = FALSE) {
  if (length(scores) < 2) return(scores)
  
  s_mean <- mean(scores, na.rm = TRUE)
  s_sd <- sd(scores, na.rm = TRUE)
  
  if (s_sd == 0) {
    # If standard deviation is zero, map all to target mean
    graded <- rep(target_mean, length(scores))
  } else {
    z_scores <- (scores - s_mean) / s_sd
    graded <- (z_scores * target_sd) + target_mean
  }
  
  # Apply inflation control if requested
  if (inflation_control) {
    # Shrink scores that are more than 2 SDs above the mean to prevent grade inflation
    high_idx <- graded > (target_mean + 2 * target_sd)
    if (any(high_idx)) {
      graded[high_idx] <- target_mean + 2 * target_sd + (graded[high_idx] - (target_mean + 2 * target_sd)) * 0.5
    }
  }
  
  # Clip to bounds
  graded <- pmax(min_grade, pmin(max_grade, graded))
  return(graded)
}

#' Z-score Grading
#'
#' @param scores Numeric vector of raw scores.
#' @param boundaries A named numeric vector or list of threshold Z-scores for each grade (e.g., A, B, C, D, F).
#'
#' @return A factor vector of assigned letter grades.
#' @export
grade_z_score <- function(scores, boundaries = c(A = 1.5, B = 0.5, C = -0.5, D = -1.5)) {
  if (length(scores) == 0) return(factor())
  
  s_mean <- mean(scores, na.rm = TRUE)
  s_sd <- sd(scores, na.rm = TRUE)
  
  if (s_sd == 0) s_sd <- 1
  z_scores <- (scores - s_mean) / s_sd
  
  # Sort boundaries in descending order
  bounds <- sort(boundaries, decreasing = TRUE)
  
  grades <- rep("F", length(scores))
  for (g_name in names(bounds)) {
    grades[z_scores >= bounds[g_name]] <- g_name
  }
  
  # Ensure the factor maintains logical order
  grade_levels <- c(names(bounds), "F")
  return(factor(grades, levels = rev(grade_levels), ordered = TRUE))
}

#' Percentile-based Grading
#'
#' @param scores Numeric vector of scores.
#' @param percentiles A named numeric vector of cumulative percentile thresholds (0 to 1) for each grade.
#'
#' @return A factor vector of assigned letter grades.
#' @export
grade_percentile <- function(scores, percentiles = c(A = 0.90, B = 0.75, C = 0.50, D = 0.25)) {
  if (length(scores) == 0) return(factor())
  
  ranks <- rank(scores, ties.method = "average")
  pct <- ranks / length(scores)
  
  bounds <- sort(percentiles, decreasing = TRUE)
  grades <- rep("F", length(scores))
  
  for (g_name in names(bounds)) {
    grades[pct >= bounds[g_name]] <- g_name
  }
  
  grade_levels <- c(names(bounds), "F")
  return(factor(grades, levels = rev(grade_levels), ordered = TRUE))
}

#' Linear Scaling (Min-Max Scaling)
#'
#' @param scores Numeric vector of scores.
#' @param target_min Numeric. New minimum score boundary.
#' @param target_max Numeric. New maximum score boundary.
#'
#' @return Numeric vector of scaled scores.
#' @export
grade_linear_scale <- function(scores, target_min = 50, target_max = 100) {
  s_min <- min(scores, na.rm = TRUE)
  s_max <- max(scores, na.rm = TRUE)
  
  if (s_max == s_min) {
    return(rep(target_max, length(scores)))
  }
  
  scaled <- target_min + (scores - s_min) * (target_max - target_min) / (s_max - s_min)
  return(scaled)
}

#' T-score Grading (Standardised score with Mean=50, SD=10)
#'
#' @param scores Numeric vector of scores.
#' @param min_grade Numeric. Minimum value clip.
#' @param max_grade Numeric. Maximum value clip.
#'
#' @return Numeric vector of T-scores.
#' @export
grade_t_score <- function(scores, min_grade = 20, max_grade = 80) {
  if (length(scores) < 2) return(rep(50, length(scores)))
  s_mean <- mean(scores, na.rm = TRUE)
  s_sd <- sd(scores, na.rm = TRUE)
  if (s_sd == 0) s_sd <- 1
  
  t_scores <- 50 + 10 * ((scores - s_mean) / s_sd)
  t_scores <- pmax(min_grade, pmin(max_grade, t_scores))
  return(t_scores)
}

#' Rank-based Institutional Grading
#'
#' @param scores Numeric vector.
#' @param class_size Numeric. Total number of students.
#' @param quotas Named list of grade quotas (e.g., A = 0.15, B = 0.30, C = 0.40, D = 0.10, F = 0.05).
#'
#' @return Factor vector of grades conforming to quota allocation.
#' @export
grade_quota_rank <- function(scores, quotas = list(A = 0.15, B = 0.30, C = 0.40, D = 0.10, F = 0.05)) {
  n <- length(scores)
  if (n == 0) return(factor())
  
  # Order from highest to lowest score
  ord <- order(scores, decreasing = TRUE)
  ranks <- match(1:n, ord)
  
  grades <- rep("F", n)
  
  # Calculate cumulative indices
  cumulative_limit <- 0
  for (g_name in names(quotas)) {
    quota <- quotas[[g_name]]
    limit <- round(n * quota)
    
    start_idx <- cumulative_limit + 1
    end_idx <- min(n, cumulative_limit + limit)
    
    if (start_idx <= n && end_idx >= start_idx) {
      grades[ord[start_idx:end_idx]] <- g_name
    }
    cumulative_limit <- cumulative_limit + limit
  }
  
  # Clean up any unassigned remaining due to rounding
  unassigned <- which(grades == "F" & !(ord %in% unassigned)) # Simple fallback
  
  grade_levels <- names(quotas)
  return(factor(grades, levels = rev(grade_levels), ordered = TRUE))
}
