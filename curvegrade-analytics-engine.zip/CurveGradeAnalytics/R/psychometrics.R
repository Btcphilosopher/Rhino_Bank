#' Psychometrics Engine
#'
#' @description Computes Cronbach's Alpha, item difficulty, and item discrimination.
#'
#' @importFrom stats var cor
#' @name psychometrics
NULL

#' Calculate Cronbach's Alpha
#'
#' @param items A data frame or matrix where columns are assessment items (questions) and rows are participants.
#'
#' @return A list with alpha coefficient, standard error, and item-deleted alpha.
#' @export
calculate_cronbach_alpha <- function(items) {
  items <- as.matrix(na.omit(items))
  k <- ncol(items)
  n <- nrow(items)
  
  if (k < 2) return(list(alpha = NA, message = "At least two items required"))
  
  # Calculate item variances and total scale variance
  item_vars <- apply(items, 2, var)
  total_scores <- rowSums(items)
  total_var <- var(total_scores)
  
  alpha <- (k / (k - 1)) * (1 - sum(item_vars) / total_var)
  
  # Item-deleted statistics
  item_deleted <- data.frame(
    Item = colnames(items),
    Item_Variance = item_vars,
    Corrected_Item_Total_Correlation = numeric(k),
    Alpha_If_Deleted = numeric(k),
    stringsAsFactors = FALSE
  )
  
  for (i in 1:k) {
    sub_items <- items[, -i, drop = FALSE]
    sub_total_scores <- rowSums(sub_items)
    
    # Corrected correlation
    item_deleted$Corrected_Item_Total_Correlation[i] <- cor(items[, i], sub_total_scores)
    
    # Alpha if deleted
    sub_k <- ncol(sub_items)
    sub_item_vars <- apply(sub_items, 2, var)
    sub_total_var <- var(sub_total_scores)
    item_deleted$Alpha_If_Deleted[i] <- (sub_k / (sub_k - 1)) * (1 - sum(sub_item_vars) / sub_total_var)
  }
  
  list(
    alpha = alpha,
    n_items = k,
    n_cases = n,
    item_analysis = item_deleted
  )
}

#' Item Difficulty and Discrimination Indices
#'
#' @param items A binary matrix of items (1 for correct, 0 for incorrect) or continuous item scores.
#' @param total_scores Numeric vector of total test scores. If NULL, calculated from items.
#'
#' @return A data frame containing difficulty and discrimination values.
#' @export
calculate_item_analysis <- function(items, total_scores = NULL) {
  items <- as.matrix(items)
  k <- ncol(items)
  n <- nrow(items)
  
  if (is.null(total_scores)) {
    total_scores <- rowSums(items, na.rm = TRUE)
  }
  
  # Item Difficulty (P-value: proportion correct or item mean / item max)
  difficulty <- apply(items, 2, function(col) {
    mean(col, na.rm = TRUE) / max(col, na.rm = TRUE)
  })
  
  # Item Discrimination (Point-biserial or item-total correlation)
  discrimination <- apply(items, 2, function(col) {
    cor(col, total_scores, use = "complete.obs")
  })
  
  data.frame(
    Item = colnames(items) %||% paste0("Item_", 1:k),
    Difficulty = difficulty,
    Discrimination = discrimination,
    Classification = ifelse(difficulty < 0.3, "Hard", ifelse(difficulty > 0.7, "Easy", "Moderate")),
    Quality = ifelse(discrimination < 0.15, "Poor - Revise/Remove", ifelse(discrimination < 0.3, "Marginal", "Excellent")),
    stringsAsFactors = FALSE
  )
}
