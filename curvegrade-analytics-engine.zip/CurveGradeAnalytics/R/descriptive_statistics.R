#' Descriptive Statistics Engine
#'
#' @description Computes key statistical measures, moments, and confidence intervals.
#'
#' @importFrom stats sd var quantile qt
#' @name descriptive_statistics
NULL

#' Compute All Descriptive Statistics
#'
#' @param x Numeric vector of scores.
#' @param conf_level Numeric. Confidence level for interval calculations (0 to 1). Default 0.95.
#'
#' @return A named list of descriptive statistics.
#' @export
calculate_descriptive_stats <- function(x, conf_level = 0.95) {
  x <- x[!is.na(x)]
  n <- length(x)
  if (n == 0) return(list())
  
  mean_val <- mean(x)
  median_val <- median(x)
  sd_val <- if (n > 1) sd(x) else 0
  var_val <- if (n > 1) var(x) else 0
  min_val <- min(x)
  max_val <- max(x)
  range_val <- max_val - min_val
  
  # Percentiles
  pcts <- quantile(x, probs = c(0.1, 0.25, 0.5, 0.75, 0.9))
  iqr_val <- pcts[["75%"]] - pcts[["25%"]]
  
  # Mode calculation
  ux <- unique(x)
  mode_val <- ux[which.max(tabulate(match(x, ux)))]
  
  # Skewness & Kurtosis
  skewness <- if (sd_val > 0 && n > 2) {
    (sum((x - mean_val)^3) / n) / (sd_val^3)
  } else {
    0
  }
  
  kurtosis <- if (sd_val > 0 && n > 3) {
    (sum((x - mean_val)^4) / n) / (sd_val^4) - 3
  } else {
    0
  }
  
  # Coefficient of Variation
  cv <- if (mean_val != 0) (sd_val / mean_val) * 100 else 0
  
  # Confidence Interval of the Mean
  se <- if (n > 1) sd_val / sqrt(n) else 0
  error_margin <- if (n > 1) qt(1 - (1 - conf_level)/2, df = n - 1) * se else 0
  ci_lower <- mean_val - error_margin
  ci_upper <- mean_val + error_margin
  
  list(
    n = n,
    mean = mean_val,
    median = median_val,
    mode = mode_val,
    sd = sd_val,
    variance = var_val,
    min = min_val,
    max = max_val,
    range = range_val,
    iqr = iqr_val,
    p10 = pcts[["10%"]],
    p25 = pcts[["25%"]],
    p75 = pcts[["75%"]],
    p90 = pcts[["90%"]],
    skewness = skewness,
    kurtosis = kurtosis,
    coeff_of_variation = cv,
    se_of_mean = se,
    ci_lower = ci_lower,
    ci_upper = ci_upper
  )
}
