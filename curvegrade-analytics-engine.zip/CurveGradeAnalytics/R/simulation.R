#' Cohort Simulation and Bootstrap Engine
#'
#' @description Generates synthetic cohorts, exam scores, item responses, and executes Monte Carlo simulations.
#'
#' @importFrom stats rnorm rlnorm rgamma runif rpois rbinom
#' @name simulation
NULL

#' Generate Synthetic Student Cohort
#'
#' @param size Integer. Size of the cohort.
#' @param mean Numeric. Average true ability score (e.g., 0-100). Default 72.
#' @param sd Numeric. Standard deviation of ability. Default 12.
#' @param n_items Integer. Number of items in simulated assessment. Default 50.
#' @param skewness Numeric. Skewness modifier (-1 for left, 0 for normal, 1 for right). Default 0.
#'
#' @return A list containing a dataframe of scores and a matrix of item responses.
#' @export
generate_cohort_data <- function(size = 500, mean = 72, sd = 12, n_items = 50, skewness = 0) {
  set.seed(42) # For reproducible results
  
  # Generate true scores
  if (skewness == 0) {
    scores <- rnorm(size, mean = mean, sd = sd)
  } else if (skewness < 0) {
    # Left-skewed (skewed towards higher scores)
    scores <- max(100) - rgamma(size, shape = 3, scale = sd / sqrt(3))
    scores <- normalize_min_max(scores, min_val = mean - 2.5*sd, max_val = mean + 1.5*sd)
  } else {
    # Right-skewed (skewed towards lower scores)
    scores <- rgamma(size, shape = 3, scale = sd / sqrt(3))
    scores <- normalize_min_max(scores, min_val = mean - 1.5*sd, max_val = mean + 2.5*sd)
  }
  
  # Ensure valid exam range
  scores <- pmax(0, pmin(100, scores))
  
  # Generate synthetic item responses
  item_difficulty <- runif(n_items, 0.2, 0.8) # Difficulty probability of correct response
  item_matrix <- matrix(0, nrow = size, ncol = n_items)
  colnames(item_matrix) <- paste0("Item_", 1:n_items)
  
  for (j in 1:n_items) {
    # Probability of correct answer increases with student's ability
    prob <- plogis((scores - mean) / sd + qlogis(item_difficulty[j]))
    item_matrix[, j] <- rbinom(size, 1, prob)
  }
  
  # Create final student demographic and score data
  df <- data.frame(
    StudentID = sprintf("STU%04d", 1:size),
    Gender = sample(c("Female", "Male", "Other"), size, replace = TRUE, prob = c(0.49, 0.48, 0.03)),
    Major = sample(c("Engineering", "Science", "Arts", "Business", "Medicine"), size, replace = TRUE),
    RawScore = round(scores, 1),
    CalculatedTotal = rowSums(item_matrix),
    stringsAsFactors = FALSE
  )
  
  list(
    students = df,
    item_responses = item_matrix
  )
}

#' Monte Carlo Grading Sensitivity Analysis
#'
#' @param base_scores Numeric vector of original scores.
#' @param simulations Integer. Number of iterations. Default 1000.
#' @param perturbation_sd Numeric. Standard deviation of measurement error added to scores. Default 2.
#' @param target_mean Numeric. Grading curve target mean. Default 75.
#'
#' @return A list containing sensitivity diagnostics and distributions of grades.
#' @export
run_monte_carlo_grading <- function(base_scores, simulations = 1000, perturbation_sd = 2, target_mean = 75) {
  n <- length(base_scores)
  grade_matrix <- matrix(0, nrow = n, ncol = simulations)
  
  for (i in 1:simulations) {
    # Introduce random test-day error/perturbation to ability
    noisy_scores <- base_scores + rnorm(n, mean = 0, sd = perturbation_sd)
    noisy_scores <- pmax(0, pmin(100, noisy_scores))
    
    # Run curve grading
    graded <- grade_bell_curve(noisy_scores, target_mean = target_mean, target_sd = 10)
    grade_matrix[, i] <- graded
  }
  
  # Compute statistical stability
  stability_metrics <- data.frame(
    StudentID = 1:n,
    OriginalScore = base_scores,
    ExpectedGradedScore = rowMeans(grade_matrix),
    GradedSD = apply(grade_matrix, 1, sd),
    LowerCI = apply(grade_matrix, 1, function(r) quantile(r, 0.025)),
    UpperCI = apply(grade_matrix, 1, function(r) quantile(r, 0.975))
  )
  
  list(
    simulations_data = grade_matrix,
    stability = stability_metrics
  )
}
