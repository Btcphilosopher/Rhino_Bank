#' Normalisation and Transformations
#'
#' @description Implements advanced scaling and normalization techniques for datasets.
#'
#' @importFrom stats median IQR
#' @name normalization
NULL

#' Min-Max Scaling
#'
#' @param x Numeric vector.
#' @param min_val Numeric. Desired minimum. Default 0.
#' @param max_val Numeric. Desired maximum. Default 1.
#'
#' @return Numeric vector scaled to [min_val, max_val]
#' @export
normalize_min_max <- function(x, min_val = 0, max_val = 1) {
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) return(rep(min_val, length(x)))
  (x - rng[1]) / (rng[2] - rng[1]) * (max_val - min_val) + min_val
}

#' Robust Scaling (using Median and IQR)
#'
#' @param x Numeric vector.
#'
#' @return Numeric vector scaled around median with IQR scale.
#' @export
normalize_robust <- function(x) {
  med <- median(x, na.rm = TRUE)
  iqr_val <- IQR(x, na.rm = TRUE)
  if (iqr_val == 0) iqr_val <- 1
  (x - med) / iqr_val
}

#' Box-Cox Transformation
#'
#' @param x Numeric vector. Must contain positive values only.
#' @param lambda Numeric value. Power transformation parameter.
#'
#' @return Transformed numeric vector.
#' @export
normalize_box_cox <- function(x, lambda) {
  if (any(x <= 0, na.rm = TRUE)) {
    stop("Box-Cox requires strictly positive values.")
  }
  if (lambda == 0) {
    log(x)
  } else {
    (x^lambda - 1) / lambda
  }
}

#' Quantile Normalisation
#'
#' @param df A data frame with numeric columns to normalize.
#'
#' @return A normalized data frame with identical distributions across columns.
#' @export
normalize_quantile <- function(df) {
  # Convert to matrix
  mat <- as.matrix(df)
  
  # Sort columns
  mat_sorted <- apply(mat, 2, sort)
  
  # Calculate row means of sorted matrix
  row_means <- rowMeans(mat_sorted)
  
  # Map means back to original ranks
  mat_normalized <- apply(mat, 2, function(x) {
    ranks <- rank(x, ties.method = "first")
    row_means[ranks]
  })
  
  as.data.frame(mat_normalized)
}
