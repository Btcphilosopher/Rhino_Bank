export interface Student {
  id: string;
  name: string;
  gender: 'Female' | 'Male' | 'Other';
  major: string;
  attendance: number; // 0 to 100
  studyHours: number; // hours per week
  midtermScore: number; // 0 to 100
  rawScore: number; // 0 to 100
  gradedScore?: number;
  letterGrade?: string;
  tScore?: number;
  normalizedScore?: number;
}

export interface DescriptiveStats {
  n: number;
  mean: number;
  median: number;
  mode: number;
  sd: number;
  variance: number;
  min: number;
  max: number;
  range: number;
  iqr: number;
  skewness: number;
  kurtosis: number;
  ciLower: number;
  ciUpper: number;
  se: number;
}

export interface ItemAnalysis {
  item: string;
  difficulty: number;
  discrimination: number;
  classification: 'Easy' | 'Moderate' | 'Hard';
  quality: 'Excellent' | 'Marginal' | 'Poor - Revise/Remove';
}

export interface CronbachResult {
  alpha: number;
  nItems: number;
  nCases: number;
  itemDeleted: {
    item: string;
    itemVariance: number;
    correctedCorrelation: number;
    alphaIfDeleted: number;
  }[];
}

export type GradingMethod = 'bell' | 'zscore' | 'percentile' | 'linear' | 'tscore' | 'quota';
export type NormalizationMethod = 'minmax' | 'zscore' | 'robust' | 'decimal' | 'log' | 'boxcox';
