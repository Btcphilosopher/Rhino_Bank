import React, { useState, useMemo, useEffect } from 'react';
import { Student, GradingMethod } from './types';
import { generateCohort, applyCurveGrading, calculatePsychometrics } from './utils/statistics';
import { 
  TrendingUp, Users, Award, BookOpen, SlidersHorizontal, Shuffle, 
  Scale, LineChart, Cpu, ShieldCheck, Activity, FileText, Settings, Sparkles, LogOut
} from 'lucide-react';

// Import panels
import ExecutiveSummary from './components/ExecutiveSummary';
import DatasetExplorer from './components/DatasetExplorer';
import DescriptiveStatistics from './components/DescriptiveStatistics';
import CurveGrading from './components/CurveGrading';
import NormalizationPanel from './components/NormalizationPanel';
import HypothesisTesting from './components/HypothesisTesting';
import RegressionModels from './components/RegressionModels';
import MachineLearningPanel from './components/MachineLearningPanel';
import PsychometricsPanel from './components/PsychometricsPanel';
import SimulationPanel from './components/SimulationPanel';
import ReportBuilderPanel from './components/ReportBuilderPanel';
import SettingsPanel from './components/SettingsPanel';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('summary');
  const [students, setStudents] = useState<Student[]>([]);
  const [currentMethod, setCurrentMethod] = useState<GradingMethod>('bell');

  // Load initial cohort dataset on mount
  useEffect(() => {
    const initialCohort = generateCohort(200, 68, 12, 'none');
    // Apply default curve grading (bell curve) to populate scores
    const graded = applyCurveGrading(initialCohort, 'bell', { targetMean: 75, targetSd: 10 });
    setStudents(graded);
  }, []);

  // Compute live reliability Alpha whenever students dataset changes
  const reliabilityAlpha = useMemo(() => {
    if (students.length === 0) return 0.75;
    const psych = calculatePsychometrics(students);
    return psych.cronbach.alpha;
  }, [students]);

  // Handle recreate cohort command from dataset explorer
  const handleRecreateCohort = (size: number, mean: number, sd: number, skew: 'none' | 'left' | 'right') => {
    const freshCohort = generateCohort(size, mean, sd, skew);
    const graded = applyCurveGrading(freshCohort, currentMethod, { targetMean: 75, targetSd: 10 });
    setStudents(graded);
  };

  // Handle applying a curve grade across the whole cohort
  const handleApplyCurve = (method: GradingMethod, config: any) => {
    setCurrentMethod(method);
    setStudents(prev => {
      return applyCurveGrading(prev, method, config);
    });
  };

  const navItems = [
    { id: 'summary', name: 'Executive Summary', icon: TrendingUp },
    { id: 'dataset', name: 'Dataset Explorer', icon: Users },
    { id: 'stats', name: 'Descriptive Stats', icon: BookOpen },
    { id: 'grading', name: 'Curve Grading', icon: SlidersHorizontal },
    { id: 'normalization', name: 'Normalisation', icon: Shuffle },
    { id: 'hypothesis', name: 'Hypothesis Testing', icon: Scale },
    { id: 'regression', name: 'Regression Models', icon: LineChart },
    { id: 'ml', name: 'Machine Learning', icon: Cpu },
    { id: 'psych', name: 'Psychometrics', icon: ShieldCheck },
    { id: 'simulation', name: 'Cohort Simulation', icon: Activity },
    { id: 'report', name: 'Report Builder', icon: FileText },
    { id: 'settings', name: 'R Package & Help', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col font-sans text-slate-200" id="applet-root">
      {/* Main Body with Sidebar Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 overflow-y-auto hidden md:flex">
          <div>
            {/* Sidebar Branding Header */}
            <div className="p-6 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-emerald-500 rounded-sm flex items-center justify-center font-bold text-slate-950 text-xl font-mono">∫</div>
                <div>
                  <h1 className="text-sm font-bold tracking-tight text-white uppercase">CurveGrade</h1>
                  <p className="text-[10px] text-slate-400 font-medium tracking-[0.2em] uppercase">Analytics Engine</p>
                </div>
              </div>
            </div>

            <div className="py-6 px-3 space-y-1">
              <span className="px-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Platform Modules</span>
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition-colors rounded-md ${
                      isActive 
                        ? 'bg-emerald-500/10 text-emerald-400 border-r-2 border-emerald-500 font-medium' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/20'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className="truncate">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sidebar Footer details */}
          <div className="p-4 border-t border-slate-800">
            <div className="bg-slate-950 rounded-md p-3">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-slate-500 uppercase font-bold">Engine Load</span>
                <span className="text-[10px] text-emerald-500 font-mono">14.2%</span>
              </div>
              <div className="w-full bg-slate-800 h-1 rounded-full">
                <div className="bg-emerald-500 w-[14%] h-full rounded-full"></div>
              </div>
            </div>
          </div>
        </aside>

        {/* Workspace panel area */}
        <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
          {/* Header */}
          <header className="h-16 border-b border-slate-800 bg-slate-900/50 px-8 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 uppercase tracking-wider font-bold">Project:</span>
                <span className="text-sm text-white font-medium">STAT301_Cohort_Analysis</span>
              </div>
              <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
              <div className="flex items-center gap-2 text-xs font-mono text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                ENGINE ONLINE
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right">
                <p className="text-[10px] text-slate-500 uppercase font-bold">Active Observations</p>
                <p className="text-sm font-mono text-white">{students.length}</p>
              </div>
              <div className="text-right hidden sm:block">
                <p className="text-[10px] text-slate-500 uppercase font-bold">Cronbach Alpha (α)</p>
                <p className="text-sm font-mono text-emerald-400">{reliabilityAlpha.toFixed(3)}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-slate-500 uppercase font-bold">Curve Curve</p>
                <p className="text-xs uppercase font-bold text-slate-300">{currentMethod}</p>
              </div>
            </div>
          </header>

          {/* Workspace scrollable area */}
          <main className="flex-1 p-6 overflow-y-auto">
            {/* Dynamic Render Page Panels */}
            {activeTab === 'summary' && <ExecutiveSummary students={students} reliabilityAlpha={reliabilityAlpha} />}
            {activeTab === 'dataset' && (
              <DatasetExplorer 
                students={students} 
                setStudents={setStudents} 
                onRecreateCohort={handleRecreateCohort} 
              />
            )}
            {activeTab === 'stats' && <DescriptiveStatistics students={students} />}
            {activeTab === 'grading' && (
              <CurveGrading 
                students={students} 
                onApplyCurve={handleApplyCurve} 
                currentMethod={currentMethod} 
              />
            )}
            {activeTab === 'normalization' && <NormalizationPanel students={students} />}
            {activeTab === 'hypothesis' && <HypothesisTesting students={students} />}
            {activeTab === 'regression' && <RegressionModels students={students} />}
            {activeTab === 'ml' && <MachineLearningPanel students={students} />}
            {activeTab === 'psych' && <PsychometricsPanel students={students} reliabilityAlpha={reliabilityAlpha} />}
            {activeTab === 'simulation' && <SimulationPanel students={students} />}
            {activeTab === 'report' && (
              <ReportBuilderPanel 
                students={students} 
                reliabilityAlpha={reliabilityAlpha} 
                currentMethod={currentMethod} 
              />
            )}
            {activeTab === 'settings' && <SettingsPanel />}
          </main>

          {/* Status Bar */}
          <footer className="h-8 border-t border-slate-800 bg-slate-900 px-6 flex items-center justify-between text-[10px] font-mono text-slate-500 shrink-0">
            <div className="flex gap-6 items-center">
              <span>ENV: R-4.3.1-Production</span>
              <span>LIBS: tidyverse, psych, caretaker, ggplot2</span>
              <span className="text-emerald-500">● MD5_CHECK_SUCCESS</span>
            </div>
            <div className="flex gap-4">
              <span>MEMORY: 1.4GB / 8GB</span>
              <span className="text-slate-400">v2.4.0-stable</span>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
