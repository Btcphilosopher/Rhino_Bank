import React, { useMemo, useState } from 'react';
import { Student } from '../types';
import { runHypothesisTest } from '../utils/statistics';
import { Award, Info, Scale } from 'lucide-react';

interface HypothesisTestingProps {
  students: Student[];
}

export default function HypothesisTesting({ students }: HypothesisTestingProps) {
  const [testType, setTestType] = useState<'ttest' | 'anova' | 'chisquare' | 'mannwhitney'>('ttest');

  const testResult = useMemo(() => {
    return runHypothesisTest(students, testType);
  }, [students, testType]);

  const testDescriptions = {
    ttest: 'One-Sample t-Test comparisons examine if the sample cohort raw mean significantly differs from a hypothesized value of 70 (representing historical baseline passing rates).',
    anova: 'One-Way Analysis of Variance (ANOVA) tests whether scores differ significantly across multiple student majors / departments (e.g. Computer Science, Math, Soft Eng).',
    chisquare: 'Chi-Square Test of Independence determines if there is a statistically significant association between demographic factors like gender and fields of study.',
    mannwhitney: 'Mann-Whitney U Test is a non-parametric equivalent to the independent t-test. It assesses if rank distributions of grades differ significantly between Female and Male cohorts.'
  };

  return (
    <div className="space-y-6" id="hypothesis-testing-panel">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Selection side */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 mb-2 border-b border-slate-800 pb-3">
            <Scale className="w-5 h-5 text-emerald-500" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Inference Engine</h4>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Select Hypothesis Test</label>
            <select
              value={testType}
              onChange={(e) => setTestType(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded text-slate-200 focus:outline-hidden focus:border-emerald-500 font-mono"
            >
              <option value="ttest">One-Sample t-Test (vs μ=70)</option>
              <option value="anova">One-Way ANOVA (Cross-Major)</option>
              <option value="chisquare">Chi-Square Independence (Gender vs Major)</option>
              <option value="mannwhitney">Mann-Whitney U Test (Gender Differences)</option>
            </select>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800 flex items-start space-x-2.5">
            <Info className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-slate-400">
              {testDescriptions[testType]}
            </p>
          </div>
        </div>

        {/* Academic Output Console */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Statistical Analysis Terminal Output</h4>
            <span className="text-[10px] font-mono bg-slate-950 border border-slate-800 text-slate-400 px-2 py-0.5 rounded">R-style console output</span>
          </div>

          {/* R console mimic box */}
          <div className="bg-slate-950 text-slate-200 font-mono p-5 rounded border border-slate-800 text-xs space-y-3 leading-relaxed shadow-inner overflow-x-auto">
            <p className="text-slate-500"># Executing: {testResult.testName}</p>
            <p className="text-slate-700 font-bold">----------------------------------------------------</p>
            <p>Data: current_cohort$raw_scores</p>
            <p>Test Statistic: <span className="text-emerald-400 font-bold">{testResult.statistic}</span></p>
            {testResult.df !== undefined && (
              <p>Degrees of Freedom (df): {testResult.df} {testResult.df2 !== undefined ? `, Error df: ${testResult.df2}` : ''}</p>
            )}
            <p>p-value: <span className={testResult.pValue < 0.05 ? "text-emerald-400 font-bold" : "text-amber-500"}>{testResult.pValue}</span></p>
            <p>Significance Level: alpha = 0.05</p>
            <p className="text-slate-500"># Clinical / Academic Interpretation:</p>
            <p className="text-slate-300 border-l-2 border-emerald-500 pl-3 italic">
              "{testResult.interpretation}"
            </p>
          </div>

          {/* Graphical summary */}
          <div className="p-4 rounded border border-slate-800 bg-slate-950 flex items-center space-x-4">
            <div className={`p-3 rounded-md ${testResult.pValue < 0.05 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-500 border border-slate-700'}`}>
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Hypothesis Outcome Conclusion</h5>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                {testResult.pValue < 0.05 
                  ? 'The result is statistically significant. We reject the null hypothesis at the 5% margin, confirming active differences or effects in the population.' 
                  : 'The result is not statistically significant. We fail to reject the null hypothesis, indicating insufficient evidence to conclude any difference or correlation.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
