import React, { useMemo } from 'react';
import { Student } from '../types';
import { calculatePsychometrics } from '../utils/statistics';
import { ShieldCheck, Info, Sparkles, HelpCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface PsychometricsPanelProps {
  students: Student[];
  reliabilityAlpha: number;
}

export default function PsychometricsPanel({ students, reliabilityAlpha }: PsychometricsPanelProps) {
  const psychResult = useMemo(() => {
    return calculatePsychometrics(students);
  }, [students]);

  return (
    <div className="space-y-6" id="psychometrics-panel">
      {/* Overview stats cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Scale Alpha (α)</p>
            <h3 className="text-xl font-bold font-mono text-white">{psychResult.cronbach.alpha}</h3>
            <span className="text-[10px] text-slate-400">Standardized Cronbach index</span>
          </div>
        </div>

        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Cronbach Quality Status</p>
            <h3 className="text-base font-bold text-white">
              {psychResult.cronbach.alpha >= 0.8 ? 'Excellent Fit' : psychResult.cronbach.alpha >= 0.7 ? 'Highly Acceptable' : 'Marginal Consistency'}
            </h3>
            <span className="text-[10px] text-slate-400">Test structural integrity score</span>
          </div>
        </div>

        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Assessment Questions</p>
            <h3 className="text-xl font-bold font-mono text-white">{psychResult.cronbach.nItems} Items</h3>
            <span className="text-[10px] text-slate-400">Evaluated parameters</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Difficulties/Discrimination Comparison */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Item Parameters Chart</h4>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">plot_item</span>
          </div>
          <p className="text-[11px] text-slate-500 mb-4">Item Difficulty (proportion correct) vs. Discrimination (how well the item distinguishes top vs. bottom students).</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={psychResult.itemAnalysis} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="item" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                <Bar dataKey="difficulty" name="Difficulty Index" fill="#10b981" radius={[2, 2, 0, 0]} />
                <Bar dataKey="discrimination" name="Discrimination index" fill="#a855f7" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alpha Deleted side card */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Item-Deleted Analysis</h4>
              <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">alpha_del</span>
            </div>
            <p className="text-[11px] text-slate-500 mb-4">Shows what the Cronbach's Alpha would be if that particular question was removed from the test scale.</p>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {psychResult.cronbach.itemDeleted.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center text-[10px] bg-slate-950 p-2 rounded border border-slate-800 font-mono">
                  <span className="font-semibold text-slate-300">{item.item}</span>
                  <div className="space-x-3 text-right text-slate-400">
                    <span>r-tot: <strong className="text-emerald-400">{item.correctedCorrelation}</strong></span>
                    <span>α: <strong className={item.alphaIfDeleted > psychResult.cronbach.alpha ? "text-red-400" : "text-emerald-400"}>{item.alphaIfDeleted}</strong></span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-start space-x-2">
            <Info className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-[11px] text-slate-400 leading-normal">
              If removing an item increases Alpha (shown in red), that question may be confusing or poorly constructed. Removing it would increase overall test reliability.
            </p>
          </div>
        </div>
      </div>

      {/* Item Analysis Table */}
      <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Detailed Item Quality Audit</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-medium">
                <th className="p-4 uppercase tracking-wider text-[10px]">Item Name</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Difficulty (p-value)</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Discrimination (r-pb)</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Classification</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Recommendation Quality</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {psychResult.itemAnalysis.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition text-slate-300">
                  <td className="p-4 font-semibold text-white">{item.item}</td>
                  <td className="p-4 text-center font-mono">{item.difficulty.toFixed(2)}</td>
                  <td className="p-4 text-center font-mono">{item.discrimination.toFixed(2)}</td>
                  <td className="p-4 text-center">
                    <span className={`inline-block px-2.5 py-0.5 rounded-sm font-semibold text-[10px] ${
                      item.classification === 'Easy' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                      item.classification === 'Hard' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                      'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}>
                      {item.classification}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <span className={`inline-block px-2.5 py-0.5 rounded-sm font-semibold text-[10px] ${
                      item.quality === 'Excellent' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                      item.quality === 'Marginal' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                      'bg-red-500/20 text-red-300 border border-red-500/30'
                    }`}>
                      {item.quality}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
