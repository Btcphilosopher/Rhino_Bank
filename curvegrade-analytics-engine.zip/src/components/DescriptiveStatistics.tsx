import React, { useMemo } from 'react';
import { Student } from '../types';
import { getDescriptiveStats } from '../utils/statistics';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface DescriptiveStatisticsProps {
  students: Student[];
}

export default function DescriptiveStatistics({ students }: DescriptiveStatisticsProps) {
  const stats = useMemo(() => {
    const rawScores = students.map(s => s.rawScore);
    return getDescriptiveStats(rawScores);
  }, [students]);

  const metricCards = [
    { name: 'Mean (Average)', value: stats.mean.toFixed(2), desc: 'Mathematical expectation of raw assessment score.' },
    { name: 'Median (P50)', value: stats.median.toFixed(2), desc: 'Middle value of the sorted dataset.' },
    { name: 'Mode (Most Frequent)', value: stats.mode.toFixed(1), desc: 'Value with the highest frequency density.' },
    { name: 'Standard Deviation (SD)', value: stats.sd.toFixed(2), desc: 'Standard measure of dispersion around the mean.' },
    { name: 'Variance (σ²)', value: stats.variance.toFixed(2), desc: 'Second statistical moment representing spread.' },
    { name: 'Range (Max-Min)', value: stats.range.toFixed(1), desc: 'Span of scores across the student cohort.' },
    { name: 'Interquartile Range (IQR)', value: stats.iqr.toFixed(2), desc: 'Dispersion of the middle 50% of students.' },
    { name: 'Standard Error (SE)', value: stats.se.toFixed(3), desc: 'Precision of sample mean relative to population.' },
    { name: 'Skewness (Symmetry)', value: stats.skewness.toFixed(3), desc: 'Measure of asymmetry. Negative = Left tail, Positive = Right tail.' },
    { name: 'Kurtosis (Tails)', value: stats.kurtosis.toFixed(3), desc: 'Measure of tail weight relative to normal curve (3).' },
  ];

  // Distribution bins for bar chart
  const histogramData = useMemo(() => {
    const bins = Array.from({ length: 10 }, (_, i) => ({
      range: `${i * 10}-${i * 10 + 9}`,
      center: i * 10 + 5,
      frequency: 0
    }));

    students.forEach(s => {
      const binIdx = Math.min(9, Math.floor(s.rawScore / 10));
      bins[binIdx].frequency++;
    });

    return bins;
  }, [students]);

  return (
    <div className="space-y-6" id="descriptive-statistics-panel">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {metricCards.map((card, i) => (
          <div key={i} className="bg-slate-900 p-4 rounded-lg border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">{card.name}</span>
              <p className="text-xl font-mono text-white">{card.value}</p>
            </div>
            <p className="text-[10px] text-slate-400 leading-snug mt-2 pt-2 border-t border-slate-800">{card.desc}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Frequency Histogram with Mean/Median Reference Lines */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Frequency Histogram with Statistical Intercepts</h4>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">stat_bin</span>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={histogramData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="range" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                <Bar dataKey="frequency" fill="#10b981" fillOpacity={0.8} radius={[2, 2, 0, 0]} name="Frequency" />
                
                {/* Reference Lines for Mean, Median */}
                <ReferenceLine x={`${Math.min(9, Math.floor(stats.mean / 10)) * 10}-${Math.min(9, Math.floor(stats.mean / 10)) * 10 + 9}`} stroke="#10b981" strokeDasharray="5 5" strokeWidth={2} label={{ value: `Mean: ${stats.mean.toFixed(1)}`, position: 'top', fill: '#10b981', fontSize: 11, fontWeight: 'bold' }} />
                <ReferenceLine x={`${Math.min(9, Math.floor(stats.median / 10)) * 10}-${Math.min(9, Math.floor(stats.median / 10)) * 10 + 9}`} stroke="#f59e0b" strokeDasharray="3 3" strokeWidth={2} label={{ value: `Median: ${stats.median.toFixed(1)}`, position: 'bottom', fill: '#f59e0b', fontSize: 11, fontWeight: 'bold' }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Confidence Intervals & Moments */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 border-b border-slate-800 pb-3">95% Confidence Interval (CI) of Mean</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-6">
              Using standard error of the mean (SE = {stats.se.toFixed(3)}), we calculate the range where the population mean resides with 95% certainty.
            </p>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Lower Bound (95%)</span>
                <span className="font-bold font-mono text-emerald-400">{stats.ciLower.toFixed(2)}%</span>
              </div>
              <div className="w-full bg-slate-950 border border-slate-800 h-2 rounded-full relative">
                <div 
                  className="bg-emerald-500/20 border border-emerald-500/50 h-[6px] rounded-full absolute top-[1px]" 
                  style={{ 
                    left: `${Math.max(0, stats.ciLower - 10)}%`, 
                    right: `${100 - Math.min(100, stats.ciUpper + 10)}%` 
                  }}
                />
                <div 
                  className="w-3 h-3 bg-emerald-400 rounded-full absolute -top-[2px] border-2 border-slate-950"
                  style={{ left: `${stats.mean}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Upper Bound (95%)</span>
                <span className="font-bold font-mono text-emerald-400">{stats.ciUpper.toFixed(2)}%</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <h5 className="text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-2">Moment Analysis Definitions</h5>
            <ul className="space-y-1.5 text-[11px] text-slate-400 list-disc list-inside">
              <li><strong>Skewness &lt; -0.5</strong>: Moderate left skew. Majority scored highly.</li>
              <li><strong>Skewness &gt; 0.5</strong>: Moderate right skew. Exam was difficult.</li>
              <li><strong>Kurtosis &gt; 0</strong>: Leptokurtic. High concentration around mean.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
