import React, { useMemo } from 'react';
import { Student, DescriptiveStats } from '../types';
import { getDescriptiveStats } from '../utils/statistics';
import { TrendingUp, Users, Award, BookOpen, ShieldAlert } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

interface ExecutiveSummaryProps {
  students: Student[];
  reliabilityAlpha: number;
}

export default function ExecutiveSummary({ students, reliabilityAlpha }: ExecutiveSummaryProps) {
  const stats = useMemo(() => {
    const rawScores = students.map(s => s.rawScore);
    return getDescriptiveStats(rawScores);
  }, [students]);

  const gradedStats = useMemo(() => {
    const gradedScores = students.map(s => s.gradedScore || s.rawScore);
    return getDescriptiveStats(gradedScores);
  }, [students]);

  const passRate = useMemo(() => {
    const passCount = students.filter(s => (s.gradedScore || s.rawScore) >= 60).length;
    return students.length > 0 ? (passCount / students.length) * 100 : 0;
  }, [students]);

  // Construct distribution dataset for chart
  const distributionData = useMemo(() => {
    const bins = Array.from({ length: 10 }, (_, i) => ({
      range: `${i * 10}-${i * 10 + 9}`,
      rawCount: 0,
      gradedCount: 0
    }));

    students.forEach(s => {
      const rawBinIdx = Math.min(9, Math.floor(s.rawScore / 10));
      const gradedBinIdx = Math.min(9, Math.floor((s.gradedScore || s.rawScore) / 10));
      bins[rawBinIdx].rawCount++;
      bins[gradedBinIdx].gradedCount++;
    });

    return bins;
  }, [students]);

  return (
    <div className="space-y-6" id="executive-summary-panel">
      {/* Top Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-slate-950 text-slate-400 rounded-sm">
            <Users className="w-5 h-5 text-slate-400" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Total Cohort</p>
            <h3 className="text-2xl font-mono font-light text-white">{stats.n}</h3>
            <span className="text-[10px] text-slate-400">Active Students</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-slate-950 text-slate-400 rounded-sm">
            <Award className="w-5 h-5 text-slate-400" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Mean Raw Score</p>
            <h3 className="text-2xl font-mono font-light text-white">{stats.mean.toFixed(1)}%</h3>
            <span className="text-[10px] text-slate-400">SD: {stats.sd.toFixed(1)}</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-slate-950 text-emerald-500 rounded-sm">
            <TrendingUp className="w-5 h-5 text-emerald-500" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Mean Graded</p>
            <h3 className="text-2xl font-mono font-light text-emerald-400">{gradedStats.mean.toFixed(1)}%</h3>
            <span className="text-[10px] text-slate-400">SD: {gradedStats.sd.toFixed(1)}</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-slate-950 text-slate-400 rounded-sm">
            <BookOpen className="w-5 h-5 text-slate-400" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Passing Rate</p>
            <h3 className="text-2xl font-mono font-light text-white">{passRate.toFixed(1)}%</h3>
            <span className="text-[10px] text-slate-400">Score &gt;= 60</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-slate-950 text-emerald-500 rounded-sm">
            <ShieldAlert className="w-5 h-5 text-emerald-500" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Reliability Alpha</p>
            <h3 className="text-2xl font-mono font-light text-emerald-400">{reliabilityAlpha.toFixed(2)}</h3>
            <span className="text-[10px] text-slate-400">Cronbach's Index</span>
          </div>
        </div>
      </div>

      {/* Main Charts area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Score distribution area chart */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Score Distribution Comparison (Raw vs Graded)</h4>
            <div className="flex gap-2">
              <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">ggplot2-render</span>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={distributionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRaw" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#475569" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#475569" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorGraded" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="range" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                <Area type="monotone" dataKey="rawCount" name="Raw Frequency" stroke="#64748b" strokeWidth={2} fillOpacity={1} fill="url(#colorRaw)" />
                <Area type="monotone" dataKey="gradedCount" name="Graded Frequency" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorGraded)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Analytical Comments */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 border-b border-slate-800 pb-3">Psychometric Diagnostics</h4>
            <div className="space-y-4">
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-md text-[11px] leading-relaxed text-slate-400">
                <span className="font-bold text-slate-300 uppercase block mb-1 tracking-wider text-[10px]">Scale Reliability Status:</span>
                An Alpha of <strong className="text-emerald-400 font-mono">{reliabilityAlpha.toFixed(3)}</strong> indicates {reliabilityAlpha >= 0.8 ? 'excellent internal consistency and highly reliable test parameters.' : reliabilityAlpha >= 0.7 ? 'acceptable scale consistency suitable for academic assessments.' : 'moderate/weak reliability. Item review is highly recommended to improve validation.'}
              </div>
              
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-md text-[11px] leading-relaxed text-slate-400">
                <span className="font-bold text-slate-300 uppercase block mb-1 tracking-wider text-[10px]">Standard Distribution Fit:</span>
                The current raw distribution has a skewness of <strong className="text-slate-200 font-mono">{stats.skewness.toFixed(2)}</strong> and a kurtosis of <strong className="text-slate-200 font-mono">{stats.kurtosis.toFixed(2)}</strong>. {Math.abs(stats.skewness) < 0.5 ? 'This resembles a highly symmetrical, balanced bell-shaped distribution ideal for standardized z-grading.' : 'This exhibits skewness. Normalization or robust linear scaling might yield fairer outcomes.'}
              </div>

              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-md text-[11px] leading-relaxed text-slate-400">
                <span className="font-bold text-slate-300 uppercase block mb-1 tracking-wider text-[10px]">Cohort Performance Summary:</span>
                Average raw exam marks sit at <strong className="text-slate-200 font-mono">{stats.mean.toFixed(1)}%</strong>. Curve grading adjusted this to <strong className="text-emerald-400 font-mono">{gradedStats.mean.toFixed(1)}%</strong>, resulting in a passing rate change to <strong className="text-emerald-400 font-mono">{passRate.toFixed(1)}%</strong>.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
