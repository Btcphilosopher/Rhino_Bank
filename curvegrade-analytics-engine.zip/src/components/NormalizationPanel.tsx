import React, { useMemo, useState } from 'react';
import { Student, NormalizationMethod } from '../types';
import { applyNormalization, getDescriptiveStats } from '../utils/statistics';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Shuffle, Info } from 'lucide-react';

interface NormalizationPanelProps {
  students: Student[];
}

export default function NormalizationPanel({ students }: NormalizationPanelProps) {
  const [method, setMethod] = useState<NormalizationMethod>('minmax');
  const [lambda, setLambda] = useState(0.5);

  const rawScores = useMemo(() => students.map(s => s.rawScore), [students]);

  // Apply Normalization Transformation
  const transformedScores = useMemo(() => {
    return applyNormalization(rawScores, method, lambda);
  }, [rawScores, method, lambda]);

  const rawStats = useMemo(() => getDescriptiveStats(rawScores), [rawScores]);
  const transformedStats = useMemo(() => getDescriptiveStats(transformedScores), [transformedScores]);

  // Comparison Bins for chart
  const distributionData = useMemo(() => {
    // Generate 12 steps along the normalization scale
    const minVal = transformedStats.min;
    const maxVal = transformedStats.max;
    const step = (maxVal - minVal) / 10 || 1;

    const bins = Array.from({ length: 11 }, (_, i) => {
      const edge = minVal + i * step;
      return {
        label: edge.toFixed(2),
        count: 0
      };
    });

    transformedScores.forEach(val => {
      let binIdx = Math.floor((val - minVal) / step);
      binIdx = Math.max(0, Math.min(10, binIdx));
      bins[binIdx].count++;
    });

    return bins;
  }, [transformedScores, transformedStats]);

  const explanations = {
    minmax: 'Rescales the scores to reside precisely within [0, 1]. Extremely useful for neural networks and comparative percentiles.',
    zscore: 'Standardizes the scale around a mean of 0 and SD of 1. Expresses student scores in units of standard deviation.',
    robust: 'Uses median and Interquartile Range (IQR) rather than mean and SD. Highly resilient against outlier distortions.',
    decimal: 'Moves decimal points based on standard maximum absolute values. Retains simple order scaling.',
    log: 'Applies natural log transform ln(x+1). Squeezes high-end scores and spreads lower-end scores to counteract negative skewness.',
    boxcox: 'Advanced power transform (x^λ - 1)/λ. Dynamically corrects skewness by adjusting the lambda factor.'
  };

  return (
    <div className="space-y-6" id="normalization-panel">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Method selection panel */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 mb-2 border-b border-slate-800 pb-3">
            <Shuffle className="w-5 h-5 text-emerald-500" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Data Transformation Engine</h4>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Normalization Method</label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as NormalizationMethod)}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded text-slate-200 focus:outline-hidden focus:border-emerald-500 font-mono"
            >
              <option value="minmax">Min-Max Scaling [0, 1]</option>
              <option value="zscore">Z-Score Standardization (μ=0, σ=1)</option>
              <option value="robust">Robust Scaling (Median/IQR)</option>
              <option value="decimal">Decimal Scaling</option>
              <option value="log">Log Transformation ln(x+1)</option>
              <option value="boxcox">Box-Cox Power Transformation</option>
            </select>
          </div>

          {method === 'boxcox' && (
            <div>
              <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Lambda (λ) Value: {lambda}</label>
              <input 
                type="range" 
                min="-2" 
                max="2" 
                step="0.1" 
                value={lambda}
                onChange={(e) => setLambda(parseFloat(e.target.value))}
                className="w-full accent-emerald-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>-2 (Inversion)</span>
                <span>0 (Log)</span>
                <span>1 (Linear)</span>
                <span>2 (Square)</span>
              </div>
            </div>
          )}

          <div className="bg-slate-950 p-4 rounded border border-slate-800 flex items-start space-x-2.5">
            <Info className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-slate-400">
              {explanations[method]}
            </p>
          </div>
        </div>

        {/* Transformed distribution visualization */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Transformed Feature Space Density</h4>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">density_plot</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={distributionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTransformed" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="label" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                <Area type="monotone" dataKey="count" name="Frequency" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorTransformed)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Comparisons Stats */}
      <div className="bg-slate-900 p-6 rounded-lg border border-slate-800">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 border-b border-slate-800 pb-3">Moment Adjustments Summary</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div>
            <h5 className="font-bold text-slate-400 uppercase tracking-wider text-[10px] mb-2">Original Raw Moments</h5>
            <div className="space-y-2 bg-slate-950 p-3.5 rounded border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-500">Mean Score</span>
                <span className="font-mono text-slate-200">{rawStats.mean.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Standard Deviation (SD)</span>
                <span className="font-mono text-slate-200">{rawStats.sd.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Skewness</span>
                <span className="font-mono text-slate-200">{rawStats.skewness.toFixed(3)}</span>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-bold text-emerald-400 uppercase tracking-wider text-[10px] mb-2">Normalized Moments</h5>
            <div className="space-y-2 bg-slate-950 p-3.5 rounded border border-emerald-500/20">
              <div className="flex justify-between">
                <span className="text-slate-500">Mean Scale</span>
                <span className="font-mono text-emerald-400">{transformedStats.mean.toFixed(4)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Standard Deviation (SD)</span>
                <span className="font-mono text-emerald-400">{transformedStats.sd.toFixed(4)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Skewness</span>
                <span className="font-mono text-emerald-400">{transformedStats.skewness.toFixed(3)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
