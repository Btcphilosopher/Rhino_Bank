import React, { useMemo, useState } from 'react';
import { Student, GradingMethod } from '../types';
import { applyCurveGrading, getDescriptiveStats } from '../utils/statistics';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Sparkles, SlidersHorizontal, CheckSquare, Settings } from 'lucide-react';

interface CurveGradingProps {
  students: Student[];
  onApplyCurve: (method: GradingMethod, config: any) => void;
  currentMethod: GradingMethod;
}

export default function CurveGrading({ students, onApplyCurve, currentMethod }: CurveGradingProps) {
  // Config states
  const [targetMean, setTargetMean] = useState(75);
  const [targetSd, setTargetSd] = useState(10);
  const [targetMin, setTargetMin] = useState(50);
  const [targetMax, setTargetMax] = useState(100);
  const [minGrade, setMinGrade] = useState(0);
  const [maxGrade, setMaxGrade] = useState(100);
  const [inflationControl, setInflationControl] = useState(false);

  // Quotas for quota method
  const [quotaA, setQuotaA] = useState(0.15);
  const [quotaB, setQuotaB] = useState(0.30);
  const [quotaC, setQuotaC] = useState(0.40);
  const [quotaD, setQuotaD] = useState(0.10);

  const rawStats = useMemo(() => {
    return getDescriptiveStats(students.map(s => s.rawScore));
  }, [students]);

  // Handle live calculation of curved grades just for visualization
  const liveCurvedStudents = useMemo(() => {
    const quotasObj = { A: quotaA, B: quotaB, C: quotaC, D: quotaD, F: 1 - (quotaA + quotaB + quotaC + quotaD) };
    return applyCurveGrading(students, currentMethod, {
      targetMean,
      targetSd,
      targetMin,
      targetMax,
      minGrade,
      maxGrade,
      inflationControl,
      quotas: quotasObj
    });
  }, [students, currentMethod, targetMean, targetSd, targetMin, targetMax, minGrade, maxGrade, inflationControl, quotaA, quotaB, quotaC, quotaD]);

  const curvedStats = useMemo(() => {
    return getDescriptiveStats(liveCurvedStudents.map(s => s.gradedScore || s.rawScore));
  }, [liveCurvedStudents]);

  // Construct scatter data: original raw score vs. new curved score
  const scatterData = useMemo(() => {
    return liveCurvedStudents.map(s => ({
      name: s.name,
      raw: s.rawScore,
      curved: s.gradedScore || s.rawScore,
      grade: s.letterGrade
    }));
  }, [liveCurvedStudents]);

  // Distribution of Letter Grades
  const letterGradeDistribution = useMemo(() => {
    const counts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, F: 0 };
    liveCurvedStudents.forEach(s => {
      if (s.letterGrade) {
        counts[s.letterGrade] = (counts[s.letterGrade] || 0) + 1;
      }
    });

    return Object.keys(counts).map(key => ({
      grade: key,
      percentage: liveCurvedStudents.length > 0 ? (counts[key] / liveCurvedStudents.length) * 100 : 0,
      count: counts[key]
    }));
  }, [liveCurvedStudents]);

  const triggerApply = () => {
    const quotasObj = { A: quotaA, B: quotaB, C: quotaC, D: quotaD, F: 1 - (quotaA + quotaB + quotaC + quotaD) };
    onApplyCurve(currentMethod, {
      targetMean,
      targetSd,
      targetMin,
      targetMax,
      minGrade,
      maxGrade,
      inflationControl,
      quotas: quotasObj
    });
  };

  return (
    <div className="space-y-6" id="curve-grading-panel">
      {/* Parameters Sidebar + Method Selection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Method selection & specific configs */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 mb-2 border-b border-slate-800 pb-3">
            <SlidersHorizontal className="w-5 h-5 text-emerald-500" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Grading System Controls</h4>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Select Curve Methodology</label>
            <select
              value={currentMethod}
              onChange={(e) => onApplyCurve(e.target.value as GradingMethod, {})}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded text-slate-200 focus:outline-hidden focus:border-emerald-500 font-mono"
            >
              <option value="bell">Standard Bell Curve (Normal Scaling)</option>
              <option value="zscore">Z-Score Boundaries (Standardized)</option>
              <option value="percentile">Percentile Scaling (Rank Percentiles)</option>
              <option value="linear">Linear Scaling (Min-Max Mapping)</option>
              <option value="tscore">T-Score Conversion (M=50, SD=10)</option>
              <option value="quota">Quota Rank-Based (Fixed Caps)</option>
            </select>
          </div>

          {/* Conditional Method Parameters */}
          {currentMethod === 'bell' && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Target Mean</label>
                  <input
                    type="number"
                    value={targetMean}
                    onChange={(e) => setTargetMean(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Target SD</label>
                  <input
                    type="number"
                    value={targetSd}
                    onChange={(e) => setTargetSd(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Min Grade</label>
                  <input
                    type="number"
                    value={minGrade}
                    onChange={(e) => setMinGrade(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Max Grade</label>
                  <input
                    type="number"
                    value={maxGrade}
                    onChange={(e) => setMaxGrade(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="inflation"
                  checked={inflationControl}
                  onChange={(e) => setInflationControl(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-emerald-500"
                />
                <label htmlFor="inflation" className="text-xs text-slate-400 select-none">
                  Enable Grade Inflation Controls
                </label>
              </div>
            </div>
          )}

          {currentMethod === 'linear' && (
            <div className="grid grid-cols-2 gap-2 pt-2">
              <div>
                <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Target Min Map</label>
                <input
                  type="number"
                  value={targetMin}
                  onChange={(e) => setTargetMin(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Target Max Map</label>
                <input
                  type="number"
                  value={targetMax}
                  onChange={(e) => setTargetMax(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          {currentMethod === 'quota' && (
            <div className="space-y-3 pt-2">
              <p className="text-[10px] text-slate-500">Specify fixed percentile quotas for each tier.</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">A Quota (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={quotaA}
                    onChange={(e) => setQuotaA(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">B Quota (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={quotaB}
                    onChange={(e) => setQuotaB(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">C Quota (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={quotaC}
                    onChange={(e) => setQuotaC(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">D Quota (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={quotaD}
                    onChange={(e) => setQuotaD(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>
              <div className="text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800">
                F quota will absorb the remaining: <strong className="text-emerald-400 font-mono">{(100 * (1 - (quotaA + quotaB + quotaC + quotaD))).toFixed(0)}%</strong> of students.
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={triggerApply}
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded uppercase tracking-wider transition-colors flex items-center justify-center space-x-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Apply Grading Parameters</span>
            </button>
          </div>
        </div>

        {/* Live grade translation scatter plot */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-3">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Quantile Shifting (Raw vs Curved Scores)</h4>
              <p className="text-[11px] text-slate-500">Each dot is a student. Observe how raw marks map onto standard curves.</p>
            </div>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">geom_point</span>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis type="number" dataKey="raw" name="Raw Score" unit="%" stroke="#64748b" fontSize={11} domain={[30, 100]} />
                <YAxis type="number" dataKey="curved" name="Curved Score" unit="%" stroke="#64748b" fontSize={11} domain={[30, 100]} />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                <Scatter name="Students" data={scatterData} fill="#10b981" shape="circle" />
                <ReferenceLine x={rawStats.mean} stroke="#64748b" strokeDasharray="3 3" label={{ value: 'Raw Mean', fill: '#64748b', fontSize: 10, position: 'top' }} />
                <ReferenceLine y={curvedStats.mean} stroke="#10b981" strokeDasharray="3 3" label={{ value: 'Curved Mean', fill: '#10b981', fontSize: 10, position: 'left' }} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Grade allocation metrics */}
      <div className="bg-slate-900 p-6 rounded-lg border border-slate-800">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 border-b border-slate-800 pb-3">Grade Allocation Quotas & Quantities</h4>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {letterGradeDistribution.map((tier) => (
            <div key={tier.grade} className="p-4 rounded-lg border border-slate-800 bg-slate-950 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Grade {tier.grade}</span>
                <p className="text-xl font-bold font-mono text-white">{tier.count} <span className="text-xs font-normal text-slate-400">Students</span></p>
              </div>
              <div className="mt-2 pt-2 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
                <span>Allocation</span>
                <span className="font-semibold text-emerald-400 font-mono">{tier.percentage.toFixed(1)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
