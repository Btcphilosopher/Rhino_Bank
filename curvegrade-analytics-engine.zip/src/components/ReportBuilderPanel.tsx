import React, { useMemo, useState } from 'react';
import { Student } from '../types';
import { getDescriptiveStats } from '../utils/statistics';
import { Printer, Calendar, FileText, FileCheck } from 'lucide-react';

interface ReportBuilderPanelProps {
  students: Student[];
  reliabilityAlpha: number;
  currentMethod: string;
}

export default function ReportBuilderPanel({ students, reliabilityAlpha, currentMethod }: ReportBuilderPanelProps) {
  const [institutionName, setInstitutionName] = useState('Standard University School of Science');
  const [courseName, setCourseName] = useState('STAT301 - Advanced Quantitative Analysis');
  const [professorName, setProfessorName] = useState('Dr. Marcus Vance, PhD');
  const [signatureLine, setSignatureLine] = useState('Dean of Academic Affairs');

  const stats = useMemo(() => {
    return getDescriptiveStats(students.map(s => s.rawScore));
  }, [students]);

  const curvedStats = useMemo(() => {
    return getDescriptiveStats(students.map(s => s.gradedScore || s.rawScore));
  }, [students]);

  const passRate = useMemo(() => {
    const passCount = students.filter(s => (s.gradedScore || s.rawScore) >= 60).length;
    return students.length > 0 ? (passCount / students.length) * 100 : 0;
  }, [students]);

  const gradesAllocation = useMemo(() => {
    const counts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, F: 0 };
    students.forEach(s => {
      if (s.letterGrade) counts[s.letterGrade]++;
    });
    return counts;
  }, [students]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="report-builder-panel">
      {/* Report settings / adjustments */}
      <div className="bg-slate-900 p-6 rounded-lg border border-slate-800">
        <div className="flex items-center space-x-2 mb-4 border-b border-slate-800 pb-3">
          <FileText className="w-5 h-5 text-emerald-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Academic Report Metadata Customization</h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Institution/University</label>
            <input 
              type="text" 
              value={institutionName} 
              onChange={(e) => setInstitutionName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Course Code & Title</label>
            <input 
              type="text" 
              value={courseName} 
              onChange={(e) => setCourseName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Lead Academic / Professor</label>
            <input 
              type="text" 
              value={professorName} 
              onChange={(e) => setProfessorName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Signatory Title</label>
            <input 
              type="text" 
              value={signatureLine} 
              onChange={(e) => setSignatureLine(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>
        <div className="flex justify-end mt-4">
          <button 
            onClick={handlePrint}
            className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold text-xs rounded uppercase tracking-wider hover:bg-emerald-400 transition flex items-center space-x-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Generate PDF / Print Report</span>
          </button>
        </div>
      </div>

      {/* Actual formal printable document sheet */}
      <div className="bg-slate-900 p-10 rounded-lg border border-slate-800 max-w-4xl mx-auto space-y-8 print:p-0 print:shadow-none print:border-none print:bg-white print:text-slate-900" id="printable-sheet">
        {/* Academic Header */}
        <div className="flex justify-between items-start border-b-2 border-slate-800 print:border-slate-300 pb-6">
          <div>
            <h2 className="text-sm font-bold text-emerald-400 print:text-slate-800 tracking-tight uppercase">{institutionName}</h2>
            <h1 className="text-lg font-black text-white print:text-slate-900 mt-1">{courseName}</h1>
            <p className="text-xs text-slate-400 print:text-slate-600 mt-1">Lead Faculty: {professorName}</p>
          </div>
          <div className="text-right text-xs text-slate-500 print:text-slate-500">
            <span className="font-mono flex items-center justify-end"><Calendar className="w-3.5 h-3.5 mr-1 text-emerald-500" /> {new Date().toLocaleDateString()}</span>
            <span className="block mt-1">Report ID: CG-V4-{Math.floor(Math.random() * 90000) + 10000}</span>
          </div>
        </div>

        {/* Executive summary statement */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-400 print:text-slate-800 uppercase tracking-wider">I. Executive Cohort Assessment Summary</h3>
          <p className="text-xs text-slate-300 print:text-slate-700 leading-relaxed">
            This analytical report details the psychometric validation, raw score summary, and final grading curves applied to the student cohort of <strong>{students.length} active records</strong>. Curve grading methodology applied: <strong>{currentMethod.toUpperCase()}</strong>. System metrics denote robust consistency under standard institutional policy regulations.
          </p>
        </div>

        {/* Score comparison table */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 print:text-slate-800 uppercase tracking-wider">II. Pre vs Post Curve Scoring Dynamics</h3>
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="bg-slate-950/40 print:bg-slate-100 border-b-2 border-slate-800 print:border-slate-300 font-bold text-slate-300 print:text-slate-700">
                <th className="p-2.5">Performance Dimension</th>
                <th className="p-2.5 text-center">Original Raw Metric</th>
                <th className="p-2.5 text-center">Curved/Graded Metric</th>
                <th className="p-2.5 text-center">Delta (Adjustment)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 print:divide-slate-200 text-slate-300 print:text-slate-700">
              <tr>
                <td className="p-2.5 font-semibold text-white print:text-slate-800">Mean Score (%)</td>
                <td className="p-2.5 text-center font-mono">{stats.mean.toFixed(2)}%</td>
                <td className="p-2.5 text-center font-mono">{curvedStats.mean.toFixed(2)}%</td>
                <td className="p-2.5 text-center font-mono text-emerald-400 print:text-blue-600">{(curvedStats.mean - stats.mean).toFixed(2)}%</td>
              </tr>
              <tr>
                <td className="p-2.5 font-semibold text-white print:text-slate-800">Standard Deviation (SD)</td>
                <td className="p-2.5 text-center font-mono">{stats.sd.toFixed(2)}</td>
                <td className="p-2.5 text-center font-mono">{curvedStats.sd.toFixed(2)}</td>
                <td className="p-2.5 text-center font-mono">{(curvedStats.sd - stats.sd).toFixed(2)}</td>
              </tr>
              <tr>
                <td className="p-2.5 font-semibold text-white print:text-slate-800">Minimum Score Recorded</td>
                <td className="p-2.5 text-center font-mono">{stats.min.toFixed(1)}%</td>
                <td className="p-2.5 text-center font-mono">{curvedStats.min.toFixed(1)}%</td>
                <td className="p-2.5 text-center font-mono text-emerald-400">+{(curvedStats.min - stats.min).toFixed(1)}%</td>
              </tr>
              <tr>
                <td className="p-2.5 font-semibold text-white print:text-slate-800">Maximum Score Recorded</td>
                <td className="p-2.5 text-center font-mono">{stats.max.toFixed(1)}%</td>
                <td className="p-2.5 text-center font-mono">{curvedStats.max.toFixed(1)}%</td>
                <td className="p-2.5 text-center font-mono">{(curvedStats.max - stats.max).toFixed(1)}%</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Grade allocation breakdown */}
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 print:text-slate-800 uppercase tracking-wider">III. Grade Letter Distribution</h3>
            <div className="space-y-1.5 text-[11px] text-slate-300 print:text-slate-700">
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Grade A (Excellent)</span>
                <span className="font-bold text-white print:text-slate-950">{gradesAllocation.A} Students ({students.length > 0 ? ((gradesAllocation.A / students.length)*100).toFixed(0) : 0}%)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Grade B (Above Average)</span>
                <span className="font-bold text-white print:text-slate-950">{gradesAllocation.B} Students ({students.length > 0 ? ((gradesAllocation.B / students.length)*100).toFixed(0) : 0}%)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Grade C (Satisfactory)</span>
                <span className="font-bold text-white print:text-slate-950">{gradesAllocation.C} Students ({students.length > 0 ? ((gradesAllocation.C / students.length)*100).toFixed(0) : 0}%)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Grade D (Minimal Pass)</span>
                <span className="font-bold text-white print:text-slate-950">{gradesAllocation.D} Students ({students.length > 0 ? ((gradesAllocation.D / students.length)*100).toFixed(0) : 0}%)</span>
              </div>
              <div className="flex justify-between pb-1">
                <span>Grade F (Failing)</span>
                <span className="font-bold text-white print:text-slate-950">{gradesAllocation.F} Students ({students.length > 0 ? ((gradesAllocation.F / students.length)*100).toFixed(0) : 0}%)</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 print:text-slate-800 uppercase tracking-wider">IV. Reliability & Fit Parameters</h3>
            <div className="space-y-1.5 text-[11px] text-slate-300 print:text-slate-700">
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Cronbach's Alpha Scale Reliability</span>
                <span className="font-bold text-emerald-400 print:text-blue-600">{reliabilityAlpha}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Overall Pass Rate Achievement</span>
                <span className="font-bold text-emerald-400 print:text-emerald-600">{passRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 print:border-slate-100 pb-1">
                <span>Skewness of Raw Grades</span>
                <span className="font-bold text-white print:text-slate-950">{stats.skewness.toFixed(3)}</span>
              </div>
              <div className="flex justify-between">
                <span>Kurtosis of Raw Grades</span>
                <span className="font-bold text-white print:text-slate-950">{stats.kurtosis.toFixed(3)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Signatures */}
        <div className="pt-12 flex justify-between items-end border-t border-slate-800 print:border-slate-200 text-xs text-slate-400 print:text-slate-600">
          <div>
            <div className="w-48 border-b border-slate-700 print:border-slate-400 mb-1" />
            <p className="font-bold text-white print:text-slate-800">{professorName}</p>
            <p className="text-slate-500">Lead Course Director</p>
          </div>

          <div className="text-right">
            <div className="w-48 border-b border-slate-700 print:border-slate-400 mb-1 ml-auto" />
            <p className="font-bold text-white print:text-slate-800">Academic Review Board Representative</p>
            <p className="text-slate-500">{signatureLine}</p>
          </div>
        </div>

        {/* Footer stamp */}
        <div className="pt-4 border-t-2 border-slate-800 print:border-slate-300 text-center text-[10px] text-slate-500 font-mono flex justify-between items-center">
          <span className="flex items-center"><FileCheck className="w-3 h-3 mr-1 text-emerald-500" /> Verified CurveGrade Analytics Platform Report</span>
          <span>Confidential Academic Summary Sheet</span>
        </div>
      </div>
    </div>
  );
}
