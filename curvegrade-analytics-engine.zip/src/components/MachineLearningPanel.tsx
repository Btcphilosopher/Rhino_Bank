import React, { useMemo } from 'react';
import { Student } from '../types';
import { runMachineLearning } from '../utils/statistics';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Award, ShieldAlert, Cpu } from 'lucide-react';

interface MachineLearningPanelProps {
  students: Student[];
}

export default function MachineLearningPanel({ students }: MachineLearningPanelProps) {
  const mlResult = useMemo(() => {
    return runMachineLearning(students);
  }, [students]);

  return (
    <div className="space-y-6" id="ml-panel">
      {/* Top Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Classification Accuracy</p>
            <h3 className="text-xl font-bold font-mono text-white">{(mlResult.accuracy * 100).toFixed(1)}%</h3>
            <span className="text-[10px] text-slate-400">Out-of-sample prediction precision</span>
          </div>
        </div>

        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">ROC Area Under Curve (AUC)</p>
            <h3 className="text-xl font-bold font-mono text-white">{mlResult.auc}</h3>
            <span className="text-[10px] text-slate-400">True Positive vs False Positive trade-off</span>
          </div>
        </div>

        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex items-center space-x-4">
          <div className="p-3 bg-red-500/10 text-red-400 border border-red-500/20 rounded-md">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Identified At-Risk Students</p>
            <h3 className="text-xl font-bold font-mono text-red-400">{mlResult.matrix.tp + mlResult.matrix.fn}</h3>
            <span className="text-[10px] text-slate-400">Students with raw score &lt; 60%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ROC Curve Graph */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">ROC (Receiver Operating Characteristic) Curve</h4>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">plot_roc</span>
          </div>
          <p className="text-[11px] text-slate-500 mb-4">Evaluates the classification risk thresholds. Higher curves represent superior discriminatory models.</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mlResult.rocCurve} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="fpr" stroke="#64748b" fontSize={11} label={{ value: 'False Positive Rate (FPR)', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }} />
                <YAxis stroke="#64748b" fontSize={11} label={{ value: 'True Positive Rate (TPR)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                <Line type="monotone" dataKey="tpr" stroke="#10b981" strokeWidth={3} dot={false} name="Model ROC" />
                <Line type="monotone" dataKey="fpr" stroke="#475569" strokeDasharray="3 3" dot={false} name="Random Guess (0.50)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Feature Importance Panel */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Feature Importance Metrics</h4>
              <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">var_imp</span>
            </div>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mlResult.features} layout="vertical" margin={{ top: 0, right: 10, bottom: 0, left: 30 }}>
                  <XAxis type="number" stroke="#64748b" fontSize={10} hide />
                  <YAxis type="category" dataKey="name" stroke="#64748b" fontSize={10} width={80} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                  <Bar dataKey="importance" fill="#10b981" radius={[0, 4, 4, 0]} name="Importance %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <h5 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Confusion Matrix (Validation Test Set)</h5>
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block">True Positives (TP)</span>
                <strong className="text-slate-200 text-sm">{mlResult.matrix.tp}</strong>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block">False Positives (FP)</span>
                <strong className="text-slate-200 text-sm">{mlResult.matrix.fp}</strong>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block">False Negatives (FN)</span>
                <strong className="text-slate-200 text-sm">{mlResult.matrix.fn}</strong>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block">True Negatives (TN)</span>
                <strong className="text-slate-200 text-sm">{mlResult.matrix.tn}</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
