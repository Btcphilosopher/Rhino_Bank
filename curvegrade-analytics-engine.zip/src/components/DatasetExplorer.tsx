import React, { useState, useMemo } from 'react';
import { Student } from '../types';
import { Search, RotateCcw, Download, UserPlus, Sliders } from 'lucide-react';

interface DatasetExplorerProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  onRecreateCohort: (size: number, mean: number, sd: number, skew: 'none' | 'left' | 'right') => void;
}

export default function DatasetExplorer({ students, setStudents, onRecreateCohort }: DatasetExplorerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGender, setSelectedGender] = useState('All');
  const [selectedMajor, setSelectedMajor] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Cohort generator options
  const [newSize, setNewSize] = useState(200);
  const [newMean, setNewMean] = useState(68);
  const [newSd, setNewSd] = useState(12);
  const [newSkew, setNewSkew] = useState<'none' | 'left' | 'right'>('none');

  const majors = useMemo(() => {
    return ['All', ...new Set(students.map(s => s.major))];
  }, [students]);

  // Filtered dataset
  const filteredStudents = useMemo(() => {
    return students.filter(student => {
      const matchesSearch = student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            student.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesGender = selectedGender === 'All' || student.gender === selectedGender;
      const matchesMajor = selectedMajor === 'All' || student.major === selectedMajor;
      return matchesSearch && matchesGender && matchesMajor;
    });
  }, [students, searchQuery, selectedGender, selectedMajor]);

  // Paginated dataset
  const paginatedStudents = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredStudents.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredStudents, currentPage]);

  const totalPages = Math.ceil(filteredStudents.length / itemsPerPage) || 1;

  // Export to CSV
  const exportToCSV = () => {
    const headers = ['StudentID', 'Name', 'Gender', 'Major', 'AttendanceRate', 'StudyHours', 'MidtermScore', 'RawScore', 'GradedScore', 'TScore', 'LetterGrade'];
    const rows = students.map(s => [
      s.id,
      `"${s.name}"`,
      s.gender,
      `"${s.major}"`,
      s.attendance,
      s.studyHours,
      s.midtermScore,
      s.rawScore,
      s.gradedScore ?? '',
      s.tScore ?? '',
      s.letterGrade ?? ''
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "curvegrade_cohort_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="dataset-explorer-panel">
      {/* Simulation Cohort Parameter Controls */}
      <div className="bg-slate-900 p-6 rounded-lg border border-slate-800">
        <div className="flex items-center space-x-2 mb-4 border-b border-slate-800 pb-3">
          <Sliders className="w-5 h-5 text-slate-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Cohort Population Simulator</h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Cohort Size (Students)</label>
            <input 
              type="number" 
              value={newSize} 
              onChange={(e) => setNewSize(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500" 
              min={10} 
              max={2000}
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Raw Score Mean (%)</label>
            <input 
              type="number" 
              value={newMean} 
              onChange={(e) => setNewMean(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500" 
              min={30} 
              max={95}
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Raw Score Std Dev</label>
            <input 
              type="number" 
              value={newSd} 
              onChange={(e) => setNewSd(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded font-mono text-slate-200 focus:outline-hidden focus:border-emerald-500" 
              min={2} 
              max={30}
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Distribution Skewness</label>
            <select 
              value={newSkew} 
              onChange={(e) => setNewSkew(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded text-slate-200 focus:outline-hidden focus:border-emerald-500"
            >
              <option value="none">Symmetrical (Normal)</option>
              <option value="left">Left-Skewed (High-Performers)</option>
              <option value="right">Right-Skewed (Struggling Cohort)</option>
            </select>
          </div>
        </div>
        <div className="flex justify-end mt-4">
          <button 
            onClick={() => onRecreateCohort(newSize, newMean, newSd, newSkew)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded border border-slate-700 uppercase tracking-wider transition-colors flex items-center space-x-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Generate Cohort Dataset</span>
          </button>
        </div>
      </div>

      {/* Dataset Filter & Table Area */}
      <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
        <div className="p-4 bg-slate-900/50 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Leftside search & filters */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input 
                type="text" 
                placeholder="Search Student or ID..." 
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                className="pl-9 pr-4 py-2 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 w-full md:w-60 focus:outline-hidden focus:border-emerald-500 font-mono"
              />
            </div>

            <select 
              value={selectedGender} 
              onChange={(e) => { setSelectedGender(e.target.value); setCurrentPage(1); }}
              className="px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-hidden focus:border-emerald-500"
            >
              <option value="All">All Genders</option>
              <option value="Female">Female</option>
              <option value="Male">Male</option>
              <option value="Other">Other</option>
            </select>

            <select 
              value={selectedMajor} 
              onChange={(e) => { setSelectedMajor(e.target.value); setCurrentPage(1); }}
              className="px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-hidden focus:border-emerald-500"
            >
              {majors.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          {/* Rightside Export */}
          <div>
            <button 
              onClick={exportToCSV}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded uppercase tracking-wider transition-colors flex items-center space-x-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Data Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-medium">
                <th className="p-4 uppercase tracking-wider text-[10px]">Student ID</th>
                <th className="p-4 uppercase tracking-wider text-[10px]">Name</th>
                <th className="p-4 uppercase tracking-wider text-[10px]">Gender</th>
                <th className="p-4 uppercase tracking-wider text-[10px]">Department / Major</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Attendance</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Study Hours/Wk</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Midterm Exam</th>
                <th className="p-4 text-center bg-slate-950/20 text-slate-300 uppercase tracking-wider text-[10px]">Raw Exam</th>
                <th className="p-4 text-center bg-slate-950/30 text-emerald-400 uppercase tracking-wider text-[10px]">Curved Exam</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Letter Grade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {paginatedStudents.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/30 transition text-slate-300">
                  <td className="p-4 font-mono text-slate-400">{s.id}</td>
                  <td className="p-4 font-semibold text-white">{s.name}</td>
                  <td className="p-4">{s.gender}</td>
                  <td className="p-4 text-slate-400">{s.major}</td>
                  <td className="p-4 text-center font-mono">{s.attendance}%</td>
                  <td className="p-4 text-center font-mono">{s.studyHours}h</td>
                  <td className="p-4 text-center font-mono">{s.midtermScore}%</td>
                  <td className="p-4 text-center bg-slate-950/20 font-mono font-bold text-slate-200">{s.rawScore}%</td>
                  <td className="p-4 text-center bg-slate-950/30 font-mono font-bold text-emerald-400">
                    {s.gradedScore !== undefined ? `${s.gradedScore}%` : '-'}
                  </td>
                  <td className="p-4 text-center">
                    {s.letterGrade ? (
                      <span className={`inline-block px-2.5 py-0.5 rounded-sm font-bold text-[10px] font-mono ${
                        s.letterGrade === 'A' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        s.letterGrade === 'B' ? 'bg-slate-800 text-slate-300 border border-slate-700' :
                        s.letterGrade === 'C' ? 'bg-slate-800 text-slate-400 border border-slate-700' :
                        s.letterGrade === 'D' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' :
                        'bg-red-500/10 text-red-500 border border-red-500/20'
                      }`}>
                        {s.letterGrade}
                      </span>
                    ) : (
                      '-'
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {filteredStudents.length === 0 && (
            <div className="py-12 text-center text-slate-500">
              No students match the selected filter criteria.
            </div>
          )}
        </div>

        {/* Pagination bar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/30 flex items-center justify-between text-xs text-slate-400">
          <div>
            Showing <strong className="text-slate-200 font-mono">{Math.min(filteredStudents.length, (currentPage - 1) * itemsPerPage + 1)}</strong> to{' '}
            <strong className="text-slate-200 font-mono">{Math.min(filteredStudents.length, currentPage * itemsPerPage)}</strong> of{' '}
            <strong className="text-slate-200 font-mono">{filteredStudents.length}</strong> students
          </div>
          <div className="flex items-center space-x-2">
            <button 
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              className="px-3 py-1 bg-slate-800 border border-slate-700 text-slate-300 rounded disabled:opacity-40 transition hover:bg-slate-700"
            >
              Previous
            </button>
            <span className="font-medium text-slate-400 font-mono">Page {currentPage} of {totalPages}</span>
            <button 
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              className="px-3 py-1 bg-slate-800 border border-slate-700 text-slate-300 rounded disabled:opacity-40 transition hover:bg-slate-700"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
