import React, { useMemo } from 'react';
import { Student } from '../types';
import { runMultipleRegression } from '../utils/statistics';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { LineChart, BarChart } from 'lucide-react';

interface RegressionModelsProps {
  students: Student[];
}

export default function RegressionModels({ students }: RegressionModelsProps) {
  const regressionResult = useMemo(() => {
    return runMultipleRegression(students);
  }, [students]);

  return (
    <div className="space-y-6" id="regression-models-panel">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">R-Squared Coefficient</span>
          <p className="text-2xl font-mono text-white">{regressionResult.rSquared}</p>
          <span className="text-[10px] text-slate-400">Proportion of variance explained by predictors</span>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">Adjusted R-Squared</span>
          <p className="text-2xl font-mono text-white">{regressionResult.adjRSquared}</p>
          <span className="text-[10px] text-slate-400">R² adjusted for degrees of freedom</span>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">F-Statistic</span>
          <p className="text-2xl font-mono text-white">{regressionResult.fStatistic}</p>
          <span className="text-[10px] text-slate-400">Global significance F-test value</span>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1">p-Value</span>
          <p className={`text-2xl font-mono ${regressionResult.pValue < 0.05 ? 'text-emerald-400' : 'text-slate-200'}`}>
            {regressionResult.pValue}
          </p>
          <span className="text-[10px] text-slate-400">Model significance status</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Table of Coefficients */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Regression Coefficients Table</h4>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">lm_summary</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-medium">
                  <th className="p-4 uppercase tracking-wider text-[10px]">Predictor Variable</th>
                  <th className="p-4 text-center uppercase tracking-wider text-[10px]">Beta Coefficient (β)</th>
                  <th className="p-4 text-center uppercase tracking-wider text-[10px]">Standard Error (SE)</th>
                  <th className="p-4 text-center uppercase tracking-wider text-[10px]">t-Value</th>
                  <th className="p-4 text-center uppercase tracking-wider text-[10px]">Pr(&gt;|t|) (p-Value)</th>
                  <th className="p-4 text-center uppercase tracking-wider text-[10px]">Significance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {regressionResult.coefficients.map((coeff, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30 transition text-slate-300">
                    <td className="p-4 font-semibold text-white">{coeff.variable}</td>
                    <td className="p-4 text-center font-mono text-slate-200">{coeff.beta.toFixed(3)}</td>
                    <td className="p-4 text-center font-mono text-slate-400">{coeff.stdError.toFixed(3)}</td>
                    <td className="p-4 text-center font-mono text-slate-400">{coeff.tValue.toFixed(2)}</td>
                    <td className="p-4 text-center font-mono font-bold text-white">{coeff.pValue}</td>
                    <td className="p-4 text-center">
                      {coeff.pValue < 0.001 ? (
                        <span className="text-emerald-400 font-bold font-mono">***</span>
                      ) : coeff.pValue < 0.01 ? (
                        <span className="text-emerald-400/80 font-bold font-mono">**</span>
                      ) : coeff.pValue < 0.05 ? (
                        <span className="text-emerald-400/60 font-bold font-mono">*</span>
                      ) : (
                        <span className="text-slate-500 font-medium font-mono">ns</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 text-[10px] text-slate-500 font-mono">
            Signif. codes: 0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
          </div>
        </div>

        {/* Residual Diagnostic Plots */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Residual vs Predicted Plot</h4>
              <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">plot_resid</span>
            </div>
            <p className="text-[11px] text-slate-500 mb-4">Checks the linear homoscedasticity assumption (residuals should be randomly dispersed around zero).</p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 10, bottom: 10, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis type="number" dataKey="predicted" name="Predicted" stroke="#64748b" fontSize={10} domain={['auto', 'auto']} />
                  <YAxis type="number" dataKey="residual" name="Residual" stroke="#64748b" fontSize={10} domain={['auto', 'auto']} />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                  <Scatter name="Residuals" data={regressionResult.residualPlotData} fill="#ef4444" shape="circle" />
                  <ReferenceLine y={0} stroke="#64748b" strokeWidth={1.5} />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 leading-snug mt-3 pt-3 border-t border-slate-800">
            If points exhibit a horn or cone shape, it suggests heteroscedasticity in test scoring variance, indicating a non-linear scaling adjustment might be superior.
          </p>
        </div>
      </div>
    </div>
  );
}
