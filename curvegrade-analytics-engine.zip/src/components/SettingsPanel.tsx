import React from 'react';
import { Folder, FileCode, CheckCircle, Terminal } from 'lucide-react';

export default function SettingsPanel() {
  const fileStructures = [
    { path: 'CurveGradeAnalytics/R/curve_grading.R', desc: 'Roxygen-documented curve grading functions (Bell, Z-score, percentile, linear scaling, quotas).' },
    { path: 'CurveGradeAnalytics/R/normalization.R', desc: 'Advanced normalization algorithms including Box-Cox transformations, robust scaling, and quantile normalizations.' },
    { path: 'CurveGradeAnalytics/R/descriptive_statistics.R', desc: 'Descriptive moment calculations: mean, median, mode, SD, skewness, kurtosis, CI levels.' },
    { path: 'CurveGradeAnalytics/R/psychometrics.R', desc: 'Test-scale items validation including Cronbach\'s Alpha and item-difficulty analysis.' },
    { path: 'CurveGradeAnalytics/R/simulation.R', desc: 'Monte Carlo simulations, randomized exam cohort generator, and bootstrap sensitivity analysis.' },
    { path: 'CurveGradeAnalytics/main.R', desc: 'Main orchestration pipeline executing mock dataset workflows and saving analytics reports to local directories.' }
  ];

  return (
    <div className="space-y-6" id="settings-panel">
      {/* R Package Structure Overview */}
      <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-xs">
        <div className="flex items-center space-x-2 mb-4">
          <Folder className="w-5 h-5 text-indigo-500" />
          <h4 className="text-base font-semibold text-slate-700">Enterprise R Package File System</h4>
        </div>
        <p className="text-xs text-slate-500 mb-6 leading-relaxed">
          The CurveGrade Analytics Engine is fully configured as an enterprise R statistical module inside the workspace directories. When exporting or checking out via ZIP, these files conform perfectly to roxygen2 and tidyverse specifications.
        </p>

        <div className="space-y-3.5">
          {fileStructures.map((f, i) => (
            <div key={i} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-100/60 hover:border-slate-200 transition">
              <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600 shrink-0">
                <FileCode className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-mono font-bold text-slate-800 block">{f.path}</span>
                <span className="text-[11px] text-slate-500 mt-0.5 block leading-normal">{f.desc}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* R Integration Installation Instructions */}
      <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-xs">
        <div className="flex items-center space-x-2 mb-4">
          <Terminal className="w-5 h-5 text-slate-800" />
          <h4 className="text-base font-semibold text-slate-700">Deployment and CLI Integration (R Console)</h4>
        </div>
        <p className="text-xs text-slate-500 mb-4 leading-relaxed">
          To run the statistical analysis engine or boot the corporate Shiny analytical dashboard directly in your local R environment:
        </p>

        {/* Code snippet */}
        <div className="bg-slate-900 text-slate-100 font-mono p-5 rounded-xl text-xs space-y-2 leading-relaxed shadow-inner overflow-x-auto">
          <p className="text-slate-400"># 1. Install system prerequisites from CRAN</p>
          <p>install.packages(c("tidyverse", "shiny", "plotly", "DT", "psych", "caret", "testthat", "yaml", "jsonlite"))</p>
          <p className="text-slate-400"># 2. Set directory and load CurveGrade Engine modules</p>
          <p>setwd("path/to/CurveGradeAnalytics")</p>
          <p>source("main.R")</p>
          <p className="text-slate-400"># 3. Launch end-to-end simulation assessment</p>
          <p>pipeline_results &lt;- run_analytics_pipeline(cohort_size = 500, target_mean = 75)</p>
          <p className="text-slate-400"># 4. View summary coefficients</p>
          <p>print(pipeline_results$descriptive)</p>
        </div>

        <div className="mt-4 flex items-center space-x-2 text-xs text-emerald-600 font-semibold">
          <CheckCircle className="w-4 h-4" />
          <span>R Code compliance checked against CRAN package development rules.</span>
        </div>
      </div>
    </div>
  );
}
