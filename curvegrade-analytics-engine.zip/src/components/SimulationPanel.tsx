import React, { useMemo, useState } from 'react';
import { Student } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Play, Activity, Info } from 'lucide-react';

interface SimulationPanelProps {
  students: Student[];
}

export default function SimulationPanel({ students }: SimulationPanelProps) {
  const [numSimulations, setNumSimulations] = useState(100);
  const [errorSD, setErrorSD] = useState(2.5);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);

  // Run a real lightweight Monte Carlo simulation on the client-side
  const simulationResults = useMemo(() => {
    if (students.length === 0) return null;

    const n = students.length;
    // Sub-sample 15 students for clear visual tracking on the chart
    const subStudents = students.slice(0, 15);
    const m = subStudents.length;

    // Simulate standard day-to-day score fluctuations
    const simulatedGrades = Array.from({ length: m }, () => [] as number[]);

    for (let sim = 0; sim < numSimulations; sim++) {
      // For each simulation, add noise to all scores in the cohort, then re-calculate standard z-scores and curve grades
      const noisyScores = students.map(s => {
        // Box-Muller noise
        let u = 0, v = 0;
        while(u === 0) u = Math.random();
        while(v === 0) v = Math.random();
        const noise = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v) * errorSD;
        return Math.max(0, Math.min(100, s.rawScore + noise));
      });

      // Recalculate mean/SD of noisy scores
      const sum = noisyScores.reduce((a, b) => a + b, 0);
      const mean = sum / n;
      const sqDiffSum = noisyScores.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
      const sd = n > 1 ? Math.sqrt(sqDiffSum / (n - 1)) : 1;

      // Calculate new bell-curve grade for sub-sampled students
      subStudents.forEach((student, subIdx) => {
        const studentRawNoisy = noisyScores[students.indexOf(student)];
        const z = sd > 0 ? (studentRawNoisy - mean) / sd : 0;
        const curved = z * 10 + 75; // standard target mean=75, SD=10
        simulatedGrades[subIdx].push(Math.max(0, Math.min(100, curved)));
      });
    }

    // Compile statistics (expected score, standard error, 95% confidence intervals)
    return subStudents.map((student, subIdx) => {
      const grades = simulatedGrades[subIdx].sort((a, b) => a - b);
      const meanSim = grades.reduce((a, b) => a + b, 0) / numSimulations;
      const lowerCI = grades[Math.floor(numSimulations * 0.025)] || grades[0];
      const upperCI = grades[Math.floor(numSimulations * 0.975)] || grades[numSimulations - 1];

      return {
        id: student.id,
        name: student.name.split(' ')[0], // only first name for chart label
        rawScore: student.rawScore,
        curvedScore: student.gradedScore || student.rawScore,
        expectedScore: Math.round(meanSim * 10) / 10,
        lowerBound: Math.round(lowerCI * 10) / 10,
        boundDiff: Math.max(0.1, Math.round((upperCI - lowerCI) * 10) / 10),
        upperBound: Math.round(upperCI * 10) / 10,
        intervalSpan: Math.round((upperCI - lowerCI) * 10) / 10
      };
    });
  }, [students, numSimulations, errorSD]);

  const runSimulation = () => {
    setIsRunning(true);
    setProgress(0);
    const interval = setInterval(() => {
      setProgress(p => {
        if (p === null || p >= 100) {
          clearInterval(interval);
          setIsRunning(false);
          return null;
        }
        return p + 25;
      });
    }, 150);
  };

  return (
    <div className="space-y-6" id="simulation-panel">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Simulation configuration */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 mb-2 border-b border-slate-800 pb-3">
            <Activity className="w-5 h-5 text-emerald-500" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Monte Carlo Simulator</h4>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Number of Simulation Runs: {numSimulations}</label>
            <input 
              type="range" 
              min="50" 
              max="1000" 
              step="50" 
              value={numSimulations}
              onChange={(e) => setNumSimulations(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>50 Trials (Fast)</span>
              <span>1000 Trials (Accurate)</span>
            </div>
          </div>

          <div>
            <label className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Measurement Error (Noise SD): {errorSD}</label>
            <input 
              type="range" 
              min="0.5" 
              max="10" 
              step="0.5" 
              value={errorSD}
              onChange={(e) => setErrorSD(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>0.5 (Highly Stable)</span>
              <span>10.0 (Extremely Noisy)</span>
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800 flex items-start space-x-2.5">
            <Info className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-slate-400">
              This models score volatility. Student test scores are perturbed by random measurement errors, then re-graded. This determines the stability and fairness of the curve grading thresholds under random fluctuation.
            </p>
          </div>

          <button
            onClick={runSimulation}
            disabled={isRunning}
            className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded uppercase tracking-wider transition-colors flex items-center justify-center space-x-1.5 disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{isRunning ? 'Processing...' : 'Run Sensitivity Analysis'}</span>
          </button>
        </div>

        {/* Confidence Interval charts */}
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 lg:col-span-2">
          <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Grade Stability Sensitivity Spans (95% CI)</h4>
            <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] font-mono text-slate-400">sensitivity_plot</span>
          </div>
          <p className="text-[11px] text-slate-500 mb-4">Displays expected grade boundaries under simulated test fluctuations. Narrower bands denote robust grade assignments.</p>
          
          {isRunning ? (
            <div className="h-64 flex flex-col items-center justify-center space-y-2">
              <div className="w-44 bg-slate-950 border border-slate-800 h-2.5 rounded overflow-hidden">
                <div className="bg-emerald-500 h-full transition-all duration-150" style={{ width: `${progress}%` }} />
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Running iterations: {progress}%</span>
            </div>
          ) : (
            <div className="h-64">
              {simulationResults && (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={simulationResults} margin={{ top: 15, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} domain={[40, 100]} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '4px', color: '#cbd5e1' }} />
                    <Line type="monotone" dataKey="expectedScore" name="Expected Grade" stroke="#10b981" strokeWidth={2.5} />
                    <Line type="monotone" dataKey="lowerBound" name="Lower 95% Bound" stroke="#ef4444" strokeDasharray="4 4" dot={false} />
                    <Line type="monotone" dataKey="upperBound" name="Upper 95% Bound" stroke="#10b981" strokeDasharray="4 4" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Stability statistics list */}
      <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Top 15 Students Simulated Variance Audit</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-medium">
                <th className="p-4 uppercase tracking-wider text-[10px]">Student ID</th>
                <th className="p-4 uppercase tracking-wider text-[10px]">Raw Exam Mark</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Original Curved Grade</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Simulated Expected Mean</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Expected 95% Range Bound</th>
                <th className="p-4 text-center uppercase tracking-wider text-[10px]">Volatility Margin (Span)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {simulationResults?.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition text-slate-300">
                  <td className="p-4 font-mono font-medium text-slate-500">{item.id}</td>
                  <td className="p-4 font-semibold text-white">{item.rawScore}%</td>
                  <td className="p-4 text-center font-bold text-slate-200">{item.curvedScore}%</td>
                  <td className="p-4 text-center font-bold text-emerald-400">{item.expectedScore}%</td>
                  <td className="p-4 text-center font-medium text-slate-400">[{item.lowerBound}% to {item.upperBound}%]</td>
                  <td className="p-4 text-center font-semibold text-white">± {item.intervalSpan}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
