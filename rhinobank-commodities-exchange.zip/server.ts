import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { 
  CommodityCategory, 
  MarketTicker, 
  Order, 
  OrderBook, 
  WarehouseStock, 
  Warehouse, 
  SupplyChainNode, 
  ShippingRoute, 
  PortfolioPosition, 
  Contract, 
  ScenarioImpact, 
  RiskProfile, 
  SimulationResult, 
  EconomicMetrics,
  IndustryDemand
} from "./src/types";

dotenv.config();

const app = express();
app.use(express.json());
const PORT = 3000;

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// ==========================================
// 1. COMMODITY MASTER DATA DEFINITION
// ==========================================
const COMMODITY_LIST = [
  // Rare Earths
  { symbol: "NdPr", name: "Neodymium-Praseodymium Oxide", category: CommodityCategory.REE, purity: "99.5% Min", unit: "kg", description: "Critical for high-performance neodymium-iron-boron (NdFeB) permanent magnets." },
  { symbol: "Dy", name: "Dysprosium Oxide", category: CommodityCategory.REE, purity: "99.5% Min", unit: "kg", description: "Added to NdFeB magnets to maintain magnetism under high operating temperatures." },
  { symbol: "Tb", name: "Terbium Oxide", category: CommodityCategory.REE, purity: "99.9% Min", unit: "kg", description: "Critical additive for heavy rare earth magnets, used in high-tech defense & wind turbines." },
  { symbol: "La", name: "Lanthanum Oxide", category: CommodityCategory.REE, purity: "99.9% Min", unit: "kg", description: "Used heavily in fluid catalytic cracking (refining) and optical glass." },
  { symbol: "Ce", name: "Cerium Oxide", category: CommodityCategory.REE, purity: "99.95% Min", unit: "kg", description: "Most abundant REE, used for polishing glass, catalytic converters, and self-cleaning ovens." },
  { symbol: "Y", name: "Yttrium Oxide", category: CommodityCategory.REE, purity: "99.99% Min", unit: "kg", description: "Used in superconductors, lasers, ceramics, and phosphor displays." },
  { symbol: "Sm", name: "Samarium Oxide", category: CommodityCategory.REE, purity: "99.5% Min", unit: "kg", description: "Used in samarium-cobalt (SmCo) high-temperature magnets and nuclear control rods." },
  { symbol: "Eu", name: "Europium Oxide", category: CommodityCategory.REE, purity: "99.9% Min", unit: "kg", description: "Highly efficient red/blue phosphors for screens, fiber optics, and control systems." },
  { symbol: "Gd", name: "Gadolinium Oxide", category: CommodityCategory.REE, purity: "99.99% Min", unit: "kg", description: "Superb neutron-absorption properties, used in medical MRI contrast agents and nuclear shielding." },

  // Battery Metals
  { symbol: "Li", name: "Lithium Carbonate", category: CommodityCategory.BATTERY, purity: "99.5% Battery Grade", unit: "tonne", description: "Essential chemical compound for lithium-ion EV battery cathodes." },
  { symbol: "Ni", name: "Nickel Sulphate", category: CommodityCategory.BATTERY, purity: "22.3% Ni Min", unit: "tonne", description: "High-purity chemical precursor for NMC batteries, providing high energy density." },
  { symbol: "Co", name: "Cobalt Metal", category: CommodityCategory.BATTERY, purity: "99.8% Min", unit: "tonne", description: "Critical for battery structural thermal stability, highly geographically concentrated." },
  { symbol: "C_gr", name: "Spherical Graphite", category: CommodityCategory.BATTERY, purity: "99.95% Anode Grade", unit: "tonne", description: "Anode material representing major volume of battery cells, requiring purification." },
  { symbol: "Mn", name: "Manganese Flake", category: CommodityCategory.BATTERY, purity: "99.7% Electrolytic", unit: "tonne", description: "Cost-efficient cathode constituent for NMC and manganese-rich batteries." },
  { symbol: "Cu", name: "Copper Cathode", category: CommodityCategory.BATTERY, purity: "Grade A 99.99%", unit: "tonne", description: "The metal of electrification, used for motors, busbars, wiring, and wind cables." },
  { symbol: "V", name: "Vanadium Pentoxide", category: CommodityCategory.BATTERY, purity: "98% Min", unit: "tonne", description: "Active material for industrial utility-scale redox flow battery storage." },

  // Industrial Metals
  { symbol: "Al", name: "Aluminium Premium", category: CommodityCategory.INDUSTRIAL, purity: "99.7% Standard", unit: "tonne", description: "Primary structural alloy for aerospace, transportation, and power lines." },
  { symbol: "Fe_st", name: "HRC Steel", category: CommodityCategory.INDUSTRIAL, purity: "Hot Rolled Coil", unit: "tonne", description: "Global benchmark industrial structural material for manufacturing and construction." },
  { symbol: "Ti", name: "Titanium Sponge", category: CommodityCategory.INDUSTRIAL, purity: "99.7% Aerospace Grade", unit: "kg", description: "Excellent strength-to-weight ratio and corrosion resistance for defense & jets." },
  { symbol: "Mg", name: "Magnesium Metal", category: CommodityCategory.INDUSTRIAL, purity: "99.9% Min", unit: "tonne", description: "Lightweight structural alloying element crucial for aluminium strengthening." },
  { symbol: "W", name: "Tungsten Concentrate", category: CommodityCategory.INDUSTRIAL, purity: "65% WO3 Min", unit: "tonne", description: "Extremely high melting point and density, critical for armor-piercing ammunition." },
  { symbol: "Mo", name: "Molybdenum Oxide", category: CommodityCategory.INDUSTRIAL, purity: "57% Mo Min", unit: "tonne", description: "High-temperature steel superalloy agent for pipelines and jet engines." },
  { symbol: "Sn", name: "Tin Refined", category: CommodityCategory.INDUSTRIAL, purity: "99.85% Solder Grade", unit: "tonne", description: "The glue of the digital age, essential for lead-free electronic circuit solders." },
  { symbol: "Zn", name: "Zinc High Grade", category: CommodityCategory.INDUSTRIAL, purity: "99.995% LME Grade", unit: "tonne", description: "Used primarily to galvanize steel and alloy brass for corrosion resistance." }
];

// ==========================================
// 2. IN-MEMORY STATE SYSTEM
// ==========================================

// Store current prices
let tickers: MarketTicker[] = COMMODITY_LIST.map(metal => {
  // Establish realistic base prices in GBP (£) per unit (kg or tonne)
  let basePrice = 0;
  let unitVol = 0;
  if (metal.category === CommodityCategory.REE) {
    if (metal.symbol === "NdPr") basePrice = 74.50; // £74.50/kg
    else if (metal.symbol === "Dy") basePrice = 285.00; // £285/kg
    else if (metal.symbol === "Tb") basePrice = 960.00; // £960/kg
    else if (metal.symbol === "La") basePrice = 4.20;
    else if (metal.symbol === "Ce") basePrice = 3.80;
    else if (metal.symbol === "Y") basePrice = 12.50;
    else if (metal.symbol === "Sm") basePrice = 14.80;
    else if (metal.symbol === "Eu") basePrice = 110.00;
    else if (metal.symbol === "Gd") basePrice = 42.00;
    unitVol = Math.floor(Math.random() * 5000) + 1000;
  } else if (metal.category === CommodityCategory.BATTERY) {
    if (metal.symbol === "Li") basePrice = 14200.00; // £14,200/tonne
    else if (metal.symbol === "Ni") basePrice = 16800.00; // £16,800/tonne
    else if (metal.symbol === "Co") basePrice = 27500.00; // £27,500/tonne
    else if (metal.symbol === "C_gr") basePrice = 6400.00; // £6,400/tonne
    else if (metal.symbol === "Mn") basePrice = 1950.00;
    else if (metal.symbol === "Cu") basePrice = 7850.00;
    else if (metal.symbol === "V") basePrice = 18500.00;
    unitVol = Math.floor(Math.random() * 200) + 50;
  } else {
    // Industrial
    if (metal.symbol === "Al") basePrice = 2150.00; // £2,150/tonne
    else if (metal.symbol === "Fe_st") basePrice = 620.00; // £620/tonne
    else if (metal.symbol === "Ti") basePrice = 11.50; // £11.50/kg
    else if (metal.symbol === "Mg") basePrice = 3100.00;
    else if (metal.symbol === "W") basePrice = 28500.00;
    else if (metal.symbol === "Mo") basePrice = 21000.00;
    else if (metal.symbol === "Sn") basePrice = 24500.00;
    else if (metal.symbol === "Zn") basePrice = 2300.00;
    unitVol = Math.floor(Math.random() * 1000) + 200;
  }

  // Calculate high/low
  const high = basePrice * (1 + (Math.random() * 0.03));
  const low = basePrice * (1 - (Math.random() * 0.03));
  const change = (Math.random() * 4) - 2; // -2% to +2%
  const prevPrice = basePrice / (1 + (change / 100));

  // Regional premium profiles
  let chinaCoeff = 1.0;
  let europeCoeff = 1.05;
  let usaCoeff = 1.08;

  if (metal.category === CommodityCategory.REE) {
    // REE production overwhelmingly Chinese, Europe and USA pay severe premiums
    chinaCoeff = 0.95;
    europeCoeff = 1.15;
    usaCoeff = 1.21;
  }

  return {
    symbol: metal.symbol,
    name: metal.name,
    category: metal.category,
    spotPrice: Number(basePrice.toFixed(2)),
    prevPrice: Number(prevPrice.toFixed(2)),
    change: Number(change.toFixed(2)),
    high: Number(high.toFixed(2)),
    low: Number(low.toFixed(2)),
    volume: unitVol,
    regional: {
      china: Number((basePrice * chinaCoeff).toFixed(2)),
      europe: Number((basePrice * europeCoeff).toFixed(2)),
      usa: Number((basePrice * usaCoeff).toFixed(2)),
    },
    unit: metal.unit,
    premiums: {
      transport: metal.category === CommodityCategory.REE ? 2.50 : 150.00,
      purity: metal.category === CommodityCategory.REE ? 1.80 : 80.00,
      warehouse: metal.category === CommodityCategory.REE ? 0.05 : 0.85,
    }
  };
});

// Generate realistic live order books for each ticker
let orderBooks: { [symbol: string]: OrderBook } = {};
const generateOrderBook = (ticker: MarketTicker): OrderBook => {
  const symbol = ticker.symbol;
  const spot = ticker.spotPrice;
  const step = spot * 0.001; // tight spreads (0.1%)
  
  const bids = Array.from({ length: 10 }, (_, i) => {
    const price = spot - (i + 1) * step - (Math.random() * step * 0.2);
    const amount = ticker.category === CommodityCategory.REE 
      ? Math.floor(Math.random() * 200) + 10 
      : Math.floor(Math.random() * 50) + 2;
    return {
      price: Number(price.toFixed(2)),
      amount,
      count: Math.floor(Math.random() * 3) + 1
    };
  }).sort((a, b) => b.price - a.price); // Bid highest first

  const asks = Array.from({ length: 10 }, (_, i) => {
    const price = spot + (i + 1) * step + (Math.random() * step * 0.2);
    const amount = ticker.category === CommodityCategory.REE 
      ? Math.floor(Math.random() * 200) + 10 
      : Math.floor(Math.random() * 50) + 2;
    return {
      price: Number(price.toFixed(2)),
      amount,
      count: Math.floor(Math.random() * 3) + 1
    };
  }).sort((a, b) => a.price - b.price); // Ask lowest first

  return { symbol, bids, asks };
};

// Populate initial order books
tickers.forEach(t => {
  orderBooks[t.symbol] = generateOrderBook(t);
});

// Historical price database (simulating past 30 days)
let historicalPrices: { [symbol: string]: { date: string; price: number }[] } = {};
const initHistoricalPrices = () => {
  const dates = Array.from({ length: 30 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (29 - i));
    return d.toISOString().split("T")[0];
  });

  tickers.forEach(t => {
    let currentPrice = t.spotPrice * 0.95; // start lower
    historicalPrices[t.symbol] = dates.map(date => {
      const dailyVolatility = t.category === CommodityCategory.REE ? 0.015 : 0.01;
      const change = (Math.random() - 0.48) * dailyVolatility; // slightly upwards trend
      currentPrice = currentPrice * (1 + change);
      return { date, price: Number(currentPrice.toFixed(2)) };
    });
    // Ensure final one equals current spot
    historicalPrices[t.symbol].push({
      date: new Date().toISOString().split("T")[0],
      price: t.spotPrice
    });
  });
};
initHistoricalPrices();

// Warehouses data
let warehouses: Warehouse[] = [
  { id: "ROT", name: "LME Rotterdam Vaults", location: "Rotterdam", country: "Netherlands", latitude: 51.9244, longitude: 4.4777, capacity: 50000, currentLoad: 12500 },
  { id: "SGP", name: "Keppel Distripark Terminal", location: "Singapore", country: "Singapore", latitude: 1.2902, longitude: 103.8519, capacity: 35000, currentLoad: 8800 },
  { id: "BAL", name: "Chesapeake Logistics Center", location: "Baltimore", country: "USA", latitude: 39.2904, longitude: -76.6122, capacity: 40000, currentLoad: 7200 },
  { id: "SHA", name: "Baoshan Heavy Terminal", location: "Shanghai", country: "China", latitude: 31.2304, longitude: 121.4737, capacity: 60000, currentLoad: 41200 },
  { id: "PTH", name: "Pilbara Port Hub", location: "Port Hedland", country: "Australia", latitude: -20.3100, longitude: 118.5700, capacity: 25000, currentLoad: 5500 }
];

// Warehouse stocks
let warehouseStocks: WarehouseStock[] = [
  // Rotterdam
  { warehouse: "LME Rotterdam Vaults", location: "Rotterdam", commodity: "Neodymium-Praseodymium Oxide", symbol: "NdPr", grade: "99.5% Magnet Grade", purity: "99.5%", origin: "Australia", stockLevel: 150, reserved: 30, deliverable: 120 },
  { warehouse: "LME Rotterdam Vaults", location: "Rotterdam", commodity: "Lithium Carbonate", symbol: "Li", grade: "Battery Grade", purity: "99.5%", origin: "Chile", stockLevel: 500, reserved: 150, deliverable: 350 },
  { warehouse: "LME Rotterdam Vaults", location: "Rotterdam", commodity: "Cobalt Metal", symbol: "Co", grade: "Electrolytic Cut", purity: "99.8%", origin: "DR Congo", stockLevel: 180, reserved: 45, deliverable: 135 },
  { warehouse: "LME Rotterdam Vaults", location: "Rotterdam", commodity: "Copper Cathode", symbol: "Cu", grade: "Grade A", purity: "99.99%", origin: "Chile", stockLevel: 8500, reserved: 1200, deliverable: 7300 },
  
  // Shanghai
  { warehouse: "Baoshan Heavy Terminal", location: "Shanghai", commodity: "Neodymium-Praseodymium Oxide", symbol: "NdPr", grade: "99.5% Magnet Grade", purity: "99.6%", origin: "China (Bayan Obo)", stockLevel: 1250, reserved: 400, deliverable: 850 },
  { warehouse: "Baoshan Heavy Terminal", location: "Shanghai", commodity: "Dysprosium Oxide", symbol: "Dy", grade: "99.5% Heavy REE", purity: "99.5%", origin: "China (Ganzhou)", stockLevel: 450, reserved: 120, deliverable: 330 },
  { warehouse: "Baoshan Heavy Terminal", location: "Shanghai", commodity: "Spherical Graphite", symbol: "C_gr", grade: "Anode Premium", purity: "99.95%", origin: "China (Heilongjiang)", stockLevel: 2500, reserved: 800, deliverable: 1700 },
  
  // Baltimore
  { warehouse: "Chesapeake Logistics Center", location: "Baltimore", commodity: "Terbium Oxide", symbol: "Tb", grade: "99.9% Super Heavy", purity: "99.9%", origin: "China (Ganzhou)", stockLevel: 45, reserved: 15, deliverable: 30 },
  { warehouse: "Chesapeake Logistics Center", location: "Baltimore", commodity: "Titanium Sponge", symbol: "Ti", grade: "Aerospace Grade", purity: "99.7%", origin: "USA", stockLevel: 1200, reserved: 200, deliverable: 1000 },
  { warehouse: "Chesapeake Logistics Center", location: "Baltimore", commodity: "Lithium Carbonate", symbol: "Li", grade: "Battery Grade", purity: "99.5%", origin: "Canada", stockLevel: 320, reserved: 100, deliverable: 220 },

  // Singapore
  { warehouse: "Keppel Distripark Terminal", location: "Singapore", commodity: "Nickel Sulphate", symbol: "Ni", grade: "Hexahydrate Precursor", purity: "22.3% Ni", origin: "Indonesia", stockLevel: 4200, reserved: 800, deliverable: 3400 },
  { warehouse: "Keppel Distripark Terminal", location: "Singapore", commodity: "Tin Refined", symbol: "Sn", grade: "Solder Premium", purity: "99.85%", origin: "Indonesia", stockLevel: 800, reserved: 150, deliverable: 650 },

  // Port Hedland
  { warehouse: "Pilbara Port Hub", location: "Port Hedland", commodity: "Lithium Carbonate", symbol: "Li", grade: "Battery Grade", purity: "99.5%", origin: "Australia (Greenbushes)", stockLevel: 3500, reserved: 500, deliverable: 3000 }
];

// Recalculate warehouse loads
const updateWarehouseLoads = () => {
  warehouses.forEach(w => {
    const total = warehouseStocks
      .filter(s => s.warehouse === w.name)
      .reduce((sum, s) => sum + s.stockLevel, 0);
    w.currentLoad = Math.min(w.capacity, total);
  });
};
updateWarehouseLoads();

// Supply Chain Nodes
let supplyChainNodes: SupplyChainNode[] = [
  { id: "M01", name: "Bayan Obo Mine", type: "Mine", metal: "NdPr, La, Ce", location: "Inner Mongolia", country: "China", latitude: 41.7997, longitude: 109.9692, status: "Active", throughput: 55000, delayDays: 0, geopoliticalRisk: 75 },
  { id: "M02", name: "Mount Weld Mine", type: "Mine", metal: "NdPr, Heavy REEs", location: "Western Australia", country: "Australia", latitude: -28.7994, longitude: 122.2533, status: "Active", throughput: 22000, delayDays: 0, geopoliticalRisk: 15 },
  { id: "M03", name: "Mountain Pass Mine", type: "Mine", metal: "NdPr", location: "California", country: "USA", latitude: 35.4764, longitude: -115.5292, status: "Active", throughput: 40000, delayDays: 0, geopoliticalRisk: 10 },
  { id: "M04", name: "Ganzhou Heavy REE Deposits", type: "Mine", metal: "Dy, Tb, Y", location: "Jiangxi", country: "China", latitude: 25.8312, longitude: 114.9337, status: "Active", throughput: 15000, delayDays: 0, geopoliticalRisk: 80 },
  { id: "M05", name: "Greenbushes Lithium Mine", type: "Mine", metal: "Li", location: "Western Australia", country: "Australia", latitude: -33.8569, longitude: 116.0592, status: "Active", throughput: 195000, delayDays: 0, geopoliticalRisk: 15 },
  { id: "M06", name: "Kolwezi Cobalt & Copper Mine", type: "Mine", metal: "Co, Cu", location: "Lualaba Province", country: "DR Congo", latitude: -10.7183, longitude: 25.4839, status: "Active", throughput: 115000, delayDays: 2, geopoliticalRisk: 85 },

  { id: "R01", name: "Ganzhou Magnet Materials Refinery", type: "Refinery", metal: "NdPr, Dy, Tb", location: "Jiangxi", country: "China", latitude: 25.8500, longitude: 114.9000, status: "Active", throughput: 25000, delayDays: 0, geopoliticalRisk: 75 },
  { id: "R02", name: "Lynas Advanced Materials Plant (LAMP)", type: "Refinery", metal: "NdPr Oxide", location: "Kuantan", country: "Malaysia", latitude: 3.9747, longitude: 103.3894, status: "Active", throughput: 11000, delayDays: 0, geopoliticalRisk: 35 },
  { id: "R03", name: "Kwinana Lithium Hydroxide Plant", type: "Refinery", metal: "Li Hydroxide", location: "Kwinana", country: "Australia", latitude: -32.2530, longitude: 115.7728, status: "Active", throughput: 24000, delayDays: 0, geopoliticalRisk: 15 },
  
  { id: "P01", name: "Suez Transit Canal Route", type: "Port", metal: "Global Supply Lines", location: "Suez", country: "Egypt", latitude: 29.9668, longitude: 32.5498, status: "Active", throughput: 1500000, delayDays: 0, geopoliticalRisk: 65 },
  { id: "P02", name: "Port of Rotterdam Hub", type: "Port", metal: "European Entry Port", location: "Rotterdam", country: "Netherlands", latitude: 51.9244, longitude: 4.4777, status: "Active", throughput: 1200000, delayDays: 0, geopoliticalRisk: 10 },
  
  { id: "U01", name: "Gigafactory Nevada", type: "Manufacturer", metal: "NMC Battery Cells", location: "Nevada", country: "USA", latitude: 39.5393, longitude: -119.4398, status: "Active", throughput: 500000, delayDays: 0, geopoliticalRisk: 10 },
  { id: "U02", name: "Munich Automotive EV Complex", type: "Manufacturer", metal: "Electric Drivetrains", location: "Munich", country: "Germany", latitude: 48.1351, longitude: 11.5820, status: "Active", throughput: 350000, delayDays: 0, geopoliticalRisk: 10 }
];

// Shipping Routes
let shippingRoutes: ShippingRoute[] = [
  {
    id: "SR01",
    from: "Mount Weld Mine",
    to: "Lynas Advanced Materials Plant (LAMP)",
    fromCoords: [-28.7994, 122.2533],
    toCoords: [3.9747, 103.3894],
    status: "Operational",
    transitTimeDays: 12,
    activeHazards: []
  },
  {
    id: "SR02",
    from: "Lynas Advanced Materials Plant (LAMP)",
    to: "Port of Rotterdam Hub",
    fromCoords: [3.9747, 103.3894],
    toCoords: [51.9244, 4.4777],
    status: "Operational",
    transitTimeDays: 28,
    activeHazards: []
  },
  {
    id: "SR03",
    from: "Ganzhou Magnet Materials Refinery",
    to: "Munich Automotive EV Complex",
    fromCoords: [25.8500, 114.9000],
    toCoords: [48.1351, 11.5820],
    status: "Operational",
    transitTimeDays: 32,
    activeHazards: ["Suez Canal Congestion"]
  },
  {
    id: "SR04",
    from: "Kolwezi Cobalt & Copper Mine",
    to: "Port of Rotterdam Hub",
    fromCoords: [-10.7183, 25.4839],
    toCoords: [51.9244, 4.4777],
    status: "Operational",
    transitTimeDays: 25,
    activeHazards: ["Durban Port Delays"]
  }
];

// ==========================================
// 3. USER PORTFOLIO & CONTRACTS
// ==========================================
let portfolioCash = 25000000.00; // £25M cash
let portfolioPositions: PortfolioPosition[] = [
  { symbol: "NdPr", name: "Neodymium-Praseodymium Oxide", category: CommodityCategory.REE, amount: 25000, averageCost: 72.20, currentPrice: 74.50, value: 1862500, pnl: 57500, pnlPercent: 3.18, hedgedAmount: 10000, hedgeRatio: 40 },
  { symbol: "Li", name: "Lithium Carbonate", category: CommodityCategory.BATTERY, amount: 150, averageCost: 13900.00, currentPrice: 14200.00, value: 2130000, pnl: 45000, pnlPercent: 2.16, hedgedAmount: 50, hedgeRatio: 33.33 },
  { symbol: "Co", name: "Cobalt Metal", category: CommodityCategory.BATTERY, amount: 80, averageCost: 28200.00, currentPrice: 27500.00, value: 2200000, pnl: -56000, pnlPercent: -2.48, hedgedAmount: 0, hedgeRatio: 0 },
  { symbol: "Ti", name: "Titanium Sponge", category: CommodityCategory.INDUSTRIAL, amount: 15000, averageCost: 11.20, currentPrice: 11.50, value: 172500, pnl: 4500, pnlPercent: 2.68, hedgedAmount: 5000, hedgeRatio: 33.33 }
];

let contracts: Contract[] = [
  { id: "C-01", symbol: "NdPr", name: "Neodymium-Praseodymium Oxide", type: "Forward", direction: "SELL", amount: 10000, price: 73.50, currentValue: 745000, pnl: -10000, maturityDate: "2026-12-15", counterparty: "Siemens Wind Power AG", status: "Active" },
  { id: "C-02", symbol: "Li", name: "Lithium Carbonate", type: "Long-Term Supply Agreements", direction: "BUY", amount: 50, price: 13800.00, currentValue: 710000, pnl: 20000, maturityDate: "2027-06-30", counterparty: "Albemarle Corp", status: "Active" },
  { id: "C-03", symbol: "Ti", name: "Titanium Sponge", type: "Forward", direction: "SELL", amount: 5000, price: 11.80, currentValue: 57500, pnl: 1500, maturityDate: "2026-10-31", counterparty: "Lockheed Martin", status: "Active" }
];

let completedTrades: Order[] = [
  { id: "T-01", symbol: "NdPr", type: "BUY", price: 72.20, amount: 25000, timestamp: "2026-08-15T14:30:22.000Z", isFilled: true },
  { id: "T-02", symbol: "Li", type: "BUY", price: 13900.00, amount: 150, timestamp: "2026-08-18T10:15:45.000Z", isFilled: true },
  { id: "T-03", symbol: "Co", type: "BUY", price: 28200.00, amount: 80, timestamp: "2026-08-20T16:45:10.000Z", isFilled: true },
  { id: "T-04", symbol: "Ti", type: "BUY", price: 11.20, amount: 15000, timestamp: "2026-08-22T09:20:00.000Z", isFilled: true }
];

// Active Scenario impacts for RhinoRisk
let activeDisruptions: { [key: string]: ScenarioImpact } = {
  "china_restrictions": {
    name: "China Rare Earth Export Restrictions",
    description: "Export quota on heavy REEs cut by 25%. Restricts NdPr, Dysprosium, and Terbium shipping.",
    triggered: false,
    priceShocks: { "NdPr": 0.18, "Dy": 0.25, "Tb": 0.32, "La": 0.10, "Ce": 0.08, "Gd": 0.15 },
    shippingDelayIncreaseDays: 14,
    tariffIncreasePercent: 15
  },
  "suez_disruption": {
    name: "Suez Canal Transit Interruption",
    description: "Geopolitical conflict blockades the Bab el-Mandeb strait forcing shipping lines around Africa.",
    triggered: false,
    priceShocks: { "NdPr": 0.07, "Li": 0.06, "Co": 0.09, "Ni": 0.05, "Cu": 0.04, "Sn": 0.05 },
    shippingDelayIncreaseDays: 12,
    tariffIncreasePercent: 5
  },
  "ev_surge": {
    name: "Global EV Battery Cathode Surge",
    description: "US and European subsidies triple Gigafactory capacities simultaneously, squeezing raw materials.",
    triggered: false,
    priceShocks: { "Li": 0.28, "Ni": 0.15, "Co": 0.18, "C_gr": 0.22, "Mn": 0.10, "Cu": 0.12 },
    shippingDelayIncreaseDays: 3,
    tariffIncreasePercent: 0
  }
};

// ==========================================
// 4. TICKER LIVE MODULATION LOOP (Bloomberg-style simulated ticker feed)
// ==========================================
setInterval(() => {
  tickers = tickers.map(t => {
    // 1. Determine local market trend based on active disruptions
    let modifier = 0.0;
    Object.values(activeDisruptions).forEach(scen => {
      if (scen.triggered && scen.priceShocks[t.symbol]) {
        // Feed in standard positive premium drift when restriction is active
        modifier += scen.priceShocks[t.symbol] * 0.0025;
      }
    });

    // 2. Base noise
    const baseVolatility = t.category === CommodityCategory.REE ? 0.0015 : 0.001;
    const tickChange = (Math.random() - 0.49) * baseVolatility + modifier; // slightly upward bias if disruptions active
    const newPrice = Number((t.spotPrice * (1 + tickChange)).toFixed(2));
    const dayChangePercent = Number(((newPrice - t.prevPrice) / t.prevPrice * 100).toFixed(2));
    
    const high = Number(Math.max(t.high, newPrice).toFixed(2));
    const low = Number(Math.min(t.low, newPrice).toFixed(2));
    const volume = t.volume + Math.floor(Math.random() * 5);

    // Apply same drift to regional prices
    const regional = {
      china: Number((newPrice * (t.symbol === "NdPr" ? 0.95 : 1.0)).toFixed(2)),
      europe: Number((newPrice * (t.symbol === "NdPr" ? 1.15 : 1.05)).toFixed(2)),
      usa: Number((newPrice * (t.symbol === "NdPr" ? 1.21 : 1.08)).toFixed(2))
    };

    return {
      ...t,
      spotPrice: newPrice,
      change: dayChangePercent,
      high,
      low,
      volume,
      regional
    };
  });

  // Keep orderbooks closely tethered to new spots
  tickers.forEach(t => {
    const ob = orderBooks[t.symbol];
    if (ob) {
      const spot = t.spotPrice;
      const step = spot * 0.001;
      // Slither bid/ask arrays closer to spot
      ob.bids = ob.bids.map((b, idx) => ({
        price: Number((spot - (idx + 1) * step).toFixed(2)),
        amount: b.amount + (Math.random() > 0.8 ? (Math.random() > 0.5 ? 5 : -5) : 0),
        count: Math.max(1, b.count + (Math.random() > 0.95 ? (Math.random() > 0.5 ? 1 : -1) : 0))
      }));
      ob.asks = ob.asks.map((a, idx) => ({
        price: Number((spot + (idx + 1) * step).toFixed(2)),
        amount: a.amount + (Math.random() > 0.8 ? (Math.random() > 0.5 ? 5 : -5) : 0),
        count: Math.max(1, a.count + (Math.random() > 0.95 ? (Math.random() > 0.5 ? 1 : -1) : 0))
      }));
    }
  });

  // Periodically add standard historical price entries (e.g. roll forward 1 tick)
  tickers.forEach(t => {
    const history = historicalPrices[t.symbol];
    if (history && history.length > 0) {
      history[history.length - 1].price = t.spotPrice; // update current day's price
    }
  });

  // Modulate active portfolio positions
  portfolioPositions = portfolioPositions.map(pos => {
    const t = tickers.find(tk => tk.symbol === pos.symbol);
    if (t) {
      const val = pos.amount * t.spotPrice;
      const pnl = val - (pos.amount * pos.averageCost);
      const pnlPct = (pnl / (pos.amount * pos.averageCost)) * 100;
      return {
        ...pos,
        currentPrice: t.spotPrice,
        value: Number(val.toFixed(2)),
        pnl: Number(pnl.toFixed(2)),
        pnlPercent: Number(pnlPct.toFixed(2))
      };
    }
    return pos;
  });

}, 4000); // Ticks every 4 seconds

// ==========================================
// 5. HELPER: VALUE-AT-RISK CALCULATOR
// ==========================================
const calculateValueAtRisk = (): RiskProfile => {
  // Simple parametric VaR: PortfolioValue * Volatility * Z-Score (99% Z-score is 2.33)
  // Summing standard deviations assuming diversified metal index correlation
  let totalPortfolioValue = portfolioPositions.reduce((sum, p) => sum + p.value, 0);
  
  // Base portfolio volatility based on categories
  let weightedVol = 0;
  portfolioPositions.forEach(p => {
    let vol = 0.025; // 2.5% daily volatility for REEs
    if (p.category === CommodityCategory.BATTERY) vol = 0.020;
    else if (p.category === CommodityCategory.INDUSTRIAL) vol = 0.012;
    
    weightedVol += (p.value / totalPortfolioValue) * vol;
  });

  const dailyVaR = totalPortfolioValue * weightedVol * 2.33; // 99% 1-day Value-at-Risk
  
  // Calculate geopolitical exposure based on position metals
  const geopoliticalExposure: { [country: string]: number } = {
    "China": 0.48, // heavy REEs and refining dominance
    "Australia": 0.24, // lithium & heavy REEs mining
    "DR Congo": 0.18, // cobalt
    "Americas": 0.10
  };

  // Stress tests calculations
  const activeCount = Object.values(activeDisruptions).filter(s => s.triggered).length;
  
  const stressTestImpacts = Object.entries(activeDisruptions).map(([id, scen]) => {
    let estimatedPnLImpact = 0;
    
    // Calculate shock impact on each held position
    portfolioPositions.forEach(pos => {
      const shock = scen.priceShocks[pos.symbol] || 0;
      // Long position benefits if price goes UP, short contracts lose
      const inventoryGain = pos.amount * pos.currentPrice * shock;
      estimatedPnLImpact += inventoryGain;
    });

    // Calculate shock impact on active forward sell contracts (Short positions lose from rising prices!)
    contracts.forEach(contract => {
      if (contract.status === "Active") {
        const shock = scen.priceShocks[contract.symbol] || 0;
        const multiplier = contract.direction === "SELL" ? -1 : 1;
        const contractLoss = contract.amount * contract.price * shock * multiplier;
        estimatedPnLImpact += contractLoss;
      }
    });

    // Geopolitical rating mapping
    let riskRating: "Low" | "Moderate" | "High" | "Critical" = "Moderate";
    const netLossRatio = Math.abs(estimatedPnLImpact) / (totalPortfolioValue + portfolioCash);
    if (netLossRatio > 0.08) riskRating = "Critical";
    else if (netLossRatio > 0.04) riskRating = "High";
    else if (netLossRatio > 0.015) riskRating = "Moderate";
    else riskRating = "Low";

    return {
      scenarioId: id,
      scenarioName: scen.name,
      estimatedPnLImpact: Number(estimatedPnLImpact.toFixed(2)),
      riskRating
    };
  });

  return {
    valueAtRisk: Number(dailyVaR.toFixed(2)),
    varConfidence: 0.99,
    liquidityRiskScore: 32 + (activeCount * 12),
    counterpartyRiskRating: activeCount > 1 ? "BBB" : "A",
    activeDisruptionsCount: activeCount,
    geopoliticalExposure,
    stressTestImpacts
  };
};

// ==========================================
// 6. INDUSTRIAL DEMAND MODELS AND ECONOMIC MODELS
// ==========================================
const SECTOR_DEMAND: IndustryDemand[] = [
  { sector: "Electric Vehicles", sharePercent: 35, growthTrend: 18.5, keyMetals: ["NdPr", "Dy", "Li", "Ni", "Co", "C_gr", "Mn", "Cu"] },
  { sector: "Wind Turbines", sharePercent: 20, growthTrend: 12.2, keyMetals: ["NdPr", "Dy", "Tb", "Cu", "Al", "Fe_st"] },
  { sector: "Defense & Aerospace", sharePercent: 15, growthTrend: 8.4, keyMetals: ["Tb", "Sm", "Gd", "Ti", "W", "Mo", "Mg"] },
  { sector: "Electronics & Robotics", sharePercent: 18, growthTrend: 9.8, keyMetals: ["NdPr", "Sn", "Zn", "Al", "Cu"] },
  { sector: "Power Grid Infrastructure", sharePercent: 12, growthTrend: 6.5, keyMetals: ["Cu", "Al", "Zn", "V"] }
];

// Calculate current total value of global rare earth inventories
const calculateGlobalRareEarthInventoryValue = () => {
  let totalValue = 0;
  warehouseStocks.forEach(s => {
    const isREE = COMMODITY_LIST.find(c => c.symbol === s.symbol && c.category === CommodityCategory.REE);
    if (isREE) {
      const ticker = tickers.find(t => t.symbol === s.symbol);
      if (ticker) {
        // stock level is in tonnes. Spot price of REEs is per kg! 1 tonne = 1000 kg.
        totalValue += s.stockLevel * 1000 * ticker.spotPrice;
      }
    }
  });
  return totalValue;
};

// ==========================================
// 7. EXPRESS SERVER REST API ENDPOINTS
// ==========================================

// GET tickers
app.get("/api/market/ticker", (req, res) => {
  res.json({ tickers });
});

// GET specific ticker history
app.get("/api/market/history/:symbol", (req, res) => {
  const symbol = req.params.symbol;
  const history = historicalPrices[symbol];
  if (history) {
    res.json({ symbol, history });
  } else {
    res.status(404).json({ error: "Symbol not found" });
  }
});

// GET specific ticker depth
app.get("/api/market/depth/:symbol", (req, res) => {
  const symbol = req.params.symbol;
  const depth = orderBooks[symbol];
  const t = tickers.find(x => x.symbol === symbol);
  if (depth && t) {
    res.json({ depth, spotPrice: t.spotPrice });
  } else {
    res.status(404).json({ error: "Order book not found" });
  }
});

// POST trade execution (MarketEngine Matching)
app.post("/api/market/trade", (req, res) => {
  const { symbol, type, price, amount, contractType, counterparty, maturityDays } = req.body;
  
  const ticker = tickers.find(t => t.symbol === symbol);
  if (!ticker) {
    return res.status(400).json({ error: "Invalid symbol" });
  }

  const tradeAmount = Number(amount);
  const tradePrice = Number(price);
  const totalCost = tradeAmount * tradePrice;

  if (type === "BUY" && portfolioCash < totalCost) {
    return res.status(400).json({ error: "Insufficient available cash capital for settlement." });
  }

  // Handle different contract structures
  const currentCategory = ticker.category;
  const isSpot = !contractType || contractType === "Spot";

  const orderId = `T-${Date.now().toString().slice(-6)}`;
  
  if (isSpot) {
    // 1. Update Portfolio Positions directly
    let pos = portfolioPositions.find(p => p.symbol === symbol);
    if (type === "BUY") {
      portfolioCash -= totalCost;
      if (pos) {
        const newAmt = pos.amount + tradeAmount;
        const newCost = ((pos.amount * pos.averageCost) + totalCost) / newAmt;
        pos.amount = newAmt;
        pos.averageCost = Number(newCost.toFixed(2));
      } else {
        portfolioPositions.push({
          symbol,
          name: ticker.name,
          category: ticker.category,
          amount: tradeAmount,
          averageCost: tradePrice,
          currentPrice: ticker.spotPrice,
          value: totalCost,
          pnl: 0,
          pnlPercent: 0,
          hedgedAmount: 0,
          hedgeRatio: 0
        });
      }

      // Add to Rotterdam physical stock
      let stock = warehouseStocks.find(s => s.symbol === symbol && s.warehouse === "LME Rotterdam Vaults");
      if (stock) {
        // If unit of symbol is kg, convert to tonnes
        const tonnes = ticker.unit === "kg" ? (tradeAmount / 1000) : tradeAmount;
        stock.stockLevel = Number((stock.stockLevel + tonnes).toFixed(2));
        stock.deliverable = Number((stock.deliverable + tonnes).toFixed(2));
      }
    } else {
      // SELL Spot
      if (!pos || pos.amount < tradeAmount) {
        return res.status(400).json({ error: "Insufficient inventory stock holding." });
      }
      portfolioCash += totalCost;
      pos.amount -= tradeAmount;
      if (pos.amount === 0) {
        portfolioPositions = portfolioPositions.filter(p => p.symbol !== symbol);
      }

      // Decrement warehouse stock
      let stock = warehouseStocks.find(s => s.symbol === symbol && s.warehouse === "LME Rotterdam Vaults");
      if (stock) {
        const tonnes = ticker.unit === "kg" ? (tradeAmount / 1000) : tradeAmount;
        stock.stockLevel = Number((Math.max(0, stock.stockLevel - tonnes)).toFixed(2));
        stock.deliverable = Number((Math.max(0, stock.deliverable - tonnes)).toFixed(2));
      }
    }

    completedTrades.unshift({
      id: orderId,
      symbol,
      type,
      price: tradePrice,
      amount: tradeAmount,
      timestamp: new Date().toISOString(),
      isFilled: true
    });
  } else {
    // Forward or Long-Term agreement
    const maturity = new Date();
    maturity.setDate(maturity.getDate() + (Number(maturityDays) || 90));
    
    const newContract: Contract = {
      id: `C-${Date.now().toString().slice(-4)}`,
      symbol,
      name: ticker.name,
      type: contractType,
      direction: type,
      amount: tradeAmount,
      price: tradePrice,
      currentValue: tradeAmount * ticker.spotPrice,
      pnl: 0,
      maturityDate: maturity.toISOString().split("T")[0],
      counterparty: counterparty || "Over-The-Counter Pool",
      status: "Active"
    };

    contracts.unshift(newContract);

    // Adjust position hedging indices
    if (type === "SELL") {
      let pos = portfolioPositions.find(p => p.symbol === symbol);
      if (pos) {
        pos.hedgedAmount += tradeAmount;
        pos.hedgeRatio = Number(((pos.hedgedAmount / pos.amount) * 100).toFixed(2));
      }
    }
  }

  updateWarehouseLoads();
  res.json({
    success: true,
    cash: portfolioCash,
    positions: portfolioPositions,
    contracts,
    trade: { id: orderId, symbol, type, price: tradePrice, amount: tradeAmount }
  });
});

// GET inventory and warehouse levels
app.get("/api/inventory", (req, res) => {
  res.json({
    warehouses,
    stocks: warehouseStocks,
    globalRareEarthValue: calculateGlobalRareEarthInventoryValue()
  });
});

// GET supply chain details
app.get("/api/supply-chain", (req, res) => {
  res.json({
    nodes: supplyChainNodes,
    routes: shippingRoutes
  });
});

// GET current risk metrics
app.get("/api/risk/assessment", (req, res) => {
  const profile = calculateValueAtRisk();
  res.json({
    profile,
    activeDisruptions: Object.entries(activeDisruptions).map(([id, item]) => ({ id, ...item }))
  });
});

// POST toggle disruption scenario
app.post("/api/risk/toggle-disruption", (req, res) => {
  const { id } = req.body;
  if (activeDisruptions[id]) {
    activeDisruptions[id].triggered = !activeDisruptions[id].triggered;
    
    // Dynamically update corresponding node or shipping status
    if (id === "china_restrictions") {
      const isRestricted = activeDisruptions[id].triggered;
      supplyChainNodes.forEach(n => {
        if (n.country === "China") {
          n.status = isRestricted ? "Restricted" : "Active";
          n.delayDays = isRestricted ? 10 : 0;
        }
      });
      shippingRoutes.forEach(r => {
        if (r.from.includes("China") || r.id === "SR03") {
          r.status = isRestricted ? "Delayed" : "Operational";
          r.transitTimeDays = isRestricted ? 46 : 32;
        }
      });
    } else if (id === "suez_disruption") {
      const isBlocked = activeDisruptions[id].triggered;
      const suezNode = supplyChainNodes.find(n => n.name === "Suez Transit Canal Route");
      if (suezNode) {
        suezNode.status = isBlocked ? "Offline" : "Active";
        suezNode.delayDays = isBlocked ? 15 : 0;
      }
      shippingRoutes.forEach(r => {
        if (r.activeHazards.includes("Suez Canal Congestion") || r.id === "SR03" || r.id === "SR02") {
          r.status = isBlocked ? "Congested" : "Operational";
          r.transitTimeDays = isBlocked ? 44 : 28;
        }
      });
    }

    res.json({ success: true, activeDisruptions: Object.entries(activeDisruptions).map(([key, value]) => ({ id: key, ...value })) });
  } else {
    res.status(404).json({ error: "Disruption ID not found" });
  }
});

// GET portfolio status
app.get("/api/portfolio", (req, res) => {
  const totalPositionsValue = portfolioPositions.reduce((sum, p) => sum + p.value, 0);
  const totalValue = totalPositionsValue + portfolioCash;
  const initialCapital = 30000000.00; // £30M initial
  const totalPnL = totalValue - initialCapital;
  
  res.json({
    cash: portfolioCash,
    positions: portfolioPositions,
    contracts,
    trades: completedTrades,
    summary: {
      totalPositionsValue,
      totalPortfolioValue: totalValue,
      totalPnL,
      pnlPercent: Number(((totalPnL / initialCapital) * 100).toFixed(2))
    }
  });
});

// POST contract settlement
app.post("/api/portfolio/settle", (req, res) => {
  const { contractId } = req.body;
  const index = contracts.findIndex(c => c.id === contractId);
  if (index === -1) {
    return res.status(404).json({ error: "Contract not found" });
  }

  const c = contracts[index];
  const ticker = tickers.find(t => t.symbol === c.symbol);
  if (!ticker) {
    return res.status(400).json({ error: "Commodity spot listing unavailable" });
  }

  // Calculate settlement settlement value
  const spotPriceAtSettlement = ticker.spotPrice;
  const unitFactor = 1; // already matched in units

  // If BUY contract, we locked in buying at c.price. Current spot is spotPriceAtSettlement.
  // PnL = (spot - contractPrice) * amount
  // If SELL contract, we locked in selling at c.price. Current spot is spotPriceAtSettlement.
  // PnL = (contractPrice - spot) * amount
  const directionMultiplier = c.direction === "BUY" ? 1 : -1;
  const settlementPnL = (spotPriceAtSettlement - c.price) * c.amount * directionMultiplier;

  portfolioCash += settlementPnL;
  
  // Create spot trade corresponding to physical delivery/receipt
  const tradeRecord: Order = {
    id: `SET-${Date.now().toString().slice(-4)}`,
    symbol: c.symbol,
    type: c.direction === "BUY" ? "BUY" : "SELL",
    price: c.price,
    amount: c.amount,
    timestamp: new Date().toISOString(),
    isFilled: true
  };
  completedTrades.unshift(tradeRecord);

  // Settle position hedge indicators
  let pos = portfolioPositions.find(p => p.symbol === c.symbol);
  if (pos && c.direction === "SELL") {
    pos.hedgedAmount = Math.max(0, pos.hedgedAmount - c.amount);
    pos.hedgeRatio = pos.amount > 0 ? Number(((pos.hedgedAmount / pos.amount) * 100).toFixed(2)) : 0;
  }

  // Remove contract from active list
  contracts.splice(index, 1);

  res.json({
    success: true,
    cash: portfolioCash,
    contracts,
    positions: portfolioPositions,
    settlementPnL
  });
});

// POST 10-30 year long-term simulation
app.post("/api/simulation/run", (req, res) => {
  const { years, toggles } = req.body;
  const duration = Number(years) || 10;
  
  // Simple simulation matrix engine
  const results: SimulationResult[] = [];
  const activeToggles = toggles || {};

  // Setup baseline pricing and multipliers
  tickers.forEach(t => {
    let price = t.spotPrice;
    let demand = t.volume * 8.5; // proxy for global demand
    let supply = t.volume * 8.4; // proxy for global supply
    let inventory = t.volume * 4.0;

    for (let yr = 1; yr <= duration; yr++) {
      // 1. Demand & Supply Growth Trends
      let demandGrowth = 0.04; // baseline 4% CAGR
      let supplyGrowth = 0.035; // baseline 3.5% CAGR

      if (t.category === CommodityCategory.REE) {
        demandGrowth = 0.08; // magnets demand
        if (activeToggles.evSurge) demandGrowth += 0.05;
        if (activeToggles.substitution) demandGrowth -= 0.045; // EV motors substitute REEs
      } else if (t.category === CommodityCategory.BATTERY) {
        demandGrowth = 0.12;
        if (activeToggles.evSurge) demandGrowth += 0.06;
      }

      if (activeToggles.recycling) {
        supplyGrowth += 0.02; // recycling bolsters circular supply
      }
      if (activeToggles.newRefinery && t.category === CommodityCategory.REE) {
        supplyGrowth += 0.035; // Texas or allied refineries boost non-China supply
      }
      if (activeToggles.chinaRestrictions && t.category === CommodityCategory.REE) {
        supplyGrowth -= 0.03; // restriction cuts global supply
      }

      demand = demand * (1 + demandGrowth);
      supply = supply * (1 + supplyGrowth);
      
      // Market balance alters price
      const imbalance = (demand - supply) / supply; // > 0 means shortage
      const priceElasticity = t.category === CommodityCategory.REE ? 1.8 : 1.2;
      const priceDrift = 1 + (imbalance * priceElasticity) + (Math.random() * 0.04 - 0.02);
      
      price = price * priceDrift;
      inventory = Math.max(0, inventory + (supply - demand));

      // Economic models for a typical mine operation in portfolio
      const revenue = supply * 0.15 * price * 0.001; // million GBP
      const processingCost = revenue * 0.45 * (activeToggles.chinaRestrictions ? 1.15 : 1.0);
      const ebitda = revenue - processingCost;
      const operatingMargin = (ebitda / revenue) * 100;
      const roi = operatingMargin * 0.4;
      const npv = ebitda * 5.2; // capitalized
      const irr = 12 + (operatingMargin * 0.3);

      const econ: EconomicMetrics = {
        mineEbitda: Number(ebitda.toFixed(2)),
        operatingMargin: Number(operatingMargin.toFixed(2)),
        roi: Number(roi.toFixed(2)),
        cashFlow: Number((ebitda * 0.8).toFixed(2)),
        npv: Number(npv.toFixed(2)),
        irr: Number(irr.toFixed(2))
      };

      // Add to results
      if (!results[yr - 1]) {
        results.push({
          year: yr,
          prices: {},
          globalDemand: {},
          globalSupply: {},
          inventories: {},
          economicMetrics: econ
        });
      }
      results[yr - 1].prices[t.symbol] = Number(price.toFixed(2));
      results[yr - 1].globalDemand[t.symbol] = Math.round(demand);
      results[yr - 1].globalSupply[t.symbol] = Math.round(supply);
      results[yr - 1].inventories[t.symbol] = Math.round(inventory);
    }
  });

  res.json({ results });
});

// POST quantitative forecasting (ARIMA/GARCH statistical modeling)
app.post("/api/quant/forecast", (req, res) => {
  const { symbol } = req.body;
  const ticker = tickers.find(t => t.symbol === symbol);
  if (!ticker) {
    return res.status(404).json({ error: "Listing symbol not found" });
  }

  // Generate standard 12-month GARCH/ARIMA forecast series
  const months = ["Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"];
  let basePrice = ticker.spotPrice;
  const history = historicalPrices[symbol] || [];
  
  // Calculate historical volatility
  let pricesArr = history.map(h => h.price);
  let returns = [];
  for (let i = 1; i < pricesArr.length; i++) {
    returns.push((pricesArr[i] - pricesArr[i - 1]) / pricesArr[i - 1]);
  }
  const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length || 0.0005;
  const vol = Math.sqrt(returns.map(x => Math.pow(x - meanReturn, 2)).reduce((a, b) => a + b, 0) / returns.length) || 0.015;

  const forecast = months.map((month, index) => {
    // Standard geometric Brownian drift for ARIMA mean forecast
    const drift = meanReturn * 21; // 21 trading days/month
    const randomShock = (Math.random() - 0.48) * vol * Math.sqrt(21);
    
    basePrice = basePrice * (1 + drift + randomShock);
    
    // GARCH conditional volatility envelope width grows over time
    const garchVol = vol * Math.sqrt(21) * Math.sqrt(index + 1);
    const upperLimit = basePrice * (1 + 1.96 * garchVol);
    const lowerLimit = basePrice * (1 - 1.96 * garchVol);

    return {
      month,
      forecast: Number(basePrice.toFixed(2)),
      upper95: Number(upperLimit.toFixed(2)),
      lower95: Number(lowerLimit.toFixed(2))
    };
  });

  res.json({ symbol, forecast });
});

// ==========================================
// 8. SERVER-SIDE GEMINI AI EXCHANGE ARCHITECT & PORTFOLIO RISK SPECIALIST
// ==========================================
app.post("/api/quant/ai-analyst", async (req, res) => {
  const { prompt, focusSymbol } = req.body;

  try {
    // Collect the entire real-time exchange state to ground the model perfectly
    const rareEarthVal = calculateGlobalRareEarthInventoryValue();
    const riskProfile = calculateValueAtRisk();
    const portfolioSummary = portfolioPositions.map(p => `${p.symbol} (${p.name}): ${p.amount} ${tickers.find(t => t.symbol === p.symbol)?.unit || 'units'} @ Cost £${p.averageCost}/unit (Spot £${p.currentPrice})`).join("; ");
    const contractsSummary = contracts.map(c => `${c.type} ${c.direction} ${c.amount} ${c.symbol} @ locked £${c.price} (Expires: ${c.maturityDate})`).join("; ");
    const activeDisruptionsList = Object.entries(activeDisruptions)
      .filter(([_, v]) => v.triggered)
      .map(([_, v]) => v.name)
      .join(", ") || "None";

    const systemInstruction = `You are the Lead Commodities Exchange Architect, Metals Analyst, and Portfolio Risk Systems Engineer at RhinoBank Commodities Exchange (RCX).
Your task is to analyze critical industrial minerals, rare earth elements, and battery metals market pricing and supply chain exposures.

We are NOT a cryptocurrency platform. We handle physically backed industrial materials: Rare Earths (NdPr, Dysprosium, Terbium), Battery Metals (Lithium, Nickel, Cobalt, Spherical Graphite), and Strategic Aerospace/Defense Materials (Titanium, Tungsten).

Here is the current real-time platform state you MUST ground your analysis in:
- Active Global Geopolitical/Supply Chain Disruptions: ${activeDisruptionsList}
- Total value of global Rare Earth inventories in RCX Rotterdam/Shanghai vaults: £${rareEarthVal.toLocaleString()}
- Daily Parametric Value-at-Risk (99% Confidence, 1-Day): £${riskProfile.valueAtRisk.toLocaleString()}
- User's physical inventory holdings: [ ${portfolioSummary} ]
- User's active OTC/Exchange derivative contracts: [ ${contractsSummary} ]
- Base Portfolio Cash: £${portfolioCash.toLocaleString()}

Always return highly technical, authoritative, Bloomberg Terminal style analysis. Include specific calculations where possible, mention industrial supply/refining flows, and avoid generic market filler. Structure your response using markdown.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction
      }
    });

    const report = response.text || "Failed to generate quantitative market analysis.";
    res.json({ report });
  } catch (error: any) {
    console.error("Gemini AI Analyst error:", error);
    res.status(500).json({ error: `Quant Systems Connection Interrupted: ${error.message || error}` });
  }
});

// ==========================================
// 9. VITE AND STATIC ASSETS SERVING SETUP
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Setup Vite middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    // Production serving
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RCX Backend] Market infrastructure engine running on http://localhost:${PORT}`);
    console.log(`[RCX Backend] Active mode: ${process.env.NODE_ENV || 'development'}`);
  });
}

startServer();
