import React, { useState, useEffect } from "react";
import { TerminalHeader } from "./components/TerminalHeader";
import { MarketModule } from "./components/MarketModule";
import { OrderDepthTicket } from "./components/OrderDepthTicket";
import { InteractiveMap } from "./components/InteractiveMap";
import { RiskCenter } from "./components/RiskCenter";
import { WarehouseModule } from "./components/WarehouseModule";
import { QuantAnalyst } from "./components/QuantAnalyst";
import { SimEngine } from "./components/SimEngine";
import { PortfolioModule } from "./components/PortfolioModule";
import { 
  MarketTicker, 
  PortfolioPosition, 
  Contract, 
  Order, 
  Warehouse, 
  WarehouseStock, 
  SupplyChainNode, 
  ShippingRoute, 
  RiskProfile, 
  ScenarioImpact 
} from "./types";
import { Globe, BarChart3, ShieldAlert, Play, Briefcase, RefreshCw, Layers } from "lucide-react";

export default function App() {
  // Centralized State
  const [tickers, setTickers] = useState<MarketTicker[]>([]);
  const [selectedSymbol, setSelectedSymbol] = useState<string>("NdPr");
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<string>("intel");
  const [isPolling, setIsPolling] = useState<boolean>(true);

  // Portfolio state
  const [portfolioCash, setPortfolioCash] = useState<number>(25000000);
  const [positions, setPositions] = useState<PortfolioPosition[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [completedTrades, setCompletedTrades] = useState<Order[]>([]);
  const [portfolioSummary, setPortfolioSummary] = useState({
    totalPositionsValue: 0,
    totalPortfolioValue: 25000000,
    totalPnL: 0,
    pnlPercent: 0
  });

  // Inventory state
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [warehouseStocks, setWarehouseStocks] = useState<WarehouseStock[]>([]);
  const [globalRareEarthValue, setGlobalRareEarthValue] = useState<number>(0);

  // Supply Chain state
  const [supplyChainNodes, setSupplyChainNodes] = useState<SupplyChainNode[]>([]);
  const [shippingRoutes, setShippingRoutes] = useState<ShippingRoute[]>([]);

  // Risk state
  const [riskProfile, setRiskProfile] = useState<RiskProfile | undefined>(undefined);
  const [activeDisruptions, setActiveDisruptions] = useState<(ScenarioImpact & { id: string })[]>([]);

  // Fetch initial datasets and start polling loop
  useEffect(() => {
    fetchAllData();
    const interval = setInterval(() => {
      if (isPolling) {
        fetchTickersAndPortfolio();
      }
    }, 4000); // Polls every 4 seconds to match backend ticker tick-rates
    return () => clearInterval(interval);
  }, [isPolling]);

  const fetchAllData = async () => {
    await Promise.all([
      fetchTickersAndPortfolio(),
      fetchInventory(),
      fetchSupplyChain()
    ]);
  };

  const fetchTickersAndPortfolio = async () => {
    try {
      const [tickerRes, portfolioRes, riskRes] = await Promise.all([
        fetch("/api/market/ticker"),
        fetch("/api/portfolio"),
        fetch("/api/risk/assessment")
      ]);

      if (tickerRes.ok) {
        const data = await tickerRes.json();
        setTickers(data.tickers);
      }

      if (portfolioRes.ok) {
        const data = await portfolioRes.json();
        setPortfolioCash(data.cash);
        setPositions(data.positions);
        setContracts(data.contracts);
        setCompletedTrades(data.trades);
        setPortfolioSummary(data.summary);
      }

      if (riskRes.ok) {
        const data = await riskRes.json();
        setRiskProfile(data.profile);
        setActiveDisruptions(data.activeDisruptions);
      }
    } catch (e) {
      console.error("Central market data feed polling failed", e);
    }
  };

  const fetchInventory = async () => {
    try {
      const res = await fetch("/api/inventory");
      if (res.ok) {
        const data = await res.json();
        setWarehouses(data.warehouses);
        setWarehouseStocks(data.stocks);
        setGlobalRareEarthValue(data.globalRareEarthValue);
      }
    } catch (e) {
      console.error("Inventory ledger fetching failed", e);
    }
  };

  const fetchSupplyChain = async () => {
    try {
      const res = await fetch("/api/supply-chain");
      if (res.ok) {
        const data = await res.json();
        setSupplyChainNodes(data.nodes);
        setShippingRoutes(data.routes);
      }
    } catch (e) {
      console.error("Supply chain network fetching failed", e);
    }
  };

  const handlePlaceTrade = async (tradeData: {
    symbol: string;
    type: "BUY" | "SELL";
    price: number;
    amount: number;
    contractType: string;
    counterparty?: string;
    maturityDays?: number;
  }) => {
    const res = await fetch("/api/market/trade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tradeData)
    });

    if (res.ok) {
      // Force instant sync
      await fetchTickersAndPortfolio();
      await fetchInventory();
    } else {
      const err = await res.json();
      throw new Error(err.error || "Order matching or settlement failed.");
    }
  };

  const handleSettleContract = async (contractId: string) => {
    try {
      const res = await fetch("/api/portfolio/settle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contractId })
      });

      if (res.ok) {
        await fetchTickersAndPortfolio();
        await fetchInventory();
      } else {
        const err = await res.json();
        alert(`Settlement Refused: ${err.error}`);
      }
    } catch (e) {
      console.error("Contract settlement failed", e);
    }
  };

  const handleToggleDisruption = async (id: string) => {
    try {
      const res = await fetch("/api/risk/toggle-disruption", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });

      if (res.ok) {
        await fetchTickersAndPortfolio();
        await fetchSupplyChain();
      }
    } catch (e) {
      console.error("Disruption toggle failed", e);
    }
  };

  // Find active focused ticker
  const activeTicker = tickers.find(t => t.symbol === selectedSymbol);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans" id="rcx-workspace">
      {/* 1. Terminal Header Bar */}
      <TerminalHeader
        cash={portfolioCash}
        portfolioValue={portfolioSummary.totalPortfolioValue}
        pnl={portfolioSummary.totalPnL}
        pnlPercent={portfolioSummary.pnlPercent}
        varValue={riskProfile?.valueAtRisk || 0}
        activeDisruptionsCount={riskProfile?.activeDisruptionsCount || 0}
        isPolling={isPolling}
        onRefresh={fetchAllData}
      />

      {/* 2. Main Bento Layout workspace grid */}
      <div className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-4 p-4 overflow-hidden" id="rcx-main-grid">
        
        {/* Left Stage Column (75% space on desktop) */}
        <div className="xl:col-span-9 flex flex-col gap-4 overflow-y-auto" id="left-stage">
          
          {/* Workspace Tab bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 flex flex-wrap gap-1 select-none" id="workspace-tabs">
            <button
              onClick={() => setActiveWorkspaceTab("intel")}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold cursor-pointer transition-colors ${
                activeWorkspaceTab === "intel" 
                  ? "bg-amber-500 text-slate-950 shadow" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>GEOSPATIAL INTEL & VAULTS</span>
            </button>
            <button
              onClick={() => setActiveWorkspaceTab("quant")}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold cursor-pointer transition-colors ${
                activeWorkspaceTab === "quant" 
                  ? "bg-amber-500 text-slate-950 shadow" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>QUANT FORECASTS & AI ANALYST</span>
            </button>
            <button
              onClick={() => setActiveWorkspaceTab("risk")}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold cursor-pointer transition-colors ${
                activeWorkspaceTab === "risk" 
                  ? "bg-amber-500 text-slate-950 shadow" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>RHINORISK ASSESSMENT</span>
            </button>
            <button
              onClick={() => setActiveWorkspaceTab("sim")}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold cursor-pointer transition-colors ${
                activeWorkspaceTab === "sim" 
                  ? "bg-amber-500 text-slate-950 shadow" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"
              }`}
            >
              <Play className="w-4 h-4" />
              <span>10-30Y MACRO SIMULATOR</span>
            </button>
            <button
              onClick={() => setActiveWorkspaceTab("portfolio")}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-mono font-bold cursor-pointer transition-colors ${
                activeWorkspaceTab === "portfolio" 
                  ? "bg-amber-500 text-slate-950 shadow" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span>PORTFOLIO & AUDIT LOGS</span>
            </button>
          </div>

          {/* Tab Workspaces Stages */}
          <div className="flex-1" id="workspace-stage">
            {activeWorkspaceTab === "intel" && (
              <div className="grid grid-cols-1 gap-4" id="intel-workspace">
                <InteractiveMap 
                  nodes={supplyChainNodes} 
                  routes={shippingRoutes} 
                  activeSymbol={selectedSymbol} 
                />
                <WarehouseModule 
                  warehouses={warehouses} 
                  stocks={warehouseStocks} 
                  globalRareEarthValue={globalRareEarthValue} 
                />
              </div>
            )}

            {activeWorkspaceTab === "quant" && (
              <div className="h-full" id="quant-workspace">
                <QuantAnalyst 
                  tickers={tickers} 
                  selectedSymbol={selectedSymbol} 
                />
              </div>
            )}

            {activeWorkspaceTab === "risk" && (
              <div className="h-full" id="risk-workspace">
                <RiskCenter 
                  riskProfile={riskProfile} 
                  activeDisruptions={activeDisruptions} 
                  onToggleDisruption={handleToggleDisruption}
                  positions={positions}
                  contracts={contracts}
                />
              </div>
            )}

            {activeWorkspaceTab === "sim" && (
              <div className="h-full" id="sim-workspace">
                <SimEngine 
                  selectedSymbol={selectedSymbol} 
                />
              </div>
            )}

            {activeWorkspaceTab === "portfolio" && (
              <div className="h-full" id="portfolio-workspace">
                <PortfolioModule 
                  cash={portfolioCash}
                  positions={positions}
                  contracts={contracts}
                  trades={completedTrades}
                  onSettleContract={handleSettleContract}
                  summary={portfolioSummary}
                />
              </div>
            )}
          </div>

          {/* Always-on Global Ticker Board at Bottom Left */}
          <div className="flex-1" id="global-ticker-stage">
            <MarketModule 
              tickers={tickers} 
              selectedSymbol={selectedSymbol} 
              onSelectSymbol={setSelectedSymbol} 
            />
          </div>

        </div>

        {/* Right Sidebar Column (Always accessible Order book & Settle Ticket - 25% space) */}
        <div className="xl:col-span-3 flex flex-col gap-4 overflow-y-auto" id="right-sidebar">
          
          <OrderDepthTicket
            selectedTicker={activeTicker}
            onPlaceTrade={handlePlaceTrade}
            portfolioCash={portfolioCash}
          />

          {/* Quick Terminal Guide Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs font-mono" id="terminal-guide">
            <h4 className="font-bold text-slate-300 border-b border-slate-800 pb-1.5 uppercase flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-amber-500" />
              Clearing & Settlement Info
            </h4>
            <div className="space-y-2 mt-2 text-slate-400 text-[11px] leading-relaxed">
              <p>
                All transactions on the <strong className="text-slate-200">RCX Core</strong> execute through physically-backed contracts.
              </p>
              <p>
                Use the derivative tabs for locking forward commodity pricing. Settling a forward converts physical balances into corresponding vault storage inventories.
              </p>
              <div className="bg-slate-950 p-2 border border-slate-850 rounded text-[10px] text-slate-500 font-sans">
                Notice: All prices and forecasts simulate econometric flows and do not represent real-life trading positions.
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
