export enum CommodityCategory {
  REE = "Rare Earth Elements",
  BATTERY = "Battery Metals",
  INDUSTRIAL = "Industrial Metals"
}

export interface CommodityInfo {
  symbol: string;
  name: string;
  category: CommodityCategory;
  purity: string; // e.g., "99.5% Min"
  unit: string; // e.g., "kg" or "tonne"
  description: string;
}

export interface RegionalPrice {
  china: number;
  europe: number;
  usa: number;
}

export interface MarketTicker {
  symbol: string;
  name: string;
  category: CommodityCategory;
  spotPrice: number; // base price in GBP (£) per unit (kg or tonne)
  prevPrice: number;
  change: number; // percentage change
  high: number;
  low: number;
  volume: number; // daily volume in units
  regional: RegionalPrice;
  unit: string;
  premiums: {
    transport: number;
    purity: number; // adjustment per 0.1% purity increase
    warehouse: number; // storage fee per unit/day
  };
}

export interface Order {
  id: string;
  symbol: string;
  type: "BUY" | "SELL";
  price: number;
  amount: number; // quantity in kg or tonnes
  timestamp: string;
  isFilled: boolean;
}

export interface OrderBook {
  symbol: string;
  bids: { price: number; amount: number; count: number }[];
  asks: { price: number; amount: number; count: number }[];
}

export interface WarehouseStock {
  warehouse: string;
  location: string;
  commodity: string;
  symbol: string;
  grade: string;
  purity: string;
  origin: string;
  stockLevel: number; // tonnes
  reserved: number; // tonnes
  deliverable: number; // tonnes
}

export interface Warehouse {
  id: string;
  name: string;
  location: string;
  country: string;
  latitude: number;
  longitude: number;
  capacity: number; // max tonnes
  currentLoad: number; // current tonnes
}

export interface SupplyChainNode {
  id: string;
  name: string;
  type: "Mine" | "Refinery" | "Processor" | "Warehouse" | "Manufacturer" | "Port";
  metal: string;
  location: string;
  country: string;
  latitude: number;
  longitude: number;
  status: "Active" | "Delayed" | "Restricted" | "Offline";
  throughput: number; // tonnes/year
  delayDays: number;
  geopoliticalRisk: number; // 0-100 scale
}

export interface ShippingRoute {
  id: string;
  from: string; // SupplyChainNode name
  to: string; // SupplyChainNode name
  fromCoords: [number, number];
  toCoords: [number, number];
  status: "Operational" | "Delayed" | "Congested" | "Blocked";
  transitTimeDays: number;
  activeHazards: string[];
}

export interface PortfolioPosition {
  symbol: string;
  name: string;
  category: CommodityCategory;
  amount: number; // inventory hold in units
  averageCost: number; // in GBP
  currentPrice: number;
  value: number;
  pnl: number;
  pnlPercent: number;
  hedgedAmount: number; // amount hedged with forwards
  hedgeRatio: number; // percentage hedged
}

export interface Contract {
  id: string;
  symbol: string;
  name: string;
  type: string;
  direction: "BUY" | "SELL";
  amount: number;
  price: number; // lock-in price
  currentValue: number;
  pnl: number;
  maturityDate: string;
  counterparty: string;
  status: "Active" | "Settled" | "Defaulted";
}

export interface ScenarioImpact {
  name: string;
  description: string;
  triggered: boolean;
  priceShocks: { [symbol: string]: number }; // percentage change, e.g. 0.18 for +18%
  shippingDelayIncreaseDays: number;
  tariffIncreasePercent: number;
}

export interface RiskProfile {
  valueAtRisk: number; // Daily VaR in GBP
  varConfidence: number; // e.g. 0.99
  liquidityRiskScore: number; // 0-100 scale
  counterpartyRiskRating: "AAA" | "AA" | "A" | "BBB" | "BB" | "B";
  activeDisruptionsCount: number;
  geopoliticalExposure: { [country: string]: number }; // e.g., {"China": 0.45, "Australia": 0.20}
  stressTestImpacts: {
    scenarioId: string;
    scenarioName: string;
    estimatedPnLImpact: number; // GBP
    riskRating: "Low" | "Moderate" | "High" | "Critical";
  }[];
}

export interface EconomicMetrics {
  mineEbitda: number; // Annual EBITDA in million GBP
  operatingMargin: number; // percentage
  roi: number; // Return on Investment %
  cashFlow: number; // Annual free cash flow in million GBP
  npv: number; // Net Present Value in million GBP
  irr: number; // Internal Rate of Return %
}

export interface SimulationResult {
  year: number;
  prices: { [symbol: string]: number };
  globalDemand: { [symbol: string]: number };
  globalSupply: { [symbol: string]: number };
  inventories: { [symbol: string]: number };
  economicMetrics: EconomicMetrics;
}

export interface IndustryDemand {
  sector: string; // e.g., "Electric Vehicles", "Wind Turbines", "Aerospace"
  sharePercent: number; // % of total demand
  growthTrend: number; // expected annual growth %
  keyMetals: string[]; // list of symbols
}
