import React, { useState } from "react";
import { SupplyChainNode, ShippingRoute } from "../types";
import { Globe, MapPin, Anchor, Flame, ChevronRight, AlertTriangle } from "lucide-react";

interface InteractiveMapProps {
  nodes: SupplyChainNode[];
  routes: ShippingRoute[];
  activeSymbol: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  nodes,
  routes,
  activeSymbol
}) => {
  const [hoveredNode, setHoveredNode] = useState<SupplyChainNode | null>(null);

  // Simple Mercator-like projection mapper for coordinates to SVG canvas width=800, height=400
  // Latitude is -90 to +90, Longitude is -180 to +180
  const getCoords = (lat: number, lng: number): [number, number] => {
    // scale longitude: -180 to 180 maps to 0 to 800
    const x = ((lng + 180) / 360) * 800;
    // scale latitude: 90 to -90 maps to 0 to 400
    const y = ((90 - lat) / 180) * 400;
    return [x, y];
  };

  const getPinColor = (node: SupplyChainNode) => {
    if (node.status === "Offline") return "#ef4444"; // red
    if (node.status === "Restricted" || node.status === "Delayed") return "#f59e0b"; // amber
    
    // Check if node is associated with selected metal
    if (node.metal.toLowerCase().includes(activeSymbol.toLowerCase())) {
      return "#3b82f6"; // bright blue for selected metal focus
    }
    return "#10b981"; // healthy green
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="geospatial-panel">
      {/* Panel Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1.5 font-bold text-slate-200">
          <Globe className="w-4 h-4 text-amber-400" />
          <span>GEOSPATIAL SUPPLY NETWORK INTELLIGENCE</span>
        </div>
        <div className="flex items-center gap-4 text-[10px]">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="text-slate-400">Mine</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 bg-blue-500 rounded"></span>
            <span className="text-slate-400">Refinery</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 bg-rose-500 rotate-45"></span>
            <span className="text-slate-400">Disruption</span>
          </span>
        </div>
      </div>

      {/* SVG Map Canvas */}
      <div className="relative bg-slate-950 rounded border border-slate-850 overflow-hidden flex items-center justify-center p-2 min-h-[300px]" id="map-stage">
        
        {/* Absolute Top-Right Selected Focus Symbol Overlay */}
        <div className="absolute top-2 left-2 bg-slate-900/90 border border-slate-800 px-2 py-1 rounded text-[10px] text-slate-400 font-bold flex items-center gap-1.5 z-10">
          <span>Active Focus Symbol:</span>
          <span className="text-amber-400 font-extrabold">{activeSymbol || "ALL"}</span>
        </div>

        <svg viewBox="0 0 800 400" className="w-full h-auto text-slate-800" id="world-svg">
          {/* Stylized Grid / Latitude lines */}
          <g stroke="#1e293b" strokeWidth="0.5" strokeDasharray="3,3">
            <line x1="0" y1="100" x2="800" y2="100" />
            <line x1="0" y1="200" x2="800" y2="200" /> {/* Equator */}
            <line x1="0" y1="300" x2="800" y2="300" />
            <line x1="200" y1="0" x2="200" y2="400" />
            <line x1="400" y1="0" x2="400" y2="400" /> {/* Prime Meridian */}
            <line x1="600" y1="0" x2="600" y2="400" />
          </g>

          {/* Abstract background continents for context */}
          <path 
            d="M 120,80 L 150,60 L 220,60 L 260,110 L 250,150 L 190,160 L 170,140 Z M 160,180 L 240,180 L 260,240 L 230,320 L 200,340 L 180,260 Z M 350,140 L 400,100 L 480,100 L 520,120 L 580,80 L 680,100 L 710,140 L 680,200 L 630,180 L 580,220 L 530,220 L 480,260 L 440,240 L 370,180 Z M 480,270 L 500,260 L 530,290 L 510,340 L 490,320 Z M 670,260 L 730,260 L 750,310 L 710,330 L 680,300 Z M 120,40 L 140,40 L 150,50 L 130,55 Z" 
            fill="#131e35" 
            opacity="0.35" 
          />

          {/* Render Shipping Routes */}
          <g id="shipping-lines">
            {routes.map(r => {
              const [startX, startY] = getCoords(r.fromCoords[0], r.fromCoords[1]);
              const [endX, endY] = getCoords(r.toCoords[0], r.toCoords[1]);
              const isDelayed = r.status === "Delayed" || r.status === "Congested" || r.status === "Blocked";
              
              // Draw an arc path instead of straight lines for premium visual look
              const midX = (startX + endX) / 2;
              const midY = (startY + endY) / 2 - 25; // bend upwards slightly

              return (
                <g key={r.id}>
                  {/* Outer glowing trace */}
                  <path
                    d={`M ${startX} ${startY} Q ${midX} ${midY} ${endX} ${endY}`}
                    fill="none"
                    stroke={isDelayed ? "#f59e0b" : "#3b82f6"}
                    strokeWidth="1.5"
                    strokeOpacity="0.45"
                    strokeDasharray={isDelayed ? "4,4" : "1,0"}
                  />
                  {/* Moving dot indicator along the active routes */}
                  <circle r="2.5" fill={isDelayed ? "#f59e0b" : "#60a5fa"}>
                    <animateMotion
                      path={`M ${startX} ${startY} Q ${midX} ${midY} ${endX} ${endY}`}
                      dur={isDelayed ? "12s" : "6s"}
                      repeatCount="indefinite"
                    />
                  </circle>
                </g>
              );
            })}
          </g>

          {/* Render Supply Network Pins */}
          <g id="supply-pins">
            {nodes.map(n => {
              const [x, y] = getCoords(n.latitude, n.longitude);
              const color = getPinColor(n);
              const isDisrupted = n.status === "Restricted" || n.status === "Offline";

              return (
                <g 
                  key={n.id}
                  transform={`translate(${x}, ${y})`}
                  onMouseEnter={() => setHoveredNode(n)}
                  onMouseLeave={() => setHoveredNode(null)}
                  className="cursor-pointer group"
                >
                  {/* Ripple effect for restricted or focused nodes */}
                  {(isDisrupted || n.metal.toLowerCase().includes(activeSymbol.toLowerCase())) && (
                    <circle r="9" fill="none" stroke={color} strokeWidth="1" opacity="0.8">
                      <animate attributeName="r" values="5;14" dur="2s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.8;0" dur="2s" repeatCount="indefinite" />
                    </circle>
                  )}

                  {/* Standard pin shape */}
                  {n.type === "Port" || n.type === "Warehouse" ? (
                    <polygon 
                      points="-4,4 4,4 0,-4" 
                      fill={color} 
                      stroke="#0f172a" 
                      strokeWidth="1" 
                    />
                  ) : n.type === "Refinery" ? (
                    <rect 
                      x="-3.5" 
                      y="-3.5" 
                      width="7" 
                      height="7" 
                      fill={color} 
                      stroke="#0f172a" 
                      strokeWidth="1" 
                    />
                  ) : (
                    <circle 
                      r="4" 
                      fill={color} 
                      stroke="#0f172a" 
                      strokeWidth="1" 
                    />
                  )}
                </g>
              );
            })}
          </g>
        </svg>

        {/* Hover Information Tooltip Overlay */}
        {hoveredNode && (
          <div className="absolute bottom-3 left-3 right-3 md:left-auto md:right-3 md:w-80 bg-slate-900/95 border border-slate-800 p-3 rounded shadow-xl z-20" id="map-tooltip">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-1.5">
              <span className="font-bold text-slate-100 uppercase">{hoveredNode.name}</span>
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                hoveredNode.status === "Active" 
                  ? "bg-emerald-950 text-emerald-400" 
                  : "bg-amber-950 text-amber-400"
              }`}>
                {hoveredNode.status}
              </span>
            </div>
            <div className="space-y-1 text-slate-400">
              <div className="flex justify-between">
                <span>Operation Node:</span>
                <span className="text-slate-200 font-bold">{hoveredNode.type}</span>
              </div>
              <div className="flex justify-between">
                <span>Location:</span>
                <span className="text-slate-200">{hoveredNode.location}, {hoveredNode.country}</span>
              </div>
              <div className="flex justify-between">
                <span>Constituent Metals:</span>
                <span className="text-amber-400 font-bold">{hoveredNode.metal}</span>
              </div>
              <div className="flex justify-between">
                <span>Capacity/Annual Cap:</span>
                <span className="text-slate-200 font-sans">{hoveredNode.throughput.toLocaleString()} tonnes</span>
              </div>
              {hoveredNode.delayDays > 0 && (
                <div className="flex justify-between text-amber-400">
                  <span>Current Delay Impact:</span>
                  <span className="font-bold">+{hoveredNode.delayDays} Days</span>
                </div>
              )}
              <div className="flex justify-between border-t border-slate-850 pt-1 mt-1 text-[10px]">
                <span>Geopolitical Exposure Index:</span>
                <span className={`font-bold ${hoveredNode.geopoliticalRisk > 60 ? "text-rose-400" : "text-emerald-400"}`}>
                  {hoveredNode.geopoliticalRisk}%
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Supply Route Legend Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3" id="supply-chain-cards">
        <div className="bg-slate-950 border border-slate-850 p-2 rounded">
          <div className="text-slate-500 text-[10px] uppercase">Australia-LAMP line</div>
          <div className="text-xs text-slate-200 font-bold mt-0.5 flex items-center justify-between">
            <span>SR-01 (Active)</span>
            <span className="text-emerald-400">12D Transit</span>
          </div>
        </div>
        <div className="bg-slate-950 border border-slate-850 p-2 rounded">
          <div className="text-slate-500 text-[10px] uppercase">Malaysia-Rotterdam Hub</div>
          <div className="text-xs text-slate-200 font-bold mt-0.5 flex items-center justify-between">
            <span>SR-02 (Active)</span>
            <span className="text-emerald-400">28D Transit</span>
          </div>
        </div>
        <div className="bg-slate-950 border border-slate-850 p-2 rounded">
          <div className="text-slate-500 text-[10px] uppercase">Ganzhou-Munich EV Line</div>
          <div className="text-xs text-slate-200 font-bold mt-0.5 flex items-center justify-between">
            <span>SR-03 (Active)</span>
            <span className="text-amber-400">32D Congested</span>
          </div>
        </div>
        <div className="bg-slate-950 border border-slate-850 p-2 rounded">
          <div className="text-slate-500 text-[10px] uppercase">DR Congo-Rotterdam Vault</div>
          <div className="text-xs text-slate-200 font-bold mt-0.5 flex items-center justify-between">
            <span>SR-04 (Active)</span>
            <span className="text-emerald-400">25D Transit</span>
          </div>
        </div>
      </div>
    </div>
  );
};
