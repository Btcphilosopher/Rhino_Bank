import React from "react";
import { RiskProfile, ScenarioImpact, PortfolioPosition, Contract } from "../types";
import { ShieldAlert, AlertTriangle, RefreshCw, Zap, TrendingUp, TrendingDown } from "lucide-react";

interface RiskCenterProps {
  riskProfile: RiskProfile | undefined;
  activeDisruptions: (ScenarioImpact & { id: string })[];
  onToggleDisruption: (id: string) => Promise<void>;
  positions: PortfolioPosition[];
  contracts: Contract[];
}

export const RiskCenter: React.FC<RiskCenterProps> = ({
  riskProfile,
  activeDisruptions,
  onToggleDisruption,
  positions,
  contracts
}) => {

  const getRiskColor = (rating: string) => {
    switch (rating) {
      case "Critical": return "text-rose-400 bg-rose-950/25 border-rose-900";
      case "High": return "text-amber-400 bg-amber-950/25 border-amber-900";
      case "Moderate": return "text-blue-400 bg-blue-950/25 border-blue-900";
      default: return "text-emerald-400 bg-emerald-950/25 border-emerald-900";
    }
  };

  const getLiquidityRiskLabel = (score: number) => {
    if (score > 60) return { label: "CRITICAL ILLIQUIDITY", color: "text-rose-400" };
    if (score > 40) return { label: "MODERATE FRICTION", color: "text-amber-400" };
    return { label: "OPTIMAL LIQUIDITY", color: "text-emerald-400" };
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="risk-engine-panel">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-tight flex items-center gap-1.5">
          <ShieldAlert className="w-4 h-4 text-rose-500" />
          <span>RhinoRisk QUANTITATIVE RISK CENTRE</span>
        </h2>
        <span className="text-[10px] text-slate-500 font-bold bg-slate-950 px-1.5 py-0.5 rounded">BASE-CURRENCY: GBP (£)</span>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1" id="risk-center-grids">
        
        {/* Left Side - Geopolitical Stress Scenario Toggle Switches (LME/Bloomberg Style) */}
        <div className="lg:col-span-7 space-y-3" id="risk-scenarios-col">
          <h3 className="font-bold text-slate-300 uppercase tracking-wide text-[11px] mb-2 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            Active Geopolitical & Logistic Stress Scenarios
          </h3>
          
          <div className="space-y-2.5" id="disruption-toggles-list">
            {activeDisruptions.map(dis => (
              <div 
                key={dis.id} 
                className={`border p-3 rounded-lg transition-all ${
                  dis.triggered 
                    ? "bg-amber-950/20 border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.05)]" 
                    : "bg-slate-950 border-slate-850 hover:border-slate-800"
                }`}
                id={`risk-scen-${dis.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                      {dis.triggered && <AlertTriangle className="w-3.5 h-3.5 text-amber-500 animate-bounce" />}
                      {dis.name}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{dis.description}</p>
                  </div>
                  
                  {/* Slider Switch */}
                  <button
                    type="button"
                    onClick={() => onToggleDisruption(dis.id)}
                    className={`relative inline-flex h-5 w-10 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      dis.triggered ? "bg-amber-500" : "bg-slate-800"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-slate-950 shadow ring-0 transition duration-200 ease-in-out ${
                        dis.triggered ? "translate-x-5" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                {/* Sub-parameters triggered details */}
                <div className="mt-2.5 border-t border-slate-850/60 pt-2 flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-slate-500">
                  <span>Price Shocks: <strong className="text-slate-300 font-sans">
                    {Object.entries(dis.priceShocks).map(([k, v]) => `${k} (+${(Number(v)*100).toFixed(0)}%)`).slice(0, 4).join(", ")}...
                  </strong></span>
                  <span>Delay Impact: <strong className="text-slate-300">+{dis.shippingDelayIncreaseDays} Days</strong></span>
                  {dis.tariffIncreasePercent > 0 && (
                    <span>Ad-Valorem Tariffs: <strong className="text-slate-300">+{dis.tariffIncreasePercent}%</strong></span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side - Value-at-Risk and Stress Test Portfolio P&L Impacts */}
        <div className="lg:col-span-5 flex flex-col justify-between gap-4" id="risk-stats-col">
          
          {/* Risk Indices Panel */}
          <div className="bg-slate-950 border border-slate-850 rounded-lg p-3 space-y-2.5" id="risk-indices">
            <h3 className="font-bold text-slate-300 text-[10px] uppercase tracking-wider">PORTFOLIO EXPOSURE RATINGS</h3>
            
            <div className="grid grid-cols-2 gap-2" id="risk-ratings-grid">
              {/* Liquidity Risk */}
              <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
                <div className="text-[9px] text-slate-500 uppercase">LIQUIDITY PENALTY</div>
                <div className={`font-black text-xs mt-1 ${getLiquidityRiskLabel(riskProfile?.liquidityRiskScore || 0).color}`}>
                  {getLiquidityRiskLabel(riskProfile?.liquidityRiskScore || 0).label}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5 font-sans">Index: {riskProfile?.liquidityRiskScore}/100</div>
              </div>

              {/* Counterparty Rating */}
              <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
                <div className="text-[9px] text-slate-500 uppercase">RCX RATING MATRIX</div>
                <div className="font-black text-xs mt-1 text-emerald-400">
                  {riskProfile?.counterpartyRiskRating || "A"} CREDIT
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Clearing Standard: Basel IV</div>
              </div>
            </div>
          </div>

          {/* Stress Impacts Matrix */}
          <div className="bg-slate-950 border border-slate-850 rounded-lg p-3 flex-1 flex flex-col" id="stress-test-pnl-impacts">
            <h3 className="font-bold text-slate-300 text-[10px] uppercase tracking-wider mb-2">STRESS TEST ESTIMATED P&L SHIFT</h3>
            
            <div className="space-y-2 flex-1 overflow-y-auto max-h-[220px]" id="stress-impact-list">
              {riskProfile?.stressTestImpacts.map(impact => {
                const isPnLPositive = impact.estimatedPnLImpact >= 0;
                return (
                  <div 
                    key={impact.scenarioId} 
                    className={`flex items-center justify-between p-2 rounded border border-slate-850 ${
                      impact.riskRating === "Critical" 
                        ? "bg-rose-950/10 border-l-2 border-l-rose-500" 
                        : impact.riskRating === "High"
                          ? "bg-amber-950/10 border-l-2 border-l-amber-500"
                          : "bg-slate-900/60 border-l-2 border-l-blue-500"
                    }`}
                  >
                    <div>
                      <span className="font-bold text-slate-200 block text-[11px]">{impact.scenarioName}</span>
                      <span className={`text-[9px] font-bold px-1 rounded uppercase mt-1 inline-block ${getRiskColor(impact.riskRating)}`}>
                        {impact.riskRating} RISK
                      </span>
                    </div>

                    <div className="text-right">
                      <span className={`font-bold font-sans text-xs flex items-center gap-0.5 justify-end ${isPnLPositive ? "text-emerald-400" : "text-rose-400"}`}>
                        {isPnLPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                        {isPnLPositive ? "+" : ""}£{impact.estimatedPnLImpact.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono">Simulated Net Asset</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
