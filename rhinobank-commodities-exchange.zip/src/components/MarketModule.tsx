import React, { useState, useEffect } from "react";
import { MarketTicker, CommodityCategory } from "../types";
import { Search, ArrowUpRight, ArrowDownRight, Award, ShieldAlert, Globe } from "lucide-react";

interface MarketModuleProps {
  tickers: MarketTicker[];
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
}

export const MarketModule: React.FC<MarketModuleProps> = ({
  tickers,
  selectedSymbol,
  onSelectSymbol
}) => {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<CommodityCategory | "ALL">("ALL");
  const [prevPrices, setPrevPrices] = useState<{ [symbol: string]: number }>({});
  const [flashStates, setFlashStates] = useState<{ [symbol: string]: "up" | "down" | null }>({});

  // Detect price ticks to trigger Bloomberg-style visual flashes
  useEffect(() => {
    const newFlashes: { [symbol: string]: "up" | "down" | null } = {};
    let changed = false;

    tickers.forEach(t => {
      const prev = prevPrices[t.symbol];
      if (prev !== undefined && prev !== t.spotPrice) {
        newFlashes[t.symbol] = t.spotPrice > prev ? "up" : "down";
        changed = true;
      }
    });

    if (changed) {
      setFlashStates(prev => ({ ...prev, ...newFlashes }));
      // Store current prices as previous
      const currentPrices = tickers.reduce((acc, t) => {
        acc[t.symbol] = t.spotPrice;
        return acc;
      }, {} as { [symbol: string]: number });
      setPrevPrices(currentPrices);

      // Clear flashes after 1 second
      const timer = setTimeout(() => {
        setFlashStates({});
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      // Initialize prev prices if empty
      if (Object.keys(prevPrices).length === 0 && tickers.length > 0) {
        const initialPrices = tickers.reduce((acc, t) => {
          acc[t.symbol] = t.spotPrice;
          return acc;
        }, {} as { [symbol: string]: number });
        setPrevPrices(initialPrices);
      }
    }
  }, [tickers, prevPrices]);

  // Filter tickers
  const filteredTickers = tickers.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(search.toLowerCase()) || 
                          t.symbol.toLowerCase().includes(search.toLowerCase());
    const matchesTab = activeTab === "ALL" || t.category === activeTab;
    return matchesSearch && matchesTab;
  });

  const getCategoryLabelColor = (cat: CommodityCategory) => {
    switch (cat) {
      case CommodityCategory.REE:
        return "text-purple-400 bg-purple-950/40 border-purple-900";
      case CommodityCategory.BATTERY:
        return "text-cyan-400 bg-cyan-950/40 border-cyan-900";
      case CommodityCategory.INDUSTRIAL:
        return "text-slate-400 bg-slate-950/40 border-slate-900";
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="market-panel">
      {/* Title & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-100 uppercase tracking-tight">GLOBAL COMMODITIES TICKER BOARD</h2>
        </div>
        
        {/* Search Input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search symbols..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-slate-700 w-44"
            id="ticker-search"
          />
        </div>
      </div>

      {/* Categories Tabs */}
      <div className="flex border-b border-slate-850 gap-1 mb-3" id="category-tabs">
        <button
          onClick={() => setActiveTab("ALL")}
          className={`px-3 py-1.5 font-bold border-b-2 cursor-pointer ${
            activeTab === "ALL" 
              ? "border-amber-500 text-amber-400 bg-slate-950/30" 
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          ALL BOARD
        </button>
        <button
          onClick={() => setActiveTab(CommodityCategory.REE)}
          className={`px-3 py-1.5 font-bold border-b-2 cursor-pointer ${
            activeTab === CommodityCategory.REE 
              ? "border-purple-500 text-purple-400 bg-purple-950/10" 
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          RARE EARTHS (REE)
        </button>
        <button
          onClick={() => setActiveTab(CommodityCategory.BATTERY)}
          className={`px-3 py-1.5 font-bold border-b-2 cursor-pointer ${
            activeTab === CommodityCategory.BATTERY 
              ? "border-cyan-500 text-cyan-400 bg-cyan-950/10" 
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          BATTERY METALS
        </button>
        <button
          onClick={() => setActiveTab(CommodityCategory.INDUSTRIAL)}
          className={`px-3 py-1.5 font-bold border-b-2 cursor-pointer ${
            activeTab === CommodityCategory.INDUSTRIAL 
              ? "border-slate-500 text-slate-300 bg-slate-950/10" 
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          INDUSTRIAL
        </button>
      </div>

      {/* Grid Header & Rows */}
      <div className="overflow-y-auto flex-1 border border-slate-850 rounded max-h-[480px]" id="ticker-table-container">
        <table className="w-full text-left border-collapse" id="ticker-table">
          <thead>
            <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-bold">
              <th className="py-2.5 px-3">SYMBOL</th>
              <th className="py-2.5 px-2">COMMODITY NAME</th>
              <th className="py-2.5 px-2 text-right">SPOT (£)</th>
              <th className="py-2.5 px-2 text-right">CHANGE</th>
              <th className="py-2.5 px-2 text-right">HIGH / LOW</th>
              <th className="py-2.5 px-2 text-right">VOL (DAILY)</th>
              <th className="py-2.5 px-2 text-right">CHINA</th>
              <th className="py-2.5 px-2 text-right">EUROPE</th>
              <th className="py-2.5 px-3 text-right">USA</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850">
            {filteredTickers.length > 0 ? (
              filteredTickers.map(t => {
                const flash = flashStates[t.symbol];
                const isSelected = selectedSymbol === t.symbol;
                const changeIsPositive = t.change >= 0;

                // Flash highlights
                let flashClass = "";
                if (flash === "up") flashClass = "bg-emerald-950/50 text-emerald-300 font-bold transition-all";
                else if (flash === "down") flashClass = "bg-rose-950/50 text-rose-300 font-bold transition-all";

                return (
                  <tr
                    key={t.symbol}
                    onClick={() => onSelectSymbol(t.symbol)}
                    className={`cursor-pointer transition-colors ${
                      isSelected 
                        ? "bg-amber-950/20 hover:bg-amber-950/30 border-l-2 border-l-amber-500" 
                        : "hover:bg-slate-850/40"
                    } ${flashClass}`}
                    id={`ticker-row-${t.symbol}`}
                  >
                    {/* Symbol with category pill */}
                    <td className="py-3 px-3 font-bold text-slate-100 flex items-center gap-2">
                      <span className="text-amber-400 text-xs">{t.symbol}</span>
                      <span className={`text-[8px] font-bold px-1 py-0.2 rounded border uppercase ${getCategoryLabelColor(t.category)}`}>
                        {t.category === CommodityCategory.REE ? "REE" : t.category === CommodityCategory.BATTERY ? "Battery" : "Ind"}
                      </span>
                    </td>
                    
                    {/* Name */}
                    <td className="py-3 px-2 text-slate-300 max-w-[180px] truncate" title={t.name}>
                      {t.name}
                    </td>

                    {/* Spot Price */}
                    <td className={`py-3 px-2 text-right font-bold text-slate-100 ${flash === "up" ? "text-emerald-400" : flash === "down" ? "text-rose-400" : ""}`}>
                      £{t.spotPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    {/* Change Percentage */}
                    <td className="py-3 px-2 text-right">
                      <span className={`inline-flex items-center gap-0.5 font-bold ${changeIsPositive ? "text-emerald-400" : "text-rose-400"}`}>
                        {changeIsPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                        {changeIsPositive ? "+" : ""}{t.change.toFixed(2)}%
                      </span>
                    </td>

                    {/* High / Low */}
                    <td className="py-3 px-2 text-right text-slate-400">
                      <span>£{t.high.toLocaleString()}</span>
                      <span className="mx-1 text-slate-600">/</span>
                      <span>£{t.low.toLocaleString()}</span>
                    </td>

                    {/* Volume */}
                    <td className="py-3 px-2 text-right text-slate-400 font-sans">
                      {t.volume.toLocaleString()}
                    </td>

                    {/* Regional Prices */}
                    <td className="py-3 px-2 text-right text-slate-300">
                      £{t.regional.china.toLocaleString()}
                    </td>
                    <td className="py-3 px-2 text-right text-slate-300">
                      £{t.regional.europe.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right text-slate-300 font-bold">
                      £{t.regional.usa.toLocaleString()}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={9} className="py-8 text-center text-slate-500">
                  No active commodities match search criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Footer statistics */}
      <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-850 text-[10px] text-slate-500">
        <span className="flex items-center gap-1.5">
          <Award className="w-3.5 h-3.5 text-purple-400" />
          Heavy Rare Earth premiums calculated with ±0.1% purity adjustments.
        </span>
        <span className="flex items-center gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          Pricing complies with LME delivery and warehouse receipt guidelines.
        </span>
      </div>
    </div>
  );
};
