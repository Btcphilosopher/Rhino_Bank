import React from "react";
import { PortfolioPosition, Contract, Order } from "../types";
import { Briefcase, FileText, CheckCircle2, History, AlertCircle, ArrowUpRight, ArrowDownRight, Award } from "lucide-react";

interface PortfolioModuleProps {
  cash: number;
  positions: PortfolioPosition[];
  contracts: Contract[];
  trades: Order[];
  onSettleContract: (contractId: string) => Promise<void>;
  summary: {
    totalPositionsValue: number;
    totalPortfolioValue: number;
    totalPnL: number;
    pnlPercent: number;
  };
}

export const PortfolioModule: React.FC<PortfolioModuleProps> = ({
  cash,
  positions,
  contracts,
  trades,
  onSettleContract,
  summary
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="portfolio-panel">
      
      {/* Upper Grid - Held Positions and Active Forwards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 mb-5" id="portfolio-upper-grid">
        
        {/* Held Physical Inventory Positions */}
        <div className="lg:col-span-7 flex flex-col" id="positions-subpanel">
          <h3 className="font-bold text-slate-300 text-[11px] uppercase tracking-wide mb-2.5 flex items-center gap-1.5">
            <Briefcase className="w-4 h-4 text-amber-500" />
            Active Physical Vault Stock Positions
          </h3>

          <div className="overflow-x-auto border border-slate-850 rounded bg-slate-950 flex-1 max-h-[220px]" id="positions-table-container">
            <table className="w-full text-left border-collapse" id="positions-table">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-850 text-slate-500 font-bold text-[10px]">
                  <th className="py-2 px-2.5">METAL</th>
                  <th className="py-2 px-1 text-right font-sans">HOLDING SIZE</th>
                  <th className="py-2 px-1 text-right">AVG COST</th>
                  <th className="py-2 px-1 text-right">SPOT</th>
                  <th className="py-2 px-1 text-right">TOTAL VALUE</th>
                  <th className="py-2 px-1 text-right">UNREALIZED P&L</th>
                  <th className="py-2 px-2.5 text-right">HEDGED %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850 text-[11px]">
                {positions.length > 0 ? (
                  positions.map(p => {
                    const isProfit = p.pnl >= 0;
                    return (
                      <tr key={p.symbol} className="hover:bg-slate-900/40 text-slate-300">
                        <td className="py-2 px-2.5 font-bold text-slate-200">
                          {p.symbol}
                          <span className="block text-[8px] text-slate-500 font-normal truncate max-w-[100px]">{p.name}</span>
                        </td>
                        <td className="py-2 px-1 text-right font-sans font-bold">{p.amount.toLocaleString()}</td>
                        <td className="py-2 px-1 text-right">£{p.averageCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        <td className="py-2 px-1 text-right text-amber-400">£{p.currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        <td className="py-2 px-1 text-right font-bold text-slate-200">£{p.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                        <td className={`py-2 px-1 text-right font-black ${isProfit ? "text-emerald-400" : "text-rose-400"}`}>
                          <span className="flex items-center gap-0.5 justify-end">
                            {isProfit ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                            {isProfit ? "+" : ""}£{p.pnl.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                          </span>
                          <span className="block text-[8px] font-normal font-sans">({p.pnlPercent.toFixed(1)}%)</span>
                        </td>
                        <td className="py-2 px-2.5 text-right font-bold text-cyan-400 font-sans">
                          {p.hedgeRatio}%
                          <span className="block text-[8px] text-slate-500 font-normal">Hedged: {p.hedgedAmount}</span>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-slate-600">
                      No active vault inventory positions. Initiate Spot BUYS on the Exchange ticket above.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Active OTC / Forwards derivatives contracts with SETTLE button */}
        <div className="lg:col-span-5 flex flex-col" id="contracts-subpanel">
          <h3 className="font-bold text-slate-300 text-[11px] uppercase tracking-wide mb-2.5 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-cyan-400" />
            Active Derivative Forwards & Hedges
          </h3>

          <div className="overflow-y-auto border border-slate-850 rounded bg-slate-950 flex-1 max-h-[220px]" id="contracts-list-container">
            {contracts.length > 0 ? (
              <div className="divide-y divide-slate-850" id="contracts-list">
                {contracts.map(c => {
                  const isSettleProfit = (c.direction === "BUY" && c.pnl >= 0) || (c.direction === "SELL" && c.pnl <= 0); // basic proxy
                  return (
                    <div key={c.id} className="p-2.5 flex items-center justify-between hover:bg-slate-900/30 gap-4" id={`contract-row-${c.id}`}>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={`w-1.5 h-1.5 rounded-full ${c.direction === "BUY" ? "bg-emerald-500" : "bg-rose-500"}`}></span>
                          <span className="font-bold text-slate-200">{c.symbol} {c.direction} Forward</span>
                          <span className="text-[8px] text-slate-500 bg-slate-900 border border-slate-800 px-1 py-0.2 rounded font-sans uppercase">
                            {c.type.split(" ")[0]}
                          </span>
                        </div>
                        <div className="text-[9px] text-slate-500 mt-0.5 space-y-0.2">
                          <div>Counterparty: <strong className="text-slate-400">{c.counterparty}</strong></div>
                          <div>Maturity Date: <strong className="text-slate-400">{c.maturityDate}</strong></div>
                        </div>
                      </div>

                      <div className="text-right flex items-center gap-3">
                        <div>
                          <div className="font-bold text-slate-200 font-sans">{c.amount.toLocaleString()} units</div>
                          <div className="text-[10px] text-amber-400 font-bold">Lock-in: £{c.price.toLocaleString()}</div>
                        </div>

                        {/* Interactive settlement trigger */}
                        <button
                          onClick={() => onSettleContract(c.id)}
                          className="bg-slate-800 hover:bg-slate-700 hover:text-amber-400 active:bg-slate-650 text-slate-300 font-black px-2 py-1 border border-slate-700 rounded text-[9px] cursor-pointer transition-all"
                          title="Trigger Cash Settlement Delivery"
                          id={`btn-settle-${c.id}`}
                        >
                          SETTLE
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full py-12 text-slate-600 gap-1" id="empty-contracts">
                <AlertCircle className="w-5 h-5 text-slate-700" />
                <span>No active hedging forward contracts.</span>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Lower Row - Completed Trades History Log */}
      <div className="flex flex-col border-t border-slate-850 pt-3 flex-1" id="trades-subpanel">
        <h3 className="font-bold text-slate-300 text-[11px] uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <History className="w-4 h-4 text-slate-400" />
          Completed Physical Exchange Audit Logs
        </h3>

        <div className="overflow-y-auto max-h-[140px] border border-slate-850 rounded bg-slate-950 flex-1" id="trades-log-container">
          <table className="w-full text-left border-collapse" id="trades-log-table">
            <thead>
              <tr className="bg-slate-900 border-b border-slate-850 text-slate-500 font-bold text-[10px]">
                <th className="py-2 px-3">TRADE ID</th>
                <th className="py-2 px-1">SYMBOL</th>
                <th className="py-2 px-1 text-center">TYPE</th>
                <th className="py-2 px-1 text-right">FILL PRICE</th>
                <th className="py-2 px-1 text-right">VOLUME</th>
                <th className="py-2 px-1 text-right">SETTLED VALUE</th>
                <th className="py-2 px-3 text-right">EXECUTION TIMESTAMP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850 text-[10px] text-slate-400 font-mono">
              {trades.map((t, idx) => {
                const totalVal = t.amount * t.price;
                return (
                  <tr key={t.id || idx} className="hover:bg-slate-900/20 text-slate-400" id={`trade-log-${t.id}`}>
                    <td className="py-1.5 px-3 font-bold text-slate-300">{t.id}</td>
                    <td className="py-1.5 px-1 font-bold text-slate-100">{t.symbol}</td>
                    <td className="py-1.5 px-1 text-center font-bold">
                      <span className={`px-1 rounded ${t.type === "BUY" ? "text-emerald-400 bg-emerald-950/20" : "text-rose-400 bg-rose-950/20"}`}>
                        {t.type}
                      </span>
                    </td>
                    <td className="py-1.5 px-1 text-right text-slate-300 font-sans">£{t.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td className="py-1.5 px-1 text-right font-bold text-slate-300 font-sans">{t.amount.toLocaleString()}</td>
                    <td className="py-1.5 px-1 text-right text-amber-400 font-bold font-sans">£{totalVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                    <td className="py-1.5 px-3 text-right text-slate-500">{new Date(t.timestamp).toLocaleTimeString() || "Live Feed"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
