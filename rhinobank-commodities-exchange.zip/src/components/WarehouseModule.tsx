import React from "react";
import { Warehouse, WarehouseStock } from "../types";
import { Database, MapPin, Archive, Disc, ClipboardCheck } from "lucide-react";

interface WarehouseModuleProps {
  warehouses: Warehouse[];
  stocks: WarehouseStock[];
  globalRareEarthValue: number;
}

export const WarehouseModule: React.FC<WarehouseModuleProps> = ({
  warehouses,
  stocks,
  globalRareEarthValue
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="warehouse-panel">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5 font-bold text-slate-200">
          <Database className="w-4 h-4 text-emerald-500" />
          <span>PHYSICAL INVENTORY SYSTEM (LME RECEIPTS)</span>
        </div>
        <div className="bg-slate-950 border border-slate-850 px-2.5 py-1 rounded text-right">
          <span className="text-[10px] text-slate-500 uppercase block tracking-wider">RCX Global REE Inventory Value</span>
          <span className="text-xs font-black text-amber-400 font-sans">
            £{globalRareEarthValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1" id="warehouse-grids">
        
        {/* 1. Warehouse Storage Caps and Loads (Left Column) */}
        <div className="lg:col-span-5 space-y-3" id="warehouse-list-col">
          <h3 className="font-bold text-slate-400 text-[10px] uppercase tracking-wider mb-2 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-amber-500" />
            LME Warehouse Hub Statuses
          </h3>
          
          <div className="space-y-2.5" id="warehouses-progress-list">
            {warehouses.map(w => {
              const pct = (w.currentLoad / w.capacity) * 100;
              return (
                <div key={w.id} className="bg-slate-950 border border-slate-850 p-3 rounded" id={`warehouse-card-${w.id}`}>
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-slate-200">{w.name}</span>
                    <span className="text-slate-400 text-[10px]">{w.location}, {w.country}</span>
                  </div>
                  
                  {/* Load bar */}
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800 mt-1.5 flex">
                    <div 
                      className={`h-full rounded-full ${pct > 80 ? "bg-rose-500" : pct > 50 ? "bg-amber-500" : "bg-emerald-500"}`}
                      style={{ width: `${pct}%` }}
                    ></div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                    <span>Load index: {pct.toFixed(1)}%</span>
                    <span>{w.currentLoad.toLocaleString()} / {w.capacity.toLocaleString()} tonnes</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 2. Warehouse Stock Records Table (Right Column) */}
        <div className="lg:col-span-7 flex flex-col" id="warehouse-stocks-col">
          <h3 className="font-bold text-slate-400 text-[10px] uppercase tracking-wider mb-2 flex items-center gap-1">
            <Archive className="w-3.5 h-3.5 text-emerald-500" />
            Physical Vault Stock Ledger (Receipts Verified)
          </h3>
          
          <div className="overflow-y-auto max-h-[300px] border border-slate-850 rounded flex-1 bg-slate-950" id="stocks-table-container">
            <table className="w-full text-left border-collapse" id="stocks-table">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-850 text-slate-500 font-bold text-[10px]">
                  <th className="py-2 px-2.5">VAULT</th>
                  <th className="py-2 px-1">SYMBOL</th>
                  <th className="py-2 px-1">METAL GRADE</th>
                  <th className="py-2 px-1 text-center">PURITY</th>
                  <th className="py-2 px-1 text-center">ORIGIN</th>
                  <th className="py-2 px-2.5 text-right">STOCK LEVEL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850 text-[11px]">
                {stocks.map((stock, idx) => (
                  <tr key={`stock-${idx}`} className="hover:bg-slate-900/40 text-slate-300">
                    <td className="py-2 px-2.5 font-bold text-slate-300">{stock.warehouse.replace("LME ", "").replace(" Vaults", "").replace(" Hub", "")}</td>
                    <td className="py-2 px-1 font-extrabold text-amber-400">{stock.symbol}</td>
                    <td className="py-2 px-1 text-slate-400">{stock.grade}</td>
                    <td className="py-2 px-1 text-center text-slate-400 font-mono">{stock.purity}</td>
                    <td className="py-2 px-1 text-center text-slate-400">{stock.origin}</td>
                    <td className="py-2 px-2.5 text-right font-bold text-slate-200 font-sans">
                      {stock.stockLevel.toLocaleString()} tonnes
                      <span className="block text-[9px] text-slate-500">Reserved: {stock.reserved}t</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
