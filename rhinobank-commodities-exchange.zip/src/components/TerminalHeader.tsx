import React from "react";
import { Activity, Coins, ShieldAlert, TrendingUp, TrendingDown, RefreshCw } from "lucide-react";

interface HeaderProps {
  cash: number;
  portfolioValue: number;
  pnl: number;
  pnlPercent: number;
  varValue: number;
  activeDisruptionsCount: number;
  isPolling: boolean;
  onRefresh: () => void;
}

export const TerminalHeader: React.FC<HeaderProps> = ({
  cash,
  portfolioValue,
  pnl,
  pnlPercent,
  varValue,
  activeDisruptionsCount,
  isPolling,
  onRefresh
}) => {
  const isProfit = pnl >= 0;

  return (
    <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-4 text-xs font-mono select-none" id="rcx-header">
      {/* Brand & Ticker Mode */}
      <div className="flex items-center gap-3">
        <div className="bg-amber-500 text-slate-950 font-black px-2 py-1 rounded text-sm tracking-tighter flex items-center gap-1.5 animate-pulse">
          <span>RCX</span>
          <span className="text-[10px] bg-slate-950 text-amber-400 px-1 py-0.2 rounded font-bold font-sans">CORE</span>
        </div>
        <div>
          <h1 className="text-sm font-bold text-slate-100 uppercase tracking-tight">RHINOBANK COMMODITIES</h1>
          <div className="flex items-center gap-2 text-[10px] text-slate-400">
            <span>RhinoQuant Metals Infrastructure v4.11</span>
            <span className="inline-flex items-center gap-1">
              <span className={`w-1.5 h-1.5 rounded-full ${isPolling ? "bg-emerald-500 animate-ping" : "bg-emerald-600"}`}></span>
              <span className="text-emerald-500 text-[9px] font-bold">FEED: LIVE</span>
            </span>
          </div>
        </div>
      </div>

      {/* Real-time Indicators */}
      <div className="flex flex-wrap items-center gap-6">
        {/* Total Assets */}
        <div className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 min-w-[130px]" id="header-assets">
          <div className="text-slate-400 text-[10px] uppercase mb-0.5 tracking-wider flex items-center gap-1">
            <Coins className="w-3 h-3 text-amber-500" />
            Net Asset Value (NAV)
          </div>
          <div className="text-sm font-bold text-slate-100">
            £{portfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* Free Cash */}
        <div className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 min-w-[110px]" id="header-cash">
          <div className="text-slate-400 text-[10px] uppercase mb-0.5 tracking-wider">Settled Cash</div>
          <div className="text-sm font-bold text-amber-400">
            £{cash.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* Cumulative P&L */}
        <div className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 min-w-[110px]" id="header-pnl">
          <div className="text-slate-400 text-[10px] uppercase mb-0.5 tracking-wider flex items-center gap-1">
            {isProfit ? <TrendingUp className="w-3 h-3 text-emerald-500" /> : <TrendingDown className="w-3 h-3 text-rose-500" />}
            Cumulative P&L
          </div>
          <div className={`text-sm font-bold flex items-center gap-1 ${isProfit ? "text-emerald-400" : "text-rose-400"}`}>
            <span>{isProfit ? "+" : ""}£{pnl.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            <span className="text-[10px]">({isProfit ? "+" : ""}{pnlPercent.toFixed(2)}%)</span>
          </div>
        </div>

        {/* Value-at-Risk */}
        <div className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 min-w-[110px]" id="header-var">
          <div className="text-slate-400 text-[10px] uppercase mb-0.5 tracking-wider flex items-center gap-1">
            <ShieldAlert className="w-3 h-3 text-amber-500" />
            1D VaR (99% CI)
          </div>
          <div className="text-sm font-bold text-amber-400">
            £{varValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
        </div>

        {/* Active Geopolitical Risks */}
        <div className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 flex items-center gap-2" id="header-risks">
          <div className="text-right">
            <div className="text-slate-400 text-[9px] uppercase tracking-wider">Disruptions</div>
            <div className="text-xs font-bold text-slate-200">{activeDisruptionsCount} Triggered</div>
          </div>
          <div className={`w-2.5 h-2.5 rounded-full ${activeDisruptionsCount > 0 ? "bg-amber-500 animate-pulse" : "bg-slate-700"}`}></div>
        </div>

        {/* Manual Force Sync */}
        <button
          onClick={onRefresh}
          className="bg-slate-800 hover:bg-slate-700 active:bg-slate-600 border border-slate-700 text-slate-300 p-2 rounded cursor-pointer transition-colors"
          title="Force Market Sync"
          id="btn-force-sync"
        >
          <RefreshCw className={`w-4 h-4 ${isPolling ? "animate-spin" : ""}`} />
        </button>
      </div>
    </header>
  );
};
