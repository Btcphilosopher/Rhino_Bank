import React, { useState, useEffect } from "react";
import { MarketTicker } from "../types";
import { Sparkles, BarChart3, TrendingUp, Send, RefreshCw, FileText, Bot } from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";

interface ForecastData {
  month: string;
  forecast: number;
  upper95: number;
  lower95: number;
}

interface QuantAnalystProps {
  tickers: MarketTicker[];
  selectedSymbol: string;
}

export const QuantAnalyst: React.FC<QuantAnalystProps> = ({
  tickers,
  selectedSymbol
}) => {
  const [forecast, setForecast] = useState<ForecastData[]>([]);
  const [isLoadingForecast, setIsLoadingForecast] = useState(false);
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiReport, setAiReport] = useState("");
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  // Poll econometric ARIMA/GARCH forecast series from backend when active symbol changes
  useEffect(() => {
    fetchForecast();
  }, [selectedSymbol]);

  // Generate initial report upon load
  useEffect(() => {
    runQuickQuery("Perform a comprehensive summary analysis of global REEs and battery metals pricing and geopolitical risks.");
  }, []);

  const fetchForecast = async () => {
    if (!selectedSymbol) return;
    setIsLoadingForecast(true);
    try {
      const res = await fetch("/api/quant/forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: selectedSymbol })
      });
      if (res.ok) {
        const data = await res.json();
        setForecast(data.forecast);
      }
    } catch (e) {
      console.error("Failed to load forecast data", e);
    } finally {
      setIsLoadingForecast(false);
    }
  };

  const handleAskAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;
    
    setIsLoadingAi(true);
    setAiReport("");
    try {
      const res = await fetch("/api/quant/ai-analyst", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: aiPrompt, focusSymbol: selectedSymbol })
      });
      if (res.ok) {
        const data = await res.json();
        setAiReport(data.report);
      } else {
        setAiReport("Error: Connection with Quantitative Core interrupted.");
      }
    } catch (e) {
      setAiReport("Error: Quantitative Core Server is currently offline.");
    } finally {
      setIsLoadingAi(false);
    }
  };

  const runQuickQuery = async (query: string) => {
    setAiPrompt(query);
    setIsLoadingAi(true);
    setAiReport("");
    try {
      const res = await fetch("/api/quant/ai-analyst", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: query, focusSymbol: selectedSymbol })
      });
      if (res.ok) {
        const data = await res.json();
        setAiReport(data.report);
      } else {
        setAiReport("Error: Quantitative Core was unable to generate a response.");
      }
    } catch (e) {
      setAiReport("Error: Quantitative Core Server is currently offline.");
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Convert raw markdown to standard formatted HTML paragraphs for neat presentation
  const renderAiReport = (markdown: string) => {
    if (!markdown) return null;
    return markdown.split("\n\n").map((para, i) => {
      if (para.startsWith("### ")) {
        return <h4 key={i} className="text-xs font-bold text-slate-100 uppercase mt-4 mb-2 tracking-wide border-b border-slate-800 pb-1 flex items-center gap-1.5"><Bot className="w-3.5 h-3.5 text-amber-500" />{para.replace("### ", "")}</h4>;
      }
      if (para.startsWith("## ")) {
        return <h3 key={i} className="text-sm font-bold text-amber-400 uppercase mt-5 mb-2.5 tracking-tight flex items-center gap-1.5 border-b border-amber-900 pb-1">{para.replace("## ", "")}</h3>;
      }
      if (para.startsWith("- ") || para.startsWith("* ")) {
        const items = para.split("\n");
        return (
          <ul key={i} className="list-disc pl-5 my-2 space-y-1 text-slate-300">
            {items.map((it, idx) => (
              <li key={idx}>{it.replace(/^-\s*/, "").replace(/^\*\s*/, "").replace(/\*\*(.*?)\*\*/g, "$1")}</li>
            ))}
          </ul>
        );
      }
      // Simple bold replacements inside paragraph texts
      const formatted = para.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
      return <p key={i} className="text-slate-300 leading-relaxed mb-3 font-mono" dangerouslySetInnerHTML={{ __html: formatted }}></p>;
    });
  };

  const ticker = tickers.find(t => t.symbol === selectedSymbol);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="quant-analyst-panel">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-tight flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>RhinoQuant Metals Quantitative Models (R Engine)</span>
        </h2>
        <span className="text-[10px] text-slate-400 font-bold bg-slate-950 px-1.5 py-0.5 rounded flex items-center gap-1">
          <Bot className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          <span>Gemini 3.7 Core Online</span>
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1" id="quant-grids">
        
        {/* Left Column - Econometric ARIMA/GARCH forecasting chart */}
        <div className="lg:col-span-5 flex flex-col justify-between" id="forecast-chart-col">
          <div className="mb-2">
            <h3 className="font-bold text-slate-300 text-[11px] uppercase tracking-wide flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-amber-500" />
              <span>GARCH Volatility ARIMA Forecast: {selectedSymbol}</span>
            </h3>
            <span className="text-[9px] text-slate-500 mt-0.5 block">
              Simulates a 12-month geometric Brownian motion drift with dynamic conditional heteroskedastic volatility bands (95% CI).
            </span>
          </div>

          {/* Forecast Recharts Container */}
          <div className="bg-slate-950 rounded border border-slate-850 p-3 h-52 flex items-center justify-center relative" id="forecast-rechart">
            {isLoadingForecast ? (
              <div className="text-slate-500 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-amber-500" />
                <span>Running econometric regressions...</span>
              </div>
            ) : forecast.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={forecast} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#111827" />
                  <XAxis dataKey="month" stroke="#6b7280" style={{ fontSize: 9 }} />
                  <YAxis stroke="#6b7280" style={{ fontSize: 9 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #1e293b", fontSize: 10, fontFamily: "monospace" }}
                    labelStyle={{ fontWeight: "bold", color: "#f59e0b" }}
                  />
                  <Legend verticalAlign="top" height={24} iconSize={8} wrapperStyle={{ fontSize: 9 }} />
                  <Line name="ARIMA Mean Forecast" type="monotone" dataKey="forecast" stroke="#f59e0b" strokeWidth={2} dot={{ r: 2 }} />
                  <Line name="95% CI Upper Vol" type="monotone" dataKey="upper95" stroke="#ef4444" strokeDasharray="5 5" strokeWidth={1} dot={false} />
                  <Line name="95% CI Lower Vol" type="monotone" dataKey="lower95" stroke="#10b981" strokeDasharray="5 5" strokeWidth={1} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <span className="text-slate-500">Awaiting econometric data initialization.</span>
            )}
          </div>

          {/* Quick Analytics Summary */}
          {ticker && (
            <div className="bg-slate-950 border border-slate-850 p-2.5 rounded mt-3 text-[11px] flex flex-wrap items-center justify-between gap-4" id="forecast-meta">
              <div>
                <span className="text-slate-500 block">Baseline Spot volatility:</span>
                <span className="font-bold text-slate-300">{ticker.category === "Rare Earth Elements" ? "21.6% Annual" : "15.4% Annual"}</span>
              </div>
              <div>
                <span className="text-slate-500 block">GARCH(1,1) Persistence:</span>
                <span className="font-bold text-slate-300">alpha+beta = 0.982</span>
              </div>
              <div>
                <span className="text-slate-500 block">12M Mean Price Target:</span>
                <span className="font-bold text-amber-400 font-sans">
                  £{forecast[forecast.length - 1]?.forecast.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Right Column - Gemini AI Market Analyst terminal */}
        <div className="lg:col-span-7 flex flex-col h-[320px] lg:h-auto" id="quant-ai-col">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-slate-300 text-[11px] uppercase tracking-wide flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>Lead Commodities Exchange Analyst</span>
            </h3>
          </div>

          {/* Text Output Terminal Screen */}
          <div className="bg-slate-950 rounded border border-slate-850 p-3 overflow-y-auto flex-1 max-h-[220px]" id="ai-response-stage">
            {isLoadingAi ? (
              <div className="flex flex-col items-center justify-center h-full gap-2.5 text-slate-500 py-10">
                <RefreshCw className="w-6 h-6 animate-spin text-amber-500" />
                <span className="text-center font-bold tracking-wider uppercase text-[10px]">Consulting quantitative exchange datasets & running Monte Carlo models...</span>
              </div>
            ) : aiReport ? (
              <div className="space-y-1.5 text-xs text-slate-300">
                {renderAiReport(aiReport)}
              </div>
            ) : (
              <div className="text-center text-slate-600 py-12">
                Awaiting analytical queries. Click a preset quick scenario report below to initialize research.
              </div>
            )}
          </div>

          {/* Preset Quick Queries */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 mt-2.5" id="preset-queries-container">
            <button
              onClick={() => runQuickQuery("What is the current market value of global rare earth inventories in our vaults? Break down by warehouse locations.")}
              className="bg-slate-950 hover:bg-slate-850 text-slate-400 text-[9px] py-1.5 px-2 rounded border border-slate-850 hover:border-slate-800 text-left cursor-pointer transition-colors"
            >
              📊 Value of global rare earth inventories?
            </button>
            <button
              onClick={() => runQuickQuery("How would a heavy rare earth elements (Dy, Tb) export restriction from China affect global spot prices and user positions?")}
              className="bg-slate-950 hover:bg-slate-850 text-slate-400 text-[9px] py-1.5 px-2 rounded border border-slate-850 hover:border-slate-800 text-left cursor-pointer transition-colors"
            >
              🛑 Heavy REE export restriction impact?
            </button>
            <button
              onClick={() => runQuickQuery("Which critical battery metals have the best long-term industrial demand outlook based on global Gigafactory backlogs?")}
              className="bg-slate-950 hover:bg-slate-850 text-slate-400 text-[9px] py-1.5 px-2 rounded border border-slate-850 hover:border-slate-800 text-left cursor-pointer transition-colors"
            >
              🔋 Best long-term battery metals outlook?
            </button>
            <button
              onClick={() => runQuickQuery("What inventory and procurement strategy minimizes geopolitical and tariff risks while maximizing portfolio EBITDA?")}
              className="bg-slate-950 hover:bg-slate-850 text-slate-400 text-[9px] py-1.5 px-2 rounded border border-slate-850 hover:border-slate-800 text-left cursor-pointer transition-colors"
            >
              🛡️ Optimal risk-minimizing procurement strategy?
            </button>
          </div>

          {/* Custom chat prompt bar */}
          <form onSubmit={handleAskAi} className="flex gap-2 mt-3" id="ai-chat-form">
            <input
              type="text"
              placeholder="Ask the Quantitative Intelligence Core a customized question..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-slate-700 flex-1 text-[11px]"
              id="ai-prompt-input"
            />
            <button
              type="submit"
              disabled={isLoadingAi || !aiPrompt.trim()}
              className="bg-amber-500 hover:bg-amber-400 active:bg-amber-650 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-bold px-3 py-1.5 rounded flex items-center gap-1 cursor-pointer transition-colors text-[11px]"
              id="btn-send-ai"
            >
              <span>SEND</span>
              <Send className="w-3 h-3" />
            </button>
          </form>

        </div>
      </div>
    </div>
  );
};
