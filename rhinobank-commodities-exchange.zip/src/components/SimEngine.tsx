import React, { useState, useEffect } from "react";
import { Play, ToggleLeft, Activity, RefreshCw } from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";

interface SimEngineProps {
  selectedSymbol: string;
}

export const SimEngine: React.FC<SimEngineProps> = ({
  selectedSymbol
}) => {
  const [years, setYears] = useState<number>(10);
  const [toggles, setToggles] = useState({
    evSurge: false,
    recycling: false,
    substitution: false,
    newRefinery: false,
    chinaRestrictions: false
  });
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    runSimulation();
  }, [selectedSymbol]);

  const runSimulation = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/simulation/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ years, toggles })
      });
      if (res.ok) {
        const data = await res.json();
        // format results for chart: year, supply, demand, price
        const formatted = data.results.map((r: any) => ({
          year: `Yr ${r.year}`,
          Price: r.prices[selectedSymbol] || 0,
          Demand: r.globalDemand[selectedSymbol] || 0,
          Supply: r.globalSupply[selectedSymbol] || 0,
          ebitda: r.economicMetrics.mineEbitda,
          npv: r.economicMetrics.npv,
          irr: r.economicMetrics.irr
        }));
        setResults(formatted);
      }
    } catch (e) {
      console.error("Simulation run failed", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggle = (key: keyof typeof toggles) => {
    setToggles(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Get final stats
  const finalResult = results[results.length - 1] || null;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-full text-xs font-mono select-none" id="sim-engine-panel">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-tight flex items-center gap-1.5">
          <Play className="w-4 h-4 text-emerald-500" />
          <span>RCX 10-30Y MACRO SIMULATION ENGINE</span>
        </h2>
        <span className="text-[10px] text-slate-500 font-bold bg-slate-950 px-1.5 py-0.5 rounded">MODELS: RUST HYBRID MATRIX</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1" id="sim-grids">
        
        {/* 1. Simulation Parameter Controls (Left Column) */}
        <div className="lg:col-span-5 space-y-3" id="sim-controls">
          <h3 className="font-bold text-slate-400 text-[10px] uppercase tracking-wider mb-2">Simulation Scenario Toggles</h3>
          
          <div className="space-y-2 bg-slate-950 p-3 rounded border border-slate-850" id="sim-toggle-switches">
            {/* EV Cathode Surge */}
            <div className="flex items-center justify-between py-1 border-b border-slate-900 pb-2">
              <div>
                <span className="font-bold text-slate-200 block text-[11px]">EV Battery Demand Boom</span>
                <span className="text-[9px] text-slate-500 block">Triples EV Gigafactory Cathode capacities.</span>
              </div>
              <input
                type="checkbox"
                checked={toggles.evSurge}
                onChange={() => handleToggle("evSurge")}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Circular Recycling */}
            <div className="flex items-center justify-between py-1 border-b border-slate-900 py-2">
              <div>
                <span className="font-bold text-slate-200 block text-[11px]">Circular Recycling Squeeze</span>
                <span className="text-[9px] text-slate-500 block">Bolsters allied closed-loop metals recovery.</span>
              </div>
              <input
                type="checkbox"
                checked={toggles.recycling}
                onChange={() => handleToggle("recycling")}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Permanent Magnet Substitution */}
            <div className="flex items-center justify-between py-1 border-b border-slate-900 py-2">
              <div>
                <span className="font-bold text-slate-200 block text-[11px]">Magnet-free substitution</span>
                <span className="text-[9px] text-slate-500 block">EV drivetrains transition away from REE magnets.</span>
              </div>
              <input
                type="checkbox"
                checked={toggles.substitution}
                onChange={() => handleToggle("substitution")}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Texas/Allied Refinery Opens */}
            <div className="flex items-center justify-between py-1 border-b border-slate-900 py-2">
              <div>
                <span className="font-bold text-slate-200 block text-[11px]">Allied Heavy Refineries</span>
                <span className="text-[9px] text-slate-500 block">US & European processing plants come online.</span>
              </div>
              <input
                type="checkbox"
                checked={toggles.newRefinery}
                onChange={() => handleToggle("newRefinery")}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* China Export Restriction */}
            <div className="flex items-center justify-between py-1 pt-2">
              <div>
                <span className="font-bold text-slate-200 block text-[11px]">Export Blockades (Heavy REEs)</span>
                <span className="text-[9px] text-slate-500 block">China imposes quota limits on Dysprosium/Terbium.</span>
              </div>
              <input
                type="checkbox"
                checked={toggles.chinaRestrictions}
                onChange={() => handleToggle("chinaRestrictions")}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Timeframe Slider and Run Button */}
          <div className="space-y-3 pt-1" id="sim-parameters">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Horizon:</span>
              <div className="flex gap-1" id="sim-horizon-buttons">
                {[10, 20, 30].map(y => (
                  <button
                    key={y}
                    type="button"
                    onClick={() => setYears(y)}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold cursor-pointer ${
                      years === y 
                        ? "bg-amber-500 text-slate-950" 
                        : "bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {y} Years
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={runSimulation}
              disabled={isLoading}
              className="w-full bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 disabled:bg-slate-850 text-slate-950 font-black py-2 rounded flex items-center justify-center gap-2 transition-colors cursor-pointer"
              id="btn-run-sim"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>SOLVING ECONOMIC MATRICES...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>RUN DE-RISK MACRO SCENARIO</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 2. Simulation Chart Results (Right Column) */}
        <div className="lg:col-span-7 flex flex-col justify-between" id="sim-chart-col">
          <div className="mb-2">
            <h3 className="font-bold text-slate-300 text-[11px] uppercase tracking-wide">
              Simulated {selectedSymbol} Prices vs Supply Balance
            </h3>
            <span className="text-[9px] text-slate-500 block">
              Multi-variant projection demonstrating spot-volatility fluctuations based on real supply-deficit ratios.
            </span>
          </div>

          {/* Chart Container */}
          <div className="bg-slate-950 rounded border border-slate-850 p-3 h-48 flex items-center justify-center relative" id="sim-rechart">
            {isLoading ? (
              <div className="text-slate-500 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-amber-500" />
                <span>Simulating physical-deficit equations...</span>
              </div>
            ) : results.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={results} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#111827" />
                  <XAxis dataKey="year" stroke="#6b7280" style={{ fontSize: 9 }} />
                  <YAxis yAxisId="left" stroke="#f59e0b" style={{ fontSize: 9 }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" style={{ fontSize: 9 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #1e293b", fontSize: 10, fontFamily: "monospace" }}
                    labelStyle={{ fontWeight: "bold", color: "#f59e0b" }}
                  />
                  <Legend verticalAlign="top" height={24} iconSize={8} wrapperStyle={{ fontSize: 9 }} />
                  <Line yAxisId="left" name="Spot Price Target" type="monotone" dataKey="Price" stroke="#f59e0b" strokeWidth={2} dot={{ r: 2 }} />
                  <Line yAxisId="right" name="Demand Balance" type="monotone" dataKey="Demand" stroke="#3b82f6" strokeWidth={1.5} dot={false} />
                  <Line yAxisId="right" name="Supply Cap" type="monotone" dataKey="Supply" stroke="#10b981" strokeWidth={1.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <span className="text-slate-500">Awaiting simulation parameters.</span>
            )}
          </div>

          {/* Project Mine Economics Summary */}
          {finalResult && (
            <div className="bg-slate-950 border border-slate-850 p-2.5 rounded mt-3 grid grid-cols-3 gap-2 text-[10px]" id="sim-economics">
              <div>
                <span className="text-slate-500 uppercase block">Mine EBITDA (Yr-End):</span>
                <span className="font-extrabold text-slate-200 font-sans">£{finalResult.ebitda}M</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase block">Project NPV (5.2x):</span>
                <span className="font-extrabold text-slate-200 font-sans">£{finalResult.npv}M</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase block">Project IRR Index:</span>
                <span className="font-extrabold text-emerald-400 font-sans">{finalResult.irr.toFixed(1)}%</span>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
