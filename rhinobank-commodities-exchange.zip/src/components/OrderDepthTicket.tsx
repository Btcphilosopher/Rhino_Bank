import React, { useState, useEffect } from "react";
import { MarketTicker, OrderBook } from "../types";
import { Activity, ShieldCheck, ArrowRight, Play, ServerCrash } from "lucide-react";

interface OrderDepthTicketProps {
  selectedTicker: MarketTicker | undefined;
  onPlaceTrade: (tradeData: {
    symbol: string;
    type: "BUY" | "SELL";
    price: number;
    amount: number;
    contractType: string;
    counterparty?: string;
    maturityDays?: number;
  }) => Promise<void>;
  portfolioCash: number;
}

export const OrderDepthTicket: React.FC<OrderDepthTicketProps> = ({
  selectedTicker,
  onPlaceTrade,
  portfolioCash
}) => {
  const [tradeType, setTradeType] = useState<"BUY" | "SELL">("BUY");
  const [contractType, setContractType] = useState<string>("Spot");
  const [amount, setAmount] = useState<number>(0);
  const [price, setPrice] = useState<number>(0);
  const [counterparty, setCounterparty] = useState<string>("");
  const [maturityDays, setMaturityDays] = useState<number>(90);
  const [depth, setDepth] = useState<OrderBook | null>(null);
  const [isLoadingDepth, setIsLoadingDepth] = useState(false);
  const [tradeStatus, setTradeStatus] = useState<{ type: "success" | "error" | null; message: string }>({ type: null, message: "" });

  // Prefill price and clear state when selectedTicker changes
  useEffect(() => {
    if (selectedTicker) {
      setPrice(selectedTicker.spotPrice);
      // Sensible default trade sizes
      setAmount(selectedTicker.category === "Rare Earth Elements" ? 500 : 10);
      setTradeStatus({ type: null, message: "" });
      fetchDepth();
    }
  }, [selectedTicker]);

  // Regular depth polling
  useEffect(() => {
    if (!selectedTicker) return;
    const interval = setInterval(fetchDepth, 4000);
    return () => clearInterval(interval);
  }, [selectedTicker]);

  const fetchDepth = async () => {
    if (!selectedTicker) return;
    try {
      const res = await fetch(`/api/market/depth/${selectedTicker.symbol}`);
      if (res.ok) {
        const data = await res.json();
        setDepth(data.depth);
      }
    } catch (e) {
      console.error("Depth polling failed", e);
    }
  };

  if (!selectedTicker) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 flex flex-col items-center justify-center h-full text-xs font-mono text-slate-500" id="empty-ticket-panel">
        <Activity className="w-10 h-10 text-slate-700 mb-2 animate-pulse" />
        <span className="uppercase text-center">Select a mineral from the Ticker Board to open the Physical Exchange Matching Engine.</span>
      </div>
    );
  }

  const handleExecuteTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    setTradeStatus({ type: null, message: "" });

    if (amount <= 0) {
      setTradeStatus({ type: "error", message: "Trade volume amount must exceed zero." });
      return;
    }

    if (price <= 0) {
      setTradeStatus({ type: "error", message: "Trade limit price must exceed zero." });
      return;
    }

    const totalCost = amount * price;
    if (tradeType === "BUY" && portfolioCash < totalCost) {
      setTradeStatus({ type: "error", message: `Insufficient settled cash capital. Required: £${totalCost.toLocaleString()}, Available: £${portfolioCash.toLocaleString()}` });
      return;
    }

    try {
      await onPlaceTrade({
        symbol: selectedTicker.symbol,
        type: tradeType,
        price,
        amount,
        contractType,
        counterparty: contractType !== "Spot" ? counterparty : undefined,
        maturityDays: contractType !== "Spot" ? Number(maturityDays) : undefined
      });
      setTradeStatus({
        type: "success",
        message: `Matched successfully! Physical ${tradeType} contract for ${amount} ${selectedTicker.unit} of ${selectedTicker.symbol} settled.`
      });
      // Trigger a direct depth refresh
      fetchDepth();
    } catch (err: any) {
      setTradeStatus({ type: "error", message: err.message || "Execution engine matched order but settlement rejected." });
    }
  };

  // Calculate order book visual maximum depth volume
  const maxBidVol = depth ? Math.max(...depth.bids.map(b => b.amount), 1) : 1;
  const maxAskVol = depth ? Math.max(...depth.asks.map(a => a.amount), 1) : 1;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col lg:flex-row gap-4 text-xs font-mono select-none h-full" id="trading-engine-panel">
      
      {/* 1. Market Depth Order Book */}
      <div className="flex-1 flex flex-col border-r border-slate-800 pr-4 lg:w-1/2" id="depth-book-col">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 font-bold text-slate-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>MATCHING DEPTH: {selectedTicker.symbol}</span>
          </div>
          <span className="text-[10px] text-slate-500 font-bold bg-slate-950 px-1.5 py-0.5 rounded">LME DEPTH-10</span>
        </div>

        {/* Depth Grid */}
        <div className="flex-1 flex flex-col justify-between" id="depth-grids">
          {/* ASKS (Sells) - Rendered from highest to lowest */}
          <div className="flex-1 flex flex-col-reverse justify-end min-h-[140px]" id="asks-container">
            {depth?.asks.slice(0, 8).map((ask, idx) => (
              <div key={`ask-${idx}`} className="flex items-center justify-between py-1 px-1.5 hover:bg-slate-850/30 text-[10px] relative">
                {/* Horizontal Depth Volume Indicator */}
                <div 
                  className="absolute right-0 top-0 bottom-0 bg-rose-950/15" 
                  style={{ width: `${(ask.amount / maxAskVol) * 100}%` }}
                ></div>
                <span className="text-rose-400 font-bold z-10">£{ask.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                <span className="text-slate-300 font-bold z-10">{ask.amount}</span>
                <span className="text-slate-500 z-10">{ask.count}</span>
              </div>
            ))}
          </div>

          {/* Current Live Spread Spacer */}
          <div className="bg-slate-950 border-y border-slate-800 py-1.5 px-3 my-2 flex items-center justify-between font-bold" id="live-spread">
            <span className="text-slate-400 text-[10px]">SPREAD TICK:</span>
            <span className="text-sm text-slate-200">£{selectedTicker.spotPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            <span className={`text-[10px] ${selectedTicker.change >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
              {selectedTicker.change >= 0 ? "+" : ""}{selectedTicker.change.toFixed(2)}%
            </span>
          </div>

          {/* BIDS (Buys) - Rendered from highest to lowest */}
          <div className="flex-1 flex flex-col justify-start min-h-[140px]" id="bids-container">
            {depth?.bids.slice(0, 8).map((bid, idx) => (
              <div key={`bid-${idx}`} className="flex items-center justify-between py-1 px-1.5 hover:bg-slate-850/30 text-[10px] relative">
                {/* Horizontal Depth Volume Indicator */}
                <div 
                  className="absolute left-0 top-0 bottom-0 bg-emerald-950/15" 
                  style={{ width: `${(bid.amount / maxBidVol) * 100}%` }}
                ></div>
                <span className="text-emerald-400 font-bold z-10">£{bid.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                <span className="text-slate-300 font-bold z-10">{bid.amount}</span>
                <span className="text-slate-500 z-10">{bid.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Physical Trade Ticket */}
      <div className="flex-1 flex flex-col lg:w-1/2" id="trade-ticket-col">
        <h3 className="font-bold text-slate-200 mb-3 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-amber-500" />
          PHYSICAL EXCHANGE SETTLEMENT TICKET
        </h3>

        {/* Buy/Sell Toggles */}
        <div className="grid grid-cols-2 gap-2 mb-4" id="buy-sell-toggle">
          <button
            type="button"
            onClick={() => setTradeType("BUY")}
            className={`py-2 rounded font-black border text-center transition-all cursor-pointer ${
              tradeType === "BUY"
                ? "bg-emerald-950 text-emerald-400 border-emerald-600 shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                : "bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-300"
            }`}
          >
            BID / BUY Spot
          </button>
          <button
            type="button"
            onClick={() => setTradeType("SELL")}
            className={`py-2 rounded font-black border text-center transition-all cursor-pointer ${
              tradeType === "SELL"
                ? "bg-rose-950 text-rose-400 border-rose-600 shadow-[0_0_10px_rgba(244,63,94,0.1)]"
                : "bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-300"
            }`}
          >
            OFFER / SELL Spot
          </button>
        </div>

        {/* Form Inputs */}
        <form onSubmit={handleExecuteTrade} className="flex-1 flex flex-col gap-3.5" id="trade-form">
          {/* Contract Select */}
          <div>
            <label className="block text-slate-400 text-[10px] uppercase mb-1 font-bold">Market Order Type</label>
            <select
              value={contractType}
              onChange={(e) => setContractType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-slate-700"
              id="input-contract-type"
            >
              <option value="Spot">Spot (Immediate Physical Settlement)</option>
              <option value="Forward">Forward Contract (Locked derivative)</option>
              <option value="Long-Term Supply Agreements">Long-Term Supply Agreement</option>
              <option value="Industrial Procurement Contracts">Procurement Contract</option>
              <option value="OTC">OTC Direct Trading</option>
              <option value="Warehouse Receipts">Warehouse Receipt Settle</option>
            </select>
          </div>

          {/* Amount and Limit Price */}
          <div className="grid grid-cols-2 gap-3" id="trade-inputs">
            <div>
              <label className="block text-slate-400 text-[10px] uppercase mb-1 font-bold">
                Volume Size ({selectedTicker.unit})
              </label>
              <input
                type="number"
                value={amount || ""}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-slate-200 focus:outline-none focus:border-slate-700 font-bold"
                id="input-amount"
                min="1"
              />
            </div>
            <div>
              <label className="block text-slate-400 text-[10px] uppercase mb-1 font-bold">
                Limit Price (£/{selectedTicker.unit})
              </label>
              <input
                type="number"
                step="0.01"
                value={price || ""}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-slate-200 focus:outline-none focus:border-slate-700 font-bold"
                id="input-price"
                min="0.01"
              />
            </div>
          </div>

          {/* Conditional derivative details */}
          {contractType !== "Spot" && (
            <div className="bg-slate-950 border border-slate-850 p-2.5 rounded gap-2.5 flex flex-col" id="derivative-fields">
              <div>
                <label className="block text-slate-400 text-[10px] uppercase mb-1 font-bold">Maturity Horizon</label>
                <select
                  value={maturityDays}
                  onChange={(e) => setMaturityDays(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-300 text-[11px]"
                  id="input-maturity"
                >
                  <option value="30">30 Days (M-1 Month)</option>
                  <option value="90">90 Days (Q-1 Quarter)</option>
                  <option value="180">180 Days (H-Half Year)</option>
                  <option value="360">360 Days (Y-1 Year Roll)</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-400 text-[10px] uppercase mb-1 font-bold">Clearing Counterparty</label>
                <input
                  type="text"
                  placeholder="e.g. Siemens Wind Power, BAE Systems, Albemarle"
                  value={counterparty}
                  onChange={(e) => setCounterparty(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-300 text-[11px]"
                  id="input-counterparty"
                />
              </div>
            </div>
          )}

          {/* Trade Math Summary */}
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-[11px]" id="trade-summary">
            <div className="flex justify-between mb-1">
              <span className="text-slate-500">Contract Face Value:</span>
              <span className="text-slate-300 font-sans font-bold">
                £{(amount * price).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-500">Settle-Purity Premium:</span>
              <span className="text-emerald-400">Included ({selectedTicker.purity})</span>
            </div>
            <div className="flex justify-between border-t border-slate-850 pt-1 mt-1 font-bold">
              <span className="text-slate-400">Total Capital Impact:</span>
              <span className="text-slate-100 font-sans">
                £{(amount * price).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Status Message */}
          {tradeStatus.type && (
            <div className={`p-2.5 rounded text-[10px] border ${
              tradeStatus.type === "success" 
                ? "bg-emerald-950/40 text-emerald-300 border-emerald-900" 
                : "bg-rose-950/40 text-rose-300 border-rose-900"
            }`} id="trade-status-msg">
              {tradeStatus.message}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className={`w-full py-2.5 rounded font-bold cursor-pointer transition-colors mt-auto flex items-center justify-center gap-2 text-slate-950 ${
              tradeType === "BUY"
                ? "bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 font-extrabold"
                : "bg-rose-500 hover:bg-rose-400 active:bg-rose-600 font-extrabold"
            }`}
            id="btn-execute-trade"
          >
            <span>SUBMIT ORDERS TO MATCHING ENGINE</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
