/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TransportMode = "bus" | "rail" | "taxi";

export type BusSubMode = "local" | "express" | "school" | "park_ride";
export type RailSubMode = "heavy_rail" | "commuter" | "regional";
export type TaxiSubMode = "licensed" | "private_hire" | "accessible";

export type SubMode = BusSubMode | RailSubMode | TaxiSubMode;

export interface TransitStop {
  id: string;
  name: string;
  authority: "Leeds" | "Bradford" | "Wakefield" | "Calderdale" | "Kirklees";
  lat: number;
  lng: number;
  modes: TransportMode[];
  capacity: number;
  passengerVolume: number; // daily average
}

export interface TransitRoute {
  id: string;
  name: string;
  mode: TransportMode;
  subMode: SubMode;
  stops: string[]; // Ordered stop IDs
  distanceMiles: number;
  baseTravelTimeMinutes: number;
  peakFrequencyMinutes: number;
  offPeakFrequencyMinutes: number;
  operatingCostPerMile: number;
  fareRevenuePerPassenger: number;
}

export interface TimetableTrip {
  id: string;
  routeId: string;
  routeName: string;
  mode: TransportMode;
  vehicleId: string;
  driverId: string;
  startTime: string; // "HH:MM"
  endTime: string; // "HH:MM"
  stopPassings: {
    stopId: string;
    stopName: string;
    arrivalTime: string;
    departureTime: string;
  }[];
}

export interface Depot {
  id: string;
  name: string;
  location: string;
  authority: string;
  capacity: number;
  currentVehicles: number;
  chargingPoints: number; // For EV buses
  modesSupported: TransportMode[];
}

export interface FleetVehicle {
  id: string;
  registration: string;
  mode: TransportMode;
  subMode: SubMode;
  capacitySeated: number;
  capacityStanding: number;
  energyType: "diesel" | "electric" | "biomethane" | "electric_train" | "diesel_train" | "hybrid";
  soc: number; // State of Charge for electric
  status: "active" | "layover" | "maintenance" | "charging";
  depotId: string;
  nextMaintenance: string;
}

export interface DriverDuty {
  id: string;
  driverName: string;
  driverId: string;
  shiftStart: string; // "HH:MM"
  shiftEnd: string; // "HH:MM"
  tripsAssigned: string[]; // TimetableTrip IDs
  breaks: {
    start: string;
    end: string;
    location: string;
    type: "meal" | "layover";
  }[];
  totalWorkMinutes: number;
  overtimeMinutes: number;
  status: "on_duty" | "break" | "off_duty" | "standby";
}

export interface SchedulingConflict {
  id: string;
  type: "headway_bunching" | "platform_congestion" | "layover_deficit" | "break_violation" | "capacity_overflow";
  severity: "critical" | "warning";
  message: string;
  location: string;
  entityId: string; // routeId, stopId, or driverId
  suggestedFix: string;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  type: "housing_development" | "infra_upgrade" | "frequency_change" | "fleet_expansion";
  impactArea: "Leeds" | "Bradford" | "Wakefield" | "Calderdale" | "Kirklees" | "All";
  parameters: {
    populationGrowthPct?: number;
    roadworkDelayMinutes?: number;
    newRouteFrequencyMinutes?: number;
    addedVehiclesCount?: number;
    electricFleetPct?: number;
  };
}

export interface NetworkMetrics {
  totalPassengers: number;
  avgOnTimePerformance: number; // 0-100
  avgWaitTimeMinutes: number;
  fleetUtilisationPct: number;
  totalRevenue: number;
  totalSubsidy: number;
  subsidyPerPassenger: number;
  averageCrowdingPct: number; // 0-100
  congestionPoints: { location: string; mode: TransportMode; score: number }[];
}

export interface SimulationResult {
  scenarioId: string;
  before: NetworkMetrics;
  after: NetworkMetrics;
  charts: {
    hourlyDemand: { hour: number; before: number; after: number }[];
    modeShare: { mode: string; before: number; after: number }[];
    authorityStats: { authority: string; before: number; after: number }[];
  };
  executiveSummary: string;
}
