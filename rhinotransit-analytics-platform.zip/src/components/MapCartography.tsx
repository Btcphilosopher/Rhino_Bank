/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { TransitStop, TransitRoute, TransportMode } from "../types";
import { MapPin, Navigation, Info, ShieldAlert, Zap, Compass } from "lucide-react";

interface MapCartographyProps {
  stops: TransitStop[];
  routes: TransitRoute[];
  selectedStop: TransitStop | null;
  onSelectStop: (stop: TransitStop | null) => void;
  crowdingOverlay: boolean;
}

export default function MapCartography({
  stops,
  routes,
  selectedStop,
  onSelectStop,
  crowdingOverlay,
}: MapCartographyProps) {
  const [filterMode, setFilterMode] = useState<TransportMode | "all">("all");
  const [startStopId, setStartStopId] = useState<string>("");
  const [endStopId, setEndStopId] = useState<string>("");
  const [activePath, setActivePath] = useState<any[] | null>(null);
  const [loadingRoute, setLoadingRoute] = useState(false);
  const [pathfindError, setPathfindError] = useState<string | null>(null);

  // Map projections coordinates range
  // West Yorkshire coordinates: lat ~ 53.6 to 53.9, lng ~ -2.1 to -1.3
  const latMin = 53.62;
  const latMax = 53.86;
  const lngMin = -2.05;
  const lngMax = -1.33;

  // Project lat/lng to 0-100% canvas bounds
  const projectCoords = (lat: number, lng: number) => {
    // scale longitude
    const x = ((lng - lngMin) / (lngMax - lngMin)) * 100;
    // scale latitude (invert Y since GPS goes up but screen goes down)
    const y = (1 - (lat - latMin) / (latMax - latMin)) * 100;
    return { x: Math.max(5, Math.min(95, x)), y: Math.max(5, Math.min(95, y)) };
  };

  // Perform shortest path Dijkstra calculations
  const runPathfind = async () => {
    if (!startStopId || !endStopId) return;
    setLoadingRoute(true);
    setPathfindError(null);
    try {
      const response = await fetch("/api/pathfind", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startStopId, endStopId }),
      });
      const data = await response.json();
      if (response.ok && data.path) {
        setActivePath(data.path);
      } else {
        setPathfindError(data.error || "Route unavailable");
        setActivePath(null);
      }
    } catch (err) {
      setPathfindError("Pathfinder routing request failed");
      setActivePath(null);
    } finally {
      setLoadingRoute(false);
    }
  };

  const clearPath = () => {
    setStartStopId("");
    setEndStopId("");
    setActivePath(null);
    setPathfindError(null);
  };

  // Pre-project stops coordinates
  const stopsWithCoords = stops.map((stop) => ({
    ...stop,
    pos: projectCoords(stop.lat, stop.lng),
  }));

  const stopMap = new Map(stopsWithCoords.map((s) => [s.id, s]));

  // District boundaries/labels in Yorkshire Futurism theme
  const districts = [
    { name: "Bradford", x: 18, y: 35, color: "rgba(100, 116, 139, 0.04)" },
    { name: "Leeds", x: 65, y: 30, color: "rgba(100, 116, 139, 0.04)" },
    { name: "Calderdale", x: 12, y: 65, color: "rgba(100, 116, 139, 0.04)" },
    { name: "Kirklees", x: 32, y: 80, color: "rgba(100, 116, 139, 0.04)" },
    { name: "Wakefield", x: 75, y: 75, color: "rgba(100, 116, 139, 0.04)" },
  ];

  return (
    <div id="gis-cartography-widget" className="grid grid-cols-1 lg:grid-cols-4 gap-6 bg-[#0A192F] border border-[#B4B8B9]/20 p-6 text-white relative">
      {/* Absolute Header Ribbon */}
      <div className="absolute top-0 left-0 bg-[#D48E5C] text-black text-[10px] font-bold px-3 py-0.5 tracking-widest uppercase">
        Metro Map-Engine v4.2
      </div>

      {/* Control panel */}
      <div className="space-y-6 flex flex-col justify-between h-full border-r border-[#B4B8B9]/20 pr-6 lg:col-span-1">
        <div>
          <h2 className="text-xl font-black tracking-tight text-white uppercase flex items-center gap-2 mt-4">
            <Compass className="w-5 h-5 text-[#D48E5C]" />
            GIS Cartography
          </h2>
          <p className="text-xs text-[#B4B8B9]/80 mt-1 leading-relaxed">
            Multi-modal geographical twin for transport corridor density, load balancing, and connectivity index calculations.
          </p>

          {/* Mode Selector */}
          <div className="mt-6 space-y-2">
            <label className="text-[10px] font-bold tracking-widest text-[#B4B8B9]/60 uppercase">Transit Filter</label>
            <div className="grid grid-cols-2 gap-1 bg-[#1A1A1A] p-1 border border-[#B4B8B9]/20">
              {(["all", "bus", "rail"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setFilterMode(m)}
                  className={`text-[10px] tracking-wider uppercase py-1.5 px-3 transition-all duration-150 whitespace-nowrap text-center font-bold ${
                    filterMode === m
                      ? "bg-[#D48E5C] text-black font-black"
                      : "text-[#B4B8B9] hover:text-white hover:bg-[#1A1A1A]/50"
                  }`}
                >
                  {m === "all" ? "All Modes" : m}
                </button>
              ))}
            </div>
          </div>

          {/* Dijkstra Pathfinder Controls */}
          <div className="mt-6 space-y-3">
            <div className="flex items-center justify-between border-b border-[#B4B8B9]/20 pb-1">
              <label className="text-[10px] font-bold tracking-widest text-[#B4B8B9]/60 uppercase">Dijkstra Pathfinder</label>
              {activePath && (
                <button onClick={clearPath} className="text-[10px] text-[#D48E5C] uppercase hover:underline font-bold">
                  Reset
                </button>
              )}
            </div>

            <div className="space-y-2">
              <select
                value={startStopId}
                onChange={(e) => setStartStopId(e.target.value)}
                className="w-full bg-[#1A1A1A] text-xs border border-[#B4B8B9]/20 p-2 text-gray-200 focus:outline-none focus:border-[#D48E5C] font-mono"
              >
                <option value="">-- Origin Stop --</option>
                {stops.map((s) => (
                  <option key={s.id} value={s.id}>
                    [{s.authority.toUpperCase()}] {s.name}
                  </option>
                ))}
              </select>

              <select
                value={endStopId}
                onChange={(e) => setEndStopId(e.target.value)}
                className="w-full bg-[#1A1A1A] text-xs border border-[#B4B8B9]/20 p-2 text-gray-200 focus:outline-none focus:border-[#D48E5C] font-mono"
              >
                <option value="">-- Destination Stop --</option>
                {stops.map((s) => (
                  <option key={s.id} value={s.id}>
                    [{s.authority.toUpperCase()}] {s.name}
                  </option>
                ))}
              </select>

              <button
                disabled={loadingRoute || !startStopId || !endStopId}
                onClick={runPathfind}
                className="w-full bg-[#D48E5C] hover:bg-[#c37d4d] text-black text-xs font-bold uppercase py-2 transition duration-150 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
              >
                {loadingRoute ? "Calculating path..." : "Run Shortest Path"}
              </button>
            </div>

            {pathfindError && (
              <div className="bg-red-950/40 border border-red-800 text-red-300 p-2 text-xs rounded-sm flex items-start gap-1.5">
                <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{pathfindError}</span>
              </div>
            )}
          </div>
        </div>

        {/* Selected stop detail card */}
        <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-xs leading-relaxed space-y-2">
          {selectedStop ? (
            <>
              <div className="flex items-center justify-between border-b border-[#B4B8B9]/20 pb-1">
                <span className="font-bold text-white text-sm uppercase tracking-tight">
                  {selectedStop.name}
                </span>
                <span className="bg-[#0A192F] text-[9px] px-1.5 py-0.5 uppercase tracking-wide border border-[#B4B8B9]/10">
                  {selectedStop.authority}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-[#B4B8B9]/80">
                <div>Modes:</div>
                <div className="text-white uppercase font-semibold">{selectedStop.modes.join(" / ")}</div>
                <div>Avg Volume:</div>
                <div className="text-[#D48E5C] font-mono font-bold">
                  {selectedStop.passengerVolume.toLocaleString()} / day
                </div>
                <div>Stop Capacity:</div>
                <div className="text-white font-mono">{selectedStop.capacity.toLocaleString()}</div>
                <div>Coordinates:</div>
                <div className="text-white font-mono text-[10px]">
                  {selectedStop.lat.toFixed(4)}, {selectedStop.lng.toFixed(4)}
                </div>
              </div>
            </>
          ) : (
            <div className="text-[#B4B8B9]/60 text-center py-4 flex flex-col items-center gap-1.5">
              <Info className="w-4 h-4 text-[#B4B8B9]/40" />
              <span>Select any stop on the cartography map to view active line connections.</span>
            </div>
          )}
        </div>
      </div>

      {/* Cartographic canvas */}
      <div className="lg:col-span-3 bg-[#1A1A1A] border border-[#B4B8B9]/20 relative overflow-hidden min-h-[460px] flex items-center justify-center">
        {/* Spatial background grid */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{
          backgroundImage: `radial-gradient(#FFF 1px, transparent 1px)`,
          backgroundSize: '20px 20px'
        }} />

        {/* Pathfinder active badge */}
        {activePath && (
          <div className="absolute top-4 right-4 bg-[#D48E5C] text-black text-[10px] font-extrabold uppercase px-2 py-1 tracking-wider z-10 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 fill-black" />
            Active Path: {activePath[activePath.length - 1].arrivalTimeMinutes.toFixed(1)} mins transit
          </div>
        )}

        <svg className="w-full h-full min-h-[460px] select-none" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Municipal Boundaries Representations */}
          {districts.map((d, idx) => (
            <g key={idx}>
              <circle cx={d.x} cy={d.y} r="18" fill={d.color} stroke="rgba(255,255,255,0.02)" strokeWidth="0.5" strokeDasharray="1 1" />
              <text x={d.x} y={d.y + 1} className="text-[2.2px] fill-gray-600 font-extrabold tracking-widest uppercase opacity-70 text-center" textAnchor="middle">
                {d.name} METRO ZONE
              </text>
            </g>
          ))}

          {/* 1. DRAW BASE TRANSIT ROUTE LINES */}
          {routes
            .filter((r) => filterMode === "all" || r.mode === filterMode)
            .map((route) => {
              const stopPoints = route.stops
                .map((id) => stopMap.get(id))
                .filter((s): s is NonNullable<typeof s> => s !== undefined);

              if (stopPoints.length < 2) return null;

              // Generate SVG path string
              const pathString = stopPoints.reduce((acc, s, idx) => {
                return acc + (idx === 0 ? `M ${s.pos.x} ${s.pos.y}` : ` L ${s.pos.x} ${s.pos.y}`);
              }, "");

              const isRail = route.mode === "rail";
              const isShortestPathSegment =
                activePath &&
                activePath.some(
                  (step, idx) =>
                    step.routeId === route.id &&
                    activePath[idx - 1] &&
                    step.stopId &&
                    (activePath[idx - 1].stopId === route.stops[route.stops.indexOf(step.stopId) - 1] ||
                      activePath[idx - 1].stopId === route.stops[route.stops.indexOf(step.stopId) + 1])
                );

              return (
                <path
                  key={route.id}
                  d={pathString}
                  fill="none"
                  stroke={isShortestPathSegment ? "#D48E5C" : isRail ? "#1D4ED8" : "#4B5563"}
                  strokeWidth={isShortestPathSegment ? "1.2" : isRail ? "0.7" : "0.4"}
                  strokeDasharray={isRail && !isShortestPathSegment ? "1.5 1" : undefined}
                  className={`transition-all duration-300 ${
                    isShortestPathSegment ? "animate-pulse stroke-[#D48E5C]" : "opacity-40"
                  }`}
                >
                  <title>{route.name}</title>
                </path>
              );
            })}

          {/* 2. PATHFINDER ANIMATED TRACER */}
          {activePath && (
            <g>
              {(() => {
                const points = activePath
                  .map((step) => stopMap.get(step.stopId))
                  .filter((s): s is NonNullable<typeof s> => s !== undefined);

                if (points.length < 2) return null;

                const pathString = points.reduce((acc, s, idx) => {
                  return acc + (idx === 0 ? `M ${s.pos.x} ${s.pos.y}` : ` L ${s.pos.x} ${s.pos.y}`);
                }, "");

                return (
                  <path
                    d={pathString}
                    fill="none"
                    stroke="#D48E5C"
                    strokeWidth="1.2"
                    strokeDasharray="2 2"
                    strokeLinecap="round"
                    className="stroke-[#D48E5C] animate-[dash_4s_linear_infinite]"
                    style={{
                      strokeDashoffset: 100,
                    }}
                  />
                );
              })()}
            </g>
          )}

          {/* 3. DRAW STOPS / INTERCHANGES */}
          {stopsWithCoords
            .filter((stop) => filterMode === "all" || stop.modes.some((m) => m === filterMode))
            .map((stop) => {
              const isSelected = selectedStop?.id === stop.id;
              const hasRail = stop.modes.includes("rail");
              const isHotspot = crowdingOverlay && stop.passengerVolume > 16000;

              // Size represents daily passenger volume scaling
              const nodeSize = 1.0 + (stop.passengerVolume / 100000) * 1.5;

              // Pathfinder status
              const isStartOfPath = activePath && activePath[0]?.stopId === stop.id;
              const isEndOfPath = activePath && activePath[activePath.length - 1]?.stopId === stop.id;
              const isInPath = activePath && activePath.some((step) => step.stopId === stop.id);

              return (
                <g
                  key={stop.id}
                  className="cursor-pointer group"
                  onClick={() => onSelectStop(stop)}
                >
                  {/* Crowding hotspot ring */}
                  {isHotspot && (
                    <circle
                      cx={stop.pos.x}
                      cy={stop.pos.y}
                      r={nodeSize * 2.2}
                      fill="none"
                      stroke="#D48E5C"
                      strokeWidth="0.25"
                      className="animate-ping opacity-35"
                    />
                  )}

                  {/* Node Hover Outline */}
                  <circle
                    cx={stop.pos.x}
                    cy={stop.pos.y}
                    r={nodeSize + 0.9}
                    fill="none"
                    stroke={isSelected ? "#D48E5C" : isInPath ? "#E2DFDA" : "rgba(255,255,255,0.2)"}
                    strokeWidth={isSelected ? "0.6" : "0.25"}
                    className="opacity-0 group-hover:opacity-100 transition-opacity duration-150"
                  />

                  {/* Primary Node core */}
                  <circle
                    cx={stop.pos.x}
                    cy={stop.pos.y}
                    r={nodeSize}
                    fill={
                      isStartOfPath
                        ? "#10B981"
                        : isEndOfPath
                        ? "#EF4444"
                        : isInPath
                        ? "#D48E5C"
                        : hasRail
                        ? "#1E3A8A"
                        : "#2D3139"
                    }
                    stroke={isSelected ? "#D48E5C" : "#111214"}
                    strokeWidth="0.3"
                  />

                  {/* Rail icon dot indicator */}
                  {hasRail && (
                    <circle
                      cx={stop.pos.x}
                      cy={stop.pos.y}
                      r={nodeSize * 0.4}
                      fill="#3B82F6"
                    />
                  )}

                  {/* Stop Name Label */}
                  <text
                    x={stop.pos.x}
                    y={stop.pos.y - nodeSize - 1}
                    className={`text-[1.8px] font-sans font-semibold text-center ${
                      isSelected ? "fill-[#D48E5C] font-black text-[2.2px]" : isInPath ? "fill-[#E2DFDA]" : "fill-gray-400 group-hover:fill-white"
                    }`}
                    textAnchor="middle"
                  >
                    {stop.name}
                  </text>
                </g>
              );
            })}
        </svg>

        {/* Legend overlays */}
        <div className="absolute bottom-4 left-4 bg-[#0A192F]/90 border border-[#B4B8B9]/20 p-3 text-[10px] space-y-1.5 leading-none">
          <div className="font-bold text-[#B4B8B9] uppercase tracking-wider pb-1 border-b border-[#B4B8B9]/20 mb-1">
            Map Legend
          </div>
          <div className="flex items-center gap-2 text-white">
            <span className="w-2 h-2 rounded-full bg-[#1E3A8A]" />
            <span>Rail Node</span>
          </div>
          <div className="flex items-center gap-2 text-white">
            <span className="w-2 h-2 rounded-full bg-[#2D3139]" />
            <span>Bus Node</span>
          </div>
          <div className="flex items-center gap-2 text-white">
            <span className="w-4 h-0.5 border-t border-dashed border-[#1D4ED8]" />
            <span>Commuter Rail Route</span>
          </div>
          <div className="flex items-center gap-2 text-white">
            <span className="w-4 h-0.5 bg-gray-600" />
            <span>Bus Transit Line</span>
          </div>
          <div className="flex items-center gap-2 text-white">
            <span className="w-3 h-3 border border-[#D48E5C] rounded-full animate-pulse bg-none" />
            <span>Congested Corridor Hotspot</span>
          </div>
        </div>
      </div>
    </div>
  );
}
