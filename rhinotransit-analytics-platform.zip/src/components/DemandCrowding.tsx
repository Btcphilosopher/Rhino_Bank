/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { TransitStop, TransitRoute } from "../types";
import { TrendingUp, Users, AlertTriangle, Check, ShieldCheck } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface DemandCrowdingProps {
  stops: TransitStop[];
  routes: TransitRoute[];
}

export default function DemandCrowding({ stops, routes }: DemandCrowdingProps) {
  const [selectedSubsegment, setSelectedSubsegment] = useState<"commuter" | "school" | "leisure">("commuter");

  // Hourly synthetic demand profiles based on segment selection
  const hourlyData = Array.from({ length: 24 }, (_, i) => {
    const hour = i;
    let weight = 0.2; // off peak baseline

    if (selectedSubsegment === "commuter") {
      // 7:00-09:00 and 16:30-18:30 peaks
      if (hour >= 7 && hour <= 9) weight = 0.95;
      else if (hour >= 16 && hour <= 18) weight = 0.88;
      else if (hour >= 10 && hour <= 15) weight = 0.45;
    } else if (selectedSubsegment === "school") {
      // Shorter, sharper peaks at 08:00 and 15:30
      if (hour === 8) weight = 0.98;
      else if (hour === 15 || hour === 16) weight = 0.75;
    } else {
      // Even leisure curve throughout midday and evening
      if (hour >= 11 && hour <= 21) weight = 0.65;
      if (hour >= 18 && hour <= 22) weight = 0.75; // dinner/pub
    }

    const passengerLoad = Math.round(weight * 38000 + Math.random() * 1200);

    return {
      hour: `${hour.toString().padStart(2, "0")}:00`,
      passengers: passengerLoad,
    };
  }).filter((_, idx) => idx >= 5 && idx <= 23); // Display active transit hours (05:00 to 23:00)

  // Busiest corridors representation
  const busyStops = [...stops]
    .sort((a, b) => b.passengerVolume - a.passengerVolume)
    .slice(0, 5);

  const subsegmentDetails = {
    commuter: {
      title: "Worker & Commuter Flow",
      impact: "High peak concentration, heavy directional asymmetry on Leeds/Bradford arterial highways.",
      ratio: "62.4%",
      avgFare: "£4.20",
    },
    school: {
      title: "Educational & Student Transit",
      impact: "Sharp morning spike. Concentrated around Woodhouse Leeds and Bradford Forster University complexes.",
      ratio: "21.8%",
      avgFare: "£1.20",
    },
    leisure: {
      title: "Off-Peak & Social Leisure",
      impact: "Even distribution, late-night regional train peaks connecting Hebden Bridge, Halifax and Leeds.",
      ratio: "15.8%",
      avgFare: "£2.80",
    },
  };

  return (
    <div id="demand-crowding-widget" className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-[#0A192F] border border-[#B4B8B9]/20 p-6 text-white relative">
      <div className="absolute top-0 left-0 bg-[#D48E5C] text-black text-[10px] font-bold px-3 py-0.5 tracking-widest uppercase">
        Demand-Engine v3.5
      </div>

      {/* Grid Column 1: Subsegment filters and key metrics */}
      <div className="space-y-4 pr-0 lg:pr-6 border-r-0 lg:border-r border-[#B4B8B9]/20 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-black tracking-tight text-white uppercase flex items-center gap-2 mt-4">
            <Users className="w-5 h-5 text-[#D48E5C]" />
            Passenger Demand
          </h2>
          <p className="text-xs text-[#B4B8B9]/85 mt-1 leading-relaxed">
            Time-of-day demographic loading indexes, seasonal forecasting models, and modal split matrices.
          </p>

          {/* Segment Selector */}
          <div className="mt-6 space-y-2">
            <label className="text-[10px] font-bold tracking-widest text-[#B4B8B9]/60 uppercase">Demographic Segment</label>
            <div className="flex flex-col gap-1.5">
              {(["commuter", "school", "leisure"] as const).map((seg) => (
                <button
                  key={seg}
                  onClick={() => setSelectedSubsegment(seg)}
                  className={`w-full text-left text-xs py-2 px-3 border transition duration-150 flex justify-between items-center ${
                    selectedSubsegment === seg
                      ? "bg-[#D48E5C] text-black border-[#D48E5C] font-black uppercase"
                      : "bg-[#1A1A1A] border-[#B4B8B9]/20 text-[#B4B8B9] hover:text-white hover:bg-[#1C1F22]"
                  }`}
                >
                  <span className="capitalize">{seg} Demand</span>
                  <span className="font-mono text-[10px]">{subsegmentDetails[seg].ratio}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Segment description card */}
          <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-xs leading-relaxed space-y-1 mt-4">
            <div className="font-bold text-white uppercase tracking-tight">
              {subsegmentDetails[selectedSubsegment].title}
            </div>
            <p className="text-[#B4B8B9]/80 text-[11px]">{subsegmentDetails[selectedSubsegment].impact}</p>
            <div className="flex justify-between border-t border-[#B4B8B9]/10 pt-2 mt-2 text-[#B4B8B9]/50 text-[10px]">
              <span>Avg Revenue/Trip:</span>
              <span className="font-mono font-bold text-[#D48E5C]">
                {subsegmentDetails[selectedSubsegment].avgFare}
              </span>
            </div>
          </div>
        </div>

        {/* Aggregate statistics */}
        <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-xs space-y-2">
          <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Active Capacity Utilisation</div>
          <div className="flex items-center justify-between">
            <div className="text-xl font-black text-[#D48E5C]">64.2%</div>
            <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 border border-emerald-900 flex items-center gap-1 font-semibold uppercase">
              <ShieldCheck className="w-3.5 h-3.5" /> Normal
            </span>
          </div>
          <div className="w-full bg-[#202224] h-1.5 rounded-none overflow-hidden">
            <div className="bg-[#D48E5C] h-full" style={{ width: "64.2%" }} />
          </div>
        </div>
      </div>

      {/* Grid Column 2: Recharts Hourly load curve */}
      <div className="lg:col-span-2 space-y-4">
        <div>
          <h3 className="text-base font-black text-white uppercase tracking-tight border-b border-[#B4B8B9]/20 pb-2">
            Hourly Passenger Load Curve
          </h3>
          <div className="h-[200px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorPass" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D48E5C" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#D48E5C" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#22252A" />
                <XAxis dataKey="hour" stroke="#9CA3AF" fontSize={10} tickLine={false} />
                <YAxis stroke="#9CA3AF" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1A1A1A", borderColor: "#B4B8B9" }}
                  labelStyle={{ fontWeight: "bold", color: "#D48E5C" }}
                />
                <Area type="monotone" dataKey="passengers" stroke="#D48E5C" fillOpacity={1} fill="url(#colorPass)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bottlenecks lists */}
        <div className="space-y-2 border-t border-[#B4B8B9]/20 pt-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-[#D48E5C]" />
            Top 5 Network Bottlenecks (Congestion Score)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
            {busyStops.map((stop) => {
              const crowdingLevel = Math.round((stop.passengerVolume / stop.capacity) * 100);
              return (
                <div key={stop.id} className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-2 flex flex-col justify-between text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white truncate uppercase tracking-wide">{stop.name}</span>
                    <span className="text-[9px] font-mono bg-[#0A192F] text-[#B4B8B9] px-1 py-0.5 border border-[#B4B8B9]/10 uppercase">{stop.authority}</span>
                  </div>
                  <div className="flex items-center justify-between mt-2 text-[11px] text-[#B4B8B9]">
                    <span>Peak Crowding:</span>
                    <span className={`font-mono font-bold ${crowdingLevel > 70 ? "text-[#D48E5C]" : "text-emerald-400"}`}>
                      {crowdingLevel}%
                    </span>
                  </div>
                  <div className="w-full bg-[#202224] h-1 mt-1">
                    <div
                      className={`h-full ${crowdingLevel > 70 ? "bg-[#D48E5C]" : "bg-emerald-500"}`}
                      style={{ width: `${Math.min(100, crowdingLevel)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
