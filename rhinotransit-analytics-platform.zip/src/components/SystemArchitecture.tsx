/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Cpu, Server, Database, GitMerge, Network, CheckCircle } from "lucide-react";

interface ServiceBlock {
  name: string;
  description: string;
  state: "operational" | "active" | "standby";
  subsystem: "core" | "analytics" | "gateway";
  techStack: string;
}

const services: ServiceBlock[] = [
  { name: "transit-core", description: "Registers base municipal state vectors, entity registries, and CRUD engines.", state: "operational", subsystem: "core", techStack: "Rust / SQLx" },
  { name: "network-engine", description: "Maintains multi-modal weighted graphs, routing topology, and Dijkstra SPF solvers.", state: "active", subsystem: "core", techStack: "Rust / Tokio" },
  { name: "timetable-engine", description: "Creates trip lists, monitors peak headways, and performs layover packing.", state: "active", subsystem: "core", techStack: "Rust / Tokio" },
  { name: "demand-engine", description: "Tracks demographic flows, boards/alights, and hourly load shapes.", state: "operational", subsystem: "analytics", techStack: "Rust / polars" },
  { name: "scheduling-engine", description: "Assigns duty schedules and manages driver shifts and relief breaks.", state: "operational", subsystem: "core", techStack: "Rust / OR-Tools" },
  { name: "fleet-engine", description: "Coordinates active rotations, depot parking, and EV battery charging cycles.", state: "operational", subsystem: "core", techStack: "Rust / Tokio" },
  { name: "depot-engine", description: "Calculates overnight terminal layouts and charging hookup load balancing.", state: "operational", subsystem: "core", techStack: "Rust / SQLx" },
  { name: "finance-engine", description: "Conducts Capex/Opex ledgers, franchising revenues, and municipal subsidies.", state: "operational", subsystem: "analytics", techStack: "Rust / SQLx" },
  { name: "gis-engine", description: "Projects coordinates, manages catchment grids, and maps regional density layers.", state: "active", subsystem: "gateway", techStack: "Rust / geo" },
  { name: "simulation-engine", description: "Runs discrete-event Monte Carlo loops for city development scenarios.", state: "active", subsystem: "analytics", techStack: "Rust / Tokio" },
  { name: "reporting-engine", description: "Formats CSV outputs, statistical tables, and routes to Gemini API.", state: "operational", subsystem: "analytics", techStack: "Rust / @google/genai" },
  { name: "dashboard-service", description: "Feeds visual front-end streams, WebSockets, and UI components.", state: "active", subsystem: "gateway", techStack: "Axum / SSE" },
  { name: "api-gateway", description: "Proxies multi-modal REST and gRPC calls, handles rate-limits, and routing.", state: "active", subsystem: "gateway", techStack: "Tonic / Axum" },
  { name: "audit-service", description: "Logs immutable ledger audits of timetables and planning actions.", state: "operational", subsystem: "gateway", techStack: "Kafka / CDC" },
];

export default function SystemArchitecture() {
  const [activeService, setActiveService] = useState<ServiceBlock | null>(services[0]);

  return (
    <div id="system-architecture-widget" className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-[#0A192F] border border-[#B4B8B9]/20 p-6 text-white relative">
      <div className="absolute top-0 left-0 bg-[#D48E5C] text-black text-[10px] font-bold px-3 py-0.5 tracking-widest uppercase">
        Infrastructure Twin v1.0
      </div>

      {/* Left panel: architecture descriptions */}
      <div className="space-y-4 pr-0 lg:pr-6 border-r-0 lg:border-r border-[#B4B8B9]/20 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-black tracking-tight text-white uppercase flex items-center gap-2 mt-4">
            <Network className="w-5 h-5 text-[#D48E5C]" />
            Rust Architecture
          </h2>
          <p className="text-xs text-[#B4B8B9]/85 mt-1 leading-relaxed">
            Institutional planning platform blueprint. The system runs as a high-concurrency microservice cluster in Rust, using <code className="text-gray-300 font-mono bg-[#1A1A1A] border border-[#B4B8B9]/20 px-1 py-0.5">Tokio</code> as the async runtime, <code className="text-gray-300 font-mono bg-[#1A1A1A] border border-[#B4B8B9]/20 px-1 py-0.5">Axum</code> for HTTP routing, and <code className="text-gray-300 font-mono bg-[#1A1A1A] border border-[#B4B8B9]/20 px-1 py-0.5">Kafka</code> for state synchronisation.
          </p>

          {/* Infrastructure components */}
          <div className="grid grid-cols-3 gap-2 mt-6">
            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-2 text-center text-xs">
              <Cpu className="w-4 h-4 mx-auto text-[#D48E5C] mb-1" />
              <span className="font-bold block text-white uppercase text-[10px] tracking-wider">Async Cores</span>
              <span className="text-[10px] text-[#B4B8B9]/50 font-mono">Tokio v1.35</span>
            </div>

            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-2 text-center text-xs">
              <Database className="w-4 h-4 mx-auto text-[#D48E5C] mb-1" />
              <span className="font-bold block text-white uppercase text-[10px] tracking-wider">Relational DB</span>
              <span className="text-[10px] text-[#B4B8B9]/50 font-mono">Postgres / SQLx</span>
            </div>

            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-2 text-center text-xs">
              <GitMerge className="w-4 h-4 mx-auto text-[#D48E5C] mb-1" />
              <span className="font-bold block text-white uppercase text-[10px] tracking-wider">State Bus</span>
              <span className="text-[10px] text-[#B4B8B9]/50 font-mono">Apache Kafka</span>
            </div>
          </div>
        </div>

        {/* Selected service details card */}
        <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-xs leading-relaxed space-y-2">
          {activeService ? (
            <>
              <div className="flex items-center justify-between border-b border-[#B4B8B9]/10 pb-1">
                <span className="font-black text-white text-sm uppercase font-mono tracking-wide">
                  {activeService.name}
                </span>
                <span className="text-[9px] bg-[#0A192F] text-[#D48E5C] border border-[#B4B8B9]/15 px-1.5 py-0.5 font-mono font-black uppercase">
                  {activeService.techStack}
                </span>
              </div>
              <p className="text-[#B4B8B9]/80 text-[11px] leading-relaxed">{activeService.description}</p>
              <div className="flex justify-between items-center text-[10px] text-[#B4B8B9]/50 pt-1.5 border-t border-[#B4B8B9]/10 mt-1">
                <span>Subsystem:</span>
                <span className="uppercase font-black text-[#D48E5C]">{activeService.subsystem}</span>
              </div>
            </>
          ) : (
            <span className="text-[#B4B8B9]/50 italic text-center block py-2">Select a service block to inspect the microservice configuration.</span>
          )}
        </div>
      </div>

      {/* Grid view of 14 core services */}
      <div className="lg:col-span-2 space-y-4">
        <h3 className="text-base font-black text-white uppercase tracking-tight border-b border-[#B4B8B9]/20 pb-2">
          Microservice Mesh Status
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-4">
          {services.map((svc) => {
            const isSelected = activeService?.name === svc.name;
            return (
              <div
                key={svc.name}
                onClick={() => setActiveService(svc)}
                className={`p-2.5 border text-xs cursor-pointer transition flex items-start gap-2 h-[68px] ${
                  isSelected
                    ? "bg-[#D48E5C]/15 border-[#D48E5C] text-white"
                    : "bg-[#1A1A1A] border-[#B4B8B9]/20 text-[#B4B8B9]/80 hover:border-[#B4B8B9]/45"
                }`}
              >
                <Server className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? "text-[#D48E5C]" : "text-[#B4B8B9]/40"}`} />
                <div className="truncate flex-1">
                  <div className={`font-mono font-bold tracking-tight truncate ${isSelected ? "text-white" : "text-[#B4B8B9]"}`}>
                    {svc.name}
                  </div>
                  <div className="text-[10px] text-[#B4B8B9]/60 truncate mt-0.5">
                    {svc.techStack}
                  </div>
                  <div className="flex items-center gap-1 text-[9px] text-emerald-400 font-semibold uppercase tracking-wider mt-1.5">
                    <CheckCircle className="w-3 h-3 fill-emerald-950 shrink-0" />
                    <span>Active</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
