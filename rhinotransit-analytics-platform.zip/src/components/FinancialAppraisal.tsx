/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { TransitRoute } from "../types";
import { CreditCard, ArrowUpRight, TrendingUp, Info } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

interface FinancialAppraisalProps {
  routes: TransitRoute[];
}

export default function FinancialAppraisal({ routes }: FinancialAppraisalProps) {
  const [selectedRegion, setSelectedRegion] = useState<string>("all");

  // Regional subsidy stats
  const regionalSubsidyData = [
    { authority: "Leeds", opex: 185000, revenue: 142000, subsidy: 43000 },
    { authority: "Bradford", opex: 122000, revenue: 84000, subsidy: 38000 },
    { authority: "Wakefield", opex: 65000, revenue: 39000, subsidy: 26000 },
    { authority: "Calderdale", opex: 48000, revenue: 26000, subsidy: 22000 },
    { authority: "Kirklees", opex: 72000, revenue: 45000, subsidy: 27000 },
  ];

  // Route cost-benefit calculations
  const routeEconomics = routes.map((r) => {
    // Estimating daily performance
    const activeDailyMiles = (1440 / (r.peakFrequencyMinutes || 15)) * r.distanceMiles * 1.3;
    const dailyOpex = activeDailyMiles * r.operatingCostPerMile;
    // Estimated ridership
    const dailyPassengers = r.mode === "rail" ? 3400 : 1200;
    const dailyRevenue = dailyPassengers * r.fareRevenuePerPassenger;
    const netDailySubsidy = dailyOpex - dailyRevenue;
    const subsidyPerPass = dailyPassengers > 0 ? netDailySubsidy / dailyPassengers : 0;

    return {
      id: r.id,
      name: r.name,
      mode: r.mode,
      opex: Math.round(dailyOpex),
      revenue: Math.round(dailyRevenue),
      netDailySubsidy: Math.round(netDailySubsidy),
      subsidyPerPassenger: Number(subsidyPerPass.toFixed(2)),
    };
  });

  return (
    <div id="financial-appraisal-widget" className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-[#0A192F] border border-[#B4B8B9]/20 p-6 text-white relative">
      <div className="absolute top-0 left-0 bg-[#D48E5C] text-black text-[10px] font-bold px-3 py-0.5 tracking-widest uppercase">
        Finance-Engine v1.8
      </div>

      {/* Grid Column 1: Financial Balance Sheet Summary */}
      <div className="space-y-4 pr-0 lg:pr-6 border-r-0 lg:border-r border-[#B4B8B9]/20 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-black tracking-tight text-white uppercase flex items-center gap-2 mt-4">
            <CreditCard className="w-5 h-5 text-[#D48E5C]" />
            Financial Audit
          </h2>
          <p className="text-xs text-[#B4B8B9]/85 mt-1 leading-relaxed">
            Institutional ledger of operating expenditure, transport asset capital appraisal, and Combined Authority franchise subsidisation metrics.
          </p>

          {/* Strategic metrics */}
          <div className="space-y-2 mt-6">
            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 flex justify-between items-center">
              <div>
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Total Net Opex</span>
                <div className="text-xl font-black text-white mt-0.5">£492,000 / day</div>
              </div>
              <ArrowUpRight className="w-5 h-5 text-[#B4B8B9]/40" />
            </div>

            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 flex justify-between items-center">
              <div>
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Farebox Yield</span>
                <div className="text-xl font-black text-white mt-0.5">£336,000 / day</div>
              </div>
              <TrendingUp className="w-5 h-5 text-emerald-400" />
            </div>

            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 flex justify-between items-center">
              <div>
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">WYCA Net Subsidy</span>
                <div className="text-xl font-black text-[#D48E5C] mt-0.5">£156,000 / day</div>
              </div>
              <span className="text-[9px] bg-[#0A192F] border border-[#B4B8B9]/20 text-[#D48E5C] font-bold px-1.5 py-0.5 uppercase tracking-wider">
                Franchised
              </span>
            </div>
          </div>
        </div>

        {/* Informative economic caption */}
        <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-xs text-[#B4B8B9] leading-relaxed flex items-start gap-2">
          <Info className="w-4 h-4 text-[#D48E5C] shrink-0 mt-0.5" />
          <span>
            West Yorkshire bus operations are undergoing a transition to a franchised network. Under this model, WYCA retains fare revenues while contracting out specific routes.
          </span>
        </div>
      </div>

      {/* Grid Column 2: Regional Subsidies Chart & Route Profitability */}
      <div className="lg:col-span-2 space-y-5">
        <div>
          <h3 className="text-base font-black text-white uppercase tracking-tight border-b border-[#B4B8B9]/20 pb-2">
            Franchise Balances by Municipal Authority
          </h3>
          <div className="h-[210px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regionalSubsidyData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#22252A" />
                <XAxis dataKey="authority" stroke="#9CA3AF" fontSize={10} tickLine={false} />
                <YAxis stroke="#9CA3AF" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1A1A1A", borderColor: "#B4B8B9" }}
                  labelStyle={{ fontWeight: "bold", color: "#D48E5C" }}
                />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="opex" name="Operating Cost (£)" fill="#1A1A1A" stroke="#B4B8B9" strokeWidth={0.5} />
                <Bar dataKey="revenue" name="Fare Revenue (£)" fill="#D48E5C" />
                <Bar dataKey="subsidy" name="Franchise Subsidy (£)" fill="#E2DFDA" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Route profit rankings */}
        <div className="space-y-2 border-t border-[#B4B8B9]/20 pt-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
            Route-by-Route Operating Costs & Subsidy Appraisal
          </h4>
          <div className="max-h-[140px] overflow-y-auto divide-y divide-[#B4B8B9]/10 pr-2">
            {routeEconomics.map((re) => {
              const isHeavilySubsidised = re.subsidyPerPassenger > 2.0;
              return (
                <div key={re.id} className="py-2 flex justify-between items-center text-xs">
                  <div>
                    <div className="font-bold text-white uppercase tracking-wide">{re.name}</div>
                    <div className="text-[10px] text-[#B4B8B9]/60 font-mono">
                      Opex: £{re.opex.toLocaleString()}/d | Farebox: £{re.revenue.toLocaleString()}/d
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-mono font-bold ${isHeavilySubsidised ? "text-[#D48E5C]" : "text-emerald-400"}`}>
                      {re.netDailySubsidy > 0 ? `+£${re.netDailySubsidy.toLocaleString()}/d Subsidy` : `£${Math.abs(re.netDailySubsidy).toLocaleString()}/d Surplus`}
                    </div>
                    <div className="text-[10px] text-[#B4B8B9]/60 font-mono">
                      £{re.subsidyPerPassenger.toFixed(2)} per trip
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
