/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { TimetableTrip, SchedulingConflict } from "../types";
import { Clock, ShieldAlert, Sparkles, CheckCircle, RotateCcw, AlertCircle, Eye } from "lucide-react";

interface TimetableOptimiserProps {
  trips: TimetableTrip[];
  conflicts: SchedulingConflict[];
  onOptimise: () => void;
  onReset: () => void;
  loading: boolean;
}

export default function TimetableOptimiser({
  trips,
  conflicts,
  onOptimise,
  onReset,
  loading,
}: TimetableOptimiserProps) {
  const [selectedRouteFilter, setSelectedRouteFilter] = useState<string>("all");
  const [selectedTrip, setSelectedTrip] = useState<TimetableTrip | null>(null);

  // Extract unique route IDs
  const routeIds = Array.from(new Set(trips.map((t) => t.routeId)));

  const filteredTrips = selectedRouteFilter === "all"
    ? trips
    : trips.filter((t) => t.routeId === selectedRouteFilter);

  return (
    <div id="timetable-optimiser-widget" className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-[#0A192F] border border-[#B4B8B9]/20 p-6 text-white relative">
      <div className="absolute top-0 left-0 bg-[#D48E5C] text-black text-[10px] font-bold px-3 py-0.5 tracking-widest uppercase">
        Scheduling-Engine v2.1
      </div>

      {/* Grid Column 1: Conflict Warnings & Resolvers */}
      <div className="lg:col-span-1 space-y-4 pr-0 lg:pr-6 border-r-0 lg:border-r border-[#B4B8B9]/20 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-black tracking-tight text-white uppercase flex items-center gap-2 mt-4">
            <Clock className="w-5 h-5 text-[#D48E5C]" />
            Timetable Auditor
          </h2>
          <p className="text-xs text-[#B4B8B9]/80 mt-1 leading-relaxed">
            Real-time conflict auditor for headway-bunching, platform overlap, and regulatory driver-break duty cycles.
          </p>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-2 mt-4">
            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
              <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Active Trips</div>
              <div className="text-2xl font-black text-white mt-0.5">{trips.length}</div>
            </div>
            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
              <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Conflicts</div>
              <div className={`text-2xl font-black mt-0.5 ${conflicts.length > 0 ? "text-[#D48E5C]" : "text-emerald-400"}`}>
                {conflicts.length}
              </div>
            </div>
          </div>

          {/* Solver Actions */}
          <div className="mt-5 space-y-2">
            <button
              disabled={loading}
              onClick={onOptimise}
              className="w-full bg-[#D48E5C] hover:bg-[#c37d4d] text-black font-black text-xs uppercase py-3 transition duration-150 flex items-center justify-center gap-2 tracking-widest"
            >
              <Sparkles className="w-4 h-4 fill-black" />
              {loading ? "Re-spacing Timetable..." : "Run AI Optimiser"}
            </button>
            <button
              disabled={loading}
              onClick={onReset}
              className="w-full bg-[#1A1A1A] border border-[#B4B8B9]/20 hover:bg-[#1C1F22] text-[#E2DFDA] text-[10px] font-bold uppercase py-2.5 transition duration-150 flex items-center justify-center gap-1.5 tracking-wider"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Schedules
            </button>
          </div>

          {/* List of conflicts */}
          <div className="mt-6 space-y-2 max-h-[220px] overflow-y-auto">
            <span className="text-xs font-semibold tracking-wider text-gray-400 uppercase">Conflict Alerts</span>
            {conflicts.length === 0 ? (
              <div className="bg-emerald-950/20 border border-emerald-800 text-emerald-400 p-3 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>Zero conflicts detected. Timetable is fully conflict-free & compliant.</span>
              </div>
            ) : (
              conflicts.map((c) => (
                <div
                  key={c.id}
                  className={`p-3 text-xs space-y-1.5 border leading-relaxed ${
                    c.severity === "critical"
                      ? "bg-red-950/20 border-red-900/60 text-red-200"
                      : "bg-[#291B13] border-[#7F3B1A]/40 text-[#EF9A6A]"
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold uppercase tracking-tight">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{c.type.replace("_", " ")}</span>
                  </div>
                  <p className="text-gray-300 text-[11px]">{c.message}</p>
                  <div className="text-[10px] italic border-t border-dashed border-[#B4B8B9]/20 pt-1.5 opacity-80">
                    <span className="font-bold uppercase text-white">Suggested Fix:</span> {c.suggestedFix}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Grid Column 2: Timetable Roster view */}
      <div className="lg:col-span-2 space-y-4 flex flex-col justify-between">
        <div>
          {/* Header & Roster Filters */}
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-[#B4B8B9]/20 pb-3">
            <div>
              <h3 className="text-base font-black text-white uppercase tracking-tight">
                Trips & Driver Allocation
              </h3>
              <p className="text-[10px] text-[#B4B8B9]/60 uppercase tracking-wider font-mono">
                Hourly dispatch matrices and driver assignments.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-widest">Route:</span>
              <select
                value={selectedRouteFilter}
                onChange={(e) => setSelectedRouteFilter(e.target.value)}
                className="bg-[#1A1A1A] text-xs border border-[#B4B8B9]/20 p-1.5 text-gray-300 focus:outline-none focus:border-[#D48E5C] max-w-[140px] font-mono"
              >
                <option value="all">All Routes</option>
                {routeIds.map((rId) => (
                  <option key={rId} value={rId}>
                    {rId.toUpperCase().replace("_", " ")}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Timetable schedule grid */}
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-xs text-left text-gray-300">
              <thead className="bg-[#1A1A1A] text-[10px] text-[#B4B8B9] uppercase font-bold tracking-widest border-b border-[#B4B8B9]/20">
                <tr>
                  <th className="p-3">Route</th>
                  <th className="p-3">Trip ID</th>
                  <th className="p-3">Operational Block</th>
                  <th className="p-3">Vehicle</th>
                  <th className="p-3">Driver</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#B4B8B9]/10">
                {filteredTrips.slice(0, 10).map((trip) => {
                  const hasConflict = conflicts.some((c) => c.entityId === trip.routeId || c.entityId === trip.driverId);
                  return (
                    <tr key={trip.id} className="hover:bg-[#1A1A1A]/50 transition-colors duration-100">
                      <td className="p-3 font-black text-white whitespace-nowrap uppercase tracking-wider">
                        {trip.routeName}
                      </td>
                      <td className="p-3 font-mono text-[#B4B8B9]">{trip.id}</td>
                      <td className="p-3 font-mono text-white whitespace-nowrap">
                        {trip.startTime} &rarr; {trip.endTime}
                      </td>
                      <td className="p-3 font-mono text-[#B4B8B9]">{trip.vehicleId}</td>
                      <td className="p-3 text-gray-300 font-mono">{trip.driverId}</td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => setSelectedTrip(trip)}
                          className="bg-[#1A1A1A] border border-[#B4B8B9]/20 text-[#D48E5C] hover:bg-[#D48E5C] hover:text-black p-1 px-2 text-[9px] uppercase font-bold tracking-widest inline-flex items-center gap-1 transition-all"
                        >
                          <Eye className="w-3 h-3" />
                          Inspect
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filteredTrips.length > 10 && (
              <div className="text-[10px] text-gray-500 text-right mt-2 italic">
                Showing first 10 entries of {filteredTrips.length} schedules...
              </div>
            )}
          </div>
        </div>

        {/* Selected Trip inspection modal panel */}
        {selectedTrip && (
          <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-4 text-xs relative mt-4">
            <button
              onClick={() => setSelectedTrip(null)}
              className="absolute top-2 right-2 text-[#B4B8B9] hover:text-white text-base font-bold"
            >
              &times;
            </button>
            <h4 className="font-black text-[#D48E5C] uppercase tracking-tight border-b border-[#B4B8B9]/20 pb-1.5 mb-2">
              Trip Segment Dispatch Detail: {selectedTrip.id}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Service</div>
                <div className="text-white mt-0.5 font-bold uppercase tracking-wide">{selectedTrip.routeName} ({selectedTrip.mode.toUpperCase()})</div>
                <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider mt-2">Assigned Driver</div>
                <div className="text-white mt-0.5 font-mono">{selectedTrip.driverId}</div>
              </div>

              <div>
                <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Allocated Vehicle</div>
                <div className="text-white mt-0.5 font-mono">{selectedTrip.vehicleId}</div>
                <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider mt-2">Active Shifts</div>
                <div className="text-white mt-0.5 font-mono">{selectedTrip.startTime} &rarr; {selectedTrip.endTime}</div>
              </div>

              <div className="space-y-1">
                <div className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Segment Passings</div>
                <div className="max-h-[90px] overflow-y-auto space-y-1 pr-1">
                  {selectedTrip.stopPassings.map((sp, idx) => (
                    <div key={idx} className="flex justify-between text-[11px] border-b border-[#B4B8B9]/10 pb-0.5">
                      <span className="text-[#B4B8B9]/80 truncate max-w-[120px]">{sp.stopName}</span>
                      <span className="text-[#D48E5C] font-mono font-black">{sp.arrivalTime}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
