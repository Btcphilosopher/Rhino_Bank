/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Scenario, SimulationResult } from "../types";
import { Play, Sparkles, AlertCircle, FileText, BarChart2, ShieldCheck, Cpu } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import ReactMarkdown from "react-markdown";

interface SimulationCentreProps {
  onRunSimulation: (scenario: Scenario) => Promise<SimulationResult | null>;
  onGenerateReport: (scenario: Scenario, simResult: SimulationResult) => Promise<string | null>;
}

const prebuiltScenarios: Scenario[] = [
  {
    id: "scen_housing_leeds",
    name: "Leeds West Housing Corridor Development",
    description: "Projections of a 12,000-unit residential boom along Kirkstall and Bramley corridors, significantly spiking commuter volume.",
    type: "housing_development",
    impactArea: "Leeds",
    parameters: { populationGrowthPct: 15 },
  },
  {
    id: "scen_calder_electrify",
    name: "Calder Valley Rail Electrification",
    description: "Electrifying heavy rail lines between Leeds, Bradford Interchange, Halifax, and Hebden Bridge to speed up transit times and lower carbon footprints.",
    type: "infra_upgrade",
    impactArea: "Calderdale",
    parameters: { populationGrowthPct: 5, newRouteFrequencyMinutes: 20 },
  },
  {
    id: "scen_peak_frequency",
    name: "A660 Corridor Bus Frequency Doubling",
    description: "Squeezing headways on the busy Headingley-Otley corridor from 12 minutes down to 6 minutes during peak commuter spikes.",
    type: "frequency_change",
    impactArea: "Leeds",
    parameters: { newRouteFrequencyMinutes: 6 },
  },
  {
    id: "scen_electric_replace",
    name: "West Yorkshire Fleet Decarbonisation",
    description: "Capital deployment to replace all remaining diesel and hybrid single-decker vehicles with 100% Zero-Emission Electric buses across all 5 depots.",
    type: "fleet_expansion",
    impactArea: "All",
    parameters: { electricFleetPct: 100, addedVehiclesCount: 15 },
  },
];

export default function SimulationCentre({ onRunSimulation, onGenerateReport }: SimulationCentreProps) {
  const [selectedScenario, setSelectedScenario] = useState<Scenario>(prebuiltScenarios[0]);
  const [simulating, setSimulating] = useState(false);
  const [simSteps, setSimSteps] = useState<string[]>([]);
  const [activeStep, setActiveStep] = useState<number>(-1);
  const [simResult, setSimResult] = useState<SimulationResult | null>(null);

  const [generatingReport, setGeneratingReport] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);

  const steps = [
    "Spinning up network-engine graph topology...",
    "Re-routing passenger OD-matrices via Dijkstra SPF...",
    "Running 10,000 Monte Carlo boarding iterations...",
    "Auditing timetables for peak vehicle schedule clashes...",
    "Balancing opex operating balance sheets...",
    "Simulation cycle complete. Compiling network state deltas.",
  ];

  const handleRunSim = async () => {
    setSimulating(true);
    setSimResult(null);
    setAiReport(null);
    setSimSteps([]);
    setActiveStep(-1);

    // Animate discrete-event steps
    for (let i = 0; i < steps.length; i++) {
      setActiveStep(i);
      setSimSteps((prev) => [...prev, steps[i]]);
      await new Promise((res) => setTimeout(res, 600));
    }

    try {
      const result = await onRunSimulation(selectedScenario);
      if (result) {
        setSimResult(result);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSimulating(false);
    }
  };

  const handleGenReport = async () => {
    if (!simResult) return;
    setGeneratingReport(true);
    try {
      const report = await onGenerateReport(selectedScenario, simResult);
      if (report) {
        setAiReport(report);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingReport(false);
    }
  };

  return (
    <div id="simulation-centre-widget" className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-[#0A192F] border border-[#B4B8B9]/20 p-6 text-white relative">
      {/* Absolute tag */}
      <div className="absolute top-0 left-0 bg-[#D48E5C] text-black text-[10px] font-bold px-3 py-0.5 tracking-widest uppercase">
        Simulation-Engine v3.1
      </div>

      {/* Column 1: Scenario Builder */}
      <div className="lg:col-span-1 space-y-4 pr-0 lg:pr-6 border-r-0 lg:border-r border-[#B4B8B9]/20">
        <h2 className="text-xl font-black tracking-tight text-white uppercase flex items-center gap-2 mt-4">
          <Cpu className="w-5 h-5 text-[#D48E5C]" />
          Scenario Centre
        </h2>
        <p className="text-xs text-[#B4B8B9]/85 leading-relaxed">
          Evaluate public transit capital investments, infrastructure interventions, demographic housing additions, and line electrifications.
        </p>

        {/* List of scenarios */}
        <div className="space-y-2 mt-4">
          <label className="text-[10px] font-bold tracking-widest text-[#B4B8B9]/60 uppercase">Strategic Option</label>
          {prebuiltScenarios.map((scen) => (
            <div
              key={scen.id}
              onClick={() => {
                if (!simulating) {
                  setSelectedScenario(scen);
                  setSimResult(null);
                  setAiReport(null);
                }
              }}
              className={`p-3 border text-xs cursor-pointer transition leading-relaxed ${
                selectedScenario.id === scen.id
                  ? "bg-[#D48E5C]/15 border-[#D48E5C] text-white"
                  : "bg-[#1A1A1A] border-[#B4B8B9]/20 text-[#B4B8B9] hover:border-[#B4B8B9]/45"
              }`}
            >
              <div className="font-black uppercase tracking-wider text-white">{scen.name}</div>
              <p className="text-[10.5px] text-[#B4B8B9]/80 mt-1">{scen.description}</p>
            </div>
          ))}
        </div>

        {/* Trigger */}
        <button
          disabled={simulating}
          onClick={handleRunSim}
          className="w-full bg-[#E2DFDA] hover:bg-[#F2EFEA] text-black text-xs font-black uppercase py-3 transition duration-150 flex items-center justify-center gap-2 disabled:opacity-40 tracking-widest"
        >
          <Play className="w-4 h-4 fill-black" />
          {simulating ? "Simulating Transport Network..." : "Run Discrete-Event Sim"}
        </button>

        {/* Live execution ticks */}
        {simulating && (
          <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 rounded-sm font-mono text-[10.5px] text-emerald-400 space-y-1">
            <div className="text-[9px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider mb-1">Discrete Simulation Log</div>
            {simSteps.map((s, idx) => (
              <div key={idx} className="flex items-center gap-1.5 animate-fadeIn">
                <span>&rsaquo;</span>
                <span>{s}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Columns 2-3: Results Viewer */}
      <div className="lg:col-span-2 space-y-5">
        {!simulating && !simResult && (
          <div className="h-full min-h-[300px] border border-dashed border-[#B4B8B9]/20 flex flex-col justify-center items-center text-center p-6 text-[#B4B8B9]/60 space-y-2">
            <Cpu className="w-10 h-10 text-[#B4B8B9]/30 animate-pulse" />
            <span className="font-black uppercase tracking-widest text-[#B4B8B9]">Sandbox Idle</span>
            <p className="text-xs text-[#B4B8B9]/50 max-w-sm">
              Select an urban transport development scenario from the panel on the left and run the discrete simulation to compare performance indices.
            </p>
          </div>
        )}

        {simResult && (
          <div className="space-y-6">
            {/* Header comparison summary */}
            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-4 relative">
              <h3 className="text-sm font-black text-white uppercase tracking-wider mb-2 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Scenario Analytics Delta: {selectedScenario.name}
              </h3>
              <p className="text-xs text-[#B4B8B9]/80 leading-relaxed italic">
                {simResult.executiveSummary}
              </p>

              {/* Board report summoner */}
              <div className="mt-4 pt-4 border-t border-[#B4B8B9]/10 flex justify-between items-center">
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Analyze with Gemini strategic forecasting model:</span>
                <button
                  disabled={generatingReport}
                  onClick={handleGenReport}
                  className="bg-[#D48E5C] hover:bg-[#c37d4d] text-black text-[9px] font-black uppercase px-3 py-1.5 flex items-center gap-1 tracking-widest"
                >
                  <Sparkles className="w-3 h-3 fill-black" />
                  {generatingReport ? "Drafting Board Paper..." : "Draft Executive Board Paper"}
                </button>
              </div>
            </div>

            {/* Matrix comparison cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Daily Ridership</span>
                <div className="font-mono mt-1 flex flex-col">
                  <span className="text-xs line-through text-[#B4B8B9]/40">{simResult.before.totalPassengers.toLocaleString()}</span>
                  <span className="text-base font-black text-white">&rarr; {simResult.after.totalPassengers.toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">On-Time Performance</span>
                <div className="font-mono mt-1 flex flex-col">
                  <span className="text-xs line-through text-[#B4B8B9]/40">{simResult.before.avgOnTimePerformance}%</span>
                  <span className={`text-base font-black ${simResult.after.avgOnTimePerformance >= simResult.before.avgOnTimePerformance ? "text-emerald-400" : "text-[#D48E5C]"}`}>
                    &rarr; {simResult.after.avgOnTimePerformance}%
                  </span>
                </div>
              </div>

              <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Avg Cust. Wait</span>
                <div className="font-mono mt-1 flex flex-col">
                  <span className="text-xs line-through text-[#B4B8B9]/40">{simResult.before.avgWaitTimeMinutes}m</span>
                  <span className={`text-base font-black ${simResult.after.avgWaitTimeMinutes <= simResult.before.avgWaitTimeMinutes ? "text-emerald-400" : "text-[#D48E5C]"}`}>
                    &rarr; {simResult.after.avgWaitTimeMinutes}m
                  </span>
                </div>
              </div>

              <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                <span className="text-[10px] text-[#B4B8B9]/60 uppercase font-bold tracking-wider">Subsidy / Journey</span>
                <div className="font-mono mt-1 flex flex-col">
                  <span className="text-xs line-through text-[#B4B8B9]/40">£{simResult.before.subsidyPerPassenger}</span>
                  <span className={`text-base font-black ${simResult.after.subsidyPerPassenger <= simResult.before.subsidyPerPassenger ? "text-emerald-400" : "text-[#D48E5C]"}`}>
                    &rarr; £{simResult.after.subsidyPerPassenger}
                  </span>
                </div>
              </div>
            </div>

            {/* Chart overlay */}
            <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-4">
              <h4 className="text-xs font-bold text-[#B4B8B9] uppercase tracking-wider mb-3">
                Peak Demand Shifts: Before vs After Upgrade (Passengers/hour)
              </h4>
              <div className="h-[180px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={simResult.charts.hourlyDemand} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#22252A" />
                    <XAxis dataKey="hour" stroke="#9CA3AF" fontSize={10} tickFormatter={(h) => `${h}:00`} />
                    <YAxis stroke="#9CA3AF" fontSize={10} />
                    <Tooltip contentStyle={{ backgroundColor: "#1A1A1A", borderColor: "#B4B8B9" }} />
                    <Legend wrapperStyle={{ fontSize: 10 }} />
                    <Area type="monotone" dataKey="before" name="Baseline Load" stroke="#6B7280" fill="#374151" fillOpacity={0.2} strokeWidth={1} />
                    <Area type="monotone" dataKey="after" name="Post-Intervention Load" stroke="#D48E5C" fill="#D48E5C" fillOpacity={0.15} strokeWidth={1.5} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Strategic board paper document modal or expansion */}
            {aiReport && (
              <div className="bg-[#E2DFDA] border border-[#B4B8B9]/30 p-6 text-black rounded-none shadow-2xl leading-relaxed space-y-4 max-h-[500px] overflow-y-auto relative animate-fadeIn">
                {/* Print watermark */}
                <div className="absolute top-4 right-4 bg-transparent border border-black/30 text-black/40 text-[9px] font-extrabold uppercase px-2 py-0.5 tracking-widest">
                  Board Draft
                </div>

                <div className="flex items-center gap-2 text-[10px] text-gray-700 font-bold uppercase tracking-widest border-b border-black/20 pb-2">
                  <FileText className="w-4 h-4 text-black shrink-0" />
                  <span>WYCA Institutional Policy Paper draft</span>
                </div>

                <div className="prose prose-sm prose-stone text-xs md:text-sm leading-relaxed max-w-none font-medium">
                  <ReactMarkdown>{aiReport}</ReactMarkdown>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
