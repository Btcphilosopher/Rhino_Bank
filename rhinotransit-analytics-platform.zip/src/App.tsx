/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import {
  TransitStop,
  TransitRoute,
  Depot,
  FleetVehicle,
  DriverDuty,
  TimetableTrip,
  SchedulingConflict,
  Scenario,
  SimulationResult,
} from "./types";
import MapCartography from "./components/MapCartography";
import TimetableOptimiser from "./components/TimetableOptimiser";
import DemandCrowding from "./components/DemandCrowding";
import FinancialAppraisal from "./components/FinancialAppraisal";
import SimulationCentre from "./components/SimulationCentre";
import SystemArchitecture from "./components/SystemArchitecture";
import {
  Compass,
  Clock,
  Users,
  CreditCard,
  Cpu,
  Network,
  Activity,
  ShieldCheck,
  Server,
  TrendingUp,
  MapPin,
  Calendar,
  Layers,
  HelpCircle,
  Briefcase,
  Wrench,
  Bus,
} from "lucide-react";

export default function App() {
  // State registries
  const [stops, setStops] = useState<TransitStop[]>([]);
  const [routes, setRoutes] = useState<TransitRoute[]>([]);
  const [depots, setDepots] = useState<Depot[]>([]);
  const [vehicles, setVehicles] = useState<FleetVehicle[]>([]);
  const [drivers, setDrivers] = useState<DriverDuty[]>([]);

  // Schedule states
  const [trips, setTrips] = useState<TimetableTrip[]>([]);
  const [conflicts, setConflicts] = useState<SchedulingConflict[]>([]);

  // Selection states
  const [selectedStop, setSelectedStop] = useState<TransitStop | null>(null);
  const [crowdingOverlay, setCrowdingOverlay] = useState<boolean>(false);

  // App layouts
  const [activeTab, setActiveTab] = useState<"overview" | "network" | "timetable" | "simulation" | "finance" | "architecture">("overview");

  // Loading states
  const [loadingData, setLoadingData] = useState(true);
  const [loadingSchedule, setLoadingSchedule] = useState(false);

  // Load baseline network and operational data
  useEffect(() => {
    async function fetchNetworkData() {
      try {
        const response = await fetch("/api/network-data");
        const data = await response.json();
        if (response.ok) {
          setStops(data.stops || []);
          setRoutes(data.routes || []);
          setDepots(data.depots || []);
          setVehicles(data.vehicles || []);
          setDrivers(data.drivers || []);

          // Set default selected stop to Leeds City Station
          const lds = data.stops.find((s: any) => s.id === "lds_station");
          if (lds) setSelectedStop(lds);
        }
      } catch (err) {
        console.error("Failed to load network data:", err);
      } finally {
        setLoadingData(false);
      }
    }

    async function fetchTimetable() {
      try {
        const response = await fetch("/api/timetable");
        const data = await response.json();
        if (response.ok) {
          setTrips(data.trips || []);
        }

        const conflictRes = await fetch("/api/timetable/conflicts");
        const conflictData = await conflictRes.json();
        if (conflictRes.ok) {
          setConflicts(conflictData.conflicts || []);
        }
      } catch (err) {
        console.error("Failed to load timetable data:", err);
      }
    }

    fetchNetworkData();
    fetchTimetable();
  }, []);

  // Handler: Optimize Active Timetable
  const handleOptimiseTimetable = async () => {
    setLoadingSchedule(true);
    try {
      const response = await fetch("/api/timetable/optimise", { method: "POST" });
      const data = await response.json();
      if (response.ok && data.success) {
        setTrips(data.trips);
        setConflicts(data.conflicts);
      }
    } catch (err) {
      console.error("Optimization failed:", err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  // Handler: Reset Timetable
  const handleResetTimetable = async () => {
    setLoadingSchedule(true);
    try {
      const response = await fetch("/api/timetable/reset", { method: "POST" });
      const data = await response.json();
      if (response.ok && data.success) {
        setTrips(data.trips);
        setConflicts(data.conflicts);
      }
    } catch (err) {
      console.error("Reset failed:", err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  // Handler: Run scenario discrete-event simulation
  const handleRunSimulation = async (scenario: Scenario): Promise<SimulationResult | null> => {
    try {
      const response = await fetch("/api/simulation/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scenario }),
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return data.result;
      }
    } catch (err) {
      console.error("Simulation request failed:", err);
    }
    return null;
  };

  // Handler: Call server-side Gemini to compile Board Memorandum
  const handleGenerateAIReport = async (scenario: Scenario, simResult: SimulationResult): Promise<string | null> => {
    try {
      const response = await fetch("/api/simulation/ai-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scenario, simResult }),
      });
      const data = await response.json();
      if (response.ok && data.success) {
        return data.report;
      }
    } catch (err) {
      console.error("AI report compilation request failed:", err);
    }
    return null;
  };

  if (loadingData) {
    return (
      <div className="min-h-screen bg-[#1A1A1A] text-[#E2DFDA] flex flex-col justify-center items-center font-sans space-y-4">
        <div className="w-10 h-10 border-4 border-[#D48E5C] border-t-transparent rounded-full animate-spin" />
        <span className="text-xl font-black italic uppercase tracking-widest text-white">
          RhinoTransit
        </span>
        <span className="text-xs text-[#B4B8B9] font-mono tracking-widest uppercase">Initializing West Yorkshire Transit Twin...</span>
      </div>
    );
  }

  // Network KPIs computed from current state
  const totalBuses = vehicles.filter((v) => v.mode === "bus").length;
  const activeRailLines = routes.filter((r) => r.mode === "rail").length;
  const activeDriversCount = drivers.filter((d) => d.status === "on_duty").length;

  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#E2DFDA] font-sans antialiased flex flex-col justify-between">
      {/* 1. ARCHITECTURAL TOP PANEL */}
      <header className="border-b border-[#B4B8B9]/20 bg-gradient-to-r from-[#1A1A1A] to-[#0A192F] px-6 md:px-10 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#D48E5C] tracking-widest uppercase mb-1">
              <Activity className="w-4 h-4 text-[#D48E5C]" />
              Institutional Planning Platform
            </div>
            <h1 className="text-3xl md:text-4xl font-black tracking-tighter text-white uppercase italic leading-none">
              Rhino Transit <span className="text-[#D48E5C] not-italic">Analytics</span>
            </h1>
            <p className="text-[10px] text-[#B4B8B9]/60 font-mono tracking-widest uppercase mt-2">
              West Yorkshire Combined Authority (Metro) Digital Twin
            </p>
          </div>

          {/* Quick Hub Statistics */}
          <div className="flex flex-wrap gap-4 text-xs font-mono">
            <div className="border-l-2 border-[#B4B8B9]/20 pl-3">
              <span className="text-[#B4B8B9]/60 block uppercase font-bold text-[9px] tracking-wider">Transit Hubs</span>
              <span className="font-bold text-sm text-white">{stops.length} STATIONS</span>
            </div>
            <div className="border-l-2 border-[#B4B8B9]/20 pl-3">
              <span className="text-[#B4B8B9]/60 block uppercase font-bold text-[9px] tracking-wider">Total Routes</span>
              <span className="font-bold text-sm text-white">{routes.length} LINES</span>
            </div>
            <div className="border-l-2 border-[#B4B8B9]/20 pl-3">
              <span className="text-[#B4B8B9]/60 block uppercase font-bold text-[9px] tracking-wider">Fleet Roster</span>
              <span className="font-bold text-sm text-white">{vehicles.length} VEHICLES</span>
            </div>
            <div className="border-l-2 border-[#D48E5C]/30 pl-3">
              <span className="text-[#D48E5C] block uppercase font-bold text-[9px] tracking-wider">Audit Status</span>
              <span className="font-extrabold text-sm text-[#D48E5C] uppercase">
                {conflicts.length > 0 ? `${conflicts.length} ALERTS` : "COMPLIANT"}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* 2. TABBED NAVIGATION METRO BAR */}
      <nav className="bg-[#0A192F] text-white border-b border-[#B4B8B9]/20 px-6 md:px-10 overflow-x-auto">
        <div className="max-w-7xl mx-auto flex gap-1 font-bold text-[10px] tracking-widest uppercase">
          {(
            [
              { id: "overview", label: "01 Executive Overview", icon: Compass },
              { id: "network", label: "02 Network Planning", icon: Compass },
              { id: "timetable", label: "03 Timetable Engine", icon: Clock },
              { id: "simulation", label: "04 Simulation Lab", icon: Cpu },
              { id: "finance", label: "05 Finance & Subsidy", icon: CreditCard },
              { id: "architecture", label: "06 System Twin", icon: Network },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-5 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 border-b-2 transition-all duration-150 whitespace-nowrap ${
                  isActive
                    ? "border-[#D48E5C] text-[#D48E5C] bg-[#1A1A1A]/40"
                    : "border-transparent text-[#B4B8B9]/50 hover:text-white hover:bg-[#1A1A1A]/20"
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* 3. CORE EDITORIAL WORKSPACE */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 md:p-10 space-y-8">
        {/* TAB: OVERVIEW */}
        {activeTab === "overview" && (
          <div className="space-y-8 animate-fadeIn">
            {/* Quick Executive KPI Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-[#0A192F] border-b-4 border-[#D48E5C] p-6 border border-[#B4B8B9]/10 relative shadow-sm">
                <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-widest block opacity-70">Active Municipal OTP</span>
                <div className="text-4xl font-black text-white mt-1 uppercase tracking-tight font-sans">88.5%</div>
                <span className="text-[10px] text-[#B4B8B9] block mt-2 font-mono">ON-TIME PERFORMANCE</span>
              </div>

              <div className="bg-[#0A192F] border-b-4 border-[#D48E5C] p-6 border border-[#B4B8B9]/10 relative shadow-sm">
                <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-widest block opacity-70">Daily Passenger Ingress</span>
                <div className="text-4xl font-black text-white mt-1 uppercase tracking-tight font-sans">242,000</div>
                <span className="text-[10px] text-emerald-400 block mt-2 font-bold uppercase tracking-widest text-[9px] flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> +4.2% MoM Shift
                </span>
              </div>

              <div className="bg-[#0A192F] border-b-4 border-[#D48E5C] p-6 border border-[#B4B8B9]/10 relative shadow-sm">
                <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-widest block opacity-70">Combined Net Subsidy</span>
                <div className="text-4xl font-black text-[#D48E5C] mt-1 uppercase tracking-tight font-sans">£156,000 /d</div>
                <span className="text-[10px] text-[#B4B8B9] block mt-2 font-mono">COUNCIL OPERATING AID</span>
              </div>

              <div className="bg-[#0A192F] border-b-4 border-[#D48E5C] p-6 border border-[#B4B8B9]/10 relative shadow-sm">
                <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-widest block opacity-70">Active Driver Shift Index</span>
                <div className="text-4xl font-black text-white mt-1 uppercase tracking-tight font-sans">{activeDriversCount} / 45</div>
                <span className="text-[10px] text-emerald-400 block mt-2 font-bold uppercase tracking-widest text-[9px] flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Break Compliant
                </span>
              </div>
            </div>

            {/* Quick Map and Info split */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left description bento container */}
              <div className="bg-[#0A192F] border border-[#B4B8B9]/20 p-6 space-y-6 lg:col-span-1">
                <div>
                  <h3 className="text-xl font-black text-white uppercase tracking-tight border-b border-[#B4B8B9]/10 pb-2">
                    Platform Summary
                  </h3>
                  <p className="text-xs text-[#E2DFDA]/80 leading-relaxed mt-3">
                    RhinoTransit acts as West Yorkshire Combined Authority's official modeling system, evaluating scheduling viability and funding allocations.
                  </p>
                </div>

                {/* Authority Regions overview list */}
                <div className="space-y-3">
                  <span className="text-[10px] text-[#D48E5C] font-bold tracking-widest uppercase block">MUNICIPAL INGRESS SUMMARY</span>
                  <div className="space-y-2 text-xs">
                    {[
                      { region: "Leeds District", flow: "110,000 / day", cap: "High Demand Corridor" },
                      { region: "Bradford District", flow: "62,000 / day", cap: "Arterial Congestion" },
                      { region: "Wakefield District", flow: "29,000 / day", cap: "Commuter Rail Links" },
                      { region: "Kirklees (Huddersfield)", flow: "23,000 / day", cap: "Multi-Modal Interchanges" },
                      { region: "Calderdale (Halifax)", flow: "18,000 / day", cap: "Valleys Feeder Network" },
                    ].map((d) => (
                      <div key={d.region} className="flex justify-between items-center border-b border-[#B4B8B9]/10 pb-2">
                        <div>
                          <div className="font-bold text-white uppercase tracking-wide">{d.region}</div>
                          <div className="text-[10px] text-[#B4B8B9] opacity-70 mt-0.5">{d.cap}</div>
                        </div>
                        <span className="font-mono text-[#D48E5C] font-black text-sm">{d.flow}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Settings checklist */}
                <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-4 space-y-3">
                  <span className="text-[10px] text-[#D48E5C] font-bold uppercase tracking-widest block">Network Twin Overlays</span>
                  <div className="flex items-center gap-3 text-xs">
                    <input
                      id="toggle-overlay"
                      type="checkbox"
                      checked={crowdingOverlay}
                      onChange={(e) => setCrowdingOverlay(e.target.checked)}
                      className="accent-[#D48E5C] w-4 h-4 cursor-pointer"
                    />
                    <label htmlFor="toggle-overlay" className="font-bold text-[#E2DFDA] cursor-pointer tracking-wide uppercase text-[10px]">
                      Overlay Corridor Crowding Heatmaps
                    </label>
                  </div>
                </div>
              </div>

              {/* Right interactive cartography mini-display */}
              <div className="lg:col-span-2">
                <MapCartography
                  stops={stops}
                  routes={routes}
                  selectedStop={selectedStop}
                  onSelectStop={setSelectedStop}
                  crowdingOverlay={crowdingOverlay}
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB: NETWORK / GIS MAP */}
        {activeTab === "network" && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-[#0A192F] border border-[#B4B8B9]/20 p-6">
              <h3 className="text-xl font-black text-white uppercase mb-1">
                Multi-Modal Transport Cartography
              </h3>
              <p className="text-xs text-[#B4B8B9]/70 mb-6 uppercase tracking-wide">
                Interactive routing map visualising West Yorkshire combined transit nodes, stations, and pathfind routing.
              </p>
              <MapCartography
                stops={stops}
                routes={routes}
                selectedStop={selectedStop}
                onSelectStop={setSelectedStop}
                crowdingOverlay={crowdingOverlay}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <DemandCrowding stops={stops} routes={routes} />
              <div className="bg-[#0A192F] border border-[#B4B8B9]/20 p-6 flex flex-col justify-between">
                <div>
                  <h4 className="text-base font-black text-white uppercase border-b border-[#B4B8B9]/10 pb-2">
                    Spatial Connectivity Index
                  </h4>
                  <p className="text-xs text-[#E2DFDA]/80 leading-relaxed mt-3">
                    Calculates geographic catchment ranges based on walking distances to nearest hubs. High integration values are shown around Central Leeds Interchange and Bradford Forster, with localized feeder deficits mapped in the outer South Wakefield area.
                  </p>
                  <div className="grid grid-cols-3 gap-3 mt-6">
                    <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                      <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-wider">Leeds Center</span>
                      <span className="text-xl font-black text-emerald-400 block mt-1">9.2 / 10</span>
                    </div>
                    <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                      <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-wider">Bradford Hub</span>
                      <span className="text-xl font-black text-emerald-400 block mt-1">8.4 / 10</span>
                    </div>
                    <div className="bg-[#1A1A1A] border border-[#B4B8B9]/20 p-3 text-center">
                      <span className="text-[10px] text-[#B4B8B9] uppercase font-bold tracking-wider">Wakefield East</span>
                      <span className="text-xl font-black text-[#D48E5C] block mt-1">4.5 / 10</span>
                    </div>
                  </div>
                </div>
                <div className="bg-[#1A1A1A]/40 border border-[#B4B8B9]/10 p-3 text-[11px] text-[#B4B8B9]/80 mt-4 leading-relaxed">
                  WYCA recommends a target Spatial Connectivity score of 7.0 for all residential zones containing over 5,000 inhabitants.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: TIMETABLE OPTIMISER */}
        {activeTab === "timetable" && (
          <div className="space-y-6 animate-fadeIn">
            <TimetableOptimiser
              trips={trips}
              conflicts={conflicts}
              onOptimise={handleOptimiseTimetable}
              onReset={handleResetTimetable}
              loading={loadingSchedule}
            />
          </div>
        )}

        {/* TAB: SIMULATION CENTRE */}
        {activeTab === "simulation" && (
          <div className="space-y-6 animate-fadeIn">
            <SimulationCentre
              onRunSimulation={handleRunSimulation}
              onGenerateReport={handleGenerateAIReport}
            />
          </div>
        )}

        {/* TAB: FINANCE */}
        {activeTab === "finance" && (
          <div className="space-y-6 animate-fadeIn">
            <FinancialAppraisal routes={routes} />
          </div>
        )}

        {/* TAB: ARCHITECTURE */}
        {activeTab === "architecture" && (
          <div className="space-y-6 animate-fadeIn">
            <SystemArchitecture />
          </div>
        )}
      </main>

      {/* 4. METRIC COOPER FOOTER */}
      <footer className="bg-[#0A192F] text-[#E2DFDA] border-t border-[#B4B8B9]/20 py-8 px-6 md:px-10 mt-12 text-xs font-mono">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1">
            <div className="text-[#D48E5C] font-bold uppercase tracking-widest">
              RhinoTransit Planning Suite
            </div>
            <div className="text-[#B4B8B9]/60">
              Contract Ref: Metro-WYCA-RHI-2026. West Yorkshire Combined Authority, Wellington House, Leeds.
            </div>
          </div>

          <div className="text-[#B4B8B9]/60 text-left md:text-right">
            <div>Engine Core: Rust 1.84 Async Mesh / Tokio Node</div>
            <div>Institutional AI Appraisal Module: Google Gemini 3.6 Flash Active</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
