/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import {
  baselineStops,
  baselineRoutes,
  baselineDepots,
  baselineVehicles,
  baselineDrivers,
} from "./server/engines/data";
import {
  calculateShortestPath,
  generateBaselineTimetable,
  detectSchedulingConflicts,
  optimiseTimetable,
  runScenarioSimulation,
  generateStrategicAIReport,
} from "./server/engines/index";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parsing middleware
  app.use(express.json());

  // Store active timetable in memory to allow optimization cycles
  let currentTimetable = generateBaselineTimetable();

  // API ROUTES
  // 1. Get complete West Yorkshire network baseline data
  app.get("/api/network-data", (req: Request, res: Response) => {
    try {
      res.json({
        stops: baselineStops,
        routes: baselineRoutes,
        depots: baselineDepots,
        vehicles: baselineVehicles,
        drivers: baselineDrivers,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to fetch network data" });
    }
  });

  // 2. Graph pathfinder routing (Dijkstra)
  app.post("/api/pathfind", (req: Request, res: Response) => {
    try {
      const { startStopId, endStopId } = req.body;
      if (!startStopId || !endStopId) {
        res.status(400).json({ error: "Missing startStopId or endStopId" });
        return;
      }

      const pathResult = calculateShortestPath(startStopId, endStopId, baselineRoutes, baselineStops);
      if (!pathResult) {
        res.status(404).json({ error: "No path exists between these stops" });
        return;
      }

      res.json({ path: pathResult });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed during route calculation" });
    }
  });

  // 3. Get active timetable
  app.get("/api/timetable", (req: Request, res: Response) => {
    try {
      res.json({ trips: currentTimetable });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to fetch timetable" });
    }
  });

  // 4. Audit active timetable for conflicts
  app.get("/api/timetable/conflicts", (req: Request, res: Response) => {
    try {
      const conflicts = detectSchedulingConflicts(currentTimetable, baselineRoutes);
      res.json({ conflicts });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to audit timetable" });
    }
  });

  // 5. Optimize active timetable
  app.post("/api/timetable/optimise", (req: Request, res: Response) => {
    try {
      const { optimisedTrips, resolvedCount } = optimiseTimetable(currentTimetable);
      currentTimetable = optimisedTrips; // persist optimized version

      const conflicts = detectSchedulingConflicts(currentTimetable, baselineRoutes);
      res.json({
        success: true,
        resolvedCount,
        trips: currentTimetable,
        conflicts,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to optimize timetable" });
    }
  });

  // 6. Reset timetable to baseline
  app.post("/api/timetable/reset", (req: Request, res: Response) => {
    try {
      currentTimetable = generateBaselineTimetable();
      const conflicts = detectSchedulingConflicts(currentTimetable, baselineRoutes);
      res.json({
        success: true,
        trips: currentTimetable,
        conflicts,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to reset timetable" });
    }
  });

  // 7. Run scenario simulation
  app.post("/api/simulation/run", (req: Request, res: Response) => {
    try {
      const { scenario } = req.body;
      if (!scenario) {
        res.status(400).json({ error: "Missing scenario parameter" });
        return;
      }

      const simResult = runScenarioSimulation(scenario);
      res.json({ success: true, result: simResult });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to run simulation" });
    }
  });

  // 8. Generate strategic AI board paper from scenario results
  app.post("/api/simulation/ai-report", async (req: Request, res: Response) => {
    try {
      const { scenario, simResult } = req.body;
      if (!scenario || !simResult) {
        res.status(400).json({ error: "Missing scenario or simResult parameters" });
        return;
      }

      const reportMarkdown = await generateStrategicAIReport(scenario, simResult);
      res.json({ success: true, report: reportMarkdown });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to generate AI report" });
    }
  });

  // VITE OR STATIC MIDDLEWARE SERVING
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RhinoTransit] Platform server running on http://localhost:${PORT}`);
  });
}

startServer();
