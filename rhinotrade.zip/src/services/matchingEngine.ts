import { Order, OrderBook, OrderBookLevel, Trade, OrderSide, OrderType } from '../types';

export class MatchingEngine {
  private orderBook: OrderBook;
  private trades: Trade[];

  constructor(initialOrderBook: OrderBook, initialTrades: Trade[]) {
    this.orderBook = JSON.parse(JSON.stringify(initialOrderBook));
    this.trades = JSON.parse(JSON.stringify(initialTrades));
  }

  public getOrderBook(): OrderBook {
    return this.orderBook;
  }

  public getTrades(): Trade[] {
    return this.trades;
  }

  /**
   * Submits a new order to the Central Limit Order Book (CLOB).
   * Matches buy/sell orders using Price-Time priority.
   */
  public submitOrder(params: {
    instrumentId: string;
    symbol: string;
    side: OrderSide;
    type: OrderType;
    price: number;
    quantityKg: number;
    traderId: string;
    icebergVisibleKg?: number;
    stopPrice?: number;
  }): { order: Order; filledTrades: Trade[] } {
    const { instrumentId, symbol, side, type, price, quantityKg, traderId, icebergVisibleKg } = params;

    const order: Order = {
      id: `ord-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      instrumentId,
      side,
      type,
      price: type === 'MARKET' ? (side === 'BUY' ? this.getBestAsk() : this.getBestBid()) : price,
      quantityKg,
      filledKg: 0,
      remainingKg: quantityKg,
      status: 'OPEN',
      timestamp: new Date().toISOString(),
      traderId,
      icebergVisibleKg,
      settlementCurrency: 'USDT',
    };

    const filledTrades: Trade[] = [];

    // Order matching logic
    if (side === 'BUY') {
      // Match against asks sorted by lowest price first
      const asks = this.orderBook.asks.sort((a, b) => a.price - b.price);

      for (const askLevel of asks) {
        if (order.remainingKg <= 0) break;
        if (type === 'LIMIT' && askLevel.price > order.price) break; // Limit price breached

        const matchQty = Math.min(order.remainingKg, askLevel.quantityKg);
        const matchPrice = askLevel.price;

        order.filledKg += matchQty;
        order.remainingKg -= matchQty;

        askLevel.quantityKg -= matchQty;
        askLevel.totalVolume = askLevel.quantityKg * askLevel.price;

        const trade: Trade = {
          id: `trd-${Date.now()}-${Math.floor(Math.random() * 100)}`,
          instrumentId,
          symbol,
          price: matchPrice,
          quantityKg: matchQty,
          side: 'BUY',
          timestamp: new Date().toISOString(),
          buyerId: traderId,
          sellerId: 'TEESSIDE-ELECTROLYSER-POOL',
          settlementCurrency: 'USDT',
          usdtEquivalent: matchQty * matchPrice,
          txHash: '0x' + Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
          status: 'SETTLED',
        };

        filledTrades.push(trade);
        this.trades.unshift(trade);
      }

      // Filter out depleted ask levels
      this.orderBook.asks = this.orderBook.asks.filter(lvl => lvl.quantityKg > 0);

      if (order.remainingKg > 0) {
        if (type === 'IOC' || type === 'FOK') {
          order.status = order.filledKg > 0 ? 'PARTIAL' : 'CANCELLED';
        } else {
          // Add remaining quantity to bids
          order.status = order.filledKg > 0 ? 'PARTIAL' : 'OPEN';
          this.addLevel('bids', order.price, order.remainingKg);
        }
      } else {
        order.status = 'FILLED';
      }
    } else {
      // SELL order matching against bids sorted by highest price first
      const bids = this.orderBook.bids.sort((a, b) => b.price - a.price);

      for (const bidLevel of bids) {
        if (order.remainingKg <= 0) break;
        if (type === 'LIMIT' && bidLevel.price < order.price) break;

        const matchQty = Math.min(order.remainingKg, bidLevel.quantityKg);
        const matchPrice = bidLevel.price;

        order.filledKg += matchQty;
        order.remainingKg -= matchQty;

        bidLevel.quantityKg -= matchQty;
        bidLevel.totalVolume = bidLevel.quantityKg * bidLevel.price;

        const trade: Trade = {
          id: `trd-${Date.now()}-${Math.floor(Math.random() * 100)}`,
          instrumentId,
          symbol,
          price: matchPrice,
          quantityKg: matchQty,
          side: 'SELL',
          timestamp: new Date().toISOString(),
          buyerId: 'UNIPER-GLOBAL-COMMODITIES',
          sellerId: traderId,
          settlementCurrency: 'USDT',
          usdtEquivalent: matchQty * matchPrice,
          txHash: '0x' + Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
          status: 'SETTLED',
        };

        filledTrades.push(trade);
        this.trades.unshift(trade);
      }

      this.orderBook.bids = this.orderBook.bids.filter(lvl => lvl.quantityKg > 0);

      if (order.remainingKg > 0) {
        if (type === 'IOC' || type === 'FOK') {
          order.status = order.filledKg > 0 ? 'PARTIAL' : 'CANCELLED';
        } else {
          order.status = order.filledKg > 0 ? 'PARTIAL' : 'OPEN';
          this.addLevel('asks', order.price, order.remainingKg);
        }
      } else {
        order.status = 'FILLED';
      }
    }

    this.orderBook.lastUpdated = new Date().toISOString();
    return { order, filledTrades };
  }

  private addLevel(side: 'bids' | 'asks', price: number, qty: number) {
    const list = this.orderBook[side];
    const existing = list.find(l => l.price === price);
    if (existing) {
      existing.quantityKg += qty;
      existing.orderCount += 1;
      existing.totalVolume = existing.quantityKg * price;
    } else {
      list.push({
        price,
        quantityKg: qty,
        orderCount: 1,
        totalVolume: qty * price,
      });
    }

    if (side === 'bids') {
      list.sort((a, b) => b.price - a.price);
    } else {
      list.sort((a, b) => a.price - b.price);
    }
  }

  public getBestBid(): number {
    return this.orderBook.bids.length > 0 ? this.orderBook.bids[0].price : 6.39;
  }

  public getBestAsk(): number {
    return this.orderBook.asks.length > 0 ? this.orderBook.asks[0].price : 6.45;
  }
}
