import { AssetCurrency, AccountWallet, LedgerEntry, UsdtTransaction, UsdtNetwork } from '../types';

export class LedgerEngine {
  private wallet: AccountWallet;
  private ledger: LedgerEntry[];
  private transactions: UsdtTransaction[];

  constructor(initialWallet: AccountWallet, initialLedger: LedgerEntry[], initialTxs: UsdtTransaction[]) {
    this.wallet = JSON.parse(JSON.stringify(initialWallet));
    this.ledger = JSON.parse(JSON.stringify(initialLedger));
    this.transactions = JSON.parse(JSON.stringify(initialTxs));
  }

  public getWallet(): AccountWallet {
    return this.wallet;
  }

  public getLedger(): LedgerEntry[] {
    return this.ledger;
  }

  public getUsdtTransactions(): UsdtTransaction[] {
    return this.transactions;
  }

  /**
   * Records a double-entry ledger movement.
   */
  public recordDoubleEntry(params: {
    currency: AssetCurrency;
    entryType: 'DEBIT' | 'CREDIT';
    amount: number;
    description: string;
    txRef: string;
  }): LedgerEntry {
    const { currency, entryType, amount, description, txRef } = params;

    if (entryType === 'DEBIT') {
      this.wallet.balances[currency] -= amount;
      this.wallet.available[currency] -= amount;
    } else {
      this.wallet.balances[currency] += amount;
      this.wallet.available[currency] += amount;
    }

    // Recalculate Net Liquidation Value in USD
    const fxUSD: Record<AssetCurrency, number> = {
      USD: 1.0,
      USDT: 0.9998,
      EUR: 1.09,
      GBP: 1.28,
      JPY: 0.0068,
      CHF: 1.15,
    };

    let nlvUSD = 0;
    (Object.keys(this.wallet.balances) as AssetCurrency[]).forEach(curr => {
      nlvUSD += this.wallet.balances[curr] * fxUSD[curr];
    });
    this.wallet.netLiquidationValueUSD = nlvUSD;

    const entry: LedgerEntry = {
      id: `ledg-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      account: this.wallet.accountNumber,
      entryType,
      currency,
      amount,
      description,
      txRef,
      balanceAfter: this.wallet.balances[currency],
    };

    this.ledger.unshift(entry);
    return entry;
  }

  /**
   * Initiates a USDT Deposit Workflow.
   */
  public initiateUsdtDeposit(amount: number, network: UsdtNetwork, address: string): UsdtTransaction {
    const txHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const tx: UsdtTransaction = {
      id: `tx-usdt-${Date.now()}`,
      type: 'DEPOSIT',
      network,
      amount,
      fee: network.includes('Tron') ? 1.0 : 12.50,
      address,
      txHash,
      confirmations: 1,
      requiredConfirmations: network.includes('Ethereum') ? 12 : 20,
      status: 'DETECTED',
      timestamp: new Date().toISOString(),
      riskScore: 'LOW',
      multiApprovalState: 'APPROVED',
    };

    this.transactions.unshift(tx);
    return tx;
  }

  /**
   * Advances a USDT Transaction confirmation status until credited.
   */
  public advanceUsdtTransaction(txId: string): UsdtTransaction | null {
    const tx = this.transactions.find(t => t.id === txId);
    if (!tx) return null;

    if (tx.status === 'DETECTED') {
      tx.status = 'CONFIRMING';
      tx.confirmations = Math.floor(tx.requiredConfirmations / 2);
    } else if (tx.status === 'CONFIRMING') {
      tx.confirmations = tx.requiredConfirmations;
      tx.status = 'CONFIRMED';
    } else if (tx.status === 'CONFIRMED' && tx.type === 'DEPOSIT') {
      tx.status = 'CREDITED';
      this.recordDoubleEntry({
        currency: 'USDT',
        entryType: 'CREDIT',
        amount: tx.amount - tx.fee,
        description: `USDT Deposit Credited via ${tx.network} (${tx.txHash.slice(0, 10)}...)`,
        txRef: tx.id,
      });
    } else if (tx.status === 'CONFIRMED' && tx.type === 'WITHDRAWAL') {
      tx.status = 'DISPATCHED';
    }

    return tx;
  }

  /**
   * Initiates a USDT Withdrawal Workflow.
   */
  public initiateUsdtWithdrawal(amount: number, network: UsdtNetwork, destinationAddress: string): UsdtTransaction | { error: string } {
    const fee = network.includes('Tron') ? 2.50 : 15.00;
    const totalDeduction = amount + fee;

    if (this.wallet.available.USDT < totalDeduction) {
      return { error: `Insufficient available USDT balance. Required: ${totalDeduction.toFixed(2)} USDT, Available: ${this.wallet.available.USDT.toFixed(2)} USDT.` };
    }

    const txHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    
    // Deduct available & balance
    this.recordDoubleEntry({
      currency: 'USDT',
      entryType: 'DEBIT',
      amount: totalDeduction,
      description: `USDT Withdrawal Request to ${destinationAddress.slice(0, 8)}... (${network})`,
      txRef: `WITHDRAW-${Date.now()}`,
    });

    const tx: UsdtTransaction = {
      id: `tx-usdt-w-${Date.now()}`,
      type: 'WITHDRAWAL',
      network,
      amount,
      fee,
      address: destinationAddress,
      txHash,
      confirmations: 0,
      requiredConfirmations: network.includes('Ethereum') ? 12 : 20,
      status: 'SCREENING',
      timestamp: new Date().toISOString(),
      riskScore: amount > 500000 ? 'MEDIUM' : 'LOW',
      multiApprovalState: amount > 100000 ? 'PENDING_DESK' : 'APPROVED',
    };

    this.transactions.unshift(tx);
    return tx;
  }

  /**
   * Calculates USDT Basis Monitor data.
   */
  public getUsdtBasisMetrics() {
    return {
      usdtUsd: { price: 0.9998, reference: 1.0000, spreadPercent: -0.02, liquidityUSD: '4.2B USDT' },
      usdtEur: { price: 0.9172, reference: 0.9174, spreadPercent: -0.02, liquidityEUR: '850M EUR' },
      usdtGbp: { price: 0.7812, reference: 0.7810, spreadPercent: 0.03, liquidityGBP: '420M GBP' },
    };
  }
}
