/**
 * RhinoTrade Quantitative Analytics Engine (R + Rust Equivalent)
 * Implements Black-Scholes with Storage Cost & Convenience Yield,
 * Binomial Tree, Monte Carlo Simulation, Value-at-Risk (VaR), Expected Shortfall,
 * Futures Curve Contango/Backwardation Analysis, and Volatility Surface.
 */

// Standard normal cumulative distribution function approximation (Abramowitz & Stegun)
export function cdfNormal(x: number): number {
  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  const p = 0.2316419;
  const c = 0.3989422804014327; // 1 / sqrt(2 * pi)

  if (x >= 0) {
    const t = 1.0 / (1.0 + p * x);
    return 1.0 - c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  } else {
    const t = 1.0 / (1.0 - p * x);
    return c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  }
}

export function pdfNormal(x: number): number {
  return (1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

export interface OptionPriceParams {
  S: number; // Spot Price (USDT/kg)
  K: number; // Strike Price (USDT/kg)
  T: number; // Time to Expiry (years)
  r: number; // Risk-free Rate (annual decimal, e.g. 0.04)
  sigma: number; // Volatility (annual decimal, e.g. 0.30)
  y: number; // Convenience Yield (e.g. 0.02)
  u: number; // Storage Cost (e.g. 0.05 for hydrogen pressurized containment)
}

export interface OptionResult {
  callPrice: number;
  putPrice: number;
  deltaCall: number;
  deltaPut: number;
  gamma: number;
  thetaCall: number;
  thetaPut: number;
  vega: number;
  impliedVol: number;
}

/**
 * Commodity Black-Scholes Model with Convenience Yield & Storage Cost
 */
export function calculateBlackScholes(params: OptionPriceParams): OptionResult {
  const { S, K, T, r, sigma, y, u } = params;

  if (T <= 0 || sigma <= 0 || S <= 0 || K <= 0) {
    return {
      callPrice: Math.max(0, S - K),
      putPrice: Math.max(0, K - S),
      deltaCall: S > K ? 1 : 0,
      deltaPut: S < K ? -1 : 0,
      gamma: 0,
      thetaCall: 0,
      thetaPut: 0,
      vega: 0,
      impliedVol: sigma,
    };
  }

  const costOfCarry = r - y + u;
  const d1 = (Math.log(S / K) + (costOfCarry + 0.5 * sigma * sigma) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);

  const discountCarry = Math.exp(-y * T + u * T); // net carry adjustment on spot
  const discountRate = Math.exp(-r * T);

  const callPrice = S * Math.exp(- (y - u) * T) * cdfNormal(d1) - K * discountRate * cdfNormal(d2);
  const putPrice = K * discountRate * cdfNormal(-d2) - S * Math.exp(- (y - u) * T) * cdfNormal(-d1);

  const deltaCall = Math.exp(-(y - u) * T) * cdfNormal(d1);
  const deltaPut = -Math.exp(-(y - u) * T) * cdfNormal(-d1);

  const gamma = (pdfNormal(d1) * Math.exp(-(y - u) * T)) / (S * sigma * Math.sqrt(T));

  const vega = (S * Math.exp(-(y - u) * T) * pdfNormal(d1) * Math.sqrt(T)) / 100; // per 1% vol change

  const thetaCall = (-(S * Math.exp(-(y - u) * T) * pdfNormal(d1) * sigma) / (2 * Math.sqrt(T))
    - r * K * discountRate * cdfNormal(d2)
    + (y - u) * S * Math.exp(-(y - u) * T) * cdfNormal(d1)) / 365;

  const thetaPut = (-(S * Math.exp(-(y - u) * T) * pdfNormal(d1) * sigma) / (2 * Math.sqrt(T))
    + r * K * discountRate * cdfNormal(-d2)
    - (y - u) * S * Math.exp(-(y - u) * T) * cdfNormal(-d1)) / 365;

  return {
    callPrice: Math.max(0, callPrice),
    putPrice: Math.max(0, putPrice),
    deltaCall,
    deltaPut,
    gamma,
    thetaCall,
    thetaPut,
    vega,
    impliedVol: sigma * 100,
  };
}

/**
 * Binomial Tree Model for American Options on Commodity Futures
 */
export function calculateBinomialTree(params: OptionPriceParams, steps = 50, isAmerican = true): { callPrice: number; putPrice: number } {
  const { S, K, T, r, sigma, y, u } = params;
  const dt = T / steps;
  const b = r - y + u;
  const u_factor = Math.exp(sigma * Math.sqrt(dt));
  const d_factor = 1.0 / u_factor;
  const p = (Math.exp(b * dt) - d_factor) / (u_factor - d_factor);
  const discount = Math.exp(-r * dt);

  // Asset prices at maturity
  const prices: number[] = new Array(steps + 1);
  for (let i = 0; i <= steps; i++) {
    prices[i] = S * Math.pow(u_factor, steps - i) * Math.pow(d_factor, i);
  }

  // Call values
  const callValues: number[] = prices.map(p => Math.max(0, p - K));
  for (let step = steps - 1; step >= 0; step--) {
    for (let i = 0; i <= step; i++) {
      const spotAtStep = S * Math.pow(u_factor, step - i) * Math.pow(d_factor, i);
      const continuation = discount * (p * callValues[i] + (1 - p) * callValues[i + 1]);
      callValues[i] = isAmerican ? Math.max(spotAtStep - K, continuation) : continuation;
    }
  }

  // Put values
  const putValues: number[] = prices.map(p => Math.max(0, K - p));
  for (let step = steps - 1; step >= 0; step--) {
    for (let i = 0; i <= step; i++) {
      const spotAtStep = S * Math.pow(u_factor, step - i) * Math.pow(d_factor, i);
      const continuation = discount * (p * putValues[i] + (1 - p) * putValues[i + 1]);
      putValues[i] = isAmerican ? Math.max(K - spotAtStep, continuation) : continuation;
    }
  }

  return { callPrice: callValues[0], putPrice: putValues[0] };
}

/**
 * Monte Carlo Risk Engine: Calculates Portfolio Value at Risk (VaR 95%, VaR 99%) & Expected Shortfall (CVaR)
 */
export function runMonteCarloSimulations(
  portfolioValueUSD: number,
  volatility: number = 0.28,
  days: number = 10,
  numSimulations: number = 5000
): {
  var95USD: number;
  var99USD: number;
  expectedShortfall99USD: number;
  simulatedPaths: number[][]; // sample paths for visualization
} {
  const dt = days / 365;
  const drift = 0.02 * dt;
  const volAdj = volatility * Math.sqrt(dt);

  const returns: number[] = [];
  const paths: number[][] = [];
  const numSamplePaths = 10;

  for (let sim = 0; sim < numSimulations; sim++) {
    // Box-Muller transformation for normal random number
    const u1 = Math.random() || 1e-10;
    const u2 = Math.random() || 1e-10;
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

    const simReturn = drift + volAdj * z;
    const pnl = portfolioValueUSD * simReturn;
    returns.push(pnl);

    if (sim < numSamplePaths) {
      const path: number[] = [portfolioValueUSD];
      let currentVal = portfolioValueUSD;
      const subSteps = 10;
      const subDt = dt / subSteps;
      for (let s = 1; s <= subSteps; s++) {
        const su1 = Math.random() || 1e-10;
        const su2 = Math.random() || 1e-10;
        const sz = Math.sqrt(-2.0 * Math.log(su1)) * Math.cos(2.0 * Math.PI * su2);
        currentVal *= Math.exp((0.02 - 0.5 * volatility * volatility) * subDt + volatility * Math.sqrt(subDt) * sz);
        path.push(currentVal);
      }
      paths.push(path);
    }
  }

  // Sort returns ascending (losses are negative returns)
  returns.sort((a, b) => a - b);

  const idx95 = Math.floor(numSimulations * 0.05);
  const idx99 = Math.floor(numSimulations * 0.01);

  const var95USD = Math.abs(returns[idx95]);
  const var99USD = Math.abs(returns[idx99]);

  // Expected Shortfall (CVaR 99%): Average of losses beyond 99th percentile
  let sumTailLoss = 0;
  for (let i = 0; i < idx99; i++) {
    sumTailLoss += Math.abs(returns[i]);
  }
  const expectedShortfall99USD = idx99 > 0 ? sumTailLoss / idx99 : var99USD * 1.25;

  return {
    var95USD,
    var99USD,
    expectedShortfall99USD,
    simulatedPaths: paths,
  };
}

/**
 * Futures Curve Analysis: Contango, Backwardation, Calendar Spreads
 */
export function analyzeFuturesCurve(spotPrice: number, curvePoints: { tenor: string; priceUSDT: number }[]) {
  const spreads = curvePoints.map(pt => ({
    tenor: pt.tenor,
    price: pt.priceUSDT,
    spreadOverSpot: pt.priceUSDT - spotPrice,
    percentSpread: ((pt.priceUSDT - spotPrice) / spotPrice) * 100,
  }));

  const isContango = curvePoints.length > 1 && curvePoints[curvePoints.length - 1].priceUSDT > spotPrice;
  const slope = curvePoints.length > 1 ? (curvePoints[curvePoints.length - 1].priceUSDT - spotPrice) / curvePoints.length : 0;

  return {
    isContango,
    marketStructure: isContango ? 'CONTANGO' : 'BACKWARDATION',
    slope,
    spreads,
  };
}
