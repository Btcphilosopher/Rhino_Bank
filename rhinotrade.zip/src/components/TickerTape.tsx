import React from 'react';
import { MarketInstrument, TickerItem } from '../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface TickerTapeProps {
  markets?: MarketInstrument[];
  items?: TickerItem[];
  onSelectMarket?: (market: MarketInstrument) => void;
  selectedMarketId?: string;
}

export const TickerTape: React.FC<TickerTapeProps> = ({ markets, items, onSelectMarket, selectedMarketId }) => {
  // Support both items or markets array
  const displayItems = items || (markets ? markets.map(m => ({
    symbol: m.symbol,
    lastPrice: m.lastPrice,
    change24h: m.change24h,
    unit: `${m.currency}/kg`,
  })) : []);

  return (
    <div className="bg-[#131722] border-b border-[#2A2E39] py-1.5 px-3 flex items-center gap-4 overflow-x-auto text-xs font-mono scrollbar-none">
      <div className="text-[#848E9C] font-mono font-bold uppercase tracking-wider text-[10px] shrink-0 flex items-center gap-1.5 border-r border-[#2A2E39] pr-3">
        <span className="h-2 w-2 rounded-full bg-[#00FF95] animate-pulse"></span>
        LIVE TICKER
      </div>

      <div className="flex items-center gap-4 shrink-0">
        {displayItems.map((item, idx) => {
          const isPositive = item.change24h >= 0;
          return (
            <div
              key={item.symbol || idx}
              className="flex items-center gap-2 px-2.5 py-1 rounded bg-[#1E222D] border border-[#2A2E39] text-[#D1D4DC]"
            >
              <span className="font-bold text-[#FFFFFF] font-sans text-xs">{item.symbol}</span>
              <span className="font-mono font-bold text-[#D1D4DC]">
                ${item.lastPrice.toFixed(2)} <span className="text-[10px] text-[#848E9C] font-normal">{item.unit || '/kg'}</span>
              </span>
              <span className={`flex items-center font-mono font-semibold text-[11px] ${isPositive ? 'text-[#00FF95]' : 'text-[#FF4D4D]'}`}>
                {isPositive ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                {isPositive ? '+' : ''}{item.change24h}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
