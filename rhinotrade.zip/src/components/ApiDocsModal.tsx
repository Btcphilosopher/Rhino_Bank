import React from 'react';
import { Terminal } from 'lucide-react';

interface ApiDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiDocsModal: React.FC<ApiDocsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const endpoints = [
    { method: 'GET', path: '/api/v1/markets', desc: 'Retrieve spot market ticker & order book metrics' },
    { method: 'GET', path: '/api/v1/instruments', desc: 'List active commodity contracts, futures & options specifications' },
    { method: 'GET', path: '/api/v1/prices', desc: 'Fetch real-time benchmark prices across Green, Blue & Grey H₂' },
    { method: 'GET', path: '/api/v1/curves', desc: 'Get term structure futures curves and forward prices' },
    { method: 'POST', path: '/api/v1/orders', desc: 'Submit limit or market order to central matching engine' },
    { method: 'DELETE', path: '/api/v1/orders/:id', desc: 'Cancel open order by Order ID' },
    { method: 'GET', path: '/api/v1/trades', desc: 'Fetch recent market trade executions and public tape' },
    { method: 'GET', path: '/api/v1/positions', desc: 'Query active institutional positions and mark-to-market P&L' },
    { method: 'GET', path: '/api/v1/margin', desc: 'Query portfolio initial & maintenance margin requirements' },
    { method: 'GET', path: '/api/v1/wallets', desc: 'Retrieve multi-currency wallet balances & net liquidation value' },
    { method: 'POST', path: '/api/v1/usdt/deposit', desc: 'Initiate USDT deposit flow across ERC-20, TRC-20, SPL' },
    { method: 'POST', path: '/api/v1/usdt/withdraw', desc: 'Submit USDT withdrawal request with multi-sign approval' },
    { method: 'GET', path: '/api/v1/contracts', desc: 'List deployed smart contract specs & locked collateral state' },
    { method: 'GET', path: '/api/v1/oracles', desc: 'Query telemetry node observations & consensus algorithm state' },
    { method: 'GET', path: '/api/v1/delivery', desc: 'Retrieve physical delivery schedules & purity inspection logs' },
    { method: 'GET', path: '/api/v1/risk', desc: 'Fetch parametric VaR 95%/99%, Expected Shortfall & Stress Scenarios' },
    { method: 'POST', path: '/api/v1/quant/backtest', desc: 'Execute R-quant backtest simulation on historical dataset' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0E11]/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#131722] border border-[#2A2E39] rounded-lg max-w-4xl w-full p-6 text-[#D1D4DC] shadow-2xl flex flex-col gap-4 max-h-[90vh]">
        <div className="flex justify-between items-center border-b border-[#2A2E39] pb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[#00FF95]" />
            <h2 className="text-sm font-extrabold tracking-wider text-[#FFFFFF] font-sans">RHINOTRADE INSTITUTIONAL REST / WEBSOCKET API v1</h2>
          </div>
          <button onClick={onClose} className="text-[#848E9C] hover:text-[#FFFFFF] text-lg font-bold">✕</button>
        </div>

        <p className="text-xs text-[#848E9C]">
          High-frequency low-latency API access for algorithmic market makers, physical off-takers, and risk managers. All requests require HMAC-SHA256 signature authentication.
        </p>

        <div className="overflow-y-auto flex-1 pr-1 border border-[#2A2E39] rounded bg-[#0B0E11]">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                <th className="py-2.5 px-3">Method</th>
                <th className="py-2.5 px-3">Endpoint Path</th>
                <th className="py-2.5 px-3 font-sans">Description</th>
              </tr>
            </thead>
            <tbody>
              {endpoints.map((ep, i) => (
                <tr key={i} className="border-b border-[#2A2E39]/60 hover:bg-[#1E222D]/60 transition">
                  <td className="py-2 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      ep.method === 'GET' ? 'bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30' :
                      ep.method === 'POST' ? 'bg-[#2962FF]/10 text-[#2962FF] border border-[#2962FF]/30' :
                      'bg-[#FF4D4D]/10 text-[#FF4D4D] border border-[#FF4D4D]/30'
                    }`}>
                      {ep.method}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-bold text-[#FFFFFF]">{ep.path}</td>
                  <td className="py-2 px-3 font-sans text-[#D1D4DC] text-[11px]">{ep.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center border-t border-[#2A2E39] pt-3">
          <span className="text-[10px] font-mono text-[#848E9C]">WebSocket Live Feed: wss://api.rhinotrade.exchange/v1/stream</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] rounded text-xs font-bold border border-[#2A2E39] transition"
          >
            Close API Docs
          </button>
        </div>
      </div>
    </div>
  );
};
