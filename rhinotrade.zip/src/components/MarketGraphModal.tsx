import React from 'react';
import { Share2, ArrowDown, ArrowRight } from 'lucide-react';

interface MarketGraphModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MarketGraphModal: React.FC<MarketGraphModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0E11]/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#131722] border border-[#2A2E39] rounded-lg max-w-4xl w-full p-6 text-[#D1D4DC] shadow-2xl flex flex-col gap-4">
        <div className="flex justify-between items-center border-b border-[#2A2E39] pb-3">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-[#00FF95]" />
            <h2 className="text-sm font-extrabold tracking-wider text-[#FFFFFF] font-sans">RHINOTRADE MARKET RELATIONSHIP ARCHITECTURE</h2>
          </div>
          <button onClick={onClose} className="text-[#848E9C] hover:text-[#FFFFFF] text-lg font-bold">✕</button>
        </div>

        <p className="text-xs text-[#848E9C] leading-relaxed">
          The diagram below maps how physical energy inputs (Power & Gas) interact with Carbon pricing to establish Spot Hydrogen benchmarks, feeding into derivatives, smart contracts, USDT settlement, and immutable double-entry accounting.
        </p>

        {/* Visual Structural Diagram */}
        <div className="bg-[#0B0E11] p-6 rounded-lg border border-[#2A2E39] flex flex-col items-center gap-6 font-mono text-xs">
          {/* Layer 1: Inputs */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <div className="px-4 py-2 bg-amber-950/40 border border-amber-500/40 rounded text-amber-300 font-bold">
              ⚡ POWER GRID (Renewable / Wind)
            </div>
            <ArrowRight className="w-5 h-5 text-[#848E9C]" />
            <div className="px-5 py-2.5 bg-[#1E222D] border border-[#00FF95]/60 rounded text-[#00FF95] font-extrabold text-sm shadow-[0_0_15px_rgba(0,255,149,0.15)]">
              🦏 RHINOTRADE HYDROGEN CORE
            </div>
            <ArrowRight className="w-5 h-5 text-[#848E9C]" />
            <div className="px-4 py-2 bg-emerald-950/40 border border-[#00FF95]/40 rounded text-[#00FF95] font-bold">
              🔥 NATURAL GAS (TTF / Henry Hub)
            </div>
          </div>

          <ArrowDown className="w-5 h-5 text-[#848E9C]" />

          {/* Layer 2: Commodity Spot */}
          <div className="px-6 py-2.5 bg-[#1E222D] border border-[#00FF95] rounded text-[#00FF95] font-bold text-sm shadow-[0_0_10px_rgba(0,255,149,0.2)]">
            SPOT HYDROGEN (Green, Blue, Low-Carbon)
          </div>

          <ArrowDown className="w-5 h-5 text-[#848E9C]" />

          {/* Layer 3: Derivatives */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full text-center">
            <div className="p-3 bg-[#131722] border border-[#2A2E39] rounded">
              <span className="font-bold text-[#2962FF] block">FUTURES</span>
              <span className="text-[10px] text-[#848E9C]">Term Curve / Contango</span>
            </div>
            <div className="p-3 bg-[#131722] border border-[#2A2E39] rounded">
              <span className="font-bold text-purple-400 block">OPTIONS</span>
              <span className="text-[10px] text-[#848E9C]">Calls / Puts / Vol Surface</span>
            </div>
            <div className="p-3 bg-[#131722] border border-[#2A2E39] rounded">
              <span className="font-bold text-amber-400 block">SWAPS</span>
              <span className="text-[10px] text-[#848E9C]">Fixed/Floating & Basis</span>
            </div>
          </div>

          <ArrowDown className="w-5 h-5 text-[#848E9C]" />

          {/* Layer 4: Settlement */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <div className="px-4 py-2 bg-[#1E222D] border border-[#00FF95]/40 rounded text-[#00FF95] font-bold">
              USDT SETTLEMENT ENGINE
            </div>
            <ArrowRight className="w-5 h-5 text-[#848E9C]" />
            <div className="px-4 py-2 bg-[#1E222D] border border-[#2962FF]/40 rounded text-[#2962FF] font-bold">
              SMART CONTRACT ESCROW
            </div>
            <ArrowRight className="w-5 h-5 text-[#848E9C]" />
            <div className="px-4 py-2 bg-[#1E222D] border border-purple-500/40 rounded text-purple-300 font-bold">
              RHINOTRADE LEDGER
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] rounded text-xs font-bold border border-[#2A2E39] transition"
          >
            Close Architecture Map
          </button>
        </div>
      </div>
    </div>
  );
};
