import React, { useState } from 'react';
import { MarketInstrument, OrderBook, Trade, OrderSide, OrderType, AccountWallet } from '../../types';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowUpRight, ArrowDownRight, ShieldCheck, Cpu, Layers, CheckCircle2, AlertCircle } from 'lucide-react';

interface SpotMarketWorkspaceProps {
  markets: MarketInstrument[];
  selectedMarket: MarketInstrument;
  onSelectMarket: (market: MarketInstrument) => void;
  orderBook: OrderBook;
  trades: Trade[];
  wallet: AccountWallet;
  onSubmitOrder: (order: {
    instrumentId: string;
    symbol: string;
    side: OrderSide;
    type: OrderType;
    price: number;
    quantityKg: number;
  }) => void;
}

export const SpotMarketWorkspace: React.FC<SpotMarketWorkspaceProps> = ({
  markets,
  selectedMarket,
  onSelectMarket,
  orderBook,
  trades,
  wallet,
  onSubmitOrder,
}) => {
  const [side, setSide] = useState<OrderSide>('BUY');
  const [orderType, setOrderType] = useState<OrderType>('LIMIT');
  const [priceInput, setPriceInput] = useState<string>(selectedMarket.lastPrice.toString());
  const [quantityInput, setQuantityInput] = useState<string>('2500');
  const [orderSuccessMsg, setOrderSuccessMsg] = useState<string | null>(null);

  const price = parseFloat(priceInput) || selectedMarket.lastPrice;
  const quantityKg = parseFloat(quantityInput) || 0;
  const totalSettlementUSDT = price * quantityKg;

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quantityKg <= 0) return;

    onSubmitOrder({
      instrumentId: selectedMarket.id,
      symbol: selectedMarket.symbol,
      side,
      type: orderType,
      price,
      quantityKg,
    });

    setOrderSuccessMsg(`Submitted ${side} Order: ${quantityKg.toLocaleString()} kg @ ${price.toFixed(2)} ${selectedMarket.currency}`);
    setTimeout(() => setOrderSuccessMsg(null), 4000);
  };

  // Generate synthetic price history for chart
  const generateChartData = () => {
    const base = selectedMarket.lastPrice;
    const result = [];
    const times = ['00:00', '02:00', '04:00', '06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', 'NOW'];
    for (let i = 0; i < times.length; i++) {
      const noise = (Math.sin(i * 1.5) * 0.12) + ((i / 12) * 0.15);
      result.push({
        time: times[i],
        price: parseFloat((base - 0.2 + noise).toFixed(2)),
      });
    }
    return result;
  };

  const chartData = generateChartData();

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Left Column: Market Selection & Asset Info (3 cols) */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        {/* Market Selector Card */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 flex items-center justify-between">
            <span>Spot Hydrogen Markets</span>
            <span className="text-[10px] bg-[#1E222D] text-[#00FF95] border border-[#2A2E39] px-1.5 py-0.5 rounded">6 Active</span>
          </div>

          <div className="flex flex-col gap-1.5 max-h-[260px] overflow-y-auto scrollbar-none pr-1">
            {markets.map(m => {
              const active = m.id === selectedMarket.id;
              return (
                <button
                  key={m.id}
                  onClick={() => {
                    onSelectMarket(m);
                    setPriceInput(m.lastPrice.toString());
                  }}
                  className={`p-2.5 rounded text-left transition border flex flex-col gap-1 ${
                    active
                      ? 'bg-[#1E222D] border-[#00FF95]/60 text-[#FFFFFF] shadow-[0_0_10px_rgba(0,255,149,0.1)]'
                      : 'bg-[#0B0E11]/60 border-[#2A2E39] hover:bg-[#1E222D]/50 text-[#D1D4DC]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-[#FFFFFF] font-sans">{m.symbol}</span>
                    <span className={`text-xs font-mono font-semibold ${m.change24h >= 0 ? 'text-[#00FF95]' : 'text-[#FF4D4D]'}`}>
                      {m.change24h >= 0 ? '+' : ''}{m.change24h}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#848E9C] font-mono">
                    <span>{m.productionType}</span>
                    <span className="font-bold text-[#D1D4DC]">${m.lastPrice.toFixed(2)} {m.currency}/kg</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Physical Spec Breakdown */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 flex flex-col gap-2 text-xs">
          <div className="font-bold text-[#FFFFFF] border-b border-[#2A2E39] pb-1.5 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#00FF95]" />
            Physical Commodity Spec
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
            <div>
              <span className="text-[#848E9C] block">Production Method</span>
              <span className="font-semibold text-[#00FF95]">{selectedMarket.productionType}</span>
            </div>
            <div>
              <span className="text-[#848E9C] block">Purity Grade</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedMarket.purity}</span>
            </div>
            <div>
              <span className="text-[#848E9C] block">Pressure Level</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedMarket.pressure}</span>
            </div>
            <div>
              <span className="text-[#848E9C] block">Delivery Method</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedMarket.deliveryMethod}</span>
            </div>
            <div className="col-span-2">
              <span className="text-[#848E9C] block">Hub Location</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedMarket.location}</span>
            </div>
            <div className="col-span-2">
              <span className="text-[#848E9C] block mb-1">Standard Certification</span>
              <span className="inline-block bg-[#1E222D] text-[#00FF95] font-semibold px-2 py-0.5 rounded border border-[#00FF95]/30">
                {selectedMarket.certification}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Center Column: Chart & Order Book (6 cols) */}
      <div className="lg:col-span-6 flex flex-col gap-4">
        {/* Header Summary Card */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">{selectedMarket.name}</h1>
              <span className="bg-[#00FF95]/10 text-[#00FF95] text-xs font-mono font-semibold px-2 py-0.5 rounded border border-[#00FF95]/30">
                USDT Settled
              </span>
            </div>
            <p className="text-xs text-[#848E9C] mt-0.5 font-mono">{selectedMarket.location}</p>
          </div>

          <div className="flex items-center gap-6 text-xs font-mono">
            <div>
              <span className="text-[#848E9C] block">Spot Last</span>
              <span className="text-base font-bold text-[#FFFFFF]">${selectedMarket.lastPrice.toFixed(2)} {selectedMarket.currency}/kg</span>
            </div>
            <div>
              <span className="text-[#848E9C] block">24h Spread</span>
              <span className="font-semibold text-[#D1D4DC]">${selectedMarket.spread.toFixed(2)} USDT</span>
            </div>
            <div>
              <span className="text-[#848E9C] block">24h Vol (kg)</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedMarket.volume24hKg.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Price Chart */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 h-64 flex flex-col">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 flex items-center justify-between">
            <span>Price Action — 24H (USDT/kg)</span>
            <span className="text-[10px] text-[#00FF95] font-mono">High: ${selectedMarket.high24h} | Low: ${selectedMarket.low24h}</span>
          </div>

          <div className="flex-1 w-full h-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="spotColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00FF95" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00FF95" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#848E9C" tick={{ fontSize: 10 }} />
                <YAxis domain={['auto', 'auto']} stroke="#848E9C" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#131722', borderColor: '#2A2E39', color: '#FFFFFF', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="price" stroke="#00FF95" strokeWidth={2} fillOpacity={1} fill="url(#spotColor)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Central Limit Order Book & Recent Trades */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Order Book */}
          <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 flex flex-col gap-2">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-1 flex justify-between">
              <span>Order Book Depth</span>
              <span className="text-[10px] text-[#848E9C] font-mono">Price-Time Priority</span>
            </div>

            {/* Asks (Sells) */}
            <div className="flex flex-col gap-0.5 font-mono text-xs">
              <div className="grid grid-cols-3 text-[10px] text-[#848E9C] font-mono uppercase mb-1">
                <span>Price</span>
                <span className="text-right">Qty (kg)</span>
                <span className="text-right">Total (USDT)</span>
              </div>
              {orderBook.asks.slice(0, 4).reverse().map((ask, i) => (
                <div key={i} className="grid grid-cols-3 text-[#FF4D4D] hover:bg-[#FF4D4D]/10 px-1 py-0.5 rounded transition">
                  <span className="font-bold">${ask.price.toFixed(2)}</span>
                  <span className="text-right text-[#D1D4DC]">{ask.quantityKg.toLocaleString()}</span>
                  <span className="text-right text-[#848E9C]">${ask.totalVolume.toLocaleString()}</span>
                </div>
              ))}
            </div>

            {/* Spread Divider */}
            <div className="bg-[#1E222D] px-2 py-1 rounded text-center text-[11px] font-mono font-semibold text-[#D1D4DC] flex justify-between border border-[#2A2E39]">
              <span className="text-[#848E9C]">MID SPREAD</span>
              <span className="text-[#00FF95] font-bold">${selectedMarket.bid.toFixed(2)} / ${selectedMarket.ask.toFixed(2)}</span>
              <span className="text-[#848E9C]">(${selectedMarket.spread.toFixed(2)} USDT)</span>
            </div>

            {/* Bids (Buys) */}
            <div className="flex flex-col gap-0.5 font-mono text-xs">
              {orderBook.bids.slice(0, 4).map((bid, i) => (
                <div key={i} className="grid grid-cols-3 text-[#00FF95] hover:bg-[#00FF95]/10 px-1 py-0.5 rounded transition">
                  <span className="font-bold">${bid.price.toFixed(2)}</span>
                  <span className="text-right text-[#D1D4DC]">{bid.quantityKg.toLocaleString()}</span>
                  <span className="text-right text-[#848E9C]">${bid.totalVolume.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Trade Tape Stream */}
          <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 flex flex-col gap-2">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-1 flex justify-between">
              <span>Executed Trade Stream</span>
              <span className="text-[10px] text-[#00FF95] font-mono">Live Match</span>
            </div>

            <div className="flex flex-col gap-1 font-mono text-xs max-h-[190px] overflow-y-auto scrollbar-none">
              <div className="grid grid-cols-4 text-[10px] text-[#848E9C] font-mono uppercase mb-1">
                <span>Time</span>
                <span className="text-right">Price</span>
                <span className="text-right">Qty (kg)</span>
                <span className="text-right">Side</span>
              </div>

              {trades.map(t => (
                <div key={t.id} className="grid grid-cols-4 py-1 px-1 border-b border-[#2A2E39]/40 text-[11px] hover:bg-[#1E222D]/60">
                  <span className="text-[#848E9C]">{t.timestamp.slice(11, 19)}</span>
                  <span className="text-right font-bold text-[#D1D4DC]">${t.price.toFixed(2)}</span>
                  <span className="text-right text-[#848E9C]">{t.quantityKg.toLocaleString()}</span>
                  <span className={`text-right font-semibold ${t.side === 'BUY' ? 'text-[#00FF95]' : 'text-[#FF4D4D]'}`}>
                    {t.side}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Order Placement & Execution Panel (3 cols) */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        {/* Order Ticket Form */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center">
            <span>Place Order</span>
            <span className="text-xs font-mono font-normal text-[#848E9C]">{selectedMarket.symbol}</span>
          </div>

          {orderSuccessMsg && (
            <div className="p-2.5 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded text-xs text-[#00FF95] flex items-center gap-1.5 font-mono">
              <CheckCircle2 className="w-4 h-4 text-[#00FF95] shrink-0" />
              <span>{orderSuccessMsg}</span>
            </div>
          )}

          {/* Buy/Sell Selector */}
          <div className="grid grid-cols-2 gap-2 bg-[#0B0E11] p-1 rounded border border-[#2A2E39]">
            <button
              type="button"
              onClick={() => setSide('BUY')}
              className={`py-1.5 font-bold text-xs rounded transition font-mono ${
                side === 'BUY' ? 'bg-[#089981] text-[#FFFFFF] shadow-[0_0_8px_rgba(8,153,129,0.3)]' : 'text-[#848E9C] hover:text-[#D1D4DC]'
              }`}
            >
              BUY HYDROGEN
            </button>
            <button
              type="button"
              onClick={() => setSide('SELL')}
              className={`py-1.5 font-bold text-xs rounded transition font-mono ${
                side === 'SELL' ? 'bg-[#F23645] text-[#FFFFFF] shadow-[0_0_8px_rgba(242,54,69,0.3)]' : 'text-[#848E9C] hover:text-[#D1D4DC]'
              }`}
            >
              SELL HYDROGEN
            </button>
          </div>

          {/* Order Type Selector */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-[#848E9C] font-mono">Order Execution Type</label>
            <select
              value={orderType}
              onChange={e => setOrderType(e.target.value as OrderType)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#D1D4DC] text-xs font-mono rounded p-2 focus:outline-none focus:border-[#00FF95]"
            >
              <option value="LIMIT">LIMIT (Price-Time Priority)</option>
              <option value="MARKET">MARKET (Immediate Best Match)</option>
              <option value="IOC">IOC (Immediate Or Cancel)</option>
              <option value="FOK">FOK (Fill Or Kill)</option>
              <option value="STOP_LIMIT">STOP LIMIT</option>
              <option value="ICEBERG">ICEBERG (Hidden Reserve)</option>
            </select>
          </div>

          {/* Price Input */}
          {orderType !== 'MARKET' && (
            <div className="flex flex-col gap-1">
              <label className="text-[11px] text-[#848E9C] font-mono">Price ({selectedMarket.currency}/kg)</label>
              <input
                type="number"
                step="0.01"
                value={priceInput}
                onChange={e => setPriceInput(e.target.value)}
                className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] font-mono text-sm rounded p-2 focus:outline-none focus:border-[#00FF95]"
              />
            </div>
          )}

          {/* Quantity Input */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-[#848E9C] font-mono">Quantity (Kilograms H₂)</label>
            <input
              type="number"
              step="100"
              value={quantityInput}
              onChange={e => setQuantityInput(e.target.value)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] font-mono text-sm rounded p-2 focus:outline-none focus:border-[#00FF95]"
            />
          </div>

          {/* Order Summary & Settlement Breakdown */}
          <div className="bg-[#0B0E11]/80 border border-[#2A2E39] rounded p-2.5 flex flex-col gap-1.5 text-xs font-mono">
            <div className="flex justify-between text-[#848E9C]">
              <span>Unit Price:</span>
              <span className="text-[#D1D4DC]">${price.toFixed(2)} {selectedMarket.currency}</span>
            </div>
            <div className="flex justify-between text-[#848E9C]">
              <span>Volume:</span>
              <span className="text-[#D1D4DC]">{quantityKg.toLocaleString()} kg</span>
            </div>
            <div className="flex justify-between text-[#848E9C] border-t border-[#2A2E39] pt-1">
              <span className="font-bold text-[#D1D4DC]">Total Settlement:</span>
              <span className="font-bold text-[#00FF95]">${totalSettlementUSDT.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT</span>
            </div>
            <div className="flex justify-between text-[10px] text-[#848E9C]">
              <span>Available USDT:</span>
              <span>${wallet.available.USDT.toLocaleString()} USDT</span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleOrderSubmit}
            className={`w-full py-2.5 rounded font-mono font-bold text-xs uppercase tracking-wider text-white shadow-lg transition ${
              side === 'BUY'
                ? 'bg-[#089981] hover:bg-[#089981]/90 active:bg-[#089981]/80 shadow-[0_0_12px_rgba(8,153,129,0.25)]'
                : 'bg-[#F23645] hover:bg-[#F23645]/90 active:bg-[#F23645]/80 shadow-[0_0_12px_rgba(242,54,69,0.25)]'
            }`}
          >
            EXECUTE {side} ({quantityKg.toLocaleString()} KG)
          </button>
        </div>

        {/* Physical Settlement Assurance */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 text-xs text-[#848E9C] flex flex-col gap-1.5">
          <div className="font-semibold text-[#D1D4DC] flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-[#2962FF]" />
            Physical Settlement Terms
          </div>
          <p className="text-[11px] leading-relaxed font-sans">
            Spot purchases settle in USDT with guaranteed custody claims at <strong className="text-[#D1D4DC]">{selectedMarket.location}</strong>. Deliveries adhere to 99.999% purity thresholds with automated Oracle telemetry verification.
          </p>
        </div>
      </div>
    </div>
  );
};
