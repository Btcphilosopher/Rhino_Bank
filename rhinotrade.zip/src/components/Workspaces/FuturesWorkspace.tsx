import React, { useState } from 'react';
import { FuturesCurvePoint, AccountWallet } from '../../types';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { TrendingUp, Activity, Layers, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { analyzeFuturesCurve } from '../../services/quantEngine';

interface FuturesWorkspaceProps {
  futuresCurve: FuturesCurvePoint[];
  wallet: AccountWallet;
}

export const FuturesWorkspace: React.FC<FuturesWorkspaceProps> = ({ futuresCurve, wallet }) => {
  const [selectedContract, setSelectedContract] = useState<FuturesCurvePoint>(futuresCurve[5]); // Q1 2027 default
  const [spreadLegA, setSpreadLegA] = useState<string>('RH-H2-GREEN-UK-DEC-2026');
  const [spreadLegB, setSpreadLegB] = useState<string>('RH-H2-GREEN-UK-Q1-2027');
  const [tradeStatus, setTradeStatus] = useState<string | null>(null);

  const curveAnalysis = analyzeFuturesCurve(futuresCurve[0].priceUSDT, futuresCurve.map(pt => ({ tenor: pt.tenor, priceUSDT: pt.priceUSDT })));

  const legAObj = futuresCurve.find(f => f.contract === spreadLegA) || futuresCurve[4];
  const legBObj = futuresCurve.find(f => f.contract === spreadLegB) || futuresCurve[5];
  const calendarSpreadVal = legBObj.priceUSDT - legAObj.priceUSDT;

  const handleSpreadExecute = () => {
    setTradeStatus(`Executed Calendar Spread: LONG ${legBObj.tenor} / SHORT ${legAObj.tenor} @ ${calendarSpreadVal.toFixed(2)} USDT spread`);
    setTimeout(() => setTradeStatus(null), 4000);
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner: Market Structure Analytics */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00FF95]/10 text-[#00FF95] rounded-lg border border-[#00FF95]/30 font-bold">
            📈
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Hydrogen Futures Term Structure</h1>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
                curveAnalysis.isContango ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-[#2962FF]/10 text-[#2962FF] border-[#2962FF]/30'
              }`}>
                {curveAnalysis.marketStructure} MARKET
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">RH-H2-GREEN-UK Central Limit Futures Curve</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Spot Baseline</span>
            <span className="text-base font-bold text-[#FFFFFF]">${futuresCurve[0].priceUSDT.toFixed(2)} USDT/kg</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Q1 2027 Contango</span>
            <span className="font-semibold text-amber-400">+${futuresCurve[5].contangoSpread.toFixed(2)} USDT ({futuresCurve[5].rollYieldPercent}%)</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Curve Slope</span>
            <span className="font-semibold text-[#D1D4DC]">+{curveAnalysis.slope.toFixed(3)} USDT/tenor</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Total Open Interest</span>
            <span className="font-semibold text-[#00FF95]">
              {futuresCurve.reduce((acc, c) => acc + c.openInterestKg, 0).toLocaleString()} kg
            </span>
          </div>
        </div>
      </div>

      {/* Main Curve Chart & Contract Table (8 cols) */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        {/* Futures Curve Chart */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 h-72 flex flex-col">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 flex justify-between items-center">
            <span>Futures Price Forward Curve (USDT/kg)</span>
            <span className="text-[10px] text-[#848E9C] font-mono">Spot → Q3 2027</span>
          </div>

          <div className="flex-1 w-full h-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={futuresCurve} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2E39" />
                <XAxis dataKey="tenor" stroke="#848E9C" tick={{ fontSize: 11 }} />
                <YAxis domain={['auto', 'auto']} stroke="#848E9C" tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#131722', borderColor: '#2A2E39', color: '#FFFFFF', fontSize: '12px' }} />
                <Line type="monotone" dataKey="priceUSDT" stroke="#00FF95" strokeWidth={3} dot={{ r: 5, fill: '#00FF95' }} activeDot={{ r: 7 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Futures Chain Table */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Futures Chain Contracts</span>
            <span className="text-[10px] text-[#848E9C] font-mono">Standard Contract Size: 10,000 kg</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[11px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Contract Code</th>
                  <th className="py-2.5 px-2">Tenor</th>
                  <th className="py-2.5 px-2 text-right">Last (USDT)</th>
                  <th className="py-2.5 px-2 text-right">Spread vs Spot</th>
                  <th className="py-2.5 px-2 text-right">Roll Yield %</th>
                  <th className="py-2.5 px-2 text-right">Volume (kg)</th>
                  <th className="py-2.5 px-2 text-right">Open Interest</th>
                  <th className="py-2.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {futuresCurve.map(row => {
                  const isSelected = row.contract === selectedContract.contract;
                  return (
                    <tr
                      key={row.contract}
                      className={`border-b border-[#2A2E39]/60 hover:bg-[#1E222D]/60 transition ${
                        isSelected ? 'bg-[#1E222D] text-[#FFFFFF]' : 'text-[#D1D4DC]'
                      }`}
                    >
                      <td className="py-2 px-2 font-bold font-sans text-[#00FF95]">{row.contract}</td>
                      <td className="py-2 px-2">{row.tenor}</td>
                      <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">${row.priceUSDT.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-amber-400">
                        {row.contangoSpread >= 0 ? '+' : ''}${row.contangoSpread.toFixed(2)}
                      </td>
                      <td className="py-2 px-2 text-right text-[#00FF95]">+{row.rollYieldPercent.toFixed(1)}%</td>
                      <td className="py-2 px-2 text-right text-[#848E9C]">{row.volumeKg.toLocaleString()}</td>
                      <td className="py-2 px-2 text-right text-[#848E9C]">{row.openInterestKg.toLocaleString()}</td>
                      <td className="py-2 px-2 text-center">
                        <button
                          onClick={() => setSelectedContract(row)}
                          className="px-2.5 py-0.5 rounded bg-[#1E222D] hover:bg-[#2A2E39] text-[11px] text-[#FFFFFF] border border-[#2A2E39] transition font-mono"
                        >
                          Select
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Calendar Spread Execution & Contract Spec (4 cols) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        {/* Calendar Spread Trader */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex items-center justify-between font-sans">
            <span>Calendar Spread Desk</span>
            <span className="text-xs text-amber-400 font-mono">Arbitrage</span>
          </div>

          {tradeStatus && (
            <div className="p-2.5 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded text-xs text-[#00FF95] flex items-center gap-1.5 font-mono">
              <CheckCircle2 className="w-4 h-4 text-[#00FF95] shrink-0" />
              <span>{tradeStatus}</span>
            </div>
          )}

          <div className="flex flex-col gap-2 text-xs">
            <div>
              <label className="text-[#848E9C] text-[11px] font-mono block mb-1">Leg A (Short / Near Tenor)</label>
              <select
                value={spreadLegA}
                onChange={e => setSpreadLegA(e.target.value)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#D1D4DC] rounded p-2 focus:outline-none focus:border-[#00FF95] font-mono"
              >
                {futuresCurve.slice(1).map(f => (
                  <option key={f.contract} value={f.contract}>
                    {f.tenor} (${f.priceUSDT.toFixed(2)} USDT)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#848E9C] text-[11px] font-mono block mb-1">Leg B (Long / Far Tenor)</label>
              <select
                value={spreadLegB}
                onChange={e => setSpreadLegB(e.target.value)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#D1D4DC] rounded p-2 focus:outline-none focus:border-[#00FF95] font-mono"
              >
                {futuresCurve.slice(1).map(f => (
                  <option key={f.contract} value={f.contract}>
                    {f.tenor} (${f.priceUSDT.toFixed(2)} USDT)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="bg-[#0B0E11] border border-[#2A2E39] rounded p-3 flex flex-col gap-1.5 text-xs font-mono">
            <div className="flex justify-between text-[#848E9C]">
              <span>Calendar Spread:</span>
              <span className="font-bold text-amber-400">+${calendarSpreadVal.toFixed(2)} USDT/kg</span>
            </div>
            <div className="flex justify-between text-[#848E9C]">
              <span>Implied Carry Rate:</span>
              <span className="text-[#00FF95]">4.85% p.a.</span>
            </div>
            <div className="flex justify-between text-[#848E9C]">
              <span>Required Initial Margin:</span>
              <span className="text-[#D1D4DC]">12,500 USDT / contract</span>
            </div>
          </div>

          <button
            onClick={handleSpreadExecute}
            className="w-full py-2.5 bg-[#2962FF] hover:bg-[#2962FF]/90 text-white font-mono font-bold text-xs uppercase tracking-wider rounded shadow-[0_0_12px_rgba(41,98,255,0.3)] transition"
          >
            EXECUTE CALENDAR SPREAD
          </button>
        </div>

        {/* Selected Contract Specs */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 text-xs flex flex-col gap-2">
          <div className="font-bold text-[#FFFFFF] border-b border-[#2A2E39] pb-1.5 flex justify-between items-center font-sans">
            <span>Contract Specifications</span>
            <span className="text-[#00FF95] font-mono">{selectedContract.contract}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
            <div>
              <span className="text-[#848E9C] block font-mono">Contract Size</span>
              <span className="font-bold text-[#D1D4DC]">10,000 kg H₂</span>
            </div>
            <div>
              <span className="text-[#848E9C] block font-mono">Tick Size</span>
              <span className="font-bold text-[#D1D4DC]">0.01 USDT/kg ($100)</span>
            </div>
            <div>
              <span className="text-[#848E9C] block font-mono">Settlement Type</span>
              <span className="font-bold text-[#00FF95]">Physical or Cash (USDT)</span>
            </div>
            <div>
              <span className="text-[#848E9C] block font-mono">Last Delivery Date</span>
              <span className="font-bold text-[#D1D4DC]">15 Dec 2026</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
