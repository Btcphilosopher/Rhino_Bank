import React, { useState } from 'react';
import { CommoditySwap, BasisSwap } from '../../types';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { RefreshCw, Send, CheckCircle2, ShieldCheck } from 'lucide-react';

interface SwapsWorkspaceProps {
  swaps: CommoditySwap[];
  basisSwaps: BasisSwap[];
}

export const SwapsWorkspace: React.FC<SwapsWorkspaceProps> = ({ swaps, basisSwaps }) => {
  const [selectedBasis, setSelectedBasis] = useState<BasisSwap>(basisSwaps[0]);
  const [rfqNotionalKg, setRfqNotionalKg] = useState<string>('5000000');
  const [rfqFixedRate, setRfqFixedRate] = useState<string>('6.75');
  const [rfqCounterparty, setRfqCounterparty] = useState<string>('BP Energy Trading & Shipping');
  const [rfqSuccessMsg, setRfqSuccessMsg] = useState<string | null>(null);

  const handleRfqSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRfqSuccessMsg(`RFQ Quote Sent to ${rfqCounterparty}: ${parseInt(rfqNotionalKg).toLocaleString()} kg @ ${rfqFixedRate} USDT/kg (Pay Fixed H₂)`);
    setTimeout(() => setRfqSuccessMsg(null), 4000);
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00FF95]/10 text-[#00FF95] rounded-lg border border-[#00FF95]/30 font-bold">
            🔄
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Commodity & Basis Swaps Desk</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#00FF95] border border-[#2A2E39] rounded">
                Bilateral ISDA / RhinoTrade Master Agreement
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Fixed/Floating Swaps, Cross-Commodity Spark Spreads, and Regional Basis Spreads</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Active Swap Notional</span>
            <span className="text-base font-bold text-[#FFFFFF]">7,000,000 kg</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">UK vs DE Basis</span>
            <span className="font-semibold text-[#FF4D4D]">-0.76 USDT/kg</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Green vs Blue Premium</span>
            <span className="font-semibold text-[#00FF95]">+2.21 USDT/kg</span>
          </div>
        </div>
      </div>

      {/* Main Swaps Overview & Basis Surface (8 cols) */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        {/* Active Commodity Swaps Table */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Active Portfolio Swaps</span>
            <span className="text-[10px] text-[#00FF95] font-mono">Bilateral Mark-to-Market</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Swap ID</th>
                  <th className="py-2.5 px-2">Structure Name</th>
                  <th className="py-2.5 px-2">Leg 1 (Fixed)</th>
                  <th className="py-2.5 px-2">Leg 2 (Reference)</th>
                  <th className="py-2.5 px-2 text-right">Notional (kg)</th>
                  <th className="py-2.5 px-2 text-right">Pv (USDT)</th>
                  <th className="py-2.5 px-2">Counterparty</th>
                </tr>
              </thead>
              <tbody>
                {swaps.map(sw => (
                  <tr key={sw.id} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition">
                    <td className="py-2 px-2 font-bold font-sans text-[#00FF95]">{sw.id}</td>
                    <td className="py-2 px-2 font-sans text-[#D1D4DC]">{sw.swapName}</td>
                    <td className="py-2 px-2 text-[#00FF95]">${sw.leg1RateUSDT.toFixed(2)} USDT</td>
                    <td className="py-2 px-2 text-[#848E9C]">{sw.leg2Reference} (${sw.leg2CurrentRateUSDT.toFixed(2)})</td>
                    <td className="py-2 px-2 text-right text-[#D1D4DC]">{sw.notionalKg.toLocaleString()}</td>
                    <td className={`py-2 px-2 text-right font-bold ${sw.pvUSDT >= 0 ? 'text-[#00FF95]' : 'text-[#FF4D4D]'}`}>
                      {sw.pvUSDT >= 0 ? '+' : ''}${sw.pvUSDT.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2 px-2 text-[#848E9C] font-sans">{sw.counterparty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Regional & Quality Basis Analytics */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-2 flex justify-between items-center">
            <span>Basis Spread History — {selectedBasis.pair}</span>
            <div className="flex gap-2">
              {basisSwaps.map(b => (
                <button
                  key={b.id}
                  onClick={() => setSelectedBasis(b)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono transition ${
                    selectedBasis.id === b.id
                      ? 'bg-[#1E222D] text-[#00FF95] border border-[#00FF95]/40 font-bold'
                      : 'bg-[#0B0E11] text-[#848E9C] border border-[#2A2E39] hover:text-[#D1D4DC]'
                  }`}
                >
                  {b.legA} / {b.legB}
                </button>
              ))}
            </div>
          </div>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={selectedBasis.historicalData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2E39" />
                <XAxis dataKey="time" stroke="#848E9C" tick={{ fontSize: 10 }} />
                <YAxis domain={['auto', 'auto']} stroke="#848E9C" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#131722', borderColor: '#2A2E39', color: '#FFFFFF', fontSize: '12px' }} />
                <Line type="monotone" dataKey="basis" stroke="#00FF95" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-4 gap-3 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
            <div>
              <span className="text-[#848E9C] block font-mono">Current Basis</span>
              <span className="font-bold text-[#FFFFFF]">${selectedBasis.currentBasisUSDT.toFixed(2)} USDT/kg</span>
            </div>
            <div>
              <span className="text-[#848E9C] block font-mono">30D Volatility</span>
              <span className="font-bold text-[#00FF95]">${selectedBasis.basisVol30d.toFixed(2)} USDT</span>
            </div>
            <div>
              <span className="text-[#848E9C] block font-mono">Historical Mean</span>
              <span className="font-bold text-[#D1D4DC]">${selectedBasis.historicalMean.toFixed(2)} USDT</span>
            </div>
            <div>
              <span className="text-[#848E9C] block font-mono">Z-Score Deviation</span>
              <span className="font-bold text-amber-400">{selectedBasis.zScore.toFixed(2)} σ</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Bilateral RFQ Generator (4 cols) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        <form onSubmit={handleRfqSubmit} className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Bilateral RFQ Desk</span>
            <span className="text-xs text-[#00FF95] font-mono">Request For Quote</span>
          </div>

          {rfqSuccessMsg && (
            <div className="p-2.5 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded text-xs text-[#00FF95] flex items-center gap-1.5 font-mono">
              <CheckCircle2 className="w-4 h-4 text-[#00FF95] shrink-0" />
              <span>{rfqSuccessMsg}</span>
            </div>
          )}

          <div className="flex flex-col gap-1 text-xs">
            <label className="text-[#848E9C] text-[11px] font-mono">Select Counterparty</label>
            <select
              value={rfqCounterparty}
              onChange={e => setRfqCounterparty(e.target.value)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#D1D4DC] rounded p-2 focus:outline-none focus:border-[#00FF95] font-mono"
            >
              <option value="BP Energy Trading & Shipping">BP Energy Trading & Shipping</option>
              <option value="Uniper Global Commodities SE">Uniper Global Commodities SE</option>
              <option value="Shell RFNBO Energy Desk">Shell RFNBO Energy Desk</option>
              <option value="TotalEnergies Gas & Power">TotalEnergies Gas & Power</option>
            </select>
          </div>

          <div className="flex flex-col gap-1 text-xs">
            <label className="text-[#848E9C] text-[11px] font-mono">Notional Volume (kg H₂)</label>
            <input
              type="number"
              step="100000"
              value={rfqNotionalKg}
              onChange={e => setRfqNotionalKg(e.target.value)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-2 font-mono focus:outline-none focus:border-[#00FF95]"
            />
          </div>

          <div className="flex flex-col gap-1 text-xs">
            <label className="text-[#848E9C] text-[11px] font-mono">Fixed Rate Quote (USDT/kg)</label>
            <input
              type="number"
              step="0.05"
              value={rfqFixedRate}
              onChange={e => setRfqFixedRate(e.target.value)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-2 font-mono focus:outline-none focus:border-[#00FF95]"
            />
          </div>

          <div className="bg-[#0B0E11] border border-[#2A2E39] rounded p-3 flex flex-col gap-1.5 text-xs font-mono">
            <div className="flex justify-between text-[#848E9C]">
              <span>Structure:</span>
              <span className="text-[#D1D4DC] font-sans font-semibold">Pay Fixed / Rec Floating Index</span>
            </div>
            <div className="flex justify-between text-[#848E9C]">
              <span>Floating Index:</span>
              <span className="text-[#00FF95] font-mono">RhinoTrade Green H2 UK</span>
            </div>
            <div className="flex justify-between text-[#848E9C]">
              <span>Settlement:</span>
              <span className="text-[#00FF95] font-sans">Monthly USDT Net Cash</span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-[#2962FF] hover:bg-[#2962FF]/90 text-white font-mono font-bold text-xs uppercase tracking-wider rounded shadow-[0_0_12px_rgba(41,98,255,0.3)] transition flex items-center justify-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            DISPATCH RFQ TO DESK
          </button>
        </form>
      </div>
    </div>
  );
};
