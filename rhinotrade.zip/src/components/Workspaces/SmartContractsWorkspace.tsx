import React, { useState } from 'react';
import { SmartContractSpec, SmartContractEvent, OracleNodeObservation, OracleConsensusResult } from '../../types';
import { ShieldCheck, Cpu, Code2, Layers, CheckCircle2, Lock, Radio } from 'lucide-react';

interface SmartContractsWorkspaceProps {
  contracts: SmartContractSpec[];
  events: SmartContractEvent[];
  oracleNodes: OracleNodeObservation[];
  oracleConsensus: OracleConsensusResult[];
}

export const SmartContractsWorkspace: React.FC<SmartContractsWorkspaceProps> = ({
  contracts,
  events,
  oracleNodes,
  oracleConsensus,
}) => {
  const [selectedContract, setSelectedContract] = useState<SmartContractSpec>(contracts[0]);
  const [activeSubTab, setActiveSubTab] = useState<'CONTRACTS' | 'EVENTS' | 'ORACLES'>('CONTRACTS');

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#2962FF]/10 text-[#2962FF] rounded-lg border border-[#2962FF]/30 font-bold">
            ⛓️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Smart Contract Architecture & Oracle Network</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#2962FF] border border-[#2A2E39] rounded">
                Solidity / Rust Programmable Settlement
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Escrow, Margin, Collateral Locking, Delivery Verification & Multi-Node Threshold Consensus</p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-[#0B0E11] p-1 rounded border border-[#2A2E39] text-xs font-mono">
          <button
            onClick={() => setActiveSubTab('CONTRACTS')}
            className={`px-3 py-1.5 rounded font-bold transition ${activeSubTab === 'CONTRACTS' ? 'bg-[#2962FF] text-white' : 'text-[#848E9C] hover:text-[#FFFFFF]'}`}
          >
            Smart Contracts ({contracts.length})
          </button>
          <button
            onClick={() => setActiveSubTab('EVENTS')}
            className={`px-3 py-1.5 rounded font-bold transition ${activeSubTab === 'EVENTS' ? 'bg-[#2962FF] text-white' : 'text-[#848E9C] hover:text-[#FFFFFF]'}`}
          >
            On-Chain Events ({events.length})
          </button>
          <button
            onClick={() => setActiveSubTab('ORACLES')}
            className={`px-3 py-1.5 rounded font-bold transition ${activeSubTab === 'ORACLES' ? 'bg-[#2962FF] text-white' : 'text-[#848E9C] hover:text-[#FFFFFF]'}`}
          >
            Oracle Network ({oracleNodes.length} Nodes)
          </button>
        </div>
      </div>

      {/* Main Content Area based on SubTab */}
      {activeSubTab === 'CONTRACTS' && (
        <>
          <div className="lg:col-span-7 bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
              <span>Deployed Programmable Commodity Contracts</span>
              <span className="text-[10px] text-[#2962FF] font-mono">RhinoChain Private L2 / Ethereum</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                    <th className="py-2.5 px-2">Contract Name</th>
                    <th className="py-2.5 px-2">Type</th>
                    <th className="py-2.5 px-2 text-right">Locked Collateral (USDT)</th>
                    <th className="py-2.5 px-2">Network</th>
                    <th className="py-2.5 px-2">Status</th>
                    <th className="py-2.5 px-2 text-center">Inspect</th>
                  </tr>
                </thead>
                <tbody>
                  {contracts.map(ct => (
                    <tr
                      key={ct.id}
                      className={`border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition ${
                        ct.id === selectedContract.id ? 'bg-[#1E222D] text-[#FFFFFF]' : 'text-[#D1D4DC]'
                      }`}
                    >
                      <td className="py-2 px-2 font-bold font-sans text-[#2962FF]">{ct.name}</td>
                      <td className="py-2 px-2 text-purple-400 font-mono">{ct.contractType}</td>
                      <td className="py-2 px-2 text-right font-bold text-[#00FF95]">
                        ${ct.lockedCollateralUSDT.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2 px-2 font-sans text-[#848E9C] text-[11px]">{ct.network}</td>
                      <td className="py-2 px-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30">
                          {ct.status}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-center">
                        <button
                          onClick={() => setSelectedContract(ct)}
                          className="px-2.5 py-0.5 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] border border-[#2A2E39] rounded text-[11px] font-mono transition"
                        >
                          Terms
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
            <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
              <span>Smart Contract Terms & State</span>
              <span className="text-xs font-mono text-[#2962FF]">{selectedContract.id}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
              <div className="col-span-2">
                <span className="text-[#848E9C] text-[10px] font-mono block">Contract Address</span>
                <span className="font-bold text-[#2962FF] text-[11px] truncate block">{selectedContract.address}</span>
              </div>
              <div>
                <span className="text-[#848E9C] text-[10px] font-mono block">Quantity Target</span>
                <span className="font-bold text-[#FFFFFF]">{selectedContract.terms.quantityKg.toLocaleString()} kg</span>
              </div>
              <div>
                <span className="text-[#848E9C] text-[10px] font-mono block">Agreed Price</span>
                <span className="font-bold text-[#00FF95]">{selectedContract.terms.pricePerKgUSDT.toFixed(2)} USDT/kg</span>
              </div>
              <div>
                <span className="text-[#848E9C] text-[10px] font-mono block">Required Purity Threshold</span>
                <span className="font-semibold text-[#00FF95]">{selectedContract.terms.purityThreshold}%</span>
              </div>
              <div>
                <span className="text-[#848E9C] text-[10px] font-mono block">Oracle Nodes Consensus</span>
                <span className="font-semibold text-purple-400">{selectedContract.terms.oracleConsensusRequired} Nodes Required</span>
              </div>
            </div>
          </div>
        </>
      )}

      {activeSubTab === 'EVENTS' && (
        <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>On-Chain Activity Event Log</span>
            <span className="text-[10px] text-[#2962FF] font-mono">Real-Time Blockchain Telemetry</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Block</th>
                  <th className="py-2.5 px-2">Event Name</th>
                  <th className="py-2.5 px-2">Tx Hash</th>
                  <th className="py-2.5 px-2">Timestamp</th>
                  <th className="py-2.5 px-2 font-sans">Event Details</th>
                </tr>
              </thead>
              <tbody>
                {events.map(evt => (
                  <tr key={evt.id} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition">
                    <td className="py-2 px-2 font-bold text-[#2962FF]">#{evt.blockNumber}</td>
                    <td className="py-2 px-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/10 text-purple-400 border border-purple-500/30">
                        {evt.eventName}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-[#848E9C] text-[11px] truncate max-w-[140px]">{evt.txHash}</td>
                    <td className="py-2 px-2 text-[#848E9C] text-[11px]">{evt.timestamp.slice(11, 19)}</td>
                    <td className="py-2 px-2 font-sans text-[#D1D4DC] text-[11px]">{evt.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSubTab === 'ORACLES' && (
        <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 flex flex-col gap-2">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-1 flex justify-between">
              <span>Oracle Node Telemetry Feed</span>
              <span className="text-[10px] text-[#00FF95] font-mono">Physical Sensors</span>
            </div>

            <div className="flex flex-col gap-1.5 font-mono text-xs">
              {oracleNodes.map(node => (
                <div key={node.nodeId} className="bg-[#0B0E11] p-2.5 rounded border border-[#2A2E39] flex justify-between items-center">
                  <div>
                    <span className="font-bold text-[#FFFFFF] font-sans block text-[11px]">{node.nodeName}</span>
                    <span className="text-[10px] text-[#848E9C] font-mono">{node.nodeId} • {node.sourceType}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-extrabold text-[#00FF95] text-sm">{node.value} {node.unit}</span>
                    <span className="text-[10px] text-purple-400 block font-mono">Confidence: {(node.confidenceScore * 100).toFixed(1)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 flex flex-col gap-2">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-1 flex justify-between">
              <span>Consensus Validation Results</span>
              <span className="text-[10px] text-purple-400 font-mono">Multi-Source Aggregation</span>
            </div>

            <div className="flex flex-col gap-2 font-mono text-xs">
              {oracleConsensus.map((res, i) => (
                <div key={i} className="bg-[#0B0E11] p-3 rounded border border-[#2A2E39] flex flex-col gap-1">
                  <div className="flex justify-between items-center font-sans">
                    <span className="font-bold text-[#FFFFFF]">{res.parameter}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30">
                      {res.status}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#848E9C] font-mono mt-1">
                    <span>Method: {res.method}</span>
                    <span className="font-bold text-[#00FF95]">Consensus Value: {res.consensusValue}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
