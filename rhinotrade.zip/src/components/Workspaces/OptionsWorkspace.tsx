import React, { useState } from 'react';
import { OptionContract, AccountWallet } from '../../types';
import { calculateBlackScholes, calculateBinomialTree } from '../../services/quantEngine';
import { Activity, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface OptionsWorkspaceProps {
  options: OptionContract[];
  wallet: AccountWallet;
}

export const OptionsWorkspace: React.FC<OptionsWorkspaceProps> = ({ options, wallet }) => {
  const [spotPrice, setSpotPrice] = useState<number>(6.82); // Q1 2027 underlying
  const [strikePrice, setStrikePrice] = useState<number>(7.00);
  const [timeToExpiry, setTimeToExpiry] = useState<number>(0.35); // years
  const [volatility, setVolatility] = useState<number>(0.285);
  const [convenienceYield, setConvenienceYield] = useState<number>(0.02);
  const [storageCost, setStorageCost] = useState<number>(0.05);
  const [riskFreeRate, setRiskFreeRate] = useState<number>(0.04);
  const [orderExecutedMsg, setOrderExecutedMsg] = useState<string | null>(null);

  // Black-Scholes valuation
  const bsResult = calculateBlackScholes({
    S: spotPrice,
    K: strikePrice,
    T: timeToExpiry,
    r: riskFreeRate,
    sigma: volatility,
    y: convenienceYield,
    u: storageCost,
  });

  // Binomial Tree valuation
  const treeResult = calculateBinomialTree({
    S: spotPrice,
    K: strikePrice,
    T: timeToExpiry,
    r: riskFreeRate,
    sigma: volatility,
    y: convenienceYield,
    u: storageCost,
  }, 40, true);

  const handleOptionTrade = (optType: 'CALL' | 'PUT', strike: number) => {
    setOrderExecutedMsg(`Executed ${optType} Option @ Strike ${strike.toFixed(2)} USDT (Premium: ${(optType === 'CALL' ? bsResult.callPrice : bsResult.putPrice).toFixed(2)} USDT/kg)`);
    setTimeout(() => setOrderExecutedMsg(null), 4000);
  };

  // Volatility Surface Grid Data
  const volSurfaceStrikes = [6.00, 6.50, 7.00, 7.50, 8.00];
  const volSurfaceExpiries = [30, 60, 90, 120, 180];

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00FF95]/10 text-[#00FF95] rounded-lg border border-[#00FF95]/30 font-bold">
            ⚡
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Hydrogen Options & Volatility Analytics</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#00FF95] border border-[#2A2E39] rounded">
                R Quantitative Engine
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">European & American Commodity Options with Storage Cost & Convenience Yield</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Underlying H₂ Futures</span>
            <span className="text-base font-bold text-[#FFFFFF]">$6.82 USDT/kg</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Storage Cost (u)</span>
            <span className="font-semibold text-purple-400">{(storageCost * 100).toFixed(1)}% p.a.</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Convenience Yield (y)</span>
            <span className="font-semibold text-[#00FF95]">{(convenienceYield * 100).toFixed(1)}% p.a.</span>
          </div>
        </div>
      </div>

      {/* Main Options Chain & Vol Surface (8 cols) */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        {/* Options Chain Table */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Option Chain — RH-H2-GREEN-UK-Q1-2027</span>
            <span className="text-[10px] text-[#848E9C] font-mono">Expiry: 15 Dec 2026</span>
          </div>

          {orderExecutedMsg && (
            <div className="mb-2 p-2.5 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded text-xs text-[#00FF95] flex items-center gap-1.5 font-mono">
              <CheckCircle2 className="w-4 h-4 text-[#00FF95] shrink-0" />
              <span>{orderExecutedMsg}</span>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase">
                  <th className="py-2 px-1 text-center bg-[#089981]/20 text-[#00FF95]" colSpan={4}>CALLS</th>
                  <th className="py-2 px-2 text-center bg-[#1E222D] text-[#FFFFFF]">STRIKE</th>
                  <th className="py-2 px-1 text-center bg-[#F23645]/20 text-[#FF4D4D]" colSpan={4}>PUTS</th>
                </tr>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]/50">
                  <th className="py-1 px-1 text-right">Bid</th>
                  <th className="py-1 px-1 text-right">Ask</th>
                  <th className="py-1 px-1 text-right">Delta</th>
                  <th className="py-1 px-1 text-center">Trade Call</th>
                  <th className="py-1 px-2 text-center font-bold text-[#FFFFFF]">USDT/kg</th>
                  <th className="py-1 px-1 text-center">Trade Put</th>
                  <th className="py-1 px-1 text-right">Delta</th>
                  <th className="py-1 px-1 text-right">Bid</th>
                  <th className="py-1 px-1 text-right">Ask</th>
                </tr>
              </thead>
              <tbody>
                {options.map(opt => (
                  <tr key={opt.id} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition">
                    {/* Call Side */}
                    <td className="py-2 px-1 text-right font-bold text-[#00FF95]">${opt.bid.toFixed(2)}</td>
                    <td className="py-2 px-1 text-right text-[#D1D4DC]">${opt.ask.toFixed(2)}</td>
                    <td className="py-2 px-1 text-right text-[#848E9C]">{opt.delta.toFixed(2)}</td>
                    <td className="py-2 px-1 text-center">
                      <button
                        onClick={() => handleOptionTrade('CALL', opt.strikeUSDT)}
                        className="px-2 py-0.5 bg-[#089981] hover:bg-[#089981]/90 text-white rounded text-[10px] font-mono font-bold transition"
                      >
                        BUY CALL
                      </button>
                    </td>

                    {/* Strike Center */}
                    <td className="py-2 px-2 text-center font-bold text-[#FFFFFF] bg-[#0B0E11]/80 border-x border-[#2A2E39]">
                      ${opt.strikeUSDT.toFixed(2)}
                    </td>

                    {/* Put Side */}
                    <td className="py-2 px-1 text-center">
                      <button
                        onClick={() => handleOptionTrade('PUT', opt.strikeUSDT)}
                        className="px-2 py-0.5 bg-[#F23645] hover:bg-[#F23645]/90 text-white rounded text-[10px] font-mono font-bold transition"
                      >
                        BUY PUT
                      </button>
                    </td>
                    <td className="py-2 px-1 text-right text-[#848E9C]">{opt.delta.toFixed(2)}</td>
                    <td className="py-2 px-1 text-right text-[#D1D4DC]">${opt.bid.toFixed(2)}</td>
                    <td className="py-2 px-1 text-right font-bold text-[#FF4D4D]">${opt.ask.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Volatility Surface Matrix */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Hydrogen Implied Volatility Surface (%)</span>
            <span className="text-[10px] text-[#00FF95] font-mono">Smile & Term Structure Matrix</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-1 px-2 text-left">Tenor (Days)</th>
                  {volSurfaceStrikes.map(st => (
                    <th key={st} className="py-1 px-2">K = ${st.toFixed(2)}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {volSurfaceExpiries.map(days => (
                  <tr key={days} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/40">
                    <td className="py-2 px-2 text-left font-bold text-[#FFFFFF] font-sans">{days} Days</td>
                    {volSurfaceStrikes.map(st => {
                      const moneyness = st / spotPrice;
                      const iv = 26.0 + Math.abs(1.0 - moneyness) * 45.0 + (days / 180) * 4.0;
                      return (
                        <td key={st} className="py-2 px-2">
                          <span className="px-2 py-0.5 rounded font-bold bg-[#1E222D] text-[#00FF95] border border-[#00FF95]/30">
                            {iv.toFixed(1)}%
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Quantitative Options Pricer (4 cols) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        {/* Pricer Form */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>R Quant Pricer</span>
            <span className="text-xs text-[#00FF95] font-mono">Black-Scholes / Tree</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="text-[#848E9C] text-[10px] font-mono block mb-1">Spot Price (S)</label>
              <input
                type="number"
                step="0.05"
                value={spotPrice}
                onChange={e => setSpotPrice(parseFloat(e.target.value) || 6.82)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-1.5 font-mono focus:outline-none focus:border-[#00FF95]"
              />
            </div>
            <div>
              <label className="text-[#848E9C] text-[10px] font-mono block mb-1">Strike Price (K)</label>
              <input
                type="number"
                step="0.05"
                value={strikePrice}
                onChange={e => setStrikePrice(parseFloat(e.target.value) || 7.00)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-1.5 font-mono focus:outline-none focus:border-[#00FF95]"
              />
            </div>
            <div>
              <label className="text-[#848E9C] text-[10px] font-mono block mb-1">Expiry (Years)</label>
              <input
                type="number"
                step="0.05"
                value={timeToExpiry}
                onChange={e => setTimeToExpiry(parseFloat(e.target.value) || 0.35)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-1.5 font-mono focus:outline-none focus:border-[#00FF95]"
              />
            </div>
            <div>
              <label className="text-[#848E9C] text-[10px] font-mono block mb-1">Volatility (σ)</label>
              <input
                type="number"
                step="0.01"
                value={volatility}
                onChange={e => setVolatility(parseFloat(e.target.value) || 0.285)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-1.5 font-mono focus:outline-none focus:border-[#00FF95]"
              />
            </div>
            <div>
              <label className="text-[#848E9C] text-[10px] font-mono block mb-1">Storage Cost (u)</label>
              <input
                type="number"
                step="0.01"
                value={storageCost}
                onChange={e => setStorageCost(parseFloat(e.target.value) || 0.05)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-1.5 font-mono focus:outline-none focus:border-[#00FF95]"
              />
            </div>
            <div>
              <label className="text-[#848E9C] text-[10px] font-mono block mb-1">Convenience Yield (y)</label>
              <input
                type="number"
                step="0.01"
                value={convenienceYield}
                onChange={e => setConvenienceYield(parseFloat(e.target.value) || 0.02)}
                className="w-full bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-1.5 font-mono focus:outline-none focus:border-[#00FF95]"
              />
            </div>
          </div>

          {/* Pricing Model Output */}
          <div className="bg-[#0B0E11] border border-[#2A2E39] rounded p-3 flex flex-col gap-2 font-mono text-xs">
            <div className="flex justify-between border-b border-[#2A2E39] pb-1">
              <span className="text-[#848E9C] font-mono">European Call (Black-Scholes):</span>
              <span className="font-bold text-[#00FF95]">${bsResult.callPrice.toFixed(3)} USDT</span>
            </div>
            <div className="flex justify-between border-b border-[#2A2E39] pb-1">
              <span className="text-[#848E9C] font-mono">European Put (Black-Scholes):</span>
              <span className="font-bold text-[#FF4D4D]">${bsResult.putPrice.toFixed(3)} USDT</span>
            </div>
            <div className="flex justify-between border-b border-[#2A2E39] pb-1">
              <span className="text-[#848E9C] font-mono">American Call (Binomial Tree):</span>
              <span className="font-bold text-[#00FF95]">${treeResult.callPrice.toFixed(3)} USDT</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#848E9C] font-mono">American Put (Binomial Tree):</span>
              <span className="font-bold text-[#FF4D4D]">${treeResult.putPrice.toFixed(3)} USDT</span>
            </div>
          </div>

          {/* Greeks Summary */}
          <div className="bg-[#0B0E11] border border-[#2A2E39] rounded p-3 flex flex-col gap-1.5 text-xs font-mono">
            <div className="font-bold text-[#FFFFFF] font-sans border-b border-[#2A2E39] pb-1">Risk Greeks</div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div><span className="text-[#848E9C]">Delta Call:</span> <span className="text-[#FFFFFF] font-bold">{bsResult.deltaCall.toFixed(3)}</span></div>
              <div><span className="text-[#848E9C]">Gamma:</span> <span className="text-[#FFFFFF] font-bold">{bsResult.gamma.toFixed(3)}</span></div>
              <div><span className="text-[#848E9C]">Theta Call:</span> <span className="text-[#FFFFFF] font-bold">{bsResult.thetaCall.toFixed(4)}</span></div>
              <div><span className="text-[#848E9C]">Vega:</span> <span className="text-[#FFFFFF] font-bold">{bsResult.vega.toFixed(3)}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
