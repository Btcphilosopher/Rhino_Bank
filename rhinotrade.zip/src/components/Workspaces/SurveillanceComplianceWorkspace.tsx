import React, { useState } from 'react';
import { SurveillanceAlert, ComplianceProfile } from '../../types';
import { ShieldCheck, AlertTriangle, Eye, FileCheck, CheckCircle2, Lock } from 'lucide-react';

interface SurveillanceComplianceWorkspaceProps {
  alerts: SurveillanceAlert[];
  compliance: ComplianceProfile;
}

export const SurveillanceComplianceWorkspace: React.FC<SurveillanceComplianceWorkspaceProps> = ({ alerts, compliance }) => {
  const [selectedAlert, setSelectedAlert] = useState<SurveillanceAlert>(alerts[0]);
  const [alertState, setAlertState] = useState<SurveillanceAlert[]>(alerts);

  const handleAlertStatus = (alertId: string, newStatus: SurveillanceAlert['status']) => {
    setAlertState(prev => prev.map(a => a.id === alertId ? { ...a, status: newStatus } : a));
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#FF4D4D]/10 text-[#FF4D4D] rounded-lg border border-[#FF4D4D]/30 font-bold">
            🛡️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Market Surveillance & Regulatory Compliance</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#FF4D4D] border border-[#2A2E39] rounded">
                Institutional Risk & Audit Engine
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Spoofing/Layering Detection, Wash Trading Flags, Position Limits & Cross-Border Sanctions</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Surveillance Status</span>
            <span className="text-base font-bold text-[#00FF95]">Monitoring Active</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Jurisdiction</span>
            <span className="font-semibold text-[#00FF95]">{compliance.jurisdiction}</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Spot Limit Utilization</span>
            <span className="font-semibold text-[#FFFFFF]">
              {((compliance.currentSpotPositionKg / compliance.spotPositionLimitKg) * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Main Surveillance Alerts Table (7 cols) */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Market Integrity Surveillance Alerts</span>
            <span className="text-[10px] text-[#FF4D4D] font-mono">Automated Detection</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Alert ID</th>
                  <th className="py-2.5 px-2">Timestamp</th>
                  <th className="py-2.5 px-2">Indicator</th>
                  <th className="py-2.5 px-2">Severity</th>
                  <th className="py-2.5 px-2">Status</th>
                  <th className="py-2.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {alertState.map(al => (
                  <tr
                    key={al.id}
                    className={`border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition ${
                      al.id === selectedAlert.id ? 'bg-[#1E222D] text-[#FFFFFF]' : 'text-[#D1D4DC]'
                    }`}
                  >
                    <td className="py-2 px-2 font-bold font-sans text-[#FF4D4D]">{al.id}</td>
                    <td className="py-2 px-2 text-[#848E9C] text-[11px]">{al.timestamp.slice(11, 19)}</td>
                    <td className="py-2 px-2 font-sans font-semibold text-[#FFFFFF]">{al.indicator}</td>
                    <td className="py-2 px-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        al.severity === 'HIGH' || al.severity === 'CRITICAL'
                          ? 'bg-[#FF4D4D]/10 text-[#FF4D4D] border border-[#FF4D4D]/30'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}>
                        {al.severity}
                      </span>
                    </td>
                    <td className="py-2 px-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-[#1E222D] text-[#D1D4DC] border border-[#2A2E39]">
                        {al.status}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-center">
                      <button
                        onClick={() => setSelectedAlert(al)}
                        className="px-2.5 py-0.5 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] border border-[#2A2E39] rounded text-[11px] font-mono transition"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Alert Inspector & Regulatory Profile (5 cols) */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Selected Alert Details */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Alert Audit Inspector</span>
            <span className="text-xs font-mono text-[#FF4D4D]">{selectedAlert.id}</span>
          </div>

          <div className="bg-[#0B0E11] p-3 rounded border border-[#2A2E39] flex flex-col gap-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-[#848E9C] font-mono">Pattern Indicator:</span>
              <span className="font-bold text-[#FF4D4D]">{selectedAlert.indicator}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#848E9C] font-mono">Instrument:</span>
              <span className="font-bold text-[#FFFFFF]">{selectedAlert.instrument}</span>
            </div>
            <div className="flex justify-between border-t border-[#2A2E39] pt-2">
              <span className="text-[#848E9C] font-mono block mb-1">Algorithmic Evidence:</span>
            </div>
            <p className="font-sans text-[#D1D4DC] text-[11px] leading-relaxed bg-[#131722] p-2 rounded border border-[#2A2E39]">
              {selectedAlert.details}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 font-mono">
            <button
              onClick={() => handleAlertStatus(selectedAlert.id, 'DISMISSED')}
              className="py-2 bg-[#1E222D] hover:bg-[#2A2E39] text-[#D1D4DC] font-bold text-xs uppercase rounded transition border border-[#2A2E39]"
            >
              DISMISS ALERT
            </button>
            <button
              onClick={() => handleAlertStatus(selectedAlert.id, 'ESCALATED')}
              className="py-2 bg-[#FF4D4D] hover:bg-[#FF4D4D]/90 text-white font-bold text-xs uppercase rounded transition"
            >
              ESCALATE TO FCA / ACER
            </button>
          </div>
        </div>

        {/* Regulatory Profile & Position Limits */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Institutional Compliance Profile</span>
            <span className="text-xs text-[#00FF95] font-mono">Verified</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">KYC Status</span>
              <span className="font-bold text-[#00FF95]">{compliance.kycStatus}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">KYB Legal Entity</span>
              <span className="font-bold text-[#00FF95]">{compliance.kybStatus}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Sanctions Screening</span>
              <span className="font-bold text-[#00FF95]">{compliance.sanctionsCheck}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Travel Rule</span>
              <span className="font-bold text-[#00FF95]">{compliance.travelRuleStatus}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
