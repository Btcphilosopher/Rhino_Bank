import React, { useState } from 'react';
import { AccountWallet, LedgerEntry, UsdtTransaction, UsdtNetwork } from '../../types';
import { Wallet, ArrowUpRight, ArrowDownLeft, ShieldCheck, RefreshCw, AlertTriangle, CheckCircle2, Lock } from 'lucide-react';

interface UsdtWalletWorkspaceProps {
  wallet: AccountWallet;
  ledger: LedgerEntry[];
  transactions: UsdtTransaction[];
  onDeposit: (amount: number, network: UsdtNetwork, address: string) => void;
  onAdvanceTx: (txId: string) => void;
  onWithdraw: (amount: number, network: UsdtNetwork, address: string) => void;
  usdtBasis: {
    usdtUsd: { price: number; reference: number; spreadPercent: number; liquidityUSD: string };
    usdtEur: { price: number; reference: number; spreadPercent: number; liquidityEUR: string };
    usdtGbp: { price: number; reference: number; spreadPercent: number; liquidityGBP: string };
  };
}

export const UsdtWalletWorkspace: React.FC<UsdtWalletWorkspaceProps> = ({
  wallet,
  ledger,
  transactions,
  onDeposit,
  onAdvanceTx,
  onWithdraw,
  usdtBasis,
}) => {
  const [modalType, setModalType] = useState<'DEPOSIT' | 'WITHDRAW' | null>(null);
  const [network, setNetwork] = useState<UsdtNetwork>('Ethereum (ERC-20)');
  const [amountInput, setAmountInput] = useState<string>('100000');
  const [addressInput, setAddressInput] = useState<string>('0x71C7656EC7ab88b098defB751B7401B5f6d8976F');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountInput);
    if (!amt || amt <= 0) return;

    onDeposit(amt, network, addressInput);
    setModalType(null);
    setSuccessMsg(`Initiated USDT Deposit of ${amt.toLocaleString()} USDT via ${network}`);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountInput);
    if (!amt || amt <= 0) return;

    onWithdraw(amt, network, addressInput);
    setModalType(null);
    setSuccessMsg(`Initiated USDT Withdrawal Request of ${amt.toLocaleString()} USDT to ${addressInput.slice(0, 10)}...`);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Wallet Balance Cards (12 cols) */}
      <div className="lg:col-span-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs text-[#848E9C] font-mono">
            <span>NET LIQUIDATION VALUE</span>
            <Wallet className="w-4 h-4 text-[#00FF95]" />
          </div>
          <div className="font-mono text-xl font-extrabold text-[#FFFFFF] mt-2">
            ${wallet.netLiquidationValueUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-[#00FF95] mt-1 flex items-center gap-1 font-mono">
            <span>Leverage Ratio:</span>
            <span className="font-bold">{wallet.leverageRatio}x</span>
          </div>
        </div>

        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs text-[#848E9C] font-mono">
            <span>USDT SETTLEMENT BALANCE</span>
            <span className="px-1.5 py-0.5 rounded bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30 text-[10px] font-mono font-bold">USDT</span>
          </div>
          <div className="font-mono text-xl font-extrabold text-[#00FF95] mt-2">
            {wallet.balances.USDT.toLocaleString('en-US', { minimumFractionDigits: 2 })} USDT
          </div>
          <div className="text-[10px] text-[#848E9C] mt-1 flex justify-between font-mono">
            <span>Available: {wallet.available.USDT.toLocaleString()} USDT</span>
            <span className="text-amber-400">Locked: {wallet.marginLocked.USDT.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs text-[#848E9C] font-mono">
            <span>USD CASH BALANCE</span>
            <span className="text-[#848E9C] font-mono">$</span>
          </div>
          <div className="font-mono text-xl font-extrabold text-[#FFFFFF] mt-2">
            ${wallet.balances.USD.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-[#848E9C] mt-1 font-mono">
            Available: ${wallet.available.USD.toLocaleString()} USD
          </div>
        </div>

        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs text-[#848E9C] font-mono">
            <span>USDT SETTLEMENT ENGINE</span>
            <button
              onClick={() => setModalType('DEPOSIT')}
              className="px-2 py-0.5 bg-[#00FF95]/20 text-[#00FF95] border border-[#00FF95]/40 hover:bg-[#00FF95]/30 rounded text-[11px] font-mono font-bold transition"
            >
              + DEPOSIT
            </button>
          </div>
          <div className="flex items-center gap-2 mt-2 font-mono">
            <button
              onClick={() => setModalType('DEPOSIT')}
              className="flex-1 py-1.5 bg-[#00FF95] hover:bg-[#00FF95]/90 text-black rounded font-bold text-xs uppercase flex items-center justify-center gap-1 shadow transition"
            >
              <ArrowDownLeft className="w-3.5 h-3.5" /> DEPOSIT USDT
            </button>
            <button
              onClick={() => setModalType('WITHDRAW')}
              className="flex-1 py-1.5 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] border border-[#2A2E39] rounded font-bold text-xs uppercase flex items-center justify-center gap-1 transition"
            >
              <ArrowUpRight className="w-3.5 h-3.5" /> WITHDRAW
            </button>
          </div>
        </div>
      </div>

      {/* Center Column: USDT Deposit / Withdrawal Activity & Ledger (8 cols) */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        {successMsg && (
          <div className="p-3 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded-lg text-xs text-[#00FF95] flex items-center gap-2 font-mono">
            <CheckCircle2 className="w-4 h-4 text-[#00FF95] shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* USDT On-Chain Activity Table */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3 flex flex-col gap-2">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-1 flex justify-between items-center">
            <span>USDT On-Chain Deposit & Withdrawal Pipeline</span>
            <span className="text-[10px] text-[#00FF95] font-mono">Multi-Chain Adapters</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Tx ID</th>
                  <th className="py-2.5 px-2">Type</th>
                  <th className="py-2.5 px-2">Network</th>
                  <th className="py-2.5 px-2 text-right">Amount (USDT)</th>
                  <th className="py-2.5 px-2 text-center">Confirmations</th>
                  <th className="py-2.5 px-2">Status</th>
                  <th className="py-2.5 px-2 text-center">Simulate Next Step</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map(tx => (
                  <tr key={tx.id} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition">
                    <td className="py-2 px-2 font-bold font-sans text-[#00FF95]">{tx.id}</td>
                    <td className="py-2 px-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                        tx.type === 'DEPOSIT' ? 'bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30' : 'bg-[#FF4D4D]/10 text-[#FF4D4D] border border-[#FF4D4D]/30'
                      }`}>
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-2 px-2 font-sans text-[#D1D4DC]">{tx.network}</td>
                    <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">{tx.amount.toLocaleString()}</td>
                    <td className="py-2 px-2 text-center font-bold text-[#D1D4DC]">
                      {tx.confirmations} / {tx.requiredConfirmations}
                    </td>
                    <td className="py-2 px-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        tx.status === 'CREDITED' || tx.status === 'CONFIRMED' || tx.status === 'DISPATCHED'
                          ? 'bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-center">
                      {tx.status !== 'CREDITED' && tx.status !== 'DISPATCHED' ? (
                        <button
                          onClick={() => onAdvanceTx(tx.id)}
                          className="px-2 py-0.5 bg-[#1E222D] hover:bg-[#2A2E39] text-[#00FF95] border border-[#2A2E39] rounded text-[10px] font-mono flex items-center justify-center gap-1 mx-auto transition"
                        >
                          <RefreshCw className="w-3 h-3" /> Advance Confirmation
                        </button>
                      ) : (
                        <span className="text-[#848E9C] text-[10px]">Complete</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Double-Entry Ledger Entries */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>RhinoTrade Audit Double-Entry Accounting Ledger</span>
            <span className="text-[10px] text-[#848E9C] font-mono">Immutable Log</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Entry Ref</th>
                  <th className="py-2.5 px-2">Timestamp</th>
                  <th className="py-2.5 px-2">Type</th>
                  <th className="py-2.5 px-2">Currency</th>
                  <th className="py-2.5 px-2 text-right">Amount</th>
                  <th className="py-2.5 px-2 font-sans">Description</th>
                  <th className="py-2.5 px-2 text-right">Balance After</th>
                </tr>
              </thead>
              <tbody>
                {ledger.map(entry => (
                  <tr key={entry.id} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition">
                    <td className="py-2 px-2 font-bold text-[#D1D4DC]">{entry.id}</td>
                    <td className="py-2 px-2 text-[#848E9C] text-[11px]">{entry.timestamp.slice(11, 19)}</td>
                    <td className="py-2 px-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                        entry.entryType === 'CREDIT' ? 'bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30' : 'bg-[#FF4D4D]/10 text-[#FF4D4D] border border-[#FF4D4D]/30'
                      }`}>
                        {entry.entryType}
                      </span>
                    </td>
                    <td className="py-2 px-2 font-bold text-[#FFFFFF]">{entry.currency}</td>
                    <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">{entry.amount.toLocaleString()}</td>
                    <td className="py-2 px-2 font-sans text-[#D1D4DC] text-[11px] truncate max-w-[240px]">{entry.description}</td>
                    <td className="py-2 px-2 text-right font-bold text-[#00FF95]">{entry.balanceAfter.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: USDT Basis Monitor & Deposit/Withdrawal Modal (4 cols) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        {/* USDT Basis Monitor */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>USDT Stablecoin Basis Monitor</span>
            <span className="text-xs text-[#00FF95] font-mono">Live Peg</span>
          </div>

          <div className="flex flex-col gap-2 font-mono text-xs">
            <div className="bg-[#0B0E11] p-2.5 rounded border border-[#2A2E39] flex justify-between items-center">
              <div>
                <span className="text-[#848E9C] font-mono block text-[11px]">USDT / USD Basis</span>
                <span className="font-bold text-[#FFFFFF]">{usdtBasis.usdtUsd.price.toFixed(4)} USD</span>
              </div>
              <span className="text-[#00FF95] font-bold">{usdtBasis.usdtUsd.spreadPercent}%</span>
            </div>

            <div className="bg-[#0B0E11] p-2.5 rounded border border-[#2A2E39] flex justify-between items-center">
              <div>
                <span className="text-[#848E9C] font-mono block text-[11px]">USDT / EUR Basis</span>
                <span className="font-bold text-[#FFFFFF]">{usdtBasis.usdtEur.price.toFixed(4)} EUR</span>
              </div>
              <span className="text-[#00FF95] font-bold">{usdtBasis.usdtEur.spreadPercent}%</span>
            </div>

            <div className="bg-[#0B0E11] p-2.5 rounded border border-[#2A2E39] flex justify-between items-center">
              <div>
                <span className="text-[#848E9C] font-mono block text-[11px]">USDT / GBP Basis</span>
                <span className="font-bold text-[#FFFFFF]">{usdtBasis.usdtGbp.price.toFixed(4)} GBP</span>
              </div>
              <span className="text-[#00FF95] font-bold">+{usdtBasis.usdtGbp.spreadPercent}%</span>
            </div>
          </div>
        </div>

        {/* Action Modal Form when Deposit / Withdraw clicked */}
        {modalType && (
          <form
            onSubmit={modalType === 'DEPOSIT' ? handleDepositSubmit : handleWithdrawSubmit}
            className="bg-[#131722] border border-[#00FF95]/60 rounded-lg p-4 flex flex-col gap-3 shadow-xl font-mono"
          >
            <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
              <span>{modalType} USDT</span>
              <button type="button" onClick={() => setModalType(null)} className="text-[#848E9C] hover:text-[#FFFFFF]">✕</button>
            </div>

            <div className="flex flex-col gap-1 text-xs">
              <label className="text-[#848E9C] font-mono">Select Blockchain Network</label>
              <select
                value={network}
                onChange={e => setNetwork(e.target.value as UsdtNetwork)}
                className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-2 font-mono focus:outline-none focus:border-[#00FF95]"
              >
                <option value="Ethereum (ERC-20)">Ethereum (ERC-20)</option>
                <option value="Tron (TRC-20)">Tron (TRC-20)</option>
                <option value="Solana (SPL)">Solana (SPL)</option>
                <option value="Polygon (POS)">Polygon (POS)</option>
                <option value="RhinoChain Sandbox">RhinoChain Sandbox (Instant)</option>
              </select>
            </div>

            <div className="flex flex-col gap-1 text-xs">
              <label className="text-[#848E9C] font-mono">Amount (USDT)</label>
              <input
                type="number"
                step="1000"
                value={amountInput}
                onChange={e => setAmountInput(e.target.value)}
                className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] font-mono rounded p-2 focus:outline-none focus:border-[#00FF95]"
              />
            </div>

            <div className="flex flex-col gap-1 text-xs">
              <label className="text-[#848E9C] font-mono">
                {modalType === 'DEPOSIT' ? 'Deposit Wallet Address' : 'Destination Wallet Address'}
              </label>
              <input
                type="text"
                value={addressInput}
                onChange={e => setAddressInput(e.target.value)}
                className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] font-mono rounded p-2 focus:outline-none focus:border-[#00FF95] text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#00FF95] hover:bg-[#00FF95]/90 text-black font-mono font-bold text-xs uppercase tracking-wider rounded shadow transition"
            >
              SUBMIT {modalType} TRANSACTION
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
