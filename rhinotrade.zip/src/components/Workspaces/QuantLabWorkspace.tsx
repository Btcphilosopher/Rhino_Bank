import React, { useState } from 'react';
import { BacktestResult, RiskMetrics } from '../../types';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, AreaChart, Area } from 'recharts';
import { Play, Cpu, RefreshCw, AlertTriangle, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { runMonteCarloSimulations } from '../../services/quantEngine';

interface QuantLabWorkspaceProps {
  backtest: BacktestResult;
  risk: RiskMetrics;
}

export const QuantLabWorkspace: React.FC<QuantLabWorkspaceProps> = ({ backtest, risk }) => {
  const [strategyName, setStrategyName] = useState<string>('Green H₂ Contango Roll & Location Arb');
  const [initialCapital, setInitialCapital] = useState<number>(10000000);
  const [backtestRunning, setBacktestRunning] = useState<boolean>(false);
  const [customBacktest, setCustomBacktest] = useState<BacktestResult>(backtest);
  const [stressScenario, setStressScenario] = useState<string>('electricityPlus30');

  // Monte Carlo simulation output
  const mcResult = runMonteCarloSimulations(risk.netLiquidationValueUSD, 0.28, 10, 1000);

  const handleRunBacktest = () => {
    setBacktestRunning(true);
    setTimeout(() => {
      const returnPct = 18.5 + (Math.random() * 12.0);
      const finalCap = initialCapital * (1 + returnPct / 100);
      setCustomBacktest({
        ...backtest,
        strategyName,
        initialCapitalUSD: initialCapital,
        finalCapitalUSD: finalCap,
        totalReturnPercent: parseFloat(returnPct.toFixed(1)),
        sharpeRatio: parseFloat((2.1 + Math.random() * 0.8).toFixed(2)),
        sortinoRatio: parseFloat((2.8 + Math.random() * 0.9).toFixed(2)),
        maxDrawdownPercent: parseFloat((-3.5 - Math.random() * 3.0).toFixed(1)),
      });
      setBacktestRunning(false);
    }, 1200);
  };

  const getScenarioLossUSD = (): number => {
    switch (stressScenario) {
      case 'electricityPlus30': return risk.stressTestLosses.electricityPlus30;
      case 'gasPlus50': return risk.stressTestLosses.gasPlus50;
      case 'carbonPlus100': return risk.stressTestLosses.carbonPlus100;
      case 'h2SupplyOutage20': return risk.stressTestLosses.h2SupplyOutage20;
      case 'usdtDepeg1': return risk.stressTestLosses.usdtDepeg1;
      default: return 0;
    }
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00FF95]/10 text-[#00FF95] rounded-lg border border-[#00FF95]/30 font-bold">
            🧪
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">RhinoTrade Strategy & Quantitative Risk Lab</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#00FF95] border border-[#2A2E39] rounded">
                R Quantitative Engine (data.table / quantmod / Rcpp)
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Backtest Calendar Spreads, Green Premium Arbitrage, and Macro Scenario Stress Testing</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Sharpe Ratio</span>
            <span className="text-base font-bold text-[#00FF95]">{customBacktest.sharpeRatio}</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Sortino Ratio</span>
            <span className="font-semibold text-purple-400">{customBacktest.sortinoRatio}</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Max Drawdown</span>
            <span className="font-semibold text-[#FF4D4D]">{customBacktest.maxDrawdownPercent}%</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Win Rate</span>
            <span className="font-semibold text-[#00FF95]">{customBacktest.winRatePercent}%</span>
          </div>
        </div>
      </div>

      {/* Main Backtest Equity Curve & Monte Carlo (8 cols) */}
      <div className="lg:col-span-8 flex flex-col gap-4">
        {/* Equity Curve Chart */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 h-72 flex flex-col">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 flex justify-between items-center">
            <span>Backtest Equity Performance vs Benchmark ($)</span>
            <span className="text-[10px] text-[#00FF95] font-mono">Total Return: +{customBacktest.totalReturnPercent}%</span>
          </div>

          <div className="flex-1 w-full h-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={customBacktest.equityCurve} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="equityColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00FF95" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#00FF95" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2E39" />
                <XAxis dataKey="date" stroke="#848E9C" tick={{ fontSize: 10 }} />
                <YAxis domain={['auto', 'auto']} stroke="#848E9C" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#131722', borderColor: '#2A2E39', color: '#FFFFFF', fontSize: '12px' }} />
                <Area type="monotone" dataKey="equity" stroke="#00FF95" strokeWidth={2} fill="url(#equityColor)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Macro Scenario Stress Test Engine */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] border-b border-[#2A2E39] pb-2 flex justify-between items-center">
            <span>Portfolio Macro Scenario Engine</span>
            <span className="text-[10px] text-amber-400 font-mono">Stress Testing</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {[
              { id: 'electricityPlus30', label: 'Electricity Price +30%', loss: risk.stressTestLosses.electricityPlus30 },
              { id: 'gasPlus50', label: 'Natural Gas +50%', loss: risk.stressTestLosses.gasPlus50 },
              { id: 'carbonPlus100', label: 'Carbon ETS +100%', loss: risk.stressTestLosses.carbonPlus100 },
              { id: 'h2SupplyOutage20', label: 'H₂ Supply Outage -20%', loss: risk.stressTestLosses.h2SupplyOutage20 },
              { id: 'usdtDepeg1', label: 'USDT/USD Depeg -1%', loss: risk.stressTestLosses.usdtDepeg1 },
            ].map(sc => (
              <button
                key={sc.id}
                onClick={() => setStressScenario(sc.id)}
                className={`p-2.5 rounded text-left transition border flex flex-col justify-between ${
                  stressScenario === sc.id
                    ? 'bg-[#1E222D] border-amber-500/80 text-[#FFFFFF]'
                    : 'bg-[#0B0E11] border-[#2A2E39] hover:bg-[#1E222D]/50 text-[#848E9C]'
                }`}
              >
                <span className="text-[11px] font-mono font-semibold">{sc.label}</span>
                <span className={`text-xs font-mono font-bold mt-1 ${sc.loss >= 0 ? 'text-[#00FF95]' : 'text-[#FF4D4D]'}`}>
                  {sc.loss >= 0 ? '+' : ''}${sc.loss.toLocaleString()}
                </span>
              </button>
            ))}
          </div>

          <div className="bg-[#0B0E11] p-3 rounded border border-[#2A2E39] flex justify-between items-center text-xs font-mono">
            <div>
              <span className="text-[#848E9C] font-mono block text-[11px]">Selected Stress Test Impact:</span>
              <span className="font-bold text-[#FFFFFF]">{stressScenario}</span>
            </div>
            <div className="text-right">
              <span className="text-[#848E9C] font-mono block text-[11px]">Simulated Portfolio P&L:</span>
              <span className={`font-extrabold text-sm ${getScenarioLossUSD() >= 0 ? 'text-[#00FF95]' : 'text-[#FF4D4D]'}`}>
                {getScenarioLossUSD() >= 0 ? '+' : ''}${getScenarioLossUSD().toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Strategy Backtester Controls (4 cols) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Backtest Configuration</span>
            <span className="text-xs text-purple-400 font-mono">Rcpp Engine</span>
          </div>

          <div className="flex flex-col gap-1 text-xs">
            <label className="text-[#848E9C] font-mono">Strategy Model</label>
            <select
              value={strategyName}
              onChange={e => setStrategyName(e.target.value)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#D1D4DC] rounded p-2 font-mono text-xs focus:outline-none focus:border-[#00FF95]"
            >
              <option value="Green H₂ Contango Roll & Location Arb">Green H₂ Contango Roll & Location Arb</option>
              <option value="Statistical Arbitrage Green vs Blue H₂">Statistical Arbitrage Green vs Blue H₂</option>
              <option value="Options Delta-Neutral Volatility Harvesting">Options Delta-Neutral Volatility Harvesting</option>
              <option value="Spark-Spread Hydrogen vs Power Mean Reversion">Spark-Spread Hydrogen vs Power Mean Reversion</option>
            </select>
          </div>

          <div className="flex flex-col gap-1 text-xs">
            <label className="text-[#848E9C] font-mono">Initial Capital (USD)</label>
            <input
              type="number"
              step="1000000"
              value={initialCapital}
              onChange={e => setInitialCapital(parseFloat(e.target.value) || 10000000)}
              className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] font-mono rounded p-2 focus:outline-none focus:border-[#00FF95]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Sharpe Ratio</span>
              <span className="font-bold text-[#00FF95]">{customBacktest.sharpeRatio}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Sortino Ratio</span>
              <span className="font-bold text-purple-400">{customBacktest.sortinoRatio}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Total Return</span>
              <span className="font-bold text-[#00FF95]">+{customBacktest.totalReturnPercent}%</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Max Drawdown</span>
              <span className="font-bold text-[#FF4D4D]">{customBacktest.maxDrawdownPercent}%</span>
            </div>
          </div>

          <button
            onClick={handleRunBacktest}
            disabled={backtestRunning}
            className="w-full py-2.5 bg-[#2962FF] hover:bg-[#2962FF]/90 disabled:bg-[#1E222D] text-white font-mono font-bold text-xs uppercase tracking-wider rounded shadow-[0_0_12px_rgba(41,98,255,0.3)] transition flex items-center justify-center gap-1.5"
          >
            {backtestRunning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {backtestRunning ? 'RUNNING BACKTEST...' : 'EXECUTE R QUANT BACKTEST'}
          </button>
        </div>
      </div>
    </div>
  );
};
