import React, { useState } from 'react';
import { AccountWallet, RiskMetrics } from '../../types';
import { ShieldCheck, AlertTriangle, Activity, PieChart, Layers, Wallet, CheckCircle2 } from 'lucide-react';

interface PortfolioRiskWorkspaceProps {
  wallet: AccountWallet;
  risk: RiskMetrics;
}

export const PortfolioRiskWorkspace: React.FC<PortfolioRiskWorkspaceProps> = ({ wallet, risk }) => {
  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00FF95]/10 text-[#00FF95] rounded-lg border border-[#00FF95]/30 font-bold">
            📊
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Institutional Portfolio & Risk Terminal</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#00FF95] border border-[#2A2E39] rounded">
                Portfolio Margin & VaR Engine
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Net Liquidation Value, Multi-Asset Collateral, Portfolio Risk Offset & Margin Call Safeguards</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Net Liquidation Value</span>
            <span className="text-base font-bold text-[#00FF95] font-mono">
              ${wallet.netLiquidationValueUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Margin Call Status</span>
            <span className="font-bold text-[#00FF95] bg-[#00FF95]/10 border border-[#00FF95]/30 px-2 py-0.5 rounded text-[11px] font-mono">
              {wallet.marginCallStatus}
            </span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Parametric VaR 99% (10D)</span>
            <span className="font-semibold text-[#FF4D4D]">${risk.var99USD.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Expected Shortfall 99%</span>
            <span className="font-semibold text-[#FF4D4D]">${risk.expectedShortfall99USD.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Main Portfolio Breakdown (7 cols) */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        {/* Account Balances Table */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Multi-Currency Cash & Collateral Balances</span>
            <span className="text-[10px] text-[#00FF95] font-mono">6 Currencies</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Currency</th>
                  <th className="py-2.5 px-2 text-right">Total Balance</th>
                  <th className="py-2.5 px-2 text-right">Margin Locked</th>
                  <th className="py-2.5 px-2 text-right">Available Balance</th>
                </tr>
              </thead>
              <tbody>
                {(Object.keys(wallet.balances) as Array<keyof typeof wallet.balances>).map(curr => (
                  <tr key={curr} className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition">
                    <td className="py-2 px-2 font-bold font-sans text-[#00FF95]">{curr}</td>
                    <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">{wallet.balances[curr].toLocaleString()}</td>
                    <td className="py-2 px-2 text-right text-amber-400">{wallet.marginLocked[curr].toLocaleString()}</td>
                    <td className="py-2 px-2 text-right font-bold text-[#00FF95]">{wallet.available[curr].toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Portfolio Net Positions */}
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Active Position Portfolio</span>
            <span className="text-[10px] text-[#00FF95] font-mono">Cross-Asset Positions</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Instrument</th>
                  <th className="py-2.5 px-2">Side</th>
                  <th className="py-2.5 px-2 text-right">Size (kg / Contracts)</th>
                  <th className="py-2.5 px-2 text-right">Entry Price</th>
                  <th className="py-2.5 px-2 text-right">Mark Price</th>
                  <th className="py-2.5 px-2 text-right">Unrealised P&L</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50">
                  <td className="py-2 px-2 font-bold text-[#FFFFFF] font-sans">GREEN-H2-UK (Spot)</td>
                  <td className="py-2 px-2 text-[#00FF95] font-bold font-mono">LONG</td>
                  <td className="py-2 px-2 text-right text-[#D1D4DC]">250,000 kg</td>
                  <td className="py-2 px-2 text-right text-[#848E9C]">$6.28 USDT</td>
                  <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">$6.42 USDT</td>
                  <td className="py-2 px-2 text-right font-bold text-[#00FF95]">+$35,000.00</td>
                </tr>
                <tr className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50">
                  <td className="py-2 px-2 font-bold text-[#FFFFFF] font-sans">RH-H2-GREEN-UK-Q1-2027 (Futures)</td>
                  <td className="py-2 px-2 text-[#00FF95] font-bold font-mono">LONG</td>
                  <td className="py-2 px-2 text-right text-[#D1D4DC]">128 Contracts (1.28M kg)</td>
                  <td className="py-2 px-2 text-right text-[#848E9C]">$6.71 USDT</td>
                  <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">$6.82 USDT</td>
                  <td className="py-2 px-2 text-right font-bold text-[#00FF95]">+$140,800.00</td>
                </tr>
                <tr className="border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50">
                  <td className="py-2 px-2 font-bold text-[#FFFFFF] font-sans">CALL 7.00 Q1-2027 (Option)</td>
                  <td className="py-2 px-2 text-[#00FF95] font-bold font-mono">LONG</td>
                  <td className="py-2 px-2 text-right text-[#D1D4DC]">320 Contracts</td>
                  <td className="py-2 px-2 text-right text-[#848E9C]">$0.28 USDT</td>
                  <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">$0.34 USDT</td>
                  <td className="py-2 px-2 text-right font-bold text-[#00FF95]">+$19,200.00</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Portfolio Greeks & Risk Metrics (5 cols) */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Portfolio Risk Greeks & VaR</span>
            <span className="text-xs text-[#FF4D4D] font-mono">Risk Engine</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Net Delta</span>
              <span className="font-bold text-[#00FF95]">+{risk.netDelta.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Net Gamma</span>
              <span className="font-bold text-[#00FF95]">+{risk.netGamma}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Net Vega</span>
              <span className="font-bold text-purple-400">+{risk.netVega.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Net Theta</span>
              <span className="font-bold text-[#FF4D4D]">{risk.netTheta} / day</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">10D VaR (95%)</span>
              <span className="font-bold text-[#FF4D4D]">${risk.var95USD.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">10D VaR (99%)</span>
              <span className="font-bold text-[#FF4D4D]">${risk.var99USD.toLocaleString()}</span>
            </div>
            <div className="col-span-2 border-t border-[#2A2E39] pt-1.5 flex justify-between font-mono">
              <span className="text-[#848E9C]">Expected Shortfall 99%:</span>
              <span className="font-bold text-[#FF4D4D]">${risk.expectedShortfall99USD.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
