import React, { useState } from 'react';
import { InventoryToken, AccountWallet } from '../../types';
import { ShieldCheck, Database, Layers, ExternalLink, Lock, CheckCircle2, Cpu } from 'lucide-react';

interface TokenisedInventoryWorkspaceProps {
  tokens: InventoryToken[];
  wallet: AccountWallet;
}

export const TokenisedInventoryWorkspace: React.FC<TokenisedInventoryWorkspaceProps> = ({ tokens, wallet }) => {
  const [selectedToken, setSelectedToken] = useState<InventoryToken>(tokens[0]);
  const [actionMsg, setActionMsg] = useState<string | null>(null);

  const handlePledgeCollateral = () => {
    setActionMsg(`Pledged Token ${selectedToken.id} (${selectedToken.quantityKg.toLocaleString()} kg Green H₂) to Smart Contract Margin Pool`);
    setTimeout(() => setActionMsg(null), 4000);
  };

  const handleTokenRedeem = () => {
    setActionMsg(`Initiated Physical Redemption Flow for ${selectedToken.id} at ${selectedToken.custodian}`);
    setTimeout(() => setActionMsg(null), 4000);
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#00FF95]/10 text-[#00FF95] rounded-lg border border-[#00FF95]/30 font-bold">
            🏷️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Tokenised Commodity Inventory Framework</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-[#00FF95] border border-[#2A2E39] rounded">
                1 Token = 1 kg Verified Physical H₂ Claim
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Programmable ERC-1155 / Rust Smart Contract Digital Receipts with Verified Physical Custody</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Total Tokenised Volume</span>
            <span className="text-base font-bold text-[#FFFFFF]">930,000 kg H₂</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Active Custodians</span>
            <span className="font-semibold text-[#00FF95]">3 Verified Hubs</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Collateralized Claims</span>
            <span className="font-semibold text-[#00FF95]">180,000 kg Pledged</span>
          </div>
        </div>
      </div>

      {/* Main Inventory Tokens Table (7 cols) */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Verified On-Chain Inventory Receipts</span>
            <span className="text-[10px] text-[#00FF95] font-mono">3 Registered Claims</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Token ID</th>
                  <th className="py-2.5 px-2">Product</th>
                  <th className="py-2.5 px-2 text-right">Qty (kg)</th>
                  <th className="py-2.5 px-2">Custodian</th>
                  <th className="py-2.5 px-2">Status</th>
                  <th className="py-2.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {tokens.map(tk => {
                  const isSelected = tk.id === selectedToken.id;
                  return (
                    <tr
                      key={tk.id}
                      className={`border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition ${
                        isSelected ? 'bg-[#1E222D] text-[#FFFFFF]' : 'text-[#D1D4DC]'
                      }`}
                    >
                      <td className="py-2 px-2 font-bold font-sans text-[#00FF95]">{tk.id}</td>
                      <td className="py-2 px-2">{tk.product}</td>
                      <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">{tk.quantityKg.toLocaleString()}</td>
                      <td className="py-2 px-2 font-sans text-[#848E9C] text-[11px] truncate max-w-[130px]">{tk.custodian}</td>
                      <td className="py-2 px-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                          tk.status === 'Available'
                            ? 'bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        }`}>
                          {tk.status}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-center">
                        <button
                          onClick={() => setSelectedToken(tk)}
                          className="px-2.5 py-0.5 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] border border-[#2A2E39] rounded text-[11px] font-mono transition"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Inspect Token Metadata & Actions (5 cols) */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Token Specification & Verification</span>
            <span className="text-xs font-mono text-[#00FF95]">{selectedToken.id}</span>
          </div>

          {actionMsg && (
            <div className="p-2.5 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded text-xs text-[#00FF95] flex items-center gap-1.5 font-mono">
              <CheckCircle2 className="w-4 h-4 text-[#00FF95] shrink-0" />
              <span>{actionMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Commodity Product</span>
              <span className="font-bold text-[#00FF95]">{selectedToken.product}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Quantity</span>
              <span className="font-bold text-[#FFFFFF]">{selectedToken.quantityKg.toLocaleString()} kg H₂</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Purity Grade</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedToken.purity}</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Certification</span>
              <span className="font-semibold text-[#00FF95]">{selectedToken.certification}</span>
            </div>
            <div className="col-span-2">
              <span className="text-[#848E9C] text-[10px] font-mono block">Storage Facility Location</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedToken.location}</span>
            </div>
            <div className="col-span-2">
              <span className="text-[#848E9C] text-[10px] font-mono block">Third-Party Custodian</span>
              <span className="font-semibold text-[#848E9C]">{selectedToken.custodian}</span>
            </div>
            <div className="col-span-2">
              <span className="text-[#848E9C] text-[10px] font-mono block">On-Chain Smart Contract Address</span>
              <span className="text-[#00FF95] text-[11px] truncate block font-mono">{selectedToken.tokenContractAddress}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 font-mono">
            <button
              onClick={handlePledgeCollateral}
              className="py-2 bg-[#1E222D] hover:bg-[#2A2E39] border border-[#2A2E39] text-[#FFFFFF] font-bold text-xs uppercase rounded transition flex items-center justify-center gap-1"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              PLEDGE AS COLLATERAL
            </button>
            <button
              onClick={handleTokenRedeem}
              className="py-2 bg-[#089981] hover:bg-[#089981]/90 text-white font-bold text-xs uppercase rounded transition flex items-center justify-center gap-1 shadow-[0_0_10px_rgba(8,153,129,0.3)]"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              REDEEM PHYSICAL H₂
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
