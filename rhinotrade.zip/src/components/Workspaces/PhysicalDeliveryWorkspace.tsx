import React, { useState } from 'react';
import { PhysicalDeliveryRecord } from '../../types';
import { Truck, ShieldCheck, AlertOctagon, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface PhysicalDeliveryWorkspaceProps {
  records: PhysicalDeliveryRecord[];
}

export const PhysicalDeliveryWorkspace: React.FC<PhysicalDeliveryWorkspaceProps> = ({ records }) => {
  const [selectedRecord, setSelectedRecord] = useState<PhysicalDeliveryRecord>(records[0]);
  const [disputeModalOpen, setDisputeModalOpen] = useState<boolean>(false);
  const [disputeReason, setDisputeReason] = useState<string>('Purity variance detected during mass spectrometry sampling');
  const [disputeSuccessMsg, setDisputeSuccessMsg] = useState<string | null>(null);

  const handleDisputeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDisputeSuccessMsg(`Logged Quality Dispute Exception for ${selectedRecord.id}: ${disputeReason}. Escalated to Third-Party Inspector.`);
    setDisputeModalOpen(false);
    setTimeout(() => setDisputeSuccessMsg(null), 4000);
  };

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#0B0E11] text-[#D1D4DC] font-sans">
      {/* Top Banner */}
      <div className="lg:col-span-12 bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/30 font-bold">
            🚛
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold text-[#FFFFFF] font-sans">Physical Delivery & Logistics Centre</h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-[#1E222D] text-amber-400 border border-[#2A2E39] rounded">
                Telemetry & Purity Inspection
              </span>
            </div>
            <p className="text-xs text-[#848E9C] font-mono">Pipeline, Trailer & Underground Storage Physical Fulfillment and Quality Dispute Exceptions</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#848E9C] block">Scheduled Fulfillment</span>
            <span className="text-base font-bold text-[#FFFFFF]">350,000 kg</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Purity Threshold</span>
            <span className="font-semibold text-[#00FF95]">99.999% Fuel Cell</span>
          </div>
          <div>
            <span className="text-[#848E9C] block">Tolerance Limit</span>
            <span className="font-semibold text-amber-400">±0.25% Mass</span>
          </div>
        </div>
      </div>

      {/* Main Delivery Records Table (7 cols) */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        {disputeSuccessMsg && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs text-amber-400 flex items-center gap-2 font-mono">
            <AlertOctagon className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{disputeSuccessMsg}</span>
          </div>
        )}

        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-3">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#848E9C] mb-2 border-b border-[#2A2E39] pb-1 flex justify-between">
            <span>Physical Delivery Log</span>
            <span className="text-[10px] text-amber-400 font-mono">Hub Telemetry</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#2A2E39] text-[10px] text-[#848E9C] font-mono uppercase bg-[#1E222D]">
                  <th className="py-2.5 px-2">Delivery Ref</th>
                  <th className="py-2.5 px-2">Product</th>
                  <th className="py-2.5 px-2 text-right">Contract Qty</th>
                  <th className="py-2.5 px-2 text-right">Delivered Qty</th>
                  <th className="py-2.5 px-2">Hub Location</th>
                  <th className="py-2.5 px-2">Status</th>
                  <th className="py-2.5 px-2 text-center">Inspect</th>
                </tr>
              </thead>
              <tbody>
                {records.map(rec => {
                  const isSelected = rec.id === selectedRecord.id;
                  return (
                    <tr
                      key={rec.id}
                      className={`border-b border-[#2A2E39]/40 hover:bg-[#1E222D]/50 transition ${
                        isSelected ? 'bg-[#1E222D] text-[#FFFFFF]' : 'text-[#D1D4DC]'
                      }`}
                    >
                      <td className="py-2 px-2 font-bold font-sans text-amber-400">{rec.id}</td>
                      <td className="py-2 px-2">{rec.product}</td>
                      <td className="py-2 px-2 text-right text-[#848E9C]">{rec.contractQuantityKg.toLocaleString()} kg</td>
                      <td className="py-2 px-2 text-right font-bold text-[#FFFFFF]">{rec.deliveredQuantityKg.toLocaleString()} kg</td>
                      <td className="py-2 px-2 font-sans text-[#848E9C] text-[11px] truncate max-w-[130px]">{rec.locationHub}</td>
                      <td className="py-2 px-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                          rec.status === 'Verified Accepted'
                            ? 'bg-[#00FF95]/10 text-[#00FF95] border border-[#00FF95]/30'
                            : rec.status === 'In Transit'
                            ? 'bg-[#2962FF]/10 text-[#2962FF] border border-[#2962FF]/30'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        }`}>
                          {rec.status}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-center">
                        <button
                          onClick={() => setSelectedRecord(rec)}
                          className="px-2.5 py-0.5 bg-[#1E222D] hover:bg-[#2A2E39] text-[#FFFFFF] border border-[#2A2E39] rounded text-[11px] font-mono transition"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Physical Quality Sensor & Penalty Calculation (5 cols) */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        <div className="bg-[#131722] border border-[#2A2E39] rounded-lg p-4 flex flex-col gap-3">
          <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
            <span>Quality Inspection & Telemetry</span>
            <span className="text-xs font-mono text-amber-400">{selectedRecord.id}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#0B0E11] p-3 rounded border border-[#2A2E39]">
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Contract Quantity</span>
              <span className="font-bold text-[#FFFFFF]">{selectedRecord.contractQuantityKg.toLocaleString()} kg</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Delivered Quantity</span>
              <span className="font-bold text-[#00FF95]">{selectedRecord.deliveredQuantityKg.toLocaleString()} kg</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Required Purity Spec</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedRecord.puritySpecification}%</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Actual Measured Purity</span>
              <span className="font-bold text-[#00FF95]">{selectedRecord.actualPurityMeasured}%</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Pressure Level</span>
              <span className="font-semibold text-[#D1D4DC]">{selectedRecord.pressureBar} Bar</span>
            </div>
            <div>
              <span className="text-[#848E9C] text-[10px] font-mono block">Delivery Variance</span>
              <span className={`font-bold ${selectedRecord.varianceKg < 0 ? 'text-amber-400' : 'text-[#00FF95]'}`}>
                {selectedRecord.varianceKg} kg
              </span>
            </div>
            <div className="col-span-2 border-t border-[#2A2E39] pt-1.5 flex justify-between font-mono">
              <span className="text-[#848E9C]">Adjusted Settlement USDT:</span>
              <span className="font-bold text-[#00FF95]">${selectedRecord.adjustedSettlementUSDT.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
          </div>

          <button
            onClick={() => setDisputeModalOpen(true)}
            className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-mono font-bold text-xs uppercase tracking-wider rounded shadow transition flex items-center justify-center gap-1.5"
          >
            <AlertTriangle className="w-4 h-4" />
            FILE QUALITY DISPUTE EXCEPTION
          </button>
        </div>

        {disputeModalOpen && (
          <form onSubmit={handleDisputeSubmit} className="bg-[#131722] border border-amber-500 rounded-lg p-4 flex flex-col gap-3">
            <div className="font-bold text-[#FFFFFF] text-sm border-b border-[#2A2E39] pb-2 flex justify-between items-center font-sans">
              <span>Quality Exception Dispute Workflow</span>
              <button type="button" onClick={() => setDisputeModalOpen(false)} className="text-[#848E9C] hover:text-[#FFFFFF]">✕</button>
            </div>

            <div className="flex flex-col gap-1 text-xs">
              <label className="text-[#848E9C] font-mono text-[11px]">Dispute Reason & Telemetry Evidence</label>
              <textarea
                value={disputeReason}
                onChange={e => setDisputeReason(e.target.value)}
                rows={3}
                className="bg-[#0B0E11] border border-[#2A2E39] text-[#FFFFFF] rounded p-2 focus:outline-none focus:border-amber-500 font-mono text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-mono font-bold text-xs uppercase rounded"
            >
              SUBMIT EXCEPTION REPORT
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
