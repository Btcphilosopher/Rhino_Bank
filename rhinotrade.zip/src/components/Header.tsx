import React from 'react';
import { ShieldCheck, Activity, Cpu, Network, FileText, Share2, Wallet, Database, Lock, AlertTriangle } from 'lucide-react';
import { AccountWallet } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  wallet: AccountWallet;
  onOpenGraph: () => void;
  onOpenApiDocs: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  wallet,
  onOpenGraph,
  onOpenApiDocs,
}) => {
  const tabs = [
    { id: 'SPOT', label: 'Spot Market' },
    { id: 'FUTURES', label: 'Futures & Curve' },
    { id: 'OPTIONS', label: 'Options & Vol' },
    { id: 'SWAPS', label: 'Swaps & Basis' },
    { id: 'TOKENISED', label: 'Tokenised H₂' },
    { id: 'USDT', label: 'USDT & Ledger' },
    { id: 'DELIVERY', label: 'Physical Delivery' },
    { id: 'QUANT', label: 'Quant Strategy Lab' },
    { id: 'SMART_CONTRACTS', label: 'On-Chain & Oracles' },
    { id: 'SURVEILLANCE', label: 'Surveillance' },
    { id: 'PORTFOLIO', label: 'Portfolio Risk' },
  ];

  return (
    <header className="bg-[#131722] border-b border-[#2A2E39] text-[#D1D4DC] flex flex-col font-sans">
      {/* Top Banner Bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#2A2E39] bg-[#0B0E11]/90 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="h-6 w-6 bg-[#00FF95]/10 border border-[#00FF95]/30 rounded flex items-center justify-center font-bold text-[#00FF95] shadow-[0_0_8px_rgba(0,255,149,0.2)]">
              🦏
            </div>
            <span className="font-extrabold tracking-wider text-[#FFFFFF] text-sm font-sans">RHINOTRADE</span>
            <span className="text-[#848E9C] border-l border-[#2A2E39] pl-2.5 hidden sm:inline text-[11px] uppercase tracking-wider font-mono">Institutional Hydrogen & Digital Assets</span>
          </div>

          <div className="hidden lg:flex items-center gap-4 text-[#848E9C] text-[11px] font-mono">
            <span className="flex items-center gap-1.5 bg-[#1E222D] px-2 py-0.5 rounded border border-[#2A2E39]">
              <span className="h-2 w-2 rounded-full bg-[#00FF95] animate-pulse"></span>
              Matching Engine: <strong className="text-[#00FF95]">0.42ms</strong>
            </span>
            <span className="flex items-center gap-1.5 bg-[#1E222D] px-2 py-0.5 rounded border border-[#2A2E39]">
              <ShieldCheck className="w-3.5 h-3.5 text-[#2962FF]" />
              Settlement: <strong className="text-[#D1D4DC]">USDT Sandbox</strong>
            </span>
            <span className="flex items-center gap-1.5 bg-[#1E222D] px-2 py-0.5 rounded border border-[#2A2E39]">
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
              R Quant Engine: <strong className="text-[#00FF95]">Online</strong>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenGraph}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#1E222D] hover:bg-[#2A2E39] text-[#D1D4DC] transition text-xs font-mono font-medium border border-[#2A2E39] hover:border-[#00FF95]/40"
            title="View Market Relationship Architecture"
          >
            <Share2 className="w-3.5 h-3.5 text-[#00FF95]" />
            Market Graph
          </button>

          <button
            onClick={onOpenApiDocs}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#1E222D] hover:bg-[#2A2E39] text-[#D1D4DC] transition text-xs font-mono font-medium border border-[#2A2E39] hover:border-[#00FF95]/40"
            title="OpenAPI Specification v1"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            API Docs
          </button>

          <div className="bg-[#1E222D] px-3 py-1 rounded border border-[#2A2E39] flex items-center gap-2">
            <Wallet className="w-3.5 h-3.5 text-[#00FF95]" />
            <span className="text-[#848E9C] text-xs">NLV:</span>
            <span className="font-mono font-bold text-[#00FF95]">
              ${wallet.netLiquidationValueUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Workspace Bar */}
      <div className="flex items-center justify-between px-3 bg-[#131722] overflow-x-auto scrollbar-none border-b border-[#2A2E39]">
        <nav className="flex items-center gap-0.5">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2.5 text-xs font-semibold tracking-wide border-b-2 transition whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-[#00FF95] text-[#00FF95] bg-[#1E222D] shadow-[inset_0_-2px_0_#00FF95]'
                  : 'border-transparent text-[#848E9C] hover:text-[#D1D4DC] hover:bg-[#1E222D]/50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};
