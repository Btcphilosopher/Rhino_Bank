export type WorkspaceTab =
  | 'SPOT'
  | 'FUTURES'
  | 'OPTIONS'
  | 'SWAPS'
  | 'TOKENISED'
  | 'USDT_WALLET'
  | 'DELIVERY'
  | 'QUANT_LAB'
  | 'CONTRACTS'
  | 'SURVEILLANCE'
  | 'PORTFOLIO';

export interface TickerItem {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  unit: string;
}

export interface SpotMarketBook {
  instrument: MarketInstrument;
  orderBook: OrderBook;
  recentTrades: Trade[];
}

export type AssetCurrency = 'USD' | 'USDT' | 'EUR' | 'GBP' | 'JPY' | 'CHF';

export type ProductionType = 'Green H₂' | 'Blue H₂' | 'Grey H₂' | 'Low-Carbon H₂' | 'Renewable H₂' | 'Turquoise H₂';

export type InstrumentType = 'SPOT' | 'FUTURES' | 'FORWARD' | 'OPTION' | 'SWAP' | 'BASIS_SWAP' | 'TOKENISED_INVENTORY' | 'INDEX';

export interface MarketInstrument {
  id: string;
  symbol: string;
  name: string;
  type: InstrumentType;
  productionType: ProductionType;
  location: string;
  purity: string; // e.g. "99.999% (Fuel Cell Grade)"
  pressure: string; // e.g. "350 Bar" or "700 Bar"
  deliveryMethod: 'Pipeline' | 'Liquefied Tanker' | 'Tube Trailer' | 'Underground Cavern Storage';
  certification: 'RED II Certified' | 'CertifHy Green' | 'Low Carbon Standard' | 'ISCC EU';
  contractSizeKg: number;
  currency: AssetCurrency;
  lastPrice: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24hKg: number;
  bid: number;
  ask: number;
  spread: number;
  expiryDate?: string;
  settlementType?: 'Physical' | 'Cash (USDT)';
  openInterestKg?: number;
}

export type OrderType = 'LIMIT' | 'MARKET' | 'IOC' | 'FOK' | 'STOP_LIMIT' | 'ICEBERG';
export type OrderSide = 'BUY' | 'SELL';
export type OrderStatus = 'PENDING' | 'OPEN' | 'PARTIAL' | 'FILLED' | 'CANCELLED' | 'REJECTED';

export interface Order {
  id: string;
  instrumentId: string;
  side: OrderSide;
  type: OrderType;
  price: number;
  quantityKg: number;
  filledKg: number;
  remainingKg: number;
  status: OrderStatus;
  timestamp: string;
  traderId: string;
  icebergVisibleKg?: number;
  stopPrice?: number;
  settlementCurrency: AssetCurrency;
  counterpartyId?: string;
}

export interface OrderBookLevel {
  price: number;
  quantityKg: number;
  orderCount: number;
  totalVolume: number;
}

export interface OrderBook {
  instrumentId: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  lastUpdated: string;
}

export interface Trade {
  id: string;
  instrumentId: string;
  symbol: string;
  price: number;
  quantityKg: number;
  side: OrderSide;
  timestamp: string;
  buyerId: string;
  sellerId: string;
  settlementCurrency: AssetCurrency;
  usdtEquivalent: number;
  txHash?: string;
  status: 'EXECUTED' | 'CLEARING' | 'SETTLED' | 'DELIVERY_PENDING';
}

export interface LedgerEntry {
  id: string;
  timestamp: string;
  account: string;
  entryType: 'DEBIT' | 'CREDIT';
  currency: AssetCurrency;
  amount: number;
  description: string;
  txRef: string;
  balanceAfter: number;
}

export interface AccountWallet {
  accountName: string;
  accountNumber: string;
  balances: Record<AssetCurrency, number>;
  marginLocked: Record<AssetCurrency, number>;
  available: Record<AssetCurrency, number>;
  netLiquidationValueUSD: number;
  leverageRatio: number;
  marginCallStatus: 'NORMAL' | 'WARNING' | 'MARGIN_CALL' | 'LIQUIDATION_IMMINENT';
}

export type UsdtNetwork = 'Ethereum (ERC-20)' | 'Tron (TRC-20)' | 'Solana (SPL)' | 'Polygon (POS)' | 'RhinoChain Sandbox';

export interface UsdtTransaction {
  id: string;
  type: 'DEPOSIT' | 'WITHDRAWAL';
  network: UsdtNetwork;
  amount: number;
  fee: number;
  address: string;
  txHash: string;
  confirmations: number;
  requiredConfirmations: number;
  status: 'DETECTED' | 'CONFIRMING' | 'CONFIRMED' | 'CREDITED' | 'REJECTED' | 'SCREENING' | 'APPROVED' | 'DISPATCHED';
  timestamp: string;
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  multiApprovalState?: 'PENDING_DESK' | 'PENDING_COMPLIANCE' | 'APPROVED';
}

export interface SmartContractSpec {
  id: string;
  name: string;
  address: string;
  network: string;
  contractType: 'CommodityEscrow' | 'MarginCollateral' | 'OracleSettlement' | 'TokenisedInventory' | 'DeliveryVerification';
  status: 'ACTIVE' | 'LOCKED' | 'SETTLED' | 'TERMINATED';
  lockedCollateralUSDT: number;
  buyerAddress: string;
  sellerAddress: string;
  terms: {
    quantityKg: number;
    pricePerKgUSDT: number;
    deliveryWindowEnd: string;
    purityThreshold: number;
    oracleConsensusRequired: number;
  };
  eventsCount: number;
}

export interface SmartContractEvent {
  id: string;
  contractAddress: string;
  eventName: 'CollateralLocked' | 'TradeSettled' | 'MarginPosted' | 'MarginReleased' | 'DeliveryConfirmed' | 'InventoryTransferred' | 'RefundIssued';
  blockNumber: number;
  txHash: string;
  timestamp: string;
  details: string;
}

export interface InventoryToken {
  id: string; // e.g. "RH-H2-UK-2026-001842"
  product: ProductionType;
  quantityKg: number;
  location: string;
  purity: string;
  certification: string;
  custodian: string;
  contractId: string;
  oracleId: string;
  status: 'Available' | 'Pledged as Collateral' | 'In Delivery Transit' | 'Redeemed';
  mintDate: string;
  expiryDate: string;
  tokenContractAddress: string;
}

export interface OracleNodeObservation {
  nodeId: string;
  nodeName: string;
  sourceType: 'Storage Sensor' | 'Pipeline Flowmeter' | 'Purity Analyzer' | 'Terminal Meter' | 'Certifier API' | 'Power Grid Oracle' | 'Gas Index Feed';
  timestamp: string;
  value: number;
  unit: 'USDT/kg' | 'bar' | '%' | 'MW' | 'EUR/MWh';
  confidenceScore: number; // 0 to 1
  signature: string;
  status: 'VERIFIED' | 'PENDING' | 'FLAGGED';
}

export interface OracleConsensusResult {
  parameter: string;
  method: 'Median' | 'Trimmed Mean' | 'Weighted Average' | 'Threshold Consensus';
  rawValues: number[];
  consensusValue: number;
  participatingNodes: number;
  confidence: number;
  status: 'VALIDATED' | 'REJECTED';
  timestamp: string;
}

export interface FuturesCurvePoint {
  contract: string;
  tenor: string;
  priceUSDT: number;
  change: number;
  volumeKg: number;
  openInterestKg: number;
  contangoSpread: number;
  rollYieldPercent: number;
}

export interface OptionContract {
  id: string;
  instrumentId: string;
  underlyingSymbol: string;
  optionType: 'CALL' | 'PUT';
  strikeUSDT: number;
  expiry: string;
  exerciseStyle: 'European' | 'American';
  settlement: 'Cash (USDT)' | 'Physical';
  premiumUSDT: number;
  bid: number;
  ask: number;
  impliedVolPercent: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  openInterest: number;
  volume: number;
}

export interface VolatilitySurfacePoint {
  strike: number;
  expiryDays: number;
  impliedVol: number;
  moneyness: number;
}

export interface CommoditySwap {
  id: string;
  swapName: string;
  notionalKg: number;
  leg1Type: 'PAY_FIXED' | 'RECEIVE_FIXED';
  leg1RateUSDT: number;
  leg2Reference: string; // e.g. "RhinoTrade Green H2 UK Index"
  leg2CurrentRateUSDT: number;
  tenorMonths: number;
  counterparty: string;
  pvUSDT: number;
  status: 'ACTIVE' | 'TERMINATED' | 'MATURED';
}

export interface BasisSwap {
  id: string;
  pair: string; // e.g. "UK Green H₂ vs German Green H₂" or "Green H₂ vs Blue H₂"
  legA: string;
  legB: string;
  currentBasisUSDT: number;
  basisVol30d: number;
  historicalMean: number;
  zScore: number;
  historicalData: { time: string; basis: number }[];
}

export interface PhysicalDeliveryRecord {
  id: string;
  contractRef: string;
  product: ProductionType;
  contractQuantityKg: number;
  deliveredQuantityKg: number;
  locationHub: string;
  deliveryWindow: string;
  puritySpecification: number; // e.g. 99.97%
  actualPurityMeasured: number; // e.g. 99.972%
  pressureBar: number;
  scheduledDate: string;
  status: 'Scheduled' | 'In Transit' | 'Delivered' | 'Verified Accepted' | 'Quality Dispute Exception';
  varianceKg: number;
  penaltyUSDT: number;
  adjustedSettlementUSDT: number;
}

export interface RiskMetrics {
  netLiquidationValueUSD: number;
  marginLockedUSD: number;
  availableMarginUSD: number;
  var95USD: number;
  var99USD: number;
  expectedShortfall99USD: number;
  netDelta: number;
  netGamma: number;
  netVega: number;
  netTheta: number;
  portfolioBeta: number;
  stressTestLosses: {
    electricityPlus30: number;
    gasPlus50: number;
    carbonPlus100: number;
    h2SupplyOutage20: number;
    usdtDepeg1: number;
  };
}

export interface BacktestResult {
  strategyName: string;
  period: string;
  initialCapitalUSD: number;
  finalCapitalUSD: number;
  totalReturnPercent: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPercent: number;
  winRatePercent: number;
  tradesCount: number;
  equityCurve: { date: string; equity: number; benchmark: number }[];
}

export interface SurveillanceAlert {
  id: string;
  timestamp: string;
  instrument: string;
  indicator: 'Spoofing' | 'Layering' | 'Wash Trading' | 'Unusual Volume' | 'Cross-Market Anomaly' | 'Abnormal Cancellation';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  details: string;
  status: 'OPEN' | 'UNDER_INVESTIGATION' | 'DISMISSED' | 'ESCALATED';
}

export interface ComplianceProfile {
  accountName: string;
  kycStatus: 'VERIFIED_INSTITUTIONAL';
  kybStatus: 'VERIFIED_LEGAL_ENTITY';
  sanctionsCheck: 'PASSED_CLEAN';
  travelRuleStatus: 'COMPLIANT_VASP';
  jurisdiction: 'UK (FCA Regulated)' | 'EU (MiCA & ACER Compliant)' | 'US (CFTC Eligible)' | 'SG (MAS Approved)';
  spotPositionLimitKg: number;
  futuresPositionLimitKg: number;
  currentSpotPositionKg: number;
  currentFuturesPositionKg: number;
}
