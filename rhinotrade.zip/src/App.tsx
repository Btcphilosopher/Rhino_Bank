import React, { useState, useEffect } from 'react';
import { WorkspaceTab, AccountWallet, TickerItem, SpotMarketBook, FuturesCurvePoint, OptionContract, CommoditySwap, BasisSwap, InventoryToken, PhysicalDeliveryRecord, BacktestResult, RiskMetrics, SmartContractSpec, SmartContractEvent, OracleNodeObservation, OracleConsensusResult, SurveillanceAlert, ComplianceProfile, LedgerEntry, UsdtTransaction, UsdtNetwork, MarketInstrument, OrderSide, OrderType } from './types';
import { Header } from './components/Header';
import { TickerTape } from './components/TickerTape';
import { SpotMarketWorkspace } from './components/Workspaces/SpotMarketWorkspace';
import { FuturesWorkspace } from './components/Workspaces/FuturesWorkspace';
import { OptionsWorkspace } from './components/Workspaces/OptionsWorkspace';
import { SwapsWorkspace } from './components/Workspaces/SwapsWorkspace';
import { TokenisedInventoryWorkspace } from './components/Workspaces/TokenisedInventoryWorkspace';
import { UsdtWalletWorkspace } from './components/Workspaces/UsdtWalletWorkspace';
import { PhysicalDeliveryWorkspace } from './components/Workspaces/PhysicalDeliveryWorkspace';
import { QuantLabWorkspace } from './components/Workspaces/QuantLabWorkspace';
import { SmartContractsWorkspace } from './components/Workspaces/SmartContractsWorkspace';
import { SurveillanceComplianceWorkspace } from './components/Workspaces/SurveillanceComplianceWorkspace';
import { PortfolioRiskWorkspace } from './components/Workspaces/PortfolioRiskWorkspace';
import { MarketGraphModal } from './components/MarketGraphModal';
import { ApiDocsModal } from './components/ApiDocsModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('SPOT');
  const [tickerItems, setTickerItems] = useState<TickerItem[]>([]);
  const [wallet, setWallet] = useState<AccountWallet | null>(null);
  const [markets, setMarkets] = useState<MarketInstrument[]>([]);
  const [selectedMarket, setSelectedMarket] = useState<MarketInstrument | null>(null);
  const [spotBook, setSpotBook] = useState<SpotMarketBook | null>(null);
  const [futuresCurve, setFuturesCurve] = useState<FuturesCurvePoint[]>([]);
  const [options, setOptions] = useState<OptionContract[]>([]);
  const [swaps, setSwaps] = useState<CommoditySwap[]>([]);
  const [basisSwaps, setBasisSwaps] = useState<BasisSwap[]>([]);
  const [tokens, setTokens] = useState<InventoryToken[]>([]);
  const [deliveries, setDeliveries] = useState<PhysicalDeliveryRecord[]>([]);
  const [backtest, setBacktest] = useState<BacktestResult | null>(null);
  const [risk, setRisk] = useState<RiskMetrics | null>(null);
  const [contracts, setContracts] = useState<SmartContractSpec[]>([]);
  const [contractEvents, setContractEvents] = useState<SmartContractEvent[]>([]);
  const [oracleNodes, setOracleNodes] = useState<OracleNodeObservation[]>([]);
  const [oracleConsensus, setOracleConsensus] = useState<OracleConsensusResult[]>([]);
  const [surveillanceAlerts, setSurveillanceAlerts] = useState<SurveillanceAlert[]>([]);
  const [compliance, setCompliance] = useState<ComplianceProfile | null>(null);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [transactions, setTransactions] = useState<UsdtTransaction[]>([]);
  const [usdtBasis, setUsdtBasis] = useState<any>(null);

  const [graphModalOpen, setGraphModalOpen] = useState<boolean>(false);
  const [apiDocsOpen, setApiDocsOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // Fetch initial state from server API
  const fetchState = async () => {
    try {
      const fetchJson = async (url: string) => {
        const r = await fetch(url);
        if (!r.ok) {
          throw new Error(`HTTP error ${r.status} for ${url}`);
        }
        const contentType = r.headers.get('content-type');
        if (contentType && !contentType.includes('application/json')) {
          throw new Error(`Expected JSON from ${url} but got ${contentType}`);
        }
        return r.json();
      };

      // Determine active spot symbol to fetch
      const activeSpotSymbol = selectedMarket?.symbol || 'GREEN-H2-UK';

      const [
        tickerRes,
        walletRes,
        marketsRes,
        spotRes,
        futuresRes,
        optionsRes,
        swapsRes,
        tokensRes,
        delivRes,
        riskRes,
        contractsRes,
        survRes,
        usdtRes,
      ] = await Promise.all([
        fetchJson('/api/v1/ticker'),
        fetchJson('/api/v1/wallets'),
        fetchJson('/api/v1/markets'),
        fetchJson(`/api/v1/spot/${activeSpotSymbol}`),
        fetchJson('/api/v1/futures/curve'),
        fetchJson('/api/v1/options/chain'),
        fetchJson('/api/v1/swaps'),
        fetchJson('/api/v1/tokens'),
        fetchJson('/api/v1/delivery'),
        fetchJson('/api/v1/risk'),
        fetchJson('/api/v1/contracts'),
        fetchJson('/api/v1/surveillance'),
        fetchJson('/api/v1/usdt'),
      ]);

      if (tickerRes) setTickerItems(tickerRes);
      if (walletRes) setWallet(walletRes);
      if (marketsRes) {
        setMarkets(marketsRes);
        if (!selectedMarket) {
          setSelectedMarket(marketsRes[0]);
        }
      }
      if (spotRes) setSpotBook(spotRes);
      if (futuresRes) setFuturesCurve(futuresRes);
      if (optionsRes) setOptions(optionsRes);
      if (swapsRes?.swaps) setSwaps(swapsRes.swaps);
      if (swapsRes?.basisSwaps) setBasisSwaps(swapsRes.basisSwaps);
      if (tokensRes) setTokens(tokensRes);
      if (delivRes) setDeliveries(delivRes);
      if (riskRes?.backtest) setBacktest(riskRes.backtest);
      if (riskRes?.riskMetrics) setRisk(riskRes.riskMetrics);
      if (contractsRes?.contracts) setContracts(contractsRes.contracts);
      if (contractsRes?.events) setContractEvents(contractsRes.events);
      if (contractsRes?.oracleNodes) setOracleNodes(contractsRes.oracleNodes);
      if (contractsRes?.oracleConsensus) setOracleConsensus(contractsRes.oracleConsensus);
      if (survRes?.alerts) setSurveillanceAlerts(survRes.alerts);
      if (survRes?.compliance) setCompliance(survRes.compliance);
      if (usdtRes?.ledger) setLedger(usdtRes.ledger);
      if (usdtRes?.transactions) setTransactions(usdtRes.transactions);
      if (usdtRes?.basis) setUsdtBasis(usdtRes.basis);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching data from API backend:', err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchState();
    const timer = setInterval(fetchState, 5000);
    return () => clearInterval(timer);
  }, []);

  // Handlers for USDT transactions via REST API
  const handleDepositUsdt = async (amount: number, network: UsdtNetwork, address: string) => {
    try {
      const res = await fetch('/api/v1/usdt/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, network, address }),
      });
      const data = await res.json();
      if (data.success) {
        setTransactions(data.transactions);
        setLedger(data.ledger);
        setWallet(data.wallet);
      }
    } catch (e) {
      console.error('Deposit error:', e);
    }
  };

  const handleAdvanceTx = async (txId: string) => {
    try {
      const res = await fetch(`/api/v1/usdt/advance/${txId}`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setTransactions(data.transactions);
        setLedger(data.ledger);
        setWallet(data.wallet);
      }
    } catch (e) {
      console.error('Advance error:', e);
    }
  };

  const handleWithdrawUsdt = async (amount: number, network: UsdtNetwork, address: string) => {
    try {
      const res = await fetch('/api/v1/usdt/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, network, address }),
      });
      const data = await res.json();
      if (data.success) {
        setTransactions(data.transactions);
        setLedger(data.ledger);
        setWallet(data.wallet);
      }
    } catch (e) {
      console.error('Withdraw error:', e);
    }
  };

  const handleSelectMarket = async (market: MarketInstrument) => {
    setSelectedMarket(market);
    try {
      const res = await fetch(`/api/v1/spot/${market.symbol}`);
      const data = await res.json();
      if (data) {
        setSpotBook(data);
      }
    } catch (e) {
      console.error('Error selecting market:', e);
    }
  };

  const handleSubmitOrder = async (order: {
    instrumentId: string;
    symbol: string;
    side: OrderSide;
    type: OrderType;
    price: number;
    quantityKg: number;
  }) => {
    try {
      const res = await fetch('/api/v1/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...order,
          traderId: 'RHINO-TRADER-01',
        }),
      });
      const data = await res.json();
      if (data.success && spotBook) {
        setSpotBook({
          ...spotBook,
          orderBook: data.orderBook,
          recentTrades: data.trades,
        });
      }
    } catch (e) {
      console.error('Order submission error:', e);
    }
  };

  if (loading || !wallet || !spotBook || !risk || !compliance || !usdtBasis || !backtest || !selectedMarket || markets.length === 0) {
    return (
      <div className="min-h-screen bg-[#0B0E11] text-[#D1D4DC] flex items-center justify-center font-sans">
        <div className="flex flex-col items-center gap-3 bg-[#131722] p-8 rounded-lg border border-[#2A2E39] shadow-2xl">
          <div className="w-8 h-8 border-3 border-[#00FF95] border-t-transparent rounded-full animate-spin"></div>
          <span className="text-xs font-mono font-bold tracking-wider text-[#00FF95] uppercase">
            INITIALIZING RHINOTRADE INSTITUTIONAL ENGINE...
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0E11] text-[#D1D4DC] font-sans flex flex-col selection:bg-[#00FF95] selection:text-[#0B0E11]">
      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        wallet={wallet}
        onOpenGraph={() => setGraphModalOpen(true)}
        onOpenApiDocs={() => setApiDocsOpen(true)}
      />

      {/* Ticker Tape */}
      <TickerTape items={tickerItems} />

      {/* Main Workspace View */}
      <main className="flex-1 bg-[#0B0E11]">
        {activeTab === 'SPOT' && (
          <SpotMarketWorkspace
            markets={markets}
            selectedMarket={selectedMarket}
            onSelectMarket={handleSelectMarket}
            orderBook={spotBook.orderBook}
            trades={spotBook.recentTrades}
            wallet={wallet}
            onSubmitOrder={handleSubmitOrder}
          />
        )}
        {activeTab === 'FUTURES' && (
          <FuturesWorkspace futuresCurve={futuresCurve} wallet={wallet} />
        )}
        {activeTab === 'OPTIONS' && (
          <OptionsWorkspace options={options} wallet={wallet} />
        )}
        {activeTab === 'SWAPS' && (
          <SwapsWorkspace swaps={swaps} basisSwaps={basisSwaps} />
        )}
        {activeTab === 'TOKENISED' && (
          <TokenisedInventoryWorkspace tokens={tokens} wallet={wallet} />
        )}
        {activeTab === 'USDT' && (
          <UsdtWalletWorkspace
            wallet={wallet}
            ledger={ledger}
            transactions={transactions}
            onDeposit={handleDepositUsdt}
            onAdvanceTx={handleAdvanceTx}
            onWithdraw={handleWithdrawUsdt}
            usdtBasis={usdtBasis}
          />
        )}
        {activeTab === 'USDT_WALLET' && (
          <UsdtWalletWorkspace
            wallet={wallet}
            ledger={ledger}
            transactions={transactions}
            onDeposit={handleDepositUsdt}
            onAdvanceTx={handleAdvanceTx}
            onWithdraw={handleWithdrawUsdt}
            usdtBasis={usdtBasis}
          />
        )}
        {activeTab === 'DELIVERY' && (
          <PhysicalDeliveryWorkspace records={deliveries} />
        )}
        {activeTab === 'QUANT' && (
          <QuantLabWorkspace backtest={backtest} risk={risk} />
        )}
        {activeTab === 'QUANT_LAB' && (
          <QuantLabWorkspace backtest={backtest} risk={risk} />
        )}
        {activeTab === 'SMART_CONTRACTS' && (
          <SmartContractsWorkspace
            contracts={contracts}
            events={contractEvents}
            oracleNodes={oracleNodes}
            oracleConsensus={oracleConsensus}
          />
        )}
        {activeTab === 'CONTRACTS' && (
          <SmartContractsWorkspace
            contracts={contracts}
            events={contractEvents}
            oracleNodes={oracleNodes}
            oracleConsensus={oracleConsensus}
          />
        )}
        {activeTab === 'SURVEILLANCE' && (
          <SurveillanceComplianceWorkspace alerts={surveillanceAlerts} compliance={compliance} />
        )}
        {activeTab === 'PORTFOLIO' && (
          <PortfolioRiskWorkspace wallet={wallet} risk={risk} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#131722] border-t border-[#2A2E39] px-4 py-2 text-[11px] font-mono text-[#848E9C] flex flex-wrap justify-between items-center gap-2">
        <div className="flex items-center gap-3">
          <span className="text-[#00FF95] font-bold tracking-tight">RhinoTrade Core v3.7.4-PROD</span>
          <span className="text-[#2A2E39]">•</span>
          <span>Matching Engine: <strong className="text-[#D1D4DC]">42µs Latency</strong></span>
          <span className="text-[#2A2E39]">•</span>
          <span>R Quant Engine: <strong className="text-[#00FF95]">Active</strong></span>
          <span className="text-[#2A2E39]">•</span>
          <span>USDT Settlement: <strong className="text-[#D1D4DC]">Synchronized</strong></span>
        </div>
        <div>
          <span className="text-[#848E9C]">FCA / ACER Registered Institutional Commodities Trading Venue</span>
        </div>
      </footer>

      {/* Modals */}
      <MarketGraphModal isOpen={graphModalOpen} onClose={() => setGraphModalOpen(false)} />
      <ApiDocsModal isOpen={apiDocsOpen} onClose={() => setApiDocsOpen(false)} />
    </div>
  );
}
