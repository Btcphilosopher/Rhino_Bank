import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  INITIAL_MARKETS,
  INITIAL_ORDERBOOK,
  INITIAL_TRADES,
  INITIAL_WALLET,
  INITIAL_LEDGER,
  INITIAL_USDT_TRANSACTIONS,
  INITIAL_SMART_CONTRACTS,
  INITIAL_CONTRACT_EVENTS,
  INITIAL_INVENTORY_TOKENS,
  INITIAL_ORACLE_NODES,
  INITIAL_ORACLE_CONSENSUS,
  INITIAL_FUTURES_CURVE,
  INITIAL_OPTIONS,
  INITIAL_SWAPS,
  INITIAL_BASIS_SWAPS,
  INITIAL_PHYSICAL_DELIVERY,
  INITIAL_RISK,
  INITIAL_BACKTEST,
  INITIAL_SURVEILLANCE,
  INITIAL_COMPLIANCE,
} from './src/data/mockData';
import { MatchingEngine } from './src/services/matchingEngine';
import { LedgerEngine } from './src/services/ledgerEngine';
import { calculateBlackScholes, runMonteCarloSimulations, analyzeFuturesCurve } from './src/services/quantEngine';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Instantiate engines
  const matchingEngine = new MatchingEngine(INITIAL_ORDERBOOK, INITIAL_TRADES);
  const ledgerEngine = new LedgerEngine(INITIAL_WALLET, INITIAL_LEDGER, INITIAL_USDT_TRANSACTIONS);

  // REST API v1 Endpoints
  app.get('/api/v1/health', (req, res) => {
    res.json({ status: 'ok', exchange: 'RhinoTrade Engine v3.7', timestamp: new Date().toISOString() });
  });

  app.get('/api/v1/ticker', (req, res) => {
    res.json(INITIAL_MARKETS);
  });

  app.get('/api/v1/markets', (req, res) => {
    res.json(INITIAL_MARKETS);
  });

  app.get('/api/v1/spot/:symbol', (req, res) => {
    const symbol = req.params.symbol;
    const instrument = INITIAL_MARKETS.find(m => m.symbol === symbol) || INITIAL_MARKETS[0];
    res.json({
      instrument,
      orderBook: matchingEngine.getOrderBook(),
      recentTrades: matchingEngine.getTrades(),
    });
  });

  app.get('/api/v1/spot', (req, res) => {
    res.json({
      instrument: INITIAL_MARKETS[0],
      orderBook: matchingEngine.getOrderBook(),
      recentTrades: matchingEngine.getTrades(),
    });
  });

  app.get('/api/v1/orderbook', (req, res) => {
    res.json(matchingEngine.getOrderBook());
  });

  app.get('/api/v1/futures/curve', (req, res) => {
    res.json(INITIAL_FUTURES_CURVE);
  });

  app.get('/api/v1/options/chain', (req, res) => {
    res.json(INITIAL_OPTIONS);
  });

  app.get('/api/v1/swaps', (req, res) => {
    res.json({ swaps: INITIAL_SWAPS, basisSwaps: INITIAL_BASIS_SWAPS });
  });

  app.get('/api/v1/tokens', (req, res) => {
    res.json(INITIAL_INVENTORY_TOKENS);
  });

  app.get('/api/v1/trades', (req, res) => {
    res.json(matchingEngine.getTrades());
  });

  app.post('/api/v1/orders', (req, res) => {
    const { instrumentId, symbol, side, type, price, quantityKg, traderId } = req.body;
    const result = matchingEngine.submitOrder({
      instrumentId: instrumentId || 'rh-h2-uk-green-spot',
      symbol: symbol || 'GREEN-H2-UK',
      side: side || 'BUY',
      type: type || 'LIMIT',
      price: Number(price) || 6.42,
      quantityKg: Number(quantityKg) || 1000,
      traderId: traderId || 'INST-DESK-ALPHA',
    });

    if (result.filledTrades.length > 0) {
      result.filledTrades.forEach(trd => {
        ledgerEngine.recordDoubleEntry({
          currency: 'USDT',
          entryType: side === 'BUY' ? 'DEBIT' : 'CREDIT',
          amount: trd.usdtEquivalent,
          description: `Order Execution ${side}: ${trd.quantityKg} kg @ ${trd.price} USDT`,
          txRef: trd.id,
        });
      });
    }

    res.json({
      order: result.order,
      filledTrades: result.filledTrades,
      updatedOrderBook: matchingEngine.getOrderBook(),
      wallet: ledgerEngine.getWallet(),
    });
  });

  app.get('/api/v1/wallets', (req, res) => {
    res.json(ledgerEngine.getWallet());
  });

  app.get('/api/v1/ledger', (req, res) => {
    res.json(ledgerEngine.getLedger());
  });

  app.get('/api/v1/usdt', (req, res) => {
    res.json({
      ledger: ledgerEngine.getLedger(),
      transactions: ledgerEngine.getUsdtTransactions(),
      basis: ledgerEngine.getUsdtBasisMetrics(),
    });
  });

  app.get('/api/v1/usdt/transactions', (req, res) => {
    res.json(ledgerEngine.getUsdtTransactions());
  });

  app.post('/api/v1/usdt/deposit', (req, res) => {
    const { amount, network, address } = req.body;
    const tx = ledgerEngine.initiateUsdtDeposit(Number(amount) || 100000, network || 'Ethereum (ERC-20)', address || '0x71C...976F');
    res.json({
      success: true,
      tx,
      transactions: ledgerEngine.getUsdtTransactions(),
      ledger: ledgerEngine.getLedger(),
      wallet: ledgerEngine.getWallet(),
    });
  });

  const handleAdvanceTx = (txId: string, res: express.Response) => {
    const updatedTx = ledgerEngine.advanceUsdtTransaction(txId);
    res.json({
      success: true,
      tx: updatedTx,
      transactions: ledgerEngine.getUsdtTransactions(),
      ledger: ledgerEngine.getLedger(),
      wallet: ledgerEngine.getWallet(),
    });
  };

  app.post('/api/v1/usdt/advance/:txId', (req, res) => {
    handleAdvanceTx(req.params.txId, res);
  });

  app.post('/api/v1/usdt/advance', (req, res) => {
    handleAdvanceTx(req.body.txId, res);
  });

  app.post('/api/v1/usdt/withdraw', (req, res) => {
    const { amount, network, destinationAddress, address } = req.body;
    const dest = destinationAddress || address || 'TR7NH...Lj6t';
    const result = ledgerEngine.initiateUsdtWithdrawal(Number(amount) || 50000, network || 'Tron (TRC-20)', dest);
    if ('error' in result) {
      return res.status(400).json({ success: false, error: result.error });
    }
    res.json({
      success: true,
      tx: result,
      transactions: ledgerEngine.getUsdtTransactions(),
      ledger: ledgerEngine.getLedger(),
      wallet: ledgerEngine.getWallet(),
    });
  });

  app.get('/api/v1/usdt/basis', (req, res) => {
    res.json(ledgerEngine.getUsdtBasisMetrics());
  });

  app.get('/api/v1/quant/options', (req, res) => {
    const spot = Number(req.query.spot) || 6.42;
    const strike = Number(req.query.strike) || 7.00;
    const t = Number(req.query.t) || 0.35;
    const vol = Number(req.query.vol) || 0.285;

    const bsResult = calculateBlackScholes({
      S: spot,
      K: strike,
      T: t,
      r: 0.04,
      sigma: vol,
      y: 0.02,
      u: 0.05,
    });
    res.json(bsResult);
  });

  app.get('/api/v1/quant/var', (req, res) => {
    const portfolioVal = Number(req.query.value) || 12480500;
    const monteCarloResult = runMonteCarloSimulations(portfolioVal, 0.28, 10, 2000);
    res.json(monteCarloResult);
  });

  app.get('/api/v1/quant/curves', (req, res) => {
    const curveAnalysis = analyzeFuturesCurve(6.42, INITIAL_FUTURES_CURVE.map(pt => ({ tenor: pt.tenor, priceUSDT: pt.priceUSDT })));
    res.json({ points: INITIAL_FUTURES_CURVE, analysis: curveAnalysis });
  });

  app.get('/api/v1/risk', (req, res) => {
    res.json({ backtest: INITIAL_BACKTEST, riskMetrics: INITIAL_RISK });
  });

  app.get('/api/v1/contracts', (req, res) => {
    res.json({
      contracts: INITIAL_SMART_CONTRACTS,
      specs: INITIAL_SMART_CONTRACTS,
      events: INITIAL_CONTRACT_EVENTS,
      oracleNodes: INITIAL_ORACLE_NODES,
      oracleConsensus: INITIAL_ORACLE_CONSENSUS,
      inventoryTokens: INITIAL_INVENTORY_TOKENS,
    });
  });

  app.get('/api/v1/oracles', (req, res) => {
    res.json({ observations: INITIAL_ORACLE_NODES, consensus: INITIAL_ORACLE_CONSENSUS });
  });

  app.get('/api/v1/delivery', (req, res) => {
    res.json(INITIAL_PHYSICAL_DELIVERY);
  });

  app.get('/api/v1/backtest', (req, res) => {
    res.json(INITIAL_BACKTEST);
  });

  app.post('/api/v1/quant/backtest', (req, res) => {
    res.json(INITIAL_BACKTEST);
  });

  app.get('/api/v1/surveillance', (req, res) => {
    res.json({ alerts: INITIAL_SURVEILLANCE, compliance: INITIAL_COMPLIANCE });
  });

  app.get('/api/v1/compliance', (req, res) => {
    res.json(INITIAL_COMPLIANCE);
  });

  // Catch-all 404 handler for API routes
  app.all('/api/*', (req, res) => {
    res.status(404).json({ error: `API route ${req.method} ${req.path} not found` });
  });

  // Vite middleware setup for dev / production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoTrade Core Exchange Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
