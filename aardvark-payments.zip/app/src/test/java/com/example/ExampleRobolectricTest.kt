package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.aardvark.engine.CryptoEngine
import com.example.aardvark.engine.RiskEngine
import com.example.aardvark.model.RiskLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aardvark Pay", appName)
    }

    @Test
    fun `test crypto engine nonce and key generation`() {
        val sessionId = CryptoEngine.generateSessionId()
        val crypto = CryptoEngine.generateSessionCrypto(sessionId, 24.80, "MERCH-RHINO-0042")
        assertNotNull(crypto.transactionNonce)
        assertTrue(crypto.transactionNonce.isNotEmpty())
        assertTrue(crypto.merchantSessionKey.contains("ECDH"))
        assertTrue(crypto.signatureReference.startsWith("SIG_ED25519_"))
    }

    @Test
    fun `test risk engine thresholds`() {
        val lowRisk = RiskEngine.evaluateTransaction(amount = 24.80)
        assertEquals(RiskLevel.LOW, lowRisk.level)
        assertTrue(lowRisk.nonceVerified)
        assertTrue(lowRisk.replayProtected)

        val highRisk = RiskEngine.evaluateTransaction(amount = 24.80, forceDecline = true)
        assertEquals(RiskLevel.HIGH, highRisk.level)

        val stepUpRequired = RiskEngine.requiresStepUpAuthentication(150.0)
        assertTrue(stepUpRequired)
    }
}
