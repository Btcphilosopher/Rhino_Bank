package com.example.aardvark.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 12 Discrete NFC Session States as specified in project requirements
 */
enum class NfcSessionState(val label: String, val description: String) {
    IDLE("IDLE", "Device NFC ready. Awaiting request."),
    DISCOVERING("DISCOVERING", "Searching for peer NFC terminal..."),
    NFC_DETECTED("NFC DETECTED", "Peer device within near-field range (2.4 cm)."),
    SESSION_INITIALISED("SESSION INITIALISED", "Mutual cryptographic handshake established."),
    PAYMENT_REQUEST_RECEIVED("PAYMENT REQUEST RECEIVED", "Encrypted payment payload transmitted to buyer."),
    BUYER_REVIEW("BUYER REVIEW", "Reviewing merchant identity and amount."),
    BUYER_AUTHORISED("BUYER AUTHORISED", "Payment authorised via biometric/PIN credentials."),
    PAYMENT_PROCESSING("PAYMENT PROCESSING", "Simulating Rhino Bank risk scoring & ledger auth..."),
    PAYMENT_APPROVED("PAYMENT APPROVED", "Transaction settled. Digital receipt signed."),
    PAYMENT_DECLINED("PAYMENT DECLINED", "Transaction declined by simulated risk engine."),
    COMPLETED("COMPLETED", "NFC field closed. Receipt archived."),
    CANCELLED("CANCELLED", "Session aborted by operator or user."),
    TIMEOUT("TIMEOUT", "NFC proximity lost or handshake timed out.")
}

enum class RiskLevel(val label: String) {
    LOW("LOW RISK"),
    MEDIUM("MEDIUM RISK"),
    HIGH("HIGH RISK")
}

enum class AuthMethod(val label: String) {
    BIOMETRIC("Biometric (Face/Touch ID)"),
    DEVICE_PIN("Device PIN"),
    PASSCODE("Rhino Passcode"),
    NONE("Contactless Low-Value")
}

enum class FundingSourceType(val label: String) {
    RHINO_BANK("Rhino Bank Primary Account"),
    AARDVARK_BALANCE("Aardvark Stored Balance"),
    DEMO_CARD("Demo Corporate Visa Card")
}

data class FundingSource(
    val id: String,
    val name: String,
    val identifier: String, // e.g. "•••• 4821"
    val type: FundingSourceType,
    val balance: Double,
    val currency: String = "£",
    val isDefault: Boolean = false
)

data class RiskAssessment(
    val level: RiskLevel = RiskLevel.LOW,
    val deviceTrustScore: Int = 98,       // 0-100%
    val sessionValidityScore: Int = 100,  // 0-100%
    val velocityStatus: String = "NORMAL",
    val nonceVerified: Boolean = true,
    val replayProtected: Boolean = true,
    val fraudRiskScore: Double = 0.02,
    val reason: String = "Normal velocity • Registered device • Verified nonce"
)

data class CryptoSessionData(
    val merchantSessionKey: String, // e.g. "04A8B9... [ECDH P-256 Ephemeral]"
    val buyerSessionKey: String,    // e.g. "043F9C... [ECDH P-256 Ephemeral]"
    val transactionNonce: String,   // e.g. "9F81-E22A-77C1"
    val sessionId: String,          // e.g. "sess_aard_984129"
    val signatureReference: String, // e.g. "SIG_ED25519_88F0B"
    val encryptionCipher: String = "AES-256-GCM / Ephemeral Key Exchange"
)

data class PaymentSession(
    val sessionId: String,
    val merchantId: String = "MERCH-RHINO-0042",
    val merchantName: String = "The Coffee House",
    val merchantCity: String = "London, UK",
    val baseAmount: Double,
    val tipAmount: Double = 0.0,
    val currency: String = "£",
    val timestamp: Long = System.currentTimeMillis(),
    val nonce: String,
    val requestType: String = "SALE",
    val deviceCapabilities: String = "NFC-A / ISO-DEP / High-Speed Host Card Emulation",
    val state: NfcSessionState = NfcSessionState.IDLE,
    val riskAssessment: RiskAssessment = RiskAssessment(),
    val cryptoDetails: CryptoSessionData,
    val selectedFundingSource: FundingSource? = null,
    val authMethodUsed: AuthMethod = AuthMethod.NONE,
    val transactionId: String? = null,
    val isOfflineQueued: Boolean = false,
    val splitCount: Int = 1,
    val splitIndex: Int = 1,
    val failureReason: String? = null
) {
    val totalAmount: Double get() = baseAmount + tipAmount
}

data class DigitalReceipt(
    val transactionId: String,
    val merchantName: String,
    val merchantId: String,
    val merchantCity: String,
    val amount: Double,
    val tipAmount: Double,
    val totalAmount: Double,
    val currency: String,
    val dateString: String,
    val timeString: String,
    val paymentMethod: String,
    val fundingSourceLast4: String,
    val status: String,
    val authMethod: String,
    val cryptoDigest: String,
    val riskLevel: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class MerchantDeviceTelemetry(
    val id: String,
    val name: String,
    val type: String, // "Pixel 9 Pro / NFC", "Aardvark Terminal Pad"
    val merchantId: String,
    val status: String, // "ACTIVE", "OFFLINE", "STANDBY"
    val batteryPercent: Int,
    val networkLatency: String, // "14ms • 5G"
    val lastActiveFormatted: String,
    val nfcActive: Boolean = true,
    val totalProcessedToday: Double = 2410.50
)

data class SettlementSummary(
    val availableBalance: Double = 42821.20,
    val pendingAmount: Double = 3182.40,
    val nextSettlementDate: String = "Tomorrow, 06:00 UTC",
    val currency: String = "£",
    val payoutAccount: String = "Rhino Bank Commercial •••• 9012"
)

data class MerchantAnalytics(
    val todaySales: Double = 8421.20,
    val transactionCount: Int = 184,
    val averageTicket: Double = 45.77,
    val refundTotal: Double = 182.40,
    val netSettlement: Double = 8238.80,
    val approvalRatePercent: Double = 98.4,
    val declineRatePercent: Double = 1.6,
    val averageAuthTimeMs: Int = 340,
    val peakHourLabel: String = "12:00 - 14:00 (Lunch Rush)"
)

object FormatUtils {
    fun formatCurrency(amount: Double, currency: String = "£"): String {
        return "$currency${String.format(Locale.UK, "%.2f", amount)}"
    }

    fun formatDateTime(timestamp: Long): Pair<String, String> {
        val date = Date(timestamp)
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.UK)
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.UK)
        return Pair(dateFormat.format(date), timeFormat.format(date))
    }
}
