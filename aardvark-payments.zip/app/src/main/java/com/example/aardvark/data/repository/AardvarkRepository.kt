package com.example.aardvark.data.repository

import com.example.aardvark.data.db.AardvarkDatabase
import com.example.aardvark.data.db.AuditLogEntity
import com.example.aardvark.data.db.MerchantDeviceEntity
import com.example.aardvark.data.db.SettlementEntity
import com.example.aardvark.data.db.TransactionEntity
import com.example.aardvark.model.FundingSource
import com.example.aardvark.model.FundingSourceType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AardvarkRepository(private val database: AardvarkDatabase) {

    val allTransactions: Flow<List<TransactionEntity>> = database.transactionDao().getAllTransactions()
    val allDevices: Flow<List<MerchantDeviceEntity>> = database.merchantDeviceDao().getAllDevices()
    val allSettlements: Flow<List<SettlementEntity>> = database.settlementDao().getAllSettlements()
    val recentAuditLogs: Flow<List<AuditLogEntity>> = database.auditLogDao().getRecentAuditLogs()

    init {
        // Seed default demo state asynchronously if empty
        CoroutineScope(Dispatchers.IO).launch {
            val count = database.transactionDao().getAllTransactions().first().size
            if (count == 0) {
                seedInitialDemoData()
            }
        }
    }

    val defaultFundingSources = listOf(
        FundingSource(
            id = "fund_rhino_01",
            name = "Rhino Bank Account",
            identifier = "•••• 4821",
            type = FundingSourceType.RHINO_BANK,
            balance = 14250.00,
            currency = "£",
            isDefault = true
        ),
        FundingSource(
            id = "fund_aardvark_02",
            name = "Aardvark Balance",
            identifier = "£1,240.80",
            type = FundingSourceType.AARDVARK_BALANCE,
            balance = 1240.80,
            currency = "£",
            isDefault = false
        ),
        FundingSource(
            id = "fund_card_03",
            name = "Demo Corporate Visa",
            identifier = "•••• 7214",
            type = FundingSourceType.DEMO_CARD,
            balance = 5000.00,
            currency = "£",
            isDefault = false
        )
    )

    suspend fun recordTransaction(entity: TransactionEntity): Long {
        return database.transactionDao().insertTransaction(entity)
    }

    suspend fun refundTransaction(transactionId: String, reason: String = "Customer return requested") {
        database.transactionDao().markRefunded(transactionId, System.currentTimeMillis(), reason)
        logAudit(
            title = "Refund Processed",
            detail = "Transaction $transactionId refunded. Amount returned to funding source.",
            severity = "SECURE"
        )
    }

    suspend fun registerDevice(device: MerchantDeviceEntity) {
        database.merchantDeviceDao().insertOrUpdateDevice(device)
        logAudit(
            title = "NFC Device Registered",
            detail = "${device.deviceName} (${device.deviceType}) provisioned for merchant.",
            severity = "INFO"
        )
    }

    suspend fun updateDeviceStatus(deviceId: String, status: String) {
        database.merchantDeviceDao().updateDeviceStatus(deviceId, status)
    }

    suspend fun renameDevice(deviceId: String, newName: String) {
        database.merchantDeviceDao().renameDevice(deviceId, newName)
    }

    suspend fun deleteDevice(deviceId: String) {
        database.merchantDeviceDao().deleteDevice(deviceId)
    }

    suspend fun logAudit(title: String, detail: String, sessionId: String? = null, severity: String = "INFO") {
        val timeFormatted = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date())
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                timestamp = System.currentTimeMillis(),
                timeFormatted = timeFormatted,
                eventTitle = title,
                eventDetail = detail,
                sessionId = sessionId,
                severity = severity
            )
        )
    }

    suspend fun triggerInstantSettlement(amount: Double) {
        val batchId = "SETTLE-RHINO-" + (1000..9999).random()
        val dateLabel = SimpleDateFormat("dd MMM yyyy", Locale.UK).format(Date())
        database.settlementDao().insertSettlement(
            SettlementEntity(
                settlementBatchId = batchId,
                dateLabel = dateLabel,
                grossSales = amount,
                refunds = 0.0,
                netSettlement = amount,
                status = "SETTLED",
                payoutAccount = "Rhino Bank Commercial •••• 9012",
                timestamp = System.currentTimeMillis()
            )
        )
        logAudit(
            title = "Instant Settlement Executed",
            detail = "Transferred £${String.format(Locale.UK, "%.2f", amount)} to Rhino Bank Commercial account.",
            severity = "SECURE"
        )
    }

    suspend fun resetDemoEnvironment() {
        database.transactionDao().clearAll()
        database.merchantDeviceDao().clearAll()
        database.settlementDao().clearAll()
        database.auditLogDao().clearAll()
        seedInitialDemoData()
    }

    suspend fun seedInitialDemoData() {
        val now = System.currentTimeMillis()
        val oneHour = 3600000L

        // Initial Transactions
        val txns = listOf(
            TransactionEntity(
                transactionId = "AARD-829194",
                sessionId = "sess_aard_coffee01",
                merchantName = "The Coffee House",
                merchantId = "MERCH-RHINO-0042",
                merchantCity = "London",
                baseAmount = 24.80,
                tipAmount = 0.00,
                totalAmount = 24.80,
                currency = "£",
                status = "APPROVED",
                timestamp = now - (15 * 60 * 1000), // 15 mins ago
                paymentMethod = "NFC Tap & Pay",
                fundingSource = "Rhino Bank Account (•••• 4821)",
                authMethod = "Biometric (Touch ID)",
                riskLevel = "LOW",
                deviceTrustScore = 98,
                sessionValidityScore = 100,
                cryptoDigest = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
            ),
            TransactionEntity(
                transactionId = "AARD-714029",
                sessionId = "sess_aard_metro02",
                merchantName = "Metro Market",
                merchantId = "MERCH-RHINO-0089",
                merchantCity = "London",
                baseAmount = 61.40,
                tipAmount = 0.00,
                totalAmount = 61.40,
                currency = "£",
                status = "APPROVED",
                timestamp = now - (35 * 60 * 1000),
                paymentMethod = "NFC Tap & Pay",
                fundingSource = "Aardvark Stored Balance",
                authMethod = "Device PIN",
                riskLevel = "LOW",
                deviceTrustScore = 96,
                sessionValidityScore = 100,
                cryptoDigest = "a7b9c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852c921"
            ),
            TransactionEntity(
                transactionId = "AARD-639112",
                sessionId = "sess_aard_aureom03",
                merchantName = "Aureom Store",
                merchantId = "MERCH-RHINO-0012",
                merchantCity = "London",
                baseAmount = 112.00,
                tipAmount = 0.00,
                totalAmount = 112.00,
                currency = "£",
                status = "APPROVED",
                timestamp = now - (70 * 60 * 1000),
                paymentMethod = "NFC Tap & Pay",
                fundingSource = "Demo Corporate Visa (•••• 7214)",
                authMethod = "Biometric (Face ID)",
                riskLevel = "LOW",
                deviceTrustScore = 99,
                sessionValidityScore = 100,
                cryptoDigest = "f4c9c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852d004"
            ),
            TransactionEntity(
                transactionId = "AARD-558291",
                sessionId = "sess_aard_north04",
                merchantName = "North Street Café",
                merchantId = "MERCH-RHINO-0055",
                merchantCity = "London",
                baseAmount = 8.90,
                tipAmount = 0.00,
                totalAmount = 8.90,
                currency = "£",
                status = "DECLINED",
                timestamp = now - (110 * 60 * 1000),
                paymentMethod = "NFC Tap & Pay",
                fundingSource = "Demo Corporate Visa",
                authMethod = "Contactless Low-Value",
                riskLevel = "HIGH",
                deviceTrustScore = 48,
                sessionValidityScore = 70,
                cryptoDigest = "d1a0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852a118"
            )
        )
        txns.forEach { database.transactionDao().insertTransaction(it) }

        // Initial Merchant Devices
        val devices = listOf(
            MerchantDeviceEntity(
                deviceId = "DEV-RHINO-01",
                deviceName = "Terminal 01 (Front Counter)",
                deviceType = "Pixel / NFC Native Terminal",
                merchantId = "MERCH-RHINO-0042",
                status = "ACTIVE",
                batteryLevel = 94,
                networkInfo = "5G • 12ms",
                lastActiveTimestamp = now - 120000,
                nfcHardwareReady = true,
                totalTransactionsToday = 112,
                totalVolumeToday = 5280.40
            ),
            MerchantDeviceEntity(
                deviceId = "DEV-RHINO-02",
                deviceName = "Terminal 02 (Patio Mobile)",
                deviceType = "Samsung Galaxy / NFC Mobile POS",
                merchantId = "MERCH-RHINO-0042",
                status = "ACTIVE",
                batteryLevel = 78,
                networkInfo = "Wi-Fi 6 • 8ms",
                lastActiveTimestamp = now - 340000,
                nfcHardwareReady = true,
                totalTransactionsToday = 58,
                totalVolumeToday = 2640.80
            ),
            MerchantDeviceEntity(
                deviceId = "DEV-RHINO-03",
                deviceName = "Terminal 03 (Drive-Thru)",
                deviceType = "Aardvark Dedicated Tablet / NFC",
                merchantId = "MERCH-RHINO-0042",
                status = "OFFLINE",
                batteryLevel = 15,
                networkInfo = "Offline",
                lastActiveTimestamp = now - (6 * oneHour),
                nfcHardwareReady = true,
                totalTransactionsToday = 14,
                totalVolumeToday = 500.00
            )
        )
        devices.forEach { database.merchantDeviceDao().insertOrUpdateDevice(it) }

        // Initial Settlements
        val settlements = listOf(
            SettlementEntity(
                settlementBatchId = "SETTLE-RHINO-8901",
                dateLabel = "Yesterday",
                grossSales = 8421.20,
                refunds = 182.40,
                netSettlement = 8238.80,
                status = "SETTLED",
                payoutAccount = "Rhino Bank Commercial •••• 9012",
                timestamp = now - (24 * oneHour)
            ),
            SettlementEntity(
                settlementBatchId = "SETTLE-RHINO-8744",
                dateLabel = "2 days ago",
                grossSales = 9104.50,
                refunds = 45.00,
                netSettlement = 9059.50,
                status = "SETTLED",
                payoutAccount = "Rhino Bank Commercial •••• 9012",
                timestamp = now - (48 * oneHour)
            )
        )
        settlements.forEach { database.settlementDao().insertSettlement(it) }

        // Initial Audit Logs
        val logs = listOf(
            Triple("Payment session created", "Session sess_aard_coffee01 initialized for £24.80", "INFO"),
            Triple("NFC handshake completed", "Mutual ECDH P-256 key agreement verified in 184ms", "SECURE"),
            Triple("Buyer authentication successful", "Biometric Touch ID credentials verified with Rhino Bank SCA", "SECURE"),
            Triple("Risk assessment completed", "Low risk score (0.02) • Device trust 98% • Nonce verified", "SECURE"),
            Triple("Payment approved", "Rhino Bank ledger debited £24.80. Transaction AARD-829194 committed.", "SECURE"),
            Triple("Receipt generated", "Digital token signed and delivered over NFC confirmation frame.", "INFO")
        )
        logs.forEach { (title, detail, severity) ->
            logAudit(title, detail, severity = severity)
        }
    }
}
