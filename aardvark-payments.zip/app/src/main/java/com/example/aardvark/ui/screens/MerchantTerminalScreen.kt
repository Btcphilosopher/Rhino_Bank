package com.example.aardvark.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.aardvark.model.FormatUtils
import com.example.aardvark.model.NfcSessionState
import com.example.aardvark.ui.components.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

@Composable
fun MerchantTerminalScreen(
    viewModel: AardvarkViewModel,
    modifier: Modifier = Modifier
) {
    val amountString by viewModel.keypadAmountString.collectAsStateWithLifecycle()
    val tipPercent by viewModel.selectedTipPercent.collectAsStateWithLifecycle()
    val tipAmount by viewModel.customTipAmount.collectAsStateWithLifecycle()
    val splitCount by viewModel.splitPayersCount.collectAsStateWithLifecycle()
    val isOfflineMode by viewModel.isOfflineModeEnabled.collectAsStateWithLifecycle()
    val offlineQueuedCount by viewModel.offlineQueuedCount.collectAsStateWithLifecycle()
    val sessionState by viewModel.activeSessionState.collectAsStateWithLifecycle()
    val session by viewModel.activePaymentSession.collectAsStateWithLifecycle()

    val parsedBase = amountString.toDoubleOrNull() ?: 0.0
    val totalAmount = parsedBase + tipAmount
    val splitPerPayer = if (splitCount > 0) totalAmount / splitCount else totalAmount

    var showNfcOverlay by remember { mutableStateOf(false) }

    LaunchedEffect(sessionState) {
        if (sessionState == NfcSessionState.DISCOVERING ||
            sessionState == NfcSessionState.NFC_DETECTED ||
            sessionState == NfcSessionState.SESSION_INITIALISED ||
            sessionState == NfcSessionState.BUYER_REVIEW ||
            sessionState == NfcSessionState.BUYER_AUTHORISED ||
            sessionState == NfcSessionState.PAYMENT_PROCESSING
        ) {
            showNfcOverlay = true
        } else if (sessionState == NfcSessionState.IDLE) {
            showNfcOverlay = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        DemoEnvironmentBanner()

        // Merchant Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AARDVARK TERMINAL",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = RhinoElectric,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Shop Terminal 01 (Flagship)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            // Offline Toggle Button
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .testTag("toggle_offline_button")
                    .clickable { viewModel.toggleOfflineMode(!isOfflineMode) },
                color = if (isOfflineMode) FinancialWarningBg else SurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isOfflineMode) FinancialWarning else SurfaceBorder
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (isOfflineMode) Icons.Default.CloudOff else Icons.Default.CloudDone,
                        contentDescription = "Offline Mode",
                        tint = if (isOfflineMode) FinancialWarning else FinancialSuccess,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOfflineMode) "OFFLINE QUEUE ($offlineQueuedCount)" else "ONLINE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isOfflineMode) FinancialWarning else FinancialSuccess,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Display Screen Card
        FintechCard(
            modifier = Modifier.fillMaxWidth().testTag("terminal_display_card"),
            backgroundColor = Color(0xFF141414),
            borderColor = Color(0xFF262626)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isOfflineMode) "DEMO OFFLINE QUEUE • ENTER SALE" else "ENTER SALE AMOUNT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    fontSize = 10.sp,
                    color = if (isOfflineMode) FinancialWarning else Color(0xFF888888)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = FormatUtils.formatCurrency(totalAmount),
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-1.5).sp,
                    color = Color.White
                )

                if (tipAmount > 0 || splitCount > 1) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (tipAmount > 0) {
                            Text(
                                text = "+${FormatUtils.formatCurrency(tipAmount)} tip",
                                style = MaterialTheme.typography.bodySmall,
                                color = RhinoElectric,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (splitCount > 1) {
                            Text(
                                text = "• Split $splitCount ways (${FormatUtils.formatCurrency(splitPerPayer)} each)",
                                style = MaterialTheme.typography.bodySmall,
                                color = RhinoBlue,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Tipping Selector
        TipSelector(
            selectedTipPercent = tipPercent,
            customTipAmount = tipAmount,
            baseAmount = parsedBase,
            onTipSelected = { pct, amt -> viewModel.setTip(pct, amt) }
        )

        // Split Payment Control
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SPLIT PAYMENT",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontSize = 10.sp
                )
                if (splitCount > 1) {
                    Text(
                        text = "$splitCount Payers • ${FormatUtils.formatCurrency(splitPerPayer)} / person",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoElectric,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(1, 2, 3, 4).forEach { count ->
                    val isSelected = splitCount == count
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                1.dp,
                                if (isSelected) RhinoElectric else Color(0xFF262626),
                                RoundedCornerShape(8.dp)
                            )
                            .testTag("split_button_$count")
                            .clickable { viewModel.setSplitCount(count) },
                        color = if (isSelected) Color(0x1A00FF88) else Color(0xFF161616)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (count == 1) "Single" else "$count Payers",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) RhinoElectric else TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Tactile Numeric Keypad
        NumericKeypad(
            onDigitClick = { viewModel.onKeypadDigit(it) },
            onBackspaceClick = { viewModel.onKeypadBackspace() },
            onClearClick = { viewModel.onKeypadClear() }
        )

        // Start NFC Charge Button
        Button(
            onClick = {
                if (totalAmount > 0) {
                    viewModel.startNfcPayment()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("terminal_charge_button"),
            enabled = totalAmount > 0,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = RhinoElectric,
                contentColor = Color(0xFF0A0A0A),
                disabledContainerColor = Color(0xFF1C1C1C),
                disabledContentColor = Color(0xFF555555)
            )
        ) {
            Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "CHARGE ${FormatUtils.formatCurrency(totalAmount)}  [ TAP TO PAY ]",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp
            )
        }

        // Active NFC Overlay / Terminal Modal
        AnimatedVisibility(visible = showNfcOverlay) {
            FintechCard(
                modifier = Modifier.fillMaxWidth().testTag("terminal_nfc_active_card"),
                backgroundColor = SurfaceDark,
                borderColor = RhinoElectric
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "READY FOR NFC",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = RhinoElectric
                    )
                    Text(
                        text = "Hold customer's smartphone or wearable near this device",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    NfcProximityVisualizer(
                        sessionState = sessionState,
                        amountFormatted = FormatUtils.formatCurrency(totalAmount),
                        merchantName = "Shop Terminal 01"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (sessionState == NfcSessionState.BUYER_REVIEW) {
                        Button(
                            onClick = { viewModel.authoriseActivePayment() },
                            modifier = Modifier.fillMaxWidth().height(44.dp).testTag("sim_buyer_touch_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = FinancialSuccessBg),
                            border = androidx.compose.foundation.BorderStroke(1.dp, FinancialSuccess)
                        ) {
                            Icon(Icons.Default.TouchApp, contentDescription = null, tint = FinancialSuccess)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SIMULATE BUYER TAP & APPROVE", color = FinancialSuccess, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            viewModel.cancelPaymentSession()
                            showNfcOverlay = false
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp).testTag("dismiss_terminal_overlay"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text("CLOSE TERMINAL OVERLAY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
