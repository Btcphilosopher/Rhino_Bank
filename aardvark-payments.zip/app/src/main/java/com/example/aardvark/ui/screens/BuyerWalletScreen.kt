package com.example.aardvark.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.aardvark.model.FundingSource
import com.example.aardvark.model.FundingSourceType
import com.example.aardvark.model.FormatUtils
import com.example.aardvark.ui.components.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

@Composable
fun BuyerWalletScreen(
    viewModel: AardvarkViewModel,
    modifier: Modifier = Modifier
) {
    val fundingSources by viewModel.fundingSources.collectAsStateWithLifecycle()
    val selectedFunding by viewModel.selectedFundingSource.collectAsStateWithLifecycle()
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    var contactlessLimit by remember { mutableStateOf(100) }
    var biometricEnabled by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            DemoEnvironmentBanner()
        }

        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AARDVARK PAY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = RhinoElectric,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Buyer Digital Wallet",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                StatusBadge(status = "ACTIVE")
            }
        }

        // Active Card Visual Presentation
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .testTag("buyer_primary_card"),
                shape = RoundedCornerShape(20.dp),
                color = SurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric.copy(alpha = 0.5f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF0F172A),
                                    Color(0xFF1E293B),
                                    Color(0xFF1E3A8A)
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Top Card Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "RHINO BANK",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    letterSpacing = 1.5.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• AARDVARK",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RhinoElectric,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Icon(Icons.Default.Nfc, contentDescription = "Contactless", tint = RhinoElectric, modifier = Modifier.size(24.dp))
                        }

                        // EMV Chip Icon
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp, 28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(FinancialGold.copy(alpha = 0.8f))
                                    .border(1.dp, Color(0xFFD97706), RoundedCornerShape(6.dp))
                            )
                        }

                        // Bottom Card Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = selectedFunding.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = selectedFunding.identifier,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    color = MetallicSilver
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "AVAILABLE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.sp,
                                    color = TextSecondary
                                )
                                Text(
                                    text = FormatUtils.formatCurrency(selectedFunding.balance),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = RhinoElectric
                                )
                            }
                        }
                    }
                }
            }
        }

        // Funding Source Selector
        item {
            Text(
                text = "FUNDING INSTRUMENTS (DEMO SOURCES)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
        }

        items(fundingSources, key = { it.id }) { source ->
            val isSelected = selectedFunding.id == source.id
            FintechCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .testTag("funding_source_${source.id}")
                    .clickable { viewModel.selectFundingSource(source) },
                backgroundColor = if (isSelected) SurfaceElevated else SurfaceDark,
                borderColor = if (isSelected) RhinoElectric else SurfaceBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    when (source.type) {
                                        FundingSourceType.RHINO_BANK -> RhinoBlue.copy(alpha = 0.3f)
                                        FundingSourceType.AARDVARK_BALANCE -> AardvarkCyan.copy(alpha = 0.3f)
                                        FundingSourceType.DEMO_CARD -> FinancialPurple.copy(alpha = 0.3f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (source.type) {
                                    FundingSourceType.RHINO_BANK -> Icons.Default.AccountBalance
                                    FundingSourceType.AARDVARK_BALANCE -> Icons.Default.AccountBalanceWallet
                                    FundingSourceType.DEMO_CARD -> Icons.Default.CreditCard
                                },
                                contentDescription = null,
                                tint = RhinoElectric,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = source.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${source.identifier} • Balance: ${FormatUtils.formatCurrency(source.balance)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(RhinoElectric),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Selected", tint = BackgroundDark, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Contactless Limits & SCA Control
        item {
            FintechCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "NFC SECURITY & AUTHENTICATION",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Standard Contactless Limit",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Payments above £100 require Strong Customer Authentication (SCA)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "£100.00",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = RhinoElectric
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = SurfaceBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Biometric Passkey (Face/Touch ID)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Simulate device-level biometric signing token",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = biometricEnabled,
                        onCheckedChange = { biometricEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BackgroundDark,
                            checkedTrackColor = RhinoElectric
                        )
                    )
                }
            }
        }

        // Recent Buyer Receipts Archive
        item {
            Text(
                text = "RECENT DIGITAL RECEIPTS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
        }

        items(transactions.filter { it.status == "APPROVED" }.take(5), key = { it.transactionId }) { txn ->
            val (_, timeStr) = FormatUtils.formatDateTime(txn.timestamp)
            FintechCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("buyer_receipt_${txn.transactionId}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = txn.merchantName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${txn.transactionId} • $timeStr",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = FormatUtils.formatCurrency(txn.totalAmount, txn.currency),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        StatusBadge(status = "APPROVED")
                    }
                }
            }
        }
    }
}
