package com.example.aardvark.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.NfcSessionState
import com.example.ui.theme.*

@Composable
fun NfcProximityVisualizer(
    sessionState: NfcSessionState,
    amountFormatted: String,
    merchantName: String,
    modifier: Modifier = Modifier,
    isHighValue: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_pulse")

    // Pulse animation for discovering/detected states
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_scale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha"
    )

    val isTransmitting = sessionState in listOf(
        NfcSessionState.DISCOVERING,
        NfcSessionState.NFC_DETECTED,
        NfcSessionState.SESSION_INITIALISED,
        NfcSessionState.PAYMENT_PROCESSING
    )

    val isApproved = sessionState in listOf(
        NfcSessionState.PAYMENT_APPROVED,
        NfcSessionState.COMPLETED
    )

    val isDeclined = sessionState in listOf(
        NfcSessionState.PAYMENT_DECLINED,
        NfcSessionState.CANCELLED,
        NfcSessionState.TIMEOUT
    )

    val activeColor = when {
        isApproved -> FinancialSuccess
        isDeclined -> FinancialError
        isTransmitting -> RhinoElectric
        else -> TextSecondary
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("nfc_proximity_visualizer"),
        color = Color(0xFF121212),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262626))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top telemetry tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Nfc,
                        contentDescription = "NFC",
                        tint = activeColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "13.56 MHz • ISO/IEC 18092",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                StatusBadge(status = sessionState.label)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Central Animated NFC Wave Chamber with Immersive radar rings
            Box(
                modifier = Modifier
                    .size(170.dp)
                    .testTag("nfc_wave_chamber"),
                contentAlignment = Alignment.Center
            ) {
                // Background concentric radar wave canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val baseRadius = size.width / 4f

                    // Draw outer radar boundary rings (Immersive dark style)
                    drawCircle(
                        color = Color(0xFF222222),
                        radius = size.width / 2f - 4.dp.toPx(),
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFF1A1A1A),
                        radius = size.width / 2.5f,
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                    drawCircle(
                        color = activeColor.copy(alpha = 0.15f),
                        radius = baseRadius * 1.3f,
                        center = center,
                        style = Stroke(width = 1.5.dp.toPx())
                    )

                    // Dynamic pulse rings if transmitting
                    if (isTransmitting) {
                        drawCircle(
                            color = activeColor.copy(alpha = pulseAlpha),
                            radius = baseRadius * pulseScale,
                            center = center,
                            style = Stroke(width = 2.dp.toPx())
                        )
                        drawCircle(
                            color = activeColor.copy(alpha = (pulseAlpha * 0.5f)),
                            radius = baseRadius * (pulseScale * 1.25f),
                            center = center,
                            style = Stroke(width = 1.dp.toPx())
                        )
                    }
                }

                // Core central 3D-styled rounded gradient pad (Matching Immersive UI)
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF222222),
                                    Color(0xFF080808)
                                )
                            )
                        )
                        .border(
                            1.5.dp,
                            if (isApproved || isTransmitting) activeColor.copy(alpha = 0.8f) else Color(0xFF333333),
                            RoundedCornerShape(22.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when {
                        isApproved -> Icons.Default.Check
                        isDeclined -> Icons.Default.Close
                        sessionState == NfcSessionState.BUYER_AUTHORISED -> Icons.Default.Fingerprint
                        sessionState == NfcSessionState.BUYER_REVIEW -> Icons.Default.TouchApp
                        else -> Icons.Default.Nfc
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = "NFC State",
                        tint = activeColor,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dynamic State Title & Instructions
            Text(
                text = when (sessionState) {
                    NfcSessionState.IDLE -> "READY FOR NFC TAP"
                    NfcSessionState.DISCOVERING -> "HOLD DEVICES TOGETHER"
                    NfcSessionState.NFC_DETECTED -> "NFC DEVICE DETECTED"
                    NfcSessionState.SESSION_INITIALISED -> "SECURE ECDH HANDSHAKE"
                    NfcSessionState.PAYMENT_REQUEST_RECEIVED -> "PAYMENT REQUEST: $amountFormatted"
                    NfcSessionState.BUYER_REVIEW -> "REVIEW & AUTHORISE"
                    NfcSessionState.BUYER_AUTHORISED -> "AUTHORISED • PROCESSING"
                    NfcSessionState.PAYMENT_PROCESSING -> "AUTHORISING WITH RHINO BANK..."
                    NfcSessionState.PAYMENT_APPROVED -> "PAYMENT APPROVED"
                    NfcSessionState.PAYMENT_DECLINED -> "PAYMENT DECLINED"
                    NfcSessionState.COMPLETED -> "PAYMENT COMPLETE"
                    NfcSessionState.CANCELLED -> "TRANSACTION CANCELLED"
                    NfcSessionState.TIMEOUT -> "NFC SESSION TIMEOUT"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (isApproved) FinancialSuccess else if (isDeclined) FinancialError else TextPrimary,
                textAlign = TextAlign.Center,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = sessionState.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                fontSize = 12.sp
            )

            if (isHighValue) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = FinancialWarningBg,
                    border = androidx.compose.foundation.BorderStroke(1.dp, FinancialWarning.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = "SCA",
                            tint = FinancialWarning,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "HIGH-VALUE PAYMENT • STEP-UP BIOMETRIC AUTH REQUIRED",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = FinancialWarning
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Proximity & Crypto Session Micro-Indicators (Immersive Dark Style)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF181818))
                    .border(1.dp, Color(0xFF262626), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isApproved || isTransmitting) RhinoElectric else TextTertiary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isTransmitting) "NFC RANGE: 2.1 cm" else if (isApproved) "SESSION VERIFIED" else "STANDBY",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextPrimary
                    )
                }

                Text(
                    text = "AES-256-GCM • ECDH P-256",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = RhinoElectric
                )
            }
        }
    }
}
