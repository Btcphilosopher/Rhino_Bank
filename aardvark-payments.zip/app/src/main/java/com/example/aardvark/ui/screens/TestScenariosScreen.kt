package com.example.aardvark.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.ui.components.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

data class SandboxScenario(
    val id: String,
    val title: String,
    val description: String,
    val tag: String,
    val tagColor: Color,
    val action: (AardvarkViewModel) -> Unit
)

@Composable
fun TestScenariosScreen(
    viewModel: AardvarkViewModel,
    modifier: Modifier = Modifier
) {
    val scenarios = remember {
        listOf(
            SandboxScenario(
                id = "scen_standard",
                title = "1. Standard Contactless Payment (£24.80)",
                description = "Baseline coffee shop NFC transaction with low risk score and instant Rhino Bank settlement.",
                tag = "SUCCESS",
                tagColor = FinancialSuccess,
                action = { vm ->
                    vm.setAmountDirect("24.80")
                    vm.setTip(null, 0.0)
                    vm.setSplitCount(1)
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 24.80)
                }
            ),
            SandboxScenario(
                id = "scen_high_value",
                title = "2. High-Value Step-Up Payment (£240.00)",
                description = "Amount exceeds £100 contactless limit; triggers Strong Customer Authentication (SCA) biometric verification.",
                tag = "STEP-UP SCA",
                tagColor = FinancialPurple,
                action = { vm ->
                    vm.setAmountDirect("240.00")
                    vm.setTip(null, 0.0)
                    vm.setSplitCount(1)
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 240.00, isHighValueSim = true)
                }
            ),
            SandboxScenario(
                id = "scen_decline",
                title = "3. High-Risk Decline Simulation (£85.00)",
                description = "Simulates risk engine rejection due to anomalous device velocity or insufficient funds.",
                tag = "DECLINE",
                tagColor = FinancialError,
                action = { vm ->
                    vm.setAmountDirect("85.00")
                    vm.setTip(null, 0.0)
                    vm.setSplitCount(1)
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 85.00, forceDecline = true)
                }
            ),
            SandboxScenario(
                id = "scen_replay",
                title = "4. Cryptographic Replay Attack Defense",
                description = "Injects an identical transaction nonce from previous session; rejected by sliding window nonce defense.",
                tag = "SECURITY DEFENSE",
                tagColor = FinancialWarning,
                action = { vm ->
                    vm.setAmountDirect("45.00")
                    vm.setTip(null, 0.0)
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 45.00, isDuplicate = true)
                }
            ),
            SandboxScenario(
                id = "scen_split",
                title = "5. Multi-Payer Split Bill (£120 ÷ 2 Payers)",
                description = "Splits bill into £60/payer segments with sequential NFC authorisations.",
                tag = "SPLIT BILL",
                tagColor = AardvarkCyan,
                action = { vm ->
                    vm.setAmountDirect("120.00")
                    vm.setTip(null, 0.0)
                    vm.setSplitCount(2)
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 120.00)
                }
            ),
            SandboxScenario(
                id = "scen_offline",
                title = "6. Offline Queue Payment (£18.50)",
                description = "Terminal conducts cryptographic offline handshake and queues transaction for deferred network sync.",
                tag = "OFFLINE QUEUE",
                tagColor = FinancialGold,
                action = { vm ->
                    vm.setAmountDirect("18.50")
                    vm.toggleOfflineMode(true)
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 18.50, isOfflineQueued = true)
                }
            ),
            SandboxScenario(
                id = "scen_timeout",
                title = "7. NFC RF Field Disconnection Timeout",
                description = "Simulates buyer pulling device away before handshake or signature completion.",
                tag = "TIMEOUT",
                tagColor = MetallicSilver,
                action = { vm ->
                    vm.setAmountDirect("30.00")
                    vm.selectTab(0)
                    vm.startNfcPayment(customAmount = 30.00, isTimeout = true)
                }
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            DemoEnvironmentBanner()
        }

        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TEST HARNESS & SANDBOX",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = RhinoElectric,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Demonstration Scenarios",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }
        }

        // Master Reset Button
        item {
            FintechCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = Color(0xFF1B1824),
                borderColor = FinancialWarning.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "RESET DEMO ENVIRONMENT",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = FinancialWarning
                        )
                        Text(
                            text = "Clears all test transactions and reseeds baseline Rhino Bank & Aardvark data.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.resetDemoEnvironment() },
                        colors = ButtonDefaults.buttonColors(containerColor = FinancialWarningBg),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FinancialWarning),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("reset_demo_button")
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, tint = FinancialWarning, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RESET", color = FinancialWarning, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "AUTOMATED TEST SCENARIOS (CLICK TO EXECUTE)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
        }

        items(scenarios.size) { index ->
            val scenario = scenarios[index]
            FintechCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .testTag("scenario_card_${scenario.id}")
                    .clickable { scenario.action(viewModel) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = scenario.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = scenario.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = scenario.tagColor.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, scenario.tagColor.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = scenario.tag,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = scenario.tagColor,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
