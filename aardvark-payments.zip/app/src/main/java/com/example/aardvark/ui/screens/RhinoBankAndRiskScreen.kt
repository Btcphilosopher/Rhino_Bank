package com.example.aardvark.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.aardvark.data.db.AuditLogEntity
import com.example.aardvark.ui.components.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

@Composable
fun RhinoBankAndRiskScreen(
    viewModel: AardvarkViewModel,
    modifier: Modifier = Modifier
) {
    val auditLogs by viewModel.recentAuditLogs.collectAsStateWithLifecycle()
    val session by viewModel.activePaymentSession.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            DemoEnvironmentBanner()
        }

        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RHINO BANK CORE & RISK",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = RhinoElectric,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Payment Infrastructure",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                StatusBadge(status = "ACTIVE")
            }
        }

        // Rhino Bank Corporate Relationship Card
        item {
            FintechCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = SurfaceElevated,
                borderColor = RhinoBlue
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "RHINO BANK PLC",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "Regulated Financial Institution • Clearing & Settlement",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(RhinoBlue.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AccountBalance, contentDescription = null, tint = RhinoElectric, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SurfaceBorder)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AARDVARK PAYMENTS LTD",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = RhinoElectric
                        )
                        Text(
                            text = "Wholly Owned Technology Subsidiary • NFC Network Provider",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "100% OWNED",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = FinancialSuccess
                    )
                }
            }
        }

        // Cryptographic Architecture Inspector
        item {
            FintechCard(modifier = Modifier.fillMaxWidth().testTag("crypto_inspector_card")) {
                Text(
                    text = "CRYPTOGRAPHIC PROTOCOL & PROTOCOL STACK",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                ReceiptRow(label = "Physical Interface", value = "13.56 MHz NFC / ISO-DEP (ISO 14443-4)")
                ReceiptRow(label = "Key Agreement", value = "ECDH NIST P-256 (Ephemeral session keys)")
                ReceiptRow(label = "Transport Cipher", value = "AES-256-GCM (Authenticated Encryption)")
                ReceiptRow(label = "SCA Digital Signatures", value = "ED25519 Hardware-backed Token")
                ReceiptRow(label = "Replay Protection", value = "64-bit Nonce sliding window (60s validity)")
                ReceiptRow(
                    label = "Active Session Nonce",
                    value = session?.nonce ?: "9A8F3C12B47E01D6",
                    isMonospace = true
                )
            }
        }

        // Risk Engine Live Matrix
        item {
            FintechCard(modifier = Modifier.fillMaxWidth().testTag("risk_matrix_card")) {
                Text(
                    text = "AARDVARK RISK & FRAUD ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        title = "Device Trust",
                        value = "${session?.riskAssessment?.deviceTrustScore ?: 98}%",
                        subtitle = "Hardware attestation",
                        icon = Icons.Default.VerifiedUser,
                        accentColor = FinancialSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Fraud Score",
                        value = "${String.format("%.2f", session?.riskAssessment?.fraudRiskScore ?: 0.02)}",
                        subtitle = "Risk Level: ${session?.riskAssessment?.level?.name ?: "LOW"}",
                        icon = Icons.Default.Shield,
                        accentColor = if ((session?.riskAssessment?.fraudRiskScore ?: 0.0) > 0.5) FinancialError else RhinoElectric,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                ReceiptRow(
                    label = "Velocity Assessment",
                    value = session?.riskAssessment?.velocityStatus ?: "NORMAL"
                )
                ReceiptRow(
                    label = "Replay Defense",
                    value = if (session?.riskAssessment?.replayProtected == true) "VERIFIED ✓" else "FAILED ✕"
                )
                ReceiptRow(
                    label = "Strong Customer Auth (SCA)",
                    value = if ((session?.totalAmount ?: 0.0) > 100.0) "REQUIRED (>£100)" else "EXEMPT (<£100)"
                )
            }
        }

        // Live Real-Time Audit Log
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CRYPTOGRAPHIC AUDIT STREAM (${auditLogs.size})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "LIVE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = FinancialSuccess
                )
            }
        }

        items(auditLogs.take(20), key = { it.id }) { log ->
            val severityColor = when (log.severity) {
                "SECURE" -> FinancialSuccess
                "WARN" -> FinancialWarning
                "CRITICAL" -> FinancialError
                else -> RhinoElectric
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = SurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth().testTag("audit_log_${log.id}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.timeFormatted,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = TextTertiary,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(severityColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = log.eventTitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = log.eventDetail,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
