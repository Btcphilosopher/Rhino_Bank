package com.example.aardvark.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aardvark.data.db.AardvarkDatabase
import com.example.aardvark.data.db.MerchantDeviceEntity
import com.example.aardvark.data.db.SettlementEntity
import com.example.aardvark.data.db.TransactionEntity
import com.example.aardvark.data.repository.AardvarkRepository
import com.example.aardvark.engine.CryptoEngine
import com.example.aardvark.engine.RiskEngine
import com.example.aardvark.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AardvarkViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AardvarkRepository

    init {
        val db = AardvarkDatabase.getDatabase(application)
        repository = AardvarkRepository(db)
    }

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDevices: StateFlow<List<MerchantDeviceEntity>> = repository.allDevices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSettlements: StateFlow<List<SettlementEntity>> = repository.allSettlements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentAuditLogs = repository.recentAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state
    private val _selectedTab = MutableStateFlow(0) // 0=Simulator, 1=Terminal, 2=Dashboard, 3=Buyer, 4=Rhino&Risk, 5=Tests
    val selectedTab = _selectedTab.asStateFlow()

    private val _keypadAmountString = MutableStateFlow("24.80")
    val keypadAmountString = _keypadAmountString.asStateFlow()

    private val _selectedTipPercent = MutableStateFlow<Int?>(null)
    val selectedTipPercent = _selectedTipPercent.asStateFlow()

    private val _customTipAmount = MutableStateFlow(0.0)
    val customTipAmount = _customTipAmount.asStateFlow()

    private val _splitPayersCount = MutableStateFlow(1)
    val splitPayersCount = _splitPayersCount.asStateFlow()

    private val _isOfflineModeEnabled = MutableStateFlow(false)
    val isOfflineModeEnabled = _isOfflineModeEnabled.asStateFlow()

    private val _offlineQueuedCount = MutableStateFlow(0)
    val offlineQueuedCount = _offlineQueuedCount.asStateFlow()

    private val _fundingSources = MutableStateFlow(repository.defaultFundingSources)
    val fundingSources = _fundingSources.asStateFlow()

    private val _selectedFundingSource = MutableStateFlow(repository.defaultFundingSources.first())
    val selectedFundingSource = _selectedFundingSource.asStateFlow()

    private val _activePaymentSession = MutableStateFlow<PaymentSession?>(null)
    val activePaymentSession = _activePaymentSession.asStateFlow()

    private val _activeSessionState = MutableStateFlow(NfcSessionState.IDLE)
    val activeSessionState = _activeSessionState.asStateFlow()

    private val _activeReceiptDialog = MutableStateFlow<DigitalReceipt?>(null)
    val activeReceiptDialog = _activeReceiptDialog.asStateFlow()

    private val _merchantNotification = MutableStateFlow<String?>(null)
    val merchantNotification = _merchantNotification.asStateFlow()

    private val _buyerNotification = MutableStateFlow<String?>(null)
    val buyerNotification = _buyerNotification.asStateFlow()

    private var activeNfcJob: Job? = null

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun onKeypadDigit(digit: String) {
        val current = _keypadAmountString.value
        if (current == "0.00" || current == "0") {
            _keypadAmountString.value = digit
        } else {
            // Keep up to 2 decimals
            if (current.contains(".")) {
                val parts = current.split(".")
                if (parts.size > 1 && parts[1].length >= 2) return
            }
            _keypadAmountString.value = current + digit
        }
    }

    fun onKeypadBackspace() {
        val current = _keypadAmountString.value
        if (current.length > 1) {
            _keypadAmountString.value = current.dropLast(1)
        } else {
            _keypadAmountString.value = "0"
        }
    }

    fun onKeypadClear() {
        _keypadAmountString.value = "0"
    }

    fun setAmountDirect(amountStr: String) {
        _keypadAmountString.value = amountStr
    }

    fun setTip(percent: Int?, amount: Double?) {
        _selectedTipPercent.value = percent
        _customTipAmount.value = amount ?: 0.0
    }

    fun setSplitCount(count: Int) {
        _splitPayersCount.value = count
    }

    fun toggleOfflineMode(enabled: Boolean) {
        _isOfflineModeEnabled.value = enabled
        viewModelScope.launch {
            repository.logAudit(
                title = if (enabled) "Offline Mode Enabled" else "Online Mode Restored",
                detail = if (enabled) "Merchant terminal configured for Demo Offline Queue" else "Direct Rhino Bank network connectivity restored",
                severity = if (enabled) "WARN" else "INFO"
            )
        }
    }

    fun selectFundingSource(source: FundingSource) {
        _selectedFundingSource.value = source
    }

    fun dismissReceiptDialog() {
        _activeReceiptDialog.value = null
    }

    fun clearNotifications() {
        _merchantNotification.value = null
        _buyerNotification.value = null
    }

    /**
     * Start the 12-state simulated NFC transaction cycle
     */
    fun startNfcPayment(
        customAmount: Double? = null,
        forceDecline: Boolean = false,
        isTimeout: Boolean = false,
        isDuplicate: Boolean = false,
        isHighValueSim: Boolean = false,
        isOfflineQueued: Boolean = _isOfflineModeEnabled.value
    ) {
        activeNfcJob?.cancel()

        val parsedBase = customAmount ?: (_keypadAmountString.value.toDoubleOrNull() ?: 24.80)
        val tip = _customTipAmount.value
        val splitTotal = parsedBase / _splitPayersCount.value
        val sessionId = CryptoEngine.generateSessionId()
        val cryptoData = CryptoEngine.generateSessionCrypto(sessionId, splitTotal + tip, "MERCH-RHINO-0042")
        val riskAssessment = RiskEngine.evaluateTransaction(
            amount = splitTotal + tip,
            forceDecline = forceDecline,
            isHighRiskSim = isHighValueSim,
            isDuplicateSim = isDuplicate
        )

        val session = PaymentSession(
            sessionId = sessionId,
            merchantName = "The Coffee House",
            merchantCity = "London, UK",
            baseAmount = splitTotal,
            tipAmount = tip,
            currency = "£",
            nonce = cryptoData.transactionNonce,
            state = NfcSessionState.DISCOVERING,
            riskAssessment = riskAssessment,
            cryptoDetails = cryptoData,
            selectedFundingSource = _selectedFundingSource.value,
            isOfflineQueued = isOfflineQueued,
            splitCount = _splitPayersCount.value
        )
        _activePaymentSession.value = session
        _activeSessionState.value = NfcSessionState.DISCOVERING

        activeNfcJob = viewModelScope.launch {
            repository.logAudit(
                title = "Payment Session Initialized",
                detail = "Created session $sessionId for £${String.format(Locale.UK, "%.2f", session.totalAmount)}",
                sessionId = sessionId,
                severity = "INFO"
            )

            // DISCOVERING -> NFC_DETECTED (300ms)
            delay(350)
            _activeSessionState.value = NfcSessionState.NFC_DETECTED
            _activePaymentSession.value = _activePaymentSession.value?.copy(state = NfcSessionState.NFC_DETECTED)
            repository.logAudit("NFC Device Detected", "Peer device at 2.4cm. ISO-DEP field established.", sessionId)

            // NFC_DETECTED -> SESSION_INITIALISED (350ms)
            delay(350)
            _activeSessionState.value = NfcSessionState.SESSION_INITIALISED
            _activePaymentSession.value = _activePaymentSession.value?.copy(state = NfcSessionState.SESSION_INITIALISED)
            repository.logAudit("Session Cryptography Initialised", "ECDH-P256 shared secret derived.", sessionId, "SECURE")

            // SESSION_INITIALISED -> PAYMENT_REQUEST_RECEIVED (300ms)
            delay(300)
            _activeSessionState.value = NfcSessionState.PAYMENT_REQUEST_RECEIVED
            _activePaymentSession.value = _activePaymentSession.value?.copy(state = NfcSessionState.PAYMENT_REQUEST_RECEIVED)

            // PAYMENT_REQUEST_RECEIVED -> BUYER_REVIEW (200ms)
            delay(250)
            _activeSessionState.value = NfcSessionState.BUYER_REVIEW
            _activePaymentSession.value = _activePaymentSession.value?.copy(state = NfcSessionState.BUYER_REVIEW)

            if (isTimeout) {
                delay(2000)
                _activeSessionState.value = NfcSessionState.TIMEOUT
                _activePaymentSession.value = _activePaymentSession.value?.copy(
                    state = NfcSessionState.TIMEOUT,
                    failureReason = "NFC field disconnected before authorisation."
                )
                repository.logAudit("NFC Session Timeout", "Peer device moved out of RF range.", sessionId, "WARN")
                return@launch
            }
        }
    }

    /**
     * Buyer taps "AUTHORISE PAYMENT"
     */
    fun authoriseActivePayment(authMethod: AuthMethod = AuthMethod.BIOMETRIC) {
        val currentSession = _activePaymentSession.value ?: return

        activeNfcJob?.cancel()
        activeNfcJob = viewModelScope.launch {
            _activeSessionState.value = NfcSessionState.BUYER_AUTHORISED
            _activePaymentSession.value = currentSession.copy(
                state = NfcSessionState.BUYER_AUTHORISED,
                authMethodUsed = authMethod
            )
            repository.logAudit(
                title = "Buyer Authorised",
                detail = "Authorised with ${authMethod.label}. Nonce signed with buyer session key.",
                sessionId = currentSession.sessionId,
                severity = "SECURE"
            )

            // Transition to PAYMENT_PROCESSING (400ms)
            delay(400)
            _activeSessionState.value = NfcSessionState.PAYMENT_PROCESSING
            _activePaymentSession.value = _activePaymentSession.value?.copy(state = NfcSessionState.PAYMENT_PROCESSING)
            repository.logAudit("Risk Scoring & Processing", "Evaluating Rhino Bank transaction velocity and fraud matrix...", currentSession.sessionId)

            delay(450)

            val risk = currentSession.riskAssessment
            if (risk.level == RiskLevel.HIGH || risk.fraudRiskScore > 0.5) {
                // DECLINED
                _activeSessionState.value = NfcSessionState.PAYMENT_DECLINED
                val reason = risk.reason
                _activePaymentSession.value = _activePaymentSession.value?.copy(
                    state = NfcSessionState.PAYMENT_DECLINED,
                    failureReason = reason
                )
                repository.logAudit("Payment Declined", "Transaction rejected by risk engine: $reason", currentSession.sessionId, "CRITICAL")
                _merchantNotification.value = "Payment Declined: $reason"
                _buyerNotification.value = "Transaction Declined: $reason"

                // Record declined transaction in ledger
                val txnId = CryptoEngine.generateTransactionId()
                val entity = TransactionEntity(
                    transactionId = txnId,
                    sessionId = currentSession.sessionId,
                    merchantName = currentSession.merchantName,
                    merchantId = currentSession.merchantId,
                    merchantCity = currentSession.merchantCity,
                    baseAmount = currentSession.baseAmount,
                    tipAmount = currentSession.tipAmount,
                    totalAmount = currentSession.totalAmount,
                    currency = currentSession.currency,
                    status = "DECLINED",
                    paymentMethod = "NFC Tap & Pay",
                    fundingSource = currentSession.selectedFundingSource?.name ?: "Rhino Bank Account",
                    authMethod = authMethod.label,
                    riskLevel = risk.level.name,
                    deviceTrustScore = risk.deviceTrustScore,
                    sessionValidityScore = risk.sessionValidityScore,
                    cryptoDigest = currentSession.cryptoDetails.signatureReference,
                    isOfflineQueued = currentSession.isOfflineQueued
                )
                repository.recordTransaction(entity)
            } else {
                // APPROVED
                val txnId = CryptoEngine.generateTransactionId()
                _activeSessionState.value = NfcSessionState.PAYMENT_APPROVED
                _activePaymentSession.value = _activePaymentSession.value?.copy(
                    state = NfcSessionState.PAYMENT_APPROVED,
                    transactionId = txnId
                )

                repository.logAudit(
                    title = "Payment Approved",
                    detail = "Transaction $txnId approved. Rhino Bank ledger settlement updated.",
                    sessionId = currentSession.sessionId,
                    severity = "SECURE"
                )

                val (dateStr, timeStr) = FormatUtils.formatDateTime(System.currentTimeMillis())
                val receipt = DigitalReceipt(
                    transactionId = txnId,
                    merchantName = currentSession.merchantName,
                    merchantId = currentSession.merchantId,
                    merchantCity = currentSession.merchantCity,
                    amount = currentSession.baseAmount,
                    tipAmount = currentSession.tipAmount,
                    totalAmount = currentSession.totalAmount,
                    currency = currentSession.currency,
                    dateString = dateStr,
                    timeString = timeStr,
                    paymentMethod = "Aardvark NFC Tap & Pay",
                    fundingSourceLast4 = currentSession.selectedFundingSource?.name ?: "Rhino Bank (•••• 4821)",
                    status = "APPROVED",
                    authMethod = authMethod.label,
                    cryptoDigest = currentSession.cryptoDetails.signatureReference,
                    riskLevel = risk.level.name
                )

                // Record in Room Database
                val entity = TransactionEntity(
                    transactionId = txnId,
                    sessionId = currentSession.sessionId,
                    merchantName = currentSession.merchantName,
                    merchantId = currentSession.merchantId,
                    merchantCity = currentSession.merchantCity,
                    baseAmount = currentSession.baseAmount,
                    tipAmount = currentSession.tipAmount,
                    totalAmount = currentSession.totalAmount,
                    currency = currentSession.currency,
                    status = "APPROVED",
                    paymentMethod = "NFC Tap & Pay",
                    fundingSource = currentSession.selectedFundingSource?.name ?: "Rhino Bank Account",
                    authMethod = authMethod.label,
                    riskLevel = risk.level.name,
                    deviceTrustScore = risk.deviceTrustScore,
                    sessionValidityScore = risk.sessionValidityScore,
                    cryptoDigest = currentSession.cryptoDetails.signatureReference,
                    isOfflineQueued = currentSession.isOfflineQueued,
                    splitInfo = if (currentSession.splitCount > 1) "Split ${currentSession.splitIndex}/${currentSession.splitCount}" else null
                )
                repository.recordTransaction(entity)

                if (currentSession.isOfflineQueued) {
                    _offlineQueuedCount.value = _offlineQueuedCount.value + 1
                }

                // Show notifications
                _merchantNotification.value = "Payment received £${String.format(Locale.UK, "%.2f", currentSession.totalAmount)} • $txnId"
                _buyerNotification.value = "Payment complete £${String.format(Locale.UK, "%.2f", currentSession.totalAmount)} • ${currentSession.merchantName}"

                // Show Receipt Dialog
                _activeReceiptDialog.value = receipt

                delay(500)
                _activeSessionState.value = NfcSessionState.COMPLETED
                _activePaymentSession.value = _activePaymentSession.value?.copy(state = NfcSessionState.COMPLETED)
            }
        }
    }

    fun cancelPaymentSession() {
        activeNfcJob?.cancel()
        val session = _activePaymentSession.value
        _activeSessionState.value = NfcSessionState.CANCELLED
        _activePaymentSession.value = session?.copy(state = NfcSessionState.CANCELLED)
        viewModelScope.launch {
            if (session != null) {
                repository.logAudit("Payment Cancelled", "User cancelled session ${session.sessionId}", session.sessionId, "WARN")
            }
        }
    }

    fun refundTransaction(transactionId: String) {
        viewModelScope.launch {
            repository.refundTransaction(transactionId, "Merchant initiated refund via Aardvark POS")
            _merchantNotification.value = "Refund processed for transaction $transactionId"
        }
    }

    fun registerNewDevice(name: String, type: String) {
        viewModelScope.launch {
            val deviceId = "DEV-RHINO-" + (10..99).random()
            val newDevice = MerchantDeviceEntity(
                deviceId = deviceId,
                deviceName = name,
                deviceType = type,
                merchantId = "MERCH-RHINO-0042",
                status = "ACTIVE",
                batteryLevel = 100,
                networkInfo = "5G • 10ms",
                lastActiveTimestamp = System.currentTimeMillis(),
                nfcHardwareReady = true,
                totalTransactionsToday = 0,
                totalVolumeToday = 0.0
            )
            repository.registerDevice(newDevice)
            _merchantNotification.value = "Registered new NFC terminal: $name"
        }
    }

    fun toggleDeviceStatus(deviceId: String, currentStatus: String) {
        viewModelScope.launch {
            val newStatus = if (currentStatus == "ACTIVE") "OFFLINE" else "ACTIVE"
            repository.updateDeviceStatus(deviceId, newStatus)
            repository.logAudit(
                title = "Device Status Changed",
                detail = "Terminal $deviceId switched to $newStatus",
                severity = if (newStatus == "ACTIVE") "INFO" else "WARN"
            )
        }
    }

    fun triggerInstantSettlement() {
        viewModelScope.launch {
            val currentTxns = allTransactions.value.filter { it.status == "APPROVED" }
            val amount = if (currentTxns.isNotEmpty()) currentTxns.sumOf { it.totalAmount } else 8238.80
            repository.triggerInstantSettlement(amount)
            _merchantNotification.value = "Instant Settlement of £${String.format(Locale.UK, "%.2f", amount)} transferred to Rhino Bank"
        }
    }

    fun resetDemoEnvironment() {
        viewModelScope.launch {
            repository.resetDemoEnvironment()
            _keypadAmountString.value = "24.80"
            _selectedTipPercent.value = null
            _customTipAmount.value = 0.0
            _splitPayersCount.value = 1
            _isOfflineModeEnabled.value = false
            _offlineQueuedCount.value = 0
            _activePaymentSession.value = null
            _activeSessionState.value = NfcSessionState.IDLE
            _merchantNotification.value = "Demo environment reset to baseline state"
            _buyerNotification.value = null
        }
    }
}
