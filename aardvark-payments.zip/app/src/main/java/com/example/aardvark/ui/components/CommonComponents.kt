package com.example.aardvark.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.aardvark.model.DigitalReceipt
import com.example.aardvark.model.FormatUtils
import com.example.aardvark.model.RiskLevel
import com.example.ui.theme.*

@Composable
fun DemoEnvironmentBanner(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("demo_environment_banner"),
        color = Color(0xFF111111),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222222))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Glowing Neon Pulse indicator
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(RhinoElectric)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "RHINO BANK",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF888888),
                        letterSpacing = 1.8.sp
                    )
                    Text(
                        text = "AARDVARK PAYMENTS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFF2F2F2),
                        letterSpacing = 1.sp
                    )
                }
            }
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color(0x1A00FF88),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x4000FF88))
            ) {
                Text(
                    text = "v3.7.0-BETA • NFC ACTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = RhinoElectric,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
fun FintechCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = SurfaceDark,
    borderColor: Color = SurfaceBorder,
    shape: RoundedCornerShape = RoundedCornerShape(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .border(1.dp, borderColor, shape)
            .clip(shape),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            content = content
        )
    }
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, icon) = when (status.uppercase()) {
        "APPROVED", "SETTLED", "ACTIVE", "LOW", "LOW RISK" -> Triple(
            Color(0x1A00FF88),
            Color(0xFF00FF88),
            "✓"
        )
        "DECLINED", "HIGH", "HIGH RISK", "FAILED", "OFFLINE" -> Triple(
            Color(0x26FF3366),
            Color(0xFFFF3366),
            "✕"
        )
        "REFUNDED", "MEDIUM", "MEDIUM RISK", "PENDING" -> Triple(
            Color(0x26FFB800),
            Color(0xFFFFB800),
            "↺"
        )
        else -> Triple(
            Color(0xFF1E1E1E),
            Color(0xFF888888),
            "•"
        )
    }

    Surface(
        modifier = modifier.testTag("status_badge_${status.lowercase()}"),
        shape = RoundedCornerShape(6.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, textColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "$icon $status",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = textColor,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    accentColor: Color = RhinoElectric,
    modifier: Modifier = Modifier
) {
    FintechCard(
        modifier = modifier,
        backgroundColor = SurfaceElevated,
        borderColor = SurfaceBorder
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-0.5).sp
                )
                if (subtitle != null) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = accentColor,
                        fontSize = 11.sp
                    )
                }
            }
            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.12f))
                        .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun NumericKeypad(
    onDigitClick: (String) -> Unit,
    onBackspaceClick: () -> Unit,
    onClearClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val keypadRows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("C", "0", "⌫")
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        keypadRows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { key ->
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF262626), RoundedCornerShape(12.dp))
                            .testTag("keypad_key_$key")
                            .clickable {
                                when (key) {
                                    "⌫" -> onBackspaceClick()
                                    "C" -> onClearClick()
                                    else -> onDigitClick(key)
                                }
                            },
                        color = when (key) {
                            "C" -> Color(0xFF161616)
                            "⌫" -> Color(0xFF161616)
                            else -> Color(0xFF181818)
                        }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = key,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Normal,
                                color = when (key) {
                                    "C" -> FinancialWarning
                                    "⌫" -> FinancialError
                                    else -> TextPrimary
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TipSelector(
    selectedTipPercent: Int?,
    customTipAmount: Double?,
    baseAmount: Double,
    onTipSelected: (Int?, Double?) -> Unit,
    modifier: Modifier = Modifier
) {
    val presets = listOf(10, 15, 20)

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "MERCHANT TIP",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            fontSize = 10.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { percent ->
                val isSelected = selectedTipPercent == percent
                val tipVal = baseAmount * (percent / 100.0)
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (isSelected) RhinoElectric else Color(0xFF262626),
                            RoundedCornerShape(10.dp)
                        )
                        .testTag("tip_preset_$percent")
                        .clickable {
                            if (isSelected) onTipSelected(null, 0.0)
                            else onTipSelected(percent, tipVal)
                        },
                    color = if (isSelected) Color(0x1A00FF88) else Color(0xFF161616)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$percent%",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) RhinoElectric else TextPrimary
                        )
                        Text(
                            text = FormatUtils.formatCurrency(tipVal),
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = if (isSelected) RhinoElectric.copy(alpha = 0.8f) else TextSecondary
                        )
                    }
                }
            }

            // No Tip option
            val isNoTip = selectedTipPercent == null && (customTipAmount == null || customTipAmount == 0.0)
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(
                        1.dp,
                        if (isNoTip) RhinoElectric else Color(0xFF262626),
                        RoundedCornerShape(10.dp)
                    )
                    .testTag("tip_preset_none")
                    .clickable { onTipSelected(null, 0.0) },
                color = if (isNoTip) Color(0x1A00FF88) else Color(0xFF161616)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "NO TIP",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isNoTip) RhinoElectric else TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun DigitalReceiptDialog(
    receipt: DigitalReceipt,
    onDismiss: () -> Unit,
    onSave: () -> Unit = {},
    onShare: () -> Unit = {}
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("digital_receipt_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AARDVARK PAYMENTS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = RhinoElectric,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "A RHINO BANK TECHNOLOGY SUBSIDIARY",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            color = TextSecondary
                        )
                    }
                    StatusBadge(status = receipt.status)
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = SurfaceBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Amount
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TOTAL PAID",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = FormatUtils.formatCurrency(receipt.totalAmount, receipt.currency),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                    if (receipt.tipAmount > 0) {
                        Text(
                            text = "Includes ${FormatUtils.formatCurrency(receipt.tipAmount, receipt.currency)} tip",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Receipt Breakdown Table
                FintechCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = SurfaceElevated
                ) {
                    ReceiptRow(label = "Merchant", value = receipt.merchantName)
                    ReceiptRow(label = "Location", value = receipt.merchantCity)
                    ReceiptRow(label = "Transaction ID", value = receipt.transactionId, isMonospace = true)
                    ReceiptRow(label = "Date & Time", value = "${receipt.dateString} • ${receipt.timeString}")
                    ReceiptRow(label = "Payment Channel", value = receipt.paymentMethod)
                    ReceiptRow(label = "Funding Source", value = receipt.fundingSourceLast4)
                    ReceiptRow(label = "Authorisation", value = receipt.authMethod)
                    ReceiptRow(label = "Risk Evaluation", value = receipt.riskLevel)
                    ReceiptRow(
                        label = "Crypto Digest",
                        value = receipt.cryptoDigest.take(16) + "...",
                        isMonospace = true
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onShare,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("share_receipt_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MetallicSilver)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SHARE", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("done_receipt_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue)
                    ) {
                        Text("DONE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(
    label: String,
    value: String,
    isMonospace: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = TextPrimary,
            fontSize = 11.sp
        )
    }
}
