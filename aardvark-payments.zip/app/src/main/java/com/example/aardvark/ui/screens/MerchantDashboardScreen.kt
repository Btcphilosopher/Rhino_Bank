package com.example.aardvark.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.aardvark.data.db.MerchantDeviceEntity
import com.example.aardvark.data.db.SettlementEntity
import com.example.aardvark.data.db.TransactionEntity
import com.example.aardvark.model.FormatUtils
import com.example.aardvark.ui.components.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

@Composable
fun MerchantDashboardScreen(
    viewModel: AardvarkViewModel,
    modifier: Modifier = Modifier
) {
    var dashboardSubTab by remember { mutableStateOf(0) } // 0=Overview, 1=Ledger, 2=Settlements, 3=Devices, 4=Analytics
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val devices by viewModel.allDevices.collectAsStateWithLifecycle()
    val settlements by viewModel.allSettlements.collectAsStateWithLifecycle()

    var selectedTransactionForDetail by remember { mutableStateOf<TransactionEntity?>(null) }
    var showRegisterDeviceDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        DemoEnvironmentBanner()

        // Merchant Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AARDVARK BUSINESS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = RhinoElectric,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "The Coffee House",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            StatusBadge(status = "ACTIVE")
        }

        // Sub-Tab Navigation Bar
        val tabs = listOf("Overview", "Transactions", "Settlement", "Devices", "Analytics")
        ScrollableTabRow(
            selectedTabIndex = dashboardSubTab,
            containerColor = SurfaceElevated,
            contentColor = RhinoElectric,
            edgePadding = 0.dp,
            divider = {},
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = dashboardSubTab == index,
                    onClick = { dashboardSubTab = index },
                    modifier = Modifier.testTag("dashboard_tab_$index"),
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (dashboardSubTab == index) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        // Tab Content Switcher
        when (dashboardSubTab) {
            0 -> OverviewTab(transactions = transactions)
            1 -> TransactionsLedgerTab(
                transactions = transactions,
                onSelectTransaction = { selectedTransactionForDetail = it }
            )
            2 -> SettlementTab(
                settlements = settlements,
                onTriggerInstant = { viewModel.triggerInstantSettlement() }
            )
            3 -> DeviceManagementTab(
                devices = devices,
                onToggleStatus = { id, st -> viewModel.toggleDeviceStatus(id, st) },
                onOpenRegister = { showRegisterDeviceDialog = true }
            )
            4 -> AnalyticsTab()
        }
    }

    // Transaction Details & Refund Modal
    if (selectedTransactionForDetail != null) {
        val txn = selectedTransactionForDetail!!
        Dialog(onDismissRequest = { selectedTransactionForDetail = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .testTag("transaction_detail_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TRANSACTION DETAILS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = RhinoElectric
                        )
                        StatusBadge(status = txn.status)
                    }

                    HorizontalDivider(color = SurfaceBorder)

                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = FormatUtils.formatCurrency(txn.totalAmount, txn.currency),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                        Text(
                            text = "Txn ID: ${txn.transactionId}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )
                    }

                    FintechCard(backgroundColor = SurfaceElevated) {
                        ReceiptRow(label = "Merchant", value = txn.merchantName)
                        ReceiptRow(label = "Channel", value = txn.paymentMethod)
                        ReceiptRow(label = "Funding Source", value = txn.fundingSource)
                        ReceiptRow(label = "Auth Type", value = txn.authMethod)
                        ReceiptRow(label = "Risk Assessment", value = "${txn.riskLevel} (${txn.deviceTrustScore}% trust)")
                        ReceiptRow(label = "Digest", value = txn.cryptoDigest.take(16) + "...", isMonospace = true)
                        if (txn.status == "REFUNDED" && txn.refundReason != null) {
                            ReceiptRow(label = "Refund Note", value = txn.refundReason)
                        }
                    }

                    // Action buttons: Refund if Approved
                    if (txn.status == "APPROVED") {
                        Button(
                            onClick = {
                                viewModel.refundTransaction(txn.transactionId)
                                selectedTransactionForDetail = null
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("refund_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = FinancialWarningBg),
                            border = androidx.compose.foundation.BorderStroke(1.dp, FinancialWarning)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = FinancialWarning)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PROCESS REFUND (${FormatUtils.formatCurrency(txn.totalAmount, txn.currency)})",
                                color = FinancialWarning,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = { selectedTransactionForDetail = null },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MetallicSilver)
                    ) {
                        Text("CLOSE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Register Device Dialog
    if (showRegisterDeviceDialog) {
        var newDeviceName by remember { mutableStateOf("Terminal 04 (Counter 2)") }
        var newDeviceType by remember { mutableStateOf("Pixel 9 / NFC Native Terminal") }

        Dialog(onDismissRequest = { showRegisterDeviceDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric),
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "REGISTER MERCHANT DEVICE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = RhinoElectric
                    )
                    Text(
                        text = "Add an approved NFC device to accept contactless payments for this merchant account.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    OutlinedTextField(
                        value = newDeviceName,
                        onValueChange = { newDeviceName = it },
                        label = { Text("Device Name") },
                        modifier = Modifier.fillMaxWidth().testTag("input_device_name"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RhinoElectric,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )

                    OutlinedTextField(
                        value = newDeviceType,
                        onValueChange = { newDeviceType = it },
                        label = { Text("Device Hardware Type") },
                        modifier = Modifier.fillMaxWidth().testTag("input_device_type"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RhinoElectric,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showRegisterDeviceDialog = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("CANCEL")
                        }

                        Button(
                            onClick = {
                                viewModel.registerNewDevice(newDeviceName, newDeviceType)
                                showRegisterDeviceDialog = false
                            },
                            modifier = Modifier.weight(1f).testTag("confirm_register_device"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue)
                        ) {
                            Text("PROVISION", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OverviewTab(transactions: List<TransactionEntity>) {
    val approvedTotal = transactions.filter { it.status == "APPROVED" }.sumOf { it.totalAmount }
    val refundTotal = transactions.filter { it.status == "REFUNDED" }.sumOf { it.totalAmount }
    val netTotal = approvedTotal - refundTotal
    val avgTicket = if (transactions.isNotEmpty()) approvedTotal / transactions.count { it.status == "APPROVED" }.coerceAtLeast(1) else 45.77

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "Today's Sales",
                    value = FormatUtils.formatCurrency(if (approvedTotal > 0) approvedTotal else 8421.20),
                    subtitle = "+14.2% vs yesterday",
                    icon = Icons.Default.TrendingUp,
                    accentColor = RhinoElectric,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Transactions",
                    value = "${transactions.size.coerceAtLeast(184)}",
                    subtitle = "98.4% approval",
                    icon = Icons.Default.ReceiptLong,
                    accentColor = FinancialSuccess,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "Avg Ticket",
                    value = FormatUtils.formatCurrency(avgTicket),
                    subtitle = "Normal velocity",
                    icon = Icons.Default.ShoppingBag,
                    accentColor = FinancialPurple,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Net Settlement",
                    value = FormatUtils.formatCurrency(if (netTotal > 0) netTotal else 8238.80),
                    subtitle = "Rhino Bank Payout",
                    icon = Icons.Default.AccountBalance,
                    accentColor = FinancialGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            FintechCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "HOURLY VOLUME DISTRIBUTION (DEMO DATA)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                // Hourly simulated chart bars
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    val bars = listOf(20, 35, 45, 60, 95, 80, 50, 70, 90, 100, 75, 40)
                    val hours = listOf("8a", "9a", "10a", "11a", "12p", "1p", "2p", "3p", "4p", "5p", "6p", "7p")
                    bars.forEachIndexed { i, heightPct ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.6f)
                                    .fillMaxHeight(heightPct / 100f)
                                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                    .background(if (heightPct >= 90) RhinoElectric else RhinoBlue.copy(alpha = 0.6f))
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = hours[i],
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                color = TextTertiary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionsLedgerTab(
    transactions: List<TransactionEntity>,
    onSelectTransaction: (TransactionEntity) -> Unit
) {
    var statusFilter by remember { mutableStateOf("ALL") }

    val filtered = when (statusFilter) {
        "APPROVED" -> transactions.filter { it.status == "APPROVED" }
        "DECLINED" -> transactions.filter { it.status == "DECLINED" }
        "REFUNDED" -> transactions.filter { it.status == "REFUNDED" }
        else -> transactions
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "APPROVED", "DECLINED", "REFUNDED").forEach { filter ->
                val isSelected = statusFilter == filter
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) RhinoBlue else SurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) RhinoElectric else SurfaceBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .testTag("filter_txn_$filter")
                        .clickable { statusFilter = filter }
                ) {
                    Text(
                        text = filter,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else TextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Transactions List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.transactionId }) { txn ->
                val (dateStr, timeStr) = FormatUtils.formatDateTime(txn.timestamp)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .testTag("txn_row_${txn.transactionId}")
                        .clickable { onSelectTransaction(txn) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (txn.status) {
                                            "APPROVED" -> FinancialSuccessBg
                                            "DECLINED" -> FinancialErrorBg
                                            else -> FinancialWarningBg
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (txn.status) {
                                        "APPROVED" -> Icons.Default.Check
                                        "DECLINED" -> Icons.Default.Close
                                        else -> Icons.Default.Refresh
                                    },
                                    contentDescription = txn.status,
                                    tint = when (txn.status) {
                                        "APPROVED" -> FinancialSuccess
                                        "DECLINED" -> FinancialError
                                        else -> FinancialWarning
                                    },
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = txn.merchantName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "$timeStr • ${txn.transactionId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = FormatUtils.formatCurrency(txn.totalAmount, txn.currency),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Black,
                                color = if (txn.status == "REFUNDED") FinancialWarning else TextPrimary
                            )
                            StatusBadge(status = txn.status)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettlementTab(
    settlements: List<SettlementEntity>,
    onTriggerInstant: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            FintechCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = SurfaceElevated,
                borderColor = RhinoBlue
            ) {
                Text(
                    text = "RHINO BANK SETTLEMENT ACCOUNT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = RhinoElectric,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AVAILABLE BALANCE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "£42,821.20",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "PENDING CLEARING",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "£3,182.40",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = FinancialGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SurfaceBorder)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Next Scheduled Settlement: Tomorrow at 06:00 UTC",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onTriggerInstant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("trigger_instant_settlement_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TRIGGER INSTANT RHINO BANK SETTLEMENT", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                }
            }
        }

        item {
            Text(
                text = "SETTLEMENT HISTORY (DEMO LEDGER)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
        }

        items(settlements, key = { it.id }) { s ->
            FintechCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = s.settlementBatchId,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimary
                        )
                        Text(
                            text = "${s.dateLabel} • ${s.payoutAccount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = FormatUtils.formatCurrency(s.netSettlement),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Black,
                            color = FinancialSuccess
                        )
                        StatusBadge(status = s.status)
                    }
                }
            }
        }
    }
}

@Composable
fun DeviceManagementTab(
    devices: List<MerchantDeviceEntity>,
    onToggleStatus: (String, String) -> Unit,
    onOpenRegister: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "REGISTERED TERMINALS (${devices.size})",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )

            Button(
                onClick = onOpenRegister,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue),
                modifier = Modifier.height(36.dp).testTag("open_register_device_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("REGISTER DEVICE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(devices, key = { it.deviceId }) { dev ->
                FintechCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (dev.status == "ACTIVE") RhinoElectric.copy(alpha = 0.4f) else SurfaceBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dev.deviceName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${dev.deviceType} • ${dev.deviceId}",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        StatusBadge(status = dev.status)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = SurfaceBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = FinancialSuccess, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${dev.batteryLevel}%", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Wifi, contentDescription = null, tint = RhinoElectric, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(dev.networkInfo, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Nfc, contentDescription = null, tint = RhinoElectric, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("NFC Ready", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                            }
                        }

                        TextButton(
                            onClick = { onToggleStatus(dev.deviceId, dev.status) },
                            modifier = Modifier.height(32.dp).testTag("toggle_device_${dev.deviceId}")
                        ) {
                            Text(
                                text = if (dev.status == "ACTIVE") "DEACTIVATE" else "ACTIVATE",
                                color = if (dev.status == "ACTIVE") FinancialWarning else FinancialSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsTab() {
    var timeframe by remember { mutableStateOf("DAY") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("DAY", "WEEK", "MONTH", "YEAR").forEach { tf ->
                    val isSelected = timeframe == tf
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, if (isSelected) RhinoElectric else SurfaceBorder, RoundedCornerShape(8.dp))
                            .clickable { timeframe = tf },
                        color = if (isSelected) RhinoBlue else SurfaceElevated
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = tf,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "Approval Rate",
                    value = "98.4%",
                    subtitle = "0.02% fraud score",
                    icon = Icons.Default.CheckCircle,
                    accentColor = FinancialSuccess,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Avg Auth Speed",
                    value = "340 ms",
                    subtitle = "NFC Handshake + SCA",
                    icon = Icons.Default.Speed,
                    accentColor = RhinoElectric,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            FintechCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "PERFORMANCE BENCHMARKS (DEMO METRICS)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                ReceiptRow(label = "Peak Transaction Period", value = "12:00 - 14:00 (Lunch Rush)")
                ReceiptRow(label = "NFC Field Success Rate", value = "99.8%")
                ReceiptRow(label = "Refund Ratio", value = "2.1% (Within Risk Target)")
                ReceiptRow(label = "Decline Rate", value = "1.6% (Insufficient Funds / Timeout)")
                ReceiptRow(label = "Biometric Step-Up Rate", value = "8.4% (For >£100 tickets)")
            }
        }
    }
}
