package com.example.aardvark.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE transactionId = :txnId LIMIT 1")
    suspend fun getTransactionById(txnId: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE status = :status ORDER BY timestamp DESC")
    fun getTransactionsByStatus(status: String): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Query("UPDATE transactions SET status = 'REFUNDED', refundTimestamp = :refundTime, refundReason = :reason WHERE transactionId = :txnId")
    suspend fun markRefunded(txnId: String, refundTime: Long, reason: String)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()
}

@Dao
interface MerchantDeviceDao {
    @Query("SELECT * FROM merchant_devices ORDER BY deviceName ASC")
    fun getAllDevices(): Flow<List<MerchantDeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateDevice(device: MerchantDeviceEntity)

    @Query("UPDATE merchant_devices SET status = :status WHERE deviceId = :deviceId")
    suspend fun updateDeviceStatus(deviceId: String, status: String)

    @Query("UPDATE merchant_devices SET deviceName = :newName WHERE deviceId = :deviceId")
    suspend fun renameDevice(deviceId: String, newName: String)

    @Query("DELETE FROM merchant_devices WHERE deviceId = :deviceId")
    suspend fun deleteDevice(deviceId: String)

    @Query("DELETE FROM merchant_devices")
    suspend fun clearAll()
}

@Dao
interface SettlementDao {
    @Query("SELECT * FROM settlement_ledger ORDER BY timestamp DESC")
    fun getAllSettlements(): Flow<List<SettlementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlement(settlement: SettlementEntity)

    @Query("DELETE FROM settlement_ledger")
    suspend fun clearAll()
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 150")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Query("DELETE FROM audit_log")
    suspend fun clearAll()
}
