package com.example.aardvark.engine

import com.example.aardvark.model.RiskAssessment
import com.example.aardvark.model.RiskLevel

object RiskEngine {
    const val CONTACTLESS_STEP_UP_THRESHOLD = 100.0 // Amounts above £100 require step-up authentication

    fun evaluateTransaction(
        amount: Double,
        forceDecline: Boolean = false,
        isHighRiskSim: Boolean = false,
        isDuplicateSim: Boolean = false
    ): RiskAssessment {
        if (forceDecline) {
            return RiskAssessment(
                level = RiskLevel.HIGH,
                deviceTrustScore = 42,
                sessionValidityScore = 65,
                velocityStatus = "ELEVATED",
                nonceVerified = false,
                replayProtected = true,
                fraudRiskScore = 0.89,
                reason = "Simulated merchant risk threshold exceeded • Insufficient funds"
            )
        }

        if (isDuplicateSim) {
            return RiskAssessment(
                level = RiskLevel.HIGH,
                deviceTrustScore = 88,
                sessionValidityScore = 15,
                velocityStatus = "SUSPICIOUS_REPLAY",
                nonceVerified = false,
                replayProtected = false,
                fraudRiskScore = 0.95,
                reason = "Cryptographic replay detected: Duplicate nonce in 60s sliding window"
            )
        }

        if (isHighRiskSim || amount > 500.0) {
            return RiskAssessment(
                level = RiskLevel.MEDIUM,
                deviceTrustScore = 91,
                sessionValidityScore = 98,
                velocityStatus = "ELEVATED",
                nonceVerified = true,
                replayProtected = true,
                fraudRiskScore = 0.28,
                reason = "High transaction amount • Step-up Biometric SCA required"
            )
        }

        // Standard Low Risk
        return RiskAssessment(
            level = RiskLevel.LOW,
            deviceTrustScore = 98,
            sessionValidityScore = 100,
            velocityStatus = "NORMAL",
            nonceVerified = true,
            replayProtected = true,
            fraudRiskScore = 0.02,
            reason = "Device trust verified (98%) • Valid nonce • Velocity normal"
        )
    }

    fun requiresStepUpAuthentication(amount: Double): Boolean {
        return amount > CONTACTLESS_STEP_UP_THRESHOLD
    }
}
