package com.example.aardvark.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: String, // e.g. "AARD-829194"
    val sessionId: String,
    val merchantName: String,
    val merchantId: String,
    val merchantCity: String,
    val baseAmount: Double,
    val tipAmount: Double = 0.0,
    val totalAmount: Double,
    val currency: String = "£",
    val status: String, // "APPROVED", "DECLINED", "REFUNDED"
    val timestamp: Long = System.currentTimeMillis(),
    val paymentMethod: String = "NFC Tap & Pay",
    val fundingSource: String = "Rhino Bank Account (•••• 4821)",
    val authMethod: String = "Biometric Auth",
    val riskLevel: String = "LOW",
    val deviceTrustScore: Int = 98,
    val sessionValidityScore: Int = 100,
    val cryptoDigest: String,
    val isOfflineQueued: Boolean = false,
    val splitInfo: String? = null,
    val refundTimestamp: Long? = null,
    val refundReason: String? = null
)

@Entity(tableName = "merchant_devices")
data class MerchantDeviceEntity(
    @PrimaryKey val deviceId: String,
    val deviceName: String,
    val deviceType: String,
    val merchantId: String,
    val status: String, // "ACTIVE", "OFFLINE", "STANDBY"
    val batteryLevel: Int,
    val networkInfo: String,
    val lastActiveTimestamp: Long,
    val nfcHardwareReady: Boolean = true,
    val totalTransactionsToday: Int = 0,
    val totalVolumeToday: Double = 0.0
)

@Entity(tableName = "settlement_ledger")
data class SettlementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val settlementBatchId: String,
    val dateLabel: String,
    val grossSales: Double,
    val refunds: Double,
    val netSettlement: Double,
    val status: String, // "SETTLED", "PENDING", "PROCESSING"
    val payoutAccount: String,
    val timestamp: Long
)

@Entity(tableName = "audit_log")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val timeFormatted: String,
    val eventTitle: String,
    val eventDetail: String,
    val sessionId: String? = null,
    val severity: String = "INFO" // "INFO", "SECURE", "WARN", "CRITICAL"
)
