package com.example.aardvark.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.aardvark.model.AuthMethod
import com.example.aardvark.model.FormatUtils
import com.example.aardvark.model.NfcSessionState
import com.example.aardvark.ui.components.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

@Composable
fun DualDeviceSimulatorScreen(
    viewModel: AardvarkViewModel,
    modifier: Modifier = Modifier
) {
    val session by viewModel.activePaymentSession.collectAsStateWithLifecycle()
    val sessionState by viewModel.activeSessionState.collectAsStateWithLifecycle()
    val amountString by viewModel.keypadAmountString.collectAsStateWithLifecycle()
    val tipPercent by viewModel.selectedTipPercent.collectAsStateWithLifecycle()
    val tipAmount by viewModel.customTipAmount.collectAsStateWithLifecycle()
    val fundingSources by viewModel.fundingSources.collectAsStateWithLifecycle()
    val selectedFunding by viewModel.selectedFundingSource.collectAsStateWithLifecycle()
    val isOfflineMode by viewModel.isOfflineModeEnabled.collectAsStateWithLifecycle()
    val receiptDialog by viewModel.activeReceiptDialog.collectAsStateWithLifecycle()
    val merchantNotif by viewModel.merchantNotification.collectAsStateWithLifecycle()
    val buyerNotif by viewModel.buyerNotification.collectAsStateWithLifecycle()

    val parsedBase = amountString.toDoubleOrNull() ?: 24.80
    val totalWithTip = parsedBase + tipAmount
    val isHighValue = totalWithTip > 100.0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Environment Header Banner
        DemoEnvironmentBanner()

        // Notification Toasts (if present)
        AnimatedVisibility(visible = merchantNotif != null || buyerNotif != null) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (merchantNotif != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF132B20),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FinancialSuccess.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().testTag("merchant_toast")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Storefront, contentDescription = null, tint = FinancialSuccess, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "MERCHANT: $merchantNotif",
                                style = MaterialTheme.typography.bodySmall,
                                color = FinancialSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                if (buyerNotif != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E293B),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().testTag("buyer_toast")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Smartphone, contentDescription = null, tint = RhinoElectric, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "BUYER: $buyerNotif",
                                style = MaterialTheme.typography.bodySmall,
                                color = RhinoElectric,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Section Title & Tagline
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DEVICE ↔ NFC ↔ DEVICE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = RhinoElectric,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Live Tap Simulator",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            if (sessionState != NfcSessionState.IDLE && sessionState != NfcSessionState.COMPLETED) {
                OutlinedButton(
                    onClick = { viewModel.cancelPaymentSession() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FinancialError),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp).testTag("cancel_session_button")
                ) {
                    Text("CANCEL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ==========================================
        // 1. MERCHANT DEVICE PANEL
        // ==========================================
        FintechCard(
            modifier = Modifier.fillMaxWidth().testTag("merchant_device_panel"),
            backgroundColor = SurfaceDark,
            borderColor = if (sessionState == NfcSessionState.DISCOVERING || sessionState == NfcSessionState.NFC_DETECTED) RhinoElectric else SurfaceBorder
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(RhinoBlue.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Storefront, contentDescription = "Merchant", tint = RhinoElectric, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AARDVARK MERCHANT",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = RhinoElectric,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "The Coffee House • London (Terminal 01)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                StatusBadge(status = if (isOfflineMode) "OFFLINE" else "ACTIVE")
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = SurfaceBorder)
            Spacer(modifier = Modifier.height(14.dp))

            // Merchant Amount Input & Preset Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PAYMENT REQUEST",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = FormatUtils.formatCurrency(totalWithTip),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }

                // Quick preset amounts
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("12.50", "24.80", "112.00").forEach { preset ->
                        val isPresetSelected = amountString == preset
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isPresetSelected) Color(0x2000FF88) else Color(0xFF1A1A1A),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isPresetSelected) RhinoElectric else Color(0xFF2E2E2E)
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .testTag("amount_preset_$preset")
                                .clickable { viewModel.setAmountDirect(preset) }
                        ) {
                            Text(
                                text = "£$preset",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isPresetSelected) RhinoElectric else Color(0xFFCCCCCC),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tip selector in simulator
            TipSelector(
                selectedTipPercent = tipPercent,
                customTipAmount = tipAmount,
                baseAmount = parsedBase,
                onTipSelected = { pct, amt -> viewModel.setTip(pct, amt) }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Tap To Pay Trigger Button
            if (sessionState == NfcSessionState.IDLE || sessionState == NfcSessionState.COMPLETED || sessionState == NfcSessionState.CANCELLED || sessionState == NfcSessionState.TIMEOUT) {
                Button(
                    onClick = { viewModel.startNfcPayment() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("tap_to_pay_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RhinoElectric,
                        contentColor = Color(0xFF0A0A0A)
                    )
                ) {
                    Icon(Icons.Default.Nfc, contentDescription = "Tap", modifier = Modifier.size(20.dp), tint = Color(0xFF0A0A0A))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "START NFC PAYMENT (${FormatUtils.formatCurrency(totalWithTip)})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF0A0A0A),
                        letterSpacing = 0.5.sp
                    )
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF161616),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = RhinoElectric,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "HOLD CUSTOMER DEVICE NEAR TERMINAL",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = RhinoElectric
                        )
                    }
                }
            }
        }

        // ==========================================
        // 2. NFC ELECTROMAGNETIC PROXIMITY WAVE
        // ==========================================
        NfcProximityVisualizer(
            sessionState = sessionState,
            amountFormatted = FormatUtils.formatCurrency(totalWithTip),
            merchantName = "The Coffee House",
            isHighValue = isHighValue
        )

        // ==========================================
        // 3. BUYER DEVICE (AARDVARK PAY)
        // ==========================================
        FintechCard(
            modifier = Modifier.fillMaxWidth().testTag("buyer_device_panel"),
            backgroundColor = SurfaceDark,
            borderColor = if (sessionState == NfcSessionState.BUYER_REVIEW || sessionState == NfcSessionState.BUYER_AUTHORISED) RhinoElectric else SurfaceBorder
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(FinancialPurple.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Smartphone, contentDescription = "Buyer", tint = FinancialPurple, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AARDVARK PAY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = FinancialPurple,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Buyer Device • Contactless Wallet",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                StatusBadge(status = if (sessionState == NfcSessionState.BUYER_REVIEW) "PROMPT RECEIVED" else "READY")
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = SurfaceBorder)
            Spacer(modifier = Modifier.height(14.dp))

            // Funding Source Card Selector
            Text(
                text = "ACTIVE PAYMENT SOURCE",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceHighlight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Brush.linearGradient(listOf(RhinoBlue, FinancialPurple))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CreditCard, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = selectedFunding.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${selectedFunding.identifier} • Balance: ${FormatUtils.formatCurrency(selectedFunding.balance)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = RhinoElectric, modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Buyer Action: Authorise / Complete
            when (sessionState) {
                NfcSessionState.BUYER_REVIEW -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E293B))
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "AUTHORISE PAYMENT TO",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "The Coffee House",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = FormatUtils.formatCurrency(totalWithTip),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = RhinoElectric
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Authorise Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.authoriseActivePayment(AuthMethod.BIOMETRIC) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("authorise_biometric_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = FinancialSuccessBg),
                                border = androidx.compose.foundation.BorderStroke(1.dp, FinancialSuccess)
                            ) {
                                Icon(Icons.Default.Fingerprint, contentDescription = "Touch ID", tint = FinancialSuccess, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("BIOMETRIC", color = FinancialSuccess, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            Button(
                                onClick = { viewModel.authoriseActivePayment(AuthMethod.DEVICE_PIN) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("authorise_pin_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue)
                            ) {
                                Icon(Icons.Default.Pin, contentDescription = "PIN", tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("DEVICE PIN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
                NfcSessionState.BUYER_AUTHORISED, NfcSessionState.PAYMENT_PROCESSING -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoElectric.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = RhinoElectric, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "TRANSMITTING SIGNED NONCE OVER NFC...",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = RhinoElectric
                            )
                        }
                    }
                }
                NfcSessionState.PAYMENT_APPROVED, NfcSessionState.COMPLETED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = FinancialSuccessBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, FinancialSuccess),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FinancialSuccess, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "PAYMENT APPROVED • ${FormatUtils.formatCurrency(totalWithTip)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = FinancialSuccess
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Transaction ID: ${session?.transactionId ?: "AARD-829194"}",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = MetallicSilver,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
                NfcSessionState.PAYMENT_DECLINED -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = FinancialErrorBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, FinancialError),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Cancel, contentDescription = null, tint = FinancialError, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "TRANSACTION DECLINED",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = FinancialError
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = session?.failureReason ?: "Risk engine declined payment",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
                else -> {
                    Text(
                        text = "Awaiting NFC payment session initiation from merchant terminal above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Show Digital Receipt Dialog if active
    if (receiptDialog != null) {
        DigitalReceiptDialog(
            receipt = receiptDialog!!,
            onDismiss = { viewModel.dismissReceiptDialog() },
            onShare = { /* simulated share */ },
            onSave = { /* simulated save */ }
        )
    }
}
