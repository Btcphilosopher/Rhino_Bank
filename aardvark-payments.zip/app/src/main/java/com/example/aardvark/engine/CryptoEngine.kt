package com.example.aardvark.engine

import com.example.aardvark.model.CryptoSessionData
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

object CryptoEngine {
    private val secureRandom = SecureRandom()

    fun generateSessionCrypto(sessionId: String, amount: Double, merchantId: String): CryptoSessionData {
        val nonceBytes = ByteArray(8)
        secureRandom.nextBytes(nonceBytes)
        val nonce = nonceBytes.joinToString("") { "%02X".format(it) }

        val merchantEphemeralKey = "04" + generateHex(32) + " [ECDH-P256]"
        val buyerEphemeralKey = "04" + generateHex(32) + " [ECDH-P256]"

        val payload = "$sessionId:$merchantId:$amount:$nonce:${System.currentTimeMillis()}"
        val digest = sha256(payload)
        val signatureRef = "SIG_ED25519_${digest.take(12).uppercase()}"

        return CryptoSessionData(
            merchantSessionKey = merchantEphemeralKey,
            buyerSessionKey = buyerEphemeralKey,
            transactionNonce = nonce,
            sessionId = sessionId,
            signatureReference = signatureRef,
            encryptionCipher = "AES-256-GCM / Ephemeral ECDH Key Agreement"
        )
    }

    fun generateTransactionId(): String {
        val randomNum = 100000 + secureRandom.nextInt(900000)
        return "AARD-$randomNum"
    }

    fun generateSessionId(): String {
        return "sess_aard_" + UUID.randomUUID().toString().take(12).replace("-", "")
    }

    private fun generateHex(length: Int): String {
        val bytes = ByteArray(length)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString("") { "%02X".format(it) }
    }

    fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
