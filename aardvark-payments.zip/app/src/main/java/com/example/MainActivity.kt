package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.aardvark.ui.screens.*
import com.example.aardvark.ui.viewmodel.AardvarkViewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: AardvarkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AardvarkMainApp(viewModel = viewModel)
            }
        }
    }
}

data class NavItem(
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun AardvarkMainApp(viewModel: AardvarkViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()

    val navItems = listOf(
        NavItem("Simulator", Icons.Default.Nfc, "nav_simulator"),
        NavItem("Terminal", Icons.Default.PointOfSale, "nav_terminal"),
        NavItem("Business", Icons.Default.Storefront, "nav_business"),
        NavItem("Buyer Pay", Icons.Default.AccountBalanceWallet, "nav_wallet"),
        NavItem("Rhino Core", Icons.Default.Shield, "nav_rhino_risk"),
        NavItem("Sandbox", Icons.Default.Science, "nav_sandbox")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize().background(BackgroundDark),
        containerColor = BackgroundDark,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F0F0F),
                tonalElevation = 0.dp,
                modifier = Modifier
                    .border(1.dp, Color(0xFF222222))
                    .testTag("main_navigation_bar")
            ) {
                navItems.forEachIndexed { index, item ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(index) },
                        modifier = Modifier.testTag(item.testTag),
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = if (isSelected) RhinoElectric else Color(0xFF888888)
                            )
                        },
                        label = {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 10.sp,
                                color = if (isSelected) RhinoElectric else Color(0xFF888888)
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0x2000FF88),
                            selectedIconColor = RhinoElectric,
                            unselectedIconColor = Color(0xFF888888),
                            selectedTextColor = RhinoElectric,
                            unselectedTextColor = Color(0xFF888888)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundDark)
        ) {
            when (selectedTab) {
                0 -> DualDeviceSimulatorScreen(viewModel = viewModel)
                1 -> MerchantTerminalScreen(viewModel = viewModel)
                2 -> MerchantDashboardScreen(viewModel = viewModel)
                3 -> BuyerWalletScreen(viewModel = viewModel)
                4 -> RhinoBankAndRiskScreen(viewModel = viewModel)
                5 -> TestScenariosScreen(viewModel = viewModel)
            }
        }
    }
}
