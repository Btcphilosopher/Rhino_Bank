package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AardvarkDarkColorScheme = darkColorScheme(
    primary = RhinoElectric,
    onPrimary = BackgroundDark,
    primaryContainer = SurfaceElevated,
    onPrimaryContainer = MetallicSilver,
    secondary = RhinoBlue,
    onSecondary = Color.White,
    secondaryContainer = SurfaceBorder,
    onSecondaryContainer = MetallicSilver,
    tertiary = AardvarkCyan,
    onTertiary = BackgroundDark,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder,
    outlineVariant = SurfaceHighlight,
    error = FinancialError,
    onError = Color.White,
    errorContainer = FinancialErrorBg,
    onErrorContainer = Color(0xFFFECACA)
)

private val AardvarkLightColorScheme = lightColorScheme(
    primary = RhinoBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = Color(0xFF0F172A),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = FinancialError,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to fintech dark infrastructure
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AardvarkDarkColorScheme else AardvarkLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
