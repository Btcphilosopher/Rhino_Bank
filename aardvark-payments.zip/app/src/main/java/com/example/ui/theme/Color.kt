package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Foundations (Pure Matte Obsidian & Graphite)
val BackgroundDark = Color(0xFF0A0A0A)
val SurfaceDark = Color(0xFF121212)
val SurfaceElevated = Color(0xFF181818)
val SurfaceCard = Color(0xFF141414)
val SurfaceBorder = Color(0xFF262626)
val SurfaceBorderSubtle = Color(0xFF1E1E1E)
val SurfaceHighlight = Color(0xFF333333)

// Immersive UI Glowing Accents
val RhinoElectric = Color(0xFF00FF88) // Neon Matrix Green
val NeonGreenGlow = Color(0xFF00FF88)
val NeonGreenDim = Color(0xFF00B35F)
val NeonGreenBg = Color(0x1A00FF88)
val RhinoBlue = Color(0xFF00E5FF) // Electric Cyber Cyan
val AardvarkCyan = Color(0xFF00FFCC)
val AardvarkTeal = Color(0xFF10B981)
val MetallicSilver = Color(0xFFF2F2F2)
val MetallicMuted = Color(0xFF888888)
val DarkMuted = Color(0xFF555555)
val UltraDark = Color(0xFF333333)

// Semantic Financial Indicators (Cyber-Fintech Immersive Palette)
val FinancialSuccess = Color(0xFF00FF88) // Matrix Green Verified / Approved
val FinancialSuccessBg = Color(0xFF082618)
val FinancialWarning = Color(0xFFFFB800) // Amber Step-up Auth / Medium Risk
val FinancialWarningBg = Color(0xFF2B1C04)
val FinancialError = Color(0xFFFF3366)   // Crimson Declined / High Risk / Timeout
val FinancialErrorBg = Color(0xFF2E0914)
val FinancialPurple = Color(0xFFA855F7)  // Cyber Purple
val FinancialGold = Color(0xFFFFC700)

val TextPrimary = Color(0xFFF2F2F2)
val TextSecondary = Color(0xFF888888)
val TextTertiary = Color(0xFF555555)

