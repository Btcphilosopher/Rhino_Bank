// ============================================================================
// RHINOBANK LBDC — FINANCIAL OPERATING SYSTEM APPLICATION ROOT
// ============================================================================

import React, { useState, useEffect, useCallback } from 'react';
import { 
  Landmark, 
  Cpu, 
  Coins, 
  BookOpen, 
  Repeat, 
  Wallet, 
  Store, 
  ShieldAlert, 
  Layers, 
  Zap, 
  ShieldCheck, 
  Terminal,
  Activity
} from 'lucide-react';

import { Header } from './components/Header';
import { OverviewView } from './components/OverviewView';
import { ConsensusView } from './components/ConsensusView';
import { MonetaryView } from './components/MonetaryView';
import { LedgerView } from './components/LedgerView';
import { SettlementView } from './components/SettlementView';
import { WalletsView } from './components/WalletsView';
import { MerchantView } from './components/MerchantView';
import { ComplianceView } from './components/ComplianceView';
import { ExplorerView } from './components/ExplorerView';
import { StressLabView } from './components/StressLabView';
import { InvariantsView } from './components/InvariantsView';
import { RustWorkspaceView } from './components/RustWorkspaceView';

// Fallback in-browser engines for offline / direct preview stability
import { ConsensusEngine } from './services/consensus';
import { MonetaryLedger } from './services/ledger';
import { Blockchain } from './services/blockchain';
import { MonetaryEngine } from './services/monetary';
import { SettlementEngine } from './services/settlement';
import { MerchantEngine } from './services/merchant';
import { ComplianceEngine } from './services/compliance';
import { SimulationLab } from './services/simulation';
import { InvariantTestSuite } from './services/invariantTests';
import { RUST_WORKSPACE_FILES } from './services/rustWorkspace';

// Local singleton fallback instances
const localConsensus = new ConsensusEngine();
const localLedger = new MonetaryLedger();
const localBlockchain = new Blockchain(localConsensus, localLedger);
const localMonetary = new MonetaryEngine(localBlockchain, localLedger);
const localSettlement = new SettlementEngine(localBlockchain, localLedger);
const localMerchant = new MerchantEngine(localBlockchain);
const localCompliance = new ComplianceEngine();
const localSimulation = new SimulationLab(localBlockchain, localConsensus, localMonetary);
const localInvariants = new InvariantTestSuite(localBlockchain, localConsensus, localMonetary, localLedger);

export function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isSyncing, setIsSyncing] = useState(false);

  // Core Data States
  const [status, setStatus] = useState<any>(null);
  const [blocks, setBlocks] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [validators, setValidators] = useState<any[]>([]);
  const [reserves, setReserves] = useState<any[]>([]);
  const [journal, setJournal] = useState<any[]>([]);
  const [chart, setChart] = useState<any[]>([]);
  const [participants, setParticipants] = useState<any[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [merchants, setMerchants] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [assessments, setAssessments] = useState<any[]>([]);
  const [invariants, setInvariants] = useState<any[]>([]);
  const [rustFiles, setRustFiles] = useState<any[]>(RUST_WORKSPACE_FILES);

  // Sync state from server or local service
  const fetchAllData = useCallback(async () => {
    setIsSyncing(true);
    try {
      // Attempt to load from REST API
      const res = await fetch('/api/status');
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
        
        const [blksRes, accsRes, valsRes, rsvsRes, jrnRes, chrtRes, partRes, btcRes, merRes, invsRes, compRes, invrRes] = await Promise.all([
          fetch('/api/blocks').then(r => r.json()),
          fetch('/api/accounts').then(r => r.json()),
          fetch('/api/validators').then(r => r.json()),
          fetch('/api/monetary/reserves').then(r => r.json()),
          fetch('/api/ledger/journal').then(r => r.json()),
          fetch('/api/ledger/chart').then(r => r.json()),
          fetch('/api/settlement/participants').then(r => r.json()),
          fetch('/api/settlement/batches').then(r => r.json()),
          fetch('/api/merchants').then(r => r.json()),
          fetch('/api/merchants/invoices').then(r => r.json()),
          fetch('/api/compliance/assessments').then(r => r.json()),
          fetch('/api/invariants/test').then(r => r.json())
        ]);

        setBlocks(blksRes);
        setAccounts(accsRes);
        setValidators(valsRes);
        setReserves(rsvsRes);
        setJournal(jrnRes);
        setChart(chrtRes);
        setParticipants(partRes);
        setBatches(btcRes);
        setMerchants(merRes);
        setInvoices(invsRes);
        setAssessments(compRes);
        setInvariants(invrRes);
      } else {
        throw new Error('API unavailable, switching to local state engine');
      }
    } catch (e) {
      // Local In-Memory Fallback Engine
      const sup = localMonetary.getSupplyState();
      const dec = localConsensus.calculateDecentralisationMetrics();
      const vel = localMonetary.calculateMoneyVelocity(30);
      const tb = localLedger.calculateTrialBalance();
      const rec = localLedger.runTriPartyReconciliation(
        sup.totalSupplyUnits,
        BigInt(Math.floor(localMonetary.getTotalReserveValueGbp() * 10000))
      );
      const latest = localBlockchain.getLatestBlock();

      setStatus({
        network: 'RhinoBank LBDC Sovereign Settlement Network',
        currentHeight: latest.height,
        currentEpoch: latest.epoch,
        currentSlot: latest.slot,
        totalValidators: localConsensus.getValidators().length,
        activeValidators: localConsensus.getValidators().filter(v => v.status === 'Active').length,
        supply: sup,
        decentralisation: dec,
        velocity: vel,
        trialBalance: tb,
        reconciliation: rec,
        policy: localMonetary.getPolicySettings()
      });

      setBlocks(localBlockchain.getBlocks().slice(-50).reverse());
      setAccounts(localBlockchain.getAccounts());
      setValidators(localConsensus.getValidators());
      setReserves(localMonetary.getReserveAssets());
      setJournal(localLedger.getJournal());
      setChart(localLedger.getChartOfAccounts());
      setParticipants(localSettlement.getParticipants());
      setBatches(localSettlement.getBatches());
      setMerchants(localMerchant.getMerchants());
      setInvoices(localMerchant.getInvoices());
      setAssessments(localCompliance.getRecentAssessments());
      setInvariants(localInvariants.runAllInvariantTests());
    } finally {
      setIsSyncing(false);
    }
  }, []);

  // Initial load and periodic block refresh
  useEffect(() => {
    fetchAllData();
    const interval = setInterval(() => {
      // Periodic block tick
      try {
        localBlockchain.produceBlock();
      } catch (err) {
        // silent
      }
      fetchAllData();
    }, 4000);
    return () => clearInterval(interval);
  }, [fetchAllData]);

  // Action Handlers
  const handleTransfer = async (params: any) => {
    try {
      const res = await fetch('/api/transactions/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (res.ok) {
        await fetchAllData();
      } else {
        const err = await res.json();
        throw new Error(err.error || 'Transfer failed');
      }
    } catch (e: any) {
      // Local fallback execution
      const amountUnits = BigInt(Math.floor(parseFloat(params.amount) * 10000));
      localBlockchain.submitTransaction({
        type: 'Transfer',
        senderId: params.senderId,
        recipientId: params.recipientId,
        amountUnits,
        memo: params.memo,
        settlementMode: params.settlementMode
      });
      localBlockchain.produceBlock();
      await fetchAllData();
    }
  };

  const handleMint = async (params: any) => {
    try {
      const res = await fetch('/api/transactions/mint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (res.ok) {
        await fetchAllData();
      } else {
        const err = await res.json();
        throw new Error(err.error || 'Mint failed');
      }
    } catch (e: any) {
      const amountUnits = BigInt(Math.floor(parseFloat(params.amount) * 10000));
      localMonetary.executeAuthorizedMint({
        amountUnits,
        destinationAccountId: params.destinationAccountId,
        issuanceReason: params.issuanceReason,
        signers: ['0xpk_rhino_gov_1', '0xpk_rhino_gov_2', '0xpk_rhino_gov_3'],
        statutoryOrderRef: params.statutoryOrderRef
      });
      localBlockchain.produceBlock();
      await fetchAllData();
    }
  };

  const handleBurn = async (params: any) => {
    try {
      const res = await fetch('/api/transactions/burn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (res.ok) {
        await fetchAllData();
      } else {
        const err = await res.json();
        throw new Error(err.error || 'Burn failed');
      }
    } catch (e: any) {
      const amountUnits = BigInt(Math.floor(parseFloat(params.amount) * 10000));
      localMonetary.executeAuthorizedBurn({
        amountUnits,
        sourceAccountId: params.sourceAccountId,
        redemptionReason: params.redemptionReason,
        signers: ['0xpk_rhino_burn_1', '0xpk_rhino_burn_2']
      });
      localBlockchain.produceBlock();
      await fetchAllData();
    }
  };

  const handleSlashValidator = async (id: string, reason: string, penalty: number) => {
    try {
      await fetch('/api/validators/slash', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ validatorId: id, reason, penaltyAmount: penalty })
      });
    } catch {
      localConsensus.slashValidator(id, reason, BigInt(penalty * 10000));
    }
    await fetchAllData();
  };

  const handleJailValidator = async (id: string, epochs: number) => {
    try {
      await fetch('/api/validators/jail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ validatorId: id, durationEpochs: epochs })
      });
    } catch {
      localConsensus.jailValidator(id, epochs);
    }
    await fetchAllData();
  };

  const handleUnjailValidator = async (id: string) => {
    try {
      await fetch('/api/validators/unjail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ validatorId: id })
      });
    } catch {
      localConsensus.unjailValidator(id);
    }
    await fetchAllData();
  };

  const handleRegisterValidator = async (data: any) => {
    try {
      await fetch('/api/validators/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
    } catch {
      localConsensus.registerValidator({
        name: data.name,
        operator: data.operator,
        jurisdiction: data.jurisdiction,
        stakeUnits: BigInt(Math.floor(parseFloat(data.stakeAmount) * 10000)),
        ipAddress: data.ipAddress
      });
    }
    await fetchAllData();
  };

  const handleUpdatePolicy = async (params: any) => {
    try {
      await fetch('/api/monetary/policy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
    } catch {
      localMonetary.updatePolicySettings(params);
    }
    await fetchAllData();
  };

  const handleExecuteRtgs = async (params: any) => {
    try {
      await fetch('/api/settlement/rtgs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
    } catch {
      localSettlement.executeRtgsSettlement({
        senderBankId: params.senderBankId,
        recipientBankId: params.recipientBankId,
        amountUnits: BigInt(Math.floor(parseFloat(params.amount) * 10000)),
        reference: params.reference
      });
    }
    await fetchAllData();
  };

  const handleExecuteNetting = async () => {
    try {
      await fetch('/api/settlement/netting-cycle', { method: 'POST' });
    } catch {
      localSettlement.executeMultilateralNettingBatch();
    }
    await fetchAllData();
  };

  const handleFreezeAccount = async (id: string, frozen: boolean) => {
    try {
      await fetch('/api/accounts/freeze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId: id, frozen })
      });
    } catch {
      localBlockchain.setAccountFreezeState(id, frozen);
    }
    await fetchAllData();
  };

  const handleCreateInvoice = async (params: any) => {
    try {
      const res = await fetch('/api/merchants/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      const data = await res.json();
      await fetchAllData();
      return data;
    } catch {
      const invoice = await localMerchant.createInvoice({
        merchantId: params.merchantId,
        amountUnits: BigInt(Math.floor(parseFloat(params.amount) * 10000)),
        description: params.description
      });
      await fetchAllData();
      return { invoice };
    }
  };

  const handlePayInvoice = async (invoiceId: string, payerWalletId: string) => {
    try {
      await fetch('/api/merchants/invoices/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoiceId, payerWalletId })
      });
    } catch {
      localMerchant.settleInvoice(invoiceId, payerWalletId);
    }
    await fetchAllData();
  };

  const handleGenerateZkProof = async (claimType: string, secretValue: string) => {
    try {
      const res = await fetch('/api/compliance/zk-proof', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claimType, secretValue })
      });
      return await res.json();
    } catch {
      const proof = localCompliance.issueZkProof(claimType, secretValue);
      return { proof };
    }
  };

  const handleRunSurge = async (count: number) => {
    try {
      const res = await fetch('/api/simulation/surge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ txCount: count })
      });
      const data = await res.json();
      await fetchAllData();
      return data;
    } catch {
      const data = localSimulation.runTransactionSurgeTest(count);
      await fetchAllData();
      return data;
    }
  };

  const handleRunPartition = async () => {
    try {
      const res = await fetch('/api/simulation/partition', { method: 'POST' });
      const data = await res.json();
      await fetchAllData();
      return data;
    } catch {
      const data = localSimulation.runValidatorPartitionTest();
      await fetchAllData();
      return data;
    }
  };

  const handleRunLiquidityShock = async () => {
    try {
      const res = await fetch('/api/simulation/liquidity-shock', { method: 'POST' });
      const data = await res.json();
      await fetchAllData();
      return data;
    } catch {
      const data = localSimulation.runLiquidityShockTest();
      await fetchAllData();
      return data;
    }
  };

  const handleRunInvariants = async () => {
    try {
      const res = await fetch('/api/invariants/test');
      const data = await res.json();
      setInvariants(data);
    } catch {
      setInvariants(localInvariants.runAllInvariantTests());
    }
  };

  // Tab definitions
  const tabs = [
    { id: 'overview', label: 'Executive Overview', icon: Landmark },
    { id: 'consensus', label: 'PoS Consensus', icon: Cpu },
    { id: 'monetary', label: 'Monetary Authority', icon: Coins },
    { id: 'ledger', label: 'General Ledger', icon: BookOpen },
    { id: 'settlement', label: 'RTGS & Netting', icon: Repeat },
    { id: 'wallets', label: 'Digital Wallets', icon: Wallet },
    { id: 'merchants', label: 'POS & Dynamic QR', icon: Store },
    { id: 'compliance', label: 'AML & Compliance', icon: ShieldAlert },
    { id: 'explorer', label: 'Blockchain Explorer', icon: Layers },
    { id: 'stress', label: 'Stress Lab (MV=PY)', icon: Zap },
    { id: 'invariants', label: 'Invariant Verifier', icon: ShieldCheck },
    { id: 'rust', label: 'Rust Node Architecture', icon: Terminal }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-900 selection:text-emerald-100">
      {/* Institutional Top Header */}
      <Header
        currentHeight={status?.currentHeight || 1}
        currentEpoch={status?.currentEpoch || 1}
        currentSlot={status?.currentSlot || 1}
        tps={status?.velocity?.tpsCapacity || 450}
        reserveRatio={status?.supply?.reserveCoverageRatio || 108.4}
        isSyncing={isSyncing}
        onRefresh={fetchAllData}
      />

      {/* Navigation Tab Bar */}
      <nav className="bg-slate-900 border-b border-slate-800/80 sticky top-[61px] z-40 shadow-sm overflow-x-auto">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-1 py-1.5 min-w-max">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/80 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Main Workspace View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {activeTab === 'overview' && (
          <OverviewView
            status={status}
            blocks={blocks}
            validators={validators}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onRunSurge={() => handleRunSurge(250)}
          />
        )}

        {activeTab === 'consensus' && (
          <ConsensusView
            validators={validators}
            decentralisation={status?.decentralisation}
            onSlash={handleSlashValidator}
            onJail={handleJailValidator}
            onUnjail={handleUnjailValidator}
            onRegister={handleRegisterValidator}
          />
        )}

        {activeTab === 'monetary' && (
          <MonetaryView
            supply={status?.supply}
            reserves={reserves}
            policy={status?.policy}
            accounts={accounts}
            onMint={handleMint}
            onBurn={handleBurn}
            onUpdatePolicy={handleUpdatePolicy}
          />
        )}

        {activeTab === 'ledger' && (
          <LedgerView
            chart={chart}
            journal={journal}
            trialBalance={status?.trialBalance}
            reconciliation={status?.reconciliation}
          />
        )}

        {activeTab === 'settlement' && (
          <SettlementView
            participants={participants}
            batches={batches}
            onExecuteRtgs={handleExecuteRtgs}
            onExecuteNetting={handleExecuteNetting}
          />
        )}

        {activeTab === 'wallets' && (
          <WalletsView
            accounts={accounts}
            onTransfer={handleTransfer}
            onFreezeAccount={handleFreezeAccount}
          />
        )}

        {activeTab === 'merchants' && (
          <MerchantView
            merchants={merchants}
            invoices={invoices}
            accounts={accounts}
            onCreateInvoice={handleCreateInvoice}
            onPayInvoice={handlePayInvoice}
          />
        )}

        {activeTab === 'compliance' && (
          <ComplianceView
            assessments={assessments}
            onGenerateZkProof={handleGenerateZkProof}
          />
        )}

        {activeTab === 'explorer' && (
          <ExplorerView
            blocks={blocks}
          />
        )}

        {activeTab === 'stress' && (
          <StressLabView
            velocity={status?.velocity}
            onRunSurge={handleRunSurge}
            onRunPartition={handleRunPartition}
            onRunLiquidityShock={handleRunLiquidityShock}
          />
        )}

        {activeTab === 'invariants' && (
          <InvariantsView
            invariants={invariants}
            onRunAll={handleRunInvariants}
          />
        )}

        {activeTab === 'rust' && (
          <RustWorkspaceView
            files={rustFiles}
          />
        )}
      </main>

      {/* Institutional Network Footer */}
      <footer className="bg-slate-950 border-t border-slate-800/80 py-4 text-xs font-mono text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <div>
            RhinoBank LBDC Protocol • Bank of England & PRA/FCA Regulatory Settlement Framework
          </div>
          <div className="flex items-center gap-3 text-slate-400">
            <span>BFT Supermajority: &ge; 66.7%</span>
            <span>•</span>
            <span>Ed25519 & BLS12-381 HSM Secured</span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">M0 Reserve Solvency: 100% Verified</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
