// ============================================================================
// RHINOBANK LBDC — DETERMINISTIC BLOCKCHAIN STATE MACHINE & BLOCKS ENGINE
// ============================================================================

import { Block, Transaction, WalletAccount, TransactionStatus, TransactionType } from '../types';
import { sha256, computeMerkleRoot } from './crypto';
import { ConsensusEngine } from './consensus';
import { MonetaryLedger } from './ledger';

export const CHAIN_ID = 'rhinobank-lbdc-uk-main-01';

export class Blockchain {
  private blocks: Block[] = [];
  private pendingTransactions: Transaction[] = [];
  private accounts: Map<string, WalletAccount> = new Map();
  private consensus: ConsensusEngine;
  private ledger: MonetaryLedger;
  private currentHeight: number = 0;
  private stateRoot: string = '';

  constructor(consensus: ConsensusEngine, ledger: MonetaryLedger) {
    this.consensus = consensus;
    this.ledger = ledger;
    this.initializeGenesisAccounts();
    this.createGenesisBlock();
  }

  private initializeGenesisAccounts() {
    const initialWallets: WalletAccount[] = [
      {
        id: '0xrhino_treasury_master_001',
        label: 'RhinoBank Central Treasury & Monetary Authority',
        type: 'TREASURY',
        ownerName: 'RhinoBank Treasury Operations',
        institution: 'RhinoBank UK plc',
        publicKey: '0xpk_rhino_treasury_sec_master',
        balanceUnits: 150_000_000_0000n, // £150M in reserve treasury
        availableUnits: 150_000_000_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 0n,
        nonce: 104,
        kycLevel: 'TIER_3_INSTITUTIONAL',
        isFrozen: false,
        dailyLimitUnits: 1_000_000_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 90
      },
      {
        id: '0xbarclays_settlement_hub_002',
        label: 'Barclays Clearing Interbank RTGS Account',
        type: 'BANK',
        ownerName: 'Barclays Settlement Desk',
        institution: 'Barclays Bank UK PLC',
        publicKey: '0xpk_barclays_rtgs_wallet_pub',
        balanceUnits: 45_000_000_0000n, // £45M
        availableUnits: 45_000_000_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 8_000_000_0000n,
        nonce: 82,
        kycLevel: 'TIER_3_INSTITUTIONAL',
        isFrozen: false,
        dailyLimitUnits: 500_000_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 90
      },
      {
        id: '0xhsbc_settlement_hub_003',
        label: 'HSBC Institutional Liquidity Gateway',
        type: 'BANK',
        ownerName: 'HSBC UK Clearing Services',
        institution: 'HSBC UK Bank plc',
        publicKey: '0xpk_hsbc_rtgs_wallet_pub',
        balanceUnits: 40_000_000_0000n, // £40M
        availableUnits: 40_000_000_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 7_500_000_0000n,
        nonce: 71,
        kycLevel: 'TIER_3_INSTITUTIONAL',
        isFrozen: false,
        dailyLimitUnits: 500_000_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 90
      },
      {
        id: '0xmarks_and_spencer_merch_010',
        label: 'Marks & Spencer Retail Central Clearing',
        type: 'MERCHANT',
        ownerName: 'M&S Finance & Payments Ltd',
        institution: 'Marks & Spencer Group',
        publicKey: '0xpk_ms_retail_pay_hub',
        balanceUnits: 12_450_000_0000n, // £12.45M
        availableUnits: 12_450_000_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 0n,
        nonce: 420,
        kycLevel: 'TIER_2_VERIFIED',
        isFrozen: false,
        dailyLimitUnits: 50_000_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 60
      },
      {
        id: '0xsainsburys_supermarket_merch_011',
        label: "Sainsbury's Supermarkets POS Master",
        type: 'MERCHANT',
        ownerName: "J Sainsbury plc Merchant Dept",
        institution: "Sainsbury's Supermarkets",
        publicKey: '0xpk_sainsbury_pay_terminal_pub',
        balanceUnits: 9_820_000_0000n,
        availableUnits: 9_820_000_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 0n,
        nonce: 318,
        kycLevel: 'TIER_2_VERIFIED',
        isFrozen: false,
        dailyLimitUnits: 50_000_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 60
      },
      {
        id: '0xacme_logistics_corp_020',
        label: 'Acme Supply Chain Logistics Ltd',
        type: 'BUSINESS',
        ownerName: 'David Sterling (CFO)',
        institution: 'Acme UK Group',
        publicKey: '0xpk_acme_commercial_wallet',
        balanceUnits: 4_250_000_0000n, // £4.25M
        availableUnits: 3_750_000_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 500_000_0000n, // £500k in smart escrow
        stakedUnits: 0n,
        nonce: 154,
        kycLevel: 'TIER_2_VERIFIED',
        isFrozen: false,
        dailyLimitUnits: 10_000_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 45
      },
      {
        id: '0xeleanor_vane_personal_101',
        label: 'Eleanor Vane — Rhino Premier Account',
        type: 'PERSONAL',
        ownerName: 'Eleanor Vane',
        institution: 'RhinoBank Retail',
        publicKey: '0xpk_user_eleanor_vane_981',
        balanceUnits: 84_500_0000n, // £84,500
        availableUnits: 84_500_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 0n,
        nonce: 49,
        kycLevel: 'TIER_2_VERIFIED',
        isFrozen: false,
        dailyLimitUnits: 25_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 30
      },
      {
        id: '0xjames_holloway_personal_102',
        label: 'James Holloway — Standard Digital Wallet',
        type: 'PERSONAL',
        ownerName: 'James Holloway',
        institution: 'RhinoBank Retail',
        publicKey: '0xpk_user_james_holloway_332',
        balanceUnits: 14_200_0000n, // £14,200
        availableUnits: 14_200_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 0n,
        nonce: 28,
        kycLevel: 'TIER_2_VERIFIED',
        isFrozen: false,
        dailyLimitUnits: 10_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 30
      },
      {
        id: '0xoxford_coffee_roasters_015',
        label: 'Oxford Artisan Coffee Merchants',
        type: 'MERCHANT',
        ownerName: 'Sarah Jenkins',
        institution: 'Independent Merchant',
        publicKey: '0xpk_oxford_coffee_pos_terminal',
        balanceUnits: 38_900_0000n, // £38,900
        availableUnits: 38_900_0000n,
        pendingUnits: 0n,
        frozenUnits: 0n,
        escrowUnits: 0n,
        stakedUnits: 0n,
        nonce: 195,
        kycLevel: 'TIER_2_VERIFIED',
        isFrozen: false,
        dailyLimitUnits: 5_000_0000n,
        dailySpentUnits: 0n,
        createdTimestamp: Date.now() - 86400000 * 20
      }
    ];

    for (const w of initialWallets) {
      this.accounts.set(w.id, w);
    }

    this.recomputeStateRoot();
  }

  private recomputeStateRoot(): string {
    const serializedAccounts: string[] = [];
    for (const [id, acc] of this.accounts.entries()) {
      serializedAccounts.push(`${id}:${acc.balanceUnits}:${acc.nonce}:${acc.isFrozen}`);
    }
    serializedAccounts.sort();
    this.stateRoot = computeMerkleRoot(serializedAccounts);
    return this.stateRoot;
  }

  private createGenesisBlock() {
    const genesisProposer = this.consensus.getValidators()[0];
    const genesisTime = Date.now() - 1000 * 60 * 30; // 30 mins ago
    const txRoot = sha256('RHINO_LBDC_GENESIS_TX_ROOT_0000');
    const receiptsRoot = sha256('RHINO_LBDC_GENESIS_RECEIPTS_ROOT_0000');
    const blockHash = sha256(`RHINO_BLOCK_0_PREV_0x0000000000000000000000000000000000000000000000000000000000000000_${this.stateRoot}`);

    const genesisBlock: Block = {
      height: 0,
      epoch: 140,
      slot: 0,
      timestamp: genesisTime,
      previousHash: '0x0000000000000000000000000000000000000000000000000000000000000000',
      hash: blockHash,
      stateRoot: this.stateRoot,
      transactionRoot: txRoot,
      receiptsRoot: receiptsRoot,
      proposer: genesisProposer.id,
      proposerName: genesisProposer.name,
      validatorCommitment: genesisProposer.consensusKey,
      transactionsCount: 0,
      transactions: [],
      attestations: this.consensus.generateAttestations(blockHash, 0),
      totalFeesUnits: 0n,
      consensusParticipationRate: 100.0
    };

    this.blocks.push(genesisBlock);
    this.currentHeight = 0;

    // Seed some historical blocks for explorer richness
    this.seedHistoricalBlocks();
  }

  private seedHistoricalBlocks() {
    for (let h = 1; h <= 18; h++) {
      const prevBlock = this.blocks[this.blocks.length - 1];
      const proposer = this.consensus.selectProposerForSlot(h);
      const fakeTxs = this.generateSyntheticTxsForBlock(h);
      const txRoot = computeMerkleRoot(fakeTxs.map(t => t.id));
      const receiptsRoot = computeMerkleRoot(fakeTxs.map(t => sha256(t.id + t.status)));
      const hash = sha256(`RHINO_BLOCK_${h}_PREV_${prevBlock.hash}_${txRoot}_${this.stateRoot}`);

      const blk: Block = {
        height: h,
        epoch: 140 + Math.floor(h / 8),
        slot: h % 8,
        timestamp: prevBlock.timestamp + 4000,
        previousHash: prevBlock.hash,
        hash,
        stateRoot: this.stateRoot,
        transactionRoot: txRoot,
        receiptsRoot,
        proposer: proposer.id,
        proposerName: proposer.name,
        validatorCommitment: proposer.consensusKey,
        transactionsCount: fakeTxs.length,
        transactions: fakeTxs,
        attestations: this.consensus.generateAttestations(hash, h),
        totalFeesUnits: BigInt(fakeTxs.length) * 50n,
        consensusParticipationRate: 98.4 + (h % 3) * 0.5
      };
      this.blocks.push(blk);
      this.currentHeight = h;
    }
  }

  private generateSyntheticTxsForBlock(height: number): Transaction[] {
    const txs: Transaction[] = [];
    const count = 3 + (height % 5);
    const sender = this.accounts.get('0xeleanor_vane_personal_101')!;
    const recipient = this.accounts.get('0xoxford_coffee_roasters_015')!;

    for (let i = 0; i < count; i++) {
      const amount = BigInt(450 + (i * 120)) * 10000n / 100n; // e.g. £4.50, £5.70
      txs.push({
        id: `0xtx_hist_${height}_${i}_${sha256(`TX_${height}_${i}`).substring(2, 18)}`,
        type: 'Transfer',
        sender: sender.id,
        senderName: sender.label,
        recipient: recipient.id,
        recipientName: recipient.label,
        asset: 'LBDC',
        amountUnits: amount,
        amountFormatted: (Number(amount) / 10000).toFixed(2) + ' LBDC',
        feeUnits: 50n,
        nonce: 10 + height + i,
        timestamp: Date.now() - (20 - height) * 4000,
        signature: `0xsig_${sha256(`SIG_${height}_${i}`).substring(2, 66)}`,
        status: 'Finalized',
        blockHeight: height,
        epoch: 140,
        memo: 'Retail contactless tap settlement',
        settlementMode: 'INSTANT_RETAIL',
        amlRiskScore: 4,
        complianceStatus: 'CLEARED'
      });
    }
    return txs;
  }

  public getBlocks(): Block[] {
    return this.blocks;
  }

  public getLatestBlock(): Block {
    return this.blocks[this.blocks.length - 1];
  }

  public getAccounts(): WalletAccount[] {
    return Array.from(this.accounts.values());
  }

  public getAccount(id: string): WalletAccount | undefined {
    return this.accounts.get(id);
  }

  public getPendingTransactions(): Transaction[] {
    return this.pendingTransactions;
  }

  // Submit and validate a new transaction into the mempool
  public submitTransaction(txParams: {
    type: TransactionType;
    senderId: string;
    recipientId: string;
    amountUnits: bigint;
    feeUnits?: bigint;
    memo?: string;
    settlementMode?: 'RTGS_GROSS' | 'MULTILATERAL_NETTING' | 'INSTANT_RETAIL';
    escrowReleaseTime?: number;
  }): Transaction {
    const sender = this.accounts.get(txParams.senderId);
    const recipient = this.accounts.get(txParams.recipientId);

    if (!sender && txParams.type !== 'Mint') {
      throw new Error(`Sender account ${txParams.senderId} does not exist.`);
    }
    if (!recipient && txParams.type !== 'Burn') {
      throw new Error(`Recipient account ${txParams.recipientId} does not exist.`);
    }

    if (sender && sender.isFrozen) {
      throw new Error(`Sender account ${sender.label} is currently frozen by compliance sanctions order.`);
    }
    if (recipient && recipient.isFrozen) {
      throw new Error(`Recipient account ${recipient.label} is currently frozen by compliance sanctions order.`);
    }

    const fee = txParams.feeUnits !== undefined ? txParams.feeUnits : 50n; // default 0.0050 LBDC
    const totalRequired = txParams.amountUnits + fee;

    if (sender && sender.availableUnits < totalRequired && txParams.type !== 'Mint') {
      throw new Error(`Insufficient available funds. Required: ${(Number(totalRequired) / 10000).toFixed(2)} LBDC, Available: ${(Number(sender.availableUnits) / 10000).toFixed(2)} LBDC.`);
    }

    // Daily spending limit validation
    if (sender && sender.type === 'PERSONAL') {
      if (sender.dailySpentUnits + txParams.amountUnits > sender.dailyLimitUnits) {
        throw new Error(`Transaction exceeds daily compliance velocity limit of ${(Number(sender.dailyLimitUnits) / 10000).toFixed(2)} LBDC.`);
      }
    }

    const txId = `0xtx_${Date.now().toString(16)}_${sha256(Math.random().toString()).substring(2, 14)}`;
    const signature = `0xsig_${sha256(`TX_SIG_${txId}_${txParams.senderId}_${txParams.recipientId}_${txParams.amountUnits}`).substring(2, 66)}`;

    const tx: Transaction = {
      id: txId,
      type: txParams.type,
      sender: txParams.senderId,
      senderName: sender?.label || 'Monetary Authority Mint',
      recipient: txParams.recipientId,
      recipientName: recipient?.label || 'Monetary Authority Burn Sink',
      asset: 'LBDC',
      amountUnits: txParams.amountUnits,
      amountFormatted: (Number(txParams.amountUnits) / 10000).toFixed(4) + ' LBDC',
      feeUnits: fee,
      nonce: sender ? ++sender.nonce : 1,
      timestamp: Date.now(),
      signature,
      status: 'Pending',
      memo: txParams.memo || 'Standard LBDC Electronic Transfer',
      settlementMode: txParams.settlementMode || 'INSTANT_RETAIL',
      amlRiskScore: Math.floor(Math.random() * 18) + 2,
      complianceStatus: 'CLEARED',
      escrowReleaseTime: txParams.escrowReleaseTime
    };

    // Fast-track state modification in mempool for instant local UI responsiveness
    if (sender && txParams.type !== 'Mint') {
      sender.availableUnits -= totalRequired;
      sender.pendingUnits += totalRequired;
      sender.dailySpentUnits += txParams.amountUnits;
    }

    this.pendingTransactions.push(tx);
    return tx;
  }

  // Produce and seal next Block in the PoS chain with deterministic Casper finality
  public produceBlock(): Block {
    const nextHeight = this.currentHeight + 1;
    const { slot, epoch } = this.consensus.advanceSlot();
    const proposer = this.consensus.selectProposerForSlot(nextHeight);
    const prevBlock = this.getLatestBlock();

    // Pull up to 50 pending txs from mempool
    const txsToInclude = this.pendingTransactions.splice(0, 50);

    let totalFees = 0n;

    // Apply state transitions deterministically
    for (const tx of txsToInclude) {
      tx.status = 'Finalized';
      tx.blockHeight = nextHeight;
      tx.epoch = epoch;

      const sender = this.accounts.get(tx.sender);
      const recipient = this.accounts.get(tx.recipient);

      if (tx.type === 'Transfer' || tx.type === 'Settlement') {
        if (sender) {
          sender.balanceUnits -= (tx.amountUnits + tx.feeUnits);
          sender.pendingUnits -= (tx.amountUnits + tx.feeUnits);
        }
        if (recipient) {
          recipient.balanceUnits += tx.amountUnits;
          recipient.availableUnits += tx.amountUnits;
        }
        totalFees += tx.feeUnits;

        // Record in Double-Entry General Ledger
        this.ledger.recordDoubleEntry(
          tx.id,
          '2020', // Debit Customer Deposit / Interbank Account
          '2030', // Credit Merchant / Recipient
          tx.amountUnits,
          `${tx.type}: ${tx.senderName} ➔ ${tx.recipientName} (${tx.memo})`
        );
      } else if (tx.type === 'Mint') {
        if (recipient) {
          recipient.balanceUnits += tx.amountUnits;
          recipient.availableUnits += tx.amountUnits;
        }
        // Record in Double-Entry General Ledger
        this.ledger.recordDoubleEntry(
          tx.id,
          '1010', // Debit Bank of England Cash Reserves
          '2010', // Credit LBDC Tokens in Issue
          tx.amountUnits,
          `Statutory M0 Monetary Issuance by RhinoBank Central Treasury`
        );
      } else if (tx.type === 'Burn') {
        if (sender) {
          sender.balanceUnits -= tx.amountUnits;
          sender.pendingUnits -= tx.amountUnits;
        }
        // Record in Double-Entry General Ledger
        this.ledger.recordDoubleEntry(
          tx.id,
          '2010', // Debit LBDC Tokens in Issue (Retirement)
          '1010', // Credit Bank of England Cash Reserves
          tx.amountUnits,
          `Statutory LBDC Monetary Redemption & Burn`
        );
      } else if (tx.type === 'Escrow') {
        if (sender) {
          sender.balanceUnits -= tx.amountUnits;
          sender.pendingUnits -= tx.amountUnits;
          sender.escrowUnits += tx.amountUnits;
        }
      }
    }

    // Award block fees to proposer
    proposer.blocksProposed++;
    proposer.rewardBalanceUnits += totalFees + 50_0000n; // fee + block reward

    // Recompute state root Merkle
    const newStateRoot = this.recomputeStateRoot();
    const txRoot = computeMerkleRoot(txsToInclude.map(t => t.id));
    const receiptsRoot = computeMerkleRoot(txsToInclude.map(t => sha256(t.id + ':Finalized')));
    const blockHash = sha256(`RHINO_BLOCK_${nextHeight}_PREV_${prevBlock.hash}_${txRoot}_${newStateRoot}`);

    const newBlock: Block = {
      height: nextHeight,
      epoch,
      slot,
      timestamp: Date.now(),
      previousHash: prevBlock.hash,
      hash: blockHash,
      stateRoot: newStateRoot,
      transactionRoot: txRoot,
      receiptsRoot,
      proposer: proposer.id,
      proposerName: proposer.name,
      validatorCommitment: proposer.consensusKey,
      transactionsCount: txsToInclude.length,
      transactions: txsToInclude,
      attestations: this.consensus.generateAttestations(blockHash, nextHeight),
      totalFeesUnits: totalFees,
      consensusParticipationRate: 98.9
    };

    this.blocks.push(newBlock);
    this.currentHeight = nextHeight;

    // Keep memory bounded to latest 200 blocks in frontend state
    if (this.blocks.length > 200) {
      this.blocks.shift();
    }

    return newBlock;
  }

  // Freeze or unfreeze wallet account (compliance order)
  public setAccountFreezeState(accountId: string, frozen: boolean): WalletAccount {
    const acc = this.accounts.get(accountId);
    if (!acc) throw new Error(`Account ${accountId} not found.`);
    acc.isFrozen = frozen;
    if (frozen) {
      acc.frozenUnits += acc.availableUnits;
      acc.availableUnits = 0n;
    } else {
      acc.availableUnits += acc.frozenUnits;
      acc.frozenUnits = 0n;
    }
    this.recomputeStateRoot();
    return acc;
  }
}
