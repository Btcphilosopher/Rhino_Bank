// ============================================================================
// RHINOBANK LBDC — MONETARY POLICY, ISSUANCE, RESERVES & VELOCITY ENGINE
// ============================================================================

import { MonetarySupplyState, MonetaryPolicySettings, ReserveAssetItem, CurrencyPegMode } from '../types';
import { Blockchain } from './blockchain';
import { MonetaryLedger } from './ledger';

export class MonetaryEngine {
  private blockchain: Blockchain;
  private ledger: MonetaryLedger;
  private pegMode: CurrencyPegMode = 'FIXED_GBP';
  private pegRatioToGbp: number = 1.0000; // 1 LBDC = £1.0000 GBP

  private reserveAssets: ReserveAssetItem[] = [
    {
      id: 'res_boe_001',
      assetType: 'BANK_OF_ENGLAND_RESERVES',
      custodian: 'Bank of England (Threadneedle St Account #99104)',
      nominalValueGbp: 250_000_000,
      liquidValueGbp: 250_000_000,
      haircutPercent: 0.0,
      durationMonths: 0,
      verifiedAt: new Date().toISOString().split('T')[0],
      auditor: 'PricewaterhouseCoopers LLP (PwC UK)'
    },
    {
      id: 'res_uk_gilts_002',
      assetType: 'UK_GILTS_TREASURIES',
      custodian: 'Euroclear UK & International (CREST Nominees)',
      nominalValueGbp: 150_000_000,
      liquidValueGbp: 147_000_000,
      haircutPercent: 2.0,
      durationMonths: 12,
      verifiedAt: new Date().toISOString().split('T')[0],
      auditor: 'KPMG UK Financial Services Audit'
    },
    {
      id: 'res_vault_cash_003',
      assetType: 'PHYSICAL_VAULT_CASH',
      custodian: 'RhinoBank London City Vault Facility #4',
      nominalValueGbp: 50_000_000,
      liquidValueGbp: 50_000_000,
      haircutPercent: 0.0,
      durationMonths: 0,
      verifiedAt: new Date().toISOString().split('T')[0],
      auditor: 'Deloitte UK Banking Practice'
    }
  ];

  private policySettings: MonetaryPolicySettings = {
    baseInterestRatePercent: 4.75, // in line with Bank of England base rate
    stakingRewardAnnualRatePercent: 3.80,
    baseTransferFeeUnits: 50n, // 0.0050 LBDC
    merchantDiscountRatePercent: 0.25, // 25 bps vs 250 bps for Visa/Mastercard
    reserveRequirementPercent: 100.0, // 100% full backing requirement
    maxValidatorWeightCapPercent: 25.0,
    emergencyHalt: false,
    unauthorizedMintDetected: false
  };

  constructor(blockchain: Blockchain, ledger: MonetaryLedger) {
    this.blockchain = blockchain;
    this.ledger = ledger;
  }

  // Multi-signature authorized monetary minting (Requires M-of-N executive sign-off)
  public executeAuthorizedMint(params: {
    amountUnits: bigint;
    destinationAccountId: string;
    issuanceReason: string;
    signers: string[];
    statutoryOrderRef: string;
  }): { success: boolean; txId: string; newSupplyUnits: bigint } {
    if (params.signers.length < 3) {
      throw new Error(`Monetary Issuance Rejected: M-of-N threshold violation. Required at least 3 authorized signatory keys, provided: ${params.signers.length}`);
    }

    if (this.policySettings.emergencyHalt) {
      throw new Error('Monetary Issuance Rejected: Monetary policy circuit breaker is currently engaged in EMERGENCY HALT.');
    }

    // Verify Reserve Coverage constraint before minting
    const currentSupply = this.getSupplyState().totalSupplyUnits;
    const projectedSupply = currentSupply + params.amountUnits;
    const totalReservesGbpUnits = BigInt(Math.floor(this.getTotalReserveValueGbp() * 10000));

    if (projectedSupply > totalReservesGbpUnits) {
      throw new Error(`Monetary Issuance Rejected: 100% Reserve Backing Constraint Violated. Projected Supply (£${(Number(projectedSupply)/10000).toLocaleString()}) exceeds verified Liquid Reserves (£${(Number(totalReservesGbpUnits)/10000).toLocaleString()}).`);
    }

    const tx = this.blockchain.submitTransaction({
      type: 'Mint',
      senderId: '0xrhino_monetary_issuance_authority',
      recipientId: params.destinationAccountId,
      amountUnits: params.amountUnits,
      feeUnits: 0n,
      memo: `Statutory M0 Mint: ${params.issuanceReason} [Ref: ${params.statutoryOrderRef}]`
    });

    return {
      success: true,
      txId: tx.id,
      newSupplyUnits: projectedSupply
    };
  }

  // Authorized monetary burning / redemption
  public executeAuthorizedBurn(params: {
    amountUnits: bigint;
    sourceAccountId: string;
    redemptionReason: string;
    signers: string[];
  }): { success: boolean; txId: string } {
    if (params.signers.length < 2) {
      throw new Error(`Monetary Redemption Rejected: Multi-sig threshold violation.`);
    }

    const tx = this.blockchain.submitTransaction({
      type: 'Burn',
      senderId: params.sourceAccountId,
      recipientId: '0xrhino_burn_retirement_sink',
      amountUnits: params.amountUnits,
      feeUnits: 0n,
      memo: `Statutory Burn: ${params.redemptionReason}`
    });

    return {
      success: true,
      txId: tx.id
    };
  }

  public getTotalReserveValueGbp(): number {
    return this.reserveAssets.reduce((sum, item) => sum + item.liquidValueGbp, 0);
  }

  public getSupplyState(): MonetarySupplyState {
    const accounts = this.blockchain.getAccounts();
    let totalBalances = 0n;
    let treasuryBalance = 0n;
    let frozenBalance = 0n;
    let escrowBalance = 0n;
    let stakedBalance = 0n;

    for (const acc of accounts) {
      totalBalances += acc.balanceUnits;
      if (acc.type === 'TREASURY') {
        treasuryBalance += acc.balanceUnits;
      }
      frozenBalance += acc.frozenUnits;
      escrowBalance += acc.escrowUnits;
      stakedBalance += acc.stakedUnits;
    }

    const circulating = totalBalances > treasuryBalance ? totalBalances - treasuryBalance : 0n;
    const totalReserveGbp = this.getTotalReserveValueGbp();
    const totalSupplyGbp = Number(totalBalances) / 10000;
    const reserveCoverage = (totalReserveGbp / (totalSupplyGbp || 1)) * 100;

    return {
      m0LbdcUnits: totalBalances,
      circulatingUnits: circulating,
      treasuryUnits: treasuryBalance,
      frozenUnits: frozenBalance,
      escrowUnits: escrowBalance,
      stakedUnits: stakedBalance,
      burnedUnits: 15_400_000_0000n,
      mintedUnits: totalBalances + 15_400_000_0000n,
      totalSupplyUnits: totalBalances,
      pegMode: this.pegMode,
      pegRatioToGbp: this.pegRatioToGbp,
      reserveCoverageRatio: Number(reserveCoverage.toFixed(2)),
      liquidReserveRatio: 98.4,
      issuanceCapUnits: 1_000_000_000_0000n // £1 Billion statutory pilot cap
    };
  }

  public getReserveAssets(): ReserveAssetItem[] {
    return this.reserveAssets;
  }

  public getPolicySettings(): MonetaryPolicySettings {
    return this.policySettings;
  }

  public updatePolicySettings(newSettings: Partial<MonetaryPolicySettings>) {
    this.policySettings = { ...this.policySettings, ...newSettings };
  }

  public setPegMode(mode: CurrencyPegMode, ratio: number = 1.0000) {
    this.pegMode = mode;
    this.pegRatioToGbp = ratio;
  }

  // Calculate Irving Fisher MV = PY Money Velocity indicator
  public calculateMoneyVelocity(rollingPeriodDays: number = 30): {
    velocity: number;
    economicVolumeGbp: number;
    averageMonetaryStockGbp: number;
    annualisedVelocity: number;
    formula: string;
  } {
    const supply = Number(this.getSupplyState().circulatingUnits) / 10000;
    // Estimate 30-day economic payment turnover based on recent block transactions
    const blocks = this.blockchain.getBlocks();
    let txVolume = 0;
    for (const b of blocks) {
      for (const t of b.transactions) {
        if (t.type === 'Transfer' || t.type === 'Settlement') {
          txVolume += Number(t.amountUnits) / 10000;
        }
      }
    }
    // Scale volume for annualized representative velocity
    const estimatedDailyVolume = Math.max(txVolume * 80, 4_200_000);
    const rollingVolume = estimatedDailyVolume * rollingPeriodDays;
    const velocity = Number((rollingVolume / (supply || 1)).toFixed(2));
    const annualised = Number((velocity * (365 / rollingPeriodDays)).toFixed(2));

    return {
      velocity,
      economicVolumeGbp: rollingVolume,
      averageMonetaryStockGbp: supply,
      annualisedVelocity: annualised,
      formula: 'V = (P × Y) / M = Gross Economic Transaction Volume / Average Circulating Stock'
    };
  }
}
