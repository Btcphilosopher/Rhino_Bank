// ============================================================================
// RHINOBANK LBDC — DOUBLE-ENTRY MONETARY ACCOUNTING & RECONCILIATION ENGINE
// ============================================================================

import { ChartOfAccount, LedgerEntry } from '../types';

export class MonetaryLedger {
  private accounts: Map<string, ChartOfAccount> = new Map();
  private journal: LedgerEntry[] = [];
  private journalSequence: number = 1000;

  constructor() {
    this.initializeChartOfAccounts();
  }

  private initializeChartOfAccounts() {
    const initialChart: ChartOfAccount[] = [
      // 1000 - ASSETS
      {
        code: '1010',
        name: 'Bank of England Operational Reserves',
        category: 'ASSET',
        balanceUnits: 250_000_000_0000n, // £250M
        normalBalance: 'DEBIT',
        description: 'Segregated central bank central reserve account at Bank of England'
      },
      {
        code: '1020',
        name: 'UK Government Gilts & Securities',
        category: 'ASSET',
        balanceUnits: 150_000_000_0000n, // £150M
        normalBalance: 'DEBIT',
        description: 'High-quality liquid assets (HQLA) held in escrow custody'
      },
      {
        code: '1030',
        name: 'Vault Cash & High-Tier Bank Deposits',
        category: 'ASSET',
        balanceUnits: 50_000_000_0000n, // £50M
        normalBalance: 'DEBIT',
        description: 'Physical vault reserves and Tier 1 clearing balances'
      },
      {
        code: '1090',
        name: 'Interbank RTGS Settlement Receivables',
        category: 'ASSET',
        balanceUnits: 15_000_000_0000n,
        normalBalance: 'DEBIT',
        description: 'Intraday clearing receivables from interbank participants'
      },

      // 2000 - LIABILITIES
      {
        code: '2010',
        name: 'LBDC Tokens in Issue (M0 Liability)',
        category: 'LIABILITY',
        balanceUnits: 400_000_000_0000n, // £400M
        normalBalance: 'CREDIT',
        description: 'Total digital currency claims in circulating and treasury supply'
      },
      {
        code: '2020',
        name: 'Customer Deposit Liabilities',
        category: 'LIABILITY',
        balanceUnits: 240_000_000_0000n,
        normalBalance: 'CREDIT',
        description: 'Retail and business customer digital wallet balances'
      },
      {
        code: '2030',
        name: 'Merchant Settlement Escrow',
        category: 'LIABILITY',
        balanceUnits: 45_000_000_0000n,
        normalBalance: 'CREDIT',
        description: 'Pending merchant settlement obligations'
      },
      {
        code: '2040',
        name: 'Interbank RTGS Settlement Payables',
        category: 'LIABILITY',
        balanceUnits: 15_000_000_0000n,
        normalBalance: 'CREDIT',
        description: 'Intraday clearing payables to interbank participants'
      },

      // 3000 - EQUITY & STAKED COLLATERAL
      {
        code: '3010',
        name: 'Validator Staked Capital Pool',
        category: 'EQUITY',
        balanceUnits: 40_000_000_0000n,
        normalBalance: 'CREDIT',
        description: 'Proof-of-Stake validator locked collateral bonds'
      },
      {
        code: '3020',
        name: 'RhinoBank Capital Reserve & Capital Surplus',
        category: 'EQUITY',
        balanceUnits: 50_000_000_0000n,
        normalBalance: 'CREDIT',
        description: 'Excess equity backing beyond 100% reserve requirement'
      },

      // 4000 - REVENUE
      {
        code: '4010',
        name: 'Transaction & Settlement Fee Revenue',
        category: 'REVENUE',
        balanceUnits: 3_240_000_0000n,
        normalBalance: 'CREDIT',
        description: 'Network transaction gas and interbank routing fees'
      },

      // 5000 - EXPENSES
      {
        code: '5010',
        name: 'Validator Consensus Rewards Distributed',
        category: 'EXPENSE',
        balanceUnits: 1_820_000_0000n,
        normalBalance: 'DEBIT',
        description: 'Network security staking yield paid to active validators'
      }
    ];

    for (const acc of initialChart) {
      this.accounts.set(acc.code, acc);
    }
  }

  // Record a strict double-entry journal movement
  public recordDoubleEntry(
    txId: string,
    debitCode: string,
    creditCode: string,
    amountUnits: bigint,
    description: string
  ): LedgerEntry {
    if (amountUnits <= 0n) {
      throw new Error(`MonetaryLedger Error: Entry amount must be strictly positive (> 0), received ${amountUnits}`);
    }

    const debitAcc = this.accounts.get(debitCode);
    const creditAcc = this.accounts.get(creditCode);

    if (!debitAcc) throw new Error(`MonetaryLedger Error: Debit account ${debitCode} not found`);
    if (!creditAcc) throw new Error(`MonetaryLedger Error: Credit account ${creditCode} not found`);

    // Update balances according to normal balance rules
    if (debitAcc.normalBalance === 'DEBIT') {
      debitAcc.balanceUnits += amountUnits;
    } else {
      debitAcc.balanceUnits -= amountUnits;
    }

    if (creditAcc.normalBalance === 'CREDIT') {
      creditAcc.balanceUnits += amountUnits;
    } else {
      creditAcc.balanceUnits -= amountUnits;
    }

    const entry: LedgerEntry = {
      id: `JRN-${++this.journalSequence}`,
      journalNo: this.journalSequence,
      timestamp: Date.now(),
      transactionId: txId,
      debitAccountCode: debitAcc.code,
      debitAccountName: debitAcc.name,
      creditAccountCode: creditAcc.code,
      creditAccountName: creditAcc.name,
      amountUnits,
      amountFormatted: (Number(amountUnits) / 10000).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 4 }) + ' LBDC',
      asset: 'LBDC',
      description,
      verified: true
    };

    this.journal.unshift(entry);
    if (this.journal.length > 500) {
      this.journal.pop();
    }

    return entry;
  }

  public getChartOfAccounts(): ChartOfAccount[] {
    return Array.from(this.accounts.values());
  }

  public getJournal(): LedgerEntry[] {
    return this.journal;
  }

  // Calculate Trial Balance & verify fundamental accounting equality: Assets = Liabilities + Equity
  public calculateTrialBalance(): {
    totalDebitsUnits: bigint;
    totalCreditsUnits: bigint;
    isBalanced: boolean;
    totalAssetsUnits: bigint;
    totalLiabilitiesUnits: bigint;
    totalEquityUnits: bigint;
    netIncomeUnits: bigint;
  } {
    let totalDebits = 0n;
    let totalCredits = 0n;
    let totalAssets = 0n;
    let totalLiabilities = 0n;
    let totalEquity = 0n;
    let totalRevenue = 0n;
    let totalExpense = 0n;

    for (const acc of this.accounts.values()) {
      if (acc.category === 'ASSET') {
        totalAssets += acc.balanceUnits;
        totalDebits += acc.balanceUnits;
      } else if (acc.category === 'LIABILITY') {
        totalLiabilities += acc.balanceUnits;
        totalCredits += acc.balanceUnits;
      } else if (acc.category === 'EQUITY') {
        totalEquity += acc.balanceUnits;
        totalCredits += acc.balanceUnits;
      } else if (acc.category === 'REVENUE') {
        totalRevenue += acc.balanceUnits;
        totalCredits += acc.balanceUnits;
      } else if (acc.category === 'EXPENSE') {
        totalExpense += acc.balanceUnits;
        totalDebits += acc.balanceUnits;
      }
    }

    const netIncome = totalRevenue - totalExpense;

    return {
      totalDebitsUnits: totalDebits,
      totalCreditsUnits: totalCredits,
      isBalanced: totalDebits === totalCredits,
      totalAssetsUnits: totalAssets,
      totalLiabilitiesUnits: totalLiabilities,
      totalEquityUnits: totalEquity,
      netIncomeUnits: netIncome
    };
  }

  // Tri-party Reconciliation Engine
  public runTriPartyReconciliation(blockchainTotalSupplyUnits: bigint, reserveAssetsTotalGbpUnits: bigint): {
    reconciled: boolean;
    discrepancyUnits: bigint;
    blockchainSupplyUnits: bigint;
    ledgerLiabilitiesUnits: bigint;
    reserveCoverageUnits: bigint;
    reserveCoverageRatio: number;
    auditStatus: 'MATCHED' | 'DISCREPANCY_DETECTED';
    timestamp: number;
  } {
    const lbdcLiabilityAcc = this.accounts.get('2010');
    const ledgerLiabilities = lbdcLiabilityAcc ? lbdcLiabilityAcc.balanceUnits : 0n;

    const discrepancy = blockchainTotalSupplyUnits > ledgerLiabilities 
      ? blockchainTotalSupplyUnits - ledgerLiabilities 
      : ledgerLiabilities - blockchainTotalSupplyUnits;

    const coverageRatio = Number(reserveAssetsTotalGbpUnits) / (Number(blockchainTotalSupplyUnits) || 1) * 100;

    return {
      reconciled: discrepancy === 0n,
      discrepancyUnits: discrepancy,
      blockchainSupplyUnits: blockchainTotalSupplyUnits,
      ledgerLiabilitiesUnits: ledgerLiabilities,
      reserveCoverageUnits: reserveAssetsTotalGbpUnits,
      reserveCoverageRatio: Number(coverageRatio.toFixed(2)),
      auditStatus: discrepancy === 0n ? 'MATCHED' : 'DISCREPANCY_DETECTED',
      timestamp: Date.now()
    };
  }
}
