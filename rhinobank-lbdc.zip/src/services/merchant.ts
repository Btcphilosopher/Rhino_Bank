// ============================================================================
// RHINOBANK LBDC — MERCHANT INFRASTRUCTURE & DYNAMIC QR PAYMENTS ENGINE
// ============================================================================

import QRCode from 'qrcode';
import { MerchantProfile, MerchantInvoice } from '../types';
import { Blockchain } from './blockchain';
import { sha256 } from './crypto';

export class MerchantEngine {
  private blockchain: Blockchain;
  private merchants: Map<string, MerchantProfile> = new Map();
  private invoices: Map<string, MerchantInvoice> = new Map();

  constructor(blockchain: Blockchain) {
    this.blockchain = blockchain;
    this.initializeMerchants();
  }

  private initializeMerchants() {
    const list: MerchantProfile[] = [
      {
        id: 'merch_marks_spencer',
        businessName: 'Marks & Spencer Retail Central',
        category: 'Food, Apparel & Department Stores',
        settlementWalletId: '0xmarks_and_spencer_merch_010',
        apiKey: 'rhino_live_sec_ms_774910284',
        webhookUrl: 'https://api.marksandspencer.com/v1/payments/rhino-lbdc-webhook',
        settlementSchedule: 'REAL_TIME',
        dailyVolumeUnits: 124_500_0000n,
        activeInvoicesCount: 142,
        refundPolicy: 'Instant 100% on-chain refund to original customer wallet ID'
      },
      {
        id: 'merch_sainsburys',
        businessName: "Sainsbury's Supermarkets POS",
        category: 'Grocery & Supermarkets',
        settlementWalletId: '0xsainsburys_supermarket_merch_011',
        apiKey: 'rhino_live_sec_sainsbury_88201',
        webhookUrl: 'https://settlement.sainsburys.co.uk/hooks/lbdc-pos',
        settlementSchedule: 'REAL_TIME',
        dailyVolumeUnits: 98_200_0000n,
        activeInvoicesCount: 89,
        refundPolicy: 'Within 30 days via POS barcoded transaction receipt'
      },
      {
        id: 'merch_oxford_coffee',
        businessName: 'Oxford Artisan Coffee Roasters',
        category: 'Hospitality & Specialty Food',
        settlementWalletId: '0xoxford_coffee_roasters_015',
        apiKey: 'rhino_live_sec_oxford_coffee_331',
        webhookUrl: 'https://oxfordcoffee.example.com/api/lbdc/notify',
        settlementSchedule: 'END_OF_DAY_BATCH',
        dailyVolumeUnits: 3_890_0000n,
        activeInvoicesCount: 14,
        refundPolicy: 'Immediate bar-side re-credit'
      }
    ];

    for (const m of list) {
      this.merchants.set(m.id, m);
    }
  }

  public getMerchants(): MerchantProfile[] {
    return Array.from(this.merchants.values());
  }

  public getMerchant(id: string): MerchantProfile | undefined {
    return this.merchants.get(id);
  }

  public getInvoices(): MerchantInvoice[] {
    return Array.from(this.invoices.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  // Create a verifiable dynamic QR payment request with cryptographic payload
  public async createInvoice(params: {
    merchantId: string;
    amountUnits: bigint;
    description: string;
    expiryMinutes?: number;
  }): Promise<MerchantInvoice> {
    const merchant = this.merchants.get(params.merchantId);
    if (!merchant) throw new Error(`Merchant ${params.merchantId} not found`);

    const invoiceId = `INV-${Date.now().toString(16).toUpperCase()}-${Math.floor(Math.random() * 1000)}`;
    const expiresAt = Date.now() + (params.expiryMinutes || 15) * 60 * 1000;
    
    // Standard LBDC Dynamic QR cryptographic JSON payload
    const qrObj = {
      protocol: 'RHINO_LBDC_PAY_V1',
      invoiceId,
      merchantId: merchant.id,
      merchantName: merchant.businessName,
      recipientWallet: merchant.settlementWalletId,
      amountUnits: params.amountUnits.toString(),
      amountFormatted: (Number(params.amountUnits) / 10000).toFixed(2) + ' LBDC',
      currency: 'LBDC',
      fiatPeg: 'GBP',
      description: params.description,
      expiresAt,
      nonce: Math.random().toString(36).substring(2, 10),
      sig: sha256(`QR_PAY_${invoiceId}_${params.amountUnits}_${merchant.settlementWalletId}`)
    };

    const qrPayload = JSON.stringify(qrObj);
    let qrSvg = '';

    try {
      qrSvg = await QRCode.toString(qrPayload, {
        type: 'svg',
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#f8fafc'
        }
      });
    } catch {
      qrSvg = '';
    }

    const invoice: MerchantInvoice = {
      invoiceId,
      merchantId: merchant.id,
      merchantName: merchant.businessName,
      amountUnits: params.amountUnits,
      amountFormatted: (Number(params.amountUnits) / 10000).toFixed(2) + ' LBDC',
      fiatEquivalentGbp: '£' + (Number(params.amountUnits) / 10000).toFixed(2),
      description: params.description,
      recipientWalletId: merchant.settlementWalletId,
      qrPayload,
      qrSvg,
      expiresAt,
      status: 'PENDING',
      createdAt: Date.now()
    };

    this.invoices.set(invoiceId, invoice);
    merchant.activeInvoicesCount++;
    return invoice;
  }

  // Settle invoice via customer wallet
  public settleInvoice(invoiceId: string, payerWalletId: string): { invoice: MerchantInvoice; txId: string } {
    const invoice = this.invoices.get(invoiceId);
    if (!invoice) throw new Error(`Invoice ${invoiceId} does not exist`);
    if (invoice.status === 'PAID') throw new Error('Invoice is already paid');
    if (Date.now() > invoice.expiresAt) {
      invoice.status = 'EXPIRED';
      throw new Error('Invoice has expired');
    }

    const tx = this.blockchain.submitTransaction({
      type: 'Transfer',
      senderId: payerWalletId,
      recipientId: invoice.recipientWalletId,
      amountUnits: invoice.amountUnits,
      feeUnits: 50n,
      memo: `Merchant POS Checkout: ${invoice.invoiceId} (${invoice.description})`,
      settlementMode: 'INSTANT_RETAIL'
    });

    invoice.status = 'PAID';
    invoice.paidTxId = tx.id;

    const merchant = this.merchants.get(invoice.merchantId);
    if (merchant) {
      merchant.dailyVolumeUnits += invoice.amountUnits;
      merchant.activeInvoicesCount = Math.max(0, merchant.activeInvoicesCount - 1);
    }

    return { invoice, txId: tx.id };
  }
}
