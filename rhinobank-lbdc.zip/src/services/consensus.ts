// ============================================================================
// RHINOBANK LBDC — PROOF-OF-STAKE CONSENSUS & VALIDATOR ENGINE
// ============================================================================

import { ValidatorNode, Attestation, ValidatorStatus } from '../types';
import { sha256 } from './crypto';

export class ConsensusEngine {
  private validators: Map<string, ValidatorNode> = new Map();
  private currentEpoch: number = 142;
  private currentSlot: number = 4;
  private slotsPerEpoch: number = 32;
  private epochDurationMs: number = 6400; // 200ms per slot in demo
  private maxValidatorWeightCap: number = 25.0; // max 25% voting power per institution

  constructor() {
    this.initializeInstitutionalValidators();
    this.recalculateVotingPowers();
  }

  private initializeInstitutionalValidators() {
    const defaultValidators: ValidatorNode[] = [
      {
        id: 'val_rhinobank_01',
        name: 'RhinoBank Primary Core Node #1',
        operator: 'RhinoBank UK plc',
        jurisdiction: 'United Kingdom (FCA Regulated)',
        publicKey: '0xpk_rhino_core_alpha_9941a8',
        consensusKey: '0xck_rhino_bls12_381_8820c',
        ipAddress: '10.240.0.12 (Tier-4 Secured HSM)',
        stakeUnits: 12_000_000_0000n, // £12M
        delegatedUnits: 2_500_000_0000n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 99.99,
        performanceScore: 99.8,
        blocksProposed: 1240,
        blocksAttested: 48920,
        missedVotes: 1,
        rewardBalanceUnits: 184_200_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 14,
        peerCount: 38
      },
      {
        id: 'val_rhinobank_02',
        name: 'RhinoBank Failover HSM Node #2',
        operator: 'RhinoBank UK plc',
        jurisdiction: 'United Kingdom (Disaster Recovery)',
        publicKey: '0xpk_rhino_core_beta_419bc3',
        consensusKey: '0xck_rhino_bls12_381_4491f',
        ipAddress: '10.244.0.88 (Tier-4 DR HSM)',
        stakeUnits: 10_000_000_0000n, // £10M
        delegatedUnits: 1_200_000_0000n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 99.98,
        performanceScore: 99.6,
        blocksProposed: 1012,
        blocksAttested: 48890,
        missedVotes: 3,
        rewardBalanceUnits: 152_100_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 18,
        peerCount: 36
      },
      {
        id: 'val_barclays_gw',
        name: 'Barclays Interbank Settlement Node',
        operator: 'Barclays Clearing Services',
        jurisdiction: 'United Kingdom (PRA/BoE)',
        publicKey: '0xpk_barclays_rtgs_902ca8',
        consensusKey: '0xck_barclays_bls12_7719d',
        ipAddress: '194.72.10.45 (Canary Wharf Hub)',
        stakeUnits: 8_000_000_0000n, // £8M
        delegatedUnits: 800_000_0000n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 99.95,
        performanceScore: 98.9,
        blocksProposed: 814,
        blocksAttested: 48750,
        missedVotes: 8,
        rewardBalanceUnits: 120_450_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 22,
        peerCount: 35
      },
      {
        id: 'val_hsbc_node',
        name: 'HSBC Global Liquidity Gateway',
        operator: 'HSBC UK Institutional',
        jurisdiction: 'United Kingdom / EU',
        publicKey: '0xpk_hsbc_inst_clearing_128',
        consensusKey: '0xck_hsbc_bls12_5510e',
        ipAddress: '155.136.2.19 (8 Canada Square)',
        stakeUnits: 7_500_000_0000n, // £7.5M
        delegatedUnits: 500_000_0000n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 99.91,
        performanceScore: 98.2,
        blocksProposed: 762,
        blocksAttested: 48510,
        missedVotes: 14,
        rewardBalanceUnits: 114_000_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 28,
        peerCount: 34
      },
      {
        id: 'val_boe_observer',
        name: 'Bank of England Regulatory Observer',
        operator: 'Bank of England RTGS Oversight',
        jurisdiction: 'United Kingdom (Central Bank Authority)',
        publicKey: '0xpk_boe_supervisory_node_01',
        consensusKey: '0xck_boe_bls12_0001a',
        ipAddress: '195.12.88.3 (Threadneedle St)',
        stakeUnits: 5_000_000_0000n, // £5M
        delegatedUnits: 0n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 100.0,
        performanceScore: 100.0,
        blocksProposed: 512,
        blocksAttested: 49010,
        missedVotes: 0,
        rewardBalanceUnits: 76_000_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 12,
        peerCount: 42
      },
      {
        id: 'val_natwest_node',
        name: 'NatWest Commercial Clearing Hub',
        operator: 'NatWest Group Markets',
        jurisdiction: 'United Kingdom (FCA/PRA)',
        publicKey: '0xpk_natwest_market_val_88',
        consensusKey: '0xck_natwest_bls12_9941b',
        ipAddress: '193.111.4.11 (Edinburgh DC)',
        stakeUnits: 4_500_000_0000n, // £4.5M
        delegatedUnits: 200_000_0000n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 99.82,
        performanceScore: 97.4,
        blocksProposed: 430,
        blocksAttested: 48100,
        missedVotes: 22,
        rewardBalanceUnits: 65_200_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 31,
        peerCount: 32
      },
      {
        id: 'val_cambridge_fintech',
        name: 'Cambridge Centre for Alternative Finance',
        operator: 'Academic Research Consortium',
        jurisdiction: 'United Kingdom (Independent Academic)',
        publicKey: '0xpk_cambridge_ccaf_node_9',
        consensusKey: '0xck_ccaf_bls12_3310f',
        ipAddress: '131.111.8.44 (Cambridge Labs)',
        stakeUnits: 2_000_000_0000n, // £2M
        delegatedUnits: 150_000_0000n,
        votingPower: 0,
        rawPower: 0,
        status: 'Active',
        uptimePercent: 99.70,
        performanceScore: 96.5,
        blocksProposed: 205,
        blocksAttested: 47800,
        missedVotes: 35,
        rewardBalanceUnits: 30_100_0000n,
        penaltyBalanceUnits: 0n,
        slashEventsCount: 0,
        latencyMs: 35,
        peerCount: 29
      }
    ];

    for (const v of defaultValidators) {
      this.validators.set(v.id, v);
    }
  }

  // Voting Power = f(Stake) with Anti-Cartel and Cap Safeguards
  public recalculateVotingPowers() {
    let totalActiveStake = 0n;
    const activeValidators = Array.from(this.validators.values()).filter(v => v.status === 'Active');

    for (const v of activeValidators) {
      const effectiveStake = v.stakeUnits + v.delegatedUnits;
      totalActiveStake += effectiveStake;
    }

    if (totalActiveStake === 0n) return;

    // Calculate raw power & cap with max weight constraint
    for (const v of activeValidators) {
      const effectiveStake = v.stakeUnits + v.delegatedUnits;
      const rawPct = (Number(effectiveStake) / Number(totalActiveStake)) * 100;
      v.rawPower = Number(rawPct.toFixed(2));
      // Capped voting power prevents any single banking node from acquiring 51% or unilateral veto power
      v.votingPower = Number(Math.min(rawPct, this.maxValidatorWeightCap).toFixed(2));
    }
  }

  public getValidators(): ValidatorNode[] {
    return Array.from(this.validators.values());
  }

  public getValidator(id: string): ValidatorNode | undefined {
    return this.validators.get(id);
  }

  // Proposer selection: Stake-weighted pseudo-random VRF-style selection for next slot
  public selectProposerForSlot(height: number): ValidatorNode {
    const activeValidators = Array.from(this.validators.values()).filter(v => v.status === 'Active');
    if (activeValidators.length === 0) {
      throw new Error('Consensus Error: No active validators available in validator set');
    }

    // Weighted pseudo-random selection based on height hash
    const seedHash = sha256(`SLOT_PROPOSER_SEED_${height}_${this.currentEpoch}`);
    const seedInt = parseInt(seedHash.substring(2, 10), 16);
    
    let totalWeight = 0;
    for (const v of activeValidators) {
      totalWeight += v.votingPower;
    }

    let target = (seedInt % 10000) / 10000 * totalWeight;
    for (const v of activeValidators) {
      target -= v.votingPower;
      if (target <= 0) {
        return v;
      }
    }
    return activeValidators[0];
  }

  // Generate cryptographic attestations from active validators
  public generateAttestations(blockHash: string, height: number): Attestation[] {
    const activeValidators = Array.from(this.validators.values()).filter(v => v.status === 'Active');
    const attestations: Attestation[] = [];

    for (const v of activeValidators) {
      // Simulate 98% voting participation in normal network conditions
      if (Math.random() < 0.98) {
        const sig = sha256(`ATTESTATION_${v.consensusKey}_${blockHash}_${height}_${this.currentEpoch}`);
        attestations.push({
          validatorId: v.id,
          validatorName: v.name,
          slot: this.currentSlot,
          epoch: this.currentEpoch,
          blockHash,
          signature: sig,
          timestamp: Date.now()
        });
        v.blocksAttested++;
      } else {
        v.missedVotes++;
      }
    }

    return attestations;
  }

  // Slash validator for malicious equivocation or double-signing
  public slashValidator(validatorId: string, reason: string, penaltyUnits: bigint): ValidatorNode {
    const val = this.validators.get(validatorId);
    if (!val) throw new Error(`Validator ${validatorId} not found`);

    val.status = 'Slashed';
    val.stakeUnits = val.stakeUnits > penaltyUnits ? val.stakeUnits - penaltyUnits : 0n;
    val.penaltyBalanceUnits += penaltyUnits;
    val.slashEventsCount++;
    val.performanceScore = Math.max(0, val.performanceScore - 25);
    val.uptimePercent = Math.max(0, val.uptimePercent - 5);

    this.recalculateVotingPowers();
    return val;
  }

  // Jail validator for offline downtime
  public jailValidator(validatorId: string, durationEpochs: number = 5): ValidatorNode {
    const val = this.validators.get(validatorId);
    if (!val) throw new Error(`Validator ${validatorId} not found`);

    val.status = 'Jailed';
    val.jailReleaseEpoch = this.currentEpoch + durationEpochs;
    this.recalculateVotingPowers();
    return val;
  }

  // Unjail validator
  public unjailValidator(validatorId: string): ValidatorNode {
    const val = this.validators.get(validatorId);
    if (!val) throw new Error(`Validator ${validatorId} not found`);

    val.status = 'Active';
    delete val.jailReleaseEpoch;
    this.recalculateVotingPowers();
    return val;
  }

  // Register new institutional validator
  public registerValidator(params: {
    name: string;
    operator: string;
    jurisdiction: string;
    stakeUnits: bigint;
    ipAddress: string;
  }): ValidatorNode {
    const id = `val_${params.operator.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now().toString().slice(-4)}`;
    const keySeed = `${id}_${Date.now()}`;
    const pubKey = `0xpk_${sha256(keySeed).substring(2, 28)}`;
    const consKey = `0xck_${sha256(keySeed + '_cons').substring(2, 28)}`;

    const node: ValidatorNode = {
      id,
      name: params.name,
      operator: params.operator,
      jurisdiction: params.jurisdiction,
      publicKey: pubKey,
      consensusKey: consKey,
      ipAddress: params.ipAddress,
      stakeUnits: params.stakeUnits,
      delegatedUnits: 0n,
      votingPower: 0,
      rawPower: 0,
      status: 'Active',
      uptimePercent: 100.0,
      performanceScore: 100.0,
      blocksProposed: 0,
      blocksAttested: 0,
      missedVotes: 0,
      rewardBalanceUnits: 0n,
      penaltyBalanceUnits: 0n,
      slashEventsCount: 0,
      latencyMs: 20,
      peerCount: 28
    };

    this.validators.set(id, node);
    this.recalculateVotingPowers();
    return node;
  }

  public advanceSlot(): { slot: number; epoch: number; isNewEpoch: boolean } {
    this.currentSlot++;
    let isNewEpoch = false;
    if (this.currentSlot >= this.slotsPerEpoch) {
      this.currentSlot = 0;
      this.currentEpoch++;
      isNewEpoch = true;
      this.distributeEpochStakingRewards();
    }
    return { slot: this.currentSlot, epoch: this.currentEpoch, isNewEpoch };
  }

  // Epoch staking reward distribution based on participation and uptime
  private distributeEpochStakingRewards() {
    const rewardPerEpoch = 500_0000n; // 500 LBDC total distributed across active set
    const activeValidators = Array.from(this.validators.values()).filter(v => v.status === 'Active');
    
    for (const v of activeValidators) {
      const share = BigInt(Math.floor(v.votingPower * 100));
      const valReward = (rewardPerEpoch * share) / 10000n;
      v.rewardBalanceUnits += valReward;
    }
  }

  // Calculate Decentralisation metrics (HHI Index, Nakamoto Threshold)
  public calculateDecentralisationMetrics(): {
    nakamotoCoefficient: number;
    stakeHhiIndex: number;
    top1StakePercent: number;
    top3StakePercent: number;
    top5StakePercent: number;
    totalStakedUnits: bigint;
  } {
    const activeVals = Array.from(this.validators.values())
      .filter(v => v.status === 'Active')
      .sort((a, b) => b.votingPower - a.votingPower);

    let totalStaked = 0n;
    for (const v of activeVals) {
      totalStaked += v.stakeUnits + v.delegatedUnits;
    }

    // HHI = sum(s_i^2) where s_i is percentage
    let hhi = 0;
    for (const v of activeVals) {
      hhi += Math.pow(v.votingPower, 2);
    }

    // Nakamoto coefficient: minimum number of validators needed to control > 33.34% or > 50%
    let cumulativePower = 0;
    let nakamoto = 0;
    for (const v of activeVals) {
      cumulativePower += v.votingPower;
      nakamoto++;
      if (cumulativePower >= 33.34) break;
    }

    const top1 = activeVals[0]?.votingPower || 0;
    const top3 = activeVals.slice(0, 3).reduce((acc, v) => acc + v.votingPower, 0);
    const top5 = activeVals.slice(0, 5).reduce((acc, v) => acc + v.votingPower, 0);

    return {
      nakamotoCoefficient: nakamoto,
      stakeHhiIndex: Math.round(hhi),
      top1StakePercent: Number(top1.toFixed(2)),
      top3StakePercent: Number(top3.toFixed(2)),
      top5StakePercent: Number(top5.toFixed(2)),
      totalStakedUnits: totalStaked
    };
  }
}
