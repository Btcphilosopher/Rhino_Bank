// ============================================================================
// RHINOBANK LBDC — RTGS & MULTILATERAL NETTING SETTLEMENT ENGINE
// ============================================================================

import { InterbankParticipant, SettlementBatch, SettlementMode } from '../types';
import { Blockchain } from './blockchain';
import { MonetaryLedger } from './ledger';

export class SettlementEngine {
  private blockchain: Blockchain;
  private ledger: MonetaryLedger;
  private participants: Map<string, InterbankParticipant> = new Map();
  private settlementBatches: SettlementBatch[] = [];
  private batchSequence: number = 240;

  constructor(blockchain: Blockchain, ledger: MonetaryLedger) {
    this.blockchain = blockchain;
    this.ledger = ledger;
    this.initializeInterbankParticipants();
    this.seedHistoricalBatches();
  }

  private initializeInterbankParticipants() {
    const list: InterbankParticipant[] = [
      {
        id: 'bank_rhino',
        bankName: 'RhinoBank UK plc (Host Operating Hub)',
        sortCode: '60-83-71',
        settlementWalletId: '0xrhino_treasury_master_001',
        reserveAccountId: '1010',
        availableLiquidityUnits: 150_000_000_0000n,
        intradayCreditLimitUnits: 50_000_000_0000n,
        grossPayableUnits: 14_200_000_0000n,
        grossReceivableUnits: 18_900_000_0000n,
        netObligationUnits: 4_700_000_0000n, // Net receiver +£4.7M
        status: 'ONLINE'
      },
      {
        id: 'bank_barclays',
        bankName: 'Barclays Bank UK PLC',
        sortCode: '20-00-00',
        settlementWalletId: '0xbarclays_settlement_hub_002',
        reserveAccountId: '1090',
        availableLiquidityUnits: 45_000_000_0000n,
        intradayCreditLimitUnits: 30_000_000_0000n,
        grossPayableUnits: 12_500_000_0000n,
        grossReceivableUnits: 10_200_000_0000n,
        netObligationUnits: -2_300_000_0000n, // Net payer -£2.3M
        status: 'ONLINE'
      },
      {
        id: 'bank_hsbc',
        bankName: 'HSBC UK Bank plc',
        sortCode: '40-05-15',
        settlementWalletId: '0xhsbc_settlement_hub_003',
        reserveAccountId: '1090',
        availableLiquidityUnits: 40_000_000_0000n,
        intradayCreditLimitUnits: 25_000_000_0000n,
        grossPayableUnits: 9_800_000_0000n,
        grossReceivableUnits: 11_400_000_0000n,
        netObligationUnits: 1_600_000_0000n, // Net receiver +£1.6M
        status: 'ONLINE'
      },
      {
        id: 'bank_natwest',
        bankName: 'NatWest Group plc',
        sortCode: '50-00-00',
        settlementWalletId: '0xnatwest_settlement_004',
        reserveAccountId: '1090',
        availableLiquidityUnits: 35_000_000_0000n,
        intradayCreditLimitUnits: 20_000_000_0000n,
        grossPayableUnits: 8_900_000_0000n,
        grossReceivableUnits: 6_200_000_0000n,
        netObligationUnits: -2_700_000_0000n, // Net payer -£2.7M
        status: 'ONLINE'
      },
      {
        id: 'bank_lloyds',
        bankName: 'Lloyds Banking Group plc',
        sortCode: '30-90-89',
        settlementWalletId: '0xlloyds_settlement_005',
        reserveAccountId: '1090',
        availableLiquidityUnits: 38_000_000_0000n,
        intradayCreditLimitUnits: 25_000_000_0000n,
        grossPayableUnits: 7_100_000_0000n,
        grossReceivableUnits: 5_800_000_0000n,
        netObligationUnits: -1_300_000_0000n, // Net payer -£1.3M
        status: 'ONLINE'
      }
    ];

    for (const p of list) {
      this.participants.set(p.id, p);
    }
  }

  private seedHistoricalBatches() {
    this.settlementBatches = [
      {
        batchId: 'SETTLE-BATCH-238',
        timestamp: Date.now() - 1000 * 60 * 45,
        cycleNumber: 238,
        mode: 'MULTILATERAL_NETTING',
        grossTotalUnits: 68_500_000_0000n,
        netSettledUnits: 14_200_000_0000n,
        liquiditySavedUnits: 54_300_000_0000n,
        efficiencyPercent: 79.27,
        transactionsIncluded: 1420,
        status: 'SETTLED'
      },
      {
        batchId: 'SETTLE-BATCH-239',
        timestamp: Date.now() - 1000 * 60 * 15,
        cycleNumber: 239,
        mode: 'MULTILATERAL_NETTING',
        grossTotalUnits: 74_200_000_0000n,
        netSettledUnits: 16_100_000_0000n,
        liquiditySavedUnits: 58_100_000_0000n,
        efficiencyPercent: 78.30,
        transactionsIncluded: 1650,
        status: 'SETTLED'
      }
    ];
  }

  public getParticipants(): InterbankParticipant[] {
    return Array.from(this.participants.values());
  }

  public getBatches(): SettlementBatch[] {
    return this.settlementBatches;
  }

  // Execute High-Value RTGS Immediate Individual Settlement
  public executeRtgsSettlement(params: {
    senderBankId: string;
    recipientBankId: string;
    amountUnits: bigint;
    reference: string;
  }): { txId: string; settledTimestamp: number } {
    const sender = this.participants.get(params.senderBankId);
    const recipient = this.participants.get(params.recipientBankId);

    if (!sender || !recipient) throw new Error('Invalid interbank participant ID');

    if (sender.availableLiquidityUnits < params.amountUnits) {
      throw new Error(`RTGS Settlement Failed: Insufficient interbank clearing liquidity at ${sender.bankName}.`);
    }

    sender.availableLiquidityUnits -= params.amountUnits;
    recipient.availableLiquidityUnits += params.amountUnits;

    // Submit transaction on blockchain
    const tx = this.blockchain.submitTransaction({
      type: 'Settlement',
      senderId: sender.settlementWalletId,
      recipientId: recipient.settlementWalletId,
      amountUnits: params.amountUnits,
      feeUnits: 250n,
      memo: `RTGS Wholesale Settlement: ${params.reference}`,
      settlementMode: 'RTGS_GROSS'
    });

    return {
      txId: tx.id,
      settledTimestamp: Date.now()
    };
  }

  // Execute Multilateral Netting Window Calculation & Settlement
  public executeMultilateralNettingBatch(): SettlementBatch {
    let grossTotal = 0n;
    let netSettled = 0n;

    for (const p of this.participants.values()) {
      grossTotal += p.grossPayableUnits + p.grossReceivableUnits;
      if (p.netObligationUnits < 0n) {
        // Payer
        const absVal = -p.netObligationUnits;
        netSettled += absVal;
        p.availableLiquidityUnits -= absVal;
      } else {
        // Receiver
        p.availableLiquidityUnits += p.netObligationUnits;
      }

      // Reset queues for next intraday window
      p.grossPayableUnits = BigInt(Math.floor(Math.random() * 5_000_000_0000));
      p.grossReceivableUnits = BigInt(Math.floor(Math.random() * 5_000_000_0000));
      p.netObligationUnits = p.grossReceivableUnits - p.grossPayableUnits;
    }

    const liquiditySaved = grossTotal > netSettled ? grossTotal - netSettled : 0n;
    const efficiency = Number((Number(liquiditySaved) / (Number(grossTotal) || 1) * 100).toFixed(2));

    const batch: SettlementBatch = {
      batchId: `SETTLE-BATCH-${++this.batchSequence}`,
      timestamp: Date.now(),
      cycleNumber: this.batchSequence,
      mode: 'MULTILATERAL_NETTING',
      grossTotalUnits: grossTotal,
      netSettledUnits: netSettled,
      liquiditySavedUnits: liquiditySaved,
      efficiencyPercent: efficiency,
      transactionsIncluded: 1200 + Math.floor(Math.random() * 500),
      status: 'SETTLED'
    };

    this.settlementBatches.unshift(batch);
    if (this.settlementBatches.length > 50) this.settlementBatches.pop();

    return batch;
  }
}
