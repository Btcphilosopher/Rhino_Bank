import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Scale, 
  FileCheck,
  AlertTriangle,
  Play
} from 'lucide-react';

interface InvariantsProps {
  invariants: any[];
  onRunAll: () => Promise<void>;
}

export const InvariantsView: React.FC<InvariantsProps> = ({
  invariants,
  onRunAll
}) => {
  const [isRunning, setIsRunning] = useState(false);

  const handleRun = async () => {
    setIsRunning(true);
    try {
      await onRunAll();
    } catch (err: any) {
      alert('Error running invariant verification: ' + err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const allPassed = invariants.every(inv => inv.passed);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Formal Invariant & Mathematical Property Verification Suite
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated model checking verifying that economic laws, accounting invariants, and blockchain consensus constraints are strictly preserved across state transitions.
          </p>
        </div>

        <button
          onClick={handleRun}
          disabled={isRunning}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
        >
          <Play className="w-4 h-4" />
          {isRunning ? 'Verifying Invariants...' : 'Run Full Invariant Audit'}
        </button>
      </div>

      {/* Global Status Banner */}
      <div className={`p-4 rounded-lg border font-mono text-xs flex items-center justify-between ${
        allPassed ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-300' : 'bg-rose-950/40 border-rose-800 text-rose-300'
      }`}>
        <div className="flex items-center gap-2">
          {allPassed ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <XCircle className="w-5 h-5 text-rose-400" />}
          <span className="font-bold text-sm">
            {allPassed ? 'ALL FINANCIAL & SYSTEM INVARIANTS SATISFIED (6/6)' : 'INVARIANT BREACH DETECTED'}
          </span>
        </div>

        <span className="text-[11px] text-slate-400">
          Last Checked: {new Date().toLocaleTimeString()}
        </span>
      </div>

      {/* Invariants Grid / Cards */}
      <div className="space-y-3 font-mono text-xs">
        {invariants.map((inv, idx) => (
          <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold">[{idx + 1}]</span>
                <span className="font-bold text-slate-200 text-sm font-sans">{inv.name}</span>
              </div>
              <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                inv.passed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}>
                {inv.passed ? '✓ VERIFIED TRUE' : '✗ FAILED'}
              </span>
            </div>

            <div className="text-slate-400 font-sans text-xs">
              {inv.description}
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800/80 text-slate-300 text-[11px] space-y-1">
              <div><strong className="text-slate-500">MATHEMATICAL FORMULA:</strong> <span className="text-sky-300">{inv.formula}</span></div>
              <div><strong className="text-slate-500">VERIFICATION DETAILS:</strong> {inv.details}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
