import React, { useState } from 'react';
import { 
  FileCode, 
  Copy, 
  Check, 
  Terminal, 
  Layers, 
  Cpu, 
  BookOpen, 
  ShieldCheck,
  Folder
} from 'lucide-react';

interface RustWorkspaceProps {
  files: any[];
}

export const RustWorkspaceView: React.FC<RustWorkspaceProps> = ({ files }) => {
  const [selectedPath, setSelectedPath] = useState(files[0]?.path || 'Cargo.toml');
  const [copied, setCopied] = useState(false);

  const currentFile = files.find(f => f.path === selectedPath) || files[0];

  const handleCopy = () => {
    if (!currentFile) return;
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-purple-400" />
            Institutional Rust Workspace Architecture
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Production-grade Rust crate layout (<span className="font-mono text-purple-300">rhinobank_core</span>, <span className="font-mono text-purple-300">rhinobank_consensus</span>, <span className="font-mono text-purple-300">rhinobank_ledger</span>) ready for high-performance node deployment.
          </p>
        </div>
      </div>

      {/* 2-Column: File Tree & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left: Crate & File Explorer */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
            <Folder className="w-4 h-4 text-purple-400" />
            Workspace Crates
          </h2>

          <div className="space-y-1 text-xs font-mono">
            {files.map((file) => (
              <button
                key={file.path}
                onClick={() => setSelectedPath(file.path)}
                className={`w-full text-left p-2 rounded transition-colors cursor-pointer flex items-center gap-2 ${
                  selectedPath === file.path
                    ? 'bg-purple-950/80 text-purple-300 font-bold border border-purple-800/80'
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{file.path}</span>
              </button>
            ))}
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <div className="text-slate-200 font-bold font-sans">Rust Node Features:</div>
            <div>• Zero-cost memory safety</div>
            <div>• Async Tokio Actor model</div>
            <div>• RocksDB / sled persistence</div>
            <div>• Ed25519 & BLS12-381 cryptography</div>
          </div>
        </div>

        {/* Right 3 Cols: Code Display */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex flex-col">
          <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
              <FileCode className="w-4 h-4 text-purple-400" />
              <span>{currentFile?.path}</span>
              <span className="text-slate-500">({currentFile?.description})</span>
            </div>

            <button
              onClick={handleCopy}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Rust Code</span>
                </>
              )}
            </button>
          </div>

          <div className="p-4 bg-slate-950 overflow-x-auto flex-1 max-h-[620px]">
            <pre className="font-mono text-xs text-slate-300 leading-relaxed">
              <code>{currentFile?.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
