import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Eye, 
  Lock, 
  CheckCircle, 
  AlertTriangle, 
  Key, 
  Sparkles,
  FileCheck2,
  Search,
  Fingerprint
} from 'lucide-react';

interface ComplianceProps {
  assessments: any[];
  onGenerateZkProof: (claimType: string, secretValue: string) => Promise<any>;
}

export const ComplianceView: React.FC<ComplianceProps> = ({
  assessments,
  onGenerateZkProof
}) => {
  const [zkClaimType, setZkClaimType] = useState('IS_UK_TAX_RESIDENT');
  const [zkSecret, setZkSecret] = useState('NI_NUMBER_AB123456C_OXFORD');
  const [generatedProof, setGeneratedProof] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handleGenerateProof = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    try {
      const res = await onGenerateZkProof(zkClaimType, zkSecret);
      if (res && res.proof) {
        setGeneratedProof(res.proof);
      }
    } catch (err: any) {
      alert('ZK Proof error: ' + err.message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-purple-400" />
            Compliance, AML & Zero-Knowledge Verification
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Decoupled regulatory layer with real-time risk scoring, FATF Travel Rule packaging, structuring detection, and ZK privacy proofs.
          </p>
        </div>
      </div>

      {/* 2-Column: Real-time AML Monitoring & ZK Vault */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Real-Time Transaction AML Risk Stream */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              Automated AML Risk Scoring Feed
            </h2>
            <span className="text-xs font-mono text-slate-400">
              Risk Range: 0 (Safe) - 100 (Critical)
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs max-h-[520px] overflow-y-auto pr-1">
            {assessments.map((a) => (
              <div 
                key={a.assessmentId} 
                className={`p-3 rounded-lg border space-y-2 ${
                  a.riskScore >= 70 ? 'bg-rose-950/40 border-rose-800/80' :
                  a.riskScore >= 40 ? 'bg-amber-950/30 border-amber-800/60' :
                  'bg-slate-950 border-slate-800/80'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300">TX: {a.txId.substring(0, 16)}...</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    a.riskScore >= 70 ? 'bg-rose-900 text-rose-200' :
                    a.riskScore >= 40 ? 'bg-amber-900 text-amber-200' :
                    'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  }`}>
                    SCORE: {a.riskScore}/100 • {a.decision}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 font-sans">
                  Amount: <strong className="text-slate-200 font-mono">£{formatUnits(a.amountUnits)}</strong>
                </div>

                {a.flags && a.flags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {a.flags.map((f: string, i: number) => (
                      <span key={i} className="px-1.5 py-0.5 rounded text-[9px] bg-slate-800 text-amber-300 border border-amber-800/40">
                        {f}
                      </span>
                    ))}
                  </div>
                )}

                <div className="text-[10px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-800/50">
                  <span>Travel Rule: {a.travelRuleRequired ? 'PACKAGED' : 'EXEMPT'}</span>
                  <span>{new Date(a.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Zero-Knowledge Selective Disclosure Vault */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-purple-400" />
              Zero-Knowledge (ZK) Selective Disclosure Vault
            </h2>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Generate verifiable cryptographic proofs of compliance (e.g. proof of UK tax residency, KYC verification, &gt;18 age verification) without revealing the underlying private data on-chain.
          </p>

          <form onSubmit={handleGenerateProof} className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Compliance Claim Type</label>
              <select
                value={zkClaimType}
                onChange={(e) => setZkClaimType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
              >
                <option value="IS_UK_TAX_RESIDENT">Proof of UK Tax Residency</option>
                <option value="IS_OVER_18">Proof of Majority Age (&ge; 18)</option>
                <option value="IS_ACCREDITED_INVESTOR">Proof of Accredited Institutional Status</option>
                <option value="BALANCE_EXCEEDS_THRESHOLD">Proof of Solvency (&gt; £100,000)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Confidential Secret Payload (Client-Side Only)</label>
              <input
                type="text"
                value={zkSecret}
                onChange={(e) => setZkSecret(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                required
              />
            </div>

            <div className="flex items-center justify-end pt-1">
              <button
                type="submit"
                disabled={isGenerating}
                className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-slate-950 font-bold transition-colors cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                {isGenerating ? 'Synthesizing ZK Proof...' : 'Generate ZK-SNARK Proof'}
              </button>
            </div>
          </form>

          {/* Generated ZK Proof Inspector */}
          {generatedProof && (
            <div className="p-4 bg-slate-950 rounded-lg border border-purple-800/60 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between text-purple-400 font-bold">
                <span>PROOF VERIFIED & VALID</span>
                <span className="text-[10px] bg-purple-950 px-2 py-0.5 rounded border border-purple-800 text-purple-300">
                  {generatedProof.protocol}
                </span>
              </div>

              <div>
                <div className="text-slate-500 text-[10px]">CLAIM HASH:</div>
                <div className="text-slate-300 truncate">{generatedProof.claimHash}</div>
              </div>

              <div>
                <div className="text-slate-500 text-[10px]">PUBLIC WITNESS COMMITMENT (A, B, C):</div>
                <div className="text-slate-400 truncate text-[11px] bg-slate-900 p-2 rounded mt-1">
                  {generatedProof.proofA} • {generatedProof.proofB}
                </div>
              </div>

              <div className="text-[11px] text-emerald-400 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                Valid on-chain proof. Zero personal private data leaked.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
