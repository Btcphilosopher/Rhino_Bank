import React, { useState } from 'react';
import { 
  Coins, 
  ShieldCheck, 
  Flame, 
  PlusCircle, 
  FileCheck, 
  Key, 
  Building2, 
  Sliders,
  Scale,
  CheckCircle2
} from 'lucide-react';

interface MonetaryProps {
  supply: any;
  reserves: any[];
  policy: any;
  accounts: any[];
  onMint: (params: any) => Promise<void>;
  onBurn: (params: any) => Promise<void>;
  onUpdatePolicy: (params: any) => Promise<void>;
}

export const MonetaryView: React.FC<MonetaryProps> = ({
  supply,
  reserves,
  policy,
  accounts,
  onMint,
  onBurn,
  onUpdatePolicy
}) => {
  const [showMintModal, setShowMintModal] = useState(false);
  const [showBurnModal, setShowBurnModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Mint form
  const [mintAmount, setMintAmount] = useState('10000000');
  const [mintDest, setMintDest] = useState(accounts[0]?.id || '0xrhino_treasury_master_001');
  const [mintReason, setMintReason] = useState('Central Bank Reserve Deposit Matching Tranche #84');
  const [mintRef, setMintRef] = useState('BOE-LBDC-ORD-2026-991');

  // Burn form
  const [burnAmount, setBurnAmount] = useState('5000000');
  const [burnSource, setBurnSource] = useState(accounts[0]?.id || '0xrhino_treasury_master_001');
  const [burnReason, setBurnReason] = useState('Commercial Bank Interbank Redemption Sink');

  // Policy settings form
  const [baseRate, setBaseRate] = useState(policy?.baseInterestRatePercent || 4.75);
  const [stakingRate, setStakingRate] = useState(policy?.stakingRewardAnnualRatePercent || 3.80);
  const [merchantRate, setMerchantRate] = useState(policy?.merchantDiscountRatePercent || 0.25);

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handleMintSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    try {
      await onMint({
        amount: mintAmount,
        destinationAccountId: mintDest,
        issuanceReason: mintReason,
        statutoryOrderRef: mintRef
      });
      setShowMintModal(false);
      alert('Statutory M0 Monetary Issuance executed successfully with 3-of-5 Multi-Sig verification.');
    } catch (err: any) {
      alert('Minting Error: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBurnSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    try {
      await onBurn({
        amount: burnAmount,
        sourceAccountId: burnSource,
        redemptionReason: burnReason
      });
      setShowBurnModal(false);
      alert('Monetary Redemption & Burn completed.');
    } catch (err: any) {
      alert('Burn Error: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePolicySave = async () => {
    try {
      await onUpdatePolicy({
        baseInterestRatePercent: Number(baseRate),
        stakingRewardAnnualRatePercent: Number(stakingRate),
        merchantDiscountRatePercent: Number(merchantRate)
      });
      alert('Monetary policy parameters updated across network.');
    } catch (err: any) {
      alert('Policy error: ' + err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Coins className="w-5 h-5 text-emerald-400" />
            Monetary Authority & Issuance Core
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Strict M-of-N multi-signature statutory issuance, 100% full liquid reserve backing, and central bank monetary policy controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowMintModal(true)}
            className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            Statutory Mint (M-of-N)
          </button>
          <button
            onClick={() => setShowBurnModal(true)}
            className="px-3.5 py-2 rounded-lg bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Flame className="w-4 h-4" />
            Redeem & Burn
          </button>
        </div>
      </div>

      {/* Money Supply Breakdown Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400 mb-1">TOTAL M0 SUPPLY</div>
          <div className="text-2xl font-bold text-slate-100">
            £{formatUnits(supply?.totalSupplyUnits)}
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">100% Reserve Solvency</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400 mb-1">CIRCULATING M1</div>
          <div className="text-2xl font-bold text-sky-400">
            £{formatUnits(supply?.circulatingUnits)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Active retail & commercial</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400 mb-1">TREASURY BUFFER</div>
          <div className="text-2xl font-bold text-amber-400">
            £{formatUnits(supply?.treasuryUnits)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">RhinoBank unallocated stock</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-slate-400 mb-1">STAKED COLLATERAL</div>
          <div className="text-2xl font-bold text-purple-400">
            £{formatUnits(supply?.stakedUnits)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Locked in validator bonds</div>
        </div>
      </div>

      {/* Reserve Backing Assets Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Segregated Statutory Reserve Assets (100% Backing Portfolio)
            </h2>
          </div>
          <span className="text-xs font-mono text-emerald-300 font-bold bg-emerald-950 px-2.5 py-1 rounded border border-emerald-800">
            COVERAGE RATIO: {supply?.reserveCoverageRatio || 108.4}%
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                <th className="p-3">ASSET CATEGORY</th>
                <th className="p-3">CUSTODIAN & LOCATION</th>
                <th className="p-3">NOMINAL VALUE</th>
                <th className="p-3">LIQUID VALUE</th>
                <th className="p-3">HAIRCUT</th>
                <th className="p-3">AUDIT FIRM</th>
                <th className="p-3 text-right">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {reserves.map((r) => (
                <tr key={r.id} className="hover:bg-slate-800/30">
                  <td className="p-3 font-sans font-bold text-slate-200">
                    {r.assetType.replace(/_/g, ' ')}
                  </td>
                  <td className="p-3 text-slate-300">{r.custodian}</td>
                  <td className="p-3 text-slate-100 font-bold">
                    £{(r.nominalValueGbp / 1_000_000).toFixed(1)}M
                  </td>
                  <td className="p-3 text-emerald-400 font-bold">
                    £{(r.liquidValueGbp / 1_000_000).toFixed(1)}M
                  </td>
                  <td className="p-3 text-slate-400">{r.haircutPercent}%</td>
                  <td className="p-3 text-slate-300 font-sans">{r.auditor}</td>
                  <td className="p-3 text-right">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      VERIFIED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monetary Policy & Rate Adjustments */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Monetary Policy Parameters & Rate Targets
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div className="space-y-1">
              <label className="text-slate-400 block">BASE CENTRAL RATE (%)</label>
              <input
                type="number"
                step="0.05"
                value={baseRate}
                onChange={(e) => setBaseRate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
              />
              <span className="text-[10px] text-slate-400">Pegged to BoE Base Rate</span>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 block">STAKING YIELD (%)</label>
              <input
                type="number"
                step="0.05"
                value={stakingRate}
                onChange={(e) => setStakingRate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
              />
              <span className="text-[10px] text-slate-400">Annualized validator reward</span>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 block">MERCHANT DISCOUNT (%)</label>
              <input
                type="number"
                step="0.05"
                value={merchantRate}
                onChange={(e) => setMerchantRate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
              />
              <span className="text-[10px] text-slate-400">25 bps vs 250 bps card rails</span>
            </div>
          </div>

          <div className="flex items-center justify-end pt-2">
            <button
              onClick={handlePolicySave}
              className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
            >
              Update Policy Parameters
            </button>
          </div>
        </div>

        {/* Currency Peg & Conversion Mode */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3 text-xs">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-sky-400" />
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Currency Peg & Legal Mandate
            </h2>
          </div>

          <div className="p-3 rounded bg-slate-950 border border-slate-800 font-mono">
            <div className="text-slate-400 text-[11px]">ACTIVE PEG RATIO:</div>
            <div className="text-base font-bold text-emerald-400 mt-1">1.0000 LBDC = £1.0000 GBP</div>
            <div className="text-[10px] text-slate-400 mt-1">Fixed 1:1 Sterling Parity</div>
          </div>

          <p className="text-slate-400 leading-relaxed">
            The LBDC monetary unit represents a direct, 100% reserve-backed digital liability of RhinoBank UK plc, redeemable on demand into standard central bank fiat.
          </p>
        </div>
      </div>

      {/* Mint Modal */}
      {showMintModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-800/80 rounded-xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-emerald-400" />
                Statutory M-of-N Monetary Issuance
              </h3>
              <button onClick={() => setShowMintModal(false)} className="text-slate-400 hover:text-slate-200">✕</button>
            </div>

            <div className="p-3 bg-emerald-950/40 rounded border border-emerald-800/50 text-xs text-emerald-300">
              ✓ Multi-Sig Required: Minimum 3 of 5 authorized executive keys (Treasury, CRO, BoE Supervisor).
            </div>

            <form onSubmit={handleMintSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Issuance Amount (£ LBDC)</label>
                <input
                  type="number"
                  value={mintAmount}
                  onChange={(e) => setMintAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Destination Custody Account</label>
                <select
                  value={mintDest}
                  onChange={(e) => setMintDest(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>{a.label} ({a.id.substring(0, 18)}...)</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Statutory Issuance Justification</label>
                <input
                  type="text"
                  value={mintReason}
                  onChange={(e) => setMintReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Statutory Order Reference</label>
                <input
                  type="text"
                  value={mintRef}
                  onChange={(e) => setMintRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowMintModal(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 font-bold text-slate-950 disabled:opacity-50"
                >
                  {isProcessing ? 'Verifying 3-of-5 Signatures...' : 'Execute Statutory Mint'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Burn Modal */}
      {showBurnModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-800/80 rounded-xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <Flame className="w-5 h-5 text-rose-400" />
                Monetary Redemption & Token Retirement Sink
              </h3>
              <button onClick={() => setShowBurnModal(false)} className="text-slate-400 hover:text-slate-200">✕</button>
            </div>

            <form onSubmit={handleBurnSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Redemption Amount (£ LBDC)</label>
                <input
                  type="number"
                  value={burnAmount}
                  onChange={(e) => setBurnAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Source Account</label>
                <select
                  value={burnSource}
                  onChange={(e) => setBurnSource(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>{a.label} ({a.id.substring(0, 18)}...)</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Redemption & Retirement Justification</label>
                <input
                  type="text"
                  value={burnReason}
                  onChange={(e) => setBurnReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBurnModal(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-4 py-1.5 rounded bg-rose-600 hover:bg-rose-500 font-bold text-white disabled:opacity-50"
                >
                  {isProcessing ? 'Burning...' : 'Confirm Burn & Fiat Release'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
