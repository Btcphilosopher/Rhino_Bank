import React, { useState } from 'react';
import { 
  BookOpen, 
  Scale, 
  CheckCircle, 
  AlertTriangle, 
  Search, 
  FileSpreadsheet,
  ArrowRight
} from 'lucide-react';

interface LedgerProps {
  chart: any[];
  journal: any[];
  trialBalance: any;
  reconciliation: any;
}

export const LedgerView: React.FC<LedgerProps> = ({
  chart,
  journal,
  trialBalance,
  reconciliation
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'JOURNAL' | 'CHART' | 'TRIAL_BALANCE' | 'RECONCILIATION'>('JOURNAL');
  const [searchTerm, setSearchTerm] = useState('');

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const filteredJournal = journal.filter(entry => 
    entry.transactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.debitAccountName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.creditAccountName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            Double-Entry Monetary General Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Every on-chain transfer produces exact double-entry accounting records (<span className="font-mono text-emerald-300">&Sigma; Debits == &Sigma; Credits</span>).
          </p>
        </div>

        {/* Sub-nav */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs font-semibold">
          <button
            onClick={() => setActiveSubTab('JOURNAL')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${activeSubTab === 'JOURNAL' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            General Journal ({journal.length})
          </button>
          <button
            onClick={() => setActiveSubTab('CHART')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${activeSubTab === 'CHART' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Chart of Accounts
          </button>
          <button
            onClick={() => setActiveSubTab('TRIAL_BALANCE')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${activeSubTab === 'TRIAL_BALANCE' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Trial Balance
          </button>
          <button
            onClick={() => setActiveSubTab('RECONCILIATION')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${activeSubTab === 'RECONCILIATION' ? 'bg-emerald-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Tri-Party Audit
          </button>
        </div>
      </div>

      {/* Trial Balance Invariant Strip */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-xs">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-emerald-400" />
          <div>
            <span className="text-slate-400">LEDGER INVARIANT:</span>
            <span className="ml-2 font-bold text-slate-200">
              Total Debits (£{formatUnits(trialBalance?.totalDebitsUnits)}) == Total Credits (£{formatUnits(trialBalance?.totalCreditsUnits)})
            </span>
          </div>
        </div>

        <span className={`px-2.5 py-1 rounded text-[11px] font-bold ${trialBalance?.isBalanced ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300'}`}>
          {trialBalance?.isBalanced ? '✓ PERFECT ACCOUNTING BALANCE' : 'UNBALANCED WARNING'}
        </span>
      </div>

      {/* SUB-VIEW 1: GENERAL JOURNAL */}
      {activeSubTab === 'JOURNAL' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden space-y-3 p-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Continuous General Ledger Journal Stream
            </h2>
            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search tx, accounts, notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                  <th className="p-2.5">JOURNAL #</th>
                  <th className="p-2.5">TX ID & TIME</th>
                  <th className="p-2.5">DEBIT ACCOUNT (DR)</th>
                  <th className="p-2.5">CREDIT ACCOUNT (CR)</th>
                  <th className="p-2.5">AMOUNT</th>
                  <th className="p-2.5">DESCRIPTION</th>
                  <th className="p-2.5 text-right">AUDIT</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredJournal.slice(0, 20).map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-800/30">
                    <td className="p-2.5 text-emerald-400 font-bold">{entry.id}</td>
                    <td className="p-2.5">
                      <div className="text-slate-300">{entry.transactionId.substring(0, 16)}...</div>
                      <div className="text-[10px] text-slate-500">{new Date(entry.timestamp).toLocaleTimeString()}</div>
                    </td>
                    <td className="p-2.5">
                      <div className="text-sky-400 font-bold">[{entry.debitAccountCode}] {entry.debitAccountName}</div>
                    </td>
                    <td className="p-2.5">
                      <div className="text-amber-400 font-bold">[{entry.creditAccountCode}] {entry.creditAccountName}</div>
                    </td>
                    <td className="p-2.5 font-bold text-slate-100">
                      £{formatUnits(entry.amountUnits)}
                    </td>
                    <td className="p-2.5 text-slate-300 font-sans max-w-xs truncate">
                      {entry.description}
                    </td>
                    <td className="p-2.5 text-right">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        VERIFIED
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: CHART OF ACCOUNTS */}
      {activeSubTab === 'CHART' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
          <div className="p-4 border-b border-slate-800">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Official Chart of Accounts (GAAP / IFRS Aligned)
            </h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                  <th className="p-3">CODE</th>
                  <th className="p-3">ACCOUNT NAME</th>
                  <th className="p-3">CATEGORY</th>
                  <th className="p-3">NORMAL BALANCE</th>
                  <th className="p-3">CURRENT BALANCE</th>
                  <th className="p-3">DESCRIPTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {chart.map((acc) => (
                  <tr key={acc.code} className="hover:bg-slate-800/30">
                    <td className="p-3 text-sky-400 font-bold">{acc.code}</td>
                    <td className="p-3 text-slate-200 font-sans font-semibold">{acc.name}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                        {acc.category}
                      </span>
                    </td>
                    <td className="p-3 text-slate-400">{acc.normalBalance}</td>
                    <td className="p-3 text-slate-100 font-bold">
                      £{formatUnits(acc.balanceUnits)}
                    </td>
                    <td className="p-3 text-slate-400 font-sans">{acc.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: TRIAL BALANCE */}
      {activeSubTab === 'TRIAL_BALANCE' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono text-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              Trial Balance Statement
            </h2>

            <div className="space-y-2 border-t border-slate-800 pt-3">
              <div className="flex justify-between py-1 text-slate-300">
                <span>Total Assets (1000 Series)</span>
                <span className="font-bold text-slate-100">£{formatUnits(trialBalance?.totalAssetsUnits)}</span>
              </div>
              <div className="flex justify-between py-1 text-slate-300">
                <span>Total Liabilities (2000 Series)</span>
                <span className="font-bold text-slate-100">£{formatUnits(trialBalance?.totalLiabilitiesUnits)}</span>
              </div>
              <div className="flex justify-between py-1 text-slate-300">
                <span>Total Equity & Capital (3000 Series)</span>
                <span className="font-bold text-slate-100">£{formatUnits(trialBalance?.totalEquityUnits)}</span>
              </div>
              <div className="flex justify-between py-2 text-emerald-400 border-t border-slate-800 font-bold text-sm">
                <span>Total Debits Sum</span>
                <span>£{formatUnits(trialBalance?.totalDebitsUnits)}</span>
              </div>
              <div className="flex justify-between py-1 text-emerald-400 font-bold text-sm">
                <span>Total Credits Sum</span>
                <span>£{formatUnits(trialBalance?.totalCreditsUnits)}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-xs space-y-3">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Accounting Correctness Rules
            </h2>
            <p className="text-slate-400 leading-relaxed">
              In RhinoBank LBDC, the blockchain does not replace accounting correctness. Instead, every blockchain block is a continuous sub-ledger that synchronously books to the RhinoBank Double-Entry General Ledger.
            </p>
            <div className="p-3 bg-slate-950 rounded border border-slate-800 text-slate-300 font-mono space-y-1">
              <div>✓ Assets = Liabilities + Equity</div>
              <div>✓ No unbacked monetary creation</div>
              <div>✓ Continuous multi-party reconciliation</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: TRI-PARTY AUDIT */}
      {activeSubTab === 'RECONCILIATION' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
              Tri-Party Continuous Audit & Reconciliation Engine
            </h2>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              STATUS: {reconciliation?.auditStatus}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div className="p-4 bg-slate-950 rounded border border-slate-800">
              <div className="text-slate-400 mb-1">A. BLOCKCHAIN TOTAL SUPPLY</div>
              <div className="text-lg font-bold text-sky-400">£{formatUnits(reconciliation?.blockchainSupplyUnits)}</div>
              <div className="text-[11px] text-slate-400 mt-1">Derived from state Merkle root</div>
            </div>

            <div className="p-4 bg-slate-950 rounded border border-slate-800">
              <div className="text-slate-400 mb-1">B. GENERAL LEDGER LIABILITY (2010)</div>
              <div className="text-lg font-bold text-amber-400">£{formatUnits(reconciliation?.ledgerLiabilitiesUnits)}</div>
              <div className="text-[11px] text-slate-400 mt-1">GAAP double-entry liability claim</div>
            </div>

            <div className="p-4 bg-slate-950 rounded border border-slate-800">
              <div className="text-slate-400 mb-1">C. CUSTODIED RESERVES (HQLA)</div>
              <div className="text-lg font-bold text-emerald-400">£{formatUnits(reconciliation?.reserveCoverageUnits)}</div>
              <div className="text-[11px] text-slate-400 mt-1">Bank of England + UK Gilts backing</div>
            </div>
          </div>

          <div className="p-3 bg-emerald-950/40 rounded border border-emerald-800/50 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>Exact parity confirmed between Blockchain tokens in issue and double-entry general ledger liabilities. Reserve coverage ratio stands at <strong>{reconciliation?.reserveCoverageRatio}%</strong>.</span>
          </div>
        </div>
      )}
    </div>
  );
};
