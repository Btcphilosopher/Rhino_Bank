import React, { useState } from 'react';
import { 
  Wallet, 
  Send, 
  Lock, 
  Unlock, 
  ShieldAlert, 
  UserCheck, 
  Clock, 
  ArrowUpRight,
  CreditCard,
  Building
} from 'lucide-react';

interface WalletsProps {
  accounts: any[];
  onTransfer: (params: any) => Promise<void>;
  onFreezeAccount: (id: string, frozen: boolean) => Promise<void>;
}

export const WalletsView: React.FC<WalletsProps> = ({
  accounts,
  onTransfer,
  onFreezeAccount
}) => {
  const [selectedWallet, setSelectedWallet] = useState(accounts[0]?.id || '');
  const [recipientWallet, setRecipientWallet] = useState(accounts[1]?.id || '');
  const [transferAmount, setTransferAmount] = useState('250.00');
  const [memo, setMemo] = useState('Consulting & Services Retainer');
  const [isSmartEscrow, setIsSmartEscrow] = useState(false);
  const [escrowDays, setEscrowDays] = useState(7);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedWallet === recipientWallet) {
      alert('Sender and recipient wallet cannot be identical.');
      return;
    }
    setIsSubmitting(true);
    try {
      await onTransfer({
        senderId: selectedWallet,
        recipientId: recipientWallet,
        amount: transferAmount,
        memo: isSmartEscrow ? `[ESCROW ${escrowDays}D] ${memo}` : memo,
        settlementMode: 'INSTANT_RETAIL'
      });
      alert('Transfer submitted and confirmed on-chain with deterministic finality.');
    } catch (err: any) {
      alert('Transfer Failed: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentAcc = accounts.find(a => a.id === selectedWallet) || accounts[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-emerald-400" />
            Digital Wallet Architecture & Programmable Money
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Support for Personal, Commercial, Merchant, Bank and Treasury wallets with segregated sub-balances and programmable time-locks.
          </p>
        </div>
      </div>

      {/* Main Grid: Wallet Selector & Transfer Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 1 Col: Wallet Directory */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
            Registered Network Wallets ({accounts.length})
          </h2>

          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {accounts.map((acc) => (
              <div
                key={acc.id}
                onClick={() => setSelectedWallet(acc.id)}
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                  selectedWallet === acc.id 
                    ? 'bg-slate-800/90 border-emerald-500/50 shadow-sm' 
                    : 'bg-slate-950/70 border-slate-800/80 hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center justify-between font-sans">
                  <span className="font-bold text-slate-200 truncate">{acc.label}</span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-slate-800 text-slate-300">
                    {acc.type}
                  </span>
                </div>

                <div className="font-mono text-emerald-400 font-bold mt-1 text-sm">
                  £{formatUnits(acc.balanceUnits)} <span className="text-[10px] text-slate-400">LBDC</span>
                </div>

                <div className="text-[10px] text-slate-500 font-mono mt-1 flex items-center justify-between">
                  <span className="truncate max-w-[140px]">{acc.id}</span>
                  {acc.isFrozen ? (
                    <span className="text-rose-400 font-bold flex items-center gap-0.5">
                      <Lock className="w-3 h-3" /> FROZEN
                    </span>
                  ) : (
                    <span className="text-emerald-400">AVAILABLE</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 2 Cols: Selected Wallet Details & Instant Transfer Terminal */}
        <div className="lg:col-span-2 space-y-4">
          {/* Selected Wallet Card */}
          {currentAcc && (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-100">{currentAcc.label}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {currentAcc.kycLevel}
                    </span>
                  </div>
                  <div className="text-xs font-mono text-slate-400 mt-0.5">
                    Address: {currentAcc.id}
                  </div>
                </div>

                <button
                  onClick={() => onFreezeAccount(currentAcc.id, !currentAcc.isFrozen)}
                  className={`px-3 py-1.5 rounded text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    currentAcc.isFrozen 
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 hover:bg-emerald-900' 
                      : 'bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900'
                  }`}
                >
                  {currentAcc.isFrozen ? (
                    <>
                      <Unlock className="w-3.5 h-3.5" /> Unfreeze Account
                    </>
                  ) : (
                    <>
                      <Lock className="w-3.5 h-3.5" /> Emergency Freeze
                    </>
                  )}
                </button>
              </div>

              {/* Sub-Balances Breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">AVAILABLE BALANCE</div>
                  <div className="text-base font-bold text-emerald-400">£{formatUnits(currentAcc.availableUnits)}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">ESCROW LOCKED</div>
                  <div className="text-base font-bold text-sky-400">£{formatUnits(currentAcc.escrowUnits)}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">STAKED BOND</div>
                  <div className="text-base font-bold text-purple-400">£{formatUnits(currentAcc.stakedUnits)}</div>
                </div>
                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">FROZEN / SANCTIONED</div>
                  <div className="text-base font-bold text-rose-400">£{formatUnits(currentAcc.frozenUnits)}</div>
                </div>
              </div>
            </div>
          )}

          {/* Transfer & Smart Payment Terminal */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
              <Send className="w-4 h-4 text-emerald-400" />
              Direct Transfer & Programmable Payment Layer
            </h2>

            <form onSubmit={handleSend} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">Debtor Wallet (Source)</label>
                  <select
                    value={selectedWallet}
                    onChange={(e) => setSelectedWallet(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                  >
                    {accounts.map(a => (
                      <option key={a.id} value={a.id}>{a.label} (£{formatUnits(a.availableUnits)})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Creditor Wallet (Recipient)</label>
                  <select
                    value={recipientWallet}
                    onChange={(e) => setRecipientWallet(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                  >
                    {accounts.map(a => (
                      <option key={a.id} value={a.id}>{a.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">Payment Amount (£ LBDC)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Payment Purpose / Description</label>
                  <input
                    type="text"
                    value={memo}
                    onChange={(e) => setMemo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                    required
                  />
                </div>
              </div>

              {/* Programmable Smart Escrow Option */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="smartEscrow"
                    checked={isSmartEscrow}
                    onChange={(e) => setIsSmartEscrow(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0"
                  />
                  <label htmlFor="smartEscrow" className="font-semibold text-slate-200 cursor-pointer">
                    Enable Programmable Smart Escrow / Conditional Time-Lock
                  </label>
                </div>

                {isSmartEscrow && (
                  <div className="flex items-center gap-3 pt-1 text-slate-400 font-mono">
                    <span>Release Lock Duration:</span>
                    <input
                      type="number"
                      value={escrowDays}
                      onChange={(e) => setEscrowDays(Number(e.target.value))}
                      className="w-20 bg-slate-900 border border-slate-800 rounded p-1 text-slate-100"
                    />
                    <span>Days (Automated on-chain release)</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-1 font-mono text-slate-400">
                <span>Fee: <strong className="text-slate-200">0.0050 LBDC</strong></span>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Signing & Transmitting...' : 'Sign & Transmit LBDC Transfer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
