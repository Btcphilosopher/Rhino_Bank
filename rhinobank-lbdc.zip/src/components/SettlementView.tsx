import React, { useState } from 'react';
import { 
  Repeat, 
  Building2, 
  ArrowRightLeft, 
  Zap, 
  Layers, 
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';

interface SettlementProps {
  participants: any[];
  batches: any[];
  onExecuteRtgs: (params: any) => Promise<void>;
  onExecuteNetting: () => Promise<void>;
}

export const SettlementView: React.FC<SettlementProps> = ({
  participants,
  batches,
  onExecuteRtgs,
  onExecuteNetting
}) => {
  const [senderBank, setSenderBank] = useState(participants[0]?.id || 'bank_rhino');
  const [recipientBank, setRecipientBank] = useState(participants[1]?.id || 'bank_barclays');
  const [amount, setAmount] = useState('5000000');
  const [reference, setReference] = useState('Interbank Overnight Liquidity Rebalancing');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handleRtgsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (senderBank === recipientBank) {
      alert('Sender and recipient bank must be distinct.');
      return;
    }
    setIsSubmitting(true);
    try {
      await onExecuteRtgs({
        senderBankId: senderBank,
        recipientBankId: recipientBank,
        amount,
        reference
      });
      alert('RTGS Immediate Gross Settlement finalized on-chain.');
    } catch (err: any) {
      alert('RTGS error: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNettingCycle = async () => {
    setIsSubmitting(true);
    try {
      await onExecuteNetting();
      alert('Multilateral Netting Settlement Cycle completed. Intraday clearing queues settled.');
    } catch (err: any) {
      alert('Netting error: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Repeat className="w-5 h-5 text-sky-400" />
            RTGS & Multilateral Netting Settlement Hub
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Interbank clearing infrastructure supporting atomic high-value Real-Time Gross Settlement (&gt; £100k) and liquidity-optimized net clearing batches.
          </p>
        </div>

        <button
          onClick={handleNettingCycle}
          disabled={isSubmitting}
          className="px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5 shadow-sm self-start cursor-pointer disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4" />
          Trigger Netting Batch Cycle
        </button>
      </div>

      {/* Interbank Participants Liquidity Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
            <Building2 className="w-4 h-4 text-sky-400" />
            Regulated Interbank Participants & Intraday Liquidity Positions
          </h2>
          <span className="text-xs font-mono text-slate-400">
            5 Regulated Clearing Members
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                <th className="p-3">INSTITUTION</th>
                <th className="p-3">SORT CODE</th>
                <th className="p-3">AVAILABLE LIQUIDITY</th>
                <th className="p-3">GROSS PAYABLE</th>
                <th className="p-3">GROSS RECEIVABLE</th>
                <th className="p-3">NET OBLIGATION</th>
                <th className="p-3 text-right">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {participants.map((p) => {
                const netVal = Number(p.netObligationUnits || 0) / 10000;
                return (
                  <tr key={p.id} className="hover:bg-slate-800/30">
                    <td className="p-3 font-sans font-bold text-slate-200">
                      {p.bankName}
                    </td>
                    <td className="p-3 text-slate-400">{p.sortCode}</td>
                    <td className="p-3 font-bold text-slate-100">
                      £{formatUnits(p.availableLiquidityUnits)}
                    </td>
                    <td className="p-3 text-rose-300">
                      £{formatUnits(p.grossPayableUnits)}
                    </td>
                    <td className="p-3 text-emerald-300">
                      £{formatUnits(p.grossReceivableUnits)}
                    </td>
                    <td className="p-3 font-bold">
                      <span className={netVal >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {netVal >= 0 ? '+' : ''}£{formatUnits(p.netObligationUnits)}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {p.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2-Column: RTGS Instant Transfer & Netting History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: RTGS Transfer Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            Execute High-Value RTGS Immediate Gross Transfer
          </h2>

          <form onSubmit={handleRtgsSubmit} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Debtor Bank (Sender)</label>
                <select
                  value={senderBank}
                  onChange={(e) => setSenderBank(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                >
                  {participants.map(p => (
                    <option key={p.id} value={p.id}>{p.bankName}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Creditor Bank (Beneficiary)</label>
                <select
                  value={recipientBank}
                  onChange={(e) => setRecipientBank(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                >
                  {participants.map(p => (
                    <option key={p.id} value={p.id}>{p.bankName}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Transfer Amount (£ LBDC)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono font-bold"
                required
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Settlement Reference / ISO 20022 Tag</label>
              <input
                type="text"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                required
              />
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-400">
              ⚡ RTGS mode executes on-chain with deterministic finality (&lt; 400ms) and updates double-entry interbank settlement accounts immediately.
            </div>

            <div className="flex items-center justify-end pt-1">
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? 'Settling...' : 'Submit RTGS Gross Order'}
              </button>
            </div>
          </form>
        </div>

        {/* Right: Netting Batches */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            Scheduled Multilateral Netting Batch Records
          </h2>

          <div className="space-y-3 font-mono text-xs">
            {batches.map((b) => (
              <div key={b.batchId} className="p-3 rounded bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sky-300">{b.batchId}</span>
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                    {b.efficiencyPercent}% LIQUIDITY SAVINGS
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-[11px] text-slate-300">
                  <div>
                    <div className="text-slate-500">GROSS VOLUME</div>
                    <div className="font-bold">£{formatUnits(b.grossTotalUnits)}</div>
                  </div>
                  <div>
                    <div className="text-slate-500">NET SETTLED</div>
                    <div className="font-bold text-amber-300">£{formatUnits(b.netSettledUnits)}</div>
                  </div>
                  <div>
                    <div className="text-slate-500">LIQUIDITY SAVED</div>
                    <div className="font-bold text-emerald-400">£{formatUnits(b.liquiditySavedUnits)}</div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-1">
                  Settled {b.transactionsIncluded} commercial obligations at {new Date(b.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
