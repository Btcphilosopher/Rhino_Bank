import React, { useState } from 'react';
import { 
  Layers, 
  Search, 
  Hash, 
  Cpu, 
  Clock, 
  CheckCircle, 
  ArrowRight,
  ShieldCheck,
  FileCode
} from 'lucide-react';

interface ExplorerProps {
  blocks: any[];
}

export const ExplorerView: React.FC<ExplorerProps> = ({ blocks }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBlock, setSelectedBlock] = useState<any>(null);

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const filteredBlocks = blocks.filter(b => 
    b.height.toString().includes(searchTerm) ||
    b.hash.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (b.proposerName && b.proposerName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Layers className="w-5 h-5 text-sky-400" />
            Blockchain State & Cryptographic Explorer
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time inspection of finalized blocks, cryptographic Merkle state roots, and transaction signatures.
          </p>
        </div>

        <div className="relative w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Search block height, hash, proposer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200"
          />
        </div>
      </div>

      {/* Block Stream Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                <th className="p-3">BLOCK HEIGHT</th>
                <th className="p-3">BLOCK HASH</th>
                <th className="p-3">EPOCH / SLOT</th>
                <th className="p-3">PROPOSER</th>
                <th className="p-3">TX COUNT</th>
                <th className="p-3">STATE MERKLE ROOT</th>
                <th className="p-3 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredBlocks.map((b) => (
                <tr key={b.height} className="hover:bg-slate-800/30">
                  <td className="p-3 font-bold text-sky-400">#{b.height}</td>
                  <td className="p-3 text-slate-300">
                    <span className="truncate max-w-[120px] inline-block">{b.hash.substring(0, 14)}...</span>
                  </td>
                  <td className="p-3 text-slate-400">{b.epoch} / {b.slot}</td>
                  <td className="p-3 font-sans font-bold text-slate-200">
                    {b.proposerName || b.proposer}
                  </td>
                  <td className="p-3 text-amber-300 font-bold">
                    {b.transactionsCount || b.transactions?.length || 0}
                  </td>
                  <td className="p-3 text-slate-400">
                    <span className="truncate max-w-[120px] inline-block">{b.stateRoot?.substring(0, 14)}...</span>
                  </td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => setSelectedBlock(b)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold border border-slate-700 cursor-pointer"
                    >
                      Inspect Block
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Block Details Inspector Modal */}
      {selectedBlock && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 max-w-2xl w-full shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-sky-400" />
                  Block #{selectedBlock.height} Cryptographic Payload
                </h3>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Timestamp: {new Date(selectedBlock.timestamp).toLocaleString()}
                </div>
              </div>
              <button onClick={() => setSelectedBlock(null)} className="text-slate-400 hover:text-slate-200">✕</button>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div>
                  <span className="text-slate-500">BLOCK HASH:</span>
                  <div className="text-slate-200 font-bold break-all mt-0.5">{selectedBlock.hash}</div>
                </div>
                <div>
                  <span className="text-slate-500">PREVIOUS BLOCK HASH:</span>
                  <div className="text-slate-400 break-all mt-0.5">{selectedBlock.previousHash}</div>
                </div>
                <div>
                  <span className="text-slate-500">STATE MERKLE ROOT:</span>
                  <div className="text-emerald-400 break-all mt-0.5">{selectedBlock.stateRoot}</div>
                </div>
                <div>
                  <span className="text-slate-500">TRANSACTIONS MERKLE ROOT:</span>
                  <div className="text-sky-400 break-all mt-0.5">{selectedBlock.transactionsRoot}</div>
                </div>
              </div>

              {/* Transactions in Block */}
              <div>
                <h4 className="font-sans font-bold text-slate-200 text-xs mb-2">
                  Transactions ({selectedBlock.transactions?.length || 0})
                </h4>

                <div className="space-y-2">
                  {selectedBlock.transactions?.map((tx: any, idx: number) => (
                    <div key={idx} className="p-2.5 bg-slate-950 rounded border border-slate-800 text-[11px] space-y-1">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="font-bold text-sky-300">{tx.id?.substring(0, 16)}...</span>
                        <span className="text-emerald-400 font-bold">£{formatUnits(tx.amountUnits)} LBDC</span>
                      </div>
                      <div className="text-slate-400 flex items-center justify-between">
                        <span>From: {tx.senderId?.substring(0, 14)}...</span>
                        <span>To: {tx.recipientId?.substring(0, 14)}...</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-sans">{tx.memo}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setSelectedBlock(null)}
                className="px-4 py-1.5 rounded bg-slate-800 text-slate-200 text-xs"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
