import React from 'react';
import { 
  Shield, 
  Coins, 
  Layers, 
  Scale, 
  Repeat, 
  CheckCircle2, 
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  Cpu,
  Zap,
  Building,
  Key
} from 'lucide-react';

interface OverviewProps {
  status: any;
  blocks: any[];
  validators: any[];
  onNavigateTab: (tabId: string) => void;
  onRunSurge: () => void;
}

export const OverviewView: React.FC<OverviewProps> = ({
  status,
  blocks,
  validators,
  onNavigateTab,
  onRunSurge
}) => {
  const supply = status?.supply;
  const dec = status?.decentralisation;
  const vel = status?.velocity;
  const recon = status?.reconciliation;
  const latestBlock = blocks[0];

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Sovereign Monetary Security Summary */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-emerald-950 text-emerald-300 border border-emerald-800/40">
                UK SOVEREIGN LBDC FRAMEWORK
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Chain ID: rhinobank-lbdc-uk-main-01
              </span>
            </div>
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">
              RhinoBank Institutional Local Bank Digital Currency Core
            </h1>
            <p className="text-sm text-slate-400 mt-1 max-w-3xl">
              Regulated monetary infrastructure uniting high-integrity double-entry accounting, Proof-of-Stake consensus, RTGS wholesale settlement, 100% liquid reserves backing, and deterministic BFT finality.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => onNavigateTab('monetary')}
              className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Coins className="w-4 h-4" />
              Monetary Authority
            </button>
            <button
              onClick={() => onNavigateTab('settlement')}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Repeat className="w-4 h-4" />
              RTGS Settlement
            </button>
            <button
              onClick={onRunSurge}
              className="px-3.5 py-2 rounded-lg bg-amber-950 hover:bg-amber-900 text-amber-300 font-semibold text-xs border border-amber-700/50 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-4 h-4" />
              Trigger Load Surge
            </button>
          </div>
        </div>
      </div>

      {/* Institutional Key Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total M0 Supply */}
        <div className="bg-slate-900 border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono">TOTAL M0 SUPPLY</span>
            <Coins className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100">
            £{formatUnits(supply?.totalSupplyUnits)} <span className="text-xs font-normal text-slate-400">LBDC</span>
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center justify-between border-t border-slate-800/60 pt-2">
            <span>Circulating: £{formatUnits(supply?.circulatingUnits)}</span>
            <span className="text-emerald-400 font-medium">1 LBDC = £1.00</span>
          </div>
        </div>

        {/* Metric 2: Reserve Asset Backing */}
        <div className="bg-slate-900 border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono">RESERVE COVERAGE</span>
            <Shield className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 flex items-baseline gap-2">
            <span>{supply?.reserveCoverageRatio || 108.4}%</span>
            <span className="text-xs text-emerald-400 font-sans font-semibold">100% Solvency</span>
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center justify-between border-t border-slate-800/60 pt-2">
            <span>Liquid HQLA: £450.00M</span>
            <span className="text-sky-300">PwC Verified</span>
          </div>
        </div>

        {/* Metric 3: Consensus & Nakamoto Coefficient */}
        <div className="bg-slate-900 border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono">VALIDATOR NAKAMOTO</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 flex items-baseline gap-2">
            <span>{dec?.nakamotoCoefficient || 3}</span>
            <span className="text-xs text-slate-400 font-sans">Nodes to 33.4% BFT</span>
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center justify-between border-t border-slate-800/60 pt-2">
            <span>Active Set: {status?.activeValidators || 7} Nodes</span>
            <span className="text-purple-300">Capped at 25%</span>
          </div>
        </div>

        {/* Metric 4: Money Velocity & Economic Turnover */}
        <div className="bg-slate-900 border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono">MONEY VELOCITY (V)</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 flex items-baseline gap-2">
            <span>{vel?.annualisedVelocity || 6.84}x</span>
            <span className="text-xs text-amber-300 font-sans">Annualised</span>
          </div>
          <div className="mt-2 text-xs text-slate-400 flex items-center justify-between border-t border-slate-800/60 pt-2">
            <span>MV = PY Analytical Core</span>
            <span className="text-slate-300">£126M / 30d</span>
          </div>
        </div>
      </div>

      {/* Middle Section: Live System Topology & Multi-Bank Network */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Architectural Pipeline & Ledger Reconciliation */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
                <Scale className="w-4 h-4 text-emerald-400" />
                Tri-Party Monetary & Ledger Reconciliation Engine
              </h2>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${recon?.reconciled ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300'}`}>
                {recon?.reconciled ? '✓ EXACT PENNY PARITY MATCHED' : 'DISCREPANCY DETECTED'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">1. BLOCKCHAIN STATE ROOT</div>
                <div className="text-slate-200 font-bold">£{formatUnits(recon?.blockchainSupplyUnits || supply?.totalSupplyUnits)}</div>
                <div className="text-[10px] text-slate-400 mt-1 truncate">
                  Root: {latestBlock?.stateRoot?.substring(0, 16)}...
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">2. GENERAL LEDGER (2010)</div>
                <div className="text-slate-200 font-bold">£{formatUnits(recon?.ledgerLiabilitiesUnits || supply?.totalSupplyUnits)}</div>
                <div className="text-[10px] text-emerald-400 mt-1">
                  Double-Entry Invariant OK
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[11px] mb-1">3. RESERVES LEDGER (HQLA)</div>
                <div className="text-slate-200 font-bold">£{formatUnits(recon?.reserveCoverageUnits || '4500000000000')}</div>
                <div className="text-[10px] text-sky-400 mt-1">
                  Bank of England + UK Gilts
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-400 mt-3 leading-relaxed">
              Every block transition continuously cross-validates the cryptographic blockchain state with RhinoBank's double-entry banking ledger and statutory reserves custody accounts.
            </p>
          </div>

          {/* Live Recent Blocks Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
                <Layers className="w-4 h-4 text-sky-400" />
                Live Proof-of-Stake Block Stream
              </h2>
              <button
                onClick={() => onNavigateTab('explorer')}
                className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 font-mono cursor-pointer"
              >
                Full Explorer <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-800 text-[11px]">
                    <th className="pb-2">HEIGHT</th>
                    <th className="pb-2">EPOCH / SLOT</th>
                    <th className="pb-2">PROPOSER</th>
                    <th className="pb-2">TXS</th>
                    <th className="pb-2">ATTESTATIONS</th>
                    <th className="pb-2">FINALITY</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {blocks.slice(0, 5).map((b: any) => (
                    <tr key={b.height} className="hover:bg-slate-800/30">
                      <td className="py-2.5 font-bold text-sky-400">#{b.height}</td>
                      <td className="py-2.5 text-slate-300">{b.epoch} / {b.slot}</td>
                      <td className="py-2.5 text-slate-200 font-sans">{b.proposerName || b.proposer}</td>
                      <td className="py-2.5 text-amber-300">{b.transactionsCount || b.transactions?.length || 0}</td>
                      <td className="py-2.5 text-emerald-400 font-bold">{b.attestations?.length || 7}/7 (99%)</td>
                      <td className="py-2.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                          FINALIZED
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Institutional Validator Network Set */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
                <Building className="w-4 h-4 text-purple-400" />
                Interbank Validator Nodes
              </h2>
              <button
                onClick={() => onNavigateTab('consensus')}
                className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1 font-mono cursor-pointer"
              >
                Validator Set <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2">
              {validators.slice(0, 6).map((v: any) => (
                <div key={v.id} className="p-2.5 rounded bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-200 font-sans flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      {v.name}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {v.operator} • Uptime {v.uptimePercent}%
                    </div>
                  </div>
                  <div className="text-right font-mono">
                    <div className="text-purple-300 font-bold">{v.votingPower}% power</div>
                    <div className="text-[10px] text-slate-400">£{formatUnits(v.stakeUnits)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Fast Actions Module */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Operational Quick Terminals
            </h2>
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <button
                onClick={() => onNavigateTab('wallets')}
                className="p-2.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-center transition-colors cursor-pointer"
              >
                Digital Wallets
              </button>
              <button
                onClick={() => onNavigateTab('merchants')}
                className="p-2.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-center transition-colors cursor-pointer"
              >
                POS & Dynamic QR
              </button>
              <button
                onClick={() => onNavigateTab('compliance')}
                className="p-2.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-center transition-colors cursor-pointer"
              >
                AML & Travel Rule
              </button>
              <button
                onClick={() => onNavigateTab('invariants')}
                className="p-2.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-center transition-colors cursor-pointer"
              >
                Invariant Verifier
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
