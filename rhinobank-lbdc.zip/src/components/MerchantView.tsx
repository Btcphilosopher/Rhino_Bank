import React, { useState } from 'react';
import { 
  Store, 
  QrCode, 
  Receipt, 
  CheckCircle, 
  Clock, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck,
  CreditCard
} from 'lucide-react';

interface MerchantProps {
  merchants: any[];
  invoices: any[];
  accounts: any[];
  onCreateInvoice: (params: any) => Promise<any>;
  onPayInvoice: (invoiceId: string, payerWalletId: string) => Promise<void>;
}

export const MerchantView: React.FC<MerchantProps> = ({
  merchants,
  invoices,
  accounts,
  onCreateInvoice,
  onPayInvoice
}) => {
  const [selectedMerchant, setSelectedMerchant] = useState(merchants[0]?.id || '');
  const [invoiceAmount, setInvoiceAmount] = useState('18.50');
  const [invoiceDesc, setInvoiceDesc] = useState('Oxford Artisan Single Origin Coffee & Pastry Batch');
  const [activeInvoice, setActiveInvoice] = useState<any>(invoices[0] || null);
  const [payerWallet, setPayerWallet] = useState(accounts.find(a => a.type === 'PERSONAL')?.id || accounts[0]?.id);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPaying, setIsPaying] = useState(false);

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    try {
      const res = await onCreateInvoice({
        merchantId: selectedMerchant,
        amount: invoiceAmount,
        description: invoiceDesc
      });
      if (res && res.invoice) {
        setActiveInvoice(res.invoice);
      }
    } catch (err: any) {
      alert('Invoice error: ' + err.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePay = async () => {
    if (!activeInvoice) return;
    setIsPaying(true);
    try {
      await onPayInvoice(activeInvoice.invoiceId, payerWallet);
      alert(`Invoice ${activeInvoice.invoiceId} successfully paid via LBDC instant POS settlement.`);
      setActiveInvoice({ ...activeInvoice, status: 'PAID' });
    } catch (err: any) {
      alert('Payment failed: ' + err.message);
    } finally {
      setIsPaying(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-400" />
            Merchant POS & Dynamic QR Payments Infrastructure
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional merchant acquiring rails with instant on-chain finality, dynamic QR cryptographic verification, and 0.25% transaction fees.
          </p>
        </div>
      </div>

      {/* 2-Column: Merchant POS Terminal & Dynamic QR Checkout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Merchant Terminal & Invoice Creator */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
              <Receipt className="w-4 h-4 text-emerald-400" />
              Generate Dynamic POS Payment Invoice
            </h2>

            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Merchant Terminal</label>
                <select
                  value={selectedMerchant}
                  onChange={(e) => setSelectedMerchant(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                >
                  {merchants.map(m => (
                    <option key={m.id} value={m.id}>{m.businessName} ({m.category})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Total Bill Amount (£ LBDC)</label>
                <input
                  type="number"
                  step="0.01"
                  value={invoiceAmount}
                  onChange={(e) => setInvoiceAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Line Item Description</label>
                <input
                  type="text"
                  value={invoiceDesc}
                  onChange={(e) => setInvoiceDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-sans"
                  required
                />
              </div>

              <div className="flex items-center justify-end pt-1">
                <button
                  type="submit"
                  disabled={isGenerating}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isGenerating ? 'Generating QR...' : 'Create Dynamic QR Invoice'}
                </button>
              </div>
            </form>
          </div>

          {/* Merchant Profiles List */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              Active Registered Merchants
            </h2>

            <div className="space-y-2">
              {merchants.map(m => (
                <div key={m.id} className="p-3 bg-slate-950 rounded border border-slate-800 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200 font-sans">{m.businessName}</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {m.settlementSchedule}
                    </span>
                  </div>
                  <div className="text-slate-400 mt-1">{m.category}</div>
                  <div className="text-[10px] text-slate-500 font-mono mt-1">
                    API Key: {m.apiKey.substring(0, 20)}...
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Dynamic QR Display & Live Payment Simulator */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
                <QrCode className="w-4 h-4 text-sky-400" />
                Live Merchant QR Terminal
              </h2>
              {activeInvoice && (
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                  activeInvoice.status === 'PAID' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {activeInvoice.status}
                </span>
              )}
            </div>

            {activeInvoice ? (
              <div className="space-y-4">
                {/* QR Code Container */}
                <div className="flex flex-col items-center justify-center p-6 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  {activeInvoice.qrSvg ? (
                    <div 
                      className="w-48 h-48 bg-white p-2 rounded-lg shadow-inner flex items-center justify-center"
                      dangerouslySetInnerHTML={{ __html: activeInvoice.qrSvg }}
                    />
                  ) : (
                    <div className="w-48 h-48 bg-slate-800 rounded flex items-center justify-center text-slate-500 font-mono text-xs">
                      QR Generated
                    </div>
                  )}

                  <div className="text-center">
                    <div className="text-lg font-bold text-emerald-400 font-mono">
                      {activeInvoice.amountFormatted}
                    </div>
                    <div className="text-xs text-slate-300 font-sans font-semibold mt-0.5">
                      {activeInvoice.merchantName}
                    </div>
                    <div className="text-[11px] text-slate-400 max-w-xs mt-0.5">
                      {activeInvoice.description}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono mt-1">
                      Ref: {activeInvoice.invoiceId}
                    </div>
                  </div>
                </div>

                {/* Simulate Payment Trigger */}
                {activeInvoice.status !== 'PAID' && (
                  <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-3 text-xs">
                    <div>
                      <label className="text-slate-400 block mb-1">Simulate Customer Phone Scan (Payer Wallet)</label>
                      <select
                        value={payerWallet}
                        onChange={(e) => setPayerWallet(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-200"
                      >
                        {accounts.filter(a => a.type === 'PERSONAL' || a.type === 'BUSINESS').map(a => (
                          <option key={a.id} value={a.id}>{a.label} (Avail: £{formatUnits(a.availableUnits)})</option>
                        ))}
                      </select>
                    </div>

                    <button
                      onClick={handlePay}
                      disabled={isPaying}
                      className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold transition-colors cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                    >
                      <CreditCard className="w-4 h-4" />
                      {isPaying ? 'Authorizing Tap Settlement...' : 'Simulate Customer Tap & Pay'}
                    </button>
                  </div>
                )}

                {activeInvoice.status === 'PAID' && (
                  <div className="p-3 bg-emerald-950/50 rounded border border-emerald-800/60 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>Payment completed on-chain. Merchant settlement wallet credited instantly.</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-500 font-mono text-xs">
                No active invoice selected. Generate an invoice on the left to activate QR display.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
