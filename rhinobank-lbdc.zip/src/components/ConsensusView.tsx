import React, { useState } from 'react';
import { 
  Cpu, 
  ShieldAlert, 
  Lock, 
  Unlock, 
  UserPlus, 
  Award, 
  AlertOctagon, 
  Activity,
  PieChart,
  CheckCircle,
  Percent
} from 'lucide-react';

interface ConsensusProps {
  validators: any[];
  decentralisation: any;
  onSlash: (id: string, reason: string, amount: number) => Promise<void>;
  onJail: (id: string, epochs: number) => Promise<void>;
  onUnjail: (id: string) => Promise<void>;
  onRegister: (data: any) => Promise<void>;
}

export const ConsensusView: React.FC<ConsensusProps> = ({
  validators,
  decentralisation,
  onSlash,
  onJail,
  onUnjail,
  onRegister
}) => {
  const [selectedValidator, setSelectedValidator] = useState<any>(null);
  const [slashReason, setSlashReason] = useState('Equivocation / Double-Signing Block');
  const [slashPenalty, setSlashPenalty] = useState(500000);
  const [jailEpochs, setJailEpochs] = useState(5);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Validator Form State
  const [newName, setNewName] = useState('Lloyds Bank Clearing Validator');
  const [newOperator, setNewOperator] = useState('Lloyds Banking Group plc');
  const [newJurisdiction, setNewJurisdiction] = useState('United Kingdom (PRA/FCA)');
  const [newStake, setNewStake] = useState('6000000');
  const [newIp, setNewIp] = useState('194.102.8.22 (London Data Center)');

  const formatUnits = (unitsStr: string | bigint | number) => {
    const val = Number(unitsStr || 0) / 10000;
    return val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onRegister({
        name: newName,
        operator: newOperator,
        jurisdiction: newJurisdiction,
        stakeAmount: newStake,
        ipAddress: newIp
      });
      setShowRegisterModal(false);
    } catch (err: any) {
      alert('Error registering validator: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-purple-400" />
            Proof-of-Stake Consensus & Validator Architecture
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Stake-weighted voting power <span className="font-mono text-purple-300">f(Stake)</span> with anti-cartel institutional weight caps (&le; 25%) and Casper-FFG deterministic finality.
          </p>
        </div>

        <button
          onClick={() => setShowRegisterModal(true)}
          className="px-3.5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5 shadow-sm self-start cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          Register Institutional Node
        </button>
      </div>

      {/* Decentralisation Metrics & Invariants */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
            <span>NAKAMOTO COEFFICIENT</span>
            <ShieldAlert className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{decentralisation?.nakamotoCoefficient || 3}</div>
          <p className="text-[11px] text-slate-400 mt-1">Minimum nodes to reach 33.4% Byzantine threshold</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
            <span>STAKE HHI INDEX</span>
            <Percent className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{decentralisation?.stakeHhiIndex || 1840}</div>
          <p className="text-[11px] text-emerald-400 mt-1">Unconcentrated (&lt; 2,500 target)</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
            <span>TOP-1 WEIGHT CAP</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{decentralisation?.top1StakePercent || 24.5}%</div>
          <p className="text-[11px] text-slate-400 mt-1">Hard statutory cap: 25.0% max power</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
            <span>TOTAL STAKED POOL</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">
            £{formatUnits(decentralisation?.totalStakedUnits || '490000000000')}
          </div>
          <p className="text-[11px] text-emerald-400 mt-1">Institutional bonded capital</p>
        </div>
      </div>

      {/* Validators Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
            Active Validator Node Registry ({validators.length} Institutional Operators)
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            Supermajority Threshold: &ge; 66.7% Attestations
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-[11px]">
                <th className="p-3">NODE NAME & OPERATOR</th>
                <th className="p-3">STATUS</th>
                <th className="p-3">EFFECTIVE STAKE</th>
                <th className="p-3">VOTING POWER</th>
                <th className="p-3">UPTIME</th>
                <th className="p-3">PROPOSED / ATTESTED</th>
                <th className="p-3">REWARDS</th>
                <th className="p-3 text-right">GOVERNANCE ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {validators.map((v) => (
                <tr key={v.id} className="hover:bg-slate-800/40">
                  <td className="p-3">
                    <div className="font-bold text-slate-200 font-sans">{v.name}</div>
                    <div className="text-[11px] text-slate-400">{v.operator} • {v.jurisdiction}</div>
                    <div className="text-[10px] text-slate-500 truncate max-w-xs">{v.publicKey}</div>
                  </td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      v.status === 'Active' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                      v.status === 'Jailed' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                      v.status === 'Slashed' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                      'bg-slate-800 text-slate-400'
                    }`}>
                      {v.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="p-3 text-slate-200 font-bold">
                    £{formatUnits(v.stakeUnits)}
                  </td>
                  <td className="p-3">
                    <div className="text-purple-300 font-bold">{v.votingPower}%</div>
                    <div className="w-16 bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
                      <div className="bg-purple-400 h-1.5 rounded-full" style={{ width: `${Math.min(100, v.votingPower * 4)}%` }}></div>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className={v.uptimePercent >= 99.9 ? 'text-emerald-400' : 'text-amber-400'}>
                      {v.uptimePercent}%
                    </span>
                  </td>
                  <td className="p-3 text-slate-300">
                    {v.blocksProposed} blk / {v.blocksAttested} att
                  </td>
                  <td className="p-3 text-emerald-400">
                    +£{formatUnits(v.rewardBalanceUnits)}
                  </td>
                  <td className="p-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {v.status === 'Active' && (
                        <>
                          <button
                            onClick={() => {
                              setSelectedValidator(v);
                            }}
                            className="px-2 py-1 rounded bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-[11px] font-semibold cursor-pointer"
                          >
                            Slash
                          </button>
                          <button
                            onClick={() => onJail(v.id, 5)}
                            className="px-2 py-1 rounded bg-amber-950 hover:bg-amber-900 text-amber-300 border border-amber-800 text-[11px] font-semibold cursor-pointer"
                          >
                            Jail (5 Ep)
                          </button>
                        </>
                      )}
                      {v.status === 'Jailed' && (
                        <button
                          onClick={() => onUnjail(v.id)}
                          className="px-2 py-1 rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-[11px] font-semibold cursor-pointer"
                        >
                          Unjail Node
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Slashing Modal / Dialog */}
      {selectedValidator && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-800/80 rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertOctagon className="w-6 h-6" />
              <h3 className="font-bold text-base text-slate-100">Slashing Protocol Enforcement</h3>
            </div>

            <p className="text-xs text-slate-300">
              You are applying an irrevocable Proof-of-Stake consensus penalty to <strong className="text-slate-100">{selectedValidator.name}</strong>.
            </p>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Violation Reason</label>
              <select
                value={slashReason}
                onChange={(e) => setSlashReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-200"
              >
                <option value="Equivocation / Double-Signing Block">Equivocation / Double-Signing Block (Critical)</option>
                <option value="Surround Vote Rule Violation">Surround Vote Rule Violation (Casper-FFG)</option>
                <option value="Malicious Proposal Injection">Malicious Proposal Injection</option>
                <option value="Extended Unannounced Outage">Extended Unannounced Outage &gt; 48h</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Slashing Penalty Amount (£ LBDC)</label>
              <input
                type="number"
                value={slashPenalty}
                onChange={(e) => setSlashPenalty(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-200 font-mono"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedValidator(null)}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  await onSlash(selectedValidator.id, slashReason, slashPenalty);
                  setSelectedValidator(null);
                }}
                className="px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white cursor-pointer"
              >
                Confirm Slashing Order
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Register Validator Modal */}
      {showRegisterModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-purple-400" />
                Register Regulated Institutional Validator
              </h3>
              <button onClick={() => setShowRegisterModal(false)} className="text-slate-400 hover:text-slate-200">✕</button>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Node Display Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Regulated Operating Institution</label>
                <input
                  type="text"
                  value={newOperator}
                  onChange={(e) => setNewOperator(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Regulatory Jurisdiction</label>
                <input
                  type="text"
                  value={newJurisdiction}
                  onChange={(e) => setNewJurisdiction(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Initial Bond Stake (£ LBDC)</label>
                  <input
                    type="number"
                    value={newStake}
                    onChange={(e) => setNewStake(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">HSM / Data Center Location</label>
                  <input
                    type="text"
                    value={newIp}
                    onChange={(e) => setNewIp(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                    required
                  />
                </div>
              </div>

              <p className="text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                New institutional nodes will generate an Ed25519 identity keypair and BLS12-381 consensus keypair stored in hardware security modules (HSM).
              </p>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 rounded bg-purple-600 hover:bg-purple-500 font-bold text-slate-950 disabled:opacity-50"
                >
                  {isSubmitting ? 'Registering...' : 'Submit Institutional Registration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
