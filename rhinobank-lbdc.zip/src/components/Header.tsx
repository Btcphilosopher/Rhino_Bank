import React from 'react';
import { 
  ShieldCheck, 
  Activity, 
  Layers, 
  Database, 
  Lock, 
  RefreshCw,
  Landmark,
  Cpu
} from 'lucide-react';

interface HeaderProps {
  currentHeight: number;
  currentEpoch: number;
  currentSlot: number;
  tps: number;
  reserveRatio: number;
  isSyncing: boolean;
  onRefresh: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentHeight,
  currentEpoch,
  currentSlot,
  tps,
  reserveRatio,
  isSyncing,
  onRefresh
}) => {
  return (
    <header className="bg-slate-950 border-b border-slate-800/80 sticky top-0 z-50 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Logo & Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-black text-xl tracking-tighter shadow-inner">
            <Landmark className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-wider text-slate-100 uppercase">
                RHINOBANK <span className="text-emerald-400">LBDC</span>
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/50">
                PROD-SETTLEMENT-MAINNET
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium">
              Local Bank Digital Currency — Proof-of-Stake Financial Operating System
            </p>
          </div>
        </div>

        {/* Live Network Indicators */}
        <div className="flex items-center gap-2 md:gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-slate-400 text-[11px]">BFT CONSENSUS:</span>
            <span className="text-emerald-400 font-bold">EPOCH {currentEpoch} • SLOT {currentSlot}/32</span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
            <Layers className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400 text-[11px]">HEIGHT:</span>
            <span className="text-sky-300 font-bold">#{currentHeight}</span>
          </div>

          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400 text-[11px]">THROUGHPUT:</span>
            <span className="text-amber-300 font-bold">{tps} TPS</span>
          </div>

          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400 text-[11px]">RESERVES:</span>
            <span className="text-emerald-300 font-bold">{reserveRatio}% BACKED</span>
          </div>

          <button
            onClick={onRefresh}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors flex items-center gap-1 text-xs border border-slate-700 cursor-pointer"
            title="Refresh Network Telemetry"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-emerald-400' : ''}`} />
          </button>
        </div>
      </div>
    </header>
  );
};
