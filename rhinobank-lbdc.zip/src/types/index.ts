// ============================================================================
// RHINOBANK LBDC — FINANCIAL OPERATING SYSTEM TYPES
// ============================================================================

export type CurrencyPegMode = 'FIXED_GBP' | 'INDEPENDENT_MONETARY_UNIT' | 'BASKET_PEG';

export type AccountType = 
  | 'PERSONAL'
  | 'BUSINESS'
  | 'MERCHANT'
  | 'BANK'
  | 'TREASURY'
  | 'VALIDATOR'
  | 'ESCROW'
  | 'RESERVE';

export type ValidatorStatus = 
  | 'Pending'
  | 'Active'
  | 'Inactive'
  | 'Jailed'
  | 'Slashed'
  | 'Exiting'
  | 'Exited';

export type TransactionStatus = 
  | 'Pending'
  | 'Proposed'
  | 'Attested'
  | 'Finalized'
  | 'Rejected'
  | 'Reverted';

export type TransactionType = 
  | 'Transfer'
  | 'Mint'
  | 'Burn'
  | 'Freeze'
  | 'Unfreeze'
  | 'Escrow'
  | 'Settlement'
  | 'ValidatorReward'
  | 'ValidatorPenalty'
  | 'Governance';

export type SettlementMode = 'RTGS_GROSS' | 'MULTILATERAL_NETTING' | 'INSTANT_RETAIL';

export interface MonetaryAmount {
  units: bigint; // fixed point 4 decimals: 1 LBDC = 10,000 units (integer representation)
  formatted: string; // e.g. "1,250.0000 LBDC"
  fiatEquivalentGbp: string;
}

export interface WalletAccount {
  id: string;
  label: string;
  type: AccountType;
  ownerName: string;
  institution: string;
  publicKey: string;
  balanceUnits: bigint;
  availableUnits: bigint;
  pendingUnits: bigint;
  frozenUnits: bigint;
  escrowUnits: bigint;
  stakedUnits: bigint;
  nonce: number;
  kycLevel: 'TIER_1_BASIC' | 'TIER_2_VERIFIED' | 'TIER_3_INSTITUTIONAL';
  isFrozen: boolean;
  dailyLimitUnits: bigint;
  dailySpentUnits: bigint;
  createdTimestamp: number;
}

export interface ValidatorNode {
  id: string;
  name: string;
  operator: string;
  jurisdiction: string;
  publicKey: string;
  consensusKey: string;
  ipAddress: string;
  stakeUnits: bigint;
  delegatedUnits: bigint;
  votingPower: number; // percentage capped f(stake)
  rawPower: number;
  status: ValidatorStatus;
  uptimePercent: number;
  performanceScore: number;
  blocksProposed: number;
  blocksAttested: number;
  missedVotes: number;
  rewardBalanceUnits: bigint;
  penaltyBalanceUnits: bigint;
  slashEventsCount: number;
  latencyMs: number;
  peerCount: number;
  jailReleaseEpoch?: number;
}

export interface Attestation {
  validatorId: string;
  validatorName: string;
  slot: number;
  epoch: number;
  blockHash: string;
  signature: string;
  timestamp: number;
}

export interface Block {
  height: number;
  epoch: number;
  slot: number;
  timestamp: number;
  previousHash: string;
  hash: string;
  stateRoot: string;
  transactionRoot: string;
  receiptsRoot: string;
  proposer: string;
  proposerName: string;
  validatorCommitment: string;
  transactionsCount: number;
  transactions: Transaction[];
  attestations: Attestation[];
  totalFeesUnits: bigint;
  consensusParticipationRate: number;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  sender: string;
  senderName: string;
  recipient: string;
  recipientName: string;
  asset: string; // "LBDC"
  amountUnits: bigint;
  amountFormatted: string;
  feeUnits: bigint;
  nonce: number;
  timestamp: number;
  signature: string;
  status: TransactionStatus;
  blockHeight?: number;
  epoch?: number;
  memo?: string;
  settlementMode?: SettlementMode;
  amlRiskScore?: number;
  complianceStatus?: 'CLEARED' | 'FLAGGED' | 'MANUAL_REVIEW';
  escrowReleaseTime?: number;
}

// Double-Entry Accounting Ledger Record
export interface LedgerEntry {
  id: string;
  timestamp: number;
  transactionId: string;
  journalNo: number;
  debitAccountCode: string;
  debitAccountName: string;
  creditAccountCode: string;
  creditAccountName: string;
  amountUnits: bigint;
  amountFormatted: string;
  asset: string;
  description: string;
  verified: boolean;
}

export interface ChartOfAccount {
  code: string;
  name: string;
  category: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  balanceUnits: bigint;
  normalBalance: 'DEBIT' | 'CREDIT';
  description: string;
}

// Reserves System
export interface ReserveAssetItem {
  id: string;
  assetType: 'BANK_OF_ENGLAND_RESERVES' | 'UK_GILTS_TREASURIES' | 'PHYSICAL_VAULT_CASH' | 'TIER_1_BANK_DEPOSITS';
  custodian: string;
  nominalValueGbp: number;
  liquidValueGbp: number;
  haircutPercent: number;
  durationMonths: number;
  verifiedAt: string;
  auditor: string;
}

export interface MonetarySupplyState {
  m0LbdcUnits: bigint;
  circulatingUnits: bigint;
  treasuryUnits: bigint;
  frozenUnits: bigint;
  escrowUnits: bigint;
  stakedUnits: bigint;
  burnedUnits: bigint;
  mintedUnits: bigint;
  totalSupplyUnits: bigint;
  pegMode: CurrencyPegMode;
  pegRatioToGbp: number; // e.g. 1.0000
  reserveCoverageRatio: number; // e.g. 108.4%
  liquidReserveRatio: number; // e.g. 96.2%
  issuanceCapUnits: bigint;
}

export interface MonetaryPolicySettings {
  baseInterestRatePercent: number;
  stakingRewardAnnualRatePercent: number;
  baseTransferFeeUnits: bigint;
  merchantDiscountRatePercent: number;
  reserveRequirementPercent: number; // e.g. 100%
  maxValidatorWeightCapPercent: number; // e.g. 20%
  emergencyHalt: boolean;
  unauthorizedMintDetected: boolean;
}

// Interbank RTGS & Netting
export interface InterbankParticipant {
  id: string;
  bankName: string;
  sortCode: string;
  settlementWalletId: string;
  reserveAccountId: string;
  availableLiquidityUnits: bigint;
  intradayCreditLimitUnits: bigint;
  grossPayableUnits: bigint;
  grossReceivableUnits: bigint;
  netObligationUnits: bigint; // positive = receives, negative = pays
  status: 'ONLINE' | 'QUEUEING' | 'STRESSED' | 'SUSPENDED';
}

export interface SettlementBatch {
  batchId: string;
  timestamp: number;
  cycleNumber: number;
  mode: SettlementMode;
  grossTotalUnits: bigint;
  netSettledUnits: bigint;
  liquiditySavedUnits: bigint;
  efficiencyPercent: number;
  transactionsIncluded: number;
  status: 'SETTLED' | 'PROCESSING' | 'QUEUED';
}

// Merchant & Invoicing
export interface MerchantProfile {
  id: string;
  businessName: string;
  category: string;
  settlementWalletId: string;
  apiKey: string;
  webhookUrl: string;
  settlementSchedule: 'REAL_TIME' | 'END_OF_DAY_BATCH' | 'T_PLUS_1';
  dailyVolumeUnits: bigint;
  activeInvoicesCount: number;
  refundPolicy: string;
}

export interface MerchantInvoice {
  invoiceId: string;
  merchantId: string;
  merchantName: string;
  amountUnits: bigint;
  amountFormatted: string;
  fiatEquivalentGbp: string;
  description: string;
  recipientWalletId: string;
  qrPayload: string;
  qrSvg?: string;
  expiresAt: number;
  status: 'PAID' | 'PENDING' | 'EXPIRED' | 'CANCELLED';
  createdAt: number;
  paidTxId?: string;
}

// Compliance, AML & Sanctions
export interface AMLRiskAssessment {
  transactionId: string;
  timestamp: number;
  sender: string;
  recipient: string;
  amountUnits: bigint;
  riskScore: number; // 0 - 100
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  reasons: string[];
  flags: {
    velocitySpike: boolean;
    structuringDetected: boolean;
    highRiskCounterparty: boolean;
    sanctionListHit: boolean;
    rapidDormancyWakeup: boolean;
    roundAmountPattern: boolean;
  };
  travelRuleStatus: 'ATTACHED_ENCRYPTED' | 'NOT_REQUIRED' | 'FLAGGED';
  recommendedAction: 'APPROVE' | 'STEP_UP_AUTH' | 'HOLD_FOR_AUDIT' | 'FREEZE';
}

export interface GovernanceProposal {
  id: string;
  title: string;
  proposer: string;
  category: 'PARAMETER_CHANGE' | 'RESERVE_POLICY' | 'VALIDATOR_RULE' | 'SECURITY_EMERGENCY' | 'PROTOCOL_UPGRADE';
  description: string;
  votesFor: number;
  votesAgainst: number;
  quorumReached: boolean;
  status: 'ACTIVE' | 'PASSED' | 'REJECTED' | 'EXECUTED';
  activationEpoch: number;
  createdAt: number;
}

export interface AuditLogEvent {
  id: string;
  timestamp: number;
  actor: string;
  actorRole: 'CENTRAL_BANKER' | 'CHIEF_RISK_OFFICER' | 'VALIDATOR_LEADER' | 'SETTLEMENT_OPERATOR' | 'SYSTEM_CORE';
  action: string;
  category: 'MONETARY_MINT' | 'MONETARY_BURN' | 'POLICY_CHANGE' | 'SLASH_EVENT' | 'FREEZE_ORDER' | 'SETTLEMENT_CYCLE' | 'RECONCILIATION';
  details: string;
  ipAddress: string;
  signature: string;
  authLevel: 'SINGLE_SIG' | 'MULTI_SIG_3_OF_5' | 'GOVERNANCE_CONSENSUS';
}

export interface NetworkHealthMetrics {
  currentHeight: number;
  currentEpoch: number;
  currentSlot: number;
  tps: number;
  peakTps: number;
  avgBlockTimeMs: number;
  finalityTimeMs: number;
  activeValidatorsCount: number;
  totalValidatorsCount: number;
  participationRatePercent: number;
  nakamotoCoefficient: number;
  stakeHhiIndex: number;
  totalStakedUnits: bigint;
  moneyVelocity: number; // MV = PY velocity indicator
  economicActivityIndex: number; // 0 - 100
  totalVolume24hUnits: bigint;
  pendingTransactionsCount: number;
}
