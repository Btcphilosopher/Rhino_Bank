// ============================================================================
// RHINOBANK LBDC — INSTITUTIONAL BACKEND SERVER & REST/RPC API
// ============================================================================

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { ConsensusEngine } from './src/services/consensus';
import { MonetaryLedger } from './src/services/ledger';
import { Blockchain } from './src/services/blockchain';
import { MonetaryEngine } from './src/services/monetary';
import { SettlementEngine } from './src/services/settlement';
import { MerchantEngine } from './src/services/merchant';
import { ComplianceEngine } from './src/services/compliance';
import { SimulationLab } from './src/services/simulation';
import { InvariantTestSuite } from './src/services/invariantTests';
import { RUST_WORKSPACE_FILES } from './src/services/rustWorkspace';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Core Financial Systems
  const consensus = new ConsensusEngine();
  const ledger = new MonetaryLedger();
  const blockchain = new Blockchain(consensus, ledger);
  const monetary = new MonetaryEngine(blockchain, ledger);
  const settlement = new SettlementEngine(blockchain, ledger);
  const merchant = new MerchantEngine(blockchain);
  const compliance = new ComplianceEngine();
  const simulation = new SimulationLab(blockchain, consensus, monetary);
  const invariantTests = new InvariantTestSuite(blockchain, consensus, monetary, ledger);

  // Background Consensus Heartbeat (Block production tick every 3.5 seconds)
  setInterval(() => {
    try {
      blockchain.produceBlock();
    } catch (err) {
      console.error('Consensus background tick error:', err);
    }
  }, 3500);

  // JSON-RPC / BigInt Serializer Helper
  function serializeBigInt(obj: any): any {
    return JSON.parse(
      JSON.stringify(obj, (_, value) =>
        typeof value === 'bigint' ? value.toString() : value
      )
    );
  }

  // ============================================================================
  // REST API ROUTES
  // ============================================================================

  app.get('/api/health', (req, res) => {
    res.json({ status: 'HEALTHY', timestamp: Date.now(), network: 'rhinobank-lbdc-uk-main-01' });
  });

  // Complete System Status & Metrics
  app.get('/api/status', (req, res) => {
    const supply = monetary.getSupplyState();
    const dec = consensus.calculateDecentralisationMetrics();
    const vel = monetary.calculateMoneyVelocity(30);
    const tb = ledger.calculateTrialBalance();
    const recon = ledger.runTriPartyReconciliation(
      supply.totalSupplyUnits,
      BigInt(Math.floor(monetary.getTotalReserveValueGbp() * 10000))
    );

    const latestBlock = blockchain.getLatestBlock();

    res.json(serializeBigInt({
      network: 'RhinoBank LBDC Sovereign Settlement Network',
      chainId: 'rhinobank-lbdc-uk-main-01',
      version: '0.1.0-institutional',
      currentHeight: latestBlock.height,
      currentEpoch: latestBlock.epoch,
      currentSlot: latestBlock.slot,
      totalValidators: consensus.getValidators().length,
      activeValidators: consensus.getValidators().filter(v => v.status === 'Active').length,
      supply,
      decentralisation: dec,
      velocity: vel,
      trialBalance: tb,
      reconciliation: recon,
      policy: monetary.getPolicySettings()
    }));
  });

  // Blockchain Blocks & Mempool
  app.get('/api/blocks', (req, res) => {
    res.json(serializeBigInt(blockchain.getBlocks().slice(-50).reverse()));
  });

  app.get('/api/accounts', (req, res) => {
    res.json(serializeBigInt(blockchain.getAccounts()));
  });

  // Submit Standard Transfer
  app.post('/api/transactions/transfer', (req, res) => {
    try {
      const { senderId, recipientId, amount, memo, settlementMode } = req.body;
      const amountUnits = BigInt(Math.floor(parseFloat(amount) * 10000));
      
      const tx = blockchain.submitTransaction({
        type: 'Transfer',
        senderId,
        recipientId,
        amountUnits,
        memo,
        settlementMode
      });

      // Assess AML Compliance
      const isPersonal = blockchain.getAccount(senderId)?.type === 'PERSONAL';
      const amlAssessment = compliance.assessTransaction({
        txId: tx.id,
        senderId,
        recipientId,
        amountUnits,
        isPersonal
      });

      res.json(serializeBigInt({ success: true, transaction: tx, amlAssessment }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Multi-Sig Authorized Monetary Minting
  app.post('/api/transactions/mint', (req, res) => {
    try {
      const { amount, destinationAccountId, issuanceReason, signers, statutoryOrderRef } = req.body;
      const amountUnits = BigInt(Math.floor(parseFloat(amount) * 10000));

      const result = monetary.executeAuthorizedMint({
        amountUnits,
        destinationAccountId,
        issuanceReason: issuanceReason || 'Statutory M0 Reserve Backing Expansion',
        signers: signers || ['0xpk_rhino_gov_key_1', '0xpk_rhino_gov_key_2', '0xpk_rhino_gov_key_3'],
        statutoryOrderRef: statutoryOrderRef || 'BOE-LBDC-ORD-2026-881'
      });

      res.json(serializeBigInt(result));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Authorized Monetary Burning
  app.post('/api/transactions/burn', (req, res) => {
    try {
      const { amount, sourceAccountId, redemptionReason, signers } = req.body;
      const amountUnits = BigInt(Math.floor(parseFloat(amount) * 10000));

      const result = monetary.executeAuthorizedBurn({
        amountUnits,
        sourceAccountId,
        redemptionReason: redemptionReason || 'Commercial Bank Interbank Redemption',
        signers: signers || ['0xpk_rhino_burn_sig_1', '0xpk_rhino_burn_sig_2']
      });

      res.json(serializeBigInt(result));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Validators & Staking
  app.get('/api/validators', (req, res) => {
    res.json(serializeBigInt(consensus.getValidators()));
  });

  app.post('/api/validators/slash', (req, res) => {
    try {
      const { validatorId, reason, penaltyAmount } = req.body;
      const penaltyUnits = BigInt(Math.floor((penaltyAmount || 500000) * 10000));
      const val = consensus.slashValidator(validatorId, reason || 'Equivocation Double-Signing', penaltyUnits);
      res.json(serializeBigInt({ success: true, validator: val }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  app.post('/api/validators/jail', (req, res) => {
    try {
      const { validatorId, durationEpochs } = req.body;
      const val = consensus.jailValidator(validatorId, durationEpochs || 5);
      res.json(serializeBigInt({ success: true, validator: val }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  app.post('/api/validators/unjail', (req, res) => {
    try {
      const { validatorId } = req.body;
      const val = consensus.unjailValidator(validatorId);
      res.json(serializeBigInt({ success: true, validator: val }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  app.post('/api/validators/register', (req, res) => {
    try {
      const { name, operator, jurisdiction, stakeAmount, ipAddress } = req.body;
      const stakeUnits = BigInt(Math.floor(parseFloat(stakeAmount) * 10000));
      const val = consensus.registerValidator({
        name,
        operator,
        jurisdiction,
        stakeUnits,
        ipAddress: ipAddress || '192.168.1.100 (Tier-3 Secured)'
      });
      res.json(serializeBigInt({ success: true, validator: val }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // General Ledger
  app.get('/api/ledger/chart', (req, res) => {
    res.json(serializeBigInt(ledger.getChartOfAccounts()));
  });

  app.get('/api/ledger/journal', (req, res) => {
    res.json(serializeBigInt(ledger.getJournal()));
  });

  app.get('/api/ledger/trial-balance', (req, res) => {
    res.json(serializeBigInt(ledger.calculateTrialBalance()));
  });

  // Monetary & Reserves
  app.get('/api/monetary/reserves', (req, res) => {
    res.json(serializeBigInt(monetary.getReserveAssets()));
  });

  app.post('/api/monetary/policy', (req, res) => {
    try {
      monetary.updatePolicySettings(req.body);
      res.json({ success: true, policy: monetary.getPolicySettings() });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Interbank RTGS & Netting
  app.get('/api/settlement/participants', (req, res) => {
    res.json(serializeBigInt(settlement.getParticipants()));
  });

  app.get('/api/settlement/batches', (req, res) => {
    res.json(serializeBigInt(settlement.getBatches()));
  });

  app.post('/api/settlement/rtgs', (req, res) => {
    try {
      const { senderBankId, recipientBankId, amount, reference } = req.body;
      const amountUnits = BigInt(Math.floor(parseFloat(amount) * 10000));
      const result = settlement.executeRtgsSettlement({
        senderBankId,
        recipientBankId,
        amountUnits,
        reference: reference || 'Interbank Wholesale Liquidity Transfer'
      });
      res.json(serializeBigInt(result));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  app.post('/api/settlement/netting-cycle', (req, res) => {
    try {
      const batch = settlement.executeMultilateralNettingBatch();
      res.json(serializeBigInt({ success: true, batch }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Merchants & Dynamic QR Invoices
  app.get('/api/merchants', (req, res) => {
    res.json(serializeBigInt(merchant.getMerchants()));
  });

  app.get('/api/merchants/invoices', (req, res) => {
    res.json(serializeBigInt(merchant.getInvoices()));
  });

  app.post('/api/merchants/invoices', async (req, res) => {
    try {
      const { merchantId, amount, description } = req.body;
      const amountUnits = BigInt(Math.floor(parseFloat(amount) * 10000));
      const invoice = await merchant.createInvoice({
        merchantId,
        amountUnits,
        description: description || 'Retail Merchant Purchase'
      });
      res.json(serializeBigInt({ success: true, invoice }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  app.post('/api/merchants/invoices/pay', (req, res) => {
    try {
      const { invoiceId, payerWalletId } = req.body;
      const result = merchant.settleInvoice(invoiceId, payerWalletId);
      res.json(serializeBigInt({ success: true, ...result }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Compliance & Zero-Knowledge Proofs
  app.get('/api/compliance/assessments', (req, res) => {
    res.json(serializeBigInt(compliance.getRecentAssessments()));
  });

  app.post('/api/compliance/zk-proof', (req, res) => {
    try {
      const { claimType, secretValue } = req.body;
      const proof = compliance.issueZkProof(claimType, secretValue || 'CONFIDENTIAL_SECRET');
      res.json({ success: true, proof });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // Stress Testing Lab
  app.post('/api/simulation/surge', (req, res) => {
    const result = simulation.runTransactionSurgeTest(req.body.txCount || 250);
    res.json(serializeBigInt(result));
  });

  app.post('/api/simulation/partition', (req, res) => {
    const result = simulation.runValidatorPartitionTest();
    res.json(serializeBigInt(result));
  });

  app.post('/api/simulation/liquidity-shock', (req, res) => {
    const result = simulation.runLiquidityShockTest();
    res.json(serializeBigInt(result));
  });

  // Invariant Verification Suite
  app.get('/api/invariants/test', (req, res) => {
    const reports = invariantTests.runAllInvariantTests();
    res.json(serializeBigInt(reports));
  });

  // Rust Workspace Files Inspector
  app.get('/api/rust/files', (req, res) => {
    res.json(RUST_WORKSPACE_FILES);
  });

  // Freeze/Unfreeze account
  app.post('/api/accounts/freeze', (req, res) => {
    try {
      const { accountId, frozen } = req.body;
      const acc = blockchain.setAccountFreezeState(accountId, frozen);
      res.json(serializeBigInt({ success: true, account: acc }));
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // ============================================================================
  // VITE MIDDLEWARE (Development) or STATIC ASSETS (Production)
  // ============================================================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RHINOBANK LBDC CORE] Financial operating system listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[RHINOBANK LBDC CORE FATAL ERROR]:', err);
});
