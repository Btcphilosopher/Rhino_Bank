'use client';

import React, { useState } from 'react';
import {
  EnvironmentMode,
  AssetCode,
  ValidatorRecord,
  MonetarySupplyMetrics,
  AccountDistribution,
  ReserveCoverageMetrics,
  StressScenarioResult,
  SystemicRiskOverview,
  AnomalyAlert,
  EconometricModel,
  ModelRegistryItem,
  CrisisTimelineStep,
  KaplanMeierPoint,
  TimeSeriesForecastPoint,
  ForecastModelDiagnostics,
  MonteCarloSummary
} from '../lib/rhinobank/types';
import {
  getSyntheticDataQuality,
  getSyntheticValidators,
  getSyntheticMonetaryMetrics,
  getAccountDistribution,
  getReserveCoverageMetrics,
  getStressScenarios,
  getSystemicRiskOverview,
  getETSReserveForecast,
  getAnomalyAlerts,
  getEconometricModels,
  getModelRegistry,
  getCrisisTimeline
} from '../lib/rhinobank/syntheticEngine';
import { generateKaplanMeierCurve, runMonteCarloSimulation } from '../lib/rhinobank/statsEngine';

import { Header } from '../components/BentoGrid/Header';
import { Navigation, TabKey } from '../components/BentoGrid/Navigation';
import { OverviewBento } from '../components/BentoGrid/OverviewBento';
import { ValidatorObservatory } from '../components/BentoGrid/ValidatorObservatory';
import { MonetaryObservatory } from '../components/BentoGrid/MonetaryObservatory';
import { ReservesStressObservatory } from '../components/BentoGrid/ReservesStressObservatory';
import { RiskEngineObservatory } from '../components/BentoGrid/RiskEngineObservatory';
import { ForecastingEconometricsObservatory } from '../components/BentoGrid/ForecastingEconometricsObservatory';
import { AnomalyCrisisObservatory } from '../components/BentoGrid/AnomalyCrisisObservatory';
import { ModelRegistryReportsObservatory } from '../components/BentoGrid/ModelRegistryReportsObservatory';
import { TimeMachineObservatory } from '../components/BentoGrid/TimeMachineObservatory';
import { Footer } from '../components/BentoGrid/Footer';

export default function RhinoBankPage() {
  const [env, setEnv] = useState<EnvironmentMode>('PRODUCTION');
  const [selectedAsset, setSelectedAsset] = useState<AssetCode>('RUSD');
  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [isSimulating, setIsSimulating] = useState(false);

  // Core Datasets
  const [dataQualityScore] = useState(getSyntheticDataQuality().overall_score);
  const [validators] = useState<ValidatorRecord[]>(getSyntheticValidators());
  const [monetaryMap] = useState<Record<string, MonetarySupplyMetrics>>(getSyntheticMonetaryMetrics());
  const [accountDist] = useState<AccountDistribution>(getAccountDistribution());
  const [reserve] = useState<ReserveCoverageMetrics>(getReserveCoverageMetrics());
  const [stressScenarios] = useState<StressScenarioResult[]>(getStressScenarios());
  const [risk] = useState<SystemicRiskOverview>(getSystemicRiskOverview());
  const [kmData] = useState<KaplanMeierPoint[]>(generateKaplanMeierCurve(1024));
  const [etsData] = useState<{ forecast: TimeSeriesForecastPoint[]; diagnostics: ForecastModelDiagnostics }>(getETSReserveForecast());
  const [anomalies] = useState<AnomalyAlert[]>(getAnomalyAlerts());
  const [econModels] = useState<EconometricModel[]>(getEconometricModels());
  const [models] = useState<ModelRegistryItem[]>(getModelRegistry());
  const [crisisTimeline] = useState<CrisisTimelineStep[]>(getCrisisTimeline());
  const [monteCarlo, setMonteCarlo] = useState<MonteCarloSummary>(runMonteCarloSimulation(50000, 42));

  // Re-run Monte Carlo trigger
  const handleTriggerSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const newSeed = Math.floor(Math.random() * 10000);
      const updated = runMonteCarloSimulation(50000, newSeed);
      setMonteCarlo(updated);
      setIsSimulating(false);
    }, 400);
  };

  const currentMonetary = monetaryMap[selectedAsset] || monetaryMap.RUSD;

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0A0A0A] text-[#D1D5DB] font-mono p-1 overflow-hidden">
      {/* Top Header */}
      <Header
        env={env}
        setEnv={setEnv}
        selectedAsset={selectedAsset}
        setSelectedAsset={setSelectedAsset}
        dataQualityScore={dataQualityScore}
        isSimulating={isSimulating}
        onTriggerSimulation={handleTriggerSimulation}
      />

      {/* Navigation Sub-Observatory Tabs */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        anomalyCount={anomalies.length}
      />

      {/* Main Observatory Content Viewport */}
      <main className="flex-1 overflow-hidden relative bg-[#0a0a0a]">
        {activeTab === 'overview' && (
          <OverviewBento
            monetary={currentMonetary}
            selectedAsset={selectedAsset}
            kmData={kmData}
            risk={risk}
            anomalies={anomalies}
            dataQualityScore={dataQualityScore}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'validators' && (
          <ValidatorObservatory validators={validators} kmData={kmData} />
        )}

        {activeTab === 'monetary' && (
          <MonetaryObservatory
            monetaryMap={monetaryMap}
            selectedAsset={selectedAsset}
            setSelectedAsset={setSelectedAsset}
            accountDist={accountDist}
          />
        )}

        {activeTab === 'reserves' && (
          <ReservesStressObservatory
            reserve={reserve}
            stressScenarios={stressScenarios}
            monteCarlo={monteCarlo}
            onRunMonteCarlo={handleTriggerSimulation}
          />
        )}

        {activeTab === 'risk' && <RiskEngineObservatory risk={risk} />}

        {activeTab === 'forecasts' && (
          <ForecastingEconometricsObservatory etsData={etsData} econModels={econModels} />
        )}

        {activeTab === 'econometrics' && (
          <ForecastingEconometricsObservatory etsData={etsData} econModels={econModels} />
        )}

        {activeTab === 'anomalies' && (
          <AnomalyCrisisObservatory anomalies={anomalies} crisisTimeline={crisisTimeline} />
        )}

        {activeTab === 'crisis' && (
          <AnomalyCrisisObservatory anomalies={anomalies} crisisTimeline={crisisTimeline} />
        )}

        {activeTab === 'models' && <ModelRegistryReportsObservatory models={models} />}

        {activeTab === 'timemachine' && <TimeMachineObservatory />}
      </main>

      {/* System Footer */}
      <Footer />
    </div>
  );
}
