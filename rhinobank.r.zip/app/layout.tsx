import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RHINOBANK.R — Statistical Intelligence Overlay',
  description: 'Enterprise-Grade R Statistical, Econometric, Risk, Forecasting & Validator Analytics Platform for RHINOBANK.VALIDATOR',
  openGraph: {
    title: 'RHINOBANK.R — Statistical Intelligence Overlay',
    description: 'Enterprise-Grade R Statistical, Econometric, Risk, Forecasting & Validator Analytics Platform for RHINOBANK.VALIDATOR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'RHINOBANK.R — Statistical Intelligence Overlay',
    description: 'Enterprise-Grade R Statistical, Econometric, Risk, Forecasting & Validator Analytics Platform for RHINOBANK.VALIDATOR',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark h-full">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,700;1,400&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="h-full bg-[#0A0A0A] text-[#D1D5DB] font-mono selection:bg-[#F27D26] selection:text-black antialiased overflow-hidden" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
