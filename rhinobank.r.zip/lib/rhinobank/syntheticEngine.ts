import {
  ValidatorRecord,
  MonetarySupplyMetrics,
  AccountDistribution,
  ReserveCoverageMetrics,
  StressScenarioResult,
  SystemicRiskOverview,
  TimeSeriesForecastPoint,
  ForecastModelDiagnostics,
  AnomalyAlert,
  EconometricModel,
  ModelRegistryItem,
  CrisisTimelineStep,
  DataQualityReport
} from './types';
import { generateKaplanMeierCurve, runMonteCarloSimulation, calcGini, calcHHI } from './statsEngine';

export function getSyntheticDataQuality(): DataQualityReport {
  return {
    overall_score: 99.98,
    missingness_rate: 0.0001,
    duplicate_rate: 0.0,
    stale_observations: 2,
    outlier_count: 5,
    inconsistent_timestamps: 0,
    orphan_events: 0,
    reserve_consistency_score: 100.0,
    supply_consistency_score: 99.99,
    last_audit_timestamp: new Date().toISOString()
  };
}

export function getSyntheticValidators(): ValidatorRecord[] {
  const regions = ['US-EAST-1', 'EU-WEST-1', 'AP-NORTHEAST-1', 'US-WEST-2', 'EU-CENTRAL-1', 'SA-EAST-1'];
  const names = [
    'Aethelgard Custody Node 01', 'SilicaFlux Core Validator', 'Rhino Reserve Staking A',
    'Borealis Prime Node', 'Caledonia Tech Validator', 'Highland Capital PoS',
    'Aegis Financial Node', 'Titan Staking Vault', 'Apex Monetary Node',
    'Helios Consensus Engine', 'Vanguard Reserve Val 1', 'Meridian Quantitative',
    'Oberon Infrastructure', 'Valhalla Staking Lab', 'Nordic Treasury Node',
    'Quantum Validator 09', 'Sovereign Bank Node', 'Kestrel Consensus Unit',
    'Graphene PoS Cluster', 'Elysium Financial Node', 'Zion Treasury Validator'
  ];

  const totalStake = 500000000; // 500M staked total

  return names.map((name, i) => {
    // Generate Pareto-ish stake distribution
    const rawStake = Math.round(totalStake * Math.pow(0.82, i) * (1 + (i % 3) * 0.15));
    const stakeShare = rawStake / totalStake;
    const isUnderperforming = i === 3 || i === 12;
    const uptime = isUnderperforming ? 96.42 : 99.98 - (i * 0.02);
    const missedBlocks = isUnderperforming ? 142 : Math.floor(i * 1.5);
    const latency = isUnderperforming ? 284 : Math.round(38 + i * 4.2);
    const riskScore = isUnderperforming ? 0.742 : Number((0.08 + i * 0.02).toFixed(3));

    return {
      validator_id: `VAL_${1000 + i}`,
      name,
      node_address: `0x71f${i}a89c...${88 + i}`,
      region: regions[i % regions.length],
      stake: rawStake,
      stake_share: Number(stakeShare.toFixed(4)),
      uptime: Number(uptime.toFixed(2)),
      downtime_hours: Number(((100 - uptime) * 7.2).toFixed(1)),
      blocks_proposed: 14820 - i * 120,
      blocks_missed: missedBlocks,
      attestation_rate: Number((uptime - 0.05).toFixed(2)),
      proposal_success_rate: Number((100 - (missedBlocks / 148.2)).toFixed(2)),
      latency_ms: latency,
      peer_count: 64 - (i % 8),
      reward_rate_apy: Number((4.85 - i * 0.04).toFixed(2)),
      slash_events: i === 12 ? 1 : 0,
      failure_count: isUnderperforming ? 4 : (i % 2),
      mtbf_hours: isUnderperforming ? 840 : 4812 - i * 120,
      mttr_hours: isUnderperforming ? 3.4 : 0.8,
      risk_score: riskScore,
      reliability_score: Number((1 - riskScore).toFixed(3)),
      status: isUnderperforming ? 'DEGRADED' : 'ACTIVE'
    };
  });
}

export function getSyntheticMonetaryMetrics(): Record<string, MonetarySupplyMetrics> {
  return {
    RUSD: {
      asset: 'RUSD',
      total_supply: 14820000000,
      circulating_supply: 12450000000,
      treasury_supply: 2370000000,
      burned_supply: 420000000,
      daily_issuance: 12500000,
      daily_redemption: 6800000,
      net_issuance_24h: 5700000,
      issuance_velocity: 0.042,
      money_velocity_v: 2.84, // V = TxVol / Supply
      growth_rate_24h: 0.04,
      annualized_growth: 3.82,
      volatility_7d: 0.012
    },
    RGBP: {
      asset: 'RGBP',
      total_supply: 4200000000,
      circulating_supply: 3800000000,
      treasury_supply: 400000000,
      burned_supply: 95000000,
      daily_issuance: 3200000,
      daily_redemption: 1900000,
      net_issuance_24h: 1300000,
      issuance_velocity: 0.038,
      money_velocity_v: 3.12,
      growth_rate_24h: 0.03,
      annualized_growth: 2.95,
      volatility_7d: 0.009
    },
    REUR: {
      asset: 'REUR',
      total_supply: 6800000000,
      circulating_supply: 5900000000,
      treasury_supply: 900000000,
      burned_supply: 180000000,
      daily_issuance: 5100000,
      daily_redemption: 3400000,
      net_issuance_24h: 1700000,
      issuance_velocity: 0.041,
      money_velocity_v: 2.65,
      growth_rate_24h: 0.025,
      annualized_growth: 3.10,
      volatility_7d: 0.011
    },
    RJPY: {
      asset: 'RJPY',
      total_supply: 1850000000000,
      circulating_supply: 1650000000000,
      treasury_supply: 200000000000,
      burned_supply: 25000000000,
      daily_issuance: 1400000000,
      daily_redemption: 980000000,
      net_issuance_24h: 420000000,
      issuance_velocity: 0.029,
      money_velocity_v: 1.98,
      growth_rate_24h: 0.02,
      annualized_growth: 2.15,
      volatility_7d: 0.008
    },
    RCHF: {
      asset: 'RCHF',
      total_supply: 1800000000,
      circulating_supply: 1600000000,
      treasury_supply: 200000000,
      burned_supply: 35000000,
      daily_issuance: 950000,
      daily_redemption: 620000,
      net_issuance_24h: 330000,
      issuance_velocity: 0.022,
      money_velocity_v: 2.15,
      growth_rate_24h: 0.018,
      annualized_growth: 1.85,
      volatility_7d: 0.006
    }
  };
}

export function getAccountDistribution(): AccountDistribution {
  const lorenz = [
    { percentile: 0, cumulative_wealth: 0 },
    { percentile: 10, cumulative_wealth: 0.4 },
    { percentile: 20, cumulative_wealth: 1.2 },
    { percentile: 30, cumulative_wealth: 2.8 },
    { percentile: 40, cumulative_wealth: 5.1 },
    { percentile: 50, cumulative_wealth: 8.9 },
    { percentile: 60, cumulative_wealth: 14.5 },
    { percentile: 70, cumulative_wealth: 22.8 },
    { percentile: 80, cumulative_wealth: 35.2 },
    { percentile: 90, cumulative_wealth: 54.8 },
    { percentile: 95, cumulative_wealth: 69.4 },
    { percentile: 99, cumulative_wealth: 86.2 },
    { percentile: 100, cumulative_wealth: 100 }
  ];

  return {
    total_accounts: 100000,
    gini_coefficient: 0.684,
    hhi_index: 842.5,
    top_1_percent_share: 13.8,
    top_5_percent_share: 30.6,
    top_10_percent_share: 45.2,
    top_50_percent_share: 91.1,
    lorenz_curve: lorenz
  };
}

export function getReserveCoverageMetrics(): ReserveCoverageMetrics {
  return {
    eligible_reserve_value_usd: 16035000000, // $16.035B
    outstanding_liabilities_usd: 14820000000, // $14.82B
    reserve_coverage_ratio: 1.082, // 108.2%
    min_coverage_30d: 1.042,
    max_coverage_30d: 1.118,
    coverage_volatility: 0.014,
    probability_coverage_below_1: 0.0024, // 0.24%
    cash_buffer_usd: 3200000000,
    near_cash_usd: 6800000000,
    short_duration_sec_usd: 6035000000,
    liquidity_ratio: 0.672,
    liquidity_gap_usd: 0
  };
}

export function getStressScenarios(): StressScenarioResult[] {
  const liabilities = 14820000000;
  const reserves = 16035000000;
  const liquidCash = 3200000000 + 6800000000; // $10B liquid

  const scenarios = [5, 10, 20, 30, 50, 75, 90];

  return scenarios.map(pct => {
    const redemptionAmt = liabilities * (pct / 100);
    const remLiab = liabilities - redemptionAmt;
    const remRes = reserves - redemptionAmt;
    const coverage = remLiab > 0 ? remRes / remLiab : 1.0;
    const liquidityReq = redemptionAmt;
    const shortfall = Math.max(0, redemptionAmt - liquidCash);

    return {
      scenario_id: `STRESS_${pct}PCT`,
      name: `${pct}% Extreme Redemption Run`,
      redemption_pct: pct,
      remaining_reserves_usd: Math.round(remRes),
      remaining_liabilities_usd: Math.round(remLiab),
      post_stress_coverage: Number(coverage.toFixed(3)),
      liquidity_required_usd: Math.round(liquidityReq),
      shortfall_usd: Math.round(shortfall),
      survival_status: shortfall > 0 ? 'DEFICIT' : (coverage < 1.02 ? 'WARNING' : 'SAFE')
    };
  });
}

export function getSystemicRiskOverview(): SystemicRiskOverview {
  return {
    validator_risk: {
      overall_score: 0.124,
      rating: 'LOW',
      model_version: 'VAL_RISK_v2.4',
      confidence_interval: [0.102, 0.146],
      components: [
        { component_name: 'Node Availability', weight: 0.40, value: 0.08, contribution: 0.032, direction: 'NEUTRAL', description: '99.98% network average uptime' },
        { component_name: 'Latency Variance', weight: 0.20, value: 0.14, contribution: 0.028, direction: 'NEUTRAL', description: 'P95 latency under 120ms' },
        { component_name: 'Attestation Reliability', weight: 0.15, value: 0.09, contribution: 0.0135, direction: 'NEUTRAL', description: '99.85% success rate' },
        { component_name: 'Stake Concentration HHI', weight: 0.10, value: 0.22, contribution: 0.022, direction: 'NEUTRAL', description: 'HHI = 842.5 (Moderate)' },
        { component_name: 'Slashing History', weight: 0.10, value: 0.18, contribution: 0.018, direction: 'NEUTRAL', description: '1 isolated slash in 30d' },
        { component_name: 'Operational Variance', weight: 0.05, value: 0.21, contribution: 0.0105, direction: 'NEUTRAL', description: 'Geographic distribution stable' }
      ]
    },
    reserve_risk: {
      overall_score: 0.442,
      rating: 'MODERATE',
      model_version: 'RES_RISK_v3.1',
      confidence_interval: [0.410, 0.474],
      components: [
        { component_name: 'Coverage Ratio Headroom', weight: 0.35, value: 0.32, contribution: 0.112, direction: 'NEUTRAL', description: 'Coverage at 108.2%' },
        { component_name: 'Asset Haircut Volatility', weight: 0.25, value: 0.54, contribution: 0.135, direction: 'HIGH_RISK_INCREASE', description: 'Treasury yields fluctuating' },
        { component_name: 'Redemption Acceleration', weight: 0.20, value: 0.48, contribution: 0.096, direction: 'NEUTRAL', description: '$6.8M/day redemption velocity' },
        { component_name: 'Counterparty Concentration', weight: 0.20, value: 0.49, contribution: 0.098, direction: 'NEUTRAL', description: 'Custodian distribution 4 banks' }
      ]
    },
    liquidity_risk: {
      overall_score: 0.891,
      rating: 'CRITICAL',
      model_version: 'LIQ_STRESS_v1.8',
      confidence_interval: [0.852, 0.920],
      components: [
        { component_name: 'T+0 Cash Buffer', weight: 0.40, value: 0.92, contribution: 0.368, direction: 'HIGH_RISK_INCREASE', description: 'Cash buffer ($3.2B) strained in >70% redemption' },
        { component_name: 'Settlement Friction', weight: 0.30, value: 0.85, contribution: 0.255, direction: 'HIGH_RISK_INCREASE', description: 'Interbank clearing delay window' },
        { component_name: 'Collateral Haircut Gap', weight: 0.30, value: 0.89, contribution: 0.267, direction: 'HIGH_RISK_INCREASE', description: 'Short-duration liquidation lag' }
      ]
    },
    network_risk: {
      overall_score: 0.185,
      rating: 'LOW',
      model_version: 'NET_LATENCY_v4.0',
      confidence_interval: [0.160, 0.210],
      components: [
        { component_name: 'Mempool Queue Congestion', weight: 0.50, value: 0.18, contribution: 0.09, direction: 'NEUTRAL', description: 'Arrival intensity 1,240 tx/s' },
        { component_name: 'Block Propagation Lag', weight: 0.50, value: 0.19, contribution: 0.095, direction: 'NEUTRAL', description: 'P99 propagation 420ms' }
      ]
    },
    monetary_risk: {
      overall_score: 0.245,
      rating: 'LOW',
      model_version: 'MON_SUPPLY_v2.0',
      confidence_interval: [0.220, 0.270],
      components: [
        { component_name: 'Supply Expansion Velocity', weight: 0.60, value: 0.22, contribution: 0.132, direction: 'NEUTRAL', description: '3.82% annualized growth' },
        { component_name: 'Velocity Instability', weight: 0.40, value: 0.28, contribution: 0.113, direction: 'NEUTRAL', description: 'Money velocity V = 2.84' }
      ]
    },
    concentration_risk: {
      overall_score: 0.082,
      rating: 'LOW',
      model_version: 'CONC_GINI_v1.2',
      confidence_interval: [0.070, 0.094],
      components: [
        { component_name: 'Stake Gini Coefficient', weight: 0.50, value: 0.08, contribution: 0.04, direction: 'NEUTRAL', description: 'Gini = 0.24 across 21 nodes' },
        { component_name: 'Account Concentration HHI', weight: 0.50, value: 0.084, contribution: 0.042, direction: 'NEUTRAL', description: 'HHI = 842.5' }
      ]
    }
  };
}

export function getETSReserveForecast(): { forecast: TimeSeriesForecastPoint[]; diagnostics: ForecastModelDiagnostics } {
  const points: TimeSeriesForecastPoint[] = [];
  const baseCoverage = 1.082;
  const now = new Date();

  // 14 days history + 30 days forecast
  for (let i = -14; i <= 30; i++) {
    const d = new Date(now.getTime() + i * 86400000);
    const dateStr = d.toISOString().split('T')[0];

    if (i <= 0) {
      // Observed history
      const noise = Math.sin(i * 0.5) * 0.008 + (Math.random() - 0.5) * 0.004;
      const obs = baseCoverage + noise;
      points.push({
        timestamp: dateStr,
        observed: Number(obs.toFixed(4)),
        forecast: Number(obs.toFixed(4)),
        ci_lower_80: Number((obs - 0.005).toFixed(4)),
        ci_upper_80: Number((obs + 0.005).toFixed(4)),
        ci_lower_95: Number((obs - 0.009).toFixed(4)),
        ci_upper_95: Number((obs + 0.009).toFixed(4))
      });
    } else {
      // Forecast horizon
      const trend = -0.0002 * i; // slight trend
      const fc = baseCoverage + trend;
      const spread80 = 0.006 + Math.sqrt(i) * 0.003;
      const spread95 = 0.010 + Math.sqrt(i) * 0.005;

      points.push({
        timestamp: dateStr,
        forecast: Number(fc.toFixed(4)),
        ci_lower_80: Number((fc - spread80).toFixed(4)),
        ci_upper_80: Number((fc + spread80).toFixed(4)),
        ci_lower_95: Number((fc - spread95).toFixed(4)),
        ci_upper_95: Number((fc + spread95).toFixed(4))
      });
    }
  }

  return {
    forecast: points,
    diagnostics: {
      model_name: 'ETS(M,A,N) Holt-Winters Exponential Smoothing',
      horizon_days: 30,
      mae: 0.0034,
      rmse: 0.0042,
      mape: 0.31,
      sMAPE: 0.30,
      aic: -312.4,
      bic: -298.2,
      coverage_80: 0.812
    }
  };
}

export function getAnomalyAlerts(): AnomalyAlert[] {
  return [
    {
      alert_id: 'ALERT_9021',
      timestamp: new Date(Date.now() - 14 * 60000).toISOString(),
      metric: 'blocks_missed_spike',
      observed_value: 142,
      expected_value: 4.2,
      deviation_zscore: 4.82,
      severity: 'HIGH',
      confidence: 0.994,
      affected_entity: 'VAL_1003 (Borealis Prime Node)',
      model: 'CUSUM Change-Point Detector',
      statistical_explanation: 'Observed missed blocks (142) exceeds 4.82 standard deviations above rolling 7-day baseline (4.2 +/- 1.1). Probability of random occurrence p < 0.0001.'
    },
    {
      alert_id: 'ALERT_9018',
      timestamp: new Date(Date.now() - 120 * 60000).toISOString(),
      metric: 'redemption_velocity_shift',
      observed_value: 18.4,
      expected_value: 6.8,
      deviation_zscore: 3.12,
      severity: 'MEDIUM',
      confidence: 0.965,
      affected_entity: 'RESERVE_RUSD',
      model: 'EWMA Statistical Process Control',
      statistical_explanation: 'Daily redemption velocity shifted from $6.8M to $18.4M. EWMA control limit breached (p5 = $14.2M).'
    },
    {
      alert_id: 'ALERT_9005',
      timestamp: new Date(Date.now() - 480 * 60000).toISOString(),
      metric: 'mempool_latency_surge',
      observed_value: 420,
      expected_value: 110,
      deviation_zscore: 2.85,
      severity: 'MEDIUM',
      confidence: 0.942,
      affected_entity: 'NETWORK_MEMPOOL',
      model: 'Mahalanobis Distance Clustering',
      statistical_explanation: 'P99 block propagation latency spiked to 420ms due to temporary peer link congestion.'
    }
  ];
}

export function getEconometricModels(): EconometricModel[] {
  return [
    {
      model_id: 'ECON_VAR_01',
      formula: 'redemption_demand ~ issuance_rate + reserve_coverage_lag1 + velocity_lag1 + fee_rate',
      dependent_var: 'redemption_demand',
      r_squared: 0.842,
      adj_r_squared: 0.828,
      f_statistic: 61.42,
      p_value: 0.000001,
      coefficients: [
        { variable: '(Intercept)', estimate: 12.420, std_error: 2.140, t_stat: 5.80, p_val: 0.00001 },
        { variable: 'issuance_rate', estimate: 0.412, std_error: 0.082, t_stat: 5.02, p_val: 0.00004 },
        { variable: 'reserve_coverage_lag1', estimate: -8.140, std_error: 1.920, t_stat: -4.24, p_val: 0.0003 },
        { variable: 'velocity_lag1', estimate: 1.840, std_error: 0.410, t_stat: 4.48, p_val: 0.0001 },
        { variable: 'fee_rate', estimate: -0.120, std_error: 0.054, t_stat: -2.22, p_val: 0.028 }
      ]
    }
  ];
}

export function getModelRegistry(): ModelRegistryItem[] {
  return [
    {
      model_id: 'MOD_SURV_KM01',
      name: 'Kaplan-Meier Validator Survival Estimator',
      type: 'Survival / Reliability',
      version: 'v4.2.1',
      status: 'ACTIVE',
      dataset_version: 'DS_2026_Q3_v1',
      accuracy_metric: 'Concordance Index = 0.912',
      drift_status: 'STABLE',
      last_validated: '2026-09-01',
      author: 'Senior R Reliability Statistician'
    },
    {
      model_id: 'MOD_ETS_COV02',
      name: 'Holt-Winters Reserve Coverage ETS(M,A,N)',
      type: 'Time-Series Forecasting',
      version: 'v3.1.0',
      status: 'ACTIVE',
      dataset_version: 'DS_2026_Q3_v1',
      accuracy_metric: 'sMAPE = 0.30%',
      drift_status: 'STABLE',
      last_validated: '2026-09-02',
      author: 'Time Series Quantitative Analyst'
    },
    {
      model_id: 'MOD_MC_VAR03',
      name: 'Monte Carlo Extreme Tail Reserve Risk Engine',
      type: 'Stochastic Simulation',
      version: 'v5.0.0',
      status: 'ACTIVE',
      dataset_version: 'DS_2026_Q3_v1',
      accuracy_metric: 'VaR 99 Calibration = 99.12%',
      drift_status: 'STABLE',
      last_validated: '2026-09-03',
      author: 'Financial Risk Quantitative Engineer'
    },
    {
      model_id: 'MOD_VAR_ECON04',
      name: 'Vector Autoregression Monetary Transmission',
      type: 'Econometrics VAR',
      version: 'v1.4.2',
      status: 'VALIDATED',
      dataset_version: 'DS_2026_Q3_v1',
      accuracy_metric: 'R² = 0.842',
      drift_status: 'STABLE',
      last_validated: '2026-08-28',
      author: 'Monetary Econometrician'
    },
    {
      model_id: 'MOD_BAYES_SL05',
      name: 'Bayesian Slashing & Failure Hazard Prior',
      type: 'Bayesian Inference',
      version: 'v0.9.1',
      status: 'DRAFT',
      dataset_version: 'DS_2026_Q3_v1',
      accuracy_metric: 'MCMC Gelman-Rubin Rhat = 1.01',
      drift_status: 'STABLE',
      last_validated: '2026-09-02',
      author: 'Bayesian Statistician'
    }
  ];
}

export function getCrisisTimeline(): CrisisTimelineStep[] {
  return [
    {
      step: 'T0',
      time_label: 'Baseline (T0)',
      title: 'Normal Operational State',
      validator_reliability: 0.998,
      network_latency_ms: 42,
      redemption_demand_usd: 6800000,
      reserve_coverage: 1.082,
      liquidity_req_usd: 6800000,
      stake_concentration_hhi: 842.5,
      systemic_risk_index: 0.124,
      description: 'Network operating in steady-state equilibrium. 21 active validators, 108.2% reserve coverage.'
    },
    {
      step: 'T1',
      time_label: '+6 Hours (T1)',
      title: 'Exogenous Redemption Surge',
      validator_reliability: 0.995,
      network_latency_ms: 68,
      redemption_demand_usd: 125000000, // $125M surge
      reserve_coverage: 1.074,
      liquidity_req_usd: 125000000,
      stake_concentration_hhi: 842.5,
      systemic_risk_index: 0.285,
      description: 'Institutional redemptions rise 18x. Reserve assets liquidated into near-cash buffers.'
    },
    {
      step: 'T2',
      time_label: '+12 Hours (T2)',
      title: 'Reserve Asset Illiquidity Squeeze',
      validator_reliability: 0.988,
      network_latency_ms: 112,
      redemption_demand_usd: 480000000,
      reserve_coverage: 1.045,
      liquidity_req_usd: 480000000,
      stake_concentration_hhi: 855.0,
      systemic_risk_index: 0.542,
      description: 'Near-cash buffers depleted. Short-duration securities haircut gap emerges.'
    },
    {
      step: 'T3',
      time_label: '+18 Hours (T3)',
      title: 'Validator Cascading Failures',
      validator_reliability: 0.842, // 4 validators offline
      network_latency_ms: 380,
      redemption_demand_usd: 920000000,
      reserve_coverage: 1.018,
      liquidity_req_usd: 920000000,
      stake_concentration_hhi: 1140.0,
      systemic_risk_index: 0.785,
      description: 'Borealis Prime and 3 secondary validators drop offline under bandwidth saturation.'
    },
    {
      step: 'T4',
      time_label: '+24 Hours (T4)',
      title: 'Network Congestion & Latency Spike',
      validator_reliability: 0.792,
      network_latency_ms: 840,
      redemption_demand_usd: 1450000000,
      reserve_coverage: 0.992, // Coverage dips below 1.0
      liquidity_req_usd: 1450000000,
      stake_concentration_hhi: 1380.0,
      systemic_risk_index: 0.892,
      description: 'Block propagation latency exceeds 800ms. Reserve coverage ratio breaches 1.0 threshold.'
    },
    {
      step: 'T5',
      time_label: '+36 Hours (T5)',
      title: 'Transaction Queue Congestion Peak',
      validator_reliability: 0.760,
      network_latency_ms: 1250,
      redemption_demand_usd: 2100000000,
      reserve_coverage: 0.964,
      liquidity_req_usd: 2100000000,
      stake_concentration_hhi: 1520.0,
      systemic_risk_index: 0.941,
      description: 'Mempool queue length > 120,000 tx. Emergency treasury liquidity injection required.'
    },
    {
      step: 'T6',
      time_label: '+48 Hours (T6)',
      title: 'Monetary Authority Intervention & Recovery',
      validator_reliability: 0.965,
      network_latency_ms: 85,
      redemption_demand_usd: 140000000,
      reserve_coverage: 1.062,
      liquidity_req_usd: 140000000,
      stake_concentration_hhi: 890.0,
      systemic_risk_index: 0.210,
      description: 'Central bank standby facility activated. Validators restored. Systemic risk drops back.'
    }
  ];
}
