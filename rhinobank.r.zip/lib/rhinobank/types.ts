export type AssetCode = 'RUSD' | 'RGBP' | 'REUR' | 'RJPY' | 'RCHF';

export type EnvironmentMode = 'LOCAL' | 'DEVNET' | 'TESTNET' | 'STAGING' | 'PRODUCTION';

export type ModelStatus = 'DRAFT' | 'VALIDATED' | 'ACTIVE' | 'RETIRED';

export type AlertSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface DataQualityReport {
  overall_score: number;
  missingness_rate: number;
  duplicate_rate: number;
  stale_observations: number;
  outlier_count: number;
  inconsistent_timestamps: number;
  orphan_events: number;
  reserve_consistency_score: number;
  supply_consistency_score: number;
  last_audit_timestamp: string;
}

export interface ValidatorRecord {
  validator_id: string;
  name: string;
  node_address: string;
  region: string;
  stake: number;
  stake_share: number; // 0 to 1
  uptime: number; // %
  downtime_hours: number;
  blocks_proposed: number;
  blocks_missed: number;
  attestation_rate: number; // %
  proposal_success_rate: number; // %
  latency_ms: number;
  peer_count: number;
  reward_rate_apy: number;
  slash_events: number;
  failure_count: number;
  mtbf_hours: number; // Mean Time Between Failures
  mttr_hours: number; // Mean Time To Repair
  risk_score: number; // 0 to 1
  reliability_score: number; // 0 to 1
  status: 'ACTIVE' | 'JAILED' | 'DEGRADED' | 'OFFLINE';
}

export interface KaplanMeierPoint {
  time_hours: number;
  survival_probability: number;
  ci_lower: number;
  ci_upper: number;
  events_count: number;
  at_risk_count: number;
}

export interface MonetarySupplyMetrics {
  asset: AssetCode;
  total_supply: number;
  circulating_supply: number;
  treasury_supply: number;
  burned_supply: number;
  daily_issuance: number;
  daily_redemption: number;
  net_issuance_24h: number;
  issuance_velocity: number; // velocity of mints
  money_velocity_v: number; // V = TxVol / Supply
  growth_rate_24h: number; // percentage
  annualized_growth: number; // percentage
  volatility_7d: number;
}

export interface AccountDistribution {
  total_accounts: number;
  gini_coefficient: number; // 0 to 1
  hhi_index: number; // Herfindahl-Hirschman Index
  top_1_percent_share: number;
  top_5_percent_share: number;
  top_10_percent_share: number;
  top_50_percent_share?: number;
  lorenz_curve: { percentile: number; cumulative_wealth: number }[];
}

export interface ReserveCoverageMetrics {
  eligible_reserve_value_usd: number;
  outstanding_liabilities_usd: number;
  reserve_coverage_ratio: number; // eligible_reserve / liabilities
  min_coverage_30d: number;
  max_coverage_30d: number;
  coverage_volatility: number;
  probability_coverage_below_1: number;
  cash_buffer_usd: number;
  near_cash_usd: number;
  short_duration_sec_usd: number;
  liquidity_ratio: number;
  liquidity_gap_usd: number;
}

export interface StressScenarioResult {
  scenario_id: string;
  name: string;
  redemption_pct: number;
  remaining_reserves_usd: number;
  remaining_liabilities_usd: number;
  post_stress_coverage: number;
  liquidity_required_usd: number;
  shortfall_usd: number;
  survival_status: 'SAFE' | 'WARNING' | 'DEFICIT';
}

export interface RiskScoreComponent {
  component_name: string;
  weight: number;
  value: number; // 0 to 1
  contribution: number;
  direction: 'HIGH_RISK_INCREASE' | 'NEUTRAL' | 'RISK_DECREASE';
  description: string;
}

export interface RiskScoreDecomposition {
  overall_score: number; // 0 to 1
  rating: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH' | 'CRITICAL';
  model_version: string;
  confidence_interval: [number, number];
  components: RiskScoreComponent[];
}

export interface SystemicRiskOverview {
  validator_risk: RiskScoreDecomposition;
  reserve_risk: RiskScoreDecomposition;
  liquidity_risk: RiskScoreDecomposition;
  network_risk: RiskScoreDecomposition;
  monetary_risk: RiskScoreDecomposition;
  concentration_risk: RiskScoreDecomposition;
}

export interface TimeSeriesForecastPoint {
  timestamp: string;
  observed?: number;
  forecast: number;
  ci_lower_80: number;
  ci_upper_80: number;
  ci_lower_95: number;
  ci_upper_95: number;
}

export interface ForecastModelDiagnostics {
  model_name: string; // e.g. "ETS(M,A,N)", "ARIMA(1,1,2)"
  horizon_days: number;
  mae: number;
  rmse: number;
  mape: number;
  sMAPE: number;
  aic: number;
  bic: number;
  coverage_80: number;
}

export interface AnomalyAlert {
  alert_id: string;
  timestamp: string;
  metric: string;
  observed_value: number;
  expected_value: number;
  deviation_zscore: number;
  severity: AlertSeverity;
  confidence: number;
  affected_entity: string;
  model: string;
  statistical_explanation: string;
}

export interface EconometricModel {
  model_id: string;
  formula: string;
  dependent_var: string;
  r_squared: number;
  adj_r_squared: number;
  f_statistic: number;
  p_value: number;
  coefficients: { variable: string; estimate: number; std_error: number; t_stat: number; p_val: number }[];
}

export interface ModelRegistryItem {
  model_id: string;
  name: string;
  type: string;
  version: string;
  status: ModelStatus;
  dataset_version: string;
  accuracy_metric: string;
  drift_status: 'STABLE' | 'MODERATE_DRIFT' | 'DEGRADED';
  last_validated: string;
  author: string;
}

export interface CrisisTimelineStep {
  step: 'T0' | 'T1' | 'T2' | 'T3' | 'T4' | 'T5' | 'T6';
  time_label: string;
  title: string;
  validator_reliability: number;
  network_latency_ms: number;
  redemption_demand_usd: number;
  reserve_coverage: number;
  liquidity_req_usd: number;
  stake_concentration_hhi: number;
  systemic_risk_index: number;
  description: string;
}

export interface MonteCarloSummary {
  iterations: number;
  mean_reserve_coverage: number;
  var_95: number;
  var_99: number;
  cvar_99: number;
  execution_time_sec: number;
  distribution: { bin: string; count: number }[];
}
