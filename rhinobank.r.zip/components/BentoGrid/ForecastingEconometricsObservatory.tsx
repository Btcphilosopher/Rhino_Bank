import React from 'react';
import { TimeSeriesForecastPoint, ForecastModelDiagnostics, EconometricModel } from '../../lib/rhinobank/types';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip
} from 'recharts';
import { TrendingUp, LineChart, FileSpreadsheet } from 'lucide-react';

interface ForecastingEconometricsObservatoryProps {
  etsData: { forecast: TimeSeriesForecastPoint[]; diagnostics: ForecastModelDiagnostics };
  econModels: EconometricModel[];
}

export const ForecastingEconometricsObservatory: React.FC<ForecastingEconometricsObservatoryProps> = ({
  etsData,
  econModels,
}) => {
  const model = econModels[0];

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Forecast Section Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2">
        <div className="lg:col-span-8 bento-card p-4">
          <div className="flex justify-between items-center mb-2">
            <div>
              <h2 className="text-xs font-bold text-[#eee] uppercase flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#F27D26]" />
                Reserve Coverage ETS Holt-Winters Forecast Fan Chart
              </h2>
              <p className="text-[10px] text-[#666]">
                30-Day Forecast Horizon with 80% and 95% Prediction Interval Fan
              </p>
            </div>
            <span className="text-[9px] bg-[#22160d] border border-[#F27D26]/40 text-[#F27D26] px-2 py-1 rounded font-bold">
              forecast::ets()
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={etsData.forecast} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="fan80Grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F27D26" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F27D26" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="timestamp" stroke="#444" tick={{ fontSize: 8, fill: '#888' }} />
                <YAxis domain={['auto', 'auto']} stroke="#444" tick={{ fontSize: 9, fill: '#888' }} />
                <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#262626', color: '#eee', fontSize: '11px', fontFamily: 'monospace' }} />
                <Area dataKey="ci_upper_95" name="95% Upper CI" stroke="none" fill="#3d2212" fillOpacity={0.2} />
                <Area dataKey="ci_upper_80" name="80% Upper CI" stroke="none" fill="url(#fan80Grad)" />
                <Line type="monotone" dataKey="observed" name="Observed Coverage" stroke="#22c55e" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="forecast" name="Point Forecast" stroke="#F27D26" strokeWidth={2} strokeDasharray="4 4" dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Forecast Accuracy Metrics */}
        <div className="lg:col-span-4 bento-card p-4 flex flex-col justify-between">
          <div>
            <div className="text-[9px] text-[#888] uppercase font-bold mb-2">
              Rolling Origin Forecast Diagnostics
            </div>

            <div className="space-y-2.5">
              <div className="flex justify-between border-b border-[#222] pb-1">
                <span className="text-[#888]">Model</span>
                <span className="text-[#eee] font-bold">{etsData.diagnostics.model_name}</span>
              </div>
              <div className="flex justify-between border-b border-[#222] pb-1">
                <span className="text-[#888]">Mean Absolute Error (MAE)</span>
                <span className="text-green-400 font-bold">{etsData.diagnostics.mae}</span>
              </div>
              <div className="flex justify-between border-b border-[#222] pb-1">
                <span className="text-[#888]">Root Mean Sq Error (RMSE)</span>
                <span className="text-green-400 font-bold">{etsData.diagnostics.rmse}</span>
              </div>
              <div className="flex justify-between border-b border-[#222] pb-1">
                <span className="text-[#888]">Symmetric MAPE (sMAPE)</span>
                <span className="text-green-400 font-bold">{etsData.diagnostics.sMAPE}%</span>
              </div>
              <div className="flex justify-between border-b border-[#222] pb-1">
                <span className="text-[#888]">Akaike Inf Criterion (AIC)</span>
                <span className="text-[#eee] font-bold">{etsData.diagnostics.aic}</span>
              </div>
              <div className="flex justify-between border-b border-[#222] pb-1">
                <span className="text-[#888]">80% Interval Coverage</span>
                <span className="text-green-400 font-bold">{(etsData.diagnostics.coverage_80 * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>

          <div className="p-2 bg-[#0c0c0c] border border-[#222] rounded text-[9px] text-[#777] mt-2">
            MODEL VALIDATED via 365-day walk-forward out-of-sample backtest.
          </div>
        </div>
      </div>

      {/* Econometric Model Specification */}
      {model && (
        <div className="bento-card p-4 space-y-3">
          <div className="flex justify-between items-center border-b border-[#222] pb-2">
            <div className="flex items-center gap-2">
              <LineChart className="w-4 h-4 text-[#F27D26]" />
              <span className="font-bold text-sm text-[#eee]">ECONOMETRIC VECTOR AUTOREGRESSION (VAR) MODEL</span>
            </div>
            <span className="text-[10px] text-green-400 font-bold">R² = {model.r_squared} &bull; F-Stat = {model.f_statistic}</span>
          </div>

          <div className="p-2.5 bg-[#000] border border-[#222] rounded text-xs font-mono text-[#F27D26]">
            <strong>FORMULA:</strong> {model.formula}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-[11px]">
              <thead>
                <tr className="border-b border-[#222] bg-[#141414] text-[#888] text-[9px] uppercase">
                  <th className="p-2">Variable</th>
                  <th className="p-2">Coefficient Estimate</th>
                  <th className="p-2">Std Error</th>
                  <th className="p-2">t-Statistic</th>
                  <th className="p-2">p-Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e1e1e]">
                {model.coefficients.map((c, i) => (
                  <tr key={i} className="hover:bg-[#161616]">
                    <td className="p-2 font-bold text-[#eee]">{c.variable}</td>
                    <td className="p-2 text-[#ccc]">{c.estimate.toFixed(4)}</td>
                    <td className="p-2 text-[#888]">{c.std_error.toFixed(4)}</td>
                    <td className="p-2 text-[#888]">{c.t_stat.toFixed(2)}</td>
                    <td className="p-2 font-bold text-green-400">{c.p_val < 0.001 ? '< 0.001' : c.p_val}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
