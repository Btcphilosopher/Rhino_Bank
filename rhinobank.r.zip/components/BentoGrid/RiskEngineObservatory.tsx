import React, { useState } from 'react';
import { SystemicRiskOverview, RiskScoreDecomposition } from '../../lib/rhinobank/types';
import { Gauge, Info, AlertTriangle, ShieldCheck, CheckCircle } from 'lucide-react';

interface RiskEngineObservatoryProps {
  risk: SystemicRiskOverview;
}

export const RiskEngineObservatory: React.FC<RiskEngineObservatoryProps> = ({ risk }) => {
  const [selectedRiskKey, setSelectedRiskKey] = useState<keyof SystemicRiskOverview>('liquidity_risk');

  const riskMap: Record<keyof SystemicRiskOverview, { title: string; score: RiskScoreDecomposition }> = {
    validator_risk: { title: 'VALIDATOR RISK MODEL', score: risk.validator_risk },
    reserve_risk: { title: 'RESERVE RISK MODEL', score: risk.reserve_risk },
    liquidity_risk: { title: 'LIQUIDITY RISK MODEL', score: risk.liquidity_risk },
    network_risk: { title: 'NETWORK LATENCY RISK MODEL', score: risk.network_risk },
    monetary_risk: { title: 'MONETARY EXPANSION RISK MODEL', score: risk.monetary_risk },
    concentration_risk: { title: 'CONCENTRATION HHI RISK MODEL', score: risk.concentration_risk },
  };

  const current = riskMap[selectedRiskKey];

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Top Banner: Risk Categories Switcher */}
      <div className="bento-card p-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-[#F27D26]" />
            <span className="font-bold text-sm text-[#eee]">TRANSPARENT RISK SCORE DECOMPOSITION ENGINE</span>
          </div>
          <span className="text-[10px] text-[#888]">NO BLACK BOXES &bull; FULLY EXPLAINABLE</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {(Object.keys(riskMap) as (keyof SystemicRiskOverview)[]).map((key) => {
            const r = riskMap[key].score;
            const isSelected = selectedRiskKey === key;
            return (
              <button
                key={key}
                onClick={() => setSelectedRiskKey(key)}
                className={`p-2.5 rounded border text-left cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#1e1712] border-[#F27D26] text-[#F27D26]'
                    : 'bg-[#121212] border-[#222] text-[#888] hover:text-[#eee]'
                }`}
              >
                <div className="text-[9px] uppercase font-bold text-[#666] truncate">{key.replace('_risk', '')}</div>
                <div className={`text-lg font-bold mt-1 ${r.overall_score > 0.7 ? 'text-red-400' : r.overall_score > 0.3 ? 'text-yellow-400' : 'text-green-400'}`}>
                  {r.overall_score.toFixed(3)}
                </div>
                <div className="text-[8px] uppercase mt-0.5">{r.rating}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Detailed Risk Score Breakdown */}
      <div className="bento-card p-4 space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-[#222] pb-3">
          <div>
            <h2 className="text-sm font-bold text-[#eee] uppercase">{current.title}</h2>
            <p className="text-[10px] text-[#777] mt-0.5">
              Model Version: {current.score.model_version} &bull; 95% Confidence Interval: [{current.score.confidence_interval[0]}, {current.score.confidence_interval[1]}]
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-[9px] text-[#777] uppercase">Aggregated Score</div>
              <div className={`text-2xl font-bold ${current.score.overall_score > 0.7 ? 'text-red-400' : current.score.overall_score > 0.3 ? 'text-yellow-400' : 'text-green-400'}`}>
                {current.score.overall_score.toFixed(3)} / 1.000
              </div>
            </div>
          </div>
        </div>

        {/* Component Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="border-b border-[#222] bg-[#141414] text-[#888] text-[9px] uppercase">
                <th className="p-2.5">Component Variable</th>
                <th className="p-2.5">Weight</th>
                <th className="p-2.5">Observed Value</th>
                <th className="p-2.5">Weighted Contribution</th>
                <th className="p-2.5">Risk Direction</th>
                <th className="p-2.5">Mathematical Explanation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e1e1e]">
              {current.score.components.map((c, idx) => (
                <tr key={idx} className="hover:bg-[#161616]">
                  <td className="p-2.5 font-bold text-[#eee]">{c.component_name}</td>
                  <td className="p-2.5 text-[#888]">{(c.weight * 100).toFixed(0)}%</td>
                  <td className="p-2.5 text-[#ccc]">{c.value.toFixed(3)}</td>
                  <td className="p-2.5 font-bold text-[#F27D26]">{c.contribution.toFixed(4)}</td>
                  <td className="p-2.5">
                    {c.direction === 'HIGH_RISK_INCREASE' ? (
                      <span className="bg-red-950 text-red-400 border border-red-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                        HIGH RISK SHIFT
                      </span>
                    ) : (
                      <span className="bg-green-950 text-green-400 border border-green-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                        NEUTRAL / SAFE
                      </span>
                    )}
                  </td>
                  <td className="p-2.5 text-[#a1a1aa] text-[10px]">{c.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-[#0a0a0a] border border-[#222] rounded text-[10px] text-[#aaa]">
          <strong className="text-[#eee] uppercase">Methodology Standard (R Axiom 102):</strong>
          <p className="mt-1 text-[#888]">
            Overall Risk = &Sigma; (Component_Weight_i &times; Component_Score_i). All component bounds are strictly normalized to [0, 1]. Confidence intervals generated via 10,000 bootstrap resamples of historical telemetry.
          </p>
        </div>
      </div>
    </div>
  );
};
