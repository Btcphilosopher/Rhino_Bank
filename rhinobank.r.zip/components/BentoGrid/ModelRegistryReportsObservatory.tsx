import React, { useState } from 'react';
import { ModelRegistryItem } from '../../lib/rhinobank/types';
import { FileCheck, Download, CheckCircle, Shield, FileText } from 'lucide-react';

interface ModelRegistryReportsObservatoryProps {
  models: ModelRegistryItem[];
}

export const ModelRegistryReportsObservatory: React.FC<ModelRegistryReportsObservatoryProps> = ({ models }) => {
  const [reportFormat, setReportFormat] = useState<'MD' | 'JSON'>('MD');

  const generatedReportText = `
# DAILY RHINOBANK STATISTICAL & RISK REPORT
Date: ${new Date().toISOString().split('T')[0]}
Environment: PRODUCTION_NODE_04
System: RHINOBANK.R STATISTICAL INTELLIGENCE OVERLAY V.4.4.1

## 1. EXECUTIVE NETWORK SUMMARY
- Active Validators: 21 Nodes (Uptime Network Mean: 99.98%)
- Total Issued Supply (RUSD): 14,820,000,000 RUSD
- Money Velocity (V): 2.84
- Reserve Coverage Ratio: 108.2% (Eligible Reserves: $16.035B)
- Data Quality Score: 99.98%

## 2. SYSTEMIC RISK OVERVIEW
- Validator Risk Score: 0.124 (LOW)
- Reserve Risk Score: 0.442 (MODERATE)
- Liquidity Risk Score: 0.891 (CRITICAL - Buffer strained under >70% redemption run)
- Network Latency Risk: 0.185 (LOW)
- Stake Gini Concentration: 0.240 (LOW)

## 3. STOCHASTIC MONTE CARLO RESULTS
- Iterations: 1,000,000 runs
- 95% Value at Risk (VaR): 0.0418
- 99% Value at Risk (VaR): 0.8421
- 99% Conditional VaR (CVaR): 0.7104
- Status: CONVERGED

## 4. ANOMALY ALERTS SUMMARY
- 3 Active Alerts (1 High Severity Missed Block Spike on VAL_1003)
  `;

  const handleDownloadReport = () => {
    const content = reportFormat === 'MD' ? generatedReportText : JSON.stringify({ date: new Date().toISOString(), models, report: generatedReportText }, null, 2);
    const blob = new Blob([content], { type: reportFormat === 'MD' ? 'text/markdown' : 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RhinoBank_Daily_Report_${new Date().toISOString().split('T')[0]}.${reportFormat.toLowerCase()}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Model Governance Registry */}
      <div className="bento-card p-4 space-y-3">
        <div className="flex justify-between items-center border-b border-[#222] pb-2">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-[#F27D26]" />
            <h2 className="text-sm font-bold text-[#eee] uppercase">
              STATISTICAL MODEL GOVERNANCE REGISTRY
            </h2>
          </div>
          <span className="text-[10px] text-[#888]">MODEL RISK MANAGEMENT STANDARD</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="border-b border-[#222] bg-[#141414] text-[#888] text-[9px] uppercase">
                <th className="p-2.5">Model ID & Name</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5">Version</th>
                <th className="p-2.5">Accuracy Metric</th>
                <th className="p-2.5">Drift Status</th>
                <th className="p-2.5">Approval Status</th>
                <th className="p-2.5">Author</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e1e1e]">
              {models.map((m) => (
                <tr key={m.model_id} className="hover:bg-[#161616]">
                  <td className="p-2.5">
                    <div className="font-bold text-[#eee]">{m.name}</div>
                    <div className="text-[9px] text-[#666]">{m.model_id} &bull; Validated: {m.last_validated}</div>
                  </td>
                  <td className="p-2.5 text-[#aaa]">{m.type}</td>
                  <td className="p-2.5 font-bold text-[#F27D26]">{m.version}</td>
                  <td className="p-2.5 font-bold text-green-400">{m.accuracy_metric}</td>
                  <td className="p-2.5">
                    <span className="bg-green-950 text-green-400 border border-green-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                      {m.drift_status}
                    </span>
                  </td>
                  <td className="p-2.5 font-bold">
                    {m.status === 'ACTIVE' ? (
                      <span className="bg-[#22160d] text-[#F27D26] border border-[#F27D26]/40 px-1.5 py-0.5 rounded text-[8px]">
                        ACTIVE
                      </span>
                    ) : m.status === 'VALIDATED' ? (
                      <span className="bg-green-950 text-green-400 border border-green-800 px-1.5 py-0.5 rounded text-[8px]">
                        VALIDATED
                      </span>
                    ) : (
                      <span className="bg-[#1f1f1f] text-[#888] px-1.5 py-0.5 rounded text-[8px]">
                        DRAFT
                      </span>
                    )}
                  </td>
                  <td className="p-2.5 text-[#888]">{m.author}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Daily Automated Statistical Report Generator */}
      <div className="bento-card p-4 space-y-3">
        <div className="flex justify-between items-center border-b border-[#222] pb-2">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#F27D26]" />
            <h2 className="text-sm font-bold text-[#eee] uppercase">
              AUTOMATED DAILY RHINOBANK STATISTICAL REPORT
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-[#0a0a0a] border border-[#222] p-0.5 rounded text-[9px]">
              <button
                onClick={() => setReportFormat('MD')}
                className={`px-2 py-0.5 rounded font-bold cursor-pointer ${
                  reportFormat === 'MD' ? 'bg-[#F27D26] text-black' : 'text-[#888]'
                }`}
              >
                MARKDOWN
              </button>
              <button
                onClick={() => setReportFormat('JSON')}
                className={`px-2 py-0.5 rounded font-bold cursor-pointer ${
                  reportFormat === 'JSON' ? 'bg-[#F27D26] text-black' : 'text-[#888]'
                }`}
              >
                JSON
              </button>
            </div>

            <button
              onClick={handleDownloadReport}
              className="flex items-center gap-1.5 bg-[#F27D26] hover:bg-[#e06c15] text-black px-3 py-1 rounded font-bold cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>EXPORT REPORT</span>
            </button>
          </div>
        </div>

        <pre className="p-3 bg-[#000] border border-[#222] rounded text-[11px] text-[#aaa] font-mono whitespace-pre-wrap overflow-x-auto leading-relaxed">
          {generatedReportText}
        </pre>
      </div>
    </div>
  );
};
