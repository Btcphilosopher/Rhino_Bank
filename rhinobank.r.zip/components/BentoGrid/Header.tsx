import React from 'react';
import { EnvironmentMode, AssetCode } from '../../lib/rhinobank/types';
import { Activity, RefreshCw, ShieldCheck, Database, Cpu } from 'lucide-react';

interface HeaderProps {
  env: EnvironmentMode;
  setEnv: (e: EnvironmentMode) => void;
  selectedAsset: AssetCode;
  setSelectedAsset: (a: AssetCode) => void;
  dataQualityScore: number;
  isSimulating: boolean;
  onTriggerSimulation: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  env,
  setEnv,
  selectedAsset,
  setSelectedAsset,
  dataQualityScore,
  isSimulating,
  onTriggerSimulation,
}) => {
  return (
    <header className="flex flex-col lg:flex-row items-start lg:items-center justify-between border-b border-[#262626] px-4 py-2.5 mb-1 bg-[#121212] gap-3">
      {/* Brand & Subtitle */}
      <div className="flex items-center gap-3">
        <div className="bg-[#F27D26] px-2.5 py-1 text-black font-bold text-xs tracking-wider rounded-xs flex items-center gap-1.5 shadow-sm">
          <Database className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>RHINOBANK.R</span>
        </div>
        <div className="text-[11px] tracking-widest text-[#888888] font-mono hidden sm:block">
          STATISTICAL INTELLIGENCE OVERLAY // V.4.4.1-STABLE
        </div>
      </div>

      {/* Control Switchers & Live Metadata */}
      <div className="flex flex-wrap items-center gap-4 text-[10px] font-mono w-full lg:w-auto justify-between lg:justify-end">
        {/* Environment Selector */}
        <div className="flex items-center gap-1.5 bg-[#0a0a0a] border border-[#262626] px-2 py-1 rounded">
          <span className="text-[#666]">ENV:</span>
          <select
            value={env}
            onChange={(e) => setEnv(e.target.value as EnvironmentMode)}
            className="bg-transparent text-[#e5e7eb] font-mono font-bold focus:outline-none cursor-pointer"
          >
            <option value="LOCAL" className="bg-[#111]">LOCAL</option>
            <option value="DEVNET" className="bg-[#111]">DEVNET</option>
            <option value="TESTNET" className="bg-[#111]">TESTNET</option>
            <option value="STAGING" className="bg-[#111]">STAGING</option>
            <option value="PRODUCTION" className="bg-[#111]">PRODUCTION_NODE_04</option>
          </select>
        </div>

        {/* Currency Asset Selector */}
        <div className="flex items-center gap-1 bg-[#0a0a0a] border border-[#262626] p-0.5 rounded">
          {(['RUSD', 'RGBP', 'REUR', 'RJPY', 'RCHF'] as AssetCode[]).map((asset) => (
            <button
              key={asset}
              onClick={() => setSelectedAsset(asset)}
              className={`px-2 py-0.5 rounded text-[9px] font-bold transition-colors ${
                selectedAsset === asset
                  ? 'bg-[#F27D26] text-black'
                  : 'text-[#888] hover:text-[#eee]'
              }`}
            >
              {asset}
            </button>
          ))}
        </div>

        {/* R-Session Status Indicator */}
        <div className="flex items-center gap-2 bg-[#122016] border border-green-500/30 px-2.5 py-1 rounded text-green-400">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          <span className="font-bold">R-SESSION: ACTIVE</span>
        </div>

        {/* Data Quality Score */}
        <div className="flex items-center gap-1.5 text-[#a1a1aa]">
          <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
          <span>QUALITY: <strong className="text-green-400">{dataQualityScore}%</strong></span>
        </div>

        {/* Simulation / Recompute Button */}
        <button
          onClick={onTriggerSimulation}
          disabled={isSimulating}
          className="flex items-center gap-1.5 bg-[#1f1610] hover:bg-[#3d2212] border border-[#F27D26]/40 text-[#F27D26] px-2.5 py-1 rounded font-bold transition-colors disabled:opacity-50 cursor-pointer"
        >
          <RefreshCw className={`w-3 h-3 ${isSimulating ? 'animate-spin' : ''}`} />
          <span>{isSimulating ? 'COMPUTING...' : 'RERUN MONTE CARLO'}</span>
        </button>
      </div>
    </header>
  );
};
