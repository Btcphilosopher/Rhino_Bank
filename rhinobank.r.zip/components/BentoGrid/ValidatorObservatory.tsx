import React, { useState } from 'react';
import { ValidatorRecord, KaplanMeierPoint } from '../../lib/rhinobank/types';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area
} from 'recharts';
import { ShieldAlert, Search, Filter, AlertOctagon, CheckCircle } from 'lucide-react';

interface ValidatorObservatoryProps {
  validators: ValidatorRecord[];
  kmData: KaplanMeierPoint[];
}

export const ValidatorObservatory: React.FC<ValidatorObservatoryProps> = ({
  validators,
  kmData,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [regionFilter, setRegionFilter] = useState('ALL');
  const [sortField, setSortField] = useState<keyof ValidatorRecord>('stake');
  const [sortAsc, setSortAsc] = useState(false);

  // Filter & Sort
  const filtered = validators
    .filter((v) => {
      const matchSearch = v.name.toLowerCase().includes(searchTerm.toLowerCase()) || v.validator_id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchRegion = regionFilter === 'ALL' || v.region === regionFilter;
      return matchSearch && matchRegion;
    })
    .sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortAsc ? valA - valB : valB - valA;
      }
      return 0;
    });

  const handleSort = (field: keyof ValidatorRecord) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Top Banner: Validator Reliability & Survival Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2">
        <div className="lg:col-span-8 bento-card p-4 bg-[#0F0F0F] relative">
          <div className="flex justify-between items-center mb-2">
            <div>
              <h2 className="text-xs font-bold text-[#e5e7eb] uppercase tracking-wider flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-[#F27D26]" />
                Kaplan-Meier Validator Survival Function & Hazard Curve
              </h2>
              <p className="text-[10px] text-[#777777]">
                Reliability Engineering Model: survival::survfit(Surv(time_hours, event_failure) ~ cohort)
              </p>
            </div>
            <div className="text-[10px] bg-[#1a1a1a] border border-[#333] px-2 py-1 rounded text-[#888]">
              N = {validators.length} NODES
            </div>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={kmData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="valSurvGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F27D26" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F27D26" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time_hours" stroke="#444" tick={{ fontSize: 9, fill: '#888' }} unit="h" />
                <YAxis domain={[0, 1]} stroke="#444" tick={{ fontSize: 9, fill: '#888' }} />
                <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#262626', color: '#eee', fontSize: '11px', fontFamily: 'monospace' }} />
                <Area type="stepAfter" dataKey="survival_probability" name="S(t) Survival" stroke="#F27D26" strokeWidth={2} fill="url(#valSurvGrad)" />
                <Area type="stepAfter" dataKey="ci_lower" name="95% CI Lower" stroke="#F27D26" strokeDasharray="3 3" strokeWidth={0.8} fill="none" />
                <Area type="stepAfter" dataKey="ci_upper" name="95% CI Upper" stroke="#F27D26" strokeDasharray="3 3" strokeWidth={0.8} fill="none" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stake Concentration Stats */}
        <div className="lg:col-span-4 bento-card p-4 flex flex-col justify-between">
          <div>
            <div className="text-[9px] text-[#888] uppercase tracking-wider font-bold mb-2">
              Stake Concentration Metrics
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-[#222] pb-1.5">
                <span className="text-[#aaa]">Herfindahl-Hirschman (HHI)</span>
                <span className="text-green-400 font-bold">842.5 (MODERATE)</span>
              </div>
              <div className="flex justify-between items-center border-b border-[#222] pb-1.5">
                <span className="text-[#aaa]">Stake Gini Coefficient</span>
                <span className="text-green-400 font-bold">0.240 (LOW)</span>
              </div>
              <div className="flex justify-between items-center border-b border-[#222] pb-1.5">
                <span className="text-[#aaa]">Top 5 Validator Share</span>
                <span className="text-yellow-400 font-bold">42.8%</span>
              </div>
              <div className="flex justify-between items-center border-b border-[#222] pb-1.5">
                <span className="text-[#aaa]">Average MTBF</span>
                <span className="text-[#eee] font-bold">4,812 Hours</span>
              </div>
            </div>
          </div>

          <div className="p-2 bg-[#121212] border border-[#222] rounded text-[9px] text-[#777] mt-3">
            CONCENTRATION ALERT: <span className="text-green-400 font-bold">LOW RISK</span>
            <div>No single entity controls &gt;33% consensus threshold.</div>
          </div>
        </div>
      </div>

      {/* Validator Table Header & Filters */}
      <div className="bento-card p-3 flex flex-col md:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Search className="w-3.5 h-3.5 text-[#666]" />
          <input
            type="text"
            placeholder="Filter validators by name or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-[#0a0a0a] border border-[#222] text-[#eee] px-2.5 py-1 rounded text-xs focus:outline-none focus:border-[#F27D26] w-full md:w-64 font-mono"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <Filter className="w-3.5 h-3.5 text-[#666]" />
          <span className="text-[#777] text-[10px]">REGION:</span>
          <select
            value={regionFilter}
            onChange={(e) => setRegionFilter(e.target.value)}
            className="bg-[#0a0a0a] border border-[#222] text-[#eee] px-2 py-1 rounded text-xs font-mono focus:outline-none"
          >
            <option value="ALL">ALL REGIONS</option>
            <option value="US-EAST-1">US-EAST-1</option>
            <option value="EU-WEST-1">EU-WEST-1</option>
            <option value="AP-NORTHEAST-1">AP-NORTHEAST-1</option>
            <option value="EU-CENTRAL-1">EU-CENTRAL-1</option>
          </select>
        </div>
      </div>

      {/* Validator Ranked Table */}
      <div className="bento-card overflow-x-auto">
        <table className="w-full text-left border-collapse text-[11px] font-mono">
          <thead>
            <tr className="border-b border-[#262626] bg-[#141414] text-[#888888] uppercase text-[9px]">
              <th className="p-2.5">Validator</th>
              <th className="p-2.5 cursor-pointer hover:text-[#eee]" onClick={() => handleSort('stake')}>
                Stake Share {sortField === 'stake' ? (sortAsc ? '▲' : '▼') : ''}
              </th>
              <th className="p-2.5 cursor-pointer hover:text-[#eee]" onClick={() => handleSort('uptime')}>
                Uptime {sortField === 'uptime' ? (sortAsc ? '▲' : '▼') : ''}
              </th>
              <th className="p-2.5 cursor-pointer hover:text-[#eee]" onClick={() => handleSort('attestation_rate')}>
                Attestation % {sortField === 'attestation_rate' ? (sortAsc ? '▲' : '▼') : ''}
              </th>
              <th className="p-2.5 cursor-pointer hover:text-[#eee]" onClick={() => handleSort('latency_ms')}>
                Latency {sortField === 'latency_ms' ? (sortAsc ? '▲' : '▼') : ''}
              </th>
              <th className="p-2.5 cursor-pointer hover:text-[#eee]" onClick={() => handleSort('blocks_missed')}>
                Missed Blocks {sortField === 'blocks_missed' ? (sortAsc ? '▲' : '▼') : ''}
              </th>
              <th className="p-2.5 cursor-pointer hover:text-[#eee]" onClick={() => handleSort('risk_score')}>
                Risk Score {sortField === 'risk_score' ? (sortAsc ? '▲' : '▼') : ''}
              </th>
              <th className="p-2.5">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1e1e1e]">
            {filtered.map((val) => (
              <tr key={val.validator_id} className="hover:bg-[#151515] transition-colors">
                <td className="p-2.5">
                  <div className="font-bold text-[#eee]">{val.name}</div>
                  <div className="text-[9px] text-[#666]">{val.validator_id} &bull; {val.region}</div>
                </td>
                <td className="p-2.5">
                  <div>{(val.stake / 1000000).toFixed(1)}M</div>
                  <div className="text-[9px] text-[#888]">{(val.stake_share * 100).toFixed(2)}%</div>
                </td>
                <td className="p-2.5 font-bold text-green-400">
                  {val.uptime}%
                </td>
                <td className="p-2.5">
                  {val.attestation_rate}%
                </td>
                <td className="p-2.5">
                  <span className={val.latency_ms > 200 ? 'text-red-400 font-bold' : 'text-[#ccc]'}>
                    {val.latency_ms} ms
                  </span>
                </td>
                <td className="p-2.5">
                  <span className={val.blocks_missed > 20 ? 'text-red-400 font-bold' : 'text-[#888]'}>
                    {val.blocks_missed}
                  </span>
                </td>
                <td className="p-2.5 font-bold">
                  <span className={val.risk_score > 0.4 ? 'text-red-400' : 'text-green-400'}>
                    {val.risk_score.toFixed(3)}
                  </span>
                </td>
                <td className="p-2.5">
                  {val.status === 'DEGRADED' ? (
                    <span className="inline-flex items-center gap-1 bg-red-950 text-red-400 border border-red-800 px-1.5 py-0.5 rounded text-[9px] font-bold">
                      <AlertOctagon className="w-3 h-3" /> DEGRADED
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 bg-green-950 text-green-400 border border-green-800 px-1.5 py-0.5 rounded text-[9px] font-bold">
                      <CheckCircle className="w-3 h-3" /> ACTIVE
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
