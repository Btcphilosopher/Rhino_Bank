import React, { useState, useEffect } from 'react';
import { AnomalyAlert, CrisisTimelineStep } from '../../lib/rhinobank/types';
import {
  AlertTriangle,
  Flame,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  ShieldAlert,
  Activity
} from 'lucide-react';

interface AnomalyCrisisObservatoryProps {
  anomalies: AnomalyAlert[];
  crisisTimeline: CrisisTimelineStep[];
}

export const AnomalyCrisisObservatory: React.FC<AnomalyCrisisObservatoryProps> = ({
  anomalies,
  crisisTimeline,
}) => {
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentStepIdx((prev) => {
          if (prev >= crisisTimeline.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 3000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, crisisTimeline.length]);

  const activeStep = crisisTimeline[currentStepIdx] || crisisTimeline[0];

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Crisis Simulator Engine Header */}
      <div className="bento-card p-4 space-y-3 bg-[#110e0c]">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-[#2d1b10] pb-3">
          <div>
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#F27D26]" />
              <h2 className="text-sm font-bold text-[#eee] uppercase">
                CRISIS LABORATORY & SYSTEMIC CONTAGION SIMULATOR
              </h2>
            </div>
            <p className="text-[10px] text-[#888] mt-0.5">
              T0-T6 Systemic Shock Replay Engine & Quantitative Digital Thread Analysis
            </p>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="flex items-center gap-1.5 bg-[#F27D26] hover:bg-[#e06c15] text-black px-3 py-1.5 rounded font-bold transition-colors cursor-pointer"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlaying ? 'PAUSE REPLAY' : 'START REPLAY'}</span>
            </button>

            <button
              onClick={() => {
                setIsPlaying(false);
                setCurrentStepIdx(0);
              }}
              className="p-1.5 bg-[#222] hover:bg-[#333] text-[#aaa] rounded cursor-pointer"
              title="Reset to T0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setCurrentStepIdx((prev) => Math.min(prev + 1, crisisTimeline.length - 1))}
              className="p-1.5 bg-[#222] hover:bg-[#333] text-[#aaa] rounded cursor-pointer"
              title="Next Step"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Timeline Step Bar */}
        <div className="grid grid-cols-7 gap-1.5">
          {crisisTimeline.map((step, idx) => {
            const isActive = idx === currentStepIdx;
            const isPassed = idx < currentStepIdx;
            return (
              <button
                key={step.step}
                onClick={() => {
                  setIsPlaying(false);
                  setCurrentStepIdx(idx);
                }}
                className={`p-2 rounded border text-center transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#F27D26] text-black border-[#F27D26] font-bold shadow-md'
                    : isPassed
                    ? 'bg-[#22160d] text-[#F27D26] border-[#3d2212]'
                    : 'bg-[#141414] text-[#666] border-[#222] hover:text-[#eee]'
                }`}
              >
                <div className="text-[10px] font-bold">{step.step}</div>
                <div className="text-[8px] truncate">{step.time_label}</div>
              </button>
            );
          })}
        </div>

        {/* Current Replay Card */}
        <div className="bg-[#000] border border-[#2d1b10] p-4 rounded space-y-3">
          <div className="flex justify-between items-center border-b border-[#222] pb-2">
            <div>
              <span className="text-[10px] text-[#F27D26] font-bold uppercase">{activeStep.time_label}</span>
              <h3 className="text-base font-bold text-[#eee]">{activeStep.title}</h3>
            </div>
            <div className="text-right">
              <span className="text-[9px] text-[#777]">SYSTEMIC RISK INDEX</span>
              <div className={`text-xl font-bold ${activeStep.systemic_risk_index > 0.7 ? 'text-red-400' : 'text-green-400'}`}>
                {activeStep.systemic_risk_index.toFixed(3)}
              </div>
            </div>
          </div>

          <p className="text-xs text-[#ccc] leading-relaxed">{activeStep.description}</p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#222] text-center text-[10px]">
            <div className="bg-[#121212] p-2 rounded">
              <div className="text-[#666]">VALIDATOR RELIABILITY</div>
              <div className={`font-bold text-sm ${activeStep.validator_reliability < 0.9 ? 'text-red-400' : 'text-green-400'}`}>
                {(activeStep.validator_reliability * 100).toFixed(1)}%
              </div>
            </div>

            <div className="bg-[#121212] p-2 rounded">
              <div className="text-[#666]">NETWORK LATENCY</div>
              <div className={`font-bold text-sm ${activeStep.network_latency_ms > 300 ? 'text-red-400' : 'text-[#eee]'}`}>
                {activeStep.network_latency_ms} ms
              </div>
            </div>

            <div className="bg-[#121212] p-2 rounded">
              <div className="text-[#666]">REDEMPTION DEMAND</div>
              <div className="font-bold text-sm text-yellow-400">
                ${(activeStep.redemption_demand_usd / 1000000).toFixed(1)}M
              </div>
            </div>

            <div className="bg-[#121212] p-2 rounded">
              <div className="text-[#666]">RESERVE COVERAGE</div>
              <div className={`font-bold text-sm ${activeStep.reserve_coverage < 1.0 ? 'text-red-400' : 'text-green-400'}`}>
                {(activeStep.reserve_coverage * 100).toFixed(1)}%
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistical Anomaly Registry */}
      <div className="bento-card p-4 space-y-3">
        <div className="flex justify-between items-center border-b border-[#222] pb-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className="font-bold text-sm text-[#eee]">UNIFIED STATISTICAL ANOMALY REGISTRY</span>
          </div>
          <span className="text-[10px] text-[#888]">CUSUM &bull; EWMA &bull; MAHALANOBIS Z-SCORES</span>
        </div>

        <div className="space-y-3">
          {anomalies.map((a) => (
            <div key={a.alert_id} className="bg-[#141414] border border-[#262626] p-3 rounded space-y-2">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                    a.severity === 'HIGH' ? 'bg-red-950 text-red-400 border border-red-800' : 'bg-yellow-950 text-yellow-400 border border-yellow-800'
                  }`}>
                    {a.severity} SEVERITY
                  </span>
                  <span className="font-bold text-[#eee]">{a.metric}</span>
                </div>
                <div className="text-[10px] text-[#888]">
                  {new Date(a.timestamp).toLocaleTimeString()} &bull; ID: {a.alert_id}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] bg-[#0a0a0a] p-2 rounded">
                <div>
                  <span className="text-[#666]">Observed:</span> <strong className="text-[#eee]">{a.observed_value}</strong>
                </div>
                <div>
                  <span className="text-[#666]">Expected Baseline:</span> <strong className="text-[#888]">{a.expected_value}</strong>
                </div>
                <div>
                  <span className="text-[#666]">Deviation Z-Score:</span> <strong className="text-red-400">z = +{a.deviation_zscore}</strong>
                </div>
                <div>
                  <span className="text-[#666]">Detector Model:</span> <strong className="text-[#eee]">{a.model}</strong>
                </div>
              </div>

              <p className="text-[11px] text-[#ccc] bg-[#0a0a0a] p-2 rounded border border-[#1f1f1f]">
                <strong>STATISTICAL WHY:</strong> {a.statistical_explanation}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
