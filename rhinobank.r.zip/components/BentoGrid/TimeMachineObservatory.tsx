import React, { useState } from 'react';
import { History, Calendar, Cpu, Search, CheckCircle2 } from 'lucide-react';

export const TimeMachineObservatory: React.FC = () => {
  const [selectedEpoch, setSelectedEpoch] = useState(14820);
  const [selectedDate, setSelectedDate] = useState('2026-08-15');

  // Calculated historical reconstructed state based on selected epoch
  const reconstructedSupply = 12450000000 + (selectedEpoch - 10000) * 420000;
  const reconstructedCoverage = Number((1.095 - (selectedEpoch - 10000) * 0.000002).toFixed(3));
  const reconstructedValidatorsCount = 21;
  const reconstructedRisk = Number((0.110 + (selectedEpoch - 10000) * 0.000003).toFixed(3));

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Time Machine Header Card */}
      <div className="bento-card p-4 space-y-3 bg-[#0d0f14]">
        <div className="flex justify-between items-center border-b border-[#222] pb-2">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#F27D26]" />
            <h2 className="text-sm font-bold text-[#eee] uppercase">
              STATISTICAL TIME MACHINE & HISTORICAL REPLAY ENGINE
            </h2>
          </div>
          <span className="text-[10px] text-green-400 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            ZERO FUTURE INFORMATION LEAKAGE
          </span>
        </div>

        <p className="text-xs text-[#888]">
          Reconstruct the precise analytical state of RHINOBANK.VALIDATOR at any historical epoch or block height.
        </p>

        {/* Selection Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-[#000] p-3 rounded border border-[#222]">
          <div>
            <label className="text-[9px] text-[#888] uppercase block mb-1">Select Epoch Number</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={selectedEpoch}
                onChange={(e) => setSelectedEpoch(Number(e.target.value))}
                min="1"
                max="20000"
                className="bg-[#121212] border border-[#333] text-[#eee] px-3 py-1.5 rounded font-mono font-bold w-full focus:outline-none focus:border-[#F27D26]"
              />
              <span className="text-[10px] text-[#666]">EPOCH</span>
            </div>
          </div>

          <div>
            <label className="text-[9px] text-[#888] uppercase block mb-1">Select Snapshot Date</label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-[#121212] border border-[#333] text-[#eee] px-3 py-1.5 rounded font-mono text-xs w-full focus:outline-none focus:border-[#F27D26]"
              />
              <Calendar className="w-4 h-4 text-[#888]" />
            </div>
          </div>
        </div>

        {/* Reconstructed State Display */}
        <div className="p-4 bg-[#121212] border border-[#222] rounded space-y-3">
          <div className="text-xs font-bold text-[#F27D26] uppercase">
            RECONSTRUCTED HISTORICAL STATE &bull; EPOCH #{selectedEpoch} ({selectedDate})
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-[10px]">
            <div className="bg-[#000] p-2.5 rounded border border-[#222]">
              <div className="text-[#666]">RECONSTRUCTED SUPPLY</div>
              <div className="text-base font-bold text-[#eee] mt-1">
                ${(reconstructedSupply / 1000000000).toFixed(2)}B RUSD
              </div>
            </div>

            <div className="bg-[#000] p-2.5 rounded border border-[#222]">
              <div className="text-[#666]">RESERVE COVERAGE</div>
              <div className="text-base font-bold text-green-400 mt-1">
                {(reconstructedCoverage * 100).toFixed(1)}%
              </div>
            </div>

            <div className="bg-[#000] p-2.5 rounded border border-[#222]">
              <div className="text-[#666]">ACTIVE VALIDATORS</div>
              <div className="text-base font-bold text-[#eee] mt-1">
                {reconstructedValidatorsCount} Nodes
              </div>
            </div>

            <div className="bg-[#000] p-2.5 rounded border border-[#222]">
              <div className="text-[#666]">SYSTEMIC RISK INDEX</div>
              <div className="text-base font-bold text-green-400 mt-1">
                {reconstructedRisk}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
