import React, { useState } from 'react';
import {
  ReserveCoverageMetrics,
  StressScenarioResult,
  MonteCarloSummary
} from '../../lib/rhinobank/types';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';
import { Scale, ShieldAlert, Cpu, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ReservesStressObservatoryProps {
  reserve: ReserveCoverageMetrics;
  stressScenarios: StressScenarioResult[];
  monteCarlo: MonteCarloSummary;
  onRunMonteCarlo: () => void;
}

export const ReservesStressObservatory: React.FC<ReservesStressObservatoryProps> = ({
  reserve,
  stressScenarios,
  monteCarlo,
  onRunMonteCarlo,
}) => {
  const [customRedemptionPct, setCustomRedemptionPct] = useState(25);

  // Custom user scenario calculation
  const customRedemptionAmt = (reserve.outstanding_liabilities_usd * customRedemptionPct) / 100;
  const remRes = reserve.eligible_reserve_value_usd - customRedemptionAmt;
  const remLiab = reserve.outstanding_liabilities_usd - customRedemptionAmt;
  const customCoverage = remLiab > 0 ? remRes / remLiab : 1.0;
  const liquidCash = reserve.cash_buffer_usd + reserve.near_cash_usd;
  const customShortfall = Math.max(0, customRedemptionAmt - liquidCash);

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Top Banner: Reserve Coverage & Liquidity Ratios */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        <div className="bento-card p-3.5 border-l-2 border-l-green-500">
          <div className="text-[9px] text-[#888] uppercase font-bold">Reserve Coverage Ratio</div>
          <div className="text-2xl font-bold text-green-400 mt-1">
            {(reserve.reserve_coverage_ratio * 100).toFixed(1)}%
          </div>
          <div className="text-[9px] text-[#777] mt-0.5">
            Assets: ${(reserve.eligible_reserve_value_usd / 1000000000).toFixed(2)}B / Liab: ${(reserve.outstanding_liabilities_usd / 1000000000).toFixed(2)}B
          </div>
        </div>

        <div className="bento-card p-3.5 border-l-2 border-l-[#F27D26]">
          <div className="text-[9px] text-[#888] uppercase font-bold">T+0 Liquid Cash Buffer</div>
          <div className="text-2xl font-bold text-[#F27D26] mt-1">
            ${((reserve.cash_buffer_usd + reserve.near_cash_usd) / 1000000000).toFixed(2)}B
          </div>
          <div className="text-[9px] text-[#777] mt-0.5">
            Liquidity Ratio: {(reserve.liquidity_ratio * 100).toFixed(1)}% of total liabilities
          </div>
        </div>

        <div className="bento-card p-3.5 border-l-2 border-l-yellow-500">
          <div className="text-[9px] text-[#888] uppercase font-bold">Monte Carlo VaR (99%)</div>
          <div className="text-2xl font-bold text-yellow-400 mt-1">
            {(monteCarlo.var_99 * 100).toFixed(2)}%
          </div>
          <div className="text-[9px] text-[#777] mt-0.5">
            CVaR (Expected Tail Loss): {(monteCarlo.cvar_99 * 100).toFixed(2)}%
          </div>
        </div>

        <div className="bento-card p-3.5 border-l-2 border-l-red-500">
          <div className="text-[9px] text-[#888] uppercase font-bold">Deficit Probability (&lt;100%)</div>
          <div className="text-2xl font-bold text-red-400 mt-1">
            {(reserve.probability_coverage_below_1 * 100).toFixed(2)}%
          </div>
          <div className="text-[9px] text-[#777] mt-0.5">
            Calculated over N=50,000 stochastic runs
          </div>
        </div>
      </div>

      {/* Main Grid: Stress Matrix & Monte Carlo Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2">
        
        {/* Extreme Redemption Stress Matrix */}
        <div className="lg:col-span-7 bento-card p-4 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-xs font-bold uppercase text-[#eee] flex items-center gap-2">
                <Scale className="w-4 h-4 text-[#F27D26]" />
                Extreme Redemption Stress Matrix
              </h2>
              <span className="text-[9px] text-[#888]">AUTHORITATIVE STRESS TESTING</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-[11px]">
                <thead>
                  <tr className="border-b border-[#222] bg-[#141414] text-[#888] text-[9px] uppercase">
                    <th className="p-2">Scenario</th>
                    <th className="p-2">Redemption $</th>
                    <th className="p-2">Post Coverage</th>
                    <th className="p-2">Liquidity Shortfall</th>
                    <th className="p-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e1e1e]">
                  {stressScenarios.map((sc) => (
                    <tr key={sc.scenario_id} className="hover:bg-[#161616]">
                      <td className="p-2 font-bold text-[#eee]">{sc.name}</td>
                      <td className="p-2">${(sc.liquidity_required_usd / 1000000000).toFixed(2)}B</td>
                      <td className="p-2 font-bold">
                        <span className={sc.post_stress_coverage < 1.0 ? 'text-red-400' : 'text-green-400'}>
                          {(sc.post_stress_coverage * 100).toFixed(1)}%
                        </span>
                      </td>
                      <td className="p-2">
                        {sc.shortfall_usd > 0 ? (
                          <span className="text-red-400 font-bold">${(sc.shortfall_usd / 1000000000).toFixed(2)}B</span>
                        ) : (
                          <span className="text-green-400">$0.00 (Covered)</span>
                        )}
                      </td>
                      <td className="p-2">
                        {sc.survival_status === 'DEFICIT' ? (
                          <span className="bg-red-950 text-red-400 border border-red-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                            DEFICIT
                          </span>
                        ) : sc.survival_status === 'WARNING' ? (
                          <span className="bg-yellow-950 text-yellow-400 border border-yellow-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                            WARNING
                          </span>
                        ) : (
                          <span className="bg-green-950 text-green-400 border border-green-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                            SAFE
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Interactive Scenario Simulator Slider */}
          <div className="mt-4 pt-3 border-t border-[#222] bg-[#0c0c0c] p-3 rounded">
            <div className="flex justify-between items-center mb-1 text-[10px]">
              <span className="text-[#a1a1aa] font-bold uppercase">Custom Redemption Run Simulator</span>
              <span className="text-[#F27D26] font-bold">{customRedemptionPct}% Redemption Shock</span>
            </div>
            <input
              type="range"
              min="1"
              max="95"
              value={customRedemptionPct}
              onChange={(e) => setCustomRedemptionPct(Number(e.target.value))}
              className="w-full accent-[#F27D26] cursor-pointer"
            />
            <div className="grid grid-cols-3 gap-2 mt-2 text-center text-[10px]">
              <div className="bg-[#141414] p-1.5 rounded border border-[#222]">
                <div className="text-[#666]">REDEMPTION $</div>
                <div className="font-bold text-[#eee]">${(customRedemptionAmt / 1000000000).toFixed(2)}B</div>
              </div>
              <div className="bg-[#141414] p-1.5 rounded border border-[#222]">
                <div className="text-[#666]">POST COVERAGE</div>
                <div className={`font-bold ${customCoverage < 1.0 ? 'text-red-400' : 'text-green-400'}`}>
                  {(customCoverage * 100).toFixed(1)}%
                </div>
              </div>
              <div className="bg-[#141414] p-1.5 rounded border border-[#222]">
                <div className="text-[#666]">CASH SHORTFALL</div>
                <div className={`font-bold ${customShortfall > 0 ? 'text-red-400' : 'text-green-400'}`}>
                  ${(customShortfall / 1000000000).toFixed(2)}B
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Monte Carlo Simulated Distribution Chart */}
        <div className="lg:col-span-5 bento-card p-4 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-xs font-bold uppercase text-[#eee] flex items-center gap-2">
                <Cpu className="w-4 h-4 text-[#F27D26]" />
                Monte Carlo Simulated Coverage Distribution
              </h2>
              <button
                onClick={onRunMonteCarlo}
                className="text-[9px] bg-[#22160d] border border-[#F27D26]/40 text-[#F27D26] px-2 py-0.5 rounded font-bold cursor-pointer hover:bg-[#3d2212]"
              >
                RE-SIMULATE
              </button>
            </div>

            <p className="text-[10px] text-[#666] mb-3">
              Stochastic Normal + Tail Shock Distribution ({monteCarlo.iterations.toLocaleString()} runs)
            </p>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monteCarlo.distribution} margin={{ top: 5, right: 5, left: -25, bottom: 20 }}>
                  <XAxis dataKey="bin" stroke="#444" tick={{ fontSize: 7, fill: '#888' }} angle={-45} textAnchor="end" />
                  <YAxis stroke="#444" tick={{ fontSize: 8, fill: '#888' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#262626', color: '#eee', fontSize: '11px', fontFamily: 'monospace' }} />
                  <Bar dataKey="count" name="Frequency" fill="#F27D26">
                    {monteCarlo.distribution.map((entry, index) => {
                      const isTail = index < 3; // worst tail
                      return <Cell key={`cell-${index}`} fill={isTail ? '#ef4444' : '#F27D26'} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="p-2 bg-[#000] border border-[#222] rounded text-[10px] text-[#aaa] space-y-1 mt-2">
            <div>Mean Coverage: <strong className="text-[#eee]">{monteCarlo.mean_reserve_coverage}</strong></div>
            <div>95% Value at Risk (VaR): <strong className="text-yellow-400">{monteCarlo.var_95}</strong></div>
            <div>99% Value at Risk (VaR): <strong className="text-red-400">{monteCarlo.var_99}</strong></div>
            <div>99% Conditional VaR (CVaR): <strong className="text-red-500">{monteCarlo.cvar_99}</strong></div>
          </div>
        </div>
      </div>
    </div>
  );
};
