import React from 'react';
import {
  MonetarySupplyMetrics,
  KaplanMeierPoint,
  SystemicRiskOverview,
  AnomalyAlert,
  AssetCode
} from '../../lib/rhinobank/types';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';
import { AlertCircle, ArrowUpRight, Cpu, CheckCircle2, ShieldAlert } from 'lucide-react';

interface OverviewBentoProps {
  monetary: MonetarySupplyMetrics;
  selectedAsset: AssetCode;
  kmData: KaplanMeierPoint[];
  risk: SystemicRiskOverview;
  anomalies: AnomalyAlert[];
  dataQualityScore: number;
  onNavigateTab: (tab: any) => void;
}

export const OverviewBento: React.FC<OverviewBentoProps> = ({
  monetary,
  selectedAsset,
  kmData,
  risk,
  anomalies,
  dataQualityScore,
  onNavigateTab,
}) => {
  return (
    <div className="w-full h-full grid grid-cols-1 md:grid-cols-12 auto-rows-[minmax(120px,auto)] md:grid-rows-12 gap-2 overflow-y-auto p-1 font-mono text-xs">
      
      {/* 1. Monetary Supply Dynamics (col-span-3, row-span-4) */}
      <div className="md:col-span-3 md:row-span-4 bento-card p-3.5 flex flex-col justify-between relative overflow-hidden group">
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-[9px] text-[#888888] uppercase tracking-wider">Monetary Supply Dynamics</span>
            <span className="text-[9px] text-[#F27D26] bg-[#22160d] border border-[#F27D26]/30 px-1.5 py-0.5 rounded font-bold">
              {selectedAsset}
            </span>
          </div>
          <div className="text-2xl font-light text-[#E5E7EB] mt-1">
            {(monetary.total_supply / 1000000000).toFixed(2)}B{' '}
            <span className="text-xs text-[#888888] font-mono">{selectedAsset}</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-green-400 mt-1">
            <ArrowUpRight className="w-3 h-3" />
            <span>+{monetary.growth_rate_24h}% (24H Δ)</span>
            <span className="text-[#666666] ml-2">V = {monetary.money_velocity_v}</span>
          </div>
        </div>

        {/* Sparkline Bar Chart Visualizer */}
        <div className="mt-4 pt-2 border-t border-[#222222]">
          <div className="text-[9px] text-[#666666] mb-1.5 flex justify-between">
            <span>24H MINT/BURN VELOCITY</span>
            <span className="text-green-500">+${(monetary.net_issuance_24h / 1000000).toFixed(1)}M Net</span>
          </div>
          <div className="h-20 flex items-end gap-1.5 opacity-80">
            <div className="w-full bg-[#262626] h-[40%] rounded-xs hover:bg-[#333]"></div>
            <div className="w-full bg-[#262626] h-[55%] rounded-xs hover:bg-[#333]"></div>
            <div className="w-full bg-[#262626] h-[45%] rounded-xs hover:bg-[#333]"></div>
            <div className="w-full bg-[#262626] h-[70%] rounded-xs hover:bg-[#333]"></div>
            <div className="w-full bg-[#3d2f23] h-[65%] rounded-xs hover:bg-[#4d3d2e]"></div>
            <div className="w-full bg-[#F27D26] h-[88%] rounded-xs"></div>
          </div>
        </div>
      </div>

      {/* 2. Validator Survival Analysis Kaplan-Meier Chart (col-span-6, row-span-8) */}
      <div className="md:col-span-6 md:row-span-8 bento-card p-4 flex flex-col justify-between relative overflow-hidden bg-[#0F0F0F]">
        <div className="flex justify-between items-start mb-2 z-10">
          <div>
            <h2 className="text-xs uppercase tracking-widest text-[#a1a1aa] font-bold flex items-center gap-2">
              <ShieldAlert className="w-3.5 h-3.5 text-[#F27D26]" />
              Validator Survival Analysis
            </h2>
            <p className="text-[10px] text-[#666666] mt-0.5">
              Kaplan-Meier Estimated Reliability Curve (N=1,024 Nodes)
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('validators')}
            className="text-[10px] bg-[#1a1a1a] hover:bg-[#262626] border border-[#333333] text-[#F27D26] px-2.5 py-1 rounded cursor-pointer transition-colors"
          >
            METHOD: survival::survfit()
          </button>
        </div>

        {/* Recharts Kaplan Meier Curve */}
        <div className="w-full h-56 my-2 relative">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={kmData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="kmSurvivalGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F27D26" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#F27D26" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="time_hours" stroke="#444444" tick={{ fontSize: 9, fill: '#888888' }} unit="h" />
              <YAxis domain={[0, 1]} stroke="#444444" tick={{ fontSize: 9, fill: '#888888' }} />
              <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#262626', color: '#eee', fontSize: '11px', fontFamily: 'monospace' }} />
              <Area
                type="stepAfter"
                dataKey="survival_probability"
                name="S(t) Survival Prob"
                stroke="#F27D26"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#kmSurvivalGrad)"
              />
              <Area
                type="stepAfter"
                dataKey="ci_lower"
                name="95% CI Lower"
                stroke="#F27D26"
                strokeDasharray="3 3"
                strokeWidth={0.8}
                fill="none"
              />
              <Area
                type="stepAfter"
                dataKey="ci_upper"
                name="95% CI Upper"
                stroke="#F27D26"
                strokeDasharray="3 3"
                strokeWidth={0.8}
                fill="none"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Statistical Summary Footer */}
        <div className="flex justify-between items-center border-t border-[#222222] pt-3 text-[10px]">
          <div className="flex gap-4 text-[#888888]">
            <div>MTBF: <strong className="text-[#e5e7eb]">4,812.4H</strong></div>
            <div>MTTR: <strong className="text-[#e5e7eb]">0.8H</strong></div>
            <div>CONFIDENCE: <strong className="text-[#e5e7eb]">95% CI</strong></div>
          </div>
          <button
            onClick={() => onNavigateTab('validators')}
            className="text-[#F27D26] hover:underline font-bold flex items-center gap-1 cursor-pointer"
          >
            EXPLORE SURVIVAL COHORTS &rarr;
          </button>
        </div>
      </div>

      {/* 3. Systemic Risk Scores (col-span-3, row-span-6) */}
      <div className="md:col-span-3 md:row-span-6 bento-card p-3.5 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-3">
            <span className="text-[9px] text-[#888888] uppercase tracking-wider font-bold">
              Systemic Risk Scores
            </span>
            <button
              onClick={() => onNavigateTab('risk')}
              className="text-[9px] text-[#F27D26] hover:underline cursor-pointer"
            >
              DECOMPOSE
            </button>
          </div>

          <div className="space-y-3.5">
            {/* VALIDATOR_RISK */}
            <div className="flex flex-col">
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span className="text-[#a1a1aa]">VALIDATOR_RISK</span>
                <span className="text-green-400 font-bold">{risk.validator_risk.overall_score.toFixed(3)}</span>
              </div>
              <div className="h-1.5 bg-[#1f1f1f] rounded-full overflow-hidden">
                <div
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${risk.validator_risk.overall_score * 100}%` }}
                ></div>
              </div>
            </div>

            {/* RESERVE_RISK */}
            <div className="flex flex-col">
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span className="text-[#a1a1aa]">RESERVE_RISK</span>
                <span className="text-yellow-400 font-bold">{risk.reserve_risk.overall_score.toFixed(3)}</span>
              </div>
              <div className="h-1.5 bg-[#1f1f1f] rounded-full overflow-hidden">
                <div
                  className="h-full bg-yellow-500 rounded-full"
                  style={{ width: `${risk.reserve_risk.overall_score * 100}%` }}
                ></div>
              </div>
            </div>

            {/* LIQUIDITY_RISK */}
            <div className="flex flex-col">
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span className="text-[#a1a1aa]">LIQUIDITY_RISK</span>
                <span className="text-red-400 font-bold">{risk.liquidity_risk.overall_score.toFixed(3)}</span>
              </div>
              <div className="h-1.5 bg-[#1f1f1f] rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500 rounded-full animate-pulse"
                  style={{ width: `${risk.liquidity_risk.overall_score * 100}%` }}
                ></div>
              </div>
            </div>

            {/* CONCENTRATION */}
            <div className="flex flex-col">
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span className="text-[#a1a1aa]">CONCENTRATION_HHI</span>
                <span className="text-green-400 font-bold">{risk.concentration_risk.overall_score.toFixed(3)}</span>
              </div>
              <div className="h-1.5 bg-[#1f1f1f] rounded-full overflow-hidden">
                <div
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${risk.concentration_risk.overall_score * 100}%` }}
                ></div>
              </div>
            </div>

            {/* NETWORK_LATENCY_RISK */}
            <div className="flex flex-col">
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span className="text-[#a1a1aa]">NETWORK_LATENCY</span>
                <span className="text-green-400 font-bold">{risk.network_risk.overall_score.toFixed(3)}</span>
              </div>
              <div className="h-1.5 bg-[#1f1f1f] rounded-full overflow-hidden">
                <div
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${risk.network_risk.overall_score * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-2 bg-[#0c0c0c] border border-[#222222] rounded mt-3 text-[9px] text-[#777777]">
          WEIGHTED MODEL: <strong className="text-[#ddd]">RISK_ENGINE_v4.4</strong>
          <div className="text-red-400 mt-0.5">&bull; Liquidity Risk elevated due to T+0 buffer stress</div>
        </div>
      </div>

      {/* 4. Monte Carlo Engine Status (col-span-3, row-span-4) */}
      <div className="md:col-span-3 md:row-span-4 bento-card p-3.5 flex flex-col justify-between">
        <div>
          <div className="text-[9px] text-[#888888] uppercase tracking-wider mb-2 font-bold">
            Monte Carlo Engine
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Cpu className="w-5 h-5 text-[#F27D26]" />
            <div className="text-xl text-[#EEEEEE] font-light">1,000,000</div>
            <div className="text-[9px] text-[#666666] font-bold">ITERATIONS</div>
          </div>
          <div className="p-2.5 bg-[#000000] border border-[#222222] rounded font-mono text-[10px] text-[#aaaaaa]">
            <div>&gt; status: <span className="text-green-400 font-bold">CONVERGED</span></div>
            <div>&gt; tail_loss: <span className="text-red-400">1.2M RUSD</span></div>
            <div>&gt; var_99: <span className="text-yellow-400">0.8421</span></div>
            <div>&gt; cvar_99: <span className="text-red-400">0.7104</span></div>
            <div>&gt; run_time: <span className="text-[#888]">0.14s (PARALLEL)</span></div>
          </div>
        </div>
        <button
          onClick={() => onNavigateTab('reserves')}
          className="text-[9px] text-[#F27D26] hover:underline font-bold text-left cursor-pointer mt-2"
        >
          VIEW MONTE CARLO REDEMPTION FAN CHART &rarr;
        </button>
      </div>

      {/* 5. Anomaly Registry Feed (col-span-3, row-span-6) */}
      <div className="md:col-span-3 md:row-span-6 bento-card p-3.5 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-[9px] text-[#888888] uppercase tracking-wider font-bold">
              Anomaly Registry
            </span>
            <span className="text-[9px] bg-red-950 text-red-400 border border-red-800 px-1.5 py-0.2 rounded font-bold">
              {anomalies.length} ALERTS
            </span>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {anomalies.map((a) => (
              <div
                key={a.alert_id}
                className={`border-l-2 pl-2.5 py-1.5 bg-[#171717] rounded-r transition-colors ${
                  a.severity === 'HIGH'
                    ? 'border-red-500 bg-red-950/20'
                    : a.severity === 'MEDIUM'
                    ? 'border-yellow-500 bg-yellow-950/20'
                    : 'border-green-500'
                }`}
              >
                <div className="flex justify-between items-center">
                  <div className="text-[10px] font-bold text-[#eeeeee]">{a.metric}</div>
                  <div className="text-[8px] text-[#888888] font-mono">
                    z={a.deviation_zscore}
                  </div>
                </div>
                <div className="text-[9px] text-[#aaaaaa] mt-0.5 line-clamp-2">
                  {a.affected_entity}: {a.statistical_explanation}
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('anomalies')}
          className="text-[9px] text-[#F27D26] hover:underline font-bold text-left cursor-pointer mt-2"
        >
          OPEN STATISTICAL PROCESS CONTROL &rarr;
        </button>
      </div>

      {/* 6. Reserve Coverage Forecast (ETS) (col-span-6, row-span-4) */}
      <div className="md:col-span-6 md:row-span-4 bento-card p-3.5 flex flex-col justify-between">
        <div className="flex justify-between items-center mb-1">
          <span className="text-[9px] text-[#888888] uppercase tracking-wider font-bold">
            Reserve Coverage Forecast (ETS Holt-Winters)
          </span>
          <span className="text-[9px] text-[#888] font-mono">HORIZON: 30 DAYS</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-2">
          <div className="text-center border border-[#222222] bg-[#141414] p-2 rounded">
            <div className="text-[8px] text-[#777777] uppercase font-bold">P50 BASE</div>
            <div className="text-base font-bold text-[#ffffff]">1.042</div>
            <div className="text-[8px] text-green-400">Coverage Target</div>
          </div>

          <div className="text-center border border-[#222222] bg-[#141414] p-2 rounded">
            <div className="text-[8px] text-[#777777] uppercase font-bold">P95 UPPER</div>
            <div className="text-base font-bold text-[#ffffff]">1.089</div>
            <div className="text-[8px] text-green-400">High Reserve</div>
          </div>

          <div className="text-center border border-[#F27D26]/30 bg-[#1A130F] p-2 rounded">
            <div className="text-[8px] text-[#F27D26] uppercase font-bold">STRESS 10%</div>
            <div className="text-base font-bold text-[#F27D26]">0.921</div>
            <div className="text-[8px] text-[#F27D26]">Moderate Run</div>
          </div>

          <div className="text-center border border-red-500/30 bg-[#200F0F] p-2 rounded">
            <div className="text-[8px] text-red-400 uppercase font-bold">STRESS 50%</div>
            <div className="text-base font-bold text-red-400">0.684</div>
            <div className="text-[8px] text-red-400">Extreme Run</div>
          </div>
        </div>

        <div className="flex justify-between items-center text-[9px] text-[#888888] border-t border-[#222] pt-2">
          <span>MODEL: forecast::ets() [sMAPE: 0.30%]</span>
          <button
            onClick={() => onNavigateTab('forecasts')}
            className="text-[#F27D26] hover:underline font-bold cursor-pointer"
          >
            VIEW FORECAST FAN CHART &rarr;
          </button>
        </div>
      </div>

      {/* 7. Data Quality Score Badge (col-span-3, row-span-2) */}
      <div className="md:col-span-3 md:row-span-2 bento-card p-3.5 flex items-center justify-between">
        <div>
          <div className="text-[9px] text-[#888888] uppercase font-bold">DATA QUALITY SCORE</div>
          <div className="text-[10px] text-[#666666] mt-0.5">Zero unhandled missing values</div>
        </div>
        <div className="text-2xl font-bold text-green-400 flex items-center gap-1">
          <CheckCircle2 className="w-5 h-5" />
          <span>{dataQualityScore}%</span>
        </div>
      </div>

    </div>
  );
};
