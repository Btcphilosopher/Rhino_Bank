import React from 'react';
import {
  LayoutGrid,
  ShieldAlert,
  Coins,
  Scale,
  Gauge,
  TrendingUp,
  LineChart,
  AlertTriangle,
  Flame,
  FileCheck,
  History
} from 'lucide-react';

export type TabKey =
  | 'overview'
  | 'validators'
  | 'monetary'
  | 'reserves'
  | 'risk'
  | 'forecasts'
  | 'econometrics'
  | 'anomalies'
  | 'crisis'
  | 'models'
  | 'timemachine';

interface NavigationProps {
  activeTab: TabKey;
  setActiveTab: (tab: TabKey) => void;
  anomalyCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  anomalyCount,
}) => {
  const tabs: { key: TabKey; label: string; icon: React.ReactNode; badge?: number }[] = [
    { key: 'overview', label: 'BENTO OVERVIEW', icon: <LayoutGrid className="w-3.5 h-3.5" /> },
    { key: 'validators', label: 'VALIDATORS & SURVIVAL', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { key: 'monetary', label: 'MONETARY & VELOCITY', icon: <Coins className="w-3.5 h-3.5" /> },
    { key: 'reserves', label: 'RESERVES & STRESS', icon: <Scale className="w-3.5 h-3.5" /> },
    { key: 'risk', label: 'RISK DECOMPOSITION', icon: <Gauge className="w-3.5 h-3.5" /> },
    { key: 'forecasts', label: 'FORECASTING (ETS)', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { key: 'econometrics', label: 'ECONOMETRICS & VAR', icon: <LineChart className="w-3.5 h-3.5" /> },
    { key: 'anomalies', label: 'ANOMALY REGISTRY', icon: <AlertTriangle className="w-3.5 h-3.5" />, badge: anomalyCount },
    { key: 'crisis', label: 'CRISIS LABORATORY', icon: <Flame className="w-3.5 h-3.5 text-[#F27D26]" /> },
    { key: 'models', label: 'MODEL REGISTRY & REPORTS', icon: <FileCheck className="w-3.5 h-3.5" /> },
    { key: 'timemachine', label: 'TIME MACHINE', icon: <History className="w-3.5 h-3.5" /> },
  ];

  return (
    <nav className="flex items-center gap-1 border-b border-[#262626] bg-[#0d0d0d] px-2 py-1 overflow-x-auto text-[10px] font-mono no-scrollbar mb-1">
      {tabs.map((t) => {
        const isActive = activeTab === t.key;
        return (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xs transition-all whitespace-nowrap cursor-pointer ${
              isActive
                ? 'bg-[#1e1b18] text-[#F27D26] border border-[#F27D26]/40 font-bold shadow-xs'
                : 'text-[#888888] hover:text-[#dddddd] hover:bg-[#151515] border border-transparent'
            }`}
          >
            {t.icon}
            <span>{t.label}</span>
            {t.badge !== undefined && t.badge > 0 && (
              <span className="ml-1 bg-red-950 text-red-400 border border-red-800 px-1 py-0.2 text-[8px] rounded font-bold">
                {t.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
