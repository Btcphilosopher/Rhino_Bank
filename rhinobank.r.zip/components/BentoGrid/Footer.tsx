import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="h-8 border-t border-[#262626] bg-[#000000] flex items-center px-4 justify-between text-[9px] font-mono text-[#888888] shrink-0 mt-1">
      <div className="flex items-center gap-4">
        <span className="text-[#F27D26] font-bold">LOAD: 0.844</span>
        <span className="text-[#666666] hidden sm:inline">MEM: 4.2GB / 32GB</span>
        <span className="text-[#666666] hidden md:inline">PROCESSORS: 16 (PARALLEL)</span>
        <span className="text-[#888888] hidden lg:inline">&bull; R 4.4.1 ENGINE</span>
      </div>

      <div className="flex items-center gap-2">
        <div className="animate-pulse w-1.5 h-1.5 bg-green-500 rounded-full"></div>
        <span className="text-[#999999] uppercase tracking-wider text-[8px] sm:text-[9px]">
          Authoritative Consensus Observer // RHINO.INTELLIGENCE.SYSTEMS
        </span>
      </div>
    </footer>
  );
};
