import React from 'react';
import { MonetarySupplyMetrics, AccountDistribution, AssetCode } from '../../lib/rhinobank/types';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  LineChart,
  Line,
  BarChart,
  Bar
} from 'recharts';
import { Coins, TrendingUp, Users, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface MonetaryObservatoryProps {
  monetaryMap: Record<string, MonetarySupplyMetrics>;
  selectedAsset: AssetCode;
  setSelectedAsset: (asset: AssetCode) => void;
  accountDist: AccountDistribution;
}

export const MonetaryObservatory: React.FC<MonetaryObservatoryProps> = ({
  monetaryMap,
  selectedAsset,
  setSelectedAsset,
  accountDist,
}) => {
  const m = monetaryMap[selectedAsset] || monetaryMap.RUSD;

  // Generate synthetic supply history
  const supplyHistory = Array.from({ length: 30 }).map((_, i) => {
    const day = i - 30;
    const base = m.total_supply;
    const noise = Math.sin(i * 0.4) * (base * 0.002);
    const trend = (base * 0.0001) * i;
    return {
      day: `Day ${day}`,
      supply: Math.round(base + noise + trend),
      issuance: Math.round(m.daily_issuance * (1 + Math.sin(i) * 0.15)),
      redemption: Math.round(m.daily_redemption * (1 + Math.cos(i) * 0.15))
    };
  });

  return (
    <div className="w-full h-full overflow-y-auto p-2 space-y-3 font-mono text-xs">
      
      {/* Top Asset Switcher Bar */}
      <div className="bento-card p-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Coins className="w-4 h-4 text-[#F27D26]" />
          <span className="font-bold text-sm text-[#eee]">MULTI-ASSET MONETARY OVERLAY</span>
        </div>

        <div className="flex items-center gap-1.5">
          {(['RUSD', 'RGBP', 'REUR', 'RJPY', 'RCHF'] as AssetCode[]).map((a) => (
            <button
              key={a}
              onClick={() => setSelectedAsset(a)}
              className={`px-3 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                selectedAsset === a
                  ? 'bg-[#F27D26] text-black shadow-sm'
                  : 'bg-[#151515] border border-[#222] text-[#888] hover:text-[#eee]'
              }`}
            >
              {a}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        <div className="bento-card p-3.5">
          <div className="text-[9px] text-[#888] uppercase">Total Issued Supply</div>
          <div className="text-xl font-bold text-[#eee] mt-1">
            {(m.total_supply / 1000000000).toFixed(3)}B <span className="text-xs text-[#888]">{m.asset}</span>
          </div>
          <div className="text-[9px] text-green-400 mt-1 flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3" />
            <span>+{m.annualized_growth}% Annualized Growth</span>
          </div>
        </div>

        <div className="bento-card p-3.5">
          <div className="text-[9px] text-[#888] uppercase">Money Velocity (V = TxVol / M)</div>
          <div className="text-xl font-bold text-[#F27D26] mt-1">
            V = {m.money_velocity_v}
          </div>
          <div className="text-[9px] text-[#888] mt-1">
            Daily Tx Vol: ${(m.total_supply * m.money_velocity_v / 365 / 1000000).toFixed(1)}M
          </div>
        </div>

        <div className="bento-card p-3.5">
          <div className="text-[9px] text-[#888] uppercase">24H Gross Issuance</div>
          <div className="text-xl font-bold text-green-400 mt-1">
            +${(m.daily_issuance / 1000000).toFixed(2)}M
          </div>
          <div className="text-[9px] text-[#888] mt-1">Velocity: {m.issuance_velocity}</div>
        </div>

        <div className="bento-card p-3.5">
          <div className="text-[9px] text-[#888] uppercase">24H Gross Redemption</div>
          <div className="text-xl font-bold text-yellow-400 mt-1">
            -${(m.daily_redemption / 1000000).toFixed(2)}M
          </div>
          <div className="text-[9px] text-green-400 mt-1">
            Net: +${(m.net_issuance_24h / 1000000).toFixed(2)}M
          </div>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2">
        {/* Supply Trend & Issuance/Redemption */}
        <div className="lg:col-span-7 bento-card p-4">
          <div className="text-xs font-bold text-[#eee] uppercase mb-2 flex justify-between items-center">
            <span>Supply Expansion & Mint/Burn Flow (30 Days)</span>
            <span className="text-[9px] text-[#888]">{m.asset} MONETARY LEDGER</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={supplyHistory} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="monSupplyGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F27D26" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#F27D26" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="#444" tick={{ fontSize: 9, fill: '#888' }} />
                <YAxis stroke="#444" tick={{ fontSize: 9, fill: '#888' }} domain={['dataMin', 'dataMax']} />
                <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#262626', color: '#eee', fontSize: '11px', fontFamily: 'monospace' }} />
                <Area type="monotone" dataKey="supply" name="Total Supply" stroke="#F27D26" strokeWidth={2} fill="url(#monSupplyGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lorenz Curve Account Wealth Distribution */}
        <div className="lg:col-span-5 bento-card p-4 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-[#eee] uppercase mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-[#F27D26]" />
                Lorenz Curve & Wealth Gini
              </span>
              <span className="text-green-400 font-bold">Gini = {accountDist.gini_coefficient}</span>
            </div>
            <p className="text-[10px] text-[#666] mb-2">
              Concentration across N=100,000 active token accounts
            </p>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={accountDist.lorenz_curve} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="percentile" stroke="#444" tick={{ fontSize: 8, fill: '#888' }} unit="%" />
                  <YAxis stroke="#444" tick={{ fontSize: 8, fill: '#888' }} unit="%" />
                  <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#262626', color: '#eee', fontSize: '11px', fontFamily: 'monospace' }} />
                  <Line type="monotone" dataKey="cumulative_wealth" name="Cumulative Wealth %" stroke="#F27D26" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="percentile" name="Equality Line" stroke="#444444" strokeDasharray="3 3" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 border-t border-[#222] pt-2 text-center text-[10px]">
            <div>
              <div className="text-[#666]">TOP 1%</div>
              <div className="font-bold text-[#eee]">{accountDist.top_1_percent_share}%</div>
            </div>
            <div>
              <div className="text-[#666]">TOP 5%</div>
              <div className="font-bold text-[#eee]">{accountDist.top_5_percent_share}%</div>
            </div>
            <div>
              <div className="text-[#666]">TOP 10%</div>
              <div className="font-bold text-[#eee]">{accountDist.top_10_percent_share}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
