# Crestline — Independent Mobile Banking Concept

> **Independent concept • Synthetic accounts • No live banking.**  
> Crestline is a Chase-inspired mobile banking demonstration featuring a Jetpack Compose Android client and a Kotlin + Ktor + PostgreSQL backend with a balanced double-entry operational ledger.

## 1. Architecture & Implemented Components

### Android Client (`/app`)
- **UI & Design**: Jetpack Compose + Material 3 (`CrestlineTheme` light & dark themes, custom `Plus Jakarta Sans` / `Inter` / `JetBrains Mono` typography, `OctagonEmblem` geometric Canvas art, adaptive `CrestlineBottomBar` / `CrestlineNavRail`, reduced-motion support, accessible touch targets and content descriptions).
- **Navigation & State**: MVVM `BankingViewModel` with `StateFlow`, `collectAsStateWithLifecycle()`, and type-safe `@Serializable` Navigation Compose routes (`Home`, `Pay & transfer`, `Cards`, `Insights`, `AccountDetail`, `Deposit`, `NotificationsStatements`, `Profile`, `Assistant`).
- **Security & Local Storage**:
  - `SecurityCryptoManager`: Android Keystore (`AES/GCM/NoPadding`) encrypted session token storage in DataStore, PBKDF2-HMAC-SHA256 salted password hashing, TLS enforcement for non-local backend URLs.
  - `BiometricHelper`: `androidx.biometric.BiometricPrompt` for local device unlock & step-up confirmation without treating local biometric results as unrestricted backend authority.
  - `LogRedactor`: Redacts bearer tokens, passwords, card PANs, and cheque document payloads.
- **Authoritative Local Engine & Room Ledger (`AuthoritativeBankingEngine`)**:
  - Balanced double-entry journals (`sum(CREDIT) == sum(DEBIT)`) using `Long` minor units (cents) and explicit `"USD"` currency.
  - Internal transfer state machine (`Draft → Reviewed → Authorised → Processing → Completed / Rejected / Cancelled`), material-terms hash validation, optimistic account locking, idempotency keys, and fault simulation (`INSUFFICIENT_FUNDS`, `EXPIRED_SESSION`, `PROVIDER_FAILURE`, `LOST_TRANSFER_RESPONSE`).
  - Mock adapters for bill payments, scheduled-payment worker execution, synthetic cheque deposit validation (Play Policy zero-permission `PickVisualMedia`), card lock/unlock reconciliation (`desiredState` vs `issuerStatus`), spending insights (`$2,184.60`), reconciled statements, notifications with lock-screen redaction, and deterministic tool-backed assistant (`BankingAssistantEngine`).

### Backend Service (`/backend`)
- **Kotlin + Ktor 3.1 + PostgreSQL 16 + Flyway**:
  - Migrations: `V1__init_ledger.sql` and `V2__seed_demo_data.sql`
  - Endpoints: `/auth/login`, `/auth/refresh`, `/auth/logout`, `/accounts`, `/accounts/{id}/transactions`, `/transfers/preview`, `/transfers`, `/transfers/{id}`, `/cards`, `/cards/{id}/lock-requests`, `/insights/spending`, `/statements`, `/notifications`, `/webhooks/mock-rail` (HMAC-SHA256 verified)
  - OpenAPI 3.1 spec: `/backend/openapi/openapi.yaml`
  - Background worker coroutine for scheduled payments & reconciliation.

## 2. Startup Instructions

### Android App
Build debug APK or run Robolectric unit/UI tests:
```bash
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```
Demo customer credentials (pre-filled on the Sign-In screen):
- Email: `alex.morgan@crestline.demo`
- Password: `DemoPassword!2026`
- Optional MFA demo code: `482910`

### Backend (Docker Compose + PostgreSQL)
```bash
cd backend
cp .env.example .env
docker compose up --build
```
Run backend integration tests (uses H2 in PostgreSQL compatibility mode):
```bash
gradle -p backend test
```

## 3. What Is Simulated vs. Production Requirements
- **Simulated**: Payment rails (ACH/bill pay), cheque clearing, card-issuer lock adapter, synthetic customer accounts, and offline deterministic AI assistant.
- **Required Before Live Banking**: Licensed bank charter/sponsor-bank BaaS agreements, KYC/AML/OFAC screening, PCI-DSS compliant card tokenization/vaulting (Visa/Mastercard issuer processor integration), FedNow/ACH/Fedwire network connectivity, HSM key management, hardware-backed Play Integrity attestation, and external observability/SOC2 controls.
