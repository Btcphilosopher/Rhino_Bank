package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CustomerEntity::class,
        DeviceSessionEntity::class,
        AccountEntity::class,
        JournalEntity::class,
        LedgerLineEntity::class,
        PendingHoldEntity::class,
        TransferEntity::class,
        PayeeEntity::class,
        PaymentEntity::class,
        PaymentRequestEntity::class,
        DepositEntity::class,
        CardEntity::class,
        NotificationEntity::class,
        StatementEntity::class,
        OutboxActionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BankingDatabase : RoomDatabase() {
    abstract fun bankingDao(): BankingDao

    companion object {
        @Volatile
        private var INSTANCE: BankingDatabase? = null

        fun getInstance(context: Context): BankingDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BankingDatabase::class.java,
                    "crestline_ledger.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
