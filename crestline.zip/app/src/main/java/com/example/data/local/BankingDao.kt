package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BankingDao {

    @Query("SELECT COUNT(*) FROM customers")
    suspend fun countCustomers(): Int

    @Query("SELECT * FROM customers WHERE email = :email LIMIT 1")
    suspend fun getCustomerByEmail(email: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE customerId = :customerId LIMIT 1")
    suspend fun getCustomerById(customerId: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE customerId = :customerId LIMIT 1")
    fun observeCustomer(customerId: String): Flow<CustomerEntity?>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCustomer(customer: CustomerEntity)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    // Device sessions
    @Query("SELECT * FROM device_sessions WHERE customerId = :customerId ORDER BY isCurrentDevice DESC")
    fun observeSessions(customerId: String): Flow<List<DeviceSessionEntity>>

    @Query("SELECT * FROM device_sessions WHERE sessionId = :sessionId LIMIT 1")
    suspend fun getSession(sessionId: String): DeviceSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSession(session: DeviceSessionEntity)

    @Query("UPDATE device_sessions SET revoked = 1 WHERE sessionId = :sessionId AND customerId = :customerId")
    suspend fun revokeSession(sessionId: String, customerId: String)

    // Accounts
    @Query("SELECT * FROM accounts WHERE customerId = :customerId")
    fun observeAccounts(customerId: String): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE customerId = :customerId")
    suspend fun getAccountsForCustomer(customerId: String): List<AccountEntity>

    @Query("SELECT * FROM accounts WHERE accountId = :accountId LIMIT 1")
    suspend fun getAccount(accountId: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<AccountEntity>)

    @Query("UPDATE accounts SET version = version + 1 WHERE accountId = :accountId AND version = :expectedVersion")
    suspend fun bumpAccountVersion(accountId: String, expectedVersion: Long): Int

    // Journals & Ledger Lines (Double-Entry)
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertJournal(journal: JournalEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLedgerLines(lines: List<LedgerLineEntity>)

    @Query("SELECT * FROM ledger_lines WHERE accountId IN (SELECT accountId FROM accounts WHERE customerId = :customerId) ORDER BY timestampEpochMs DESC")
    fun observeCustomerLedgerLines(customerId: String): Flow<List<LedgerLineEntity>>

    @Query("SELECT * FROM ledger_lines WHERE accountId = :accountId ORDER BY timestampEpochMs DESC")
    suspend fun getLedgerLinesForAccount(accountId: String): List<LedgerLineEntity>

    @Query("SELECT * FROM ledger_lines WHERE journalId = :journalId")
    suspend fun getLinesForJournal(journalId: String): List<LedgerLineEntity>

    @Query("SELECT * FROM ledger_lines WHERE lineId = :lineId LIMIT 1")
    suspend fun getLedgerLine(lineId: String): LedgerLineEntity?

    @Query("UPDATE ledger_lines SET category = :category WHERE lineId = :lineId")
    suspend fun updateLedgerLineCategory(lineId: String, category: String)

    @Query("SELECT SUM(CASE WHEN direction = 'CREDIT' THEN amountCents ELSE -amountCents END) FROM ledger_lines")
    suspend fun verifyGlobalDoubleEntrySum(): Long?

    // Pending holds
    @Query("SELECT * FROM pending_holds WHERE accountId IN (SELECT accountId FROM accounts WHERE customerId = :customerId) AND active = 1 ORDER BY createdAtEpochMs DESC")
    fun observeActiveHolds(customerId: String): Flow<List<PendingHoldEntity>>

    @Query("SELECT * FROM pending_holds WHERE accountId = :accountId AND active = 1")
    suspend fun getActiveHoldsForAccount(accountId: String): List<PendingHoldEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHold(hold: PendingHoldEntity)

    @Query("UPDATE pending_holds SET active = 0 WHERE holdId = :holdId")
    suspend fun releaseHold(holdId: String)

    // Transfers
    @Query("SELECT * FROM transfers WHERE customerId = :customerId ORDER BY createdAtEpochMs DESC")
    fun observeTransfers(customerId: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getTransferByIdempotencyKey(key: String): TransferEntity?

    @Query("SELECT * FROM transfers WHERE transferId = :transferId LIMIT 1")
    suspend fun getTransfer(transferId: String): TransferEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTransfer(transfer: TransferEntity)

    // Payees, Payments, Requests
    @Query("SELECT * FROM payees WHERE customerId = :customerId")
    fun observePayees(customerId: String): Flow<List<PayeeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayee(payee: PayeeEntity)

    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY createdAtEpochMs DESC")
    fun observePayments(customerId: String): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE customerId = :customerId AND status = 'SCHEDULED'")
    suspend fun getScheduledPayments(customerId: String): List<PaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayment(payment: PaymentEntity)

    @Query("SELECT * FROM payment_requests WHERE customerId = :customerId ORDER BY createdAtEpochMs DESC")
    fun observePaymentRequests(customerId: String): Flow<List<PaymentRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPaymentRequest(request: PaymentRequestEntity)

    // Deposits
    @Query("SELECT * FROM deposits WHERE customerId = :customerId ORDER BY createdAtEpochMs DESC")
    fun observeDeposits(customerId: String): Flow<List<DepositEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDeposit(deposit: DepositEntity)

    // Cards
    @Query("SELECT * FROM cards WHERE customerId = :customerId")
    fun observeCards(customerId: String): Flow<List<CardEntity>>

    @Query("SELECT * FROM cards WHERE cardId = :cardId LIMIT 1")
    suspend fun getCard(cardId: String): CardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCard(card: CardEntity)

    // Notifications
    @Query("SELECT * FROM notifications WHERE customerId = :customerId ORDER BY createdAtEpochMs DESC")
    fun observeNotifications(customerId: String): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE customerId = :customerId")
    suspend fun markAllNotificationsRead(customerId: String)

    // Statements
    @Query("SELECT * FROM statements WHERE customerId = :customerId ORDER BY statementId DESC")
    fun observeStatements(customerId: String): Flow<List<StatementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatement(statement: StatementEntity)

    // Outbox
    @Query("SELECT * FROM outbox_actions WHERE customerId = :customerId ORDER BY createdAtEpochMs DESC")
    fun observeOutbox(customerId: String): Flow<List<OutboxActionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOutboxAction(action: OutboxActionEntity)

    @Query("DELETE FROM outbox_actions WHERE actionId = :actionId")
    suspend fun deleteOutboxAction(actionId: String)

    /**
     * Atomically posts a balanced double-entry journal inside a SQLite/Room transaction.
     * Verifies sum of credits == sum of debits before committing.
     */
    @Transaction
    suspend fun postBalancedJournalAtomically(
        journal: JournalEntity,
        lines: List<LedgerLineEntity>,
        accountIdToBump: String? = null,
        expectedVersion: Long? = null
    ) {
        val creditSum = lines.filter { it.direction == "CREDIT" }.sumOf { it.amountCents }
        val debitSum = lines.filter { it.direction == "DEBIT" }.sumOf { it.amountCents }
        require(creditSum > 0L && creditSum == debitSum) {
            "Unbalanced double-entry journal: credits=$creditSum, debits=$debitSum"
        }
        if (accountIdToBump != null && expectedVersion != null) {
            val updated = bumpAccountVersion(accountIdToBump, expectedVersion)
            check(updated == 1) { "Optimistic lock conflict on account $accountIdToBump" }
        }
        insertJournal(journal)
        insertLedgerLines(lines)
    }
}
