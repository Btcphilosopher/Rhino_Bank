package com.example.data.engine

import com.example.domain.AccountType
import com.example.domain.AssistantCitation
import com.example.domain.AssistantMessage
import com.example.domain.BankAccount
import com.example.domain.CurrencyFormatter
import com.example.domain.LedgerTransaction
import com.example.domain.PaymentInstruction
import com.example.domain.SpendingInsights
import com.example.domain.TransactionStatus
import java.util.UUID

/**
 * Deterministic, tool-backed mock AI assistant that operates without external model
 * credentials. Enforces strict guardrails:
 * - Cites real ledger references for every figure.
 * - Never fabricates activity, promises refunds, or gives investment advice.
 * - Never executes autonomous transfers, payments, payee changes, or card locks.
 */
object BankingAssistantEngine {

    fun respond(
        prompt: String,
        accounts: List<BankAccount>,
        transactions: List<LedgerTransaction>,
        insights: SpendingInsights?,
        payments: List<PaymentInstruction>
    ): AssistantMessage {
        val q = prompt.lowercase()
        val msgId = "ast_${UUID.randomUUID().toString().take(8)}"

        // Guardrail 1: Block autonomous financial actions
        if (listOf("send ", "transfer ", "move $", "pay ", "lock my card", "unlock my card", "add payee", "change payee")
                .any { q.contains(it) } && !q.contains("status") && !q.contains("how") && !q.contains("fee")
        ) {
            return AssistantMessage(
                id = msgId,
                fromUser = false,
                text = "I cannot execute transfers, payments, payee changes, or card controls autonomously. Every consequential action must go through your normal review and authorisation workflow.",
                suggestedRoute = if (q.contains("card") || q.contains("lock")) "CARDS" else "TRANSFER",
                suggestedActionLabel = if (q.contains("card") || q.contains("lock")) {
                    "Open Cards controls"
                } else {
                    "Open Pay & transfer review"
                }
            )
        }

        // Guardrail 2: Block unsupported personalised investment advice or refund promises
        if (q.contains("invest") || q.contains("stock") || q.contains("etf") || q.contains("crypto") || q.contains("buy ")) {
            return AssistantMessage(
                id = msgId,
                fromUser = false,
                text = "I cannot provide personalised investment advice or recommend securities. I can help explain your recorded balances, spending breakdown, fees, or statements using your synthetic ledger.",
                suggestedRoute = "INSIGHTS",
                suggestedActionLabel = "View spending insights"
            )
        }
        if (q.contains("refund") && (q.contains("promise") || q.contains("guarantee") || q.contains("give me"))) {
            return AssistantMessage(
                id = msgId,
                fromUser = false,
                text = "I cannot promise or issue refunds. If you see an unexpected posted charge, I can draft a support enquiry referencing the transaction ID for dispute review.",
                suggestedRoute = "ACCOUNT_CHECKING",
                suggestedActionLabel = "Review Checking activity"
            )
        }

        // Tool 1: Draft support enquiry
        if (q.contains("support") || q.contains("dispute") || q.contains("draft") || q.contains("enquiry")) {
            val latestDebit = transactions.firstOrNull { it.status == TransactionStatus.POSTED && it.amountCents > 0 }
            val refText = latestDebit?.let { "${it.description} (${CurrencyFormatter.formatCents(it.amountCents)}, ref: ${it.reference})" }
                ?: "recent ledger activity"
            return AssistantMessage(
                id = msgId,
                fromUser = false,
                text = "Here is a support enquiry draft grounded in your recorded ledger:\n\n" +
                    "\"Hello Crestline Support — I am requesting review of $refText. Please confirm settlement details and advise next steps. (Synthetic demonstration enquiry)\"",
                citations = listOfNotNull(
                    latestDebit?.let { AssistantCitation(it.description, it.reference) }
                )
            )
        }

        // Tool 2: Explain spending
        if (q.contains("spend") || q.contains("category") || q.contains("dining") || q.contains("shopping") || q.contains("travel")) {
            val total = insights?.totalCents ?: 0L
            val topCat = insights?.categories?.maxByOrNull { it.totalCents }
            val breakdown = insights?.categories?.joinToString(", ") {
                "${it.category.displayName}: ${CurrencyFormatter.formatCents(it.totalCents)}"
            } ?: "No category data"
            return AssistantMessage(
                id = msgId,
                fromUser = false,
                text = "Your recorded eligible spending for ${insights?.monthLabel ?: "this month"} totals ${CurrencyFormatter.formatCents(total)} ($breakdown). " +
                    "Top category is ${topCat?.category?.displayName ?: "N/A"}. Internal transfers, pending holds, and credit-card bill payments are excluded to avoid double-counting.",
                citations = transactions.take(3).map { AssistantCitation(it.description, it.reference) },
                suggestedRoute = "INSIGHTS",
                suggestedActionLabel = "Open Insights"
            )
        }

        // Tool 3: Explain fees or payment status
        if (q.contains("fee") || q.contains("payment") || q.contains("rent") || q.contains("pending")) {
            val pending = transactions.filter { it.status == TransactionStatus.PENDING }
            val scheduled = payments.firstOrNull()
            val pendingSummary = if (pending.isEmpty()) {
                "You currently have no pending holds."
            } else {
                "Pending holds: " + pending.joinToString("; ") {
                    "${it.description} (${CurrencyFormatter.formatCents(it.amountCents)}, ref: ${it.reference})"
                }
            }
            val paySummary = scheduled?.let {
                " Scheduled/recent payment: ${it.payeeName} for ${CurrencyFormatter.formatCents(it.amountCents)} (${it.status.name}, ref: ${it.reference})."
            } ?: ""
            return AssistantMessage(
                id = msgId,
                fromUser = false,
                text = "Internal transfers between your Checking and Savings accounts have a $0.00 fee in this synthetic demonstration. $pendingSummary$paySummary",
                citations = (pending.map { AssistantCitation(it.description, it.reference) } +
                    listOfNotNull(scheduled?.let { AssistantCitation(it.payeeName, it.reference) })).take(4)
            )
        }

        // Tool 4: Explain balances & authorised transactions
        val checking = accounts.firstOrNull { it.accountType == AccountType.CHECKING }
        val savings = accounts.firstOrNull { it.accountType == AccountType.SAVINGS }
        val credit = accounts.firstOrNull { it.accountType == AccountType.CREDIT_CARD }
        val combined = (checking?.availableBalanceCents ?: 0L) + (savings?.availableBalanceCents ?: 0L)
        return AssistantMessage(
            id = msgId,
            fromUser = false,
            text = "Summary from your verified ledger:\n" +
                "• Checking (${checking?.maskedNumber ?: "••••1842"}): ${CurrencyFormatter.formatCents(checking?.availableBalanceCents ?: 0L)} available " +
                "(posted ${CurrencyFormatter.formatCents(checking?.postedBalanceCents ?: 0L)})\n" +
                "• Savings (${savings?.maskedNumber ?: "••••6091"}): ${CurrencyFormatter.formatCents(savings?.availableBalanceCents ?: 0L)} available\n" +
                "• Combined deposits: ${CurrencyFormatter.formatCents(combined)}\n" +
                "• Credit card owed (kept separate): ${CurrencyFormatter.formatCents(credit?.postedBalanceCents ?: 0L)}\n" +
                "Ask me to explain a transaction, summarise spending, draft a support enquiry, or explain fees.",
            citations = transactions.take(3).map { AssistantCitation(it.description, it.reference) },
            suggestedRoute = "HOME",
            suggestedActionLabel = "View accounts"
        )
    }
}
