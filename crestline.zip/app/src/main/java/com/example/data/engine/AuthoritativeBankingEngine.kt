package com.example.data.engine

import com.example.data.local.AccountEntity
import com.example.data.local.BankingDao
import com.example.data.local.CardEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.DepositEntity
import com.example.data.local.DeviceSessionEntity
import com.example.data.local.JournalEntity
import com.example.data.local.LedgerLineEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.OutboxActionEntity
import com.example.data.local.PayeeEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.PaymentRequestEntity
import com.example.data.local.PendingHoldEntity
import com.example.data.local.SecurityCryptoManager
import com.example.data.local.StatementEntity
import com.example.data.local.StoredSessionTokens
import com.example.data.local.TransferEntity
import com.example.domain.AccountType
import com.example.domain.ApiOutcome
import com.example.domain.BankAccount
import com.example.domain.BankCard
import com.example.domain.BankStatement
import com.example.domain.CardDesiredState
import com.example.domain.CardIssuerStatus
import com.example.domain.CardType
import com.example.domain.CategoryBreakdown
import com.example.domain.CurrencyFormatter
import com.example.domain.CustomerProfile
import com.example.domain.DemoFaultMode
import com.example.domain.DepositStatus
import com.example.domain.DepositSubmission
import com.example.domain.DeviceSession
import com.example.domain.LedgerTransaction
import com.example.domain.LogRedactor
import com.example.domain.NotificationItem
import com.example.domain.Payee
import com.example.domain.PaymentInstruction
import com.example.domain.PaymentRequest
import com.example.domain.PaymentStatus
import com.example.domain.PendingHold
import com.example.domain.SpendingCategory
import com.example.domain.SpendingInsights
import com.example.domain.StatementLine
import com.example.domain.TransactionDirection
import com.example.domain.TransactionStatus
import com.example.domain.TransferRecord
import com.example.domain.TransferStatus
import com.example.domain.TransferTiming
import com.example.domain.UpcomingItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Authoritative local double-entry ledger & mock banking adapter engine backed by Room.
 * Enforces ownership checks, balanced journals (debits == credits), optimistic locking,
 * idempotency keys, material-terms verification, and configurable demo fault simulation.
 */
class AuthoritativeBankingEngine(
    private val dao: BankingDao,
    private val crypto: SecurityCryptoManager
) {
    private val ledgerMutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Volatile
    var activeFaultMode: DemoFaultMode = DemoFaultMode.NONE

    @Volatile
    var simulateOffline: Boolean = false

    companion object {
        const val DEMO_EMAIL = "alex.morgan@crestline.demo"
        const val DEMO_PASSWORD = "DemoPassword!2026"
        const val ALEX_CUSTOMER_ID = "cust_alex_morgan"
        const val CHECKING_ACCOUNT_ID = "acct_checking_1842"
        const val SAVINGS_ACCOUNT_ID = "acct_savings_6091"
        const val CREDIT_ACCOUNT_ID = "acct_credit_4477"
        private const val SYS_FUNDING = "sys_funding_usd"
        private const val SYS_MERCHANT_CLEARING = "sys_merchant_clearing_usd"
        private const val SYS_FEE_REVENUE = "sys_fee_revenue_usd"
        private const val MAX_SINGLE_TRANSFER_CENTS = 2_500_000L // $25,000.00
        private const val MAX_DEPOSIT_BYTES = 5L * 1024L * 1024L
        private val SUPPORTED_DEPOSIT_MIMES = setOf("image/png", "image/jpeg", "image/webp")
        private const val ACCESS_TTL_MS = 15 * 60 * 1000L
    }

    suspend fun ensureSeeded() {
        ledgerMutex.withLock {
            if (dao.countCustomers() > 0) return

            val (hashHex, saltHex) = SecurityCryptoManager.hashPassword(DEMO_PASSWORD)
            dao.insertCustomer(
                CustomerEntity(
                    customerId = ALEX_CUSTOMER_ID,
                    fullName = "Alex Morgan",
                    firstName = "Alex",
                    email = DEMO_EMAIL,
                    phoneMasked = "+1 (•••) •••-4821",
                    passwordHashHex = hashHex,
                    passwordSaltHex = saltHex,
                    mfaEnabled = false,
                    biometricEnabled = true,
                    lockScreenRedactionEnabled = true,
                    emailAlertsEnabled = true,
                    pushAlertsEnabled = true
                )
            )

            // Secondary customer to allow testing cross-customer access control boundaries
            val (otherHash, otherSalt) = SecurityCryptoManager.hashPassword("OtherUser!2026")
            dao.insertCustomer(
                CustomerEntity(
                    customerId = "cust_jordan_lee",
                    fullName = "Jordan Lee",
                    firstName = "Jordan",
                    email = "jordan.lee@crestline.demo",
                    phoneMasked = "+1 (•••) •••-9910",
                    passwordHashHex = otherHash,
                    passwordSaltHex = otherSalt,
                    mfaEnabled = false,
                    biometricEnabled = false,
                    lockScreenRedactionEnabled = true,
                    emailAlertsEnabled = true,
                    pushAlertsEnabled = true
                )
            )

            dao.insertAccounts(
                listOf(
                    AccountEntity(
                        accountId = SYS_FUNDING,
                        customerId = "SYSTEM",
                        name = "Synthetic Funding Vault",
                        accountType = AccountType.FUNDING.name,
                        maskedNumber = "SYS-FUND",
                        currency = "USD",
                        creditLimitCents = 0L,
                        statementBalanceCents = 0L,
                        minimumPaymentCents = 0L,
                        paymentDueDateLabel = null,
                        version = 1L
                    ),
                    AccountEntity(
                        accountId = SYS_MERCHANT_CLEARING,
                        customerId = "SYSTEM",
                        name = "Merchant Clearing Pool",
                        accountType = AccountType.CLEARING.name,
                        maskedNumber = "SYS-CLR",
                        currency = "USD",
                        creditLimitCents = 0L,
                        statementBalanceCents = 0L,
                        minimumPaymentCents = 0L,
                        paymentDueDateLabel = null,
                        version = 1L
                    ),
                    AccountEntity(
                        accountId = SYS_FEE_REVENUE,
                        customerId = "SYSTEM",
                        name = "Synthetic Fee Ledger",
                        accountType = AccountType.FEE.name,
                        maskedNumber = "SYS-FEE",
                        currency = "USD",
                        creditLimitCents = 0L,
                        statementBalanceCents = 0L,
                        minimumPaymentCents = 0L,
                        paymentDueDateLabel = null,
                        version = 1L
                    ),
                    AccountEntity(
                        accountId = CHECKING_ACCOUNT_ID,
                        customerId = ALEX_CUSTOMER_ID,
                        name = "Everyday Checking",
                        accountType = AccountType.CHECKING.name,
                        maskedNumber = "••••1842",
                        currency = "USD",
                        creditLimitCents = 0L,
                        statementBalanceCents = 0L,
                        minimumPaymentCents = 0L,
                        paymentDueDateLabel = null,
                        version = 1L
                    ),
                    AccountEntity(
                        accountId = SAVINGS_ACCOUNT_ID,
                        customerId = ALEX_CUSTOMER_ID,
                        name = "Savings",
                        accountType = AccountType.SAVINGS.name,
                        maskedNumber = "••••6091",
                        currency = "USD",
                        creditLimitCents = 0L,
                        statementBalanceCents = 0L,
                        minimumPaymentCents = 0L,
                        paymentDueDateLabel = null,
                        version = 1L
                    ),
                    AccountEntity(
                        accountId = CREDIT_ACCOUNT_ID,
                        customerId = ALEX_CUSTOMER_ID,
                        name = "Credit card balance",
                        accountType = AccountType.CREDIT_CARD.name,
                        maskedNumber = "••••4477",
                        currency = "USD",
                        creditLimitCents = 600_000L,
                        statementBalanceCents = 98_460L,
                        minimumPaymentCents = 3_500L,
                        paymentDueDateLabel = "Dec 12",
                        version = 1L
                    ),
                    AccountEntity(
                        accountId = "acct_jordan_checking",
                        customerId = "cust_jordan_lee",
                        name = "Jordan Checking",
                        accountType = AccountType.CHECKING.name,
                        maskedNumber = "••••7701",
                        currency = "USD",
                        creditLimitCents = 0L,
                        statementBalanceCents = 0L,
                        minimumPaymentCents = 0L,
                        paymentDueDateLabel = null,
                        version = 1L
                    )
                )
            )

            // Seed balanced double-entry journals reconciling to exact prompt & mockup figures:
            // Checking Posted = $8,426.98, Pending hold = $6.80 -> Available = $8,420.18
            // Savings Available = $16,440.24
            // Combined Deposit Available = $24,860.42
            // Credit Card Owed = $1,284.60
            // Insights Monthly Spending = Dining $420.00 + Shopping $680.00 + Travel $540.00 + Other $544.60 = $2,184.60
            val baseMs = 1794800000000L
            seedDoubleEntry(
                journalId = "jrn_seed_chk_open",
                customerId = ALEX_CUSTOMER_ID,
                ref = "OPEN-CHK-1842",
                desc = "Opening Balance Carryover",
                merchant = "Crestline Synthetic Treasury",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_FUNDING,
                amountCents = 607_698L,
                accountDirection = TransactionDirection.CREDIT,
                category = SpendingCategory.EXCLUDED,
                tsMs = baseMs + 1_000L,
                tsLabel = "Nov 1, 9:00 AM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_sav_open",
                customerId = ALEX_CUSTOMER_ID,
                ref = "OPEN-SAV-6091",
                desc = "Opening Savings Balance",
                merchant = "Crestline Synthetic Treasury",
                accountId = SAVINGS_ACCOUNT_ID,
                counterAccountId = SYS_FUNDING,
                amountCents = 1_640_210L,
                accountDirection = TransactionDirection.CREDIT,
                category = SpendingCategory.EXCLUDED,
                tsMs = baseMs + 2_000L,
                tsLabel = "Nov 1, 9:00 AM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_sav_int",
                customerId = ALEX_CUSTOMER_ID,
                ref = "INT-202611-6091",
                desc = "Monthly Interest Credit",
                merchant = "Crestline Yield Engine",
                accountId = SAVINGS_ACCOUNT_ID,
                counterAccountId = SYS_FUNDING,
                amountCents = 3_814L,
                accountDirection = TransactionDirection.CREDIT,
                category = SpendingCategory.EXCLUDED,
                tsMs = baseMs + 3_000L,
                tsLabel = "Nov 1, 9:05 AM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_chk_util",
                customerId = ALEX_CUSTOMER_ID,
                ref = "ACH-20261105-4410",
                desc = "City Electric & Fiber",
                merchant = "City Electric & Fiber",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 27_580L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.OTHER,
                tsMs = baseMs + 100_000L,
                tsLabel = "Nov 5, 10:15 AM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_cc_cloud",
                customerId = ALEX_CUSTOMER_ID,
                ref = "CRD-20261106-1190",
                desc = "Cloud & Media Subscriptions",
                merchant = "Cloud & Media",
                accountId = CREDIT_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 18_460L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.OTHER,
                tsMs = baseMs + 150_000L,
                tsLabel = "Nov 6, 11:00 AM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_chk_home",
                customerId = ALEX_CUSTOMER_ID,
                ref = "DEB-20261108-2218",
                desc = "Nordic Home Goods",
                merchant = "Nordic Home Goods",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 28_000L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.SHOPPING,
                tsMs = baseMs + 200_000L,
                tsLabel = "Nov 8, 2:40 PM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_cc_air",
                customerId = ALEX_CUSTOMER_ID,
                ref = "CRD-20261109-3304",
                desc = "Skyline Air",
                merchant = "Skyline Air",
                accountId = CREDIT_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 40_000L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.TRAVEL,
                tsMs = baseMs + 250_000L,
                tsLabel = "Nov 9, 4:10 PM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_chk_dining",
                customerId = ALEX_CUSTOMER_ID,
                ref = "DEB-20261110-5092",
                desc = "Harbor Bistro",
                merchant = "Harbor Bistro",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 12_000L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.DINING,
                tsMs = baseMs + 300_000L,
                tsLabel = "Nov 10, 7:55 PM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_cc_apparel",
                customerId = ALEX_CUSTOMER_ID,
                ref = "CRD-20261111-6642",
                desc = "Atelier Apparel",
                merchant = "Atelier Apparel",
                accountId = CREDIT_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 40_000L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.SHOPPING,
                tsMs = baseMs + 350_000L,
                tsLabel = "Nov 11, 1:25 PM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_chk_rail",
                customerId = ALEX_CUSTOMER_ID,
                ref = "DEB-20261112-7103",
                desc = "Metro Transit & Rail",
                merchant = "Metro Transit",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 14_000L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.TRAVEL,
                tsMs = baseMs + 400_000L,
                tsLabel = "Nov 12, 8:20 AM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_cc_roast",
                customerId = ALEX_CUSTOMER_ID,
                ref = "CRD-20261114-8820",
                desc = "Apex Roasters & Kitchen",
                merchant = "Apex Roasters",
                accountId = CREDIT_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 30_000L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.DINING,
                tsMs = baseMs + 450_000L,
                tsLabel = "Nov 14, 8:15 PM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_chk_grocery",
                customerId = ALEX_CUSTOMER_ID,
                ref = "DEB-20261115-9901",
                desc = "Grocery market",
                merchant = "Fresh Harvest Market",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_MERCHANT_CLEARING,
                amountCents = 8_420L,
                accountDirection = TransactionDirection.DEBIT,
                category = SpendingCategory.OTHER,
                tsMs = baseMs + 500_000L,
                tsLabel = "Yesterday, 5:47 PM"
            )
            seedDoubleEntry(
                journalId = "jrn_seed_chk_payroll",
                customerId = ALEX_CUSTOMER_ID,
                ref = "ACH-20261116-1203",
                desc = "Payroll",
                merchant = "Northstar Systems Inc.",
                accountId = CHECKING_ACCOUNT_ID,
                counterAccountId = SYS_FUNDING,
                amountCents = 325_000L,
                accountDirection = TransactionDirection.CREDIT,
                category = SpendingCategory.EXCLUDED,
                tsMs = baseMs + 600_000L,
                tsLabel = "Today, 12:03 PM"
            )

            // Pending Coffee shop hold (-$6.80) so Posted=$8,426.98 - Hold=$6.80 = Available=$8,420.18
            dao.insertHold(
                PendingHoldEntity(
                    holdId = "hold_coffee_680",
                    accountId = CHECKING_ACCOUNT_ID,
                    description = "Coffee shop",
                    amountCents = 680L,
                    currency = "USD",
                    createdAtEpochMs = baseMs + 700_000L,
                    createdAtLabel = "Today, 6:24 PM",
                    reference = "HOLD-20261116-8821",
                    active = true
                )
            )

            // Cards
            dao.upsertCard(
                CardEntity(
                    cardId = "card_debit_1842",
                    customerId = ALEX_CUSTOMER_ID,
                    linkedAccountId = CHECKING_ACCOUNT_ID,
                    linkedAccountName = "Everyday Checking ••••1842",
                    cardType = CardType.DEBIT.name,
                    holderName = "ALEX MORGAN",
                    maskedLast4 = "1842",
                    networkLabel = "Debit",
                    desiredState = CardDesiredState.ACTIVE.name,
                    issuerStatus = CardIssuerStatus.CONFIRMED_ACTIVE.name,
                    dailyPurchaseLimitCents = 250_000L,
                    dailyAtmLimitCents = 50_000L,
                    onlinePaymentsEnabled = true,
                    internationalEnabled = false,
                    issuerRuleNote = "Card-lock effects depend on configured issuer rules. Recurring pre-authorised debits may still post while locked.",
                    lastSyncedLabel = "Synced with mock issuer"
                )
            )
            dao.upsertCard(
                CardEntity(
                    cardId = "card_credit_4477",
                    customerId = ALEX_CUSTOMER_ID,
                    linkedAccountId = CREDIT_ACCOUNT_ID,
                    linkedAccountName = "Credit card ••••4477",
                    cardType = CardType.CREDIT.name,
                    holderName = "ALEX MORGAN",
                    maskedLast4 = "4477",
                    networkLabel = "Credit",
                    desiredState = CardDesiredState.ACTIVE.name,
                    issuerStatus = CardIssuerStatus.CONFIRMED_ACTIVE.name,
                    dailyPurchaseLimitCents = 400_000L,
                    dailyAtmLimitCents = 30_000L,
                    onlinePaymentsEnabled = true,
                    internationalEnabled = true,
                    issuerRuleNote = "Synthetic credit card facility. Locking blocks new card-present and e-commerce authorisations via mock issuer.",
                    lastSyncedLabel = "Synced with mock issuer"
                )
            )

            // Payees & Scheduled Rent Payment
            dao.upsertPayee(
                PayeeEntity(
                    payeeId = "payee_oakridge",
                    customerId = ALEX_CUSTOMER_ID,
                    name = "Oakridge Properties",
                    category = "Rent & Housing",
                    maskedAccount = "••••9012",
                    verifiedByStepUp = true
                )
            )
            dao.upsertPayee(
                PayeeEntity(
                    payeeId = "payee_water",
                    customerId = ALEX_CUSTOMER_ID,
                    name = "Metro Water & Power",
                    category = "Utilities",
                    maskedAccount = "••••3318",
                    verifiedByStepUp = true
                )
            )
            dao.upsertPayee(
                PayeeEntity(
                    payeeId = "payee_fiber",
                    customerId = ALEX_CUSTOMER_ID,
                    name = "Apex Fiber Internet",
                    category = "Telecom",
                    maskedAccount = "••••7740",
                    verifiedByStepUp = true
                )
            )

            dao.upsertPayment(
                PaymentEntity(
                    paymentId = "pay_rent_dec1",
                    customerId = ALEX_CUSTOMER_ID,
                    sourceAccountId = CHECKING_ACCOUNT_ID,
                    payeeId = "payee_oakridge",
                    payeeName = "Rent payment",
                    amountCents = 185_000L,
                    currency = "USD",
                    scheduledForLabel = "Dec 1",
                    isRecurring = true,
                    status = PaymentStatus.SCHEDULED.name,
                    reference = "SCH-RENT-20261201",
                    railNote = "Scheduled ACH instruction — funds not yet debited",
                    createdAtEpochMs = baseMs + 550_000L
                )
            )

            dao.upsertPaymentRequest(
                PaymentRequestEntity(
                    requestId = "req_split_dinner",
                    customerId = ALEX_CUSTOMER_ID,
                    fromParty = "Samira Chen",
                    destinationAccountId = CHECKING_ACCOUNT_ID,
                    amountCents = 6_400L,
                    currency = "USD",
                    memo = "Harbor Bistro split",
                    dueDateLabel = "Nov 20",
                    statusLabel = "Awaiting sender payment (not received funds)",
                    createdAtEpochMs = baseMs + 560_000L
                )
            )

            // Notifications
            dao.insertNotification(
                NotificationEntity(
                    notificationId = "notif_payroll_1",
                    customerId = ALEX_CUSTOMER_ID,
                    title = "Direct deposit posted",
                    body = "Payroll deposit of $3,250.00 posted to Everyday Checking ••••1842.",
                    lockScreenSafeBody = "A new deposit posted to your checking account. Open Crestline to view details.",
                    category = "Deposit",
                    createdAtEpochMs = baseMs + 600_000L,
                    createdAtLabel = "Today, 12:03 PM",
                    deliveryStatus = "Delivered (In-App)",
                    isRead = false
                )
            )
            dao.insertNotification(
                NotificationEntity(
                    notificationId = "notif_statement_1",
                    customerId = ALEX_CUSTOMER_ID,
                    title = "Statement available",
                    body = "Your October reconciled statement for Everyday Checking ••••1842 is ready.",
                    lockScreenSafeBody = "A monthly account statement is ready to view.",
                    category = "Statement",
                    createdAtEpochMs = baseMs + 10_000L,
                    createdAtLabel = "Nov 1, 9:10 AM",
                    deliveryStatus = "Delivered (In-App)",
                    isRead = true
                )
            )

            // Other active remote session for Device Session management demo
            dao.upsertSession(
                DeviceSessionEntity(
                    sessionId = "sess_web_chrome_demo",
                    customerId = ALEX_CUSTOMER_ID,
                    deviceName = "Chrome on Linux Workstation",
                    lastActiveLabel = "2 days ago",
                    ipRegion = "Seattle, US (Demo)",
                    isCurrentDevice = false,
                    refreshTokenHash = sha256("seeded_remote_refresh"),
                    accessToken = "seeded_remote_tok",
                    accessExpiresAtEpochMs = System.currentTimeMillis() + ACCESS_TTL_MS,
                    refreshGeneration = 1,
                    revoked = false
                )
            )
        }
    }

    private suspend fun seedDoubleEntry(
        journalId: String,
        customerId: String,
        ref: String,
        desc: String,
        merchant: String,
        accountId: String,
        counterAccountId: String,
        amountCents: Long,
        accountDirection: TransactionDirection,
        category: SpendingCategory,
        tsMs: Long,
        tsLabel: String
    ) {
        val counterDir = if (accountDirection == TransactionDirection.CREDIT) {
            TransactionDirection.DEBIT
        } else {
            TransactionDirection.CREDIT
        }
        dao.postBalancedJournalAtomically(
            journal = JournalEntity(
                journalId = journalId,
                customerId = customerId,
                businessReference = ref,
                description = desc,
                createdAtEpochMs = tsMs,
                createdAtLabel = tsLabel
            ),
            lines = listOf(
                LedgerLineEntity(
                    lineId = "${journalId}_1",
                    journalId = journalId,
                    accountId = accountId,
                    description = desc,
                    merchantOrCounterparty = merchant,
                    amountCents = amountCents,
                    currency = "USD",
                    direction = accountDirection.name,
                    status = TransactionStatus.POSTED.name,
                    category = category.name,
                    timestampEpochMs = tsMs,
                    timestampLabel = tsLabel,
                    reference = ref,
                    linkedLineId = null,
                    notes = null
                ),
                LedgerLineEntity(
                    lineId = "${journalId}_2",
                    journalId = journalId,
                    accountId = counterAccountId,
                    description = desc,
                    merchantOrCounterparty = merchant,
                    amountCents = amountCents,
                    currency = "USD",
                    direction = counterDir.name,
                    status = TransactionStatus.POSTED.name,
                    category = SpendingCategory.EXCLUDED.name,
                    timestampEpochMs = tsMs,
                    timestampLabel = tsLabel,
                    reference = ref,
                    linkedLineId = null,
                    notes = null
                )
            )
        )
    }

    // --- Authentication & Session Management ---

    suspend fun signIn(
        email: String,
        password: String,
        deviceName: String,
        mfaCode: String? = null
    ): ApiOutcome<CustomerProfile> {
        ensureSeeded()
        val reqId = reqId()
        val normalizedEmail = email.trim().lowercase()
        val customer = dao.getCustomerByEmail(normalizedEmail)
            ?: return ApiOutcome.Error("AUTH_INVALID", "Invalid demonstration credentials.", 401, reqId)

        if (!SecurityCryptoManager.verifyPassword(password, customer.passwordHashHex, customer.passwordSaltHex)) {
            return ApiOutcome.Error("AUTH_INVALID", "Invalid demonstration credentials.", 401, reqId)
        }

        if (customer.mfaEnabled && mfaCode != "482910") {
            return ApiOutcome.Error(
                code = "MFA_REQUIRED",
                message = "Multifactor code required. Enter demo code 482910.",
                httpStatus = 403,
                requestId = reqId
            )
        }

        val sessionId = "sess_${UUID.randomUUID().toString().take(10)}"
        val accessToken = "atk_${UUID.randomUUID().toString().replace("-", "")}"
        val refreshToken = "rtk_${UUID.randomUUID().toString().replace("-", "")}"
        val expiresAt = System.currentTimeMillis() + ACCESS_TTL_MS

        dao.upsertSession(
            DeviceSessionEntity(
                sessionId = sessionId,
                customerId = customer.customerId,
                deviceName = deviceName,
                lastActiveLabel = "Active now",
                ipRegion = "Local Device",
                isCurrentDevice = true,
                refreshTokenHash = sha256(refreshToken),
                accessToken = accessToken,
                accessExpiresAtEpochMs = expiresAt,
                refreshGeneration = 1,
                revoked = false
            )
        )

        crypto.saveSessionTokens(
            StoredSessionTokens(
                customerId = customer.customerId,
                sessionId = sessionId,
                accessToken = accessToken,
                refreshToken = refreshToken,
                accessExpiresAtEpochMs = expiresAt
            )
        )

        dao.insertNotification(
            NotificationEntity(
                notificationId = "notif_login_${UUID.randomUUID().toString().take(8)}",
                customerId = customer.customerId,
                title = "New device session",
                body = "Signed in on $deviceName.",
                lockScreenSafeBody = "A new sign-in occurred on your Crestline profile.",
                category = "Security",
                createdAtEpochMs = System.currentTimeMillis(),
                createdAtLabel = nowLabel(),
                deliveryStatus = "Delivered (In-App)",
                isRead = false
            )
        )
        crypto.updateLastSynced(System.currentTimeMillis())
        return ApiOutcome.Success(customer.toProfile(), reqId)
    }

    suspend fun createDemoAccount(
        fullName: String,
        email: String,
        password: String,
        deviceName: String
    ): ApiOutcome<CustomerProfile> {
        ensureSeeded()
        val reqId = reqId()
        val cleanName = fullName.trim()
        val cleanEmail = email.trim().lowercase()
        if (cleanName.length < 2 || !cleanEmail.contains("@") || password.length < 8) {
            return ApiOutcome.Error(
                "VALIDATION_ERROR",
                "Enter a valid name, email, and password (min 8 chars).",
                400,
                reqId
            )
        }
        if (dao.getCustomerByEmail(cleanEmail) != null) {
            return ApiOutcome.Error("EMAIL_EXISTS", "A demonstration account with that email already exists.", 409, reqId)
        }

        val customerId = "cust_${UUID.randomUUID().toString().take(8)}"
        val firstName = cleanName.substringBefore(" ").ifBlank { cleanName }
        val (hashHex, saltHex) = SecurityCryptoManager.hashPassword(password)
        dao.insertCustomer(
            CustomerEntity(
                customerId = customerId,
                fullName = cleanName,
                firstName = firstName,
                email = cleanEmail,
                phoneMasked = "+1 (•••) •••-0100",
                passwordHashHex = hashHex,
                passwordSaltHex = saltHex,
                mfaEnabled = false,
                biometricEnabled = true,
                lockScreenRedactionEnabled = true,
                emailAlertsEnabled = true,
                pushAlertsEnabled = true
            )
        )

        val chkId = "acct_chk_${UUID.randomUUID().toString().take(6)}"
        val savId = "acct_sav_${UUID.randomUUID().toString().take(6)}"
        dao.insertAccounts(
            listOf(
                AccountEntity(chkId, customerId, "Everyday Checking", AccountType.CHECKING.name, "••••3104", "USD", 0, 0, 0, null, 1L),
                AccountEntity(savId, customerId, "Savings", AccountType.SAVINGS.name, "••••7822", "USD", 0, 0, 0, null, 1L)
            )
        )
        seedDoubleEntry(
            journalId = "jrn_${UUID.randomUUID().toString().take(8)}",
            customerId = customerId,
            ref = "SEED-CHK-$customerId",
            desc = "Synthetic Welcome Funding",
            merchant = "Crestline Synthetic Treasury",
            accountId = chkId,
            counterAccountId = SYS_FUNDING,
            amountCents = 250_000L,
            accountDirection = TransactionDirection.CREDIT,
            category = SpendingCategory.EXCLUDED,
            tsMs = System.currentTimeMillis(),
            tsLabel = nowLabel()
        )
        seedDoubleEntry(
            journalId = "jrn_${UUID.randomUUID().toString().take(8)}",
            customerId = customerId,
            ref = "SEED-SAV-$customerId",
            desc = "Synthetic Savings Seed",
            merchant = "Crestline Synthetic Treasury",
            accountId = savId,
            counterAccountId = SYS_FUNDING,
            amountCents = 500_000L,
            accountDirection = TransactionDirection.CREDIT,
            category = SpendingCategory.EXCLUDED,
            tsMs = System.currentTimeMillis(),
            tsLabel = nowLabel()
        )
        dao.upsertCard(
            CardEntity(
                cardId = "card_${UUID.randomUUID().toString().take(8)}",
                customerId = customerId,
                linkedAccountId = chkId,
                linkedAccountName = "Everyday Checking ••••3104",
                cardType = CardType.DEBIT.name,
                holderName = cleanName.uppercase(),
                maskedLast4 = "3104",
                networkLabel = "Debit",
                desiredState = CardDesiredState.ACTIVE.name,
                issuerStatus = CardIssuerStatus.CONFIRMED_ACTIVE.name,
                dailyPurchaseLimitCents = 250_000L,
                dailyAtmLimitCents = 50_000L,
                onlinePaymentsEnabled = true,
                internationalEnabled = false,
                issuerRuleNote = "Card-lock effects depend on configured issuer rules.",
                lastSyncedLabel = "Synced with mock issuer"
            )
        )
        return signIn(cleanEmail, password, deviceName)
    }

    suspend fun restoreActiveSession(): CustomerProfile? {
        ensureSeeded()
        val stored = crypto.readSessionTokens() ?: return null
        val session = dao.getSession(stored.sessionId) ?: return null
        if (session.revoked) {
            crypto.clearSessionTokens()
            return null
        }
        return dao.getCustomerById(stored.customerId)?.toProfile()
    }

    suspend fun refreshSession(): ApiOutcome<DeviceSession> {
        val reqId = reqId()
        val stored = crypto.readSessionTokens()
            ?: return ApiOutcome.Error("NO_SESSION", "No active session to refresh.", 401, reqId)
        val session = dao.getSession(stored.sessionId)
            ?: return ApiOutcome.Error("NO_SESSION", "Session no longer exists.", 401, reqId)
        if (session.revoked) {
            return ApiOutcome.Error("SESSION_REVOKED", "Session was revoked.", 401, reqId)
        }
        if (session.refreshTokenHash != sha256(stored.refreshToken)) {
            // Replay detection -> revoke session!
            dao.revokeSession(session.sessionId, session.customerId)
            crypto.clearSessionTokens()
            return ApiOutcome.Error("REFRESH_REUSE_DETECTED", "Refresh token mismatch; session revoked.", 401, reqId)
        }

        val newAccess = "atk_${UUID.randomUUID().toString().replace("-", "")}"
        val newRefresh = "rtk_${UUID.randomUUID().toString().replace("-", "")}"
        val newExpiry = System.currentTimeMillis() + ACCESS_TTL_MS
        val rotated = session.copy(
            accessToken = newAccess,
            refreshTokenHash = sha256(newRefresh),
            accessExpiresAtEpochMs = newExpiry,
            refreshGeneration = session.refreshGeneration + 1,
            lastActiveLabel = "Refreshed just now"
        )
        dao.upsertSession(rotated)
        crypto.saveSessionTokens(
            StoredSessionTokens(
                customerId = session.customerId,
                sessionId = session.sessionId,
                accessToken = newAccess,
                refreshToken = newRefresh,
                accessExpiresAtEpochMs = newExpiry
            )
        )
        return ApiOutcome.Success(rotated.toDomain(), reqId)
    }

    suspend fun simulateExpireAccessToken() {
        val stored = crypto.readSessionTokens() ?: return
        val session = dao.getSession(stored.sessionId) ?: return
        val expiredTime = System.currentTimeMillis() - 60_000L
        dao.upsertSession(session.copy(accessExpiresAtEpochMs = expiredTime))
        crypto.saveSessionTokens(stored.copy(accessExpiresAtEpochMs = expiredTime))
    }

    suspend fun revokeDeviceSession(customerId: String, sessionId: String) {
        dao.revokeSession(sessionId, customerId)
        val current = crypto.readSessionTokens()
        if (current?.sessionId == sessionId) {
            crypto.clearSessionTokens()
        }
    }

    suspend fun signOut() {
        val stored = crypto.readSessionTokens()
        if (stored != null) {
            dao.revokeSession(stored.sessionId, stored.customerId)
        }
        crypto.clearSessionTokens()
    }

    suspend fun updateProfilePreferences(
        customerId: String,
        mfaEnabled: Boolean,
        biometricEnabled: Boolean,
        lockScreenRedaction: Boolean,
        emailAlerts: Boolean,
        pushAlerts: Boolean
    ) {
        val current = dao.getCustomerById(customerId) ?: return
        dao.updateCustomer(
            current.copy(
                mfaEnabled = mfaEnabled,
                biometricEnabled = biometricEnabled,
                lockScreenRedactionEnabled = lockScreenRedaction,
                emailAlertsEnabled = emailAlerts,
                pushAlertsEnabled = pushAlerts
            )
        )
    }

    // --- Reactive Observations ---

    fun observeCustomer(customerId: String): Flow<CustomerProfile?> =
        dao.observeCustomer(customerId).map { it?.toProfile() }

    fun observeSessions(customerId: String): Flow<List<DeviceSession>> =
        dao.observeSessions(customerId).map { list -> list.map { it.toDomain() } }

    fun observeAccounts(customerId: String): Flow<List<BankAccount>> =
        combine(
            dao.observeAccounts(customerId),
            dao.observeCustomerLedgerLines(customerId),
            dao.observeActiveHolds(customerId)
        ) { accounts, lines, holds ->
            accounts.map { acc ->
                val accLines = lines.filter { it.accountId == acc.accountId }
                val accHolds = holds.filter { it.accountId == acc.accountId }
                computeAccountDomain(acc, accLines, accHolds)
            }
        }

    fun observeTransactions(customerId: String): Flow<List<LedgerTransaction>> =
        combine(
            dao.observeCustomerLedgerLines(customerId),
            dao.observeActiveHolds(customerId)
        ) { lines, holds ->
            val posted = lines.map { it.toDomain() }
            val pending = holds.map { it.toTransaction() }
            (pending + posted).sortedByDescending { it.timestampEpochMs }
        }

    fun observeHolds(customerId: String): Flow<List<PendingHold>> =
        dao.observeActiveHolds(customerId).map { list ->
            list.map {
                PendingHold(
                    holdId = it.holdId,
                    accountId = it.accountId,
                    description = it.description,
                    amountCents = it.amountCents,
                    currency = it.currency,
                    createdAtLabel = it.createdAtLabel,
                    reference = it.reference
                )
            }
        }

    fun observeTransfers(customerId: String): Flow<List<TransferRecord>> =
        dao.observeTransfers(customerId).map { list -> list.map { it.toDomain() } }

    fun observePayees(customerId: String): Flow<List<Payee>> =
        dao.observePayees(customerId).map { list ->
            list.map { Payee(it.payeeId, it.name, it.category, it.maskedAccount, it.verifiedByStepUp) }
        }

    fun observePayments(customerId: String): Flow<List<PaymentInstruction>> =
        dao.observePayments(customerId).map { list ->
            list.map {
                PaymentInstruction(
                    paymentId = it.paymentId,
                    sourceAccountId = it.sourceAccountId,
                    payeeId = it.payeeId,
                    payeeName = it.payeeName,
                    amountCents = it.amountCents,
                    currency = it.currency,
                    scheduledForLabel = it.scheduledForLabel,
                    isRecurring = it.isRecurring,
                    status = PaymentStatus.valueOf(it.status),
                    reference = it.reference,
                    railNote = it.railNote
                )
            }
        }

    fun observePaymentRequests(customerId: String): Flow<List<PaymentRequest>> =
        dao.observePaymentRequests(customerId).map { list ->
            list.map {
                PaymentRequest(
                    requestId = it.requestId,
                    fromParty = it.fromParty,
                    destinationAccountId = it.destinationAccountId,
                    amountCents = it.amountCents,
                    currency = it.currency,
                    memo = it.memo,
                    dueDateLabel = it.dueDateLabel,
                    statusLabel = it.statusLabel
                )
            }
        }

    fun observeDeposits(customerId: String): Flow<List<DepositSubmission>> =
        dao.observeDeposits(customerId).map { list ->
            list.map {
                DepositSubmission(
                    depositId = it.depositId,
                    accountId = it.accountId,
                    amountCents = it.amountCents,
                    currency = it.currency,
                    documentLabel = it.documentLabel,
                    mimeType = it.mimeType,
                    fileSizeBytes = it.fileSizeBytes,
                    status = DepositStatus.valueOf(it.status),
                    availabilityNote = it.availabilityNote,
                    reference = it.reference
                )
            }
        }

    fun observeCards(customerId: String): Flow<List<BankCard>> =
        dao.observeCards(customerId).map { list -> list.map { it.toDomain() } }

    fun observeNotifications(customerId: String): Flow<List<NotificationItem>> =
        dao.observeNotifications(customerId).map { list ->
            list.map {
                NotificationItem(
                    notificationId = it.notificationId,
                    title = it.title,
                    body = it.body,
                    lockScreenSafeBody = it.lockScreenSafeBody,
                    category = it.category,
                    createdAtLabel = it.createdAtLabel,
                    deliveryStatus = it.deliveryStatus,
                    isRead = it.isRead
                )
            }
        }

    fun observeStatements(customerId: String): Flow<List<BankStatement>> =
        dao.observeStatements(customerId).map { list ->
            list.map {
                val lines = runCatching { json.decodeFromString<List<StatementLine>>(it.linesJson) }.getOrDefault(emptyList())
                BankStatement(
                    statementId = it.statementId,
                    accountId = it.accountId,
                    accountName = it.accountName,
                    maskedNumber = it.maskedNumber,
                    periodLabel = it.periodLabel,
                    openingBalanceCents = it.openingBalanceCents,
                    totalCreditsCents = it.totalCreditsCents,
                    totalDebitsCents = it.totalDebitsCents,
                    closingBalanceCents = it.closingBalanceCents,
                    lines = lines,
                    generatedAtLabel = it.generatedAtLabel
                )
            }
        }

    fun observeOutboxCount(customerId: String): Flow<Int> =
        dao.observeOutbox(customerId).map { it.size }

    fun observeInsights(customerId: String): Flow<SpendingInsights> =
        combine(
            dao.observeCustomerLedgerLines(customerId),
            dao.observePayments(customerId),
            dao.observeAccounts(customerId)
        ) { lines, payments, accounts ->
            val accountTypes = accounts.associate { it.accountId to AccountType.valueOf(it.accountType) }
            // Eligible spending: POSTED DEBIT purchases on Checking or Credit Card, excluding transfers/payments/excluded,
            // plus REVERSED/ADJUSTMENT credits reduce their category total.
            val eligibleLines = lines.filter { line ->
                val accType = accountTypes[line.accountId]
                val cat = SpendingCategory.valueOf(line.category)
                cat != SpendingCategory.EXCLUDED &&
                    (accType == AccountType.CHECKING || accType == AccountType.CREDIT_CARD)
            }

            val totalsByCategory = SpendingCategory.entries
                .filter { it != SpendingCategory.EXCLUDED }
                .associateWith { cat ->
                    eligibleLines.filter { it.category == cat.name }.sumOf { line ->
                        if (line.direction == TransactionDirection.DEBIT.name) line.amountCents else -line.amountCents
                    }.coerceAtLeast(0L)
                }

            val grandTotal = totalsByCategory.values.sum()
            val prevByCategory = mapOf(
                SpendingCategory.DINING to 39_500L,
                SpendingCategory.SHOPPING to 71_000L,
                SpendingCategory.TRAVEL to 48_000L,
                SpendingCategory.OTHER to 51_200L
            )
            val breakdowns = totalsByCategory.entries.map { (cat, amt) ->
                CategoryBreakdown(
                    category = cat,
                    totalCents = amt,
                    previousPeriodCents = prevByCategory[cat] ?: 0L,
                    shareFraction = if (grandTotal > 0L) amt.toFloat() / grandTotal.toFloat() else 0f
                )
            }

            val scheduledUpcoming = payments
                .filter { it.status == PaymentStatus.SCHEDULED.name }
                .map {
                    UpcomingItem(
                        id = it.paymentId,
                        title = it.payeeName,
                        amountCents = it.amountCents,
                        dueDateLabel = it.scheduledForLabel,
                        isConfirmedSchedule = true,
                        sourceNote = "Scheduled instruction"
                    )
                }
            val estimatedRecurring = listOf(
                UpcomingItem(
                    id = "est_util_dec",
                    title = "City Electric & Fiber (Estimated)",
                    amountCents = 27_580L,
                    dueDateLabel = "Dec 5",
                    isConfirmedSchedule = false,
                    sourceNote = "Estimated recurring pattern — not a scheduled instruction"
                )
            )

            SpendingInsights(
                monthLabel = "November 2026",
                totalCents = grandTotal,
                previousMonthTotalCents = prevByCategory.values.sum(),
                categories = breakdowns,
                upcomingItems = scheduledUpcoming + estimatedRecurring,
                methodologyNote = "Includes posted debit & credit card purchases. Refunds reduce category totals. Internal transfers, pending holds, and credit-card bill payments are excluded to avoid double-counting."
            )
        }

    // --- Ownership & Session Guard ---

    private suspend fun verifyAuthAndOwnership(
        customerId: String,
        accountId: String? = null
    ): ApiOutcome.Error? {
        val reqId = reqId()
        if (activeFaultMode == DemoFaultMode.EXPIRED_SESSION) {
            return ApiOutcome.Error(
                code = "SESSION_EXPIRED",
                message = "Access token expired (simulated). Refresh session or sign in again.",
                httpStatus = 401,
                requestId = reqId
            )
        }
        val stored = crypto.readSessionTokens()
        if (stored != null) {
            val session = dao.getSession(stored.sessionId)
            if (session == null || session.revoked) {
                return ApiOutcome.Error("SESSION_REVOKED", "Session revoked.", 401, reqId)
            }
            if (session.accessExpiresAtEpochMs < System.currentTimeMillis()) {
                return ApiOutcome.Error(
                    "SESSION_EXPIRED",
                    "Access token expired. Use Refresh Token or re-authenticate.",
                    401,
                    reqId
                )
            }
        }
        if (accountId != null) {
            val acc = dao.getAccount(accountId)
                ?: return ApiOutcome.Error("ACCOUNT_NOT_FOUND", "Account does not exist.", 404, reqId)
            if (acc.customerId != customerId) {
                return ApiOutcome.Error("FORBIDDEN", "Cross-customer account access denied.", 403, reqId)
            }
        }
        return null
    }

    // --- Internal Transfers (Draft -> Reviewed -> Authorised -> Processing -> Completed/Rejected/Cancelled) ---

    suspend fun previewTransfer(
        customerId: String,
        sourceAccountId: String,
        destinationAccountId: String,
        amountCents: Long,
        timing: TransferTiming
    ): ApiOutcome<TransferRecord> {
        ensureSeeded()
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, sourceAccountId)?.let { return it }
        verifyAuthAndOwnership(customerId, destinationAccountId)?.let { return it }

        if (sourceAccountId == destinationAccountId) {
            return ApiOutcome.Error("SAME_ACCOUNT", "Source and destination accounts must differ.", 400, reqId)
        }
        if (amountCents <= 0L) {
            return ApiOutcome.Error("INVALID_AMOUNT", "Transfer amount must be greater than $0.00.", 400, reqId)
        }
        if (amountCents > MAX_SINGLE_TRANSFER_CENTS) {
            return ApiOutcome.Error(
                "LIMIT_EXCEEDED",
                "Exceeds single internal transfer demo limit of ${CurrencyFormatter.formatCents(MAX_SINGLE_TRANSFER_CENTS)}.",
                422,
                reqId
            )
        }

        val src = dao.getAccount(sourceAccountId)!!
        val dst = dao.getAccount(destinationAccountId)!!
        if (src.currency != dst.currency) {
            return ApiOutcome.Error("CURRENCY_MISMATCH", "Cross-currency transfers are not enabled in this demo.", 422, reqId)
        }

        val srcDomain = computeAccountDomain(
            src,
            dao.getLedgerLinesForAccount(src.accountId),
            dao.getActiveHoldsForAccount(src.accountId)
        )
        if (srcDomain.accountType == AccountType.CREDIT_CARD) {
            return ApiOutcome.Error("INVALID_SOURCE", "Credit card accounts cannot originate deposit transfers.", 422, reqId)
        }
        if (activeFaultMode == DemoFaultMode.INSUFFICIENT_FUNDS || srcDomain.availableBalanceCents < amountCents) {
            return ApiOutcome.Error(
                "INSUFFICIENT_FUNDS",
                "Insufficient available funds in ${src.name} (${CurrencyFormatter.formatCents(srcDomain.availableBalanceCents)} available).",
                422,
                reqId
            )
        }

        val transferId = "trf_${UUID.randomUUID().toString().take(10)}"
        val idempotencyKey = "idem_${UUID.randomUUID()}"
        val termsHash = computeTermsHash(sourceAccountId, destinationAccountId, amountCents, src.currency, timing)
        val preview = TransferEntity(
            transferId = transferId,
            customerId = customerId,
            sourceAccountId = sourceAccountId,
            destinationAccountId = destinationAccountId,
            sourceName = "${src.name} ${src.maskedNumber}",
            destinationName = "${dst.name} ${dst.maskedNumber}",
            amountCents = amountCents,
            feeCents = 0L,
            currency = src.currency,
            timing = timing.name,
            status = TransferStatus.REVIEWED.name,
            idempotencyKey = idempotencyKey,
            termsHash = termsHash,
            confirmationReference = null,
            failureReason = null,
            createdAtEpochMs = System.currentTimeMillis(),
            createdAtLabel = nowLabel(),
            journalId = null
        )
        dao.upsertTransfer(preview)
        return ApiOutcome.Success(preview.toDomain(), reqId)
    }

    suspend fun cancelDraftTransfer(transferId: String) {
        val existing = dao.getTransfer(transferId) ?: return
        if (existing.status == TransferStatus.DRAFT.name || existing.status == TransferStatus.REVIEWED.name) {
            dao.upsertTransfer(existing.copy(status = TransferStatus.CANCELLED.name))
        }
    }

    suspend fun executeTransfer(
        customerId: String,
        draftTransfer: TransferRecord
    ): ApiOutcome<TransferRecord> = ledgerMutex.withLock {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, draftTransfer.sourceAccountId)?.let { return it }
        verifyAuthAndOwnership(customerId, draftTransfer.destinationAccountId)?.let { return it }

        // 1. Idempotency check FIRST (handles retries & lost-response recovery!)
        val existingByKey = dao.getTransferByIdempotencyKey(draftTransfer.idempotencyKey)
        if (existingByKey != null && existingByKey.status == TransferStatus.COMPLETED.name) {
            return ApiOutcome.Success(existingByKey.toDomain(), reqId)
        }

        // 2. Material terms integrity check
        val expectedHash = computeTermsHash(
            draftTransfer.sourceAccountId,
            draftTransfer.destinationAccountId,
            draftTransfer.amountCents,
            draftTransfer.currency,
            draftTransfer.timing
        )
        if (expectedHash != draftTransfer.termsHash) {
            return ApiOutcome.Error(
                "TERMS_CHANGED_REVIEW_REQUIRED",
                "Material transfer terms changed. Renewed review is required before authorising.",
                409,
                reqId
            )
        }

        if (simulateOffline) {
            dao.upsertOutboxAction(
                OutboxActionEntity(
                    actionId = "out_${UUID.randomUUID().toString().take(8)}",
                    customerId = customerId,
                    actionType = "TRANSFER:${draftTransfer.idempotencyKey}",
                    payloadJson = json.encodeToString(draftTransfer),
                    status = "QUEUED_OFFLINE",
                    createdAtEpochMs = System.currentTimeMillis()
                )
            )
            return ApiOutcome.Error(
                "OFFLINE_QUEUED",
                "Offline mode: action queued locally and NOT marked completed until backend confirmation.",
                503,
                reqId,
                recoverableByReconcile = true
            )
        }

        if (activeFaultMode == DemoFaultMode.PROVIDER_FAILURE) {
            val rejected = draftTransfer.copy(
                status = TransferStatus.REJECTED,
                failureReason = "Simulated transfer rail outage (no ledger entries posted)."
            )
            dao.upsertTransfer(rejected.toEntity())
            return ApiOutcome.Error(
                "PROVIDER_UNAVAILABLE",
                "Mock transfer rail unavailable. Ledger was not modified.",
                502,
                reqId
            )
        }

        val srcEntity = dao.getAccount(draftTransfer.sourceAccountId)!!
        val dstEntity = dao.getAccount(draftTransfer.destinationAccountId)!!
        val srcDomain = computeAccountDomain(
            srcEntity,
            dao.getLedgerLinesForAccount(srcEntity.accountId),
            dao.getActiveHoldsForAccount(srcEntity.accountId)
        )

        if (activeFaultMode == DemoFaultMode.INSUFFICIENT_FUNDS || srcDomain.availableBalanceCents < draftTransfer.amountCents) {
            val rejected = draftTransfer.copy(
                status = TransferStatus.REJECTED,
                failureReason = "Insufficient available funds."
            )
            dao.upsertTransfer(rejected.toEntity())
            return ApiOutcome.Error(
                "INSUFFICIENT_FUNDS",
                "Insufficient available funds in ${srcEntity.name}.",
                422,
                reqId
            )
        }

        // Transition: Authorised -> Processing -> Completed (atomic double-entry journal)
        val tsMs = System.currentTimeMillis()
        val tsLabel = nowLabel()
        val confRef = "TRF-${UUID.randomUUID().toString().take(8).uppercase()}"
        val journalId = "jrn_${UUID.randomUUID().toString().take(10)}"

        val completed = if (draftTransfer.timing == TransferTiming.TODAY) {
            // If destination is a CREDIT_CARD, paying it credits the liability reduction (CREDIT reduces owed = DEBIT - CREDIT)
            dao.postBalancedJournalAtomically(
                journal = JournalEntity(
                    journalId = journalId,
                    customerId = customerId,
                    businessReference = confRef,
                    description = "Transfer: ${srcEntity.name} to ${dstEntity.name}",
                    createdAtEpochMs = tsMs,
                    createdAtLabel = tsLabel
                ),
                lines = listOf(
                    LedgerLineEntity(
                        lineId = "${journalId}_src",
                        journalId = journalId,
                        accountId = srcEntity.accountId,
                        description = "Transfer to ${dstEntity.name}",
                        merchantOrCounterparty = dstEntity.name,
                        amountCents = draftTransfer.amountCents,
                        currency = draftTransfer.currency,
                        direction = TransactionDirection.DEBIT.name,
                        status = TransactionStatus.POSTED.name,
                        category = SpendingCategory.EXCLUDED.name,
                        timestampEpochMs = tsMs,
                        timestampLabel = tsLabel,
                        reference = confRef,
                        linkedLineId = null,
                        notes = "Idempotency: ${draftTransfer.idempotencyKey}"
                    ),
                    LedgerLineEntity(
                        lineId = "${journalId}_dst",
                        journalId = journalId,
                        accountId = dstEntity.accountId,
                        description = "Transfer from ${srcEntity.name}",
                        merchantOrCounterparty = srcEntity.name,
                        amountCents = draftTransfer.amountCents,
                        currency = draftTransfer.currency,
                        direction = TransactionDirection.CREDIT.name,
                        status = TransactionStatus.POSTED.name,
                        category = SpendingCategory.EXCLUDED.name,
                        timestampEpochMs = tsMs,
                        timestampLabel = tsLabel,
                        reference = confRef,
                        linkedLineId = null,
                        notes = "Idempotency: ${draftTransfer.idempotencyKey}"
                    )
                ),
                accountIdToBump = srcEntity.accountId,
                expectedVersion = srcEntity.version
            )

            draftTransfer.copy(
                status = TransferStatus.COMPLETED,
                confirmationReference = confRef,
                journalId = journalId
            )
        } else {
            // Scheduled or recurring transfer stays AUTHORISED/SCHEDULED without prematurely moving funds
            draftTransfer.copy(
                status = TransferStatus.AUTHORISED,
                confirmationReference = confRef
            )
        }

        dao.upsertTransfer(completed.toEntity())
        dao.insertNotification(
            NotificationEntity(
                notificationId = "notif_trf_${UUID.randomUUID().toString().take(8)}",
                customerId = customerId,
                title = "Transfer ${completed.status.name.lowercase()}",
                body = "${CurrencyFormatter.formatCents(completed.amountCents)} from ${completed.sourceName} to ${completed.destinationName} ($confRef).",
                lockScreenSafeBody = "A transfer update is available in your Crestline account.",
                category = "Transfer",
                createdAtEpochMs = tsMs,
                createdAtLabel = tsLabel,
                deliveryStatus = "Delivered (In-App)",
                isRead = false
            )
        )
        crypto.updateLastSynced(tsMs)

        // Simulate a lost network response AFTER the backend committed!
        if (activeFaultMode == DemoFaultMode.LOST_TRANSFER_RESPONSE) {
            activeFaultMode = DemoFaultMode.NONE
            return ApiOutcome.Error(
                code = "LOST_RESPONSE_RECONCILE",
                message = "Connection dropped after submission. Tap Retry/Reconcile — idempotency key will return existing confirmation without duplicating.",
                httpStatus = 504,
                requestId = reqId,
                recoverableByReconcile = true
            )
        }

        return ApiOutcome.Success(completed, reqId)
    }

    suspend fun reconcileTransferByIdempotencyKey(
        customerId: String,
        idempotencyKey: String
    ): ApiOutcome<TransferRecord> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        val found = dao.getTransferByIdempotencyKey(idempotencyKey)
            ?: return ApiOutcome.Error("NOT_FOUND", "No committed transfer found for idempotency key.", 404, reqId)
        if (found.customerId != customerId) {
            return ApiOutcome.Error("FORBIDDEN", "Access denied.", 403, reqId)
        }
        return ApiOutcome.Success(found.toDomain(), reqId)
    }

    // --- Reversal / Linked Adjustment (Immutable Ledger History) ---

    suspend fun createLinkedAdjustment(
        customerId: String,
        transactionId: String,
        reason: String
    ): ApiOutcome<String> = ledgerMutex.withLock {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        val original = dao.getLedgerLine(transactionId)
            ?: return ApiOutcome.Error("NOT_FOUND", "Only posted ledger entries can be adjusted via linked entry.", 404, reqId)
        val acc = dao.getAccount(original.accountId)
            ?: return ApiOutcome.Error("NOT_FOUND", "Account not found.", 404, reqId)
        if (acc.customerId != customerId) {
            return ApiOutcome.Error("FORBIDDEN", "Access denied.", 403, reqId)
        }

        val journalId = "jrn_adj_${UUID.randomUUID().toString().take(8)}"
        val adjRef = "ADJ-${UUID.randomUUID().toString().take(6).uppercase()}"
        val tsMs = System.currentTimeMillis()
        val tsLabel = nowLabel()
        val adjDirection = if (original.direction == TransactionDirection.DEBIT.name) {
            TransactionDirection.CREDIT
        } else {
            TransactionDirection.DEBIT
        }
        val counterDir = if (adjDirection == TransactionDirection.CREDIT) {
            TransactionDirection.DEBIT
        } else {
            TransactionDirection.CREDIT
        }

        dao.postBalancedJournalAtomically(
            journal = JournalEntity(
                journalId = journalId,
                customerId = customerId,
                businessReference = adjRef,
                description = "Adjustment for ${original.reference}",
                createdAtEpochMs = tsMs,
                createdAtLabel = tsLabel
            ),
            lines = listOf(
                LedgerLineEntity(
                    lineId = "${journalId}_1",
                    journalId = journalId,
                    accountId = original.accountId,
                    description = "Adjustment: ${original.description}",
                    merchantOrCounterparty = original.merchantOrCounterparty,
                    amountCents = original.amountCents,
                    currency = original.currency,
                    direction = adjDirection.name,
                    status = TransactionStatus.ADJUSTMENT.name,
                    category = original.category,
                    timestampEpochMs = tsMs,
                    timestampLabel = tsLabel,
                    reference = adjRef,
                    linkedLineId = original.lineId,
                    notes = reason
                ),
                LedgerLineEntity(
                    lineId = "${journalId}_2",
                    journalId = journalId,
                    accountId = SYS_MERCHANT_CLEARING,
                    description = "Adjustment offset: ${original.reference}",
                    merchantOrCounterparty = original.merchantOrCounterparty,
                    amountCents = original.amountCents,
                    currency = original.currency,
                    direction = counterDir.name,
                    status = TransactionStatus.ADJUSTMENT.name,
                    category = SpendingCategory.EXCLUDED.name,
                    timestampEpochMs = tsMs,
                    timestampLabel = tsLabel,
                    reference = adjRef,
                    linkedLineId = original.lineId,
                    notes = reason
                )
            )
        )
        return ApiOutcome.Success(adjRef, reqId)
    }

    // --- Payments & Requests ---

    suspend fun addPayeeWithStepUp(
        customerId: String,
        name: String,
        category: String,
        maskedAccount: String,
        stepUpVerified: Boolean
    ): ApiOutcome<Payee> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        if (!stepUpVerified) {
            return ApiOutcome.Error("STEP_UP_REQUIRED", "Step-up authorisation required to add a new payee.", 403, reqId)
        }
        if (name.isBlank() || maskedAccount.length < 4) {
            return ApiOutcome.Error("INVALID_PAYEE", "Provide payee name and last 4 account digits.", 400, reqId)
        }
        val payee = PayeeEntity(
            payeeId = "payee_${UUID.randomUUID().toString().take(8)}",
            customerId = customerId,
            name = name.trim(),
            category = category.trim().ifEmpty { "General" },
            maskedAccount = "••••" + maskedAccount.takeLast(4),
            verifiedByStepUp = true
        )
        dao.upsertPayee(payee)
        return ApiOutcome.Success(
            Payee(payee.payeeId, payee.name, payee.category, payee.maskedAccount, true),
            reqId
        )
    }

    suspend fun submitBillPayment(
        customerId: String,
        sourceAccountId: String,
        payeeId: String,
        payeeName: String,
        amountCents: Long,
        scheduledForToday: Boolean,
        isRecurring: Boolean
    ): ApiOutcome<PaymentInstruction> = ledgerMutex.withLock {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, sourceAccountId)?.let { return it }
        if (amountCents <= 0L) {
            return ApiOutcome.Error("INVALID_AMOUNT", "Amount must be greater than $0.00.", 400, reqId)
        }
        val src = dao.getAccount(sourceAccountId)!!
        val srcDomain = computeAccountDomain(src, dao.getLedgerLinesForAccount(src.accountId), dao.getActiveHoldsForAccount(src.accountId))
        if (scheduledForToday && srcDomain.availableBalanceCents < amountCents) {
            return ApiOutcome.Error("INSUFFICIENT_FUNDS", "Insufficient available funds for immediate payment.", 422, reqId)
        }

        val payId = "pay_${UUID.randomUUID().toString().take(8)}"
        val ref = "PAY-${UUID.randomUUID().toString().take(6).uppercase()}"
        val tsMs = System.currentTimeMillis()
        val tsLabel = nowLabel()

        val status = if (scheduledForToday) PaymentStatus.SETTLED else PaymentStatus.SCHEDULED
        if (scheduledForToday) {
            val journalId = "jrn_$payId"
            dao.postBalancedJournalAtomically(
                journal = JournalEntity(journalId, customerId, ref, "Bill Payment: $payeeName", tsMs, tsLabel),
                lines = listOf(
                    LedgerLineEntity(
                        "${journalId}_1", journalId, sourceAccountId, "Payment to $payeeName",
                        payeeName, amountCents, "USD", TransactionDirection.DEBIT.name,
                        TransactionStatus.POSTED.name, SpendingCategory.OTHER.name,
                        tsMs, tsLabel, ref, null, "Mock ACH rail settled"
                    ),
                    LedgerLineEntity(
                        "${journalId}_2", journalId, SYS_MERCHANT_CLEARING, "ACH Clearing: $payeeName",
                        payeeName, amountCents, "USD", TransactionDirection.CREDIT.name,
                        TransactionStatus.POSTED.name, SpendingCategory.EXCLUDED.name,
                        tsMs, tsLabel, ref, null, null
                    )
                ),
                accountIdToBump = sourceAccountId,
                expectedVersion = src.version
            )
        }

        val entity = PaymentEntity(
            paymentId = payId,
            customerId = customerId,
            sourceAccountId = sourceAccountId,
            payeeId = payeeId,
            payeeName = payeeName,
            amountCents = amountCents,
            currency = "USD",
            scheduledForLabel = if (scheduledForToday) "Today" else "Dec 15",
            isRecurring = isRecurring,
            status = status.name,
            reference = ref,
            railNote = if (scheduledForToday) "Mock ACH rail: Instruction -> Submitted -> Settled" else "Scheduled instruction — funds not yet debited",
            createdAtEpochMs = tsMs
        )
        dao.upsertPayment(entity)
        return ApiOutcome.Success(
            PaymentInstruction(
                entity.paymentId, entity.sourceAccountId, entity.payeeId, entity.payeeName,
                entity.amountCents, entity.currency, entity.scheduledForLabel, entity.isRecurring,
                status, entity.reference, entity.railNote
            ),
            reqId
        )
    }

    suspend fun runScheduledPaymentWorker(customerId: String): Int = ledgerMutex.withLock {
        val scheduled = dao.getScheduledPayments(customerId)
        var executed = 0
        for (item in scheduled) {
            val src = dao.getAccount(item.sourceAccountId) ?: continue
            val srcDomain = computeAccountDomain(src, dao.getLedgerLinesForAccount(src.accountId), dao.getActiveHoldsForAccount(src.accountId))
            if (srcDomain.availableBalanceCents < item.amountCents) {
                dao.upsertPayment(item.copy(status = PaymentStatus.FAILED.name, railNote = "Worker execution failed: insufficient available funds"))
                dao.insertNotification(
                    NotificationEntity(
                        "notif_payfail_${UUID.randomUUID().toString().take(6)}",
                        customerId,
                        "Payment exception",
                        "Scheduled payment to ${item.payeeName} failed due to insufficient funds.",
                        "A scheduled payment requires attention.",
                        "Payment",
                        System.currentTimeMillis(),
                        nowLabel(),
                        "Delivered (In-App)",
                        false
                    )
                )
                continue
            }
            val tsMs = System.currentTimeMillis()
            val tsLabel = nowLabel()
            val journalId = "jrn_wrk_${item.paymentId}"
            dao.postBalancedJournalAtomically(
                journal = JournalEntity(journalId, customerId, item.reference, "Scheduled Payment: ${item.payeeName}", tsMs, tsLabel),
                lines = listOf(
                    LedgerLineEntity(
                        "${journalId}_1", journalId, item.sourceAccountId, item.payeeName,
                        item.payeeName, item.amountCents, item.currency, TransactionDirection.DEBIT.name,
                        TransactionStatus.POSTED.name, SpendingCategory.OTHER.name,
                        tsMs, tsLabel, item.reference, null, "Executed by background reconciliation worker"
                    ),
                    LedgerLineEntity(
                        "${journalId}_2", journalId, SYS_MERCHANT_CLEARING, item.payeeName,
                        item.payeeName, item.amountCents, item.currency, TransactionDirection.CREDIT.name,
                        TransactionStatus.POSTED.name, SpendingCategory.EXCLUDED.name,
                        tsMs, tsLabel, item.reference, null, null
                    )
                ),
                accountIdToBump = src.accountId,
                expectedVersion = src.version
            )
            dao.upsertPayment(item.copy(status = PaymentStatus.SETTLED.name, railNote = "Settled via background worker"))
            executed++
        }
        return executed
    }

    suspend fun createPaymentRequest(
        customerId: String,
        fromParty: String,
        destinationAccountId: String,
        amountCents: Long,
        memo: String
    ): ApiOutcome<PaymentRequest> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, destinationAccountId)?.let { return it }
        if (fromParty.isBlank() || amountCents <= 0L) {
            return ApiOutcome.Error("INVALID_REQUEST", "Enter payer name and positive amount.", 400, reqId)
        }
        val entity = PaymentRequestEntity(
            requestId = "req_${UUID.randomUUID().toString().take(8)}",
            customerId = customerId,
            fromParty = fromParty.trim(),
            destinationAccountId = destinationAccountId,
            amountCents = amountCents,
            currency = "USD",
            memo = memo.ifBlank { "Payment request" },
            dueDateLabel = "In 7 days",
            statusLabel = "Requested — awaiting external sender (not received funds)",
            createdAtEpochMs = System.currentTimeMillis()
        )
        dao.upsertPaymentRequest(entity)
        return ApiOutcome.Success(
            PaymentRequest(
                entity.requestId, entity.fromParty, entity.destinationAccountId,
                entity.amountCents, entity.currency, entity.memo, entity.dueDateLabel, entity.statusLabel
            ),
            reqId
        )
    }

    // --- Deposit Demonstration (Synthetic validation + Hold separation) ---

    suspend fun submitSyntheticDeposit(
        customerId: String,
        accountId: String,
        amountCents: Long,
        documentLabel: String,
        mimeType: String,
        fileSizeBytes: Long
    ): ApiOutcome<DepositSubmission> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, accountId)?.let { return it }

        // Safe file validation & sensitive-data log redaction
        LogRedactor.redactDocumentBytes(fileSizeBytes.toInt(), mimeType)
        if (mimeType !in SUPPORTED_DEPOSIT_MIMES) {
            return ApiOutcome.Error("UNSUPPORTED_FILE_TYPE", "Only PNG, JPEG, or WebP synthetic cheque documents are supported.", 400, reqId)
        }
        if (fileSizeBytes <= 0L || fileSizeBytes > MAX_DEPOSIT_BYTES) {
            return ApiOutcome.Error("FILE_TOO_LARGE", "Document exceeds 5 MB limit.", 400, reqId)
        }
        if (amountCents <= 0L || amountCents > 500_000L) {
            return ApiOutcome.Error("INVALID_DEPOSIT_AMOUNT", "Demo cheque deposit limit is $5,000.00.", 422, reqId)
        }

        val depositId = "dep_${UUID.randomUUID().toString().take(8)}"
        val ref = "DEP-${UUID.randomUUID().toString().take(6).uppercase()}"
        val entity = DepositEntity(
            depositId = depositId,
            customerId = customerId,
            accountId = accountId,
            amountCents = amountCents,
            currency = "USD",
            documentLabel = documentLabel,
            mimeType = mimeType,
            fileSizeBytes = fileSizeBytes,
            status = DepositStatus.HELD_PENDING_AVAILABILITY.name,
            availabilityNote = "Submitted & under simulated review. Funds are NOT spendable until mock clearing completes.",
            reference = ref,
            createdAtEpochMs = System.currentTimeMillis()
        )
        dao.upsertDeposit(entity)
        return ApiOutcome.Success(
            DepositSubmission(
                depositId, accountId, amountCents, "USD", documentLabel, mimeType, fileSizeBytes,
                DepositStatus.HELD_PENDING_AVAILABILITY, entity.availabilityNote, ref
            ),
            reqId
        )
    }

    suspend fun releaseSimulatedDeposit(customerId: String, deposit: DepositSubmission): ApiOutcome<Unit> = ledgerMutex.withLock {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, deposit.accountId)?.let { return it }
        if (deposit.status == DepositStatus.AVAILABLE) return ApiOutcome.Success(Unit, reqId)

        val tsMs = System.currentTimeMillis()
        val tsLabel = nowLabel()
        val journalId = "jrn_${deposit.depositId}"
        dao.postBalancedJournalAtomically(
            journal = JournalEntity(journalId, customerId, deposit.reference, "Synthetic Cheque Deposit", tsMs, tsLabel),
            lines = listOf(
                LedgerLineEntity(
                    "${journalId}_1", journalId, deposit.accountId, "Cheque Deposit (${deposit.documentLabel})",
                    "Mock Cheque Clearing", deposit.amountCents, deposit.currency, TransactionDirection.CREDIT.name,
                    TransactionStatus.POSTED.name, SpendingCategory.EXCLUDED.name, tsMs, tsLabel, deposit.reference, null, null
                ),
                LedgerLineEntity(
                    "${journalId}_2", journalId, SYS_FUNDING, "Cheque Deposit Offset",
                    "Mock Cheque Clearing", deposit.amountCents, deposit.currency, TransactionDirection.DEBIT.name,
                    TransactionStatus.POSTED.name, SpendingCategory.EXCLUDED.name, tsMs, tsLabel, deposit.reference, null, null
                )
            )
        )
        dao.upsertDeposit(
            DepositEntity(
                deposit.depositId, customerId, deposit.accountId, deposit.amountCents, deposit.currency,
                deposit.documentLabel, deposit.mimeType, deposit.fileSizeBytes,
                DepositStatus.AVAILABLE.name,
                "Cleared via mock deposit provider adapter — funds now available.",
                deposit.reference, tsMs
            )
        )
        return ApiOutcome.Success(Unit, reqId)
    }

    // --- Cards & Mock Issuer Reconciliation ---

    suspend fun requestCardLockToggle(
        customerId: String,
        cardId: String,
        lock: Boolean
    ): ApiOutcome<BankCard> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        val card = dao.getCard(cardId)
            ?: return ApiOutcome.Error("CARD_NOT_FOUND", "Card not found.", 404, reqId)
        if (card.customerId != customerId) {
            return ApiOutcome.Error("FORBIDDEN", "Access denied.", 403, reqId)
        }

        val desired = if (lock) CardDesiredState.LOCK_REQUESTED else CardDesiredState.UNLOCK_REQUESTED
        // Step 1: persist requested state first (never falsely claim local toggle immediately locked physical card)
        val pendingCard = card.copy(
            desiredState = desired.name,
            issuerStatus = CardIssuerStatus.PENDING_ISSUER.name,
            lastSyncedLabel = "Awaiting mock issuer confirmation..."
        )
        dao.upsertCard(pendingCard)

        if (activeFaultMode == DemoFaultMode.PROVIDER_FAILURE || simulateOffline) {
            val unconfirmed = pendingCard.copy(
                issuerStatus = CardIssuerStatus.ISSUER_UNAVAILABLE.name,
                lastSyncedLabel = "Issuer unreachable — lock request pending reconciliation"
            )
            dao.upsertCard(unconfirmed)
            return ApiOutcome.Error(
                "ISSUER_UNAVAILABLE",
                "Mock issuer adapter unavailable. Desired state saved; actual card status remains unconfirmed.",
                503,
                reqId,
                recoverableByReconcile = true
            )
        }

        // Step 2: mock issuer adapter confirmation
        val confirmed = pendingCard.copy(
            desiredState = if (lock) CardDesiredState.LOCK_REQUESTED.name else CardDesiredState.ACTIVE.name,
            issuerStatus = if (lock) CardIssuerStatus.CONFIRMED_LOCKED.name else CardIssuerStatus.CONFIRMED_ACTIVE.name,
            lastSyncedLabel = "Mock-issuer confirmed ${nowLabel()}"
        )
        dao.upsertCard(confirmed)
        dao.insertNotification(
            NotificationEntity(
                notificationId = "notif_card_${UUID.randomUUID().toString().take(6)}",
                customerId = customerId,
                title = if (lock) "Card lock confirmed" else "Card unlocked",
                body = "${card.networkLabel} ••••${card.maskedLast4} is now ${if (lock) "locked" else "active"} per mock issuer.",
                lockScreenSafeBody = "A card status update occurred on your Crestline profile.",
                category = "Card",
                createdAtEpochMs = System.currentTimeMillis(),
                createdAtLabel = nowLabel(),
                deliveryStatus = "Delivered (In-App)",
                isRead = false
            )
        )
        return ApiOutcome.Success(confirmed.toDomain(), reqId)
    }

    suspend fun updateCardControls(
        customerId: String,
        cardId: String,
        dailyPurchaseCents: Long,
        dailyAtmCents: Long,
        onlineEnabled: Boolean,
        internationalEnabled: Boolean
    ): ApiOutcome<BankCard> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        val card = dao.getCard(cardId) ?: return ApiOutcome.Error("NOT_FOUND", "Card not found.", 404, reqId)
        if (card.customerId != customerId) return ApiOutcome.Error("FORBIDDEN", "Access denied.", 403, reqId)
        val updated = card.copy(
            dailyPurchaseLimitCents = dailyPurchaseCents,
            dailyAtmLimitCents = dailyAtmCents,
            onlinePaymentsEnabled = onlineEnabled,
            internationalEnabled = internationalEnabled,
            lastSyncedLabel = "Controls updated ${nowLabel()}"
        )
        dao.upsertCard(updated)
        return ApiOutcome.Success(updated.toDomain(), reqId)
    }

    suspend fun requestCardReplacement(customerId: String, cardId: String, lostStolen: Boolean): ApiOutcome<BankCard> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        val card = dao.getCard(cardId) ?: return ApiOutcome.Error("NOT_FOUND", "Card not found.", 404, reqId)
        if (card.customerId != customerId) return ApiOutcome.Error("FORBIDDEN", "Access denied.", 403, reqId)
        val updated = card.copy(
            desiredState = if (lostStolen) CardDesiredState.LOST_REPORTED.name else CardDesiredState.REPLACEMENT_REQUESTED.name,
            issuerStatus = if (lostStolen) CardIssuerStatus.FROZEN_LOST.name else CardIssuerStatus.REPLACEMENT_ISSUED.name,
            lastSyncedLabel = if (lostStolen) "Frozen as lost/stolen (${nowLabel()})" else "Replacement queued (${nowLabel()})"
        )
        dao.upsertCard(updated)
        return ApiOutcome.Success(updated.toDomain(), reqId)
    }

    // --- Insights Recategorisation & Statements ---

    suspend fun recategorizeTransaction(
        customerId: String,
        transactionId: String,
        newCategory: SpendingCategory
    ): ApiOutcome<Unit> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId)?.let { return it }
        val line = dao.getLedgerLine(transactionId)
            ?: return ApiOutcome.Error("NOT_FOUND", "Pending transactions cannot be recategorized until posted.", 404, reqId)
        val acc = dao.getAccount(line.accountId) ?: return ApiOutcome.Error("NOT_FOUND", "Account not found.", 404, reqId)
        if (acc.customerId != customerId) return ApiOutcome.Error("FORBIDDEN", "Access denied.", 403, reqId)
        dao.updateLedgerLineCategory(transactionId, newCategory.name)
        return ApiOutcome.Success(Unit, reqId)
    }

    suspend fun generateStatement(
        customerId: String,
        accountId: String,
        periodLabel: String = "November 2026"
    ): ApiOutcome<BankStatement> {
        val reqId = reqId()
        verifyAuthAndOwnership(customerId, accountId)?.let { return it }
        val acc = dao.getAccount(accountId)!!
        val lines = dao.getLedgerLinesForAccount(accountId).sortedBy { it.timestampEpochMs }

        val openingLine = lines.firstOrNull { it.reference.startsWith("OPEN-") }
        val openingCents = openingLine?.amountCents ?: 0L
        val nonOpening = lines.filter { it.lineId != openingLine?.lineId }

        val credits = nonOpening.filter { it.direction == TransactionDirection.CREDIT.name }.sumOf { it.amountCents }
        val debits = nonOpening.filter { it.direction == TransactionDirection.DEBIT.name }.sumOf { it.amountCents }
        val closingCents = if (acc.accountType == AccountType.CREDIT_CARD.name) {
            openingCents + debits - credits
        } else {
            openingCents + credits - debits
        }

        val stmtLines = nonOpening.map {
            StatementLine(
                dateLabel = it.timestampLabel,
                description = it.description,
                reference = it.reference,
                amountCents = it.amountCents,
                direction = TransactionDirection.valueOf(it.direction)
            )
        }
        val stmtId = "stmt_${UUID.randomUUID().toString().take(8)}"
        val entity = StatementEntity(
            statementId = stmtId,
            customerId = customerId,
            accountId = accountId,
            accountName = acc.name,
            maskedNumber = acc.maskedNumber,
            periodLabel = periodLabel,
            openingBalanceCents = openingCents,
            totalCreditsCents = credits,
            totalDebitsCents = debits,
            closingBalanceCents = closingCents,
            linesJson = json.encodeToString(stmtLines),
            generatedAtLabel = nowLabel()
        )
        dao.insertStatement(entity)
        dao.insertNotification(
            NotificationEntity(
                "notif_stmt_${UUID.randomUUID().toString().take(6)}",
                customerId,
                "Statement generated",
                "$periodLabel statement for ${acc.name} ${acc.maskedNumber} is ready.",
                "A monthly statement is ready to view.",
                "Statement",
                System.currentTimeMillis(),
                nowLabel(),
                "Delivered (In-App)",
                false
            )
        )
        return ApiOutcome.Success(
            BankStatement(
                stmtId, accountId, acc.name, acc.maskedNumber, periodLabel,
                openingCents, credits, debits, closingCents, stmtLines, entity.generatedAtLabel
            ),
            reqId
        )
    }

    suspend fun markAllNotificationsRead(customerId: String) {
        dao.markAllNotificationsRead(customerId)
    }

    suspend fun verifyLedgerBalanced(): Boolean {
        return (dao.verifyGlobalDoubleEntrySum() ?: 0L) == 0L
    }

    // --- Helpers & Mappers ---

    private fun computeAccountDomain(
        acc: AccountEntity,
        lines: List<LedgerLineEntity>,
        holds: List<PendingHoldEntity>
    ): BankAccount {
        val type = AccountType.valueOf(acc.accountType)
        val credits = lines.filter { it.direction == TransactionDirection.CREDIT.name }.sumOf { it.amountCents }
        val debits = lines.filter { it.direction == TransactionDirection.DEBIT.name }.sumOf { it.amountCents }
        val holdTotal = holds.filter { it.active }.sumOf { it.amountCents }

        val postedBalance = if (type == AccountType.CREDIT_CARD) {
            (debits - credits).coerceAtLeast(0L)
        } else {
            credits - debits
        }
        val availableBalance = if (type == AccountType.CREDIT_CARD) {
            (acc.creditLimitCents - postedBalance - holdTotal).coerceAtLeast(0L)
        } else {
            postedBalance - holdTotal
        }
        return BankAccount(
            accountId = acc.accountId,
            customerId = acc.customerId,
            name = acc.name,
            accountType = type,
            maskedNumber = acc.maskedNumber,
            currency = acc.currency,
            postedBalanceCents = postedBalance,
            pendingHoldCents = holdTotal,
            availableBalanceCents = availableBalance,
            creditLimitCents = acc.creditLimitCents,
            statementBalanceCents = acc.statementBalanceCents,
            minimumPaymentCents = acc.minimumPaymentCents,
            paymentDueDateLabel = acc.paymentDueDateLabel,
            version = acc.version
        )
    }

    private fun computeTermsHash(
        src: String,
        dst: String,
        amountCents: Long,
        currency: String,
        timing: TransferTiming
    ): String = sha256("$src|$dst|$amountCents|$currency|${timing.name}")

    private fun sha256(input: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun reqId(): String = "req_${UUID.randomUUID().toString().take(8)}"

    private fun nowLabel(): String =
        SimpleDateFormat("MMM d, h:mm a", Locale.US).format(Date())

    private fun CustomerEntity.toProfile() = CustomerProfile(
        customerId, fullName, firstName, email, phoneMasked,
        mfaEnabled, biometricEnabled, lockScreenRedactionEnabled,
        emailAlertsEnabled, pushAlertsEnabled
    )

    private fun DeviceSessionEntity.toDomain() = DeviceSession(
        sessionId, deviceName, lastActiveLabel, ipRegion,
        isCurrentDevice, accessExpiresAtEpochMs, refreshGeneration, revoked
    )

    private fun LedgerLineEntity.toDomain() = LedgerTransaction(
        transactionId = lineId,
        journalId = journalId,
        accountId = accountId,
        description = description,
        merchantOrCounterparty = merchantOrCounterparty,
        amountCents = amountCents,
        currency = currency,
        direction = TransactionDirection.valueOf(direction),
        status = TransactionStatus.valueOf(status),
        category = SpendingCategory.valueOf(category),
        timestampEpochMs = timestampEpochMs,
        timestampLabel = timestampLabel,
        reference = reference,
        linkedTransactionId = linkedLineId,
        notes = notes
    )

    private fun PendingHoldEntity.toTransaction() = LedgerTransaction(
        transactionId = holdId,
        journalId = holdId,
        accountId = accountId,
        description = description,
        merchantOrCounterparty = description,
        amountCents = amountCents,
        currency = currency,
        direction = TransactionDirection.DEBIT,
        status = TransactionStatus.PENDING,
        category = SpendingCategory.EXCLUDED,
        timestampEpochMs = createdAtEpochMs,
        timestampLabel = createdAtLabel,
        reference = reference
    )

    private fun TransferEntity.toDomain() = TransferRecord(
        transferId, customerId, sourceAccountId, destinationAccountId,
        sourceName, destinationName, amountCents, feeCents, currency,
        TransferTiming.valueOf(timing), TransferStatus.valueOf(status),
        idempotencyKey, termsHash, confirmationReference, failureReason,
        createdAtLabel, journalId
    )

    private fun TransferRecord.toEntity() = TransferEntity(
        transferId, customerId, sourceAccountId, destinationAccountId,
        sourceName, destinationName, amountCents, feeCents, currency,
        timing.name, status.name, idempotencyKey, termsHash,
        confirmationReference, failureReason, System.currentTimeMillis(),
        createdAtLabel, journalId
    )

    private fun CardEntity.toDomain() = BankCard(
        cardId, customerId, linkedAccountId, linkedAccountName,
        CardType.valueOf(cardType), holderName, maskedLast4, networkLabel,
        CardDesiredState.valueOf(desiredState), CardIssuerStatus.valueOf(issuerStatus),
        dailyPurchaseLimitCents, dailyAtmLimitCents, onlinePaymentsEnabled,
        internationalEnabled, issuerRuleNote, lastSyncedLabel
    )
}
