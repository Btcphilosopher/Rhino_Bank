package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "customers",
    indices = [Index(value = ["email"], unique = true)]
)
data class CustomerEntity(
    @PrimaryKey val customerId: String,
    val fullName: String,
    val firstName: String,
    val email: String,
    val phoneMasked: String,
    val passwordHashHex: String,
    val passwordSaltHex: String,
    val mfaEnabled: Boolean,
    val biometricEnabled: Boolean,
    val lockScreenRedactionEnabled: Boolean,
    val emailAlertsEnabled: Boolean,
    val pushAlertsEnabled: Boolean
)

@Entity(tableName = "device_sessions")
data class DeviceSessionEntity(
    @PrimaryKey val sessionId: String,
    val customerId: String,
    val deviceName: String,
    val lastActiveLabel: String,
    val ipRegion: String,
    val isCurrentDevice: Boolean,
    val refreshTokenHash: String,
    val accessToken: String,
    val accessExpiresAtEpochMs: Long,
    val refreshGeneration: Int,
    val revoked: Boolean
)

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val accountId: String,
    val customerId: String,
    val name: String,
    val accountType: String,
    val maskedNumber: String,
    val currency: String,
    val creditLimitCents: Long,
    val statementBalanceCents: Long,
    val minimumPaymentCents: Long,
    val paymentDueDateLabel: String?,
    val version: Long
)

@Entity(
    tableName = "journals",
    indices = [Index(value = ["businessReference"], unique = true)]
)
data class JournalEntity(
    @PrimaryKey val journalId: String,
    val customerId: String,
    val businessReference: String,
    val description: String,
    val createdAtEpochMs: Long,
    val createdAtLabel: String
)

@Entity(
    tableName = "ledger_lines",
    indices = [
        Index(value = ["accountId"]),
        Index(value = ["journalId"])
    ]
)
data class LedgerLineEntity(
    @PrimaryKey val lineId: String,
    val journalId: String,
    val accountId: String,
    val description: String,
    val merchantOrCounterparty: String,
    val amountCents: Long,
    val currency: String,
    val direction: String, // DEBIT or CREDIT
    val status: String,    // POSTED, REVERSED, ADJUSTMENT
    val category: String,
    val timestampEpochMs: Long,
    val timestampLabel: String,
    val reference: String,
    val linkedLineId: String?,
    val notes: String?
)

@Entity(
    tableName = "pending_holds",
    indices = [Index(value = ["accountId"])]
)
data class PendingHoldEntity(
    @PrimaryKey val holdId: String,
    val accountId: String,
    val description: String,
    val amountCents: Long,
    val currency: String,
    val createdAtEpochMs: Long,
    val createdAtLabel: String,
    val reference: String,
    val active: Boolean
)

@Entity(
    tableName = "transfers",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class TransferEntity(
    @PrimaryKey val transferId: String,
    val customerId: String,
    val sourceAccountId: String,
    val destinationAccountId: String,
    val sourceName: String,
    val destinationName: String,
    val amountCents: Long,
    val feeCents: Long,
    val currency: String,
    val timing: String,
    val status: String,
    val idempotencyKey: String,
    val termsHash: String,
    val confirmationReference: String?,
    val failureReason: String?,
    val createdAtEpochMs: Long,
    val createdAtLabel: String,
    val journalId: String?
)

@Entity(tableName = "payees")
data class PayeeEntity(
    @PrimaryKey val payeeId: String,
    val customerId: String,
    val name: String,
    val category: String,
    val maskedAccount: String,
    val verifiedByStepUp: Boolean
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val paymentId: String,
    val customerId: String,
    val sourceAccountId: String,
    val payeeId: String,
    val payeeName: String,
    val amountCents: Long,
    val currency: String,
    val scheduledForLabel: String,
    val isRecurring: Boolean,
    val status: String,
    val reference: String,
    val railNote: String,
    val createdAtEpochMs: Long
)

@Entity(tableName = "payment_requests")
data class PaymentRequestEntity(
    @PrimaryKey val requestId: String,
    val customerId: String,
    val fromParty: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val currency: String,
    val memo: String,
    val dueDateLabel: String,
    val statusLabel: String,
    val createdAtEpochMs: Long
)

@Entity(tableName = "deposits")
data class DepositEntity(
    @PrimaryKey val depositId: String,
    val customerId: String,
    val accountId: String,
    val amountCents: Long,
    val currency: String,
    val documentLabel: String,
    val mimeType: String,
    val fileSizeBytes: Long,
    val status: String,
    val availabilityNote: String,
    val reference: String,
    val createdAtEpochMs: Long
)

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey val cardId: String,
    val customerId: String,
    val linkedAccountId: String,
    val linkedAccountName: String,
    val cardType: String,
    val holderName: String,
    val maskedLast4: String,
    val networkLabel: String,
    val desiredState: String,
    val issuerStatus: String,
    val dailyPurchaseLimitCents: Long,
    val dailyAtmLimitCents: Long,
    val onlinePaymentsEnabled: Boolean,
    val internationalEnabled: Boolean,
    val issuerRuleNote: String,
    val lastSyncedLabel: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val notificationId: String,
    val customerId: String,
    val title: String,
    val body: String,
    val lockScreenSafeBody: String,
    val category: String,
    val createdAtEpochMs: Long,
    val createdAtLabel: String,
    val deliveryStatus: String,
    val isRead: Boolean
)

@Entity(tableName = "statements")
data class StatementEntity(
    @PrimaryKey val statementId: String,
    val customerId: String,
    val accountId: String,
    val accountName: String,
    val maskedNumber: String,
    val periodLabel: String,
    val openingBalanceCents: Long,
    val totalCreditsCents: Long,
    val totalDebitsCents: Long,
    val closingBalanceCents: Long,
    val linesJson: String,
    val generatedAtLabel: String
)

@Entity(tableName = "outbox_actions")
data class OutboxActionEntity(
    @PrimaryKey val actionId: String,
    val customerId: String,
    val actionType: String,
    val payloadJson: String,
    val status: String, // QUEUED_OFFLINE, RECONCILING, FAILED
    val createdAtEpochMs: Long
)
