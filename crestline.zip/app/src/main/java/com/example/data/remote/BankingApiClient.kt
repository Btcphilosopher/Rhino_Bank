package com.example.data.remote

import com.example.data.local.SecurityCryptoManager
import com.example.domain.ApiOutcome
import com.example.domain.BankAccount
import com.example.domain.BankCard
import com.example.domain.BankStatement
import com.example.domain.LedgerTransaction
import com.example.domain.LogRedactor
import com.example.domain.NotificationItem
import com.example.domain.SpendingInsights
import com.example.domain.TransferRecord
import com.example.domain.TransferTiming
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.util.UUID
import java.util.concurrent.TimeUnit

@Serializable
data class LoginApiRequest(
    val email: String,
    val password: String,
    val deviceName: String,
    val mfaCode: String? = null
)

@Serializable
data class LoginApiResponse(
    val customerId: String,
    val sessionId: String,
    val accessToken: String,
    val refreshToken: String,
    val accessExpiresAtEpochMs: Long,
    val mfaRequired: Boolean = false
)

@Serializable
data class RefreshApiRequest(val sessionId: String, val refreshToken: String)

@Serializable
data class TransferPreviewApiRequest(
    val sourceAccountId: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val currency: String = "USD",
    val timing: TransferTiming = TransferTiming.TODAY
)

@Serializable
data class TransferCreateApiRequest(
    val transferId: String,
    val sourceAccountId: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val currency: String = "USD",
    val timing: TransferTiming,
    val idempotencyKey: String,
    val termsHash: String
)

@Serializable
data class CardLockApiRequest(val lock: Boolean, val reason: String = "Customer toggle")

@Serializable
data class ApiErrorPayload(
    val code: String,
    val message: String,
    val requestId: String? = null
)

/**
 * Real HTTPS/TLS REST client targeting the Kotlin + Ktor backend service.
 * Enforces TLS on non-local endpoints and redacts credentials from HTTP logs.
 */
class BankingApiClient {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(
            HttpLoggingInterceptor { message ->
                // Redact sensitive tokens/credentials from diagnostic logs
                LogRedactor.redact(message)
            }.apply { level = HttpLoggingInterceptor.Level.BASIC }
        )
        .build()

    suspend fun login(baseUrl: String, request: LoginApiRequest): ApiOutcome<LoginApiResponse> =
        post(baseUrl, "/auth/login", null, null, json.encodeToString(request))

    suspend fun refresh(baseUrl: String, request: RefreshApiRequest): ApiOutcome<LoginApiResponse> =
        post(baseUrl, "/auth/refresh", null, null, json.encodeToString(request))

    suspend fun logout(baseUrl: String, accessToken: String): ApiOutcome<Map<String, String>> =
        post(baseUrl, "/auth/logout", accessToken, null, "{}")

    suspend fun getAccounts(baseUrl: String, accessToken: String): ApiOutcome<List<BankAccount>> =
        get(baseUrl, "/accounts", accessToken)

    suspend fun getAccountTransactions(
        baseUrl: String,
        accessToken: String,
        accountId: String
    ): ApiOutcome<List<LedgerTransaction>> =
        get(baseUrl, "/accounts/$accountId/transactions", accessToken)

    suspend fun previewTransfer(
        baseUrl: String,
        accessToken: String,
        request: TransferPreviewApiRequest
    ): ApiOutcome<TransferRecord> =
        post(baseUrl, "/transfers/preview", accessToken, null, json.encodeToString(request))

    suspend fun executeTransfer(
        baseUrl: String,
        accessToken: String,
        request: TransferCreateApiRequest
    ): ApiOutcome<TransferRecord> =
        post(
            baseUrl,
            "/transfers",
            accessToken,
            request.idempotencyKey,
            json.encodeToString(request)
        )

    suspend fun getTransfer(
        baseUrl: String,
        accessToken: String,
        transferId: String
    ): ApiOutcome<TransferRecord> =
        get(baseUrl, "/transfers/$transferId", accessToken)

    suspend fun getCards(baseUrl: String, accessToken: String): ApiOutcome<List<BankCard>> =
        get(baseUrl, "/cards", accessToken)

    suspend fun requestCardLock(
        baseUrl: String,
        accessToken: String,
        cardId: String,
        request: CardLockApiRequest
    ): ApiOutcome<BankCard> =
        post(
            baseUrl,
            "/cards/$cardId/lock-requests",
            accessToken,
            UUID.randomUUID().toString(),
            json.encodeToString(request)
        )

    suspend fun getSpendingInsights(
        baseUrl: String,
        accessToken: String
    ): ApiOutcome<SpendingInsights> =
        get(baseUrl, "/insights/spending", accessToken)

    suspend fun getStatements(
        baseUrl: String,
        accessToken: String
    ): ApiOutcome<List<BankStatement>> =
        get(baseUrl, "/statements", accessToken)

    suspend fun getNotifications(
        baseUrl: String,
        accessToken: String
    ): ApiOutcome<List<NotificationItem>> =
        get(baseUrl, "/notifications", accessToken)

    private suspend inline fun <reified T> get(
        baseUrl: String,
        path: String,
        accessToken: String?
    ): ApiOutcome<T> = executeRequest(baseUrl, path, "GET", accessToken, null, null)

    private suspend inline fun <reified T> post(
        baseUrl: String,
        path: String,
        accessToken: String?,
        idempotencyKey: String?,
        bodyJson: String
    ): ApiOutcome<T> = executeRequest(baseUrl, path, "POST", accessToken, idempotencyKey, bodyJson)

    private suspend inline fun <reified T> executeRequest(
        baseUrl: String,
        path: String,
        method: String,
        accessToken: String?,
        idempotencyKey: String?,
        bodyJson: String?
    ): ApiOutcome<T> = withContext(Dispatchers.IO) {
        val cleanBase = baseUrl.trimEnd('/')
        val requestId = "req_${UUID.randomUUID().toString().take(8)}"
        if (!SecurityCryptoManager.validateTlsEndpoint(cleanBase)) {
            return@withContext ApiOutcome.Error(
                code = "TLS_REQUIRED",
                message = "Deployed backend endpoints must use HTTPS/TLS.",
                httpStatus = 400,
                requestId = requestId
            )
        }
        val builder = Request.Builder()
            .url("$cleanBase$path")
            .header("X-Request-Id", requestId)
            .header("Accept", "application/json")
        if (accessToken != null) {
            builder.header("Authorization", "Bearer $accessToken")
        }
        if (idempotencyKey != null) {
            builder.header("Idempotency-Key", idempotencyKey)
        }
        if (method == "POST") {
            builder.post((bodyJson ?: "{}").toRequestBody(jsonMediaType))
        } else {
            builder.get()
        }
        return@withContext try {
            client.newCall(builder.build()).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                val respReqId = response.header("X-Request-Id") ?: requestId
                if (response.isSuccessful) {
                    val parsed = json.decodeFromString<T>(raw)
                    ApiOutcome.Success(parsed, respReqId)
                } else {
                    val err = runCatching { json.decodeFromString<ApiErrorPayload>(raw) }.getOrNull()
                    ApiOutcome.Error(
                        code = err?.code ?: "HTTP_${response.code}",
                        message = err?.message ?: "Request failed with status ${response.code}",
                        httpStatus = response.code,
                        requestId = err?.requestId ?: respReqId
                    )
                }
            }
        } catch (e: Exception) {
            ApiOutcome.Error(
                code = "NETWORK_UNCERTAIN",
                message = e.message ?: "Connection interrupted before confirmation.",
                httpStatus = 504,
                requestId = requestId,
                recoverableByReconcile = true
            )
        }
    }
}
