package com.example.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

private val Context.securePrefsDataStore by preferencesDataStore(name = "crestline_secure_prefs")

data class StoredSessionTokens(
    val customerId: String,
    val sessionId: String,
    val accessToken: String,
    val refreshToken: String,
    val accessExpiresAtEpochMs: Long
)

data class AppPreferences(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val reducedMotion: Boolean = false,
    val backendBaseUrl: String = "",
    val lastSyncedEpochMs: Long = 0L
)

/**
 * Manages Android Keystore-backed AES-GCM encryption for session credentials
 * and salted PBKDF2 password hashing for demonstration accounts.
 */
class SecurityCryptoManager(private val context: Context) {

    companion object {
        private const val KEYSTORE_ALIAS = "crestline_session_master_key"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val AES_GCM = "AES/GCM/NoPadding"

        private val KEY_ENC_SESSION = stringPreferencesKey("enc_session_payload")
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        private val KEY_BACKEND_URL = stringPreferencesKey("backend_url")
        private val KEY_LAST_SYNC_MS = longPreferencesKey("last_sync_ms")

        private val fallbackKeyBytes = "CrestlineTestFallback32ByteKey!!".toByteArray()

        fun hashPassword(password: String, saltHex: String? = null): Pair<String, String> {
            val salt = if (saltHex != null) {
                saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            } else {
                ByteArray(16).also { SecureRandom().nextBytes(it) }
            }
            val spec = PBEKeySpec(password.toCharArray(), salt, 65536, 256)
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val hash = factory.generateSecret(spec).encoded
            return hash.toHex() to salt.toHex()
        }

        fun verifyPassword(password: String, expectedHashHex: String, saltHex: String): Boolean {
            val (actualHashHex, _) = hashPassword(password, saltHex)
            return MessageDigest.isEqual(
                actualHashHex.toByteArray(Charsets.UTF_8),
                expectedHashHex.toByteArray(Charsets.UTF_8)
            )
        }

        fun validateTlsEndpoint(url: String): Boolean {
            val trimmed = url.trim()
            if (trimmed.isEmpty()) return true // Local embedded engine mode
            return trimmed.startsWith("https://", ignoreCase = true) ||
                trimmed.startsWith("http://10.0.2.2", ignoreCase = true) ||
                trimmed.startsWith("http://localhost", ignoreCase = true) ||
                trimmed.startsWith("http://127.0.0.1", ignoreCase = true)
        }

        private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
    }

    val preferencesFlow: Flow<AppPreferences> = context.securePrefsDataStore.data.map { prefs ->
        val theme = prefs[KEY_THEME_MODE]?.let { name ->
            ThemeMode.entries.firstOrNull { it.name == name }
        } ?: ThemeMode.SYSTEM
        AppPreferences(
            themeMode = theme,
            reducedMotion = prefs[KEY_REDUCED_MOTION] ?: false,
            backendBaseUrl = prefs[KEY_BACKEND_URL] ?: "",
            lastSyncedEpochMs = prefs[KEY_LAST_SYNC_MS] ?: 0L
        )
    }

    suspend fun saveThemeMode(mode: ThemeMode) {
        context.securePrefsDataStore.edit { it[KEY_THEME_MODE] = mode.name }
    }

    suspend fun saveReducedMotion(enabled: Boolean) {
        context.securePrefsDataStore.edit { it[KEY_REDUCED_MOTION] = enabled }
    }

    suspend fun saveBackendUrl(url: String): Boolean {
        val trimmed = url.trim()
        if (!validateTlsEndpoint(trimmed)) return false
        context.securePrefsDataStore.edit { it[KEY_BACKEND_URL] = trimmed }
        return true
    }

    suspend fun updateLastSynced(epochMs: Long) {
        context.securePrefsDataStore.edit { it[KEY_LAST_SYNC_MS] = epochMs }
    }

    suspend fun saveSessionTokens(tokens: StoredSessionTokens) {
        val payload = listOf(
            tokens.customerId,
            tokens.sessionId,
            tokens.accessToken,
            tokens.refreshToken,
            tokens.accessExpiresAtEpochMs.toString()
        ).joinToString("|")
        val encrypted = encryptString(payload)
        context.securePrefsDataStore.edit { it[KEY_ENC_SESSION] = encrypted }
    }

    suspend fun readSessionTokens(): StoredSessionTokens? {
        val prefs = context.securePrefsDataStore.data.first()
        val encrypted = prefs[KEY_ENC_SESSION] ?: return null
        val decrypted = decryptString(encrypted) ?: return null
        val parts = decrypted.split("|")
        if (parts.size != 5) return null
        return StoredSessionTokens(
            customerId = parts[0],
            sessionId = parts[1],
            accessToken = parts[2],
            refreshToken = parts[3],
            accessExpiresAtEpochMs = parts[4].toLongOrNull() ?: return null
        )
    }

    suspend fun clearSessionTokens() {
        context.securePrefsDataStore.edit { it.remove(KEY_ENC_SESSION) }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            (keyStore.getKey(KEYSTORE_ALIAS, null) as? SecretKey) ?: run {
                val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                generator.init(
                    KeyGenParameterSpec.Builder(
                        KEYSTORE_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                )
                generator.generateKey()
            }
        } catch (_: Exception) {
            // Fallback only for JVM Robolectric unit tests lacking AndroidKeyStore
            SecretKeySpec(fallbackKeyBytes, "AES")
        }
    }

    private fun encryptString(plaintext: String): String {
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        val ctB64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP)
        return "$ivB64:$ctB64"
    }

    private fun decryptString(encoded: String): String? {
        return try {
            val parts = encoded.split(":")
            if (parts.size != 2) return null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ct = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance(AES_GCM)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }
}
