package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.engine.AuthoritativeBankingEngine
import com.example.domain.ThemeMode
import com.example.ui.BankingUiState
import com.example.ui.BankingViewModel
import com.example.ui.components.CrestlineBottomBar
import com.example.ui.components.CrestlineNavRail
import com.example.ui.components.CrestlineTopBar
import com.example.ui.components.MainNavTab
import com.example.ui.navigation.AccountDetailRoute
import com.example.ui.navigation.AssistantRoute
import com.example.ui.navigation.CardsRoute
import com.example.ui.navigation.DepositRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.InsightsRoute
import com.example.ui.navigation.NotificationsStatementsRoute
import com.example.ui.navigation.PayTransferRoute
import com.example.ui.navigation.ProfileRoute
import com.example.ui.screens.AccountDetailScreen
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.CardsScreen
import com.example.ui.screens.DepositScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InsightsScreen
import com.example.ui.screens.NotificationsStatementsScreen
import com.example.ui.screens.PayTransferScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SignInScreen
import com.example.ui.theme.CrestlineTheme

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: BankingViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            val darkTheme = when (uiState.preferences.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            CrestlineTheme(
                darkTheme = darkTheme,
                reducedMotion = uiState.preferences.reducedMotion
            ) {
                CrestlineAppRoot(uiState = uiState, viewModel = viewModel)
            }
        }
    }
}

@Composable
fun CrestlineAppRoot(
    uiState: BankingUiState,
    viewModel: BankingViewModel
) {
    if (uiState.isInitializing) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (uiState.currentCustomer == null) {
        SignInScreen(
            uiState = uiState,
            onSignIn = { email, pwd, mfa -> viewModel.signIn(email, pwd, mfa) },
            onSignInDemoAlex = { viewModel.signInAsDemoAlex() },
            onCreateDemoAccount = { name, email, pwd -> viewModel.createDemoAccount(name, email, pwd) }
        )
        return
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination

    val currentMainTab = when {
        destination?.hasRoute<HomeRoute>() == true -> MainNavTab.HOME
        destination?.hasRoute<PayTransferRoute>() == true -> MainNavTab.PAY_TRANSFER
        destination?.hasRoute<CardsRoute>() == true -> MainNavTab.CARDS
        destination?.hasRoute<InsightsRoute>() == true -> MainNavTab.INSIGHTS
        else -> null
    }

    fun navigateTopTab(tab: MainNavTab) {
        val route: Any = when (tab) {
            MainNavTab.HOME -> HomeRoute
            MainNavTab.PAY_TRANSFER -> PayTransferRoute()
            MainNavTab.CARDS -> CardsRoute
            MainNavTab.INSIGHTS -> InsightsRoute
        }
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 700.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavRail && currentMainTab != null) {
                CrestlineNavRail(
                    selectedTab = currentMainTab,
                    onSelectTab = ::navigateTopTab
                )
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                topBar = {
                    CrestlineTopBar(
                        showBack = currentMainTab == null,
                        onBackClick = { navController.popBackStack() },
                        unreadNotifications = uiState.unreadNotificationCount,
                        isOnline = uiState.serviceStatus.isOnlineMode,
                        onNotificationsClick = {
                            navController.navigate(NotificationsStatementsRoute(initialTab = 0))
                        },
                        onProfileClick = {
                            navController.navigate(ProfileRoute)
                        }
                    )
                },
                bottomBar = {
                    if (!useNavRail && currentMainTab != null) {
                        CrestlineBottomBar(
                            selectedTab = currentMainTab,
                            onSelectTab = ::navigateTopTab
                        )
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = HomeRoute,
                    modifier = Modifier.padding(innerPadding)
                ) {
                    composable<HomeRoute> {
                        HomeScreen(
                            uiState = uiState,
                            onPayClick = {
                                navController.navigate(PayTransferRoute(initialMode = "PAY"))
                            },
                            onTransferClick = {
                                navController.navigate(PayTransferRoute(initialMode = "TRANSFER"))
                            },
                            onDepositClick = {
                                navController.navigate(DepositRoute)
                            },
                            onCardsClick = { navigateTopTab(MainNavTab.CARDS) },
                            onAccountClick = { accountId ->
                                navController.navigate(AccountDetailRoute(accountId))
                            },
                            onSeeNotificationsClick = {
                                navController.navigate(NotificationsStatementsRoute(initialTab = 0))
                            }
                        )
                    }
                    composable<PayTransferRoute> { entry ->
                        val args = entry.toRoute<PayTransferRoute>()
                        PayTransferScreen(
                            uiState = uiState,
                            initialMode = args.initialMode,
                            onPreviewTransfer = { src, dst, amt, timing ->
                                viewModel.previewTransfer(src, dst, amt, timing)
                            },
                            onInvalidateDraft = { viewModel.invalidateDraftOnTermsChanged() },
                            onAuthoriseTransfer = { viewModel.authoriseAndExecuteTransfer() },
                            onRetryReconcileTransfer = { viewModel.retryOrReconcileLastTransfer() },
                            onCancelDraft = { viewModel.cancelDraftTransfer() },
                            onDismissConfirmation = { viewModel.dismissTransferConfirmation() },
                            onSetFaultMode = { viewModel.setFaultMode(it) },
                            onAddPayee = { name, cat, digits, stepUp ->
                                viewModel.addPayee(name, cat, digits, stepUp)
                            },
                            onSubmitBillPayment = { src, pid, pname, amt, today, rec ->
                                viewModel.submitBillPayment(src, pid, pname, amt, today, rec)
                            },
                            onRunScheduledWorker = { viewModel.runScheduledPaymentsWorker() },
                            onCreatePaymentRequest = { from, dst, amt, memo ->
                                viewModel.createPaymentRequest(from, dst, amt, memo)
                            }
                        )
                    }
                    composable<CardsRoute> {
                        CardsScreen(
                            uiState = uiState,
                            onToggleCardLock = { cardId, lock -> viewModel.toggleCardLock(cardId, lock) },
                            onUpdateControls = { cid, p, a, onl, intl ->
                                viewModel.updateCardControls(cid, p, a, onl, intl)
                            },
                            onRequestReplacement = { cid, lost -> viewModel.requestCardReplacement(cid, lost) },
                            onOpenInsights = { navigateTopTab(MainNavTab.INSIGHTS) },
                            onOpenCreditAccount = { accId ->
                                navController.navigate(AccountDetailRoute(accId))
                            },
                            onPayCreditCard = {
                                navController.navigate(PayTransferRoute(initialMode = "TRANSFER"))
                            }
                        )
                    }
                    composable<InsightsRoute> {
                        InsightsScreen(
                            uiState = uiState,
                            onRecategorize = { txId, cat -> viewModel.recategorizeTransaction(txId, cat) },
                            onOpenAssistant = { navController.navigate(AssistantRoute) }
                        )
                    }
                    composable<AccountDetailRoute> { entry ->
                        val args = entry.toRoute<AccountDetailRoute>()
                        AccountDetailScreen(
                            accountId = args.accountId,
                            uiState = uiState,
                            onTransferFromHere = { navController.navigate(PayTransferRoute("TRANSFER")) },
                            onDepositHere = { navController.navigate(DepositRoute) },
                            onGenerateStatement = { viewModel.generateStatement(it) },
                            onOpenStatements = { navController.navigate(NotificationsStatementsRoute(initialTab = 1)) },
                            onCreateLinkedAdjustment = { txId, reason ->
                                viewModel.createAdjustment(txId, reason)
                            }
                        )
                    }
                    composable<DepositRoute> {
                        DepositScreen(
                            uiState = uiState,
                            onSubmitDeposit = { accId, amt, label, mime, size ->
                                viewModel.submitSyntheticDeposit(accId, amt, label, mime, size)
                            },
                            onSimulateClear = { viewModel.releaseSimulatedDeposit(it) }
                        )
                    }
                    composable<NotificationsStatementsRoute> { entry ->
                        val args = entry.toRoute<NotificationsStatementsRoute>()
                        NotificationsStatementsScreen(
                            uiState = uiState,
                            initialTab = args.initialTab,
                            onMarkNotificationsRead = { viewModel.markNotificationsRead() },
                            onGenerateStatement = { viewModel.generateStatement(it) }
                        )
                    }
                    composable<ProfileRoute> {
                        ProfileScreen(
                            uiState = uiState,
                            onUpdateProfilePrefs = { mfa, bio, red, em, push ->
                                viewModel.updateProfilePreferences(mfa, bio, red, em, push)
                            },
                            onSetThemeMode = { viewModel.setThemeMode(it) },
                            onSetReducedMotion = { viewModel.setReducedMotion(it) },
                            onSetOfflineMode = { viewModel.setOfflineMode(it) },
                            onSetBackendUrl = { viewModel.setBackendUrl(it) },
                            onRefreshToken = { viewModel.refreshSessionTokens() },
                            onSimulateExpiredToken = { viewModel.simulateExpiredToken() },
                            onRevokeSession = { viewModel.revokeSession(it) },
                            onSignOut = { viewModel.signOut() }
                        )
                    }
                    composable<AssistantRoute> {
                        AssistantScreen(
                            uiState = uiState,
                            onSendPrompt = { viewModel.askAssistant(it) },
                            onNavigateRoute = { key ->
                                when (key) {
                                    "HOME" -> navigateTopTab(MainNavTab.HOME)
                                    "TRANSFER" -> navController.navigate(PayTransferRoute("TRANSFER"))
                                    "CARDS" -> navigateTopTab(MainNavTab.CARDS)
                                    "INSIGHTS" -> navigateTopTab(MainNavTab.INSIGHTS)
                                    "ACCOUNT_CHECKING" -> navController.navigate(
                                        AccountDetailRoute(AuthoritativeBankingEngine.CHECKING_ACCOUNT_ID)
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
