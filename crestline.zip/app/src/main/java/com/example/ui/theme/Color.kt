package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luminous White & Pale-Blue Surfaces (Light Mode)
val LuminousWhite = Color(0xFFFFFFFF)
val PaleIceCanvas = Color(0xFFF5F8FE)
val SoftBlueTint = Color(0xFFECF2FC)
val SubtleBorderLight = Color(0xFFE1EAF7)
val CardShadowTint = Color(0x140B2A5B)

// Cobalt-Blue Primary Actions & Hero Palette
val CobaltPrimary = Color(0xFF0D5BDF)
val DeepCobalt = Color(0xFF084AAA)
val RoyalBlueAccent = Color(0xFF1466EA)
val DarkCardNavy = Color(0xFF071D49)
val DarkCardMid = Color(0xFF0A3B94)

// Midnight-Navy Typography
val MidnightNavy = Color(0xFF0B1B38)
val SlateNavy = Color(0xFF526583)
val MutedSlate = Color(0xFF7B8CA8)

// Semantic Status Colors (High Contrast)
val EmeraldPositive = Color(0xFF0C8C57)
val EmeraldContainerLight = Color(0xFFE7F7F0)
val AmberWarning = Color(0xFFB46900)
val AmberContainerLight = Color(0xFFFFF4E0)
val CrimsonError = Color(0xFFC53030)
val CrimsonContainerLight = Color(0xFFFDECEC)

// Dark Mode Tokens
val NightCanvas = Color(0xFF071020)
val NightSurface = Color(0xFF0F1C33)
val NightSurfaceElevated = Color(0xFF172847)
val NightBorder = Color(0xFF243A61)
val CobaltDarkPrimary = Color(0xFF4E95FF)
val NightTextPrimary = Color(0xFFF0F5FF)
val NightTextSecondary = Color(0xFFA7B8D4)
val EmeraldDark = Color(0xFF3FD596)
val AmberDark = Color(0xFFFFB74D)
val CrimsonDark = Color(0xFFFF6B6B)
