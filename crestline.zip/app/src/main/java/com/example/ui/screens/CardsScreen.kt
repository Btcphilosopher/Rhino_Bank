package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.BankCard
import com.example.domain.CardIssuerStatus
import com.example.domain.CurrencyFormatter
import com.example.domain.SpendingCategory
import com.example.ui.BankingUiState
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.components.VirtualDebitCardVisual
import com.example.ui.theme.LocalCrestlineColors

@Composable
fun CardsScreen(
    uiState: BankingUiState,
    onToggleCardLock: (cardId: String, lock: Boolean) -> Unit,
    onUpdateControls: (cardId: String, dailyPurchaseCents: Long, dailyAtmCents: Long, online: Boolean, intl: Boolean) -> Unit,
    onRequestReplacement: (cardId: String, lostStolen: Boolean) -> Unit,
    onOpenInsights: () -> Unit,
    onOpenCreditAccount: (String) -> Unit,
    onPayCreditCard: () -> Unit
) {
    val ext = LocalCrestlineColors.current
    var selectedCardIndex by remember { mutableStateOf(0) }
    val cards = uiState.cards
    val activeCard = cards.getOrNull(selectedCardIndex) ?: cards.firstOrNull()
    var showCardSettingsDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your cards",
                        style = MaterialTheme.typography.displayMedium.copy(fontSize = 28.sp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (cards.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            cards.forEachIndexed { idx, c ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (idx == selectedCardIndex) MaterialTheme.colorScheme.primary else ext.softTile,
                                    modifier = Modifier.clickable { selectedCardIndex = idx }
                                ) {
                                    Text(
                                        text = "${c.networkLabel} ••${c.maskedLast4}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (idx == selectedCardIndex) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                if (activeCard != null) {
                    VirtualDebitCardVisual(card = activeCard)

                    // Mockup's split card control bar: Lock card [Switch] | Card settings >
                    val isLockedOrRequested = activeCard.issuerStatus == CardIssuerStatus.CONFIRMED_LOCKED ||
                        activeCard.desiredState == com.example.domain.CardDesiredState.LOCK_REQUESTED

                    ElevatedSurfaceCard {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Lock,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Lock card",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Switch(
                                        checked = isLockedOrRequested,
                                        onCheckedChange = { checked ->
                                            onToggleCardLock(activeCard.cardId, checked)
                                        },
                                        modifier = Modifier
                                            .semantics { contentDescription = "Toggle card lock request" }
                                            .testTag("lock_card_switch")
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .height(28.dp)
                                        .width(1.dp)
                                        .background(ext.cardBorder)
                                )

                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .minimumInteractiveComponentSize()
                                        .clickable { showCardSettingsDialog = true }
                                        .padding(start = 12.dp)
                                        .testTag("card_settings_button"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Settings,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text("Card settings", style = MaterialTheme.typography.titleSmall)
                                    }
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                                }
                            }
                            HorizontalDivider(color = ext.cardBorder)
                            // Separate requested state vs mock-issuer confirmed status
                            Column(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Requested: ${activeCard.desiredState.name.replace('_', ' ')}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Issuer: ${activeCard.issuerStatus.name.replace('_', ' ')}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = when (activeCard.issuerStatus) {
                                            CardIssuerStatus.CONFIRMED_ACTIVE -> ext.positive
                                            CardIssuerStatus.CONFIRMED_LOCKED -> MaterialTheme.colorScheme.primary
                                            else -> ext.warning
                                        },
                                        modifier = Modifier.testTag("card_issuer_status")
                                    )
                                }
                                Text(
                                    text = "${activeCard.issuerRuleNote} (${activeCard.lastSyncedLabel})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Credit-card separate accounting summary card
                uiState.creditCardAccount?.let { cc ->
                    ElevatedSurfaceCard {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Credit card account ${cc.maskedNumber}", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Separate from checking & savings deposits",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = CurrencyFormatter.formatCents(cc.postedBalanceCents),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Statement: ${CurrencyFormatter.formatCents(cc.statementBalanceCents)}", style = MaterialTheme.typography.bodySmall)
                                Text("Available credit: ${CurrencyFormatter.formatCents(cc.availableBalanceCents)}", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Min payment: ${CurrencyFormatter.formatCents(cc.minimumPaymentCents)}", style = MaterialTheme.typography.bodySmall)
                                Text("Due: ${cc.paymentDueDateLabel ?: "Dec 12"}", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = onPayCreditCard,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Pay card")
                                }
                                OutlinedButton(
                                    onClick = { onOpenCreditAccount(cc.accountId) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Activity")
                                }
                            }
                        }
                    }
                }

                // Mockup's Spending this month summary card
                uiState.insights?.let { insights ->
                    ElevatedSurfaceCard {
                        Column(
                            modifier = Modifier
                                .clickable(onClick = onOpenInsights)
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Spending this month",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = CurrencyFormatter.formatCents(insights.totalCents),
                                style = MaterialTheme.typography.displayMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            insights.categories.forEach { cat ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = categoryIcon(cat.category),
                                        contentDescription = cat.category.displayName,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = cat.category.displayName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.width(76.dp)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(10.dp)
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(ext.softTile)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .fillMaxWidth(cat.shareFraction.coerceIn(0.05f, 1f))
                                                .clip(RoundedCornerShape(5.dp))
                                                .background(MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                    Text(
                                        text = CurrencyFormatter.formatCents(cat.totalCents),
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                                    )
                                }
                            }
                            Text(
                                text = "Illustrative categorisation • Tap for full insights",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Upcoming section matching mockup's Rent payment row
                    Text(
                        text = "Upcoming",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    insights.upcomingItems.take(1).forEach { up ->
                        ElevatedSurfaceCard {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(onClick = onOpenInsights)
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(ext.softTile),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(up.title, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${CurrencyFormatter.formatCents(up.amountCents)} • ${up.dueDateLabel} (${up.sourceNote})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                            }
                        }
                    }
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    if (showCardSettingsDialog && activeCard != null) {
        CardSettingsDialog(
            card = activeCard,
            onDismiss = { showCardSettingsDialog = false },
            onSave = { purchaseCents, atmCents, online, intl ->
                onUpdateControls(activeCard.cardId, purchaseCents, atmCents, online, intl)
                showCardSettingsDialog = false
            },
            onRequestReplacement = { lost ->
                onRequestReplacement(activeCard.cardId, lost)
                showCardSettingsDialog = false
            }
        )
    }
}

@Composable
private fun CardSettingsDialog(
    card: BankCard,
    onDismiss: () -> Unit,
    onSave: (Long, Long, Boolean, Boolean) -> Unit,
    onRequestReplacement: (Boolean) -> Unit
) {
    var purchaseLimitDollars by remember(card) { mutableFloatStateOf((card.dailyPurchaseLimitCents / 100L).toFloat()) }
    var atmLimitDollars by remember(card) { mutableFloatStateOf((card.dailyAtmLimitCents / 100L).toFloat()) }
    var onlineEnabled by remember(card) { mutableStateOf(card.onlinePaymentsEnabled) }
    var intlEnabled by remember(card) { mutableStateOf(card.internationalEnabled) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Card settings ••••${card.maskedLast4}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Linked account: ${card.linkedAccountName}", style = MaterialTheme.typography.bodySmall)
                Text("Daily purchase limit: $${purchaseLimitDollars.toInt()}")
                Slider(
                    value = purchaseLimitDollars,
                    onValueChange = { purchaseLimitDollars = it },
                    valueRange = 200f..5000f
                )
                Text("Daily ATM limit: $${atmLimitDollars.toInt()}")
                Slider(
                    value = atmLimitDollars,
                    onValueChange = { atmLimitDollars = it },
                    valueRange = 100f..1500f
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Online & wallet payments")
                    Switch(checked = onlineEnabled, onCheckedChange = { onlineEnabled = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("International transactions")
                    Switch(checked = intlEnabled, onCheckedChange = { intlEnabled = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onRequestReplacement(false) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Replace card", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = { onRequestReplacement(true) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Report lost", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(purchaseLimitDollars.toLong() * 100L, atmLimitDollars.toLong() * 100L, onlineEnabled, intlEnabled)
            }) {
                Text("Save controls")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

fun categoryIcon(cat: SpendingCategory) = when (cat) {
    SpendingCategory.DINING -> Icons.Filled.Restaurant
    SpendingCategory.SHOPPING -> Icons.Filled.ShoppingBag
    SpendingCategory.TRAVEL -> Icons.Filled.Flight
    SpendingCategory.OTHER -> Icons.Filled.MoreHoriz
    SpendingCategory.EXCLUDED -> Icons.Filled.DirectionsCar
}
