package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.ThemeMode
import com.example.ui.BankingUiState
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.theme.LocalCrestlineColors
import com.example.ui.theme.MonoFontFamily

@Composable
fun ProfileScreen(
    uiState: BankingUiState,
    onUpdateProfilePrefs: (mfa: Boolean, bio: Boolean, redact: Boolean, email: Boolean, push: Boolean) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetReducedMotion: (Boolean) -> Unit,
    onSetOfflineMode: (Boolean) -> Unit,
    onSetBackendUrl: (String) -> Unit,
    onRefreshToken: () -> Unit,
    onSimulateExpiredToken: () -> Unit,
    onRevokeSession: (String) -> Unit,
    onSignOut: () -> Unit
) {
    val ext = LocalCrestlineColors.current
    val customer = uiState.currentCustomer
    var backendUrlInput by remember(uiState.preferences.backendBaseUrl) {
        mutableStateOf(uiState.preferences.backendBaseUrl)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Profile & Security", style = MaterialTheme.typography.displayMedium)

                uiState.bannerMessage?.let { msg ->
                    Surface(shape = RoundedCornerShape(12.dp), color = ext.positiveContainer) {
                        Text(msg, color = ext.positive, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
                uiState.errorMessage?.let { err ->
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Text(err, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (customer != null) {
                    ElevatedSurfaceCard {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(customer.fullName, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Text(customer.email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Phone: ${customer.phoneMasked}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                "Account recovery boundary: Recovery requires verified email + out-of-band MFA; local biometric alone never overrides backend identity checks.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Security, MFA, Privacy & Contact Preferences
                    ElevatedSurfaceCard {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Security & Privacy", style = MaterialTheme.typography.titleMedium)
                            PrefToggleRow(
                                title = "Multifactor authentication (Demo code: 482910)",
                                checked = customer.mfaEnabled,
                                onCheckedChange = {
                                    onUpdateProfilePrefs(it, customer.biometricEnabled, customer.lockScreenRedactionEnabled, customer.emailAlertsEnabled, customer.pushAlertsEnabled)
                                }
                            )
                            PrefToggleRow(
                                title = "Biometric unlock / step-up",
                                checked = customer.biometricEnabled,
                                onCheckedChange = {
                                    onUpdateProfilePrefs(customer.mfaEnabled, it, customer.lockScreenRedactionEnabled, customer.emailAlertsEnabled, customer.pushAlertsEnabled)
                                }
                            )
                            PrefToggleRow(
                                title = "Redact sensitive amounts on lock screen",
                                checked = customer.lockScreenRedactionEnabled,
                                onCheckedChange = {
                                    onUpdateProfilePrefs(customer.mfaEnabled, customer.biometricEnabled, it, customer.emailAlertsEnabled, customer.pushAlertsEnabled)
                                }
                            )
                            HorizontalDivider(color = ext.cardBorder)
                            Text("Contact preferences", style = MaterialTheme.typography.titleSmall)
                            PrefToggleRow(
                                title = "Email security & statement notices",
                                checked = customer.emailAlertsEnabled,
                                onCheckedChange = {
                                    onUpdateProfilePrefs(customer.mfaEnabled, customer.biometricEnabled, customer.lockScreenRedactionEnabled, it, customer.pushAlertsEnabled)
                                }
                            )
                            PrefToggleRow(
                                title = "In-app & push alerts",
                                checked = customer.pushAlertsEnabled,
                                onCheckedChange = {
                                    onUpdateProfilePrefs(customer.mfaEnabled, customer.biometricEnabled, customer.lockScreenRedactionEnabled, customer.emailAlertsEnabled, it)
                                }
                            )
                        }
                    }
                }

                // Appearance & Accessibility
                ElevatedSurfaceCard {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Theme & Accessibility", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemeMode.entries.forEach { mode ->
                                val selected = uiState.preferences.themeMode == mode
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (selected) MaterialTheme.colorScheme.primary else ext.softTile,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onSetThemeMode(mode) }
                                ) {
                                    Text(
                                        text = mode.label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                        PrefToggleRow(
                            title = "Reduced motion",
                            checked = uiState.preferences.reducedMotion,
                            onCheckedChange = onSetReducedMotion
                        )
                        PrefToggleRow(
                            title = "Simulate offline mode (cached balances)",
                            checked = !uiState.serviceStatus.isOnlineMode,
                            onCheckedChange = onSetOfflineMode
                        )
                    }
                }

                // Token Rotation & Active Device Sessions
                ElevatedSurfaceCard {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Device Sessions & Token Rotation", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onRefreshToken,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Rotate Refresh Token", style = MaterialTheme.typography.labelMedium)
                            }
                            OutlinedButton(
                                onClick = onSimulateExpiredToken,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Expire Access Token", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        uiState.deviceSessions.forEach { sess ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = ext.softTile,
                                border = BorderStroke(1.dp, ext.cardBorder)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (sess.isCurrentDevice) "${sess.deviceName} (This device)" else sess.deviceName,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "${sess.lastActiveLabel} • Gen #${sess.refreshGeneration} • ${if (sess.revoked) "REVOKED" else "Active"}",
                                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                                            color = if (sess.revoked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (!sess.revoked) {
                                        TextButton(onClick = { onRevokeSession(sess.sessionId) }) {
                                            Text("Revoke")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Optional HTTPS Ktor Backend Endpoint Configuration
                ElevatedSurfaceCard {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Ktor Backend Connection (TLS Required)", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Leave blank for embedded authoritative ledger, or enter an https:// Ktor backend URL.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = backendUrlInput,
                            onValueChange = { backendUrlInput = it },
                            label = { Text("https://api.crestline.example") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(
                            onClick = { onSetBackendUrl(backendUrlInput) },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Save endpoint")
                        }
                    }
                }

                Button(
                    onClick = onSignOut,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("sign_out_button")
                ) {
                    Text("Sign out & clear device tokens")
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun PrefToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f).padding(end = 8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
