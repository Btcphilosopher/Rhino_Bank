package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.AccountType
import com.example.domain.CurrencyFormatter
import com.example.domain.LedgerTransaction
import com.example.domain.TransactionDirection
import com.example.domain.TransactionStatus
import com.example.ui.BankingUiState
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.LocalCrestlineColors
import com.example.ui.theme.MonoFontFamily

@Composable
fun AccountDetailScreen(
    accountId: String,
    uiState: BankingUiState,
    onTransferFromHere: () -> Unit,
    onDepositHere: () -> Unit,
    onGenerateStatement: (String) -> Unit,
    onOpenStatements: () -> Unit,
    onCreateLinkedAdjustment: (txId: String, reason: String) -> Unit
) {
    val ext = LocalCrestlineColors.current
    val account = uiState.accounts.firstOrNull { it.accountId == accountId }
    val accountHolds = uiState.pendingHolds.filter { it.accountId == accountId }
    val accountTxs = remember(uiState.transactions, accountId) {
        uiState.transactions.filter { it.accountId == accountId }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }
    var inspectedTx by remember { mutableStateOf<LedgerTransaction?>(null) }
    var adjustmentReason by remember { mutableStateOf("Merchant overcharge dispute correction") }

    val filteredTxs = remember(accountTxs, searchQuery, selectedFilter) {
        accountTxs.filter { tx ->
            val matchesQuery = searchQuery.isBlank() ||
                tx.description.contains(searchQuery, ignoreCase = true) ||
                tx.reference.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (selectedFilter) {
                "POSTED" -> tx.status == TransactionStatus.POSTED
                "PENDING" -> tx.status == TransactionStatus.PENDING
                "INFLOW" -> tx.direction == TransactionDirection.CREDIT
                "OUTFLOW" -> tx.direction == TransactionDirection.DEBIT
                "ADJUST" -> tx.status == TransactionStatus.ADJUSTMENT || tx.status == TransactionStatus.REVERSED
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (account == null) {
                    Text("Account not found.", style = MaterialTheme.typography.titleLarge)
                    return@item
                }

                ElevatedSurfaceCard {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${account.accountType.name.replace('_', ' ')} • ${account.maskedNumber}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(account.currency, style = MaterialTheme.typography.labelMedium)
                        }
                        Text(account.name, style = MaterialTheme.typography.headlineMedium)

                        if (account.accountType == AccountType.CREDIT_CARD) {
                            Text(
                                text = "Amount owed: ${CurrencyFormatter.formatCents(account.postedBalanceCents)}",
                                style = MaterialTheme.typography.displayMedium
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Statement: ${CurrencyFormatter.formatCents(account.statementBalanceCents)}", style = MaterialTheme.typography.bodySmall)
                                Text("Available credit: ${CurrencyFormatter.formatCents(account.availableBalanceCents)}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("Credit limit: ${CurrencyFormatter.formatCents(account.creditLimitCents)} • Min payment: ${CurrencyFormatter.formatCents(account.minimumPaymentCents)} (Due ${account.paymentDueDateLabel})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Text(
                                text = CurrencyFormatter.formatCents(account.availableBalanceCents),
                                style = MaterialTheme.typography.displayLarge,
                                modifier = Modifier.testTag("account_detail_available")
                            )
                            Text("Available balance", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            HorizontalDivider(color = ext.cardBorder)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Posted balance: ${CurrencyFormatter.formatCents(account.postedBalanceCents)}", style = MaterialTheme.typography.bodyMedium)
                                Text("Pending holds: ${CurrencyFormatter.formatCents(account.pendingHoldCents)}", style = MaterialTheme.typography.bodyMedium)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onTransferFromHere,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (account.accountType == AccountType.CREDIT_CARD) "Pay card" else "Transfer")
                            }
                            if (account.accountType != AccountType.CREDIT_CARD) {
                                OutlinedButton(
                                    onClick = onDepositHere,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Deposit")
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    onGenerateStatement(account.accountId)
                                    onOpenStatements()
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Statement")
                            }
                        }
                    }
                }

                if (accountHolds.isNotEmpty()) {
                    Text("Pending holds", style = MaterialTheme.typography.titleMedium)
                    ElevatedSurfaceCard {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            accountHolds.forEach { hold ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(hold.description, style = MaterialTheme.typography.titleSmall)
                                        Text("${hold.createdAtLabel} • ${hold.reference}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = "-${CurrencyFormatter.formatCents(hold.amountCents)}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = ext.warning
                                    )
                                }
                            }
                        }
                    }
                }

                // Search & Filters
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search description or reference") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "ALL" to "All",
                        "POSTED" to "Posted",
                        "PENDING" to "Pending",
                        "INFLOW" to "Inflows",
                        "OUTFLOW" to "Outflows",
                        "ADJUST" to "Adjustments"
                    ).forEach { (code, label) ->
                        FilterChip(
                            selected = selectedFilter == code,
                            onClick = { selectedFilter = code },
                            label = { Text(label) }
                        )
                    }
                }

                Text("Ledger activity (${filteredTxs.size})", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                ElevatedSurfaceCard {
                    Column {
                        if (filteredTxs.isEmpty()) {
                            Text("No matching transactions.", modifier = Modifier.padding(20.dp))
                        } else {
                            filteredTxs.forEachIndexed { idx, tx ->
                                TransactionRowItem(
                                    transaction = tx,
                                    onClick = { inspectedTx = tx }
                                )
                                if (idx < filteredTxs.lastIndex) {
                                    HorizontalDivider(color = ext.cardBorder, modifier = Modifier.padding(horizontal = 16.dp))
                                }
                            }
                        }
                    }
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    val tx = inspectedTx
    if (tx != null) {
        AlertDialog(
            onDismissRequest = { inspectedTx = null },
            title = { Text(tx.description) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Amount: ${CurrencyFormatter.formatCents(tx.amountCents, tx.currency)}")
                    Text("Direction: ${tx.direction.name} • Status: ${tx.status.name}")
                    Text("Counterparty: ${tx.merchantOrCounterparty}")
                    Text("Timestamp: ${tx.timestampLabel}")
                    Text("Category: ${tx.category.displayName}")
                    Text("Reference: ${tx.reference}", style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily))
                    if (tx.linkedTransactionId != null) {
                        Text("Linked to original entry: ${tx.linkedTransactionId}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (tx.status == TransactionStatus.POSTED) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Need to correct a posted entry? Crestline preserves immutable history and posts a linked adjustment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = adjustmentReason,
                            onValueChange = { adjustmentReason = it },
                            label = { Text("Adjustment reason") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                if (tx.status == TransactionStatus.POSTED) {
                    Button(onClick = {
                        onCreateLinkedAdjustment(tx.transactionId, adjustmentReason)
                        inspectedTx = null
                    }) {
                        Text("Post linked adjustment")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { inspectedTx = null }) { Text("Close") }
            }
        )
    }
}
