package com.example.ui.theme

/**
 * Replaceable brand configuration so visual identity remains decoupled from
 * business logic and clearly marked as an independent synthetic concept.
 */
object BrandConfig {
    const val BRAND_NAME = "Crestline"
    const val WORDMARK = "CRESTLINE"
    const val CONCEPT_DISCLAIMER = "INDEPENDENT CONCEPT • SYNTHETIC ACCOUNTS • NO LIVE BANKING"
    const val SHORT_DISCLAIMER = "Independent concept — synthetic accounts — no live banking"
    const val SUPPORT_EMAIL = "support@crestline.demo"
}
