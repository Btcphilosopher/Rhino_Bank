package com.example.ui.screens

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.AccountType
import com.example.domain.CurrencyFormatter
import com.example.domain.DepositStatus
import com.example.domain.DepositSubmission
import com.example.ui.BankingUiState
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.theme.LocalCrestlineColors

@Composable
fun DepositScreen(
    uiState: BankingUiState,
    onSubmitDeposit: (accountId: String, amount: String, docLabel: String, mimeType: String, sizeBytes: Long) -> Unit,
    onSimulateClear: (DepositSubmission) -> Unit
) {
    val context = LocalContext.current
    val ext = LocalCrestlineColors.current
    val checkingId = uiState.accounts.firstOrNull { it.accountType == AccountType.CHECKING }?.accountId.orEmpty()

    var amountText by remember { mutableStateOf("450.00") }
    var docLabel by remember { mutableStateOf("Synthetic Payroll Cheque #4091") }
    var docMime by remember { mutableStateOf("image/png") }
    var docSize by remember { mutableLongStateOf(248_000L) }

    // Play Policy compliant zero-permission Photo Picker
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            var name = "Selected synthetic image"
            var size = 350_000L
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                    if (sizeIdx >= 0) size = cursor.getLong(sizeIdx).coerceAtLeast(1024L)
                }
            }
            docLabel = name
            docMime = mime
            docSize = size
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Deposit simulation", style = MaterialTheme.typography.displayMedium)

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = ext.softTile,
                    border = BorderStroke(1.dp, ext.cardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "Real-document submission disabled unless an authorised provider integration is configured. Captured document metadata is redacted from logs and funds are NOT immediately spendable.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                uiState.errorMessage?.let { err ->
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Text(err, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }

                uiState.bannerMessage?.let { msg ->
                    Surface(shape = RoundedCornerShape(12.dp), color = ext.positiveContainer) {
                        Text(msg, color = ext.positive, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }

                ElevatedSurfaceCard {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Destination: Everyday Checking ••••1842", style = MaterialTheme.typography.titleSmall)

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Cheque amount ($)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Synthetic sample documents", style = MaterialTheme.typography.labelMedium)
                        listOf(
                            Triple("Synthetic Payroll Cheque #4091", "image/png", 248_000L),
                            Triple("Synthetic Rebate Cheque #1024", "image/jpeg", 190_000L),
                            Triple("Unsupported PDF Test (Validation)", "application/pdf", 120_000L)
                        ).forEach { (label, mime, size) ->
                            val selected = docLabel == label
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) ext.softTile else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else ext.cardBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        docLabel = label
                                        docMime = mime
                                        docSize = size
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Filled.DocumentScanner, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(label, style = MaterialTheme.typography.titleSmall)
                                        Text("$mime • ${size / 1024} KB", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (selected) {
                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Choose sample image via Photo Picker")
                        }

                        Button(
                            onClick = {
                                if (checkingId.isNotEmpty()) {
                                    onSubmitDeposit(checkingId, amountText, docLabel, docMime, docSize)
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) {
                            Text("Submit to simulated review")
                        }
                    }
                }

                if (uiState.deposits.isNotEmpty()) {
                    Text("Deposit lifecycle", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                    uiState.deposits.forEach { dep ->
                        ElevatedSurfaceCard {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(dep.documentLabel, style = MaterialTheme.typography.titleSmall)
                                    Text(CurrencyFormatter.formatCents(dep.amountCents), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (dep.status == DepositStatus.AVAILABLE) ext.positiveContainer else ext.warningContainer
                                ) {
                                    Text(
                                        text = "State: ${dep.status.name.replace('_', ' ')}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (dep.status == DepositStatus.AVAILABLE) ext.positive else ext.warning,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Text(dep.availabilityNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (dep.status == DepositStatus.HELD_PENDING_AVAILABILITY) {
                                    OutlinedButton(
                                        onClick = { onSimulateClear(dep) },
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Simulate mock-clearing release")
                                    }
                                }
                            }
                        }
                    }
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
