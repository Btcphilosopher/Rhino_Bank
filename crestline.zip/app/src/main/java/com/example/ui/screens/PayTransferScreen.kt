package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.AccountType
import com.example.domain.BankAccount
import com.example.domain.CurrencyFormatter
import com.example.domain.DemoFaultMode
import com.example.domain.TransferTiming
import com.example.ui.BankingUiState
import com.example.ui.components.BiometricHelper
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.LocalCrestlineColors
import com.example.ui.theme.MonoFontFamily

@Composable
fun PayTransferScreen(
    uiState: BankingUiState,
    initialMode: String = "TRANSFER",
    onPreviewTransfer: (srcId: String, dstId: String, amountText: String, timing: TransferTiming) -> Unit,
    onInvalidateDraft: () -> Unit,
    onAuthoriseTransfer: () -> Unit,
    onRetryReconcileTransfer: () -> Unit,
    onCancelDraft: () -> Unit,
    onDismissConfirmation: () -> Unit,
    onSetFaultMode: (DemoFaultMode) -> Unit,
    onAddPayee: (name: String, category: String, digits: String, stepUpVerified: Boolean) -> Unit,
    onSubmitBillPayment: (srcId: String, payeeId: String, payeeName: String, amount: String, today: Boolean, recurring: Boolean) -> Unit,
    onRunScheduledWorker: () -> Unit,
    onCreatePaymentRequest: (fromParty: String, dstId: String, amount: String, memo: String) -> Unit
) {
    val ext = LocalCrestlineColors.current
    val context = LocalContext.current
    var activeSegment by remember(initialMode) { mutableStateOf(initialMode) }

    val depositAccounts = uiState.accounts.filter {
        it.accountType == AccountType.CHECKING || it.accountType == AccountType.SAVINGS
    }
    val allDestinationAccounts = uiState.accounts

    var selectedSourceId by remember(depositAccounts) {
        mutableStateOf(
            depositAccounts.firstOrNull { it.accountType == AccountType.CHECKING }?.accountId
                ?: depositAccounts.firstOrNull()?.accountId.orEmpty()
        )
    }
    var selectedDestId by remember(allDestinationAccounts) {
        mutableStateOf(
            allDestinationAccounts.firstOrNull { it.accountType == AccountType.SAVINGS }?.accountId
                ?: allDestinationAccounts.lastOrNull()?.accountId.orEmpty()
        )
    }
    var amountInput by remember { mutableStateOf("500.00") }
    var selectedTiming by remember { mutableStateOf(TransferTiming.TODAY) }
    var showFaultMenu by remember { mutableStateOf(false) }

    val sourceAccount = depositAccounts.firstOrNull { it.accountId == selectedSourceId } ?: depositAccounts.firstOrNull()
    val destAccount = allDestinationAccounts.firstOrNull { it.accountId == selectedDestId } ?: allDestinationAccounts.lastOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Move money. Simply.",
                    style = MaterialTheme.typography.displayMedium.copy(fontSize = 28.sp),
                    color = MaterialTheme.colorScheme.onBackground
                )

                // Segmented Pill: Transfer | Pay | Request
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = ext.softTile,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "TRANSFER" to "Transfer",
                            "PAY" to "Pay",
                            "REQUEST" to "Request"
                        ).forEach { (key, label) ->
                            val selected = activeSegment == key
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { activeSegment = key }
                                    .testTag("segment_${key.lowercase()}"),
                                shape = RoundedCornerShape(20.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                uiState.errorMessage?.let { err ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            if (uiState.transferNeedsReconcile && uiState.activeDraftTransfer != null) {
                                Button(
                                    onClick = onRetryReconcileTransfer,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("reconcile_retry_button")
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Retry / Reconcile safely")
                                }
                            }
                        }
                    }
                }

                uiState.bannerMessage?.let { msg ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = ext.positiveContainer
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = ext.positive,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        )
                    }
                }

                when (activeSegment) {
                    "TRANSFER" -> {
                        TransferFormSection(
                            sourceAccount = sourceAccount,
                            destAccount = destAccount,
                            depositAccounts = depositAccounts,
                            allAccounts = allDestinationAccounts,
                            amountInput = amountInput,
                            timing = selectedTiming,
                            activeFaultMode = uiState.serviceStatus.activeFaultMode,
                            onSelectSource = {
                                selectedSourceId = it
                                onInvalidateDraft()
                            },
                            onSelectDest = {
                                selectedDestId = it
                                onInvalidateDraft()
                            },
                            onAmountChange = {
                                amountInput = it
                                onInvalidateDraft()
                            },
                            onTimingChange = {
                                selectedTiming = it
                                onInvalidateDraft()
                            },
                            onReviewClick = {
                                if (sourceAccount != null && destAccount != null) {
                                    onPreviewTransfer(sourceAccount.accountId, destAccount.accountId, amountInput, selectedTiming)
                                }
                            },
                            showFaultMenu = showFaultMenu,
                            onToggleFaultMenu = { showFaultMenu = it },
                            onSelectFault = {
                                onSetFaultMode(it)
                                showFaultMenu = false
                            }
                        )
                    }
                    "PAY" -> {
                        PayBillsSection(
                            uiState = uiState,
                            depositAccounts = depositAccounts,
                            onAddPayee = onAddPayee,
                            onSubmitBillPayment = onSubmitBillPayment,
                            onRunScheduledWorker = onRunScheduledWorker
                        )
                    }
                    else -> {
                        RequestMoneySection(
                            uiState = uiState,
                            depositAccounts = depositAccounts,
                            onCreateRequest = onCreatePaymentRequest
                        )
                    }
                }

                // Recent activity section (matching mockup's bottom card on Transfer screen)
                Text(
                    text = "Recent activity",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                ElevatedSurfaceCard {
                    Column {
                        uiState.transactions.take(4).forEachIndexed { idx, tx ->
                            TransactionRowItem(transaction = tx)
                            if (idx < 3 && idx < uiState.transactions.lastIndex) {
                                HorizontalDivider(
                                    color = ext.cardBorder,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                    }
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    // Transfer Review & Authorisation Dialog (Draft -> Reviewed -> Authorised -> Processing -> Completed)
    val draft = uiState.activeDraftTransfer
    if (draft != null) {
        AlertDialog(
            onDismissRequest = onCancelDraft,
            title = {
                Text("Review & Authorise Transfer", style = MaterialTheme.typography.titleLarge)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = ext.softTile
                    ) {
                        Text(
                            text = "State: ${draft.status.name} (Draft → Reviewed → Authorised → Processing → Completed)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Text("From: ${draft.sourceName}", style = MaterialTheme.typography.bodyMedium)
                    Text("To: ${draft.destinationName}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Amount: ${CurrencyFormatter.formatCents(draft.amountCents)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text("Timing: ${draft.timing.label} • Fee: $0.00", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Idempotency key: ${draft.idempotencyKey.take(18)}…",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        BiometricHelper.authenticate(
                            context = context,
                            title = "Authorise Transfer",
                            subtitle = "Confirm ${CurrencyFormatter.formatCents(draft.amountCents)} from ${draft.sourceName}",
                            onSuccess = onAuthoriseTransfer,
                            onFallbackRequested = onAuthoriseTransfer,
                            onError = { /* user canceled */ }
                        )
                    },
                    modifier = Modifier.testTag("authorise_transfer_button")
                ) {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Authorise & Send")
                }
            },
            dismissButton = {
                TextButton(onClick = onCancelDraft) {
                    Text("Cancel")
                }
            }
        )
    }

    // Persistent Transfer Confirmation Receipt Dialog
    val conf = uiState.lastTransferConfirmation
    if (conf != null) {
        AlertDialog(
            onDismissRequest = onDismissConfirmation,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = ext.positive)
                    Text("Transfer ${conf.status.name.lowercase().replaceFirstChar { it.uppercase() }}")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        CurrencyFormatter.formatCents(conf.amountCents),
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text("${conf.sourceName} → ${conf.destinationName}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Confirmation: ${conf.confirmationReference}",
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily)
                    )
                    Text(
                        "Idempotency: ${conf.idempotencyKey.take(18)}…",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            // Demonstrate idempotent retry returns exact same confirmation without double posting
                            onDismissConfirmation()
                            onRetryReconcileTransfer()
                        },
                        modifier = Modifier.testTag("test_idempotent_retry_button")
                    ) {
                        Text("Done")
                    }
                }
            }
        )
    }
}

@Composable
private fun TransferFormSection(
    sourceAccount: BankAccount?,
    destAccount: BankAccount?,
    depositAccounts: List<BankAccount>,
    allAccounts: List<BankAccount>,
    amountInput: String,
    timing: TransferTiming,
    activeFaultMode: DemoFaultMode,
    onSelectSource: (String) -> Unit,
    onSelectDest: (String) -> Unit,
    onAmountChange: (String) -> Unit,
    onTimingChange: (TransferTiming) -> Unit,
    onReviewClick: () -> Unit,
    showFaultMenu: Boolean,
    onToggleFaultMenu: (Boolean) -> Unit,
    onSelectFault: (DemoFaultMode) -> Unit
) {
    val ext = LocalCrestlineColors.current
    var srcExpanded by remember { mutableStateOf(false) }
    var dstExpanded by remember { mutableStateOf(false) }
    var timingExpanded by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("From", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            AccountPickerCard(
                account = sourceAccount,
                isSource = true,
                onClick = { srcExpanded = true },
                testTag = "transfer_from_picker"
            )
            DropdownMenu(expanded = srcExpanded, onDismissRequest = { srcExpanded = false }) {
                depositAccounts.forEach { acc ->
                    DropdownMenuItem(
                        text = {
                            Text("${acc.name} ${acc.maskedNumber} (${CurrencyFormatter.formatCents(acc.availableBalanceCents)})")
                        },
                        onClick = {
                            onSelectSource(acc.accountId)
                            srcExpanded = false
                        }
                    )
                }
            }
        }

        Text("To", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            AccountPickerCard(
                account = destAccount,
                isSource = false,
                onClick = { dstExpanded = true },
                testTag = "transfer_to_picker"
            )
            DropdownMenu(expanded = dstExpanded, onDismissRequest = { dstExpanded = false }) {
                allAccounts.forEach { acc ->
                    DropdownMenuItem(
                        text = {
                            val bal = if (acc.accountType == AccountType.CREDIT_CARD) acc.postedBalanceCents else acc.availableBalanceCents
                            Text("${acc.name} ${acc.maskedNumber} (${CurrencyFormatter.formatCents(bal)})")
                        },
                        onClick = {
                            onSelectDest(acc.accountId)
                            dstExpanded = false
                        }
                    )
                }
            }
        }

        Text("Amount", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, ext.cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.width(4.dp))
                BasicTextField(
                    value = amountInput,
                    onValueChange = onAmountChange,
                    textStyle = MaterialTheme.typography.displayLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("transfer_amount_input")
                )
            }
        }

        // Quick preset chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("100.00", "500.00", "1000.00").forEach { preset ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ext.softTile,
                    modifier = Modifier.clickable { onAmountChange(preset) }
                ) {
                    Text(
                        text = "$$preset",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Timing row
        Box {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, ext.cardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable { timingExpanded = true }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Timing", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(16.dp))
                    Icon(
                        imageVector = Icons.Filled.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = timing.label,
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Select timing")
                }
            }
            DropdownMenu(expanded = timingExpanded, onDismissRequest = { timingExpanded = false }) {
                TransferTiming.entries.forEach { t ->
                    DropdownMenuItem(
                        text = { Text(t.label) },
                        onClick = {
                            onTimingChange(t)
                            timingExpanded = false
                        }
                    )
                }
            }
        }

        // Between your accounts info banner
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = ext.softTile,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column {
                    Text("Between your accounts", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Fee $0.00 • Illustrative demo transfer",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Primary Cobalt CTA: Review transfer ->
        Button(
            onClick = onReviewClick,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("review_transfer_button")
        ) {
            Text("Review transfer", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
        }

        // Collapsible Demo Edge-Case Fault Simulator pill
        Box {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (activeFaultMode == DemoFaultMode.NONE) ext.softTile else ext.warningContainer,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleFaultMenu(true) }
                    .testTag("fault_simulator_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Demo edge-case mode: ${activeFaultMode.label}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (activeFaultMode == DemoFaultMode.NONE) MaterialTheme.colorScheme.primary else ext.warning
                    )
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Select fault simulation mode")
                }
            }
            DropdownMenu(expanded = showFaultMenu, onDismissRequest = { onToggleFaultMenu(false) }) {
                DemoFaultMode.entries.forEach { mode ->
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(mode.label, style = MaterialTheme.typography.titleSmall)
                                Text(mode.description, style = MaterialTheme.typography.bodySmall)
                            }
                        },
                        onClick = { onSelectFault(mode) }
                    )
                }
            }
        }
    }
}

@Composable
private fun AccountPickerCard(
    account: BankAccount?,
    isSource: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val ext = LocalCrestlineColors.current
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, ext.cardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ext.softTile),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSource) Icons.Filled.AccountBalance else Icons.Filled.Savings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = account?.let { "${it.name}  ${it.maskedNumber}" } ?: "Select account",
                    style = MaterialTheme.typography.titleSmall
                )
                if (account != null) {
                    val bal = if (account.accountType == AccountType.CREDIT_CARD) {
                        "Owed ${CurrencyFormatter.formatCents(account.postedBalanceCents)}"
                    } else {
                        "Available ${CurrencyFormatter.formatCents(account.availableBalanceCents)}"
                    }
                    Text(bal, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Change account")
        }
    }
}

@Composable
private fun PayBillsSection(
    uiState: BankingUiState,
    depositAccounts: List<BankAccount>,
    onAddPayee: (String, String, String, Boolean) -> Unit,
    onSubmitBillPayment: (String, String, String, String, Boolean, Boolean) -> Unit,
    onRunScheduledWorker: () -> Unit
) {
    val ext = LocalCrestlineColors.current
    val context = LocalContext.current
    var selectedPayee by remember(uiState.payees) { mutableStateOf(uiState.payees.firstOrNull()) }
    var payAmount by remember { mutableStateOf("145.00") }
    var payToday by remember { mutableStateOf(true) }
    var isRecurring by remember { mutableStateOf(false) }
    var showAddPayee by remember { mutableStateOf(false) }
    var newPayeeName by remember { mutableStateOf("") }
    var newPayeeCategory by remember { mutableStateOf("Utilities") }
    var newPayeeDigits by remember { mutableStateOf("") }

    val sourceId = depositAccounts.firstOrNull { it.accountType == AccountType.CHECKING }?.accountId
        ?: depositAccounts.firstOrNull()?.accountId.orEmpty()

    ElevatedSurfaceCard {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Saved payees (Mock ACH Rail)", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { showAddPayee = true }) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("New payee")
                }
            }

            uiState.payees.forEach { payee ->
                val isSelected = selectedPayee?.payeeId == payee.payeeId
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isSelected) ext.softTile else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else ext.cardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPayee = payee }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(payee.name, style = MaterialTheme.typography.titleSmall)
                            Text("${payee.category} • ${payee.maskedAccount}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (payee.verifiedByStepUp) {
                            Icon(Icons.Filled.VerifiedUser, contentDescription = "Verified", tint = ext.positive, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            OutlinedTextField(
                value = payAmount,
                onValueChange = { payAmount = it },
                label = { Text("Payment amount ($)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = !payToday, onCheckedChange = { payToday = !it })
                Text("Schedule for Dec 15 (instruction only)", style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = isRecurring, onCheckedChange = { isRecurring = it })
                Text("Repeat monthly", style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    val payee = selectedPayee ?: return@Button
                    onSubmitBillPayment(sourceId, payee.payeeId, payee.name, payAmount, payToday, isRecurring)
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(if (payToday) "Submit payment via mock rail" else "Create scheduled instruction")
            }

            OutlinedButton(
                onClick = onRunScheduledWorker,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Run scheduled-payment worker now")
            }
        }
    }

    if (uiState.payments.isNotEmpty()) {
        ElevatedSurfaceCard {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Scheduled & Payment History", style = MaterialTheme.typography.titleMedium)
                uiState.payments.forEach { p ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.payeeName, style = MaterialTheme.typography.titleSmall)
                            Text("${p.status.name} • ${p.railNote}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(CurrencyFormatter.formatCents(p.amountCents), style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }
    }

    if (showAddPayee) {
        AlertDialog(
            onDismissRequest = { showAddPayee = false },
            title = { Text("Add Payee (Step-Up Required)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = newPayeeName, onValueChange = { newPayeeName = it }, label = { Text("Payee name") })
                    OutlinedTextField(value = newPayeeCategory, onValueChange = { newPayeeCategory = it }, label = { Text("Category") })
                    OutlinedTextField(value = newPayeeDigits, onValueChange = { newPayeeDigits = it }, label = { Text("Last 4 account digits") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    BiometricHelper.authenticate(
                        context = context,
                        title = "Step-Up Authorisation",
                        subtitle = "Confirm adding new payee $newPayeeName",
                        onSuccess = {
                            onAddPayee(newPayeeName, newPayeeCategory, newPayeeDigits, true)
                            showAddPayee = false
                        },
                        onFallbackRequested = {
                            onAddPayee(newPayeeName, newPayeeCategory, newPayeeDigits, true)
                            showAddPayee = false
                        },
                        onError = {}
                    )
                }) {
                    Text("Authorise & Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPayee = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun RequestMoneySection(
    uiState: BankingUiState,
    depositAccounts: List<BankAccount>,
    onCreateRequest: (String, String, String, String) -> Unit
) {
    var fromParty by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("45.00") }
    var memo by remember { mutableStateOf("") }
    val destId = depositAccounts.firstOrNull()?.accountId.orEmpty()

    ElevatedSurfaceCard {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Create payment request", style = MaterialTheme.typography.titleMedium)
            Text(
                "A payment request notifies the recipient; it does not credit your ledger until settled.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(value = fromParty, onValueChange = { fromParty = it }, label = { Text("Request from") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Amount ($)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(value = memo, onValueChange = { memo = it }, label = { Text("Memo") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { onCreateRequest(fromParty, destId, amount, memo) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("Send payment request")
            }
        }
    }

    if (uiState.paymentRequests.isNotEmpty()) {
        ElevatedSurfaceCard {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Active payment requests", style = MaterialTheme.typography.titleMedium)
                uiState.paymentRequests.forEach { req ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${req.fromParty} • ${req.memo}", style = MaterialTheme.typography.titleSmall)
                            Text(req.statusLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(CurrencyFormatter.formatCents(req.amountCents), style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }
    }
}
