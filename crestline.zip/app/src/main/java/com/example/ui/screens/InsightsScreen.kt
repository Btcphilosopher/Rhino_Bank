package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CurrencyFormatter
import com.example.domain.LedgerTransaction
import com.example.domain.SpendingCategory
import com.example.domain.TransactionDirection
import com.example.domain.TransactionStatus
import com.example.ui.BankingUiState
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.theme.LocalCrestlineColors

@Composable
fun InsightsScreen(
    uiState: BankingUiState,
    onRecategorize: (transactionId: String, category: SpendingCategory) -> Unit,
    onOpenAssistant: () -> Unit
) {
    val ext = LocalCrestlineColors.current
    val insights = uiState.insights
    var editingTx by remember { mutableStateOf<LedgerTransaction?>(null) }

    val categorizableTransactions = remember(uiState.transactions) {
        uiState.transactions.filter {
            it.status == TransactionStatus.POSTED &&
                it.direction == TransactionDirection.DEBIT &&
                !it.reference.startsWith("TRF-") &&
                !it.reference.startsWith("OPEN-")
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Insights",
                        style = MaterialTheme.typography.displayMedium.copy(fontSize = 28.sp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Button(
                        onClick = onOpenAssistant,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.testTag("open_assistant_button")
                    ) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Ask Assistant")
                    }
                }

                if (insights != null) {
                    ElevatedSurfaceCard {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Spending this month (${insights.monthLabel})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val deltaCents = insights.totalCents - insights.previousMonthTotalCents
                                val deltaPrefix = if (deltaCents >= 0) "+" else ""
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (deltaCents <= 0) ext.positiveContainer else ext.softTile
                                ) {
                                    Text(
                                        text = "$deltaPrefix${CurrencyFormatter.formatCents(deltaCents)} vs last mo",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (deltaCents <= 0) ext.positive else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Text(
                                text = CurrencyFormatter.formatCents(insights.totalCents),
                                style = MaterialTheme.typography.displayLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("insights_monthly_total")
                            )

                            insights.categories.forEach { cat ->
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = categoryIcon(cat.category),
                                            contentDescription = cat.category.displayName,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = cat.category.displayName,
                                            style = MaterialTheme.typography.titleSmall,
                                            modifier = Modifier.width(84.dp)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(10.dp)
                                                .clip(RoundedCornerShape(5.dp))
                                                .background(ext.softTile)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxHeight()
                                                    .fillMaxWidth(cat.shareFraction.coerceIn(0.05f, 1f))
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(MaterialTheme.colorScheme.primary)
                                            )
                                        }
                                        Text(
                                            text = CurrencyFormatter.formatCents(cat.totalCents),
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                    }
                                    Text(
                                        text = "Previous period: ${CurrencyFormatter.formatCents(cat.previousPeriodCents)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(start = 28.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Calculation rules transparency box
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = ext.softTile,
                        border = BorderStroke(1.dp, ext.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = insights.methodologyNote,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Upcoming payments (scheduled vs estimated recurring)
                    Text(
                        text = "Upcoming payments",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    ElevatedSurfaceCard {
                        Column {
                            insights.upcomingItems.forEachIndexed { idx, item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(ext.softTile),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Filled.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            "${item.dueDateLabel} • ${item.sourceNote}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(CurrencyFormatter.formatCents(item.amountCents), style = MaterialTheme.typography.titleSmall)
                                }
                                if (idx < insights.upcomingItems.lastIndex) {
                                    HorizontalDivider(color = ext.cardBorder, modifier = Modifier.padding(horizontal = 16.dp))
                                }
                            }
                        }
                    }
                }

                // Editable Transaction Categories
                Text(
                    text = "Recategorise eligible purchases",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                ElevatedSurfaceCard {
                    Column {
                        categorizableTransactions.forEachIndexed { idx, tx ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { editingTx = tx }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tx.description, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${tx.timestampLabel} • ${tx.category.displayName}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Text(CurrencyFormatter.formatCents(tx.amountCents), style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Filled.Edit, contentDescription = "Edit category", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (idx < categorizableTransactions.lastIndex) {
                                HorizontalDivider(color = ext.cardBorder, modifier = Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    val target = editingTx
    if (target != null) {
        AlertDialog(
            onDismissRequest = { editingTx = null },
            title = { Text("Categorise ${target.description}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SpendingCategory.entries.forEach { cat ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (cat == target.category) ext.softTile else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, ext.cardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onRecategorize(target.transactionId, cat)
                                    editingTx = null
                                }
                        ) {
                            Text(
                                text = cat.displayName,
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { editingTx = null }) { Text("Cancel") }
            }
        )
    }
}
