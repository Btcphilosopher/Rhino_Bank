package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.AccountType
import com.example.ui.BankingUiState
import com.example.ui.components.AccountSummaryRowCard
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.components.HeroBalanceCard
import com.example.ui.components.TransactionRowItem
import com.example.ui.theme.LocalCrestlineColors
import java.util.Calendar

@Composable
fun HomeScreen(
    uiState: BankingUiState,
    onPayClick: () -> Unit,
    onTransferClick: () -> Unit,
    onDepositClick: () -> Unit,
    onCardsClick: () -> Unit,
    onAccountClick: (String) -> Unit,
    onSeeNotificationsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalCrestlineColors.current
    val firstName = uiState.currentCustomer?.firstName ?: "Alex"
    val greeting = rememberGreeting(firstName)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text(
                    text = greeting,
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.testTag("home_greeting")
                )

                HeroBalanceCard(
                    totalAvailableCents = uiState.combinedDepositAvailableCents,
                    syncLabel = uiState.serviceStatus.lastSyncedLabel,
                    isOnline = uiState.serviceStatus.isOnlineMode
                )

                // Quick actions row: Pay, Transfer, Deposit, Cards (exact 4-tile layout)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        label = "Pay",
                        icon = Icons.Filled.Payment,
                        onClick = onPayClick,
                        testTag = "quick_action_pay",
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        label = "Transfer",
                        icon = Icons.AutoMirrored.Filled.CompareArrows,
                        onClick = onTransferClick,
                        testTag = "quick_action_transfer",
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        label = "Deposit",
                        icon = Icons.Filled.Download,
                        onClick = onDepositClick,
                        testTag = "quick_action_deposit",
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        label = "Cards",
                        icon = Icons.Filled.CreditCard,
                        onClick = onCardsClick,
                        testTag = "quick_action_cards",
                        modifier = Modifier.weight(1f)
                    )
                }

                // Your accounts section
                Text(
                    text = "Your accounts",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                ElevatedSurfaceCard {
                    Column {
                        val orderedAccounts = uiState.accounts.sortedBy {
                            when (it.accountType) {
                                AccountType.CHECKING -> 0
                                AccountType.SAVINGS -> 1
                                AccountType.CREDIT_CARD -> 2
                                else -> 3
                            }
                        }
                        orderedAccounts.forEachIndexed { idx, account ->
                            AccountSummaryRowCard(
                                account = account,
                                onClick = { onAccountClick(account.accountId) }
                            )
                            if (idx < orderedAccounts.lastIndex) {
                                HorizontalDivider(
                                    color = ext.cardBorder,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                    }
                }

                // Recent activity preview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent activity",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    val checkingId = uiState.accounts.firstOrNull { it.accountType == AccountType.CHECKING }?.accountId
                    if (checkingId != null) {
                        TextButton(onClick = { onAccountClick(checkingId) }) {
                            Text("View all")
                        }
                    }
                }

                ElevatedSurfaceCard {
                    Column {
                        val recent = uiState.transactions.take(4)
                        if (recent.isEmpty()) {
                            Text(
                                text = "No recent activity yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(20.dp)
                            )
                        } else {
                            recent.forEachIndexed { idx, tx ->
                                TransactionRowItem(
                                    transaction = tx,
                                    onClick = { onAccountClick(tx.accountId) }
                                )
                                if (idx < recent.lastIndex) {
                                    HorizontalDivider(
                                        color = ext.cardBorder,
                                        modifier = Modifier.padding(horizontal = 16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Notifications & Service Status card
                ElevatedSurfaceCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (uiState.serviceStatus.isOnlineMode) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                                    contentDescription = "Service status",
                                    tint = if (uiState.serviceStatus.isOnlineMode) ext.positive else ext.warning
                                )
                                Text(
                                    text = if (uiState.serviceStatus.isOnlineMode) {
                                        "Ledger & Mock Adapters Operational"
                                    } else {
                                        "Offline Cache Mode (${uiState.serviceStatus.pendingOutboxCount} queued)"
                                    },
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (uiState.serviceStatus.ledgerBalanced) ext.positiveContainer else MaterialTheme.colorScheme.errorContainer
                            ) {
                                Text(
                                    text = if (uiState.serviceStatus.ledgerBalanced) "Balanced" else "Check",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (uiState.serviceStatus.ledgerBalanced) ext.positive else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        val unread = uiState.notifications.firstOrNull { !it.isRead } ?: uiState.notifications.firstOrNull()
                        if (unread != null) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ext.softTile)
                                    .clickable(onClick = onSeeNotificationsClick)
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.NotificationsActive,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(unread.title, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = unread.body,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                ConceptDisclaimerBar()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun QuickActionTile(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val ext = LocalCrestlineColors.current
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, ext.cardBorder),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

private fun rememberGreeting(firstName: String): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val period = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }
    return "$period,\n$firstName"
}
