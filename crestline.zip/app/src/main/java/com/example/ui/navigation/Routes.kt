package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object SignInRoute

@Serializable
object HomeRoute

@Serializable
data class PayTransferRoute(val initialMode: String = "TRANSFER")

@Serializable
object CardsRoute

@Serializable
object InsightsRoute

@Serializable
data class AccountDetailRoute(val accountId: String)

@Serializable
object DepositRoute

@Serializable
data class NotificationsStatementsRoute(val initialTab: Int = 0)

@Serializable
object ProfileRoute

@Serializable
object AssistantRoute
