package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.AccountType
import com.example.domain.BankAccount
import com.example.domain.BankCard
import com.example.domain.CardIssuerStatus
import com.example.domain.CurrencyFormatter
import com.example.domain.LedgerTransaction
import com.example.domain.TransactionDirection
import com.example.domain.TransactionStatus
import com.example.ui.theme.BrandConfig
import com.example.ui.theme.LocalCrestlineColors
import com.example.ui.theme.MonoFontFamily
import kotlin.math.cos
import kotlin.math.sin

/**
 * Geometric octagonal motif inspired by the reference design's restrained banking emblem.
 */
@Composable
fun OctagonEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    innerCutColor: Color = MaterialTheme.colorScheme.background
) {
    val emblemDesc = stringResource(R.string.cd_brand_logo)
    Canvas(
        modifier = modifier
            .size(size)
            .semantics { contentDescription = emblemDesc }
    ) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val outerR = minOf(w, h) * 0.46f
        val innerR = outerR * 0.42f

        val outerPath = Path().apply {
            for (i in 0 until 8) {
                val angle = Math.toRadians((22.5 + i * 45.0))
                val x = cx + outerR * cos(angle).toFloat()
                val y = cy + outerR * sin(angle).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        drawPath(outerPath, color = primaryColor)

        val innerPath = Path().apply {
            for (i in 0 until 8) {
                val angle = Math.toRadians((22.5 + i * 45.0))
                val x = cx + innerR * cos(angle).toFloat()
                val y = cy + innerR * sin(angle).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        drawPath(innerPath, color = innerCutColor)

        // Subtle segmented bevel lines
        val strokeW = minOf(w, h) * 0.08f
        drawLine(
            color = innerCutColor,
            start = Offset(cx, cy - outerR),
            end = Offset(cx, cy - innerR),
            strokeWidth = strokeW,
            cap = StrokeCap.Butt
        )
        drawLine(
            color = innerCutColor,
            start = Offset(cx + outerR, cy),
            end = Offset(cx + innerR, cy),
            strokeWidth = strokeW,
            cap = StrokeCap.Butt
        )
    }
}

@Composable
fun CrestlineTopBar(
    showBack: Boolean = false,
    onBackClick: () -> Unit = {},
    unreadNotifications: Int = 0,
    isOnline: Boolean = true,
    onNotificationsClick: (() -> Unit)? = null,
    onProfileClick: (() -> Unit)? = null
) {
    val ext = LocalCrestlineColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (showBack) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("top_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Navigate back",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = BrandConfig.WORDMARK,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                ),
                color = MaterialTheme.colorScheme.onBackground
            )
            OctagonEmblem(
                size = 24.dp,
                primaryColor = MaterialTheme.colorScheme.primary,
                innerCutColor = MaterialTheme.colorScheme.background
            )
            if (!isOnline) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ext.warningContainer
                ) {
                    Text(
                        text = "OFFLINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.warning,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (onNotificationsClick != null) {
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(ext.softTile)
                        .testTag("notifications_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotifications > 0) {
                                Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                    Text(unreadNotifications.coerceAtMost(9).toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (unreadNotifications > 0) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                            contentDescription = stringResource(R.string.cd_notifications_button),
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
            if (onProfileClick != null) {
                IconButton(
                    onClick = onProfileClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(ext.softTile)
                        .testTag("profile_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = stringResource(R.string.cd_profile_button),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}

@Composable
fun HeroBalanceCard(
    totalAvailableCents: Long,
    syncLabel: String,
    isOnline: Boolean,
    modifier: Modifier = Modifier
) {
    val ext = LocalCrestlineColors.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(ext.heroGradientStart, ext.heroGradientEnd)
                )
            )
            .testTag("hero_balance_card")
    ) {
        // Restrained geometric octagonal facets on the right half
        Canvas(modifier = Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val cx = w * 0.86f
            val cy = h * 0.50f
            listOf(h * 0.62f to 0.14f, h * 0.42f to 0.18f).forEach { (r, alpha) ->
                val path = Path().apply {
                    for (i in 0 until 8) {
                        val a = Math.toRadians(22.5 + i * 45.0)
                        val px = cx + r * cos(a).toFloat()
                        val py = cy + r * sin(a).toFloat()
                        if (i == 0) moveTo(px, py) else lineTo(px, py)
                    }
                    close()
                }
                drawPath(
                    path = path,
                    color = Color.White.copy(alpha = alpha),
                    style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round)
                )
            }
            val fillOct = Path().apply {
                val r = h * 0.52f
                for (i in 0 until 8) {
                    val a = Math.toRadians(22.5 + i * 45.0)
                    val px = cx + r * cos(a).toFloat()
                    val py = cy + r * sin(a).toFloat()
                    if (i == 0) moveTo(px, py) else lineTo(px, py)
                }
                close()
            }
            drawPath(fillOct, color = Color(0xFF4BA3FF).copy(alpha = 0.22f))
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Total available balance",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.86f)
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White.copy(alpha = 0.16f)
                ) {
                    Text(
                        text = if (isOnline) "Reconciled • $syncLabel" else "Cached • $syncLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = CurrencyFormatter.formatCents(totalAvailableCents),
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 36.sp),
                color = Color.White,
                modifier = Modifier.testTag("total_available_balance")
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Across eligible accounts • Excludes credit debt",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.80f)
            )
        }
    }
}

@Composable
fun VirtualDebitCardVisual(
    card: BankCard,
    modifier: Modifier = Modifier
) {
    val ext = LocalCrestlineColors.current
    val isLocked = card.issuerStatus == CardIssuerStatus.CONFIRMED_LOCKED ||
        card.issuerStatus == CardIssuerStatus.FROZEN_LOST
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(206.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(ext.debitCardStart, ext.debitCardEnd)
                )
            )
            .testTag("virtual_card_visual")
    ) {
        // Layered geometric octagonal facets
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w * 0.72f
            val cy = h * 0.56f
            listOf(h * 0.58f to 0.24f, h * 0.40f to 0.35f, h * 0.24f to 0.20f).forEach { (r, alpha) ->
                val p = Path().apply {
                    for (i in 0 until 8) {
                        val a = Math.toRadians(22.5 + i * 45.0)
                        val x = cx + r * cos(a).toFloat()
                        val y = cy + r * sin(a).toFloat()
                        if (i == 0) moveTo(x, y) else lineTo(x, y)
                    }
                    close()
                }
                drawPath(
                    p,
                    color = Color(0xFF47A1FF).copy(alpha = alpha),
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = BrandConfig.WORDMARK,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp
                        ),
                        color = Color.White
                    )
                    OctagonEmblem(
                        size = 20.dp,
                        primaryColor = Color.White,
                        innerCutColor = ext.debitCardStart
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isLocked) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFB74D).copy(alpha = 0.24f)
                        ) {
                            Text(
                                text = "LOCKED",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFFFD580),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = card.networkLabel,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White.copy(alpha = 0.90f)
                    )
                }
            }

            Text(
                text = "SYNTHETIC DEMO CARD • NO PAN/CVV STORED",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                color = Color.White.copy(alpha = 0.56f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = card.holderName,
                    style = MaterialTheme.typography.titleSmall.copy(letterSpacing = 1.sp),
                    color = Color.White
                )
                Text(
                    text = "•••• ${card.maskedLast4}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun AccountSummaryRowCard(
    account: BankAccount,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalCrestlineColors.current
    val icon = when (account.accountType) {
        AccountType.CHECKING -> Icons.Filled.AccountBalance
        AccountType.SAVINGS -> Icons.Filled.Savings
        else -> Icons.Filled.CreditCard
    }
    val subtitle = when (account.accountType) {
        AccountType.CREDIT_CARD -> "${account.maskedNumber} • Amount owed"
        else -> if (account.pendingHoldCents > 0L) {
            "${account.maskedNumber} • ${CurrencyFormatter.formatCents(account.pendingHoldCents)} pending"
        } else {
            account.maskedNumber
        }
    }
    val displayAmount = if (account.accountType == AccountType.CREDIT_CARD) {
        account.postedBalanceCents
    } else {
        account.availableBalanceCents
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag("account_row_${account.accountId}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(ext.softTile),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = account.name,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = account.name,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = CurrencyFormatter.formatCents(displayAmount),
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFeatureSettings = "tnum"
            ),
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun TransactionRowItem(
    transaction: LedgerTransaction,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val ext = LocalCrestlineColors.current
    val isCredit = transaction.direction == TransactionDirection.CREDIT
    val signedAmount = if (isCredit) transaction.amountCents else -transaction.amountCents
    val amountColor = if (isCredit) ext.positive else MaterialTheme.colorScheme.onSurface

    val rowMod = if (onClick != null) {
        modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
    } else {
        modifier.fillMaxWidth()
    }

    Row(
        modifier = rowMod.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ext.softTile),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isCredit) Icons.Filled.AccountBalance else Icons.Filled.CreditCard,
                contentDescription = transaction.description,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = transaction.description,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (transaction.status != TransactionStatus.POSTED) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (transaction.status == TransactionStatus.PENDING) ext.warningContainer else ext.softTile
                    ) {
                        Text(
                            text = transaction.status.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (transaction.status == TransactionStatus.PENDING) ext.warning else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${transaction.timestampLabel} • ${transaction.reference}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = CurrencyFormatter.formatCents(signedAmount, transaction.currency, showPositiveSign = true),
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                fontFeatureSettings = "tnum"
            ),
            color = amountColor
        )
    }
}

@Composable
fun ElevatedSurfaceCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val ext = LocalCrestlineColors.current
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, ext.cardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        content()
    }
}

@Composable
fun ConceptDisclaimerBar(modifier: Modifier = Modifier) {
    Text(
        text = BrandConfig.CONCEPT_DISCLAIMER,
        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.6.sp),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}

enum class MainNavTab(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME(R.string.nav_home, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    PAY_TRANSFER(
        R.string.nav_pay_transfer,
        Icons.AutoMirrored.Filled.CompareArrows,
        Icons.AutoMirrored.Filled.CompareArrows,
        "nav_pay_transfer"
    ),
    CARDS(R.string.nav_cards, Icons.Filled.CreditCard, Icons.Outlined.CreditCard, "nav_cards"),
    INSIGHTS(R.string.nav_insights, Icons.Filled.BarChart, Icons.Outlined.BarChart, "nav_insights")
}

@Composable
fun CrestlineBottomBar(
    selectedTab: MainNavTab,
    onSelectTab: (MainNavTab) -> Unit
) {
    val ext = LocalCrestlineColors.current
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.navigationBarsPadding()) {
            HorizontalDivider(color = ext.cardBorder, thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                MainNavTab.entries.forEach { tab ->
                    val selected = tab == selectedTab
                    val tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .minimumInteractiveComponentSize()
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 6.dp)
                            .testTag(tab.testTag),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) ext.softTile else Color.Transparent)
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = stringResource(tab.labelRes),
                                tint = tint,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(tab.labelRes),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = tint,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CrestlineNavRail(
    selectedTab: MainNavTab,
    onSelectTab: (MainNavTab) -> Unit
) {
    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
        Spacer(modifier = Modifier.height(16.dp))
        OctagonEmblem(size = 28.dp)
        Spacer(modifier = Modifier.height(24.dp))
        MainNavTab.entries.forEach { tab ->
            val selected = tab == selectedTab
            NavigationRailItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Icon(
                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                        contentDescription = stringResource(tab.labelRes)
                    )
                },
                label = { Text(stringResource(tab.labelRes)) }
            )
        }
    }
}
