package com.example.ui

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.engine.AuthoritativeBankingEngine
import com.example.data.engine.BankingAssistantEngine
import com.example.data.local.AppPreferences
import com.example.data.local.BankingDatabase
import com.example.data.local.SecurityCryptoManager
import com.example.data.remote.BankingApiClient
import com.example.domain.AccountType
import com.example.domain.ApiOutcome
import com.example.domain.AssistantMessage
import com.example.domain.BankAccount
import com.example.domain.BankCard
import com.example.domain.BankStatement
import com.example.domain.CurrencyFormatter
import com.example.domain.CustomerProfile
import com.example.domain.DemoFaultMode
import com.example.domain.DepositSubmission
import com.example.domain.DeviceSession
import com.example.domain.LedgerTransaction
import com.example.domain.NotificationItem
import com.example.domain.Payee
import com.example.domain.PaymentInstruction
import com.example.domain.PaymentRequest
import com.example.domain.PendingHold
import com.example.domain.ServiceStatusInfo
import com.example.domain.SpendingCategory
import com.example.domain.SpendingInsights
import com.example.domain.ThemeMode
import com.example.domain.TransferRecord
import com.example.domain.TransferTiming
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BankingUiState(
    val isInitializing: Boolean = true,
    val currentCustomer: CustomerProfile? = null,
    val accounts: List<BankAccount> = emptyList(),
    val combinedDepositAvailableCents: Long = 0L,
    val creditCardAccount: BankAccount? = null,
    val transactions: List<LedgerTransaction> = emptyList(),
    val pendingHolds: List<PendingHold> = emptyList(),
    val transfers: List<TransferRecord> = emptyList(),
    val activeDraftTransfer: TransferRecord? = null,
    val lastTransferConfirmation: TransferRecord? = null,
    val transferNeedsReconcile: Boolean = false,
    val payees: List<Payee> = emptyList(),
    val payments: List<PaymentInstruction> = emptyList(),
    val paymentRequests: List<PaymentRequest> = emptyList(),
    val deposits: List<DepositSubmission> = emptyList(),
    val cards: List<BankCard> = emptyList(),
    val insights: SpendingInsights? = null,
    val notifications: List<NotificationItem> = emptyList(),
    val unreadNotificationCount: Int = 0,
    val statements: List<BankStatement> = emptyList(),
    val deviceSessions: List<DeviceSession> = emptyList(),
    val preferences: AppPreferences = AppPreferences(),
    val serviceStatus: ServiceStatusInfo = ServiceStatusInfo(
        isOnlineMode = true,
        backendEndpoint = "Embedded Authoritative Ledger",
        lastSyncedLabel = "Just now",
        pendingOutboxCount = 0,
        ledgerBalanced = true,
        activeFaultMode = DemoFaultMode.NONE
    ),
    val assistantMessages: List<AssistantMessage> = emptyList(),
    val isBusy: Boolean = false,
    val mfaPromptRequired: Boolean = false,
    val bannerMessage: String? = null,
    val errorMessage: String? = null,
    val lastRequestId: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class BankingViewModel(application: Application) : AndroidViewModel(application) {

    private val crypto = SecurityCryptoManager(application)
    private val db = BankingDatabase.getInstance(application)
    val engine = AuthoritativeBankingEngine(db.bankingDao(), crypto)
    @Suppress("unused")
    private val apiClient = BankingApiClient()

    private val activeCustomerId = MutableStateFlow<String?>(null)
    private val transientState = MutableStateFlow(TransientControls())

    private data class TransientControls(
        val isInitializing: Boolean = true,
        val activeDraftTransfer: TransferRecord? = null,
        val lastTransferConfirmation: TransferRecord? = null,
        val transferNeedsReconcile: Boolean = false,
        val isBusy: Boolean = false,
        val mfaPromptRequired: Boolean = false,
        val bannerMessage: String? = null,
        val errorMessage: String? = null,
        val lastRequestId: String? = null,
        val faultMode: DemoFaultMode = DemoFaultMode.NONE,
        val offlineMode: Boolean = false,
        val ledgerBalanced: Boolean = true,
        val assistantMessages: List<AssistantMessage> = listOf(
            AssistantMessage(
                id = "ast_welcome",
                fromUser = false,
                text = "Hello! I am the Crestline synthetic insights assistant (offline deterministic mode). Ask me to explain authorised transactions, summarise your $2,184.60 spending, explain fees, or draft a support enquiry with ledger references."
            )
        )
    )

    val uiState: StateFlow<BankingUiState> = combine(
        activeCustomerId.flatMapLatest { cid ->
            if (cid == null) {
                flowOf(CustomerBundle())
            } else {
                combine(
                    engine.observeCustomer(cid),
                    engine.observeAccounts(cid),
                    engine.observeTransactions(cid),
                    engine.observeHolds(cid),
                    engine.observeTransfers(cid)
                ) { cust, accs, txs, holds, trfs ->
                    CustomerBundle(cust, accs, txs, holds, trfs)
                }
            }
        },
        activeCustomerId.flatMapLatest { cid ->
            if (cid == null) {
                flowOf(SecondaryBundle())
            } else {
                combine(
                    engine.observePayees(cid),
                    engine.observePayments(cid),
                    engine.observePaymentRequests(cid),
                    engine.observeDeposits(cid),
                    engine.observeCards(cid)
                ) { payees, pays, reqs, deps, cards ->
                    SecondaryBundle(payees, pays, reqs, deps, cards)
                }
            }
        },
        activeCustomerId.flatMapLatest { cid ->
            if (cid == null) {
                flowOf(TertiaryBundle())
            } else {
                combine(
                    engine.observeInsights(cid),
                    engine.observeNotifications(cid),
                    engine.observeStatements(cid),
                    engine.observeSessions(cid),
                    engine.observeOutboxCount(cid)
                ) { insights, notifs, stmts, sess, outbox ->
                    TertiaryBundle(insights, notifs, stmts, sess, outbox)
                }
            }
        },
        crypto.preferencesFlow,
        transientState.asStateFlow()
    ) { primary, secondary, tertiary, prefs, ctrl ->
        val depositAccounts = primary.accounts.filter {
            it.accountType == AccountType.CHECKING || it.accountType == AccountType.SAVINGS
        }
        val combinedDeposit = depositAccounts.sumOf { it.availableBalanceCents }
        val creditAccount = primary.accounts.firstOrNull { it.accountType == AccountType.CREDIT_CARD }
        val syncLabel = if (prefs.lastSyncedEpochMs > 0L) {
            SimpleDateFormat("h:mm:ss a", Locale.US).format(Date(prefs.lastSyncedEpochMs))
        } else {
            "Seeded"
        }

        BankingUiState(
            isInitializing = ctrl.isInitializing,
            currentCustomer = primary.customer,
            accounts = primary.accounts,
            combinedDepositAvailableCents = combinedDeposit,
            creditCardAccount = creditAccount,
            transactions = primary.transactions,
            pendingHolds = primary.holds,
            transfers = primary.transfers,
            activeDraftTransfer = ctrl.activeDraftTransfer,
            lastTransferConfirmation = ctrl.lastTransferConfirmation,
            transferNeedsReconcile = ctrl.transferNeedsReconcile,
            payees = secondary.payees,
            payments = secondary.payments,
            paymentRequests = secondary.paymentRequests,
            deposits = secondary.deposits,
            cards = secondary.cards,
            insights = tertiary.insights,
            notifications = tertiary.notifications,
            unreadNotificationCount = tertiary.notifications.count { !it.isRead },
            statements = tertiary.statements,
            deviceSessions = tertiary.sessions,
            preferences = prefs,
            serviceStatus = ServiceStatusInfo(
                isOnlineMode = !ctrl.offlineMode,
                backendEndpoint = prefs.backendBaseUrl.ifBlank { "Embedded Ktor-Parity Ledger" },
                lastSyncedLabel = syncLabel,
                pendingOutboxCount = tertiary.outboxCount,
                ledgerBalanced = ctrl.ledgerBalanced,
                activeFaultMode = ctrl.faultMode
            ),
            assistantMessages = ctrl.assistantMessages,
            isBusy = ctrl.isBusy,
            mfaPromptRequired = ctrl.mfaPromptRequired,
            bannerMessage = ctrl.bannerMessage,
            errorMessage = ctrl.errorMessage,
            lastRequestId = ctrl.lastRequestId
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BankingUiState()
    )

    init {
        viewModelScope.launch {
            engine.ensureSeeded()
            val restored = engine.restoreActiveSession()
            val balanced = engine.verifyLedgerBalanced()
            activeCustomerId.value = restored?.customerId
            transientState.update { it.copy(isInitializing = false, ledgerBalanced = balanced) }
        }
    }

    // --- Auth ---

    fun signIn(email: String, password: String, mfaCode: String? = null) {
        viewModelScope.launch {
            transientState.update { it.copy(isBusy = true, errorMessage = null, bannerMessage = null) }
            val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }
            when (val res = engine.signIn(email, password, deviceName, mfaCode)) {
                is ApiOutcome.Success -> {
                    activeCustomerId.value = res.data.customerId
                    transientState.update {
                        it.copy(
                            isBusy = false,
                            mfaPromptRequired = false,
                            lastRequestId = res.requestId,
                            bannerMessage = "Signed in as ${res.data.fullName}"
                        )
                    }
                }
                is ApiOutcome.Error -> {
                    transientState.update {
                        it.copy(
                            isBusy = false,
                            mfaPromptRequired = res.code == "MFA_REQUIRED",
                            errorMessage = res.message,
                            lastRequestId = res.requestId
                        )
                    }
                }
            }
        }
    }

    fun signInAsDemoAlex() {
        signIn(AuthoritativeBankingEngine.DEMO_EMAIL, AuthoritativeBankingEngine.DEMO_PASSWORD)
    }

    fun createDemoAccount(fullName: String, email: String, password: String) {
        viewModelScope.launch {
            transientState.update { it.copy(isBusy = true, errorMessage = null) }
            val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }
            when (val res = engine.createDemoAccount(fullName, email, password, deviceName)) {
                is ApiOutcome.Success -> {
                    activeCustomerId.value = res.data.customerId
                    transientState.update {
                        it.copy(
                            isBusy = false,
                            lastRequestId = res.requestId,
                            bannerMessage = "Created demonstration profile for ${res.data.fullName}"
                        )
                    }
                }
                is ApiOutcome.Error -> {
                    transientState.update {
                        it.copy(isBusy = false, errorMessage = res.message, lastRequestId = res.requestId)
                    }
                }
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            engine.signOut()
            activeCustomerId.value = null
            transientState.update {
                it.copy(
                    activeDraftTransfer = null,
                    lastTransferConfirmation = null,
                    transferNeedsReconcile = false,
                    mfaPromptRequired = false,
                    bannerMessage = "Signed out securely. Session credentials cleared."
                )
            }
        }
    }

    fun refreshSessionTokens() {
        viewModelScope.launch {
            when (val res = engine.refreshSession()) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        bannerMessage = "Refresh token rotated (gen #${res.data.refreshGeneration}).",
                        errorMessage = null,
                        lastRequestId = res.requestId
                    )
                }
                is ApiOutcome.Error -> transientState.update {
                    it.copy(errorMessage = res.message, lastRequestId = res.requestId)
                }
            }
        }
    }

    fun simulateExpiredToken() {
        viewModelScope.launch {
            engine.simulateExpireAccessToken()
            transientState.update {
                it.copy(bannerMessage = "Access token marked expired. Try an action or tap Refresh Token.")
            }
        }
    }

    fun revokeSession(sessionId: String) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            engine.revokeDeviceSession(cid, sessionId)
            val restored = engine.restoreActiveSession()
            if (restored == null) {
                activeCustomerId.value = null
            }
            transientState.update { it.copy(bannerMessage = "Session revoked.") }
        }
    }

    // --- Transfers ---

    fun previewTransfer(
        sourceAccountId: String,
        destinationAccountId: String,
        amountText: String,
        timing: TransferTiming
    ) {
        val cid = activeCustomerId.value ?: return
        val amountCents = CurrencyFormatter.parseToCents(amountText)
        if (amountCents == null || amountCents <= 0L) {
            transientState.update { it.copy(errorMessage = "Enter a valid dollar amount (e.g. 500.00).") }
            return
        }
        viewModelScope.launch {
            transientState.update { it.copy(isBusy = true, errorMessage = null, lastTransferConfirmation = null) }
            when (val res = engine.previewTransfer(cid, sourceAccountId, destinationAccountId, amountCents, timing)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        isBusy = false,
                        activeDraftTransfer = res.data,
                        transferNeedsReconcile = false,
                        lastRequestId = res.requestId
                    )
                }
                is ApiOutcome.Error -> transientState.update {
                    it.copy(isBusy = false, errorMessage = res.message, lastRequestId = res.requestId)
                }
            }
        }
    }

    fun invalidateDraftOnTermsChanged() {
        if (transientState.value.activeDraftTransfer != null) {
            transientState.update {
                it.copy(
                    activeDraftTransfer = null,
                    transferNeedsReconcile = false,
                    bannerMessage = "Material terms changed — renewed review required."
                )
            }
        }
    }

    fun cancelDraftTransfer() {
        val draft = transientState.value.activeDraftTransfer ?: return
        viewModelScope.launch {
            engine.cancelDraftTransfer(draft.transferId)
            transientState.update {
                it.copy(
                    activeDraftTransfer = null,
                    transferNeedsReconcile = false,
                    bannerMessage = "Transfer draft cancelled."
                )
            }
        }
    }

    fun authoriseAndExecuteTransfer() {
        val cid = activeCustomerId.value ?: return
        val draft = transientState.value.activeDraftTransfer ?: return
        viewModelScope.launch {
            transientState.update { it.copy(isBusy = true, errorMessage = null) }
            when (val res = engine.executeTransfer(cid, draft)) {
                is ApiOutcome.Success -> {
                    val balanced = engine.verifyLedgerBalanced()
                    transientState.update {
                        it.copy(
                            isBusy = false,
                            activeDraftTransfer = null,
                            lastTransferConfirmation = res.data,
                            transferNeedsReconcile = false,
                            faultMode = engine.activeFaultMode,
                            ledgerBalanced = balanced,
                            lastRequestId = res.requestId,
                            bannerMessage = "Transfer ${res.data.status.name.lowercase()} (${res.data.confirmationReference})."
                        )
                    }
                }
                is ApiOutcome.Error -> {
                    transientState.update {
                        it.copy(
                            isBusy = false,
                            errorMessage = res.message,
                            transferNeedsReconcile = res.recoverableByReconcile,
                            faultMode = engine.activeFaultMode,
                            lastRequestId = res.requestId
                        )
                    }
                }
            }
        }
    }

    fun retryOrReconcileLastTransfer() {
        val cid = activeCustomerId.value ?: return
        val draft = transientState.value.activeDraftTransfer ?: return
        viewModelScope.launch {
            transientState.update { it.copy(isBusy = true, errorMessage = null) }
            // First check backend by idempotency key; if already committed (lost response!), returns persisted confirmation without duplicating!
            val res = when (val existing = engine.reconcileTransferByIdempotencyKey(cid, draft.idempotencyKey)) {
                is ApiOutcome.Success -> {
                    if (existing.data.status == com.example.domain.TransferStatus.COMPLETED) existing
                    else engine.executeTransfer(cid, draft)
                }
                is ApiOutcome.Error -> engine.executeTransfer(cid, draft)
            }
            when (res) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        isBusy = false,
                        activeDraftTransfer = null,
                        lastTransferConfirmation = res.data,
                        transferNeedsReconcile = false,
                        lastRequestId = res.requestId,
                        bannerMessage = "Reconciled via idempotency key — zero duplicate postings (${res.data.confirmationReference})."
                    )
                }
                is ApiOutcome.Error -> transientState.update {
                    it.copy(isBusy = false, errorMessage = res.message, lastRequestId = res.requestId)
                }
            }
        }
    }

    fun dismissTransferConfirmation() {
        transientState.update { it.copy(lastTransferConfirmation = null) }
    }

    // --- Payments & Requests ---

    fun addPayee(name: String, category: String, accountDigits: String, stepUpVerified: Boolean) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.addPayeeWithStepUp(cid, name, category, accountDigits, stepUpVerified)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(bannerMessage = "Added verified payee ${res.data.name}", errorMessage = null)
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun submitBillPayment(
        sourceAccountId: String,
        payeeId: String,
        payeeName: String,
        amountText: String,
        today: Boolean,
        recurring: Boolean
    ) {
        val cid = activeCustomerId.value ?: return
        val cents = CurrencyFormatter.parseToCents(amountText)
        if (cents == null || cents <= 0L) {
            transientState.update { it.copy(errorMessage = "Enter a valid payment amount.") }
            return
        }
        viewModelScope.launch {
            when (val res = engine.submitBillPayment(cid, sourceAccountId, payeeId, payeeName, cents, today, recurring)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        bannerMessage = "Payment ${res.data.status.name.lowercase()} (${res.data.reference})",
                        errorMessage = null
                    )
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun runScheduledPaymentsWorker() {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            val count = engine.runScheduledPaymentWorker(cid)
            transientState.update {
                it.copy(bannerMessage = "Reconciliation worker executed $count scheduled instruction(s).")
            }
        }
    }

    fun createPaymentRequest(fromParty: String, destinationAccountId: String, amountText: String, memo: String) {
        val cid = activeCustomerId.value ?: return
        val cents = CurrencyFormatter.parseToCents(amountText)
        if (cents == null || cents <= 0L) {
            transientState.update { it.copy(errorMessage = "Enter a valid request amount.") }
            return
        }
        viewModelScope.launch {
            when (val res = engine.createPaymentRequest(cid, fromParty, destinationAccountId, cents, memo)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(bannerMessage = "Payment request sent to ${res.data.fromParty} (not received funds).", errorMessage = null)
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    // --- Deposits ---

    fun submitSyntheticDeposit(
        accountId: String,
        amountText: String,
        docLabel: String,
        mimeType: String,
        fileSizeBytes: Long
    ) {
        val cid = activeCustomerId.value ?: return
        val cents = CurrencyFormatter.parseToCents(amountText)
        if (cents == null || cents <= 0L) {
            transientState.update { it.copy(errorMessage = "Enter a valid deposit amount.") }
            return
        }
        viewModelScope.launch {
            when (val res = engine.submitSyntheticDeposit(cid, accountId, cents, docLabel, mimeType, fileSizeBytes)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        bannerMessage = "Deposit ${res.data.reference} held pending simulated review (not yet spendable).",
                        errorMessage = null
                    )
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun releaseSimulatedDeposit(deposit: DepositSubmission) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.releaseSimulatedDeposit(cid, deposit)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(bannerMessage = "Mock deposit adapter cleared ${deposit.reference}.", errorMessage = null)
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    // --- Cards ---

    fun toggleCardLock(cardId: String, lock: Boolean) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.requestCardLockToggle(cid, cardId, lock)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        bannerMessage = "${res.data.networkLabel} ••••${res.data.maskedLast4}: ${res.data.issuerStatus.name.replace('_', ' ')}",
                        errorMessage = null,
                        lastRequestId = res.requestId
                    )
                }
                is ApiOutcome.Error -> transientState.update {
                    it.copy(errorMessage = res.message, lastRequestId = res.requestId)
                }
            }
        }
    }

    fun updateCardControls(
        cardId: String,
        dailyPurchaseCents: Long,
        dailyAtmCents: Long,
        onlineEnabled: Boolean,
        internationalEnabled: Boolean
    ) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.updateCardControls(cid, cardId, dailyPurchaseCents, dailyAtmCents, onlineEnabled, internationalEnabled)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(bannerMessage = "Card spending controls updated.", errorMessage = null)
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun requestCardReplacement(cardId: String, lostStolen: Boolean) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.requestCardReplacement(cid, cardId, lostStolen)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        bannerMessage = if (lostStolen) "Lost/stolen report confirmed by mock issuer." else "Replacement card request submitted.",
                        errorMessage = null
                    )
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    // --- Account Adjustments, Insights, Statements, Notifications ---

    fun createAdjustment(transactionId: String, reason: String) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.createLinkedAdjustment(cid, transactionId, reason)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(bannerMessage = "Linked adjustment posted (${res.data}); original entry preserved.", errorMessage = null)
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun recategorizeTransaction(transactionId: String, category: SpendingCategory) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.recategorizeTransaction(cid, transactionId, category)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(bannerMessage = "Category updated to ${category.displayName}.", errorMessage = null)
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun generateStatement(accountId: String) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            when (val res = engine.generateStatement(cid, accountId)) {
                is ApiOutcome.Success -> transientState.update {
                    it.copy(
                        bannerMessage = "Statement ${res.data.periodLabel} generated for ${res.data.accountName}.",
                        errorMessage = null
                    )
                }
                is ApiOutcome.Error -> transientState.update { it.copy(errorMessage = res.message) }
            }
        }
    }

    fun markNotificationsRead() {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch { engine.markAllNotificationsRead(cid) }
    }

    // --- Preferences & Demo Controls ---

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { crypto.saveThemeMode(mode) }
    }

    fun setReducedMotion(enabled: Boolean) {
        viewModelScope.launch { crypto.saveReducedMotion(enabled) }
    }

    fun setBackendUrl(url: String) {
        viewModelScope.launch {
            if (crypto.saveBackendUrl(url)) {
                transientState.update { it.copy(bannerMessage = "Backend endpoint saved.", errorMessage = null) }
            } else {
                transientState.update { it.copy(errorMessage = "Deployed endpoints must use https:// (TLS required).") }
            }
        }
    }

    fun updateProfilePreferences(
        mfaEnabled: Boolean,
        biometricEnabled: Boolean,
        lockScreenRedaction: Boolean,
        emailAlerts: Boolean,
        pushAlerts: Boolean
    ) {
        val cid = activeCustomerId.value ?: return
        viewModelScope.launch {
            engine.updateProfilePreferences(cid, mfaEnabled, biometricEnabled, lockScreenRedaction, emailAlerts, pushAlerts)
            transientState.update { it.copy(bannerMessage = "Security & contact preferences saved.") }
        }
    }

    fun setFaultMode(mode: DemoFaultMode) {
        engine.activeFaultMode = mode
        transientState.update {
            it.copy(
                faultMode = mode,
                bannerMessage = "Fault simulator set to: ${mode.label}"
            )
        }
    }

    fun setOfflineMode(offline: Boolean) {
        engine.simulateOffline = offline
        transientState.update {
            it.copy(
                offlineMode = offline,
                bannerMessage = if (offline) "Offline mode active — cached balances shown with update time." else "Reconnected to authoritative ledger."
            )
        }
    }

    fun askAssistant(prompt: String) {
        if (prompt.isBlank()) return
        val state = uiState.value
        val userMsg = AssistantMessage(
            id = "usr_${System.currentTimeMillis()}",
            fromUser = true,
            text = prompt.trim()
        )
        val reply = BankingAssistantEngine.respond(
            prompt = prompt,
            accounts = state.accounts,
            transactions = state.transactions,
            insights = state.insights,
            payments = state.payments
        )
        transientState.update {
            it.copy(assistantMessages = it.assistantMessages + userMsg + reply)
        }
    }

    fun clearMessages() {
        transientState.update { it.copy(bannerMessage = null, errorMessage = null) }
    }

    private data class CustomerBundle(
        val customer: CustomerProfile? = null,
        val accounts: List<BankAccount> = emptyList(),
        val transactions: List<LedgerTransaction> = emptyList(),
        val holds: List<PendingHold> = emptyList(),
        val transfers: List<TransferRecord> = emptyList()
    )

    private data class SecondaryBundle(
        val payees: List<Payee> = emptyList(),
        val payments: List<PaymentInstruction> = emptyList(),
        val paymentRequests: List<PaymentRequest> = emptyList(),
        val deposits: List<DepositSubmission> = emptyList(),
        val cards: List<BankCard> = emptyList()
    )

    private data class TertiaryBundle(
        val insights: SpendingInsights? = null,
        val notifications: List<NotificationItem> = emptyList(),
        val statements: List<BankStatement> = emptyList(),
        val sessions: List<DeviceSession> = emptyList(),
        val outboxCount: Int = 0
    )
}
