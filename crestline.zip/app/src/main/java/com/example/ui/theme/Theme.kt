package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

@Immutable
data class CrestlineExtendedColors(
    val cardBorder: Color,
    val softTile: Color,
    val positive: Color,
    val positiveContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val heroGradientStart: Color,
    val heroGradientEnd: Color,
    val debitCardStart: Color,
    val debitCardEnd: Color,
    val subtleText: Color
)

private val LightExtendedColors = CrestlineExtendedColors(
    cardBorder = SubtleBorderLight,
    softTile = SoftBlueTint,
    positive = EmeraldPositive,
    positiveContainer = EmeraldContainerLight,
    warning = AmberWarning,
    warningContainer = AmberContainerLight,
    heroGradientStart = DeepCobalt,
    heroGradientEnd = RoyalBlueAccent,
    debitCardStart = DarkCardNavy,
    debitCardEnd = RoyalBlueAccent,
    subtleText = SlateNavy
)

private val DarkExtendedColors = CrestlineExtendedColors(
    cardBorder = NightBorder,
    softTile = NightSurfaceElevated,
    positive = EmeraldDark,
    positiveContainer = Color(0xFF0E3325),
    warning = AmberDark,
    warningContainer = Color(0xFF33240C),
    heroGradientStart = Color(0xFF082E73),
    heroGradientEnd = Color(0xFF1456C4),
    debitCardStart = Color(0xFF05132E),
    debitCardEnd = Color(0xFF0D44A8),
    subtleText = NightTextSecondary
)

val LocalCrestlineColors = staticCompositionLocalOf { LightExtendedColors }
val LocalReducedMotion = staticCompositionLocalOf { false }

private val LightColorScheme = lightColorScheme(
    primary = CobaltPrimary,
    onPrimary = LuminousWhite,
    primaryContainer = SoftBlueTint,
    onPrimaryContainer = DeepCobalt,
    secondary = RoyalBlueAccent,
    onSecondary = LuminousWhite,
    secondaryContainer = SoftBlueTint,
    onSecondaryContainer = MidnightNavy,
    tertiary = EmeraldPositive,
    onTertiary = LuminousWhite,
    background = PaleIceCanvas,
    onBackground = MidnightNavy,
    surface = LuminousWhite,
    onSurface = MidnightNavy,
    surfaceVariant = SoftBlueTint,
    onSurfaceVariant = SlateNavy,
    outline = SubtleBorderLight,
    outlineVariant = Color(0xFFD0DDF0),
    error = CrimsonError,
    onError = LuminousWhite,
    errorContainer = CrimsonContainerLight,
    onErrorContainer = CrimsonError
)

private val DarkColorScheme = darkColorScheme(
    primary = CobaltDarkPrimary,
    onPrimary = NightCanvas,
    primaryContainer = NightSurfaceElevated,
    onPrimaryContainer = NightTextPrimary,
    secondary = Color(0xFF7CB2FF),
    onSecondary = NightCanvas,
    secondaryContainer = NightSurfaceElevated,
    onSecondaryContainer = NightTextPrimary,
    tertiary = EmeraldDark,
    onTertiary = NightCanvas,
    background = NightCanvas,
    onBackground = NightTextPrimary,
    surface = NightSurface,
    onSurface = NightTextPrimary,
    surfaceVariant = NightSurfaceElevated,
    onSurfaceVariant = NightTextSecondary,
    outline = NightBorder,
    outlineVariant = Color(0xFF1D3154),
    error = CrimsonDark,
    onError = NightCanvas,
    errorContainer = Color(0xFF3D161A),
    onErrorContainer = CrimsonDark
)

val CrestlineShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun CrestlineTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    val extendedColors = if (darkTheme) DarkExtendedColors else LightExtendedColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalCrestlineColors provides extendedColors,
        LocalReducedMotion provides reducedMotion
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = CrestlineTypography,
            shapes = CrestlineShapes,
            content = content
        )
    }
}
