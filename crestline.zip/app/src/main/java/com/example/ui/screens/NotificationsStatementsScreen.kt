package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.CurrencyFormatter
import com.example.domain.TransactionDirection
import com.example.ui.BankingUiState
import com.example.ui.components.ConceptDisclaimerBar
import com.example.ui.components.ElevatedSurfaceCard
import com.example.ui.theme.LocalCrestlineColors
import com.example.ui.theme.MonoFontFamily

@Composable
fun NotificationsStatementsScreen(
    uiState: BankingUiState,
    initialTab: Int = 0,
    onMarkNotificationsRead: () -> Unit,
    onGenerateStatement: (accountId: String) -> Unit
) {
    val ext = LocalCrestlineColors.current
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var previewLockScreenMode by remember { mutableStateOf(false) }

    LaunchedEffect(selectedTab) {
        if (selectedTab == 0) onMarkNotificationsRead()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Notifications (${uiState.notifications.size})") },
                modifier = Modifier.testTag("tab_notifications")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Statements (${uiState.statements.size})") },
                modifier = Modifier.testTag("tab_statements")
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier.widthIn(max = 620.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (selectedTab == 0) {
                        ElevatedSurfaceCard {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Lock-screen redaction preview", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "Sensitive balances and amounts are hidden on lock-screen alerts by default.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = previewLockScreenMode,
                                    onCheckedChange = { previewLockScreenMode = it }
                                )
                            }
                        }

                        uiState.notifications.forEach { n ->
                            ElevatedSurfaceCard {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(n.title, style = MaterialTheme.typography.titleSmall)
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = ext.softTile
                                        ) {
                                            Text(
                                                text = n.category,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = if (previewLockScreenMode || (uiState.currentCustomer?.lockScreenRedactionEnabled == true && previewLockScreenMode)) {
                                            n.lockScreenSafeBody
                                        } else {
                                            n.body
                                        },
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        text = "Created: ${n.createdAtLabel} • Delivery: ${n.deliveryStatus}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        ElevatedSurfaceCard {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Generate reconciled statement", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Statements reconcile opening balance, posted credits, posted debits, and closing balance directly from immutable ledger entries.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    uiState.accounts.forEach { acc ->
                                        OutlinedButton(
                                            onClick = { onGenerateStatement(acc.accountId) },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("generate_stmt_${acc.accountId}")
                                        ) {
                                            Text(acc.name.substringBefore(" "), style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            }
                        }

                        uiState.statements.forEach { stmt ->
                            ElevatedSurfaceCard {
                                Column(
                                    modifier = Modifier
                                        .padding(18.dp)
                                        .testTag("statement_card_${stmt.accountId}"),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("${stmt.accountName} ${stmt.maskedNumber}", style = MaterialTheme.typography.titleMedium)
                                        Text(stmt.periodLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                    }
                                    HorizontalDivider(color = ext.cardBorder)
                                    StatementMetricRow("Opening balance", CurrencyFormatter.formatCents(stmt.openingBalanceCents))
                                    StatementMetricRow("Posted credits", "+${CurrencyFormatter.formatCents(stmt.totalCreditsCents)}")
                                    StatementMetricRow("Posted debits", "-${CurrencyFormatter.formatCents(stmt.totalDebitsCents)}")
                                    StatementMetricRow("Closing balance", CurrencyFormatter.formatCents(stmt.closingBalanceCents), bold = true)
                                    HorizontalDivider(color = ext.cardBorder)
                                    Text("Posted entries (${stmt.lines.size})", style = MaterialTheme.typography.labelLarge)
                                    stmt.lines.forEach { line ->
                                        val sign = if (line.direction == TransactionDirection.CREDIT) "+" else "-"
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(line.description, style = MaterialTheme.typography.bodySmall)
                                                Text("${line.dateLabel} • ${line.reference}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Text("$sign${CurrencyFormatter.formatCents(line.amountCents)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                        }
                                    }
                                    Text(
                                        "Generated: ${stmt.generatedAtLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    ConceptDisclaimerBar()
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun StatementMetricRow(label: String, value: String, bold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodySmall)
        Text(
            value,
            style = if (bold) MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold) else MaterialTheme.typography.bodySmall
        )
    }
}
