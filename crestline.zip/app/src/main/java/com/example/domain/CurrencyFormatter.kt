package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

/**
 * Deterministic minor-unit (cents) currency formatting and fixed-point parsing.
 * Avoids floating-point arithmetic completely for financial figures.
 */
object CurrencyFormatter {

    fun formatCents(
        cents: Long,
        currency: String = "USD",
        showPositiveSign: Boolean = false,
        showNegativeSign: Boolean = true
    ): String {
        val absCents = abs(cents)
        val whole = absCents / 100
        val frac = absCents % 100
        val intFormatter = NumberFormat.getIntegerInstance(Locale.US)
        val formattedWhole = intFormatter.format(whole)
        val prefix = when {
            cents < 0 && showNegativeSign -> "-"
            cents > 0 && showPositiveSign -> "+"
            else -> ""
        }
        val symbol = when (currency) {
            "USD" -> "$"
            else -> "$currency "
        }
        return "$prefix$symbol$formattedWhole.${frac.toString().padStart(2, '0')}"
    }

    /**
     * Parses a user-entered decimal currency string (e.g. "500.00", "$500", "1,250.5")
     * strictly into integer minor units (cents) using BigDecimal.
     * Returns null if invalid, negative, or more than 2 decimal places.
     */
    fun parseToCents(rawInput: String): Long? {
        val cleaned = rawInput.trim().replace("$", "").replace(",", "")
        if (cleaned.isEmpty()) return null
        return try {
            val bd = BigDecimal(cleaned)
            if (bd.scale() > 2 || bd < BigDecimal.ZERO) return null
            val scaled = bd.setScale(2, RoundingMode.UNNECESSARY)
            scaled.movePointRight(2).longValueExact()
        } catch (_: Exception) {
            null
        }
    }
}
