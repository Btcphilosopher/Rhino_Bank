package com.example.domain

import kotlinx.serialization.Serializable

@Serializable
enum class AccountType {
    CHECKING,
    SAVINGS,
    CREDIT_CARD,
    CLEARING,
    FEE,
    FUNDING
}

@Serializable
enum class TransactionDirection {
    DEBIT,
    CREDIT
}

@Serializable
enum class TransactionStatus {
    PENDING,
    POSTED,
    REVERSED,
    ADJUSTMENT
}

@Serializable
enum class SpendingCategory(val displayName: String) {
    DINING("Dining"),
    SHOPPING("Shopping"),
    TRAVEL("Travel"),
    OTHER("Other"),
    EXCLUDED("Excluded")
}

@Serializable
enum class TransferStatus {
    DRAFT,
    REVIEWED,
    AUTHORISED,
    PROCESSING,
    COMPLETED,
    REJECTED,
    CANCELLED
}

@Serializable
enum class TransferTiming(val label: String) {
    TODAY("Today"),
    SCHEDULED("Scheduled (Next Business Day)"),
    RECURRING("Recurring Monthly")
}

@Serializable
enum class PaymentStatus {
    INSTRUCTION_CREATED,
    SUBMITTED,
    SETTLED,
    FAILED,
    SCHEDULED
}

@Serializable
enum class DepositStatus {
    SUBMITTED,
    UNDER_REVIEW,
    HELD_PENDING_AVAILABILITY,
    AVAILABLE,
    REJECTED
}

@Serializable
enum class CardType {
    DEBIT,
    CREDIT
}

@Serializable
enum class CardDesiredState {
    ACTIVE,
    LOCK_REQUESTED,
    UNLOCK_REQUESTED,
    REPLACEMENT_REQUESTED,
    LOST_REPORTED
}

@Serializable
enum class CardIssuerStatus {
    CONFIRMED_ACTIVE,
    CONFIRMED_LOCKED,
    PENDING_ISSUER,
    ISSUER_UNAVAILABLE,
    REPLACEMENT_ISSUED,
    FROZEN_LOST
}

@Serializable
enum class DemoFaultMode(val label: String, val description: String) {
    NONE("Normal (Success)", "Standard mock rail and ledger confirmation."),
    INSUFFICIENT_FUNDS("Insufficient funds", "Force an available-funds rejection on the next transfer."),
    EXPIRED_SESSION("Expired session", "Simulate an expired access token requiring refresh or sign-in."),
    PROVIDER_FAILURE("Provider failure", "Simulate an external rail / issuer adapter outage."),
    LOST_TRANSFER_RESPONSE("Lost response", "Ledger commits on backend while network drops; retry reconciles safely.")
}

@Serializable
enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

@Serializable
data class CustomerProfile(
    val customerId: String,
    val fullName: String,
    val firstName: String,
    val email: String,
    val phoneMasked: String,
    val mfaEnabled: Boolean,
    val biometricEnabled: Boolean,
    val lockScreenRedactionEnabled: Boolean,
    val emailAlertsEnabled: Boolean,
    val pushAlertsEnabled: Boolean
)

@Serializable
data class DeviceSession(
    val sessionId: String,
    val deviceName: String,
    val lastActiveLabel: String,
    val ipRegion: String,
    val isCurrentDevice: Boolean,
    val accessExpiresAtEpochMs: Long,
    val refreshGeneration: Int,
    val revoked: Boolean
)

@Serializable
data class BankAccount(
    val accountId: String,
    val customerId: String,
    val name: String,
    val accountType: AccountType,
    val maskedNumber: String,
    val currency: String = "USD",
    val postedBalanceCents: Long,
    val pendingHoldCents: Long,
    val availableBalanceCents: Long,
    val creditLimitCents: Long = 0L,
    val statementBalanceCents: Long = 0L,
    val minimumPaymentCents: Long = 0L,
    val paymentDueDateLabel: String? = null,
    val version: Long = 1L
)

@Serializable
data class PendingHold(
    val holdId: String,
    val accountId: String,
    val description: String,
    val amountCents: Long,
    val currency: String = "USD",
    val createdAtLabel: String,
    val reference: String
)

@Serializable
data class LedgerTransaction(
    val transactionId: String,
    val journalId: String,
    val accountId: String,
    val description: String,
    val merchantOrCounterparty: String,
    val amountCents: Long,
    val currency: String = "USD",
    val direction: TransactionDirection,
    val status: TransactionStatus,
    val category: SpendingCategory,
    val timestampEpochMs: Long,
    val timestampLabel: String,
    val reference: String,
    val linkedTransactionId: String? = null,
    val notes: String? = null
)

@Serializable
data class TransferRecord(
    val transferId: String,
    val customerId: String,
    val sourceAccountId: String,
    val destinationAccountId: String,
    val sourceName: String,
    val destinationName: String,
    val amountCents: Long,
    val feeCents: Long,
    val currency: String = "USD",
    val timing: TransferTiming,
    val status: TransferStatus,
    val idempotencyKey: String,
    val termsHash: String,
    val confirmationReference: String?,
    val failureReason: String? = null,
    val createdAtLabel: String,
    val journalId: String? = null
)

@Serializable
data class Payee(
    val payeeId: String,
    val name: String,
    val category: String,
    val maskedAccount: String,
    val verifiedByStepUp: Boolean
)

@Serializable
data class PaymentInstruction(
    val paymentId: String,
    val sourceAccountId: String,
    val payeeId: String,
    val payeeName: String,
    val amountCents: Long,
    val currency: String = "USD",
    val scheduledForLabel: String,
    val isRecurring: Boolean,
    val status: PaymentStatus,
    val reference: String,
    val railNote: String
)

@Serializable
data class PaymentRequest(
    val requestId: String,
    val fromParty: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val currency: String = "USD",
    val memo: String,
    val dueDateLabel: String,
    val statusLabel: String
)

@Serializable
data class DepositSubmission(
    val depositId: String,
    val accountId: String,
    val amountCents: Long,
    val currency: String = "USD",
    val documentLabel: String,
    val mimeType: String,
    val fileSizeBytes: Long,
    val status: DepositStatus,
    val availabilityNote: String,
    val reference: String
)

@Serializable
data class BankCard(
    val cardId: String,
    val customerId: String,
    val linkedAccountId: String,
    val linkedAccountName: String,
    val cardType: CardType,
    val holderName: String,
    val maskedLast4: String,
    val networkLabel: String,
    val desiredState: CardDesiredState,
    val issuerStatus: CardIssuerStatus,
    val dailyPurchaseLimitCents: Long,
    val dailyAtmLimitCents: Long,
    val onlinePaymentsEnabled: Boolean,
    val internationalEnabled: Boolean,
    val issuerRuleNote: String,
    val lastSyncedLabel: String
)

@Serializable
data class CategoryBreakdown(
    val category: SpendingCategory,
    val totalCents: Long,
    val previousPeriodCents: Long,
    val shareFraction: Float
)

@Serializable
data class UpcomingItem(
    val id: String,
    val title: String,
    val amountCents: Long,
    val dueDateLabel: String,
    val isConfirmedSchedule: Boolean,
    val sourceNote: String
)

@Serializable
data class SpendingInsights(
    val monthLabel: String,
    val totalCents: Long,
    val previousMonthTotalCents: Long,
    val categories: List<CategoryBreakdown>,
    val upcomingItems: List<UpcomingItem>,
    val methodologyNote: String
)

@Serializable
data class NotificationItem(
    val notificationId: String,
    val title: String,
    val body: String,
    val lockScreenSafeBody: String,
    val category: String,
    val createdAtLabel: String,
    val deliveryStatus: String,
    val isRead: Boolean
)

@Serializable
data class StatementLine(
    val dateLabel: String,
    val description: String,
    val reference: String,
    val amountCents: Long,
    val direction: TransactionDirection
)

@Serializable
data class BankStatement(
    val statementId: String,
    val accountId: String,
    val accountName: String,
    val maskedNumber: String,
    val periodLabel: String,
    val openingBalanceCents: Long,
    val totalCreditsCents: Long,
    val totalDebitsCents: Long,
    val closingBalanceCents: Long,
    val lines: List<StatementLine>,
    val generatedAtLabel: String
)

@Serializable
data class AssistantCitation(
    val label: String,
    val reference: String
)

@Serializable
data class AssistantMessage(
    val id: String,
    val fromUser: Boolean,
    val text: String,
    val citations: List<AssistantCitation> = emptyList(),
    val suggestedRoute: String? = null,
    val suggestedActionLabel: String? = null
)

@Serializable
data class ServiceStatusInfo(
    val isOnlineMode: Boolean,
    val backendEndpoint: String,
    val lastSyncedLabel: String,
    val pendingOutboxCount: Int,
    val ledgerBalanced: Boolean,
    val activeFaultMode: DemoFaultMode
)

sealed interface ApiOutcome<out T> {
    data class Success<T>(val data: T, val requestId: String) : ApiOutcome<T>
    data class Error(
        val code: String,
        val message: String,
        val httpStatus: Int,
        val requestId: String,
        val recoverableByReconcile: Boolean = false
    ) : ApiOutcome<Nothing>
}
