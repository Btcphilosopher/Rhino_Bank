package com.example.domain

/**
 * Redacts credentials, tokens, document payloads, and card numbers before
 * anything touches application logs or diagnostic exports.
 */
object LogRedactor {
    private val panRegex = Regex("""\b\d{12,19}\b""")
    private val bearerRegex = Regex("""(?i)(bearer|token|password|secret|cvv|pin)\s*[:=]\s*\S+""")

    fun redact(input: String): String {
        return input
            .replace(panRegex) { match ->
                val v = match.value
                "••••" + v.takeLast(4)
            }
            .replace(bearerRegex) { match ->
                val key = match.groupValues[1]
                "$key=[REDACTED]"
            }
    }

    fun redactDocumentBytes(byteCount: Int, mimeType: String): String =
        "[REDACTED_DOCUMENT mime=$mimeType sizeBytes=$byteCount]"
}
