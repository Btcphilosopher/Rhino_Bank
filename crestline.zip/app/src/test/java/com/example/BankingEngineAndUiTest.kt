package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.engine.AuthoritativeBankingEngine
import com.example.data.engine.BankingAssistantEngine
import com.example.data.local.BankingDatabase
import com.example.data.local.SecurityCryptoManager
import com.example.domain.AccountType
import com.example.domain.ApiOutcome
import com.example.domain.CurrencyFormatter
import com.example.domain.DemoFaultMode
import com.example.domain.LogRedactor
import com.example.domain.SpendingCategory
import com.example.domain.TransferStatus
import com.example.domain.TransferTiming
import com.example.ui.BankingUiState
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.CrestlineTheme
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BankingEngineAndUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var db: BankingDatabase
    private lateinit var crypto: SecurityCryptoManager
    private lateinit var engine: AuthoritativeBankingEngine

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, BankingDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        crypto = SecurityCryptoManager(context)
        engine = AuthoritativeBankingEngine(db.bankingDao(), crypto)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `complete demonstration flow sign in balances 500 transfer idempotency card lock insights statement sign out`() = runBlocking {
        // 1. Sign in as Alex Morgan
        val signInRes = engine.signIn(
            AuthoritativeBankingEngine.DEMO_EMAIL,
            AuthoritativeBankingEngine.DEMO_PASSWORD,
            "Robolectric Pixel"
        )
        assertTrue(signInRes is ApiOutcome.Success)

        // 2. Reconciled initial balances
        val accountsInitial = engine.observeAccounts(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        val checking = accountsInitial.first { it.accountType == AccountType.CHECKING }
        val savings = accountsInitial.first { it.accountType == AccountType.SAVINGS }
        val credit = accountsInitial.first { it.accountType == AccountType.CREDIT_CARD }
        assertEquals(842_018L, checking.availableBalanceCents)
        assertEquals(842_698L, checking.postedBalanceCents)
        assertEquals(680L, checking.pendingHoldCents)
        assertEquals(1_644_024L, savings.availableBalanceCents)
        assertEquals(2_486_042L, checking.availableBalanceCents + savings.availableBalanceCents)
        assertEquals(128_460L, credit.postedBalanceCents)

        // 3. Preview $500 checking-to-savings transfer
        val preview = engine.previewTransfer(
            AuthoritativeBankingEngine.ALEX_CUSTOMER_ID,
            AuthoritativeBankingEngine.CHECKING_ACCOUNT_ID,
            AuthoritativeBankingEngine.SAVINGS_ACCOUNT_ID,
            50_000L,
            TransferTiming.TODAY
        ) as ApiOutcome.Success

        // 4. Authorise and execute once
        val exec = engine.executeTransfer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, preview.data) as ApiOutcome.Success
        assertEquals(TransferStatus.COMPLETED, exec.data.status)

        // 5. Checking $7,920.18, Savings $16,940.24, Combined unchanged ($24,860.42)
        val after = engine.observeAccounts(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        val chkAfter = after.first { it.accountType == AccountType.CHECKING }
        val savAfter = after.first { it.accountType == AccountType.SAVINGS }
        assertEquals(792_018L, chkAfter.availableBalanceCents)
        assertEquals(1_694_024L, savAfter.availableBalanceCents)
        assertEquals(2_486_042L, chkAfter.availableBalanceCents + savAfter.availableBalanceCents)

        // 6. Retry same idempotency key without duplicating
        val retry = engine.executeTransfer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, preview.data) as ApiOutcome.Success
        assertEquals(exec.data.confirmationReference, retry.data.confirmationReference)
        val afterRetry = engine.observeAccounts(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        assertEquals(792_018L, afterRetry.first { it.accountType == AccountType.CHECKING }.availableBalanceCents)
        assertTrue(engine.verifyLedgerBalanced())

        // 7. Submit card lock & verify mock-issuer confirmation
        val lockRes = engine.requestCardLockToggle(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, "card_debit_1842", true) as ApiOutcome.Success
        assertEquals("LOCK_REQUESTED", lockRes.data.desiredState.name)
        assertEquals("CONFIRMED_LOCKED", lockRes.data.issuerStatus.name)

        // 8. Insights total $2,184.60 unchanged by internal transfer
        val insights = engine.observeInsights(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        assertEquals(218_460L, insights.totalCents)
        assertEquals(42_000L, insights.categories.first { it.category == SpendingCategory.DINING }.totalCents)

        // 9. Generate statement & verify opening + credits - debits == closing
        val stmt = engine.generateStatement(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, AuthoritativeBankingEngine.CHECKING_ACCOUNT_ID) as ApiOutcome.Success
        assertEquals(
            stmt.data.openingBalanceCents + stmt.data.totalCreditsCents - stmt.data.totalDebitsCents,
            stmt.data.closingBalanceCents
        )

        // 10. Sign out clears session
        engine.signOut()
        assertEquals(null, engine.restoreActiveSession())
    }

    @Test
    fun `security boundaries concurrent transfers lost response recovery and redaction`() = runBlocking {
        engine.signIn(AuthoritativeBankingEngine.DEMO_EMAIL, AuthoritativeBankingEngine.DEMO_PASSWORD, "Test")

        // Cross-customer access forbidden
        val cross = engine.previewTransfer(
            AuthoritativeBankingEngine.ALEX_CUSTOMER_ID,
            "acct_jordan_checking",
            AuthoritativeBankingEngine.SAVINGS_ACCOUNT_ID,
            1_000L,
            TransferTiming.TODAY
        )
        assertTrue(cross is ApiOutcome.Error && cross.httpStatus == 403)

        // Lost response fault mode commits once and reconciles via idempotency key
        val preview = (engine.previewTransfer(
            AuthoritativeBankingEngine.ALEX_CUSTOMER_ID,
            AuthoritativeBankingEngine.CHECKING_ACCOUNT_ID,
            AuthoritativeBankingEngine.SAVINGS_ACCOUNT_ID,
            10_000L,
            TransferTiming.TODAY
        ) as ApiOutcome.Success).data

        engine.activeFaultMode = DemoFaultMode.LOST_TRANSFER_RESPONSE
        val lostErr = engine.executeTransfer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, preview)
        assertTrue(lostErr is ApiOutcome.Error && lostErr.recoverableByReconcile)

        val reconciled = engine.reconcileTransferByIdempotencyKey(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, preview.idempotencyKey)
        assertTrue(reconciled is ApiOutcome.Success && reconciled.data.status == TransferStatus.COMPLETED)

        // Concurrent $5,000 transfers against remaining ~$8,320.18: only 1 succeeds
        val d1 = (engine.previewTransfer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, AuthoritativeBankingEngine.CHECKING_ACCOUNT_ID, AuthoritativeBankingEngine.SAVINGS_ACCOUNT_ID, 500_000L, TransferTiming.TODAY) as ApiOutcome.Success).data
        val d2 = (engine.previewTransfer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, AuthoritativeBankingEngine.CHECKING_ACCOUNT_ID, AuthoritativeBankingEngine.SAVINGS_ACCOUNT_ID, 500_000L, TransferTiming.TODAY) as ApiOutcome.Success).data
        val results = listOf(d1, d2).map { d ->
            async { engine.executeTransfer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID, d) }
        }.awaitAll()
        assertEquals(1, results.count { it is ApiOutcome.Success })
        assertTrue(engine.verifyLedgerBalanced())

        // TLS enforcement & Log redaction
        assertFalse(SecurityCryptoManager.validateTlsEndpoint("http://api.example.com"))
        assertTrue(SecurityCryptoManager.validateTlsEndpoint("https://api.crestline.demo"))
        val safeLog = LogRedactor.redact("token=abc12345 pan=4111222233334477")
        assertFalse(safeLog.contains("abc12345"))
        assertTrue(safeLog.contains("••••4477"))

        // Assistant guardrail blocks autonomous transfer
        val assistantReply = BankingAssistantEngine.respond("transfer $500 to savings", emptyList(), emptyList(), null, emptyList())
        assertTrue(assistantReply.text.contains("cannot execute", ignoreCase = true))
        assertEquals("$500.00", CurrencyFormatter.formatCents(50_000L))
    }

    @Test
    fun `home screen renders balances and quick actions with compose test tags`() = runBlocking {
        engine.ensureSeeded()
        val accounts = engine.observeAccounts(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        val txs = engine.observeTransactions(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        val customer = engine.observeCustomer(AuthoritativeBankingEngine.ALEX_CUSTOMER_ID).first()
        var transferClicked = false

        composeRule.setContent {
            CrestlineTheme {
                HomeScreen(
                    uiState = BankingUiState(
                        isInitializing = false,
                        currentCustomer = customer,
                        accounts = accounts,
                        combinedDepositAvailableCents = 2_486_042L,
                        transactions = txs
                    ),
                    onPayClick = {},
                    onTransferClick = { transferClicked = true },
                    onDepositClick = {},
                    onCardsClick = {},
                    onAccountClick = {},
                    onSeeNotificationsClick = {}
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("total_available_balance").assertIsDisplayed()
        composeRule.onNodeWithText("$24,860.42").assertIsDisplayed()
        composeRule.onNodeWithTag("quick_action_transfer").performClick()
        assertTrue(transferClicked)
    }
}
