package com.crestline.backend

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.server.testing.testApplication
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.serialization.json.Json
import org.h2.jdbcx.JdbcDataSource
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class BankingBackendTest {

    private val json = Json { ignoreUnknownKeys = true }

    private fun freshTestDataSource(): JdbcDataSource {
        return JdbcDataSource().apply {
            setURL("jdbc:h2:mem:crestline_${UUID.randomUUID().toString().replace("-", "")};MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1")
            user = "sa"
            password = ""
        }
    }

    @Test
    fun `auth login refresh rotation revocation and cross customer isolation`() = testApplication {
        val ds = freshTestDataSource()
        application { bankingModule(ds, startBackgroundWorker = false) }

        val loginResp = client.post("/auth/login") {
            contentType(ContentType.Application.Json)
            setBody("""{"email":"alex.morgan@crestline.demo","password":"DemoPassword!2026","deviceName":"Pixel 9"}""")
        }
        assertEquals(HttpStatusCode.OK, loginResp.status)
        val auth = json.decodeFromString<AuthResponseDto>(loginResp.bodyAsText())

        // Cross-customer access denied
        val crossResp = client.get("/accounts/acct_jordan_checking/transactions") {
            header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}")
        }
        assertEquals(HttpStatusCode.Forbidden, crossResp.status)

        // Refresh rotation
        val refreshResp = client.post("/auth/refresh") {
            contentType(ContentType.Application.Json)
            setBody("""{"sessionId":"${auth.sessionId}","refreshToken":"${auth.refreshToken}"}""")
        }
        assertEquals(HttpStatusCode.OK, refreshResp.status)
        val rotated = json.decodeFromString<AuthResponseDto>(refreshResp.bodyAsText())
        assertNotEquals(auth.refreshToken, rotated.refreshToken)

        // Reusing old refresh token triggers revocation
        val replayResp = client.post("/auth/refresh") {
            contentType(ContentType.Application.Json)
            setBody("""{"sessionId":"${auth.sessionId}","refreshToken":"${auth.refreshToken}"}""")
        }
        assertEquals(HttpStatusCode.Unauthorized, replayResp.status)

        // Revoked session token cannot read accounts
        val blockedAccounts = client.get("/accounts") {
            header(HttpHeaders.Authorization, "Bearer ${rotated.accessToken}")
        }
        assertEquals(HttpStatusCode.Unauthorized, blockedAccounts.status)
    }

    @Test
    fun `seeded balances internal 500 transfer idempotency and lost response recovery`() = testApplication {
        val ds = freshTestDataSource()
        application { bankingModule(ds, startBackgroundWorker = false) }

        val auth = json.decodeFromString<AuthResponseDto>(
            client.post("/auth/login") {
                contentType(ContentType.Application.Json)
                setBody("""{"email":"alex.morgan@crestline.demo","password":"DemoPassword!2026","deviceName":"Test"}""")
            }.bodyAsText()
        )

        val accounts = json.decodeFromString<List<AccountDto>>(
            client.get("/accounts") { header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}") }.bodyAsText()
        )
        val checking = accounts.first { it.accountId == "acct_checking_1842" }
        val savings = accounts.first { it.accountId == "acct_savings_6091" }
        val credit = accounts.first { it.accountId == "acct_credit_4477" }

        assertEquals(842_018L, checking.availableBalanceCents)
        assertEquals(842_698L, checking.postedBalanceCents)
        assertEquals(680L, checking.pendingHoldCents)
        assertEquals(1_644_024L, savings.availableBalanceCents)
        assertEquals(128_460L, credit.postedBalanceCents)

        // Preview $500 transfer
        val preview = json.decodeFromString<TransferDto>(
            client.post("/transfers/preview") {
                header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}")
                contentType(ContentType.Application.Json)
                setBody("""{"sourceAccountId":"acct_checking_1842","destinationAccountId":"acct_savings_6091","amountCents":50000,"currency":"USD","timing":"TODAY"}""")
            }.bodyAsText()
        )
        assertEquals("REVIEWED", preview.status)

        // Execute transfer
        val execBody = """{"transferId":"${preview.transferId}","sourceAccountId":"acct_checking_1842","destinationAccountId":"acct_savings_6091","amountCents":50000,"currency":"USD","timing":"TODAY","idempotencyKey":"${preview.idempotencyKey}","termsHash":"${preview.termsHash}"}"""
        val execResp = client.post("/transfers") {
            header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}")
            header("Idempotency-Key", preview.idempotencyKey)
            contentType(ContentType.Application.Json)
            setBody(execBody)
        }
        assertEquals(HttpStatusCode.OK, execResp.status)
        val completed = json.decodeFromString<TransferDto>(execResp.bodyAsText())
        assertEquals("COMPLETED", completed.status)

        // Duplicate retry with same idempotency key returns identical confirmation
        val retryResp = client.post("/transfers") {
            header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}")
            header("Idempotency-Key", preview.idempotencyKey)
            contentType(ContentType.Application.Json)
            setBody(execBody)
        }
        val retried = json.decodeFromString<TransferDto>(retryResp.bodyAsText())
        assertEquals(completed.confirmationReference, retried.confirmationReference)

        // Lost-response recovery via GET /transfers/{id}
        val recovered = json.decodeFromString<TransferDto>(
            client.get("/transfers/${preview.transferId}") {
                header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}")
            }.bodyAsText()
        )
        assertEquals("COMPLETED", recovered.status)

        // Verify updated balances & unchanged combined deposit balance
        val after = json.decodeFromString<List<AccountDto>>(
            client.get("/accounts") { header(HttpHeaders.Authorization, "Bearer ${auth.accessToken}") }.bodyAsText()
        )
        val chkAfter = after.first { it.accountId == "acct_checking_1842" }
        val savAfter = after.first { it.accountId == "acct_savings_6091" }
        assertEquals(792_018L, chkAfter.availableBalanceCents)
        assertEquals(1_694_024L, savAfter.availableBalanceCents)
        assertEquals(2_486_042L, chkAfter.availableBalanceCents + savAfter.availableBalanceCents)
    }

    @Test
    fun `concurrent transfers available funds guard cards insights statements worker and webhook hmac`() = testApplication {
        val ds = freshTestDataSource()
        application { bankingModule(ds, webhookSecret = "test-webhook-secret", startBackgroundWorker = false) }
        assertEquals(HttpStatusCode.OK, client.get("/health").status)
        val service = LedgerService(ds, "test-secret")

        // Concurrent $5,000 transfers against $8,420.18 available: only one can succeed!
        val p1 = service.previewTransfer("cust_alex_morgan", TransferPreviewRequestDto("acct_checking_1842", "acct_savings_6091", 500_000L))
        val p2 = service.previewTransfer("cust_alex_morgan", TransferPreviewRequestDto("acct_checking_1842", "acct_savings_6091", 500_000L))

        val outcomes = kotlinx.coroutines.coroutineScope {
            listOf(p1, p2).map { p ->
                async {
                    runCatching {
                        service.executeTransfer(
                            "cust_alex_morgan",
                            TransferExecuteRequestDto(p.transferId, p.sourceAccountId, p.destinationAccountId, p.amountCents, p.currency, p.timing, p.idempotencyKey, p.termsHash)
                        )
                    }
                }
            }.awaitAll()
        }

        assertEquals(1, outcomes.count { it.isSuccess })
        assertEquals(0L, service.verifyGlobalLedgerZeroSum())

        // Card lock reconciliation
        val locked = service.requestCardLock("cust_alex_morgan", "card_debit_1842", CardLockRequestDto(true))
        assertEquals("LOCK_REQUESTED", locked.desiredState)
        assertEquals("CONFIRMED_LOCKED", locked.issuerStatus)

        // Spending insights ($2,184.60 excluding transfers & pending)
        val insights = service.getSpendingInsights("cust_alex_morgan")
        assertEquals(218_460L, insights.totalCents)

        // Statements reconcile cleanly
        val statements = service.generateOrListStatements("cust_alex_morgan")
        val chkStmt = statements.first { it.accountId == "acct_checking_1842" }
        assertEquals(chkStmt.openingBalanceCents + chkStmt.totalCreditsCents - chkStmt.totalDebitsCents, chkStmt.closingBalanceCents)

        // Scheduled payment worker
        ds.connection.use { conn ->
            conn.prepareStatement("UPDATE scheduled_payments SET due_at_ms = 0 WHERE payment_id = 'pay_rent_dec1'").executeUpdate()
        }
        assertEquals(1, service.runScheduledWorkerTick())

        // Sensitive data redaction
        val redacted = BackendSecurity.redactLog("Authorization: Bearer secret_abc_123 card=4111222233331842")
        assertTrue(!redacted.contains("secret_abc_123"))
        assertTrue(redacted.contains("••••1842"))

        // Webhook HMAC verification
        val payload = """{"event":"ach.settled","ref":"PAY-123"}"""
        val mac = Mac.getInstance("HmacSHA256").apply {
            init(SecretKeySpec("test-webhook-secret".toByteArray(), "HmacSHA256"))
        }.doFinal(payload.toByteArray()).joinToString("") { "%02x".format(it) }

        val badWebhook = client.post("/webhooks/mock-rail") {
            header("X-Webhook-Signature", "deadbeef")
            setBody(payload)
        }
        assertEquals(HttpStatusCode.Unauthorized, badWebhook.status)

        val goodWebhook = client.post("/webhooks/mock-rail") {
            header("X-Webhook-Signature", mac)
            setBody(payload)
        }
        assertEquals(HttpStatusCode.OK, goodWebhook.status)
    }
}
