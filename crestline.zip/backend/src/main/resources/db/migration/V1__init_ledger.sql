CREATE TABLE IF NOT EXISTS customers (
    customer_id VARCHAR(64) PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    password_hash_hex VARCHAR(128) NOT NULL,
    password_salt_hex VARCHAR(64) NOT NULL,
    mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    created_at_ms BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS device_sessions (
    session_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(customer_id),
    device_name VARCHAR(160) NOT NULL,
    refresh_token_hash VARCHAR(128) NOT NULL,
    refresh_generation INT NOT NULL DEFAULT 1,
    access_expires_at_ms BIGINT NOT NULL,
    revoked BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS accounts (
    account_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL,
    name VARCHAR(120) NOT NULL,
    account_type VARCHAR(32) NOT NULL,
    masked_number VARCHAR(32) NOT NULL,
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    credit_limit_cents BIGINT NOT NULL DEFAULT 0,
    statement_balance_cents BIGINT NOT NULL DEFAULT 0,
    minimum_payment_cents BIGINT NOT NULL DEFAULT 0,
    payment_due_date_label VARCHAR(32),
    version BIGINT NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS journals (
    journal_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL,
    business_reference VARCHAR(80) NOT NULL UNIQUE,
    description VARCHAR(240) NOT NULL,
    created_at_ms BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS ledger_lines (
    line_id VARCHAR(64) PRIMARY KEY,
    journal_id VARCHAR(64) NOT NULL REFERENCES journals(journal_id),
    account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    description VARCHAR(240) NOT NULL,
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    direction VARCHAR(16) NOT NULL CHECK (direction IN ('DEBIT', 'CREDIT')),
    status VARCHAR(24) NOT NULL DEFAULT 'POSTED',
    category VARCHAR(32) NOT NULL DEFAULT 'EXCLUDED',
    timestamp_ms BIGINT NOT NULL,
    timestamp_label VARCHAR(64) NOT NULL,
    reference VARCHAR(80) NOT NULL,
    linked_line_id VARCHAR(64)
);

CREATE INDEX IF NOT EXISTS idx_ledger_lines_account ON ledger_lines(account_id);

CREATE TABLE IF NOT EXISTS pending_holds (
    hold_id VARCHAR(64) PRIMARY KEY,
    account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    description VARCHAR(200) NOT NULL,
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    created_at_ms BIGINT NOT NULL,
    created_at_label VARCHAR(64) NOT NULL,
    reference VARCHAR(80) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS transfers (
    transfer_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(customer_id),
    source_account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    destination_account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    fee_cents BIGINT NOT NULL DEFAULT 0,
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    timing VARCHAR(32) NOT NULL,
    status VARCHAR(24) NOT NULL,
    idempotency_key VARCHAR(128) NOT NULL UNIQUE,
    terms_hash VARCHAR(128) NOT NULL,
    confirmation_reference VARCHAR(80),
    journal_id VARCHAR(64),
    created_at_ms BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS cards (
    card_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(customer_id),
    linked_account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    card_type VARCHAR(16) NOT NULL,
    holder_name VARCHAR(120) NOT NULL,
    masked_last4 VARCHAR(8) NOT NULL,
    desired_state VARCHAR(32) NOT NULL,
    issuer_status VARCHAR(32) NOT NULL,
    daily_purchase_limit_cents BIGINT NOT NULL,
    daily_atm_limit_cents BIGINT NOT NULL,
    last_synced_label VARCHAR(80) NOT NULL
);

CREATE TABLE IF NOT EXISTS scheduled_payments (
    payment_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(customer_id),
    source_account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    payee_name VARCHAR(120) NOT NULL,
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    due_at_ms BIGINT NOT NULL,
    due_label VARCHAR(32) NOT NULL,
    status VARCHAR(24) NOT NULL,
    reference VARCHAR(80) NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
    notification_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(customer_id),
    title VARCHAR(120) NOT NULL,
    body VARCHAR(400) NOT NULL,
    lock_screen_safe_body VARCHAR(240) NOT NULL,
    category VARCHAR(32) NOT NULL,
    created_at_ms BIGINT NOT NULL,
    delivery_status VARCHAR(64) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS statements (
    statement_id VARCHAR(64) PRIMARY KEY,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(customer_id),
    account_id VARCHAR(64) NOT NULL REFERENCES accounts(account_id),
    period_label VARCHAR(64) NOT NULL,
    opening_balance_cents BIGINT NOT NULL,
    total_credits_cents BIGINT NOT NULL,
    total_debits_cents BIGINT NOT NULL,
    closing_balance_cents BIGINT NOT NULL,
    generated_at_ms BIGINT NOT NULL
);
