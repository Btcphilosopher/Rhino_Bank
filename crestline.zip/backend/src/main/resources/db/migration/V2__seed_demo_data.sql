-- Seed system clearing/funding/fee accounts
INSERT INTO accounts (account_id, customer_id, name, account_type, masked_number, currency, version)
VALUES
    ('sys_funding_usd', 'SYSTEM', 'Synthetic Funding Vault', 'FUNDING', 'SYS-FUND', 'USD', 1),
    ('sys_merchant_clearing_usd', 'SYSTEM', 'Merchant Clearing Pool', 'CLEARING', 'SYS-CLR', 'USD', 1),
    ('sys_fee_revenue_usd', 'SYSTEM', 'Synthetic Fee Ledger', 'FEE', 'SYS-FEE', 'USD', 1);

-- Seed synthetic accounts for Alex Morgan (password hashed dynamically in app bootstrap if absent; fallback placeholder hash replaced on startup)
INSERT INTO customers (customer_id, full_name, email, password_hash_hex, password_salt_hex, mfa_enabled, created_at_ms)
VALUES
    ('cust_alex_morgan', 'Alex Morgan', 'alex.morgan@crestline.demo', 'BOOTSTRAP_HASH', '00112233445566778899aabbccddeeff', FALSE, 1794800000000),
    ('cust_jordan_lee', 'Jordan Lee', 'jordan.lee@crestline.demo', 'BOOTSTRAP_HASH', 'ffeeddccbbaa99887766554433221100', FALSE, 1794800000000);

INSERT INTO accounts (account_id, customer_id, name, account_type, masked_number, currency, credit_limit_cents, statement_balance_cents, minimum_payment_cents, payment_due_date_label, version)
VALUES
    ('acct_checking_1842', 'cust_alex_morgan', 'Everyday Checking', 'CHECKING', '••••1842', 'USD', 0, 0, 0, NULL, 1),
    ('acct_savings_6091', 'cust_alex_morgan', 'Savings', 'SAVINGS', '••••6091', 'USD', 0, 0, 0, NULL, 1),
    ('acct_credit_4477', 'cust_alex_morgan', 'Credit card balance', 'CREDIT_CARD', '••••4477', 'USD', 600000, 98460, 3500, 'Dec 12', 1),
    ('acct_jordan_checking', 'cust_jordan_lee', 'Jordan Checking', 'CHECKING', '••••7701', 'USD', 0, 0, 0, NULL, 1);

-- Balanced seed journals reconciling to Checking $8,420.18 ($8,426.98 posted - $6.80 hold), Savings $16,440.24, Credit $1,284.60, Insights $2,184.60
INSERT INTO journals (journal_id, customer_id, business_reference, description, created_at_ms) VALUES
    ('jrn_chk_open', 'cust_alex_morgan', 'OPEN-CHK-1842', 'Opening Checking Balance', 1794800001000),
    ('jrn_sav_open', 'cust_alex_morgan', 'OPEN-SAV-6091', 'Opening Savings Balance', 1794800002000),
    ('jrn_sav_int', 'cust_alex_morgan', 'INT-202611-6091', 'Monthly Interest Credit', 1794800003000),
    ('jrn_chk_util', 'cust_alex_morgan', 'ACH-20261105-4410', 'City Electric & Fiber', 1794800100000),
    ('jrn_cc_cloud', 'cust_alex_morgan', 'CRD-20261106-1190', 'Cloud & Media Subscriptions', 1794800150000),
    ('jrn_chk_home', 'cust_alex_morgan', 'DEB-20261108-2218', 'Nordic Home Goods', 1794800200000),
    ('jrn_cc_air', 'cust_alex_morgan', 'CRD-20261109-3304', 'Skyline Air', 1794800250000),
    ('jrn_chk_dining', 'cust_alex_morgan', 'DEB-20261110-5092', 'Harbor Bistro', 1794800300000),
    ('jrn_cc_apparel', 'cust_alex_morgan', 'CRD-20261111-6642', 'Atelier Apparel', 1794800350000),
    ('jrn_chk_rail', 'cust_alex_morgan', 'DEB-20261112-7103', 'Metro Transit & Rail', 1794800400000),
    ('jrn_cc_roast', 'cust_alex_morgan', 'CRD-20261114-8820', 'Apex Roasters & Kitchen', 1794800450000),
    ('jrn_chk_grocery', 'cust_alex_morgan', 'DEB-20261115-9901', 'Grocery market', 1794800500000),
    ('jrn_chk_payroll', 'cust_alex_morgan', 'ACH-20261116-1203', 'Payroll', 1794800600000),
    ('jrn_jordan_open', 'cust_jordan_lee', 'OPEN-JRD-7701', 'Jordan Opening Balance', 1794800004000);

INSERT INTO ledger_lines (line_id, journal_id, account_id, description, amount_cents, currency, direction, status, category, timestamp_ms, timestamp_label, reference) VALUES
    ('l_chk_open_1', 'jrn_chk_open', 'acct_checking_1842', 'Opening Balance Carryover', 607698, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800001000, 'Nov 1, 9:00 AM', 'OPEN-CHK-1842'),
    ('l_chk_open_2', 'jrn_chk_open', 'sys_funding_usd', 'Opening Balance Offset', 607698, 'USD', 'DEBIT', 'POSTED', 'EXCLUDED', 1794800001000, 'Nov 1, 9:00 AM', 'OPEN-CHK-1842'),
    ('l_sav_open_1', 'jrn_sav_open', 'acct_savings_6091', 'Opening Savings Balance', 1640210, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800002000, 'Nov 1, 9:00 AM', 'OPEN-SAV-6091'),
    ('l_sav_open_2', 'jrn_sav_open', 'sys_funding_usd', 'Opening Savings Offset', 1640210, 'USD', 'DEBIT', 'POSTED', 'EXCLUDED', 1794800002000, 'Nov 1, 9:00 AM', 'OPEN-SAV-6091'),
    ('l_sav_int_1', 'jrn_sav_int', 'acct_savings_6091', 'Monthly Interest Credit', 3814, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800003000, 'Nov 1, 9:05 AM', 'INT-202611-6091'),
    ('l_sav_int_2', 'jrn_sav_int', 'sys_funding_usd', 'Interest Offset', 3814, 'USD', 'DEBIT', 'POSTED', 'EXCLUDED', 1794800003000, 'Nov 1, 9:05 AM', 'INT-202611-6091'),
    ('l_chk_util_1', 'jrn_chk_util', 'acct_checking_1842', 'City Electric & Fiber', 27580, 'USD', 'DEBIT', 'POSTED', 'OTHER', 1794800100000, 'Nov 5, 10:15 AM', 'ACH-20261105-4410'),
    ('l_chk_util_2', 'jrn_chk_util', 'sys_merchant_clearing_usd', 'Merchant Clearing', 27580, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800100000, 'Nov 5, 10:15 AM', 'ACH-20261105-4410'),
    ('l_cc_cloud_1', 'jrn_cc_cloud', 'acct_credit_4477', 'Cloud & Media Subscriptions', 18460, 'USD', 'DEBIT', 'POSTED', 'OTHER', 1794800150000, 'Nov 6, 11:00 AM', 'CRD-20261106-1190'),
    ('l_cc_cloud_2', 'jrn_cc_cloud', 'sys_merchant_clearing_usd', 'Merchant Clearing', 18460, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800150000, 'Nov 6, 11:00 AM', 'CRD-20261106-1190'),
    ('l_chk_home_1', 'jrn_chk_home', 'acct_checking_1842', 'Nordic Home Goods', 28000, 'USD', 'DEBIT', 'POSTED', 'SHOPPING', 1794800200000, 'Nov 8, 2:40 PM', 'DEB-20261108-2218'),
    ('l_chk_home_2', 'jrn_chk_home', 'sys_merchant_clearing_usd', 'Merchant Clearing', 28000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800200000, 'Nov 8, 2:40 PM', 'DEB-20261108-2218'),
    ('l_cc_air_1', 'jrn_cc_air', 'acct_credit_4477', 'Skyline Air', 40000, 'USD', 'DEBIT', 'POSTED', 'TRAVEL', 1794800250000, 'Nov 9, 4:10 PM', 'CRD-20261109-3304'),
    ('l_cc_air_2', 'jrn_cc_air', 'sys_merchant_clearing_usd', 'Merchant Clearing', 40000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800250000, 'Nov 9, 4:10 PM', 'CRD-20261109-3304'),
    ('l_chk_din_1', 'jrn_chk_dining', 'acct_checking_1842', 'Harbor Bistro', 12000, 'USD', 'DEBIT', 'POSTED', 'DINING', 1794800300000, 'Nov 10, 7:55 PM', 'DEB-20261110-5092'),
    ('l_chk_din_2', 'jrn_chk_dining', 'sys_merchant_clearing_usd', 'Merchant Clearing', 12000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800300000, 'Nov 10, 7:55 PM', 'DEB-20261110-5092'),
    ('l_cc_app_1', 'jrn_cc_apparel', 'acct_credit_4477', 'Atelier Apparel', 40000, 'USD', 'DEBIT', 'POSTED', 'SHOPPING', 1794800350000, 'Nov 11, 1:25 PM', 'CRD-20261111-6642'),
    ('l_cc_app_2', 'jrn_cc_apparel', 'sys_merchant_clearing_usd', 'Merchant Clearing', 40000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800350000, 'Nov 11, 1:25 PM', 'CRD-20261111-6642'),
    ('l_chk_rail_1', 'jrn_chk_rail', 'acct_checking_1842', 'Metro Transit & Rail', 14000, 'USD', 'DEBIT', 'POSTED', 'TRAVEL', 1794800400000, 'Nov 12, 8:20 AM', 'DEB-20261112-7103'),
    ('l_chk_rail_2', 'jrn_chk_rail', 'sys_merchant_clearing_usd', 'Merchant Clearing', 14000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800400000, 'Nov 12, 8:20 AM', 'DEB-20261112-7103'),
    ('l_cc_roast_1', 'jrn_cc_roast', 'acct_credit_4477', 'Apex Roasters & Kitchen', 30000, 'USD', 'DEBIT', 'POSTED', 'DINING', 1794800450000, 'Nov 14, 8:15 PM', 'CRD-20261114-8820'),
    ('l_cc_roast_2', 'jrn_cc_roast', 'sys_merchant_clearing_usd', 'Merchant Clearing', 30000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800450000, 'Nov 14, 8:15 PM', 'CRD-20261114-8820'),
    ('l_chk_groc_1', 'jrn_chk_grocery', 'acct_checking_1842', 'Grocery market', 8420, 'USD', 'DEBIT', 'POSTED', 'OTHER', 1794800500000, 'Yesterday, 5:47 PM', 'DEB-20261115-9901'),
    ('l_chk_groc_2', 'jrn_chk_grocery', 'sys_merchant_clearing_usd', 'Merchant Clearing', 8420, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800500000, 'Yesterday, 5:47 PM', 'DEB-20261115-9901'),
    ('l_chk_pay_1', 'jrn_chk_payroll', 'acct_checking_1842', 'Payroll', 325000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800600000, 'Today, 12:03 PM', 'ACH-20261116-1203'),
    ('l_chk_pay_2', 'jrn_chk_payroll', 'sys_funding_usd', 'Payroll Funding Offset', 325000, 'USD', 'DEBIT', 'POSTED', 'EXCLUDED', 1794800600000, 'Today, 12:03 PM', 'ACH-20261116-1203'),
    ('l_jrd_open_1', 'jrn_jordan_open', 'acct_jordan_checking', 'Jordan Opening Balance', 120000, 'USD', 'CREDIT', 'POSTED', 'EXCLUDED', 1794800004000, 'Nov 1, 9:00 AM', 'OPEN-JRD-7701'),
    ('l_jrd_open_2', 'jrn_jordan_open', 'sys_funding_usd', 'Jordan Funding Offset', 120000, 'USD', 'DEBIT', 'POSTED', 'EXCLUDED', 1794800004000, 'Nov 1, 9:00 AM', 'OPEN-JRD-7701');

INSERT INTO pending_holds (hold_id, account_id, description, amount_cents, currency, created_at_ms, created_at_label, reference, active)
VALUES ('hold_coffee_680', 'acct_checking_1842', 'Coffee shop', 680, 'USD', 1794800700000, 'Today, 6:24 PM', 'HOLD-20261116-8821', TRUE);

INSERT INTO cards (card_id, customer_id, linked_account_id, card_type, holder_name, masked_last4, desired_state, issuer_status, daily_purchase_limit_cents, daily_atm_limit_cents, last_synced_label)
VALUES
    ('card_debit_1842', 'cust_alex_morgan', 'acct_checking_1842', 'DEBIT', 'ALEX MORGAN', '1842', 'ACTIVE', 'CONFIRMED_ACTIVE', 250000, 50000, 'Mock issuer synced'),
    ('card_credit_4477', 'cust_alex_morgan', 'acct_credit_4477', 'CREDIT', 'ALEX MORGAN', '4477', 'ACTIVE', 'CONFIRMED_ACTIVE', 400000, 30000, 'Mock issuer synced');

INSERT INTO scheduled_payments (payment_id, customer_id, source_account_id, payee_name, amount_cents, currency, due_at_ms, due_label, status, reference)
VALUES ('pay_rent_dec1', 'cust_alex_morgan', 'acct_checking_1842', 'Rent payment', 185000, 'USD', 1796083200000, 'Dec 1', 'SCHEDULED', 'SCH-RENT-20261201');

INSERT INTO notifications (notification_id, customer_id, title, body, lock_screen_safe_body, category, created_at_ms, delivery_status, is_read)
VALUES
    ('notif_payroll_1', 'cust_alex_morgan', 'Direct deposit posted', 'Payroll deposit of $3,250.00 posted to Everyday Checking ••••1842.', 'A new deposit posted to your checking account.', 'Deposit', 1794800600000, 'Delivered (In-App)', FALSE),
    ('notif_stmt_1', 'cust_alex_morgan', 'Statement available', 'October statement for Checking ••••1842 is ready.', 'A monthly account statement is ready.', 'Statement', 1794800010000, 'Delivered (In-App)', TRUE);
