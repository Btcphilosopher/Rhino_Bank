package com.crestline.backend

import com.auth0.jwt.JWT
import com.auth0.jwt.JWTVerifier
import com.auth0.jwt.algorithms.Algorithm
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Date
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object BackendSecurity {
    private val bearerRegex = Regex("""(?i)(bearer|token|password|secret|cvv|pin)\s*[:=]\s*\S+""")
    private val panRegex = Regex("""\b\d{12,19}\b""")

    fun redactLog(input: String): String =
        input
            .replace(panRegex) { "••••" + it.value.takeLast(4) }
            .replace(bearerRegex) { "${it.groupValues[1]}=[REDACTED]" }

    fun hashPassword(password: String, saltHex: String? = null): Pair<String, String> {
        val salt = if (saltHex != null) {
            saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } else {
            ByteArray(16).also { SecureRandom().nextBytes(it) }
        }
        val spec = PBEKeySpec(password.toCharArray(), salt, 65536, 256)
        val encoded = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return encoded.toHex() to salt.toHex()
    }

    fun verifyPassword(password: String, expectedHashHex: String, saltHex: String): Boolean {
        val (actual, _) = hashPassword(password, saltHex)
        return MessageDigest.isEqual(actual.toByteArray(), expectedHashHex.toByteArray())
    }

    fun sha256(input: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    fun verifyWebhookHmac(payload: String, signatureHex: String, secret: String): Boolean {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val expected = mac.doFinal(payload.toByteArray(Charsets.UTF_8)).toHex()
        return MessageDigest.isEqual(expected.toByteArray(), signatureHex.lowercase().toByteArray())
    }

    fun createJwt(customerId: String, sessionId: String, secret: String, ttlMs: Long): Pair<String, Long> {
        val expiresAt = System.currentTimeMillis() + ttlMs
        val token = JWT.create()
            .withIssuer("crestline-backend")
            .withSubject(customerId)
            .withClaim("sid", sessionId)
            .withExpiresAt(Date(expiresAt))
            .sign(Algorithm.HMAC256(secret))
        return token to expiresAt
    }

    fun jwtVerifier(secret: String): JWTVerifier =
        JWT.require(Algorithm.HMAC256(secret))
            .withIssuer("crestline-backend")
            .build()

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
