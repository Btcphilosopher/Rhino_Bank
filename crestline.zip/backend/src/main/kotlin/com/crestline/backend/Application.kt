package com.crestline.backend

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.auth.Authentication
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.jwt.JWTPrincipal
import io.ktor.server.auth.jwt.jwt
import io.ktor.server.auth.principal
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.calllogging.CallLogging
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.ratelimit.RateLimit
import io.ktor.server.plugins.ratelimit.RateLimitName
import io.ktor.server.plugins.ratelimit.rateLimit
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.request.header
import io.ktor.server.request.receive
import io.ktor.server.request.receiveText
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import org.flywaydb.core.Flyway
import org.slf4j.event.Level
import java.util.UUID
import javax.sql.DataSource
import kotlin.time.Duration.Companion.minutes

fun createDataSource(
    jdbcUrl: String,
    user: String,
    password: String
): DataSource {
    val config = HikariConfig().apply {
        this.jdbcUrl = jdbcUrl
        this.username = user
        this.password = password
        maximumPoolSize = 10
        isAutoCommit = true
    }
    return HikariDataSource(config)
}

fun migrateDatabase(dataSource: DataSource) {
    Flyway.configure()
        .dataSource(dataSource)
        .locations("classpath:db/migration")
        .load()
        .migrate()
}

fun Application.bankingModule(
    dataSource: DataSource,
    jwtSecret: String = System.getenv("JWT_SECRET") ?: "crestline-dev-only-jwt-secret-32chars!",
    webhookSecret: String = System.getenv("WEBHOOK_HMAC_SECRET") ?: "crestline-dev-webhook-secret",
    startBackgroundWorker: Boolean = true
) {
    migrateDatabase(dataSource)
    val service = LedgerService(dataSource, jwtSecret)
    service.bootstrapSeedPasswords()

    install(ContentNegotiation) {
        json(Json { ignoreUnknownKeys = true; encodeDefaults = true })
    }
    install(CallLogging) {
        level = Level.INFO
        format { call ->
            val reqId = call.request.header("X-Request-Id") ?: "-"
            BackendSecurity.redactLog("${call.request.local.method.value} ${call.request.local.uri} reqId=$reqId")
        }
    }
    install(RateLimit) {
        register(RateLimitName("auth")) {
            rateLimiter(limit = 30, refillPeriod = 1.minutes)
        }
        register(RateLimitName("consequential")) {
            rateLimiter(limit = 60, refillPeriod = 1.minutes)
        }
    }
    install(StatusPages) {
        exception<BackendException> { call, cause ->
            val reqId = call.request.header("X-Request-Id") ?: UUID.randomUUID().toString().take(8)
            call.response.header("X-Request-Id", reqId)
            call.respond(
                HttpStatusCode.fromValue(cause.httpStatus),
                ApiErrorDto(cause.code, cause.message, reqId)
            )
        }
        exception<Throwable> { call, cause ->
            val reqId = call.request.header("X-Request-Id") ?: UUID.randomUUID().toString().take(8)
            call.response.header("X-Request-Id", reqId)
            call.respond(
                HttpStatusCode.InternalServerError,
                ApiErrorDto("INTERNAL_ERROR", BackendSecurity.redactLog(cause.message ?: "Unexpected error"), reqId)
            )
        }
    }
    install(Authentication) {
        jwt("auth-jwt") {
            verifier(BackendSecurity.jwtVerifier(jwtSecret))
            validate { credential ->
                val sub = credential.payload.subject
                val sid = credential.payload.getClaim("sid").asString()
                if (sub != null && sid != null && service.isSessionActive(sid)) {
                    JWTPrincipal(credential.payload)
                } else null
            }
            challenge { _, _ ->
                val reqId = call.request.header("X-Request-Id") ?: UUID.randomUUID().toString().take(8)
                call.respond(HttpStatusCode.Unauthorized, ApiErrorDto("SESSION_EXPIRED", "Valid Bearer token required.", reqId))
            }
        }
    }

    if (startBackgroundWorker) {
        launch {
            while (isActive) {
                runCatching { service.runScheduledWorkerTick() }
                delay(30_000L)
            }
        }
    }

    routing {
        get("/health") {
            call.respond(mapOf("status" to "ok", "ledgerNetSum" to service.verifyGlobalLedgerZeroSum().toString()))
        }

        rateLimit(RateLimitName("auth")) {
            post("/auth/login") {
                val req = call.receive<LoginRequestDto>()
                call.respond(service.login(req))
            }
            post("/auth/refresh") {
                val req = call.receive<RefreshRequestDto>()
                call.respond(service.refresh(req))
            }
        }

        post("/webhooks/mock-rail") {
            val sig = call.request.header("X-Webhook-Signature") ?: ""
            val body = call.receiveText()
            if (!BackendSecurity.verifyWebhookHmac(body, sig, webhookSecret)) {
                throw BackendException(401, "INVALID_WEBHOOK_SIGNATURE", "HMAC signature mismatch.")
            }
            call.respond(mapOf("status" to "accepted"))
        }

        authenticate("auth-jwt") {
            post("/auth/logout") {
                val principal = call.principal<JWTPrincipal>()!!
                service.logout(principal.payload.getClaim("sid").asString(), principal.payload.subject)
                call.respond(mapOf("status" to "revoked"))
            }

            get("/accounts") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                call.respond(service.listAccounts(customerId))
            }

            get("/accounts/{id}/transactions") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                val accountId = call.parameters["id"] ?: throw BackendException(400, "MISSING_ID", "Account id required.")
                val limit = call.request.queryParameters["limit"]?.toIntOrNull() ?: 50
                val offset = call.request.queryParameters["offset"]?.toIntOrNull() ?: 0
                call.respond(service.listTransactions(customerId, accountId, limit, offset))
            }

            rateLimit(RateLimitName("consequential")) {
                post("/transfers/preview") {
                    val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                    val req = call.receive<TransferPreviewRequestDto>()
                    call.respond(service.previewTransfer(customerId, req))
                }

                post("/transfers") {
                    val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                    val req = call.receive<TransferExecuteRequestDto>()
                    val headerIdem = call.request.header("Idempotency-Key")
                    val normalizedReq = if (!headerIdem.isNullOrBlank()) req.copy(idempotencyKey = headerIdem) else req
                    call.respond(service.executeTransfer(customerId, normalizedReq))
                }

                post("/cards/{id}/lock-requests") {
                    val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                    val cardId = call.parameters["id"] ?: throw BackendException(400, "MISSING_ID", "Card id required.")
                    val req = call.receive<CardLockRequestDto>()
                    call.respond(service.requestCardLock(customerId, cardId, req))
                }
            }

            get("/transfers/{id}") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                val trfId = call.parameters["id"] ?: throw BackendException(400, "MISSING_ID", "Transfer id required.")
                call.respond(service.getTransfer(customerId, trfId))
            }

            get("/cards") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                call.respond(service.listCards(customerId))
            }

            get("/insights/spending") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                call.respond(service.getSpendingInsights(customerId))
            }

            get("/statements") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                call.respond(service.generateOrListStatements(customerId))
            }

            get("/notifications") {
                val customerId = call.principal<JWTPrincipal>()!!.payload.subject
                call.respond(service.listNotifications(customerId))
            }
        }
    }
}

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    val jdbcUrl = System.getenv("JDBC_URL") ?: "jdbc:postgresql://localhost:5432/crestline"
    val user = System.getenv("DB_USER") ?: "crestline_app"
    val password = System.getenv("DB_PASSWORD") ?: "crestline_dev_only"
    val dataSource = createDataSource(jdbcUrl, user, password)

    embeddedServer(Netty, port = port) {
        bankingModule(dataSource)
    }.start(wait = true)
}
