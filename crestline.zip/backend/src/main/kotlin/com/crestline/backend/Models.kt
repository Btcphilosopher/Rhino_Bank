package com.crestline.backend

import kotlinx.serialization.Serializable

@Serializable
data class ApiErrorDto(
    val code: String,
    val message: String,
    val requestId: String
)

@Serializable
data class LoginRequestDto(
    val email: String,
    val password: String,
    val deviceName: String,
    val mfaCode: String? = null
)

@Serializable
data class RefreshRequestDto(
    val sessionId: String,
    val refreshToken: String
)

@Serializable
data class AuthResponseDto(
    val customerId: String,
    val sessionId: String,
    val accessToken: String,
    val refreshToken: String,
    val accessExpiresAtEpochMs: Long
)

@Serializable
data class AccountDto(
    val accountId: String,
    val customerId: String,
    val name: String,
    val accountType: String,
    val maskedNumber: String,
    val currency: String,
    val postedBalanceCents: Long,
    val pendingHoldCents: Long,
    val availableBalanceCents: Long,
    val creditLimitCents: Long,
    val statementBalanceCents: Long,
    val minimumPaymentCents: Long,
    val paymentDueDateLabel: String?,
    val version: Long
)

@Serializable
data class TransactionDto(
    val transactionId: String,
    val journalId: String,
    val accountId: String,
    val description: String,
    val amountCents: Long,
    val currency: String,
    val direction: String,
    val status: String,
    val category: String,
    val timestampLabel: String,
    val reference: String
)

@Serializable
data class TransferPreviewRequestDto(
    val sourceAccountId: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val currency: String = "USD",
    val timing: String = "TODAY"
)

@Serializable
data class TransferExecuteRequestDto(
    val transferId: String,
    val sourceAccountId: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val currency: String = "USD",
    val timing: String = "TODAY",
    val idempotencyKey: String,
    val termsHash: String
)

@Serializable
data class TransferDto(
    val transferId: String,
    val customerId: String,
    val sourceAccountId: String,
    val destinationAccountId: String,
    val amountCents: Long,
    val feeCents: Long,
    val currency: String,
    val timing: String,
    val status: String,
    val idempotencyKey: String,
    val termsHash: String,
    val confirmationReference: String?,
    val journalId: String?
)

@Serializable
data class CardDto(
    val cardId: String,
    val customerId: String,
    val linkedAccountId: String,
    val cardType: String,
    val holderName: String,
    val maskedLast4: String,
    val desiredState: String,
    val issuerStatus: String,
    val dailyPurchaseLimitCents: Long,
    val dailyAtmLimitCents: Long,
    val lastSyncedLabel: String
)

@Serializable
data class CardLockRequestDto(
    val lock: Boolean,
    val reason: String = "Customer request"
)

@Serializable
data class CategoryBreakdownDto(
    val category: String,
    val totalCents: Long
)

@Serializable
data class SpendingInsightsDto(
    val monthLabel: String,
    val totalCents: Long,
    val categories: List<CategoryBreakdownDto>
)

@Serializable
data class StatementDto(
    val statementId: String,
    val accountId: String,
    val periodLabel: String,
    val openingBalanceCents: Long,
    val totalCreditsCents: Long,
    val totalDebitsCents: Long,
    val closingBalanceCents: Long
)

@Serializable
data class NotificationDto(
    val notificationId: String,
    val title: String,
    val body: String,
    val lockScreenSafeBody: String,
    val category: String,
    val deliveryStatus: String,
    val isRead: Boolean
)
