package com.crestline.backend

import java.sql.Connection
import java.util.UUID
import javax.sql.DataSource

class BackendException(
    val httpStatus: Int,
    val code: String,
    override val message: String
) : RuntimeException(message)

class LedgerService(
    private val dataSource: DataSource,
    private val jwtSecret: String
) {
    companion object {
        const val DEMO_PASSWORD = "DemoPassword!2026"
        const val MAX_TRANSFER_CENTS = 2_500_000L
        const val ACCESS_TTL_MS = 15 * 60 * 1000L
    }

    fun bootstrapSeedPasswords() {
        dataSource.connection.use { conn ->
            conn.autoCommit = false
            try {
                conn.prepareStatement("SELECT customer_id, password_hash_hex, password_salt_hex FROM customers").use { ps ->
                    val rs = ps.executeQuery()
                    val toUpdate = mutableListOf<Triple<String, String, String>>()
                    while (rs.next()) {
                        val cid = rs.getString("customer_id")
                        val hash = rs.getString("password_hash_hex")
                        val salt = rs.getString("password_salt_hex")
                        if (hash == "BOOTSTRAP_HASH") {
                            val pwd = if (cid == "cust_alex_morgan") DEMO_PASSWORD else "OtherUser!2026"
                            val (newHash, newSalt) = BackendSecurity.hashPassword(pwd, salt)
                            toUpdate.add(Triple(cid, newHash, newSalt))
                        }
                    }
                    for ((cid, newHash, _) in toUpdate) {
                        conn.prepareStatement("UPDATE customers SET password_hash_hex = ? WHERE customer_id = ?").use { up ->
                            up.setString(1, newHash)
                            up.setString(2, cid)
                            up.executeUpdate()
                        }
                    }
                }
                conn.commit()
            } catch (e: Exception) {
                conn.rollback()
                throw e
            }
        }
    }

    fun login(req: LoginRequestDto): AuthResponseDto {
        dataSource.connection.use { conn ->
            conn.prepareStatement(
                "SELECT customer_id, password_hash_hex, password_salt_hex, mfa_enabled FROM customers WHERE LOWER(email) = LOWER(?)"
            ).use { ps ->
                ps.setString(1, req.email.trim())
                val rs = ps.executeQuery()
                if (!rs.next()) throw BackendException(401, "AUTH_INVALID", "Invalid credentials.")
                val customerId = rs.getString("customer_id")
                val hash = rs.getString("password_hash_hex")
                val salt = rs.getString("password_salt_hex")
                val mfa = rs.getBoolean("mfa_enabled")
                if (!BackendSecurity.verifyPassword(req.password, hash, salt)) {
                    throw BackendException(401, "AUTH_INVALID", "Invalid credentials.")
                }
                if (mfa && req.mfaCode != "482910") {
                    throw BackendException(403, "MFA_REQUIRED", "Multifactor code required.")
                }

                val sessionId = "sess_${UUID.randomUUID().toString().take(10)}"
                val refreshToken = "rtk_${UUID.randomUUID().toString().replace("-", "")}"
                val (accessToken, expiresAt) = BackendSecurity.createJwt(customerId, sessionId, jwtSecret, ACCESS_TTL_MS)

                conn.prepareStatement(
                    "INSERT INTO device_sessions (session_id, customer_id, device_name, refresh_token_hash, refresh_generation, access_expires_at_ms, revoked) VALUES (?, ?, ?, ?, 1, ?, FALSE)"
                ).use { ins ->
                    ins.setString(1, sessionId)
                    ins.setString(2, customerId)
                    ins.setString(3, req.deviceName)
                    ins.setString(4, BackendSecurity.sha256(refreshToken))
                    ins.setLong(5, expiresAt)
                    ins.executeUpdate()
                }
                return AuthResponseDto(customerId, sessionId, accessToken, refreshToken, expiresAt)
            }
        }
    }

    fun refresh(req: RefreshRequestDto): AuthResponseDto {
        dataSource.connection.use { conn ->
            conn.autoCommit = false
            try {
                conn.prepareStatement(
                    "SELECT customer_id, refresh_token_hash, refresh_generation, revoked FROM device_sessions WHERE session_id = ?"
                ).use { ps ->
                    ps.setString(1, req.sessionId)
                    val rs = ps.executeQuery()
                    if (!rs.next()) throw BackendException(401, "SESSION_NOT_FOUND", "Session does not exist.")
                    val customerId = rs.getString("customer_id")
                    val expectedHash = rs.getString("refresh_token_hash")
                    val gen = rs.getInt("refresh_generation")
                    val revoked = rs.getBoolean("revoked")
                    if (revoked) throw BackendException(401, "SESSION_REVOKED", "Session revoked.")

                    if (expectedHash != BackendSecurity.sha256(req.refreshToken)) {
                        conn.prepareStatement("UPDATE device_sessions SET revoked = TRUE WHERE session_id = ?").use { rev ->
                            rev.setString(1, req.sessionId)
                            rev.executeUpdate()
                        }
                        conn.commit()
                        throw BackendException(401, "REFRESH_REUSE_DETECTED", "Refresh token reuse detected; session revoked.")
                    }

                    val newRefresh = "rtk_${UUID.randomUUID().toString().replace("-", "")}"
                    val (newAccess, expiresAt) = BackendSecurity.createJwt(customerId, req.sessionId, jwtSecret, ACCESS_TTL_MS)
                    conn.prepareStatement(
                        "UPDATE device_sessions SET refresh_token_hash = ?, refresh_generation = ?, access_expires_at_ms = ? WHERE session_id = ?"
                    ).use { up ->
                        up.setString(1, BackendSecurity.sha256(newRefresh))
                        up.setInt(2, gen + 1)
                        up.setLong(3, expiresAt)
                        up.setString(4, req.sessionId)
                        up.executeUpdate()
                    }
                    conn.commit()
                    return AuthResponseDto(customerId, req.sessionId, newAccess, newRefresh, expiresAt)
                }
            } catch (e: Exception) {
                conn.rollback()
                throw e
            }
        }
    }

    fun logout(sessionId: String, customerId: String) {
        dataSource.connection.use { conn ->
            conn.prepareStatement("UPDATE device_sessions SET revoked = TRUE WHERE session_id = ? AND customer_id = ?").use { ps ->
                ps.setString(1, sessionId)
                ps.setString(2, customerId)
                ps.executeUpdate()
            }
        }
    }

    fun isSessionActive(sessionId: String): Boolean {
        dataSource.connection.use { conn ->
            conn.prepareStatement("SELECT revoked FROM device_sessions WHERE session_id = ?").use { ps ->
                ps.setString(1, sessionId)
                val rs = ps.executeQuery()
                return rs.next() && !rs.getBoolean("revoked")
            }
        }
    }

    fun listAccounts(customerId: String): List<AccountDto> {
        dataSource.connection.use { conn ->
            val result = mutableListOf<AccountDto>()
            conn.prepareStatement("SELECT * FROM accounts WHERE customer_id = ?").use { ps ->
                ps.setString(1, customerId)
                val rs = ps.executeQuery()
                while (rs.next()) {
                    result.add(computeAccountDto(conn, rs.getString("account_id"), customerId))
                }
            }
            return result
        }
    }

    fun listTransactions(customerId: String, accountId: String, limit: Int, offset: Int): List<TransactionDto> {
        dataSource.connection.use { conn ->
            verifyOwnership(conn, customerId, accountId)
            val list = mutableListOf<TransactionDto>()
            conn.prepareStatement(
                "SELECT * FROM pending_holds WHERE account_id = ? AND active = TRUE ORDER BY created_at_ms DESC"
            ).use { ps ->
                ps.setString(1, accountId)
                val rs = ps.executeQuery()
                while (rs.next()) {
                    list.add(
                        TransactionDto(
                            transactionId = rs.getString("hold_id"),
                            journalId = rs.getString("hold_id"),
                            accountId = accountId,
                            description = rs.getString("description"),
                            amountCents = rs.getLong("amount_cents"),
                            currency = rs.getString("currency"),
                            direction = "DEBIT",
                            status = "PENDING",
                            category = "EXCLUDED",
                            timestampLabel = rs.getString("created_at_label"),
                            reference = rs.getString("reference")
                        )
                    )
                }
            }
            conn.prepareStatement(
                "SELECT * FROM ledger_lines WHERE account_id = ? ORDER BY timestamp_ms DESC LIMIT ? OFFSET ?"
            ).use { ps ->
                ps.setString(1, accountId)
                ps.setInt(2, limit.coerceIn(1, 200))
                ps.setInt(3, offset.coerceAtLeast(0))
                val rs = ps.executeQuery()
                while (rs.next()) {
                    list.add(
                        TransactionDto(
                            transactionId = rs.getString("line_id"),
                            journalId = rs.getString("journal_id"),
                            accountId = accountId,
                            description = rs.getString("description"),
                            amountCents = rs.getLong("amount_cents"),
                            currency = rs.getString("currency"),
                            direction = rs.getString("direction"),
                            status = rs.getString("status"),
                            category = rs.getString("category"),
                            timestampLabel = rs.getString("timestamp_label"),
                            reference = rs.getString("reference")
                        )
                    )
                }
            }
            return list
        }
    }

    fun previewTransfer(customerId: String, req: TransferPreviewRequestDto): TransferDto {
        if (req.sourceAccountId == req.destinationAccountId) {
            throw BackendException(400, "SAME_ACCOUNT", "Source and destination must differ.")
        }
        if (req.amountCents <= 0L) {
            throw BackendException(400, "INVALID_AMOUNT", "Amount must be positive.")
        }
        if (req.amountCents > MAX_TRANSFER_CENTS) {
            throw BackendException(422, "LIMIT_EXCEEDED", "Exceeds single transfer limit.")
        }
        dataSource.connection.use { conn ->
            val src = verifyOwnership(conn, customerId, req.sourceAccountId)
            val dst = verifyOwnership(conn, customerId, req.destinationAccountId)
            if (src.currency != dst.currency || src.currency != req.currency) {
                throw BackendException(422, "CURRENCY_MISMATCH", "Currency mismatch.")
            }
            if (src.availableBalanceCents < req.amountCents) {
                throw BackendException(422, "INSUFFICIENT_FUNDS", "Insufficient available funds.")
            }
            val transferId = "trf_${UUID.randomUUID().toString().take(10)}"
            val idemKey = "idem_${UUID.randomUUID()}"
            val termsHash = BackendSecurity.sha256("${req.sourceAccountId}|${req.destinationAccountId}|${req.amountCents}|${req.currency}|${req.timing}")
            conn.prepareStatement(
                "INSERT INTO transfers (transfer_id, customer_id, source_account_id, destination_account_id, amount_cents, fee_cents, currency, timing, status, idempotency_key, terms_hash, confirmation_reference, journal_id, created_at_ms) VALUES (?, ?, ?, ?, ?, 0, ?, ?, 'REVIEWED', ?, ?, NULL, NULL, ?)"
            ).use { ins ->
                ins.setString(1, transferId)
                ins.setString(2, customerId)
                ins.setString(3, req.sourceAccountId)
                ins.setString(4, req.destinationAccountId)
                ins.setLong(5, req.amountCents)
                ins.setString(6, req.currency)
                ins.setString(7, req.timing)
                ins.setString(8, idemKey)
                ins.setString(9, termsHash)
                ins.setLong(10, System.currentTimeMillis())
                ins.executeUpdate()
            }
            return TransferDto(
                transferId, customerId, req.sourceAccountId, req.destinationAccountId,
                req.amountCents, 0L, req.currency, req.timing, "REVIEWED",
                idemKey, termsHash, null, null
            )
        }
    }

    fun executeTransfer(customerId: String, req: TransferExecuteRequestDto): TransferDto {
        dataSource.connection.use { conn ->
            conn.autoCommit = false
            try {
                // 1. Idempotency check FIRST
                conn.prepareStatement("SELECT * FROM transfers WHERE idempotency_key = ?").use { ps ->
                    ps.setString(1, req.idempotencyKey)
                    val rs = ps.executeQuery()
                    if (rs.next()) {
                        if (rs.getString("customer_id") != customerId) {
                            throw BackendException(403, "FORBIDDEN", "Access denied.")
                        }
                        if (rs.getString("status") == "COMPLETED") {
                            val existing = mapTransferRow(rs)
                            conn.commit()
                            return existing
                        }
                    }
                }

                // 2. Material terms verification
                val expectedHash = BackendSecurity.sha256("${req.sourceAccountId}|${req.destinationAccountId}|${req.amountCents}|${req.currency}|${req.timing}")
                if (expectedHash != req.termsHash) {
                    throw BackendException(409, "TERMS_CHANGED_REVIEW_REQUIRED", "Material terms changed; renewed review required.")
                }

                // 3. Ownership & Row Lock (SELECT ... FOR UPDATE prevents concurrent double-spend)
                val firstId = minOf(req.sourceAccountId, req.destinationAccountId)
                val secondId = maxOf(req.sourceAccountId, req.destinationAccountId)
                conn.prepareStatement("SELECT account_id FROM accounts WHERE account_id IN (?, ?) ORDER BY account_id FOR UPDATE").use { lock ->
                    lock.setString(1, firstId)
                    lock.setString(2, secondId)
                    lock.executeQuery().close()
                }

                val src = verifyOwnership(conn, customerId, req.sourceAccountId)
                val dst = verifyOwnership(conn, customerId, req.destinationAccountId)
                if (src.accountId == dst.accountId) {
                    throw BackendException(400, "SAME_ACCOUNT", "Source and destination must differ.")
                }
                if (src.availableBalanceCents < req.amountCents) {
                    throw BackendException(422, "INSUFFICIENT_FUNDS", "Insufficient available funds.")
                }

                val tsMs = System.currentTimeMillis()
                val confRef = "TRF-${UUID.randomUUID().toString().take(8).uppercase()}"
                val journalId = "jrn_${UUID.randomUUID().toString().take(10)}"

                conn.prepareStatement(
                    "INSERT INTO journals (journal_id, customer_id, business_reference, description, created_at_ms) VALUES (?, ?, ?, ?, ?)"
                ).use { ins ->
                    ins.setString(1, journalId)
                    ins.setString(2, customerId)
                    ins.setString(3, confRef)
                    ins.setString(4, "Transfer ${src.name} to ${dst.name}")
                    ins.setLong(5, tsMs)
                    ins.executeUpdate()
                }

                val insertLineSql = "INSERT INTO ledger_lines (line_id, journal_id, account_id, description, amount_cents, currency, direction, status, category, timestamp_ms, timestamp_label, reference) VALUES (?, ?, ?, ?, ?, ?, ?, 'POSTED', 'EXCLUDED', ?, 'Just now', ?)"
                conn.prepareStatement(insertLineSql).use { ins ->
                    ins.setString(1, "${journalId}_src")
                    ins.setString(2, journalId)
                    ins.setString(3, src.accountId)
                    ins.setString(4, "Transfer to ${dst.name}")
                    ins.setLong(5, req.amountCents)
                    ins.setString(6, req.currency)
                    ins.setString(7, "DEBIT")
                    ins.setLong(8, tsMs)
                    ins.setString(9, confRef)
                    ins.executeUpdate()
                }
                conn.prepareStatement(insertLineSql).use { ins ->
                    ins.setString(1, "${journalId}_dst")
                    ins.setString(2, journalId)
                    ins.setString(3, dst.accountId)
                    ins.setString(4, "Transfer from ${src.name}")
                    ins.setLong(5, req.amountCents)
                    ins.setString(6, req.currency)
                    ins.setString(7, "CREDIT")
                    ins.setLong(8, tsMs)
                    ins.setString(9, confRef)
                    ins.executeUpdate()
                }

                // Optimistic version bump
                conn.prepareStatement("UPDATE accounts SET version = version + 1 WHERE account_id = ? AND version = ?").use { up ->
                    up.setString(1, src.accountId)
                    up.setLong(2, src.version)
                    if (up.executeUpdate() != 1) throw BackendException(409, "CONCURRENT_MODIFICATION", "Retry transfer.")
                }

                val transferExists = conn.prepareStatement("SELECT 1 FROM transfers WHERE idempotency_key = ?").use { ps ->
                    ps.setString(1, req.idempotencyKey)
                    ps.executeQuery().next()
                }
                if (transferExists) {
                    conn.prepareStatement(
                        "UPDATE transfers SET status = 'COMPLETED', confirmation_reference = ?, journal_id = ? WHERE idempotency_key = ?"
                    ).use { up ->
                        up.setString(1, confRef)
                        up.setString(2, journalId)
                        up.setString(3, req.idempotencyKey)
                        up.executeUpdate()
                    }
                } else {
                    conn.prepareStatement(
                        "INSERT INTO transfers (transfer_id, customer_id, source_account_id, destination_account_id, amount_cents, fee_cents, currency, timing, status, idempotency_key, terms_hash, confirmation_reference, journal_id, created_at_ms) VALUES (?, ?, ?, ?, ?, 0, ?, ?, 'COMPLETED', ?, ?, ?, ?, ?)"
                    ).use { ins ->
                        ins.setString(1, req.transferId)
                        ins.setString(2, customerId)
                        ins.setString(3, req.sourceAccountId)
                        ins.setString(4, req.destinationAccountId)
                        ins.setLong(5, req.amountCents)
                        ins.setString(6, req.currency)
                        ins.setString(7, req.timing)
                        ins.setString(8, req.idempotencyKey)
                        ins.setString(9, req.termsHash)
                        ins.setString(10, confRef)
                        ins.setString(11, journalId)
                        ins.setLong(12, tsMs)
                        ins.executeUpdate()
                    }
                }

                // Assert global double-entry invariant before commit
                conn.prepareStatement("SELECT COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount_cents ELSE -amount_cents END), 0) AS net FROM ledger_lines").use { chk ->
                    val rs = chk.executeQuery()
                    rs.next()
                    check(rs.getLong("net") == 0L) { "Double-entry ledger imbalance detected!" }
                }

                conn.commit()
                return TransferDto(
                    req.transferId, customerId, req.sourceAccountId, req.destinationAccountId,
                    req.amountCents, 0L, req.currency, req.timing, "COMPLETED",
                    req.idempotencyKey, req.termsHash, confRef, journalId
                )
            } catch (e: Exception) {
                conn.rollback()
                throw e
            }
        }
    }

    fun getTransfer(customerId: String, transferId: String): TransferDto {
        dataSource.connection.use { conn ->
            conn.prepareStatement("SELECT * FROM transfers WHERE transfer_id = ?").use { ps ->
                ps.setString(1, transferId)
                val rs = ps.executeQuery()
                if (!rs.next()) throw BackendException(404, "NOT_FOUND", "Transfer not found.")
                if (rs.getString("customer_id") != customerId) throw BackendException(403, "FORBIDDEN", "Access denied.")
                return mapTransferRow(rs)
            }
        }
    }

    fun listCards(customerId: String): List<CardDto> {
        dataSource.connection.use { conn ->
            val list = mutableListOf<CardDto>()
            conn.prepareStatement("SELECT * FROM cards WHERE customer_id = ?").use { ps ->
                ps.setString(1, customerId)
                val rs = ps.executeQuery()
                while (rs.next()) list.add(mapCardRow(rs))
            }
            return list
        }
    }

    fun requestCardLock(customerId: String, cardId: String, req: CardLockRequestDto): CardDto {
        dataSource.connection.use { conn ->
            conn.prepareStatement("SELECT * FROM cards WHERE card_id = ?").use { ps ->
                ps.setString(1, cardId)
                val rs = ps.executeQuery()
                if (!rs.next()) throw BackendException(404, "CARD_NOT_FOUND", "Card not found.")
                if (rs.getString("customer_id") != customerId) throw BackendException(403, "FORBIDDEN", "Access denied.")
            }
            val desired = if (req.lock) "LOCK_REQUESTED" else "ACTIVE"
            val issuer = if (req.lock) "CONFIRMED_LOCKED" else "CONFIRMED_ACTIVE"
            conn.prepareStatement(
                "UPDATE cards SET desired_state = ?, issuer_status = ?, last_synced_label = 'Mock issuer confirmed' WHERE card_id = ?"
            ).use { up ->
                up.setString(1, desired)
                up.setString(2, issuer)
                up.setString(3, cardId)
                up.executeUpdate()
            }
            conn.prepareStatement("SELECT * FROM cards WHERE card_id = ?").use { ps ->
                ps.setString(1, cardId)
                val rs = ps.executeQuery()
                rs.next()
                return mapCardRow(rs)
            }
        }
    }

    fun getSpendingInsights(customerId: String): SpendingInsightsDto {
        dataSource.connection.use { conn ->
            val sql = """
                SELECT l.category,
                       COALESCE(SUM(CASE WHEN l.direction = 'DEBIT' THEN l.amount_cents ELSE -l.amount_cents END), 0) AS total_cents
                FROM ledger_lines l
                JOIN accounts a ON l.account_id = a.account_id
                WHERE a.customer_id = ?
                  AND a.account_type IN ('CHECKING', 'CREDIT_CARD')
                  AND l.category <> 'EXCLUDED'
                GROUP BY l.category
            """.trimIndent()
            val breakdown = mutableListOf<CategoryBreakdownDto>()
            conn.prepareStatement(sql).use { ps ->
                ps.setString(1, customerId)
                val rs = ps.executeQuery()
                while (rs.next()) {
                    breakdown.add(CategoryBreakdownDto(rs.getString("category"), rs.getLong("total_cents").coerceAtLeast(0L)))
                }
            }
            return SpendingInsightsDto("November 2026", breakdown.sumOf { it.totalCents }, breakdown)
        }
    }

    fun generateOrListStatements(customerId: String): List<StatementDto> {
        dataSource.connection.use { conn ->
            val accounts = listAccounts(customerId)
            val statements = mutableListOf<StatementDto>()
            for (acc in accounts) {
                var opening = 0L
                var credits = 0L
                var debits = 0L
                conn.prepareStatement("SELECT amount_cents, direction, reference FROM ledger_lines WHERE account_id = ?").use { ps ->
                    ps.setString(1, acc.accountId)
                    val rs = ps.executeQuery()
                    while (rs.next()) {
                        val amt = rs.getLong("amount_cents")
                        val dir = rs.getString("direction")
                        val ref = rs.getString("reference")
                        if (ref.startsWith("OPEN-")) {
                            opening = amt
                        } else if (dir == "CREDIT") {
                            credits += amt
                        } else {
                            debits += amt
                        }
                    }
                }
                val closing = if (acc.accountType == "CREDIT_CARD") opening + debits - credits else opening + credits - debits
                statements.add(
                    StatementDto(
                        statementId = "stmt_${acc.accountId}_202611",
                        accountId = acc.accountId,
                        periodLabel = "November 2026",
                        openingBalanceCents = opening,
                        totalCreditsCents = credits,
                        totalDebitsCents = debits,
                        closingBalanceCents = closing
                    )
                )
            }
            return statements
        }
    }

    fun listNotifications(customerId: String): List<NotificationDto> {
        dataSource.connection.use { conn ->
            val list = mutableListOf<NotificationDto>()
            conn.prepareStatement("SELECT * FROM notifications WHERE customer_id = ? ORDER BY created_at_ms DESC").use { ps ->
                ps.setString(1, customerId)
                val rs = ps.executeQuery()
                while (rs.next()) {
                    list.add(
                        NotificationDto(
                            rs.getString("notification_id"),
                            rs.getString("title"),
                            rs.getString("body"),
                            rs.getString("lock_screen_safe_body"),
                            rs.getString("category"),
                            rs.getString("delivery_status"),
                            rs.getBoolean("is_read")
                        )
                    )
                }
            }
            return list
        }
    }

    fun runScheduledWorkerTick(): Int {
        dataSource.connection.use { conn ->
            conn.autoCommit = false
            var processed = 0
            try {
                val dueList = mutableListOf<Triple<String, String, Long>>()
                conn.prepareStatement("SELECT payment_id, customer_id, amount_cents FROM scheduled_payments WHERE status = 'SCHEDULED' AND due_at_ms <= ?").use { ps ->
                    ps.setLong(1, System.currentTimeMillis())
                    val rs = ps.executeQuery()
                    while (rs.next()) {
                        dueList.add(Triple(rs.getString("payment_id"), rs.getString("customer_id"), rs.getLong("amount_cents")))
                    }
                }
                for ((pid, cid, amt) in dueList) {
                    conn.prepareStatement("SELECT source_account_id, payee_name, reference FROM scheduled_payments WHERE payment_id = ?").use { ps ->
                        ps.setString(1, pid)
                        val rs = ps.executeQuery()
                        if (rs.next()) {
                            val srcId = rs.getString("source_account_id")
                            val payee = rs.getString("payee_name")
                            val ref = rs.getString("reference")
                            val src = computeAccountDto(conn, srcId, cid)
                            if (src.availableBalanceCents >= amt) {
                                val jid = "jrn_wrk_$pid"
                                val now = System.currentTimeMillis()
                                conn.prepareStatement("INSERT INTO journals (journal_id, customer_id, business_reference, description, created_at_ms) VALUES (?, ?, ?, ?, ?)").use { ins ->
                                    ins.setString(1, jid)
                                    ins.setString(2, cid)
                                    ins.setString(3, ref)
                                    ins.setString(4, "Scheduled Payment: $payee")
                                    ins.setLong(5, now)
                                    ins.executeUpdate()
                                }
                                val lineSql = "INSERT INTO ledger_lines (line_id, journal_id, account_id, description, amount_cents, currency, direction, status, category, timestamp_ms, timestamp_label, reference) VALUES (?, ?, ?, ?, ?, 'USD', ?, 'POSTED', 'OTHER', ?, 'Worker', ?)"
                                conn.prepareStatement(lineSql).use { ins ->
                                    ins.setString(1, "${jid}_1"); ins.setString(2, jid); ins.setString(3, srcId); ins.setString(4, payee); ins.setLong(5, amt); ins.setString(6, "DEBIT"); ins.setLong(7, now); ins.setString(8, ref); ins.executeUpdate()
                                }
                                conn.prepareStatement(lineSql).use { ins ->
                                    ins.setString(1, "${jid}_2"); ins.setString(2, jid); ins.setString(3, "sys_merchant_clearing_usd"); ins.setString(4, payee); ins.setLong(5, amt); ins.setString(6, "CREDIT"); ins.setLong(7, now); ins.setString(8, ref); ins.executeUpdate()
                                }
                                conn.prepareStatement("UPDATE scheduled_payments SET status = 'SETTLED' WHERE payment_id = ?").use { up ->
                                    up.setString(1, pid); up.executeUpdate()
                                }
                                processed++
                            }
                        }
                    }
                }
                conn.commit()
                return processed
            } catch (e: Exception) {
                conn.rollback()
                throw e
            }
        }
    }

    fun verifyGlobalLedgerZeroSum(): Long {
        dataSource.connection.use { conn ->
            conn.prepareStatement("SELECT COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount_cents ELSE -amount_cents END), 0) FROM ledger_lines").use { ps ->
                val rs = ps.executeQuery()
                rs.next()
                return rs.getLong(1)
            }
        }
    }

    private fun verifyOwnership(conn: Connection, customerId: String, accountId: String): AccountDto {
        conn.prepareStatement("SELECT customer_id FROM accounts WHERE account_id = ?").use { ps ->
            ps.setString(1, accountId)
            val rs = ps.executeQuery()
            if (!rs.next()) throw BackendException(404, "ACCOUNT_NOT_FOUND", "Account not found.")
            if (rs.getString("customer_id") != customerId) {
                throw BackendException(403, "FORBIDDEN", "Cross-customer access denied.")
            }
        }
        return computeAccountDto(conn, accountId, customerId)
    }

    private fun computeAccountDto(conn: Connection, accountId: String, customerId: String): AccountDto {
        conn.prepareStatement("SELECT * FROM accounts WHERE account_id = ? AND customer_id = ?").use { ps ->
            ps.setString(1, accountId)
            ps.setString(2, customerId)
            val rs = ps.executeQuery()
            if (!rs.next()) throw BackendException(404, "ACCOUNT_NOT_FOUND", "Account not found.")
            val type = rs.getString("account_type")
            val creditLimit = rs.getLong("credit_limit_cents")
            var credits = 0L
            var debits = 0L
            conn.prepareStatement("SELECT direction, COALESCE(SUM(amount_cents), 0) AS total FROM ledger_lines WHERE account_id = ? GROUP BY direction").use { lps ->
                lps.setString(1, accountId)
                val lrs = lps.executeQuery()
                while (lrs.next()) {
                    if (lrs.getString("direction") == "CREDIT") credits = lrs.getLong("total")
                    else debits = lrs.getLong("total")
                }
            }
            var holds = 0L
            conn.prepareStatement("SELECT COALESCE(SUM(amount_cents), 0) FROM pending_holds WHERE account_id = ? AND active = TRUE").use { hps ->
                hps.setString(1, accountId)
                val hrs = hps.executeQuery()
                if (hrs.next()) holds = hrs.getLong(1)
            }
            val posted = if (type == "CREDIT_CARD") (debits - credits).coerceAtLeast(0L) else (credits - debits)
            val available = if (type == "CREDIT_CARD") (creditLimit - posted - holds).coerceAtLeast(0L) else (posted - holds)
            return AccountDto(
                accountId = accountId,
                customerId = customerId,
                name = rs.getString("name"),
                accountType = type,
                maskedNumber = rs.getString("masked_number"),
                currency = rs.getString("currency"),
                postedBalanceCents = posted,
                pendingHoldCents = holds,
                availableBalanceCents = available,
                creditLimitCents = creditLimit,
                statementBalanceCents = rs.getLong("statement_balance_cents"),
                minimumPaymentCents = rs.getLong("minimum_payment_cents"),
                paymentDueDateLabel = rs.getString("payment_due_date_label"),
                version = rs.getLong("version")
            )
        }
    }

    private fun mapTransferRow(rs: java.sql.ResultSet) = TransferDto(
        transferId = rs.getString("transfer_id"),
        customerId = rs.getString("customer_id"),
        sourceAccountId = rs.getString("source_account_id"),
        destinationAccountId = rs.getString("destination_account_id"),
        amountCents = rs.getLong("amount_cents"),
        feeCents = rs.getLong("fee_cents"),
        currency = rs.getString("currency"),
        timing = rs.getString("timing"),
        status = rs.getString("status"),
        idempotencyKey = rs.getString("idempotency_key"),
        termsHash = rs.getString("terms_hash"),
        confirmationReference = rs.getString("confirmation_reference"),
        journalId = rs.getString("journal_id")
    )

    private fun mapCardRow(rs: java.sql.ResultSet) = CardDto(
        cardId = rs.getString("card_id"),
        customerId = rs.getString("customer_id"),
        linkedAccountId = rs.getString("linked_account_id"),
        cardType = rs.getString("card_type"),
        holderName = rs.getString("holder_name"),
        maskedLast4 = rs.getString("masked_last4"),
        desiredState = rs.getString("desired_state"),
        issuerStatus = rs.getString("issuer_status"),
        dailyPurchaseLimitCents = rs.getLong("daily_purchase_limit_cents"),
        dailyAtmLimitCents = rs.getLong("daily_atm_limit_cents"),
        lastSyncedLabel = rs.getString("last_synced_label")
    )
}
