import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Health Check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      platform: 'Yorkshire Marketplace',
      region: 'Yorkshire and the Humber',
      timestamp: new Date().toISOString()
    });
  });

  // AI Concierge API
  app.post('/api/ai-concierge', async (req, res) => {
    try {
      const { prompt, context } = req.body;

      if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }

      const apiKey = process.env.GEMINI_API_KEY;

      if (apiKey) {
        const ai = new GoogleGenAI({ apiKey });
        const systemInstruction = `You are "Tyke", the expert AI Concierge for Yorkshire Marketplace (Made in Yorkshire).
You celebrate Yorkshire heritage, craftsmanship, local businesses, independent artisans, farms, steel manufacturers, and Yorkshire gifts across Leeds, Sheffield, York, Bradford, Hull, Whitby, Dales, and Humber.
Be warmly helpful, enthusiastic about local Yorkshire goods, concise, and polite. Always recommend authentic Yorkshire products or businesses.`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: [
            { role: 'user', parts: [{ text: `${systemInstruction}\n\nContext: ${JSON.stringify(context || {})}\nUser Query: ${prompt}` }] }
          ]
        });

        const reply = response.text || "I'd be glad to help you discover authentic Yorkshire products and local businesses across the county!";
        return res.json({ reply });
      } else {
        // Smart fallback response if API key is not configured
        const fallbackReply = `Welcome to Yorkshire Marketplace! I'm Tyke, your local guide. Whether you're looking for forged Sheffield cutlery, artisan Wensleydale cheese, handcrafted Whitby jet jewellery, or heavy industrial machinery from Leeds, our directory showcases the finest regional producers across all 21 Yorkshire towns and regions.`;
        return res.json({ reply: fallbackReply });
      }
    } catch (err: any) {
      console.error('Error in /api/ai-concierge:', err);
      return res.status(500).json({
        reply: "Apologies, I encountered an issue connecting to the Yorkshire Concierge service. Please feel free to browse our product directory or regional map directly!"
      });
    }
  });

  // B2B Quote Submission Endpoint
  app.post('/api/b2b-quote', (req, res) => {
    const { companyName, contactEmail, productOrService, quantity, details, town } = req.body;
    if (!contactEmail || !details) {
      return res.status(400).json({ error: 'Contact email and details are required.' });
    }
    
    // Simulate quote generation
    const quoteReference = `YM-B2B-${Math.floor(100000 + Math.random() * 900000)}`;
    res.json({
      success: true,
      quoteReference,
      message: `Your B2B quote request (${quoteReference}) has been routed to regional Yorkshire suppliers in ${town || 'Yorkshire'}.`,
      estimatedResponseTime: '24 hours'
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Yorkshire Marketplace server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
