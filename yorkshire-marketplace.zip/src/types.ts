export type YorkshireRegion =
  | 'Leeds'
  | 'Sheffield'
  | 'Bradford'
  | 'York'
  | 'Hull'
  | 'Wakefield'
  | 'Doncaster'
  | 'Barnsley'
  | 'Rotherham'
  | 'Huddersfield'
  | 'Halifax'
  | 'Harrogate'
  | 'Scarborough'
  | 'Whitby'
  | 'Beverley'
  | 'Ripon'
  | 'Skipton'
  | 'Ilkley'
  | 'The Yorkshire Dales'
  | 'The North York Moors'
  | 'The East Riding';

export type ProductCategory =
  | 'Food & Drink'
  | 'Engineering'
  | 'Industrial Supplies'
  | 'Manufacturing'
  | 'Agriculture'
  | 'Garden & Outdoor'
  | 'Home & Living'
  | 'Furniture'
  | 'Fashion'
  | 'Health & Beauty'
  | 'Electronics'
  | 'Books'
  | 'Art & Crafts'
  | 'Jewellery'
  | 'Sports'
  | 'Pets'
  | 'Automotive'
  | 'Building Materials'
  | 'Renewable Energy'
  | 'Yorkshire Gifts';

export type BusinessType =
  | 'Artisan & Craft'
  | 'Manufacturer'
  | 'Farm & Produce'
  | 'Independent Retailer'
  | 'Engineering & Tech'
  | 'Industrial Supplier'
  | 'Furniture & Joinery';

export type Certification =
  | 'Made in Yorkshire'
  | 'Made in Sheffield'
  | 'Guild of Fine Food'
  | 'Soil Association Organic'
  | 'ISO 9001 Certified'
  | 'Craft Council Accredited'
  | 'Yorkshire Dales Protected Origin'
  | 'Red Tractor Farm Assured';

export interface Business {
  id: string;
  name: string;
  tagline: string;
  description: string;
  logo: string;
  coverImage: string;
  type: BusinessType;
  town: YorkshireRegion;
  address: string;
  postcode: string;
  latitude: number;
  longitude: number;
  phone: string;
  email: string;
  website: string;
  certifications: Certification[];
  rating: number;
  reviewCount: number;
  deliveryRadiusMiles: number;
  isVerified: boolean;
  yearEstablished: number;
  story: string;
  openingHours: string;
  socialLinks?: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
    linkedin?: string;
  };
}

export interface ProductSpec {
  name: string;
  value: string;
}

export interface B2BTierPrice {
  minQty: number;
  pricePerUnit: number;
}

export interface Product {
  id: string;
  businessId: string;
  businessName: string;
  title: string;
  tagline: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: ProductCategory;
  originTown: YorkshireRegion;
  images: string[];
  specs: ProductSpec[];
  stock: number;
  rating: number;
  reviewCount: number;
  isB2bAvailable: boolean;
  b2bTierPrices?: B2BTierPrice[];
  tags: string[];
  leadTimeDays: number;
  badges: string[];
  featured?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  notes?: string;
}

export interface Review {
  id: string;
  productId?: string;
  businessId?: string;
  authorName: string;
  authorTown: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
}

export interface OrderVendorGroup {
  businessId: string;
  businessName: string;
  town: YorkshireRegion;
  items: CartItem[];
  shippingFee: number;
  deliveryEstimate: string;
}

export interface Order {
  id: string;
  date: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  town: string;
  postcode: string;
  vendorGroups: OrderVendorGroup[];
  subtotal: number;
  shippingTotal: number;
  discountTotal: number;
  grandTotal: number;
  paymentMethod: 'card' | 'apple_pay' | 'google_pay' | 'b2b_invoice';
  status: 'Processing' | 'In Production' | 'Dispatched' | 'Delivered' | 'Ready for Pickup';
  b2bInvoiceRef?: string;
}

export interface B2BQuoteRequest {
  id: string;
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  town: YorkshireRegion;
  category: ProductCategory;
  details: string;
  estimatedQuantity: number;
  targetDeadline: string;
  status: 'Pending' | 'Under Review' | 'Quotes Received' | 'Approved';
  dateSubmitted: string;
}

export interface FilterState {
  searchQuery: string;
  category: ProductCategory | 'All';
  region: YorkshireRegion | 'All';
  businessType: BusinessType | 'All';
  minPrice: number;
  maxPrice: number;
  verifiedOnly: boolean;
  b2bOnly: boolean;
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';
}

export type UserRole = 'customer' | 'seller' | 'admin' | 'b2b_trade';
