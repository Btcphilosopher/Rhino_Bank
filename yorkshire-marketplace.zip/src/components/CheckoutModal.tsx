import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { Order, OrderVendorGroup } from '../types';
import {
  X,
  CheckCircle2,
  Printer,
  ShieldCheck,
  CreditCard,
  Building2,
  Truck,
  ArrowRight
} from 'lucide-react';
import { YORKSHIRE_REGIONS } from '../data/mockData';

interface CheckoutModalProps {
  onClose: () => void;
  grandTotal: number;
  subtotal: number;
  shippingTotal: number;
  discountTotal: number;
  vendorGroups: Record<string, { businessName: string; originTown: string; items: any[] }>;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  onClose,
  grandTotal,
  subtotal,
  shippingTotal,
  discountTotal,
  vendorGroups
}) => {
  const { placeOrder, setIsCartOpen } = useMarketplace();

  const [step, setStep] = useState<'details' | 'payment' | 'confirmation'>('details');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  const [formData, setFormData] = useState({
    customerName: 'Margaret Thornton',
    customerEmail: 'm.thornton@yorkshire.co.uk',
    customerPhone: '0113 496 0122',
    shippingAddress: '42 Headingley Lane',
    town: 'Leeds',
    postcode: 'LS6 2BR',
    paymentMethod: 'card' as 'card' | 'apple_pay' | 'google_pay' | 'b2b_invoice'
  });

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handleFinalPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const formattedVendorGroups: OrderVendorGroup[] = Object.entries(vendorGroups).map(
      ([bizId, g]: [string, { businessName: string; originTown: string; items: any[] }]) => ({
        businessId: bizId,
        businessName: g.businessName,
        town: g.originTown as any,
        items: g.items,
        shippingFee: 4.95,
        deliveryEstimate: '2-3 Working Days'
      })
    );

    const newOrder = placeOrder({
      customerName: formData.customerName,
      customerEmail: formData.customerEmail,
      customerPhone: formData.customerPhone,
      shippingAddress: formData.shippingAddress,
      town: formData.town,
      postcode: formData.postcode,
      vendorGroups: formattedVendorGroups,
      subtotal,
      shippingTotal,
      discountTotal,
      grandTotal,
      paymentMethod: formData.paymentMethod,
      b2bInvoiceRef: formData.paymentMethod === 'b2b_invoice' ? `YM-INV-${Math.floor(100000 + Math.random() * 900000)}` : undefined
    });

    setCompletedOrder(newOrder);
    setStep('confirmation');
  };

  const handlePrintInvoice = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 border border-[#E2DCD2] shadow-2xl relative space-y-6 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E2DCD2] pb-4">
          <div>
            <span className="text-xs font-bold text-[#C86D51] uppercase tracking-wider">
              Made in Yorkshire Checkout
            </span>
            <h2 className="font-serif text-2xl font-bold text-[#0F172A]">
              {step === 'confirmation' ? 'Order Invoice & Confirmation' : 'Secure Yorkshire Checkout'}
            </h2>
          </div>
          <button
            onClick={() => {
              if (step === 'confirmation') {
                setIsCartOpen(false);
              }
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: Shipping Details Form */}
        {step === 'details' && (
          <form onSubmit={handleDetailsSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Full Customer / Trade Name</label>
                <input
                  type="text"
                  required
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={formData.customerEmail}
                  onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Telephone Contact</label>
                <input
                  type="text"
                  required
                  value={formData.customerPhone}
                  onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Yorkshire Town / City</label>
                <select
                  value={formData.town}
                  onChange={(e) => setFormData({ ...formData, town: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                >
                  {YORKSHIRE_REGIONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-[#0F172A] mb-1">Delivery Address</label>
                <input
                  type="text"
                  required
                  value={formData.shippingAddress}
                  onChange={(e) => setFormData({ ...formData, shippingAddress: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Postcode</label>
                <input
                  type="text"
                  required
                  value={formData.postcode}
                  onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#1C4532] text-white py-3.5 rounded-xl font-bold text-sm hover:bg-[#153426] transition-colors flex items-center justify-center space-x-2 cursor-pointer mt-4"
            >
              <span>Continue to Payment (£{grandTotal.toFixed(2)})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* STEP 2: Payment Method */}
        {step === 'payment' && (
          <form onSubmit={handleFinalPaymentSubmit} className="space-y-4 text-xs">
            <div className="space-y-3">
              <label className="block font-bold text-[#0F172A]">Select Payment Gateway</label>

              <label className={`flex items-center p-3 rounded-2xl border cursor-pointer ${
                formData.paymentMethod === 'card' ? 'border-[#1C4532] bg-emerald-50/50' : 'border-[#E2DCD2]'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  checked={formData.paymentMethod === 'card'}
                  onChange={() => setFormData({ ...formData, paymentMethod: 'card' })}
                  className="text-[#1C4532] mr-3"
                />
                <CreditCard className="w-5 h-5 text-[#2B4C7E] mr-2" />
                <span className="font-bold text-[#0F172A]">Debit / Credit Card (Visa, Mastercard, Amex)</span>
              </label>

              <label className={`flex items-center p-3 rounded-2xl border cursor-pointer ${
                formData.paymentMethod === 'b2b_invoice' ? 'border-[#2B4C7E] bg-sky-50/50' : 'border-[#E2DCD2]'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  checked={formData.paymentMethod === 'b2b_invoice'}
                  onChange={() => setFormData({ ...formData, paymentMethod: 'b2b_invoice' })}
                  className="text-[#2B4C7E] mr-3"
                />
                <Building2 className="w-5 h-5 text-[#2B4C7E] mr-2" />
                <span className="font-bold text-[#0F172A]">Trade B2B Invoice (30-Day Credit Terms)</span>
              </label>
            </div>

            <div className="p-4 bg-[#F6F4EF] rounded-2xl border border-[#E2DCD2] space-y-2 text-xs">
              <div className="flex justify-between font-semibold">
                <span>Grand Total to Pay:</span>
                <span className="font-bold text-lg text-[#1C4532]">£{grandTotal.toFixed(2)}</span>
              </div>
              <p className="text-[11px] text-[#4A5568]">
                Protected by 256-bit Yorkshire Regional Payment Gateway Encryption.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep('details')}
                className="w-1/3 bg-[#F6F4EF] text-[#0F172A] py-3 rounded-xl font-bold hover:bg-[#E2DCD2]"
              >
                Back
              </button>
              <button
                type="submit"
                className="w-2/3 bg-[#1C4532] text-white py-3 rounded-xl font-bold text-sm hover:bg-[#153426]"
              >
                Confirm Order & Pay
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: Order Confirmation & Invoice */}
        {step === 'confirmation' && completedOrder && (
          <div className="space-y-6 text-xs text-[#0F172A]">
            <div className="bg-emerald-50 border border-emerald-300 p-4 rounded-2xl flex items-center space-x-3 text-emerald-900">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-serif font-bold text-base">Order Successfully Placed!</h4>
                <p className="text-xs">
                  Order Ref: <strong>{completedOrder.id}</strong> • Confirmation sent to {completedOrder.customerEmail}
                </p>
              </div>
            </div>

            {/* Print Printable Invoice Card */}
            <div className="p-6 bg-[#F6F4EF] rounded-2xl border border-[#E2DCD2] space-y-4 font-sans print:p-0">
              <div className="flex justify-between items-start border-b border-[#E2DCD2] pb-3">
                <div>
                  <div className="font-serif font-bold text-lg text-[#0F172A]">Yorkshire Marketplace Invoice</div>
                  <div className="text-[11px] text-[#4A5568]">Tax Point Date: {completedOrder.date}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-[#1C4532]">{completedOrder.id}</div>
                  {completedOrder.b2bInvoiceRef && (
                    <div className="text-[11px] text-[#2B4C7E] font-semibold">
                      Invoice Ref: {completedOrder.b2bInvoiceRef}
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="font-bold text-[#4A5568] uppercase block">Billed To:</span>
                  <div>{completedOrder.customerName}</div>
                  <div>{completedOrder.shippingAddress}</div>
                  <div>{completedOrder.town}, {completedOrder.postcode}</div>
                </div>

                <div>
                  <span className="font-bold text-[#4A5568] uppercase block">Payment Status:</span>
                  <div className="font-bold text-emerald-700">
                    {completedOrder.paymentMethod === 'b2b_invoice' ? '30-Day B2B Trade Terms' : 'Paid in Full via Gateway'}
                  </div>
                </div>
              </div>

              {/* Vendors List */}
              <div className="space-y-2 pt-2 border-t border-[#E2DCD2]">
                <span className="font-bold uppercase text-[#4A5568]">Vendor Fullfillment Breakdown:</span>
                {completedOrder.vendorGroups.map((vg, idx) => (
                  <div key={idx} className="bg-white p-3 rounded-xl border border-[#E2DCD2]">
                    <div className="font-bold text-[#0F172A]">{vg.businessName} ({vg.town})</div>
                    <div className="text-[11px] text-[#4A5568] mt-1 space-y-0.5">
                      {vg.items.map((it) => (
                        <div key={it.product.id} className="flex justify-between">
                          <span>{it.quantity}x {it.product.title}</span>
                          <span className="font-bold">£{(it.product.price * it.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-[#E2DCD2] flex justify-between font-serif text-lg font-bold text-[#0F172A]">
                <span>Grand Total:</span>
                <span className="text-[#1C4532]">£{completedOrder.grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={handlePrintInvoice}
                className="flex-1 bg-[#2B4C7E] text-white py-3 rounded-xl font-bold flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Invoice</span>
              </button>

              <button
                onClick={() => {
                  setIsCartOpen(false);
                  onClose();
                }}
                className="flex-1 bg-[#0F172A] text-white py-3 rounded-xl font-bold cursor-pointer"
              >
                Return to Marketplace
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
