import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { MapPin, Building2, Store, ExternalLink, CheckCircle2, Factory, Navigation, Filter } from 'lucide-react';
import { Business } from '../types';

export const RegionalMap: React.FC = () => {
  const { businesses, setSelectedBusiness } = useMarketplace();
  const [selectedPin, setSelectedPin] = useState<Business | null>(businesses[0] || null);
  const [filterType, setFilterType] = useState<string>('All');

  const filteredBusinesses = businesses.filter((b) => {
    if (filterType === 'All') return true;
    return b.type === filterType;
  });

  return (
    <div className="bg-[#FAFA3] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Map Section Title */}
        <div className="bg-white p-8 rounded-3xl border border-[#E2DCD2] shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-[#C86D51]">
              <MapPin className="w-4 h-4" />
              <span>GIS Interactive Regional Map</span>
            </div>
            <h1 className="font-serif text-3xl font-bold text-[#0F172A] mt-1">
              Yorkshire Business & Distribution Hubs
            </h1>
            <p className="text-xs text-[#4A5568] max-w-2xl mt-1">
              Interactive geographic guide to registered steelworks, farm shops, craft workshops, and industrial centers across Yorkshire and the Humber.
            </p>
          </div>

          {/* Map Pins Filter */}
          <div className="flex items-center space-x-2 bg-[#F6F4EF] p-2 rounded-2xl border border-[#E2DCD2] text-xs font-semibold">
            <Filter className="w-3.5 h-3.5 text-[#2B4C7E] ml-1" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-transparent text-[#0F172A] focus:outline-none cursor-pointer"
            >
              <option value="All">All Business Types</option>
              <option value="Manufacturer">Manufacturers</option>
              <option value="Farm & Produce">Farms & Produce</option>
              <option value="Artisan & Craft">Artisan Workshops</option>
              <option value="Furniture & Joinery">Furniture & Joinery</option>
              <option value="Industrial Supplier">Industrial Suppliers</option>
            </select>
          </div>
        </div>

        {/* Interactive Map Board Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Visual Interactive Vector Map View */}
          <div className="lg:col-span-8 bg-[#0F172A] rounded-3xl p-6 border border-slate-800 shadow-2xl relative overflow-hidden min-h-[500px] flex flex-col justify-between">
            
            {/* Top Map Status Bar */}
            <div className="relative z-10 flex justify-between items-center text-xs text-slate-300 bg-slate-900/80 backdrop-blur-md px-4 py-2.5 rounded-xl border border-slate-700">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse" />
                <span className="font-mono">YORKSHIRE_GIS_GRID // 53.8008° N, 1.5491° W</span>
              </div>
              <span className="text-emerald-400 font-bold">{filteredBusinesses.length} Pins Active</span>
            </div>

            {/* Stylized Contour Yorkshire Map Grid */}
            <div className="absolute inset-0 z-0 opacity-20 pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />

            {/* Interactive Pins Area */}
            <div className="relative z-10 my-12 grid grid-cols-2 sm:grid-cols-4 gap-6">
              {filteredBusinesses.map((b) => {
                const isSelected = selectedPin?.id === b.id;
                return (
                  <button
                    key={b.id}
                    onClick={() => setSelectedPin(b)}
                    className={`group p-4 rounded-2xl border transition-all text-left cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#1C4532] text-white border-emerald-400 shadow-lg scale-105'
                        : 'bg-slate-800/90 text-slate-200 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <MapPin className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-[#C86D51]'}`} />
                        <span className="text-[10px] font-mono uppercase bg-slate-900/80 px-2 py-0.5 rounded text-slate-300">
                          {b.town}
                        </span>
                      </div>
                      <div className="font-serif font-bold text-sm line-clamp-1">{b.name}</div>
                      <div className="text-[11px] opacity-80 mt-1">{b.type}</div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-white/10 text-[10px] font-mono flex items-center justify-between">
                      <span>{b.postcode}</span>
                      <Navigation className="w-3 h-3 text-emerald-400" />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Map Legend */}
            <div className="relative z-10 flex flex-wrap gap-4 text-[11px] text-slate-400 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-400" /> Sheffield Steel & Cutlery</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-400" /> Wensleydale & Dales Dairy</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-sky-400" /> Leeds Textile Mills</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-rose-400" /> Whitby Jet Crafts</span>
            </div>

          </div>

          {/* Right Selected Pin Detail Drawer */}
          <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-[#E2DCD2] shadow-xl space-y-5">
            {selectedPin ? (
              <div className="space-y-4">
                <img
                  src={selectedPin.coverImage}
                  alt={selectedPin.name}
                  className="w-full h-40 rounded-2xl object-cover border border-[#E2DCD2]"
                />

                <div>
                  <span className="bg-[#1C4532] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase">
                    {selectedPin.type}
                  </span>
                  <h3 className="font-serif font-bold text-[#0F172A] text-xl mt-2 flex items-center gap-1.5">
                    <span>{selectedPin.name}</span>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  </h3>
                  <p className="text-xs text-[#C86D51] font-semibold mt-1">
                    {selectedPin.address}, {selectedPin.town} ({selectedPin.postcode})
                  </p>
                </div>

                <p className="text-xs text-[#4A5568] leading-relaxed font-sans">
                  {selectedPin.description}
                </p>

                <div className="p-3 bg-[#F6F4EF] rounded-xl space-y-1.5 text-xs text-[#0F172A]">
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Est. Year:</span>
                    <span className="font-bold">{selectedPin.yearEstablished}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Delivery Coverage:</span>
                    <span className="font-bold">{selectedPin.deliveryRadiusMiles} Miles</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Contact Phone:</span>
                    <span className="font-bold">{selectedPin.phone}</span>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedBusiness(selectedPin)}
                  className="w-full bg-[#0F172A] text-white py-3 rounded-xl font-bold text-xs hover:bg-[#1E293B] transition-colors flex items-center justify-center space-x-2 cursor-pointer shadow-sm"
                >
                  <span>Open Full Storefront</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="text-center py-12 text-sm text-[#4A5568]">
                Select a map pin to view location details.
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
