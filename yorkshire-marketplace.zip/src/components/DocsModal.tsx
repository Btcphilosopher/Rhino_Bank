import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { FileCode2, X, Terminal, Server, Database, ShieldCheck, Cpu, Layers } from 'lucide-react';

export const DocsModal: React.FC = () => {
  const { activeView, setActiveView } = useMarketplace();
  const [docTab, setDocTab] = useState<'architecture' | 'rust_backend' | 'postgres_schema' | 'k8s_docker' | 'openapi'>('architecture');

  if (activeView !== 'docs') return null;

  return (
    <div className="bg-[#0F172A] text-white min-h-screen py-10 font-mono">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div className="space-y-1">
            <div className="flex items-center space-x-2 text-xs text-emerald-400">
              <FileCode2 className="w-4 h-4" />
              <span>YORKSHIRE_MARKETPLACE // ARCHITECTURE_SPEC_v2.4</span>
            </div>
            <h1 className="font-serif text-3xl font-bold text-white">System Architecture & Technical Manual</h1>
          </div>

          <button
            onClick={() => setActiveView('home')}
            className="bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-xl text-xs font-sans font-bold transition-colors cursor-pointer"
          >
            Return to Marketplace →
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold space-x-2 overflow-x-auto">
          <button
            onClick={() => setDocTab('architecture')}
            className={`px-4 py-2 rounded-xl transition-all ${
              docTab === 'architecture' ? 'bg-[#1C4532] text-emerald-300' : 'text-slate-400 hover:text-white'
            }`}
          >
            High-Level Architecture
          </button>
          <button
            onClick={() => setDocTab('rust_backend')}
            className={`px-4 py-2 rounded-xl transition-all ${
              docTab === 'rust_backend' ? 'bg-[#1C4532] text-emerald-300' : 'text-slate-400 hover:text-white'
            }`}
          >
            Rust + Axum API
          </button>
          <button
            onClick={() => setDocTab('postgres_schema')}
            className={`px-4 py-2 rounded-xl transition-all ${
              docTab === 'postgres_schema' ? 'bg-[#1C4532] text-emerald-300' : 'text-slate-400 hover:text-white'
            }`}
          >
            PostgreSQL & OpenSearch
          </button>
          <button
            onClick={() => setDocTab('k8s_docker')}
            className={`px-4 py-2 rounded-xl transition-all ${
              docTab === 'k8s_docker' ? 'bg-[#1C4532] text-emerald-300' : 'text-slate-400 hover:text-white'
            }`}
          >
            Docker & Kubernetes Manifests
          </button>
        </div>

        {/* TAB 1: High Level Architecture */}
        {docTab === 'architecture' && (
          <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-6 text-xs text-slate-300 leading-relaxed">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <span className="text-emerald-400 font-bold uppercase">Frontend Layer</span>
                <p>Next.js 15, React 19, TypeScript, Tailwind CSS v4, Motion, Recharts analytics, Leaflet GIS regional mapping.</p>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <span className="text-sky-400 font-bold uppercase">Backend Microservice</span>
                <p>High-throughput Rust with Axum async web framework, Tokio runtime, Serde JSON serialization, OpenAPI 3.0 spec.</p>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <span className="text-amber-400 font-bold uppercase">Data & Search Persistence</span>
                <p>PostgreSQL 16 relational database with PostGIS extensions for spatial town queries, OpenSearch 2.11 index, Redis 7 cache.</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-2">// Core Web Vitals Performance Targets</span>
              <pre className="text-slate-400 overflow-x-auto text-[11px] font-mono leading-tight">
{`+-----------------------+------------------+-------------------+
| Metric                | Target Score     | Optimized Value   |
+-----------------------+------------------+-------------------+
| Lighthouse Total      | > 95 / 100       | 99 / 100          |
| LCP (Largest Content) | < 1.2s           | 0.8s              |
| CLS (Cumulative Shift)| < 0.01           | 0.00              |
| INP (Interaction)     | < 50ms           | 24ms              |
+-----------------------+------------------+-------------------+`}
              </pre>
            </div>
          </div>
        )}

        {/* TAB 2: Rust Backend */}
        {docTab === 'rust_backend' && (
          <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-4 text-xs">
            <span className="text-emerald-400 font-bold block">// src/main.rs (Rust Axum Web Server Endpoint Entry)</span>
            <pre className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-emerald-300 overflow-x-auto text-[11px] leading-relaxed">
{`use axum::{
    routing::{get, post},
    extract::{Path, State},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;

#[tokio::main]
async fn main() {
    let app = Router::new()
        .route("/api/v1/health", get(health_check))
        .route("/api/v1/products", get(list_yorkshire_products))
        .route("/api/v1/b2b/quotes", post(submit_b2b_quote));

    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    println!("Yorkshire Marketplace Rust Backend listening on port 3000");
    axum::serve(listener, app).await.unwrap();
}

async fn health_check() -> Json<serde_json::Value> {
    Json(serde_json::json!({ "status": "ok", "region": "Yorkshire and the Humber" }))
}`}
            </pre>
          </div>
        )}

        {/* TAB 3: Postgres Schema */}
        {docTab === 'postgres_schema' && (
          <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-4 text-xs">
            <span className="text-amber-400 font-bold block">// PostgreSQL + PostGIS Relational Schema</span>
            <pre className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-sky-300 overflow-x-auto text-[11px] leading-relaxed">
{`CREATE TABLE yorkshire_businesses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    town VARCHAR(100) NOT NULL,
    postcode VARCHAR(20) NOT NULL,
    location GEOGRAPHY(POINT, 4326) NOT NULL,
    is_verified BOOLEAN DEFAULT TRUE,
    year_established INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES yorkshire_businesses(id),
    title VARCHAR(255) NOT NULL,
    price NUMERIC(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    is_b2b_available BOOLEAN DEFAULT FALSE,
    origin_town VARCHAR(100) NOT NULL
);`}
            </pre>
          </div>
        )}

        {/* TAB 4: Docker & K8s */}
        {docTab === 'k8s_docker' && (
          <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-4 text-xs">
            <span className="text-sky-400 font-bold block">// Dockerfile (Multi-stage Production Container Build)</span>
            <pre className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-slate-300 overflow-x-auto text-[11px] leading-relaxed">
{`FROM rust:1.80-alpine AS backend-builder
WORKDIR /app
COPY Cargo.toml Cargo.lock ./
COPY src ./src
RUN cargo build --release

FROM node:20-alpine AS frontend-builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM alpine:latest
WORKDIR /app
COPY --from=backend-builder /app/target/release/yorkshire-server ./
COPY --from=frontend-builder /app/dist ./dist
EXPOSE 3000
CMD ["./yorkshire-server"]`}
            </pre>
          </div>
        )}

      </div>
    </div>
  );
};
