import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { Building2, Factory, ShieldCheck, FileText, Send, CheckCircle2, ArrowRight } from 'lucide-react';
import { YORKSHIRE_REGIONS, PRODUCT_CATEGORIES } from '../data/mockData';

export const B2BHub: React.FC = () => {
  const { submitB2BQuote } = useMarketplace();
  const [quoteForm, setQuoteForm] = useState({
    companyName: 'Leeds Engineering Ltd',
    contactName: 'James Sterling',
    email: 'purchasing@leedseng.co.uk',
    phone: '0113 244 8900',
    town: 'Leeds' as any,
    category: 'Engineering' as any,
    details: 'Looking for 500 units of custom forged steel valves and CNC precision milled components for industrial machinery.',
    estimatedQuantity: 500,
    targetDeadline: '3 Weeks'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitB2BQuote(quoteForm);
  };

  return (
    <div className="bg-[#FAF9F6] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* B2B Hero */}
        <div className="bg-[#1A1A1A] text-white p-8 sm:p-12 border border-[#1A1A1A] shadow-xl space-y-6">
          <div className="inline-flex items-center space-x-2 bg-[#4682B4]/20 text-[#4682B4] px-3.5 py-1 text-[10px] font-bold uppercase tracking-[0.2em] border border-[#4682B4]/40">
            <Building2 className="w-4 h-4 text-[#4682B4]" />
            <span>Yorkshire B2B Trade & Wholesale Supply</span>
          </div>

          <h1 className="font-serif font-black italic text-3xl sm:text-5xl max-w-3xl leading-tight">
            Direct Commercial Trade with Yorkshire Mills, Steelworks & Fabricators.
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl font-light leading-relaxed">
            Eliminate middleman markups. Connect directly with heavy engineering firms in Sheffield, textile mills in Leeds, maritime energy suppliers in Hull, and organic farms across the Dales.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-white/10 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-300">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-[#B87333]" />
              <span>30-Day Credit Payment Terms</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-[#B87333]" />
              <span>Bulk Tiered Wholesale Rates</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-[#B87333]" />
              <span>ISO 9001 Certified Quality</span>
            </div>
          </div>
        </div>

        {/* RFQ Form & Advantages Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 border border-[#1A1A1A]/15 shadow-xl space-y-6">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#B87333]">
                Request Commercial Wholesale Quote
              </span>
              <h2 className="font-serif font-black italic text-2xl text-[#1A1A1A] mt-1">
                Submit RFQ to Regional Suppliers
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Company / Trade Name</label>
                  <input
                    type="text"
                    required
                    value={quoteForm.companyName}
                    onChange={(e) => setQuoteForm({ ...quoteForm, companyName: e.target.value })}
                    className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Buyer Contact Name</label>
                  <input
                    type="text"
                    required
                    value={quoteForm.contactName}
                    onChange={(e) => setQuoteForm({ ...quoteForm, contactName: e.target.value })}
                    className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Work Email</label>
                  <input
                    type="email"
                    required
                    value={quoteForm.email}
                    onChange={(e) => setQuoteForm({ ...quoteForm, email: e.target.value })}
                    className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Telephone Contact</label>
                  <input
                    type="text"
                    required
                    value={quoteForm.phone}
                    onChange={(e) => setQuoteForm({ ...quoteForm, phone: e.target.value })}
                    className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Product / Trade Category</label>
                  <select
                    value={quoteForm.category}
                    onChange={(e) => setQuoteForm({ ...quoteForm, category: e.target.value as any })}
                    className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs font-bold text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                  >
                    {PRODUCT_CATEGORIES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Target Yorkshire Region</label>
                  <select
                    value={quoteForm.town}
                    onChange={(e) => setQuoteForm({ ...quoteForm, town: e.target.value as any })}
                    className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs font-bold text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                  >
                    {YORKSHIRE_REGIONS.map((r) => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Quantity Required</label>
                <input
                  type="number"
                  value={quoteForm.estimatedQuantity}
                  onChange={(e) => setQuoteForm({ ...quoteForm, estimatedQuantity: Number(e.target.value) })}
                  className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs font-bold text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                />
              </div>

              <div>
                <label className="block font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] mb-1">Technical Specifications & Custom Requests</label>
                <textarea
                  rows={4}
                  required
                  value={quoteForm.details}
                  onChange={(e) => setQuoteForm({ ...quoteForm, details: e.target.value })}
                  className="w-full border border-[#1A1A1A]/20 p-2.5 text-xs text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333]"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1A1A1A] text-white py-4 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] transition-colors shadow-md flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Transmit Quote Request to Suppliers</span>
              </button>
            </form>
          </div>

          {/* Info Side */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white p-6 border border-[#1A1A1A]/15 shadow-sm space-y-4">
              <h3 className="font-serif font-black italic text-lg text-[#1A1A1A]">Why Buy Yorkshire B2B?</h3>
              <ul className="space-y-4 text-xs text-[#555]">
                <li className="flex items-start space-x-3">
                  <Factory className="w-4 h-4 text-[#4682B4] shrink-0 mt-0.5" />
                  <span><strong className="text-[#1A1A1A]">Zero Overseas Supply Chain Delays:</strong> Rapid road haulage and local collection hubs in Leeds, Sheffield, and Hull.</span>
                </li>
                <li className="flex items-start space-x-3">
                  <ShieldCheck className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
                  <span><strong className="text-[#1A1A1A]">Industrial Compliance:</strong> All manufacturers adhere strictly to ISO 9001 and British Standards Institute (BSI) regulations.</span>
                </li>
                <li className="flex items-start space-x-3">
                  <FileText className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
                  <span><strong className="text-[#1A1A1A]">Automated Invoicing:</strong> Integrated VAT invoices, purchase order tracking, and credit account facilities.</span>
                </li>
              </ul>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
