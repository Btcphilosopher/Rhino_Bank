import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import {
  Search,
  MapPin,
  ShoppingBag,
  Heart,
  Store,
  Building2,
  ShieldCheck,
  Bot,
  FileCode2,
  Menu,
  X,
  UserCheck
} from 'lucide-react';
import { YORKSHIRE_REGIONS, PRODUCT_CATEGORIES } from '../data/mockData';

export const Header: React.FC = () => {
  const {
    activeView,
    setActiveView,
    cart,
    wishlist,
    setIsCartOpen,
    filters,
    setFilters,
    setIsAiModalOpen,
    userRole,
    setUserRole
  } = useMarketplace();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeView !== 'directory' && activeView !== 'home') {
      setActiveView('directory');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F6]/90 backdrop-blur-md border-b border-[#1A1A1A]/10">
      {/* Top Banner Ticker */}
      <div className="bg-[#1A1A1A] text-white text-xs py-2 px-4 flex flex-wrap justify-between items-center">
        <div className="flex items-center space-x-3">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-[0.2em] bg-[#B87333] text-white">
            Made in Yorkshire
          </span>
          <span className="hidden sm:inline text-slate-300 text-[11px] font-medium tracking-wide">
            Connecting 1,200+ Independent Yorkshire Artisans, Manufacturers & Farms.
          </span>
        </div>
        <div className="flex items-center space-x-4 text-xs font-bold tracking-[0.15em] uppercase">
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="flex items-center space-x-1.5 text-[#B87333] hover:text-amber-200 transition-colors cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Yorkshire AI Concierge</span>
          </button>
          <span className="text-slate-600">|</span>
          <button
            onClick={() => setActiveView('docs')}
            className="flex items-center space-x-1 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Platform Specs</span>
          </button>
        </div>
      </div>

      {/* Primary Brand Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveView('home')}>
            <div className="w-10 h-10 bg-[#1A1A1A] text-white rounded-none flex items-center justify-center font-serif text-2xl font-black border border-[#1A1A1A]">
              Y
            </div>
            <div>
              <div className="flex items-baseline space-x-2">
                <span className="font-serif text-2xl font-black tracking-tight text-[#1A1A1A] uppercase">
                  Yorkshire
                </span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-[#B87333] uppercase underline underline-offset-4">
                  Marketplace
                </span>
              </div>
              <p className="text-[10px] text-[#555] font-bold tracking-[0.15em] uppercase hidden sm:block">
                Regional Strength • Northern Heritage
              </p>
            </div>
          </div>

          {/* Search Bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="hidden lg:flex flex-1 max-w-lg items-center bg-white border border-[#1A1A1A]/20 rounded-none px-3 py-2 focus-within:ring-2 focus-within:ring-[#B87333] transition-all"
          >
            <Search className="w-4 h-4 text-[#555] mr-2 shrink-0" />
            <input
              type="text"
              placeholder="Search Yorkshire goods, steel cutlery, cheese, wool..."
              value={filters.searchQuery}
              onChange={(e) => setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))}
              className="w-full bg-transparent text-xs font-medium text-[#1A1A1A] placeholder-[#888] focus:outline-none"
            />
            <div className="h-4 w-px bg-[#1A1A1A]/10 mx-2" />
            <div className="flex items-center space-x-1 shrink-0 text-xs text-[#555]">
              <MapPin className="w-3.5 h-3.5 text-[#B87333]" />
              <select
                value={filters.region}
                onChange={(e) => setFilters((prev) => ({ ...prev, region: e.target.value as any }))}
                className="bg-transparent text-xs text-[#1A1A1A] font-bold tracking-wide focus:outline-none cursor-pointer"
              >
                <option value="All">All Regions</option>
                {YORKSHIRE_REGIONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
          </form>

          {/* Actions & Role Switcher */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            
            {/* Wishlist Button */}
            <button
              onClick={() => setActiveView('directory')}
              className="relative p-2 text-[#1A1A1A] hover:text-[#B87333] transition-colors rounded-none"
              title="Saved Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#B87333] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center space-x-2 bg-[#1A1A1A] text-white px-5 py-2.5 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] transition-colors shadow-sm cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Basket</span>
              {totalCartCount > 0 && (
                <span className="bg-[#B87333] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full ml-1">
                  {totalCartCount}
                </span>
              )}
            </button>

            {/* Role Switcher Pill */}
            <div className="hidden md:flex items-center bg-[#D8D2C2]/40 p-1 border border-[#1A1A1A]/10 text-[10px] font-bold uppercase tracking-wider">
              <button
                onClick={() => {
                  setUserRole('customer');
                  if (activeView === 'seller_portal' || activeView === 'admin_portal') setActiveView('home');
                }}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${
                  userRole === 'customer'
                    ? 'bg-[#1A1A1A] text-white font-bold'
                    : 'text-[#555] hover:text-[#1A1A1A]'
                }`}
              >
                Shopper
              </button>
              <button
                onClick={() => {
                  setUserRole('seller');
                  setActiveView('seller_portal');
                }}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${
                  userRole === 'seller'
                    ? 'bg-[#1A1A1A] text-white font-bold'
                    : 'text-[#555] hover:text-[#1A1A1A]'
                }`}
              >
                Seller Portal
              </button>
              <button
                onClick={() => {
                  setUserRole('admin');
                  setActiveView('admin_portal');
                }}
                className={`px-3 py-1.5 transition-colors cursor-pointer ${
                  userRole === 'admin'
                    ? 'bg-[#1A1A1A] text-white font-bold'
                    : 'text-[#555] hover:text-[#1A1A1A]'
                }`}
              >
                Admin
              </button>
            </div>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#1A1A1A] hover:bg-[#D8D2C2]/30"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>
        </div>
      </div>

      {/* Secondary Bar - Navigation Views */}
      <nav className="bg-[#FAF9F6] border-t border-[#1A1A1A]/10 hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-11 text-[10px] font-bold tracking-[0.15em] uppercase text-[#555]">
            <div className="flex items-center space-x-8">
              <button
                onClick={() => setActiveView('home')}
                className={`hover:text-[#B87333] transition-colors py-2 border-b-2 cursor-pointer ${
                  activeView === 'home' ? 'border-[#1A1A1A] text-[#1A1A1A] font-extrabold' : 'border-transparent'
                }`}
              >
                Home Marketplace
              </button>

              <button
                onClick={() => setActiveView('directory')}
                className={`hover:text-[#B87333] transition-colors py-2 border-b-2 cursor-pointer ${
                  activeView === 'directory' ? 'border-[#1A1A1A] text-[#1A1A1A] font-extrabold' : 'border-transparent'
                }`}
              >
                Products & Categories
              </button>

              <button
                onClick={() => setActiveView('map')}
                className={`flex items-center space-x-1.5 hover:text-[#B87333] transition-colors py-2 border-b-2 cursor-pointer ${
                  activeView === 'map' ? 'border-[#1A1A1A] text-[#1A1A1A] font-extrabold' : 'border-transparent'
                }`}
              >
                <MapPin className="w-3.5 h-3.5 text-[#B87333]" />
                <span>Interactive Yorkshire Map</span>
              </button>

              <button
                onClick={() => setActiveView('b2b')}
                className={`flex items-center space-x-1.5 hover:text-[#B87333] transition-colors py-2 border-b-2 cursor-pointer ${
                  activeView === 'b2b' ? 'border-[#1A1A1A] text-[#1A1A1A] font-extrabold' : 'border-transparent'
                }`}
              >
                <Building2 className="w-3.5 h-3.5 text-[#4682B4]" />
                <span>B2B & Trade Accounts</span>
              </button>

              <button
                onClick={() => setActiveView('seller_portal')}
                className={`flex items-center space-x-1.5 hover:text-[#B87333] transition-colors py-2 border-b-2 cursor-pointer ${
                  activeView === 'seller_portal' ? 'border-[#1A1A1A] text-[#1A1A1A] font-extrabold' : 'border-transparent'
                }`}
              >
                <Store className="w-3.5 h-3.5 text-[#B87333]" />
                <span>Seller Dashboard</span>
              </button>
            </div>

            <div className="flex items-center space-x-4 text-[10px] font-bold tracking-[0.2em] uppercase text-[#B87333]">
              <span className="flex items-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>100% Verified Yorkshire Businesses</span>
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-[#E2DCD2] px-4 pt-3 pb-6 space-y-4">
          <form onSubmit={handleSearchSubmit} className="flex items-center bg-[#F6F4EF] rounded-xl px-3 py-2 border border-[#E2DCD2]">
            <Search className="w-4 h-4 text-[#4A5568] mr-2" />
            <input
              type="text"
              placeholder="Search products & towns..."
              value={filters.searchQuery}
              onChange={(e) => setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))}
              className="w-full bg-transparent text-sm focus:outline-none"
            />
          </form>

          <div className="grid grid-cols-2 gap-2 text-sm font-medium">
            <button
              onClick={() => { setActiveView('home'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-[#F6F4EF] text-[#0F172A] text-left"
            >
              Home
            </button>
            <button
              onClick={() => { setActiveView('directory'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-[#F6F4EF] text-[#0F172A] text-left"
            >
              All Products
            </button>
            <button
              onClick={() => { setActiveView('map'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-[#F6F4EF] text-[#0F172A] text-left"
            >
              Yorkshire Map
            </button>
            <button
              onClick={() => { setActiveView('b2b'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-[#F6F4EF] text-[#0F172A] text-left"
            >
              B2B Trade
            </button>
            <button
              onClick={() => { setActiveView('seller_portal'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-[#F6F4EF] text-[#0F172A] text-left"
            >
              Seller Dashboard
            </button>
            <button
              onClick={() => { setActiveView('admin_portal'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-[#F6F4EF] text-[#0F172A] text-left"
            >
              Platform Admin
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
