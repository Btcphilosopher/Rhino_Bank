import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { ProductCard } from './ProductCard';
import {
  Building2,
  MapPin,
  Phone,
  Mail,
  Globe,
  Clock,
  ShieldCheck,
  Star,
  Award,
  ArrowLeft,
  Send,
  CheckCircle2,
  Calendar,
  X
} from 'lucide-react';

export const BusinessProfileView: React.FC = () => {
  const { selectedBusiness, setSelectedBusiness, products, reviews, submitB2BQuote } = useMarketplace();
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [quoteDetails, setQuoteDetails] = useState({ company: '', email: '', details: '', qty: 10 });

  if (!selectedBusiness) return null;

  const businessProducts = products.filter((p) => p.businessId === selectedBusiness.id);
  const businessReviews = reviews.filter((r) => r.businessId === selectedBusiness.id);

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitB2BQuote({
      companyName: quoteDetails.company || 'Trade Customer',
      contactName: 'Trade Buyer',
      email: quoteDetails.email,
      phone: selectedBusiness.phone,
      town: selectedBusiness.town,
      category: businessProducts[0]?.category || 'Industrial Supplies',
      details: quoteDetails.details,
      estimatedQuantity: Number(quoteDetails.qty),
      targetDeadline: '2 Weeks'
    });
    setShowQuoteModal(false);
  };

  return (
    <div className="bg-[#FAFA3] min-h-screen pb-16">
      
      {/* Back to Marketplace Header */}
      <div className="bg-white border-b border-[#E2DCD2] py-3 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button
            onClick={() => setSelectedBusiness(null)}
            className="flex items-center space-x-2 text-xs font-bold text-[#2B4C7E] hover:underline cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Yorkshire Products</span>
          </button>

          <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Verified Yorkshire Storefront
          </span>
        </div>
      </div>

      {/* Hero Cover Banner */}
      <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-[#0F172A]">
        <img
          src={selectedBusiness.coverImage}
          alt={selectedBusiness.name}
          className="w-full h-full object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/40 to-transparent" />
      </div>

      {/* Storefront Info Header Box */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10 space-y-8">
        
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E2DCD2] shadow-xl flex flex-col md:flex-row gap-6 items-start justify-between">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <img
              src={selectedBusiness.logo}
              alt={selectedBusiness.name}
              className="w-24 h-24 rounded-2xl object-cover border-2 border-[#E2DCD2] shadow-md bg-white shrink-0"
            />

            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="bg-[#1C4532] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  {selectedBusiness.type}
                </span>
                <span className="text-xs text-[#C86D51] font-semibold flex items-center space-x-1">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{selectedBusiness.town}, Yorkshire</span>
                </span>
              </div>

              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#0F172A] flex items-center gap-2">
                <span>{selectedBusiness.name}</span>
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
              </h1>

              <p className="text-sm font-medium text-[#4A5568]">
                {selectedBusiness.tagline}
              </p>

              {/* Rating and Est Year */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-[#4A5568] pt-1">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-bold text-[#0F172A]">{selectedBusiness.rating}</span>
                  <span>({selectedBusiness.reviewCount} Ratings)</span>
                </div>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-3.5 h-3.5 text-[#2B4C7E]" />
                  <span>Established {selectedBusiness.yearEstablished}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={() => setShowQuoteModal(true)}
              className="bg-[#2B4C7E] text-white px-5 py-3 rounded-xl text-xs font-semibold hover:bg-[#1E3A63] transition-colors shadow-sm flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Contact / B2B Quote</span>
            </button>
          </div>

        </div>

        {/* Storefront Layout: Left Details, Right Products */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Sidebar: Business Profile Details & Certifications */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Story Box */}
            <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] space-y-3 shadow-xs">
              <h3 className="font-serif font-bold text-[#0F172A] text-lg">Our Story & Provenance</h3>
              <p className="text-xs text-[#4A5568] leading-relaxed font-sans">
                {selectedBusiness.story}
              </p>
            </div>

            {/* Certifications Box */}
            <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] space-y-3 shadow-xs">
              <h3 className="font-serif font-bold text-[#0F172A] text-lg flex items-center space-x-2">
                <Award className="w-5 h-5 text-amber-500" />
                <span>Accreditations & Badges</span>
              </h3>
              <div className="flex flex-wrap gap-2">
                {selectedBusiness.certifications.map((cert) => (
                  <span
                    key={cert}
                    className="bg-[#1C4532]/10 text-[#1C4532] text-xs font-bold px-3 py-1 rounded-full border border-emerald-300"
                  >
                    {cert}
                  </span>
                ))}
              </div>
            </div>

            {/* Location & Opening Hours */}
            <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] space-y-3 text-xs text-[#4A5568] shadow-xs">
              <h3 className="font-serif font-bold text-[#0F172A] text-lg">Location & Contact</h3>

              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-[#C86D51] shrink-0 mt-0.5" />
                <span>{selectedBusiness.address}, {selectedBusiness.town}, {selectedBusiness.postcode}</span>
              </div>

              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-[#2B4C7E] shrink-0" />
                <span>{selectedBusiness.phone}</span>
              </div>

              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-[#2B4C7E] shrink-0" />
                <span>{selectedBusiness.email}</span>
              </div>

              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-[#1C4532] shrink-0" />
                <span>{selectedBusiness.openingHours}</span>
              </div>

              <div className="pt-2 border-t border-[#E2DCD2] text-[11px] text-[#0F172A] font-semibold">
                Delivery Radius: Up to {selectedBusiness.deliveryRadiusMiles} miles across Yorkshire
              </div>
            </div>

          </div>

          {/* Right Main Column: Business Products Grid */}
          <div className="lg:col-span-8 space-y-6">
            <div className="flex items-center justify-between border-b border-[#E2DCD2] pb-3">
              <h2 className="font-serif text-2xl font-bold text-[#0F172A]">
                Products by {selectedBusiness.name}
              </h2>
              <span className="text-xs font-semibold text-[#4A5568]">
                {businessProducts.length} Items Available
              </span>
            </div>

            {businessProducts.length === 0 ? (
              <div className="bg-white p-8 text-center rounded-2xl border border-[#E2DCD2]">
                <p className="text-sm text-[#4A5568]">No active listings found for this business right now.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {businessProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Quote Request Modal */}
      {showQuoteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-[#E2DCD2] shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-[#E2DCD2] pb-3">
              <h3 className="font-serif font-bold text-[#0F172A] text-lg">Request B2B Quote</h3>
              <button onClick={() => setShowQuoteModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleQuoteSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Company / Trade Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Leeds Engineering Ltd"
                  value={quoteDetails.company}
                  onChange={(e) => setQuoteDetails({ ...quoteDetails, company: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Contact Email</label>
                <input
                  type="email"
                  required
                  placeholder="buyer@company.co.uk"
                  value={quoteDetails.email}
                  onChange={(e) => setQuoteDetails({ ...quoteDetails, email: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Estimated Quantity</label>
                <input
                  type="number"
                  min={1}
                  value={quoteDetails.qty}
                  onChange={(e) => setQuoteDetails({ ...quoteDetails, qty: Number(e.target.value) })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Requirement Details</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Specify sizes, specifications, or custom steel/fabric requirements..."
                  value={quoteDetails.details}
                  onChange={(e) => setQuoteDetails({ ...quoteDetails, details: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5 focus:ring-2 focus:ring-[#2B4C7E]"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1C4532] text-white py-3 rounded-xl font-bold hover:bg-[#153426] transition-colors"
              >
                Submit Quote Request
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
