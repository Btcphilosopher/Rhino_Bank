import React from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { MapPin, Tag } from 'lucide-react';
import { YORKSHIRE_REGIONS, PRODUCT_CATEGORIES } from '../data/mockData';

export const RegionalQuickBar: React.FC = () => {
  const { filters, setQuickRegion, setQuickCategory } = useMarketplace();

  return (
    <div className="bg-[#FAF9F6] border-b border-[#1A1A1A]/10 py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
        
        {/* Regions Row */}
        <div className="flex items-center space-x-2 overflow-x-auto scrollbar-none py-1">
          <div className="flex items-center space-x-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#B87333] shrink-0 pr-3 border-r border-[#1A1A1A]/10">
            <MapPin className="w-3.5 h-3.5" />
            <span>Region:</span>
          </div>

          <button
            onClick={() => setQuickRegion('All')}
            className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.15em] transition-colors shrink-0 cursor-pointer ${
              filters.region === 'All'
                ? 'bg-[#1A1A1A] text-white'
                : 'bg-white text-[#555] hover:bg-[#B87333] hover:text-white border border-[#1A1A1A]/15'
            }`}
          >
            All Yorkshire
          </button>

          {YORKSHIRE_REGIONS.slice(0, 12).map((region) => (
            <button
              key={region}
              onClick={() => setQuickRegion(region)}
              className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.15em] transition-colors shrink-0 cursor-pointer ${
                filters.region === region
                  ? 'bg-[#1A1A1A] text-white'
                  : 'bg-white text-[#555] hover:bg-[#B87333] hover:text-white border border-[#1A1A1A]/15'
              }`}
            >
              {region}
            </button>
          ))}
        </div>

        {/* Categories Row */}
        <div className="flex items-center space-x-2 overflow-x-auto scrollbar-none py-1">
          <div className="flex items-center space-x-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#4682B4] shrink-0 pr-3 border-r border-[#1A1A1A]/10">
            <Tag className="w-3.5 h-3.5" />
            <span>Category:</span>
          </div>

          <button
            onClick={() => setQuickCategory('All')}
            className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.15em] transition-colors shrink-0 cursor-pointer ${
              filters.category === 'All'
                ? 'bg-[#4682B4] text-white'
                : 'bg-white text-[#555] hover:bg-[#4682B4] hover:text-white border border-[#1A1A1A]/15'
            }`}
          >
            All Categories
          </button>

          {PRODUCT_CATEGORIES.slice(0, 10).map((cat) => (
            <button
              key={cat}
              onClick={() => setQuickCategory(cat)}
              className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.15em] transition-colors shrink-0 cursor-pointer ${
                filters.category === cat
                  ? 'bg-[#4682B4] text-white'
                  : 'bg-white text-[#555] hover:bg-[#4682B4] hover:text-white border border-[#1A1A1A]/15'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>
    </div>
  );
};
