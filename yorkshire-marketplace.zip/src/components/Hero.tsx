import React from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { Search, MapPin, ArrowRight, ShieldCheck, Award, Factory, Sparkles, Building2 } from 'lucide-react';
import { YORKSHIRE_REGIONS } from '../data/mockData';

export const Hero: React.FC = () => {
  const { setActiveView, setFilters, filters, setIsAiModalOpen } = useMarketplace();

  return (
    <div className="relative bg-[#FAF9F6] text-[#1A1A1A] overflow-hidden border-b border-[#1A1A1A]/10">
      {/* Background Large Watermark */}
      <div className="absolute top-4 left-8 lg:left-16 z-0 select-none pointer-events-none hidden sm:block">
        <h1 className="text-[200px] lg:text-[280px] font-serif font-black leading-[0.75] tracking-tighter text-[#1A1A1A] opacity-[0.03]">
          YORK<br />SHIRE
        </h1>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Hero Copy */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline Eyebrow */}
            <div className="flex items-center space-x-4 text-[#B87333]">
              <span className="w-12 h-[1px] bg-[#B87333]"></span>
              <span className="text-xs font-bold uppercase tracking-[0.4em]">Regional Strength</span>
            </div>

            <h1 className="font-serif font-black italic text-5xl sm:text-7xl lg:text-8xl leading-[0.88] tracking-tight text-[#1A1A1A]">
              Quality<br />
              <span className="not-italic font-black text-[#1A1A1A]">Crafted.</span>
            </h1>

            <p className="text-base sm:text-lg font-light max-w-md leading-relaxed text-[#555]">
              Connecting the heritage of the North with the innovation of today. Discover artisanal cutlery, industrial supplies, woollens, and local produce.
            </p>

            {/* Quick Hero Buttons */}
            <div className="flex flex-wrap gap-4 pt-4">
              <button
                onClick={() => setActiveView('directory')}
                className="px-8 py-4 bg-[#1A1A1A] text-white text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] transition-colors cursor-pointer"
              >
                Shop The Region
              </button>

              <button
                onClick={() => setActiveView('seller_portal')}
                className="px-8 py-4 border border-[#1A1A1A] text-[#1A1A1A] text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#1A1A1A] hover:text-white transition-colors cursor-pointer"
              >
                Become a Seller
              </button>

              <button
                onClick={() => setActiveView('b2b')}
                className="px-6 py-4 bg-[#4682B4]/10 text-[#4682B4] border border-[#4682B4]/30 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#4682B4] hover:text-white transition-colors cursor-pointer"
              >
                B2B Wholesale Hub
              </button>
            </div>

            {/* Verification Promises */}
            <div className="pt-8 grid grid-cols-2 sm:grid-cols-3 gap-4 border-t border-[#1A1A1A]/10 text-[10px] font-bold uppercase tracking-[0.15em] text-[#555]">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-[#B87333] shrink-0" />
                <span>100% Certified Provenance</span>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="w-4 h-4 text-[#B87333] shrink-0" />
                <span>Fair Maker Pricing</span>
              </div>
              <div className="flex items-center space-x-2">
                <Factory className="w-4 h-4 text-[#4682B4] shrink-0" />
                <span>B2B Trade Accounts</span>
              </div>
            </div>

          </div>

          {/* Search Card Box */}
          <div className="lg:col-span-5 bg-[#D8D2C2]/30 text-[#1A1A1A] p-6 sm:p-8 border border-[#1A1A1A]/15 shadow-xl space-y-6">
            <div className="border-b border-[#1A1A1A]/10 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#B87333]">
                Regional Search Directory
              </span>
              <h2 className="font-serif font-bold italic text-2xl mt-1 text-[#1A1A1A]">
                Explore Regional Goods
              </h2>
              <p className="text-xs text-[#555] font-light mt-1">
                Search products or select your nearest Yorkshire town.
              </p>
            </div>

            <div className="space-y-4">
              {/* Search Field */}
              <div>
                <label className="block text-[10px] font-bold text-[#1A1A1A] tracking-[0.2em] uppercase mb-1.5">
                  Keywords or Item
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="e.g. Cutlery, Wensleydale, Wool..."
                    value={filters.searchQuery}
                    onChange={(e) => setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))}
                    className="w-full bg-white border border-[#1A1A1A]/20 px-3.5 py-2.5 text-xs text-[#1A1A1A] placeholder-[#888] focus:ring-1 focus:ring-[#B87333] focus:outline-none"
                  />
                  <Search className="absolute right-3.5 top-3 w-4 h-4 text-[#555]" />
                </div>
              </div>

              {/* Region Selector */}
              <div>
                <label className="block text-[10px] font-bold text-[#1A1A1A] tracking-[0.2em] uppercase mb-1.5">
                  Yorkshire Region
                </label>
                <div className="relative">
                  <select
                    value={filters.region}
                    onChange={(e) => setFilters((prev) => ({ ...prev, region: e.target.value as any }))}
                    className="w-full bg-white border border-[#1A1A1A]/20 px-3.5 py-2.5 text-xs font-bold text-[#1A1A1A] focus:ring-1 focus:ring-[#B87333] focus:outline-none cursor-pointer"
                  >
                    <option value="All">All 21 Yorkshire Regions</option>
                    {YORKSHIRE_REGIONS.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                  <MapPin className="absolute right-3.5 top-3 w-4 h-4 text-[#B87333] pointer-events-none" />
                </div>
              </div>

              {/* Search Execute Button */}
              <button
                onClick={() => setActiveView('directory')}
                className="w-full bg-[#1A1A1A] text-white py-3.5 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] transition-colors shadow-sm flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>Search Marketplace</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Concierge Banner */}
              <div className="pt-3 border-t border-[#1A1A1A]/10 flex items-center justify-between text-xs text-[#555]">
                <span className="font-light">Need a custom recommendation?</span>
                <button
                  onClick={() => setIsAiModalOpen(true)}
                  className="text-[#B87333] font-bold tracking-wider uppercase text-[10px] hover:underline cursor-pointer"
                >
                  Ask AI Concierge →
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>

      {/* Bottom Key Statistics Bar */}
      <div className="bg-[#1A1A1A] text-white py-8 border-t border-[#1A1A1A]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <div className="font-serif text-3xl font-black italic text-[#B87333]">1,248</div>
            <div className="text-[9px] text-slate-400 mt-1 font-bold uppercase tracking-[0.25em]">Active Merchants</div>
          </div>
          <div>
            <div className="font-serif text-3xl font-black italic text-white">21</div>
            <div className="text-[9px] text-slate-400 mt-1 font-bold uppercase tracking-[0.25em]">Regional Hubs</div>
          </div>
          <div>
            <div className="font-serif text-3xl font-black italic text-[#4682B4]">£14.8M</div>
            <div className="text-[9px] text-slate-400 mt-1 font-bold uppercase tracking-[0.25em]">Products Shipped</div>
          </div>
          <div>
            <div className="font-serif text-3xl font-black italic text-[#B87333]">100%</div>
            <div className="text-[9px] text-slate-400 mt-1 font-bold uppercase tracking-[0.25em]">Verified Provenance</div>
          </div>
        </div>
      </div>
    </div>
  );
};
