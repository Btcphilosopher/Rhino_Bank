import React, { useMemo, useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { ProductCard } from './ProductCard';
import { Filter, SlidersHorizontal, Grid, List, RotateCcw, Building2, ShieldCheck } from 'lucide-react';
import { YORKSHIRE_REGIONS, PRODUCT_CATEGORIES } from '../data/mockData';

export const ProductGrid: React.FC = () => {
  const { products, filters, setFilters, resetFilters } = useMarketplace();
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Search query
      if (
        filters.searchQuery &&
        !p.title.toLowerCase().includes(filters.searchQuery.toLowerCase()) &&
        !p.description.toLowerCase().includes(filters.searchQuery.toLowerCase()) &&
        !p.businessName.toLowerCase().includes(filters.searchQuery.toLowerCase()) &&
        !p.originTown.toLowerCase().includes(filters.searchQuery.toLowerCase())
      ) {
        return false;
      }

      // Region
      if (filters.region !== 'All' && p.originTown !== filters.region) {
        return false;
      }

      // Category
      if (filters.category !== 'All' && p.category !== filters.category) {
        return false;
      }

      // Price Range
      if (p.price < filters.minPrice || p.price > filters.maxPrice) {
        return false;
      }

      // B2B Only
      if (filters.b2bOnly && !p.isB2bAvailable) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'price-asc') return a.price - b.price;
      if (filters.sortBy === 'price-desc') return b.price - a.price;
      if (filters.sortBy === 'rating') return b.rating - a.rating;
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [products, filters]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
      
      {/* Top Filter Controls Bar */}
      <div className="bg-white p-4 border border-[#1A1A1A]/10 flex flex-wrap items-center justify-between gap-4">
        
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
            className="flex items-center space-x-2 bg-[#FAF9F6] border border-[#1A1A1A]/15 px-4 py-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#1A1A1A] hover:bg-[#B87333] hover:text-white transition-colors cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>

          <span className="text-xs text-[#555] font-light">
            Showing <strong className="text-[#1A1A1A] font-bold">{filteredProducts.length}</strong> Yorkshire products
          </span>
        </div>

        {/* Sort & Layout Controls */}
        <div className="flex items-center space-x-3 text-xs">
          
          <div className="flex items-center space-x-1.5">
            <span className="text-[#555] font-bold text-[10px] uppercase tracking-[0.15em] hidden sm:inline">Sort by:</span>
            <select
              value={filters.sortBy}
              onChange={(e) => setFilters((prev) => ({ ...prev, sortBy: e.target.value as any }))}
              className="bg-[#FAF9F6] border border-[#1A1A1A]/15 text-[#1A1A1A] px-3 py-1.5 text-xs font-bold focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured First</option>
              <option value="rating">Highest Rated</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>

          <div className="h-4 w-px bg-[#1A1A1A]/10" />

          {/* Grid/List View Toggle */}
          <div className="flex bg-[#FAF9F6] p-1 border border-[#1A1A1A]/15">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-[#1A1A1A] text-white' : 'text-[#555]'
              }`}
              title="Grid View"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 transition-colors cursor-pointer ${
                viewMode === 'list' ? 'bg-[#1A1A1A] text-white' : 'text-[#555]'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>

      {/* Expandable Filter Drawer Panel */}
      {isFilterPanelOpen && (
        <div className="bg-[#FAF9F6] p-6 border border-[#1A1A1A]/15 grid grid-cols-1 md:grid-cols-4 gap-6 animate-fadeIn text-xs">
          
          {/* Region */}
          <div>
            <label className="block font-bold text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A] mb-2">Region</label>
            <select
              value={filters.region}
              onChange={(e) => setFilters((prev) => ({ ...prev, region: e.target.value as any }))}
              className="w-full bg-white border border-[#1A1A1A]/20 p-2.5 text-xs font-bold text-[#1A1A1A]"
            >
              <option value="All">All 21 Yorkshire Regions</option>
              {YORKSHIRE_REGIONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          {/* Category */}
          <div>
            <label className="block font-bold text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A] mb-2">Category</label>
            <select
              value={filters.category}
              onChange={(e) => setFilters((prev) => ({ ...prev, category: e.target.value as any }))}
              className="w-full bg-white border border-[#1A1A1A]/20 p-2.5 text-xs font-bold text-[#1A1A1A]"
            >
              <option value="All">All Categories</option>
              {PRODUCT_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Max Price Slider */}
          <div>
            <div className="flex justify-between font-bold text-[10px] uppercase tracking-[0.2em] text-[#1A1A1A] mb-2">
              <span>Max Price</span>
              <span className="text-[#B87333]">£{filters.maxPrice}</span>
            </div>
            <input
              type="range"
              min={10}
              max={2000}
              step={10}
              value={filters.maxPrice}
              onChange={(e) => setFilters((prev) => ({ ...prev, maxPrice: Number(e.target.value) }))}
              className="w-full accent-[#B87333]"
            />
          </div>

          {/* Special Toggles & Reset */}
          <div className="space-y-3 flex flex-col justify-end">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.b2bOnly}
                onChange={(e) => setFilters((prev) => ({ ...prev, b2bOnly: e.target.checked }))}
                className="accent-[#4682B4]"
              />
              <span className="font-bold text-[10px] uppercase tracking-[0.15em] text-[#1A1A1A] flex items-center space-x-1">
                <Building2 className="w-3.5 h-3.5 text-[#4682B4]" />
                <span>B2B Wholesale Available</span>
              </span>
            </label>

            <button
              onClick={resetFilters}
              className="flex items-center space-x-1 text-[#B87333] font-bold text-[10px] uppercase tracking-[0.2em] hover:underline pt-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All Filters</span>
            </button>
          </div>

        </div>
      )}

      {/* Grid or List Display */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-[#E2DCD2] space-y-3">
          <Filter className="w-12 h-12 text-[#4A5568] mx-auto" />
          <h3 className="font-serif text-xl font-bold text-[#0F172A]">No products match your criteria</h3>
          <p className="text-sm text-[#4A5568]">Try selecting "All Regions" or clearing your search term.</p>
          <button
            onClick={resetFilters}
            className="mt-2 bg-[#1C4532] text-white px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div
          className={
            viewMode === 'grid'
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
              : 'space-y-4'
          }
        >
          {filteredProducts.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}

    </div>
  );
};
