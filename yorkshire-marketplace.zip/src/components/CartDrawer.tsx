import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import {
  X,
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  MapPin,
  Tag,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { CheckoutModal } from './CheckoutModal';
import { motion, AnimatePresence } from 'motion/react';

export const CartDrawer: React.FC = () => {
  const { cart, isCartOpen, setIsCartOpen, removeFromCart, updateCartQuantity, clearCart, showToast } = useMarketplace();
  const [discountCode, setDiscountCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [showCheckout, setShowCheckout] = useState(false);

  if (!isCartOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleApplyDiscount = (e: React.FormEvent) => {
    e.preventDefault();
    const code = discountCode.trim().toUpperCase();
    if (code === 'YORKSHIRE10' || code === 'SUPPORTLOCAL') {
      setAppliedDiscount(subtotal * 0.1);
      showToast('10% Yorkshire Local Discount Applied!');
    } else if (code === 'FREESHIPDALE') {
      setAppliedDiscount(5.0);
      showToast('£5 Shipping Voucher Applied!');
    } else {
      showToast('Invalid discount code. Try "YORKSHIRE10"', 'error');
    }
  };

  // Group cart items by Yorkshire business
  const vendorGroups = cart.reduce<Record<string, { businessName: string; originTown: string; items: typeof cart }>>((groups, item) => {
    const bizId = item.product.businessId;
    if (!groups[bizId]) {
      groups[bizId] = {
        businessName: item.product.businessName,
        originTown: item.product.originTown,
        items: []
      };
    }
    groups[bizId].items.push(item);
    return groups;
  }, {});

  const shippingTotal = Object.keys(vendorGroups).length * 4.95;
  const grandTotal = Math.max(0, subtotal - appliedDiscount + shippingTotal);

  return (
    <>
      <AnimatePresence>
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs">
          <div className="absolute inset-0" onClick={() => setIsCartOpen(false)} />

          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute inset-y-0 right-0 max-w-full flex pl-10"
          >
            <div className="w-screen max-w-md bg-white border-l border-[#E2DCD2] shadow-2xl flex flex-col justify-between">
              
              {/* Cart Drawer Header */}
              <div className="p-6 bg-[#1A1A1A] text-white flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <ShoppingBag className="w-5 h-5 text-[#B87333]" />
                  <h2 className="font-serif font-black italic text-lg tracking-wide">Your Yorkshire Shopping Basket</h2>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cart Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="text-center py-16 space-y-4">
                    <ShoppingBag className="w-16 h-16 text-[#555] mx-auto opacity-40" />
                    <h3 className="font-serif font-black italic text-[#1A1A1A] text-xl">Your basket is currently empty</h3>
                    <p className="text-xs text-[#555] font-light">
                      Support local Yorkshire artisans, farms, and manufacturers.
                    </p>
                  </div>
                ) : (
                  Object.entries(vendorGroups).map(([bizId, group]: [string, { businessName: string; originTown: string; items: typeof cart }]) => (
                    <div key={bizId} className="bg-[#FAF9F6] p-4 border border-[#1A1A1A]/15 space-y-3">
                      <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A] pb-2 border-b border-[#1A1A1A]/10">
                        <span className="truncate">{group.businessName}</span>
                        <span className="bg-[#1A1A1A] text-white px-2 py-0.5 text-[9px]">
                          {group.originTown}
                        </span>
                      </div>

                      <div className="space-y-3">
                        {group.items.map((item) => (
                          <div key={item.product.id} className="flex space-x-3 items-center">
                            <img
                              src={item.product.images[0]}
                              alt={item.product.title}
                              className="w-14 h-14 object-cover border border-[#1A1A1A]/15 shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-xs text-[#1A1A1A] truncate">
                                {item.product.title}
                              </h4>
                              <div className="text-xs font-bold text-[#B87333] mt-0.5">
                                £{item.product.price.toFixed(2)}
                              </div>

                              {/* Quantity Controls */}
                              <div className="flex items-center space-x-2 mt-1">
                                <button
                                  onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                                  className="p-1 bg-white border border-[#1A1A1A]/20 hover:bg-[#B87333] hover:text-white"
                                >
                                  <Minus className="w-3 h-3 text-[#1A1A1A]" />
                                </button>
                                <span className="text-xs font-bold">{item.quantity}</span>
                                <button
                                  onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                                  className="p-1 bg-white border border-[#1A1A1A]/20 hover:bg-[#B87333] hover:text-white"
                                >
                                  <Plus className="w-3 h-3 text-[#1A1A1A]" />
                                </button>
                              </div>
                            </div>

                            <button
                              onClick={() => removeFromCart(item.product.id)}
                              className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Drawer Footer Calculations & Checkout */}
              {cart.length > 0 && (
                <div className="p-6 bg-[#FAF9F6] border-t border-[#1A1A1A]/15 space-y-4">
                  
                  {/* Coupon Code Input */}
                  <form onSubmit={handleApplyDiscount} className="flex gap-2 text-xs">
                    <input
                      type="text"
                      placeholder="PROMO CODE (E.G. YORKSHIRE10)"
                      value={discountCode}
                      onChange={(e) => setDiscountCode(e.target.value)}
                      className="flex-1 bg-white border border-[#1A1A1A]/20 px-3 py-2 text-xs text-[#1A1A1A] focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="bg-[#1A1A1A] text-white px-3 py-2 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] cursor-pointer"
                    >
                      Apply
                    </button>
                  </form>

                  {/* Calculations Breakdown */}
                  <div className="space-y-1.5 text-xs text-[#555]">
                    <div className="flex justify-between">
                      <span>Items Subtotal:</span>
                      <span className="font-bold text-[#1A1A1A]">£{subtotal.toFixed(2)}</span>
                    </div>

                    {appliedDiscount > 0 && (
                      <div className="flex justify-between text-[#B87333] font-semibold">
                        <span>Discount Applied:</span>
                        <span>-£{appliedDiscount.toFixed(2)}</span>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <span>Regional Shipping ({Object.keys(vendorGroups).length} Vendors):</span>
                      <span className="font-bold text-[#1A1A1A]">£{shippingTotal.toFixed(2)}</span>
                    </div>

                    <div className="flex justify-between text-sm font-bold text-[#1A1A1A] pt-2 border-t border-[#1A1A1A]/10">
                      <span>Grand Total:</span>
                      <span className="font-serif font-black italic text-xl text-[#B87333]">£{grandTotal.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Proceed to Checkout Button */}
                  <button
                    onClick={() => setShowCheckout(true)}
                    className="w-full bg-[#1A1A1A] text-white py-4 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] transition-colors shadow-md flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <span>Proceed to Regional Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                </div>
              )}

            </div>
          </motion.div>
        </div>
      </AnimatePresence>

      {/* Checkout Modal Launcher */}
      {showCheckout && (
        <CheckoutModal
          onClose={() => setShowCheckout(false)}
          grandTotal={grandTotal}
          subtotal={subtotal}
          shippingTotal={shippingTotal}
          discountTotal={appliedDiscount}
          vendorGroups={vendorGroups}
        />
      )}
    </>
  );
};
