import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import {
  Store,
  Plus,
  Package,
  TrendingUp,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  Building2,
  DollarSign,
  Users,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { YORKSHIRE_REGIONS, PRODUCT_CATEGORIES } from '../data/mockData';

const revenueData = [
  { month: 'Jan', sales: 12400, orders: 142 },
  { month: 'Feb', sales: 15800, orders: 185 },
  { month: 'Mar', sales: 18200, orders: 210 },
  { month: 'Apr', sales: 22400, orders: 260 },
  { month: 'May', sales: 26800, orders: 310 },
  { month: 'Jun', sales: 31200, orders: 380 },
  { month: 'Jul', sales: 39500, orders: 490 }
];

const categoryData = [
  { name: 'Cutlery & Steel', value: 35, color: '#2B4C7E' },
  { name: 'Artisan Dairy', value: 25, color: '#1C4532' },
  { name: 'Woollens & Tweed', value: 20, color: '#C86D51' },
  { name: 'Whitby Jet', value: 12, color: '#A3734C' },
  { name: 'Craft Spirits', value: 8, color: '#0F172A' }
];

export const SellerPortal: React.FC = () => {
  const { products, addNewProduct, updateProductStock, orders, showToast } = useMarketplace();
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'analytics'>('overview');
  const [showAddModal, setShowAddModal] = useState(false);

  const [newProd, setNewProd] = useState({
    title: '',
    tagline: '',
    description: '',
    price: 45.0,
    category: 'Home & Living' as any,
    originTown: 'Sheffield' as any,
    stock: 20,
    isB2bAvailable: true,
    image: 'https://images.unsplash.com/photo-1593618998160-e34014e67546?auto=format&fit=crop&w=800&q=80'
  });

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    addNewProduct({
      businessId: 'biz-sheffield-steel',
      businessName: 'Sheffield Forged Steelworks & Cutlery Co.',
      title: newProd.title,
      tagline: newProd.tagline,
      description: newProd.description,
      price: Number(newProd.price),
      category: newProd.category,
      originTown: newProd.originTown,
      images: [newProd.image],
      specs: [
        { name: 'Origin', value: newProd.originTown },
        { name: 'Quality Standard', value: 'ISO 9001 Made in Yorkshire' }
      ],
      stock: Number(newProd.stock),
      isB2bAvailable: newProd.isB2bAvailable,
      b2bTierPrices: [
        { minQty: 10, pricePerUnit: Number(newProd.price) * 0.8 }
      ],
      tags: ['Yorkshire', newProd.category],
      leadTimeDays: 2,
      badges: ['Made in Yorkshire', 'Verified Supplier']
    });

    setShowAddModal(false);
  };

  return (
    <div className="bg-[#FAFA3] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Seller Header */}
        <div className="bg-[#0F172A] text-white p-8 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-emerald-400">
              <Store className="w-4 h-4" />
              <span>Yorkshire Seller Portal</span>
            </div>
            <h1 className="font-serif text-3xl font-bold">
              Sheffield Forged Steelworks Storefront
            </h1>
            <p className="text-xs text-slate-300 max-w-xl">
              Manage inventory, process B2B trade inquiries, track regional sales analytics, and update product catalog listings.
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="bg-[#1C4532] text-white px-5 py-3 rounded-xl text-xs font-bold hover:bg-[#153426] transition-colors shadow-md flex items-center space-x-2 cursor-pointer border border-emerald-500/30"
          >
            <Plus className="w-4 h-4" />
            <span>List New Product</span>
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-white p-2 rounded-2xl border border-[#E2DCD2] text-xs font-bold space-x-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'overview' ? 'bg-[#0F172A] text-white' : 'text-[#4A5568] hover:text-[#0F172A]'
            }`}
          >
            Store Overview
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'products' ? 'bg-[#0F172A] text-white' : 'text-[#4A5568] hover:text-[#0F172A]'
            }`}
          >
            Product Catalog ({products.length})
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'analytics' ? 'bg-[#0F172A] text-white' : 'text-[#4A5568] hover:text-[#0F172A]'
            }`}
          >
            Sales & Regional Analytics
          </button>
        </div>

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* 4 Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              
              <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
                <div className="flex justify-between items-center text-xs text-[#4A5568]">
                  <span>Total Gross Revenue</span>
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="font-serif text-3xl font-bold text-[#0F172A]">£39,500.00</div>
                <div className="text-xs text-emerald-700 font-semibold flex items-center space-x-1">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  <span>+18.4% vs Last Month</span>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
                <div className="flex justify-between items-center text-xs text-[#4A5568]">
                  <span>Monthly Orders</span>
                  <Package className="w-4 h-4 text-[#2B4C7E]" />
                </div>
                <div className="font-serif text-3xl font-bold text-[#0F172A]">490</div>
                <div className="text-xs text-[#4A5568]">Avg Order Value: £80.61</div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
                <div className="flex justify-between items-center text-xs text-[#4A5568]">
                  <span>B2B Wholesale Accounts</span>
                  <Building2 className="w-4 h-4 text-[#C86D51]" />
                </div>
                <div className="font-serif text-3xl font-bold text-[#0F172A]">34</div>
                <div className="text-xs text-[#C86D51] font-semibold">Trade Accounts Active</div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
                <div className="flex justify-between items-center text-xs text-[#4A5568]">
                  <span>Customer Satisfaction</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="font-serif text-3xl font-bold text-[#0F172A]">4.95 / 5.0</div>
                <div className="text-xs text-[#4A5568]">Based on 148 Reviews</div>
              </div>

            </div>

            {/* Recharts Revenue Trend Chart */}
            <div className="bg-white p-6 rounded-3xl border border-[#E2DCD2] shadow-md space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#0F172A]">Monthly Sales Revenue Trajectory</h3>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData}>
                    <defs>
                      <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#1C4532" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#1C4532" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="month" stroke="#4A5568" fontSize={12} />
                    <YAxis stroke="#4A5568" fontSize={12} />
                    <Tooltip />
                    <Area type="monotone" dataKey="sales" stroke="#1C4532" fillOpacity={1} fill="url(#colorSales)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>
        )}

        {/* PRODUCTS MANAGEMENT TAB */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-3xl border border-[#E2DCD2] shadow-md overflow-hidden p-6 space-y-4">
            <h3 className="font-serif text-xl font-bold text-[#0F172A]">Store Product Inventory</h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#F6F4EF] border-b border-[#E2DCD2]">
                  <tr>
                    <th className="p-3 font-bold text-[#0F172A]">Product</th>
                    <th className="p-3 font-bold text-[#0F172A]">Category</th>
                    <th className="p-3 font-bold text-[#0F172A]">Origin</th>
                    <th className="p-3 font-bold text-[#0F172A]">Price</th>
                    <th className="p-3 font-bold text-[#0F172A]">Stock</th>
                    <th className="p-3 font-bold text-[#0F172A]">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.id} className="border-t border-[#E2DCD2]">
                      <td className="p-3 font-bold text-[#0F172A] flex items-center space-x-2">
                        <img src={p.images[0]} alt="p" className="w-8 h-8 rounded-lg object-cover" />
                        <span>{p.title}</span>
                      </td>
                      <td className="p-3 font-semibold text-[#4A5568]">{p.category}</td>
                      <td className="p-3 text-emerald-800 font-bold">{p.originTown}</td>
                      <td className="p-3 font-bold text-[#0F172A]">£{p.price.toFixed(2)}</td>
                      <td className="p-3">
                        <input
                          type="number"
                          value={p.stock}
                          onChange={(e) => updateProductStock(p.id, Number(e.target.value))}
                          className="w-16 border border-[#E2DCD2] rounded p-1 text-center font-bold"
                        />
                      </td>
                      <td className="p-3 text-emerald-700 font-bold">Active</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ANALYTICS TAB */}
        {activeTab === 'analytics' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-3xl border border-[#E2DCD2] shadow-md space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#0F172A]">Category Popularity Share</h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={categoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-[#E2DCD2] shadow-md space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#0F172A]">Regional Customer Orders</h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={revenueData}>
                    <XAxis dataKey="month" stroke="#4A5568" />
                    <YAxis stroke="#4A5568" />
                    <Tooltip />
                    <Bar dataKey="orders" fill="#2B4C7E" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 border border-[#E2DCD2] shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-[#E2DCD2] pb-3">
              <h3 className="font-serif font-bold text-[#0F172A] text-lg">List New Yorkshire Product</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                ×
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Product Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Handmade Sheffield Cutlery Set"
                  value={newProd.title}
                  onChange={(e) => setNewProd({ ...newProd, title: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                />
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Short Tagline</label>
                <input
                  type="text"
                  required
                  placeholder="Hand-ground in Sheffield"
                  value={newProd.tagline}
                  onChange={(e) => setNewProd({ ...newProd, tagline: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0F172A] mb-1">Category</label>
                  <select
                    value={newProd.category}
                    onChange={(e) => setNewProd({ ...newProd, category: e.target.value as any })}
                    className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                  >
                    {PRODUCT_CATEGORIES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#0F172A] mb-1">Origin Town</label>
                  <select
                    value={newProd.originTown}
                    onChange={(e) => setNewProd({ ...newProd, originTown: e.target.value as any })}
                    className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                  >
                    {YORKSHIRE_REGIONS.map((r) => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0F172A] mb-1">Price (£)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProd.price}
                    onChange={(e) => setNewProd({ ...newProd, price: Number(e.target.value) })}
                    className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[#0F172A] mb-1">Initial Stock</label>
                  <input
                    type="number"
                    value={newProd.stock}
                    onChange={(e) => setNewProd({ ...newProd, stock: Number(e.target.value) })}
                    className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#0F172A] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={newProd.description}
                  onChange={(e) => setNewProd({ ...newProd, description: e.target.value })}
                  className="w-full border border-[#E2DCD2] rounded-xl p-2.5"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1C4532] text-white py-3 rounded-xl font-bold hover:bg-[#153426]"
              >
                Publish Listing
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
