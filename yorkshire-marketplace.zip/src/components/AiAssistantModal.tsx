import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { Bot, X, Send, Sparkles, MapPin, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const AiAssistantModal: React.FC = () => {
  const { isAiModalOpen, setIsAiModalOpen, setSelectedProduct, products } = useMarketplace();
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: "Ey up! I'm Tyke, your Yorkshire Marketplace AI Concierge. Ask me for authentic local gift ideas, recommendations for Sheffield steel, artisan Wensleydale cheese, or regional manufacturers!"
    }
  ]);

  if (!isAiModalOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch('/api/ai-concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg })
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: data.reply || "I'd be glad to help you find local Yorkshire products!" }
      ]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: "Ey up! I had a quick glitch connecting to the concierge server. However, you can browse all Sheffield steel cutlery, Whitby jet, and Dales cheese directly in our product catalog!"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl max-w-lg w-full border border-[#E2DCD2] shadow-2xl overflow-hidden flex flex-col h-[550px]"
        >
          {/* Header */}
          <div className="p-4 bg-[#0F172A] text-white flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-[#1C4532] flex items-center justify-center text-amber-300">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-sm">Tyke — Yorkshire AI Concierge</h3>
                <p className="text-[10px] text-emerald-400 font-mono">POWERED_BY_GEMINI_2.5_FLASH</p>
              </div>
            </div>
            <button
              onClick={() => setIsAiModalOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#F6F4EF] text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl ${
                    m.role === 'user'
                      ? 'bg-[#1C4532] text-white rounded-tr-none font-medium'
                      : 'bg-white text-[#0F172A] border border-[#E2DCD2] rounded-tl-none shadow-xs font-sans leading-relaxed'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white text-[#4A5568] p-3 rounded-2xl border border-[#E2DCD2] text-xs animate-pulse">
                  Consulting Yorkshire directory...
                </div>
              </div>
            )}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} className="p-3 bg-white border-t border-[#E2DCD2] flex gap-2">
            <input
              type="text"
              placeholder="Ask for gift ideas, steel, cheese, or towns..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-[#F6F4EF] border border-[#E2DCD2] rounded-xl px-3.5 py-2.5 text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2B4C7E]"
            />
            <button
              type="submit"
              disabled={loading}
              className="bg-[#1C4532] text-white px-4 py-2.5 rounded-xl font-bold text-xs hover:bg-[#153426] transition-colors cursor-pointer flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
