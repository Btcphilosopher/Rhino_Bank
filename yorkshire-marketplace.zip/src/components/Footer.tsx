import React from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { MapPin, ShieldCheck, Heart, Store, FileCode2, ArrowRight } from 'lucide-react';
import { YORKSHIRE_REGIONS } from '../data/mockData';

export const Footer: React.FC = () => {
  const { setActiveView, setQuickRegion, setUserRole } = useMarketplace();

  return (
    <footer className="bg-[#1A1A1A] text-white border-t border-[#1A1A1A]">
      
      {/* Onboarding Callout Banner */}
      <div className="bg-[#D8D2C2]/20 border-b border-[#1A1A1A]/20 py-10 px-4 sm:px-6 lg:px-8 text-[#1A1A1A] bg-[#FAF9F6]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="font-serif font-black italic text-2xl sm:text-3xl text-[#1A1A1A]">
              Are you a Yorkshire business, maker or manufacturer?
            </h3>
            <p className="text-xs font-light text-[#555]">
              Join over 1,200 independent Yorkshire producers showcasing locally forged cutlery, artisan food, textiles, and engineering.
            </p>
          </div>

          <button
            onClick={() => {
              setUserRole('seller');
              setActiveView('seller_portal');
            }}
            className="bg-[#1A1A1A] text-white px-8 py-4 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-[#B87333] transition-colors shadow-md flex items-center space-x-2 shrink-0 cursor-pointer"
          >
            <Store className="w-4 h-4 text-[#B87333]" />
            <span>Open Yorkshire Storefront</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Links Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-12 gap-8 text-xs">
        
        {/* Brand Column */}
        <div className="md:col-span-4 space-y-4">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveView('home')}>
            <div className="w-10 h-10 bg-white text-[#1A1A1A] flex items-center justify-center font-serif text-2xl font-black border border-white">
              Y
            </div>
            <div>
              <span className="font-serif text-xl font-black text-white uppercase tracking-tight">Yorkshire Marketplace</span>
              <p className="text-[9px] text-[#B87333] font-bold uppercase tracking-[0.25em]">Regional Strength • Heritage</p>
            </div>
          </div>

          <p className="text-slate-400 font-light leading-relaxed">
            The definitive regional e-commerce platform dedicated to businesses, artisans, manufacturers, farms, and independent retailers across Yorkshire and the Humber.
          </p>

          <div className="pt-2 text-[#B87333] font-bold text-[10px] uppercase tracking-[0.2em] flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4" />
            <span>100% Certified Yorkshire Provenance</span>
          </div>
        </div>

        {/* Regions Column */}
        <div className="md:col-span-5 space-y-3">
          <h4 className="font-serif font-black italic text-white text-base text-[#B87333]">
            21 Yorkshire Towns & Regions
          </h4>
          <div className="flex flex-wrap gap-1.5 text-slate-300 text-[10px] font-bold tracking-wider uppercase">
            {YORKSHIRE_REGIONS.map((r) => (
              <button
                key={r}
                onClick={() => setQuickRegion(r)}
                className="hover:text-white hover:bg-[#B87333] cursor-pointer bg-[#252525] px-2.5 py-1 border border-white/10 transition-colors"
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Navigation Links Column */}
        <div className="md:col-span-3 space-y-3">
          <h4 className="font-serif font-black italic text-white text-base text-[#4682B4]">
            Platform Services
          </h4>
          <ul className="space-y-2 text-slate-400 text-[10px] font-bold uppercase tracking-[0.15em]">
            <li>
              <button onClick={() => setActiveView('directory')} className="hover:text-white cursor-pointer transition-colors">
                Product Catalog
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('map')} className="hover:text-white cursor-pointer transition-colors">
                GIS Interactive Regional Map
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('b2b')} className="hover:text-white cursor-pointer transition-colors">
                B2B Trade & Wholesale Hub
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('seller_portal')} className="hover:text-white cursor-pointer transition-colors">
                Seller Dashboard
              </button>
            </li>
            <li>
              <button onClick={() => setActiveView('docs')} className="hover:text-white cursor-pointer flex items-center space-x-1 text-[#B87333] transition-colors">
                <FileCode2 className="w-3.5 h-3.5" />
                <span>Technical Specs</span>
              </button>
            </li>
          </ul>
        </div>

      </div>

      {/* Bottom Legal Copyright Bar */}
      <div className="bg-[#111111] py-4 border-t border-white/10 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-2">
          <div>
            © {new Date().getFullYear()} Yorkshire Marketplace • Celebrating Northern Industrial Heritage & Innovation.
          </div>
          <div className="flex items-center space-x-4">
            <span>WCAG AA Accessible</span>
            <span>•</span>
            <span className="text-[#B87333]">Local Business. Regional Strength.</span>
          </div>
        </div>
      </div>

    </footer>
  );
};
