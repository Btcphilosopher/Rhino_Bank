import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import {
  X,
  Star,
  ShoppingBag,
  Heart,
  MapPin,
  CheckCircle2,
  Building2,
  Truck,
  ShieldCheck,
  Clock,
  ArrowRight,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ProductDetailModal: React.FC = () => {
  const { selectedProduct, setSelectedProduct, addToCart, toggleWishlist, wishlist, businesses, setSelectedBusiness, reviews } = useMarketplace();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'specs' | 'b2b' | 'reviews'>('specs');

  if (!selectedProduct) return null;

  const isWishlisted = wishlist.includes(selectedProduct.id);
  const business = businesses.find((b) => b.id === selectedProduct.businessId);
  const productReviews = reviews.filter((r) => r.productId === selectedProduct.id);

  const handleSellerClick = () => {
    if (business) {
      setSelectedBusiness(business);
      setSelectedProduct(null);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-[#E2DCD2] shadow-2xl p-6 sm:p-8 space-y-6"
        >
          {/* Close Button */}
          <button
            onClick={() => setSelectedProduct(null)}
            className="absolute top-5 right-5 p-2 text-[#4A5568] hover:text-[#0F172A] hover:bg-[#F6F4EF] rounded-full transition-colors cursor-pointer z-10"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            
            {/* Left: Gallery */}
            <div className="md:col-span-6 space-y-4">
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-[#F6F4EF] border border-[#E2DCD2]">
                <img
                  src={selectedProduct.images[selectedImageIndex] || selectedProduct.images[0]}
                  alt={selectedProduct.title}
                  className="w-full h-full object-cover"
                />

                <span className="absolute top-3 left-3 bg-[#1C4532]/90 backdrop-blur-md text-emerald-200 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Made in {selectedProduct.originTown}
                </span>

                <button
                  onClick={() => toggleWishlist(selectedProduct.id)}
                  className={`absolute top-3 right-3 p-2.5 rounded-full backdrop-blur-md cursor-pointer ${
                    isWishlisted ? 'bg-[#C86D51] text-white' : 'bg-white/80 text-[#0F172A]'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Thumbnails */}
              {selectedProduct.images.length > 1 && (
                <div className="flex space-x-3 overflow-x-auto pb-1">
                  {selectedProduct.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 cursor-pointer ${
                        selectedImageIndex === idx ? 'border-[#2B4C7E]' : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="thumb" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Mini Seller Card */}
              {business && (
                <div
                  onClick={handleSellerClick}
                  className="p-4 bg-[#F6F4EF] rounded-2xl border border-[#E2DCD2] hover:border-[#2B4C7E] transition-colors cursor-pointer flex items-center space-x-4"
                >
                  <img
                    src={business.logo}
                    alt={business.name}
                    className="w-12 h-12 rounded-xl object-cover border border-[#E2DCD2]"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-1.5 text-xs font-bold text-[#0F172A]">
                      <span className="truncate">{business.name}</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    </div>
                    <div className="text-xs text-[#4A5568] flex items-center space-x-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-[#C86D51]" />
                      <span>{business.town} • Est. {business.yearEstablished}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#2B4C7E]" />
                </div>
              )}
            </div>

            {/* Right: Product Details & Purchase Actions */}
            <div className="md:col-span-6 space-y-5">
              
              <div>
                <div className="flex items-center space-x-2 text-xs font-semibold text-[#C86D51] uppercase tracking-wider">
                  <span>{selectedProduct.category}</span>
                  <span>•</span>
                  <span>{selectedProduct.originTown}, Yorkshire</span>
                </div>

                <h1 className="font-serif text-2xl font-bold text-[#0F172A] mt-1 leading-snug">
                  {selectedProduct.title}
                </h1>

                <div className="flex items-center space-x-3 mt-2 text-xs text-[#4A5568]">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="font-bold text-[#0F172A]">{selectedProduct.rating}</span>
                    <span>({selectedProduct.reviewCount} Reviews)</span>
                  </div>
                  <span>•</span>
                  <span className="text-emerald-700 font-semibold flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>In Stock ({selectedProduct.stock} available)</span>
                  </span>
                </div>
              </div>

              {/* Price Row */}
              <div className="p-4 bg-[#F6F4EF] rounded-2xl border border-[#E2DCD2] flex items-center justify-between">
                <div>
                  <div className="text-xs text-[#4A5568]">Retail Unit Price</div>
                  <div className="font-serif text-3xl font-bold text-[#0F172A]">
                    £{selectedProduct.price.toFixed(2)}
                  </div>
                </div>
                {selectedProduct.originalPrice && (
                  <div className="text-right">
                    <div className="text-xs text-[#4A5568]">Was</div>
                    <div className="text-sm font-semibold text-[#4A5568] line-through">
                      £{selectedProduct.originalPrice.toFixed(2)}
                    </div>
                  </div>
                )}
              </div>

              <p className="text-sm text-[#4A5568] font-sans leading-relaxed">
                {selectedProduct.description}
              </p>

              {/* Quantity and Add to Cart Actions */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center space-x-3">
                  <span className="text-xs font-bold text-[#0F172A] uppercase">Quantity:</span>
                  <div className="flex items-center border border-[#E2DCD2] rounded-xl overflow-hidden bg-[#F6F4EF]">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1.5 font-bold hover:bg-[#E2DCD2] text-sm"
                    >
                      -
                    </button>
                    <span className="px-4 py-1.5 text-sm font-bold text-[#0F172A]">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-1.5 font-bold hover:bg-[#E2DCD2] text-sm"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-xs text-[#4A5568]">
                    Subtotal: <strong>£{(selectedProduct.price * quantity).toFixed(2)}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      addToCart(selectedProduct, quantity);
                      setSelectedProduct(null);
                    }}
                    className="w-full bg-[#1C4532] text-white py-3 rounded-xl font-semibold text-sm hover:bg-[#153426] transition-colors shadow-sm flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Yorkshire Cart</span>
                  </button>

                  {selectedProduct.isB2bAvailable && (
                    <button
                      onClick={handleSellerClick}
                      className="w-full bg-[#2B4C7E] text-white py-3 rounded-xl font-semibold text-sm hover:bg-[#1E3A63] transition-colors shadow-sm flex items-center justify-center space-x-2 cursor-pointer"
                    >
                      <Building2 className="w-4 h-4" />
                      <span>Request B2B Quote</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Delivery Guarantees */}
              <div className="grid grid-cols-2 gap-3 text-xs text-[#4A5568] pt-3 border-t border-[#E2DCD2]">
                <div className="flex items-center space-x-2">
                  <Truck className="w-4 h-4 text-[#C86D51]" />
                  <span>Ships in {selectedProduct.leadTimeDays} business days</span>
                </div>
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>100% Guaranteed Local Quality</span>
                </div>
              </div>

            </div>

          </div>

          {/* Bottom Tabs: Specs, B2B Tiered Prices, Reviews */}
          <div className="pt-6 border-t border-[#E2DCD2]">
            <div className="flex space-x-6 border-b border-[#E2DCD2] text-sm font-semibold">
              <button
                onClick={() => setActiveTab('specs')}
                className={`pb-2 border-b-2 cursor-pointer ${
                  activeTab === 'specs' ? 'border-[#2B4C7E] text-[#0F172A]' : 'border-transparent text-[#4A5568]'
                }`}
              >
                Specifications
              </button>

              {selectedProduct.isB2bAvailable && (
                <button
                  onClick={() => setActiveTab('b2b')}
                  className={`pb-2 border-b-2 cursor-pointer ${
                    activeTab === 'b2b' ? 'border-[#2B4C7E] text-[#0F172A]' : 'border-transparent text-[#4A5568]'
                  }`}
                >
                  B2B Trade Pricing
                </button>
              )}

              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-2 border-b-2 cursor-pointer ${
                  activeTab === 'reviews' ? 'border-[#2B4C7E] text-[#0F172A]' : 'border-transparent text-[#4A5568]'
                }`}
              >
                Reviews ({productReviews.length})
              </button>
            </div>

            <div className="pt-4 text-xs">
              {activeTab === 'specs' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {selectedProduct.specs.map((s, idx) => (
                    <div key={idx} className="flex justify-between p-2.5 bg-[#F6F4EF] rounded-lg">
                      <span className="font-semibold text-[#4A5568]">{s.name}:</span>
                      <span className="font-bold text-[#0F172A]">{s.value}</span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'b2b' && selectedProduct.b2bTierPrices && (
                <div className="space-y-3">
                  <p className="text-[#4A5568]">Wholesale discount tiers for trade accounts:</p>
                  <div className="border border-[#E2DCD2] rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead className="bg-[#F6F4EF]">
                        <tr>
                          <th className="p-2.5 font-bold text-[#0F172A]">Minimum Order Qty</th>
                          <th className="p-2.5 font-bold text-[#0F172A]">Price Per Unit</th>
                          <th className="p-2.5 font-bold text-[#0F172A]">Savings</th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedProduct.b2bTierPrices.map((tier, idx) => (
                          <tr key={idx} className="border-t border-[#E2DCD2]">
                            <td className="p-2.5 font-semibold text-[#0F172A]">{tier.minQty}+ units</td>
                            <td className="p-2.5 font-bold text-[#1C4532]">£{tier.pricePerUnit.toFixed(2)}</td>
                            <td className="p-2.5 text-[#C86D51] font-semibold">
                              {Math.round(((selectedProduct.price - tier.pricePerUnit) / selectedProduct.price) * 100)}% OFF
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-3">
                  {productReviews.length === 0 ? (
                    <p className="text-[#4A5568]">No customer reviews yet for this product.</p>
                  ) : (
                    productReviews.map((rev) => (
                      <div key={rev.id} className="p-3 bg-[#F6F4EF] rounded-xl space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-[#0F172A]">{rev.authorName} ({rev.authorTown})</span>
                          <span className="text-[#4A5568]">{rev.date}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-amber-400">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-current" />
                          ))}
                        </div>
                        <p className="font-semibold text-[#0F172A] mt-1">{rev.title}</p>
                        <p className="text-[#4A5568]">{rev.comment}</p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
