import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { ProductGrid } from './ProductGrid';
import { YORKSHIRE_REGIONS } from '../data/mockData';
import { MapPin, Building2, Store, CheckCircle2, ChevronRight, Filter } from 'lucide-react';

export const RegionalDirectory: React.FC = () => {
  const { businesses, setSelectedBusiness, setQuickRegion, filters } = useMarketplace();
  const [activeTab, setActiveTab] = useState<'products' | 'businesses'>('products');

  return (
    <div className="bg-[#FAF9F6] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Directory Header Banner */}
        <div className="bg-white p-8 border border-[#1A1A1A]/15 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#B87333]">
              Yorkshire Regional Directory
            </span>
            <h1 className="font-serif font-black italic text-3xl sm:text-4xl text-[#1A1A1A]">
              Explore Local Enterprise Across Yorkshire & The Humber
            </h1>
            <p className="text-xs text-[#555] max-w-2xl font-light">
              Discover verified independent makers, steel fabricators, farm shops, and master joiners operating in all 21 Yorkshire towns and national parks.
            </p>
          </div>

          {/* Toggle View Mode Tab */}
          <div className="flex bg-[#FAF9F6] p-1.5 border border-[#1A1A1A]/15 text-[10px] font-bold tracking-[0.15em] uppercase shrink-0">
            <button
              onClick={() => setActiveTab('products')}
              className={`px-5 py-2.5 transition-all cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-[#1A1A1A] text-white'
                  : 'text-[#555] hover:text-[#1A1A1A]'
              }`}
            >
              Catalog Products
            </button>

            <button
              onClick={() => setActiveTab('businesses')}
              className={`px-5 py-2.5 transition-all cursor-pointer ${
                activeTab === 'businesses'
                  ? 'bg-[#1A1A1A] text-white'
                  : 'text-[#555] hover:text-[#1A1A1A]'
              }`}
            >
              Business Directory ({businesses.length})
            </button>
          </div>
        </div>

        {/* Content View */}
        {activeTab === 'products' ? (
          <ProductGrid />
        ) : (
          <div className="space-y-6">
            
            {/* Quick Town Filter Pills */}
            <div className="bg-white p-4 border border-[#1A1A1A]/15 flex flex-wrap gap-2 text-[10px] font-bold tracking-[0.15em] uppercase">
              <span className="text-[#1A1A1A] py-1">Filter Town:</span>
              <button
                onClick={() => setQuickRegion('All')}
                className={`px-3 py-1 cursor-pointer transition-colors ${
                  filters.region === 'All' ? 'bg-[#1A1A1A] text-white' : 'bg-[#FAF9F6] text-[#555] hover:bg-[#B87333] hover:text-white border border-[#1A1A1A]/10'
                }`}
              >
                All Towns
              </button>
              {YORKSHIRE_REGIONS.map((town) => (
                <button
                  key={town}
                  onClick={() => setQuickRegion(town)}
                  className={`px-3 py-1 cursor-pointer transition-colors ${
                    filters.region === town ? 'bg-[#1A1A1A] text-white' : 'bg-[#FAF9F6] text-[#555] hover:bg-[#B87333] hover:text-white border border-[#1A1A1A]/10'
                  }`}
                >
                  {town}
                </button>
              ))}
            </div>

            {/* Businesses Directory Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {businesses
                .filter((b) => filters.region === 'All' || b.town === filters.region)
                .map((b) => (
                  <div
                    key={b.id}
                    onClick={() => setSelectedBusiness(b)}
                    className="group bg-white p-6 border border-[#1A1A1A]/15 hover:border-[#1A1A1A] transition-all cursor-pointer flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <img
                          src={b.logo}
                          alt={b.name}
                          className="w-14 h-14 object-cover border border-[#1A1A1A]/15"
                        />
                        <span className="bg-[#1A1A1A] text-white text-[9px] font-bold px-2.5 py-1 uppercase tracking-[0.2em]">
                          {b.town}
                        </span>
                      </div>

                      <div>
                        <h3 className="font-serif font-bold text-[#1A1A1A] text-lg group-hover:text-[#B87333] transition-colors flex items-center gap-1.5">
                          <span>{b.name}</span>
                          <CheckCircle2 className="w-4 h-4 text-[#B87333] shrink-0" />
                        </h3>
                        <p className="text-[10px] text-[#B87333] font-bold uppercase tracking-[0.2em] mt-0.5">{b.type}</p>
                      </div>

                      <p className="text-xs text-[#555] font-light line-clamp-2">{b.description}</p>
                    </div>

                    <div className="pt-3 border-t border-[#1A1A1A]/10 flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.2em] text-[#1A1A1A] group-hover:text-[#B87333] transition-colors">
                      <span>Visit Storefront</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                ))}
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
