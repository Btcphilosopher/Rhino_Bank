import React from 'react';
import { Product } from '../types';
import { useMarketplace } from '../context/MarketplaceContext';
import { Star, MapPin, ShoppingBag, Heart, Building2, CheckCircle2 } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, wishlist, toggleWishlist, setSelectedProduct, setSelectedBusiness, businesses } = useMarketplace();
  const isWishlisted = wishlist.includes(product.id);

  const business = businesses.find((b) => b.id === product.businessId);

  const handleOpenProduct = () => {
    setSelectedProduct(product);
  };

  const handleOpenBusiness = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (business) {
      setSelectedBusiness(business);
    }
  };

  return (
    <div
      onClick={handleOpenProduct}
      className="group bg-white border border-[#1A1A1A]/15 overflow-hidden hover:border-[#1A1A1A] transition-all duration-300 flex flex-col cursor-pointer relative"
    >
      {/* Product Image Container */}
      <div className="relative aspect-4/3 overflow-hidden bg-[#FAF9F6]">
        <img
          src={product.images[0]}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
          <span className="bg-[#1A1A1A] text-white text-[9px] font-bold px-2.5 py-1 uppercase tracking-[0.2em]">
            {product.originTown}
          </span>
          {product.badges && product.badges[0] && (
            <span className="bg-[#B87333] text-white text-[9px] font-bold px-2.5 py-1 uppercase tracking-[0.2em]">
              {product.badges[0]}
            </span>
          )}
        </div>

        {/* Wishlist Toggle Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-3 right-3 p-2 backdrop-blur-md transition-all z-10 cursor-pointer ${
            isWishlisted
              ? 'bg-[#B87333] text-white'
              : 'bg-white/80 text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white'
          }`}
          title="Save to Wishlist"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* B2B Badge */}
        {product.isB2bAvailable && (
          <div className="absolute bottom-3 left-3 bg-[#4682B4] text-white text-[9px] font-bold uppercase tracking-[0.2em] px-2.5 py-1 flex items-center space-x-1">
            <Building2 className="w-3 h-3 text-white" />
            <span>B2B Trade</span>
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        
        <div className="space-y-2">
          {/* Seller Name Link */}
          <div className="flex items-center justify-between text-xs">
            <button
              onClick={handleOpenBusiness}
              className="text-[#555] hover:text-[#B87333] font-bold text-[10px] uppercase tracking-[0.15em] flex items-center space-x-1 text-left truncate transition-colors"
            >
              <span>{product.businessName}</span>
              <CheckCircle2 className="w-3 h-3 text-[#B87333] inline shrink-0" />
            </button>
            <span className="text-[10px] text-[#B87333] font-bold uppercase tracking-[0.2em]">{product.category}</span>
          </div>

          {/* Title */}
          <h3 className="font-serif font-bold text-[#1A1A1A] text-lg group-hover:text-[#B87333] transition-colors line-clamp-2 leading-snug">
            {product.title}
          </h3>

          <p className="text-xs text-[#666] line-clamp-2 font-light">
            {product.tagline || product.description}
          </p>
        </div>

        {/* Footer Rating & Price Row */}
        <div className="pt-3 border-t border-[#1A1A1A]/10 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1 text-xs">
              <Star className="w-3.5 h-3.5 fill-[#B87333] text-[#B87333]" />
              <span className="font-bold text-[#1A1A1A]">{product.rating}</span>
              <span className="text-[#666]">({product.reviewCount})</span>
            </div>
            
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="font-serif text-xl font-black text-[#B87333]">
                £{product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-[#888] line-through">
                  £{product.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product);
            }}
            className="p-3 bg-[#1A1A1A] text-white hover:bg-[#B87333] transition-colors flex items-center justify-center cursor-pointer"
            title="Add to Yorkshire Cart"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
