import React, { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import {
  ShieldCheck,
  Building2,
  Users,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  BarChart2,
  Lock,
  ArrowUpRight
} from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const { businesses, products, showToast } = useMarketplace();
  const [pendingBusinesses, setPendingBusinesses] = useState([
    {
      id: 'pending-1',
      name: 'Rotherham Precision Hydraulic Fittings',
      town: 'Rotherham',
      type: 'Industrial Supplier',
      applicant: 'David Miller',
      dateSubmitted: '2026-08-03',
      isoCertified: true
    },
    {
      id: 'pending-2',
      name: 'Wakefield Rhubarb Preserves & Honey',
      town: 'Wakefield',
      type: 'Farm & Produce',
      applicant: 'Sarah Briggs',
      dateSubmitted: '2026-08-04',
      isoCertified: false
    }
  ]);

  const handleApproveBusiness = (id: string, name: string) => {
    setPendingBusinesses((prev) => prev.filter((b) => b.id !== id));
    showToast(`Approved "${name}" as a Certified Yorkshire Business!`);
  };

  return (
    <div className="bg-[#FAFA3] min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Admin Header */}
        <div className="bg-[#0F172A] text-white p-8 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-amber-300">
              <ShieldCheck className="w-4 h-4" />
              <span>Yorkshire Marketplace Platform Administration</span>
            </div>
            <h1 className="font-serif text-3xl font-bold">
              Marketplace Operations & Verification Center
            </h1>
            <p className="text-xs text-slate-300 max-w-xl">
              Audit regional seller applications, manage "Made in Yorkshire" badge verifications, monitor system health, and enforce compliance policies.
            </p>
          </div>

          <span className="bg-[#1C4532] text-emerald-300 text-xs font-mono font-bold px-4 py-2 rounded-xl border border-emerald-500/30">
            SYSTEM_STATUS: HEALTHY 99.98%
          </span>
        </div>

        {/* System Overview Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-xs">
          <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
            <span className="text-[#4A5568] uppercase font-bold">Verified Businesses</span>
            <div className="font-serif text-3xl font-bold text-[#0F172A]">{businesses.length} Active</div>
            <div className="text-emerald-700 font-semibold flex items-center space-x-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>100% Provenance Checked</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
            <span className="text-[#4A5568] uppercase font-bold">Active Catalog Items</span>
            <div className="font-serif text-3xl font-bold text-[#0F172A]">{products.length} Products</div>
            <div className="text-[#2B4C7E] font-semibold">21 Regions Covered</div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
            <span className="text-[#4A5568] uppercase font-bold">Pending Applications</span>
            <div className="font-serif text-3xl font-bold text-amber-600">{pendingBusinesses.length} Pending</div>
            <div className="text-slate-500">Requires Manual Review</div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2DCD2] shadow-xs space-y-2">
            <span className="text-[#4A5568] uppercase font-bold">Platform Trade Volume</span>
            <div className="font-serif text-3xl font-bold text-[#1C4532]">£14.8M / yr</div>
            <div className="text-emerald-700 font-semibold flex items-center space-x-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>+24.2% YoY Regional Growth</span>
            </div>
          </div>
        </div>

        {/* Pending Business Applications Moderation */}
        <div className="bg-white rounded-3xl border border-[#E2DCD2] shadow-md p-6 space-y-4">
          <h2 className="font-serif text-xl font-bold text-[#0F172A] flex items-center space-x-2">
            <FileCheck className="w-5 h-5 text-[#2B4C7E]" />
            <span>Pending "Made in Yorkshire" Business Verification Queue</span>
          </h2>

          {pendingBusinesses.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#4A5568] bg-[#F6F4EF] rounded-2xl">
              All business applications have been audited and verified.
            </div>
          ) : (
            <div className="space-y-3 text-xs">
              {pendingBusinesses.map((b) => (
                <div
                  key={b.id}
                  className="p-4 bg-[#F6F4EF] rounded-2xl border border-[#E2DCD2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="font-serif font-bold text-[#0F172A] text-base">{b.name}</div>
                    <div className="text-[#4A5568] space-x-2">
                      <span>Town: <strong>{b.town}</strong></span>
                      <span>•</span>
                      <span>Category: <strong>{b.type}</strong></span>
                      <span>•</span>
                      <span>Applicant: <strong>{b.applicant}</strong></span>
                    </div>
                  </div>

                  <div className="flex gap-2 w-full sm:w-auto">
                    <button
                      onClick={() => handleApproveBusiness(b.id, b.name)}
                      className="flex-1 sm:flex-none bg-[#1C4532] text-white px-4 py-2 rounded-xl font-bold hover:bg-[#153426] transition-colors cursor-pointer"
                    >
                      Approve & Grant Badge
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
