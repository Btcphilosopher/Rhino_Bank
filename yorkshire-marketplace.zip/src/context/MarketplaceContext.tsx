import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Business,
  CartItem,
  Order,
  B2BQuoteRequest,
  FilterState,
  YorkshireRegion,
  ProductCategory,
  UserRole,
  Review
} from '../types';
import { MOCK_BUSINESSES, MOCK_PRODUCTS, MOCK_REVIEWS } from '../data/mockData';

interface Toast {
  id: string;
  type: 'success' | 'info' | 'error';
  message: string;
}

interface MarketplaceContextType {
  // Navigation & Active View State
  activeView: 'home' | 'directory' | 'map' | 'b2b' | 'seller_portal' | 'admin_portal' | 'docs';
  setActiveView: (view: 'home' | 'directory' | 'map' | 'b2b' | 'seller_portal' | 'admin_portal' | 'docs') => void;
  
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;

  // Selected Detail Views
  selectedBusiness: Business | null;
  setSelectedBusiness: (biz: Business | null) => void;
  
  selectedProduct: Product | null;
  setSelectedProduct: (prod: Product | null) => void;

  // Filter State
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  setQuickRegion: (region: YorkshireRegion | 'All') => void;
  setQuickCategory: (category: ProductCategory | 'All') => void;

  // Data Collections
  businesses: Business[];
  products: Product[];
  reviews: Review[];

  // Cart & Wishlist
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  
  wishlist: string[]; // Product IDs
  toggleWishlist: (productId: string) => void;

  // Orders & B2B
  orders: Order[];
  placeOrder: (order: Omit<Order, 'id' | 'date' | 'status'>) => Order;
  
  b2bQuotes: B2BQuoteRequest[];
  submitB2BQuote: (quote: Omit<B2BQuoteRequest, 'id' | 'dateSubmitted' | 'status'>) => void;

  // Seller Dashboard helpers
  addNewProduct: (product: Omit<Product, 'id' | 'rating' | 'reviewCount'>) => void;
  updateProductStock: (productId: string, stock: number) => void;

  // AI Concierge Drawer
  isAiModalOpen: boolean;
  setIsAiModalOpen: (open: boolean) => void;

  // Toasts
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'info' | 'error') => void;
  removeToast: (id: string) => void;
}

const initialFilterState: FilterState = {
  searchQuery: '',
  category: 'All',
  region: 'All',
  businessType: 'All',
  minPrice: 0,
  maxPrice: 2000,
  verifiedOnly: false,
  b2bOnly: false,
  sortBy: 'featured'
};

const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

export const MarketplaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<'home' | 'directory' | 'map' | 'b2b' | 'seller_portal' | 'admin_portal' | 'docs'>('home');
  const [userRole, setUserRole] = useState<UserRole>('customer');
  
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [filters, setFilters] = useState<FilterState>(initialFilterState);

  const [businesses] = useState<Business[]>(MOCK_BUSINESSES);
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [reviews] = useState<Review[]>(MOCK_REVIEWS);

  // Cart & Wishlist persistence in localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ym_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('ym_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);

  const [orders, setOrders] = useState<Order[]>([]);
  const [b2bQuotes, setB2bQuotes] = useState<B2BQuoteRequest[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem('ym_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('ym_wishlist', JSON.stringify(wishlist));
    } catch (e) {
      console.error(e);
    }
  }, [wishlist]);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const resetFilters = () => {
    setFilters(initialFilterState);
  };

  const setQuickRegion = (region: YorkshireRegion | 'All') => {
    setFilters((prev) => ({ ...prev, region }));
    if (activeView !== 'home' && activeView !== 'directory') {
      setActiveView('directory');
    }
  };

  const setQuickCategory = (category: ProductCategory | 'All') => {
    setFilters((prev) => ({ ...prev, category }));
    if (activeView !== 'home' && activeView !== 'directory') {
      setActiveView('directory');
    }
  };

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(`Added "${product.title}" to your Yorkshire cart!`);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Item removed from cart', 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from wishlist', 'info');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to your Yorkshire Wishlist!');
        return [...prev, productId];
      }
    });
  };

  const placeOrder = (orderData: Omit<Order, 'id' | 'date' | 'status'>): Order => {
    const newOrder: Order = {
      ...orderData,
      id: `YM-ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString().split('T')[0],
      status: 'Processing'
    };
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    showToast(`Order ${newOrder.id} confirmed! Invoice generated.`);
    return newOrder;
  };

  const submitB2BQuote = (quoteData: Omit<B2BQuoteRequest, 'id' | 'dateSubmitted' | 'status'>) => {
    const newQuote: B2BQuoteRequest = {
      ...quoteData,
      id: `YM-B2B-${Math.floor(100000 + Math.random() * 900000)}`,
      dateSubmitted: new Date().toISOString().split('T')[0],
      status: 'Pending'
    };
    setB2bQuotes((prev) => [newQuote, ...prev]);
    showToast(`B2B Quote Request ${newQuote.id} submitted to regional suppliers!`);
  };

  const addNewProduct = (productData: Omit<Product, 'id' | 'rating' | 'reviewCount'>) => {
    const newProduct: Product = {
      ...productData,
      id: `prod-${Math.random().toString(36).substr(2, 9)}`,
      rating: 5.0,
      reviewCount: 0
    };
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`Product "${newProduct.title}" created successfully!`);
  };

  const updateProductStock = (productId: string, stock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock } : p))
    );
    showToast(`Inventory updated for product`, 'info');
  };

  return (
    <MarketplaceContext.Provider
      value={{
        activeView,
        setActiveView,
        userRole,
        setUserRole,
        selectedBusiness,
        setSelectedBusiness,
        selectedProduct,
        setSelectedProduct,
        filters,
        setFilters,
        resetFilters,
        setQuickRegion,
        setQuickCategory,
        businesses,
        products,
        reviews,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        wishlist,
        toggleWishlist,
        orders,
        placeOrder,
        b2bQuotes,
        submitB2BQuote,
        addNewProduct,
        updateProductStock,
        isAiModalOpen,
        setIsAiModalOpen,
        toasts,
        showToast,
        removeToast
      }}
    >
      {children}
    </MarketplaceContext.Provider>
  );
};

export const useMarketplace = () => {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error('useMarketplace must be used within a MarketplaceProvider');
  }
  return context;
};
