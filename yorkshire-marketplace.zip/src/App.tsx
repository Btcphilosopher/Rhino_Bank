import React from 'react';
import { MarketplaceProvider, useMarketplace } from './context/MarketplaceContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { RegionalQuickBar } from './components/RegionalQuickBar';
import { ProductGrid } from './components/ProductGrid';
import { RegionalDirectory } from './components/RegionalDirectory';
import { RegionalMap } from './components/RegionalMap';
import { B2BHub } from './components/B2BHub';
import { SellerPortal } from './components/SellerPortal';
import { AdminPortal } from './components/AdminPortal';
import { BusinessProfileView } from './components/BusinessProfileView';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { AiAssistantModal } from './components/AiAssistantModal';
import { DocsModal } from './components/DocsModal';
import { ToastContainer } from './components/ToastContainer';
import { Footer } from './components/Footer';
import { Award, ShieldCheck, Factory, Heart, Building2, Sparkles, MapPin } from 'lucide-react';

const MarketplaceContent: React.FC = () => {
  const { activeView, selectedBusiness } = useMarketplace();

  // If a specific business profile storefront is being viewed, render BusinessProfileView
  if (selectedBusiness) {
    return (
      <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-[#1A1A1A] font-sans antialiased">
        <Header />
        <main className="flex-1">
          <BusinessProfileView />
        </main>
        <ProductDetailModal />
        <CartDrawer />
        <AiAssistantModal />
        <ToastContainer />
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-[#1A1A1A] font-sans antialiased">
      <Header />

      <main className="flex-1">
        {activeView === 'home' && (
          <>
            <Hero />
            <RegionalQuickBar />

            {/* Featured Yorkshire Spotlights */}
            <section className="py-16 bg-[#FAF9F6] border-b border-[#1A1A1A]/10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
                <div className="text-center max-w-2xl mx-auto space-y-3">
                  <div className="flex items-center justify-center space-x-3 text-[#B87333]">
                    <span className="w-8 h-[1px] bg-[#B87333]"></span>
                    <span className="text-[10px] font-bold uppercase tracking-[0.3em]">
                      Regional Excellence
                    </span>
                    <span className="w-8 h-[1px] bg-[#B87333]"></span>
                  </div>
                  <h2 className="font-serif font-black italic text-3xl sm:text-5xl text-[#1A1A1A]">
                    Crafted, Forged & Grown in Yorkshire
                  </h2>
                  <p className="text-xs text-[#555] font-light">
                    Explore authentic goods from independent businesses across Leeds, Sheffield, York, Whitby, and the Yorkshire Dales.
                  </p>
                </div>

                <ProductGrid />
              </div>
            </section>
          </>
        )}

        {activeView === 'directory' && <RegionalDirectory />}
        {activeView === 'map' && <RegionalMap />}
        {activeView === 'b2b' && <B2BHub />}
        {activeView === 'seller_portal' && <SellerPortal />}
        {activeView === 'admin_portal' && <AdminPortal />}
        {activeView === 'docs' && <DocsModal />}
      </main>

      {/* Global Modals & Notifications */}
      <ProductDetailModal />
      <CartDrawer />
      <AiAssistantModal />
      <ToastContainer />

      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <MarketplaceProvider>
      <MarketplaceContent />
    </MarketplaceProvider>
  );
}
