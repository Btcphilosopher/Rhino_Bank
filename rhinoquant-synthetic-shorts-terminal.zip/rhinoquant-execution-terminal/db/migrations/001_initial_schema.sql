-- ==============================================================================
-- RhinoQuant Execution Terminal — PostgreSQL Authoritative Schema Migration
-- Migration: 001_initial_schema.sql
-- ==============================================================================

CREATE TABLE IF NOT EXISTS instruments (
    id VARCHAR(64) PRIMARY KEY,
    symbol VARCHAR(32) NOT NULL,
    underlying VARCHAR(16) NOT NULL,
    asset_class VARCHAR(32) NOT NULL,
    contract_type VARCHAR(16) NOT NULL,
    expiry_date DATE NOT NULL,
    strike NUMERIC(14, 4) NOT NULL,
    option_type VARCHAR(8) NOT NULL,
    multiplier INTEGER NOT NULL DEFAULT 100,
    tick_size NUMERIC(8, 4) NOT NULL DEFAULT 0.01,
    currency VARCHAR(8) NOT NULL DEFAULT 'USD',
    settlement_type VARCHAR(16) NOT NULL DEFAULT 'PHYSICAL',
    exercise_style VARCHAR(16) NOT NULL DEFAULT 'AMERICAN',
    trading_venue VARCHAR(32) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(64) PRIMARY KEY,
    client_order_id VARCHAR(64) NOT NULL UNIQUE,
    book_id VARCHAR(32) NOT NULL,
    underlying VARCHAR(16) NOT NULL,
    strategy_type VARCHAR(32) NOT NULL DEFAULT 'SYNTHETIC_SHORT',
    status VARCHAR(32) NOT NULL,
    order_type VARCHAR(32) NOT NULL,
    net_limit_price NUMERIC(14, 4) NOT NULL,
    quantity INTEGER NOT NULL,
    time_in_force VARCHAR(16) NOT NULL,
    risk_decision VARCHAR(32),
    rejection_message TEXT,
    idempotency_key VARCHAR(128) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_legs (
    id BIGSERIAL PRIMARY KEY,
    order_id VARCHAR(64) NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    instrument_id VARCHAR(64) NOT NULL REFERENCES instruments(id),
    leg_index INTEGER NOT NULL,
    side VARCHAR(8) NOT NULL,
    option_type VARCHAR(8) NOT NULL,
    strike NUMERIC(14, 4) NOT NULL,
    expiry_date DATE NOT NULL,
    multiplier INTEGER NOT NULL DEFAULT 100,
    limit_price NUMERIC(14, 4) NOT NULL,
    filled_quantity INTEGER NOT NULL DEFAULT 0,
    avg_fill_price NUMERIC(14, 4) NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS executions (
    execution_id VARCHAR(64) PRIMARY KEY,
    client_order_id VARCHAR(64) NOT NULL,
    broker_order_id VARCHAR(64) NOT NULL,
    instrument_id VARCHAR(64) NOT NULL REFERENCES instruments(id),
    underlying VARCHAR(16) NOT NULL,
    side VARCHAR(8) NOT NULL,
    filled_qty INTEGER NOT NULL,
    fill_price NUMERIC(14, 4) NOT NULL,
    fee NUMERIC(10, 4) NOT NULL DEFAULT 0.65,
    venue VARCHAR(32) NOT NULL,
    liquidity_flag VARCHAR(16) NOT NULL,
    executed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS positions (
    instrument_id VARCHAR(64) PRIMARY KEY REFERENCES instruments(id),
    underlying VARCHAR(16) NOT NULL,
    book_id VARCHAR(32) NOT NULL DEFAULT 'ALPHA_HEDGE_BOOK',
    strategy_tag VARCHAR(32) NOT NULL DEFAULT 'SYNTHETIC_SHORT',
    quantity INTEGER NOT NULL,
    avg_cost NUMERIC(14, 4) NOT NULL,
    current_market_price NUMERIC(14, 4) NOT NULL,
    multiplier INTEGER NOT NULL DEFAULT 100,
    realized_pnl NUMERIC(16, 4) NOT NULL DEFAULT 0.0,
    delta_equivalent NUMERIC(14, 4) NOT NULL DEFAULT 0.0,
    margin_requirement NUMERIC(16, 4) NOT NULL DEFAULT 0.0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reconciliation_exceptions (
    id VARCHAR(64) PRIMARY KEY,
    run_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    instrument VARCHAR(64) NOT NULL,
    entity_type VARCHAR(32) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    internal_value TEXT NOT NULL,
    provider_value TEXT NOT NULL,
    difference TEXT NOT NULL,
    severity VARCHAR(16) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'OPEN',
    notes TEXT
);

CREATE TABLE IF NOT EXISTS audit_events (
    id BIGSERIAL PRIMARY KEY,
    event_id VARCHAR(64) NOT NULL UNIQUE,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    event_type VARCHAR(64) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    actor VARCHAR(64) NOT NULL,
    details TEXT NOT NULL,
    severity VARCHAR(16) NOT NULL DEFAULT 'INFO'
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_executions_client_order_id ON executions(client_order_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_events(timestamp DESC);
