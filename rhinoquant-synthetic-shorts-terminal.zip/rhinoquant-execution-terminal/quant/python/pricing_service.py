"""
RhinoQuant Execution Terminal — Quantitative Valuation & Greeks Microservice
FastAPI + NumPy/SciPy implementation of Black-Scholes-Merton and Scenario Shock Engine
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import numpy as np
from scipy.stats import norm
import math

app = FastAPI(
    title="RhinoQuant Pricing & Risk API",
    version="1.0.0",
    description="Quantitative options pricing, Greeks, put-call parity diagnostics and stress scenarios"
)

class OptionContract(BaseModel):
    instrument_id: str
    underlying: str
    strike: float
    time_to_expiry_years: float
    option_type: str = Field(..., pattern="^(CALL|PUT)$")
    volatility: float
    risk_free_rate: float = 0.045
    dividend_yield: float = 0.012

class GreeksResponse(BaseModel):
    price: float
    delta: float
    gamma: float
    vega: float
    theta: float
    rho: float

class SyntheticShortRequest(BaseModel):
    spot: float
    strike: float
    time_to_expiry_years: float
    volatility: float
    quantity: int = 1
    multiplier: int = 100
    risk_free_rate: float = 0.045
    dividend_yield: float = 0.012
    borrow_rate: float = 0.0075

class SyntheticValuationResponse(BaseModel):
    put_price: float
    call_price: float
    synthetic_short_fair_value: float
    net_delta: float
    net_gamma: float
    net_vega: float
    net_theta: float
    put_call_parity_discrepancy: float
    break_even_underlying: float
    margin_estimate: float

def compute_bsm(spot: float, strike: float, t: float, sigma: float, r: float, q: float, is_call: bool):
    if t <= 0.0001:
        intrinsic = max(0.0, spot - strike) if is_call else max(0.0, strike - spot)
        delta = 1.0 if is_call and spot > strike else (-1.0 if not is_call and spot < strike else 0.0)
        return intrinsic, delta, 0.0, 0.0, 0.0, 0.0

    sigma = max(0.001, sigma)
    sqrt_t = math.sqrt(t)
    d1 = (math.log(spot / strike) + (r - q + 0.5 * sigma ** 2) * t) / (sigma * sqrt_t)
    d2 = d1 - sigma * sqrt_t

    df_q = math.exp(-q * t)
    df_r = math.exp(-r * t)
    pdf_d1 = norm.pdf(d1)

    if is_call:
        price = spot * df_q * norm.cdf(d1) - strike * df_r * norm.cdf(d2)
        delta = df_q * norm.cdf(d1)
        theta = (-(spot * df_q * pdf_d1 * sigma) / (2.0 * sqrt_t) - r * strike * df_r * norm.cdf(d2) + q * spot * df_q * norm.cdf(d1)) / 365.0
        rho = (strike * t * df_r * norm.cdf(d2)) / 100.0
    else:
        price = strike * df_r * norm.cdf(-d2) - spot * df_q * norm.cdf(-d1)
        delta = -df_q * norm.cdf(-d1)
        theta = (-(spot * df_q * pdf_d1 * sigma) / (2.0 * sqrt_t) + r * strike * df_r * norm.cdf(-d2) - q * spot * df_q * norm.cdf(-d1)) / 365.0
        rho = (-strike * t * df_r * norm.cdf(-d2)) / 100.0

    gamma = (df_q * pdf_d1) / (spot * sigma * sqrt_t)
    vega = (spot * df_q * sqrt_t * pdf_d1) / 100.0

    return price, delta, gamma, vega, theta, rho

@app.post("/api/v1/pricing/greeks", response_model=GreeksResponse)
def calculate_greeks(opt: OptionContract):
    is_call = opt.option_type.upper() == "CALL"
    price, delta, gamma, vega, theta, rho = compute_bsm(
        opt.spot if hasattr(opt, "spot") else 100.0,
        opt.strike,
        opt.time_to_expiry_years,
        opt.volatility,
        opt.risk_free_rate,
        opt.dividend_yield,
        is_call
    )
    return GreeksResponse(
        price=round(price, 4),
        delta=round(delta, 4),
        gamma=round(gamma, 6),
        vega=round(vega, 4),
        theta=round(theta, 4),
        rho=round(rho, 4)
    )

@app.post("/api/v1/strategies/synthetic-short/valuate", response_model=SyntheticValuationResponse)
def valuate_synthetic_short(req: SyntheticShortRequest):
    # Long Put (+1) and Short Call (-1)
    put_p, put_d, put_g, put_v, put_th, _ = compute_bsm(
        req.spot, req.strike, req.time_to_expiry_years, req.volatility, req.risk_free_rate, req.dividend_yield, False
    )
    call_p, call_d, call_g, call_v, call_th, _ = compute_bsm(
        req.spot, req.strike, req.time_to_expiry_years, req.volatility, req.risk_free_rate, req.dividend_yield, True
    )

    synthetic_value = put_p - call_p
    net_delta = (put_d - call_d) * req.quantity * req.multiplier
    net_gamma = (put_g - call_g) * req.quantity * req.multiplier
    net_vega = (put_v - call_v) * req.quantity * req.multiplier
    net_theta = (put_th - call_th) * req.quantity * req.multiplier

    # Theoretical forward fair value: P - C = K * e^(-rT) - S * e^(-qT)
    theoretical_parity = req.strike * math.exp(-req.risk_free_rate * req.time_to_expiry_years) - req.spot * math.exp(-req.dividend_yield * req.time_to_expiry_years)
    discrepancy = abs(synthetic_value - theoretical_parity)

    margin_est = req.spot * req.quantity * req.multiplier * 0.20

    return SyntheticValuationResponse(
        put_price=round(put_p, 4),
        call_price=round(call_p, 4),
        synthetic_short_fair_value=round(synthetic_value, 4),
        net_delta=round(net_delta, 2),
        net_gamma=round(net_gamma, 4),
        net_vega=round(net_vega, 2),
        net_theta=round(net_theta, 2),
        put_call_parity_discrepancy=round(discrepancy, 6),
        break_even_underlying=round(req.strike + synthetic_value, 2),
        margin_estimate=round(margin_est, 2)
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
