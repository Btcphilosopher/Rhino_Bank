# RhinoQuant Execution Terminal
### Synthetic Shorts — Executable Institutional Trading System

---

## 1. Executive Summary & Mission
RhinoQuant Execution Terminal is a production-grade institutional electronic trading workstation and order-execution system tailored for constructing, pricing, risk-checking, submitting, monitoring, and reconciling **synthetic short-stock positions** via listed option derivatives.

The core workflow strictly enforces the institutional trading pipeline:
$$\text{Market Data} \longrightarrow \text{Instrument Master} \longrightarrow \text{Synthetic Structure} \longrightarrow \text{Valuation \& Parity} \longrightarrow \text{Pre-Trade Risk Gate} \longrightarrow \text{Order Routing} \longrightarrow \text{Execution Reports} \longrightarrow \text{Position Ledger} \longrightarrow \text{Reconciliation}$$

---

## 2. Distinction of Core Financial Concepts
RhinoQuant strictly separates four critical domain concepts:
1. **Synthetic Exposure**: The economic exposure created by combining long put and short call options with matched strikes and expiries ($P - C = K e^{-rT} - S_0 e^{-qT}$).
2. **Modelled Position**: A quantitative strategy that has been priced and analyzed across scenario shocks, but has **not** been submitted or executed.
3. **Working Order**: An active multi-leg complex order accepted by the execution venue matching engine but not yet filled.
4. **Executed Position**: Derivative exposure derived **exclusively** from confirmed execution reports and ledger events.

---

## 3. Technology Stack & Multi-Tier Architecture

| Tier | Technology | Responsibility |
|---|---|---|
| **Workstation UI** | Jetpack Compose (Android / Tablet / Desktop) | Dark navy institutional terminal with 5 panels: Options Chain, Strategy Builder, Risk Monitor, Order Blotter, and Ledger Reconciliation. |
| **Execution & State Machine** | Rust (`crates/order-state/`) | Authoritative order state machine, transition validator, idempotency enforcement, and event audit trail. |
| **Quantitative Services** | Python 3.12+ (`quant/python/pricing_service.py`) | High-precision Black-Scholes-Merton options pricing, Greeks ($\Delta, \Gamma, \mathcal{V}, \Theta, \rho$), and full revaluation stress scenarios. |
| **Model Validation** | R (`analytics/r/model_validation.R`) | Independent quantitative verification, P&L reconciliation audits, and VaR backtesting. |
| **Authoritative Store** | PostgreSQL (`db/migrations/001_initial_schema.sql`) | Append-only audit events, relational order books, execution logs, and position snapshots. |

---

## 4. Synthetic Short Construction & Pricing
A synthetic short-stock position consists of:
- **Leg 1**: Long Put (Buy Put, Strike $K$, Expiry $T$, Multiplier 100)
- **Leg 2**: Short Call (Sell Call, Strike $K$, Expiry $T$, Multiplier 100)

### Put-Call Parity Valuation
By European Put-Call Parity:
$$C - P = S_0 e^{-q T} - K e^{-r T}$$
Rearranging for the synthetic short value:
$$\text{Synthetic Short} = P - C = K e^{-r T} - S_0 e^{-q T}$$
Where:
- $S_0$ = Current spot price of underlying
- $K$ = Strike price
- $r$ = Risk-free rate
- $q$ = Continuous dividend yield
- $T$ = Time to expiration (years)

The terminal displays both the **executable market side** (Buying Put at Ask, Selling Call at Bid) and the **strategy midpoint**, clearly highlighting that midpoints are indicative and not guaranteed execution prices.

---

## 5. Pre-Trade Risk Gate
Every submitted order is processed by a server-side pre-trade risk engine before reaching the execution adapter. The gate evaluates:
1. **Leg Compatibility**: Verifies matched underlying, strikes, expiries, quantities, and valid long put + short call setup.
2. **Quantity Bounds**: Verifies clip size (1 to 50 contracts).
3. **Contract Multiplier**: Validates 100x standard contracts.
4. **Tick Size**: Validates $0.01 price increments.
5. **Market Data Freshness**: Fails if quote timestamp latency exceeds 10,000ms.
6. **Order Notional**: Rejects orders with notional > $250,000.
7. **Gross Exposure**: Enforces book gross limit of $1,000,000.
8. **Margin & Buffer**: Verifies available liquidity after 20% margin requirement exceeds $25,000 buffer.
9. **Single-Name Concentration**: Caps single ticker exposure at 35% of total gross.
10. **Duplicate Detection**: Flags identical orders submitted within 60 seconds.

Decision codes returned: `APPROVED`, `REJECTED`, or `REQUIRES_REVIEW`.

---

## 6. Authoritative Order State Machine
Orders transition through deterministic, auditable states:
```
Draft
  └── PendingValidation
        └── PendingRisk ──► [Approved | RequiresReview | Rejected]
              └── Submitting
                    └── Submitted
                          └── Acknowledged
                                ├── PartiallyFilled ──► Filled
                                ├── Filled (Terminal)
                                └── PendingCancel ────► Cancelled (Terminal)
```
- A filled order cannot transition backwards.
- Cancellation requests do not modify position state until confirmed by execution reports.

---

## 7. Automated Verification & Testing
The system includes local JVM and Robolectric unit tests covering:
- Black-Scholes-Merton options pricing and Put-Call parity forward fair value.
- Synthetic short leg compatibility (detects mismatched strikes, missing legs).
- State machine transition rules.
- Pre-trade risk gate bounds and rejection handling.
- Reconciliation engine discrepancy detection.

To run the test suite:
```bash
gradle :app:testDebugUnitTest
```

---

## 8. Security & Execution Governance
- **Paper Trading Engine**: Simulates realistic bid/ask spread crossing, partial executions, slippage, and fees ($0.65/contract).
- **Live Trading Disabled**: Live execution remains strictly disabled until authorized FIX broker credentials are provisioned in secure server-side secrets. The platform never fakes live broker connections.
