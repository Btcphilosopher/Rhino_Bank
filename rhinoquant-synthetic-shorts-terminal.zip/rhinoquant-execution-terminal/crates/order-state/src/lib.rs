//! RhinoQuant Execution Terminal — Authoritative Order State Machine
//! Implements deterministic transitions, idempotency verification, and event history.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum OrderState {
    Draft,
    PendingValidation,
    PendingRisk,
    RequiresReview,
    Approved,
    Submitting,
    Submitted,
    Acknowledged,
    PartiallyFilled,
    Filled,
    PendingCancel,
    Cancelled,
    Rejected,
    Expired,
    ReconciliationRequired,
}

#[derive(Error, Debug, PartialEq)]
pub enum StateMachineError {
    #[error("Invalid state transition from {from:?} to {to:?}: {reason}")]
    InvalidTransition {
        from: OrderState,
        to: OrderState,
        reason: &'static str,
    },
    #[error("Order in terminal state {0:?} cannot be modified")]
    TerminalStateViolation(OrderState),
    #[error("Duplicate submission detected for idempotency key {0}")]
    DuplicateIdempotencyKey(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderEvent {
    pub event_id: String,
    pub client_order_id: String,
    pub from_state: OrderState,
    pub to_state: OrderState,
    pub timestamp: DateTime<Utc>,
    pub reason: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderStateMachine {
    pub client_order_id: String,
    pub idempotency_key: String,
    pub current_state: OrderState,
    pub event_history: Vec<OrderEvent>,
}

impl OrderStateMachine {
    pub fn new(client_order_id: String, idempotency_key: String) -> Self {
        Self {
            client_order_id,
            idempotency_key,
            current_state: OrderState::Draft,
            event_history: Vec::new(),
        }
    }

    pub fn transition_to(&mut self, target_state: OrderState, reason: Option<String>) -> Result<(), StateMachineError> {
        if self.current_state == target_state {
            return Ok(());
        }

        if self.is_terminal() && target_state != OrderState::ReconciliationRequired {
            return Err(StateMachineError::TerminalStateViolation(self.current_state));
        }

        let is_valid = match (self.current_state, target_state) {
            (OrderState::Draft, OrderState::PendingValidation) => true,
            (OrderState::Draft, OrderState::Cancelled) => true,
            (OrderState::PendingValidation, OrderState::PendingRisk) => true,
            (OrderState::PendingValidation, OrderState::Rejected) => true,
            (OrderState::PendingValidation, OrderState::Draft) => true,
            (OrderState::PendingRisk, OrderState::Approved) => true,
            (OrderState::PendingRisk, OrderState::RequiresReview) => true,
            (OrderState::PendingRisk, OrderState::Rejected) => true,
            (OrderState::RequiresReview, OrderState::Approved) => true,
            (OrderState::RequiresReview, OrderState::Rejected) => true,
            (OrderState::Approved, OrderState::Submitting) => true,
            (OrderState::Approved, OrderState::Cancelled) => true,
            (OrderState::Submitting, OrderState::Submitted) => true,
            (OrderState::Submitting, OrderState::Rejected) => true,
            (OrderState::Submitted, OrderState::Acknowledged) => true,
            (OrderState::Submitted, OrderState::Rejected) => true,
            (OrderState::Submitted, OrderState::PendingCancel) => true,
            (OrderState::Acknowledged, OrderState::PartiallyFilled) => true,
            (OrderState::Acknowledged, OrderState::Filled) => true,
            (OrderState::Acknowledged, OrderState::PendingCancel) => true,
            (OrderState::Acknowledged, OrderState::Expired) => true,
            (OrderState::PartiallyFilled, OrderState::PartiallyFilled) => true,
            (OrderState::PartiallyFilled, OrderState::Filled) => true,
            (OrderState::PartiallyFilled, OrderState::PendingCancel) => true,
            (OrderState::PendingCancel, OrderState::Cancelled) => true,
            (OrderState::PendingCancel, OrderState::Filled) => true,
            (_, OrderState::ReconciliationRequired) => true,
            (OrderState::ReconciliationRequired, OrderState::Acknowledged) => true,
            (OrderState::ReconciliationRequired, OrderState::Filled) => true,
            (OrderState::ReconciliationRequired, OrderState::Cancelled) => true,
            _ => false,
        };

        if !is_valid {
            return Err(StateMachineError::InvalidTransition {
                from: self.current_state,
                to: target_state,
                reason: "Transition not permitted in authoritative lifecycle policy",
            });
        }

        let event = OrderEvent {
            event_id: uuid::Uuid::new_v4().to_string(),
            client_order_id: self.client_order_id.clone(),
            from_state: self.current_state,
            to_state: target_state,
            timestamp: Utc::now(),
            reason,
        };

        self.event_history.push(event);
        self.current_state = target_state;
        Ok(())
    }

    pub fn is_terminal(&self) -> bool {
        matches!(
            self.current_state,
            OrderState::Filled | OrderState::Cancelled | OrderState::Rejected | OrderState::Expired
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_lifecycle() {
        let mut sm = OrderStateMachine::new("CL-001".to_string(), "IDEM-1".to_string());
        assert_eq!(sm.current_state, OrderState::Draft);

        sm.transition_to(OrderState::PendingValidation, None).unwrap();
        sm.transition_to(OrderState::PendingRisk, None).unwrap();
        sm.transition_to(OrderState::Approved, None).unwrap();
        sm.transition_to(OrderState::Submitting, None).unwrap();
        sm.transition_to(OrderState::Submitted, None).unwrap();
        sm.transition_to(OrderState::Acknowledged, None).unwrap();
        sm.transition_to(OrderState::Filled, Some("100% matched".into())).unwrap();

        assert_eq!(sm.current_state, OrderState::Filled);
        assert!(sm.is_terminal());

        // Cannot jump back to Draft
        assert!(sm.transition_to(OrderState::Draft, None).is_err());
    }
}
