package com.example.model

data class OptionGreeks(
    val price: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double,
    val rho: Double
)

data class StrategyValuation(
    val netDebitOrCredit: Double, // positive = net credit, negative = net debit
    val isCredit: Boolean,
    val midpointPrice: Double,
    val executableSidePrice: Double, // ask for buys, bid for sells
    val theoreticalForwardPrice: Double,
    val theoreticalFairValue: Double,
    val breakEvenPrice: Double,
    val maxGain: Double, // For synthetic short, unlimited or capped by zero stock price
    val maxLoss: Double, // Theoretical infinite on stock rise
    val netDelta: Double, // approx -1.0 per unit synthetic short
    val netGamma: Double,
    val netVega: Double,
    val netTheta: Double,
    val estimatedTransactionCosts: Double,
    val initialMarginEstimate: Double,
    val maintenanceMarginEstimate: Double,
    val carryCostEstimate: Double
)

data class ScenarioShock(
    val id: String,
    val name: String,
    val priceShockPct: Double, // e.g. -0.10 for -10%
    val volShockPts: Double,    // e.g. +0.05 for +5 vol points
    val daysDecay: Int,         // e.g. 7 days
    val rateShockBps: Double = 0.0
)

data class ScenarioResult(
    val shock: ScenarioShock,
    val stressedSpot: Double,
    val pnlImpact: Double,
    val pnlPct: Double,
    val stressedDelta: Double,
    val stressedGamma: Double,
    val stressedVega: Double,
    val stressedMargin: Double
)
