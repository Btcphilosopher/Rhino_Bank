package com.example.model

enum class OrderSide {
    BUY,
    SELL
}

enum class OrderType {
    LIMIT,
    MARKET,
    NET_CREDIT_LIMIT,
    NET_DEBIT_LIMIT
}

enum class TimeInForce {
    DAY,
    GTC,
    IOC
}

enum class OrderState {
    Draft,
    PendingValidation,
    PendingRisk,
    RequiresReview,
    Approved,
    Submitting,
    Submitted,
    Acknowledged,
    PartiallyFilled,
    Filled,
    PendingCancel,
    Cancelled,
    Rejected,
    Expired,
    ReconciliationRequired
}

enum class PreTradeDecision {
    APPROVED,
    REJECTED,
    REQUIRES_REVIEW
}

data class RiskCheckResult(
    val decision: PreTradeDecision,
    val checks: List<RiskRuleResult>,
    val timestamp: Long = System.currentTimeMillis()
)

data class RiskRuleResult(
    val ruleName: String,
    val passed: Boolean,
    val code: String,
    val message: String
)

data class OrderLeg(
    val instrumentId: String,
    val underlying: String,
    val optionType: OptionType,
    val side: OrderSide,
    val quantity: Int,
    val strike: Double,
    val expiry: String,
    val multiplier: Int = 100,
    val bid: Double,
    val ask: Double,
    val limitPrice: Double,
    val filledQuantity: Int = 0,
    val avgFillPrice: Double = 0.0
) {
    val isFilled: Boolean
        get() = filledQuantity >= quantity
}

data class SyntheticOrder(
    val id: String,
    val clientOrderId: String,
    val bookId: String = "ALPHA_HEDGE_BOOK",
    val underlying: String,
    val legs: List<OrderLeg>,
    val orderType: OrderType = OrderType.NET_CREDIT_LIMIT,
    val netLimitPrice: Double,
    val quantity: Int = 1,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val status: OrderState = OrderState.Draft,
    val riskDecision: PreTradeDecision? = null,
    val riskReasonCodes: List<String> = emptyList(),
    val rejectionMessage: String? = null,
    val idempotencyKey: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val totalNotional: Double
        get() = legs.sumOf { it.strike * it.quantity * it.multiplier }

    val isTerminal: Boolean
        get() = status in listOf(OrderState.Filled, OrderState.Cancelled, OrderState.Rejected, OrderState.Expired)
}
