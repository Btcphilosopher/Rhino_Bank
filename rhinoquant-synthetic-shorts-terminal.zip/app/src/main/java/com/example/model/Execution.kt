package com.example.model

data class ExecutionReport(
    val executionId: String,
    val clientOrderId: String,
    val brokerOrderId: String,
    val instrumentId: String,
    val underlying: String,
    val side: OrderSide,
    val filledQty: Int,
    val fillPrice: Double,
    val fee: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val venue: String = "RHINO_PAPER_SIM",
    val liquidityFlag: String = "TAKER"
)

data class Position(
    val instrumentId: String,
    val underlying: String,
    val strategyTag: String = "SYNTHETIC_SHORT",
    val quantity: Int, // positive = long, negative = short
    val avgCost: Double,
    val currentMarketPrice: Double,
    val multiplier: Int = 100,
    val realizedPnl: Double = 0.0,
    val deltaEquivalent: Double = 0.0,
    val marginRequirement: Double = 0.0,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val unrealizedPnl: Double
        get() = (currentMarketPrice - avgCost) * quantity * multiplier

    val marketValue: Double
        get() = currentMarketPrice * quantity * multiplier
}

enum class DiscrepancySeverity {
    INFO,
    WARNING,
    CRITICAL
}

enum class ExceptionStatus {
    OPEN,
    INVESTIGATING,
    RESOLVED
}

data class ReconciliationException(
    val id: String,
    val runTimestamp: Long = System.currentTimeMillis(),
    val instrument: String,
    val entityType: String, // "ORDER" | "POSITION" | "MARGIN" | "CASH"
    val entityId: String,
    val internalValue: String,
    val providerValue: String,
    val difference: String,
    val severity: DiscrepancySeverity,
    val status: ExceptionStatus = ExceptionStatus.OPEN,
    val notes: String = ""
)

data class AuditEvent(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String,
    val entityId: String,
    val actor: String = "DESK_TRADER_1",
    val details: String,
    val severity: String = "INFO"
)
