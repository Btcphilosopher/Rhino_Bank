package com.example.model

enum class ContractType {
    OPTION,
    EQUITY,
    FUTURES,
    FORWARD,
    TOTAL_RETURN_SWAP
}

enum class OptionType {
    CALL,
    PUT
}

enum class QuoteQuality {
    LIVE,
    DELAYED,
    SIMULATED,
    STALE,
    INDICATIVE
}

data class Instrument(
    val id: String,
    val symbol: String,
    val underlying: String,
    val assetClass: String = "EQUITY_DERIVATIVE",
    val contractType: ContractType = ContractType.OPTION,
    val expiry: String, // YYYY-MM-DD
    val strike: Double,
    val optionType: OptionType,
    val multiplier: Int = 100,
    val tickSize: Double = 0.01,
    val currency: String = "USD",
    val settlementType: String = "PHYSICAL",
    val exerciseStyle: String = "AMERICAN",
    val tradingVenue: String = "CBOE_PAPER"
)

data class Quote(
    val instrumentId: String,
    val underlying: String,
    val bid: Double,
    val ask: Double,
    val last: Double,
    val iv: Double, // Implied Volatility e.g. 0.28 for 28%
    val delta: Double,
    val volume: Long,
    val openInterest: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val quality: QuoteQuality = QuoteQuality.SIMULATED
) {
    val mid: Double
        get() = (bid + ask) / 2.0

    val spreadWidth: Double
        get() = ask - bid

    val isStale: Boolean
        get() = System.currentTimeMillis() - timestamp > 10_000
}

data class UnderlyingQuote(
    val symbol: String,
    val name: String,
    val spotPrice: Double,
    val change: Double,
    val changePct: Double,
    val dividendYield: Double = 0.012, // 1.2%
    val borrowRate: Double = 0.0075,   // 0.75% borrow fee
    val riskFreeRate: Double = 0.045,  // 4.5% Treasury bill rate
    val timestamp: Long = System.currentTimeMillis()
)
