package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.TerminalTab
import com.example.ui.TerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                RhinoQuantApp(viewModel)
            }
        }
    }
}

@Composable
fun RhinoQuantApp(viewModel: TerminalViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedUnderlying by viewModel.selectedUnderlying.collectAsStateWithLifecycle()
    val underlyings by viewModel.marketData.underlyings.collectAsStateWithLifecycle()
    val instruments by viewModel.marketData.instruments.collectAsStateWithLifecycle()
    val quotes by viewModel.marketData.quotes.collectAsStateWithLifecycle()
    val selectedExpiry by viewModel.selectedExpiry.collectAsStateWithLifecycle()
    val moneynessFilter by viewModel.moneynessFilter.collectAsStateWithLifecycle()

    val builderLegs by viewModel.builderLegs.collectAsStateWithLifecycle()
    val builderQuantity by viewModel.builderQuantity.collectAsStateWithLifecycle()
    val builderLimitPrice by viewModel.builderLimitPrice.collectAsStateWithLifecycle()
    val builderOrderType by viewModel.builderOrderType.collectAsStateWithLifecycle()
    val builderTif by viewModel.builderTif.collectAsStateWithLifecycle()
    val lastRiskResult by viewModel.lastRiskResult.collectAsStateWithLifecycle()
    val isSubmittingOrder by viewModel.isSubmittingOrder.collectAsStateWithLifecycle()

    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val executions by viewModel.executions.collectAsStateWithLifecycle()
    val positions by viewModel.positions.collectAsStateWithLifecycle()
    val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()
    val reconciliationExceptions by viewModel.reconciliationExceptions.collectAsStateWithLifecycle()
    val lastReconReport by viewModel.lastReconciliationReport.collectAsStateWithLifecycle()

    val totalCash by viewModel.totalCash.collectAsStateWithLifecycle()
    val isLiveFeedActive by viewModel.isLiveFeedActive.collectAsStateWithLifecycle()
    val lastTickTime by viewModel.lastMarketTickTime.collectAsStateWithLifecycle()
    val selectedBook by viewModel.selectedBook.collectAsStateWithLifecycle()

    val strategyValuation = viewModel.getStrategyValuation()
    val scenarioResults = viewModel.getScenarioStressResults()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyVoid)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            TerminalHeader(
                selectedUnderlying = selectedUnderlying,
                underlyings = underlyings,
                selectedBook = selectedBook,
                totalCash = totalCash,
                isLiveFeedActive = isLiveFeedActive,
                lastTickTime = lastTickTime,
                onSelectUnderlying = { viewModel.selectUnderlying(it) },
                onToggleFeed = { viewModel.toggleLiveFeed() }
            )
        },
        bottomBar = {
            TerminalBottomBar(
                currentTab = currentTab,
                ordersCount = orders.count { !it.isTerminal },
                exceptionsCount = reconciliationExceptions.size,
                onSelectTab = { viewModel.selectTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NavyDeep)
        ) {
            when (currentTab) {
                TerminalTab.OPTIONS_CHAIN -> {
                    OptionsChainView(
                        underlying = selectedUnderlying,
                        spotQuote = underlyings[selectedUnderlying],
                        instruments = instruments,
                        quotes = quotes,
                        selectedExpiry = selectedExpiry,
                        moneynessFilter = moneynessFilter,
                        onSelectExpiry = { viewModel.selectExpiry(it) },
                        onSelectMoneyness = { viewModel.selectMoneyness(it) },
                        onSelectStrikeForSynthetic = { strike, exp ->
                            viewModel.selectStrikeForSynthetic(strike, exp)
                            viewModel.selectTab(TerminalTab.STRATEGY_BUILDER)
                        }
                    )
                }
                TerminalTab.STRATEGY_BUILDER -> {
                    SyntheticBuilderView(
                        underlying = selectedUnderlying,
                        legs = builderLegs,
                        quantity = builderQuantity,
                        limitPrice = builderLimitPrice,
                        orderType = builderOrderType,
                        timeInForce = builderTif,
                        valuation = strategyValuation,
                        riskResult = lastRiskResult,
                        isSubmitting = isSubmittingOrder,
                        onUpdateQuantity = { viewModel.updateQuantity(it) },
                        onUpdateLimitPrice = { viewModel.updateNetLimitPrice(it) },
                        onReverseDirection = { viewModel.reverseStrategyDirection() },
                        onRunRiskCheck = { viewModel.runPreTradeRiskCheck() },
                        onSubmitOrder = { viewModel.submitSyntheticOrder() }
                    )
                }
                TerminalTab.RISK_MONITOR -> {
                    RiskMonitorView(
                        positions = positions,
                        valuation = strategyValuation,
                        scenarioResults = scenarioResults,
                        totalCash = totalCash,
                        selectedBook = selectedBook
                    )
                }
                TerminalTab.ORDER_BLOTTER -> {
                    OrderBlotterView(
                        orders = orders,
                        executions = executions,
                        positions = positions,
                        onCancelOrder = { viewModel.cancelOrder(it) }
                    )
                }
                TerminalTab.RECONCILIATION -> {
                    ReconciliationView(
                        reconciliationReport = lastReconReport,
                        exceptions = reconciliationExceptions,
                        auditEvents = auditEvents,
                        onTriggerRecon = { viewModel.triggerReconciliation() }
                    )
                }
            }
        }
    }
}

@Composable
fun TerminalBottomBar(
    currentTab: TerminalTab,
    ordersCount: Int,
    exceptionsCount: Int,
    onSelectTab: (TerminalTab) -> Unit
) {
    NavigationBar(
        containerColor = NavyVoid,
        contentColor = TextSecondary,
        tonalElevation = 0.dp,
        modifier = Modifier
            .border(1.dp, BorderSubtle)
            .navigationBarsPadding()
    ) {
        val items = listOf(
            TabItem(TerminalTab.OPTIONS_CHAIN, "CHAIN", Icons.Default.ViewList),
            TabItem(TerminalTab.STRATEGY_BUILDER, "BUILDER", Icons.Default.Layers),
            TabItem(TerminalTab.RISK_MONITOR, "RISK", Icons.Default.Shield),
            TabItem(TerminalTab.ORDER_BLOTTER, if (ordersCount > 0) "BLOTTER ($ordersCount)" else "BLOTTER", Icons.Default.ReceiptLong),
            TabItem(TerminalTab.RECONCILIATION, if (exceptionsCount > 0) "RECON ($exceptionsCount)" else "RECON", Icons.Default.Sync)
        )

        items.forEach { item ->
            val isSelected = currentTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectTab(item.tab) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        modifier = Modifier.size(18.dp)
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandCyan,
                    selectedTextColor = BrandCyan,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted,
                    indicatorColor = NavyCardElevated
                ),
                modifier = Modifier.testTag("nav_tab_${item.tab.name.lowercase()}")
            )
        }
    }
}

data class TabItem(
    val tab: TerminalTab,
    val label: String,
    val icon: ImageVector
)
