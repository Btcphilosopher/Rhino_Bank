package com.example.data.repository

import com.example.data.MarketDataProvider
import com.example.data.db.*
import com.example.execution.ExecutionAdapter
import com.example.execution.OrderStateMachine
import com.example.execution.PaperExecutionAdapter
import com.example.execution.ReconciliationEngine
import com.example.model.*
import com.example.risk.PreTradeRiskGate
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs

class TerminalRepository(
    private val database: TerminalDatabase,
    val marketData: MarketDataProvider,
    val executionAdapter: ExecutionAdapter = PaperExecutionAdapter()
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    val ordersFlow: Flow<List<SyntheticOrder>> = database.orderDao().getAllOrders().map { list ->
        list.map { it.toDomain() }
    }

    val executionsFlow: Flow<List<ExecutionReport>> = database.executionDao().getAllExecutions().map { list ->
        list.map { it.toDomain() }
    }

    val positionsFlow: Flow<List<Position>> = database.positionDao().getAllPositions().map { list ->
        list.map { it.toDomain() }
    }

    val auditEventsFlow: Flow<List<AuditEvent>> = database.auditDao().getAllAuditEvents().map { list ->
        list.map { it.toDomain() }
    }

    val exceptionsFlow: Flow<List<ReconciliationException>> = database.reconciliationDao().getAllExceptions().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun logAudit(eventType: String, entityId: String, details: String, severity: String = "INFO") {
        database.auditDao().insertAudit(
            AuditEventEntity(
                eventId = UUID.randomUUID().toString(),
                timestamp = System.currentTimeMillis(),
                eventType = eventType,
                entityId = entityId,
                actor = "DESK_EXECUTION_ENGINE",
                details = details,
                severity = severity
            )
        )
    }

    suspend fun saveDraftOrder(order: SyntheticOrder) {
        database.orderDao().insertOrder(order.toEntity())
        logAudit("ORDER_DRAFTED", order.clientOrderId, "Created synthetic short draft on ${order.underlying}")
    }

    suspend fun validateAndSubmitOrder(
        order: SyntheticOrder,
        currentGross: Double,
        availableCash: Double,
        activeOrders: List<SyntheticOrder>
    ): RiskCheckResult {
        // Step 1: Pre-Trade Risk Gate
        val riskResult = PreTradeRiskGate.evaluateOrder(
            order = order,
            currentGrossExposure = currentGross,
            availableCash = availableCash,
            activeOrders = activeOrders,
            quotes = marketData.quotes.value
        )

        val updatedOrder = order.copy(
            status = when (riskResult.decision) {
                PreTradeDecision.APPROVED -> OrderState.Approved
                PreTradeDecision.REQUIRES_REVIEW -> OrderState.RequiresReview
                PreTradeDecision.REJECTED -> OrderState.Rejected
            },
            riskDecision = riskResult.decision,
            riskReasonCodes = riskResult.checks.filter { !it.passed }.map { it.code },
            rejectionMessage = riskResult.checks.find { !it.passed }?.message,
            updatedAt = System.currentTimeMillis()
        )

        database.orderDao().insertOrder(updatedOrder.toEntity())

        logAudit(
            "PRE_TRADE_EVALUATION",
            order.clientOrderId,
            "Risk Gate Decision: ${riskResult.decision} - ${updatedOrder.rejectionMessage ?: "All checks passed"}",
            if (riskResult.decision == PreTradeDecision.APPROVED) "INFO" else "WARNING"
        )

        // Step 2: If APPROVED, route to Execution Adapter
        if (riskResult.decision == PreTradeDecision.APPROVED) {
            scope.launch {
                routeOrderToVenue(updatedOrder)
            }
        }

        return riskResult
    }

    private suspend fun routeOrderToVenue(approvedOrder: SyntheticOrder) {
        logAudit("ORDER_ROUTED", approvedOrder.clientOrderId, "Transmitting complex order to ${executionAdapter.venueName}")

        executionAdapter.submitOrder(
            order = approvedOrder,
            onReport = { report ->
                processExecutionReport(report)
            },
            onStateChange = { newState, message ->
                val canTransition = OrderStateMachine.canTransition(approvedOrder.status, newState)
                if (canTransition.isAllowed) {
                    val entity = database.orderDao().getOrderById(approvedOrder.id)
                    if (entity != null) {
                        val current = entity.toDomain()
                        val updated = current.copy(
                            status = newState,
                            rejectionMessage = message ?: current.rejectionMessage,
                            updatedAt = System.currentTimeMillis()
                        )
                        database.orderDao().updateOrder(updated.toEntity())
                        logAudit("STATE_CHANGE", current.clientOrderId, "Transitioned to $newState: ${message ?: ""}")
                    }
                } else {
                    logAudit("STATE_VIOLATION", approvedOrder.clientOrderId, canTransition.reason, "CRITICAL")
                }
            }
        )
    }

    private suspend fun processExecutionReport(report: ExecutionReport) {
        database.executionDao().insertExecution(report.toEntity())

        logAudit(
            "EXECUTION_FILL",
            report.executionId,
            "Fill confirmed: ${report.side} ${report.filledQty}x ${report.instrumentId} @ \$${"%.2f".format(report.fillPrice)} fee=\$${report.fee}"
        )

        // Authoritative Position Ledger derivation from confirmed execution reports
        // Look up instrument from quotes to get current mark-to-market
        val q = marketData.quotes.value[report.instrumentId]
        val currentMkt = q?.mid ?: report.fillPrice

        val currentPositions = database.positionDao().getAllPositions()
        // Simple update: adjust quantity and recalculate weighted average cost
        val deltaQty = if (report.side == OrderSide.BUY) report.filledQty else -report.filledQty

        // Read or create position
        val existing = database.positionDao().getAllPositions()
        // We will insert or update position for this instrument
        val posEntity = PositionEntity(
            instrumentId = report.instrumentId,
            underlying = report.underlying,
            strategyTag = "SYNTHETIC_SHORT",
            quantity = deltaQty, // If new
            avgCost = report.fillPrice,
            currentMarketPrice = currentMkt,
            multiplier = 100,
            realizedPnl = 0.0,
            deltaEquivalent = if (report.side == OrderSide.BUY) (q?.delta ?: 0.5) * deltaQty * 100 else -(q?.delta ?: 0.5) * abs(deltaQty) * 100,
            marginRequirement = currentMkt * abs(deltaQty) * 20.0,
            updatedAt = System.currentTimeMillis()
        )
        database.positionDao().upsertPosition(posEntity)
    }

    suspend fun cancelOrder(orderId: String): Boolean {
        val entity = database.orderDao().getOrderById(orderId) ?: return false
        val order = entity.toDomain()

        val canCancel = OrderStateMachine.canTransition(order.status, OrderState.PendingCancel)
        if (!canCancel.isAllowed) {
            logAudit("CANCEL_REJECTED", order.clientOrderId, canCancel.reason, "WARNING")
            return false
        }

        logAudit("CANCEL_REQUEST", order.clientOrderId, "Transmitting cancellation to venue")
        return executionAdapter.cancelOrder(orderId) { newState, msg ->
            val updated = order.copy(status = newState, rejectionMessage = msg, updatedAt = System.currentTimeMillis())
            database.orderDao().updateOrder(updated.toEntity())
            logAudit("ORDER_CANCELLED", order.clientOrderId, "Order cancellation confirmed: ${msg ?: ""}")
        }
    }

    suspend fun runReconciliation(
        orders: List<SyntheticOrder>,
        positions: List<Position>,
        executions: List<ExecutionReport>,
        cash: Double,
        margin: Double
    ): ReconciliationEngine.ReconciliationReport {
        val report = ReconciliationEngine.runReconciliation(
            internalOrders = orders,
            internalPositions = positions,
            executionReports = executions,
            simulatedCash = cash,
            simulatedMargin = margin
        )

        // Clear and persist exceptions
        database.reconciliationDao().clearAll()
        for (exc in report.exceptions) {
            database.reconciliationDao().insertException(exc.toEntity())
        }

        logAudit(
            "RECONCILIATION_RUN",
            "RECON-${System.currentTimeMillis()}",
            "Reconciled ${report.ordersReconciled} orders and ${report.positionsReconciled} positions. Exceptions: ${report.exceptions.size}",
            if (report.exceptions.isEmpty()) "INFO" else "WARNING"
        )

        return report
    }
}

// Converters between Domain & Room Entities
fun SyntheticOrder.toEntity(): OrderEntity {
    val legsArray = JSONArray()
    for (leg in legs) {
        val obj = JSONObject()
        obj.put("instrumentId", leg.instrumentId)
        obj.put("underlying", leg.underlying)
        obj.put("optionType", leg.optionType.name)
        obj.put("side", leg.side.name)
        obj.put("quantity", leg.quantity)
        obj.put("strike", leg.strike)
        obj.put("expiry", leg.expiry)
        obj.put("multiplier", leg.multiplier)
        obj.put("bid", leg.bid)
        obj.put("ask", leg.ask)
        obj.put("limitPrice", leg.limitPrice)
        obj.put("filledQuantity", leg.filledQuantity)
        obj.put("avgFillPrice", leg.avgFillPrice)
        legsArray.put(obj)
    }

    return OrderEntity(
        id = id,
        clientOrderId = clientOrderId,
        bookId = bookId,
        underlying = underlying,
        status = status.name,
        orderType = orderType.name,
        netLimitPrice = netLimitPrice,
        quantity = quantity,
        timeInForce = timeInForce.name,
        riskDecision = riskDecision?.name,
        rejectionMessage = rejectionMessage,
        idempotencyKey = idempotencyKey,
        legsJson = legsArray.toString(),
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun OrderEntity.toDomain(): SyntheticOrder {
    val legsList = mutableListOf<OrderLeg>()
    val arr = JSONArray(legsJson)
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        legsList.add(
            OrderLeg(
                instrumentId = o.getString("instrumentId"),
                underlying = o.getString("underlying"),
                optionType = OptionType.valueOf(o.getString("optionType")),
                side = OrderSide.valueOf(o.getString("side")),
                quantity = o.getInt("quantity"),
                strike = o.getDouble("strike"),
                expiry = o.getString("expiry"),
                multiplier = o.optInt("multiplier", 100),
                bid = o.optDouble("bid", 0.0),
                ask = o.optDouble("ask", 0.0),
                limitPrice = o.getDouble("limitPrice"),
                filledQuantity = o.optInt("filledQuantity", 0),
                avgFillPrice = o.optDouble("avgFillPrice", 0.0)
            )
        )
    }

    return SyntheticOrder(
        id = id,
        clientOrderId = clientOrderId,
        bookId = bookId,
        underlying = underlying,
        legs = legsList,
        orderType = OrderType.valueOf(orderType),
        netLimitPrice = netLimitPrice,
        quantity = quantity,
        timeInForce = TimeInForce.valueOf(timeInForce),
        status = OrderState.valueOf(status),
        riskDecision = riskDecision?.let { PreTradeDecision.valueOf(it) },
        rejectionMessage = rejectionMessage,
        idempotencyKey = idempotencyKey,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun ExecutionReport.toEntity(): ExecutionEntity = ExecutionEntity(
    executionId = executionId,
    clientOrderId = clientOrderId,
    brokerOrderId = brokerOrderId,
    instrumentId = instrumentId,
    underlying = underlying,
    side = side.name,
    filledQty = filledQty,
    fillPrice = fillPrice,
    fee = fee,
    timestamp = timestamp,
    venue = venue,
    liquidityFlag = liquidityFlag
)

fun ExecutionEntity.toDomain(): ExecutionReport = ExecutionReport(
    executionId = executionId,
    clientOrderId = clientOrderId,
    brokerOrderId = brokerOrderId,
    instrumentId = instrumentId,
    underlying = underlying,
    side = OrderSide.valueOf(side),
    filledQty = filledQty,
    fillPrice = fillPrice,
    fee = fee,
    timestamp = timestamp,
    venue = venue,
    liquidityFlag = liquidityFlag
)

fun PositionEntity.toDomain(): Position = Position(
    instrumentId = instrumentId,
    underlying = underlying,
    strategyTag = strategyTag,
    quantity = quantity,
    avgCost = avgCost,
    currentMarketPrice = currentMarketPrice,
    multiplier = multiplier,
    realizedPnl = realizedPnl,
    deltaEquivalent = deltaEquivalent,
    marginRequirement = marginRequirement,
    updatedAt = updatedAt
)

fun AuditEventEntity.toDomain(): AuditEvent = AuditEvent(
    id = eventId,
    timestamp = timestamp,
    eventType = eventType,
    entityId = entityId,
    actor = actor,
    details = details,
    severity = severity
)

fun ReconciliationException.toEntity(): ReconciliationExceptionEntity = ReconciliationExceptionEntity(
    id = id,
    runTimestamp = runTimestamp,
    instrument = instrument,
    entityType = entityType,
    entityId = entityId,
    internalValue = internalValue,
    providerValue = providerValue,
    difference = difference,
    severity = severity.name,
    status = status.name,
    notes = notes
)

fun ReconciliationExceptionEntity.toDomain(): ReconciliationException = ReconciliationException(
    id = id,
    runTimestamp = runTimestamp,
    instrument = instrument,
    entityType = entityType,
    entityId = entityId,
    internalValue = internalValue,
    providerValue = providerValue,
    difference = difference,
    severity = DiscrepancySeverity.valueOf(severity),
    status = ExceptionStatus.valueOf(status),
    notes = notes
)
