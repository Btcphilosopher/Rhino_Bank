package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val clientOrderId: String,
    val bookId: String,
    val underlying: String,
    val status: String,
    val orderType: String,
    val netLimitPrice: Double,
    val quantity: Int,
    val timeInForce: String,
    val riskDecision: String?,
    val rejectionMessage: String?,
    val idempotencyKey: String,
    val legsJson: String, // Serialized list of legs
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "executions")
data class ExecutionEntity(
    @PrimaryKey val executionId: String,
    val clientOrderId: String,
    val brokerOrderId: String,
    val instrumentId: String,
    val underlying: String,
    val side: String,
    val filledQty: Int,
    val fillPrice: Double,
    val fee: Double,
    val timestamp: Long,
    val venue: String,
    val liquidityFlag: String
)

@Entity(tableName = "positions")
data class PositionEntity(
    @PrimaryKey val instrumentId: String,
    val underlying: String,
    val strategyTag: String,
    val quantity: Int,
    val avgCost: Double,
    val currentMarketPrice: Double,
    val multiplier: Int,
    val realizedPnl: Double,
    val deltaEquivalent: Double,
    val marginRequirement: Double,
    val updatedAt: Long
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventId: String,
    val timestamp: Long,
    val eventType: String,
    val entityId: String,
    val actor: String,
    val details: String,
    val severity: String
)

@Entity(tableName = "reconciliation_exceptions")
data class ReconciliationExceptionEntity(
    @PrimaryKey val id: String,
    val runTimestamp: Long,
    val instrument: String,
    val entityType: String,
    val entityId: String,
    val internalValue: String,
    val providerValue: String,
    val difference: String,
    val severity: String,
    val status: String,
    val notes: String
)
