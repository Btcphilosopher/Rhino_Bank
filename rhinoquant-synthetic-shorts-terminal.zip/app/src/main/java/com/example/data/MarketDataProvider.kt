package com.example.data

import com.example.model.*
import com.example.quant.BlackScholes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.random.Random

class MarketDataProvider {

    private val _underlyings = MutableStateFlow<Map<String, UnderlyingQuote>>(emptyMap())
    val underlyings: StateFlow<Map<String, UnderlyingQuote>> = _underlyings.asStateFlow()

    private val _quotes = MutableStateFlow<Map<String, Quote>>(emptyMap())
    val quotes: StateFlow<Map<String, Quote>> = _quotes.asStateFlow()

    private val _instruments = MutableStateFlow<List<Instrument>>(emptyList())
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    init {
        initializeMasterData()
    }

    private fun initializeMasterData() {
        val baseUnderlyings = listOf(
            UnderlyingQuote("SPY", "SPDR S&P 500 ETF Trust", 582.40, -1.85, -0.32),
            UnderlyingQuote("QQQ", "Invesco QQQ Trust (Nasdaq 100)", 495.15, -3.20, -0.64),
            UnderlyingQuote("NVDA", "NVIDIA Corporation", 135.50, -2.40, -1.74),
            UnderlyingQuote("AAPL", "Apple Inc.", 232.20, +0.85, +0.37),
            UnderlyingQuote("TSLA", "Tesla Inc.", 218.40, -4.90, -2.20),
            UnderlyingQuote("IWM", "iShares Russell 2000 ETF", 224.50, -1.10, -0.49)
        )

        val uMap = baseUnderlyings.associateBy { it.symbol }
        _underlyings.value = uMap

        // Generate standardized expiry dates: 14D (bi-weekly), 30D (monthly), 60D
        val cal = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        cal.add(Calendar.DAY_OF_YEAR, 14)
        val exp14 = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 16) // total 30
        val exp30 = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 30) // total 60
        val exp60 = sdf.format(cal.time)

        val expiries = listOf(
            Pair(exp14, 14),
            Pair(exp30, 30),
            Pair(exp60, 60)
        )

        val instList = mutableListOf<Instrument>()
        val quoteMap = mutableMapOf<String, Quote>()

        for (u in baseUnderlyings) {
            val spot = u.spotPrice
            val strikeStep = when {
                spot > 400 -> 5.0
                spot > 200 -> 2.5
                else -> 1.0
            }

            // Generate strikes around ATM (-10% to +10%)
            val roundedSpot = (spot / strikeStep).toInt() * strikeStep
            val strikes = (-6..6).map { roundedSpot + it * strikeStep }

            for ((expStr, days) in expiries) {
                val t = days / 365.0
                val baseVol = when (u.symbol) {
                    "TSLA" -> 0.48
                    "NVDA" -> 0.42
                    "QQQ" -> 0.22
                    "IWM" -> 0.24
                    else -> 0.18
                }

                for (strike in strikes) {
                    // Volatility skew: higher IV for OTM puts
                    val moneyness = ln(strike / spot)
                    val skew = -0.15 * moneyness
                    val iv = max(0.10, baseVol + skew)

                    // Call
                    val callG = BlackScholes.calculateGreeks(spot, strike, t, iv, 0.045, 0.012, OptionType.CALL)
                    val callId = "${u.symbol}_${expStr}_C_${strike.toInt()}"
                    val callSpread = max(0.05, callG.price * 0.02)
                    val callBid = Math.max(0.01, Math.round((callG.price - callSpread / 2) * 100.0) / 100.0)
                    val callAsk = Math.round((callG.price + callSpread / 2) * 100.0) / 100.0

                    instList.add(
                        Instrument(
                            id = callId,
                            symbol = "${u.symbol} $expStr ${strike.toInt()} C",
                            underlying = u.symbol,
                            expiry = expStr,
                            strike = strike,
                            optionType = OptionType.CALL
                        )
                    )
                    quoteMap[callId] = Quote(
                        instrumentId = callId,
                        underlying = u.symbol,
                        bid = callBid,
                        ask = callAsk,
                        last = callG.price,
                        iv = Math.round(iv * 1000.0) / 1000.0,
                        delta = Math.round(callG.delta * 1000.0) / 1000.0,
                        volume = Random.nextLong(150, 4500),
                        openInterest = Random.nextLong(1200, 25000),
                        timestamp = System.currentTimeMillis()
                    )

                    // Put
                    val putG = BlackScholes.calculateGreeks(spot, strike, t, iv, 0.045, 0.012, OptionType.PUT)
                    val putId = "${u.symbol}_${expStr}_P_${strike.toInt()}"
                    val putSpread = max(0.05, putG.price * 0.02)
                    val putBid = Math.max(0.01, Math.round((putG.price - putSpread / 2) * 100.0) / 100.0)
                    val putAsk = Math.round((putG.price + putSpread / 2) * 100.0) / 100.0

                    instList.add(
                        Instrument(
                            id = putId,
                            symbol = "${u.symbol} $expStr ${strike.toInt()} P",
                            underlying = u.symbol,
                            expiry = expStr,
                            strike = strike,
                            optionType = OptionType.PUT
                        )
                    )
                    quoteMap[putId] = Quote(
                        instrumentId = putId,
                        underlying = u.symbol,
                        bid = putBid,
                        ask = putAsk,
                        last = putG.price,
                        iv = Math.round(iv * 1000.0) / 1000.0,
                        delta = Math.round(putG.delta * 1000.0) / 1000.0,
                        volume = Random.nextLong(200, 5200),
                        openInterest = Random.nextLong(1500, 31000),
                        timestamp = System.currentTimeMillis()
                    )
                }
            }
        }

        _instruments.value = instList
        _quotes.value = quoteMap
    }

    private fun ln(x: Double) = kotlin.math.ln(x)

    /**
     * Simulate market tick (refresh timestamps and introduce slight micro-price moves)
     */
    fun tickMarket() {
        val currentQuotes = _quotes.value.toMutableMap()
        val now = System.currentTimeMillis()

        for ((id, q) in currentQuotes) {
            val delta = (Random.nextDouble() - 0.5) * 0.04
            val newBid = Math.max(0.01, Math.round((q.bid + delta) * 100.0) / 100.0)
            val newAsk = Math.max(newBid + 0.02, Math.round((q.ask + delta) * 100.0) / 100.0)
            currentQuotes[id] = q.copy(
                bid = newBid,
                ask = newAsk,
                last = Math.round(((newBid + newAsk) / 2.0) * 100.0) / 100.0,
                timestamp = now
            )
        }
        _quotes.value = currentQuotes
    }
}
