package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: String): OrderEntity?
}

@Dao
interface ExecutionDao {
    @Query("SELECT * FROM executions ORDER BY timestamp DESC")
    fun getAllExecutions(): Flow<List<ExecutionEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertExecution(execution: ExecutionEntity)

    @Query("SELECT * FROM executions WHERE clientOrderId = :clientOrderId")
    suspend fun getExecutionsForOrder(clientOrderId: String): List<ExecutionEntity>
}

@Dao
interface PositionDao {
    @Query("SELECT * FROM positions ORDER BY underlying ASC")
    fun getAllPositions(): Flow<List<PositionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPosition(position: PositionEntity)

    @Query("DELETE FROM positions WHERE instrumentId = :instrumentId")
    suspend fun deletePosition(instrumentId: String)

    @Query("DELETE FROM positions")
    suspend fun clearPositions()
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC LIMIT 200")
    fun getAllAuditEvents(): Flow<List<AuditEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(event: AuditEventEntity)
}

@Dao
interface ReconciliationDao {
    @Query("SELECT * FROM reconciliation_exceptions ORDER BY runTimestamp DESC")
    fun getAllExceptions(): Flow<List<ReconciliationExceptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertException(exception: ReconciliationExceptionEntity)

    @Update
    suspend fun updateException(exception: ReconciliationExceptionEntity)

    @Query("DELETE FROM reconciliation_exceptions")
    suspend fun clearAll()
}
