package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        OrderEntity::class,
        ExecutionEntity::class,
        PositionEntity::class,
        AuditEventEntity::class,
        ReconciliationExceptionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TerminalDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun executionDao(): ExecutionDao
    abstract fun positionDao(): PositionDao
    abstract fun auditDao(): AuditDao
    abstract fun reconciliationDao(): ReconciliationDao

    companion object {
        @Volatile
        private var INSTANCE: TerminalDatabase? = null

        fun getInstance(context: Context): TerminalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TerminalDatabase::class.java,
                    "rhinoquant_terminal.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
