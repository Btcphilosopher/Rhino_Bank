package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MarketDataProvider
import com.example.data.db.TerminalDatabase
import com.example.data.repository.TerminalRepository
import com.example.execution.OrderStateMachine
import com.example.execution.PaperExecutionAdapter
import com.example.execution.ReconciliationEngine
import com.example.model.*
import com.example.quant.ValuationEngine
import com.example.risk.PreTradeRiskGate
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs

enum class TerminalTab {
    OPTIONS_CHAIN,
    STRATEGY_BUILDER,
    RISK_MONITOR,
    ORDER_BLOTTER,
    RECONCILIATION
}

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TerminalDatabase.getInstance(application)
    val marketData = MarketDataProvider()
    val repository = TerminalRepository(db, marketData, PaperExecutionAdapter())

    // Active Navigation Tab
    private val _currentTab = MutableStateFlow(TerminalTab.OPTIONS_CHAIN)
    val currentTab: StateFlow<TerminalTab> = _currentTab.asStateFlow()

    // Selected Underlying
    private val _selectedUnderlying = MutableStateFlow("SPY")
    val selectedUnderlying: StateFlow<String> = _selectedUnderlying.asStateFlow()

    // Selected Book
    private val _selectedBook = MutableStateFlow("ALPHA_HEDGE_BOOK")
    val selectedBook: StateFlow<String> = _selectedBook.asStateFlow()

    // Options Chain Filter: Expiry & Moneyness
    private val _selectedExpiry = MutableStateFlow<String?>(null)
    val selectedExpiry: StateFlow<String?> = _selectedExpiry.asStateFlow()

    private val _moneynessFilter = MutableStateFlow("ALL") // "ALL", "ATM", "ITM", "OTM"
    val moneynessFilter: StateFlow<String> = _moneynessFilter.asStateFlow()

    // Synthetic Short Builder State
    private val _builderLegs = MutableStateFlow<List<OrderLeg>>(emptyList())
    val builderLegs: StateFlow<List<OrderLeg>> = _builderLegs.asStateFlow()

    private val _builderQuantity = MutableStateFlow(5)
    val builderQuantity: StateFlow<Int> = _builderQuantity.asStateFlow()

    private val _builderLimitPrice = MutableStateFlow(0.0) // Net price
    val builderLimitPrice: StateFlow<Double> = _builderLimitPrice.asStateFlow()

    private val _builderOrderType = MutableStateFlow(OrderType.NET_CREDIT_LIMIT)
    val builderOrderType: StateFlow<OrderType> = _builderOrderType.asStateFlow()

    private val _builderTif = MutableStateFlow(TimeInForce.DAY)
    val builderTif: StateFlow<TimeInForce> = _builderTif.asStateFlow()

    // Prior risk approval (invalidated upon leg change)
    private val _lastRiskResult = MutableStateFlow<RiskCheckResult?>(null)
    val lastRiskResult: StateFlow<RiskCheckResult?> = _lastRiskResult.asStateFlow()

    private val _isSubmittingOrder = MutableStateFlow(false)
    val isSubmittingOrder: StateFlow<Boolean> = _isSubmittingOrder.asStateFlow()

    // Cash and Account Balances (Simulated Institutional Margin Account)
    val totalCash = MutableStateFlow(500_000.0)
    val maintenanceMarginUsed = MutableStateFlow(0.0)

    // Data freshness & Market Feed simulation
    private val _isLiveFeedActive = MutableStateFlow(true)
    val isLiveFeedActive: StateFlow<Boolean> = _isLiveFeedActive.asStateFlow()

    private val _lastMarketTickTime = MutableStateFlow(System.currentTimeMillis())
    val lastMarketTickTime: StateFlow<Long> = _lastMarketTickTime.asStateFlow()

    // Auto market ticking job
    private var tickerJob: Job? = null

    // Reconciliation state
    private val _lastReconciliationReport = MutableStateFlow<ReconciliationEngine.ReconciliationReport?>(null)
    val lastReconciliationReport: StateFlow<ReconciliationEngine.ReconciliationReport?> = _lastReconciliationReport.asStateFlow()

    // Observables from Room
    val orders = repository.ordersFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val executions = repository.executionsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val positions = repository.positionsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditEvents = repository.auditEventsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reconciliationExceptions = repository.exceptionsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize synthetic short builder with ATM SPY pair
        loadDefaultSyntheticPair("SPY")

        // Start background high-frequency market data tick simulation
        startMarketFeed()
    }

    fun selectTab(tab: TerminalTab) {
        _currentTab.value = tab
    }

    fun selectUnderlying(symbol: String) {
        _selectedUnderlying.value = symbol
        loadDefaultSyntheticPair(symbol)
    }

    fun selectExpiry(expiry: String?) {
        _selectedExpiry.value = expiry
    }

    fun selectMoneyness(filter: String) {
        _moneynessFilter.value = filter
    }

    fun toggleLiveFeed() {
        val next = !_isLiveFeedActive.value
        _isLiveFeedActive.value = next
        if (next) startMarketFeed() else tickerJob?.cancel()
    }

    private fun startMarketFeed() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                delay(3000)
                marketData.tickMarket()
                _lastMarketTickTime.value = System.currentTimeMillis()
                recalculateBuilderPrices()
            }
        }
    }

    fun loadDefaultSyntheticPair(underlying: String) {
        val u = marketData.underlyings.value[underlying] ?: return
        val spot = u.spotPrice

        val insts = marketData.instruments.value.filter { it.underlying == underlying }
        if (insts.isEmpty()) return

        // Pick closest expiry
        val expiry = insts.first().expiry
        _selectedExpiry.value = expiry

        // Find ATM strike
        val calls = insts.filter { it.optionType == OptionType.CALL && it.expiry == expiry }
        val atmCall = calls.minByOrNull { abs(it.strike - spot) } ?: return
        val strike = atmCall.strike

        val putInst = insts.find { it.optionType == OptionType.PUT && it.expiry == expiry && it.strike == strike } ?: return
        val callInst = atmCall

        val quotes = marketData.quotes.value
        val putQ = quotes[putInst.id]
        val callQ = quotes[callInst.id]

        val putLeg = OrderLeg(
            instrumentId = putInst.id,
            underlying = underlying,
            optionType = OptionType.PUT,
            side = OrderSide.BUY, // Long Put
            quantity = _builderQuantity.value,
            strike = strike,
            expiry = expiry,
            multiplier = 100,
            bid = putQ?.bid ?: 5.0,
            ask = putQ?.ask ?: 5.2,
            limitPrice = putQ?.ask ?: 5.2
        )

        val callLeg = OrderLeg(
            instrumentId = callInst.id,
            underlying = underlying,
            optionType = OptionType.CALL,
            side = OrderSide.SELL, // Short Call
            quantity = _builderQuantity.value,
            strike = strike,
            expiry = expiry,
            multiplier = 100,
            bid = callQ?.bid ?: 5.0,
            ask = callQ?.ask ?: 5.2,
            limitPrice = callQ?.bid ?: 5.0
        )

        _builderLegs.value = listOf(putLeg, callLeg)
        _lastRiskResult.value = null // Invalidate prior risk
        recalculateBuilderPrices()
    }

    fun selectStrikeForSynthetic(strike: Double, expiry: String) {
        val underlying = _selectedUnderlying.value
        val insts = marketData.instruments.value.filter { it.underlying == underlying && it.expiry == expiry && abs(it.strike - strike) < 0.01 }
        val putInst = insts.find { it.optionType == OptionType.PUT } ?: return
        val callInst = insts.find { it.optionType == OptionType.CALL } ?: return

        val quotes = marketData.quotes.value
        val putQ = quotes[putInst.id]
        val callQ = quotes[callInst.id]

        val putLeg = OrderLeg(
            instrumentId = putInst.id,
            underlying = underlying,
            optionType = OptionType.PUT,
            side = OrderSide.BUY,
            quantity = _builderQuantity.value,
            strike = strike,
            expiry = expiry,
            multiplier = 100,
            bid = putQ?.bid ?: 0.0,
            ask = putQ?.ask ?: 0.0,
            limitPrice = putQ?.ask ?: 0.0
        )

        val callLeg = OrderLeg(
            instrumentId = callInst.id,
            underlying = underlying,
            optionType = OptionType.CALL,
            side = OrderSide.SELL,
            quantity = _builderQuantity.value,
            strike = strike,
            expiry = expiry,
            multiplier = 100,
            bid = callQ?.bid ?: 0.0,
            ask = callQ?.ask ?: 0.0,
            limitPrice = callQ?.bid ?: 0.0
        )

        _builderLegs.value = listOf(putLeg, callLeg)
        _lastRiskResult.value = null
        recalculateBuilderPrices()
    }

    fun updateQuantity(newQty: Int) {
        if (newQty <= 0) return
        _builderQuantity.value = newQty
        _builderLegs.value = _builderLegs.value.map { it.copy(quantity = newQty) }
        _lastRiskResult.value = null // Changing quantity invalidates risk approval
        recalculateBuilderPrices()
    }

    fun updateNetLimitPrice(price: Double) {
        _builderLimitPrice.value = price
        _lastRiskResult.value = null
    }

    fun updateOrderType(type: OrderType) {
        _builderOrderType.value = type
        _lastRiskResult.value = null
    }

    fun updateTimeInForce(tif: TimeInForce) {
        _builderTif.value = tif
    }

    fun reverseStrategyDirection() {
        // Swap sides: Buy Call + Sell Put (Synthetic Long)
        _builderLegs.value = _builderLegs.value.map { leg ->
            val newSide = if (leg.side == OrderSide.BUY) OrderSide.SELL else OrderSide.BUY
            leg.copy(side = newSide)
        }
        _lastRiskResult.value = null
        recalculateBuilderPrices()
    }

    private fun recalculateBuilderPrices() {
        val legs = _builderLegs.value
        if (legs.size != 2) return

        val quotes = marketData.quotes.value
        val updatedLegs = legs.map { leg ->
            val q = quotes[leg.instrumentId]
            if (q != null) {
                leg.copy(
                    bid = q.bid,
                    ask = q.ask,
                    limitPrice = if (leg.side == OrderSide.BUY) q.ask else q.bid
                )
            } else leg
        }
        _builderLegs.value = updatedLegs

        val putLeg = updatedLegs.find { it.optionType == OptionType.PUT }
        val callLeg = updatedLegs.find { it.optionType == OptionType.CALL }

        if (putLeg != null && callLeg != null) {
            // Net executable side: Call proceeds - Put cost
            val netCash = callLeg.limitPrice - putLeg.limitPrice
            _builderLimitPrice.value = Math.round(netCash * 100.0) / 100.0
        }
    }

    // Current Valuation of strategy in builder
    fun getStrategyValuation(): StrategyValuation? {
        val legs = _builderLegs.value
        if (legs.size != 2) return null
        val u = marketData.underlyings.value[_selectedUnderlying.value] ?: return null

        val putLeg = legs.find { it.optionType == OptionType.PUT } ?: return null
        val callLeg = legs.find { it.optionType == OptionType.CALL } ?: return null

        val q = marketData.quotes.value[putLeg.instrumentId]
        val vol = q?.iv ?: 0.20

        return ValuationEngine.valuateSyntheticShort(
            spot = u.spotPrice,
            strike = putLeg.strike,
            daysToExpiry = 30,
            volatility = vol,
            putBid = putLeg.bid,
            putAsk = putLeg.ask,
            callBid = callLeg.bid,
            callAsk = callLeg.ask,
            quantity = _builderQuantity.value,
            multiplier = 100
        )
    }

    fun getScenarioStressResults(): List<ScenarioResult> {
        val valn = getStrategyValuation() ?: return emptyList()
        val u = marketData.underlyings.value[_selectedUnderlying.value] ?: return emptyList()
        val strike = _builderLegs.value.firstOrNull()?.strike ?: u.spotPrice

        return ValuationEngine.runScenarioShocks(
            spot = u.spotPrice,
            strike = strike,
            daysToExpiry = 30,
            volatility = 0.22,
            baseValuation = valn,
            quantity = _builderQuantity.value,
            multiplier = 100
        )
    }

    fun runPreTradeRiskCheck(): RiskCheckResult {
        val legs = _builderLegs.value
        val syntheticOrder = SyntheticOrder(
            id = UUID.randomUUID().toString(),
            clientOrderId = "ORD-" + UUID.randomUUID().toString().take(8).uppercase(),
            bookId = _selectedBook.value,
            underlying = _selectedUnderlying.value,
            legs = legs,
            orderType = _builderOrderType.value,
            netLimitPrice = _builderLimitPrice.value,
            quantity = _builderQuantity.value,
            timeInForce = _builderTif.value,
            status = OrderState.PendingRisk,
            idempotencyKey = UUID.randomUUID().toString()
        )

        val currentGross = positions.value.sumOf { abs(it.marketValue) }
        val activeWorking = orders.value.filter { !it.isTerminal }

        val result = PreTradeRiskGate.evaluateOrder(
            order = syntheticOrder,
            currentGrossExposure = currentGross,
            availableCash = totalCash.value,
            activeOrders = activeWorking,
            quotes = marketData.quotes.value
        )
        _lastRiskResult.value = result
        return result
    }

    fun submitSyntheticOrder() {
        val legs = _builderLegs.value
        val syntheticOrder = SyntheticOrder(
            id = UUID.randomUUID().toString(),
            clientOrderId = "ORD-" + UUID.randomUUID().toString().take(8).uppercase(),
            bookId = _selectedBook.value,
            underlying = _selectedUnderlying.value,
            legs = legs,
            orderType = _builderOrderType.value,
            netLimitPrice = _builderLimitPrice.value,
            quantity = _builderQuantity.value,
            timeInForce = _builderTif.value,
            status = OrderState.PendingValidation,
            idempotencyKey = UUID.randomUUID().toString()
        )

        viewModelScope.launch {
            _isSubmittingOrder.value = true
            val currentGross = positions.value.sumOf { abs(it.marketValue) }
            val activeWorking = orders.value.filter { !it.isTerminal }

            val result = repository.validateAndSubmitOrder(
                order = syntheticOrder,
                currentGross = currentGross,
                availableCash = totalCash.value,
                activeOrders = activeWorking
            )
            _lastRiskResult.value = result
            _isSubmittingOrder.value = false

            // If approved and executed, deduct or credit cash
            if (result.decision == PreTradeDecision.APPROVED) {
                val netFlow = syntheticOrder.netLimitPrice * syntheticOrder.quantity * 100
                totalCash.value = totalCash.value + netFlow - (syntheticOrder.quantity * 2 * 0.65)
            }
        }
    }

    fun cancelOrder(orderId: String) {
        viewModelScope.launch {
            repository.cancelOrder(orderId)
        }
    }

    fun triggerReconciliation() {
        viewModelScope.launch {
            val report = repository.runReconciliation(
                orders = orders.value,
                positions = positions.value,
                executions = executions.value,
                cash = totalCash.value,
                margin = maintenanceMarginUsed.value
            )
            _lastReconciliationReport.value = report
        }
    }
}
