package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.quant.ValuationEngine
import com.example.ui.theme.*

@Composable
fun SyntheticBuilderView(
    underlying: String,
    legs: List<OrderLeg>,
    quantity: Int,
    limitPrice: Double,
    orderType: OrderType,
    timeInForce: TimeInForce,
    valuation: StrategyValuation?,
    riskResult: RiskCheckResult?,
    isSubmitting: Boolean,
    onUpdateQuantity: (Int) -> Unit,
    onUpdateLimitPrice: (Double) -> Unit,
    onReverseDirection: () -> Unit,
    onRunRiskCheck: () -> Unit,
    onSubmitOrder: () -> Unit
) {
    val scrollState = rememberScrollState()
    val compCheck = ValuationEngine.validateSyntheticShortCompatibility(legs)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .verticalScroll(scrollState)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Strategy Header Banner & Compatibility Tag
        Surface(
            color = if (compCheck.isCompatible) NavySurface else RiskRedMuted,
            border = BorderStroke(1.dp, if (compCheck.isCompatible) BrandCyan else RiskRed),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "SYNTHETIC SHORT STOCK BUILDER",
                            color = BrandCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "$underlying // Long Put + Short Call",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    IconButton(
                        onClick = onReverseDirection,
                        modifier = Modifier.size(32.dp).testTag("reverse_strategy_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Reverse strategy direction",
                            tint = BrandCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                if (compCheck.isCompatible) {
                    Text(
                        text = "VERIFIED COMPATIBLE: Matched strike, expiry, 100x multiplier and quantities.",
                        color = ExecutionGreen,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    Text(
                        text = "INCOMPATIBLE: ${compCheck.issues.joinToString(", ")}",
                        color = RiskRed,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Leg Structure Table
        Surface(
            color = NavySurface,
            border = BorderStroke(1.dp, BorderSubtle),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "STRATEGY LEGS (ATOMIC COMPLEX SPECIFICATION)",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                legs.forEachIndexed { index, leg ->
                    Surface(
                        color = NavyCard,
                        border = BorderStroke(1.dp, BorderSubtle),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = if (leg.side == OrderSide.BUY) BrandCyan.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Text(
                                        text = "${leg.side} ${leg.optionType}",
                                        color = if (leg.side == OrderSide.BUY) BrandCyan else AmberWarning,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "${leg.quantity}x Strike \$${"%.2f".format(leg.strike)} (Exp: ${leg.expiry})",
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Multiplier: ${leg.multiplier} | Bid: \$${leg.bid} / Ask: \$${leg.ask}",
                                        color = TextMuted,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Exec: \$${"%.2f".format(leg.limitPrice)}",
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = if (leg.side == OrderSide.BUY) "Pays Ask" else "Receives Bid",
                                    color = TextSecondary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Valuation & Put-Call Parity Breakdown
        if (valuation != null) {
            Surface(
                color = NavySurface,
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "VALUATION & RISK CHARACTERISTICS",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Surface(
                            color = if (valuation.isCredit) ExecutionGreenMuted else AmberMuted,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = if (valuation.isCredit) "NET CREDIT: \$${"%.2f".format(valuation.netDebitOrCredit)}" else "NET DEBIT: \$${"%.2f".format(valuation.netDebitOrCredit)}",
                                color = if (valuation.isCredit) ExecutionGreen else AmberWarning,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Grid of financial metrics
                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricCell(
                            label = "EXECUTABLE PRICE",
                            value = "\$${"%.2f".format(valuation.executableSidePrice)}",
                            subtext = "Ask vs Bid",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "STRATEGY MIDPOINT",
                            value = "\$${"%.2f".format(valuation.midpointPrice)}",
                            subtext = "Indicative only",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricCell(
                            label = "PUT-CALL PARITY FV",
                            value = "\$${"%.2f".format(valuation.theoreticalFairValue)}",
                            subtext = "Discounted forward",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "BREAK-EVEN PRICE",
                            value = "\$${"%.2f".format(valuation.breakEvenPrice)}",
                            subtext = "At expiration",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricCell(
                            label = "NET DELTA",
                            value = "${"%.1f".format(valuation.netDelta)} shs",
                            subtext = "Synthetic short share equiv",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "EST. INITIAL MARGIN",
                            value = "\$${"%.0f".format(valuation.initialMarginEstimate)}",
                            subtext = "Reg-T uncovered cap",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Multi-Leg Order Ticket Form
        Surface(
            color = NavySurface,
            border = BorderStroke(1.dp, BorderSubtle),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "MULTI-LEG ORDER TICKET",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Quantity Stepper
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ORDER CONTRACTS:",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { if (quantity > 1) onUpdateQuantity(quantity - 1) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyCard),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.size(32.dp).testTag("qty_minus_button")
                        ) {
                            Text("-", color = BrandCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = "$quantity",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        Button(
                            onClick = { onUpdateQuantity(quantity + 1) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyCard),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.size(32.dp).testTag("qty_plus_button")
                        ) {
                            Text("+", color = BrandCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Net Limit Price Editor
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "NET LIMIT PRICE (\$):",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { onUpdateLimitPrice(Math.round((limitPrice - 0.05) * 100.0) / 100.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyCard),
                            contentPadding = PaddingValues(horizontal = 6.dp),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Text("-", color = BrandCyan, fontSize = 12.sp)
                        }
                        Text(
                            text = "\$${"%.2f".format(limitPrice)}",
                            color = BrandCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Button(
                            onClick = { onUpdateLimitPrice(Math.round((limitPrice + 0.05) * 100.0) / 100.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyCard),
                            contentPadding = PaddingValues(horizontal = 6.dp),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Text("+", color = BrandCyan, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Time in Force & Venue
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "TIF: ${timeInForce.name} | ROUTING: COMPLEX NATIVE",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "VENUE: RHINO_PAPER_SIM",
                        color = ExecutionGreen,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Pre-Trade Risk Result Feedback (if evaluated)
        if (riskResult != null) {
            Surface(
                color = when (riskResult.decision) {
                    PreTradeDecision.APPROVED -> ExecutionGreenMuted.copy(alpha = 0.5f)
                    PreTradeDecision.REQUIRES_REVIEW -> AmberMuted.copy(alpha = 0.5f)
                    PreTradeDecision.REJECTED -> RiskRedMuted.copy(alpha = 0.5f)
                },
                border = BorderStroke(
                    1.dp,
                    when (riskResult.decision) {
                        PreTradeDecision.APPROVED -> ExecutionGreen
                        PreTradeDecision.REQUIRES_REVIEW -> AmberWarning
                        PreTradeDecision.REJECTED -> RiskRed
                    }
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when (riskResult.decision) {
                                PreTradeDecision.APPROVED -> Icons.Default.CheckCircle
                                PreTradeDecision.REQUIRES_REVIEW -> Icons.Default.Warning
                                PreTradeDecision.REJECTED -> Icons.Default.Error
                            },
                            contentDescription = null,
                            tint = when (riskResult.decision) {
                                PreTradeDecision.APPROVED -> ExecutionGreen
                                PreTradeDecision.REQUIRES_REVIEW -> AmberWarning
                                PreTradeDecision.REJECTED -> RiskRed
                            },
                            modifier = Modifier.size(16.dp).padding(end = 6.dp)
                        )
                        Text(
                            text = "PRE-TRADE RISK DECISION: ${riskResult.decision}",
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    riskResult.checks.filter { !it.passed }.forEach { failedRule ->
                        Text(
                            text = "[${failedRule.code}] ${failedRule.message}",
                            color = RiskRed,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    if (riskResult.decision == PreTradeDecision.APPROVED) {
                        Text(
                            text = "All 10 pre-trade rules passed. Order approved for execution routing.",
                            color = ExecutionGreen,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Action Buttons: Run Pre-Trade Check & Submit Order
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onRunRiskCheck,
                modifier = Modifier
                    .weight(1f)
                    .testTag("run_risk_check_button"),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = BrandCyan
                ),
                border = BorderStroke(1.dp, BrandCyan),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "RUN PRE-TRADE CHECK",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onSubmitOrder,
                enabled = !isSubmitting,
                modifier = Modifier
                    .weight(1f)
                    .testTag("submit_order_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandCyan,
                    contentColor = NavyVoid,
                    disabledContainerColor = NavyCard
                ),
                shape = RoundedCornerShape(4.dp)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = NavyVoid,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = "SUBMIT COMPLEX ORDER",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCell(
    label: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = NavyCard,
        border = BorderStroke(0.5.dp, BorderSubtle),
        shape = RoundedCornerShape(3.dp),
        modifier = modifier.padding(horizontal = 2.dp)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Text(
                text = label,
                color = TextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = subtext,
                color = TextSecondary,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
