package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Position
import com.example.model.ScenarioResult
import com.example.model.StrategyValuation
import com.example.ui.theme.*
import kotlin.math.abs
import kotlin.math.max

@Composable
fun RiskMonitorView(
    positions: List<Position>,
    valuation: StrategyValuation?,
    scenarioResults: List<ScenarioResult>,
    totalCash: Double,
    selectedBook: String
) {
    val totalGrossExposure = positions.sumOf { abs(it.marketValue) }
    val totalNetExposure = positions.sumOf { it.marketValue }
    val totalUnrealizedPnl = positions.sumOf { it.unrealizedPnl }
    val totalDeltaEquivalent = positions.sumOf { it.deltaEquivalent }
    val marginRequirement = positions.sumOf { it.marginRequirement }
    val buyingPowerUsedPct = if (totalCash > 0) (marginRequirement / totalCash) * 100.0 else 0.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Book Header & Summary
        item {
            Surface(
                color = NavySurface,
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PORTFOLIO RISK // $selectedBook",
                            color = BrandCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Surface(
                            color = if (totalUnrealizedPnl >= 0) ExecutionGreenMuted else RiskRedMuted,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = "UNREALIZED P&L: ${if (totalUnrealizedPnl >= 0) "+" else ""}\$${"%.2f".format(totalUnrealizedPnl)}",
                                color = if (totalUnrealizedPnl >= 0) ExecutionGreen else RiskRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricCell(
                            label = "GROSS EXPOSURE",
                            value = "\$${"%.0f".format(totalGrossExposure)}",
                            subtext = "Book limit: \$1,000,000",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "NET DELTA EQUIV",
                            value = "${"%.1f".format(totalDeltaEquivalent)} shs",
                            subtext = "Short directional bias",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricCell(
                            label = "EST. MARGIN REQ",
                            value = "\$${"%.0f".format(marginRequirement)}",
                            subtext = "House margin buffer",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCell(
                            label = "BUYING POWER USED",
                            value = "${"%.1f".format(buyingPowerUsedPct)}%",
                            subtext = "Available: \$${"%.0f".format(max(0.0, totalCash - marginRequirement))}",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Linear Progress Bar for Margin utilization
                    LinearProgressIndicator(
                        progress = { (buyingPowerUsedPct / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = if (buyingPowerUsedPct > 80.0) RiskRed else if (buyingPowerUsedPct > 50.0) AmberWarning else ExecutionGreen,
                        trackColor = NavyCard
                    )
                }
            }
        }

        // Full Revaluation Scenario Matrix
        item {
            Surface(
                color = NavySurface,
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "FULL-REVALUATION STRESS TESTING (SHOCK MATRIX)",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Non-linear revaluation under simultaneous underlying, volatility, and decay shocks",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Table Header
                    Surface(
                        color = NavyVoid,
                        border = BorderStroke(0.5.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp, horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SCENARIO",
                                color = TextSecondary,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.2f),
                                textAlign = TextAlign.Start
                            )
                            Text(
                                text = "STRESSED SPOT",
                                color = TextSecondary,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.0f),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "P&L IMPACT",
                                color = TextSecondary,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.0f),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "STRESSED DELTA",
                                color = TextSecondary,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.0f),
                                textAlign = TextAlign.End
                            )
                        }
                    }

                    // Scenario Rows
                    scenarioResults.forEach { res ->
                        Surface(
                            color = NavyCard,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp, horizontal = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = res.shock.name,
                                    color = TextPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1.2f),
                                    textAlign = TextAlign.Start
                                )
                                Text(
                                    text = "\$${"%.2f".format(res.stressedSpot)}",
                                    color = TextSecondary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1.0f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "${if (res.pnlImpact >= 0) "+" else ""}\$${"%.0f".format(res.pnlImpact)}",
                                    color = if (res.pnlImpact >= 0) ExecutionGreen else RiskRed,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1.0f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "${"%.1f".format(res.stressedDelta)} shs",
                                    color = TextPrimary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1.0f),
                                    textAlign = TextAlign.End
                                )
                            }
                        }
                        HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
                    }
                }
            }
        }

        // Active Risk Limits Table
        item {
            Surface(
                color = NavySurface,
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "AUTHORITATIVE DESK RISK LIMITS",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    RiskLimitRow(
                        rule = "MAX ORDER NOTIONAL",
                        threshold = "\$250,000",
                        status = "COMPLIANT"
                    )
                    RiskLimitRow(
                        rule = "MAX GROSS BOOK EXPOSURE",
                        threshold = "\$1,000,000",
                        status = "COMPLIANT"
                    )
                    RiskLimitRow(
                        rule = "CONCENTRATION CAP (SINGLE NAME)",
                        threshold = "35% of Gross",
                        status = "COMPLIANT"
                    )
                    RiskLimitRow(
                        rule = "MIN CASH LIQUIDITY BUFFER",
                        threshold = "\$25,000",
                        status = "COMPLIANT"
                    )
                    RiskLimitRow(
                        rule = "MAX QUOTE STALENESS",
                        threshold = "10,000 ms",
                        status = "ACTIVE ENFORCEMENT"
                    )
                }
            }
        }
    }
}

@Composable
fun RiskLimitRow(rule: String, threshold: String, status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = rule,
                color = TextPrimary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Cap: $threshold",
                color = TextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Surface(
            color = ExecutionGreenMuted,
            shape = RoundedCornerShape(2.dp)
        ) {
            Text(
                text = status,
                color = ExecutionGreen,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }
    }
    HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
}
