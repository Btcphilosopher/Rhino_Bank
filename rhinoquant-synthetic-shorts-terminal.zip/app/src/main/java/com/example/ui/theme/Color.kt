package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RhinoQuant Institutional Color Palette
// Dark navy, graphite, steel grey, restrained amber warnings, crisp accents
val NavyVoid = Color(0xFF040810)
val NavyDeep = Color(0xFF0A1120)
val NavySurface = Color(0xFF101C30)
val NavyCard = Color(0xFF162540)
val NavyCardElevated = Color(0xFF1E3152)

val BorderSubtle = Color(0xFF223554)
val BorderProminent = Color(0xFF334B75)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Functional indicators
val BrandCyan = Color(0xFF38BDF8)
val ExecutionGreen = Color(0xFF10B981)
val ExecutionGreenMuted = Color(0xFF064E3B)
val AmberWarning = Color(0xFFF59E0B)
val AmberMuted = Color(0xFF78350F)
val RiskRed = Color(0xFFEF4444)
val RiskRedMuted = Color(0xFF7F1D1D)
val AccentPurple = Color(0xFFA855F7)
