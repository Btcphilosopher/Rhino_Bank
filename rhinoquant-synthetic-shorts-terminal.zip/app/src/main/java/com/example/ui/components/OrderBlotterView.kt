package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun OrderBlotterView(
    orders: List<SyntheticOrder>,
    executions: List<ExecutionReport>,
    positions: List<Position>,
    onCancelOrder: (String) -> Unit
) {
    var subTab by remember { mutableStateOf("ORDERS") } // "ORDERS" | "EXECUTIONS" | "POSITIONS"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .padding(8.dp)
    ) {
        // Blotter sub-navigation pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ORDERS", "EXECUTIONS", "POSITIONS").forEach { tab ->
                val isSelected = tab == subTab
                Surface(
                    color = if (isSelected) NavyCardElevated else NavySurface,
                    border = BorderStroke(1.dp, if (isSelected) BrandCyan else BorderSubtle),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    TextButton(
                        onClick = { subTab = tab },
                        contentPadding = PaddingValues(vertical = 4.dp),
                        modifier = Modifier.testTag("blotter_subtab_$tab")
                    ) {
                        Text(
                            text = when (tab) {
                                "ORDERS" -> "ORDERS (${orders.size})"
                                "EXECUTIONS" -> "FILLS (${executions.size})"
                                else -> "POSITIONS (${positions.size})"
                            },
                            color = if (isSelected) BrandCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // SubTab content
        when (subTab) {
            "ORDERS" -> {
                if (orders.isEmpty()) {
                    EmptyBlotterState("No active or historical orders submitted.")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(1.dp, BorderSubtle),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(orders) { order ->
                            OrderItemCard(order = order, onCancel = { onCancelOrder(order.id) })
                        }
                    }
                }
            }
            "EXECUTIONS" -> {
                if (executions.isEmpty()) {
                    EmptyBlotterState("No confirmed execution fill reports received yet.")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(1.dp, BorderSubtle),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(executions) { exec ->
                            ExecutionItemCard(exec = exec)
                        }
                    }
                }
            }
            "POSITIONS" -> {
                if (positions.isEmpty()) {
                    EmptyBlotterState("No open derivative positions derived from confirmed fills.")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(1.dp, BorderSubtle),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(positions) { pos ->
                            PositionItemCard(pos = pos)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrderItemCard(order: SyntheticOrder, onCancel: () -> Unit) {
    Surface(
        color = NavySurface,
        border = BorderStroke(1.dp, BorderSubtle),
        shape = RoundedCornerShape(3.dp),
        modifier = Modifier.fillMaxWidth().testTag("order_card_${order.clientOrderId}")
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = order.clientOrderId,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${order.underlying} // ${order.quantity}x Complex",
                        color = BrandCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    color = when (order.status) {
                        OrderState.Filled -> ExecutionGreenMuted
                        OrderState.PartiallyFilled -> AmberMuted
                        OrderState.Cancelled -> NavyCard
                        OrderState.Rejected -> RiskRedMuted
                        else -> NavyCardElevated
                    },
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = order.status.name.uppercase(),
                        color = when (order.status) {
                            OrderState.Filled -> ExecutionGreen
                            OrderState.PartiallyFilled -> AmberWarning
                            OrderState.Cancelled -> TextMuted
                            OrderState.Rejected -> RiskRed
                            else -> BrandCyan
                        },
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Limit: \$${"%.2f".format(order.netLimitPrice)} | TIF: ${order.timeInForce} | Legs: ${order.legs.size}",
                color = TextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )

            if (order.rejectionMessage != null) {
                Text(
                    text = "Note: ${order.rejectionMessage}",
                    color = if (order.status == OrderState.Rejected) RiskRed else TextMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Cancel action if order is working
            if (order.status in listOf(OrderState.Submitted, OrderState.Acknowledged, OrderState.PartiallyFilled)) {
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = onCancel,
                    colors = ButtonDefaults.buttonColors(containerColor = RiskRedMuted),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.align(Alignment.End).testTag("cancel_order_button")
                ) {
                    Text(
                        text = "REQUEST CANCEL",
                        color = RiskRed,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun ExecutionItemCard(exec: ExecutionReport) {
    Surface(
        color = NavySurface,
        border = BorderStroke(1.dp, BorderSubtle),
        shape = RoundedCornerShape(3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = exec.executionId,
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = if (exec.side == OrderSide.BUY) BrandCyan.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text(
                            text = exec.side.name,
                            color = if (exec.side == OrderSide.BUY) BrandCyan else AmberWarning,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                        )
                    }
                }
                Text(
                    text = "${exec.instrumentId} (Ref: ${exec.clientOrderId})",
                    color = TextMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${exec.filledQty}x @ \$${"%.2f".format(exec.fillPrice)}",
                    color = ExecutionGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Fee: \$${"%.2f".format(exec.fee)} | ${exec.venue}",
                    color = TextSecondary,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun PositionItemCard(pos: Position) {
    Surface(
        color = NavySurface,
        border = BorderStroke(1.dp, BorderSubtle),
        shape = RoundedCornerShape(3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = pos.instrumentId,
                    color = TextPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Qty: ${pos.quantity} contracts (${pos.quantity * pos.multiplier} shs) | Avg Cost: \$${"%.2f".format(pos.avgCost)}",
                    color = TextSecondary,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Mark: \$${"%.2f".format(pos.currentMarketPrice)} | Delta Eq: ${"%.1f".format(pos.deltaEquivalent)}",
                    color = TextMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                val pnl = pos.unrealizedPnl
                Text(
                    text = "${if (pnl >= 0) "+" else ""}\$${"%.2f".format(pnl)}",
                    color = if (pnl >= 0) ExecutionGreen else RiskRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Unrealized P&L",
                    color = TextMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun EmptyBlotterState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, BorderSubtle)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            color = TextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
