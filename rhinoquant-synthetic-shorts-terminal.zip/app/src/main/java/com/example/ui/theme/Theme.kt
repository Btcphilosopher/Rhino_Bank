package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RhinoDarkColorScheme = darkColorScheme(
    primary = BrandCyan,
    onPrimary = NavyVoid,
    primaryContainer = NavyCardElevated,
    onPrimaryContainer = TextPrimary,
    secondary = AmberWarning,
    onSecondary = NavyVoid,
    secondaryContainer = AmberMuted,
    onSecondaryContainer = AmberWarning,
    tertiary = ExecutionGreen,
    onTertiary = NavyVoid,
    tertiaryContainer = ExecutionGreenMuted,
    onTertiaryContainer = ExecutionGreen,
    error = RiskRed,
    onError = NavyVoid,
    errorContainer = RiskRedMuted,
    onErrorContainer = RiskRed,
    background = NavyDeep,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavyCard,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderProminent
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // RhinoQuant is an institutional workstation terminal locked to calibrated dark theme
    MaterialTheme(
        colorScheme = RhinoDarkColorScheme,
        typography = Typography,
        content = content
    )
}
