package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.execution.ReconciliationEngine
import com.example.model.AuditEvent
import com.example.model.DiscrepancySeverity
import com.example.model.ReconciliationException
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReconciliationView(
    reconciliationReport: ReconciliationEngine.ReconciliationReport?,
    exceptions: List<ReconciliationException>,
    auditEvents: List<AuditEvent>,
    onTriggerRecon: () -> Unit
) {
    var subTab by remember { mutableStateOf("EXCEPTIONS") } // "EXCEPTIONS" | "AUDIT" | "PROVIDERS"
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .padding(8.dp)
    ) {
        // Run Reconciliation Header Card
        Surface(
            color = NavySurface,
            border = BorderStroke(1.dp, BorderSubtle),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "LEDGER & PROVIDER RECONCILIATION",
                        color = BrandCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (reconciliationReport != null)
                            "Last Run: ${timeFormat.format(Date(reconciliationReport.timestamp))} | Matched: ${reconciliationReport.matchedCount} | Exceptions: ${reconciliationReport.exceptions.size}"
                        else "No reconciliation run executed this session.",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = onTriggerRecon,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandCyan, contentColor = NavyVoid),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier.testTag("trigger_recon_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Run reconciliation",
                        modifier = Modifier.size(14.dp).padding(end = 4.dp)
                    )
                    Text(
                        text = "RUN RECON",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Subtabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("EXCEPTIONS", "AUDIT", "PROVIDERS").forEach { tab ->
                val isSelected = tab == subTab
                Surface(
                    color = if (isSelected) NavyCardElevated else NavySurface,
                    border = BorderStroke(1.dp, if (isSelected) BrandCyan else BorderSubtle),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    TextButton(
                        onClick = { subTab = tab },
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text(
                            text = when (tab) {
                                "EXCEPTIONS" -> "DISCREPANCIES (${exceptions.size})"
                                "AUDIT" -> "AUDIT LOG (${auditEvents.size})"
                                else -> "CONNECTIVITY"
                            },
                            color = if (isSelected) BrandCyan else TextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Content
        when (subTab) {
            "EXCEPTIONS" -> {
                if (exceptions.isEmpty()) {
                    Surface(
                        color = NavySurface,
                        border = BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxSize().padding(top = 4.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = ExecutionGreen,
                                    modifier = Modifier.size(16.dp).padding(end = 4.dp)
                                )
                                Text(
                                    text = "Zero reconciliation exceptions. Internal ledger matches venue records 100%.",
                                    color = ExecutionGreen,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(1.dp, BorderSubtle),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(exceptions) { exc ->
                            Surface(
                                color = NavySurface,
                                border = BorderStroke(1.dp, if (exc.severity == DiscrepancySeverity.CRITICAL) RiskRed else AmberWarning),
                                shape = RoundedCornerShape(3.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "[${exc.severity}] ${exc.instrument} (${exc.entityType})",
                                            color = if (exc.severity == DiscrepancySeverity.CRITICAL) RiskRed else AmberWarning,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = exc.status.name,
                                            color = TextSecondary,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Internal: ${exc.internalValue} vs Provider: ${exc.providerValue} (Diff: ${exc.difference})",
                                        color = TextPrimary,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = exc.notes,
                                        color = TextMuted,
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
            "AUDIT" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(1.dp, BorderSubtle),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    items(auditEvents) { ev ->
                        Surface(
                            color = NavySurface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = timeFormat.format(Date(ev.timestamp)),
                                    color = TextMuted,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.width(68.dp)
                                )
                                Text(
                                    text = ev.eventType,
                                    color = when (ev.severity) {
                                        "CRITICAL" -> RiskRed
                                        "WARNING" -> AmberWarning
                                        else -> BrandCyan
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.width(130.dp)
                                )
                                Text(
                                    text = ev.details,
                                    color = TextPrimary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
                    }
                }
            }
            "PROVIDERS" -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(1.dp, BorderSubtle)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Paper Provider Status
                    Surface(
                        color = NavySurface,
                        border = BorderStroke(1.dp, BorderSubtle),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PROVIDER: RHINO_PAPER_SIM",
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Surface(
                                    color = ExecutionGreenMuted,
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Text(
                                        text = "OPERATIONAL",
                                        color = ExecutionGreen,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Capabilities: COMPLEX_ORDERS, PARTIAL_FILLS, CANCELLATIONS, RECONCILIATION_QUERY",
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Mode: Deterministic & Interactive liquidity matching engine with slippage modelling.",
                                color = TextMuted,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Live Institutional FIX Broker Status
                    Surface(
                        color = NavySurface,
                        border = BorderStroke(1.dp, BorderSubtle),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PROVIDER: CBOE_DIRECT_FIX",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Surface(
                                    color = NavyCard,
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Text(
                                        text = "UNCONFIGURED (DISABLED)",
                                        color = TextMuted,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Live execution remains strictly disabled until authorized FIX credentials and clearing membership are securely configured.",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
