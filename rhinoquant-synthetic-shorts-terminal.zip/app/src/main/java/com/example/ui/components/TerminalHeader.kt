package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UnderlyingQuote
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    selectedUnderlying: String,
    underlyings: Map<String, UnderlyingQuote>,
    selectedBook: String,
    totalCash: Double,
    isLiveFeedActive: Boolean,
    lastTickTime: Long,
    onSelectUnderlying: (String) -> Unit,
    onToggleFeed: () -> Unit
) {
    val currentQuote = underlyings[selectedUnderlying]
    val feedAge = System.currentTimeMillis() - lastTickTime

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(NavyVoid)
            .border(1.dp, BorderSubtle)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Top bar: Branding & Provider Status Indicators
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = NavyCardElevated,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        text = "RHINOQUANT",
                        color = BrandCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
                Text(
                    text = "SYNTHETIC SHORTS // EXECUTION TERMINAL",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Provider connection badges
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Paper Provider (Active)
                Surface(
                    color = ExecutionGreenMuted,
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FiberManualRecord,
                            contentDescription = "Paper online",
                            tint = ExecutionGreen,
                            modifier = Modifier.size(7.dp).padding(end = 3.dp)
                        )
                        Text(
                            text = "PAPER: ACTIVE",
                            color = ExecutionGreen,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Live Broker (Unavailable / Disconnected)
                Surface(
                    color = NavyCard,
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FiberManualRecord,
                            contentDescription = "Live offline",
                            tint = TextMuted,
                            modifier = Modifier.size(7.dp).padding(end = 3.dp)
                        )
                        Text(
                            text = "LIVE: DISABLED",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Feed indicator
                Surface(
                    color = if (feedAge < 5000) NavyCard else AmberMuted,
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier
                        .clickable { onToggleFeed() }
                        .testTag("feed_toggle_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isLiveFeedActive) "FEED: ${feedAge}ms" else "FEED: PAUSED",
                            color = if (feedAge < 5000) TextSecondary else AmberWarning,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Underlying Ticker Chips & Spot Quote
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                underlyings.keys.forEach { sym ->
                    val isSelected = sym == selectedUnderlying
                    Surface(
                        color = if (isSelected) BrandCyan.copy(alpha = 0.15f) else NavySurface,
                        border = BorderStroke(1.dp, if (isSelected) BrandCyan else BorderSubtle),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .clickable { onSelectUnderlying(sym) }
                            .testTag("ticker_select_$sym")
                    ) {
                        Text(
                            text = sym,
                            color = if (isSelected) BrandCyan else TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Spot Price Display
            if (currentQuote != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "\$${"%.2f".format(currentQuote.spotPrice)}",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${if (currentQuote.change >= 0) "+" else ""}${"%.2f".format(currentQuote.change)} (${"%.2f".format(currentQuote.changePct)}%)",
                        color = if (currentQuote.change >= 0) ExecutionGreen else RiskRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
