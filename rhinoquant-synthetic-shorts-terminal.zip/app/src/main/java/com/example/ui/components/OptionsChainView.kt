package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Instrument
import com.example.model.OptionType
import com.example.model.Quote
import com.example.model.UnderlyingQuote
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun OptionsChainView(
    underlying: String,
    spotQuote: UnderlyingQuote?,
    instruments: List<Instrument>,
    quotes: Map<String, Quote>,
    selectedExpiry: String?,
    moneynessFilter: String,
    onSelectExpiry: (String) -> Unit,
    onSelectMoneyness: (String) -> Unit,
    onSelectStrikeForSynthetic: (Double, String) -> Unit
) {
    val spot = spotQuote?.spotPrice ?: 100.0
    val underlyingInsts = instruments.filter { it.underlying == underlying }
    val expiries = underlyingInsts.map { it.expiry }.distinct().sorted()
    val activeExpiry = selectedExpiry ?: expiries.firstOrNull() ?: ""

    // Group into strikes
    val strikesForExpiry = underlyingInsts
        .filter { it.expiry == activeExpiry }
        .map { it.strike }
        .distinct()
        .sorted()

    val filteredStrikes = strikesForExpiry.filter { strike ->
        when (moneynessFilter) {
            "ATM" -> abs(strike - spot) / spot <= 0.03
            "ITM" -> strike < spot
            "OTM" -> strike > spot
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .padding(8.dp)
    ) {
        // Expiry selection tabs & Moneyness filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Expiries
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                expiries.forEach { exp ->
                    val isExpSelected = exp == activeExpiry
                    Surface(
                        color = if (isExpSelected) NavyCardElevated else NavySurface,
                        border = BorderStroke(1.dp, if (isExpSelected) BrandCyan else BorderSubtle),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier
                            .clickable { onSelectExpiry(exp) }
                            .testTag("expiry_chip_$exp")
                    ) {
                        Text(
                            text = exp,
                            color = if (isExpSelected) BrandCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isExpSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // Moneyness
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("ALL", "ATM", "ITM", "OTM").forEach { mode ->
                    val isModeSelected = mode == moneynessFilter
                    Surface(
                        color = if (isModeSelected) BrandCyan.copy(alpha = 0.2f) else NavySurface,
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.clickable { onSelectMoneyness(mode) }
                    ) {
                        Text(
                            text = mode,
                            color = if (isModeSelected) BrandCyan else TextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Table Header
        Surface(
            color = NavyVoid,
            border = BorderStroke(1.dp, BorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Calls
                Text(
                    text = "CALL BID/ASK",
                    color = BrandCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1.3f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "IV %",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(0.7f),
                    textAlign = TextAlign.Center
                )

                // Strike
                Text(
                    text = "STRIKE",
                    color = TextPrimary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1.0f),
                    textAlign = TextAlign.Center
                )

                // Puts
                Text(
                    text = "IV %",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(0.7f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "PUT BID/ASK",
                    color = AmberWarning,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1.3f),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Option Rows
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, BorderSubtle)
        ) {
            items(filteredStrikes) { strike ->
                val callInst = underlyingInsts.find { it.expiry == activeExpiry && it.strike == strike && it.optionType == OptionType.CALL }
                val putInst = underlyingInsts.find { it.expiry == activeExpiry && it.strike == strike && it.optionType == OptionType.PUT }

                val callQ = callInst?.let { quotes[it.id] }
                val putQ = putInst?.let { quotes[it.id] }

                val isAtm = abs(strike - spot) / spot <= 0.01

                Surface(
                    color = if (isAtm) NavyCardElevated.copy(alpha = 0.5f) else NavySurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectStrikeForSynthetic(strike, activeExpiry) }
                        .testTag("option_row_${strike.toInt()}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp, horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Call Bid / Ask
                        Text(
                            text = "${callQ?.bid ?: "-"} / ${callQ?.ask ?: "-"}",
                            color = TextPrimary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.3f),
                            textAlign = TextAlign.Center
                        )
                        // Call IV
                        Text(
                            text = if (callQ != null) "${(callQ.iv * 100).toInt()}%" else "-",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.Center
                        )

                        // Strike Badge (clickable into synthetic builder)
                        Surface(
                            color = if (isAtm) BrandCyan.copy(alpha = 0.2f) else NavyCard,
                            border = BorderStroke(1.dp, if (isAtm) BrandCyan else BorderSubtle),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1.0f)
                        ) {
                            Text(
                                text = "%.2f".format(strike),
                                color = if (isAtm) BrandCyan else TextPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }

                        // Put IV
                        Text(
                            text = if (putQ != null) "${(putQ.iv * 100).toInt()}%" else "-",
                            color = TextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.Center
                        )

                        // Put Bid / Ask
                        Text(
                            text = "${putQ?.bid ?: "-"} / ${putQ?.ask ?: "-"}",
                            color = TextPrimary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.3f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
                HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
            }
        }
    }
}
