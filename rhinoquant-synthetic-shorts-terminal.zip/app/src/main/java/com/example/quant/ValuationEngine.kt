package com.example.quant

import com.example.model.*
import kotlin.math.abs
import kotlin.math.max

object ValuationEngine {

    data class LegCompatibilityResult(
        val isCompatible: Boolean,
        val issues: List<String>
    )

    fun validateSyntheticShortCompatibility(legs: List<OrderLeg>): LegCompatibilityResult {
        val issues = mutableListOf<String>()

        if (legs.size != 2) {
            issues.add("Synthetic short must contain exactly 2 legs (Long Put + Short Call). Found: ${legs.size}")
            return LegCompatibilityResult(false, issues)
        }

        val putLeg = legs.find { it.optionType == OptionType.PUT }
        val callLeg = legs.find { it.optionType == OptionType.CALL }

        if (putLeg == null) {
            issues.add("Missing required Put leg.")
        }
        if (callLeg == null) {
            issues.add("Missing required Call leg.")
        }

        if (putLeg != null && callLeg != null) {
            if (putLeg.side != OrderSide.BUY) {
                issues.add("Synthetic short requires LONG Put (Buy). Found: ${putLeg.side}")
            }
            if (callLeg.side != OrderSide.SELL) {
                issues.add("Synthetic short requires SHORT Call (Sell). Found: ${callLeg.side}")
            }
            if (putLeg.underlying != callLeg.underlying) {
                issues.add("Mismatched underlying: Put is ${putLeg.underlying}, Call is ${callLeg.underlying}")
            }
            if (abs(putLeg.strike - callLeg.strike) > 0.001) {
                issues.add("Mismatched strikes: Put strike is ${putLeg.strike}, Call strike is ${callLeg.strike}")
            }
            if (putLeg.expiry != callLeg.expiry) {
                issues.add("Mismatched expiries: Put expiry is ${putLeg.expiry}, Call expiry is ${callLeg.expiry}")
            }
            if (putLeg.multiplier != callLeg.multiplier) {
                issues.add("Mismatched multipliers: Put is ${putLeg.multiplier}, Call is ${callLeg.multiplier}")
            }
            if (putLeg.quantity != callLeg.quantity) {
                issues.add("Mismatched quantities: Put is ${putLeg.quantity}, Call is ${callLeg.quantity}")
            }
        }

        return LegCompatibilityResult(issues.isEmpty(), issues)
    }

    fun valuateSyntheticShort(
        spot: Double,
        strike: Double,
        daysToExpiry: Int,
        volatility: Double,
        putBid: Double,
        putAsk: Double,
        callBid: Double,
        callAsk: Double,
        quantity: Int = 1,
        multiplier: Int = 100,
        riskFreeRate: Double = 0.045,
        dividendYield: Double = 0.012,
        borrowRate: Double = 0.0075
    ): StrategyValuation {
        val t = max(0.0001, daysToExpiry / 365.0)

        // Midpoint prices
        val putMid = (putBid + putAsk) / 2.0
        val callMid = (callBid + callAsk) / 2.0
        val midNetCash = (callMid - putMid) // Call received - Put paid

        // Executable prices: Buy Put at Ask, Sell Call at Bid
        val putPay = putAsk
        val callReceive = callBid
        val executableNetCash = (callReceive - putPay) // If positive, net credit. If negative, net debit.

        // Theoretical Greeks from Black-Scholes
        val putGreeks = BlackScholes.calculateGreeks(spot, strike, t, volatility, riskFreeRate, dividendYield, OptionType.PUT)
        val callGreeks = BlackScholes.calculateGreeks(spot, strike, t, volatility, riskFreeRate, dividendYield, OptionType.CALL)

        // Synthetic short: +1 Put, -1 Call
        val netDelta = (putGreeks.delta - callGreeks.delta) * quantity * multiplier
        val netGamma = (putGreeks.gamma - callGreeks.gamma) * quantity * multiplier
        val netVega = (putGreeks.vega - callGreeks.vega) * quantity * multiplier
        val netTheta = (putGreeks.theta - callGreeks.theta) * quantity * multiplier

        // Theoretical fair value via put-call parity
        val theoreticalParity = BlackScholes.putCallParityFairValue(spot, strike, t, riskFreeRate, dividendYield)

        // Forward price under cost of carry
        val carryRate = riskFreeRate - dividendYield + borrowRate
        val theoreticalForward = spot * kotlin.math.exp(carryRate * t)

        // Break even: Strike + Net Credit (or Strike - Net Debit)
        val netPremiumPerShare = executableNetCash
        val breakEven = strike + netPremiumPerShare

        // Transaction fees estimation (e.g. $0.65 per option contract leg)
        val feePerContract = 0.65
        val estimatedFees = feePerContract * 2 * quantity

        // Margin requirement estimation (CBOE / FINRA uncovered short call margin with put offset)
        // Short call margin: Greater of [20% underlying - OTM amount + premium] or [10% underlying + premium]
        // Since call and put have same strike, otm amount is 0 if ATM.
        val notionalValue = spot * quantity * multiplier
        val baseMargin = notionalValue * 0.20
        val initialMargin = baseMargin + max(0.0, -executableNetCash * quantity * multiplier)
        val maintenanceMargin = notionalValue * 0.15

        val carryCost = notionalValue * borrowRate * t

        return StrategyValuation(
            netDebitOrCredit = executableNetCash * quantity * multiplier,
            isCredit = executableNetCash >= 0,
            midpointPrice = midNetCash,
            executableSidePrice = executableNetCash,
            theoreticalForwardPrice = theoreticalForward,
            theoreticalFairValue = theoreticalParity,
            breakEvenPrice = breakEven,
            maxGain = breakEven * quantity * multiplier, // If stock falls to 0
            maxLoss = Double.POSITIVE_INFINITY, // Stock can rise without limit
            netDelta = netDelta,
            netGamma = netGamma,
            netVega = netVega,
            netTheta = netTheta,
            estimatedTransactionCosts = estimatedFees,
            initialMarginEstimate = initialMargin,
            maintenanceMarginEstimate = maintenanceMargin,
            carryCostEstimate = carryCost
        )
    }

    fun runScenarioShocks(
        spot: Double,
        strike: Double,
        daysToExpiry: Int,
        volatility: Double,
        baseValuation: StrategyValuation,
        quantity: Int = 1,
        multiplier: Int = 100
    ): List<ScenarioResult> {
        val shocks = listOf(
            ScenarioShock("SHOCK_CRASH_20", "Underlying -20%", -0.20, 0.08, 0),
            ScenarioShock("SHOCK_DOWN_10", "Underlying -10%", -0.10, 0.04, 0),
            ScenarioShock("SHOCK_DOWN_5", "Underlying -5%", -0.05, 0.02, 0),
            ScenarioShock("SHOCK_UP_5", "Underlying +5%", 0.05, -0.02, 0),
            ScenarioShock("SHOCK_UP_10", "Underlying +10%", 0.10, -0.03, 0),
            ScenarioShock("SHOCK_RALLY_20", "Underlying +20%", 0.20, -0.05, 0),
            ScenarioShock("SHOCK_DECAY_7D", "Time Decay 7 Days", 0.0, 0.0, 7),
            ScenarioShock("SHOCK_VOL_SPIKE", "Vol Spike +10 Pts", 0.0, 0.10, 0)
        )

        return shocks.map { shock ->
            val stressedSpot = spot * (1.0 + shock.priceShockPct)
            val stressedVol = max(0.05, volatility + shock.volShockPts)
            val stressedDays = max(1, daysToExpiry - shock.daysDecay)
            val t = stressedDays / 365.0

            val putG = BlackScholes.calculateGreeks(stressedSpot, strike, t, stressedVol, 0.045, 0.012, OptionType.PUT)
            val callG = BlackScholes.calculateGreeks(stressedSpot, strike, t, stressedVol, 0.045, 0.012, OptionType.CALL)

            val newSyntheticValue = (putG.price - callG.price) // Synthetic short value
            val initialEntry = (strike - spot) // Base intrinsic baseline
            val pnlImpact = -(stressedSpot - spot) * quantity * multiplier // Synthetic short gains on drop, loses on rally

            val newDelta = (putG.delta - callG.delta) * quantity * multiplier
            val newGamma = (putG.gamma - callG.gamma) * quantity * multiplier
            val newVega = (putG.vega - callG.vega) * quantity * multiplier

            val stressedMargin = stressedSpot * quantity * multiplier * 0.20

            ScenarioResult(
                shock = shock,
                stressedSpot = stressedSpot,
                pnlImpact = pnlImpact,
                pnlPct = (pnlImpact / (spot * quantity * multiplier)) * 100.0,
                stressedDelta = newDelta,
                stressedGamma = newGamma,
                stressedVega = newVega,
                stressedMargin = stressedMargin
            )
        }
    }
}
