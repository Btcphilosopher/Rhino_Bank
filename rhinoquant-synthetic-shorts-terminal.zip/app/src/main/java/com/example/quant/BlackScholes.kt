package com.example.quant

import com.example.model.OptionGreeks
import com.example.model.OptionType
import kotlin.math.*

object BlackScholes {

    // Standard Normal Cumulative Distribution Function (Abramowitz and Stegun 26.2.17)
    fun normCdf(x: Double): Double {
        if (x < -8.0) return 0.0
        if (x > 8.0) return 1.0

        val p = 0.2316419
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429

        val t = 1.0 / (1.0 + p * abs(x))
        val phi = (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
        val poly = t * (b1 + t * (b2 + t * (b3 + t * (b4 + t * b5))))
        val cdf = 1.0 - phi * poly

        return if (x < 0.0) 1.0 - cdf else cdf
    }

    fun normPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    /**
     * Calculate European option price and Greeks using Black-Scholes-Merton.
     * @param spot Spot price of underlying S
     * @param strike Strike price K
     * @param timeToExpiry Years to expiration T
     * @param volatility Annualized volatility sigma (e.g. 0.25)
     * @param riskFreeRate Annualized risk-free interest rate r (e.g. 0.045)
     * @param dividendYield Annualized continuous dividend yield q (e.g. 0.015)
     * @param optionType CALL or PUT
     */
    fun calculateGreeks(
        spot: Double,
        strike: Double,
        timeToExpiry: Double,
        volatility: Double,
        riskFreeRate: Double = 0.045,
        dividendYield: Double = 0.012,
        optionType: OptionType
    ): OptionGreeks {
        if (timeToExpiry <= 0.0001) {
            // At expiration intrinsic valuation
            val intrinsic = when (optionType) {
                OptionType.CALL -> max(0.0, spot - strike)
                OptionType.PUT -> max(0.0, strike - spot)
            }
            val delta = when (optionType) {
                OptionType.CALL -> if (spot > strike) 1.0 else 0.0
                OptionType.PUT -> if (spot < strike) -1.0 else 0.0
            }
            return OptionGreeks(
                price = intrinsic,
                delta = delta,
                gamma = 0.0,
                vega = 0.0,
                theta = 0.0,
                rho = 0.0
            )
        }

        val sigma = max(0.001, volatility)
        val t = max(0.0001, timeToExpiry)
        val sqrtT = sqrt(t)

        val d1 = (ln(spot / strike) + (riskFreeRate - dividendYield + 0.5 * sigma * sigma) * t) / (sigma * sqrtT)
        val d2 = d1 - sigma * sqrtT

        val dfDividend = exp(-dividendYield * t)
        val dfRate = exp(-riskFreeRate * t)

        val normPdfD1 = normPdf(d1)

        val price: Double
        val delta: Double
        val theta: Double
        val rho: Double

        when (optionType) {
            OptionType.CALL -> {
                price = spot * dfDividend * normCdf(d1) - strike * dfRate * normCdf(d2)
                delta = dfDividend * normCdf(d1)
                theta = (-(spot * dfDividend * normPdfD1 * sigma) / (2.0 * sqrtT)
                        - riskFreeRate * strike * dfRate * normCdf(d2)
                        + dividendYield * spot * dfDividend * normCdf(d1)) / 365.0
                rho = (strike * t * dfRate * normCdf(d2)) / 100.0
            }
            OptionType.PUT -> {
                price = strike * dfRate * normCdf(-d2) - spot * dfDividend * normCdf(-d1)
                delta = -dfDividend * normCdf(-d1)
                theta = (-(spot * dfDividend * normPdfD1 * sigma) / (2.0 * sqrtT)
                        + riskFreeRate * strike * dfRate * normCdf(-d2)
                        - dividendYield * spot * dfDividend * normCdf(-d1)) / 365.0
                rho = (-strike * t * dfRate * normCdf(-d2)) / 100.0
            }
        }

        // Gamma and Vega are identical for Calls and Puts
        val gamma = (dfDividend * normPdfD1) / (spot * sigma * sqrtT)
        val vega = (spot * dfDividend * sqrtT * normPdfD1) / 100.0 // per 1% vol point

        return OptionGreeks(
            price = max(0.0, price),
            delta = delta,
            gamma = gamma,
            vega = vega,
            theta = theta,
            rho = rho
        )
    }

    /**
     * Put-Call Parity theoretical forward relationship:
     * C - P = S0 * e^(-q*T) - K * e^(-r*T)
     * Synthetic Short = Long Put + Short Call = P - C = K * e^(-r*T) - S0 * e^(-q*T)
     */
    fun putCallParityFairValue(
        spot: Double,
        strike: Double,
        timeToExpiry: Double,
        riskFreeRate: Double = 0.045,
        dividendYield: Double = 0.012
    ): Double {
        val t = max(0.0001, timeToExpiry)
        val dfDividend = exp(-dividendYield * t)
        val dfRate = exp(-riskFreeRate * t)
        return strike * dfRate - spot * dfDividend
    }
}
