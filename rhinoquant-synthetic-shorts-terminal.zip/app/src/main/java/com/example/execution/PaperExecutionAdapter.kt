package com.example.execution

import com.example.model.*
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

interface ExecutionAdapter {
    val venueName: String
    val isLive: Boolean
    val isConnected: Boolean

    suspend fun submitOrder(
        order: SyntheticOrder,
        onReport: suspend (ExecutionReport) -> Unit,
        onStateChange: suspend (OrderState, String?) -> Unit
    )

    suspend fun cancelOrder(
        orderId: String,
        onStateChange: suspend (OrderState, String?) -> Unit
    ): Boolean
}

class PaperExecutionAdapter : ExecutionAdapter {
    override val venueName: String = "RHINO_PAPER_SIM"
    override val isLive: Boolean = false
    override val isConnected: Boolean = true

    // Set of active orders currently working in the paper simulator
    private val workingOrders = mutableMapOf<String, SyntheticOrder>()

    override suspend fun submitOrder(
        order: SyntheticOrder,
        onReport: suspend (ExecutionReport) -> Unit,
        onStateChange: suspend (OrderState, String?) -> Unit
    ) {
        workingOrders[order.id] = order

        // Step 1: Submitting -> Submitted
        onStateChange(OrderState.Submitting, null)
        delay(120) // Simulated network latency to matching engine

        onStateChange(OrderState.Submitted, null)
        delay(150)

        // Step 2: Acknowledged by venue
        onStateChange(OrderState.Acknowledged, null)
        delay(300)

        // Step 3: Complex Multi-Leg Execution Simulation
        // For synthetic short: execute Long Put and Short Call
        // If order size > 5, simulate realistic partial fills
        val totalQty = order.quantity
        val brokerOrderId = "BKR-" + UUID.randomUUID().toString().take(8).uppercase()

        if (totalQty > 5) {
            // Partial fill 1
            val partialQty1 = totalQty / 2
            val partialRemaining = totalQty - partialQty1

            for (leg in order.legs) {
                val fillPrice = when (leg.side) {
                    OrderSide.BUY -> leg.ask + (Random.nextDouble() * 0.02 - 0.01) // slight slippage
                    OrderSide.SELL -> leg.bid - (Random.nextDouble() * 0.02 - 0.01)
                }
                val report = ExecutionReport(
                    executionId = "EXEC-" + UUID.randomUUID().toString().take(10).uppercase(),
                    clientOrderId = order.clientOrderId,
                    brokerOrderId = brokerOrderId,
                    instrumentId = leg.instrumentId,
                    underlying = leg.underlying,
                    side = leg.side,
                    filledQty = partialQty1,
                    fillPrice = Math.round(fillPrice * 100.0) / 100.0,
                    fee = 0.65 * partialQty1,
                    venue = venueName,
                    liquidityFlag = "TAKER_PARTIAL"
                )
                onReport(report)
            }
            onStateChange(OrderState.PartiallyFilled, "Partial fill 1/2 completed ($partialQty1 / $totalQty)")

            delay(600) // Liquidity delay for rest of queue

            // Partial fill 2 -> Completing the order
            for (leg in order.legs) {
                val fillPrice = when (leg.side) {
                    OrderSide.BUY -> leg.ask
                    OrderSide.SELL -> leg.bid
                }
                val report = ExecutionReport(
                    executionId = "EXEC-" + UUID.randomUUID().toString().take(10).uppercase(),
                    clientOrderId = order.clientOrderId,
                    brokerOrderId = brokerOrderId,
                    instrumentId = leg.instrumentId,
                    underlying = leg.underlying,
                    side = leg.side,
                    filledQty = partialRemaining,
                    fillPrice = Math.round(fillPrice * 100.0) / 100.0,
                    fee = 0.65 * partialRemaining,
                    venue = venueName,
                    liquidityFlag = "TAKER"
                )
                onReport(report)
            }
            onStateChange(OrderState.Filled, "Complex order fully filled at execution venue ($totalQty contracts)")
        } else {
            // Immediate full fill for standard institutional clip
            for (leg in order.legs) {
                val fillPrice = when (leg.side) {
                    OrderSide.BUY -> leg.ask
                    OrderSide.SELL -> leg.bid
                }
                val report = ExecutionReport(
                    executionId = "EXEC-" + UUID.randomUUID().toString().take(10).uppercase(),
                    clientOrderId = order.clientOrderId,
                    brokerOrderId = brokerOrderId,
                    instrumentId = leg.instrumentId,
                    underlying = leg.underlying,
                    side = leg.side,
                    filledQty = totalQty,
                    fillPrice = Math.round(fillPrice * 100.0) / 100.0,
                    fee = 0.65 * totalQty,
                    venue = venueName,
                    liquidityFlag = "TAKER"
                )
                onReport(report)
            }
            onStateChange(OrderState.Filled, "Synthetic multi-leg order filled cleanly at marketable quotes.")
        }

        workingOrders.remove(order.id)
    }

    override suspend fun cancelOrder(
        orderId: String,
        onStateChange: suspend (OrderState, String?) -> Unit
    ): Boolean {
        onStateChange(OrderState.PendingCancel, "Cancel request transmitted to venue")
        delay(200)
        workingOrders.remove(orderId)
        onStateChange(OrderState.Cancelled, "Venue confirmed cancellation of working order")
        return true
    }
}
