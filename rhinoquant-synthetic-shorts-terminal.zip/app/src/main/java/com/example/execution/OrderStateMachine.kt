package com.example.execution

import com.example.model.OrderState

object OrderStateMachine {

    data class TransitionResult(
        val isAllowed: Boolean,
        val reason: String
    )

    private val validTransitions: Map<OrderState, Set<OrderState>> = mapOf(
        OrderState.Draft to setOf(OrderState.PendingValidation, OrderState.Cancelled),
        OrderState.PendingValidation to setOf(OrderState.PendingRisk, OrderState.Rejected, OrderState.Draft),
        OrderState.PendingRisk to setOf(OrderState.Approved, OrderState.RequiresReview, OrderState.Rejected),
        OrderState.RequiresReview to setOf(OrderState.Approved, OrderState.Rejected, OrderState.Draft),
        OrderState.Approved to setOf(OrderState.Submitting, OrderState.Cancelled, OrderState.Draft),
        OrderState.Submitting to setOf(OrderState.Submitted, OrderState.Rejected, OrderState.ReconciliationRequired),
        OrderState.Submitted to setOf(OrderState.Acknowledged, OrderState.Rejected, OrderState.PendingCancel, OrderState.ReconciliationRequired),
        OrderState.Acknowledged to setOf(OrderState.PartiallyFilled, OrderState.Filled, OrderState.PendingCancel, OrderState.Expired, OrderState.ReconciliationRequired),
        OrderState.PartiallyFilled to setOf(OrderState.PartiallyFilled, OrderState.Filled, OrderState.PendingCancel, OrderState.ReconciliationRequired),
        OrderState.PendingCancel to setOf(OrderState.Cancelled, OrderState.Filled, OrderState.ReconciliationRequired),
        OrderState.Filled to setOf(OrderState.ReconciliationRequired), // Terminal
        OrderState.Cancelled to setOf(OrderState.ReconciliationRequired), // Terminal
        OrderState.Rejected to setOf(OrderState.ReconciliationRequired), // Terminal
        OrderState.Expired to setOf(OrderState.ReconciliationRequired), // Terminal
        OrderState.ReconciliationRequired to setOf(OrderState.Draft, OrderState.Acknowledged, OrderState.Filled, OrderState.Cancelled)
    )

    fun canTransition(from: OrderState, to: OrderState): TransitionResult {
        if (from == to) {
            return TransitionResult(true, "No-op transition within same state: $from")
        }

        val allowedNext = validTransitions[from] ?: emptySet()
        if (to in allowedNext) {
            return TransitionResult(true, "Valid transition: $from -> $to")
        }

        return TransitionResult(
            false,
            "Illegal order state transition from $from to $to. Allowed next states: ${allowedNext.joinToString(", ")}"
        )
    }
}
