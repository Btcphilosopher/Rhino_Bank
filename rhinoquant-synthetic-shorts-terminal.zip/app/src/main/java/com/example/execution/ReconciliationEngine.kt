package com.example.execution

import com.example.model.*
import java.util.UUID
import kotlin.math.abs

object ReconciliationEngine {

    data class ReconciliationReport(
        val timestamp: Long = System.currentTimeMillis(),
        val ordersReconciled: Int,
        val positionsReconciled: Int,
        val matchedCount: Int,
        val exceptions: List<ReconciliationException>
    )

    fun runReconciliation(
        internalOrders: List<SyntheticOrder>,
        internalPositions: List<Position>,
        executionReports: List<ExecutionReport>,
        simulatedCash: Double,
        simulatedMargin: Double
    ): ReconciliationReport {
        val exceptions = mutableListOf<ReconciliationException>()
        var matched = 0

        // 1. Reconcile Positions against Execution Reports
        // Net quantity per instrument from execution reports must equal position open quantity
        val netFillsByInstrument = mutableMapOf<String, Int>()
        for (report in executionReports) {
            val delta = when (report.side) {
                OrderSide.BUY -> report.filledQty
                OrderSide.SELL -> -report.filledQty
            }
            netFillsByInstrument[report.instrumentId] = (netFillsByInstrument[report.instrumentId] ?: 0) + delta
        }

        for (pos in internalPositions) {
            val expectedQty = netFillsByInstrument[pos.instrumentId] ?: 0
            if (pos.quantity != expectedQty) {
                exceptions.add(
                    ReconciliationException(
                        id = "EXC-" + UUID.randomUUID().toString().take(8).uppercase(),
                        instrument = pos.instrumentId,
                        entityType = "POSITION",
                        entityId = pos.instrumentId,
                        internalValue = "${pos.quantity} contracts",
                        providerValue = "$expectedQty contracts",
                        difference = "${pos.quantity - expectedQty} contracts",
                        severity = DiscrepancySeverity.CRITICAL,
                        status = ExceptionStatus.OPEN,
                        notes = "Position ledger mismatch against cumulative execution fill reports."
                    )
                )
            } else {
                matched++
            }
        }

        // 2. Reconcile Orders
        for (order in internalOrders) {
            if (order.status == OrderState.Filled) {
                // Ensure every leg has matching execution reports
                for (leg in order.legs) {
                    val legFills = executionReports
                        .filter { it.clientOrderId == order.clientOrderId && it.instrumentId == leg.instrumentId }
                        .sumOf { it.filledQty }

                    if (legFills < leg.quantity) {
                        exceptions.add(
                            ReconciliationException(
                                id = "EXC-" + UUID.randomUUID().toString().take(8).uppercase(),
                                instrument = leg.instrumentId,
                                entityType = "ORDER",
                                entityId = order.clientOrderId,
                                internalValue = "Filled (Qty: ${leg.quantity})",
                                providerValue = "Confirmed Fills: $legFills",
                                difference = "Missing ${leg.quantity - legFills} fills",
                                severity = DiscrepancySeverity.WARNING,
                                status = ExceptionStatus.OPEN,
                                notes = "Order marked filled internally but venue reports fewer cumulative executions."
                            )
                        )
                    } else {
                        matched++
                    }
                }
            } else {
                matched++
            }
        }

        return ReconciliationReport(
            ordersReconciled = internalOrders.size,
            positionsReconciled = internalPositions.size,
            matchedCount = matched,
            exceptions = exceptions
        )
    }
}
