package com.example.risk

import com.example.model.*
import com.example.quant.ValuationEngine
import kotlin.math.abs

object PreTradeRiskGate {

    // Configurable Risk Limits for Desk / Book
    data class DeskRiskLimits(
        val maxOrderNotional: Double = 250_000.0,
        val maxGrossExposure: Double = 1_000_000.0,
        val maxNetDeltaShares: Double = 5_000.0,
        val maxSinglePositionPct: Double = 0.35, // 35% concentration cap
        val minCashBuffer: Double = 25_000.0,
        val maxStaleQuoteAgeMs: Long = 10_000L,
        val allowedVenues: Set<String> = setOf("CBOE_PAPER", "RHINO_PAPER_SIM")
    )

    fun evaluateOrder(
        order: SyntheticOrder,
        currentGrossExposure: Double,
        availableCash: Double,
        activeOrders: List<SyntheticOrder>,
        quotes: Map<String, Quote>,
        limits: DeskRiskLimits = DeskRiskLimits()
    ): RiskCheckResult {
        val checks = mutableListOf<RiskRuleResult>()

        // 1. Leg Multi-leg compatibility check
        val compResult = ValuationEngine.validateSyntheticShortCompatibility(order.legs)
        if (!compResult.isCompatible) {
            checks.add(
                RiskRuleResult(
                    ruleName = "LEG_COMPATIBILITY",
                    passed = false,
                    code = "ERR_LEG_MISMATCH",
                    message = compResult.issues.joinToString("; ")
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "LEG_COMPATIBILITY",
                    passed = true,
                    code = "OK_LEGS_MATCHED",
                    message = "Long Put and Short Call matched strikes, expiries, multipliers and quantities."
                )
            )
        }

        // 2. Quantity & Multiplier Check
        if (order.quantity <= 0 || order.quantity > 50) {
            checks.add(
                RiskRuleResult(
                    ruleName = "QUANTITY_BOUNDS",
                    passed = false,
                    code = "ERR_QTY_OUT_OF_BOUNDS",
                    message = "Order quantity ${order.quantity} exceeds desk limit [1, 50] contracts."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "QUANTITY_BOUNDS",
                    passed = true,
                    code = "OK_QTY",
                    message = "Order size ${order.quantity} within limit."
                )
            )
        }

        // 3. Contract Multiplier validation (Standard US options 100)
        val nonStandardMultiplier = order.legs.any { it.multiplier != 100 }
        if (nonStandardMultiplier) {
            checks.add(
                RiskRuleResult(
                    ruleName = "CONTRACT_MULTIPLIER",
                    passed = false,
                    code = "ERR_NON_STANDARD_MULTIPLIER",
                    message = "Non-standard multiplier detected. Only standard 100x contracts eligible."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "CONTRACT_MULTIPLIER",
                    passed = true,
                    code = "OK_MULTIPLIER",
                    message = "Contract multiplier verified at 100."
                )
            )
        }

        // 4. Tick Size validation
        val invalidTick = order.legs.any { it.limitPrice <= 0.0 || (it.limitPrice * 100).rem(1.0) > 0.001 }
        if (invalidTick) {
            checks.add(
                RiskRuleResult(
                    ruleName = "TICK_SIZE",
                    passed = false,
                    code = "ERR_INVALID_TICK",
                    message = "Price does not conform to valid minimum tick increment ($0.01)."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "TICK_SIZE",
                    passed = true,
                    code = "OK_TICK",
                    message = "Tick increments valid."
                )
            )
        }

        // 5. Market Data Freshness check
        val now = System.currentTimeMillis()
        var hasStaleQuote = false
        var staleDetails = ""
        for (leg in order.legs) {
            val q = quotes[leg.instrumentId]
            if (q == null) {
                hasStaleQuote = true
                staleDetails = "Missing market quote for leg ${leg.instrumentId}"
                break
            } else if (now - q.timestamp > limits.maxStaleQuoteAgeMs) {
                hasStaleQuote = true
                staleDetails = "Quote for ${leg.instrumentId} is stale (${now - q.timestamp}ms > ${limits.maxStaleQuoteAgeMs}ms limit)"
                break
            }
        }
        if (hasStaleQuote) {
            checks.add(
                RiskRuleResult(
                    ruleName = "DATA_FRESHNESS",
                    passed = false,
                    code = "ERR_MARKET_DATA_STALE",
                    message = staleDetails
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "DATA_FRESHNESS",
                    passed = true,
                    code = "OK_DATA_FRESH",
                    message = "All leg market data feeds fresh (< 10s latency)."
                )
            )
        }

        // 6. Order Notional Cap
        val notional = order.totalNotional
        if (notional > limits.maxOrderNotional) {
            checks.add(
                RiskRuleResult(
                    ruleName = "ORDER_NOTIONAL",
                    passed = false,
                    code = "ERR_NOTIONAL_EXCEEDED",
                    message = "Order notional \$${"%.2f".format(notional)} exceeds limit \$${"%.2f".format(limits.maxOrderNotional)}."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "ORDER_NOTIONAL",
                    passed = true,
                    code = "OK_NOTIONAL",
                    message = "Order notional \$${"%.2f".format(notional)} approved."
                )
            )
        }

        // 7. Gross Exposure Limit
        val projectedGross = currentGrossExposure + notional
        if (projectedGross > limits.maxGrossExposure) {
            checks.add(
                RiskRuleResult(
                    ruleName = "GROSS_EXPOSURE",
                    passed = false,
                    code = "ERR_GROSS_EXPOSURE_CAP",
                    message = "Projected gross exposure \$${"%.2f".format(projectedGross)} breaches book cap \$${"%.2f".format(limits.maxGrossExposure)}."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "GROSS_EXPOSURE",
                    passed = true,
                    code = "OK_GROSS_EXPOSURE",
                    message = "Projected gross exposure \$${"%.2f".format(projectedGross)} within book limits."
                )
            )
        }

        // 8. Margin & Cash Buffer Availability
        val estimatedMarginRequired = notional * 0.20
        if (availableCash - estimatedMarginRequired < limits.minCashBuffer) {
            checks.add(
                RiskRuleResult(
                    ruleName = "MARGIN_AVAILABILITY",
                    passed = false,
                    code = "ERR_INSUFFICIENT_MARGIN",
                    message = "Post-trade cash (\$${"%.2f".format(availableCash - estimatedMarginRequired)}) falls below required buffer \$${"%.2f".format(limits.minCashBuffer)}."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "MARGIN_AVAILABILITY",
                    passed = true,
                    code = "OK_MARGIN",
                    message = "Required margin \$${"%.2f".format(estimatedMarginRequired)} available."
                )
            )
        }

        // 9. Concentration limit (Single underlying <= 35% of book)
        val tickerExposure = notional
        val concentration = if (projectedGross > 0) tickerExposure / projectedGross else 0.0
        if (concentration > limits.maxSinglePositionPct && projectedGross > 100_000.0) {
            checks.add(
                RiskRuleResult(
                    ruleName = "CONCENTRATION_LIMIT",
                    passed = false,
                    code = "ERR_CONCENTRATION_BREACH",
                    message = "Position concentration ${(concentration * 100).toInt()}% exceeds single-name cap ${(limits.maxSinglePositionPct * 100).toInt()}%."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "CONCENTRATION_LIMIT",
                    passed = true,
                    code = "OK_CONCENTRATION",
                    message = "Concentration ${(concentration * 100).toInt()}% compliant."
                )
            )
        }

        // 10. Duplicate order detection
        val duplicate = activeOrders.any {
            it.clientOrderId != order.clientOrderId &&
                    it.underlying == order.underlying &&
                    it.quantity == order.quantity &&
                    abs(it.netLimitPrice - order.netLimitPrice) < 0.01 &&
                    it.status in listOf(OrderState.Submitted, OrderState.Acknowledged, OrderState.PartiallyFilled) &&
                    (now - it.createdAt) < 60_000L // within 60s
        }
        if (duplicate) {
            checks.add(
                RiskRuleResult(
                    ruleName = "DUPLICATE_ORDER",
                    passed = false,
                    code = "ERR_POSSIBLE_DUPLICATE",
                    message = "Potential duplicate active order detected in ${order.underlying} submitted within last 60 seconds."
                )
            )
        } else {
            checks.add(
                RiskRuleResult(
                    ruleName = "DUPLICATE_ORDER",
                    passed = true,
                    code = "OK_NO_DUPLICATE",
                    message = "No duplicate working order detected."
                )
            )
        }

        // Determine final decision
        val allPassed = checks.all { it.passed }
        val decision = if (allPassed) {
            PreTradeDecision.APPROVED
        } else {
            val hasHardError = checks.any {
                !it.passed && it.code in listOf(
                    "ERR_LEG_MISMATCH",
                    "ERR_MARKET_DATA_STALE",
                    "ERR_INSUFFICIENT_MARGIN",
                    "ERR_NOTIONAL_EXCEEDED"
                )
            }
            if (hasHardError) PreTradeDecision.REJECTED else PreTradeDecision.REQUIRES_REVIEW
        }

        return RiskCheckResult(
            decision = decision,
            checks = checks
        )
    }
}
