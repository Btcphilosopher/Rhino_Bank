package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.TerminalDatabase
import com.example.data.repository.toDomain
import com.example.data.repository.toEntity
import com.example.model.OrderLeg
import com.example.model.OptionType
import com.example.model.OrderSide
import com.example.model.SyntheticOrder
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RhinoQuant", appName)
    }

    @Test
    fun `test room database order insertion and retrieval`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = TerminalDatabase.getInstance(context)

        val testOrder = SyntheticOrder(
            id = "TEST-ORDER-1",
            clientOrderId = "CL-ORD-1",
            underlying = "SPY",
            legs = listOf(
                OrderLeg("P1", "SPY", OptionType.PUT, OrderSide.BUY, 2, 580.0, "2026-11-15", 100, 5.0, 5.2, 5.2),
                OrderLeg("C1", "SPY", OptionType.CALL, OrderSide.SELL, 2, 580.0, "2026-11-15", 100, 5.0, 5.2, 5.0)
            ),
            netLimitPrice = -0.20,
            quantity = 2,
            idempotencyKey = "IDEMP-123"
        )

        db.orderDao().insertOrder(testOrder.toEntity())

        val retrieved = db.orderDao().getOrderById("TEST-ORDER-1")
        assertNotNull(retrieved)
        assertEquals("CL-ORD-1", retrieved?.clientOrderId)
        assertEquals("SPY", retrieved?.underlying)
        assertEquals(2, retrieved?.toDomain()?.legs?.size)
    }
}
