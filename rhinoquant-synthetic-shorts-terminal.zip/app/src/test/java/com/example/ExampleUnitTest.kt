package com.example

import com.example.execution.OrderStateMachine
import com.example.execution.ReconciliationEngine
import com.example.model.*
import com.example.quant.BlackScholes
import com.example.quant.ValuationEngine
import com.example.risk.PreTradeRiskGate
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs

class ExampleUnitTest {

    @Test
    fun testBlackScholesPutCallParity() {
        // Test BSM: C - P = S*e^(-qT) - K*e^(-rT)
        val spot = 500.0
        val strike = 500.0
        val t = 0.25 // 3 months
        val vol = 0.20
        val r = 0.045
        val q = 0.012

        val call = BlackScholes.calculateGreeks(spot, strike, t, vol, r, q, OptionType.CALL)
        val put = BlackScholes.calculateGreeks(spot, strike, t, vol, r, q, OptionType.PUT)

        val parityExpected = BlackScholes.putCallParityFairValue(spot, strike, t, r, q)
        val parityActual = put.price - call.price

        assertEquals(parityExpected, parityActual, 0.05)

        // Net delta of synthetic short (Put Delta - Call Delta) should be close to -e^(-qT) ~ -0.997
        val netDelta = put.delta - call.delta
        assertTrue("Net delta of synthetic short should be near -1.0", netDelta < -0.95 && netDelta > -1.05)
    }

    @Test
    fun testSyntheticShortLegValidation() {
        val validLegs = listOf(
            OrderLeg(
                instrumentId = "SPY_2026-11-15_P_580",
                underlying = "SPY",
                optionType = OptionType.PUT,
                side = OrderSide.BUY,
                quantity = 5,
                strike = 580.0,
                expiry = "2026-11-15",
                multiplier = 100,
                bid = 6.20,
                ask = 6.30,
                limitPrice = 6.30
            ),
            OrderLeg(
                instrumentId = "SPY_2026-11-15_C_580",
                underlying = "SPY",
                optionType = OptionType.CALL,
                side = OrderSide.SELL,
                quantity = 5,
                strike = 580.0,
                expiry = "2026-11-15",
                multiplier = 100,
                bid = 8.10,
                ask = 8.20,
                limitPrice = 8.10
            )
        )

        val validCheck = ValuationEngine.validateSyntheticShortCompatibility(validLegs)
        assertTrue(validCheck.isCompatible)
        assertTrue(validCheck.issues.isEmpty())

        // Incompatible strikes test
        val mismatchedStrikes = listOf(
            validLegs[0].copy(strike = 580.0),
            validLegs[1].copy(strike = 585.0)
        )
        val invalidCheck = ValuationEngine.validateSyntheticShortCompatibility(mismatchedStrikes)
        assertFalse(invalidCheck.isCompatible)
        assertTrue(invalidCheck.issues.any { it.contains("Mismatched strikes") })
    }

    @Test
    fun testOrderStateMachineTransitions() {
        // Valid forward flow
        assertTrue(OrderStateMachine.canTransition(OrderState.Draft, OrderState.PendingValidation).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.PendingValidation, OrderState.PendingRisk).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.PendingRisk, OrderState.Approved).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.Approved, OrderState.Submitting).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.Submitting, OrderState.Submitted).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.Submitted, OrderState.Acknowledged).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.Acknowledged, OrderState.PartiallyFilled).isAllowed)
        assertTrue(OrderStateMachine.canTransition(OrderState.PartiallyFilled, OrderState.Filled).isAllowed)

        // Invalid jump backwards from terminal Filled to Draft
        assertFalse(OrderStateMachine.canTransition(OrderState.Filled, OrderState.Draft).isAllowed)
    }

    @Test
    fun testPreTradeRiskGateRejectionOnExcessiveNotional() {
        val largeOrder = SyntheticOrder(
            id = "O1",
            clientOrderId = "ORD-TEST-1",
            underlying = "SPY",
            legs = listOf(
                OrderLeg("P1", "SPY", OptionType.PUT, OrderSide.BUY, 100, 580.0, "2026-11-15", 100, 5.0, 5.2, 5.2),
                OrderLeg("C1", "SPY", OptionType.CALL, OrderSide.SELL, 100, 580.0, "2026-11-15", 100, 5.0, 5.2, 5.0)
            ),
            netLimitPrice = 0.0,
            quantity = 100, // Exceeds desk 50 contract limit & notional limit
            idempotencyKey = "KEY-1"
        )

        val quotes = mapOf(
            "P1" to Quote("P1", "SPY", 5.0, 5.2, 5.1, 0.20, -0.5, 1000, 5000),
            "C1" to Quote("C1", "SPY", 5.0, 5.2, 5.1, 0.20, 0.5, 1000, 5000)
        )

        val result = PreTradeRiskGate.evaluateOrder(
            order = largeOrder,
            currentGrossExposure = 0.0,
            availableCash = 500_000.0,
            activeOrders = emptyList(),
            quotes = quotes
        )

        assertEquals(PreTradeDecision.REJECTED, result.decision)
        assertTrue(result.checks.any { !it.passed && it.code == "ERR_QTY_OUT_OF_BOUNDS" })
    }

    @Test
    fun testReconciliationDetectsPositionDiscrepancy() {
        val internalPositions = listOf(
            Position("INST-1", "SPY", "SYNTHETIC_SHORT", 10, 5.0, 5.2)
        )
        // Only 5 fills recorded in reports
        val executionReports = listOf(
            ExecutionReport("EXEC-1", "ORD-1", "BKR-1", "INST-1", "SPY", OrderSide.BUY, 5, 5.0, 3.25)
        )

        val report = ReconciliationEngine.runReconciliation(
            internalOrders = emptyList(),
            internalPositions = internalPositions,
            executionReports = executionReports,
            simulatedCash = 500_000.0,
            simulatedMargin = 10_000.0
        )

        assertEquals(1, report.exceptions.size)
        assertEquals("POSITION", report.exceptions.first().entityType)
        assertEquals(DiscrepancySeverity.CRITICAL, report.exceptions.first().severity)
    }
}
