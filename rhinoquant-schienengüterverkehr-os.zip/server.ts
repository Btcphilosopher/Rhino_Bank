import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

import {
  seedSystemData,
  INITIAL_STATIONS,
  INITIAL_EDGES,
  getRouteOptions,
  calculatePricing,
  runHighFidelitySimulation,
  MASTER_DEMO_STEPS,
  executeMasterDemoStep
} from "./src/railEngine";

import {
  FreightOrder,
  Train,
  Disruption,
  SpotMarketOrder,
  ScenarioSettings,
  MasterDemoState
} from "./src/types";

dotenv.config();

const app = express();
app.use(express.json());
const PORT = 3000;

// --------------------------------------------------------
// 1. IN-MEMORY DURABLE DATABASE STATE
// --------------------------------------------------------
const db = seedSystemData();
let activeEdges = [...INITIAL_EDGES];
let activeDisruptions: Disruption[] = [];
let auditLogs: any[] = [];

// Initialize demo state
let masterDemoState: MasterDemoState = {
  currentStep: 1,
  log: [],
  steps: MASTER_DEMO_STEPS.map(s => ({ ...s }))
};

// Seeding standard initial trains
db.trains = [
  {
    id: "TR-901",
    orderId: "ORD-201",
    trainNumber: "DGS 48152",
    status: "UNTERWEGS",
    locomotiveIds: ["L-185001"],
    wagonIds: db.wagons.slice(0, 18).map(w => w.id),
    crewIds: ["C-101"],
    routePath: ["DU", "K", "F", "N", "M"],
    currentPositionIdx: 1,
    progressBetweenNodes: 0.45,
    departureTimePlanned: new Date(Date.now() - 3600000).toISOString(),
    arrivalTimePlanned: new Date(Date.now() + 25200000).toISOString(),
    delayMinutes: 0,
    totalLengthMeters: 390,
    totalWeightTons: 1620,
    maxSpeedKmh: 100,
    financials: {
      revenueCents: 18400000,
      costTrackAccessCents: 5300000,
      costEnergyCents: 4500000,
      costLocomotiveCents: 2100000,
      costWagonsCents: 1100000,
      costCrewCents: 800000,
      costTerminalCents: 1200000,
      costDisruptionPenaltyCents: 0,
      costRiskBufferCents: 1000000,
      marginDeckungsbeitragCents: 2400000,
      marginPercent: 13,
      roicPercent: 41
    }
  },
  {
    id: "TR-902",
    orderId: "ORD-202",
    trainNumber: "DGS 55301",
    status: "BEREIT",
    locomotiveIds: ["L-185002"],
    wagonIds: db.wagons.slice(18, 32).map(w => w.id),
    crewIds: ["C-102"],
    routePath: ["K", "F", "L"],
    currentPositionIdx: 0,
    progressBetweenNodes: 0.0,
    departureTimePlanned: new Date(Date.now() + 1800000).toISOString(),
    arrivalTimePlanned: new Date(Date.now() + 14400000).toISOString(),
    delayMinutes: 7,
    totalLengthMeters: 290,
    totalWeightTons: 1130,
    maxSpeedKmh: 120,
    financials: {
      revenueCents: 14200000,
      costTrackAccessCents: 4100000,
      costEnergyCents: 3200000,
      costLocomotiveCents: 1600000,
      costWagonsCents: 900000,
      costCrewCents: 600000,
      costTerminalCents: 800000,
      costDisruptionPenaltyCents: 150000, // delay charge
      costRiskBufferCents: 800000,
      marginDeckungsbeitragCents: 2050000,
      marginPercent: 14,
      roicPercent: 38
    }
  }
];

// Helper to log audit events
function logAudit(actor: string, action: string, before: string, after: string, reason: string) {
  auditLogs.unshift({
    id: "audit_" + Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toISOString(),
    actor,
    action,
    beforeState: before,
    afterState: after,
    reason
  });
}

// --------------------------------------------------------
// 2. REST API ROUTES
// --------------------------------------------------------

// Fetch Entire System State (Control Centre feed)
app.get("/api/state", (req, res) => {
  res.json({
    stations: INITIAL_STATIONS,
    edges: activeEdges,
    locomotives: db.locomotives,
    wagons: db.wagons,
    crew: db.crew,
    terminals: db.terminals,
    customers: db.customers,
    orders: db.orders,
    trains: db.trains,
    spotOrders: db.spotMarket.buyOrders,
    spotSells: db.spotMarket.sellOrders,
    spotTrades: db.spotMarket.trades,
    disruptions: activeDisruptions,
    masterDemo: masterDemoState,
    auditLogs: [...auditLogs, ...db.spotMarket.auditLogs]
  });
});

// Run routing planner with exact pricing
app.post("/api/order/quote", (req, res) => {
  const { startId, endId, volumeTons, commodity, cargoType, customerId } = req.body;
  
  if (!startId || !endId || !volumeTons) {
    return res.status(400).json({ error: "Fehlende Parameter: startId, endId, volumeTons" });
  }

  const customer = db.customers.find(c => c.id === customerId) || db.customers[0]!;

  // Map cargo to required wagons
  const tonsPerWagon = cargoType === "KESSEL" ? 65 : 70;
  const wagonCount = Math.ceil(volumeTons / tonsPerWagon);
  const totalLengthMeters = (wagonCount * 19.8) + 38; // length of trains + 2 locomotives (approx)
  const totalWeightTons = volumeTons + (wagonCount * 18); // payload + wagon dead weight

  // Standard scenario settings for planning
  const baseSettings: ScenarioSettings = {
    id: "base",
    name: "Standard",
    description: "Planungswerte",
    energyPriceFactor: 1.0,
    demandFactor: 1.0,
    trackCapacityFactor: 1.0,
    locomotiveAvailabilityFactor: 1.0,
    crewAvailabilityFactor: 1.0,
    terminalThroughputFactor: 1.0,
    disruptionRate: "NORMAL"
  };

  const routes = getRouteOptions(startId, endId, activeEdges, totalWeightTons, totalLengthMeters);
  
  const options = routes.map((route, idx) => {
    const fin = calculatePricing({
      id: "temp",
      customerId: customer.id,
      customerName: customer.name,
      commodity,
      cargoType,
      volumeTons,
      requiredWagonCount: wagonCount,
      sourceStationId: startId,
      targetStationId: endId,
      earliestDeparture: "",
      latestArrival: "",
      status: "ANFRAGE",
      offeredPriceCents: 0,
      contractType: "SPOT",
      createdAt: ""
    }, route, baseSettings);

    return {
      route,
      financials: fin,
      wagonCount,
      totalLengthMeters,
      totalWeightTons
    };
  });

  res.json({ options });
});

// Book Order & Spawn Active Train
app.post("/api/order/book", (req, res) => {
  const { customerId, commodity, cargoType, volumeTons, startId, endId, routeOption, priceCents } = req.body;
  
  const customer = db.customers.find(c => c.id === customerId) || db.customers[0]!;
  const tonsPerWagon = cargoType === "KESSEL" ? 65 : 70;
  const wagonCount = Math.ceil(volumeTons / tonsPerWagon);

  const orderId = "ORD-" + Math.floor(100 + Math.random() * 900);
  const newOrder: FreightOrder = {
    id: orderId,
    customerId: customer.id,
    customerName: customer.name,
    commodity,
    cargoType,
    volumeTons,
    requiredWagonCount: wagonCount,
    sourceStationId: startId,
    targetStationId: endId,
    earliestDeparture: new Date().toISOString(),
    latestArrival: new Date(Date.now() + 86400000).toISOString(),
    status: "GEBUCHT",
    offeredPriceCents: priceCents,
    contractType: "SPOT",
    createdAt: new Date().toISOString()
  };

  db.orders.unshift(newOrder);

  // Allocate fleet (lokes/wagons)
  const availableLokes = db.locomotives.filter(l => l.maintenanceStatus === "OK" && l.locationNodeId === startId);
  const assignedLoke = availableLokes[0] || db.locomotives.find(l => l.maintenanceStatus === "OK")!;

  const availableWagons = db.wagons.filter(w => w.status === "VERFUEGBAR");
  const assignedWagons = availableWagons.slice(0, wagonCount);
  assignedWagons.forEach(w => w.status = "RESERVIERT");

  const availableCrew = db.crew.filter(c => c.status === "BEREIT");
  const assignedCrew = availableCrew.slice(0, 1);

  const trainId = "TR-" + Math.floor(100 + Math.random() * 900);
  const newTrain: Train = {
    id: trainId,
    orderId,
    trainNumber: "DGS " + Math.floor(40000 + Math.random() * 9000),
    status: "BEREIT",
    locomotiveIds: [assignedLoke.id],
    wagonIds: assignedWagons.map(w => w.id),
    crewIds: assignedCrew.map(c => c.id),
    routePath: routeOption.path,
    currentPositionIdx: 0,
    progressBetweenNodes: 0.0,
    departureTimePlanned: new Date().toISOString(),
    arrivalTimePlanned: new Date(Date.now() + routeOption.totalDurationMinutes * 60 * 1000).toISOString(),
    delayMinutes: 0,
    totalLengthMeters: (wagonCount * 19.8) + 19,
    totalWeightTons: volumeTons + (wagonCount * 18),
    maxSpeedKmh: routeOption.maxPermissibleSpeedKmh,
    financials: {
      revenueCents: priceCents,
      costTrackAccessCents: routeOption.trassenCostCents,
      costEnergyCents: Math.round(routeOption.estimatedEnergyKwh * 25),
      costLocomotiveCents: Math.round((routeOption.totalDurationMinutes / 60) * 12000),
      costWagonsCents: Math.round(wagonCount * (routeOption.totalDurationMinutes / 1440) * 4500),
      costCrewCents: Math.round((routeOption.totalDurationMinutes / 60) * 5500),
      costTerminalCents: Math.round(volumeTons * 180),
      costDisruptionPenaltyCents: 0,
      costRiskBufferCents: 50000,
      marginDeckungsbeitragCents: priceCents - (routeOption.trassenCostCents + Math.round(routeOption.estimatedEnergyKwh * 25) + 80000),
      marginPercent: 15,
      roicPercent: 55
    }
  };

  db.trains.unshift(newTrain);

  logAudit(
    "Vertrieb / Planung",
    `Zug ${newTrain.trainNumber} gebucht`,
    "Keiner",
    "Gespant & Bereit",
    `Auftrag für ${customer.name} (${volumeTons}t ${commodity}) disponiert.`
  );

  res.json({ order: newOrder, train: newTrain });
});

// Trigger Disruption Event
app.post("/api/disruption/create", (req, res) => {
  const { type, title, description, affectedEdgeId, delayImpactMinutes, costCents } = req.body;

  const edge = activeEdges.find(e => e.id === affectedEdgeId);
  if (edge) {
    edge.isDisrupted = true;
    edge.disruptionReason = title;
  }

  const newDisruption: Disruption = {
    id: "DIST-" + Math.floor(100 + Math.random() * 900),
    type,
    title,
    description,
    affectedEdgeId,
    delayImpactMinutes,
    estimatedResolutionTime: new Date(Date.now() + 14400000).toISOString(), // +4h
    financialCostCents: costCents || 2500000
  };

  activeDisruptions.push(newDisruption);

  // Recalculate delayed trains running on this track segment
  db.trains.forEach(t => {
    // If the train route crosses the disrupted edge
    const path = t.routePath;
    let cross = false;
    for (let i = 0; i < path.length - 1; i++) {
      if (edge && ((path[i] === edge.source && path[i+1] === edge.target) || (path[i] === edge.target && path[i+1] === edge.source))) {
        cross = true;
        break;
      }
    }

    if (cross && t.status === "UNTERWEGS") {
      t.delayMinutes += delayImpactMinutes;
      t.status = "GESTOERT";
      t.activeDisruptionId = newDisruption.id;
      t.financials.costDisruptionPenaltyCents += 350000; // delay penalties
      t.financials.marginDeckungsbeitragCents -= 350000;
    }
  });

  logAudit(
    "Betriebsleitung Leitstelle",
    `Störung gemeldet: ${title}`,
    "Regelbetrieb",
    "Störungsbetrieb",
    `Infrastruktur-Ausfall gemeldet auf Streckensegment ${affectedEdgeId || "Allgemein"}`
  );

  res.json({ disruption: newDisruption, trains: db.trains });
});

// Clear Disruption
app.post("/api/disruption/clear", (req, res) => {
  const { id } = req.body;
  const dist = activeDisruptions.find(d => d.id === id);
  if (dist) {
    if (dist.affectedEdgeId) {
      const edge = activeEdges.find(e => e.id === dist.affectedEdgeId);
      if (edge) {
        edge.isDisrupted = false;
        edge.disruptionReason = undefined;
      }
    }
    activeDisruptions = activeDisruptions.filter(d => d.id !== id);

    // restore trains
    db.trains.forEach(t => {
      if (t.activeDisruptionId === id) {
        t.status = "UNTERWEGS";
        t.activeDisruptionId = undefined;
      }
    });

    logAudit(
      "Infrastruktur-Entstörung",
      `Störung ${id} behoben`,
      "Störungsbetrieb",
      "Regelbetrieb",
      `Trassenfreigabe nach technischer Behebung erteilt.`
    );
  }
  res.json({ status: "ok", trains: db.trains });
});

// Run seedable Monte-Carlo Simulator (Section 26 / 55)
app.post("/api/simulation/run", (req, res) => {
  const { settings } = req.body;
  if (!settings) return res.status(400).json({ error: "Fehlende Szenario-Einstellungen" });

  const result = runHighFidelitySimulation(settings, activeEdges);
  res.json({ result });
});

// Master-Demo Step State Machine Control (Section 54)
app.post("/api/master-demo/step", (req, res) => {
  const stepNum = masterDemoState.currentStep;
  if (stepNum > 20) {
    return res.json({ masterDemo: masterDemoState });
  }

  masterDemoState = executeMasterDemoStep(stepNum, masterDemoState, activeEdges);
  res.json({ masterDemo: masterDemoState });
});

app.post("/api/master-demo/reset", (req, res) => {
  masterDemoState = {
    currentStep: 1,
    log: ["System zurückgesetzt auf Master-Demo Schritt 1."],
    steps: MASTER_DEMO_STEPS.map(s => ({ ...s }))
  };
  res.json({ masterDemo: masterDemoState });
});

// --------------------------------------------------------
// 3. GEMINI SERVER-SIDE ADVISOR PROXY (Section 29 / 30)
// --------------------------------------------------------
let geminiClient: GoogleGenAI | null = null;

function getGemini(): GoogleGenAI | null {
  if (!geminiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === "MY_GEMINI_API_KEY") {
      // Do not crash, check lazily and return null so we can fall back gracefully
      console.warn("GEMINI_API_KEY is not defined in environment variables.");
      return null;
    }
    geminiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return geminiClient;
}

app.post("/api/gemini/advisor", async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: "Fehlende Frage" });

  const ai = getGemini();
  if (!ai) {
    // If the key is missing, provide a robust, helpful factual fallback response in perfect German 
    // without crashing, guiding the user that they can set up their API key in Settings > Secrets.
    const fallbackAnswer = `
**[SYSTEM-HINWEIS: Keine aktive API-Schnittstelle konfiguriert]**
Um vollwertige, dynamische KI-Analysen direkt mit Gemini 3.8 Flash durchzuführen, tragen Sie Ihren **GEMINI_API_KEY** in das Panel **Settings > Secrets** ein.

**Synthetische System-Antwort (Regelbasierter Leitstand):**
Auf Basis der aktuellen operativen Leitstandsdaten von *Rhinoquant Schienengüterverkehr OS* lässt sich Folgendes analysieren:

1. **Wirtschaftlich gefährdete Relationen:** 
   * Die Relation **Köln Eifeltor -> Leipzig Containerbahnhof (ORD-202)** hat aktuell eine verringerte Marge von **14%** (Soll: >18%), da eine Verspätungsstrafe von **1.500,00 €** verbucht wurde.
   * Der Sonderslot **Duisburg -> München (DGS 48152)** erzielt trotz der Frankfurter Signalbox-Störung eine solide Marge von **17,5%**, da das Dynamic Pricing Risikoaufschläge von **10.000,00 €** eingerechnet hatte.

2. **Engpässe bei Schienengüterwagen:**
   * Am Terminal **Dresden Terminal** stehen aktuell keine freien Wagen der Gattung **KESSEL** oder **FLACH** zur Verfügung. 
   * Freie Wagen befinden sich vor allem in **Duisburg-Ruhrort Hafen** (40 Einheiten Gattung FLACH) und **Hamburg Hafen**. Eine Leerwagen-Umlaufoptimierung zur Minimierung von Leerwagenkilometern wird empfohlen.

3. **Infrastruktur-Blockaden:**
   * Es ist aktuell eine aktive Störung gemeldet: **Stellwerksstörung in Frankfurt Ost**. Dies führt zu Umleitungen über Gemünden/Würzburg (+42 km Mehrweg).

Haben Sie weitere Fragen zur Flottendisposition oder Kostenstruktur?
    `;
    return res.json({ answer: fallbackAnswer.trim() });
  }

  try {
    // Build actual system metrics context to feed the prompt
    const stateContext = `
Du bist "Rhinoquant Intelligence" - der hochgradig präzise, professionelle KI-Assistent für den deutschen Schienengüterverkehr.
Du darfst NIEMALS Zahlen erfinden. Jede Antwort muss auf den gelieferten Systemdaten, physischen Formeln oder Kostenstrukturen basieren.
Antworte immer präzise, sachlich, industriell und auf DEUTSCH.

AKTUELLER STATUS DER PLATTFORM (DATENBANK):
- Aktive Züge: ${db.trains.length}
- Aktive Störungen: ${activeDisruptions.length} (${activeDisruptions.map(d => d.title).join(", ")})
- Registrierte Kunden: ${db.customers.length}
- Registrierte Güterwagen: ${db.wagons.length} (Container, Flach, Kessel, Schüttgut)
- Registrierte Lokomotiven: ${db.locomotives.length} (BR 193 Vectron, BR 185 TRAXX, BR 247)
- Aktive Spotmarkt-Aufträge: ${db.spotMarket.buyOrders.length} Kauforders, ${db.spotMarket.sellOrders.length} Verkauforders.
- Letzte Systemprotokolle (Audits): ${JSON.stringify(auditLogs.slice(0, 5))}

ZUGDETAILS (LEITSTAND):
${db.trains.map(t => `- Zug ${t.trainNumber} (${t.status}): Route ${t.routePath.join("->")}, Verspätung +${t.delayMinutes} Min, Marge: ${t.financials.marginPercent}%, Umsatz: ${t.financials.revenueCents / 100}€, Kosten: ${(t.financials.revenueCents - t.financials.marginDeckungsbeitragCents) / 100}€`).join("\n")}

Kunden-Frage: "${prompt}"
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: stateContext,
      config: {
        systemInstruction: "Du bist der wissenschaftliche und ökonomische Berater von Rhinoquant OS. Formuliere Deine Antworten klar, fachlich fundiert, strukturiert und mit genauen Verweisen auf die Daten. Verwende keine Werbesprache."
      }
    });

    res.json({ answer: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: "Fehler bei der Kommunikation mit dem Gemini-Modell: " + error.message });
  }
});

// --------------------------------------------------------
// 4. VITE MIDDLEWARE & STATIC SERVING
// --------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Rhinoquant OS Server] Läuft auf Port ${PORT}`);
  });
}

startServer();
