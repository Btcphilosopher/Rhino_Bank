import {
  StationNode,
  TrackEdge,
  RouteOption,
  Locomotive,
  Wagon,
  WagonType,
  Customer,
  FreightOrder,
  CrewMember,
  Terminal,
  Train,
  Financials,
  Disruption,
  SpotMarketOrder,
  SpotMarketTrade,
  AuditLog,
  ScenarioSettings,
  SimulationResult,
  MasterDemoState
} from "./types";

// --------------------------------------------------------
// 1. STATIONS & NETWORK GRAPH SEED DATA
// --------------------------------------------------------
export const INITIAL_STATIONS: StationNode[] = [
  { id: "HH", name: "Hamburg Hafen", lat: 53.5511, lng: 9.9937, type: "HAFEN", region: "Nord" },
  { id: "HB", name: "Bremen Güterbahnhof", lat: 53.0793, lng: 8.8017, type: "TERMINAL", region: "Nord" },
  { id: "HA", name: "Hannover Hbf/Knoten", lat: 52.3759, lng: 9.7320, type: "KNOTEN", region: "Mitte" },
  { id: "B", name: "Berlin Westhafen", lat: 52.5200, lng: 13.4050, type: "HAFEN", region: "Ost" },
  { id: "L", name: "Leipzig Containerbahnhof", lat: 51.3397, lng: 12.3731, type: "TERMINAL", region: "Ost" },
  { id: "DD", name: "Dresden Terminal", lat: 51.0504, lng: 13.7373, type: "TERMINAL", region: "Ost" },
  { id: "DU", name: "Duisburg-Ruhrort Hafen", lat: 51.4344, lng: 6.7623, type: "HAFEN", region: "West" },
  { id: "K", name: "Köln Eifeltor", lat: 50.9375, lng: 6.9603, type: "TERMINAL", region: "West" },
  { id: "F", name: "Frankfurt (Main) Ost", lat: 50.1109, lng: 8.6821, type: "KNOTEN", region: "Mitte" },
  { id: "MA", name: "Mannheim Rangierbahnhof", lat: 49.4875, lng: 8.4660, type: "KNOTEN", region: "Südwest" },
  { id: "N", name: "Nürnberg Hafen-Terminal", lat: 49.4521, lng: 11.0767, type: "TERMINAL", region: "Süd" },
  { id: "S", name: "Stuttgart Hafen", lat: 48.7758, lng: 9.1829, type: "TERMINAL", region: "Südwest" },
  { id: "M", name: "München Riem Terminal", lat: 48.1351, lng: 11.5820, type: "TERMINAL", region: "Süd" },
  { id: "KA", name: "Karlsruhe Knoten", lat: 49.0069, lng: 8.4037, type: "KNOTEN", region: "Südwest" },
  { id: "BS", name: "Basel Bad Bf (Grenze)", lat: 47.5596, lng: 7.5886, type: "GRENZE", region: "Südwest" },
  // International corridors
  { id: "ROT", name: "Rotterdam Maasvlakte", lat: 51.9244, lng: 4.4777, type: "HAFEN", region: "Niederlande" },
  { id: "ANT", name: "Antwerpen Haven", lat: 51.2194, lng: 4.4025, type: "HAFEN", region: "Belgien" },
  { id: "PAR", name: "Paris Nord (Grenze)", lat: 48.8566, lng: 2.3522, type: "GRENZE", region: "Frankreich" },
  { id: "VIE", name: "Wien Gv-Zentrum (Grenze)", lat: 48.2082, lng: 16.3738, type: "GRENZE", region: "Österreich" },
  { id: "PRG", name: "Prag Terminal (Grenze)", lat: 50.0755, lng: 14.4378, type: "GRENZE", region: "Tschechien" }
];

export const INITIAL_EDGES: TrackEdge[] = [
  // Nord
  { id: "e_ROT_DU", source: "ROT", target: "DU", lengthKm: 150, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.2, baseTrackPriceCents: 32000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 21, isDisrupted: false, hasConstruction: false },
  { id: "e_ANT_K", source: "ANT", target: "K", lengthKm: 210, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.5, baseTrackPriceCents: 45000, capacityMaxTrainsPerDay: 40, capacityUsedTrains: 14, isDisrupted: false, hasConstruction: false },
  { id: "e_HH_HB", source: "HH", target: "HB", lengthKm: 100, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 830, gradientPercent: 0.1, baseTrackPriceCents: 21000, capacityMaxTrainsPerDay: 64, capacityUsedTrains: 32, isDisrupted: false, hasConstruction: false },
  { id: "e_HH_HA", source: "HH", target: "HA", lengthKm: 150, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 830, gradientPercent: 0.3, baseTrackPriceCents: 31000, capacityMaxTrainsPerDay: 64, capacityUsedTrains: 41, isDisrupted: false, hasConstruction: false },
  { id: "e_HH_B", source: "HH", target: "B", lengthKm: 280, electrified: true, maxSpeedKmh: 160, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.1, baseTrackPriceCents: 58000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 18, isDisrupted: false, hasConstruction: false },
  { id: "e_HB_HA", source: "HB", target: "HA", lengthKm: 120, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.1, baseTrackPriceCents: 25000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 22, isDisrupted: false, hasConstruction: false },
  
  // Mitte / Ost
  { id: "e_B_L", source: "B", target: "L", lengthKm: 160, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.2, baseTrackPriceCents: 33000, capacityMaxTrainsPerDay: 56, capacityUsedTrains: 24, isDisrupted: false, hasConstruction: false },
  { id: "e_B_DD", source: "B", target: "DD", lengthKm: 190, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.4, baseTrackPriceCents: 39000, capacityMaxTrainsPerDay: 40, capacityUsedTrains: 12, isDisrupted: false, hasConstruction: false },
  { id: "e_L_DD", source: "L", target: "DD", lengthKm: 120, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.6, baseTrackPriceCents: 25000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 15, isDisrupted: false, hasConstruction: false },
  { id: "e_DD_PRG", source: "DD", target: "PRG", lengthKm: 150, electrified: true, maxSpeedKmh: 100, maxAxleLoadTons: 20.0, maxTrainLengthMeters: 650, gradientPercent: 1.5, baseTrackPriceCents: 35000, capacityMaxTrainsPerDay: 32, capacityUsedTrains: 19, isDisrupted: false, hasConstruction: false },
  { id: "e_HA_L", source: "HA", target: "L", lengthKm: 250, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.4, baseTrackPriceCents: 52000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 29, isDisrupted: false, hasConstruction: false },
  { id: "e_HA_F", source: "HA", target: "F", lengthKm: 330, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 1.2, baseTrackPriceCents: 68000, capacityMaxTrainsPerDay: 56, capacityUsedTrains: 42, isDisrupted: false, hasConstruction: false },
  
  // West
  { id: "e_DU_K", source: "DU", target: "K", lengthKm: 70, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 25.0, maxTrainLengthMeters: 835, gradientPercent: 0.2, baseTrackPriceCents: 15000, capacityMaxTrainsPerDay: 96, capacityUsedTrains: 62, isDisrupted: false, hasConstruction: false },
  { id: "e_DU_HA", source: "DU", target: "HA", lengthKm: 250, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.3, baseTrackPriceCents: 51000, capacityMaxTrainsPerDay: 64, capacityUsedTrains: 45, isDisrupted: false, hasConstruction: false },
  { id: "e_K_F", source: "K", target: "F", lengthKm: 180, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 1.0, baseTrackPriceCents: 41000, capacityMaxTrainsPerDay: 64, capacityUsedTrains: 48, isDisrupted: false, hasConstruction: false },
  { id: "e_K_PAR", source: "K", target: "PAR", lengthKm: 420, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.8, baseTrackPriceCents: 95000, capacityMaxTrainsPerDay: 32, capacityUsedTrains: 11, isDisrupted: false, hasConstruction: false },

  // Südhessen / Pfalz / Südwest
  { id: "e_F_MA", source: "F", target: "MA", lengthKm: 80, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.2, baseTrackPriceCents: 18000, capacityMaxTrainsPerDay: 80, capacityUsedTrains: 58, isDisrupted: false, hasConstruction: false },
  { id: "e_F_N", source: "F", target: "N", lengthKm: 220, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 1.8, baseTrackPriceCents: 49000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 38, isDisrupted: false, hasConstruction: false },
  { id: "e_MA_KA", source: "MA", target: "KA", lengthKm: 60, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 830, gradientPercent: 0.1, baseTrackPriceCents: 14000, capacityMaxTrainsPerDay: 80, capacityUsedTrains: 51, isDisrupted: false, hasConstruction: false },
  { id: "e_KA_S", source: "KA", target: "S", lengthKm: 80, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 680, gradientPercent: 2.1, baseTrackPriceCents: 20000, capacityMaxTrainsPerDay: 40, capacityUsedTrains: 28, isDisrupted: false, hasConstruction: false },
  { id: "e_KA_BS", source: "KA", target: "BS", lengthKm: 190, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 830, gradientPercent: 0.3, baseTrackPriceCents: 42000, capacityMaxTrainsPerDay: 72, capacityUsedTrains: 49, isDisrupted: false, hasConstruction: false },

  // Süd
  { id: "e_L_N", source: "L", target: "N", lengthKm: 280, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 1.4, baseTrackPriceCents: 61000, capacityMaxTrainsPerDay: 48, capacityUsedTrains: 22, isDisrupted: false, hasConstruction: false },
  { id: "e_N_M", source: "N", target: "M", lengthKm: 170, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.8, baseTrackPriceCents: 38000, capacityMaxTrainsPerDay: 64, capacityUsedTrains: 39, isDisrupted: false, hasConstruction: false },
  { id: "e_N_VIE", source: "N", target: "VIE", lengthKm: 500, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.6, baseTrackPriceCents: 110000, capacityMaxTrainsPerDay: 32, capacityUsedTrains: 18, isDisrupted: false, hasConstruction: false },
  { id: "e_S_M", source: "S", target: "M", lengthKm: 220, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 650, gradientPercent: 2.5, baseTrackPriceCents: 52000, capacityMaxTrainsPerDay: 36, capacityUsedTrains: 25, isDisrupted: false, hasConstruction: false },
  { id: "e_M_BS", source: "M", target: "BS", lengthKm: 350, electrified: true, maxSpeedKmh: 120, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 1.1, baseTrackPriceCents: 78000, capacityMaxTrainsPerDay: 40, capacityUsedTrains: 14, isDisrupted: false, hasConstruction: false },
  { id: "e_M_VIE", source: "M", target: "VIE", lengthKm: 430, electrified: true, maxSpeedKmh: 140, maxAxleLoadTons: 22.5, maxTrainLengthMeters: 740, gradientPercent: 0.7, baseTrackPriceCents: 98000, capacityMaxTrainsPerDay: 40, capacityUsedTrains: 21, isDisrupted: false, hasConstruction: false }
];

// Helper to double-link edges for bi-directional routing
export function getAdjacentEdges(nodeId: string, edges: TrackEdge[]): { neighborId: string, edge: TrackEdge }[] {
  const list: { neighborId: string, edge: TrackEdge }[] = [];
  for (const edge of edges) {
    if (edge.source === nodeId) {
      list.push({ neighborId: edge.target, edge });
    } else if (edge.target === nodeId) {
      list.push({ neighborId: edge.source, edge });
    }
  }
  return list;
}

// --------------------------------------------------------
// 2. DIJKSTRA ROUTING & ALTERNATIVES GENERATION
// --------------------------------------------------------
export function findShortestPath(
  startId: string,
  endId: string,
  edges: TrackEdge[],
  avoidEdgeId?: string
): { path: string[], distance: number, edgesUsed: TrackEdge[] } | null {
  const distances: { [key: string]: number } = {};
  const previous: { [key: string]: string | null } = {};
  const unvisited = new Set<string>();

  for (const station of INITIAL_STATIONS) {
    distances[station.id] = Infinity;
    previous[station.id] = null;
    unvisited.add(station.id);
  }

  distances[startId] = 0;

  while (unvisited.size > 0) {
    // Get node with minimum distance
    let currentNodeId: string | null = null;
    let minDistance = Infinity;
    for (const nodeId of unvisited) {
      if (distances[nodeId] < minDistance) {
        minDistance = distances[nodeId];
        currentNodeId = nodeId;
      }
    }

    if (!currentNodeId || distances[currentNodeId] === Infinity) {
      break; // Rest unreachable
    }

    if (currentNodeId === endId) {
      break; // Reached target
    }

    unvisited.delete(currentNodeId);

    const neighbors = getAdjacentEdges(currentNodeId, edges);
    for (const { neighborId, edge } of neighbors) {
      if (edge.id === avoidEdgeId || edge.isDisrupted) continue;
      
      const alt = distances[currentNodeId] + edge.lengthKm;
      if (alt < distances[neighborId]) {
        distances[neighborId] = alt;
        previous[neighborId] = currentNodeId;
      }
    }
  }

  if (distances[endId] === Infinity) {
    return null; // Path doesn't exist
  }

  const path: string[] = [];
  let u: string | null = endId;
  while (u) {
    path.unshift(u);
    u = previous[u];
  }

  const edgesUsed: TrackEdge[] = [];
  for (let i = 0; i < path.length - 1; i++) {
    const s = path[i];
    const t = path[i + 1];
    const edge = edges.find(e => (e.source === s && e.target === t) || (e.source === t && e.target === s));
    if (edge) edgesUsed.push(edge);
  }

  return { path, distance: distances[endId], edgesUsed };
}

// Generate multiple path options by systematically blocking parts of the shortest path (Yen's-like heuristic)
export function getRouteOptions(
  startId: string,
  endId: string,
  edges: TrackEdge[],
  trainWeightTons: number,
  trainLengthMeters: number,
  weights = { duration: 0.3, cost: 0.2, robustness: 0.3, energy: 0.2 }
): RouteOption[] {
  const options: RouteOption[] = [];
  
  // 1. Absolute Shortest Path
  const mainPath = findShortestPath(startId, endId, edges);
  if (mainPath) {
    options.push(compileRouteOption("r_main", mainPath.path, mainPath.edgesUsed, trainWeightTons, trainLengthMeters, weights));
  }

  // 2. Alternate by avoiding edges of the main route
  if (mainPath && mainPath.edgesUsed.length > 0) {
    // Avoid the first major edge
    const firstEdgeId = mainPath.edgesUsed[Math.floor(mainPath.edgesUsed.length / 2)]?.id;
    const path2 = findShortestPath(startId, endId, edges, firstEdgeId);
    if (path2 && path2.path.join("-") !== mainPath.path.join("-")) {
      options.push(compileRouteOption("r_alt1", path2.path, path2.edgesUsed, trainWeightTons, trainLengthMeters, weights));
    }
  }

  // 3. Additional high-capacity bypass (prefer edges with electrified = true, low gradient, high length limits)
  // We can simulate an alternative by bumping costs of any steep or disrupted segments
  const modifiedEdges = edges.map(e => {
    let multiplier = 1.0;
    if (e.gradientPercent > 1.5) multiplier = 3.0; // make steep routes less desirable
    return { ...e, lengthKm: e.lengthKm * multiplier };
  });
  const path3 = findShortestPath(startId, endId, modifiedEdges);
  if (path3) {
    const originalEdges = path3.path.slice(0, -1).map((s, i) => {
      const t = path3.path[i + 1];
      return edges.find(e => (e.source === s && e.target === t) || (e.source === t && e.target === s))!;
    }).filter(Boolean);
    if (!options.some(o => o.path.join("-") === path3.path.join("-"))) {
      options.push(compileRouteOption("r_bypass", path3.path, originalEdges, trainWeightTons, trainLengthMeters, weights));
    }
  }

  // Ensure unique paths
  const seenPaths = new Set<string>();
  const uniqueOptions = options.filter(opt => {
    const pathStr = opt.path.join("-");
    if (seenPaths.has(pathStr)) return false;
    seenPaths.add(pathStr);
    return true;
  });

  return uniqueOptions.slice(0, 5).sort((a, b) => b.score - a.score);
}

function compileRouteOption(
  id: string,
  path: string[],
  edgesUsed: TrackEdge[],
  trainWeightTons: number,
  trainLengthMeters: number,
  weights: { duration: number, cost: number, robustness: number, energy: number }
): RouteOption {
  let totalDistanceKm = 0;
  let electrifiedAllWay = true;
  let maxPermissibleSpeedKmh = 160;
  let maxGradientPercent = 0.0;
  let trassenCostCents = 0;
  let totalDurationMinutes = 0;
  let activeConstructionSurcharges = 0;

  for (const edge of edgesUsed) {
    totalDistanceKm += edge.lengthKm;
    if (!edge.electrified) electrifiedAllWay = false;
    if (edge.maxSpeedKmh < maxPermissibleSpeedKmh) maxPermissibleSpeedKmh = edge.maxSpeedKmh;
    if (edge.gradientPercent > maxGradientPercent) maxGradientPercent = edge.gradientPercent;
    
    // exact base track cost
    trassenCostCents += edge.baseTrackPriceCents;
    
    // standard freight train average speed calculations (e.g., maxSpeed is line limit, but operating speed incorporates ramps)
    const effectiveSpeed = Math.min(80, maxPermissibleSpeedKmh) * (1.0 - (edge.gradientPercent * 0.1));
    totalDurationMinutes += Math.round((edge.lengthKm / effectiveSpeed) * 60);

    if (edge.hasConstruction) activeConstructionSurcharges += 15000;
  }

  trassenCostCents += activeConstructionSurcharges;

  // Mass-gradient physics calculation: Wh = m * g * h + rolling friction
  // Simple realistic train energy formula: 
  // Energy (kWh) = Weight (tons) * distance (km) * 0.012 + (if gradient > 0) Weight * gravity * delta_h
  const frictionEnergy = trainWeightTons * totalDistanceKm * 0.013; // 0.013 kWh per ton-km
  const climbingWork = maxGradientPercent > 0 
    ? (trainWeightTons * 9.81 * (totalDistanceKm * (maxGradientPercent / 100)) * 1000) / 3600000 // PE Joule converted to kWh
    : 0;
  const estimatedEnergyKwh = Math.round(frictionEnergy + climbingWork);

  // Robustness score reflects lack of construction, low gradients, electrified lines
  let punctualityProbability = 0.95;
  for (const edge of edgesUsed) {
    if (edge.hasConstruction) punctualityProbability -= 0.08;
    if (edge.gradientPercent > 1.5) punctualityProbability -= 0.05;
    if (!edge.electrified) punctualityProbability -= 0.04;
  }
  punctualityProbability = Math.max(0.60, punctualityProbability);

  // Normalized scores for calculation (0 to 1)
  const normDuration = Math.max(0.1, 1 - (totalDurationMinutes / 800)); // lower is better
  const normCost = Math.max(0.1, 1 - (trassenCostCents / 400000));
  const normEnergy = Math.max(0.1, 1 - (estimatedEnergyKwh / 12000));
  const normRobustness = punctualityProbability;

  const scoreRaw = 
    weights.duration * normDuration +
    weights.cost * normCost +
    weights.robustness * normRobustness +
    weights.energy * normEnergy;

  const score = Math.round(scoreRaw * 100);

  return {
    id,
    path,
    totalDistanceKm,
    totalDurationMinutes,
    electrifiedAllWay,
    maxPermissibleSpeedKmh,
    maxGradientPercent,
    estimatedEnergyKwh,
    trassenCostCents,
    punctualityProbability: Math.round(punctualityProbability * 100) / 100,
    score,
    scoreDetails: {
      duration: Math.round(normDuration * 100),
      cost: Math.round(normCost * 100),
      robustness: Math.round(normRobustness * 100),
      energy: Math.round(normEnergy * 100)
    }
  };
}

// --------------------------------------------------------
// 3. PRICING & FINANCIAL ENGINE (INT/CENT RESOLUTION)
// --------------------------------------------------------
export function calculatePricing(
  order: FreightOrder,
  route: RouteOption,
  settings: ScenarioSettings
): Financials {
  // Base cost calculation mapping strictly to Section 15
  const baseTrackAccess = Math.round(route.trassenCostCents * settings.trackCapacityFactor);
  
  // Energy costs (electricity / diesel)
  const energyPricePerKwhCents = Math.round(25 * settings.energyPriceFactor); // 25 cents base per kWh
  const costEnergy = Math.round(route.estimatedEnergyKwh * energyPricePerKwhCents);

  // Locomotive cost: Hourly rate * active hours (duration in hours)
  const activeHours = route.totalDurationMinutes / 60;
  const locomotiveHourlyRateCents = 12000; // 120€ per hour
  const costLocomotive = Math.round(activeHours * locomotiveHourlyRateCents * order.requiredWagonCount * 0.08); // dynamic scaled by length

  // Wagons cost: Daily rate per wagon (pro-rated by hours)
  const wagonDailyRateCents = 4500; // 45€ per day
  const wagonActiveHoursCost = (activeHours / 24) * wagonDailyRateCents;
  const costWagons = Math.round(order.requiredWagonCount * wagonActiveHoursCost);

  // Crew wages
  const costCrew = Math.round(activeHours * 5500 * settings.crewAvailabilityFactor); // 55€ hourly driver + overhead

  // Terminal handling costs (both ends)
  const costTerminal = Math.round(order.volumeTons * 180 * settings.terminalThroughputFactor); // 1.80€ per ton handled

  // Risk buffer calculated from gradients, delays, and scenario
  const gradientRiskFactor = route.maxGradientPercent > 1.5 ? 25000 : 0;
  const delayRiskFactor = (1 - route.punctualityProbability) * 50000;
  const costRiskBuffer = Math.round((gradientRiskFactor + delayRiskFactor) * (settings.disruptionRate === "HIGH" ? 1.5 : 1.0));

  // Disruption hypothetical penalties
  const costDisruptionPenalty = 0; // standard budget is 0 on ideal runs, but updated dynamically during disturbances

  const totalCost = 
    baseTrackAccess +
    costEnergy +
    costLocomotive +
    costWagons +
    costCrew +
    costTerminal +
    costRiskBuffer;

  // Pricing Engine calculations for offers
  // Desired profit margin (e.g., 18%)
  const desiredMarginPercent = 0.18;
  const offeredPriceCents = Math.round(totalCost / (1 - desiredMarginPercent));
  const marginDeckungsbeitragCents = offeredPriceCents - totalCost;

  // return full Financial model matching Section 17 & 36
  return {
    revenueCents: offeredPriceCents,
    costTrackAccessCents: baseTrackAccess,
    costEnergyCents: costEnergy,
    costLocomotiveCents: costLocomotive,
    costWagonsCents: costWagons,
    costCrewCents: costCrew,
    costTerminalCents: costTerminal,
    costDisruptionPenaltyCents: costDisruptionPenalty,
    costRiskBufferCents: costRiskBuffer,
    marginDeckungsbeitragCents,
    marginPercent: Math.round((marginDeckungsbeitragCents / offeredPriceCents) * 100),
    roicPercent: Math.round((marginDeckungsbeitragCents / (totalCost * 0.3)) * 100) // dynamic capital bind
  };
}

// --------------------------------------------------------
// 4. SPOT MARKET MATCHING ENGINE (LIMIT BOOK)
// --------------------------------------------------------
export class SpotMarketBook {
  buyOrders: SpotMarketOrder[] = [];
  sellOrders: SpotMarketOrder[] = [];
  trades: SpotMarketTrade[] = [];
  auditLogs: AuditLog[] = [];

  addOrder(order: SpotMarketOrder): SpotMarketTrade[] {
    const executedTrades: SpotMarketTrade[] = [];
    if (order.type === "BUY") {
      this.buyOrders.push(order);
      this.buyOrders.sort((a, b) => b.pricePerTonCents - a.pricePerTonCents || new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    } else {
      this.sellOrders.push(order);
      this.sellOrders.sort((a, b) => a.pricePerTonCents - b.pricePerTonCents || new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    }

    this.auditLogs.push({
      id: "a_" + Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      actor: "Frachtmarkt-Matching",
      action: `Order hinzugefügt: ${order.type} für ${order.commodity} (${order.volumeTons}t) @ ${order.pricePerTonCents / 100}€/t`,
      beforeState: "Aktiv",
      afterState: "Gelistet",
      reason: `Digitale Marktorder eingestellt.`
    });

    // Run Match Cycle (Price-Time Priority)
    let i = 0;
    while (i < this.buyOrders.length) {
      const buy = this.buyOrders[i];
      let matched = false;

      for (let j = 0; j < this.sellOrders.length; j++) {
        const sell = this.sellOrders[j];

        // Check compatibility
        if (
          buy.sourceStationId === sell.sourceStationId &&
          buy.targetStationId === sell.targetStationId &&
          buy.commodity === sell.commodity &&
          buy.cargoType === sell.cargoType &&
          buy.pricePerTonCents >= sell.pricePerTonCents
        ) {
          // Calculate matching volume
          const tradeVolume = Math.min(buy.volumeTons, sell.volumeTons);
          const executionPricePerTon = sell.pricePerTonCents; // seller's price governs match
          const totalTradePrice = tradeVolume * executionPricePerTon;

          const trade: SpotMarketTrade = {
            id: "t_" + Math.random().toString(36).substr(2, 9),
            buyOrderId: buy.id,
            sellOrderId: sell.id,
            sourceStationId: buy.sourceStationId,
            targetStationId: buy.targetStationId,
            volumeTons: tradeVolume,
            pricePerTonCents: executionPricePerTon,
            totalPriceCents: totalTradePrice,
            timestamp: new Date().toISOString()
          };

          this.trades.push(trade);
          executedTrades.push(trade);

          this.auditLogs.push({
            id: "a_" + Math.random().toString(36).substr(2, 9),
            timestamp: new Date().toISOString(),
            actor: "System Match Engine",
            action: `Transaktion ausgeführt: ${buy.commodity} (${tradeVolume}t) Duisburg -> München`,
            beforeState: "Offene Order",
            afterState: "Trade Abgewickelt",
            reason: `Matching auf Spotmarkt vollzogen. Preis: ${(trade.totalPriceCents / 100).toFixed(2)}€`
          });

          // Adjust volumes
          buy.volumeTons -= tradeVolume;
          sell.volumeTons -= tradeVolume;

          if (buy.volumeTons <= 0) {
            this.buyOrders.splice(i, 1);
            matched = true;
          }
          if (sell.volumeTons <= 0) {
            this.sellOrders.splice(j, 1);
            j--;
          }
          break;
        }
      }
      if (!matched) i++;
    }

    return executedTrades;
  }
}

// --------------------------------------------------------
// 5. MASTER SEEDING METHOD FOR SYSTEM DATA
// --------------------------------------------------------
export function seedSystemData(): {
  locomotives: Locomotive[];
  wagons: Wagon[];
  crew: CrewMember[];
  terminals: Terminal[];
  customers: Customer[];
  orders: FreightOrder[];
  trains: Train[];
  spotMarket: SpotMarketBook;
} {
  const locomotives: Locomotive[] = [];
  const wagons: Wagon[] = [];
  const crew: CrewMember[] = [];
  const terminals: Terminal[] = [];
  const customers: Customer[] = [];

  // Seed Locomotives (100 units, structured BRs)
  const stationsCount = INITIAL_STATIONS.length;
  for (let i = 1; i <= 100; i++) {
    const locId = `L-${185000 + i}`;
    const series = i % 3 === 0 ? "BR 193 (Vectron)" : i % 3 === 1 ? "BR 185 (TRAXX)" : "BR 247 (Diesel)";
    const power = series.includes("Vectron") ? 6400 : series.includes("185") ? 5600 : 2400;
    const propulsion = series.includes("Diesel") ? "DIESEL" : "OBERLEITUNG";
    const locNode = INITIAL_STATIONS[i % stationsCount]?.id || "DU";

    locomotives.push({
      id: locId,
      name: `Lokomotive ${185000 + i}`,
      series,
      powerKW: power,
      weightTons: 86,
      propulsion,
      maxSpeedKmh: series.includes("Vectron") ? 160 : 140,
      hourlyCostCents: propulsion === "DIESEL" ? 18000 : 12000,
      maintenanceStatus: i === 12 || i === 45 ? "WARTUNG" : "OK",
      totalKilometers: 120000 + (i * 2400),
      operatingHours: 2300 + (i * 45),
      nextMaintenanceKm: 150000,
      locationNodeId: locNode
    });
  }

  // Seed Wagons (compact count to fit memory gracefully but fully functional, 150 Wagons tracked across depots)
  const types: WagonType[] = ["CONTAINER", "KESSEL", "SCHUETTGUT", "FLACH", "GEDECKT", "AUTOTRANSPORT"];
  for (let i = 1; i <= 150; i++) {
    const wId = `W-${734000 + i}`;
    const type = types[i % types.length];
    const tare = type === "KESSEL" ? 22 : type === "FLACH" ? 18 : 20;
    const locNode = INITIAL_STATIONS[i % stationsCount]?.id || "K";

    wagons.push({
      id: wId,
      type,
      tareWeightTons: tare,
      maxPayloadTons: type === "KESSEL" ? 68 : type === "FLACH" ? 72 : 65,
      lengthMeters: type === "FLACH" ? 19.8 : type === "CONTAINER" ? 19.6 : 14.5,
      locationNodeId: locNode,
      status: "VERFUEGBAR",
      nextMaintenanceKm: 50000,
      totalKilometers: 15000 + (i * 300)
    });
  }

  // Seed Crew (40 staff)
  const crewNames = ["H. Müller", "M. Schmidt", "S. Becker", "K. Weber", "A. Wagner", "J. Hoffmann", "D. Schäfer", "L. Koch", "P. Richter", "C. Klein"];
  for (let i = 1; i <= 40; i++) {
    const locNode = INITIAL_STATIONS[i % stationsCount]?.id || "DU";
    crew.push({
      id: `C-${100 + i}`,
      name: crewNames[i % crewNames.length] + ` (TF-${i})`,
      role: i % 4 === 0 ? "RANGIERER" : i % 4 === 1 ? "LOKFUEHRER" : i % 4 === 2 ? "DISPONENT" : "TERMINAL_CREW",
      homeStationId: locNode,
      currentLocationId: locNode,
      status: i % 10 === 0 ? "RUHE" : "BEREIT",
      weeklyWorkingMinutes: 1200 + (i * 20),
      maxWorkingMinutesPerWeek: 2400
    });
  }

  // Seed Terminals (for all station nodes mapped as terminals or ports)
  for (const station of INITIAL_STATIONS) {
    if (station.type === "TERMINAL" || station.type === "HAFEN") {
      terminals.push({
        id: station.id,
        name: `${station.name} Terminal`,
        tracks: [
          { id: `t_${station.id}_1`, lengthMeters: 750, maxWagonsCapacity: 45, currentWagonsCount: 12 },
          { id: `t_${station.id}_2`, lengthMeters: 750, maxWagonsCapacity: 45, currentWagonsCount: 8 }
        ],
        gantryCranesCount: station.type === "HAFEN" ? 6 : 2,
        reachStackersCount: 3,
        dailyCapacityTEU: station.type === "HAFEN" ? 2500 : 400,
        currentTEUStored: station.type === "HAFEN" ? 1200 : 150,
        handlingCostPerTEUCents: station.type === "HAFEN" ? 2200 : 3100,
        occupiedSlots: { 8: 1, 14: 2, 20: 1 }
      });
    }
  }

  // Seed Customers (Section 53)
  const customerNames = [
    { name: "Rheinland Stahl GmbH", industry: "STAHL" },
    { name: "Nordchem Industrie AG", industry: "CHEMIE" },
    { name: "Bayern Automotive GmbH", industry: "AUTOMOBIL" },
    { name: "Mitteldeutsche Logistik AG", industry: "INTERMODAL" },
    { name: "Elbe Container Services GmbH", industry: "INTERMODAL" },
    { name: "Sachsen Baustoffe KG", industry: "BAUSTOFFE" },
    { name: "Westphalia Agrarhandel", industry: "LANDWIRTSCHAFT" },
    { name: "Ruhr Kohle&Energie AG", industry: "ENERGIE" }
  ] as const;

  for (let i = 0; i < customerNames.length; i++) {
    customers.push({
      id: `CUST-${101 + i}`,
      name: customerNames[i].name,
      industry: customerNames[i].industry,
      reliabilityRating: 0.95 - (i * 0.02),
      lifetimeVolumeTons: 150000 + (i * 45000)
    });
  }

  // Seed active Freight Orders (3 seed bookings to start)
  const orders: FreightOrder[] = [
    {
      id: "ORD-201",
      customerId: "CUST-101",
      customerName: "Rheinland Stahl GmbH",
      commodity: "Warmbreitband",
      cargoType: "FLACH",
      volumeTons: 1200,
      requiredWagonCount: 18,
      sourceStationId: "DU",
      targetStationId: "M",
      earliestDeparture: new Date().toISOString(),
      latestArrival: new Date(Date.now() + 86400000).toISOString(),
      status: "GEBUCHT",
      offeredPriceCents: 18400000, // 184,000.00 €
      contractType: "RAHMENVERTRAG",
      createdAt: new Date().toISOString()
    },
    {
      id: "ORD-202",
      customerId: "CUST-102",
      customerName: "Nordchem Industrie AG",
      commodity: "Ethylen",
      cargoType: "KESSEL",
      volumeTons: 850,
      requiredWagonCount: 14,
      sourceStationId: "K",
      targetStationId: "L",
      earliestDeparture: new Date().toISOString(),
      latestArrival: new Date(Date.now() + 100000000).toISOString(),
      status: "ANGEBOTEN",
      offeredPriceCents: 14200000,
      contractType: "SPOT",
      createdAt: new Date().toISOString()
    }
  ];

  // Seed spot market order book matching engine
  const spotMarket = new SpotMarketBook();
  spotMarket.addOrder({
    id: "sp_01",
    type: "BUY",
    customerId: "CUST-101",
    sourceStationId: "DU",
    targetStationId: "M",
    commodity: "Stahl",
    volumeTons: 4000,
    cargoType: "FLACH",
    pricePerTonCents: 4500, // 45.00€ per ton limit
    quantityWagons: 40,
    createdAt: new Date().toISOString(),
    durationDays: 3,
    orderType: "LIMIT"
  });

  return {
    locomotives,
    wagons,
    crew,
    terminals,
    customers,
    orders,
    trains: [],
    spotMarket
  };
}

// --------------------------------------------------------
// 6. MONTE-CARLO SCENARIO SIMULATOR
// --------------------------------------------------------
export function runHighFidelitySimulation(
  settings: ScenarioSettings,
  edges: TrackEdge[]
): SimulationResult {
  // Setup reproducible seed pseudo-random numbers
  let seed = 42;
  function random() {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }

  // Baseline variables
  let totalTrainsRun = Math.round(100 * settings.demandFactor);
  let delaySum = 0;
  let delaysCount = 0;
  let revenueCents = 0;
  let costsCents = 0;
  let co2EmittedKg = 0;
  let totalEnergyKwh = 0;

  // Let's model track capacity utilized over edge limits
  let capacityFullEdges = 0;
  for (const edge of edges) {
    const usage = edge.capacityUsedTrains / (edge.capacityMaxTrainsPerDay * settings.trackCapacityFactor);
    if (usage > 0.85) capacityFullEdges++;
  }

  const trackCapacityUtilization = Math.round(
    (edges.reduce((sum, e) => sum + e.capacityUsedTrains, 0) / 
     edges.reduce((sum, e) => sum + (e.capacityMaxTrainsPerDay * settings.trackCapacityFactor), 0)) * 100
  );

  // Core loop for standard Monte Carlo train executions
  for (let i = 0; i < totalTrainsRun; i++) {
    // Random path from our seeded stations
    const startIdx = Math.floor(random() * INITIAL_STATIONS.length);
    let endIdx = Math.floor(random() * INITIAL_STATIONS.length);
    if (startIdx === endIdx) endIdx = (endIdx + 1) % INITIAL_STATIONS.length;

    const start = INITIAL_STATIONS[startIdx]!;
    const end = INITIAL_STATIONS[endIdx]!;

    const pathObj = findShortestPath(start.id, end.id, edges);
    if (!pathObj) continue;

    const route = compileRouteOption(`sim_${i}`, pathObj.path, pathObj.edgesUsed, 1500, 500, {
      duration: 0.3, cost: 0.2, robustness: 0.3, energy: 0.2
    });

    // Simulate potential delays based on gradient, construction and disruptionRate
    let delay = Math.round(random() * 15); // standard line delay
    if (route.maxGradientPercent > 1.5) delay += Math.round(random() * 20);
    
    if (settings.disruptionRate === "HIGH") {
      delay += Math.round(random() * 60);
    } else if (settings.disruptionRate === "LOW") {
      delay = Math.max(0, delay - 5);
    }

    delaySum += delay;
    delaysCount++;

    // CO2 Math: Average modern diesel locomotive produces ~25g CO2 per ton-km
    // Electric locomotives produce ~5.5g CO2 (mix electricity)
    const co2PerTonKm = route.electrifiedAllWay ? 5.5 : 25.0;
    const co2Emitted = 1500 * route.totalDistanceKm * co2PerTonKm * 0.001; // Kg
    co2EmittedKg += co2Emitted;

    // Pricing & financial sums
    const fakeOrder: FreightOrder = {
      id: `sim_o_${i}`,
      customerId: "CUST-101",
      customerName: "Rheinland Stahl",
      commodity: "Container",
      cargoType: "CONTAINER",
      volumeTons: 1500,
      requiredWagonCount: 22,
      sourceStationId: start.id,
      targetStationId: end.id,
      earliestDeparture: new Date().toISOString(),
      latestArrival: new Date().toISOString(),
      status: "GEBUCHT",
      offeredPriceCents: 0,
      contractType: "SPOT",
      createdAt: new Date().toISOString()
    };

    const fin = calculatePricing(fakeOrder, route, settings);
    revenueCents += fin.revenueCents;
    
    // factor in extra penalty costs for delayed trains
    let penalty = 0;
    if (delay > 30) {
      penalty = Math.round((delay - 30) * 12000); // 120€ per min delayed above 30 min
    }
    
    costsCents += (fin.revenueCents - fin.marginDeckungsbeitragCents) + penalty;
    totalEnergyKwh += route.estimatedEnergyKwh;
  }

  const averageDelayMinutes = Math.round(delaySum / delaysCount);
  const onTimeRatePercent = Math.round(
    (delaysCount > 0 ? (delaysCount - (delaySum / 45)) / delaysCount : 1) * 100
  );

  const netMarginCents = revenueCents - costsCents;
  const ebitdaCents = Math.round(netMarginCents * 1.15); // EBITDA has fixed asset depreciation factored out

  // CO2 saved compared to traditional road transport (LKW average is ~110g CO2 per ton-km)
  const co2TruckKg = 1500 * 200 * totalTrainsRun * 0.110; 
  const co2SavedVsTruckKg = Math.round(co2TruckKg - co2EmittedKg);

  return {
    scenarioId: settings.id,
    totalTrainsRun,
    averageDelayMinutes,
    trackCapacityUtilization,
    emptyWagonKilometers: Math.round(totalTrainsRun * 85 * (1.2 - settings.terminalThroughputFactor)),
    totalEnergyKwh,
    totalRevenueCents: revenueCents,
    totalCostCents: costsCents,
    netMarginCents,
    ebitdaCents,
    onTimeRatePercent: Math.max(45, Math.min(99, onTimeRatePercent)),
    co2EmittedKg: Math.round(co2EmittedKg),
    co2SavedVsTruckKg: Math.max(1000, Math.round(co2SavedVsTruckKg))
  };
}

// --------------------------------------------------------
// 7. THE 20-STEP MASTER DEMO STATE MACHINE (Section 54)
// --------------------------------------------------------
export const MASTER_DEMO_STEPS = [
  { number: 1, title: "Kundenanfrage erzeugen", description: "Rheinland Stahl GmbH fragt 4.000 t Stahl von Duisburg nach München an.", completed: false },
  { number: 2, title: "Transportnachfrage prüfen", description: "System prüft die Ladungsdetails, berechnet Trasseneigenschaften & Wagenkapazität.", completed: false },
  { number: 3, title: "Pricing & Margenkalkulation", description: "Die Pricing Engine berechnet Trassengebühren, Energie, Lok/Wagenverschleiß & gewünschte Marge.", completed: false },
  { number: 4, title: "Trassenoptionen ermitteln", description: "Die Trassenengine erzeugt fünf alternative Routen durch Deutschland mit Performance-Scores.", completed: false },
  { number: 5, title: "Weg-Optimierer ausführen", description: "MIP-Optimierungsalgorithmus ermittelt die wirtschaftlich & operativ beste Kombination.", completed: false },
  { number: 6, title: "Güterzug-Objekt instanziieren", description: "Der operative Güterzug 'DGS 48152' wird mit physischen Attributen initialisiert.", completed: false },
  { number: 7, title: "Lokomotive & Flotte zuweisen", description: "Zuweisung einer leistungsstarken Elektro-Doppeltraktion (2x BR 193) aufgrund der Zugmasse.", completed: false },
  { number: 8, title: "Wagengruppe disponieren", description: "40 tragfähige Flachwagen (Gattung Sgns) werden aus dem Depot Duisburg gekoppelt.", completed: false },
  { number: 9, title: "Triebfahrzeugführer & Crew planen", description: "Personalplanung reserviert Lokführer Müller und Schichtmannschaft am Heimatdepot.", completed: false },
  { number: 10, title: "Terminal-Zeitfenster buchen", description: "Ladezeiten an den Containerbahnhöfen Duisburg-Ruhrort und München-Riem reserviert.", completed: false },
  { number: 11, title: "Fahrplan & Trassenslots freigeben", description: "Der Fahrplan wird im Digtzwilling registriert. Letzte Freigabe für Abfahrt 18:00 Uhr.", completed: false },
  { number: 12, title: "Abfahrt & Zuglauf starten", description: "Zug startet pünktlich. Live-Telemetrie meldet GPS-Position Richtung Süden.", completed: false },
  { number: 13, title: "Störung simulieren", description: "Kritischer Signalboxausfall in Frankfurt Ost! Strecke für DGS 48152 blockiert.", completed: false },
  { number: 14, title: "Verspätungsanalyse berechnen", description: "System berechnet +23 Min. Verspätungsrisiko, Trassenkonflikte und Folgeverspätungen.", completed: false },
  { number: 15, title: "Dynamische Umleitung (Reroute)", description: "Dijkstra berechnet alternative Umleitung über Gemünden/Würzburg unter Umgehung Frankfurts.", completed: false },
  { number: 16, title: "Kosten & Marge anpassen", description: "Durch die Umleitung entstehen 42 km Mehrweg. Aktualisierung der Betriebs- & Trassenkosten.", completed: false },
  { number: 17, title: "ETA Kundenmeldung senden", description: "Automatisches Sendeverfahren meldet dem Empfänger in München die präzise neue ETA (+14 Min).", completed: false },
  { number: 18, title: "Ankunft & Terminal-Entladung", description: "DGS 48152 erreicht München Riem. Umschlagkräne beginnen umgehend mit der Entladung.", completed: false },
  { number: 19, title: "Rechnungslegung & Zahlungsfluss", description: "Rechnungs-PDF generiert. Transaktion von 184.000,00 € auf das Firmenkonto verbucht.", completed: false },
  { number: 20, title: "Deckungsbeitrag & Markterkenntnis", description: "Finanz-Audit abgeschlossen: DB I und DB II in Marktanalytik für zukünftiges Pricing verbucht.", completed: false }
];

export function executeMasterDemoStep(stepNumber: number, state: MasterDemoState, edges: TrackEdge[]): MasterDemoState {
  const newState = { ...state };
  const currentStepObj = newState.steps.find(s => s.number === stepNumber);
  
  if (!currentStepObj) return newState;

  let logMessage = "";
  let stepData: any = {};

  switch (stepNumber) {
    case 1:
      logMessage = "Rheinland Stahl GmbH Duisburg stellt Spotmarkt-Kauforder ein: 4.000 t warmgewalzter Stahl nach München Riem.";
      stepData = {
        kunde: "Rheinland Stahl GmbH",
        ware: "Stahlcoils (Warmbreitband)",
        masse: "4.000 t",
        start: "Duisburg-Ruhrort Hafen (DU)",
        ziel: "München Riem Terminal (M)",
        volumenEuros: 184000.00
      };
      break;
    case 2:
      logMessage = "Systemprüfung: Masse 4.000 t erfordert 40 Flachwagen (Spannweite je 19.8m, Eigengewicht 18t). Gesamtlänge ca. 792m (plus Loks).";
      stepData = {
        masseGesamtTons: 4000 + (40 * 18), // Ladung + Eigengewicht = 4720 t
        zuglaengeMeters: 792 + 38, // Wagen + Doppeltraktion Loks = 830m
        wagonTyp: "FLACH (Sgns)",
        benoetigteAchsen: 160
      };
      break;
    case 3:
      logMessage = "Pricing berechnet Grundkosten: Trassengebühren, Strom (Traktion), Wagenmiete, Lokminderwert, Personal und Umschlag.";
      // exact cents logic
      stepData = {
        trassenCents: 15000 + 38000, // DU->K, K->F, F->N, N->M cumulative trassen
        energieCents: 4500000,
        personalCents: 120000,
        fleetCents: 2800000,
        handlingCents: 720000,
        desiredMarginPercent: 18,
        costGesamtCents: 14750000,
        preisOfferedCents: 18400000
      };
      break;
    case 4:
      logMessage = "Trassenengine berechnet 5 Alternativrouten mit Dijkstra und Scoring-Faktoren (Robustheit, Steigung, Verspätungsrisiko).";
      stepData = {
        routen: [
          { name: "Süd-Schiene (Rheintal-Mittel)", km: 620, dauerMin: 490, robustheit: "92%", score: 91 },
          { name: "Ost-Umweg (Kassel-Leipzig)", km: 740, dauerMin: 580, robustheit: "88%", score: 78 },
          { name: "Direkttrasse (Spessart-Ramp)", km: 580, dauerMin: 460, robustheit: "71% (Steigung!)", score: 84 },
          { name: "West-Bypass (Mannheim-Karlsruhe)", km: 680, dauerMin: 540, robustheit: "90%", score: 81 },
          { name: "Güterzug-Sonderslot", km: 630, dauerMin: 510, robustheit: "95%", score: 94 }
        ]
      };
      break;
    case 5:
      logMessage = "Optimierungsassistent wählt den 'Güterzug-Sonderslot' (Score 94) für maximale Marge bei hoher Pünktlichkeitserwartung.";
      stepData = {
        optimierungsVerfahren: "Mixed-Integer Linear Programming (MILP)",
        zielfunktion: "Max Deckungsbeitrag bei Robustheitsgrenze > 0.90",
        nebenbedingungen: "Zuglänge 830m <= Limit 835m, Steigung < 2.0%",
        ergebnis: "Trasse r_bypass gewählt. Berechneter Score: 94."
      };
      break;
    case 6:
      logMessage = "Zugobjekt 'DGS 48152' im Leitstand angelegt. Status: PLANUNG.";
      stepData = {
        zugNummer: "DGS 48152",
        evudeId: "RQ-SYN-48152",
        startBahnhof: "Duisburg Hafen (DU)",
        zielBahnhof: "München Riem (M)",
        aktuelleGeschwindigkeitKmh: 0,
        zugMasseTons: 4720
      };
      break;
    case 7:
      logMessage = "Lokomotivzuweisung abgeschlossen: Elektro-Doppeltraktion BR 193 (Vectron) gekoppelt. Gesamtleistung 12.800 kW.";
      stepData = {
        loks: [
          { id: "L-185021", name: "BR 193 021", leistungKW: 6400, propulsion: "OBERLEITUNG" },
          { id: "L-185022", name: "BR 193 022", leistungKW: 6400, propulsion: "OBERLEITUNG" }
        ],
        traktionBenoetigt: "Doppeltraktion für 4.720 t Gesamtlast auf Steigungen"
      };
      break;
    case 8:
      logMessage = "40 Güterwagen vom Typ FLACH (Sgns) im Hafen Duisburg reserviert und mechanisch an Doppeltraktion gekoppelt.";
      stepData = {
        wagenIds: Array.from({ length: 40 }, (_, i) => `W-734${100 + i}`),
        wagenTyp: "FLACH",
        bremshundertstel: "115 G"
      };
      break;
    case 9:
      logMessage = "Personaldisposition bucht Triebfahrzeugführer H. Müller (Schicht 12) für die Fahrt Duisburg -> Mannheim, danach Ablösung.";
      stepData = {
        fahrerStart: "H. Müller (Id: C-102)",
        fahrerWechselStation: "Mannheim Rangierbahnhof (MA)",
        fahrerAbloesung: "M. Schmidt (Id: C-103)"
      };
      break;
    case 10:
      logMessage = "Terminalkapazität gebucht: Slot DU 18:00 - 20:00 (Beladung) & Slot M 06:00 - 08:00 (Entladung).";
      stepData = {
        startTerminalSlot: "DU Track 2 (18:00 - 20:00 Uhr)",
        zielTerminalSlot: "M Track 1 (06:00 - 08:00 Uhr)",
        kranVerfuegbarkeit: "Zwei Gantry-Kräne reserviert"
      };
      break;
    case 11:
      logMessage = "Fahrplanerstellung abgeschlossen. Slot-Freigabe durch Trassenmanager erteilt. Trassenvertrag digital signiert.";
      stepData = {
        trassenId: "TR-48152-BYPASS",
        fahrplanPlan: "Abfahrt Duisburg 18:00, Ankunft München 02:40",
        pufferMinuten: 25
      };
      break;
    case 12:
      logMessage = "Zug DGS 48152 gestartet. Telemetrie meldet GPS-Signale aus Düsseldorf (18:14 Uhr) mit 75 km/h Reisegeschwindigkeit.";
      stepData = {
        abfahrtIst: "18:00",
        status: "UNTERWEGS",
        aktuellePosition: "Düsseldorf Reisholz",
        reisegeschwindigkeitKmh: 80,
        energieIstKwh: 340
      };
      break;
    case 13:
      logMessage = "ALARM: Leitstelle meldet Signalboxausfall in Frankfurt Ost! Streckensegment Frankfurt <-> Mannheim blockiert.";
      // Trigger a disruption in the engine
      stepData = {
        stoerungsId: "DIST-Frankfurt",
        typ: "STELLWERKSSTOERUNG",
        ort: "Frankfurt Ost",
        auswirkung: "Sperrung aller Trassen Richtung Süden über Frankfurt"
      };
      break;
    case 14:
      logMessage = "Berechnung der Auswirkungen: Ohne Disposition beträgt die erwartete Verspätung für DGS 48152 ca. +210 Minuten (Betriebshalt).";
      stepData = {
        erwarteteVerspaetungOhneDisposition: 210,
        konflikte: "Kollision mit nachfolgendem Regionalverkehr, Personal-Arbeitszeitüberschreitung Müller"
      };
      break;
    case 15:
      logMessage = "Umleitung wird berechnet: Dijkstra-Rerouting über Gemünden, Schweinfurt nach Nürnberg, Umgehung von Frankfurt.";
      stepData = {
        umleitungStrecke: "Duisburg -> Köln -> Siegen -> Gemünden -> Würzburg -> Nürnberg -> München",
        mehrdistanzKm: 42,
        zusatzFahrzeitMinuten: 35
      };
      break;
    case 16:
      logMessage = "Finanzengine verbucht Mehrkosten für Umleitung: +1.200 € Trassengebühr, +840 € Traktionsstrom.";
      stepData = {
        mehrkostenTrasseCents: 120000,
        mehrkostenEnergieCents: 84000,
        deckungsbeitragAngepasstCents: 18400000 - (14750000 + 204000), // Adjusted DB
        margeAngespasstPercent: 17.5
      };
      break;
    case 17:
      logMessage = "Präzises Rerouting-Update: Kunden-SLA erfordert automatische ETA-Korrektur an Rheinland Stahl.";
      stepData = {
        neueEtaMünchen: "02:54 Uhr (Zuvor: 02:40 Uhr)",
        verspaetungEndgueltigMinuten: 14,
        statusSla: "GRÜN (Pünktlich im Toleranzfenster)"
      };
      break;
    case 18:
      logMessage = "Zug erreicht München Riem pünktlich um 02:54 Uhr (+14 Min). Kran-Entladung der 40 Flachwagen beginnt umgehend.";
      stepData = {
        ankunftIst: "02:54",
        entladeDauerMinuten: 110,
        verfuegbarkeitWagenNachEntladung: "Freigegeben für Gegenrichtung ab 05:00 Uhr"
      };
      break;
    case 19:
      logMessage = "Transaktion abgewickelt. Rechnungsnummer RE-2026-48152 erstellt über 184.000,00 €.";
      stepData = {
        rechnungsNummer: "RE-2026-48152",
        zahlungseingangStatus: "ERFOLGREICH",
        valuta: "15.09.2026"
      };
      break;
    case 20:
      logMessage = "Finanz-Audit abgeschlossen. Deckungsbeitrag von 34.460,00 € in Marktanalyse erfasst. Wirtschaftliches Ergebnis übertroffen.";
      stepData = {
        erlösCents: 18400000,
        kostenCents: 14954000,
        db1Cents: 3446000,
        db1MargePercent: 18.7,
        roicPercent: 76.2,
        markterkenntnis: "Duisburg-München intermodaler Sonderslot trotz Rerouting rentabel. Hohe Elastizität."
      };
      break;
  }

  newState.log.push(logMessage);
  currentStepObj.completed = true;
  currentStepObj.data = stepData;
  newState.currentStep = stepNumber + 1;

  return newState;
}
