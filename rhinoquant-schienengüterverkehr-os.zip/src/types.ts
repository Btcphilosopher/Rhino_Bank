/**
 * RHINOQUANT SCHIENENGÜTERVERKEHR OS - Shared Type Definitions
 * 
 * Consistent object model mapping:
 * MARKT -> KUNDE -> AUFTRAG -> TRASSE -> ZUG -> FAHRPLAN -> LIVE-BETRIEB -> FINANZEN
 */

export interface StationNode {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: "KNOTEN" | "TERMINAL" | "GRENZE" | "HAFEN";
  region: string;
}

export interface TrackEdge {
  id: string;
  source: string; // Station ID
  target: string; // Station ID
  lengthKm: number;
  electrified: boolean;
  maxSpeedKmh: number;
  maxAxleLoadTons: number;
  maxTrainLengthMeters: number;
  gradientPercent: number; // Steigung/Gefälle in %
  baseTrackPriceCents: number; // Trassengebühr base cost
  capacityMaxTrainsPerDay: number;
  capacityUsedTrains: number;
  isDisrupted: boolean;
  disruptionReason?: string;
  hasConstruction: boolean;
}

export interface RouteOption {
  id: string;
  path: string[]; // Station IDs
  totalDistanceKm: number;
  totalDurationMinutes: number;
  electrifiedAllWay: boolean;
  maxPermissibleSpeedKmh: number;
  maxGradientPercent: number;
  estimatedEnergyKwh: number;
  trassenCostCents: number;
  punctualityProbability: number; // 0.0 to 1.0
  score: number; // 0 to 100 based on configurable weights
  scoreDetails: {
    duration: number;
    cost: number;
    robustness: number;
    energy: number;
  };
}

export interface Locomotive {
  id: string;
  name: string; // e.g., "BR 185 021"
  series: string; // Baureihe e.g., "BR 185", "BR 193 (Vectron)", "BR 247 (Diesel)"
  powerKW: number;
  weightTons: number;
  propulsion: "OBERLEITUNG" | "DIESEL" | "BATTERIE" | "HYBRID";
  maxSpeedKmh: number;
  hourlyCostCents: number;
  maintenanceStatus: "OK" | "WARTUNG" | "DEFEKT";
  totalKilometers: number;
  operatingHours: number;
  nextMaintenanceKm: number;
  locationNodeId: string;
}

export type WagonType = "CONTAINER" | "KESSEL" | "SCHUETTGUT" | "FLACH" | "GEDECKT" | "AUTOTRANSPORT";

export interface Wagon {
  id: string;
  type: WagonType;
  tareWeightTons: number; // Eigengewicht
  maxPayloadTons: number;
  lengthMeters: number;
  locationNodeId: string;
  status: "VERFUEGBAR" | "RESERVIERT" | "BELADUNG" | "BELADEN" | "UNTERWEGS" | "ENTLADUNG" | "LEER" | "WARTUNG" | "DEFEKT";
  assignedTrainId?: string;
  nextMaintenanceKm: number;
  totalKilometers: number;
}

export interface Customer {
  id: string;
  name: string;
  industry: "STAHL" | "CHEMIE" | "AUTOMOBIL" | "ENERGIE" | "LANDWIRTSCHAFT" | "BAUSTOFFE" | "INTERMODAL" | "KONSUMGUETER";
  reliabilityRating: number; // 0.0 - 1.0
  lifetimeVolumeTons: number;
}

export interface FreightOrder {
  id: string;
  customerId: string;
  customerName: string;
  commodity: string; // e.g., "Warmbreitband", "Ethylen", "Kies"
  cargoType: WagonType;
  volumeTons: number;
  requiredWagonCount: number;
  sourceStationId: string;
  targetStationId: string;
  earliestDeparture: string; // ISO DateTime
  latestArrival: string; // ISO DateTime
  status: "ANFRAGE" | "ANGEBOTEN" | "GEBUCHT" | "DISPONIERT" | "UNTERWEGS" | "GELIEFERT" | "ABGERECHNET";
  offeredPriceCents: number; // Bid or final price in cents
  contractType: "SPOT" | "RAHMENVERTRAG";
  createdAt: string;
}

export interface CrewMember {
  id: string;
  name: string;
  role: "LOKFUEHRER" | "RANGIERER" | "DISPONENT" | "TERMINAL_CREW";
  homeStationId: string;
  currentLocationId: string;
  status: "BEREIT" | "DIENST" | "RUHE" | "URLAUB" | "KRANK";
  weeklyWorkingMinutes: number;
  maxWorkingMinutesPerWeek: number;
}

export interface TerminalTrack {
  id: string;
  lengthMeters: number;
  maxWagonsCapacity: number;
  currentWagonsCount: number;
}

export interface Terminal {
  id: string;
  name: string;
  tracks: TerminalTrack[];
  gantryCranesCount: number;
  reachStackersCount: number;
  dailyCapacityTEU: number;
  currentTEUStored: number;
  handlingCostPerTEUCents: number;
  occupiedSlots: { [hour: number]: number }; // Hour of day -> active trains loading
}

export interface Financials {
  revenueCents: number;
  costTrackAccessCents: number;
  costEnergyCents: number;
  costLocomotiveCents: number;
  costWagonsCents: number;
  costCrewCents: number;
  costTerminalCents: number;
  costDisruptionPenaltyCents: number;
  costRiskBufferCents: number;
  marginDeckungsbeitragCents: number; // EBIT / Contribution Margin
  marginPercent: number; // margin / revenue
  roicPercent: number;
}

export interface Train {
  id: string;
  orderId?: string;
  trainNumber: string; // e.g., "DGS 48152"
  status: "PLANUNG" | "BEREIT" | "UNTERWEGS" | "GESTOERT" | "ANKUNFT" | "ARCHIVIERT";
  locomotiveIds: string[];
  wagonIds: string[];
  crewIds: string[];
  routePath: string[]; // List of Station IDs
  currentPositionIdx: number; // Index in routePath
  progressBetweenNodes: number; // 0.0 to 1.0 (interpolation)
  departureTimePlanned: string;
  arrivalTimePlanned: string;
  departureTimeActual?: string;
  arrivalTimeActual?: string;
  delayMinutes: number;
  totalLengthMeters: number;
  totalWeightTons: number;
  maxSpeedKmh: number;
  activeDisruptionId?: string;
  financials: Financials;
}

export interface Disruption {
  id: string;
  type: "STELLWERKSSTOERUNG" | "STRECKENSPERRUNG" | "LOKSCHADEN" | "WAGENSCHADEN" | "PERSONALAUSFALL" | "TERMINALSTOERUNG" | "UNWETTER";
  title: string;
  description: string;
  affectedEdgeId?: string;
  affectedNodeId?: string;
  delayImpactMinutes: number;
  estimatedResolutionTime: string;
  financialCostCents: number;
}

export interface SpotMarketOrder {
  id: string;
  type: "BUY" | "SELL";
  customerId?: string;
  sourceStationId: string;
  targetStationId: string;
  commodity: string;
  volumeTons: number;
  cargoType: WagonType;
  pricePerTonCents: number;
  quantityWagons: number;
  createdAt: string;
  durationDays: number;
  orderType: "LIMIT" | "MARKET" | "IOC" | "FOK" | "GTC";
}

export interface SpotMarketTrade {
  id: string;
  buyOrderId: string;
  sellOrderId: string;
  sourceStationId: string;
  targetStationId: string;
  volumeTons: number;
  pricePerTonCents: number;
  totalPriceCents: number;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string; // e.g. "Vertrieb", "Trassenplanung", "System"
  action: string;
  beforeState: string;
  afterState: string;
  reason: string;
}

export interface ScenarioSettings {
  id: string;
  name: string;
  description: string;
  energyPriceFactor: number; // multiplier e.g. 1.2 (+20%)
  demandFactor: number; // multiplier
  trackCapacityFactor: number; // e.g. 0.85 (-15%)
  locomotiveAvailabilityFactor: number;
  crewAvailabilityFactor: number;
  terminalThroughputFactor: number;
  disruptionRate: "NONE" | "LOW" | "NORMAL" | "HIGH";
}

export interface SimulationResult {
  scenarioId: string;
  totalTrainsRun: number;
  averageDelayMinutes: number;
  trackCapacityUtilization: number;
  emptyWagonKilometers: number;
  totalEnergyKwh: number;
  totalRevenueCents: number;
  totalCostCents: number;
  netMarginCents: number;
  ebitdaCents: number;
  onTimeRatePercent: number; // Pünktlichkeit
  co2EmittedKg: number;
  co2SavedVsTruckKg: number;
}

// Master-Demo states matching Section 54 20-step lifecycle
export interface MasterDemoState {
  currentStep: number;
  activeOrderId?: string;
  activeTrainId?: string;
  log: string[];
  steps: {
    number: number;
    title: string;
    description: string;
    completed: boolean;
    data?: any;
  }[];
}
