import React, { useState, useEffect, useRef } from "react";
import {
  Activity,
  Train as TrainIcon,
  Map,
  Layers,
  ShieldAlert,
  DollarSign,
  TrendingUp,
  Bot,
  FileText,
  Settings,
  Play,
  Users,
  Anchor,
  Truck,
  FileCheck,
  RefreshCw,
  Sliders,
  Plus,
  X,
  ChevronRight,
  AlertTriangle,
  Info,
  Clock,
  CheckCircle,
  Database,
  ArrowRightLeft
} from "lucide-react";

import {
  StationNode,
  TrackEdge,
  Locomotive,
  Wagon,
  CrewMember,
  Terminal,
  Customer,
  FreightOrder,
  Train,
  Disruption,
  SpotMarketOrder,
  SpotMarketTrade,
  AuditLog,
  ScenarioSettings,
  SimulationResult,
  MasterDemoState
} from "./types";

export default function App() {
  // --------------------------------------------------------
  // TABS & SYSTEM STATE
  // --------------------------------------------------------
  const [activeTab, setActiveTab] = useState<
    "overview" | "market" | "network" | "fleet" | "disruptions" | "sim" | "demo" | "ai" | "audit"
  >("overview");

  const [state, setState] = useState<{
    stations: StationNode[];
    edges: TrackEdge[];
    locomotives: Locomotive[];
    wagons: Wagon[];
    crew: CrewMember[];
    terminals: Terminal[];
    customers: Customer[];
    orders: FreightOrder[];
    trains: Train[];
    spotOrders: SpotMarketOrder[];
    spotSells: SpotMarketOrder[];
    spotTrades: SpotMarketTrade[];
    disruptions: Disruption[];
    masterDemo: MasterDemoState;
    auditLogs: AuditLog[];
  } | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Auto-refresh interval (every 6 seconds for live state)
  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 6000);
    return () => clearInterval(interval);
  }, []);

  const fetchState = async () => {
    try {
      const res = await fetch("/api/state");
      if (!res.ok) throw new Error("Fehler beim Abrufen des Server-Zustands");
      const data = await res.json();
      setState(data);
      setIsLoading(false);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message);
      setIsLoading(false);
    }
  };

  // --------------------------------------------------------
  // SPOT MARKET FORM STATES
  // --------------------------------------------------------
  const [spotForm, setSpotForm] = useState({
    customerId: "",
    sourceId: "DU",
    targetId: "M",
    commodity: "Stahlcoils",
    volume: 1500,
    cargoType: "FLACH" as any,
    pricePerTon: 45
  });

  const [bookingPlanner, setBookingPlanner] = useState({
    customerId: "",
    sourceId: "DU",
    targetId: "M",
    commodity: "Flachglas",
    volume: 1200,
    cargoType: "FLACH" as any
  });

  const [planningResults, setPlanningResults] = useState<any[] | null>(null);
  const [isPlanning, setIsPlanning] = useState(false);

  // --------------------------------------------------------
  // DISRUPTION FORM STATES
  // --------------------------------------------------------
  const [disruptionForm, setDisruptionForm] = useState({
    type: "STRECKENSPERRUNG" as any,
    title: "Gleisbettabsenkung",
    description: "Akute Streckenbehinderung durch Unwetterschäden.",
    affectedEdgeId: "e_F_MA",
    delayImpact: 45,
    cost: 35000
  });

  // --------------------------------------------------------
  // SIMULATION STATES
  // --------------------------------------------------------
  const [simulationSettings, setSimulationSettings] = useState<ScenarioSettings>({
    id: "scen_custom",
    name: "Custom Szenario",
    description: "Benutzerkonfiguriert",
    energyPriceFactor: 1.2, // +20%
    demandFactor: 1.0,
    trackCapacityFactor: 0.85, // -15%
    locomotiveAvailabilityFactor: 1.0,
    crewAvailabilityFactor: 1.0,
    terminalThroughputFactor: 1.0,
    disruptionRate: "NORMAL"
  });

  const [simResult, setSimResult] = useState<SimulationResult | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [savedScenarios, setSavedScenarios] = useState<any[]>([
    {
      id: "baseline",
      name: "Standard-Betrieb",
      settings: { energyPriceFactor: 1.0, demandFactor: 1.0, trackCapacityFactor: 1.0, disruptionRate: "LOW" },
      result: { totalTrainsRun: 100, averageDelayMinutes: 4, onTimeRatePercent: 96, netMarginCents: 114500000, co2SavedVsTruckKg: 14500 }
    },
    {
      id: "energy_crisis",
      name: "Energiekrise +20% Strom",
      settings: { energyPriceFactor: 1.2, demandFactor: 0.95, trackCapacityFactor: 1.0, disruptionRate: "NORMAL" },
      result: { totalTrainsRun: 95, averageDelayMinutes: 8, onTimeRatePercent: 91, netMarginCents: 98120000, co2SavedVsTruckKg: 13700 }
    }
  ]);

  // --------------------------------------------------------
  // AI CHAT STATES
  // --------------------------------------------------------
  const [chatInput, setChatInput] = useState("");
  const [chatLogs, setChatLogs] = useState<{ query: string; response: string }[]>([
    {
      query: "Welche Züge sind heute wirtschaftlich gefährdet?",
      response: "Der Güterzug ORD-202 (Köln Eifeltor -> Leipzig) verzeichnet aktuell verringerte Margen von 14%, bedingt durch eine Verspätungsstrafe von 1.500,00 €. Der Sonderslot Duisburg -> München steht stabil bei 17,5% Marge."
    }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Ref for auto-scroll in demo log
  const demoLogEndRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    demoLogEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [state?.masterDemo?.log]);

  // --------------------------------------------------------
  // HANDLERS
  // --------------------------------------------------------
  const handleCheckRoutes = async () => {
    setIsPlanning(true);
    setPlanningResults(null);
    try {
      const res = await fetch("/api/order/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          startId: bookingPlanner.sourceId,
          endId: bookingPlanner.targetId,
          volumeTons: bookingPlanner.volume,
          commodity: bookingPlanner.commodity,
          cargoType: bookingPlanner.cargoType,
          customerId: bookingPlanner.customerId || (state?.customers[0]?.id || "")
        })
      });
      const data = await res.json();
      setPlanningResults(data.options);
    } catch (err) {
      console.error(err);
    } finally {
      setIsPlanning(false);
    }
  };

  const handleBookTrain = async (option: any) => {
    try {
      const res = await fetch("/api/order/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerId: bookingPlanner.customerId || (state?.customers[0]?.id || ""),
          commodity: bookingPlanner.commodity,
          cargoType: bookingPlanner.cargoType,
          volumeTons: bookingPlanner.volume,
          startId: bookingPlanner.sourceId,
          endId: bookingPlanner.targetId,
          routeOption: option.route,
          priceCents: option.financials.revenueCents
        })
      });
      if (res.ok) {
        alert(`Zug erfolgreich gebucht! Transport wird operativ disponiert.`);
        setPlanningResults(null);
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateDisruption = async () => {
    try {
      const res = await fetch("/api/disruption/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(disruptionForm)
      });
      if (res.ok) {
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleClearDisruption = async (id: string) => {
    try {
      const res = await fetch("/api/disruption/clear", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRunSimulation = async () => {
    setIsSimulating(true);
    setSimResult(null);
    try {
      const res = await fetch("/api/simulation/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: simulationSettings })
      });
      const data = await res.json();
      setSimResult(data.result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleSaveScenario = () => {
    if (!simResult) return;
    const newScen = {
      id: "scen_" + Date.now(),
      name: `Szenario ${savedScenarios.length + 1} (${simulationSettings.disruptionRate} Störung)`,
      settings: { ...simulationSettings },
      result: { ...simResult }
    };
    setSavedScenarios([...savedScenarios, newScen]);
    alert("Szenario gespeichert!");
  };

  const handleDemoStep = async () => {
    try {
      const res = await fetch("/api/master-demo/step", { method: "POST" });
      const data = await res.json();
      setState(prev => prev ? { ...prev, masterDemo: data.masterDemo } : null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDemoReset = async () => {
    try {
      const res = await fetch("/api/master-demo/reset", { method: "POST" });
      const data = await res.json();
      setState(prev => prev ? { ...prev, masterDemo: data.masterDemo } : null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSendAiQuery = async (preText?: string) => {
    const text = preText || chatInput;
    if (!text.trim()) return;

    setIsAiLoading(true);
    setChatLogs(prev => [...prev, { query: text, response: "Rhinoquant Intelligence analysiert Leitstelle..." }]);
    setChatInput("");

    try {
      const res = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text })
      });
      const data = await res.json();
      setChatLogs(prev => {
        const next = [...prev];
        next[next.length - 1]!.response = data.answer;
        return next;
      });
    } catch (err: any) {
      setChatLogs(prev => {
        const next = [...prev];
        next[next.length - 1]!.response = `Fehler: ${err.message}`;
        return next;
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  // --------------------------------------------------------
  // GERMANY MAP SVG PROJECTION (Section 48)
  // --------------------------------------------------------
  const mapWidth = 520;
  const mapHeight = 580;
  const projectCoord = (lat: number, lng: number) => {
    // Germany bounding box mapping
    const minLng = 3.5;
    const maxLng = 16.5;
    const minLat = 47.0;
    const maxLat = 55.5;

    const x = ((lng - minLng) / (maxLng - minLng)) * mapWidth;
    const y = (1 - (lat - minLat) / (maxLat - minLat)) * mapHeight;
    return { x, y };
  };

  // --------------------------------------------------------
  // UTILS
  // --------------------------------------------------------
  const formatEuro = (cents: number) => {
    return (cents / 100).toLocaleString("de-DE", { style: "currency", currency: "EUR" });
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-50 text-slate-800">
        <RefreshCw className="animate-spin text-slate-600 mb-4 h-10 w-10" />
        <h2 className="text-xl font-bold uppercase tracking-wider">Lade Rhinoquant OS</h2>
        <p className="text-sm text-slate-500 mt-2">Initialisiere Leitstand, Graph und Simulationen...</p>
      </div>
    );
  }

  // Aggregate metrics
  const activeTrainsCount = state?.trains.filter(t => t.status === "UNTERWEGS" || t.status === "GESTOERT").length || 0;
  const totalVolumeTons = state?.orders.reduce((sum, o) => sum + o.volumeTons, 0) || 0;
  const totalEbitdaCents = state?.trains.reduce((sum, t) => sum + t.financials.marginDeckungsbeitragCents, 0) || 0;
  const totalRevenueCents = state?.trains.reduce((sum, t) => sum + t.financials.revenueCents, 0) || 0;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans flex flex-col antialiased">
      {/* HEADER BAR */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-slate-900 text-white rounded">
            <TrainIcon className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-slate-900">RHINOQUANT</h1>
            <p className="text-xs uppercase tracking-widest text-slate-500 font-bold">SCHIENENGÜTERVERKEHR OS • V1.4</p>
          </div>
        </div>

        {/* Global Stats Bar */}
        <div className="flex flex-wrap items-center gap-6 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-semibold text-slate-700">Leitstelle Online</span>
          </div>
          <div className="h-4 w-px bg-slate-200"></div>
          <div>
            <span className="text-slate-500">Züge Unterwegs:</span>{" "}
            <span className="font-black text-slate-900">{activeTrainsCount}</span>
          </div>
          <div className="h-4 w-px bg-slate-200"></div>
          <div>
            <span className="text-slate-500">Marge (EBITDA):</span>{" "}
            <span className="font-black text-emerald-700">{formatEuro(totalEbitdaCents)}</span>
          </div>
          <div className="h-4 w-px bg-slate-200"></div>
          <div>
            <span className="text-slate-500 text-[10px] bg-slate-200 px-1.5 py-0.5 rounded font-black text-slate-600">SYNTHETISCHE BETRIEBSDATEN</span>
          </div>
        </div>
      </header>

      {/* CORE NAVIGATION */}
      <nav className="bg-slate-900 text-slate-300 px-6 py-2.5 flex flex-wrap gap-1 text-sm border-b border-slate-800">
        <button
          onClick={() => setActiveTab("overview")}
          className={`px-3 py-1.5 rounded font-medium transition-colors ${
            activeTab === "overview" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          ÜBERSICHT
        </button>
        <button
          onClick={() => setActiveTab("market")}
          className={`px-3 py-1.5 rounded font-medium transition-colors ${
            activeTab === "market" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          MARKT & AUFTRÄGE
        </button>
        <button
          onClick={() => setActiveTab("network")}
          className={`px-3 py-1.5 rounded font-medium transition-colors ${
            activeTab === "network" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          NETZ & TRASSEN
        </button>
        <button
          onClick={() => setActiveTab("fleet")}
          className={`px-3 py-1.5 rounded font-medium transition-colors ${
            activeTab === "fleet" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          FLOTTE & TERMINALS
        </button>
        <button
          onClick={() => setActiveTab("disruptions")}
          className={`px-3 py-1.5 rounded font-medium transition-colors ${
            activeTab === "disruptions" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          DISPOSITION & STÖRUNGEN
        </button>
        <button
          onClick={() => setActiveTab("sim")}
          className={`px-3 py-1.5 rounded font-medium transition-colors ${
            activeTab === "sim" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          DIGITALER ZWILLING SIM
        </button>
        <button
          onClick={() => setActiveTab("demo")}
          className={`px-3 py-1.5 rounded font-medium transition-colors flex items-center gap-1.5 ${
            activeTab === "demo" ? "bg-blue-900 text-white font-bold border-b-2 border-blue-400" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          <Play className="h-3.5 w-3.5 fill-current" />
          MASTER-DEMO (20 SCHRITTE)
        </button>
        <button
          onClick={() => setActiveTab("ai")}
          className={`px-3 py-1.5 rounded font-medium transition-colors flex items-center gap-1.5 ${
            activeTab === "ai" ? "bg-emerald-900 text-white font-bold border-b-2 border-emerald-400" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          <Bot className="h-3.5 w-3.5" />
          RHINOQUANT INTELLIGENCE
        </button>
        <button
          onClick={() => setActiveTab("audit")}
          className={`px-3 py-1.5 rounded font-medium transition-colors flex items-center gap-1.5 ${
            activeTab === "audit" ? "bg-slate-800 text-white font-bold border-b-2 border-white" : "hover:bg-slate-800 hover:text-white"
          }`}
        >
          <Database className="h-3.5 w-3.5" />
          SYSTEMAUDIT
        </button>
      </nav>

      {/* MAIN MAIN MAIN */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto">
        {state?.masterDemo && state.masterDemo.currentStep > 1 && state.masterDemo.currentStep <= 20 && (
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex justify-between items-center text-sm">
            <div className="flex items-center gap-3">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
              </span>
              <div>
                <span className="font-bold text-blue-900">MASTER-DEMO AKTIV:</span>{" "}
                <span className="text-blue-800">
                  Schritt {state.masterDemo.currentStep - 1} abgeschlossen: {state.masterDemo.steps[state.masterDemo.currentStep - 2]?.title}
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveTab("demo")}
              className="px-3 py-1.5 bg-blue-600 text-white font-bold rounded hover:bg-blue-700 text-xs transition-all uppercase"
            >
              Zum Demo-Prozess
            </button>
          </div>
        )}

        {/* TAB CONTENTS */}

        {/* 1. OVERVIEW / COMMAND CENTER */}
        {activeTab === "overview" && state && (
          <div className="space-y-6">
            {/* KPI GRID */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                <div className="flex justify-between items-start text-slate-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Transportleistung</span>
                  <Activity className="h-4 w-4 text-blue-600" />
                </div>
                <div className="mt-2 text-2xl font-black text-slate-900">
                  {totalVolumeTons.toLocaleString()} t
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-emerald-600 font-bold">
                  <TrendingUp className="h-3.5 w-3.5" />
                  <span>+12.4% vs Vorwoche</span>
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                <div className="flex justify-between items-start text-slate-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Nettoerlös (Gesamt)</span>
                  <DollarSign className="h-4 w-4 text-emerald-600" />
                </div>
                <div className="mt-2 text-2xl font-black text-slate-900">
                  {formatEuro(totalRevenueCents)}
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
                  <span>Soll-Erreichung: 94.2%</span>
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                <div className="flex justify-between items-start text-slate-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Betriebsmarge (EBITDA)</span>
                  <TrendingUp className="h-4 w-4 text-emerald-600" />
                </div>
                <div className="mt-2 text-2xl font-black text-slate-900 text-emerald-700 font-mono">
                  {formatEuro(totalEbitdaCents)}
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
                  <span>Ø Deckungsbeitrag: {totalRevenueCents > 0 ? Math.round((totalEbitdaCents / totalRevenueCents) * 100) : 0}%</span>
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                <div className="flex justify-between items-start text-slate-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Pünktlichkeitsrate</span>
                  <Clock className="h-4 w-4 text-amber-500" />
                </div>
                <div className="mt-2 text-2xl font-black text-slate-900">
                  84.5%
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-red-500 font-bold">
                  <span>-2.1% (durch Netz-Störungen)</span>
                </div>
              </div>
            </div>

            {/* LIVE OUTAGE ALERT */}
            {state.disruptions.length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex gap-3 items-center">
                <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0" />
                <div className="flex-1 text-sm text-red-800">
                  <span className="font-bold">AKTIVE INFRASTRUKTUR-STÖRUNG:</span>{" "}
                  {state.disruptions.map(d => `${d.title} (erwarteter Verzug: +${d.delayImpactMinutes} Min.)`).join(", ")}
                </div>
                <button
                  onClick={() => setActiveTab("disruptions")}
                  className="text-xs bg-red-600 text-white font-bold px-3 py-1.5 rounded hover:bg-red-700 transition"
                >
                  Disposition öffnen
                </button>
              </div>
            )}

            {/* MAIN OPERATIONAL TABLE */}
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
              <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
                <h3 className="font-black text-slate-900 uppercase tracking-tight text-sm flex items-center gap-2">
                  <TrainIcon className="h-4 w-4 text-slate-700" />
                  Aktiver Leitstand (Laufende Güterzüge)
                </h3>
                <span className="text-xs text-slate-500 font-bold">{state.trains.length} Züge registriert</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <th className="px-6 py-3">Zugnummer</th>
                      <th className="px-6 py-3">Relation</th>
                      <th className="px-6 py-3">Ladung / Gewicht</th>
                      <th className="px-6 py-3">Triebkraft / Wagen</th>
                      <th className="px-6 py-3">Soll-Ankunft / Plan</th>
                      <th className="px-6 py-3">Verzug</th>
                      <th className="px-6 py-3">Umsatz / Marge</th>
                      <th className="px-6 py-3 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {state.trains.map(train => {
                      const finalNode = state.stations.find(s => s.id === train.routePath[train.routePath.length - 1]);
                      const startNode = state.stations.find(s => s.id === train.routePath[0]);
                      const currentNode = state.stations.find(s => s.id === train.routePath[train.currentPositionIdx]);

                      return (
                        <tr key={train.id} className="hover:bg-slate-50 transition-all">
                          <td className="px-6 py-4 font-bold text-slate-900">
                            {train.trainNumber}
                          </td>
                          <td className="px-6 py-4">
                            <div className="font-medium text-slate-800">
                              {startNode?.name.split(" ")[0]} ➔ {finalNode?.name.split(" ")[0]}
                            </div>
                            <div className="text-slate-400 text-xs flex items-center gap-1">
                              <span>Aktuelle Position:</span>
                              <span className="font-bold text-slate-600">{currentNode?.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="font-semibold text-slate-800">{train.totalWeightTons.toLocaleString()} t</div>
                            <div className="text-slate-400 text-xs">Gesamtlänge: {train.totalLengthMeters}m</div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-slate-700">Loks: {train.locomotiveIds.join(", ")}</div>
                            <div className="text-slate-400 text-xs">Waggons: {train.wagonIds.length} Einheiten</div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-slate-700">{new Date(train.arrivalTimePlanned).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} Uhr</div>
                            <div className="text-slate-400 text-xs">Plan-Abfahrt: {new Date(train.departureTimePlanned).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} Uhr</div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`font-black ${train.delayMinutes > 0 ? "text-red-600" : "text-emerald-600"}`}>
                              {train.delayMinutes > 0 ? `+${train.delayMinutes} Min.` : "Pünktlich"}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-mono">
                            <div className="text-slate-800 font-bold">{formatEuro(train.financials.revenueCents)}</div>
                            <div className="text-emerald-700 text-xs font-semibold">DB: {train.financials.marginPercent}%</div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <span
                              className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                                train.status === "UNTERWEGS"
                                  ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                                  : train.status === "GESTOERT"
                                  ? "bg-red-50 text-red-700 border border-red-200"
                                  : "bg-blue-50 text-blue-700 border border-blue-200"
                              }`}
                            >
                              {train.status}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* 2. MARKET & CONTRACT PLANNING */}
        {activeTab === "market" && state && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* SPOT MARKET ORDER BOOK */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Layers className="h-4 w-4 text-slate-600" />
                  Spotmarkt-Orderbuch (Limit Book)
                </h3>

                {/* Sell orders (Asks) - top of book */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider">Verkaufsangebote (Asks)</span>
                  <div className="space-y-1 text-xs">
                    {state.spotSells.length === 0 ? (
                      <p className="text-slate-400 italic">Keine Verkaufsangebote im Buch.</p>
                    ) : (
                      state.spotSells.map(sell => (
                        <div key={sell.id} className="flex justify-between bg-red-50/50 p-2 rounded text-red-900">
                          <span>{sell.commodity} ({sell.volumeTons}t)</span>
                          <span className="font-bold">{(sell.pricePerTonCents / 100).toFixed(2)} €/t</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Match boundary indicator */}
                <div className="h-px bg-slate-200 flex items-center justify-center my-4">
                  <span className="bg-white px-2 text-[10px] text-slate-400 font-bold tracking-widest uppercase">Matching-Grenze</span>
                </div>

                {/* Buy orders (Bids) - bottom of book */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">Kaufnachfragen (Bids)</span>
                  <div className="space-y-1 text-xs">
                    {state.spotOrders.length === 0 ? (
                      <p className="text-slate-400 italic">Keine Kaufnachfragen gelistet.</p>
                    ) : (
                      state.spotOrders.map(buy => (
                        <div key={buy.id} className="flex justify-between bg-emerald-50/50 p-2 rounded text-emerald-900">
                          <span>{buy.commodity} ({buy.volumeTons}t)</span>
                          <span className="font-bold">{(buy.pricePerTonCents / 100).toFixed(2)} €/t</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Recent trades list */}
                <div className="pt-4 border-t border-slate-100">
                  <span className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-2">Letzte Abschlüsse</span>
                  <div className="space-y-1.5 max-h-[140px] overflow-y-auto text-xs font-mono">
                    {state.spotTrades.length === 0 ? (
                      <p className="text-slate-400 italic text-[11px]">Keine Transaktionen gelaufen.</p>
                    ) : (
                      state.spotTrades.map(t => (
                        <div key={t.id} className="flex justify-between text-slate-600 border-b border-slate-50 pb-1.5">
                          <span>{t.volumeTons}t {state.spotOrders.find(o => o.id === t.buyOrderId)?.commodity || "Fracht"}</span>
                          <span className="font-bold text-slate-800">{formatEuro(t.totalPriceCents)}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* BOOKING PLANNING & TRASSEN CALCULATOR */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm lg:col-span-2 space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Sliders className="h-4 w-4 text-slate-600" />
                  Interaktiver Trassenplaner & Preiskalkulator (MIP Engine)
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Auftraggeber Kunde</label>
                    <select
                      value={bookingPlanner.customerId}
                      onChange={e => setBookingPlanner({ ...bookingPlanner, customerId: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded font-medium text-slate-800"
                    >
                      <option value="">Wähle Vertragspartner...</option>
                      {state.customers.map(c => (
                        <option key={c.id} value={c.id}>{c.name} ({c.industry})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Absender Terminal (Start)</label>
                    <select
                      value={bookingPlanner.sourceId}
                      onChange={e => setBookingPlanner({ ...bookingPlanner, sourceId: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded font-medium text-slate-800"
                    >
                      {state.stations.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Empfänger Terminal (Ziel)</label>
                    <select
                      value={bookingPlanner.targetId}
                      onChange={e => setBookingPlanner({ ...bookingPlanner, targetId: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded font-medium text-slate-800"
                    >
                      {state.stations.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Warentyp / Ladung</label>
                    <input
                      type="text"
                      value={bookingPlanner.commodity}
                      onChange={e => setBookingPlanner({ ...bookingPlanner, commodity: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Masse Ladung (Tonnen)</label>
                    <input
                      type="number"
                      value={bookingPlanner.volume}
                      onChange={e => setBookingPlanner({ ...bookingPlanner, volume: parseInt(e.target.value) || 0 })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Gattung Güterwagen</label>
                    <select
                      value={bookingPlanner.cargoType}
                      onChange={e => setBookingPlanner({ ...bookingPlanner, cargoType: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    >
                      <option value="FLACH">FLACH (Sgns/Flachwagen)</option>
                      <option value="KESSEL">KESSEL (Zacns/Kesselwagen)</option>
                      <option value="SCHUETTGUT">SCHUETTGUT (Fals/Ganzzug)</option>
                      <option value="CONTAINER">CONTAINER (Sggrss/Intermodal)</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleCheckRoutes}
                    disabled={isPlanning}
                    className="w-full py-2 bg-slate-900 text-white font-bold rounded hover:bg-slate-800 transition uppercase text-xs tracking-wider flex items-center justify-center gap-2"
                  >
                    {isPlanning ? (
                      <>
                        <RefreshCw className="animate-spin h-3.5 w-3.5" />
                        Trassen-Auswahl wird optimiert...
                      </>
                    ) : (
                      "Trassenverfügbarkeit & Wirtschaftlichkeit prüfen"
                    )}
                  </button>
                </div>

                {/* ROUTE PLANNING OPTIONS (Section 7) */}
                {planningResults && (
                  <div className="pt-4 border-t border-slate-100 space-y-4">
                    <span className="text-xs font-black text-slate-500 uppercase tracking-wider block">Gefundene Trassenoptionen & Deckungsbeiträge</span>
                    <div className="space-y-3">
                      {planningResults.map((opt, i) => (
                        <div key={i} className="border border-slate-200 rounded-lg p-3.5 bg-slate-50/50 hover:bg-slate-50 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs">
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 bg-slate-900 text-white font-black rounded text-[10px] uppercase">Option {i+1}</span>
                              <span className="font-bold text-slate-800 text-sm">Score: {opt.route.score}/100</span>
                              <span className="text-slate-400">•</span>
                              <span className="text-slate-500 font-semibold">{opt.route.totalDistanceKm} km</span>
                              <span className="text-slate-400">•</span>
                              <span className="text-slate-500 font-semibold">Ø {Math.round(opt.route.totalDurationMinutes / 60)}h Fahrzeit</span>
                            </div>
                            <div className="text-slate-600 font-medium font-mono text-[11px]">
                              Route: {opt.route.path.join(" ➔ ")}
                            </div>
                            <div className="text-slate-400 text-[10px] flex gap-3 flex-wrap">
                              <span>Waggons: {opt.wagonCount}x {opt.route.electrifiedAllWay ? "Elektrifiziert" : "Diesel-Traktion"}</span>
                              <span>Masse: {opt.totalWeightTons}t</span>
                              <span>Energiebedarf: {opt.route.estimatedEnergyKwh} kWh</span>
                              <span>Pünktlichkeitserwartung: {opt.route.punctualityProbability * 100}%</span>
                            </div>
                          </div>

                          <div className="md:text-right border-l md:border-l-0 border-slate-200 pl-3 md:pl-0 space-y-1">
                            <div className="text-[10px] uppercase font-bold text-slate-400">Angebotspreis</div>
                            <div className="text-base font-black text-slate-900 font-mono">{formatEuro(opt.financials.revenueCents)}</div>
                            <div className="text-[10px] font-bold text-emerald-700">Marge: {opt.financials.marginPercent}% (DB: {formatEuro(opt.financials.marginDeckungsbeitragCents)})</div>
                            
                            <button
                              onClick={() => handleBookTrain(opt)}
                              className="mt-2 w-full px-4 py-1.5 bg-emerald-600 text-white font-black rounded hover:bg-emerald-700 uppercase tracking-widest text-[10px]"
                            >
                              Fahrt Buchen & Disponieren
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* CUSTOMER REGISTER CRM TABLE */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3 mb-4">
                <Users className="h-4 w-4 text-slate-600" />
                Kundenregister & Vertragsvolumina (CRM-Wirtschaftlichkeit)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {state.customers.map(c => {
                  const custOrders = state.orders.filter(o => o.customerId === c.id);
                  return (
                    <div key={c.id} className="border border-slate-100 bg-slate-50/50 p-4 rounded-xl flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-black bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded uppercase">{c.industry}</span>
                          <span className="text-[11px] font-bold text-emerald-600">Bonität: {c.reliabilityRating * 100}%</span>
                        </div>
                        <h4 className="font-bold text-slate-900 mt-2 text-sm">{c.name}</h4>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center text-xs">
                        <span className="text-slate-400">Bestellvolumen:</span>
                        <span className="font-black text-slate-800">{c.lifetimeVolumeTons.toLocaleString()} t</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 3. NETWORK MAP & TRAIN GRAPH */}
        {activeTab === "network" && state && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              
              {/* INTERACTIVE GERMANY MAP LAYER */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm lg:col-span-3 space-y-4">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2">
                    <Map className="h-4 w-4 text-slate-600" />
                    Leitstellen-Netzwerkkarte (Deutschland & Korridore)
                  </h3>
                  <span className="text-xs text-slate-500 font-semibold">Tippen Sie auf Strecken, um Störungen zu simulieren</span>
                </div>

                <div className="relative border border-slate-100 rounded-xl bg-slate-50 flex items-center justify-center p-2 overflow-hidden select-none">
                  <svg width={mapWidth} height={mapHeight} className="max-w-full">
                    {/* Render tracks (edges) */}
                    {state.edges.map(edge => {
                      const s = state.stations.find(st => st.id === edge.source);
                      const t = state.stations.find(st => st.id === edge.target);
                      if (!s || !t) return null;

                      const sProj = projectCoord(s.lat, s.lng);
                      const tProj = projectCoord(t.lat, t.lng);

                      return (
                        <g key={edge.id} className="group cursor-pointer" onClick={() => {
                          setDisruptionForm({
                            ...disruptionForm,
                            affectedEdgeId: edge.id,
                            title: `Gleisabschnittsfehler ${s.id}-${t.id}`,
                            description: `Technische Signalblock-Blockade zwischen ${s.name} und ${t.name}.`
                          });
                        }}>
                          <line
                            x1={sProj.x}
                            y1={sProj.y}
                            x2={tProj.x}
                            y2={tProj.y}
                            stroke={edge.isDisrupted ? "#EF4444" : edge.hasConstruction ? "#F59E0B" : "#CBD5E1"}
                            strokeWidth={edge.isDisrupted ? 3 : 2}
                            strokeDasharray={edge.electrified ? "none" : "3,3"}
                          />
                          <line
                            x1={sProj.x}
                            y1={sProj.y}
                            x2={tProj.x}
                            y2={tProj.y}
                            stroke="transparent"
                            strokeWidth={10}
                            className="hover:stroke-slate-900/10 transition-colors"
                          />
                          <title>{`${edge.id}: ${s.name} ➔ ${t.name} (${edge.lengthKm} km). Steigung: ${edge.gradientPercent}%. ${edge.isDisrupted ? 'STOERUNG!' : 'Regelbetrieb'}`}</title>
                        </g>
                      );
                    })}

                    {/* Render stations (nodes) */}
                    {state.stations.map(station => {
                      const proj = projectCoord(station.lat, station.lng);
                      const isPort = station.type === "HAFEN";
                      const isTerminal = station.type === "TERMINAL";

                      return (
                        <g key={station.id} className="group">
                          <circle
                            cx={proj.x}
                            cy={proj.y}
                            r={isPort ? 7 : isTerminal ? 5.5 : 4}
                            fill={isPort ? "#059669" : isTerminal ? "#2563EB" : "#1E293B"}
                            stroke="#FFFFFF"
                            strokeWidth={1.5}
                          />
                          <text
                            x={proj.x + 8}
                            y={proj.y + 4}
                            fontSize="8"
                            fontWeight="bold"
                            fill="#475569"
                            className="pointer-events-none drop-shadow"
                          >
                            {station.id}
                          </text>
                          <title>{`${station.name} (${station.type})`}</title>
                        </g>
                      );
                    })}

                    {/* Pulsing trains running online */}
                    {state.trains.filter(t => t.status === "UNTERWEGS" || t.status === "GESTOERT").map(train => {
                      const startNode = state.stations.find(s => s.id === train.routePath[train.currentPositionIdx]);
                      const nextNodeId = train.routePath[train.currentPositionIdx + 1];
                      const nextNode = state.stations.find(s => s.id === nextNodeId);

                      if (!startNode || !nextNode) return null;

                      const startProj = projectCoord(startNode.lat, startNode.lng);
                      const nextProj = projectCoord(nextNode.lat, nextNode.lng);

                      // Interpolate train coordinate based on progress
                      const progress = train.progressBetweenNodes || 0.5;
                      const tx = startProj.x + (nextProj.x - startProj.x) * progress;
                      const ty = startProj.y + (nextProj.y - startProj.y) * progress;

                      return (
                        <g key={train.id} className="cursor-pointer">
                          <circle
                            cx={tx}
                            cy={ty}
                            r={6.5}
                            fill={train.status === "GESTOERT" ? "#EF4444" : "#10B981"}
                            className="animate-pulse"
                            stroke="#FFFFFF"
                            strokeWidth={1.5}
                          />
                          <circle
                            cx={tx}
                            cy={ty}
                            r={12}
                            fill="none"
                            stroke={train.status === "GESTOERT" ? "#EF4444" : "#10B981"}
                            strokeWidth={1}
                            className="animate-ping opacity-40"
                          />
                          <title>{`Zug: ${train.trainNumber}\n${train.totalWeightTons}t ${train.status}\nVerspätung: +${train.delayMinutes} Min`}</title>
                        </g>
                      );
                    })}
                  </svg>
                </div>
              </div>

              {/* TRAIN GRAPH (WEG-ZEIT-DIAGRAMM - Section 49) */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm lg:col-span-2 space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Clock className="h-4 w-4 text-slate-600" />
                  Weg-Zeit-Linienbild (Train Graph)
                </h3>
                
                <p className="text-xs text-slate-400">
                  Visualisiert Zugläufe über Zeit (X-Achse: 06:00 - 24:00 Uhr) und Betriebsstellen (Y-Achse). Knicke indizieren Wartezeiten oder Konflikte.
                </p>

                <div className="relative border border-slate-100 rounded-xl bg-slate-900 p-4 h-[350px] flex items-center justify-center font-mono text-[10px] text-slate-400 overflow-hidden select-none">
                  {/* Grid Renderer */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-between">
                    <div className="flex justify-between border-b border-slate-800 pb-1 text-slate-500 font-bold">
                      <span>STATION</span>
                      <span>06:00</span>
                      <span>12:00</span>
                      <span>18:00</span>
                      <span>24:00</span>
                    </div>

                    {/* Main stations on vertical axis */}
                    {["Hamburg (HH)", "Duisburg (DU)", "Frankfurt (F)", "Stuttgart (S)", "München (M)"].map((s, idx) => (
                      <div key={idx} className="flex justify-between border-b border-slate-800/40 py-4">
                        <span className="text-slate-400 font-bold">{s}</span>
                        <div className="h-px bg-slate-800 flex-1 mx-4 border-dashed self-center"></div>
                      </div>
                    ))}
                  </div>

                  {/* Render simulated diagonal train paths */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none p-6">
                    {/* Train path lines */}
                    {/* Train 1 Duisburg -> München */}
                    <line x1="120" y1="110" x2="420" y2="280" stroke="#10B981" strokeWidth={2.5} />
                    <circle cx="280" cy="200" r="4" fill="#10B981" />
                    <text x="130" y="105" fill="#10B981" fontSize={8} fontWeight="bold">DGS 48152</text>

                    {/* Train 2 Köln -> Leipzig */}
                    <line x1="80" y1="110" x2="350" y2="50" stroke="#3B82F6" strokeWidth={2} />
                    <text x="90" y="125" fill="#3B82F6" fontSize={8}>DGS 55301</text>

                    {/* Disrupted bent train path */}
                    <path
                      d="M 120 110 L 220 180 L 300 180 L 450 280"
                      fill="none"
                      stroke="#EF4444"
                      strokeWidth={2}
                      strokeDasharray="4,4"
                    />
                    <text x="230" y="170" fill="#EF4444" fontSize={8} fontWeight="bold">DGS 48152 (Reroute)</text>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 4. FLEET & TERMINALS STATUS */}
        {activeTab === "fleet" && state && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* LOCOMOTIVE ASSET MANAGEMENT */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Activity className="h-4 w-4 text-slate-600" />
                  Triebfahrzeug-Bestand (100 Elektro-/Diesellokomotiven)
                </h3>
                <div className="max-h-[350px] overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                        <th className="p-2">Lok-Kennung</th>
                        <th className="p-2">Baureihe</th>
                        <th className="p-2">Leistung</th>
                        <th className="p-2">Betriebsstunden</th>
                        <th className="p-2">Standort</th>
                        <th className="p-2 text-right">Zustand</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {state.locomotives.slice(0, 15).map(l => (
                        <tr key={l.id} className="hover:bg-slate-50">
                          <td className="p-2 font-bold text-slate-800">{l.name}</td>
                          <td className="p-2">{l.series}</td>
                          <td className="p-2 font-mono">{l.powerKW} kW</td>
                          <td className="p-2 font-mono">{l.operatingHours} h</td>
                          <td className="p-2 font-bold">{l.locationNodeId}</td>
                          <td className="p-2 text-right">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                              l.maintenanceStatus === "OK" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
                            }`}>
                              {l.maintenanceStatus}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* WAGON POOL DEPOT CONTROL */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Truck className="h-4 w-4 text-slate-600" />
                  Güterwagen-Roster & Leerwagenminimierung (150 Wagen)
                </h3>
                <div className="max-h-[350px] overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                        <th className="p-2">Wagen-ID</th>
                        <th className="p-2">Gattungstyp</th>
                        <th className="p-2">Eigengewicht / payload</th>
                        <th className="p-2">Nächste Wartung</th>
                        <th className="p-2">Lageort</th>
                        <th className="p-2 text-right">Betriebsstatus</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {state.wagons.slice(0, 15).map(w => (
                        <tr key={w.id} className="hover:bg-slate-50">
                          <td className="p-2 font-bold text-slate-800">{w.id}</td>
                          <td className="p-2 font-semibold text-slate-600">{w.type}</td>
                          <td className="p-2">{w.tareWeightTons}t / {w.maxPayloadTons}t</td>
                          <td className="p-2 font-mono">In {w.nextMaintenanceKm - w.totalKilometers} km</td>
                          <td className="p-2 font-bold">{w.locationNodeId}</td>
                          <td className="p-2 text-right">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                              w.status === "VERFUEGBAR"
                                ? "bg-emerald-50 text-emerald-700"
                                : w.status === "RESERVIERT"
                                ? "bg-blue-50 text-blue-700"
                                : "bg-slate-100 text-slate-600"
                            }`}>
                              {w.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* CREW AND TERMINALS ROW */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* CREW SHIFTS WORKBOOK */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Users className="h-4 w-4 text-slate-600" />
                  Dienstplanung & Fahrpersonal (Triebfahrzeugführer)
                </h3>
                <div className="max-h-[250px] overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                        <th className="p-2">Mitarbeiter</th>
                        <th className="p-2">Funktion</th>
                        <th className="p-2">Arbeitszeit / Woche</th>
                        <th className="p-2">Lageort</th>
                        <th className="p-2 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {state.crew.slice(0, 8).map(c => (
                        <tr key={c.id} className="hover:bg-slate-50">
                          <td className="p-2 font-bold text-slate-800">{c.name}</td>
                          <td className="p-2 font-medium text-slate-600">{c.role}</td>
                          <td className="p-2 font-mono">{Math.round(c.weeklyWorkingMinutes / 60)}h / {Math.round(c.maxWorkingMinutesPerWeek / 60)}h</td>
                          <td className="p-2 font-bold">{c.currentLocationId}</td>
                          <td className="p-2 text-right">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                              c.status === "BEREIT" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"
                            }`}>
                              {c.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* TERMINALS CAPACITIES TRACKS */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Anchor className="h-4 w-4 text-slate-600" />
                  Umschlagterminals & Containergleise
                </h3>
                <div className="max-h-[250px] overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                        <th className="p-2">Terminal-Gleis</th>
                        <th className="p-2">Krane / Reachstacker</th>
                        <th className="p-2">Yard Bestand</th>
                        <th className="p-2">Soll-Kapazität / Tag</th>
                        <th className="p-2 text-right">Umschlaggebühr</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {state.terminals.slice(0, 8).map(t => (
                        <tr key={t.id} className="hover:bg-slate-50">
                          <td className="p-2 font-bold text-slate-800">{t.name}</td>
                          <td className="p-2">{t.gantryCranesCount} Krane / {t.reachStackersCount} Stackers</td>
                          <td className="p-2 font-mono">{t.currentTEUStored} TEU</td>
                          <td className="p-2 font-mono">{t.dailyCapacityTEU} TEU</td>
                          <td className="p-2 text-right font-bold text-slate-800">{formatEuro(t.handlingCostPerTEUCents)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5. DISRUPTIONS & OPERATIVE DISPOSITION */}
        {activeTab === "disruptions" && state && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* DISRUPTIONS LIST */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 lg:col-span-2">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <ShieldAlert className="h-4 w-4 text-slate-600" />
                  Aktive Netzstörungen & Verspätungen (Dispatcher Leitstand)
                </h3>
                <div className="space-y-3">
                  {state.disruptions.length === 0 ? (
                    <div className="p-8 text-center bg-slate-50 rounded-xl text-slate-400 italic">
                      Perfekter Regelbetrieb. Keine signalisierten Störungen im deutschen Schienennetz.
                    </div>
                  ) : (
                    state.disruptions.map(d => (
                      <div key={d.id} className="border border-red-200 bg-red-50/50 p-4 rounded-xl flex justify-between items-start text-xs">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="bg-red-600 text-white font-black px-1.5 py-0.5 rounded text-[9px] uppercase">{d.type}</span>
                            <span className="font-bold text-red-950 text-sm">{d.title}</span>
                          </div>
                          <p className="text-red-900 font-medium">{d.description}</p>
                          <div className="text-[10px] text-red-700 font-semibold flex gap-4">
                            <span>Sperrsegment: {d.affectedEdgeId || "Allgemein"}</span>
                            <span>Soll-Verzug: +{d.delayImpactMinutes} Min.</span>
                            <span>Wirtschaftlicher Schaden: {formatEuro(d.financialCostCents)}</span>
                          </div>
                        </div>
                        <button
                          onClick={() => handleClearDisruption(d.id)}
                          className="px-3 py-1.5 bg-red-600 text-white font-black rounded hover:bg-red-700 uppercase tracking-widest text-[10px]"
                        >
                          Entstörung erteilen
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* SIMULATE DISRUPTION CONTROL */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Plus className="h-4 w-4 text-slate-600" />
                  Infrastrukturstörung simulieren
                </h3>
                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Störungsursache</label>
                    <select
                      value={disruptionForm.type}
                      onChange={e => setDisruptionForm({ ...disruptionForm, type: e.target.value as any })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    >
                      <option value="STRECKENSPERRUNG">Streckensperrung (Unwetterschaden)</option>
                      <option value="STELLWERKSSTOERUNG">Stellwerksstörung (Signalboxausfall)</option>
                      <option value="LOKSCHADEN">Triebfahrzeugschaden (BR 193)</option>
                      <option value="WAGENSCHADEN">Flachwagendefekt (Heißläufer)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Störungstitel</label>
                    <input
                      type="text"
                      value={disruptionForm.title}
                      onChange={e => setDisruptionForm({ ...disruptionForm, title: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Gleissegment (Kanten-ID)</label>
                    <select
                      value={disruptionForm.affectedEdgeId}
                      onChange={e => setDisruptionForm({ ...disruptionForm, affectedEdgeId: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    >
                      {state.edges.map(e => (
                        <option key={e.id} value={e.id}>{e.id} ({e.source} ➔ {e.target})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Erwarteter Zugverzug (Minuten)</label>
                    <input
                      type="number"
                      value={disruptionForm.delayImpact}
                      onChange={e => setDisruptionForm({ ...disruptionForm, delayImpact: parseInt(e.target.value) || 0 })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    />
                  </div>
                  <button
                    onClick={handleCreateDisruption}
                    className="w-full py-2 bg-red-600 text-white font-bold rounded hover:bg-red-700 transition uppercase text-xs tracking-wider"
                  >
                    Störung auf Gleis einspeisen
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 6. TWIN MONTE-CARLO SIMULATOR */}
        {activeTab === "sim" && state && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* CONFIGURE ENVIRONMENT MULTIPLIERS */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Settings className="h-4 w-4 text-slate-600" />
                  Konfiguration der Szenarioparameter
                </h3>
                
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="flex justify-between text-slate-500 font-bold mb-1 uppercase">
                      <span>Energiepreis-Faktor</span>
                      <span className="text-slate-800 font-mono">{(simulationSettings.energyPriceFactor * 100).toFixed(0)}%</span>
                    </label>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.05"
                      value={simulationSettings.energyPriceFactor}
                      onChange={e => setSimulationSettings({ ...simulationSettings, energyPriceFactor: parseFloat(e.target.value) })}
                      className="w-full accent-slate-900"
                    />
                  </div>

                  <div>
                    <label className="flex justify-between text-slate-500 font-bold mb-1 uppercase">
                      <span>Infrastrukturkapazität</span>
                      <span className="text-slate-800 font-mono">{(simulationSettings.trackCapacityFactor * 100).toFixed(0)}%</span>
                    </label>
                    <input
                      type="range"
                      min="0.5"
                      max="1.2"
                      step="0.05"
                      value={simulationSettings.trackCapacityFactor}
                      onChange={e => setSimulationSettings({ ...simulationSettings, trackCapacityFactor: parseFloat(e.target.value) })}
                      className="w-full accent-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-500 font-bold mb-1 uppercase">Störungsquote (Netzweit)</label>
                    <select
                      value={simulationSettings.disruptionRate}
                      onChange={e => setSimulationSettings({ ...simulationSettings, disruptionRate: e.target.value as any })}
                      className="w-full bg-slate-50 border border-slate-200 p-2 rounded text-slate-800"
                    >
                      <option value="NONE">Keine Störungen (0%)</option>
                      <option value="LOW">Niedrige Störungsfrequenz</option>
                      <option value="NORMAL">Standardbetrieb (Deutsches Netz)</option>
                      <option value="HIGH">Extremes Unwetter / Warnstreik</option>
                    </select>
                  </div>

                  <button
                    onClick={handleRunSimulation}
                    disabled={isSimulating}
                    className="w-full py-2.5 bg-slate-900 text-white font-bold rounded hover:bg-slate-800 transition uppercase text-xs tracking-wider flex items-center justify-center gap-2"
                  >
                    {isSimulating ? (
                      <>
                        <RefreshCw className="animate-spin h-3.5 w-3.5" />
                        Monte-Carlo läuft (100 Züge)...
                      </>
                    ) : (
                      "Monte-Carlo Simulation starten"
                    )}
                  </button>
                </div>
              </div>

              {/* SIMULATION RESULTS */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm lg:col-span-2 space-y-4">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-slate-600" />
                    Wirtschaftliches & Ökologisches Audit-Ergebnis
                  </h3>
                  {simResult && (
                    <button
                      onClick={handleSaveScenario}
                      className="px-2.5 py-1.5 bg-emerald-600 text-white font-black rounded hover:bg-emerald-700 uppercase tracking-widest text-[9px] transition-all"
                    >
                      Szenario sichern
                    </button>
                  )}
                </div>

                {!simResult ? (
                  <div className="h-[250px] flex items-center justify-center border border-slate-100 bg-slate-50 rounded-xl text-slate-400 italic text-xs">
                    Konfigurieren Sie Parameter und starten Sie die Monte-Carlo Analyse.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                    <div className="space-y-4">
                      <div className="bg-slate-50 p-4 rounded-xl space-y-2 border border-slate-100">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Betriebswirtschaft</span>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Umsatz (Sim):</span>
                          <span className="font-bold text-slate-900 font-mono">{formatEuro(simResult.totalRevenueCents)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Betriebskosten:</span>
                          <span className="font-bold text-red-600 font-mono">{formatEuro(simResult.totalCostCents)}</span>
                        </div>
                        <div className="flex justify-between border-t border-slate-200 pt-2 font-black text-sm">
                          <span className="text-slate-800">Marge (EBITDA):</span>
                          <span className="text-emerald-700 font-mono">{formatEuro(simResult.ebitdaCents)}</span>
                        </div>
                      </div>

                      <div className="bg-emerald-50/50 p-4 rounded-xl space-y-1.5 border border-emerald-100">
                        <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Klimabilanz (CO₂-Engine)</span>
                        <div className="flex justify-between">
                          <span className="text-emerald-800 font-medium">CO₂ emittiert:</span>
                          <span className="font-bold text-slate-950 font-mono">{(simResult.co2EmittedKg / 1000).toFixed(1)} t</span>
                        </div>
                        <div className="flex justify-between font-bold text-emerald-800">
                          <span>Eingespart vs. LKW-Strasse:</span>
                          <span className="font-black font-mono">➔ {(simResult.co2SavedVsTruckKg / 1000).toFixed(1)} t CO₂</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="bg-slate-50 p-4 rounded-xl space-y-2 border border-slate-100">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pünktlichkeit & Auslastung</span>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Ø Fahrplanverzug:</span>
                          <span className="font-bold text-slate-800">{simResult.averageDelayMinutes} Min.</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Soll-Pünktlichkeit:</span>
                          <span className="font-bold text-emerald-600">{simResult.onTimeRatePercent}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Gleiskapazität genutzt:</span>
                          <span className="font-bold text-slate-800">{simResult.trackCapacityUtilization}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Leerwagenkilometer:</span>
                          <span className="font-bold text-slate-800">{simResult.emptyWagonKilometers.toLocaleString()} km</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* SCENARIOS SIDE BY SIDE COMPARISON */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                <Sliders className="h-4 w-4 text-slate-600" />
                Szenarienvergleich (Side-by-Side KPIs)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                {savedScenarios.map(sc => (
                  <div key={sc.id} className="border border-slate-200 bg-slate-50/50 p-4 rounded-xl space-y-3">
                    <h4 className="font-black text-sm text-slate-900 border-b border-slate-200 pb-1.5">{sc.name}</h4>
                    <div className="space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Musterzüge gefahren:</span>
                        <span className="font-semibold text-slate-800">{sc.result.totalTrainsRun}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Ø Verspätung:</span>
                        <span className="font-semibold text-red-600">{sc.result.averageDelayMinutes} Min.</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Pünktlichkeit:</span>
                        <span className="font-semibold text-emerald-600">{sc.result.onTimeRatePercent}%</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-200 pt-1.5 font-bold">
                        <span className="text-slate-700">Marge EBITDA:</span>
                        <span className="font-mono">{formatEuro(sc.result.netMarginCents)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 7. MASTER-DEMO (20 STEPS - Section 54) */}
        {activeTab === "demo" && state && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* STEPS TIMELINE LIST */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 lg:col-span-2">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2">
                    <Play className="h-4 w-4 text-blue-600 fill-current" />
                    Operative & Ökonomische Prozesskette (Section 54)
                  </h3>
                  <button
                    onClick={handleDemoReset}
                    className="px-3 py-1 bg-slate-200 hover:bg-slate-300 rounded text-slate-700 font-bold uppercase text-[10px]"
                  >
                    Reset Demo
                  </button>
                </div>

                <div className="space-y-2 max-h-[480px] overflow-y-auto pr-2">
                  {state.masterDemo.steps.map(step => (
                    <div
                      key={step.number}
                      className={`border p-3 rounded-lg text-xs transition-all flex items-start gap-3 ${
                        step.completed
                          ? "border-emerald-200 bg-emerald-50/30 text-slate-800"
                          : state.masterDemo.currentStep === step.number
                          ? "border-blue-300 bg-blue-50/50 text-slate-950 font-semibold ring-2 ring-blue-100"
                          : "border-slate-100 bg-white text-slate-400"
                      }`}
                    >
                      <div className={`flex-shrink-0 flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-black ${
                        step.completed
                          ? "bg-emerald-600 text-white"
                          : state.masterDemo.currentStep === step.number
                          ? "bg-blue-600 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {step.number}
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex justify-between items-start">
                          <span className="font-bold">{step.title}</span>
                          {step.completed && <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />}
                        </div>
                        <p className="text-[11px] leading-relaxed">{step.description}</p>
                        
                        {/* Dynamic Step Data rendered on completion */}
                        {step.completed && step.data && (
                          <div className="mt-2 bg-slate-900 text-slate-300 font-mono p-2.5 rounded-lg text-[10px] space-y-1">
                            {Object.entries(step.data).map(([k, v]: any) => (
                              <div key={k} className="flex justify-between">
                                <span className="text-slate-500 uppercase">{k}:</span>
                                <span className="text-slate-200 font-bold">
                                  {typeof v === "number" && k.endsWith("Cents") ? formatEuro(v) : JSON.stringify(v)}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* DEMO CONTROL PANEL */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5 flex flex-col justify-between">
                <div>
                  <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                    <Activity className="h-4 w-4 text-slate-600" />
                    Master-Demo Steuerung
                  </h3>
                  
                  <div className="mt-4 p-4 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono h-[320px] overflow-y-auto space-y-2 flex flex-col justify-end">
                    <div className="text-slate-500 border-b border-slate-800 pb-1 mb-2 font-bold uppercase tracking-wider text-[9px]">DEMO AKTIVITÄTSLOGBUCH</div>
                    <div className="space-y-1.5 flex-1 overflow-y-auto">
                      {state.masterDemo.log.map((log, i) => (
                        <div key={i} className="text-[11px] border-b border-slate-800/20 pb-1 text-slate-300">
                          ➔ {log}
                        </div>
                      ))}
                      <div ref={demoLogEndRef} />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  {state.masterDemo.currentStep <= 20 ? (
                    <button
                      onClick={handleDemoStep}
                      className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-xl uppercase tracking-wider text-xs transition flex items-center justify-center gap-2 animate-pulse"
                    >
                      <Play className="h-4 w-4 fill-current" />
                      Schritt {state.masterDemo.currentStep} ausführen
                    </button>
                  ) : (
                    <div className="space-y-2">
                      <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-bold text-center">
                        Demo-Prozess vollständig abgeschlossen!
                      </div>
                      <button
                        onClick={handleDemoReset}
                        className="w-full py-2 bg-slate-900 text-white font-bold rounded hover:bg-slate-800 uppercase text-xs"
                      >
                        Erneut starten (Reset)
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 8. AI INTELLIGENCE ADVISOR (Section 29) */}
        {activeTab === "ai" && state && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* CHAT WINDOW */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm lg:col-span-2 flex flex-col h-[520px]">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3 mb-4">
                  <Bot className="h-5 w-5 text-emerald-600" />
                  Rhinoquant Intelligence (Gemini AI Leitstand-Assistent)
                </h3>

                {/* Dialog thread */}
                <div className="flex-1 overflow-y-auto space-y-4 pr-2 text-xs">
                  {chatLogs.map((log, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex items-center gap-2 font-bold text-slate-800">
                        <span className="bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">Nutzer</span>
                        <span>{log.query}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-200/60 p-3.5 rounded-xl text-slate-900 leading-relaxed font-sans whitespace-pre-wrap">
                        {log.response === "Rhinoquant Intelligence analysiert Leitstelle..." ? (
                          <div className="flex items-center gap-2 text-slate-500">
                            <RefreshCw className="animate-spin h-3.5 w-3.5 text-slate-500" />
                            <span>Analysiere live Betriebsdaten von BR 193 & Streckenkonflikten...</span>
                          </div>
                        ) : (
                          log.response
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Query inputs */}
                <div className="pt-4 border-t border-slate-100 flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && handleSendAiQuery()}
                    placeholder="Fragen Sie Rhinoquant Intelligence nach Kosten, Margen, Wagenbeständen..."
                    className="flex-1 bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-400"
                  />
                  <button
                    onClick={() => handleSendAiQuery()}
                    disabled={isAiLoading}
                    className="px-5 py-2.5 bg-emerald-600 text-white font-black rounded-xl hover:bg-emerald-700 transition text-xs uppercase"
                  >
                    Senden
                  </button>
                </div>
              </div>

              {/* RECOMMENDED QUESTIONS */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                  <Info className="h-4 w-4 text-slate-600" />
                  Analytische Fragestellungen (Vorschläge)
                </h3>
                <p className="text-xs text-slate-400">
                  Wählen Sie vordefinierte Fragestellungen zur wirtschaftlich-operativen Optimierung:
                </p>

                <div className="space-y-2 text-xs">
                  <button
                    onClick={() => handleSendAiQuery("Welche Relationen haben die niedrigste Marge?")}
                    className="w-full text-left p-3 border border-slate-200 hover:border-slate-300 rounded-lg bg-slate-50/50 font-semibold text-slate-700 transition"
                  >
                    Welche Relationen haben die niedrigste Marge?
                  </button>
                  <button
                    onClick={() => handleSendAiQuery("Wo fehlen Wagen im Netz und wie minimieren wir Leerfahrten?")}
                    className="w-full text-left p-3 border border-slate-200 hover:border-slate-300 rounded-lg bg-slate-50/50 font-semibold text-slate-700 transition"
                  >
                    Wo fehlen Wagen im Netz und wie minimieren wir Leerfahrten?
                  </button>
                  <button
                    onClick={() => handleSendAiQuery("Was kostet uns eine Sperrung der Strecke Frankfurt - Mannheim?")}
                    className="w-full text-left p-3 border border-slate-200 hover:border-slate-300 rounded-lg bg-slate-50/50 font-semibold text-slate-700 transition"
                  >
                    Was kostet uns eine Sperrung der Strecke Frankfurt - Mannheim?
                  </button>
                  <button
                    onClick={() => handleSendAiQuery("Wie verändert sich das EBITDA bei +15% Stromkosten?")}
                    className="w-full text-left p-3 border border-slate-200 hover:border-slate-300 rounded-lg bg-slate-50/50 font-semibold text-slate-700 transition"
                  >
                    Wie verändert sich das EBITDA bei +15% Stromkosten?
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 9. SYSTEM AUDIT TRAIL */}
        {activeTab === "audit" && state && (
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="font-black text-sm uppercase tracking-tight text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
              <Database className="h-4 w-4 text-slate-600" />
              Revisionssichere Betriebsprotokolle (Compliance Audit Log)
            </h3>
            <p className="text-xs text-slate-400">
              Historischer Nachweis aller Dispositionen, Preisänderungen und Statusanpassungen zur Gewährleistung vollständiger Auditierbarkeit gemäß Section 40.
            </p>

            <div className="overflow-x-auto text-xs font-mono">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <th className="p-3">Zeitstempel</th>
                    <th className="p-3">Akteur / System</th>
                    <th className="p-3">Aktion</th>
                    <th className="p-3">Vorheriger Zustand</th>
                    <th className="p-3">Neuer Zustand</th>
                    <th className="p-3">Grund</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {state.auditLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="p-3 text-slate-500">
                        {new Date(log.timestamp).toLocaleString("de-DE")}
                      </td>
                      <td className="p-3 font-bold text-slate-700">{log.actor}</td>
                      <td className="p-3 font-semibold text-slate-800">{log.action}</td>
                      <td className="p-3 text-slate-400">{log.beforeState}</td>
                      <td className="p-3 text-emerald-700 font-bold">{log.afterState}</td>
                      <td className="p-3 text-slate-600 font-sans">{log.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 px-6 py-4 text-center text-xs text-slate-400 mt-auto">
        <div>RHINOQUANT SCHIENENGÜTERVERKEHR OS • Professionelles Softwaresystem für den deutschen Schienengüterverkehr</div>
        <div className="mt-1 font-semibold text-slate-500 uppercase tracking-wider text-[10px]">
          Fiktives & synthetisches Simulationssystem • Keine tatsächliche Verbindung zu realen Bahngesellschaften
        </div>
      </footer>
    </div>
  );
}
