package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEntity
import com.example.ui.TravelViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.tickets.collectAsState()
    val isSubscribed by viewModel.isSubscribedToSYPlus.collectAsState()

    var activeTab by remember { mutableStateOf("Wallet") } // Wallet, Buy Passes
    var activeQrTicket by remember { mutableStateOf<TicketEntity?>(null) }

    val formatter = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Unified Ticket Wallet",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B365D)
            )
            Text(
                text = "Smart Fare Engine & Capping Live",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // 1. Smart Fare Engine Capping Card (Only in Wallet tab)
        if (activeTab == "Wallet") {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Savings, contentDescription = null, tint = Color(0xFF2E7D32))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Smart Fare Engine (Auto-Cap)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B365D)
                                )
                            }

                            Text(
                                text = "Saved £14.80",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Text(
                            text = "You tap, we calculate. At midnight, we charge the absolute cheapest ticket combo for your day's trips.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        // Daily Cap Progress
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Daily Cap Limit (£5.40 max)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Text("£4.80 spent / £0.60 left", fontSize = 11.sp, color = Color(0xFF1B365D), fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = 0.88f,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFF2E7D32),
                                trackColor = Color(0xFFE2E8F0)
                            )
                        }

                        // Weekly Cap Progress
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Weekly Cap Limit (£24.00 max)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Text("£18.20 spent / £5.80 left", fontSize = 11.sp, color = Color(0xFF1B365D), fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = 0.75f,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFF1B365D),
                                trackColor = Color(0xFFE2E8F0)
                            )
                        }
                    }
                }
            }
        }

        // Sub-tabs: Wallet vs Buy Passes
        item {
            TabRow(
                selectedTabIndex = if (activeTab == "Wallet") 0 else 1,
                containerColor = Color.Transparent,
                contentColor = Color(0xFF1B365D)
            ) {
                Tab(
                    selected = activeTab == "Wallet",
                    onClick = { activeTab = "Wallet" },
                    text = { Text("Active Wallet (${tickets.size + if (isSubscribed) 1 else 0})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeTab == "Buy Passes",
                    onClick = { activeTab = "Buy Passes" },
                    text = { Text("Buy Day & Weekly Passes 🎫", fontWeight = FontWeight.Bold) }
                )
            }
        }

        // Wallet view
        if (activeTab == "Wallet") {
            if (tickets.isEmpty() && !isSubscribed) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Outlined.QrCode2, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Tickets in Wallet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "Your purchased tickets, day passes, and taxi receipts will appear here. Tap 'Buy Passes' to secure a ticket.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                }
            } else {
                // Subscription Item
                if (isSubscribed) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    activeQrTicket = TicketEntity(
                                        type = "Subscription",
                                        title = "TravelSY+ Monthly Membership",
                                        price = 79.00,
                                        qrCodeData = "TRAVELSY-PLUS-MEMBER-SECURE-2026",
                                        expiryTimestamp = System.currentTimeMillis() + (30L * 24L * 60L * 60L * 1000L)
                                    )
                                },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32)) // Tram Green
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = Color.White.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Verified, contentDescription = null, tint = Color.White)
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Text("TravelSY+ Membership", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text("Active · Infinite Bus / Tram / Rail", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.8f))
                                        Text("Expiring in 28 Days", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.6f))
                                    }
                                }

                                Icon(Icons.Outlined.QrCode2, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                }

                items(tickets) { ticket ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeQrTicket = ticket }
                            .testTag("ticket_wallet_item_${ticket.id}"),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val (icon, color) = when (ticket.type) {
                                    "Tram" -> Icons.Default.Tram to Color(0xFF2E7D32)
                                    "Bus" -> Icons.Default.DirectionsBus to Color(0xFF1B365D)
                                    "Train" -> Icons.Default.Train to Color(0xFF5C677D)
                                    "Taxi" -> Icons.Default.LocalTaxi to Color(0xFFFF6D00)
                                    else -> Icons.Default.ConfirmationNumber to Color(0xFFFF6D00)
                                }

                                Surface(
                                    color = color.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(icon, contentDescription = null, tint = color)
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(ticket.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    Text("Valid until: ${formatter.format(Date(ticket.expiryTimestamp))}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                    Text("Paid £${String.format("%.2f", ticket.price)}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                }
                            }

                            Icon(Icons.Outlined.QrCode2, contentDescription = "View QR Code", tint = Color(0xFF1B365D), modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }
        }

        // Buy Passes view
        if (activeTab == "Buy Passes") {
            item {
                Text(
                    text = "South Yorkshire System Tickets",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B365D)
                )
            }

            val systemPasses = listOf(
                Triple("Sheffield Bus & Tram DayRider", "Unlimited Supertram & Stagecoach/First Buses in Sheffield.", 5.20),
                Triple("South Yorkshire Explorer Pass", "Uncapped transport on every bus, tram, and local rail across the county.", 8.50),
                Triple("Peak District Explorer Pass", "Includes buses to Bakewell, Chatsworth, Castleton and rail to Dore & Totley.", 12.00),
                Triple("Weekly Tram Saver Pass", "7 days of unlimited Stagecoach Supertram travel (Yellow, Blue, Purple, Tram-Train).", 16.80),
                Triple("SY Unified Monthly Pass", "30 days of hassle-free travel across all rail, buses and trams.", 54.00)
            )

            items(systemPasses) { pass ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(pass.first, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                Text(pass.second, style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
                            }

                            Text(
                                text = "£${String.format("%.2f", pass.third)}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val type = if (pass.first.contains("Tram")) "Tram" else if (pass.first.contains("Explorer")) "Train" else "Bus"
                                viewModel.purchaseTicket(type, pass.first, pass.third)
                                activeTab = "Wallet" // Return to Wallet immediately to display ticket
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B365D)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Payment, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Secure Payment & Purchase")
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Interactive offline QR Backup ticket popup dialog!
    if (activeQrTicket != null) {
        val t = activeQrTicket!!
        AlertDialog(
            onDismissRequest = { activeQrTicket = null },
            confirmButton = {
                Button(
                    onClick = { activeQrTicket = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B365D))
                ) {
                    Text("Close Wallet")
                }
            },
            title = {
                Text(
                    text = t.title,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B365D),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Travel South Yorkshire Boarding Pass",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Draw a beautiful, modern stylized vector QR Code using Canvas!
                    // This is 100% reliable, offline, and visually stunning.
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw mock QR pixels, corners, and guides
                            // Corners
                            drawRect(Color.Black, Offset(0f, 0f), androidx.compose.ui.geometry.Size(w * 0.25f, h * 0.25f))
                            drawRect(Color.White, Offset(4f, 4f), androidx.compose.ui.geometry.Size(w * 0.25f - 8f, h * 0.25f - 8f))
                            drawRect(Color.Black, Offset(8f, 8f), androidx.compose.ui.geometry.Size(w * 0.25f - 16f, h * 0.25f - 16f))

                            drawRect(Color.Black, Offset(w * 0.75f, 0f), androidx.compose.ui.geometry.Size(w * 0.25f, h * 0.25f))
                            drawRect(Color.White, Offset(w * 0.75f + 4f, 4f), androidx.compose.ui.geometry.Size(w * 0.25f - 8f, h * 0.25f - 8f))
                            drawRect(Color.Black, Offset(w * 0.75f + 8f, 8f), androidx.compose.ui.geometry.Size(w * 0.25f - 16f, h * 0.25f - 16f))

                            drawRect(Color.Black, Offset(0f, h * 0.75f), androidx.compose.ui.geometry.Size(w * 0.25f, h * 0.25f))
                            drawRect(Color.White, Offset(4f, h * 0.75f + 4f), androidx.compose.ui.geometry.Size(w * 0.25f - 8f, h * 0.25f - 8f))
                            drawRect(Color.Black, Offset(8f, h * 0.75f + 8f), androidx.compose.ui.geometry.Size(w * 0.25f - 16f, h * 0.25f - 16f))

                            // Custom randomized patterns inside
                            val sizeStep = w / 12f
                            for (row in 0..11) {
                                for (col in 0..11) {
                                    // Skip corners
                                    if ((row < 4 && col < 4) || (row < 4 && col > 7) || (row > 7 && col < 4)) continue

                                    // Pseudo-random deterministic fill based on grid coordinates & string hash
                                    val shouldFill = ((row * 7 + col * 13 + t.qrCodeData.hashCode()) % 2 == 0)
                                    if (shouldFill) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(col * sizeStep, row * sizeStep),
                                            size = androidx.compose.ui.geometry.Size(sizeStep - 1f, sizeStep - 1f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Offline Ticket QR Backup",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = t.qrCodeData,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B365D)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Hold this QR code up to any bus scanner, tram conductor, or train barrier reader.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        )
    }
}
