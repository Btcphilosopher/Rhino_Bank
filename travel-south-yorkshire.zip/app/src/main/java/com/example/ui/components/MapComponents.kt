package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChargingStation
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.LiveVehicle
import kotlin.math.sqrt

@OptIn(ExperimentalTextApi::class)
@Composable
fun InteractiveSouthYorkshireMap(
    vehicles: List<LiveVehicle>,
    selectedVehicle: LiveVehicle?,
    onVehicleSelected: (LiveVehicle?) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Box(modifier = modifier.background(Color(0xFFE2E8F0))) { // Soft Yorkshire Stone background
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(vehicles) {
                    detectTapGestures { offset ->
                        // Detect tap on a vehicle
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        var closest: LiveVehicle? = null
                        var minDistance = 100f // max touch pixel radius

                        for (v in vehicles) {
                            val vx = v.currentX * canvasWidth
                            val vy = v.currentY * canvasHeight
                            val dist = sqrt((vx - offset.x) * (vx - offset.x) + (vy - offset.y) * (vy - offset.y))
                            if (dist < minDistance) {
                                minDistance = dist
                                closest = v
                            }
                        }
                        onVehicleSelected(closest)
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. Draw Peak District Gateway (Left-hand side green hills)
            drawCircle(
                color = Color(0xFFC7F9CC).copy(alpha = 0.6f),
                radius = w * 0.35f,
                center = Offset(0f, h * 0.5f)
            )
            drawCircle(
                color = Color(0xFFC7F9CC).copy(alpha = 0.4f),
                radius = w * 0.25f,
                center = Offset(0f, h * 0.8f)
            )

            // Draw hills title
            drawText(
                textMeasurer = textMeasurer,
                text = "Peak District\nNational Park",
                topLeft = Offset(20.dp.toPx(), h * 0.6f),
                style = TextStyle(
                    color = Color(0xFF2D6A4F),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            // 2. Draw Major Rail Connection Line (Dotted White / Stone Line)
            val trainPathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
            // Barnsley (top left) -> Meadowhall -> Sheffield (center) -> Dore & Totley (bottom left)
            drawLine(
                color = Color.White,
                start = Offset(w * 0.25f, h * 0.15f),
                end = Offset(w * 0.45f, h * 0.35f),
                strokeWidth = 6f,
                pathEffect = trainPathEffect
            )
            drawLine(
                color = Color.White,
                start = Offset(w * 0.45f, h * 0.35f),
                end = Offset(w * 0.45f, h * 0.6f),
                strokeWidth = 6f,
                pathEffect = trainPathEffect
            )
            drawLine(
                color = Color.White,
                start = Offset(w * 0.45f, h * 0.6f),
                end = Offset(w * 0.25f, h * 0.85f),
                strokeWidth = 6f,
                pathEffect = trainPathEffect
            )

            // Sheffield (center) -> Rotherham (top center) -> Doncaster (top right)
            drawLine(
                color = Color.White,
                start = Offset(w * 0.45f, h * 0.6f),
                end = Offset(w * 0.6f, h * 0.45f),
                strokeWidth = 6f,
                pathEffect = trainPathEffect
            )
            drawLine(
                color = Color.White,
                start = Offset(w * 0.6f, h * 0.45f),
                end = Offset(w * 0.85f, h * 0.25f),
                strokeWidth = 6f,
                pathEffect = trainPathEffect
            )

            // 3. Draw Supertram Line (Tram Green Solid line)
            drawLine(
                color = Color(0xFF2E7D32), // Tram Green
                start = Offset(w * 0.35f, h * 0.55f),
                end = Offset(w * 0.45f, h * 0.6f), // Cathedral to Sheffield Stn
                strokeWidth = 8f
            )
            drawLine(
                color = Color(0xFF2E7D32),
                start = Offset(w * 0.45f, h * 0.6f),
                end = Offset(w * 0.45f, h * 0.35f), // Sheffield Stn to Meadowhall
                strokeWidth = 8f
            )

            // 4. Draw Major City Nodes (Radial circles)
            val cities = listOf(
                Triple("Sheffield", Offset(w * 0.45f, h * 0.6f), Color(0xFF1B365D)), // Steel Blue
                Triple("Meadowhall", Offset(w * 0.45f, h * 0.35f), Color(0xFF1B365D)),
                Triple("Doncaster", Offset(w * 0.85f, h * 0.25f), Color(0xFF1B365D)),
                Triple("Barnsley", Offset(w * 0.25f, h * 0.15f), Color(0xFF1B365D)),
                Triple("Rotherham", Offset(w * 0.6f, h * 0.45f), Color(0xFF1B365D)),
                Triple("Dore & Totley", Offset(w * 0.25f, h * 0.85f), Color(0xFF2D6A4F))
            )

            for (city in cities) {
                // City radial outline
                drawCircle(
                    color = city.third.copy(alpha = 0.15f),
                    radius = 35.dp.toPx(),
                    center = city.second
                )
                drawCircle(
                    color = city.third.copy(alpha = 0.8f),
                    radius = 8.dp.toPx(),
                    center = city.second
                )
                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx(),
                    center = city.second
                )

                // Label Text
                drawText(
                    textMeasurer = textMeasurer,
                    text = city.first,
                    topLeft = Offset(city.second.x + 10.dp.toPx(), city.second.y - 10.dp.toPx()),
                    style = TextStyle(
                        color = Color(0xFF212529),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        background = Color.White.copy(alpha = 0.8f)
                    )
                )
            }

            // 5. Draw Live Vehicles
            for (v in vehicles) {
                val vx = v.currentX * w
                val vy = v.currentY * h

                val isSelected = selectedVehicle?.id == v.id

                val markerColor = when (v.type) {
                    "Tram" -> Color(0xFF2E7D32)   // Tram Green
                    "Bus" -> Color(0xFF1B365D)    // Steel Blue
                    "Train" -> Color(0xFF5C677D)  // Grey
                    "Taxi" -> Color(0xFFFF6D00)   // Electric Orange
                    else -> Color(0xFF00B4D8)     // Cycle Teal
                }

                // Selected glow ring
                if (isSelected) {
                    drawCircle(
                        color = markerColor.copy(alpha = 0.4f),
                        radius = 20.dp.toPx(),
                        center = Offset(vx, vy)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 16.dp.toPx(),
                        center = Offset(vx, vy),
                        style = Stroke(width = 3f)
                    )
                }

                // Inner filled vehicle circle
                drawCircle(
                    color = markerColor,
                    radius = 10.dp.toPx(),
                    center = Offset(vx, vy)
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.dp.toPx(),
                    center = Offset(vx, vy)
                )

                // Floating Line Badge Label (compact)
                val badgeText = v.lineName
                val layoutResult = textMeasurer.measure(
                    text = badgeText,
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                val badgeWidth = layoutResult.size.width
                val badgeHeight = layoutResult.size.height

                drawRect(
                    color = markerColor,
                    topLeft = Offset(vx - badgeWidth / 2f - 6f, vy - 24.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(badgeWidth + 12f, badgeHeight + 4f)
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = badgeText,
                    topLeft = Offset(vx - badgeWidth / 2f, vy - 22.dp.toPx()),
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        // Overlay instructions
        Box(
            modifier = Modifier
                .padding(12.dp)
                .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .align(Alignment.BottomCenter)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = Color(0xFF1B365D),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Tap any moving vehicle to inspect live occupancy and USB/Wi-Fi",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF212529),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun VehicleDetailCard(
    vehicle: LiveVehicle,
    onClose: () -> Unit,
    onBookTaxi: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val icon = when (vehicle.type) {
                        "Tram" -> Icons.Default.Tram
                        "Bus" -> Icons.Default.DirectionsBus
                        "Train" -> Icons.Default.Train
                        "Taxi" -> Icons.Default.LocalTaxi
                        else -> Icons.Default.DirectionsBike
                    }

                    val color = when (vehicle.type) {
                        "Tram" -> Color(0xFF2E7D32)
                        "Bus" -> Color(0xFF1B365D)
                        "Train" -> Color(0xFF5C677D)
                        "Taxi" -> Color(0xFFFF6D00)
                        else -> Color(0xFF00B4D8)
                    }

                    Surface(
                        color = color.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "${vehicle.operator} - Line ${vehicle.lineName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Vehicle No: ${vehicle.vehicleNo}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Details body
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Destination",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                    Text(
                        text = vehicle.destination,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column {
                    Text(
                        text = "Status",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                    val delay = vehicle.delayMins
                    val (statusText, statusColor) = if (delay == 0) {
                        "On Time" to Color(0xFF2E7D32)
                    } else {
                        "+$delay min delay" to Color(0xFFFF6D00)
                    }
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = statusColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column {
                    Text(
                        text = "Crowding",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                    Text(
                        text = vehicle.occupancy,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = when (vehicle.occupancy) {
                            "Low" -> Color(0xFF2E7D32)
                            "Medium" -> Color(0xFFFF6D00)
                            else -> Color.Red
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider()
            Spacer(modifier = Modifier.height(12.dp))

            // Amenity indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AssistChip(
                    onClick = {},
                    label = { Text("Low Floor / Step-free", fontSize = 11.sp) },
                    leadingIcon = { Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )

                AssistChip(
                    onClick = {},
                    label = { Text("Wi-Fi & USB Charging", fontSize = 11.sp) },
                    leadingIcon = { Icon(Icons.Outlined.Wifi, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            // Taxi booking section
            if (vehicle.type == "Taxi") {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onBookTaxi,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6D00)) // Electric Orange
                ) {
                    Icon(Icons.Default.LocalTaxi, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Book ${vehicle.lineName} Now (£8.50 Est)")
                }
            }
        }
    }
}
