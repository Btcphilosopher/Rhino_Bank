package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Travel South Yorkshire - Modern Industrial Brand Palette
val SteelBlue = Color(0xFF1B365D)
val SteelBlueLight = Color(0xFF62B6CB)
val TramGreen = Color(0xFF2E7D32)
val YorkshireStoneGrey = Color(0xFFE2E8F0)
val YorkshireStoneDark = Color(0xFF2B2D42)
val ElectricOrange = Color(0xFFFF6D00)

// Light Theme Color Scheme Mapping
val PrimaryLight = Color(0xFF1B365D)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFBEE1E6)
val OnPrimaryContainerLight = Color(0xFF112A3A)

val SecondaryLight = Color(0xFF2E7D32)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD8F3DC)
val OnSecondaryContainerLight = Color(0xFF11322A)

val BackgroundLight = Color(0xFFF3F4F6) // Soft stone white
val SurfaceLight = Color(0xFFFFFFFF)
val OnBackgroundLight = Color(0xFF1C1B1F)
val OnSurfaceLight = Color(0xFF1C1B1F)

// Dark Theme Color Scheme Mapping
val PrimaryDark = Color(0xFF90E0EF)
val OnPrimaryDark = Color(0xFF0F3B4E)
val PrimaryContainerDark = Color(0xFF1B365D)
val OnPrimaryContainerDark = Color(0xFFD1E3ED)

val SecondaryDark = Color(0xFF52B788)
val OnSecondaryDark = Color(0xFF0C2419)
val SecondaryContainerDark = Color(0xFF2E7D32)
val OnSecondaryContainerDark = Color(0xFFD1EDEB)

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val OnBackgroundDark = Color(0xFFE2E8F0)
val OnSurfaceDark = Color(0xFFE2E8F0)
