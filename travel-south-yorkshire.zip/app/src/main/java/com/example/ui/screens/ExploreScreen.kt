package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.FlightTakeoff
import androidx.compose.material.icons.outlined.Landscape
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TravelViewModel

data class ExploreItem(
    val title: String,
    val category: String, // Tourist, Event, Airport, Local
    val nearestTransit: String,
    val walkingTime: String,
    val description: String,
    val advice: String,
    val details: String = ""
)

@Composable
fun ExploreScreen(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val activeMode by viewModel.activeExploreMode.collectAsState()

    val exploreItems = listOf(
        // Tourist Mode
        ExploreItem(
            title = "Peak District Explorer Trail",
            category = "Tourist",
            nearestTransit = "Dore & Totley Station (Rail)",
            walkingTime = "5 mins walk",
            description = "Hike from Dore & Totley into the Peak District Gateways, stopping at scenic viewpoints and heritage stone houses.",
            advice = "🎟 Recommendation: Buy Peak District Explorer Pass (£12.00). Use TM Travel Bus 218.",
            details = "Hours: 24/7 · Combined attraction pass available."
        ),
        ExploreItem(
            title = "Sheffield Kelham Island Industrial Heritage",
            category = "Tourist",
            nearestTransit = "Shalesmoor Supertram Stop",
            walkingTime = "3 mins walk",
            description = "Explore Sheffield's steelmaking roots at the Kelham Island Museum and enjoy local craft breweries in restored warehouses.",
            advice = "🚋 Recommendation: Take Supertram (Yellow Line) directly to Shalesmoor. Museum free entry.",
            details = "Hours: 10:00 - 17:00 · Ideal for steel culture enthusiasts."
        ),
        ExploreItem(
            title = "The Steel City Tour",
            category = "Tourist",
            nearestTransit = "Sheffield Cathedral",
            walkingTime = "1 min walk",
            description = "A curated walk through central Sheffield, including Winter Gardens, Millennium Gallery, and Peace Gardens.",
            advice = "🚶 Recommendation: Walking-only route. Accessible stone pathways.",
            details = "Hours: 08:00 - 20:00 · Wheelchair friendly."
        ),
        
        // Event Mode
        ExploreItem(
            title = "Sheffield Football Derby (Bramall Lane)",
            category = "Event",
            nearestTransit = "Sheffield Interchange / Bramall Lane Bus",
            walkingTime = "8 mins walk",
            description = "Sheffield United vs Sheffield Wednesday. Major local match. Special extra buses and tram departures running post-game.",
            advice = "⚠️ Advice: Roads congested. Board the Supertram Blue line to Granville Road/Sheffield College. Late-night return services extended.",
            details = "Match Kickoff: 15:00 · Stadium gates open 1.5h early."
        ),
        ExploreItem(
            title = "Tramlines Festival (Hillsborough Park)",
            category = "Event",
            nearestTransit = "Hillsborough Park Supertram Stop",
            walkingTime = "1 min walk",
            description = "South Yorkshire's largest music festival. Multi-stage concerts, food trucks, and craft bars.",
            advice = "🚋 Advice: Tramlines Festival special ticketing active. Yellow line trams depart every 3 mins post-concert.",
            details = "Dates: 24 - 26 July · Ticket wallet stores your combined music & travel pass."
        ),
        ExploreItem(
            title = "Cliffhanger Festival & Christmas Market",
            category = "Event",
            nearestTransit = "Sheffield City Centre (Cathedral)",
            walkingTime = "1 min walk",
            description = "Explore rock climbing, outdoor sports stalls, and traditional wooden Christmas market cabins with festive treats.",
            advice = "🎁 Advice: Use Sheffield DayRider for unlimited bus/tram connections to and from the markets.",
            details = "Seasonal: November - December · Festive evening buses active."
        ),

        // Airport Mode
        ExploreItem(
            title = "Manchester Airport (MAN) Connection",
            category = "Airport",
            nearestTransit = "Sheffield Station (Rail)",
            walkingTime = "Direct rail from Platform 5",
            description = "Unified journey planning from South Yorkshire straight to Manchester Airport Terminal 1, 2, and 3.",
            advice = "🚆 Train: £14.50 single. 1h 15m duration. TransPennine Express runs hourly.",
            details = "Taxi Option: £75.00 Est with City Cabs. Bookable in Live tab."
        ),
        ExploreItem(
            title = "Leeds Bradford Airport (LBA) Coach",
            category = "Airport",
            nearestTransit = "Meadowhall Interchange",
            walkingTime = "Coach Platform A",
            description = "Take the Trans-Yorkshire Express Coach directly to Leeds, connecting with the LBA link shuttle.",
            advice = "🚍 Coach + Shuttle: £11.20 combined fare. 1h 45m duration. Runs every 2 hours.",
            details = "Saves 35% compared to individual rail tickets."
        ),
        ExploreItem(
            title = "East Midlands Airport (EMA) Link",
            category = "Airport",
            nearestTransit = "Sheffield Station (Rail)",
            walkingTime = "Direct rail platform 2",
            description = "Travel south via train to Derby, connecting with the EMA Skylink bus service.",
            advice = "🚆 Rail + Skylink: £16.50. Total travel: 1h 20m. Best for early departures.",
            details = "Skylink operates 24/7 from Derby station."
        )
    )

    val categories = listOf("All", "Tourist", "Event", "Airport")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Explore South Yorkshire",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B365D)
            )
            Text(
                text = "Discover attractions, events, and travel connections",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Filtering pills
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = activeMode == cat
                    val containerColor = if (isSelected) Color(0xFF1B365D) else Color.White
                    val contentColor = if (isSelected) Color.White else Color(0xFF1B365D)

                    Surface(
                        modifier = Modifier
                            .clickable { viewModel.setExploreMode(cat) }
                            .testTag("explore_filter_$cat"),
                        shape = RoundedCornerShape(20.dp),
                        color = containerColor,
                        border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B365D)) else null
                    ) {
                        Text(
                            text = cat,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = contentColor
                        )
                    }
                }
            }
        }

        // Render matching items
        val filteredItems = if (activeMode == "All") exploreItems else exploreItems.filter { it.category == activeMode }

        if (filteredItems.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Text(
                        text = "No items found in this category.",
                        modifier = Modifier.padding(24.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = Color.Gray
                    )
                }
            }
        } else {
            items(filteredItems) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("explore_item_${item.title.replace(" ", "_")}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val (icon, color) = when (item.category) {
                                    "Tourist" -> Icons.Outlined.Landscape to Color(0xFF2E7D32)
                                    "Event" -> Icons.Outlined.Event to Color(0xFFFF6D00)
                                    "Airport" -> Icons.Outlined.FlightTakeoff to Color(0xFF1B365D)
                                    else -> Icons.Outlined.Place to Color.Gray
                                }

                                Surface(
                                    color = color.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B365D)
                                )
                            }

                            Surface(
                                color = Color(0xFFE2E8F0),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = item.category,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = item.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.DarkGray
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Nearest Transit info
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.DirectionsTransit, contentDescription = "Nearest Transit", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${item.nearestTransit} (${item.walkingTime})",
                                fontSize = 12.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = item.details,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Live Advice box (Electric Orange or Green)
                        Surface(
                            color = if (item.category == "Event") Color(0xFFFF6D00).copy(alpha = 0.08f) else Color(0xFF2E7D32).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = item.advice,
                                modifier = Modifier.padding(10.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (item.category == "Event") Color(0xFFE65F2B) else Color(0xFF2E7D32)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
