package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Accessible
import androidx.compose.material.icons.outlined.DirectionsBus
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.DirectionsWalk
import androidx.compose.material.icons.outlined.Landscape
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.Train
import androidx.compose.material.icons.outlined.Tram
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JourneyOption
import com.example.ui.JourneyStep
import com.example.ui.TravelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyScreen(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val fromLocation by viewModel.plannedJourneyFrom.collectAsState()
    val toLocation by viewModel.plannedJourneyTo.collectAsState()
    val options by viewModel.plannedJourneyOptions.collectAsState()
    val isLoading by viewModel.isPlanningLoading.collectAsState()

    var activeFromMenu by remember { mutableStateOf(false) }
    var activeToMenu by remember { mutableStateOf(false) }

    val locations = listOf(
        "Sheffield Interchange",
        "Meadowhall Interchange",
        "Barnsley Interchange",
        "Rotherham Central",
        "Doncaster Station",
        "Dore & Totley (Peak Gateway)",
        "Sheffield Cathedral",
        "Utilita Arena",
        "Bramall Lane",
        "Hillsborough"
    )

    var expandedOptionId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Smart Journey Planner",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B365D)
            )
            Text(
                text = "AI Multi-Mode Route Engine",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Planning Card Inputs
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("planner_inputs_card"),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Origin selector
                    Box {
                        OutlinedTextField(
                            value = fromLocation,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("From (Current Location)") },
                            leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null, tint = Color(0xFF1B365D)) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { activeFromMenu = true }
                                .testTag("from_location_field"),
                            enabled = false, // delegate to tap detection
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = LocalContentColor.current,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        DropdownMenu(
                            expanded = activeFromMenu,
                            onDismissRequest = { activeFromMenu = false },
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            locations.forEach { loc ->
                                DropdownMenuItem(
                                    text = { Text(loc) },
                                    onClick = {
                                        viewModel.setPlannedFrom(loc)
                                        activeFromMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Swap button
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        IconButton(
                            onClick = {
                                val temp = fromLocation
                                viewModel.setPlannedFrom(toLocation)
                                viewModel.setPlannedTo(temp)
                            },
                            modifier = Modifier.background(Color(0xFFE2E8F0), CircleShape)
                        ) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap Locations", tint = Color(0xFF1B365D))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Destination selector
                    Box {
                        OutlinedTextField(
                            value = toLocation,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("To (Destination)") },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFFFF6D00)) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { activeToMenu = true }
                                .testTag("to_location_field"),
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = LocalContentColor.current,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        DropdownMenu(
                            expanded = activeToMenu,
                            onDismissRequest = { activeToMenu = false },
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            locations.forEach { loc ->
                                DropdownMenuItem(
                                    text = { Text(loc) },
                                    onClick = {
                                        viewModel.setPlannedTo(loc)
                                        activeToMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Departure & Arrival Pickers (Simulated text inputs)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = "Depart Now",
                            onValueChange = {},
                            label = { Text("When") },
                            readOnly = true,
                            enabled = false,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(disabledTextColor = LocalContentColor.current)
                        )

                        OutlinedTextField(
                            value = "08:30 AM",
                            onValueChange = {},
                            label = { Text("Time") },
                            readOnly = true,
                            enabled = false,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(disabledTextColor = LocalContentColor.current)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Plan Button
                    Button(
                        onClick = { viewModel.calculateJourney() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("plan_journey_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B365D))
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Icon(Icons.Default.Route, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Calculate Best Journeys", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Suggestions when empty or loaded
        if (options.isEmpty() && !isLoading) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE2E8F0).copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.DirectionsTransit, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Awaiting Journey Plan",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B365D)
                        )
                        Text(
                            text = "Select an origin and destination to see optimized options.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 24.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        // Options listing
        if (options.isNotEmpty() && !isLoading) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Calculated Options",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B365D)
                    )

                    Button(
                        onClick = { viewModel.saveJourneyToFavorites() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF1B365D)),
                        modifier = Modifier.border(1.dp, Color(0xFF1B365D), RoundedCornerShape(20.dp))
                    ) {
                        Icon(Icons.Outlined.StarBorder, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save Commute", fontSize = 12.sp)
                    }
                }
            }

            items(options) { opt ->
                val isExpanded = expandedOptionId == opt.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedOptionId = if (isExpanded) null else opt.id }
                        .testTag("option_${opt.id}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = when {
                                    opt.type.contains("Fastest") -> Color(0xFF1B365D).copy(alpha = 0.1f)
                                    opt.type.contains("Cheapest") -> Color(0xFF2E7D32).copy(alpha = 0.1f)
                                    opt.type.contains("Greenest") -> Color(0xFF2D6A4F).copy(alpha = 0.1f)
                                    else -> Color(0xFFFF6D00).copy(alpha = 0.1f)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = opt.type,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        opt.type.contains("Fastest") -> Color(0xFF1B365D)
                                        opt.type.contains("Cheapest") -> Color(0xFF2E7D32)
                                        opt.type.contains("Greenest") -> Color(0xFF2D6A4F)
                                        else -> Color(0xFFFF6D00)
                                    }
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Co2, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                                Text(
                                    text = "-${opt.co2SavedKg}kg CO₂",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${opt.durationMins} mins",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B365D)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                // Render modal summary icons
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    opt.steps.forEachIndexed { sIndex, step ->
                                        val icon = when (step.mode) {
                                            "Walk" -> Icons.Outlined.DirectionsWalk
                                            "Bus" -> Icons.Outlined.DirectionsBus
                                            "Tram" -> Icons.Outlined.Tram
                                            "Train" -> Icons.Outlined.Train
                                            else -> Icons.Outlined.DirectionsCar
                                        }
                                        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                                        if (sIndex < opt.steps.size - 1) {
                                            Text("›", color = Color.Gray, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            Text(
                                text = "£${String.format("%.2f", opt.costGbp)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }

                        // Expandable step-by-step timeline details
                        AnimatedVisibility(
                            visible = isExpanded,
                            enter = expandVertically(),
                            exit = shrinkVertically()
                        ) {
                            Column(modifier = Modifier.padding(top = 16.dp)) {
                                Divider()
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Step-by-step Itinerary:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Spacer(modifier = Modifier.height(12.dp))

                                opt.steps.forEachIndexed { index, step ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Visual line and bubble
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.width(32.dp)
                                        ) {
                                            val stepIcon = when (step.iconName) {
                                                "directions_walk" -> Icons.Outlined.DirectionsWalk
                                                "directions_bus" -> Icons.Outlined.DirectionsBus
                                                "tram" -> Icons.Outlined.Tram
                                                "train" -> Icons.Outlined.Train
                                                "accessible" -> Icons.Outlined.Accessible
                                                "landscape" -> Icons.Outlined.Landscape
                                                else -> Icons.Outlined.DirectionsCar
                                            }

                                            Surface(
                                                color = Color(0xFFE2E8F0),
                                                shape = CircleShape,
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(stepIcon, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF1B365D))
                                                }
                                            }

                                            if (index < opt.steps.size - 1) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(2.dp)
                                                        .height(20.dp)
                                                        .background(Color.LightGray)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = step.details,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "${step.mode} · ${step.durationMins} mins",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { viewModel.purchaseTicket(opt.id, "${opt.type.replace("Route ", "")} Ticket", opt.costGbp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6D00))
                                ) {
                                    Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Book & Pay Instantly (£${String.format("%.2f", opt.costGbp)})")
                                }
                            }
                        }

                        if (!isExpanded) {
                            Text(
                                text = "▾ Tap to view timeline details & book",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
