package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.BrightnessHigh
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.OfflinePin
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TravelViewModel

data class QuickActionItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val badge: String? = null,
    val action: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.travelStats.collectAsState()
    val isSubscribed by viewModel.isSubscribedToSYPlus.collectAsState()
    val favoriteJourneys by viewModel.favoriteJourneys.collectAsState()

    var showQuickDetailDialog by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6)) // Yorkshire Stone white
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Good morning,",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.Gray
                    )
                    Text(
                        text = "Travel South Yorkshire",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B365D) // Steel Blue
                    )
                    Text(
                        text = "One Region. One App. Every Journey.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF2E7D32), // Tram Green
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Bell Alert button
                IconButton(
                    onClick = { showQuickDetailDialog = "Service Alerts: No major system-wide issues. Slight platform changes on Sheffield Cathedral tram siding due to signal repairs." },
                    modifier = Modifier
                        .background(Color.White, CircleShape)
                        .testTag("notification_button")
                ) {
                    Icon(
                        Icons.Outlined.NotificationsActive,
                        contentDescription = "Alerts",
                        tint = Color(0xFFFF6D00) // Electric Orange
                    )
                }
            }
        }

        // Clean Utility / Minimal Search Bar Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectTab(1) } // Navigate to Journey planner
                    .testTag("search_bar_card"),
                shape = RoundedCornerShape(24.dp), // Pill/rounded-full style
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)), // border-slate-200
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search icon",
                            tint = Color(0xFF64748B), // text-slate-500
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Where to in South Yorkshire?",
                            color = Color(0xFF64748B),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // JD Avatar
                    Surface(
                        color = Color(0xFF1B365D),
                        shape = CircleShape,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "JD",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // TravelSY+ Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("travelsy_banner"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSubscribed) Color(0xFF2E7D32) else Color(0xFF1B365D)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TravelSY+",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Unified Mobility Membership",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }

                        Surface(
                            color = Color.White.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (isSubscribed) "ACTIVE MEMBER" else "£79/Month",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isSubscribed) 
                            "✓ Unlimited Bus, Supertram & Local Rail across Sheffield, Barnsley, Rotherham, Doncaster & Peak District."
                            else "Get unlimited bus, tram, regional rail and massive taxi/bike hire discounts with one simple billing.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.toggleSubscription() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSubscribed) Color(0xFFFF6D00) else Color.White,
                            contentColor = if (isSubscribed) Color.White else Color(0xFF1B365D)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isSubscribed) "Cancel Subscription" else "Activate TravelSY+ Membership",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Weather and Service Alert Widget
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Weather
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Outlined.BrightnessHigh,
                            contentDescription = null,
                            tint = Color(0xFFFF6D00),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Sheffield Weather", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("18°C · Sun", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Alert Check
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showQuickDetailDialog = "All services are running normally with no severe delays reported. Live tracking updates are online." },
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Live Status", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("All Services Good", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick cards grid (Next Tram, next Bus, hire bike, book taxi, etc.)
        item {
            Text(
                text = "Transit Quick Cards",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B365D)
            )
        }

        item {
            val quickActions = listOf(
                QuickActionItem("Next Tram 🚋", Icons.Default.Tram, Color(0xFF2E7D32), "Live") {
                    showQuickDetailDialog = "🚋 **Next Tram Departure:**\n\nYellow Line towards Meadowhall departing in **3 mins** from Sheffield Cathedral.\nBlue Line towards Halfway departing in **7 mins** from Platform 1."
                },
                QuickActionItem("Next Bus 🚌", Icons.Default.DirectionsBus, Color(0xFF1B365D), "Live") {
                    showQuickDetailDialog = "🚌 **Next Bus Departure:**\n\nBus 120 towards Rotherham departing in **4 mins** from Stop SF3.\nBus 95 towards Walkley departing in **9 mins** from Stop SF1."
                },
                QuickActionItem("Next Train 🚆", Icons.Default.Train, Color(0xFF5C677D), "Live") {
                    showQuickDetailDialog = "🚆 **Next Train Departure:**\n\nNorthern Rail towards Doncaster departing in **8 mins** from Platform 3.\nTransPennine towards Leeds departing in **12 mins** from Platform 5."
                },
                QuickActionItem("Book Taxi 🚖", Icons.Default.LocalTaxi, Color(0xFFFF6D00), null) {
                    viewModel.selectTab(2) // Direct to Live map to choose a nearby taxi
                },
                QuickActionItem("Park & Ride 🚗", Icons.Default.LocalParking, Color(0xFF1B365D), "Spaces") {
                    showQuickDetailDialog = "🅿 **Park & Ride Occupancy:**\n\nMeadowhall Interchange: **240 / 400 spaces** available.\nNunnery Square (Tram): **180 / 300 spaces** available.\nHillsborough: **85 / 120 spaces** available."
                },
                QuickActionItem("Hire Bike 🚴", Icons.Default.DirectionsBike, Color(0xFF00B4D8), null) {
                    viewModel.selectTab(2) // Live tab
                },
                QuickActionItem("Buy Ticket 🎫", Icons.Default.ConfirmationNumber, Color(0xFFFF6D00), "Save") {
                    viewModel.selectTab(3) // Tickets tab
                },
                QuickActionItem("Service Alerts ⚠", Icons.Default.Warning, Color(0xFFFF6D00), "1 Alert") {
                    showQuickDetailDialog = "⚠️ **Active Service Alerts:**\n\nSupertram Purple Line experiencing brief 5-minute delays due to electrical maintenance near Gleadless Townend. All other lines operating perfectly."
                }
            )

            // Grid Layout
            Column {
                for (row in quickActions.chunked(2)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (item in row) {
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { item.action() }
                                    .testTag("quick_${item.title.replace(" ", "_")}"),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Box(modifier = Modifier.padding(12.dp)) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Surface(
                                            color = item.color.copy(alpha = 0.1f),
                                            shape = CircleShape,
                                            modifier = Modifier.size(44.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(item.icon, contentDescription = null, tint = item.color, modifier = Modifier.size(24.dp))
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    if (item.badge != null) {
                                        Surface(
                                            color = item.color,
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.align(Alignment.TopEnd)
                                        ) {
                                            Text(
                                                text = item.badge,
                                                color = Color.White,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Favorite journeys list
        if (favoriteJourneys.isNotEmpty()) {
            item {
                Text(
                    text = "★ Saved Commutes",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B365D)
                )
            }

            items(favoriteJourneys.size) { index ->
                val fav = favoriteJourneys[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setPlannedFrom(fav.fromLocation)
                            viewModel.setPlannedTo(fav.toLocation)
                            viewModel.selectTab(1) // Go to Journey planner
                            viewModel.calculateJourney()
                        },
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = Color(0xFFE2E8F0),
                                shape = CircleShape,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.Star, contentDescription = null, tint = Color(0xFFFF6D00))
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(fav.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Text("${fav.fromLocation} → ${fav.toLocation}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }

                        Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // Sustainability Dashboard Card
        item {
            stats?.let { s ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32).copy(alpha = 0.08f)) // Soft Tram Green background
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Analytics, contentDescription = null, tint = Color(0xFF2E7D32))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Your Green Footprint",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }

                            // Points display
                            Surface(
                                color = Color(0xFFFF6D00),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Outlined.EmojiEvents, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${s.pointsEarned} Points", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "${s.co2Saved} kg", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF1B365D))
                                Text(text = "CO₂ Saved", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "${s.carJourneysAvoided}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF1B365D))
                                Text(text = "Car Trips Avoided", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "${s.caloriesWalked.toInt()} kcal", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF1B365D))
                                Text(text = "Calories", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "£${String.format("%.2f", s.moneySaved)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF1B365D))
                                Text(text = "Money Saved", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Detail dialog popups
    if (showQuickDetailDialog != null) {
        AlertDialog(
            onDismissRequest = { showQuickDetailDialog = null },
            confirmButton = {
                TextButton(onClick = { showQuickDetailDialog = null }) {
                    Text("Done")
                }
            },
            title = {
                Text(
                    text = "South Yorkshire Transit",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B365D)
                )
            },
            text = {
                Text(
                    text = showQuickDetailDialog ?: "",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        )
    }
}
