package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AssistantUiState
import com.example.ui.TravelViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val chatMessages by viewModel.chatMessages.collectAsState()
    val assistantState by viewModel.assistantUiState.collectAsState()
    val reports by viewModel.communityReports.collectAsState()

    var activeSubTab by remember { mutableStateOf("AI Assistant") } // AI Assistant, Safety, Report, Business

    // Report form states
    var reportVehicleType by remember { mutableStateOf("Tram") }
    var reportVehicleNo by remember { mutableStateOf("") }
    var reportType by remember { mutableStateOf("Crowding") }
    var reportDesc by remember { mutableStateOf("") }

    var activeVehicleTypeDropdown by remember { mutableStateOf(false) }
    var activeReportTypeDropdown by remember { mutableStateOf(false) }

    var alertMessage by remember { mutableStateOf<String?>(null) }

    val formatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
    ) {
        // Inner Tab Selector
        TabRow(
            selectedTabIndex = when (activeSubTab) {
                "AI Assistant" -> 0
                "Report" -> 1
                "Safety" -> 2
                else -> 3
            },
            containerColor = Color.White,
            contentColor = Color(0xFF1B365D)
        ) {
            Tab(
                selected = activeSubTab == "AI Assistant",
                onClick = { activeSubTab = "AI Assistant" },
                icon = { Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(20.dp)) },
                text = { Text("AI Assistant", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeSubTab == "Report",
                onClick = { activeSubTab = "Report" },
                icon = { Icon(Icons.Outlined.ReportProblem, contentDescription = null, modifier = Modifier.size(20.dp)) },
                text = { Text("Report Fault", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeSubTab == "Safety",
                onClick = { activeSubTab = "Safety" },
                icon = { Icon(Icons.Outlined.Security, contentDescription = null, modifier = Modifier.size(20.dp)) },
                text = { Text("Safety", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeSubTab == "Business",
                onClick = { activeSubTab = "Business" },
                icon = { Icon(Icons.Outlined.LibraryBooks, contentDescription = null, modifier = Modifier.size(20.dp)) },
                text = { Text("Business", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeSubTab) {
                "AI Assistant" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "TravelSY AI Companion 🤖",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B365D)
                                )
                                Text(
                                    text = "Ask about routes, tickets, and travel advice.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }

                            TextButton(onClick = { viewModel.clearChat() }) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Clear", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Chat bubbles history
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(chatMessages) { msg ->
                                val isUser = msg.second
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                                ) {
                                    Surface(
                                        color = if (isUser) Color(0xFF1B365D) else Color(0xFFE2E8F0),
                                        contentColor = if (isUser) Color.White else Color.Black,
                                        shape = RoundedCornerShape(
                                            topStart = 12.dp,
                                            topEnd = 12.dp,
                                            bottomStart = if (isUser) 12.dp else 0.dp,
                                            bottomEnd = if (isUser) 0.dp else 12.dp
                                        ),
                                        modifier = Modifier.fillMaxWidth(0.85f)
                                    ) {
                                        Text(
                                            text = msg.first,
                                            modifier = Modifier.padding(12.dp),
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }

                            if (assistantState is AssistantUiState.Loading) {
                                item {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.Start,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            color = Color(0xFF2E7D32),
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "TravelSY is planning...",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Chat entry box
                        var textInput by remember { mutableStateOf("") }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = textInput,
                                onValueChange = { textInput = it },
                                placeholder = { Text("Ask: 'quickest way to Meadowhall'...") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("chat_input_field"),
                                shape = RoundedCornerShape(24.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = {
                                    if (textInput.isNotBlank()) {
                                        viewModel.sendMessage(textInput)
                                        textInput = ""
                                    }
                                },
                                modifier = Modifier
                                    .background(Color(0xFF2E7D32), CircleShape)
                                    .testTag("chat_send_button")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                            }
                        }
                    }
                }

                "Report" -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text(
                                text = "Community Reporting Hub 📣",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B365D)
                            )
                            Text(
                                text = "Report delays, cleanliness, crowding or faults to immediately alert operators & fellow passengers. Earn 15 travel points per report!",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }

                        // Form card
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    // Vehicle Type Dropdown
                                    Box {
                                        OutlinedTextField(
                                            value = reportVehicleType,
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("Transit Mode") },
                                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { activeVehicleTypeDropdown = true },
                                            enabled = false,
                                            colors = OutlinedTextFieldDefaults.colors(disabledTextColor = LocalContentColor.current)
                                        )
                                        DropdownMenu(
                                            expanded = activeVehicleTypeDropdown,
                                            onDismissRequest = { activeVehicleTypeDropdown = false },
                                            modifier = Modifier.fillMaxWidth(0.85f)
                                        ) {
                                            listOf("Bus", "Tram", "Train", "Station").forEach { type ->
                                                DropdownMenuItem(
                                                    text = { Text(type) },
                                                    onClick = {
                                                        reportVehicleType = type
                                                        activeVehicleTypeDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Vehicle Number
                                    OutlinedTextField(
                                        value = reportVehicleNo,
                                        onValueChange = { reportVehicleNo = it },
                                        label = { Text("Line Number / Vehicle ID (e.g. Bus 120)") },
                                        placeholder = { Text("e.g. Tram 104") },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("report_vehicle_field")
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Report Type Dropdown
                                    Box {
                                        OutlinedTextField(
                                            value = reportType,
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("Issue Type") },
                                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { activeReportTypeDropdown = true },
                                            enabled = false,
                                            colors = OutlinedTextFieldDefaults.colors(disabledTextColor = LocalContentColor.current)
                                        )
                                        DropdownMenu(
                                            expanded = activeReportTypeDropdown,
                                            onDismissRequest = { activeReportTypeDropdown = false },
                                            modifier = Modifier.fillMaxWidth(0.85f)
                                        ) {
                                            listOf("Crowding", "Cleanliness", "Broken Machine", "Delay", "Accessibility").forEach { t ->
                                                DropdownMenuItem(
                                                    text = { Text(t) },
                                                    onClick = {
                                                        reportType = t
                                                        activeReportTypeDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Description
                                    OutlinedTextField(
                                        value = reportDesc,
                                        onValueChange = { reportDesc = it },
                                        label = { Text("Describe the Situation") },
                                        placeholder = { Text("Provide details...") },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .testTag("report_desc_field")
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Button(
                                        onClick = {
                                            if (reportVehicleNo.isNotBlank() && reportDesc.isNotBlank()) {
                                                viewModel.submitReport(
                                                    vehicleType = reportVehicleType,
                                                    vehicleNo = reportVehicleNo,
                                                    reportType = reportType,
                                                    desc = reportDesc
                                                )
                                                reportVehicleNo = ""
                                                reportDesc = ""
                                                alertMessage = "📣 Thank you! Your community report has been submitted successfully. 15 Travel Points have been added to your profile."
                                            } else {
                                                alertMessage = "⚠️ Please fill in all fields before submitting."
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("report_submit_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B365D))
                                    ) {
                                        Icon(Icons.Default.Campaign, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Submit Broadcast Report")
                                    }
                                }
                            }
                        }

                        // Existing reports list
                        if (reports.isNotEmpty()) {
                            item {
                                Text(
                                    text = "Active Commuter Broadcasts",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B365D)
                                )
                            }

                            items(reports) { rep ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    color = Color(0xFFFF6D00).copy(alpha = 0.1f),
                                                    shape = CircleShape,
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Icon(Icons.Default.Campaign, contentDescription = null, tint = Color(0xFFFF6D00), modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${rep.vehicleNumber} - ${rep.reportType}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                            }

                                            Text(
                                                text = "UNDER REVIEW",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFFF6D00),
                                                modifier = Modifier
                                                    .background(Color(0xFFFF6D00).copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = rep.description, style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Reported at ${formatter.format(Date(rep.timestamp))} · Operator alerted",
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "Safety" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "South Yorkshire Safety Centre 🛡",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B365D)
                        )
                        Text(
                            text = "Access round-the-clock emergency assistance, report anti-social incidents on vehicles, or securely share your live location coordinates.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )

                        // Action Buttons
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Button(
                                    onClick = { alertMessage = "🚨 Connecting with Travel South Yorkshire Emergency Control Center desk. A dispatcher is matching your phone IP..." },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Emergency, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Emergency Control Centre (24/7)")
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedButton(
                                    onClick = { alertMessage = "🔗 Live Journey coordinates link copied to clipboard! Share with family or companions." },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.ShareLocation, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Share Live Journey Link")
                                }
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Lost Property", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                Text("Left an item on the Supertram or First/Stagecoach buses? File a quick registry ticket here.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { alertMessage = "💼 Lost Property file initiated. Please visit Sheffield Interchange desk or call 0114 276 2762." },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B365D)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Open Lost Property Ticket")
                                }
                            }
                        }
                    }
                }

                "Business" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Business Portal & Salary Sacrifice 💼",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B365D)
                        )
                        Text(
                            text = "Employers across South Yorkshire can sponsor commute subscriptions tax-free. Save up to 42% on annual ticket costs via Salary Sacrifice schemes.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("TravelSY+ Sponsoring", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                Text("Connect your employer account to pay the monthly £79 fee directly from pre-tax payroll salary.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { alertMessage = "💼 Sponsoring proposal sent to your company's HR department for review. You will be notified shortly." },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Business, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Connect Sponsoring Account")
                                }
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Expense Reporting", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                Text("Export taxi receipts, rail invoices, and bus fares as HMRC-compliant PDF expensing documents.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { alertMessage = "📊 Exporting PDF expensing ledger for July 2026. File saved to downloads." },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Download Expensing PDF Ledger")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal warnings/alerts
    if (alertMessage != null) {
        AlertDialog(
            onDismissRequest = { alertMessage = null },
            confirmButton = {
                TextButton(onClick = { alertMessage = null }) {
                    Text("OK")
                }
            },
            title = {
                Text("Travel South Yorkshire Hub", fontWeight = FontWeight.Bold, color = Color(0xFF1B365D))
            },
            text = {
                Text(alertMessage ?: "", style = MaterialTheme.typography.bodyMedium)
            }
        )
    }
}
