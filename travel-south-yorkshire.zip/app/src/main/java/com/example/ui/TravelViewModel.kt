package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

// Sealed UI State for AI Assistant
sealed interface AssistantUiState {
    object Idle : AssistantUiState
    object Loading : AssistantUiState
    data class Success(val response: String) : AssistantUiState
    data class Error(val message: String) : AssistantUiState
}

// Data class representing a simulated vehicle on the map
data class LiveVehicle(
    val id: String,
    val type: String, // Tram, Bus, Train, Taxi, Bike
    val lineName: String, // e.g. "Yellow Line", "120", "Northern Rail", "City Taxi"
    val operator: String, // e.g. "Stagecoach Supertram", "First Bus", "Northern", "City Cabs"
    val startX: Float,
    val startY: Float,
    var currentX: Float,
    var currentY: Float,
    val speedX: Float,
    val speedY: Float,
    val destination: String,
    val occupancy: String, // Low, Medium, High
    val accessibility: String = "Wheelchair Accessible, Low Floor",
    val usbWiLine: String = "USB Charging, Free Wi-Fi",
    val delayMins: Int = 0,
    val vehicleNo: String = "SY-${Random.nextInt(100, 999)}"
)

// Itinerary step
data class JourneyStep(
    val mode: String, // Walk, Tram, Bus, Train, Taxi
    val details: String,
    val durationMins: Int,
    val iconName: String
)

// Journey Option result
data class JourneyOption(
    val id: String,
    val type: String, // Fastest, Cheapest, Greenest, Step-Free, Scenic, Fewest Changes
    val durationMins: Int,
    val costGbp: Double,
    val co2SavedKg: Double,
    val steps: List<JourneyStep>
)

class TravelViewModel(application: Application) : AndroidViewModel(application) {

    private val database = TravelDatabase.getDatabase(application)
    private val repository = TravelRepository(database.travelDao())

    // --- Tab Selection ---
    private val _selectedTab = MutableStateFlow(0) // 0 = Home, 1 = Journey, 2 = Live, 3 = Tickets, 4 = Explore, 5 = Account
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    fun selectTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    // --- Local DB flows ---
    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteJourneys: StateFlow<List<FavoriteJourneyEntity>> = repository.allFavoriteJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val communityReports: StateFlow<List<CommunityReportEntity>> = repository.allCommunityReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val travelStats: StateFlow<TravelStatsEntity?> = repository.travelStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- AI Assistant Chat History ---
    private val _chatMessages = MutableStateFlow<List<Pair<String, Boolean>>>(
        listOf(
            "Hello! I am your Travel South Yorkshire AI assistant. Ask me anything about routes, fares, buses, trams, or booking a taxi." to false
        )
    ) // Pair(Message, isUser)
    val chatMessages: StateFlow<List<Pair<String, Boolean>>> = _chatMessages.asStateFlow()

    private val _assistantUiState = MutableStateFlow<AssistantUiState>(AssistantUiState.Idle)
    val assistantUiState: StateFlow<AssistantUiState> = _assistantUiState.asStateFlow()

    // --- Live Vehicles State (Simulated) ---
    private val _liveVehicles = MutableStateFlow<List<LiveVehicle>>(emptyList())
    val liveVehicles: StateFlow<List<LiveVehicle>> = _liveVehicles.asStateFlow()

    private val _selectedVehicle = MutableStateFlow<LiveVehicle?>(null)
    val selectedVehicle: StateFlow<LiveVehicle?> = _selectedVehicle.asStateFlow()

    // --- Journey Planner State ---
    private val _plannedJourneyFrom = MutableStateFlow("Sheffield Interchange")
    val plannedJourneyFrom: StateFlow<String> = _plannedJourneyFrom.asStateFlow()

    private val _plannedJourneyTo = MutableStateFlow("Meadowhall Interchange")
    val plannedJourneyTo: StateFlow<String> = _plannedJourneyTo.asStateFlow()

    private val _plannedJourneyOptions = MutableStateFlow<List<JourneyOption>>(emptyList())
    val plannedJourneyOptions: StateFlow<List<JourneyOption>> = _plannedJourneyOptions.asStateFlow()

    private val _isPlanningLoading = MutableStateFlow(false)
    val isPlanningLoading: StateFlow<Boolean> = _isPlanningLoading.asStateFlow()

    // --- Subscription TravelSY+ ---
    private val _isSubscribedToSYPlus = MutableStateFlow(false)
    val isSubscribedToSYPlus: StateFlow<Boolean> = _isSubscribedToSYPlus.asStateFlow()

    // Active screen specific modes
    private val _activeExploreMode = MutableStateFlow("All") // All, Tourist, Event, Airport
    val activeExploreMode: StateFlow<String> = _activeExploreMode.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.prepopulateStatsIfNeeded()
            generateInitialLiveVehicles()
            startVehicleSimulation()
            // Generate some initial favorites if empty
            repository.allFavoriteJourneys.first().let {
                if (it.isEmpty()) {
                    repository.insertFavoriteJourney(
                        FavoriteJourneyEntity(
                            title = "Commute to Meadowhall",
                            fromLocation = "Sheffield Cathedral",
                            toLocation = "Meadowhall Interchange",
                            modes = "Supertram"
                        )
                    )
                    repository.insertFavoriteJourney(
                        FavoriteJourneyEntity(
                            title = "Weekend in Peak District",
                            fromLocation = "Sheffield Interchange",
                            toLocation = "Dore & Totley",
                            modes = "Train,Walk"
                        )
                    )
                }
            }
        }
    }

    // --- Actions ---

    fun setPlannedFrom(from: String) {
        _plannedJourneyFrom.value = from
    }

    fun setPlannedTo(to: String) {
        _plannedJourneyTo.value = to
    }

    fun setExploreMode(mode: String) {
        _activeExploreMode.value = mode
    }

    fun toggleSubscription() {
        _isSubscribedToSYPlus.value = !_isSubscribedToSYPlus.value
        viewModelScope.launch(Dispatchers.IO) {
            // Update stats when subscribing
            val current = travelStats.value ?: return@launch
            val updated = current.copy(
                pointsEarned = current.pointsEarned + 100,
                moneySaved = current.moneySaved + 25.0
            )
            repository.updateTravelStats(updated)
        }
    }

    fun selectVehicle(vehicle: LiveVehicle?) {
        _selectedVehicle.value = vehicle
    }

    // Smart Journey Planner generator
    fun calculateJourney() {
        viewModelScope.launch {
            _isPlanningLoading.value = true
            delay(1500) // Realistic loading sensation

            val from = _plannedJourneyFrom.value
            val to = _plannedJourneyTo.value

            val options = listOf(
                JourneyOption(
                    id = "fastest",
                    type = "Fastest Route ⚡",
                    durationMins = 16,
                    costGbp = 2.80,
                    co2SavedKg = 2.4,
                    steps = listOf(
                        JourneyStep("Walk", "Walk from $from to Sheffield Station", 4, "directions_walk"),
                        JourneyStep("Train", "Northern Rail (Platform 3B) towards Leeds", 6, "train"),
                        JourneyStep("Walk", "Arrive at $to", 6, "directions_walk")
                    )
                ),
                JourneyOption(
                    id = "cheapest",
                    type = "Cheapest Route 🎟",
                    durationMins = 28,
                    costGbp = 2.00,
                    co2SavedKg = 1.8,
                    steps = listOf(
                        JourneyStep("Walk", "Walk to nearest Bus Stop", 5, "directions_walk"),
                        JourneyStep("Bus", "First Bus 120 towards Rotherham", 18, "directions_bus"),
                        JourneyStep("Walk", "Arrive at $to", 5, "directions_walk")
                    )
                ),
                JourneyOption(
                    id = "greenest",
                    type = "Greenest Route 🌿",
                    durationMins = 24,
                    costGbp = 2.80,
                    co2SavedKg = 3.6,
                    steps = listOf(
                        JourneyStep("Walk", "Walk to nearest Supertram Station", 6, "directions_walk"),
                        JourneyStep("Tram", "Supertram (Yellow Line) towards Meadowhall", 14, "tram"),
                        JourneyStep("Walk", "Arrive at $to", 4, "directions_walk")
                    )
                ),
                JourneyOption(
                    id = "step_free",
                    type = "Step-Free Route ♿",
                    durationMins = 24,
                    costGbp = 2.80,
                    co2SavedKg = 3.2,
                    steps = listOf(
                        JourneyStep("Walk", "Walk via ramp to Cathedral Tram Stop", 8, "accessible"),
                        JourneyStep("Tram", "Stagecoach Supertram (Purple Line) - Low Floor Car", 12, "tram"),
                        JourneyStep("Walk", "Arrive at $to (Step-free Interchange)", 4, "accessible")
                    )
                ),
                JourneyOption(
                    id = "scenic",
                    type = "Scenic Peak View ⛰",
                    durationMins = 45,
                    costGbp = 4.50,
                    co2SavedKg = 1.2,
                    steps = listOf(
                        JourneyStep("Walk", "Walk through Yorkshire stone streets", 10, "landscape"),
                        JourneyStep("Bus", "TM Travel 218 Peak Line", 30, "directions_bus"),
                        JourneyStep("Walk", "Walk along rural pathway to $to", 5, "directions_walk")
                    )
                )
            )

            _plannedJourneyOptions.value = options
            _isPlanningLoading.value = false
        }
    }

    // Purchase tickets directly
    fun purchaseTicket(type: String, title: String, price: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val ticket = TicketEntity(
                type = type,
                title = title,
                price = price,
                qrCodeData = "TRAVEL-SY-AUTH-${Random.nextInt(100000, 999999)}",
                expiryTimestamp = System.currentTimeMillis() + (24 * 60 * 60 * 1000) // 1 day validity
            )
            repository.insertTicket(ticket)

            // Update user stats
            val currentStats = travelStats.value ?: TravelStatsEntity(co2Saved = 0.0, carJourneysAvoided = 0, caloriesWalked = 0.0, cyclingDistance = 0.0, moneySaved = 0.0, pointsEarned = 0)
            val updated = currentStats.copy(
                pointsEarned = currentStats.pointsEarned + (price * 10).toInt(),
                co2Saved = currentStats.co2Saved + 1.8,
                carJourneysAvoided = currentStats.carJourneysAvoided + 1
            )
            repository.updateTravelStats(updated)
        }
    }

    // Submit user community report
    fun submitReport(vehicleType: String, vehicleNo: String, reportType: String, desc: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val report = CommunityReportEntity(
                vehicleType = vehicleType,
                vehicleNumber = vehicleNo,
                reportType = reportType,
                description = desc
            )
            repository.insertCommunityReport(report)

            // Reward passenger for helping the community!
            val currentStats = travelStats.value ?: TravelStatsEntity(co2Saved = 0.0, carJourneysAvoided = 0, caloriesWalked = 0.0, cyclingDistance = 0.0, moneySaved = 0.0, pointsEarned = 0)
            val updated = currentStats.copy(
                pointsEarned = currentStats.pointsEarned + 15
            )
            repository.updateTravelStats(updated)
        }
    }

    // Save planned journey to favorites
    fun saveJourneyToFavorites() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertFavoriteJourney(
                FavoriteJourneyEntity(
                    title = "Saved Route: ${_plannedJourneyFrom.value} to ${_plannedJourneyTo.value}",
                    fromLocation = _plannedJourneyFrom.value,
                    toLocation = _plannedJourneyTo.value,
                    modes = "Multimodal"
                )
            )
        }
    }

    // AI Chat Assistant call
    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val currentHistory = _chatMessages.value
        _chatMessages.value = currentHistory + (text to true)

        viewModelScope.launch {
            _assistantUiState.value = AssistantUiState.Loading

            // Create history list for conversational context
            val history = currentHistory
                .filter { it.first != "Hello! I am your Travel South Yorkshire AI assistant. Ask me anything about routes, fares, buses, trams, or booking a taxi." }
                .map { it.first to !it.second } // True was user, match formatting of pair
                .map { it.first to if (it.second) "User" else "Assistant" } // Map helper
            
            // Format to list of Pair(Query, Response)
            val historyPairs = mutableListOf<Pair<String, String>>()
            var i = 0
            while (i < currentHistory.size - 1) {
                if (currentHistory[i].second && !currentHistory[i+1].second) {
                    historyPairs.add(currentHistory[i].first to currentHistory[i+1].first)
                }
                i++
            }

            try {
                val reply = RetrofitGeminiClient.askAssistant(text, historyPairs)
                _chatMessages.value = _chatMessages.value + (reply to false)
                _assistantUiState.value = AssistantUiState.Success(reply)
            } catch (e: Exception) {
                val errorMsg = "Apologies, I encountered a connection issue. Please try again."
                _chatMessages.value = _chatMessages.value + (errorMsg to false)
                _assistantUiState.value = AssistantUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            "Hello! I am your Travel South Yorkshire AI assistant. Ask me anything about routes, fares, buses, trams, or booking a taxi." to false
        )
    }

    // --- Map Simulation ---

    private fun generateInitialLiveVehicles() {
        val list = listOf(
            LiveVehicle("1", "Tram", "Yellow Line", "Supertram", 0.2f, 0.3f, 0.2f, 0.3f, 0.002f, 0.001f, "Meadowhall", "High", vehicleNo = "Tram 120"),
            LiveVehicle("2", "Tram", "Blue Line", "Supertram", 0.5f, 0.4f, 0.5f, 0.4f, -0.001f, 0.002f, "Malin Bridge", "Low", vehicleNo = "Tram 104"),
            LiveVehicle("3", "Bus", "120", "First Bus", 0.3f, 0.6f, 0.3f, 0.6f, 0.003f, -0.002f, "Halfway", "Medium", vehicleNo = "Bus F12"),
            LiveVehicle("4", "Bus", "95", "Stagecoach", 0.7f, 0.2f, 0.7f, 0.2f, -0.002f, -0.001f, "Walkley", "Low", vehicleNo = "Bus S95"),
            LiveVehicle("5", "Train", "Regional Express", "Northern", 0.1f, 0.8f, 0.1f, 0.8f, 0.004f, 0.004f, "Doncaster", "Medium", vehicleNo = "Train 158"),
            LiveVehicle("6", "Taxi", "City Cabs", "City Cabs", 0.4f, 0.5f, 0.4f, 0.5f, -0.003f, 0.003f, "Sheffield City Centre", "Low", vehicleNo = "Taxi 55"),
            LiveVehicle("7", "Bike", "E-Bike 204", "SY Bike Hire", 0.6f, 0.7f, 0.6f, 0.7f, 0.0f, 0.0f, "Interchange Station", "Low", vehicleNo = "Bike 204"),
            LiveVehicle("8", "Train", "National Rail", "LNER", 0.8f, 0.1f, 0.8f, 0.1f, -0.005f, 0.005f, "London King's Cross", "High", vehicleNo = "Train 225")
        )
        _liveVehicles.value = list
    }

    private fun startVehicleSimulation() {
        viewModelScope.launch {
            while (true) {
                delay(100) // 10fps map update rate for seamless smoothness
                val currentList = _liveVehicles.value
                val updatedList = currentList.map { vehicle ->
                    // Update coordinates with simple rebounding logic
                    var nextX = vehicle.currentX + vehicle.speedX
                    var nextY = vehicle.currentY + vehicle.speedY

                    // Rebound boundaries
                    var speedX = vehicle.speedX
                    var speedY = vehicle.speedY

                    if (nextX < 0.05f || nextX > 0.95f) {
                        speedX = -speedX
                        nextX = vehicle.currentX + speedX
                    }
                    if (nextY < 0.05f || nextY > 0.95f) {
                        speedY = -speedY
                        nextY = vehicle.currentY + speedY
                    }

                    vehicle.copy(
                        currentX = nextX,
                        currentY = nextY,
                        speedX = speedX,
                        speedY = speedY
                    )
                }
                _liveVehicles.value = updatedList

                // Synchronize selected vehicle detail box if visible
                val selected = _selectedVehicle.value
                if (selected != null) {
                    val matching = updatedList.firstOrNull { it.id == selected.id }
                    if (matching != null) {
                        _selectedVehicle.value = matching
                    }
                }
            }
        }
    }
}
