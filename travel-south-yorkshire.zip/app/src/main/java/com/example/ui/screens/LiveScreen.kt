package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChargingStation
import androidx.compose.material.icons.outlined.LocalParking
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TravelViewModel
import com.example.ui.components.InteractiveSouthYorkshireMap
import com.example.ui.components.VehicleDetailCard

data class ParkRideSpot(
    val name: String,
    val spaces: String,
    val chargingPoints: Int,
    val price: String
)

data class BikeStation(
    val name: String,
    val availableBikes: Int,
    val type: String,
    val distance: String
)

@Composable
fun LiveScreen(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val vehicles by viewModel.liveVehicles.collectAsState()
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()

    var showBookingToast by remember { mutableStateOf<String?>(null) }
    var activeSubTab by remember { mutableStateOf("Map") } // Map, Park & Ride, Bikes

    val parkAndRideSpots = listOf(
        ParkRideSpot("Meadowhall Interchange", "240 / 400 Free Spaces", 12, "Free with Tram Ticket"),
        ParkRideSpot("Nunnery Square (Supertram)", "180 / 300 Spaces", 8, "£4.50 combined fare"),
        ParkRideSpot("Hillsborough Park & Ride", "85 / 120 Spaces", 4, "£4.00 combined fare"),
        ParkRideSpot("Middlewood (Supertram)", "150 / 220 Spaces", 6, "Free with weekly pass")
    )

    val bikeStations = listOf(
        BikeStation("Sheffield Cathedral Plaza", 8, "E-Bikes + Manual", "2 mins walk"),
        BikeStation("Meadowhall South Siding", 12, "E-Bikes only", "5 mins walk"),
        BikeStation("Barnsley Interchange Gate 3", 5, "Manual only", "4 mins walk"),
        BikeStation("Rotherham Central Siding", 6, "E-Bikes + Manual", "3 mins walk")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
    ) {
        // Upper Sub-tab headers
        TabRow(
            selectedTabIndex = when (activeSubTab) {
                "Map" -> 0
                "Park & Ride" -> 1
                else -> 2
            },
            containerColor = Color.White,
            contentColor = Color(0xFF1B365D)
        ) {
            Tab(
                selected = activeSubTab == "Map",
                onClick = { activeSubTab = "Map" },
                text = { Text("Live Tracking Map 🗺", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeSubTab == "Park & Ride",
                onClick = { activeSubTab = "Park & Ride" },
                text = { Text("Park & Ride 🚗", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeSubTab == "Bikes",
                onClick = { activeSubTab = "Bikes" },
                text = { Text("Hire Bikes 🚴", fontWeight = FontWeight.Bold) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeSubTab) {
                "Map" -> {
                    MapTabContent(
                        vehicles = vehicles,
                        selectedVehicle = selectedVehicle,
                        onVehicleSelected = { viewModel.selectVehicle(it) },
                        onBookTaxi = { lineName ->
                            showBookingToast = "🚖 Dispatching $lineName to your coordinates! Driver: Dave (ID: SY-776) arriving in 4 mins."
                            viewModel.purchaseTicket("Taxi", "$lineName Taxi fare", 8.50)
                        },
                        onClose = { viewModel.selectVehicle(null) }
                    )
                }

                "Park & Ride" -> {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "South Yorkshire Park & Ride",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B365D)
                        )
                        Text(
                            text = "Live parking counts, charging points & integrated pricing",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        parkAndRideSpots.forEach { spot ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = Color(0xFF1B365D).copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.size(44.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Outlined.LocalParking, contentDescription = null, tint = Color(0xFF1B365D))
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(spot.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                            Text(spot.spaces, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                                Icon(Icons.Outlined.ChargingStation, contentDescription = null, tint = Color(0xFFFF6D00), modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("${spot.chargingPoints} EV Chargers", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                            }
                                        }
                                    }

                                    Surface(
                                        color = Color(0xFFE2E8F0),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = spot.price,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "Bikes" -> {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "SY Bike & E-Bike Hire",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B365D)
                        )
                        Text(
                            text = "Locate and unlock micro-mobility docks in-app instantly",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        bikeStations.forEach { station ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = Color(0xFF00B4D8).copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.size(44.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.DirectionsBike, contentDescription = null, tint = Color(0xFF00B4D8))
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(station.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                            Text("${station.availableBikes} Bikes Available", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold)
                                            Text("${station.type} · ${station.distance}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            showBookingToast = "🚴 Bike unlocked! Code: ${varCode()}. Grab your helmet and travel safely."
                                            viewModel.purchaseTicket("Bike Hire", "E-Bike Unlock at ${station.name}", 2.00)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B4D8))
                                    ) {
                                        Icon(Icons.Outlined.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Unlock", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Booking notification alert
    if (showBookingToast != null) {
        AlertDialog(
            onDismissRequest = { showBookingToast = null },
            confirmButton = {
                TextButton(onClick = { showBookingToast = null }) {
                    Text("OK, Safe Travel!")
                }
            },
            title = {
                Text("Booking Successful!", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
            },
            text = {
                Text(showBookingToast ?: "", style = MaterialTheme.typography.bodyMedium)
            }
        )
    }
}

private fun varCode(): String {
    return (1000..9999).random().toString()
}

@Composable
fun MapTabContent(
    vehicles: List<com.example.ui.LiveVehicle>,
    selectedVehicle: com.example.ui.LiveVehicle?,
    onVehicleSelected: (com.example.ui.LiveVehicle?) -> Unit,
    onBookTaxi: (String) -> Unit,
    onClose: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        InteractiveSouthYorkshireMap(
            vehicles = vehicles,
            selectedVehicle = selectedVehicle,
            onVehicleSelected = onVehicleSelected,
            modifier = Modifier.fillMaxSize()
        )

        // Overlay vehicle inspector bottom-card
        androidx.compose.animation.AnimatedVisibility(
            visible = selectedVehicle != null,
            enter = androidx.compose.animation.slideInVertically(initialOffsetY = { it }),
            exit = androidx.compose.animation.slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .testTag("vehicle_detail_overlay")
        ) {
            selectedVehicle?.let { v ->
                VehicleDetailCard(
                    vehicle = v,
                    onClose = onClose,
                    onBookTaxi = { onBookTaxi(v.lineName) }
                )
            }
        }
    }
}
