package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onStart

class TravelRepository(private val travelDao: TravelDao) {

    val allTickets: Flow<List<TicketEntity>> = travelDao.getAllTickets()
    val allFavoriteJourneys: Flow<List<FavoriteJourneyEntity>> = travelDao.getAllFavoriteJourneys()
    val allCommunityReports: Flow<List<CommunityReportEntity>> = travelDao.getAllCommunityReports()
    val travelStats: Flow<TravelStatsEntity?> = travelDao.getTravelStats()

    suspend fun insertTicket(ticket: TicketEntity) {
        travelDao.insertTicket(ticket)
    }

    suspend fun deleteTicket(id: Int) {
        travelDao.deleteTicket(id)
    }

    suspend fun insertFavoriteJourney(journey: FavoriteJourneyEntity) {
        travelDao.insertFavoriteJourney(journey)
    }

    suspend fun deleteFavoriteJourney(id: Int) {
        travelDao.deleteFavoriteJourney(id)
    }

    suspend fun insertCommunityReport(report: CommunityReportEntity) {
        travelDao.insertCommunityReport(report)
    }

    suspend fun updateTravelStats(stats: TravelStatsEntity) {
        travelDao.insertTravelStats(stats)
    }

    suspend fun prepopulateStatsIfNeeded() {
        // Prepopulate default stats on startup if they don't exist
        val defaultStats = TravelStatsEntity(
            id = 1,
            co2Saved = 124.5,
            carJourneysAvoided = 42,
            caloriesWalked = 5820.0,
            cyclingDistance = 18.2,
            moneySaved = 154.20,
            pointsEarned = 340
        )
        travelDao.insertTravelStats(defaultStats)
    }
}
