package com.example.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

// 1. Ticket Entity
@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String,          // Bus, Tram, Train, Subscription
    val title: String,         // e.g. "Sheffield DayRider", "TravelSY+ Monthly"
    val price: Double,
    val qrCodeData: String,    // Simulated QR content
    val purchaseTimestamp: Long = System.currentTimeMillis(),
    val expiryTimestamp: Long,
    val status: String = "Active" // Active, Used, Expired
)

// 2. Favorite Journey Entity
@Entity(tableName = "favorite_journeys")
data class FavoriteJourneyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val fromLocation: String,
    val toLocation: String,
    val modes: String          // Comma-separated list (e.g. "Walk,Supertram,Train")
)

// 3. Community Report Entity
@Entity(tableName = "community_reports")
data class CommunityReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleType: String,   // Bus, Tram, Train, Station
    val vehicleNumber: String, // e.g. "Bus 120", "Tram 104"
    val reportType: String,    // Crowding, Cleanliness, Broken Machine, Delay, Accessibility
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Reported" // Reported, Under Review, Resolved
)

// 4. Travel Stats Entity (Sustainability & Rewards)
@Entity(tableName = "travel_stats")
data class TravelStatsEntity(
    @PrimaryKey val id: Int = 1, // Single row for user stats
    val co2Saved: Double,        // In kg
    val carJourneysAvoided: Int,
    val caloriesWalked: Double,
    val cyclingDistance: Double, // In km
    val moneySaved: Double,      // In GBP
    val pointsEarned: Int
)

// --- DAOs ---

@Dao
interface TravelDao {
    // Tickets
    @Query("SELECT * FROM tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("DELETE FROM tickets WHERE id = :id")
    suspend fun deleteTicket(id: Int)

    // Favorite Journeys
    @Query("SELECT * FROM favorite_journeys ORDER BY id DESC")
    fun getAllFavoriteJourneys(): Flow<List<FavoriteJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteJourney(journey: FavoriteJourneyEntity)

    @Query("DELETE FROM favorite_journeys WHERE id = :id")
    suspend fun deleteFavoriteJourney(id: Int)

    // Community Reports
    @Query("SELECT * FROM community_reports ORDER BY timestamp DESC")
    fun getAllCommunityReports(): Flow<List<CommunityReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommunityReport(report: CommunityReportEntity)

    // Travel Stats
    @Query("SELECT * FROM travel_stats WHERE id = 1 LIMIT 1")
    fun getTravelStats(): Flow<TravelStatsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTravelStats(stats: TravelStatsEntity)
}
