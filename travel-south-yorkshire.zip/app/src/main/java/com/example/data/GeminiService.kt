package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object RetrofitGeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    suspend fun askAssistant(prompt: String, chatHistory: List<Pair<String, String>> = emptyList()): String {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // If the key is empty or is a placeholder, use our local mock transport assistant
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return generateLocalFallbackResponse(prompt)
        }

        val systemPrompt = """
            You are Travel South Yorkshire's official AI Travel Assistant.
            You are polite, smart, and help passengers plan journeys, find transit, and book taxis.
            
            Keep your answers brief and focused. Emphasize South Yorkshire transit modes: 
            - Supertram (tram services across Sheffield/Rotherham)
            - Buses (First, Stagecoach, TM Travel)
            - Regional rail (Sheffield, Meadowhall, Chapeltown, Rotherham, Barnsley, Doncaster)
            - Taxi Bookings (local operators, cash/card in app)
            - Active Travel (walking, cycling, bike hire)
            
            Give concrete times, platforms, or pricing estimates in £. 
            If asked to "book me a taxi", explain that you can book it right now via the App's Live tab or Taxi section.
        """.trimIndent()

        // Construct history contents
        val contentsList = mutableListOf<GeminiContent>()
        for (turn in chatHistory) {
            contentsList.add(GeminiContent(parts = listOf(GeminiPart(text = turn.first)))) // User
            contentsList.add(GeminiContent(parts = listOf(GeminiPart(text = turn.second)))) // Assistant
        }
        contentsList.add(GeminiContent(parts = listOf(GeminiPart(text = prompt)))) // Current prompt

        val requestBody = GeminiRequest(
            contents = contentsList,
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt)))
        )

        return try {
            val response = service.generateContent(apiKey, requestBody)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "I couldn't generate a response. Please check back shortly."
        } catch (e: Exception) {
            // Fallback in case of networking issues
            generateLocalFallbackResponse(prompt)
        }
    }

    private fun generateLocalFallbackResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("meadowhall") -> {
                "🚋 **Fastest Route to Meadowhall (Sheffield):**\n\nTake the **Supertram (Yellow Line)** directly from Sheffield City Centre (Cathedral or Fitzalan Square) towards Meadowhall Interchange.\n\n⏱ **Travel Time:** ~18 mins\n🎟 **Cost:** £2.80 single / capped daily.\n🚍 **Alternative:** Stagecoach Bus 120 or First Bus 95 or Northern Rail train (only 6 mins from Sheffield Station)."
            }
            lower.contains("taxi") || lower.contains("book") -> {
                "🚖 **Taxi Booking & Integration:**\n\nI can certainly arrange that for you! You can book a local licensed private hire or taxi directly from the **Live** tab inside this app. \n\nWe support cashless Payments, estimated fares, wheelchair-accessible vehicle options, and real-time GPS tracking. Fares start at £5.50 for short journeys."
            }
            lower.contains("doncaster") -> {
                "🚆 **Sheffield to Doncaster Commute:**\n\n- **Regional Train (Northern Rail / TransPennine Express):** Direct services run every 10-15 minutes.\n  ⏱ **Duration:** 25 mins\n  🎟 **Cost:** £6.40 single\n- **Bus:** First Bus X78 via Rotherham (slower, ~1h 15m, cheaper and scenic)."
            }
            lower.contains("chatsworth") || lower.contains("peak district") -> {
                "⛰ **Peak District Gateways - Chatsworth House:**\n\nTake the **Peak Line Bus 218** (operated by TM Travel) from Sheffield Interchange directly to Chatsworth House gates. \n\n⏱ **Duration:** ~45 mins of scenic travel.\n🎟 **Cost:** £2.00 single (national fare cap applies) or use the **Peak District Explorer Pass** available in the tickets tab!"
            }
            lower.contains("commute") || lower.contains("tomorrow") -> {
                "📅 **Commute Planner for Tomorrow:**\n\nYour saved route (*Commute to Meadowhall*) has no active disruptions tomorrow.\n\n- **Supertram Yellow Line** is running every 10 minutes.\n- Weather is forecast as **Partly Cloudy (18°C)** with gentle breeze. Ideal for walking to the stop!"
            }
            lower.contains("avoid buses") -> {
                "🚋 **Bus-Free Route Selection Active:**\n\nGot it! I will filter all journey options to prefer **Supertram** and **Regional Trains** for your travel. You can also view nearby bike hire spots and local taxis."
            }
            else -> {
                "👋 **Welcome to Travel South Yorkshire Assistant!**\n\nI am your unified AI mobility companion. Ask me anything about:\n• 🚋 **Supertram** yellow/blue/purple routes\n• 🚌 **Bus routes** (120, 95, X78, etc.)\n• 🚆 **Rail platform and delays**\n• 🚖 **Book taxis** & comparison\n• 🎟 **TravelSY+ subscriptions** & tickets\n\n*Try asking: 'What is the quickest way to Meadowhall?' or 'Tell me about the Peak District Pass.'*"
            }
        }
    }
}
