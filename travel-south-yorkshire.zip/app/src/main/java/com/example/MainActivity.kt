package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.TravelViewModel
import com.example.ui.screens.*
import com.example.ui.theme.TravelSouthYorkshireTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TravelSouthYorkshireTheme {
                val travelViewModel: TravelViewModel = viewModel()
                TravelSouthYorkshireApp(viewModel = travelViewModel)
            }
        }
    }
}

@Composable
fun TravelSouthYorkshireApp(
    viewModel: TravelViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.selectedTab.collectAsState()

    val tabs = listOf(
        Triple("Home", Icons.Default.Home, "tab_home"),
        Triple("Journey", Icons.Default.Route, "tab_journey"),
        Triple("Live Map", Icons.Default.MyLocation, "tab_live"),
        Triple("Tickets", Icons.Default.ConfirmationNumber, "tab_tickets"),
        Triple("Explore", Icons.Default.Explore, "tab_explore"),
        Triple("Account", Icons.Default.AccountCircle, "tab_account")
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                contentColor = Color(0xFF1B365D),
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier.testTag("app_navigation_bar")
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = currentTab == index,
                        onClick = { viewModel.selectTab(index) },
                        icon = {
                            Icon(
                                imageVector = tab.second,
                                contentDescription = tab.first
                            )
                        },
                        label = {
                            Text(
                                text = tab.first,
                                fontWeight = if (currentTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF1B365D),
                            selectedTextColor = Color(0xFF1B365D),
                            indicatorColor = Color(0xFFDBEAFE), // Light blue active pill
                            unselectedIconColor = Color(0xFF64748B),
                            unselectedTextColor = Color(0xFF64748B)
                        ),
                        modifier = Modifier.testTag(tab.third)
                    )
                }
            }
        }
    ) { innerPadding ->
        val screenModifier = Modifier.padding(innerPadding)
        when (currentTab) {
            0 -> HomeScreen(viewModel = viewModel, modifier = screenModifier)
            1 -> JourneyScreen(viewModel = viewModel, modifier = screenModifier)
            2 -> LiveScreen(viewModel = viewModel, modifier = screenModifier)
            3 -> TicketsScreen(viewModel = viewModel, modifier = screenModifier)
            4 -> ExploreScreen(viewModel = viewModel, modifier = screenModifier)
            5 -> AccountScreen(viewModel = viewModel, modifier = screenModifier)
        }
    }
}
