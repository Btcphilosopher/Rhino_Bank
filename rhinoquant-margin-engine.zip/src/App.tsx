/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Quantitative Profit Margin Intelligence & Optimisation Platform
 * Theme: Sophisticated Dark (#0A0A0A / #0E0E0E / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { OverviewModule } from './components/modules/OverviewModule';
import { RevenueModule } from './components/modules/RevenueModule';
import { CostAllocationModule } from './components/modules/CostAllocationModule';
import { MarginsModule } from './components/modules/MarginsModule';
import { ProfitabilityModule } from './components/modules/ProfitabilityModule';
import { PricingModule } from './components/modules/PricingModule';
import { ProjectFinanceModule } from './components/modules/ProjectFinanceModule';
import { ScenariosModule } from './components/modules/ScenariosModule';
import { OptimisationModule } from './components/modules/OptimisationModule';
import { MonteCarloModule } from './components/modules/MonteCarloModule';
import { SensitivityModule } from './components/modules/SensitivityModule';
import { BenchmarksModule } from './components/modules/BenchmarksModule';
import { LeakageOpportunityModule } from './components/modules/LeakageOpportunityModule';
import { RConsoleModule } from './components/modules/RConsoleModule';
import { ReportingModule } from './components/modules/ReportingModule';

import { DEMO_BUSINESS_UNITS } from './engine/demoData';
import { calculateCompanyMetrics, runNonLinearOptimiser } from './engine/quantEngine';
import { ScenarioType, CurrencyCode, AllocationMethod, OptimisationConfig } from './types';
import { SCENARIO_PRESETS } from './engine/demoData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [currency, setCurrency] = useState<CurrencyCode>('GBP');
  const [activeScenario, setActiveScenario] = useState<ScenarioType>('base');
  const [seed, setSeed] = useState<number>(42);
  const [allocationMethod, setAllocationMethod] = useState<AllocationMethod>('activity');

  const bus = DEMO_BUSINESS_UNITS;

  // Active scenario definition
  const currentScenarioDef = SCENARIO_PRESETS.find(s => s.id === activeScenario) || SCENARIO_PRESETS[0];

  // Currency multiplier (simplified FX rate for view)
  const fxMultiplier = currency === 'USD' ? 1.28 : currency === 'EUR' ? 1.18 : 1.0;
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  // Real-time calculation of core company metrics
  const metrics = calculateCompanyMetrics(bus, allocationMethod, fxMultiplier, currentScenarioDef);

  // Real-time non-linear optimization calculation
  const optConfig: OptimisationConfig = {
    objective: 'max_profit',
    alphaProfit: 1.0,
    betaEbitdaMargin: 0.5,
    gammaRoic: 0.2,
    deltaRisk: 0.1,
    minEbitdaMargin: 0.22,
    maxPriceIncreasePct: 0.15,
    minVolumeRetentionPct: 0.85,
    maxCapacityUtilisation: 0.95,
    maxCapexLimit: 50.0
  };

  const optimisation = runNonLinearOptimiser(bus, optConfig);

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-gray-300 flex flex-col font-sans selection:bg-[#D4AF37]/30 selection:text-[#D4AF37]">
      {/* Top Institutional Header and Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        activeScenario={activeScenario}
        setActiveScenario={setActiveScenario}
        seed={seed}
        setSeed={setSeed}
      />

      {/* Top Institutional Header Metric Strip (Directly matching Sophisticated Dark Spec) */}
      <section className="border-b border-[#262626] bg-[#0E0E0E]/80 backdrop-blur-sm px-4 lg:px-6 py-3">
        <div className="max-w-[1720px] mx-auto flex flex-wrap items-center justify-between gap-6">
          <div className="flex flex-wrap items-center gap-8 lg:gap-12">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">Gross Revenue (FY25)</span>
              <span className="text-xl lg:text-2xl font-light text-white tracking-tight font-mono">
                {sym}{metrics.revenue.toFixed(1)}m
              </span>
            </div>

            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">EBITDA Margin</span>
              <span className="text-xl lg:text-2xl font-light text-white tracking-tight font-mono">
                {(metrics.ebitdaMargin * 100).toFixed(2)}%
              </span>
            </div>

            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">Net Contribution</span>
              <span className="text-xl lg:text-2xl font-light text-white tracking-tight font-mono">
                {sym}{metrics.contributionProfit.toFixed(1)}m
              </span>
            </div>

            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">Return on Capital</span>
              <span className="text-xl lg:text-2xl font-light text-white tracking-tight font-mono">
                {(metrics.roic * 100).toFixed(1)}%
              </span>
            </div>

            <div className="hidden sm:flex flex-col border-l border-[#262626] pl-6 lg:pl-10">
              <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">Rhino Margin Score</span>
              <div className="flex items-end gap-2">
                <span className="text-2xl lg:text-3xl font-bold text-[#D4AF37] leading-none font-mono">78</span>
                <span className="text-[10px] text-[#D4AF37] uppercase mb-0.5 font-semibold font-mono tracking-wider">Optimal</span>
              </div>
            </div>
          </div>

          <div className="hidden xl:flex items-center gap-3 text-[11px] font-mono text-gray-500">
            <span className="px-2 py-1 bg-[#141414] border border-[#262626] rounded text-green-500">
              +£9.4m EBITDA UPSIDE IDENTIFIED
            </span>
          </div>
        </div>
      </section>

      {/* Main Analytical Stage */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-4 sm:p-6 space-y-6 bg-[#0A0A0A]">
        {activeTab === 'overview' && (
          <OverviewModule
            metrics={metrics}
            bus={bus}
            optimisation={optimisation}
            currency={currency}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'revenue' && (
          <RevenueModule bus={bus} currency={currency} />
        )}

        {activeTab === 'costs' && (
          <CostAllocationModule bus={bus} currency={currency} />
        )}

        {activeTab === 'margins' && (
          <MarginsModule metrics={metrics} bus={bus} currency={currency} />
        )}

        {activeTab === 'profitability' && (
          <ProfitabilityModule bus={bus} currency={currency} />
        )}

        {activeTab === 'pricing' && (
          <PricingModule bus={bus} currency={currency} />
        )}

        {activeTab === 'project' && (
          <ProjectFinanceModule currency={currency} />
        )}

        {activeTab === 'scenarios' && (
          <ScenariosModule
            bus={bus}
            currency={currency}
            activeScenario={activeScenario}
            setActiveScenario={setActiveScenario}
          />
        )}

        {activeTab === 'optimisation' && (
          <OptimisationModule
            optimisation={optimisation}
            bus={bus}
            currency={currency}
          />
        )}

        {activeTab === 'monte_carlo' && (
          <MonteCarloModule bus={bus} currency={currency} seed={seed} />
        )}

        {activeTab === 'sensitivity' && (
          <SensitivityModule bus={bus} currency={currency} />
        )}

        {activeTab === 'benchmarks' && (
          <BenchmarksModule metrics={metrics} currency={currency} />
        )}

        {activeTab === 'leakage' && (
          <LeakageOpportunityModule currency={currency} />
        )}

        {activeTab === 'r_console' && (
          <RConsoleModule />
        )}

        {activeTab === 'reports' && (
          <ReportingModule
            metrics={metrics}
            bus={bus}
            optimisation={optimisation}
            currency={currency}
          />
        )}
      </main>

      {/* Global Institutional Status Bar */}
      <footer className="border-t border-[#262626] bg-[#0E0E0E] px-4 lg:px-6 py-2.5 text-[11px] font-mono text-gray-500">
        <div className="max-w-[1720px] mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-gray-400">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
              RHINOQUANT R-ENGINE v4.2.1
            </span>
            <span className="hidden sm:inline text-[#262626]">|</span>
            <span className="hidden sm:inline text-gray-400">NLOPT_LD_SLSQP: CONVERGED</span>
            <span className="hidden md:inline text-[#262626]">|</span>
            <span className="hidden md:inline text-gray-400">KKT TOL: &lt; 1e-6</span>
          </div>

          <div className="flex items-center gap-4 text-gray-400">
            <span>MEM: 14.2 MB</span>
            <span>PRNG SEED: {seed}</span>
            <span className="text-[#D4AF37] font-semibold">ALL COVENANTS VERIFIED</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
