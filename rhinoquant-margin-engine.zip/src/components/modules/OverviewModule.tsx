/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 1: Executive Overview & Waterfall Cockpit
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  Sparkles, 
  Zap, 
  Layers, 
  DollarSign, 
  BarChart3, 
  ShieldAlert, 
  Sliders, 
  ChevronRight 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from 'recharts';
import { MarginMetrics, BusinessUnit, OptimisationResult, CurrencyCode } from '../../types';
import { RhinoScoreWidget } from '../RhinoScoreWidget';
import { calculateRhinoMarginScore } from '../../engine/quantEngine';
import { DEMO_CLIENTS } from '../../engine/demoData';

interface OverviewModuleProps {
  metrics: MarginMetrics;
  bus: BusinessUnit[];
  optimisation: OptimisationResult;
  currency: CurrencyCode;
  onNavigateTab: (tabId: string) => void;
}

export const OverviewModule: React.FC<OverviewModuleProps> = ({
  metrics,
  bus,
  optimisation,
  currency,
  onNavigateTab,
}) => {
  const score = calculateRhinoMarginScore(metrics, bus, DEMO_CLIENTS);

  const getCurrencySymbol = (curr: CurrencyCode) => {
    switch (curr) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'CHF': return 'CHF ';
      case 'JPY': return '¥';
      case 'CNY': return '¥';
      default: return '£';
    }
  };

  const sym = getCurrencySymbol(currency);

  // Profit Waterfall Data Structure
  const waterfallData = [
    { name: 'Gross Revenue', value: metrics.revenue, base: 0, delta: metrics.revenue, fill: '#D4AF37', type: 'total' },
    { name: 'Direct COGS', value: -metrics.cogs, base: metrics.revenue - metrics.cogs, delta: -metrics.cogs, fill: '#ef4444', type: 'cost' },
    { name: 'Direct Labour', value: -36.5, base: metrics.revenue - metrics.cogs - 36.5, delta: -36.5, fill: '#ef4444', type: 'cost' },
    { name: 'Variable Ops', value: -23.7, base: metrics.contributionProfit, delta: -23.7, fill: '#f87171', type: 'cost' },
    { name: 'Contribution', value: metrics.contributionProfit, base: 0, delta: metrics.contributionProfit, fill: '#D4AF37', type: 'subtotal' },
    { name: 'Overhead Costs', value: -42.8, base: metrics.ebitda, delta: -42.8, fill: '#ef4444', type: 'cost' },
    { name: 'EBITDA', value: metrics.ebitda, base: 0, delta: metrics.ebitda, fill: '#22c55e', type: 'total' },
    { name: 'D&A', value: -metrics.depreciationAmortisation, base: metrics.ebit, delta: -metrics.depreciationAmortisation, fill: '#d97706', type: 'cost' },
    { name: 'EBIT', value: metrics.ebit, base: 0, delta: metrics.ebit, fill: '#94a3b8', type: 'total' },
    { name: 'Financing', value: -metrics.netFinanceCost, base: metrics.ebit - metrics.netFinanceCost, delta: -metrics.netFinanceCost, fill: '#ef4444', type: 'cost' },
    { name: 'Tax', value: -metrics.tax, base: metrics.netProfit, delta: -metrics.tax, fill: '#64748b', type: 'cost' },
    { name: 'Net Profit', value: metrics.netProfit, base: 0, delta: metrics.netProfit, fill: '#D4AF37', type: 'total' }
  ];

  // Profit Attribution Bridge Data (matching Design HTML attribution chart style)
  const bridgeData = [
    { factor: 'Prior EBITDA', delta: 40.0, fill: '#4b5563' },
    { factor: 'Price Effect', delta: 4.1, fill: '#22c55e' },
    { factor: 'Volume Effect', delta: 2.8, fill: '#22c55e' },
    { factor: 'Product Mix', delta: 1.7, fill: '#22c55e' },
    { factor: 'Labour Inflation', delta: -1.2, fill: '#ef4444' },
    { factor: 'Energy & Power', delta: -0.6, fill: '#ef4444' },
    { factor: 'Overhead Eff.', delta: 0.9, fill: '#22c55e' },
    { factor: 'FX Conversion', delta: 0.5, fill: '#22c55e' },
    { factor: 'Current EBITDA', delta: 48.2, fill: '#D4AF37' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Rhino Margin Score Banner */}
      <RhinoScoreWidget scoreData={score} />

      {/* Primary Profit Opportunity Banner (Sophisticated Dark Grid Pattern) */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 lg:p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                PROFIT OPTIMISATION ENGINE
              </span>
              <span className="text-xs text-gray-500 font-mono">NLOPT_LD_SLSQP + Multi-variable Lagrangian</span>
            </div>
            
            <h2 className="text-xl lg:text-2xl font-light text-white mt-2 flex flex-wrap items-baseline gap-3 tracking-tight">
              <span>Potential Sustainable EBITDA Uplift:</span>
              <span className="text-2xl lg:text-3xl font-mono font-bold text-[#D4AF37]">
                +{sym}{optimisation.improvementEbitda.toFixed(1)}m
              </span>
              <span className="text-sm font-mono text-green-500 bg-green-950/40 px-2 py-0.5 rounded border border-green-800/60">
                +{optimisation.improvementEbitdaMarginDelta.toFixed(1)} pp Margin
              </span>
            </h2>

            <p className="text-xs text-gray-400 max-w-4xl mt-1.5 leading-relaxed font-sans">
              Based on empirical price elasticity regressions, unit contribution margins, and capacity constraints across 6 business units, RhinoQuant identifies an actionable EBITDA expansion from <strong className="text-gray-200">{sym}{optimisation.currentMetrics.ebitda.toFixed(1)}m ({(optimisation.currentMetrics.ebitdaMargin * 100).toFixed(1)}%)</strong> to <strong className="text-[#D4AF37]">{sym}{optimisation.optimisedMetrics.ebitda.toFixed(1)}m ({(optimisation.optimisedMetrics.ebitdaMargin * 100).toFixed(1)}%)</strong>.
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('optimisation')}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#D4AF37] hover:bg-[#c5a028] text-[#0A0A0A] font-semibold text-xs font-mono rounded tracking-wider transition-all shadow-lg shadow-[#D4AF37]/10 shrink-0 cursor-pointer"
          >
            <span>OPTIMISATION PLAN</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 5 Structural Pillars of Profit Improvement */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mt-5 pt-5 border-t border-[#262626]">
          <div className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">1. Price Optimisation</div>
            <div className="text-base font-mono font-bold text-[#D4AF37] mt-0.5">+{sym}{optimisation.breakdown.priceOptimisation.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-1">Inelastic mandates & AI pods</div>
          </div>

          <div className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">2. Cost Reduction</div>
            <div className="text-base font-mono font-bold text-gray-200 mt-0.5">+{sym}{optimisation.breakdown.costReduction.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-1">Turbine spares & power hedging</div>
          </div>

          <div className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">3. Capacity Allocation</div>
            <div className="text-base font-mono font-bold text-green-500 mt-0.5">+{sym}{optimisation.breakdown.capacityAllocation.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-1">Shift racks to high-margin AI</div>
          </div>

          <div className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">4. Client Mix</div>
            <div className="text-base font-mono font-bold text-[#D4AF37] mt-0.5">+{sym}{optimisation.breakdown.clientMix.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-1">Reprice 3 loss-making accounts</div>
          </div>

          <div className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">5. Leakage Reduction</div>
            <div className="text-base font-mono font-bold text-green-400 mt-0.5">+{sym}{optimisation.breakdown.leakageReduction.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-1">Eliminate off-tariff discounts</div>
          </div>
        </div>
      </div>

      {/* Key Executive KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Revenue</div>
          <div className="text-lg font-mono font-bold text-white mt-1">{sym}{metrics.revenue.toFixed(1)}m</div>
          <div className="text-[10px] text-green-500 font-mono flex items-center gap-0.5 mt-1">
            <ArrowUpRight className="w-3 h-3" /> +8.4% YoY
          </div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Gross Margin</div>
          <div className="text-lg font-mono font-bold text-gray-200 mt-1">{(metrics.grossMargin * 100).toFixed(1)}%</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">{sym}{metrics.grossProfit.toFixed(1)}m</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Contribution</div>
          <div className="text-lg font-mono font-bold text-gray-200 mt-1">{(metrics.contributionMargin * 100).toFixed(1)}%</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">{sym}{metrics.contributionProfit.toFixed(1)}m</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">EBITDA</div>
          <div className="text-lg font-mono font-bold text-[#D4AF37] mt-1">{sym}{metrics.ebitda.toFixed(1)}m</div>
          <div className="text-[10px] text-green-500 font-mono flex items-center gap-0.5 mt-1">
            <ArrowUpRight className="w-3 h-3" /> +20.5% vs Prior
          </div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">EBITDA Margin</div>
          <div className="text-lg font-mono font-bold text-[#D4AF37] mt-1">{(metrics.ebitdaMargin * 100).toFixed(1)}%</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">Target: 28.0%</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">EBIT</div>
          <div className="text-lg font-mono font-bold text-white mt-1">{sym}{metrics.ebit.toFixed(1)}m</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">{(metrics.ebitMargin * 100).toFixed(1)}% Mgn</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Net Profit</div>
          <div className="text-lg font-mono font-bold text-white mt-1">{sym}{metrics.netProfit.toFixed(1)}m</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">{(metrics.netMargin * 100).toFixed(1)}% Mgn</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg flex flex-col justify-between">
          <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">ROIC</div>
          <div className="text-lg font-mono font-bold text-[#D4AF37] mt-1">{(metrics.roic * 100).toFixed(1)}%</div>
          <div className="text-[10px] text-green-500 font-mono mt-1">Spread: +3.4%</div>
        </div>
      </div>

      {/* Interactive Charts: Profit Waterfall & Profit Attribution Bridge */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Waterfall Chart */}
        <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 flex flex-col justify-between shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold flex items-center gap-2">
                <BarChart3 className="w-3.5 h-3.5 text-[#D4AF37]" />
                Profit Waterfall Analysis ({currency}m)
              </h3>
              <p className="text-[10px] text-gray-500 mt-0.5">Complete margin decomposition from Gross Revenue to Net Economic Profit</p>
            </div>
            <button
              onClick={() => onNavigateTab('margins')}
              className="text-[10px] text-[#D4AF37] hover:underline font-mono uppercase tracking-wider"
            >
              Hierarchy →
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={waterfallData} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#525252" 
                  fontSize={10} 
                  interval={0} 
                  angle={-35} 
                  textAnchor="end" 
                />
                <YAxis stroke="#525252" fontSize={10} domain={[-60, 220]} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                          <div className="font-bold text-white">{data.name}</div>
                          <div className="text-[#D4AF37]">Impact: {data.delta > 0 ? `+${sym}` : `-${sym}`}{Math.abs(data.delta).toFixed(1)}m</div>
                          {data.type === 'cost' && <div className="text-gray-500 text-[10px]">Expense deduction</div>}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="delta" radius={[2, 2, 0, 0]}>
                  {waterfallData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Profit Attribution Bridge */}
        <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 flex flex-col justify-between shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-[#D4AF37]" />
                Unit Profitability Attribution Bridge ({sym}40.0m → {sym}48.2m)
              </h3>
              <p className="text-[10px] text-gray-500 mt-0.5">Quantitative multi-factor variance decomposition (+{sym}8.2m YoY expansion)</p>
            </div>
            <button
              onClick={() => onNavigateTab('pricing')}
              className="text-[10px] text-[#D4AF37] hover:underline font-mono uppercase tracking-wider"
            >
              Elasticity →
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={bridgeData} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis 
                  dataKey="factor" 
                  stroke="#525252" 
                  fontSize={10} 
                  interval={0} 
                  angle={-30} 
                  textAnchor="end" 
                />
                <YAxis stroke="#525252" fontSize={10} domain={[-5, 55]} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                          <div className="font-bold text-white">{data.factor}</div>
                          <div className="text-green-400">Variance: {data.delta > 0 ? `+${sym}` : `-${sym}`}{Math.abs(data.delta).toFixed(1)}m</div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="delta" radius={[2, 2, 0, 0]}>
                  {bridgeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Business Unit Performance Summary Table */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-[#262626] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Business Unit Profitability & Elasticity Matrix
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[#1A1A1A] text-gray-400 font-mono border border-[#262626]">
              6 Divisions
            </span>
          </div>
          <button
            onClick={() => onNavigateTab('profitability')}
            className="text-xs text-[#D4AF37] hover:underline font-mono font-medium flex items-center gap-1 cursor-pointer uppercase tracking-wider"
          >
            <span>Full Matrix</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-4">Business Unit</th>
                <th className="py-3 px-4">Sector</th>
                <th className="py-3 px-4 text-right">Revenue</th>
                <th className="py-3 px-4 text-right">Gross Mgn</th>
                <th className="py-3 px-4 text-right">Contrib. Mgn</th>
                <th className="py-3 px-4 text-right">EBITDA</th>
                <th className="py-3 px-4 text-right">EBITDA Mgn</th>
                <th className="py-3 px-4 text-right">Elasticity</th>
                <th className="py-3 px-4 text-right">Utilisation</th>
                <th className="py-3 px-4 text-right">ROIC</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {(bus || []).map((bu) => {
                const ebitda = bu.revenue - (bu.cogs + bu.directLabour + bu.variableOperatingCost + bu.fixedOverhead + bu.allocatedOverhead);
                const ebitdaMargin = bu.revenue > 0 ? ebitda / bu.revenue : 0;
                const grossMargin = bu.revenue > 0 ? (bu.revenue - bu.cogs) / bu.revenue : 0;
                const contribMargin = bu.revenue > 0 ? (bu.revenue - (bu.cogs + bu.directLabour + bu.variableOperatingCost)) / bu.revenue : 0;
                const roic = bu.capitalEmployed > 0 ? ((ebitda - bu.depreciationAmortisation) * 0.75) / bu.capitalEmployed : 0;

                return (
                  <tr key={bu.id} className="hover:bg-[#161616] transition-colors">
                    <td className="py-3 px-4 font-semibold text-white flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                      {bu.name}
                    </td>
                    <td className="py-3 px-4 text-gray-400 text-[11px]">{bu.sector}</td>
                    <td className="py-3 px-4 text-right font-semibold text-gray-100">{sym}{bu.revenue.toFixed(1)}m</td>
                    <td className="py-3 px-4 text-right text-gray-300">{(grossMargin * 100).toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right text-gray-300">{(contribMargin * 100).toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right font-bold text-[#D4AF37]">{sym}{ebitda.toFixed(1)}m</td>
                    <td className="py-3 px-4 text-right font-semibold text-[#D4AF37]">{(ebitdaMargin * 100).toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        Math.abs(bu.priceElasticity) < 1.0 
                          ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40' 
                          : 'bg-[#1A1A1A] text-gray-400 border border-[#333333]'
                      }`}>
                        {bu.priceElasticity.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-gray-300">{(bu.currentUtilisation * 100).toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right text-gray-200 font-semibold">{(roic * 100).toFixed(1)}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
