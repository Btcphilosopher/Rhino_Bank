/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 5: Division, Deal & Client Profitability Tiering
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  Briefcase, 
  Search
} from 'lucide-react';
import { BusinessUnit, ClientProfile, CurrencyCode } from '../../types';
import { DEMO_CLIENTS, DEMO_PRODUCTS } from '../../engine/demoData';

interface ProfitabilityModuleProps {
  bus: BusinessUnit[];
  currency: CurrencyCode;
}

export const ProfitabilityModule: React.FC<ProfitabilityModuleProps> = ({ bus, currency }) => {
  const [activeSubView, setActiveSubView] = useState<'clients' | 'products' | 'business_units'>('clients');
  const [clientSearch, setClientSearch] = useState('');
  const [tierFilter, setTierFilter] = useState('all');

  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  // Filter clients
  const clients = (DEMO_CLIENTS || []).filter(c => {
    if (tierFilter !== 'all' && c.classification !== tierFilter) return false;
    if (clientSearch && !c.name.toLowerCase().includes(clientSearch.toLowerCase()) && !c.sector.toLowerCase().includes(clientSearch.toLowerCase())) {
      return false;
    }
    return true;
  });

  const getClassificationBadge = (cls: ClientProfile['classification']) => {
    switch (cls) {
      case 'HIGH VALUE':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase">HIGH VALUE</span>;
      case 'PROFITABLE':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-green-950/60 text-green-400 border border-green-800 uppercase">PROFITABLE</span>;
      case 'BREAKEVEN':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#1A1A1A] text-gray-300 border border-[#333333] uppercase">BREAKEVEN</span>;
      case 'LOW MARGIN':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/60 text-amber-300 border border-amber-800 uppercase">LOW MARGIN</span>;
      case 'LOSS-MAKING':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950/60 text-rose-300 border border-rose-800 uppercase">LOSS-MAKING</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-view Navigation Bar */}
      <div className="flex items-center justify-between border-b border-[#262626] pb-4">
        <div className="flex items-center gap-2">
          {[
            { id: 'clients', label: 'CLIENT PROFITABILITY & RISK COSTS', icon: Users },
            { id: 'products', label: 'PRODUCT & CAPACITY CONTRIBUTION', icon: Briefcase },
            { id: 'business_units', label: 'BUSINESS UNIT DRILLDOWN', icon: Building2 }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeSubView === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubView(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded text-xs font-mono transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#D4AF37] text-[#0A0A0A] font-bold shadow-lg shadow-[#D4AF37]/10'
                    : 'bg-[#141414] text-gray-400 hover:text-gray-200 border border-[#262626]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sub-View 1: Client Profitability Ranking */}
      {activeSubView === 'clients' && (
        <div className="space-y-5">
          <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
            <div>
              <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold font-mono">
                Institutional Client Contribution & Capital Absorption Matrix
              </h3>
              <p className="text-xs text-gray-400 mt-1 font-sans">
                Full-absorption client analysis: Direct Costs + Allocated Corporate Overhead + Risk Cost + Funding Cost.
              </p>
            </div>

            {/* Filter controls */}
            <div className="flex items-center gap-3 text-xs font-mono">
              <div className="flex items-center gap-1.5 bg-[#0A0A0A] border border-[#262626] px-2.5 py-1 rounded">
                <Search className="w-3.5 h-3.5 text-gray-500" />
                <input
                  type="text"
                  placeholder="Search client / sector..."
                  value={clientSearch}
                  onChange={(e) => setClientSearch(e.target.value)}
                  className="bg-transparent text-gray-200 focus:outline-none w-40 text-xs"
                />
              </div>

              <select
                value={tierFilter}
                onChange={(e) => setTierFilter(e.target.value)}
                className="bg-[#0A0A0A] border border-[#262626] text-gray-300 px-2.5 py-1 rounded focus:outline-none cursor-pointer text-xs"
              >
                <option value="all">All Tiers</option>
                <option value="HIGH VALUE">High Value</option>
                <option value="PROFITABLE">Profitable</option>
                <option value="BREAKEVEN">Breakeven</option>
                <option value="LOSS-MAKING">Loss-Making</option>
              </select>
            </div>
          </div>

          <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                    <th className="py-3 px-4">Client Account</th>
                    <th className="py-3 px-4">Sector</th>
                    <th className="py-3 px-4 text-right">Revenue</th>
                    <th className="py-3 px-4 text-right">Direct Cost</th>
                    <th className="py-3 px-4 text-right">Allocated</th>
                    <th className="py-3 px-4 text-right">Capital Usage</th>
                    <th className="py-3 px-4 text-right">Funding/Risk</th>
                    <th className="py-3 px-4 text-right">Net Contrib.</th>
                    <th className="py-3 px-4 text-right">Margin %</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
                  {clients.map((c) => (
                    <tr key={c.id} className="hover:bg-[#161616] transition-colors">
                      <td className="py-3 px-4 font-semibold text-white">{c.name}</td>
                      <td className="py-3 px-4 text-gray-400 text-[11px]">{c.sector}</td>
                      <td className="py-3 px-4 text-right font-bold text-gray-100">{sym}{c.revenue.toFixed(1)}m</td>
                      <td className="py-3 px-4 text-right text-gray-400">{sym}{c.directCost.toFixed(1)}m</td>
                      <td className="py-3 px-4 text-right text-gray-400">{sym}{c.allocatedCost.toFixed(1)}m</td>
                      <td className="py-3 px-4 text-right text-gray-300">{sym}{c.capitalUsage.toFixed(1)}m</td>
                      <td className="py-3 px-4 text-right text-red-400">{sym}{(c.fundingCost + c.riskCost).toFixed(1)}m</td>
                      <td className={`py-3 px-4 text-right font-bold ${c.netContribution >= 0 ? 'text-[#D4AF37]' : 'text-red-400'}`}>
                        {c.netContribution >= 0 ? `+${sym}` : `-${sym}`}{Math.abs(c.netContribution).toFixed(1)}m
                      </td>
                      <td className={`py-3 px-4 text-right font-bold ${c.marginPercent >= 20 ? 'text-green-400' : c.marginPercent >= 0 ? 'text-[#D4AF37]' : 'text-red-400'}`}>
                        {c.marginPercent.toFixed(1)}%
                      </td>
                      <td className="py-3 px-4 text-center">
                        {getClassificationBadge(c.classification)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Sub-View 2: Product & Capacity Contribution */}
      {activeSubView === 'products' && (
        <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
          <div className="px-5 py-4 border-b border-[#262626] flex items-center justify-between">
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Product Unit Economics & Pricing Power Scores
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                  <th className="py-3 px-4">Product / Facility</th>
                  <th className="py-3 px-4 text-right">Unit Price</th>
                  <th className="py-3 px-4 text-right">Unit Cost</th>
                  <th className="py-3 px-4 text-right">Active Vol</th>
                  <th className="py-3 px-4 text-right">Revenue</th>
                  <th className="py-3 px-4 text-right">Gross Mgn</th>
                  <th className="py-3 px-4 text-right">Contrib. Mgn</th>
                  <th className="py-3 px-4 text-right">Elasticity</th>
                  <th className="py-3 px-4 text-right">Comp. Price</th>
                  <th className="py-3 px-4 text-right">Pricing Power</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
                {(DEMO_PRODUCTS || []).map((p) => (
                  <tr key={p.id} className="hover:bg-[#161616] transition-colors">
                    <td className="py-3 px-4 font-semibold text-white">{p.name}</td>
                    <td className="py-3 px-4 text-right font-mono text-gray-100">{sym}{p.price.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right text-gray-400">{sym}{p.unitCost.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right text-gray-300">{p.volume.toLocaleString()} {p.unitOfMeasure}</td>
                    <td className="py-3 px-4 text-right font-bold text-gray-100">{sym}{p.revenue.toFixed(1)}m</td>
                    <td className="py-3 px-4 text-right text-gray-300">{p.grossMarginPercent.toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right text-gray-200 font-semibold">{p.contributionMarginPercent.toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        Math.abs(p.elasticity) < 1.0 ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40' : 'bg-[#141414] text-gray-400 border border-[#262626]'
                      }`}>
                        {p.elasticity.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-gray-400">{sym}{p.competitorPrice.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right font-bold text-[#D4AF37]">{p.pricingPowerScore}/10</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-View 3: Business Unit Detailed Cards */}
      {activeSubView === 'business_units' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(bus || []).map((bu) => {
            const ebitda = bu.revenue - (bu.cogs + bu.directLabour + bu.variableOperatingCost + bu.fixedOverhead + bu.allocatedOverhead);
            const ebitdaMargin = bu.revenue > 0 ? (ebitda / bu.revenue) * 100 : 0;
            const roic = bu.capitalEmployed > 0 ? (((ebitda - bu.depreciationAmortisation) * 0.75) / bu.capitalEmployed) * 100 : 0;

            return (
              <div key={bu.id} className="p-5 bg-[#111111] border border-[#262626] rounded-lg space-y-3 shadow-xl">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-[#D4AF37] uppercase font-bold tracking-widest">{bu.code}</span>
                    <h4 className="text-sm font-bold text-white mt-0.5">{bu.name}</h4>
                    <p className="text-[11px] text-gray-400">{bu.sector}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-base font-mono font-bold text-[#D4AF37]">{sym}{ebitda.toFixed(1)}m</div>
                    <div className="text-[10px] text-gray-500 font-mono">{ebitdaMargin.toFixed(1)}% EBITDA Mgn</div>
                  </div>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed font-sans">{bu.description}</p>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-3 border-t border-[#262626]">
                  <div>
                    <span className="text-gray-500 text-[10px] uppercase tracking-widest block">Revenue:</span>
                    <span className="text-gray-100 font-bold">{sym}{bu.revenue.toFixed(1)}m</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] uppercase tracking-widest block">Capital Employed:</span>
                    <span className="text-gray-100 font-bold">{sym}{bu.capitalEmployed.toFixed(1)}m</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] uppercase tracking-widest block">ROIC:</span>
                    <span className="text-[#D4AF37] font-bold">{roic.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[10px] uppercase tracking-widest block">Utilisation:</span>
                    <span className="text-green-400 font-bold">{(bu.currentUtilisation * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
