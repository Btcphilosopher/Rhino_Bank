/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 3: Cost Classification & Dynamic Allocation Engine
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { 
  Scale
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';
import { BusinessUnit, AllocationMethod, CurrencyCode } from '../../types';
import { calculateAllocatedOverhead } from '../../engine/quantEngine';

interface CostAllocationModuleProps {
  bus: BusinessUnit[];
  currency: CurrencyCode;
}

export const CostAllocationModule: React.FC<CostAllocationModuleProps> = ({ bus, currency }) => {
  const [allocationMethod, setAllocationMethod] = useState<AllocationMethod>('activity');
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const totalSharedPool = 19.9; // £19.9m shared corporate overhead pool

  const safeBus = bus || [];

  // Total cost classifications across company
  const totalCOGS = safeBus.reduce((s, b) => s + b.cogs, 0); // 48.8
  const totalLabour = safeBus.reduce((s, b) => s + b.directLabour, 0); // 36.5
  const totalVarOps = safeBus.reduce((s, b) => s + b.variableOperatingCost, 0); // 23.7
  const totalFixedOverhead = safeBus.reduce((s, b) => s + b.fixedOverhead, 0); // 25.2
  const totalAllocatedOverhead = totalSharedPool; // 19.9
  const totalDepreciation = safeBus.reduce((s, b) => s + b.depreciationAmortisation, 0); // 14.7

  // Compute allocation comparison table
  const allocationComparison = safeBus.map(bu => {
    const revWeighted = calculateAllocatedOverhead(bu, safeBus, 'revenue', totalSharedPool);
    const abcWeighted = calculateAllocatedOverhead(bu, safeBus, 'activity', totalSharedPool);
    const hcWeighted = calculateAllocatedOverhead(bu, safeBus, 'headcount', totalSharedPool);
    const capWeighted = calculateAllocatedOverhead(bu, safeBus, 'capital', totalSharedPool);

    const activeAlloc = calculateAllocatedOverhead(bu, safeBus, allocationMethod, totalSharedPool);
    const baseAlloc = revWeighted; // Baseline is Revenue-weighted
    const allocDelta = activeAlloc - baseAlloc;

    const baseEbitda = bu.revenue - (bu.cogs + bu.directLabour + bu.variableOperatingCost + bu.fixedOverhead + baseAlloc);
    const activeEbitda = bu.revenue - (bu.cogs + bu.directLabour + bu.variableOperatingCost + bu.fixedOverhead + activeAlloc);

    const baseMargin = bu.revenue > 0 ? (baseEbitda / bu.revenue) * 100 : 0;
    const activeMargin = bu.revenue > 0 ? (activeEbitda / bu.revenue) * 100 : 0;
    const marginDelta = activeMargin - baseMargin;

    return {
      bu,
      revWeighted,
      abcWeighted,
      hcWeighted,
      capWeighted,
      activeAlloc,
      allocDelta,
      baseEbitda,
      activeEbitda,
      baseMargin,
      activeMargin,
      marginDelta
    };
  });

  const chartData = allocationComparison.map(row => ({
    name: row.bu.code,
    'Revenue-Weighted': row.revWeighted,
    'Activity-Based (ABC)': row.abcWeighted,
    'Headcount-Weighted': row.hcWeighted,
    'Capital-Employed': row.capWeighted
  }));

  return (
    <div className="space-y-6">
      {/* Top Cost Breakdown Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Variable Costs</div>
          <div className="text-xl font-mono font-bold text-gray-200 mt-1">{sym}{(totalCOGS + totalVarOps).toFixed(1)}m</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">COGS, power, fuel, handling</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Direct Labour Costs</div>
          <div className="text-xl font-mono font-bold text-gray-200 mt-1">{sym}{totalLabour.toFixed(1)}m</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">1,420 dedicated staff salaries</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Fixed & Shared Overhead</div>
          <div className="text-xl font-mono font-bold text-[#D4AF37] mt-1">{sym}{(totalFixedOverhead + totalAllocatedOverhead).toFixed(1)}m</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">{sym}{totalAllocatedOverhead.toFixed(1)}m corporate shared pool</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Capital Depreciation</div>
          <div className="text-xl font-mono font-bold text-gray-300 mt-1">{sym}{totalDepreciation.toFixed(1)}m</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">Asset depreciation & amortisation</div>
        </div>
      </div>

      {/* Allocation Methodology Interactive Simulator */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 lg:p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#262626] pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#D4AF37]" />
              <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
                Corporate Overhead Allocation Engine ({sym}{totalSharedPool.toFixed(1)}m Pool)
              </h3>
            </div>
            <p className="text-xs text-gray-400 mt-1 font-sans">
              Select an institutional allocation methodology to observe how reported business unit profitability and EBITDA margins shift.
            </p>
          </div>

          {/* Allocation Key Buttons */}
          <div className="flex items-center flex-wrap gap-2">
            {[
              { id: 'activity', label: 'Activity-Based (ABC)' },
              { id: 'revenue', label: 'Revenue-Weighted' },
              { id: 'headcount', label: 'Headcount-Weighted' },
              { id: 'capital', label: 'Capital-Employed' }
            ].map(m => (
              <button
                key={m.id}
                onClick={() => setAllocationMethod(m.id as AllocationMethod)}
                className={`px-3 py-1.5 rounded text-xs font-mono transition-all cursor-pointer ${
                  allocationMethod === m.id
                    ? 'bg-[#D4AF37] text-[#0A0A0A] font-bold shadow-lg shadow-[#D4AF37]/10'
                    : 'bg-[#1A1A1A] text-gray-300 hover:bg-[#262626] border border-[#262626]'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Comparison Bar Chart */}
        <div className="mt-5">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 15 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="name" stroke="#525252" fontSize={10} />
                <YAxis stroke="#525252" fontSize={10} tickFormatter={(v) => `${sym}${v}m`} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                          <div className="font-bold text-white">{payload[0].payload.name} Allocation Comparison</div>
                          {payload.map((entry, idx) => (
                            <div key={idx} className="flex justify-between gap-4" style={{ color: entry.color }}>
                              <span>{entry.name}:</span>
                              <span className="font-bold">{sym}{Number(entry.value).toFixed(2)}m</span>
                            </div>
                          ))}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="Revenue-Weighted" fill="#525252" radius={[2, 2, 0, 0]} />
                <Bar dataKey="Activity-Based (ABC)" fill="#D4AF37" radius={[2, 2, 0, 0]} />
                <Bar dataKey="Headcount-Weighted" fill="#22c55e" radius={[2, 2, 0, 0]} />
                <Bar dataKey="Capital-Employed" fill="#e5e7eb" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Impact & Margin Shift Table */}
        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-4">Division</th>
                <th className="py-3 px-4 text-right">Revenue-Weight</th>
                <th className="py-3 px-4 text-right">Selected ({allocationMethod.toUpperCase()})</th>
                <th className="py-3 px-4 text-right">Overhead Shift</th>
                <th className="py-3 px-4 text-right">Base EBITDA Mgn</th>
                <th className="py-3 px-4 text-right">New EBITDA Mgn</th>
                <th className="py-3 px-4 text-right">Margin Shift</th>
                <th className="py-3 px-4">Accounting Reality / Insight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {allocationComparison.map((row, idx) => (
                <tr key={idx} className="hover:bg-[#161616] transition-colors">
                  <td className="py-3 px-4 font-semibold text-white">{row.bu.name}</td>
                  <td className="py-3 px-4 text-right text-gray-400">{sym}{row.revWeighted.toFixed(2)}m</td>
                  <td className="py-3 px-4 text-right font-bold text-gray-100">{sym}{row.activeAlloc.toFixed(2)}m</td>
                  <td className={`py-3 px-4 text-right font-semibold ${row.allocDelta > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    {row.allocDelta > 0 ? `+${sym}` : `-${sym}`}{Math.abs(row.allocDelta).toFixed(2)}m
                  </td>
                  <td className="py-3 px-4 text-right text-gray-400">{row.baseMargin.toFixed(1)}%</td>
                  <td className="py-3 px-4 text-right font-bold text-[#D4AF37]">{row.activeMargin.toFixed(1)}%</td>
                  <td className={`py-3 px-4 text-right font-bold ${row.marginDelta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {row.marginDelta >= 0 ? '+' : ''}{row.marginDelta.toFixed(1)} pp
                  </td>
                  <td className="py-3 px-4 text-gray-400 text-[11px]">
                    {row.bu.id === 'bu-transport' && 'Heavy transaction load & floor area increases true ABC cost burden.'}
                    {row.bu.id === 'bu-infra-fin' && 'High revenue per employee means low headcount-driven overhead absorption.'}
                    {row.bu.id === 'bu-data-centres' && 'Capital intensive facilities absorb higher capital-employed allocations.'}
                    {row.bu.id === 'bu-energy' && 'Grid asset footprint balanced across volume generation.'}
                    {row.bu.id === 'bu-property' && 'High physical square metre occupancy drives ABC facility costs.'}
                    {row.bu.id === 'bu-advisory' && 'Lean asset base but higher partner compensation allocation.'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
