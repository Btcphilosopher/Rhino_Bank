/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 12: Sector & Peer Benchmark Intelligence
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { MarginMetrics, CurrencyCode } from '../../types';

interface BenchmarksModuleProps {
  metrics: MarginMetrics;
  currency: CurrencyCode;
}

export const BenchmarksModule: React.FC<BenchmarksModuleProps> = ({ metrics, currency }) => {
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const benchmarkData = [
    { metric: 'Gross Margin', Rhino: Number((metrics.grossMargin * 100).toFixed(1)), TopQuartile: 78.5, SectorMedian: 68.2, BottomQuartile: 52.0 },
    { metric: 'EBITDA Margin', Rhino: Number((metrics.ebitdaMargin * 100).toFixed(1)), TopQuartile: 29.5, SectorMedian: 21.0, BottomQuartile: 14.2 },
    { metric: 'EBIT Margin', Rhino: Number((metrics.ebitMargin * 100).toFixed(1)), TopQuartile: 21.0, SectorMedian: 14.5, BottomQuartile: 8.5 },
    { metric: 'Net Margin', Rhino: Number((metrics.netMargin * 100).toFixed(1)), TopQuartile: 9.8, SectorMedian: 4.8, BottomQuartile: 1.5 },
    { metric: 'ROIC', Rhino: Number((metrics.roic * 100).toFixed(1)), TopQuartile: 14.2, SectorMedian: 8.5, BottomQuartile: 4.2 }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                PEER & SECTOR INTELLIGENCE
              </span>
              <span className="text-xs text-gray-500 font-mono">Universe: 42 European Infrastructure & High-Tech Asset Operators</span>
            </div>
            <h2 className="text-base font-bold text-white mt-1.5">
              Institutional Margin Benchmark & Top-Quartile Gap Analysis
            </h2>
            <p className="text-xs text-gray-400 mt-1 max-w-3xl font-sans">
              Rhino Infrastructure Holdings outperforms sector median across Gross (+7.4 pp) and EBITDA (+3.1 pp) margins, with an actionable +5.4 pp gap to European Top-Quartile leaders.
            </p>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg text-right text-xs font-mono shrink-0">
            <span className="text-gray-500 text-[10px] uppercase tracking-widest block">Top-Quartile EBITDA Gap:</span>
            <span className="text-lg font-bold text-[#D4AF37]">+{sym}10.8m</span>
          </div>
        </div>
      </div>

      {/* Comparison Bar Chart */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Margin Metric Comparison vs Industry Quartiles (%)
            </h3>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={benchmarkData} margin={{ top: 10, right: 10, left: -20, bottom: 15 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
              <XAxis dataKey="metric" stroke="#525252" fontSize={10} />
              <YAxis stroke="#525252" fontSize={10} tickFormatter={(v) => `${v}%`} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                        <div className="font-bold text-white">{payload[0].payload.metric}</div>
                        {payload.map((entry, idx) => (
                          <div key={idx} className="flex justify-between gap-4" style={{ color: entry.color }}>
                            <span>{entry.name}:</span>
                            <span className="font-bold">{entry.value}%</span>
                          </div>
                        ))}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
              <Bar dataKey="Rhino" fill="#D4AF37" radius={[2, 2, 0, 0]} />
              <Bar dataKey="TopQuartile" fill="#e5e7eb" radius={[2, 2, 0, 0]} />
              <Bar dataKey="SectorMedian" fill="#525252" radius={[2, 2, 0, 0]} />
              <Bar dataKey="BottomQuartile" fill="#ef4444" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
