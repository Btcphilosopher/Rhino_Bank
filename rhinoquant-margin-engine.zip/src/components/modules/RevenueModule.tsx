/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 2: Revenue Engine & Concentration Analytics
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { 
  DollarSign, 
  Repeat, 
  Users, 
  Filter, 
  ArrowUpRight, 
  ShieldCheck 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid 
} from 'recharts';
import { BusinessUnit, CurrencyCode } from '../../types';
import { DEMO_REVENUE_STREAMS } from '../../engine/demoData';

interface RevenueModuleProps {
  bus: BusinessUnit[];
  currency: CurrencyCode;
}

export const RevenueModule: React.FC<RevenueModuleProps> = ({ bus, currency }) => {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedBU, setSelectedBU] = useState<string>('all');

  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const safeBus = bus || [];

  // Filtered revenue streams
  const streams = (DEMO_REVENUE_STREAMS || []).filter(s => {
    if (selectedType !== 'all' && s.type !== selectedType) return false;
    if (selectedBU !== 'all' && s.buId !== selectedBU) return false;
    return true;
  });

  const totalRevenue = streams.reduce((s, r) => s + r.revenue, 0);
  const totalPrior = streams.reduce((s, r) => s + r.priorPeriodRevenue, 0);
  const overallGrowth = totalPrior > 0 ? (totalRevenue - totalPrior) / totalPrior : 0;
  const recurringRevenue = streams.filter(s => s.recurring).reduce((s, r) => s + r.revenue, 0);
  const recurringShare = totalRevenue > 0 ? recurringRevenue / totalRevenue : 0;

  // Herfindahl-Hirschman Index (HHI) for Revenue Concentration
  const hhi = safeBus.reduce((acc, b) => {
    const share = b.revenue / 200.0;
    return acc + Math.pow(share * 100, 2);
  }, 0);

  // Revenue by Stream Type Pie Data
  const streamTypeMap: Record<string, number> = {};
  (DEMO_REVENUE_STREAMS || []).forEach(s => {
    streamTypeMap[s.type] = (streamTypeMap[s.type] || 0) + s.revenue;
  });

  const streamTypeData = Object.entries(streamTypeMap).map(([type, rev]) => ({
    name: type.replace('_', ' ').toUpperCase(),
    value: Number(rev.toFixed(1))
  }));

  const COLORS = ['#D4AF37', '#e5e7eb', '#22c55e', '#f59e0b', '#ec4899', '#14b8a6', '#f43f5e', '#a855f7'];

  // Revenue per Employee by BU
  const buRevPerEmployee = safeBus.map(bu => ({
    name: bu.code,
    revPerEmployee: bu.headcount > 0 ? Math.round((bu.revenue * 1e6) / bu.headcount) : 0,
    headcount: bu.headcount,
    revenue: bu.revenue
  }));

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Total Tracked Revenue</span>
            <DollarSign className="w-3.5 h-3.5 text-[#D4AF37]" />
          </div>
          <div className="text-2xl font-mono font-bold text-white mt-2">{sym}{totalRevenue.toFixed(1)}m</div>
          <div className="text-[10px] text-green-500 font-mono mt-1 flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3" /> +{(overallGrowth * 100).toFixed(1)}% Group CAGR
          </div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Recurring Revenue Share</span>
            <Repeat className="w-3.5 h-3.5 text-[#D4AF37]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#D4AF37] mt-2">{(recurringShare * 100).toFixed(1)}%</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">{sym}{recurringRevenue.toFixed(1)}m contracted recurring</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Concentration Index (HHI)</span>
            <ShieldCheck className="w-3.5 h-3.5 text-gray-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-white mt-2">{Math.round(hhi)}</div>
          <div className="text-[10px] text-green-500 font-mono mt-1">Optimal Diversity (&lt; 2,500 threshold)</div>
        </div>

        <div className="p-4 bg-[#111111] border border-[#262626] rounded-lg shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Avg Revenue / Employee</span>
            <Users className="w-3.5 h-3.5 text-[#D4AF37]" />
          </div>
          <div className="text-2xl font-mono font-bold text-gray-200 mt-2">{sym}140,845</div>
          <div className="text-[10px] text-gray-500 font-mono mt-1">1,420 full-time professionals</div>
        </div>
      </div>

      {/* Revenue Structure Charts: Stream Types & Revenue per Employee */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
          <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-1">
            Revenue Streams by Contract & Monetisation Structure
          </h3>
          <p className="text-[10px] text-gray-500 mb-4">Breakdown of {sym}200.0m across 8 contract archetypes</p>

          <div className="h-64 w-full flex items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={streamTypeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {streamTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl">
                          <div className="font-bold text-white">{data.name}</div>
                          <div className="text-[#D4AF37] mt-0.5">{sym}{data.value}m ({((data.value / 200) * 100).toFixed(1)}%)</div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-[#262626]">
            {streamTypeData.map((st, idx) => (
              <div key={idx} className="flex items-center gap-1.5 text-[10px] font-mono text-gray-400">
                <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                <span className="truncate">{st.name}: {sym}{st.value}m</span>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue per Employee Bar Chart */}
        <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
          <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-1">
            Revenue Productivity per Employee by Division
          </h3>
          <p className="text-[10px] text-gray-500 mb-4">Headcount efficiency and fee intensity across divisions</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={buRevPerEmployee} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="name" stroke="#525252" fontSize={10} />
                <YAxis stroke="#525252" fontSize={10} tickFormatter={(val) => `${sym}${val / 1000}k`} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl">
                          <div className="font-bold text-white">{data.name}</div>
                          <div className="text-[#D4AF37]">Rev / Employee: {sym}{data.revPerEmployee.toLocaleString()}</div>
                          <div className="text-gray-500 text-[10px]">Headcount: {data.headcount} | Total Rev: {sym}{data.revenue}m</div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="revPerEmployee" fill="#D4AF37" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Granular Revenue Streams Table */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-[#262626] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Granular Revenue Stream Registry ({streams.length} Streams)
            </h3>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <div className="flex items-center gap-1.5 bg-[#0A0A0A] border border-[#262626] rounded px-2.5 py-1 text-gray-300">
              <Filter className="w-3 h-3 text-gray-500" />
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-transparent text-gray-200 focus:outline-none cursor-pointer text-xs"
              >
                <option value="all" className="bg-[#141414]">All Types</option>
                <option value="unit_sales" className="bg-[#141414]">Unit Sales</option>
                <option value="subscription" className="bg-[#141414]">Subscription</option>
                <option value="contract" className="bg-[#141414]">Contract</option>
                <option value="interest" className="bg-[#141414]">Interest Income</option>
                <option value="advisory" className="bg-[#141414]">Advisory Fees</option>
                <option value="licensing" className="bg-[#141414]">Licensing</option>
                <option value="rental" className="bg-[#141414]">Rental</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-[#0A0A0A] border border-[#262626] rounded px-2.5 py-1 text-gray-300">
              <select
                value={selectedBU}
                onChange={(e) => setSelectedBU(e.target.value)}
                className="bg-transparent text-gray-200 focus:outline-none cursor-pointer text-xs"
              >
                <option value="all" className="bg-[#141414]">All Divisions</option>
                {safeBus.map(b => (
                  <option key={b.id} value={b.id} className="bg-[#141414]">{b.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-4">Stream Name</th>
                <th className="py-3 px-4">Division</th>
                <th className="py-3 px-4">Archetype</th>
                <th className="py-3 px-4">Model</th>
                <th className="py-3 px-4 text-right">Current Rev</th>
                <th className="py-3 px-4 text-right">Prior Period</th>
                <th className="py-3 px-4 text-right">YoY Growth</th>
                <th className="py-3 px-4 text-right">Client Count</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {streams.map((s) => {
                const bu = bus.find(b => b.id === s.buId);
                return (
                  <tr key={s.id} className="hover:bg-[#161616] transition-colors">
                    <td className="py-3 px-4 font-semibold text-white">{s.name}</td>
                    <td className="py-3 px-4 text-gray-400 text-[11px]">{bu?.name}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-[#141414] text-gray-300 border border-[#262626]">
                        {s.type.replace('_', ' ').toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {s.recurring ? (
                        <span className="text-green-400 text-[10px] flex items-center gap-1">
                          <Repeat className="w-3 h-3" /> Recurring
                        </span>
                      ) : (
                        <span className="text-gray-500 text-[10px]">Milestones</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-gray-100">{sym}{s.revenue.toFixed(1)}m</td>
                    <td className="py-3 px-4 text-right text-gray-500">{sym}{s.priorPeriodRevenue.toFixed(1)}m</td>
                    <td className="py-3 px-4 text-right text-green-400 font-semibold">
                      +{(s.growthRate * 100).toFixed(1)}%
                    </td>
                    <td className="py-3 px-4 text-right text-gray-400">{s.clientCount} clients</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
