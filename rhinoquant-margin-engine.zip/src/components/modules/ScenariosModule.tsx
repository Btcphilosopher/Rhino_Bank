/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 8: Multi-Scenario Macro Shock Engine
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  CheckCircle2
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';
import { ScenarioType, BusinessUnit, CurrencyCode } from '../../types';
import { SCENARIO_PRESETS } from '../../engine/demoData';
import { calculateCompanyMetrics } from '../../engine/quantEngine';

interface ScenariosModuleProps {
  bus: BusinessUnit[];
  currency: CurrencyCode;
  activeScenario: ScenarioType;
  setActiveScenario: (scen: ScenarioType) => void;
}

export const ScenariosModule: React.FC<ScenariosModuleProps> = ({
  bus,
  currency,
  activeScenario,
  setActiveScenario,
}) => {
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const baseMetrics = calculateCompanyMetrics(bus, 'revenue');

  // Compute metrics for all 5 presets
  const scenarioResults = SCENARIO_PRESETS.map(preset => {
    const res = calculateCompanyMetrics(bus, 'revenue', 1.0, preset);
    return {
      preset,
      metrics: res,
      ebitdaDelta: res.ebitda - baseMetrics.ebitda,
      marginDelta: (res.ebitdaMargin - baseMetrics.ebitdaMargin) * 100
    };
  });

  // Current active scenario metrics
  const activePreset = SCENARIO_PRESETS.find(s => s.id === activeScenario) || SCENARIO_PRESETS[0];
  const activeMetrics = calculateCompanyMetrics(bus, 'revenue', 1.0, activePreset);

  const comparisonChartData = scenarioResults.map(s => ({
    name: s.preset.name.split(' ')[0],
    EBITDA: s.metrics.ebitda,
    Revenue: s.metrics.revenue,
    NetProfit: s.metrics.netProfit
  }));

  return (
    <div className="space-y-6">
      {/* Scenario Presets Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        {SCENARIO_PRESETS.map((scen) => {
          const isSelected = activeScenario === scen.id;
          const res = scenarioResults.find(r => r.preset.id === scen.id);
          const ebitdaDelta = res ? res.ebitdaDelta : 0;

          return (
            <button
              key={scen.id}
              onClick={() => setActiveScenario(scen.id)}
              className={`p-4 rounded-lg border text-left transition-all cursor-pointer shadow-lg ${
                isSelected
                  ? 'bg-[#141414] border-[#D4AF37] text-white shadow-xl'
                  : 'bg-[#111111] border-[#262626] text-gray-400 hover:border-gray-600'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-gray-500">
                  {scen.id.replace('_', ' ')}
                </span>
                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />}
              </div>

              <div className="text-xs font-bold text-gray-100 mt-1.5">{scen.name}</div>
              
              <div className="mt-3 flex items-baseline justify-between text-xs font-mono">
                <span className="text-gray-500">EBITDA:</span>
                <span className={`font-bold ${ebitdaDelta >= 0 ? 'text-[#D4AF37]' : 'text-red-400'}`}>
                  {sym}{res?.metrics.ebitda.toFixed(1)}m
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Scenario Detailed Deep Dive */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 lg:p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#262626] pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                ACTIVE SCENARIO SPECIFICATION
              </span>
              <h3 className="text-sm font-bold text-white tracking-wide">{activePreset.name}</h3>
            </div>
            <p className="text-xs text-gray-400 mt-1 font-sans">{activePreset.description}</p>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="bg-[#0A0A0A] border border-[#262626] px-3 py-1.5 rounded">
              <span className="text-gray-500">Revenue Impact: </span>
              <span className={`font-bold ${activeMetrics.revenue >= baseMetrics.revenue ? 'text-green-400' : 'text-red-400'}`}>
                {activeMetrics.revenue >= baseMetrics.revenue ? `+${sym}` : `-${sym}`}{Math.abs(activeMetrics.revenue - baseMetrics.revenue).toFixed(1)}m
              </span>
            </div>

            <div className="bg-[#0A0A0A] border border-[#262626] px-3 py-1.5 rounded">
              <span className="text-gray-500">EBITDA Impact: </span>
              <span className={`font-bold ${activeMetrics.ebitda >= baseMetrics.ebitda ? 'text-[#D4AF37]' : 'text-red-400'}`}>
                {activeMetrics.ebitda >= baseMetrics.ebitda ? `+${sym}` : `-${sym}`}{Math.abs(activeMetrics.ebitda - baseMetrics.ebitda).toFixed(1)}m
              </span>
            </div>
          </div>
        </div>

        {/* Comparison Chart across Scenarios */}
        <div className="mt-5">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonChartData} margin={{ top: 10, right: 10, left: -10, bottom: 15 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="name" stroke="#525252" fontSize={10} />
                <YAxis stroke="#525252" fontSize={10} domain={[0, 220]} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                          <div className="font-bold text-white">{payload[0].payload.name} Scenario</div>
                          {payload.map((entry, idx) => (
                            <div key={idx} className="flex justify-between gap-4" style={{ color: entry.color }}>
                              <span>{entry.name}:</span>
                              <span className="font-bold">{sym}{Number(entry.value).toFixed(1)}m</span>
                            </div>
                          ))}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="Revenue" fill="#525252" radius={[2, 2, 0, 0]} />
                <Bar dataKey="EBITDA" fill="#D4AF37" radius={[2, 2, 0, 0]} />
                <Bar dataKey="NetProfit" fill="#e5e7eb" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
