/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 7: 20-Year Project Finance DCF & Infrastructure Model
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  ReferenceLine 
} from 'recharts';
import { CurrencyCode } from '../../types';
import { DEMO_PROJECT_FINANCE } from '../../engine/demoData';

interface ProjectFinanceModuleProps {
  currency: CurrencyCode;
}

export const ProjectFinanceModule: React.FC<ProjectFinanceModuleProps> = ({ currency }) => {
  const [discountRate] = useState<number>(7.8);
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const project = DEMO_PROJECT_FINANCE;
  const schedule = project?.schedule || [];

  // Chart data for schedule
  const chartData = schedule.map(s => ({
    year: `Y${s.year}`,
    Revenue: s.revenue,
    EBITDA: s.ebitda,
    FreeCashFlow: s.freeCashFlow,
    DebtService: s.debtService,
    CumulativeCashFlow: s.cumulativeCashFlow,
    DSCR: s.dscr
  }));

  return (
    <div className="space-y-6">
      {/* Project Header Banner */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                INFRASTRUCTURE ASSET FINANCE
              </span>
              <span className="text-xs text-gray-400 font-mono">Division: Tier 4 Data Centres</span>
            </div>
            <h2 className="text-base font-bold text-white mt-1.5">{project.name}</h2>
            <p className="text-xs text-gray-400 mt-1 max-w-3xl font-sans">
              20-year concession cash-flow model for greenfield sovereign AI compute facility. Structured under Rhino Bank Senior Debt Facility with 70/30 project leverage.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="bg-[#0A0A0A] border border-[#262626] px-3 py-2 rounded">
              <span className="text-gray-500 text-[10px] uppercase tracking-widest block">WACC Discount Rate:</span>
              <span className="text-gray-200 font-bold">{discountRate}%</span>
            </div>
            <div className="bg-[#0A0A0A] border border-[#262626] px-3 py-2 rounded">
              <span className="text-gray-500 text-[10px] uppercase tracking-widest block">Total Initial Capex:</span>
              <span className="text-[#D4AF37] font-bold">{sym}{project.totalCapex.toFixed(1)}m</span>
            </div>
          </div>
        </div>

        {/* Project Key Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-[#262626]">
          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Project NPV (WACC {discountRate}%)</div>
            <div className="text-xl font-mono font-bold text-[#D4AF37] mt-1">+{sym}{project.npv.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-0.5">Net value added over benchmark</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Equity IRR</div>
            <div className="text-xl font-mono font-bold text-gray-200 mt-1">{(project.irr * 100).toFixed(1)}%</div>
            <div className="text-[10px] text-gray-500 mt-0.5">Hurdle spread: +9.0%</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Equity Payback Period</div>
            <div className="text-xl font-mono font-bold text-gray-200 mt-1">{project.paybackYears} Years</div>
            <div className="text-[10px] text-gray-500 mt-0.5">Full capital return by Year 6</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Average DSCR</div>
            <div className="text-xl font-mono font-bold text-green-400 mt-1">{project.averageDscr.toFixed(2)}x</div>
            <div className="text-[10px] text-gray-500 mt-0.5">Covenant floor: &gt; 1.30x</div>
          </div>
        </div>
      </div>

      {/* 20-Year Cash Flow Profile Chart */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              20-Year Cash Generation & Cumulative J-Curve Profile ({sym}m)
            </h3>
            <p className="text-[10px] text-gray-500 mt-0.5">EBITDA generation, Debt Service cover, and Net Free Cash Flows</p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-[#D4AF37]">
              <span className="w-2.5 h-0.5 bg-[#D4AF37]" /> EBITDA
            </span>
            <span className="flex items-center gap-1.5 text-gray-300">
              <span className="w-2.5 h-0.5 bg-gray-300" /> Free Cash Flow
            </span>
            <span className="flex items-center gap-1.5 text-green-400">
              <span className="w-2.5 h-0.5 bg-green-400" /> Cumulative Cash
            </span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 15 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
              <XAxis dataKey="year" stroke="#525252" fontSize={10} />
              <YAxis stroke="#525252" fontSize={10} domain={[-60, 200]} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                        <div className="font-bold text-white">{data.year} Project Schedule</div>
                        <div className="text-[#D4AF37]">EBITDA: {sym}{data.EBITDA}m</div>
                        <div className="text-gray-300">Free Cash Flow: {sym}{data.FreeCashFlow}m</div>
                        <div className="text-red-400">Debt Service: {sym}{data.DebtService}m</div>
                        <div className="text-green-400">Cumulative Cash: {sym}{data.CumulativeCashFlow}m</div>
                        <div className="text-gray-400">DSCR: {data.DSCR}x</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine y={0} stroke="#525252" />
              <Line type="monotone" dataKey="EBITDA" stroke="#D4AF37" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="FreeCashFlow" stroke="#e5e7eb" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="CumulativeCashFlow" stroke="#22c55e" strokeWidth={2} strokeDasharray="3 3" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Full 20-Year Schedule Table */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-[#262626] flex items-center justify-between">
          <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
            Comprehensive 20-Year DCF & Debt Amortisation Schedule
          </h3>
        </div>

        <div className="overflow-x-auto max-h-80">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead className="sticky top-0 bg-[#0A0A0A] z-10">
              <tr className="text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-3">Period</th>
                <th className="py-3 px-3 text-right">Revenue</th>
                <th className="py-3 px-3 text-right">OPEX</th>
                <th className="py-3 px-3 text-right">EBITDA</th>
                <th className="py-3 px-3 text-right">D&A</th>
                <th className="py-3 px-3 text-right">Interest</th>
                <th className="py-3 px-3 text-right">Tax</th>
                <th className="py-3 px-3 text-right">Debt Service</th>
                <th className="py-3 px-3 text-right">Free Cash Flow</th>
                <th className="py-3 px-3 text-right">DSCR</th>
                <th className="py-3 px-3 text-right">Cumulative Cash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {schedule.map((s) => (
                <tr key={s.year} className="hover:bg-[#161616] transition-colors">
                  <td className="py-2.5 px-3 font-semibold text-white">Year {s.year}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-gray-100">{sym}{s.revenue.toFixed(1)}m</td>
                  <td className="py-2.5 px-3 text-right text-gray-400">{sym}{s.operatingCosts.toFixed(1)}m</td>
                  <td className="py-2.5 px-3 text-right text-[#D4AF37] font-bold">{sym}{s.ebitda.toFixed(1)}m</td>
                  <td className="py-2.5 px-3 text-right text-gray-400">{sym}{s.depreciation.toFixed(1)}m</td>
                  <td className="py-2.5 px-3 text-right text-red-400">{sym}{s.interest.toFixed(1)}m</td>
                  <td className="py-2.5 px-3 text-right text-gray-400">{sym}{s.tax.toFixed(1)}m</td>
                  <td className="py-2.5 px-3 text-right text-red-400">{sym}{s.debtService.toFixed(1)}m</td>
                  <td className={`py-2.5 px-3 text-right font-bold ${s.freeCashFlow >= 0 ? 'text-gray-200' : 'text-red-400'}`}>
                    {sym}{s.freeCashFlow.toFixed(1)}m
                  </td>
                  <td className="py-2.5 px-3 text-right text-green-400 font-semibold">{s.dscr.toFixed(2)}x</td>
                  <td className={`py-2.5 px-3 text-right font-bold ${s.cumulativeCashFlow >= 0 ? 'text-green-400' : 'text-amber-400'}`}>
                    {sym}{s.cumulativeCashFlow.toFixed(1)}m
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
