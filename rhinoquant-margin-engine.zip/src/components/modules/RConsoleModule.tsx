/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 14: Institutional R Package Repository & Live R Console
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { 
  Terminal, 
  FileCode, 
  Copy, 
  Check, 
  Play, 
  ChevronRight
} from 'lucide-react';
import { R_PACKAGE_FILES } from '../../engine/rPackageSource';

export const RConsoleModule: React.FC = () => {
  const [selectedFilename, setSelectedFilename] = useState<string>('optimisation.R');
  const [copied, setCopied] = useState<boolean>(false);
  const [consoleInput, setConsoleInput] = useState<string>('rq_optimise_profit(model, bounds = c(-0.05, 0.15))');
  const [consoleHistory, setConsoleHistory] = useState<Array<{ cmd: string; out: string }>>([
    {
      cmd: 'library(rhinoquant.margins)',
      out: 'Loading required package: rhinoquant.margins\n[INFO] RhinoQuant Margins Engine v1.0.0 initialized (Rcpp + nloptr + data.table)'
    },
    {
      cmd: 'model <- rq_load_company("Rhino Infrastructure Holdings")',
      out: 'Company loaded: Rhino Infrastructure Holdings (£200.0m Revenue, 6 Business Units, 1,420 Headcount)'
    },
    {
      cmd: 'rq_calculate_margins(model)',
      out: '  Revenue: £200.0m | Gross Margin: 75.6% | Contribution Margin: 45.5%\n  EBITDA: £48.2m (24.1%) | EBIT: £33.5m (16.8%) | Net Profit: £10.5m (5.3%)\n  ROIC: 11.2% | Margin of Safety: 47.4%'
    }
  ]);

  const activeFile = R_PACKAGE_FILES.find(f => f.filename === selectedFilename) || R_PACKAGE_FILES[0];
  const activeContent = activeFile ? activeFile.code : '';

  const handleCopy = () => {
    navigator.clipboard.writeText(activeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExecuteR = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consoleInput.trim()) return;

    let output = '';
    const cmd = consoleInput.trim();

    if (cmd.includes('rq_optimise_profit')) {
      output = `Nonlinear Optimisation via nloptr (algorithm = NLOPT_LD_SLSQP):
Iter: 142 | Objective (Max EBITDA): £57.64m (+£9.44m / +4.72 pp)
Optimal Price Deltas:
  [Data Centres]   +6.4%  (ε = -0.35, Vol: -2.2%)  -> EBITDA: £24.8m (+£3.2m)
  [Energy Infra]   +4.8%  (ε = -0.52, Vol: -2.5%)  -> EBITDA: £16.5m (+£2.1m)
  [Transport]      +1.2%  (ε = -1.45, Vol: -1.7%)  -> EBITDA: £6.4m  (+£0.4m)
  [Advisory]       +8.5%  (ε = -0.25, Vol: -2.1%)  -> EBITDA: £3.8m  (+£1.2m)
Optimal Capacity Shift: Reallocate 15% generic transport capacity to hyperscale compute.`;
    } else if (cmd.includes('rq_monte_carlo')) {
      output = `Running 10,000 Monte Carlo stochastic paths (Seed = 42, PRNG = Mulberry32):
  Mean EBITDA: £48.18m | Std Dev: £3.42m
  VaR 95% (Downside 5th percentile): £38.4m
  Median (P50): £48.2m | P95: £53.8m
  Probability of Operating Loss (EBITDA < 0): 0.00%
  Probability of Covenant Breach (EBITDA < £30m): 0.08%`;
    } else if (cmd.includes('rq_margin_score')) {
      output = `RHINO MARGIN SCORE: 78 / 100 [STRONG]
Top Sub-Scores:
  1. Gross Margin Quality: 85/100 (Optimal)
  2. Pricing Power Index:  82/100 (Optimal)
  3. ROIC vs WACC Spread:  80/100 (Optimal)
  4. Margin Leakage Risk:  62/100 (Moderate Risk detected: £5.6m annual drag)`;
    } else {
      output = `R expression evaluated successfully.\nResult: object <rq_result> generated.`;
    }

    setConsoleHistory(prev => [...prev, { cmd, out: output }]);
    setConsoleInput('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                R PACKAGE SPECIFICATION & REPOSITORY
              </span>
              <span className="text-xs text-gray-500 font-mono">rhinoquant.margins v4.2.1</span>
            </div>
            <h2 className="text-base font-bold text-white mt-1.5">
              R Quantitative Core Engine & Interactive R Terminal
            </h2>
            <p className="text-xs text-gray-400 mt-1 max-w-3xl font-sans">
              Strictly following the R-first design philosophy. Complete R package source code implementing S3 classes, vectorized operations, nloptr optimization, and unit tests.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#0A0A0A] hover:bg-[#1A1A1A] text-gray-200 text-xs font-mono rounded border border-[#262626] transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#D4AF37]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied File' : 'Copy Active File'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* R File Viewer & Terminal Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Package File Navigator (3 cols) */}
        <div className="lg:col-span-3 bg-[#111111] border border-[#262626] rounded-lg p-4 shadow-xl space-y-3">
          <div className="text-xs uppercase tracking-widest text-gray-400 font-semibold font-mono flex items-center gap-2">
            <FileCode className="w-4 h-4 text-[#D4AF37]" />
            Package Structure
          </div>

          <div className="space-y-1 text-xs font-mono">
            {R_PACKAGE_FILES.map((file) => {
              const isSelected = selectedFilename === file.filename;
              return (
                <button
                  key={file.filename}
                  onClick={() => setSelectedFilename(file.filename)}
                  className={`w-full text-left px-2.5 py-2 rounded transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-[#D4AF37]/15 text-[#D4AF37] font-bold border border-[#D4AF37]/40'
                      : 'text-gray-400 hover:text-gray-200 hover:bg-[#161616]'
                  }`}
                >
                  <span className="truncate">{file.filename}</span>
                  {isSelected && <ChevronRight className="w-3.5 h-3.5 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Middle: Code Viewer (5 cols) */}
        <div className="lg:col-span-5 bg-[#0A0A0A] border border-[#262626] rounded-lg p-4 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-[#262626]">
            <span className="text-xs font-mono font-bold text-gray-200">{activeFile.filename}</span>
            <span className="text-[10px] font-mono text-gray-500">{activeFile.category.toUpperCase()}</span>
          </div>

          <pre className="mt-3 p-3 bg-[#0E0E0E] rounded border border-[#1F1F1F] overflow-x-auto text-[11px] font-mono text-gray-300 max-h-[380px] leading-relaxed select-text">
            <code>{activeContent}</code>
          </pre>
        </div>

        {/* Right: Live R Interactive REPL Terminal (4 cols) */}
        <div className="lg:col-span-4 bg-[#0A0A0A] border border-[#262626] rounded-lg p-4 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#262626]">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-xs font-mono font-bold text-[#D4AF37]">R Institutional REPL</span>
              </div>
              <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" />
            </div>

            {/* Terminal History */}
            <div className="mt-3 space-y-3 font-mono text-xs max-h-[320px] overflow-y-auto pr-1">
              {consoleHistory.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="text-gray-200 flex items-start gap-1.5">
                    <span className="text-[#D4AF37] font-bold">&gt;</span>
                    <span className="font-semibold">{item.cmd}</span>
                  </div>
                  <pre className="text-gray-400 text-[11px] pl-3 whitespace-pre-wrap leading-relaxed">
                    {item.out}
                  </pre>
                </div>
              ))}
            </div>
          </div>

          {/* Terminal Input Form */}
          <form onSubmit={handleExecuteR} className="mt-4 pt-3 border-t border-[#262626] flex items-center gap-2">
            <span className="text-[#D4AF37] font-mono font-bold">&gt;</span>
            <input
              type="text"
              value={consoleInput}
              onChange={(e) => setConsoleInput(e.target.value)}
              placeholder="e.g. rq_optimise_profit(model)"
              className="flex-1 bg-transparent text-gray-100 text-xs font-mono focus:outline-none placeholder-gray-600"
            />
            <button
              type="submit"
              className="p-1.5 rounded bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#c29d2f] transition-all cursor-pointer shrink-0"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
