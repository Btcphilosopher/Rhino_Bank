/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 11: 2D Sensitivity Heatmap & Tornado Chart of Drivers
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  ReferenceLine 
} from 'recharts';
import { BusinessUnit, CurrencyCode, ScenarioDefinition } from '../../types';
import { calculateCompanyMetrics } from '../../engine/quantEngine';

interface SensitivityModuleProps {
  bus: BusinessUnit[];
  currency: CurrencyCode;
}

export const SensitivityModule: React.FC<SensitivityModuleProps> = ({ bus, currency }) => {
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  // 2D Matrix Parameters
  const priceDeltas = [-5, -2.5, 0, 2.5, 5, 7.5, 10];
  const volumeDeltas = [-10, -5, 0, 5, 10];

  // Base metrics
  const baseMetrics = calculateCompanyMetrics(bus, 'revenue');

  // Compute 2D Matrix Grid of EBITDA values
  const matrixGrid = volumeDeltas.map(vDelta => {
    return {
      volumeDelta: vDelta,
      row: priceDeltas.map(pDelta => {
        const simScenario: ScenarioDefinition = {
          id: 'custom',
          name: 'Sensitivity',
          description: '',
          priceShockPct: pDelta / 100,
          volumeShockPct: vDelta / 100,
          costInflationPct: 0,
          wageInflationPct: 0,
          energyShockPct: 0,
          fxShockPct: 0,
          interestRateShockPct: 0,
          taxRateChangePct: 0
        };
        const m = calculateCompanyMetrics(bus, 'revenue', 1.0, simScenario);
        return {
          priceDelta: pDelta,
          ebitda: m.ebitda,
          margin: m.ebitdaMargin * 100
        };
      })
    };
  });

  // Tornado Chart Data
  const tornadoData = [
    { driver: 'Unit Price (+/- 5%)', downside: -10.0, upside: 10.0, base: 48.2 },
    { driver: 'Sales Volume (+/- 5%)', downside: -5.8, upside: 5.8, base: 48.2 },
    { driver: 'Direct Labour (+/- 5%)', downside: 1.8, upside: -1.8, base: 48.2 },
    { driver: 'Power & Energy (+/- 10%)', downside: 1.2, upside: -1.2, base: 48.2 },
    { driver: 'Corp Overhead (+/- 5%)', downside: 1.0, upside: -1.0, base: 48.2 },
    { driver: 'Senior Debt Rate (+/- 100bp)', downside: 0.8, upside: -0.8, base: 48.2 }
  ];

  const getCellBg = (ebitda: number) => {
    if (ebitda >= 58) return 'bg-[#D4AF37]/25 text-[#D4AF37] border-[#D4AF37]/50';
    if (ebitda >= 50) return 'bg-[#D4AF37]/10 text-gray-200 border-[#D4AF37]/30';
    if (ebitda >= 46) return 'bg-[#141414] text-gray-300 border-[#262626]';
    if (ebitda >= 40) return 'bg-amber-950/40 text-amber-300 border-amber-800/40';
    return 'bg-red-950/40 text-red-300 border-red-800/40';
  };

  return (
    <div className="space-y-6">
      {/* 2D Sensitivity Heatmap Table */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 lg:p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold font-mono">
              2D Profit Sensitivity Matrix: Price Delta vs Volume Delta ({sym}m EBITDA)
            </h3>
            <p className="text-xs text-gray-400 mt-1 font-sans">
              Simultaneous interaction matrix showing group EBITDA under cross-varied price and volume shocks.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-gray-500">Base EBITDA:</span>
            <span className="text-[#D4AF37] font-bold bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              {sym}{baseMetrics.ebitda.toFixed(1)}m (24.1%)
            </span>
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-[#262626] text-gray-500">
                <th className="py-2.5 px-3 text-left bg-[#0A0A0A]">Vol \ Price</th>
                {priceDeltas.map(p => (
                  <th key={p} className="py-2.5 px-2 bg-[#0A0A0A] font-bold text-gray-300">
                    {p >= 0 ? `+${p}%` : `${p}%`}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A]">
              {matrixGrid.map((row) => (
                <tr key={row.volumeDelta}>
                  <td className="py-2.5 px-3 text-left font-bold text-gray-300 bg-[#0A0A0A]">
                    {row.volumeDelta >= 0 ? `+${row.volumeDelta}% Vol` : `${row.volumeDelta}% Vol`}
                  </td>
                  {row.row.map((cell, idx) => (
                    <td key={idx} className="p-1">
                      <div className={`py-2 px-1 rounded border font-bold text-xs transition-all hover:scale-105 ${getCellBg(cell.ebitda)}`}>
                        <div>{sym}{cell.ebitda.toFixed(1)}m</div>
                        <div className="text-[9px] opacity-75 font-normal">{cell.margin.toFixed(1)}%</div>
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Tornado Chart of Profit Drivers */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Tornado Diagram: Key EBITDA Variance Drivers ({sym}m Impact)
            </h3>
            <p className="text-[10px] text-gray-500 mt-0.5">Ranks sensitivity to individual 5-10% unilateral parameter variations</p>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={tornadoData} layout="vertical" margin={{ top: 10, right: 30, left: 70, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#262626" horizontal={false} />
              <XAxis type="number" stroke="#525252" fontSize={10} domain={[-12, 12]} tickFormatter={(v) => `${v > 0 ? '+' : ''}${v}m`} />
              <YAxis dataKey="driver" type="category" stroke="#525252" fontSize={10} width={160} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                        <div className="font-bold text-white">{data.driver}</div>
                        <div className="text-[#D4AF37]">Upside Impact: +{sym}{Math.abs(data.upside)}m</div>
                        <div className="text-red-400">Downside Impact: -{sym}{Math.abs(data.downside)}m</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine x={0} stroke="#525252" />
              <Bar dataKey="upside" fill="#D4AF37" radius={[0, 2, 2, 0]} />
              <Bar dataKey="downside" fill="#ef4444" radius={[2, 0, 0, 2]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
