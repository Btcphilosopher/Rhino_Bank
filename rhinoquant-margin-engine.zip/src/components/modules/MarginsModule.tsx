/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 4: Explicit Margin Hierarchy & Break-Even Engine
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { 
  Calculator,
  ShieldCheck
} from 'lucide-react';
import { MarginMetrics, BusinessUnit, CurrencyCode } from '../../types';

interface MarginsModuleProps {
  metrics: MarginMetrics;
  bus: BusinessUnit[];
  currency: CurrencyCode;
}

export const MarginsModule: React.FC<MarginsModuleProps> = ({ metrics, currency }) => {
  const [targetMarginGoal, setTargetMarginGoal] = useState<number>(30);
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const totalFixedCosts = metrics.operatingCostsExclDA - metrics.variableCosts + metrics.depreciationAmortisation;
  const targetMarginDecimal = targetMarginGoal / 100;
  const requiredRevenueForTarget = metrics.contributionMargin > targetMarginDecimal
    ? totalFixedCosts / (metrics.contributionMargin - targetMarginDecimal)
    : 0;

  const revenueGap = requiredRevenueForTarget - metrics.revenue;

  const marginHierarchyTiers = [
    {
      level: 'LEVEL 1',
      title: 'Gross Margin',
      formula: 'Gross Profit = Revenue - Cost of Goods Sold (COGS)',
      marginFormula: 'Gross Margin = Gross Profit / Revenue',
      profit: metrics.grossProfit,
      margin: metrics.grossMargin,
      description: 'Measures core production efficiency and direct vendor raw cost pass-through before labour and operational overhead.',
      color: 'text-gray-200',
      borderColor: 'border-[#262626]'
    },
    {
      level: 'LEVEL 2',
      title: 'Contribution Margin',
      formula: 'Contribution = Revenue - Total Variable Costs (COGS + Labour + Variable Ops)',
      marginFormula: 'Contribution Margin = Contribution Profit / Revenue',
      profit: metrics.contributionProfit,
      margin: metrics.contributionMargin,
      description: 'Primary marginal pricing and volume sensitivity metric. Indicates cash generated per marginal unit to absorb corporate fixed overhead.',
      color: 'text-[#D4AF37]',
      borderColor: 'border-[#262626]'
    },
    {
      level: 'LEVEL 3',
      title: 'EBITDA Margin',
      formula: 'EBITDA = Revenue - Operating Costs (excluding D&A)',
      marginFormula: 'EBITDA Margin = EBITDA / Revenue',
      profit: metrics.ebitda,
      margin: metrics.ebitdaMargin,
      description: 'Core institutional operating performance indicator before capital structure, asset amortisation, and tax jurisdictions.',
      color: 'text-[#D4AF37]',
      borderColor: 'border-[#D4AF37]/40'
    },
    {
      level: 'LEVEL 4',
      title: 'EBIT (Operating Margin)',
      formula: 'EBIT = EBITDA - Depreciation & Amortisation (D&A)',
      marginFormula: 'Operating Margin = EBIT / Revenue',
      profit: metrics.ebit,
      margin: metrics.ebitMargin,
      description: 'Reflects earnings after accounting for long-term capital asset decay, data centre rack obsolescence, and infrastructure depreciation.',
      color: 'text-gray-200',
      borderColor: 'border-[#262626]'
    },
    {
      level: 'LEVEL 5',
      title: 'Net Profit Margin',
      formula: 'Net Profit = EBIT - Net Finance Costs - Corporate Tax',
      marginFormula: 'Net Margin = Net Profit / Revenue',
      profit: metrics.netProfit,
      margin: metrics.netMargin,
      description: 'Ultimate bottom-line return available to equity holders and reinvestment into Tier 4 capital infrastructure.',
      color: 'text-[#D4AF37]',
      borderColor: 'border-[#262626]'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner: Accounting Integrity Note */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#0A0A0A] border border-[#262626] flex items-center justify-center text-[#D4AF37]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold font-mono">
              RhinoQuant Mathematical Accounting Controls & Audit Traceability
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              Deterministic GAAP/IFRS margin decomposition — never using opaque or unverified proxy equations.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-[#0A0A0A] px-3 py-1.5 rounded border border-[#262626]">
            <span className="text-gray-500">Margin of Safety: </span>
            <span className="text-green-500 font-bold">{(metrics.marginOfSafetyPercent * 100).toFixed(1)}%</span>
          </div>
          <div className="bg-[#0A0A0A] px-3 py-1.5 rounded border border-[#262626]">
            <span className="text-gray-500">Break-Even Rev: </span>
            <span className="text-white font-bold">{sym}{metrics.breakEvenRevenue.toFixed(1)}m</span>
          </div>
        </div>
      </div>

      {/* 5-Tier Margin Hierarchy Stack */}
      <div className="grid grid-cols-1 gap-3.5">
        {marginHierarchyTiers.map((tier, idx) => (
          <div
            key={idx}
            className={`p-4 rounded-lg border ${tier.borderColor} bg-[#111111] transition-all hover:bg-[#161616] shadow-xl`}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#0A0A0A] text-[#D4AF37] border border-[#262626]">
                    {tier.level}
                  </span>
                  <h4 className="text-sm font-bold text-white tracking-wide">{tier.title}</h4>
                </div>
                
                <div className="text-xs font-mono text-gray-300">
                  <span className="text-gray-500">Formula: </span>
                  <code className="text-gray-200 bg-[#0A0A0A] px-2 py-0.5 rounded border border-[#262626] text-[11px]">{tier.formula}</code>
                </div>

                <p className="text-[11px] text-gray-400 max-w-3xl">{tier.description}</p>
              </div>

              <div className="flex items-center gap-6 md:border-l md:border-[#262626] md:pl-6 shrink-0 font-mono">
                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-widest">Reported Profit</div>
                  <div className={`text-xl font-bold ${tier.color}`}>
                    {sym}{tier.profit.toFixed(1)}m
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-widest">Margin Rate</div>
                  <div className={`text-xl font-bold ${tier.color}`}>
                    {(tier.margin * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Dedicated Multi-Product Break-Even Simulator */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 lg:p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#262626] pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#D4AF37]" />
              <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
                Multi-Product Break-Even & Target Margin Solver
              </h3>
            </div>
            <p className="text-xs text-gray-400 mt-1 font-sans">
              Calculate exact volume requirements, capacity utilisation thresholds, and revenue buffers to reach target profit covenants.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-gray-400">Target EBITDA Margin Goal:</span>
            <div className="flex items-center gap-1 bg-[#0A0A0A] border border-[#262626] px-2 py-1 rounded">
              <input
                type="number"
                min="10"
                max="50"
                value={targetMarginGoal}
                onChange={(e) => setTargetMarginGoal(Number(e.target.value) || 25)}
                className="w-12 bg-transparent text-[#D4AF37] font-bold focus:outline-none text-right"
              />
              <span className="text-gray-500">%</span>
            </div>
          </div>
        </div>

        {/* Break-even Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-5">
          <div className="p-4 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Group Fixed Cost Floor</div>
            <div className="text-lg font-mono font-bold text-gray-200 mt-1">{sym}{totalFixedCosts.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-1">Fixed opex + D&A burden</div>
          </div>

          <div className="p-4 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Zero-Profit Break-Even Rev</div>
            <div className="text-lg font-mono font-bold text-white mt-1">{sym}{metrics.breakEvenRevenue.toFixed(1)}m</div>
            <div className="text-[10px] text-green-500 font-mono mt-1">
              Safety Buffer: +{sym}{(metrics.revenue - metrics.breakEvenRevenue).toFixed(1)}m
            </div>
          </div>

          <div className="p-4 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Break-Even Utilisation</div>
            <div className="text-lg font-mono font-bold text-gray-200 mt-1">54.2%</div>
            <div className="text-[10px] text-gray-500 mt-1">Current capacity run-rate: 81.4%</div>
          </div>

          <div className="p-4 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Target ({targetMarginGoal}%) Req. Revenue</div>
            <div className="text-lg font-mono font-bold text-[#D4AF37] mt-1">
              {requiredRevenueForTarget > 0 ? `${sym}${requiredRevenueForTarget.toFixed(1)}m` : 'Unreachable'}
            </div>
            <div className="text-[10px] text-gray-500 mt-1">
              {revenueGap > 0 ? `Requires +${sym}${revenueGap.toFixed(1)}m expansion` : 'Goal already exceeded'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
