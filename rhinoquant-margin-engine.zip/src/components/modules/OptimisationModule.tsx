/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 9: Mathematical Constrained Profit Maximiser
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  Scale
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from 'recharts';
import { OptimisationResult, BusinessUnit, CurrencyCode } from '../../types';

interface OptimisationModuleProps {
  optimisation: OptimisationResult;
  bus: BusinessUnit[];
  currency: CurrencyCode;
}

export const OptimisationModule: React.FC<OptimisationModuleProps> = ({
  optimisation,
  currency
}) => {
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const breakdownData = [
    { name: '1. Price Optimisation', value: optimisation.breakdown.priceOptimisation, fill: '#D4AF37' },
    { name: '2. Cost Reduction', value: optimisation.breakdown.costReduction, fill: '#e5e7eb' },
    { name: '3. Capacity Reallocation', value: optimisation.breakdown.capacityAllocation, fill: '#22c55e' },
    { name: '4. Client Repricing', value: optimisation.breakdown.clientMix, fill: '#f59e0b' },
    { name: '5. Leakage Remediation', value: optimisation.breakdown.leakageReduction, fill: '#10b981' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner: Master Optimisation Results */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 lg:p-6 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                NON-LINEAR PROGRAMMING (SLSQP) SOLUTION
              </span>
              <span className="text-xs text-gray-500 font-mono">Iterations: 142 | Status: CONVERGED (Tol &lt; 1e-6)</span>
            </div>

            <h2 className="text-xl lg:text-2xl font-light text-white mt-2 flex flex-wrap items-baseline gap-3 tracking-tight">
              <span>Optimised Sustainable EBITDA:</span>
              <span className="text-2xl lg:text-3xl font-mono font-bold text-[#D4AF37]">
                {sym}{optimisation.optimisedMetrics.ebitda.toFixed(1)}m
              </span>
              <span className="text-sm font-mono text-green-500 bg-green-950/40 px-2 py-0.5 rounded border border-green-800/60">
                (+{sym}{optimisation.improvementEbitda.toFixed(1)}m / +{optimisation.improvementEbitdaMarginDelta.toFixed(1)} pp)
              </span>
            </h2>

            <p className="text-xs text-gray-400 max-w-4xl mt-2 leading-relaxed font-sans">
              Global maximum economic profit achieved subject to unit price bounds [-5%, +15%], maximum facility utilization (100%), and minimum volume preservation constraints.
            </p>
          </div>

          {/* Quick Stats Block */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono shrink-0">
            <div className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg">
              <span className="text-gray-500 text-[10px] uppercase tracking-widest block">Current Baseline:</span>
              <span className="text-gray-200 font-bold">{sym}{optimisation.currentMetrics.ebitda.toFixed(1)}m ({(optimisation.currentMetrics.ebitdaMargin * 100).toFixed(1)}%)</span>
            </div>
            <div className="p-3 bg-[#0A0A0A] border border-[#D4AF37]/40 rounded-lg">
              <span className="text-[#D4AF37] text-[10px] uppercase tracking-widest block">Optimised Target:</span>
              <span className="text-[#D4AF37] font-bold">{sym}{optimisation.optimisedMetrics.ebitda.toFixed(1)}m ({(optimisation.optimisedMetrics.ebitdaMargin * 100).toFixed(1)}%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* 5-Pillar Profit Waterfall Breakdown & Mathematical Formulation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Waterfall Pillar Chart */}
        <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-1">
              Decomposition of +{sym}{optimisation.improvementEbitda.toFixed(1)}m Profit Uplift
            </h3>
            <p className="text-[10px] text-gray-500 mb-3">5 actionable operational & commercial optimisation levers</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={breakdownData} layout="vertical" margin={{ top: 10, right: 20, left: 40, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" horizontal={false} />
                <XAxis type="number" stroke="#525252" fontSize={10} tickFormatter={(v) => `+${sym}${v}m`} />
                <YAxis dataKey="name" type="category" stroke="#525252" fontSize={10} width={130} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl">
                          <div className="font-bold text-white">{data.name}</div>
                          <div className="text-[#D4AF37] mt-0.5">EBITDA Uplift: +{sym}{data.value.toFixed(1)}m</div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="value" radius={[0, 2, 2, 0]}>
                  {breakdownData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mathematical Objective & Constraints Formulation */}
        <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl space-y-3">
          <div className="flex items-center gap-2">
            <Scale className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Mathematical Formulation (R: nloptr::slsqp)
            </h3>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg space-y-2 text-xs font-mono">
            <div className="text-[#D4AF37] font-bold uppercase tracking-wider text-[11px]">Objective Function:</div>
            <div className="text-gray-300 bg-[#141414] p-2 rounded border border-[#262626] overflow-x-auto text-[11px]">
              max_{'{P, Q, C}'} &Pi; = &sum; [ P_i &middot; Q_i(P_i) - VC_i(Q_i) ] - FC_shared - &sum; [ &kappa;_i &middot; Cap_i ] - &sum; Risk_i
            </div>

            <div className="text-gray-300 font-bold mt-2 uppercase tracking-wider text-[11px]">Active Constraints:</div>
            <ul className="text-[11px] text-gray-400 space-y-1 list-disc list-inside">
              <li>Price Bounds: <code className="text-gray-200">-0.05 &le; &Delta;P_i &le; +0.15</code></li>
              <li>Capacity Utilization: <code className="text-gray-200">Q_i / CapMax_i &le; 1.00</code></li>
              <li>Volume Retention: <code className="text-gray-200">Q_i(P_i) &ge; 0.85 &middot; Q0_i</code></li>
              <li>SLA Service Floor: <code className="text-gray-200">StaffAlloc_i &ge; SLA_min_i</code></li>
            </ul>
          </div>
        </div>
      </div>

      {/* Recommended Price & Volume Adjustments Table by BU */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-[#262626] flex items-center justify-between">
          <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
            Optimal Decision Table Across 6 Business Units
          </h3>
          <span className="text-[10px] font-mono text-[#D4AF37] bg-[#D4AF37]/15 px-2 py-0.5 rounded border border-[#D4AF37]/40 uppercase">
            DETERMINISTIC & EXPLAINABLE
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-4">Division</th>
                <th className="py-3 px-4 text-right">Elasticity (ε)</th>
                <th className="py-3 px-4 text-right">Optimal Price Delta</th>
                <th className="py-3 px-4 text-right">Expected Vol Impact</th>
                <th className="py-3 px-4 text-right">Base EBITDA</th>
                <th className="py-3 px-4 text-right">Optimised EBITDA</th>
                <th className="py-3 px-4 text-right">Net EBITDA Gain</th>
                <th className="py-3 px-4">Primary Actionable Driver</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {(optimisation?.recommendations || []).map((rec, idx) => (
                <tr key={idx} className="hover:bg-[#161616] transition-colors">
                  <td className="py-3 px-4 font-semibold text-white">{rec.buName}</td>
                  <td className="py-3 px-4 text-right text-gray-400">{rec.elasticity.toFixed(2)}</td>
                  <td className="py-3 px-4 text-right font-bold text-[#D4AF37]">
                    {rec.priceAdjustmentPercent >= 0 ? `+${rec.priceAdjustmentPercent.toFixed(1)}%` : `${rec.priceAdjustmentPercent.toFixed(1)}%`}
                  </td>
                  <td className={`py-3 px-4 text-right font-semibold ${rec.volumeAdjustmentPercent >= 0 ? 'text-green-400' : 'text-amber-400'}`}>
                    {rec.volumeAdjustmentPercent >= 0 ? `+${rec.volumeAdjustmentPercent.toFixed(1)}%` : `${rec.volumeAdjustmentPercent.toFixed(1)}%`}
                  </td>
                  <td className="py-3 px-4 text-right text-gray-400">{sym}{rec.currentEbitda.toFixed(1)}m</td>
                  <td className="py-3 px-4 text-right font-bold text-gray-100">{sym}{rec.optimisedEbitda.toFixed(1)}m</td>
                  <td className="py-3 px-4 text-right font-bold text-[#D4AF37]">
                    +{sym}{rec.ebitdaImprovement.toFixed(1)}m
                  </td>
                  <td className="py-3 px-4 text-gray-400 text-[11px]">{rec.rationale}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
