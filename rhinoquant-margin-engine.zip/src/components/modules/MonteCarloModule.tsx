/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 10: 10,000-Path Monte Carlo Stochastic Risk Simulator
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState, useMemo } from 'react';
import { 
  Play
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell
} from 'recharts';
import { BusinessUnit, CurrencyCode, MonteCarloResult, MonteCarloConfig } from '../../types';
import { runMonteCarloSimulation } from '../../engine/quantEngine';

interface MonteCarloModuleProps {
  bus: BusinessUnit[];
  currency: CurrencyCode;
  seed: number;
}

export const MonteCarloModule: React.FC<MonteCarloModuleProps> = ({ bus, currency, seed }) => {
  const [iterations] = useState<number>(10000);
  const [activeSeed, setActiveSeed] = useState<number>(seed);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  // Run simulation with memoization
  const mcResult: MonteCarloResult = useMemo(() => {
    const config: MonteCarloConfig = {
      iterations,
      seed: activeSeed,
      priceVolatilityPct: 3.5,
      volumeVolatilityPct: 4.2,
      energyCostVolatilityPct: 8.5,
      wageInflationPct: 2.8,
      fxVolatilityPct: 3.0,
      interestRateShockBps: 50
    };
    return runMonteCarloSimulation(bus, config);
  }, [bus, iterations, activeSeed]);

  const handleRerun = () => {
    setIsRunning(true);
    setTimeout(() => {
      setActiveSeed(prev => prev + 1);
      setIsRunning(false);
    }, 150);
  };

  const chartData = mcResult.histogramBins.map((bin) => ({
    range: `${sym}${bin.rangeMin.toFixed(0)}-${bin.rangeMax.toFixed(0)}m`,
    count: bin.count,
    cumulativeProb: bin.cumulativeProb
  }));

  return (
    <div className="space-y-6">
      {/* Top Banner & Simulation Controls */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase tracking-wider">
                STOCHASTIC RISK ENGINE
              </span>
              <span className="text-xs text-gray-500 font-mono">
                Generator: Deterministic Mulberry32 PRNG (Seed: {activeSeed})
              </span>
            </div>
            <h2 className="text-base font-bold text-white mt-1.5">
              Correlated Stochastic Profit Distribution ({iterations.toLocaleString()} Iterations)
            </h2>
            <p className="text-xs text-gray-400 mt-1 max-w-3xl font-sans">
              Evaluates corporate profit distribution under simultaneously correlated demand shocks, energy tariff spikes, wage inflation drift, and FX currency volatility.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleRerun}
              disabled={isRunning}
              className="flex items-center gap-2 px-4 py-2 bg-[#D4AF37] hover:bg-[#c29d2f] text-[#0A0A0A] font-bold text-xs font-mono rounded transition-all shadow-lg shadow-[#D4AF37]/10 cursor-pointer disabled:opacity-50"
            >
              <Play className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
              <span>{isRunning ? 'Simulating...' : 'Run 10,000 Paths'}</span>
            </button>
          </div>
        </div>

        {/* Statistical Percentiles & VaR Summary Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 mt-5 pt-4 border-t border-[#262626]">
          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Expected Mean EBITDA</div>
            <div className="text-lg font-mono font-bold text-gray-100 mt-1">{sym}{mcResult.meanEbitda.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-0.5">Std Dev: &plusmn;{sym}{mcResult.stdDev.toFixed(1)}m</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Median (P50)</div>
            <div className="text-lg font-mono font-bold text-[#D4AF37] mt-1">{sym}{mcResult.p50.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-400 mt-0.5">IQR: {sym}{(mcResult.p75 - mcResult.p25).toFixed(1)}m</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">VaR 95% (Downside 5th)</div>
            <div className="text-lg font-mono font-bold text-red-400 mt-1">{sym}{mcResult.p5.toFixed(1)}m</div>
            <div className="text-[10px] text-red-400 mt-0.5">Worst 5% threshold</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Upside 95th Percentile</div>
            <div className="text-lg font-mono font-bold text-gray-200 mt-1">{sym}{mcResult.p95.toFixed(1)}m</div>
            <div className="text-[10px] text-gray-500 mt-0.5">Optimistic ceiling</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Loss Probability</div>
            <div className="text-lg font-mono font-bold text-green-400 mt-1">
              {(mcResult.probabilityOfLoss * 100).toFixed(2)}%
            </div>
            <div className="text-[10px] text-green-500 mt-0.5">Negligible insolvency risk</div>
          </div>

          <div className="p-3.5 bg-[#0A0A0A] border border-[#262626] rounded-lg">
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-mono">Target (25%) Margin Prob</div>
            <div className="text-lg font-mono font-bold text-[#D4AF37] mt-1">
              {(mcResult.probabilityOfTargetMargin * 100).toFixed(1)}%
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">EBITDA &gt; {sym}50.0m</div>
          </div>
        </div>
      </div>

      {/* Distribution Histogram Chart */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
              Simulated EBITDA Outcome Frequency Density ({sym}m)
            </h3>
            <p className="text-[10px] text-gray-500 mt-0.5">10,000 sample paths clustered into discrete profit bins</p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-red-400">
              <span className="w-2.5 h-0.5 bg-red-400" /> VaR 95% (P5)
            </span>
            <span className="flex items-center gap-1.5 text-[#D4AF37]">
              <span className="w-2.5 h-0.5 bg-[#D4AF37]" /> Median (P50)
            </span>
            <span className="flex items-center gap-1.5 text-gray-300">
              <span className="w-2.5 h-0.5 bg-gray-300" /> P95
            </span>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
              <XAxis dataKey="range" stroke="#525252" fontSize={10} angle={-30} textAnchor="end" />
              <YAxis stroke="#525252" fontSize={10} tickFormatter={(val) => `${val}`} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-[#0E0E0E] border border-[#262626] p-2.5 rounded text-xs font-mono shadow-2xl space-y-1">
                        <div className="font-bold text-white">Bin: {data.range}</div>
                        <div className="text-[#D4AF37]">Simulations: {data.count.toLocaleString()} paths</div>
                        <div className="text-gray-400">Frequency: {((data.count / iterations) * 100).toFixed(1)}%</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                {chartData.map((_, index) => {
                  const isP5 = index <= 3;
                  const isP95 = index >= chartData.length - 3;
                  return (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={isP5 ? '#ef4444' : isP95 ? '#e5e7eb' : '#D4AF37'} 
                    />
                  );
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
