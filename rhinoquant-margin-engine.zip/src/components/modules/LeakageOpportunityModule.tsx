/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Module 13: Margin Leakage Detector & Profit Opportunity Engine
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  AlertTriangle, 
  Sparkles, 
  ShieldAlert, 
  Zap
} from 'lucide-react';
import { CurrencyCode } from '../../types';
import { DEMO_MARGIN_LEAKAGES, DEMO_PROFIT_OPPORTUNITIES } from '../../engine/demoData';

interface LeakageOpportunityModuleProps {
  currency: CurrencyCode;
}

export const LeakageOpportunityModule: React.FC<LeakageOpportunityModuleProps> = ({ currency }) => {
  const sym = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'JPY' || currency === 'CNY' ? '¥' : '£';

  const safeLeakages = DEMO_MARGIN_LEAKAGES || [];
  const safeOpportunities = DEMO_PROFIT_OPPORTUNITIES || [];

  const totalLeakage = safeLeakages.reduce((s, i) => s + Math.abs(i.annualImpact), 0);
  const totalOpportunity = safeOpportunities.reduce((s, o) => s + o.estimatedProfitImpact, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 bg-[#111111] border border-red-900/30 rounded-lg shadow-xl flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <span className="text-xs font-mono font-bold text-red-400 uppercase tracking-wider">
                Detected Margin Leakage Drag
              </span>
            </div>
            <div className="text-2xl font-mono font-bold text-red-400 mt-2">
              -{sym}{totalLeakage.toFixed(1)}m / year
            </div>
            <p className="text-xs text-gray-400 mt-1 font-sans">
              6 identified structural friction points across billing, energy pass-through and discounts.
            </p>
          </div>
        </div>

        <div className="p-5 bg-[#111111] border border-[#D4AF37]/30 rounded-lg shadow-xl flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-mono font-bold text-[#D4AF37] uppercase tracking-wider">
                Total Prioritised Profit Opportunity
              </span>
            </div>
            <div className="text-2xl font-mono font-bold text-[#D4AF37] mt-2">
              +{sym}{totalOpportunity.toFixed(1)}m / year
            </div>
            <p className="text-xs text-gray-400 mt-1 font-sans">
              5 ranked actionable initiatives evaluated by net economic impact and implementation ease.
            </p>
          </div>
        </div>
      </div>

      {/* Margin Leakage Registry Table */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-[#262626] flex items-center justify-between">
          <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            Margin Leakage Registry & Remediation Protocol
          </h3>
          <span className="text-[10px] font-mono text-red-400 bg-red-950/40 px-2 py-0.5 rounded border border-red-800/40 uppercase">
            ACTIVE DRAG DETECTED
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-4">Leakage Source / Category</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Root Cause Analysis</th>
                <th className="py-3 px-4 text-right">Annual Drag</th>
                <th className="py-3 px-4 text-center">Remediation Difficulty</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {safeLeakages.map((item) => (
                <tr key={item.id} className="hover:bg-[#161616] transition-colors">
                  <td className="py-3 px-4 font-semibold text-white">{item.source}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-[#141414] text-gray-300 border border-[#262626]">
                      {item.category.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-400 text-[11px] font-sans">{item.rootCause}</td>
                  <td className="py-3 px-4 text-right font-bold text-red-400">-{sym}{Math.abs(item.annualImpact).toFixed(1)}m</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                      item.remediationDifficulty === 'Low' ? 'bg-green-950/50 text-green-400 border border-green-800/50' :
                      item.remediationDifficulty === 'Medium' ? 'bg-amber-950/50 text-amber-300 border border-amber-800/50' :
                      'bg-red-950/50 text-red-300 border border-red-800/50'
                    }`}>
                      {item.remediationDifficulty}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Prioritised Profit Opportunities Table */}
      <div className="bg-[#111111] border border-[#262626] rounded-lg overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-[#262626] flex items-center justify-between">
          <h3 className="text-xs uppercase tracking-widest text-gray-400 font-semibold flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#D4AF37]" />
            Ranked Profit Opportunity Engine (ROI & Action Plan)
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#0A0A0A] text-gray-500 uppercase tracking-wider text-[10px] border-b border-[#262626]">
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Opportunity Initiative</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Annual EBITDA Uplift</th>
                <th className="py-3 px-4 text-center">Risk Level</th>
                <th className="py-3 px-4 text-right">Timeframe</th>
                <th className="py-3 px-4">Action Plan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A] text-gray-300">
              {safeOpportunities.map((opp) => (
                <tr key={opp.id} className="hover:bg-[#161616] transition-colors">
                  <td className="py-3 px-4 font-bold text-[#D4AF37]">#{opp.rank}</td>
                  <td className="py-3 px-4 font-semibold text-white">{opp.opportunity}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-[#141414] text-gray-300 border border-[#262626]">
                      {opp.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-bold text-[#D4AF37]">+{sym}{opp.estimatedProfitImpact.toFixed(1)}m</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                      opp.riskLevel === 'Low' ? 'bg-green-950/50 text-green-400 border border-green-800/50' :
                      opp.riskLevel === 'Moderate' ? 'bg-amber-950/50 text-amber-300 border border-amber-800/50' :
                      'bg-red-950/50 text-red-300 border border-red-800/50'
                    }`}>
                      {opp.riskLevel}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-gray-400">{opp.timeToBenefitMonths} Months</td>
                  <td className="py-3 px-4 text-gray-300 text-[11px] font-sans">{opp.actionPlan}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
