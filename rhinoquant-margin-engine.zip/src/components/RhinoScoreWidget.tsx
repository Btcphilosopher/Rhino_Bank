/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Proprietary Rhino Margin Score Component (0-100)
 * Theme: Sophisticated Dark (#0A0A0A / #111111 / #262626 / #D4AF37)
 */

import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Sparkles, ShieldAlert, Award } from 'lucide-react';
import { RhinoMarginScore } from '../types';

interface RhinoScoreWidgetProps {
  scoreData: RhinoMarginScore;
}

export const RhinoScoreWidget: React.FC<RhinoScoreWidgetProps> = ({ scoreData }) => {
  const [expanded, setExpanded] = useState(false);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-[#D4AF37] border-[#D4AF37]/40 bg-[#D4AF37]/10';
    if (score >= 65) return 'text-[#D4AF37] border-[#D4AF37]/30 bg-[#D4AF37]/5';
    if (score >= 50) return 'text-amber-400 border-amber-500/40 bg-amber-500/10';
    return 'text-rose-400 border-rose-500/40 bg-rose-500/10';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Optimal':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40">OPTIMAL</span>;
      case 'Sound':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-[#1A1A1A] text-gray-300 border border-[#333333]">SOUND</span>;
      case 'Needs Attention':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-amber-950/60 text-amber-300 border border-amber-800">ATTENTION</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-rose-950/60 text-rose-300 border border-rose-800">CRITICAL</span>;
    }
  };

  return (
    <div className="bg-[#111111] border border-[#262626] rounded-lg p-5 shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left: Score Dial and Brand Label */}
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-lg border flex flex-col items-center justify-center font-mono ${getScoreColor(scoreData.overallScore)}`}>
            <span className="text-2xl font-bold text-[#D4AF37] tracking-tight leading-none">{scoreData.overallScore}</span>
            <span className="text-[9px] uppercase font-semibold text-gray-500">/ 100</span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-semibold tracking-widest text-gray-400 uppercase">
                RHINO MARGIN SCORE
              </span>
              <span className="text-[10px] font-mono font-bold text-[#D4AF37] bg-[#D4AF37]/15 px-2 py-0.5 rounded border border-[#D4AF37]/40 uppercase">
                {scoreData.rating}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Proprietary 10-factor quantitative index of margin quality, pricing power & earnings resilience.
            </p>
          </div>
        </div>

        {/* Right: Quick metric indicators & toggle */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-5 text-xs font-mono border-l border-[#262626] pl-5">
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-widest">Pricing Power</div>
              <div className="font-semibold text-gray-200 mt-0.5">82 / 100</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-widest">Resilience</div>
              <div className="font-semibold text-gray-200 mt-0.5">84 / 100</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase tracking-widest">Leakage Risk</div>
              <div className="font-semibold text-amber-400 mt-0.5">Moderate (£5.6m)</div>
            </div>
          </div>

          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1A1A1A] hover:bg-[#262626] text-gray-300 text-xs font-mono rounded border border-[#262626] transition-colors cursor-pointer"
          >
            <span>{expanded ? 'Hide Factors' : '10 Dimensions'}</span>
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expandable 10-dimension factor grid */}
      {expanded && (
        <div className="mt-5 pt-5 border-t border-[#262626] grid grid-cols-1 md:grid-cols-2 gap-3">
          {(scoreData?.components || []).map((comp, idx) => (
            <div
              key={idx}
              className="p-3 bg-[#0A0A0A] border border-[#262626] rounded-lg flex flex-col justify-between gap-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-gray-500">#{idx + 1}</span>
                  <span className="text-xs font-semibold text-gray-200">{comp.name}</span>
                  <span className="text-[10px] font-mono text-gray-500">({Math.round(comp.weight * 100)}% wt)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-[#D4AF37]">{comp.score}/100</span>
                  {getStatusBadge(comp.status)}
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-[#1A1A1A] rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    comp.score >= 80 ? 'bg-[#D4AF37]' : comp.score >= 65 ? 'bg-amber-400' : 'bg-gray-500'
                  }`}
                  style={{ width: `${comp.score}%` }}
                />
              </div>

              <p className="text-[11px] text-gray-400">{comp.description}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
