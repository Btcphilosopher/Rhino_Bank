/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Institutional Header & Navigation Bar
 * Theme: Sophisticated Dark (#0A0A0A / #0E0E0E / #262626 / #D4AF37)
 */

import React from 'react';
import { 
  Building2, 
  TrendingUp, 
  Layers, 
  Sliders, 
  DollarSign, 
  ShieldAlert, 
  Cpu, 
  FileText, 
  RefreshCw,
  Terminal,
  Sparkles,
  Download
} from 'lucide-react';
import { CurrencyCode, ScenarioType } from '../types';
import { DEMO_METADATA } from '../engine/demoData';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currency: CurrencyCode;
  setCurrency: (curr: CurrencyCode) => void;
  activeScenario: ScenarioType;
  setActiveScenario: (scen: ScenarioType) => void;
  seed: number;
  setSeed: (seed: number) => void;
  onReset?: () => void;
  onRunOptimizer?: () => void;
}

export const NAV_TABS = [
  { id: 'overview', label: 'OVERVIEW', icon: TrendingUp },
  { id: 'revenue', label: 'REVENUE ENGINE', icon: DollarSign },
  { id: 'costs', label: 'COST ATTRIBUTION', icon: Layers },
  { id: 'margins', label: 'MARGIN BRIDGES', icon: Building2 },
  { id: 'profitability', label: 'UNIT PROFITABILITY', icon: Building2 },
  { id: 'pricing', label: 'PRICE ELASTICITY', icon: Sliders },
  { id: 'project', label: 'PROJECT FINANCE', icon: Building2 },
  { id: 'scenarios', label: 'SCENARIO ENGINE', icon: Sliders },
  { id: 'optimisation', label: 'PROFIT OPTIMISER', icon: Cpu },
  { id: 'monte_carlo', label: 'MONTE CARLO', icon: RefreshCw },
  { id: 'sensitivity', label: 'SENSITIVITY MATRIX', icon: Layers },
  { id: 'benchmarks', label: 'PEER BENCHMARKS', icon: TrendingUp },
  { id: 'leakage', label: 'LEAKAGE DETECTOR', icon: ShieldAlert },
  { id: 'r_console', label: 'R ENGINE & REPO', icon: Terminal },
  { id: 'reports', label: 'BOARD PACK & AUDIT', icon: FileText },
];

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  activeScenario,
  setActiveScenario,
  seed,
  setSeed,
  onReset,
  onRunOptimizer,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0E0E0E] border-b border-[#262626] shadow-2xl">
      {/* Top Institutional Identity Bar */}
      <div className="max-w-[1720px] mx-auto px-4 lg:px-6 h-14 flex items-center justify-between gap-4">
        {/* Brand Hierarchy */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-[#D4AF37]/10 border border-[#D4AF37]/40 flex items-center justify-center font-mono font-bold text-[#D4AF37] text-xs tracking-wider shadow-sm">
              RQ
            </div>
            <div className="text-[#D4AF37] font-bold tracking-[0.2em] text-base lg:text-lg">
              RHINOQUANT
            </div>
          </div>
          
          <div className="h-4 w-px bg-[#262626] hidden sm:block" />
          
          <div className="text-[11px] uppercase tracking-widest text-gray-500 hidden sm:flex items-center gap-2 font-mono">
            <span>MARGIN ENGINE v4.2.1</span>
            <span className="text-[#262626]">/</span>
            <span className="text-gray-400 font-sans">{DEMO_METADATA.companyName}</span>
          </div>
        </div>

        {/* Global Controls & Status */}
        <div className="flex items-center gap-3 lg:gap-4 text-xs font-mono">
          {/* Live System Status Indicator */}
          <div className="hidden md:flex items-center gap-1.5 text-[10px] text-gray-400 tracking-wider">
            <span className="text-green-500 animate-pulse">●</span>
            <span>SYSTEM: STABLE</span>
          </div>

          {/* Scenario Selector */}
          <div className="flex items-center gap-1.5 bg-[#141414] border border-[#262626] rounded px-2.5 py-1 text-gray-300">
            <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">SCENARIO:</span>
            <select
              value={activeScenario}
              onChange={(e) => setActiveScenario(e.target.value as ScenarioType)}
              className="bg-transparent text-gray-200 text-xs font-medium focus:outline-none cursor-pointer tracking-tight"
            >
              <option value="base" className="bg-[#141414]">BASE_CASE (FY25)</option>
              <option value="upside" className="bg-[#141414]">UPSIDE_EXPANSION</option>
              <option value="downside" className="bg-[#141414]">DOWNSIDE_DEMAND</option>
              <option value="stress" className="bg-[#141414]">STAGFLATION_SHOCK</option>
              <option value="extreme_stress" className="bg-[#141414]">REGULATORY_STRESS</option>
            </select>
          </div>

          {/* Currency Selector */}
          <div className="flex items-center gap-1.5 bg-[#141414] border border-[#262626] rounded px-2.5 py-1 text-gray-300">
            <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">FX:</span>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="bg-transparent text-[#D4AF37] text-xs font-bold focus:outline-none cursor-pointer"
            >
              <option value="GBP" className="bg-[#141414]">GBP (£)</option>
              <option value="EUR" className="bg-[#141414]">EUR (€)</option>
              <option value="USD" className="bg-[#141414]">USD ($)</option>
              <option value="CHF" className="bg-[#141414]">CHF</option>
              <option value="JPY" className="bg-[#141414]">JPY (¥)</option>
              <option value="CNY" className="bg-[#141414]">CNY (¥)</option>
            </select>
          </div>

          {/* Seed Input */}
          <div className="hidden xl:flex items-center gap-1 bg-[#141414] border border-[#262626] rounded px-2 py-1" title="Deterministic Mulberry32 PRNG Seed">
            <span className="text-[10px] text-gray-500">SEED:</span>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(Number(e.target.value) || 42)}
              className="w-10 bg-transparent text-gray-300 text-xs focus:outline-none text-right font-mono"
            />
          </div>

          {/* Fast Action: Export Report */}
          <button
            onClick={() => setActiveTab('reports')}
            className="bg-[#262626] hover:bg-[#333333] text-gray-200 px-3 py-1 rounded text-[10px] uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 font-medium border border-[#333333]"
          >
            <Download className="w-3 h-3 text-[#D4AF37]" />
            <span className="hidden sm:inline">Export Report</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs Bar */}
      <div className="max-w-[1720px] mx-auto px-4 lg:px-6 flex items-center overflow-x-auto no-scrollbar gap-1 border-t border-[#262626] bg-[#0A0A0A]">
        {NAV_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 text-[11px] font-mono tracking-wider uppercase whitespace-nowrap transition-all border-b-2 cursor-pointer ${
                isActive
                  ? 'border-[#D4AF37] text-[#D4AF37] bg-[#D4AF37]/10 font-bold'
                  : 'border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#141414]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#D4AF37]' : 'text-gray-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
