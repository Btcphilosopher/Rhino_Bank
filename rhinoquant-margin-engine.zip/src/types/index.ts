/**
 * RHINOQUANT PROFIT MARGIN ENGINE (RQME)
 * Type Definitions & Institutional Financial Data Model
 * Rhino Bank Quantitative Subsidiary
 */

export type CurrencyCode = 'GBP' | 'EUR' | 'USD' | 'CHF' | 'JPY' | 'CNY';

export interface FXRate {
  pair: string;
  rate: number;
  inverseRate: number;
  date: string;
}

export type ScenarioType = 'base' | 'upside' | 'downside' | 'stress' | 'extreme_stress' | 'custom';

export type AllocationMethod = 'revenue' | 'activity' | 'headcount' | 'capital';

export interface BusinessUnit {
  id: string;
  name: string;
  code: string;
  sector: string;
  description: string;
  headcount: number;
  capitalEmployed: number; // in £m
  floorAreaSqM: number;
  transactionsCount: number;
  
  // Baseline financial metrics (£m)
  revenue: number;
  cogs: number;
  directLabour: number;
  variableOperatingCost: number;
  fixedOverhead: number;
  allocatedOverhead: number;
  depreciationAmortisation: number;
  netFinanceCost: number;
  taxRate: number; // e.g. 0.25
  
  // Operational parameters
  priceIndex: number; // 100 base
  volumeUnits: number; // e.g. MWh, sq ft, rack units, deals
  unitOfMeasure: string;
  averagePricePerUnit: number;
  directCostPerUnit: number;
  priceElasticity: number; // e.g. -1.45
  capacityLimit: number; // max volume units
  currentUtilisation: number; // e.g. 0.82
}

export interface RevenueStream {
  id: string;
  buId: string;
  name: string;
  type: 'unit_sales' | 'subscription' | 'contract' | 'project' | 'interest' | 'advisory' | 'licensing' | 'rental';
  recurring: boolean;
  revenue: number; // £m
  priorPeriodRevenue: number;
  growthRate: number;
  clientCount: number;
  contractTermMonths?: number;
}

export interface CostItem {
  id: string;
  buId: string;
  name: string;
  category: 'variable' | 'fixed' | 'semi_variable' | 'capital';
  amount: number; // £m
  costDriver: 'volume' | 'headcount' | 'time' | 'capacity' | 'fixed';
  variabilityPercent: number; // 100 for variable, 0 for fixed, 30-70 for semi
  inflationSensitivity: number; // beta to CPI/PPI
}

export interface ProductService {
  id: string;
  buId: string;
  name: string;
  price: number; // £
  unitCost: number; // £
  volume: number;
  unitOfMeasure: string;
  revenue: number; // £m
  grossMarginPercent: number;
  contributionMarginPercent: number;
  elasticity: number;
  capacityConsumptionPerUnit: number; // capacity units consumed
  competitorPrice: number;
  pricingPowerScore: number; // 1-10
}

export interface ClientProfile {
  id: string;
  name: string;
  tier: 'tier_1_strategic' | 'tier_2_core' | 'tier_3_standard' | 'tier_4_transactional';
  sector: string;
  revenue: number; // £m
  directCost: number; // £m
  allocatedCost: number; // £m
  capitalUsage: number; // £m
  riskCost: number; // £m
  fundingCost: number; // £m
  netContribution: number; // £m
  marginPercent: number;
  classification: 'HIGH VALUE' | 'PROFITABLE' | 'BREAKEVEN' | 'LOW MARGIN' | 'LOSS-MAKING';
  relationshipYears: number;
  contractExpiry: string;
}

export interface ProjectFinanceModel {
  id: string;
  name: string;
  buId: string;
  totalCapex: number; // £m
  equityShare: number; // 0.30
  debtShare: number; // 0.70
  debtInterestRate: number; // 0.055
  tenorYears: number; // 20
  discountRate: number; // WACC e.g. 0.075
  schedule: ProjectYearSchedule[];
  npv: number;
  irr: number;
  paybackYears: number;
  averageDscr: number;
}

export interface ProjectYearSchedule {
  year: number;
  revenue: number;
  operatingCosts: number;
  ebitda: number;
  depreciation: number;
  ebit: number;
  interest: number;
  tax: number;
  netIncome: number;
  capex: number;
  freeCashFlow: number;
  debtService: number;
  dscr: number;
  cumulativeCashFlow: number;
}

export interface MarginMetrics {
  revenue: number;
  cogs: number;
  grossProfit: number;
  grossMargin: number;
  
  variableCosts: number;
  contributionProfit: number;
  contributionMargin: number;
  
  operatingCostsExclDA: number;
  ebitda: number;
  ebitdaMargin: number;
  
  depreciationAmortisation: number;
  ebit: number;
  ebitMargin: number;
  
  operatingAdjustments: number;
  operatingProfit: number;
  operatingMargin: number;
  
  netFinanceCost: number;
  tax: number;
  netProfit: number;
  netMargin: number;
  
  capitalEmployed: number;
  roic: number;
  
  // Per unit/headcount metrics
  revenuePerEmployee: number;
  ebitdaPerEmployee: number;
  contributionPerEmployee: number;
  breakEvenRevenue: number;
  breakEvenVolume: number;
  breakEvenUtilisation: number;
  marginOfSafetyPercent: number;
}

export interface ProfitAttributionBridge {
  priorEbitda: number;
  currentEbitda: number;
  totalVariance: number;
  
  priceImpact: number;
  volumeImpact: number;
  mixImpact: number;
  directCostImpact: number;
  labourImpact: number;
  energyImpact: number;
  overheadImpact: number;
  fxImpact: number;
}

export interface MarginLeakageItem {
  id: string;
  rank: number;
  source: string;
  annualImpact: number; // in £m (negative)
  category: 'pricing' | 'operations' | 'procurement' | 'capacity' | 'commercial';
  rootCause: string;
  affectedUnits: string[];
  remediationDifficulty: 'Low' | 'Medium' | 'High';
}

export interface ProfitOpportunityItem {
  id: string;
  rank: number;
  opportunity: string;
  category: 'PRICE OPTIMISATION' | 'COST REDUCTION' | 'CAPACITY ALLOCATION' | 'CLIENT MIX' | 'LEAKAGE REDUCTION' | 'CONTRACT RENEGOTIATION';
  estimatedProfitImpact: number; // in £m (positive)
  implementationCost: number; // in £m
  riskLevel: 'Low' | 'Moderate' | 'Elevated';
  confidence: number; // 0-100%
  timeToBenefitMonths: number;
  actionPlan: string;
}

export interface OptimisationConfig {
  objective: 'max_profit' | 'max_ebitda_margin' | 'max_roic' | 'weighted';
  alphaProfit: number; // weight on profit
  betaEbitdaMargin: number; // weight on EBITDA margin
  gammaRoic: number; // weight on ROIC
  deltaRisk: number; // penalty weight on risk
  
  // Constraints
  minEbitdaMargin: number; // e.g. 0.22
  maxPriceIncreasePct: number; // e.g. 0.15
  minVolumeRetentionPct: number; // e.g. 0.85
  maxCapacityUtilisation: number; // e.g. 0.95
  maxCapexLimit: number; // in £m
}

export interface OptimisationResult {
  status: 'OPTIMAL' | 'FEASIBLE' | 'CONVERGED';
  algorithm: string;
  iterations: number;
  solveTimeMs: number;
  
  currentMetrics: MarginMetrics;
  optimisedMetrics: MarginMetrics;
  
  improvementEbitda: number; // £m
  improvementEbitdaMarginDelta: number; // percentage points
  improvementNetProfit: number; // £m
  
  breakdown: {
    priceOptimisation: number;
    costReduction: number;
    capacityAllocation: number;
    clientMix: number;
    leakageReduction: number;
  };
  
  recommendedPriceChanges: {
    buId: string;
    buName: string;
    currentPrice: number;
    recommendedPrice: number;
    priceDeltaPct: number;
    expectedVolumeImpactPct: number;
    expectedRevenueImpact: number;
    expectedEbitdaImpact: number;
    confidence: number;
  }[];
  
  capacityReallocation: {
    buId: string;
    buName: string;
    currentCapacityShare: number;
    recommendedCapacityShare: number;
    deltaCapacityUnits: number;
    expectedContributionGain: number;
  }[];
  
  paretoPoints: {
    growth: number;
    margin: number;
    profit: number;
    risk: number;
    isSelected?: boolean;
  }[];
}

export interface MonteCarloConfig {
  iterations: number; // 10,000
  seed: number;
  priceVolatilityPct: number;
  volumeVolatilityPct: number;
  energyCostVolatilityPct: number;
  wageInflationPct: number;
  fxVolatilityPct: number;
  interestRateShockBps: number;
}

export interface MonteCarloResult {
  iterations: number;
  seed: number;
  distribution: number[]; // array of 10000 ebitda results
  
  meanEbitda: number;
  medianEbitda: number;
  stdDev: number;
  p5: number;
  p25: number;
  p50: number;
  p75: number;
  p95: number;
  
  probabilityOfLoss: number; // e.g. 0.012 (1.2%)
  probabilityOfTargetMargin: number; // e.g. 0.84 (84%)
  valueAtRisk95: number; // £m potential shortfall
  expectedShortfall95: number;
  
  histogramBins: {
    rangeMin: number;
    rangeMax: number;
    count: number;
    cumulativeProb: number;
  }[];
}

export interface RhinoMarginScore {
  overallScore: number; // 0-100
  rating: 'EXCEPTIONAL' | 'STRONG' | 'ADEQUATE' | 'VULNERABLE' | 'DISTRESSED';
  components: {
    name: string;
    weight: number;
    score: number;
    status: 'Optimal' | 'Sound' | 'Needs Attention' | 'Critical';
    description: string;
  }[];
}

export interface ScenarioDefinition {
  id: ScenarioType;
  name: string;
  description: string;
  priceShockPct: number;
  volumeShockPct: number;
  costInflationPct: number;
  wageInflationPct: number;
  energyShockPct: number;
  fxShockPct: number;
  interestRateShockPct: number;
  taxRateChangePct: number;
}
