/**
 * RHINOQUANT MARGIN ENGINE (RQME)
 * Full R Package Source Code Repository & Documentation
 * Rhino Bank Quantitative Subsidiary
 */

export interface RFileContent {
  filename: string;
  path: string;
  category: 'core' | 'accounting' | 'quant' | 'optim' | 'app' | 'tests' | 'config';
  description: string;
  code: string;
}

export const R_PACKAGE_FILES: RFileContent[] = [
  {
    filename: 'DESCRIPTION',
    path: 'rhinoquant-margin-engine/DESCRIPTION',
    category: 'config',
    description: 'R Package Metadata, Dependencies, and Rhino Bank institutional licensing',
    code: `Package: rhinoquant.margin.engine
Type: Package
Title: RhinoQuant Quantitative Profitability Intelligence & Optimisation Platform
Version: 4.2.1
Author: Rhino Bank Quantitative Analytics Group <quant@rhinobank.com>
Maintainer: Principal Quantitative Systems Architect <rqme-support@rhinobank.com>
Description: High-performance quantitative profit margin decomposition, non-linear
    price elasticity optimisation, multi-method cost allocation, Monte Carlo risk
    simulation, and margin leakage detection for institutional and infrastructure finance.
License: Proprietary (Rhino Bank Institutional License)
Encoding: UTF-8
LazyData: true
RoxygenNote: 7.3.1
Depends:
    R (>= 4.2.0)
Imports:
    R6 (>= 2.5.1),
    data.table (>= 1.15.0),
    dplyr (>= 1.1.4),
    tidyr (>= 1.3.1),
    nloptr (>= 2.0.3),
    stats,
    quadprog (>= 1.5-8),
    forecast (>= 8.21.1),
    lubridate (>= 1.9.3),
    readr (>= 2.1.5),
    readxl (>= 1.4.3),
    ggplot2 (>= 3.5.0),
    plotly (>= 4.10.4),
    shiny (>= 1.8.1),
    DT (>= 0.33),
    purrr (>= 1.0.2)
Suggests:
    testthat (>= 3.2.1),
    knitr (>= 1.45),
    rmarkdown (>= 2.26)
URL: https://quant.rhinobank.com/rqme`
  },
  {
    filename: 'core.R',
    path: 'rhinoquant-margin-engine/R/core.R',
    category: 'core',
    description: 'R6 Class orchestration engine for RhinoQuant Profitability Engine',
    code: `#' @title RhinoQuant Margin Engine R6 Orchestrator
#' @description Core stateful quantitative engine for enterprise margin analytics.
#' @import R6 data.table
#' @export
RhinoMarginEngine <- R6::R6Class(
  classname = "RhinoMarginEngine",
  public = list(
    #' @field version Engine semantic release version
    version = "4.2.1",
    #' @field currency Base reporting currency code
    currency = "GBP",
    #' @field scenario Current active scenario name
    scenario = "base",
    #' @field data Raw and processed transactional data tables
    data = list(),
    #' @field results Cached mathematical calculation outputs
    results = list(),

    #' @description Initialize the quantitative engine instance
    #' @param company_name String name of the holding company
    #' @param base_currency Currency code (GBP, EUR, USD, CHF, JPY, CNY)
    initialize = function(company_name = "Rhino Infrastructure Holdings", base_currency = "GBP") {
      self$currency <- base_currency
      self$data$company_name <- company_name
      self$data$created_at <- Sys.time()
      message(sprintf("[RhinoQuant RQME v%s] Initialized for '%s' (%s)", 
                      self$version, company_name, self$currency))
    },

    #' @description Ingest verified structured data into memory
    #' @param bu_data data.frame of Business Unit parameters
    #' @param revenue_data data.frame of detailed revenue streams
    #' @param cost_data data.frame of classified cost line items
    load_data = function(bu_data, revenue_data, cost_data) {
      validate_accounting_data(bu_data, revenue_data, cost_data)
      self$data$bus <- data.table::as.data.table(bu_data)
      self$data$revenue <- data.table::as.data.table(revenue_data)
      self$data$costs <- data.table::as.data.table(cost_data)
      message(sprintf("Loaded %d Business Units and %d Revenue Streams.", 
                      nrow(self$data$bus), nrow(self$data$revenue)))
      invisible(self)
    },

    #' @description Compute comprehensive institutional margin hierarchy
    #' @param allocation_method Method for corporate overhead ('revenue', 'activity', 'headcount', 'capital')
    compute_margins = function(allocation_method = "revenue") {
      res <- calculate_margins(self$data$bus, method = allocation_method)
      self$results$margins <- res
      return(res)
    },

    #' @description Execute non-linear Lagrangian profit maximiser
    #' @param constraints Named list of mathematical boundary constraints
    #' @param objective Target function ('max_profit', 'max_ebitda_margin', 'weighted')
    optimise = function(constraints = list(), objective = "max_profit") {
      opt <- optimise_profitability(
        bus = self$data$bus,
        constraints = constraints,
        objective = objective
      )
      self$results$optimisation <- opt
      return(opt)
    },

    #' @description Run 10,000 iteration stochastic Monte Carlo risk simulation
    #' @param iterations Total stochastic runs (default 10,000)
    #' @param seed Deterministic PRNG seed integer
    simulate_monte_carlo = function(iterations = 10000, seed = 42) {
      mc <- run_monte_carlo(self$data$bus, iterations = iterations, seed = seed)
      self$results$monte_carlo <- mc
      return(mc)
    }
  )
)`
  },
  {
    filename: 'optimisation.R',
    path: 'rhinoquant-margin-engine/R/optimisation.R',
    category: 'optim',
    description: 'Non-linear constrained profit maximization solver using nloptr SLSQP',
    code: `#' @title Profit Maximiser and Capacity Optimisation Engine
#' @description Solves non-linear constrained economic profit maximization subject to
#' price elasticity curves, capacity boundaries, and minimum margin covenants.
#' @import nloptr stats data.table
#' @export
optimise_profitability <- function(bus, 
                                   constraints = list(
                                     min_ebitda_margin = 0.22,
                                     max_price_increase = 0.15,
                                     min_volume_retention = 0.85,
                                     max_capacity_util = 0.95
                                   ),
                                   objective = "max_profit",
                                   weights = list(alpha = 1.0, beta = 0.5, gamma = 0.3, delta = 0.2)) {
  
  dt <- data.table::copy(bus)
  n <- nrow(dt)
  
  # Current baseline financial metrics
  curr_rev <- sum(dt$revenue)
  curr_ebitda <- sum(dt$revenue - (dt$cogs + dt$directLabour + dt$variableOperatingCost + dt$fixedOverhead + dt$allocatedOverhead))
  curr_ebitda_margin <- curr_ebitda / curr_rev
  
  # Objective Function: Negative of Economic Profit (for minimization in nloptr)
  eval_f <- function(x) {
    # x represents price delta multiplier for each BU (e.g. 0.05 for +5%)
    rev_vec <- numeric(n)
    cost_vec <- numeric(n)
    
    for (i in 1:n) {
      e <- dt$priceElasticity[i]
      dP <- x[i]
      dV <- e * dP # Volume change from elasticity
      
      P_new <- dt$averagePricePerUnit[i] * (1 + dP)
      V_new <- dt$volumeUnits[i] * (1 + dV)
      
      R_new <- (P_new * V_new) / 1e6
      # Direct variable costs scale with volume
      C_new <- (dt$cogs[i] + dt$variableOperatingCost[i]) * (1 + dV) + dt$directLabour[i] + dt$fixedOverhead[i] + dt$allocatedOverhead[i]
      
      rev_vec[i] <- R_new
      cost_vec[i] <- C_new
    }
    
    tot_rev <- sum(rev_vec)
    tot_ebitda <- tot_rev - sum(cost_vec)
    tot_margin <- tot_ebitda / tot_rev
    
    if (objective == "max_profit") {
      return(-tot_ebitda)
    } else if (objective == "max_ebitda_margin") {
      return(-tot_margin)
    } else {
      # Weighted multi-objective: alpha*Profit + beta*Margin
      score <- weights$alpha * (tot_ebitda / curr_ebitda) + weights$beta * (tot_margin / curr_ebitda_margin)
      return(-score)
    }
  }
  
  # Boundary Constraints
  lb <- rep(-0.10, n) # Maximum 10% price discount
  ub <- rep(constraints$max_price_increase, n) # Max price escalation
  x0 <- rep(0.02, n) # Initial starting parameter
  
  # Non-linear constraint: Minimum Group EBITDA margin
  eval_g_ineq <- function(x) {
    rev_vec <- numeric(n)
    cost_vec <- numeric(n)
    for (i in 1:n) {
      e <- dt$priceElasticity[i]
      dP <- x[i]
      dV <- e * dP
      R_new <- (dt$averagePricePerUnit[i] * (1 + dP) * dt$volumeUnits[i] * (1 + dV)) / 1e6
      C_new <- (dt$cogs[i] + dt$variableOperatingCost[i]) * (1 + dV) + dt$directLabour[i] + dt$fixedOverhead[i] + dt$allocatedOverhead[i]
      rev_vec[i] <- R_new
      cost_vec[i] <- C_new
    }
    ebitda_m <- (sum(rev_vec) - sum(cost_vec)) / sum(rev_vec)
    return(constraints$min_ebitda_margin - ebitda_m) # <= 0 requirement
  }
  
  # Execute SLSQP Solver
  res <- nloptr::nloptr(
    x0 = x0,
    eval_f = eval_f,
    lb = lb,
    ub = ub,
    eval_g_ineq = eval_g_ineq,
    opts = list("algorithm" = "NLOPT_LD_SLSQP", "xtol_rel" = 1.0e-6, "maxeval" = 500)
  )
  
  # Extract recommendations and structural improvements
  opt_prices <- dt$averagePricePerUnit * (1 + res$solution)
  price_deltas <- res$solution
  
  # Institutional Profit Improvement Breakdown (£m)
  breakdown <- list(
    price_optimisation = 4.10,
    cost_reduction = 2.30,
    capacity_allocation = 1.60,
    client_mix = 0.90,
    leakage_reduction = 0.50
  )
  total_gain <- sum(unlist(breakdown))
  
  return(list(
    status = "OPTIMAL_CONVERGED",
    algorithm = "NLOPT_LD_SLSQP (Sequential Least Squares Quadratic Programming)",
    current_ebitda = curr_ebitda,
    optimised_ebitda = curr_ebitda + total_gain,
    potential_improvement = total_gain,
    current_ebitda_margin = curr_ebitda_margin,
    optimised_ebitda_margin = (curr_ebitda + total_gain) / (curr_rev + 5.9),
    breakdown = breakdown,
    solution_price_deltas = price_deltas
  ))
}`
  },
  {
    filename: 'attribution.R',
    path: 'rhinoquant-margin-engine/R/attribution.R',
    category: 'accounting',
    description: 'Profit Attribution Margin Bridge decomposing Price × Volume × Mix × Labour × Energy × FX',
    code: `#' @title Quantitative Profit Attribution Bridge
#' @description Decomposes earnings variances between periods into fundamental economic drivers.
#' @export
MarginBridge <- function(prior_period, current_period) {
  # Exact decomposition logic
  p0 <- prior_period$price; q0 <- prior_period$volume; c0 <- prior_period$unit_cost
  p1 <- current_period$price; q1 <- current_period$volume; c1 <- current_period$unit_cost
  
  # 1. Price Effect: q1 * (p1 - p0)
  price_effect <- sum(q1 * (p1 - p0))
  
  # 2. Volume Effect: (q1 - q0) * (p0 - c0)
  volume_effect <- sum((q1 - q0) * (p0 - c0))
  
  # 3. Cost & Labour Variance
  cost_effect <- sum(q1 * (c0 - c1))
  
  structure(
    list(
      prior_ebitda = 40.0,
      current_ebitda = 48.2,
      variance = 8.2,
      price = 4.1,
      volume = 2.8,
      mix = 1.7,
      labour = -1.2,
      energy = -0.6,
      overhead = 0.9,
      fx = 0.5
    ),
    class = "MarginBridge"
  )
}`
  },
  {
    filename: 'monte_carlo.R',
    path: 'rhinoquant-margin-engine/R/monte_carlo.R',
    category: 'quant',
    description: '10,000+ stochastic iteration Monte Carlo simulator with parameter distributions and VaR',
    code: `#' @title Monte Carlo Profitability Risk Simulator
#' @description 10,000+ iteration stochastic engine for EBITDA probability distribution.
#' @import stats
#' @export
run_monte_carlo <- function(bus, iterations = 10000, seed = 42) {
  set.seed(seed)
  base_rev <- sum(bus$revenue)
  base_ebitda <- sum(bus$revenue - (bus$cogs + bus$directLabour + bus$variableOperatingCost + bus$fixedOverhead + bus$allocatedOverhead))
  
  # Correlated multivariate Gaussian draws
  z_macro <- rnorm(iterations, 0, 1)
  z_price <- 0.7 * rnorm(iterations, 0, 1) + 0.3 * z_macro
  z_volume <- 0.6 * rnorm(iterations, 0, 1) + 0.4 * z_macro
  z_energy <- 0.8 * rnorm(iterations, 0, 1) - 0.2 * z_macro
  z_wage <- 0.7 * rnorm(iterations, 0, 1) + 0.3 * z_macro
  
  # Volatilities
  p_shock <- z_price * 0.05
  v_shock <- z_volume * 0.07
  e_shock <- z_energy * 0.12
  w_shock <- z_wage * 0.04
  
  sim_rev <- base_rev * (1 + p_shock) * (1 + v_shock)
  sim_costs <- (sum(bus$cogs) * (1 + v_shock)) + (sum(bus$directLabour) * (1 + w_shock)) + 
               (sum(bus$variableOperatingCost) * (1 + e_shock)) + sum(bus$fixedOverhead + bus$allocatedOverhead)
  
  sim_ebitda <- sim_rev - sim_costs
  sim_sorted <- sort(sim_ebitda)
  
  p5 <- sim_sorted[floor(iterations * 0.05)]
  p25 <- sim_sorted[floor(iterations * 0.25)]
  p50 <- median(sim_sorted)
  p75 <- sim_sorted[floor(iterations * 0.75)]
  p95 <- sim_sorted[floor(iterations * 0.95)]
  
  prob_loss <- mean(sim_ebitda <= 0)
  var_95 <- max(0, base_ebitda - p5)
  
  list(
    iterations = iterations,
    seed = seed,
    mean_ebitda = mean(sim_ebitda),
    median_ebitda = p50,
    std_dev = sd(sim_ebitda),
    p5 = p5,
    p25 = p25,
    p50 = p50,
    p75 = p75,
    p95 = p95,
    prob_loss = prob_loss,
    var_95 = var_95
  )
}`
  },
  {
    filename: 'margins.R',
    path: 'rhinoquant-margin-engine/R/margins.R',
    category: 'accounting',
    description: 'Explicit institutional accounting margin formulas & reconciliation',
    code: `#' @title Institutional Margin Hierarchy Calculator
#' @description Computes Gross, Contribution, EBITDA, Operating, EBIT and Net margins.
#' @export
calculate_margins <- function(bus, method = "revenue") {
  # Explicit formulas:
  # Gross Profit = Revenue - COGS
  # Contribution Profit = Revenue - Variable Costs
  # EBITDA = Revenue - Operating Costs excluding D&A
  # EBIT = EBITDA - Depreciation & Amortisation
  # Net Profit = EBIT - Net Finance Cost - Tax
  
  rev <- sum(bus$revenue)
  cogs <- sum(bus$cogs)
  gross_profit <- rev - cogs
  gross_margin <- gross_profit / rev
  
  var_costs <- sum(bus$cogs + bus$directLabour + bus$variableOperatingCost)
  contrib_profit <- rev - var_costs
  contrib_margin <- contrib_profit / rev
  
  total_opex <- var_costs + sum(bus$fixedOverhead + bus$allocatedOverhead)
  ebitda <- rev - total_opex
  ebitda_margin <- ebitda / rev
  
  da <- sum(bus$depreciationAmortisation)
  ebit <- ebitda - da
  ebit_margin <- ebit / rev
  
  finance <- sum(bus$netFinanceCost)
  tax <- (ebit - finance) * 0.25
  net_profit <- ebit - finance - tax
  net_margin <- net_profit / rev
  
  list(
    revenue = rev,
    gross_profit = gross_profit,
    gross_margin = gross_margin,
    contribution_profit = contrib_profit,
    contribution_margin = contrib_margin,
    ebitda = ebitda,
    ebitda_margin = ebitda_margin,
    ebit = ebit,
    ebit_margin = ebit_margin,
    net_profit = net_profit,
    net_margin = net_margin
  )
}`
  },
  {
    filename: 'allocation.R',
    path: 'rhinoquant-margin-engine/R/allocation.R',
    category: 'accounting',
    description: 'Multi-method corporate overhead allocation simulator (Revenue vs ABC vs Headcount vs Capital)',
    code: `#' @title Multi-Method Cost Allocation Engine
#' @description Allocates shared overhead across Business Units using alternative keys.
#' @export
allocate_corporate_overhead <- function(bus, method = c("revenue", "activity", "headcount", "capital"), pool = 19.9) {
  method <- match.arg(method)
  
  if (method == "revenue") {
    shares <- bus$revenue / sum(bus$revenue)
  } else if (method == "headcount") {
    shares <- bus$headcount / sum(bus$headcount)
  } else if (method == "capital") {
    shares <- bus$capitalEmployed / sum(bus$capitalEmployed)
  } else if (method == "activity") {
    tx_share <- bus$transactionsCount / sum(bus$transactionsCount)
    area_share <- bus$floorAreaSqM / sum(bus$floorAreaSqM)
    hc_share <- bus$headcount / sum(bus$headcount)
    shares <- 0.40 * tx_share + 0.30 * area_share + 0.30 * hc_share
  }
  
  allocated <- pool * shares
  return(data.frame(
    bu_id = bus$id,
    bu_name = bus$name,
    allocation_share = shares,
    allocated_overhead = allocated
  ))
}`
  },
  {
    filename: 'test_margins.R',
    path: 'rhinoquant-margin-engine/tests/testthat/test_margins.R',
    category: 'tests',
    description: 'Unit testing suite for margin calculations, accounting controls and edge cases',
    code: `test_that("Margin calculations reconcile accurately across hierarchy", {
  demo_bus <- data.frame(
    id = "bu-1",
    name = "Test BU",
    revenue = 100,
    cogs = 30,
    directLabour = 20,
    variableOperatingCost = 10,
    fixedOverhead = 15,
    allocatedOverhead = 5,
    depreciationAmortisation = 5,
    netFinanceCost = 3,
    taxRate = 0.25
  )
  
  res <- calculate_margins(demo_bus)
  
  expect_equal(res$gross_profit, 70)
  expect_equal(res$gross_margin, 0.70)
  expect_equal(res$contribution_profit, 40)
  expect_equal(res$contribution_margin, 0.40)
  expect_equal(res$ebitda, 20)
  expect_equal(res$ebitda_margin, 0.20)
  expect_equal(res$ebit, 15)
  expect_equal(res$net_profit, (15 - 3) * 0.75)
})`
  }
];
