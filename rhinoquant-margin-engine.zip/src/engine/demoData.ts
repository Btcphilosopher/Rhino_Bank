/**
 * RHINO INFRASTRUCTURE HOLDINGS
 * Institutional Demonstration Dataset for RhinoQuant Margin Engine (RQME)
 * 
 * Note: Clearly labelled DEMONSTRATION DATA (Fictional quantitative financial structures)
 */

import {
  BusinessUnit,
  RevenueStream,
  CostItem,
  ProductService,
  ClientProfile,
  ProjectFinanceModel,
  MarginLeakageItem,
  ProfitOpportunityItem,
  FXRate,
  ScenarioDefinition
} from '../types';

export const DEMO_METADATA = {
  companyName: 'Rhino Infrastructure Holdings PLC',
  ticker: 'RIH.L',
  reportingCurrency: 'GBP' as const,
  reportingPeriod: 'FY2025 / Q4 Annualised',
  analyst: 'A. Sterling, CFA (RhinoQuant Principal Quantitative Analyst)',
  version: 'RQME-v4.2.1-PROD',
  datasetStatus: 'DEMONSTRATION DATA — INSTITUTIONAL QUANT SPECIFICATION',
  totalEmployees: 1420,
};

export const FX_RATES: Record<string, FXRate> = {
  'GBP/USD': { pair: 'GBP/USD', rate: 1.2850, inverseRate: 0.7782, date: '2025-12-31' },
  'GBP/EUR': { pair: 'GBP/EUR', rate: 1.1740, inverseRate: 0.8518, date: '2025-12-31' },
  'GBP/CHF': { pair: 'GBP/CHF', rate: 1.1420, inverseRate: 0.8757, date: '2025-12-31' },
  'GBP/JPY': { pair: 'GBP/JPY', rate: 198.40, inverseRate: 0.00504, date: '2025-12-31' },
  'GBP/CNY': { pair: 'GBP/CNY', rate: 9.2450, inverseRate: 0.1082, date: '2025-12-31' },
  'GBP/GBP': { pair: 'GBP/GBP', rate: 1.0000, inverseRate: 1.0000, date: '2025-12-31' }
};

export const DEMO_BUSINESS_UNITS: BusinessUnit[] = [
  {
    id: 'bu-infra-fin',
    name: 'Infrastructure Finance',
    code: 'INFRA-FIN',
    sector: 'Specialised Debt & Syndication',
    description: 'Project debt structuring, syndicated lending, and infrastructure mezzanine facilities.',
    headcount: 145,
    capitalEmployed: 210.0, // £m
    floorAreaSqM: 3200,
    transactionsCount: 84,
    
    revenue: 48.6,
    cogs: 8.2,
    directLabour: 11.4,
    variableOperatingCost: 3.6,
    fixedOverhead: 6.8,
    allocatedOverhead: 4.4,
    depreciationAmortisation: 1.2,
    netFinanceCost: 3.8,
    taxRate: 0.25,
    
    priceIndex: 100.0,
    volumeUnits: 84, // mandates completed
    unitOfMeasure: 'Deals & Mandates',
    averagePricePerUnit: 578571, // £578k per mandate
    directCostPerUnit: 233333,
    priceElasticity: -0.85, // Low elasticity / high pricing power
    capacityLimit: 110,
    currentUtilisation: 0.76
  },
  {
    id: 'bu-energy',
    name: 'Energy & Renewables',
    code: 'ENERGY-REN',
    sector: 'Utility & Grid Storage',
    description: 'Offshore wind generation, solar array assets, and grid-scale BESS battery storage.',
    headcount: 310,
    capitalEmployed: 340.0,
    floorAreaSqM: 14500,
    transactionsCount: 1820,
    
    revenue: 54.2,
    cogs: 16.4,
    directLabour: 9.8,
    variableOperatingCost: 7.2,
    fixedOverhead: 5.6,
    allocatedOverhead: 4.8,
    depreciationAmortisation: 6.4,
    netFinanceCost: 5.2,
    taxRate: 0.25,
    
    priceIndex: 100.0,
    volumeUnits: 485000, // MWh generated
    unitOfMeasure: 'MWh',
    averagePricePerUnit: 111.75, // £/MWh
    directCostPerUnit: 54.02,
    priceElasticity: -1.65, // Moderate elasticity (power purchase contracts)
    capacityLimit: 580000,
    currentUtilisation: 0.836
  },
  {
    id: 'bu-data-centres',
    name: 'Tier 4 Data Centres',
    code: 'DATA-CENTRE',
    sector: 'Hyperscale Infrastructure',
    description: 'Ultra-low latency colocation, enterprise cloud hosting, and sovereign AI compute suites.',
    headcount: 220,
    capitalEmployed: 280.0,
    floorAreaSqM: 42000,
    transactionsCount: 420,
    
    revenue: 44.8,
    cogs: 9.6,
    directLabour: 7.2,
    variableOperatingCost: 6.8, // Power/cooling
    fixedOverhead: 4.8,
    allocatedOverhead: 3.6,
    depreciationAmortisation: 5.8,
    netFinanceCost: 4.1,
    taxRate: 0.25,
    
    priceIndex: 100.0,
    volumeUnits: 2800, // Rack units active
    unitOfMeasure: 'Rack Units (kW equivalent)',
    averagePricePerUnit: 16000, // £16,000 / kW-year
    directCostPerUnit: 6000,
    priceElasticity: -0.92, // Strong pricing power (hyperscaler switching costs)
    capacityLimit: 3200,
    currentUtilisation: 0.875
  },
  {
    id: 'bu-transport',
    name: 'Transport & Port Logistics',
    code: 'TRANS-PORT',
    sector: 'Intermodal Logistics',
    description: 'Deep-sea container port operations, dry bulk terminals, and intermodal freight corridors.',
    headcount: 460,
    capitalEmployed: 195.0,
    floorAreaSqM: 180000,
    transactionsCount: 38500,
    
    revenue: 28.4,
    cogs: 11.2,
    directLabour: 7.8,
    variableOperatingCost: 3.4,
    fixedOverhead: 3.2,
    allocatedOverhead: 2.8,
    depreciationAmortisation: 3.1,
    netFinanceCost: 2.4,
    taxRate: 0.25,
    
    priceIndex: 100.0,
    volumeUnits: 240000, // TEU containers handled
    unitOfMeasure: 'TEU Container',
    averagePricePerUnit: 118.33,
    directCostPerUnit: 79.16,
    priceElasticity: -2.10, // Elastic (competition from nearby hubs)
    capacityLimit: 300000,
    currentUtilisation: 0.80
  },
  {
    id: 'bu-property',
    name: 'Commercial Property',
    code: 'COMM-PROP',
    sector: 'Prime Real Estate & Science Parks',
    description: 'Grade-A life sciences campuses, green logistics hubs, and modern business parks.',
    headcount: 95,
    capitalEmployed: 260.0,
    floorAreaSqM: 120000,
    transactionsCount: 140,
    
    revenue: 16.2,
    cogs: 2.8,
    directLabour: 2.1,
    variableOperatingCost: 1.9,
    fixedOverhead: 3.4,
    allocatedOverhead: 2.2,
    depreciationAmortisation: 2.9,
    netFinanceCost: 3.6,
    taxRate: 0.25,
    
    priceIndex: 100.0,
    volumeUnits: 98000, // sq m leased
    unitOfMeasure: 'sq m leased',
    averagePricePerUnit: 165.30,
    directCostPerUnit: 48.97,
    priceElasticity: -1.20,
    capacityLimit: 120000,
    currentUtilisation: 0.816
  },
  {
    id: 'bu-advisory',
    name: 'Advisory & Capital Markets',
    code: 'ADV-DCM',
    sector: 'Investment Banking & M&A',
    description: 'Project advisory, ESG bond underwriting, restructuring, and infrastructure M&A.',
    headcount: 190,
    capitalEmployed: 45.0,
    floorAreaSqM: 3800,
    transactionsCount: 112,
    
    revenue: 7.8,
    cogs: 0.6,
    directLabour: 3.9,
    variableOperatingCost: 0.8,
    fixedOverhead: 1.4,
    allocatedOverhead: 1.1,
    depreciationAmortisation: 0.3,
    netFinanceCost: 0.4,
    taxRate: 0.25,
    
    priceIndex: 100.0,
    volumeUnits: 112, // Engagements
    unitOfMeasure: 'Retainers & Milestones',
    averagePricePerUnit: 69642,
    directCostPerUnit: 40178,
    priceElasticity: -0.65, // Highly inelastic advisory fees
    capacityLimit: 140,
    currentUtilisation: 0.80
  }
];

export const DEMO_REVENUE_STREAMS: RevenueStream[] = [
  { id: 'rs-1', buId: 'bu-infra-fin', name: 'Project Loan Arrangement Fees', type: 'advisory', recurring: false, revenue: 22.4, priorPeriodRevenue: 19.8, growthRate: 0.131, clientCount: 38 },
  { id: 'rs-2', buId: 'bu-infra-fin', name: 'Net Interest Margin on Senior Debt', type: 'interest', recurring: true, revenue: 18.6, priorPeriodRevenue: 17.2, growthRate: 0.081, clientCount: 52 },
  { id: 'rs-3', buId: 'bu-infra-fin', name: 'Mezzanine Facility Participation Fees', type: 'contract', recurring: true, revenue: 7.6, priorPeriodRevenue: 6.9, growthRate: 0.101, clientCount: 19 },
  
  { id: 'rs-4', buId: 'bu-energy', name: 'Offshore Wind Generation (PPA Index)', type: 'unit_sales', recurring: true, revenue: 26.8, priorPeriodRevenue: 24.5, growthRate: 0.094, clientCount: 14 },
  { id: 'rs-5', buId: 'bu-energy', name: 'Solar PV Feed-in Tariff & Merchant Power', type: 'unit_sales', recurring: false, revenue: 15.2, priorPeriodRevenue: 14.1, growthRate: 0.078, clientCount: 22 },
  { id: 'rs-6', buId: 'bu-energy', name: 'BESS Grid Frequency Response Contracts', type: 'subscription', recurring: true, revenue: 12.2, priorPeriodRevenue: 9.8, growthRate: 0.245, clientCount: 6 },
  
  { id: 'rs-7', buId: 'bu-data-centres', name: 'Tier 4 Dedicated AI Compute Hosting', type: 'contract', recurring: true, revenue: 23.4, priorPeriodRevenue: 17.5, growthRate: 0.337, clientCount: 18 },
  { id: 'rs-8', buId: 'bu-data-centres', name: 'Enterprise Hybrid Cloud Colocation', type: 'subscription', recurring: true, revenue: 16.2, priorPeriodRevenue: 15.4, growthRate: 0.052, clientCount: 64 },
  { id: 'rs-9', buId: 'bu-data-centres', name: 'Cross-Connect & Sovereign Telemetry', type: 'licensing', recurring: true, revenue: 5.2, priorPeriodRevenue: 4.8, growthRate: 0.083, clientCount: 88 },
  
  { id: 'rs-10', buId: 'bu-transport', name: 'Port Wharfage & Container Crane Dwell', type: 'unit_sales', recurring: false, revenue: 16.8, priorPeriodRevenue: 16.5, growthRate: 0.018, clientCount: 140 },
  { id: 'rs-11', buId: 'bu-transport', name: 'Dedicated Rail Freight Corridor Access', type: 'contract', recurring: true, revenue: 8.4, priorPeriodRevenue: 7.9, growthRate: 0.063, clientCount: 18 },
  { id: 'rs-12', buId: 'bu-transport', name: 'Customs & Bonded Cold Storage Operations', type: 'rental', recurring: true, revenue: 3.2, priorPeriodRevenue: 3.0, growthRate: 0.067, clientCount: 45 },
  
  { id: 'rs-13', buId: 'bu-property', name: 'Life Science Innovation Park Leases', type: 'rental', recurring: true, revenue: 11.4, priorPeriodRevenue: 10.2, growthRate: 0.118, clientCount: 32 },
  { id: 'rs-14', buId: 'bu-property', name: 'Green Logistics Warehouse Master Leases', type: 'contract', recurring: true, revenue: 4.8, priorPeriodRevenue: 4.6, growthRate: 0.043, clientCount: 12 },
  
  { id: 'rs-15', buId: 'bu-advisory', name: 'Infrastructure M&A Retainers & Success Fees', type: 'advisory', recurring: false, revenue: 5.2, priorPeriodRevenue: 4.4, growthRate: 0.182, clientCount: 28 },
  { id: 'rs-16', buId: 'bu-advisory', name: 'Green Bond Structuring & ESG Syndication', type: 'advisory', recurring: false, revenue: 2.6, priorPeriodRevenue: 2.1, growthRate: 0.238, clientCount: 16 }
];

export const DEMO_COST_ITEMS: CostItem[] = [
  { id: 'ci-1', buId: 'bu-energy', name: 'Turbine Blade Maintenance & Spares', category: 'variable', amount: 9.4, costDriver: 'volume', variabilityPercent: 90, inflationSensitivity: 1.15 },
  { id: 'ci-2', buId: 'bu-energy', name: 'Grid Connection & Balancing Tariffs', category: 'semi_variable', amount: 7.0, costDriver: 'capacity', variabilityPercent: 65, inflationSensitivity: 1.30 },
  { id: 'ci-3', buId: 'bu-data-centres', name: 'High-Density Chiller Power Consumption', category: 'variable', amount: 8.8, costDriver: 'volume', variabilityPercent: 95, inflationSensitivity: 1.45 },
  { id: 'ci-4', buId: 'bu-data-centres', name: 'Hyperscale Optical Fibre Carrier Leases', category: 'fixed', amount: 4.8, costDriver: 'fixed', variabilityPercent: 10, inflationSensitivity: 0.40 },
  { id: 'ci-5', buId: 'bu-transport', name: 'Diesel Bunker Fuel & Tugboat Operations', category: 'variable', amount: 6.8, costDriver: 'volume', variabilityPercent: 100, inflationSensitivity: 1.60 },
  { id: 'ci-6', buId: 'bu-transport', name: 'Stevedoring & Heavy Equipment Labour', category: 'semi_variable', amount: 7.8, costDriver: 'headcount', variabilityPercent: 60, inflationSensitivity: 0.95 },
  { id: 'ci-7', buId: 'bu-infra-fin', name: 'Deal Origination & Legal Documentation Retainers', category: 'semi_variable', amount: 5.4, costDriver: 'volume', variabilityPercent: 50, inflationSensitivity: 0.80 },
  { id: 'ci-8', buId: 'bu-advisory', name: 'Senior Partner & Managing Director Compensation', category: 'semi_variable', amount: 3.9, costDriver: 'headcount', variabilityPercent: 40, inflationSensitivity: 0.75 },
  { id: 'ci-9', buId: 'bu-property', name: 'Facilities Management, Security & Climate Systems', category: 'fixed', amount: 3.4, costDriver: 'capacity', variabilityPercent: 20, inflationSensitivity: 0.90 }
];

export const DEMO_PRODUCTS: ProductService[] = [
  { id: 'prod-1', buId: 'bu-infra-fin', name: 'Senior Project Debt Facility (>£50m)', price: 650000, unitCost: 240000, volume: 42, unitOfMeasure: 'Deals', revenue: 27.3, grossMarginPercent: 63.1, contributionMarginPercent: 58.5, elasticity: -0.75, capacityConsumptionPerUnit: 1.0, competitorPrice: 620000, pricingPowerScore: 8.4 },
  { id: 'prod-2', buId: 'bu-infra-fin', name: 'Mezzanine / Subordinated Debt Tranche', price: 480000, unitCost: 190000, volume: 36, unitOfMeasure: 'Deals', revenue: 17.3, grossMarginPercent: 60.4, contributionMarginPercent: 54.2, elasticity: -0.95, capacityConsumptionPerUnit: 0.8, competitorPrice: 490000, pricingPowerScore: 7.8 },
  { id: 'prod-3', buId: 'bu-energy', name: 'Offshore Wind Baseload Contract (PPA)', price: 118.5, unitCost: 48.2, volume: 226000, unitOfMeasure: 'MWh', revenue: 26.8, grossMarginPercent: 59.3, contributionMarginPercent: 52.1, elasticity: -1.45, capacityConsumptionPerUnit: 1.0, competitorPrice: 115.0, pricingPowerScore: 6.9 },
  { id: 'prod-4', buId: 'bu-energy', name: 'Solar PV Peak Generation Feed-in', price: 102.0, unitCost: 59.4, volume: 149000, unitOfMeasure: 'MWh', revenue: 15.2, grossMarginPercent: 41.8, contributionMarginPercent: 36.5, elasticity: -1.95, capacityConsumptionPerUnit: 0.7, competitorPrice: 104.0, pricingPowerScore: 5.2 },
  { id: 'prod-5', buId: 'bu-data-centres', name: 'Dedicated Sovereign AI Compute Pod (64-rack)', price: 385000, unitCost: 142000, volume: 44, unitOfMeasure: 'Pods', revenue: 16.9, grossMarginPercent: 63.1, contributionMarginPercent: 57.8, elasticity: -0.68, capacityConsumptionPerUnit: 2.2, competitorPrice: 360000, pricingPowerScore: 9.1 },
  { id: 'prod-6', buId: 'bu-data-centres', name: 'Tier 4 High-Density Enterprise Colocation', price: 14200, unitCost: 5100, volume: 1420, unitOfMeasure: 'Racks', revenue: 20.2, grossMarginPercent: 64.1, contributionMarginPercent: 59.2, elasticity: -0.88, capacityConsumptionPerUnit: 1.0, competitorPrice: 14000, pricingPowerScore: 8.2 },
  { id: 'prod-7', buId: 'bu-transport', name: 'Automated Port Container Handling (TEU)', price: 122.0, unitCost: 81.5, volume: 138000, unitOfMeasure: 'TEUs', revenue: 16.8, grossMarginPercent: 33.2, contributionMarginPercent: 28.4, elasticity: -2.35, capacityConsumptionPerUnit: 1.0, competitorPrice: 120.0, pricingPowerScore: 4.1 },
  { id: 'prod-8', buId: 'bu-transport', name: 'Intermodal Rail Freight Block Train (40-car)', price: 18200, unitCost: 12400, volume: 460, unitOfMeasure: 'Trains', revenue: 8.4, grossMarginPercent: 31.9, contributionMarginPercent: 26.8, elasticity: -1.85, capacityConsumptionPerUnit: 2.5, competitorPrice: 18500, pricingPowerScore: 4.9 },
  { id: 'prod-9', buId: 'bu-property', name: 'Wet-Lab Grade A Bio-Innovation Space', price: 420.0, unitCost: 110.0, volume: 27100, unitOfMeasure: 'sq m', revenue: 11.4, grossMarginPercent: 73.8, contributionMarginPercent: 68.2, elasticity: -0.82, capacityConsumptionPerUnit: 1.0, competitorPrice: 405.0, pricingPowerScore: 8.7 },
  { id: 'prod-10', buId: 'bu-advisory', name: 'Infrastructure M&A Lead Mandate', price: 185000, unitCost: 65000, volume: 28, unitOfMeasure: 'Mandates', revenue: 5.2, grossMarginPercent: 64.9, contributionMarginPercent: 61.2, elasticity: -0.62, capacityConsumptionPerUnit: 1.2, competitorPrice: 190000, pricingPowerScore: 8.9 }
];

export const DEMO_CLIENTS: ClientProfile[] = [
  { id: 'cl-1', name: 'National Grid & European Utilities Consortium', tier: 'tier_1_strategic', sector: 'Power & Utilities', revenue: 24.8, directCost: 7.2, allocatedCost: 4.1, capitalUsage: 48.0, riskCost: 0.6, fundingCost: 1.2, netContribution: 11.7, marginPercent: 47.2, classification: 'HIGH VALUE', relationshipYears: 11, contractExpiry: '2031-09-30' },
  { id: 'cl-2', name: 'Global Hyperscale Cloud Alpha Inc.', tier: 'tier_1_strategic', sector: 'Technology / Cloud', revenue: 21.6, directCost: 6.4, allocatedCost: 3.4, capitalUsage: 38.0, riskCost: 0.3, fundingCost: 0.9, netContribution: 10.6, marginPercent: 49.1, classification: 'HIGH VALUE', relationshipYears: 7, contractExpiry: '2030-03-31' },
  { id: 'cl-3', name: 'Meridian Sovereign Wealth Infrastructure Fund', tier: 'tier_1_strategic', sector: 'Sovereign Capital', revenue: 18.2, directCost: 4.8, allocatedCost: 2.8, capitalUsage: 32.0, riskCost: 0.4, fundingCost: 0.8, netContribution: 9.4, marginPercent: 51.6, classification: 'HIGH VALUE', relationshipYears: 9, contractExpiry: '2029-12-31' },
  { id: 'cl-4', name: 'Atlantic Intermodal Freight Alliance', tier: 'tier_2_core', sector: 'Shipping & Freight', revenue: 14.5, directCost: 6.8, allocatedCost: 2.9, capitalUsage: 22.0, riskCost: 0.8, fundingCost: 0.7, netContribution: 3.3, marginPercent: 22.8, classification: 'PROFITABLE', relationshipYears: 5, contractExpiry: '2027-06-30' },
  { id: 'cl-5', name: 'Cambridge Bio-Therapeutics Cluster', tier: 'tier_2_core', sector: 'Life Sciences / Biotech', revenue: 10.8, directCost: 3.1, allocatedCost: 1.8, capitalUsage: 19.0, riskCost: 0.2, fundingCost: 0.5, netContribution: 5.2, marginPercent: 48.1, classification: 'HIGH VALUE', relationshipYears: 4, contractExpiry: '2028-11-30' },
  { id: 'cl-6', name: 'Nordic Clean Energy Grid SPV', tier: 'tier_2_core', sector: 'Renewables', revenue: 9.4, directCost: 4.2, allocatedCost: 1.9, capitalUsage: 16.0, riskCost: 0.5, fundingCost: 0.4, netContribution: 2.4, marginPercent: 25.5, classification: 'PROFITABLE', relationshipYears: 3, contractExpiry: '2026-12-31' },
  { id: 'cl-7', name: 'Vanguard Trans-European Logistics Ltd', tier: 'tier_3_standard', sector: 'Logistics', revenue: 7.2, directCost: 4.6, allocatedCost: 1.8, capitalUsage: 12.0, riskCost: 0.7, fundingCost: 0.4, netContribution: -0.3, marginPercent: -4.2, classification: 'LOSS-MAKING', relationshipYears: 2, contractExpiry: '2026-04-30' },
  { id: 'cl-8', name: 'Apex Commodities Trading Desk', tier: 'tier_3_standard', sector: 'Commodities', revenue: 6.5, directCost: 3.9, allocatedCost: 1.7, capitalUsage: 11.0, riskCost: 0.6, fundingCost: 0.3, netContribution: 0.0, marginPercent: 0.0, classification: 'BREAKEVEN', relationshipYears: 3, contractExpiry: '2026-08-31' },
  { id: 'cl-9', name: 'Pacific Maritime Spot Freight Charterers', tier: 'tier_4_transactional', sector: 'Bulk Freight', revenue: 4.2, directCost: 3.1, allocatedCost: 1.1, capitalUsage: 6.5, riskCost: 0.5, fundingCost: 0.2, netContribution: -0.7, marginPercent: -16.7, classification: 'LOSS-MAKING', relationshipYears: 1, contractExpiry: '2026-01-31' },
  { id: 'cl-10', name: 'Metropolitan Commercial Retail SPV', tier: 'tier_4_transactional', sector: 'Real Estate', revenue: 3.8, directCost: 2.4, allocatedCost: 1.1, capitalUsage: 8.0, riskCost: 0.4, fundingCost: 0.3, netContribution: -0.4, marginPercent: -10.5, classification: 'LOSS-MAKING', relationshipYears: 2, contractExpiry: '2026-03-31' }
];

export const DEMO_PROJECT_FINANCE: ProjectFinanceModel = {
  id: 'proj-dc-hyperscale-ii',
  name: 'Project Thor: 120MW Hyperscale AI Campus (Phase II)',
  buId: 'bu-data-centres',
  totalCapex: 185.0, // £m
  equityShare: 0.30, // £55.5m equity
  debtShare: 0.70, // £129.5m senior debt
  debtInterestRate: 0.0575, // 5.75%
  tenorYears: 20,
  discountRate: 0.078, // WACC 7.8%
  npv: 68.4, // £m
  irr: 0.168, // 16.8% Equity IRR
  paybackYears: 5.4,
  averageDscr: 1.84,
  schedule: Array.from({ length: 20 }, (_, idx) => {
    const year = idx + 1;
    const ramp = year === 1 ? 0.45 : year === 2 ? 0.85 : 1.0;
    const rev = (32.0 + year * 0.6) * ramp;
    const opex = (8.4 + year * 0.18) * ramp;
    const ebitda = rev - opex;
    const depr = year <= 15 ? 185.0 / 15 : 0;
    const ebit = ebitda - depr;
    const principalPaid = year <= 12 ? 129.5 / 12 : 0;
    const remainingDebt = Math.max(0, 129.5 - principalPaid * (year - 1));
    const interest = remainingDebt * 0.0575;
    const tax = Math.max(0, (ebit - interest) * 0.25);
    const netIncome = ebit - interest - tax;
    const capex = year === 1 ? 25.0 : year === 8 ? 12.0 : 1.5;
    const debtService = principalPaid + interest;
    const freeCashFlow = ebitda - tax - capex - debtService;
    const dscr = debtService > 0 ? (ebitda - tax) / debtService : 9.99;
    
    return {
      year,
      revenue: Number(rev.toFixed(2)),
      operatingCosts: Number(opex.toFixed(2)),
      ebitda: Number(ebitda.toFixed(2)),
      depreciation: Number(depr.toFixed(2)),
      ebit: Number(ebit.toFixed(2)),
      interest: Number(interest.toFixed(2)),
      tax: Number(tax.toFixed(2)),
      netIncome: Number(netIncome.toFixed(2)),
      capex: Number(capex.toFixed(2)),
      freeCashFlow: Number(freeCashFlow.toFixed(2)),
      debtService: Number(debtService.toFixed(2)),
      dscr: Number(dscr.toFixed(2)),
      cumulativeCashFlow: 0 // Will be computed dynamically
    };
  })
};

// Calculate cumulative cash flow
let cum = -55.5; // Initial Equity Capex
DEMO_PROJECT_FINANCE.schedule.forEach(yr => {
  cum += yr.freeCashFlow;
  yr.cumulativeCashFlow = Number(cum.toFixed(2));
});

export const DEMO_MARGIN_LEAKAGES: MarginLeakageItem[] = [
  {
    id: 'leak-1',
    rank: 1,
    source: 'Commercial Off-Tariff Discounting & Unauthorised Concessions',
    annualImpact: -2.4,
    category: 'pricing',
    rootCause: 'Decentralised sales desk fee discretion exceeding pricing guidelines in Transport & Energy PPAs.',
    affectedUnits: ['Transport & Port Logistics', 'Energy & Renewables'],
    remediationDifficulty: 'Low'
  },
  {
    id: 'leak-2',
    rank: 2,
    source: 'Subcontractor Overtime & Peak Standby Premiums',
    annualImpact: -1.1,
    category: 'operations',
    rootCause: 'Unscheduled vessel delays at port terminals triggering 2.2x stevedoring overtime rates.',
    affectedUnits: ['Transport & Port Logistics'],
    remediationDifficulty: 'Medium'
  },
  {
    id: 'leak-3',
    rank: 3,
    source: 'Unhedged Energy & Chiller Power Tariff Inflation',
    annualImpact: -0.8,
    category: 'procurement',
    rootCause: 'Data Centre power pass-through lag in older 3-year legacy colocation master agreements.',
    affectedUnits: ['Tier 4 Data Centres'],
    remediationDifficulty: 'Low'
  },
  {
    id: 'leak-4',
    rank: 4,
    source: 'Unbilled Advisory Scope Creep & Out-of-Pocket Expenses',
    annualImpact: -0.6,
    category: 'commercial',
    rootCause: 'Infrastructure debt restructuring execution requiring 280+ unbilled quantitative modeling hours.',
    affectedUnits: ['Advisory & Capital Markets', 'Infrastructure Finance'],
    remediationDifficulty: 'Low'
  },
  {
    id: 'leak-5',
    rank: 5,
    source: 'Low-Margin & Loss-Making Legacy Cargo Contracts',
    annualImpact: -0.4,
    category: 'commercial',
    rootCause: 'Three multi-year spot freight charterers paying 18% below fully-absorbed cost floor.',
    affectedUnits: ['Transport & Port Logistics', 'Commercial Property'],
    remediationDifficulty: 'Medium'
  },
  {
    id: 'leak-6',
    rank: 6,
    source: 'Sub-Optimal Rack Capacity Reserve & Stranded Power',
    annualImpact: -0.3,
    category: 'capacity',
    rootCause: '400kW of data centre standby capacity reserved without contracted commitment fees.',
    affectedUnits: ['Tier 4 Data Centres'],
    remediationDifficulty: 'Low'
  }
];

export const DEMO_PROFIT_OPPORTUNITIES: ProfitOpportunityItem[] = [
  {
    id: 'opp-1',
    rank: 1,
    opportunity: 'Non-Linear Price Optimisation on Inelastic Products',
    category: 'PRICE OPTIMISATION',
    estimatedProfitImpact: 4.1,
    implementationCost: 0.25,
    riskLevel: 'Low',
    confidence: 86,
    timeToBenefitMonths: 2,
    actionPlan: 'Enforce +6.4% target price escalation on Infrastructure Debt Mandates and Sovereign AI Compute suites where elasticity is below |0.85|.'
  },
  {
    id: 'opp-2',
    rank: 2,
    opportunity: 'Direct Cost Rationalisation & Power Index Hedging',
    category: 'COST REDUCTION',
    estimatedProfitImpact: 2.3,
    implementationCost: 0.40,
    riskLevel: 'Moderate',
    confidence: 82,
    timeToBenefitMonths: 4,
    actionPlan: 'Renegotiate wind turbine parts consortium contracts and hedge 100% of data centre power pass-through formulas.'
  },
  {
    id: 'opp-3',
    rank: 3,
    opportunity: 'Scarce Capacity Reallocation to High-Contribution Pods',
    category: 'CAPACITY ALLOCATION',
    estimatedProfitImpact: 1.6,
    implementationCost: 0.60,
    riskLevel: 'Low',
    confidence: 88,
    timeToBenefitMonths: 3,
    actionPlan: 'Shift 380 rack units from standard colocation (£14.2k/rack) to high-density Sovereign AI Pods (£26.8k/equivalent).'
  },
  {
    id: 'opp-4',
    rank: 4,
    opportunity: 'Client Tier Restructuring & Loss-Making Account Repricing',
    category: 'CLIENT MIX',
    estimatedProfitImpact: 0.9,
    implementationCost: 0.15,
    riskLevel: 'Moderate',
    confidence: 79,
    timeToBenefitMonths: 3,
    actionPlan: 'Issue contract rate adjustment notices or minimum margin covenants to 3 loss-making transactional accounts (saving £0.9m).'
  },
  {
    id: 'opp-5',
    rank: 5,
    opportunity: 'Commercial Leakage Elimination & Tariff Governance',
    category: 'LEAKAGE REDUCTION',
    estimatedProfitImpact: 0.5,
    implementationCost: 0.10,
    riskLevel: 'Low',
    confidence: 94,
    timeToBenefitMonths: 1,
    actionPlan: 'Lock sales delegation matrix inside RhinoQuant CRM to prevent off-tariff discounts and capture 100% of billable out-of-scope advisory.'
  }
];

export const SCENARIO_PRESETS: ScenarioDefinition[] = [
  {
    id: 'base',
    name: 'Base Case (FY2025 Budget)',
    description: 'Current baseline operating conditions, standard CPI inflation (2.4%), steady volume demand.',
    priceShockPct: 0.0,
    volumeShockPct: 0.0,
    costInflationPct: 0.0,
    wageInflationPct: 0.0,
    energyShockPct: 0.0,
    fxShockPct: 0.0,
    interestRateShockPct: 0.0,
    taxRateChangePct: 0.0
  },
  {
    id: 'upside',
    name: 'Upside (Strong Infrastructure Expansion)',
    description: 'Accelerated European grid decarbonisation, surge in AI compute demand (+14%), favorable pricing power (+4.5%).',
    priceShockPct: 0.045,
    volumeShockPct: 0.082,
    costInflationPct: -0.015,
    wageInflationPct: 0.020,
    energyShockPct: -0.050,
    fxShockPct: 0.030,
    interestRateShockPct: -0.0050,
    taxRateChangePct: 0.0
  },
  {
    id: 'downside',
    name: 'Downside (Cyclical Slowdown)',
    description: 'Trade volume slowdown (-6.5%), mild industrial power tariff contraction, softening commercial real estate rents.',
    priceShockPct: -0.025,
    volumeShockPct: -0.058,
    costInflationPct: 0.032,
    wageInflationPct: 0.035,
    energyShockPct: 0.080,
    fxShockPct: -0.040,
    interestRateShockPct: 0.0075,
    taxRateChangePct: 0.0
  },
  {
    id: 'stress',
    name: 'Stress (Stagflation & Energy Shock)',
    description: 'Geopolitical supply chain bottleneck, energy price spike (+22%), wage inflation (+6%), transport cargo volume drops (-11%).',
    priceShockPct: -0.010,
    volumeShockPct: -0.105,
    costInflationPct: 0.075,
    wageInflationPct: 0.060,
    energyShockPct: 0.220,
    fxShockPct: -0.080,
    interestRateShockPct: 0.0150,
    taxRateChangePct: 0.020
  },
  {
    id: 'extreme_stress',
    name: 'Extreme Stress (Rhino Bank Regulatory Stress Test)',
    description: 'Severe multi-market crisis: volume collapse (-18%), debt repricing (+250 bps), sovereign currency shock, energy surge (+35%).',
    priceShockPct: -0.060,
    volumeShockPct: -0.180,
    costInflationPct: 0.120,
    wageInflationPct: 0.075,
    energyShockPct: 0.350,
    fxShockPct: -0.140,
    interestRateShockPct: 0.0250,
    taxRateChangePct: 0.030
  }
];
