/**
 * RhinoQuant Synthetic Shorts - Portfolio Risk & Non-Linear Aggregation Terminal
 * Consolidated Book Greeks, Delta-Neutral Hedging, Parametric & Monte Carlo VaR, and Expected Shortfall
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useMemo, useState } from 'react';
import { StrategyDefinition } from '../quant/instruments';
import { buildPortfolioRiskReport } from '../quant/risk';
import { Shield, TrendingDown, Layers, AlertCircle, RefreshCw } from 'lucide-react';

interface PortfolioRiskViewProps {
  portfolioStrategies: StrategyDefinition[];
  onRemoveStrategyFromPortfolio?: (strategyId: string) => void;
}

export const PortfolioRiskView: React.FC<PortfolioRiskViewProps> = ({
  portfolioStrategies,
  onRemoveStrategyFromPortfolio,
}) => {
  const [confidenceLevel, setConfidenceLevel] = useState<number>(0.95);
  const [timeHorizon, setTimeHorizon] = useState<number>(1);

  const report = useMemo(() => {
    return buildPortfolioRiskReport(portfolioStrategies);
  }, [portfolioStrategies]);

  const { greeks, margin, var95_1Day, var99_10Day } = report;

  return (
    <div className="space-y-4">
      {/* Risk Alert & Status Banner */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-3">
          <div
            className={`w-3 h-3 rounded-full ${
              report.riskStatus === 'NORMAL'
                ? 'bg-emerald-400'
                : report.riskStatus === 'ELEVATED'
                ? 'bg-amber-400'
                : 'bg-rose-500 animate-pulse'
            }`}
          />
          <span className="font-bold text-slate-100">
            Book Status: <span className="text-cyan-400">{report.riskStatus}</span>
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">
            Positions: <strong className="text-slate-200">{report.totalPositions} Legs</strong> ({portfolioStrategies.length} Strategies)
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">
            Gross Notional: <strong className="text-slate-200">${report.grossNotional.toLocaleString()}</strong>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-slate-400">
            Unrealized MTM:
            <strong
              className={`ml-1 ${
                report.unrealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {report.unrealizedPnl >= 0 ? '+' : '-'}${Math.abs(report.unrealizedPnl).toFixed(2)}
            </strong>
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">
            Margin Util:
            <strong
              className={`ml-1 ${
                margin.marginUtilizationPct > 80 ? 'text-rose-400' : 'text-amber-400'
              }`}
            >
              {margin.marginUtilizationPct.toFixed(1)}%
            </strong>
          </span>
        </div>
      </div>

      {/* Greeks Matrix & Delta Neutral Hedging Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Consolidated Portfolio Greeks */}
        <div className="lg:col-span-8 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg font-mono">
          <div className="pb-3 border-b border-[#1e293b] flex justify-between items-center">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Consolidated Portfolio Risk Sensitivities (Greeks)
              </h4>
              <p className="text-[11px] text-slate-400">
                Full-book delta, curvature, volatility exposure, and calendar decay
              </p>
            </div>
            <span className="text-[11px] text-cyan-400">Currency: USD</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Delta</div>
              <div
                className={`text-base font-bold ${
                  greeks.netDelta < 0 ? 'text-cyan-400' : 'text-slate-200'
                }`}
              >
                {greeks.netDelta.toFixed(2)} shs
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                ${greeks.deltaEquivalentNotional.toFixed(0)} delta-notional
              </div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Gross Delta</div>
              <div className="text-base font-bold text-slate-200">
                {greeks.grossDelta.toFixed(2)} shs
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Absolute directional mass</div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Gamma</div>
              <div className="text-base font-bold text-slate-200">
                {greeks.netGamma.toFixed(4)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">dDelta / dS Curvature</div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Vega (1%)</div>
              <div
                className={`text-base font-bold ${
                  greeks.netVega1pct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {greeks.netVega1pct >= 0 ? '+' : '-'}${Math.abs(greeks.netVega1pct).toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">per 1% IV expansion</div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Theta (1-Day)</div>
              <div
                className={`text-base font-bold ${
                  greeks.netTheta1Day >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {greeks.netTheta1Day >= 0 ? '+' : '-'}${Math.abs(greeks.netTheta1Day).toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">daily calendar decay</div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Rho (100bps)</div>
              <div className="text-base font-bold text-slate-200">
                {greeks.netRho1pct >= 0 ? '+' : '-'}${Math.abs(greeks.netRho1pct).toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">interest rate sensitivity</div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Vanna</div>
              <div className="text-base font-bold text-slate-200">
                {greeks.netVanna.toFixed(4)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">dDelta / dVol cross-greek</div>
            </div>

            <div className="p-3 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400 uppercase">Net Volga / Vomma</div>
              <div className="text-base font-bold text-slate-200">
                {greeks.netVolga.toFixed(4)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">dVega / dVol cross-greek</div>
            </div>
          </div>

          {/* Delta-Neutral Rebalancing Order Calculator */}
          <div className="mt-4 p-3 bg-[#141d2e] border border-[#233045] rounded flex flex-wrap items-center justify-between gap-3 text-xs">
            <div>
              <div className="font-bold text-slate-200">
                Delta-Neutral Hedge Recommendation:
              </div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                To achieve zero directional exposure, execute hedge order:
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 bg-cyan-950 border border-cyan-800 text-cyan-300 font-bold rounded">
                {greeks.hedgeRequirementShares >= 0 ? 'BUY' : 'SELL'}{' '}
                {Math.abs(Math.round(greeks.hedgeRequirementShares))}{' '}
                {portfolioStrategies[0]?.underlying.ticker ?? 'SHARES'}
              </span>
            </div>
          </div>
        </div>

        {/* Tail Risk, VaR & Expected Shortfall (CVaR) */}
        <div className="lg:col-span-4 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg font-mono text-xs space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Value at Risk & Expected Shortfall
            </h4>
            <p className="text-[11px] text-slate-400">
              Basel Market Risk Quantiles & Fat-Tail Jump Diffusion
            </p>
          </div>

          <div className="space-y-2">
            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>1-Day 95% Parametric VaR:</span>
                <span className="font-bold text-rose-400">
                  ${var95_1Day.parametricDeltaGammaVaR.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>1-Day 95% Monte Carlo VaR (5k):</span>
                <span className="font-bold text-rose-400">
                  ${var95_1Day.monteCarloVaR.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>1-Day 95% Expected Shortfall (CVaR):</span>
                <span className="font-bold text-rose-500">
                  ${var95_1Day.expectedShortfallCVaR.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>10-Day 99% Regulatory VaR:</span>
                <span className="font-bold text-rose-400">
                  ${var99_10Day.monteCarloVaR.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>10-Day 99% Expected Shortfall:</span>
                <span className="font-bold text-rose-500">
                  ${var99_10Day.expectedShortfallCVaR.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Projected Max Drawdown:</span>
                <span className="font-bold text-amber-400">
                  ${var99_10Day.maxDrawdownProjected.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 leading-normal p-2 bg-[#121927]/60 rounded border border-[#1e293b]/40">
            {var95_1Day.assumptions}
          </div>
        </div>
      </div>

      {/* Strategies Active in Book Table */}
      <div className="bg-[#0e1420] border border-[#1e293b] rounded-lg p-3.5 font-mono text-xs">
        <div className="pb-2.5 border-b border-[#1e293b] flex justify-between items-center">
          <h4 className="font-bold uppercase tracking-wider text-slate-300">
            Active Strategies in Portfolio ({portfolioStrategies.length})
          </h4>
          <span className="text-slate-400 text-[11px]">Desk: NY-LON Macro Bearish</span>
        </div>

        {portfolioStrategies.length === 0 ? (
          <div className="py-8 text-center text-slate-500">
            No strategies currently aggregated into portfolio. Go to Position Lab and click &quot;Add to Portfolio&quot;.
          </div>
        ) : (
          <div className="overflow-x-auto mt-2.5">
            <table className="w-full">
              <thead>
                <tr className="text-slate-400 border-b border-[#1e293b] text-left">
                  <th className="py-1.5 px-2">Strategy ID</th>
                  <th className="py-1.5 px-2">Name</th>
                  <th className="py-1.5 px-2">Underlying</th>
                  <th className="py-1.5 px-2">Template</th>
                  <th className="py-1.5 px-2 text-center">Legs</th>
                  <th className="py-1.5 px-2 text-right">Net Delta</th>
                  <th className="py-1.5 px-2 text-right">Vega (1%)</th>
                  <th className="py-1.5 px-2 text-right">Created</th>
                  <th className="py-1.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]/60">
                {portfolioStrategies.map((strat) => {
                  let sDelta = 0;
                  let sVega = 0;
                  for (const l of strat.legs) {
                    const sign = l.side === 'BUY' ? 1 : -1;
                    sDelta += sign * l.greeks.delta * l.multiplier * l.quantity;
                    sVega += sign * l.greeks.vega1pct * l.multiplier * l.quantity;
                  }

                  return (
                    <tr key={strat.id} className="hover:bg-[#141d2e] transition-colors">
                      <td className="py-2 px-2 text-cyan-400 font-bold">{strat.id.slice(-8)}</td>
                      <td className="py-2 px-2 text-slate-200">{strat.name}</td>
                      <td className="py-2 px-2 text-slate-300">{strat.underlying.ticker}</td>
                      <td className="py-2 px-2 text-slate-400">{strat.templateType.replace(/_/g, ' ')}</td>
                      <td className="py-2 px-2 text-center text-slate-300">{strat.legs.length}</td>
                      <td className="py-2 px-2 text-right font-bold text-cyan-300">{sDelta.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-slate-300">${sVega.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-slate-400">{strat.createdTimestamp.slice(11, 19)}</td>
                      <td className="py-2 px-2 text-center">
                        {onRemoveStrategyFromPortfolio && (
                          <button
                            onClick={() => onRemoveStrategyFromPortfolio(strat.id)}
                            className="text-slate-500 hover:text-rose-400 transition-colors text-[11px]"
                          >
                            Remove
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
