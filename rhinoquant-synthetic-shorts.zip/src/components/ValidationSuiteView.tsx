/**
 * RhinoQuant Synthetic Shorts - Mandatory Quantitative Validation Suite
 * Section 23 Automated Mathematical Proofs, Literature Benchmarks, No-Arbitrage Bounds, and Parity Tests
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState } from 'react';
import { runQuantitativeValidationSuite, ValidationSuiteReport } from '../quant/validation-suite';
import { CheckCircle2, XCircle, RotateCcw, ShieldCheck, Scale, Cpu } from 'lucide-react';

interface ValidationSuiteViewProps {
  initialReport?: ValidationSuiteReport;
}

export const ValidationSuiteView: React.FC<ValidationSuiteViewProps> = ({ initialReport }) => {
  const [report, setReport] = useState<ValidationSuiteReport>(() =>
    initialReport ?? runQuantitativeValidationSuite()
  );
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const handleRerun = () => {
    setIsRunning(true);
    setTimeout(() => {
      const newReport = runQuantitativeValidationSuite();
      setReport(newReport);
      setIsRunning(false);
    }, 150);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Test Execution Summary Banner */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded flex items-center justify-center ${
              report.allPassed
                ? 'bg-emerald-950/80 border border-emerald-600 text-emerald-400'
                : 'bg-rose-950/80 border border-rose-600 text-rose-400'
            }`}
          >
            {report.allPassed ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Section 23 Quantitative Model Verification Suite</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  report.allPassed
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : 'bg-rose-950 text-rose-400 border border-rose-800'
                }`}
              >
                {report.allPassed ? 'ALL PROOFS PASSED' : `${report.failedTests} FAILED`}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Automated reconciliation of Black-Scholes analytical benchmarks, Put-Call parity, and boundary limits
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div>
            <span className="text-slate-400 mr-1.5">Executed Tests:</span>
            <span className="font-bold text-slate-100">{report.totalTests} Assertions</span>
          </div>
          <div>
            <span className="text-slate-400 mr-1.5">Duration:</span>
            <span className="font-bold text-cyan-300">{report.executionDurationMs.toFixed(2)} ms</span>
          </div>

          <button
            onClick={handleRerun}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-700 hover:bg-cyan-600 text-white rounded font-bold transition-colors disabled:opacity-50"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
            <span>Re-Run Mathematical Suite</span>
          </button>
        </div>
      </div>

      {/* Assertion Table */}
      <div className="bg-[#0e1420] border border-[#1e293b] rounded-lg p-3.5">
        <div className="pb-2.5 border-b border-[#1e293b] flex justify-between items-center">
          <h4 className="font-bold uppercase tracking-wider text-slate-300">
            Automated Mathematical Proofs & Assertion Log
          </h4>
          <span className="text-slate-400 text-[11px]">Tolerance Engine: Strict Floating Point Bounds</span>
        </div>

        <div className="overflow-x-auto mt-2.5">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-[#1e293b] text-left">
                <th className="py-1.5 px-2">Test ID</th>
                <th className="py-1.5 px-2">Category</th>
                <th className="py-1.5 px-2">Assertion Description</th>
                <th className="py-1.5 px-2">Expected Identity / Benchmark</th>
                <th className="py-1.5 px-2">Calculated Result</th>
                <th className="py-1.5 px-2 text-right">Difference (|Δ|)</th>
                <th className="py-1.5 px-2 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/60">
              {report.assertions.map((test) => (
                <tr key={test.testId} className="hover:bg-[#141d2e] transition-colors">
                  <td className="py-2.5 px-2 font-bold text-cyan-400">{test.testId}</td>
                  <td className="py-2.5 px-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#121927] border border-[#1e293b] text-slate-300">
                      {test.category}
                    </span>
                  </td>
                  <td className="py-2.5 px-2">
                    <div className="font-semibold text-slate-200">{test.name}</div>
                    {test.notes && <div className="text-[10px] text-slate-500 mt-0.5">{test.notes}</div>}
                  </td>
                  <td className="py-2.5 px-2 text-slate-300">{test.expectedDescription}</td>
                  <td className="py-2.5 px-2 text-cyan-300 font-semibold">{test.actualDescription}</td>
                  <td className="py-2.5 px-2 text-right text-slate-400">
                    {test.difference === 0
                      ? '0.00'
                      : test.difference < 0.0001
                      ? test.difference.toExponential(3)
                      : test.difference.toFixed(4)}
                  </td>
                  <td className="py-2.5 px-2 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        test.passed
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {test.passed ? 'PASSED' : 'FAILED'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
