/**
 * RhinoQuant Synthetic Shorts - Counterparty & Credit Exposure Terminal
 * ISDA / CSA Bilateral Netting Sets, Potential Future Exposure (PFE), and Variation Margin Call Simulator
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState } from 'react';
import {
  INSTITUTIONAL_COUNTERPARTIES,
  CounterpartyEntity,
  evaluateCounterpartyNetting,
} from '../quant/counterparty';
import { Building2, ShieldCheck, Scale, ArrowUpRight, ArrowDownRight, CheckCircle2 } from 'lucide-react';

export const CounterpartyView: React.FC = () => {
  const [selectedCpId, setSelectedCpId] = useState<string>(INSTITUTIONAL_COUNTERPARTIES[0].id);
  const [incrementalMtM, setIncrementalMtM] = useState<number>(0);

  const counterparty =
    INSTITUTIONAL_COUNTERPARTIES.find((cp) => cp.id === selectedCpId) ?? INSTITUTIONAL_COUNTERPARTIES[0];

  const nettingResult = evaluateCounterpartyNetting(counterparty, incrementalMtM);

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Counterparty Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        {INSTITUTIONAL_COUNTERPARTIES.map((cp) => {
          const isSelected = cp.id === selectedCpId;
          return (
            <button
              key={cp.id}
              onClick={() => setSelectedCpId(cp.id)}
              className={`p-3.5 rounded-lg border text-left transition-all ${
                isSelected
                  ? 'bg-cyan-950/70 border-cyan-500 shadow-xs'
                  : 'bg-[#0e1420] border-[#1e293b] hover:border-[#334155]'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="font-bold text-slate-100 truncate">{cp.legalName.split(' ')[0]} PB</span>
                <span className="px-1.5 py-0.2 text-[10px] bg-[#1e293b] text-cyan-300 font-bold rounded">
                  {cp.creditRating}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Net Exp: <strong className="text-white">${cp.netCurrentExposure.toLocaleString()}</strong>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                Limit Util: {cp.limitUtilizationPct.toFixed(1)}% of ${(cp.settlementExposureLimit / 1000000).toFixed(1)}M
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Analysis: Netting Agreement & Credit Exposure Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: CSA Netting & Parameters */}
        <div className="lg:col-span-6 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b] flex justify-between items-center">
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              ISDA / CSA Master Agreement Terms
            </h4>
            <span className="text-cyan-400 font-bold">{counterparty.csaAgreementType.replace(/_/g, ' ')}</span>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Legal Entity:</span>
              <span className="text-slate-200 font-semibold">{counterparty.legalName}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Legal Entity Identifier (LEI):</span>
              <span className="text-cyan-300">{counterparty.lei}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Governing Jurisdiction:</span>
              <span className="text-slate-300">{counterparty.jurisdiction}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Bilateral Netting Enforceable:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> YES (Clean Legal Opinion)
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Threshold Amount:</span>
              <span className="text-slate-200">${counterparty.thresholdAmount} (Full VM Margining)</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Minimum Transfer Amount (MTA):</span>
              <span className="text-slate-200">${counterparty.minimumTransferAmount.toLocaleString()}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Independent Amount (Initial Margin):</span>
              <span className="text-slate-200">${counterparty.independentAmount.toLocaleString()}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Wrong-Way-Risk (WWR) Indicator:</span>
              <span className="text-emerald-400 font-bold">{counterparty.wrongWayRiskStatus}</span>
            </div>
          </div>
        </div>

        {/* Right Column: Gross vs Net Exposure & Collateral Calls */}
        <div className="lg:col-span-6 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Exposure Profile & Variation Margin Transfer
            </h4>
            <p className="text-[11px] text-slate-400">
              Gross positive exposure vs net current exposure after legal netting
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400">Gross Positive (GPE)</div>
              <div className="text-base font-bold text-slate-100 mt-0.5">
                ${counterparty.grossPositiveExposure.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500">Unhedged counterparty risk</div>
            </div>

            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400">Gross Negative (GNE)</div>
              <div className="text-base font-bold text-slate-100 mt-0.5">
                ${counterparty.grossNegativeExposure.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500">Liability to counterparty</div>
            </div>

            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400">Net Current Exposure (NCE)</div>
              <div className="text-base font-bold text-cyan-400 mt-0.5">
                ${counterparty.netCurrentExposure.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500">Enforceable CSA Netting</div>
            </div>

            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded">
              <div className="text-[10px] text-slate-400">Potential Future Exp (PFE 95%)</div>
              <div className="text-base font-bold text-amber-400 mt-0.5">
                ${counterparty.potentialFutureExposure95.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500">1-Year 95th Percentile</div>
            </div>
          </div>

          {/* Interactive Collateral Call Simulator */}
          <div className="p-3 bg-[#141d2e] border border-[#233045] rounded space-y-2">
            <div className="font-bold text-slate-200">
              Simulate Incremental MTM Shock & Collateral Transfer Call:
            </div>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="-200000"
                max="200000"
                step="10000"
                value={incrementalMtM}
                onChange={(e) => setIncrementalMtM(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-1 bg-[#1e293b] rounded cursor-pointer"
              />
              <span className="font-bold text-slate-100 w-28 text-right">
                {incrementalMtM >= 0 ? '+' : '-'}${Math.abs(incrementalMtM).toLocaleString()}
              </span>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-[#1e293b] text-[11px]">
              <span className="text-slate-400">Required CSA Margin Transfer:</span>
              <span
                className={`font-bold ${
                  nettingResult.callDirection === 'RECEIVE_COLLATERAL'
                    ? 'text-emerald-400'
                    : nettingResult.callDirection === 'POST_COLLATERAL'
                    ? 'text-rose-400'
                    : 'text-slate-300'
                }`}
              >
                {nettingResult.callDirection === 'RECEIVE_COLLATERAL' &&
                  `CALL: Demand $${nettingResult.variationMarginCallRequired.toLocaleString()} from CP`}
                {nettingResult.callDirection === 'POST_COLLATERAL' &&
                  `POST: Deliver $${nettingResult.variationMarginCallRequired.toLocaleString()} to CP`}
                {nettingResult.callDirection === 'WITHIN_THRESHOLD' && 'Within MTA Threshold (No Transfer)'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
