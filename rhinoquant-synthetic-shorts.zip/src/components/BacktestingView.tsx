/**
 * RhinoQuant Synthetic Shorts - Historical Backtesting & Research Terminal
 * Walk-Forward Equity Curves, Benchmark Comparisons, Slippage Drag, and Institutional Risk-Adjusted Ratios
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState, useMemo } from 'react';
import { StrategyDefinition } from '../quant/instruments';
import { MarketRegime, runStrategyBacktest, BacktestResults } from '../quant/backtesting';
import { Play, TrendingUp, TrendingDown, DollarSign, Activity, AlertCircle } from 'lucide-react';

interface BacktestingViewProps {
  strategy: StrategyDefinition;
}

export const BacktestingView: React.FC<BacktestingViewProps> = ({ strategy }) => {
  const [selectedRegime, setSelectedRegime] = useState<MarketRegime>('BEAR_MARKET_DOWNTREND');
  const [lookbackDays, setLookbackDays] = useState<number>(90);
  const [initialCapital, setInitialCapital] = useState<number>(250000);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const backtestResult: BacktestResults = useMemo(() => {
    return runStrategyBacktest(strategy, selectedRegime, lookbackDays, initialCapital);
  }, [strategy, selectedRegime, lookbackDays, initialCapital]);

  const records = backtestResult.dailyRecords;

  // SVG Chart Dimensions
  const width = 800;
  const height = 260;
  const padding = { top: 20, right: 30, bottom: 35, left: 65 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const { minNav, maxNav } = useMemo(() => {
    let minN = initialCapital;
    let maxN = initialCapital;
    for (const r of records) {
      minN = Math.min(minN, r.strategyNav, r.benchmarkNav);
      maxN = Math.max(maxN, r.strategyNav, r.benchmarkNav);
    }
    const pad = Math.max(5000, (maxN - minN) * 0.1);
    return { minNav: minN - pad, maxNav: maxN + pad };
  }, [records, initialCapital]);

  const getX = (idx: number) => padding.left + (idx / Math.max(1, records.length - 1)) * chartW;
  const getY = (nav: number) => padding.top + (1.0 - (nav - minNav) / Math.max(1, maxNav - minNav)) * chartH;

  const strategyPath = useMemo(() => {
    if (records.length === 0) return '';
    return records.reduce((acc, r, i) => {
      const x = getX(i);
      const y = getY(r.strategyNav);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [records, minNav, maxNav]);

  const benchmarkPath = useMemo(() => {
    if (records.length === 0) return '';
    return records.reduce((acc, r, i) => {
      const x = getX(i);
      const y = getY(r.benchmarkNav);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [records, minNav, maxNav]);

  const activeRecord = hoverIndex !== null && records[hoverIndex] ? records[hoverIndex] : null;

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Simulation Controls & Market Regime Bar */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-3">
        <div className="flex flex-wrap justify-between items-center pb-2.5 border-b border-[#1e293b]">
          <div>
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Quantitative Backtesting Simulator
            </h4>
            <p className="text-[11px] text-slate-400">
              Testing &quot;{strategy.name}&quot; with realistic commission, borrow fees, and zero look-ahead bias
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-[11px]">Lookback Window:</span>
            {[30, 60, 90, 180].map((days) => (
              <button
                key={`lb-${days}`}
                onClick={() => setLookbackDays(days)}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  lookbackDays === days
                    ? 'bg-cyan-950 border border-cyan-600 text-cyan-300 font-bold'
                    : 'bg-[#141d2e] border border-[#1e293b] text-slate-400 hover:text-slate-200'
                }`}
              >
                {days}d
              </button>
            ))}
          </div>
        </div>

        {/* Market Regime Selector */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <button
            onClick={() => setSelectedRegime('BEAR_MARKET_DOWNTREND')}
            className={`p-2.5 rounded border text-left transition-all ${
              selectedRegime === 'BEAR_MARKET_DOWNTREND'
                ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 font-bold'
                : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
            }`}
          >
            <div className="text-xs font-bold text-slate-200">Bear Market Downtrend</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Steady downward drift (-0.35%/d)</div>
          </button>

          <button
            onClick={() => setSelectedRegime('SIDEWAYS_CHOP_HIGH_THETA')}
            className={`p-2.5 rounded border text-left transition-all ${
              selectedRegime === 'SIDEWAYS_CHOP_HIGH_THETA'
                ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 font-bold'
                : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
            }`}
          >
            <div className="text-xs font-bold text-slate-200">Sideways Chop & Decay</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Rangebound theta grind</div>
          </button>

          <button
            onClick={() => setSelectedRegime('BULL_MOMENTUM_ADVERSE')}
            className={`p-2.5 rounded border text-left transition-all ${
              selectedRegime === 'BULL_MOMENTUM_ADVERSE'
                ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 font-bold'
                : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
            }`}
          >
            <div className="text-xs font-bold text-slate-200">Bull Momentum Adverse</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Adverse upward rally (+0.28%/d)</div>
          </button>

          <button
            onClick={() => setSelectedRegime('HIGH_VOL_CRISIS_EXPANSION')}
            className={`p-2.5 rounded border text-left transition-all ${
              selectedRegime === 'HIGH_VOL_CRISIS_EXPANSION'
                ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 font-bold'
                : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
            }`}
          >
            <div className="text-xs font-bold text-slate-200">High-Vol Crisis Expansion</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Violent selloff with vol spike</div>
          </button>
        </div>
      </div>

      {/* SVG Cumulative NAV Equity Curve Chart */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg">
        <div className="flex justify-between items-center pb-2 border-b border-[#1e293b]">
          <div className="flex items-center gap-4 text-xs">
            <span className="font-bold text-slate-200 uppercase tracking-wider">
              Cumulative NAV Growth vs Benchmark
            </span>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-0.5 bg-cyan-400 inline-block"></span>
              <span className="text-slate-300">Strategy NAV</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-0.5 bg-slate-500 inline-block"></span>
              <span className="text-slate-400">Short Underlying Benchmark</span>
            </div>
          </div>

          <div className="text-xs text-slate-400">
            Initial Capital: <strong className="text-slate-100">${initialCapital.toLocaleString()}</strong>
          </div>
        </div>

        {/* SVG Canvas */}
        <div className="mt-3">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full h-auto cursor-crosshair select-none"
            onMouseLeave={() => setHoverIndex(null)}
            onMouseMove={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const mouseX = ((e.clientX - rect.left) / rect.width) * width;
              const chartX = mouseX - padding.left;
              const ratio = Math.max(0, Math.min(1, chartX / chartW));
              const idx = Math.round(ratio * (records.length - 1));
              setHoverIndex(idx);
            }}
          >
            {/* Grid */}
            {[0.2, 0.4, 0.6, 0.8].map((ratio, i) => {
              const y = padding.top + ratio * chartH;
              const navVal = maxNav - ratio * (maxNav - minNav);
              return (
                <g key={`nav-grid-${i}`}>
                  <line
                    x1={padding.left}
                    y1={y}
                    x2={width - padding.right}
                    y2={y}
                    stroke="#1e293b"
                    strokeDasharray="2,3"
                  />
                  <text
                    x={padding.left - 8}
                    y={y + 4}
                    textAnchor="end"
                    className="text-[10px] fill-slate-400 font-mono"
                  >
                    ${(navVal / 1000).toFixed(0)}k
                  </text>
                </g>
              );
            })}

            {/* Benchmark Path */}
            <path d={benchmarkPath} fill="none" stroke="#64748b" strokeWidth="1.5" strokeDasharray="3,3" />

            {/* Strategy Path */}
            <path d={strategyPath} fill="none" stroke="#22d3ee" strokeWidth="2.5" />

            {/* Hover Crosshair */}
            {activeRecord && hoverIndex !== null && (
              <g>
                <line
                  x1={getX(hoverIndex)}
                  y1={padding.top}
                  x2={getX(hoverIndex)}
                  y2={height - padding.bottom}
                  stroke="#94a3b8"
                  strokeWidth="1"
                  strokeDasharray="2,2"
                />
                <circle
                  cx={getX(hoverIndex)}
                  cy={getY(activeRecord.strategyNav)}
                  r="4"
                  fill="#22d3ee"
                  stroke="#0e1420"
                  strokeWidth="1.5"
                />
              </g>
            )}
          </svg>
        </div>

        {/* Hover Tooltip Readout */}
        {activeRecord && (
          <div className="mt-2 flex flex-wrap items-center justify-between gap-3 px-3 py-1.5 bg-[#141d2e] border border-[#233045] rounded text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Date:</span>
              <span className="text-white font-bold">{activeRecord.dateStr}</span>
              <span className="text-slate-400">· Spot:</span>
              <span className="text-cyan-300 font-bold">${activeRecord.underlyingPrice.toFixed(2)}</span>
            </div>

            <div className="flex items-center gap-4">
              <div>
                <span className="text-slate-400 mr-1.5">Strategy NAV:</span>
                <span className="font-bold text-cyan-300">${activeRecord.strategyNav.toFixed(2)}</span>
                <span className="text-[10px] ml-1 text-slate-400">
                  ({activeRecord.cumulativeReturnPct >= 0 ? '+' : ''}{activeRecord.cumulativeReturnPct.toFixed(2)}%)
                </span>
              </div>
              <div>
                <span className="text-slate-400 mr-1.5">Benchmark:</span>
                <span className="text-slate-300 font-bold">${activeRecord.benchmarkNav.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-400 mr-1.5">Drawdown:</span>
                <span className="text-rose-400 font-bold">-{activeRecord.drawdownPct.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Institutional Performance Statistics Matrix */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Cumulative Return</div>
          <div
            className={`text-lg font-bold mt-1 ${
              backtestResult.cumulativeReturnPct >= 0 ? 'text-cyan-400' : 'text-rose-400'
            }`}
          >
            {backtestResult.cumulativeReturnPct >= 0 ? '+' : ''}
            {backtestResult.cumulativeReturnPct.toFixed(2)}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Bench: {backtestResult.benchmarkCumulativeReturnPct.toFixed(2)}%
          </div>
        </div>

        <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Annualized Return</div>
          <div
            className={`text-lg font-bold mt-1 ${
              backtestResult.annualizedReturnPct >= 0 ? 'text-cyan-400' : 'text-rose-400'
            }`}
          >
            {backtestResult.annualizedReturnPct >= 0 ? '+' : ''}
            {backtestResult.annualizedReturnPct.toFixed(2)}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">CAGR extrapolated</div>
        </div>

        <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Sharpe Ratio</div>
          <div
            className={`text-lg font-bold mt-1 ${
              backtestResult.sharpeRatio >= 1.0
                ? 'text-emerald-400'
                : backtestResult.sharpeRatio >= 0
                ? 'text-cyan-300'
                : 'text-rose-400'
            }`}
          >
            {backtestResult.sharpeRatio.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Rf = 4.5% hurdle</div>
        </div>

        <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Sortino Ratio</div>
          <div className="text-lg font-bold text-slate-200 mt-1">
            {backtestResult.sortinoRatio.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Downside volatility only</div>
        </div>

        <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Max Drawdown</div>
          <div className="text-lg font-bold text-rose-400 mt-1">
            -{backtestResult.maxDrawdownPct.toFixed(2)}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Peak-to-trough decline</div>
        </div>

        <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Win Rate & Profit Factor</div>
          <div className="text-lg font-bold text-slate-200 mt-1">
            {backtestResult.winRatePct.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">PF: {backtestResult.profitFactor.toFixed(2)}x</div>
        </div>
      </div>

      {/* Institutional Audit & Friction Accounting Strip */}
      <div className="p-3 bg-[#0e1420] border border-[#1e293b] rounded-lg space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-3 text-slate-400">
          <div>
            Total Commissions & Slippage Incurred:{' '}
            <strong className="text-slate-200">${backtestResult.totalTradingCost.toFixed(2)}</strong>
          </div>
          <div>
            Borrow & Financing Drag Incurred:{' '}
            <strong className="text-slate-200">${backtestResult.totalBorrowCost.toFixed(2)}</strong>
          </div>
          <div>
            Final Net Asset Value:{' '}
            <strong className="text-cyan-400">${backtestResult.finalNav.toLocaleString(undefined, { maximumFractionDigits: 2 })}</strong>
          </div>
        </div>

        <div className="p-2.5 bg-[#141d2e] border border-[#233045] rounded text-[11px] text-slate-400 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            {backtestResult.disclaimer}
          </p>
        </div>
      </div>
    </div>
  );
};
