/**
 * RhinoQuant Synthetic Shorts - Margin & Collateral Subsystem
 * Initial Margin (SPAN-Proxy), Maintenance Margin, Haircuts, Collateral Buffer, and Margin Deficit Tracking
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState, useMemo } from 'react';
import { StrategyDefinition } from '../quant/instruments';
import { calculateMarginAndCollateral } from '../quant/risk';
import { ShieldAlert, CheckCircle, Wallet, ArrowDownRight, Info } from 'lucide-react';

interface MarginCollateralViewProps {
  strategies: StrategyDefinition[];
}

export const MarginCollateralView: React.FC<MarginCollateralViewProps> = ({ strategies }) => {
  const [cashDeposit, setCashDeposit] = useState<number>(300000);
  const [treasuryDeposit, setTreasuryDeposit] = useState<number>(500000);
  const [treasuryHaircut, setTreasuryHaircut] = useState<number>(0.02); // 2%

  const margin = useMemo(() => {
    return calculateMarginAndCollateral(strategies, cashDeposit, treasuryDeposit, treasuryHaircut);
  }, [strategies, cashDeposit, treasuryDeposit, treasuryHaircut]);

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Margin Status Card */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-3.5 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Total Margin Required</div>
          <div className="text-xl font-bold text-slate-100 mt-1">
            ${margin.totalMarginRequirement.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Initial + Add-ons</div>
        </div>

        <div className="p-3.5 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Effective Collateral</div>
          <div className="text-xl font-bold text-cyan-400 mt-1">
            ${margin.effectiveCollateralAfterHaircut.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Post-haircut value</div>
        </div>

        <div className="p-3.5 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Free Margin Headroom</div>
          <div
            className={`text-xl font-bold mt-1 ${
              margin.freeMarginHeadroom >= 0 ? 'text-emerald-400' : 'text-rose-500'
            }`}
          >
            ${margin.freeMarginHeadroom.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Buffer before call</div>
        </div>

        <div className="p-3.5 bg-[#0e1420] border border-[#1e293b] rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Margin Utilization</div>
          <div
            className={`text-xl font-bold mt-1 ${
              margin.marginUtilizationPct > 80 ? 'text-rose-500' : 'text-amber-400'
            }`}
          >
            {margin.marginUtilizationPct.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Threshold: 70% / 90%</div>
        </div>
      </div>

      {/* Margin Utilization Progress Bar */}
      <div className="p-3.5 bg-[#0e1420] border border-[#1e293b] rounded-lg space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="font-bold text-slate-300 uppercase tracking-wider">
            Collateral Utilization & Capacity Gauge
          </span>
          <span className="text-slate-400">
            {margin.isMarginCallActive ? (
              <span className="text-rose-400 font-bold flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" /> MARGIN CALL ACTIVE (Deficit: ${margin.marginCallDeficit.toFixed(0)})
              </span>
            ) : (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Margin Sound & Sufficient Headroom
              </span>
            )}
          </span>
        </div>

        <div className="w-full bg-[#1e293b] h-3 rounded overflow-hidden relative">
          {/* Warning markers at 70% and 90% */}
          <div className="absolute top-0 bottom-0 left-[70%] w-0.5 bg-amber-500 z-10" />
          <div className="absolute top-0 bottom-0 left-[90%] w-0.5 bg-rose-500 z-10" />
          <div
            className={`h-full transition-all duration-300 ${
              margin.marginUtilizationPct > 90
                ? 'bg-rose-500'
                : margin.marginUtilizationPct > 70
                ? 'bg-amber-400'
                : 'bg-cyan-400'
            }`}
            style={{ width: `${Math.min(100, margin.marginUtilizationPct)}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-slate-500">
          <span>0%</span>
          <span>70% Elevated Alert</span>
          <span>90% Liquidation Action</span>
          <span>100% Full Capacity</span>
        </div>
      </div>

      {/* Two Column Layout: Detailed Margin Components & Collateral Assets */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Margin Component Breakdown */}
        <div className="lg:col-span-6 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Margin Kernel Breakdown
            </h4>
            <p className="text-[11px] text-slate-400">
              Institutional SPAN-Equivalent proxy formulas per instrument family
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Base Initial Margin (IM):</span>
              <span className="font-bold text-slate-100">
                ${margin.initialMarginRequired.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Maintenance Margin (MM):</span>
              <span className="text-slate-300">
                ${margin.maintenanceMargin.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Hard-To-Borrow Liquidity Add-on:</span>
              <span className="font-bold text-amber-400">
                +${margin.liquidityAddOn.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Concentration Exposure Add-on:</span>
              <span className="font-bold text-amber-400">
                +${margin.concentrationAddOn.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Unrealized Variation Margin (MTM):</span>
              <span
                className={`font-bold ${
                  margin.variationMarginUnrealized >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {margin.variationMarginUnrealized >= 0 ? '+' : '-'}$
                {Math.abs(margin.variationMarginUnrealized).toFixed(2)}
              </span>
            </div>
          </div>

          <div className="p-2.5 bg-[#141d2e] border border-[#233045] rounded text-[11px] text-slate-400 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-slate-300">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>Methodology & Legal Boundary</span>
            </div>
            <p className="leading-relaxed text-slate-500">
              {margin.methodologyNote}
            </p>
          </div>
        </div>

        {/* Collateral Balances & Haircuts Manager */}
        <div className="lg:col-span-6 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Eligible Collateral Balances & Haircuts
            </h4>
            <p className="text-[11px] text-slate-400">
              Custody balances with regulatory haircuts (CFTC / SEC Rule 15c3-3)
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-400">
                <span>USD Cash Collateral (0% Haircut):</span>
                <span className="font-bold text-white">${cashDeposit.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="50000"
                max="1000000"
                step="25000"
                value={cashDeposit}
                onChange={(e) => setCashDeposit(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-1 bg-[#1e293b] rounded cursor-pointer mt-1"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400">
                <span>US Treasury Bills / Notes:</span>
                <span className="font-bold text-white">${treasuryDeposit.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="0"
                max="2000000"
                step="50000"
                value={treasuryDeposit}
                onChange={(e) => setTreasuryDeposit(parseFloat(e.target.value))}
                className="w-full accent-indigo-400 h-1 bg-[#1e293b] rounded cursor-pointer mt-1"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400">
                <span>Treasury Haircut Applied:</span>
                <span className="font-bold text-amber-400">{(treasuryHaircut * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.10"
                step="0.005"
                value={treasuryHaircut}
                onChange={(e) => setTreasuryHaircut(parseFloat(e.target.value))}
                className="w-full accent-amber-400 h-1 bg-[#1e293b] rounded cursor-pointer mt-1"
              />
            </div>

            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Total Gross Collateral:</span>
                <span className="text-slate-200">${margin.totalCollateralDeposited.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Haircut Deduction:</span>
                <span className="text-rose-400">-${(treasuryDeposit * treasuryHaircut).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-300 font-bold pt-1 border-t border-[#1e293b]">
                <span>Effective Net Collateral:</span>
                <span className="text-cyan-400">${margin.effectiveCollateralAfterHaircut.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
