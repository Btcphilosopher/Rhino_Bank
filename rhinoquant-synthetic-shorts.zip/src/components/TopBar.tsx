/**
 * RhinoQuant Synthetic Shorts - Institutional Workstation Top Navigation Bar
 * Universal Top Bar Contract: Single-Line Brand Mark, Clean Navigation Tabs, and Primary Execution Trigger
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React from 'react';
import { ShieldAlert, Play, CheckCircle2 } from 'lucide-react';

export type ActiveTab =
  | 'LAB'
  | 'OPTIONS_ANALYTICS'
  | 'PORTFOLIO_RISK'
  | 'SCENARIO_ENGINE'
  | 'MARGIN_COLLATERAL'
  | 'BACKTESTING'
  | 'EXECUTION'
  | 'COUNTERPARTY'
  | 'MODEL_REGISTRY'
  | 'VALIDATION_SUITE';

interface TopBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onRunValidation: () => void;
  validationPassed?: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onSelectTab,
  onRunValidation,
  validationPassed = true,
}) => {
  return (
    <header className="w-full bg-[#0d131f] border-b border-[#1e293b] sticky top-0 z-50">
      {/* Simulation / Data Quality Watermark Banner */}
      <div className="bg-[#121927] border-b border-[#1e293b]/60 px-4 py-1 flex items-center justify-between text-[11px] font-mono text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-300">RhinoBank Institutional Derivatives</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-amber-400 font-medium">SIMULATED DATA ENVIRONMENT</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Deterministic Calibrated Market Feed</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Desk: <strong className="text-slate-300 font-normal">NY-LON Macro Shorts</strong></span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Feed Staleness: <strong className="text-emerald-400 font-normal">1.2s (Nominal)</strong></span>
        </div>
      </div>

      {/* Main Top Bar Contract: 3 Zones */}
      <div className="flex items-center justify-between gap-6 px-6 py-2.5">
        {/* Zone 1: Brand Wordmark (Single Text Element) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onSelectTab('LAB')}
            className="text-left group cursor-pointer focus:outline-none"
          >
            <span className="text-lg font-bold tracking-tight text-white font-sans hover:text-cyan-400 transition-colors">
              RhinoQuant <span className="text-cyan-400 font-semibold">Synthetic Shorts</span>
            </span>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Clean Single-Line Tabs) */}
        <nav className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
          <button
            onClick={() => onSelectTab('LAB')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'LAB'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Position Lab
          </button>

          <button
            onClick={() => onSelectTab('OPTIONS_ANALYTICS')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'OPTIONS_ANALYTICS'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Options Analytics
          </button>

          <button
            onClick={() => onSelectTab('PORTFOLIO_RISK')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'PORTFOLIO_RISK'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Portfolio Risk
          </button>

          <button
            onClick={() => onSelectTab('SCENARIO_ENGINE')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'SCENARIO_ENGINE'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Scenario Engine
          </button>

          <button
            onClick={() => onSelectTab('MARGIN_COLLATERAL')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'MARGIN_COLLATERAL'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Margin & Collateral
          </button>

          <button
            onClick={() => onSelectTab('BACKTESTING')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'BACKTESTING'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Backtesting Lab
          </button>

          <button
            onClick={() => onSelectTab('EXECUTION')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'EXECUTION'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Execution
          </button>

          <button
            onClick={() => onSelectTab('COUNTERPARTY')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'COUNTERPARTY'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Counterparty
          </button>

          <button
            onClick={() => onSelectTab('MODEL_REGISTRY')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'MODEL_REGISTRY'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Model Registry
          </button>

          <button
            onClick={() => onSelectTab('VALIDATION_SUITE')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'VALIDATION_SUITE'
                ? 'bg-[#1e293b] text-cyan-400 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141d2e]'
            }`}
          >
            Validation Suite
          </button>
        </nav>

        {/* Zone 3: Primary Action Trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onRunValidation}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-100 bg-[#1e293b] hover:bg-[#28384f] border border-[#334155] rounded transition-colors whitespace-nowrap shrink-0"
            title="Execute Section 23 Quantitative Model Verification Suite"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Run Validation Suite</span>
          </button>
        </div>
      </div>
    </header>
  );
};
