/**
 * RhinoQuant Synthetic Shorts - Institutional Execution Terminal & Order Lifecycle
 * Pre-Trade Risk Gateways, 3-Mode Execution Separation, and Auditable State Transitions
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState } from 'react';
import { StrategyDefinition } from '../quant/instruments';
import {
  ExecutionEnvironment,
  OrderProposal,
  createOrderProposal,
  executePaperOrder,
  EXECUTION_LIMITS,
} from '../quant/execution';
import { ShieldCheck, ShieldAlert, Lock, Play, CheckCircle2, Clock, XCircle, FileText } from 'lucide-react';

interface ExecutionViewProps {
  currentStrategy: StrategyDefinition;
  orders: OrderProposal[];
  onAddOrder: (order: OrderProposal) => void;
  onUpdateOrder: (order: OrderProposal) => void;
}

export const ExecutionView: React.FC<ExecutionViewProps> = ({
  currentStrategy,
  orders,
  onAddOrder,
  onUpdateOrder,
}) => {
  const [environment, setEnvironment] = useState<ExecutionEnvironment>('PAPER_TRADING');
  const [orderType, setOrderType] = useState<OrderProposal['orderType']>('MULTI_LEG_NET_DEBIT');
  const [limitPrice, setLimitPrice] = useState<number>(() => {
    return Math.abs(
      currentStrategy.legs.reduce((acc, l) => acc + (l.side === 'BUY' ? 1 : -1) * l.currentTheoreticalPrice, 0)
    );
  });
  const [selectedAuditOrder, setSelectedAuditOrder] = useState<OrderProposal | null>(null);

  // Generate staged proposal
  const activeProposal = createOrderProposal(currentStrategy, orderType, environment, limitPrice);

  const handleCreateOrder = () => {
    onAddOrder(activeProposal);
  };

  const handleExecutePaper = (order: OrderProposal) => {
    const filled = executePaperOrder(order);
    onUpdateOrder(filled);
  };

  const handleCancelOrder = (order: OrderProposal) => {
    const now = new Date().toISOString();
    const cancelled: OrderProposal = {
      ...order,
      status: 'CANCELLED',
      auditTrail: [
        ...order.auditTrail,
        {
          timestamp: now,
          fromState: order.status,
          toState: 'CANCELLED',
          operator: 'Desk Trader',
          note: 'Order manually cancelled by user in execution terminal',
        },
      ],
    };
    onUpdateOrder(cancelled);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* 3-Mode Environment Separation Gate */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-3">
        <div className="flex flex-wrap justify-between items-center pb-2.5 border-b border-[#1e293b]">
          <div>
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Execution Architecture & Venue Routing
            </h4>
            <p className="text-[11px] text-slate-400">
              Rule #16 & #17: Strict separation of Research, Paper Matching, and Locked Live Execution
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-[#141d2e] p-1 rounded border border-[#1e293b]">
            <button
              onClick={() => setEnvironment('RESEARCH')}
              className={`px-3 py-1 rounded transition-colors ${
                environment === 'RESEARCH'
                  ? 'bg-slate-700 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              1. Research Mode
            </button>

            <button
              onClick={() => setEnvironment('PAPER_TRADING')}
              className={`px-3 py-1 rounded transition-colors ${
                environment === 'PAPER_TRADING'
                  ? 'bg-cyan-900 border border-cyan-500 text-cyan-200 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              2. Paper Trading (Simulated)
            </button>

            <button
              onClick={() => setEnvironment('LIVE_EXECUTION')}
              className={`px-3 py-1 rounded transition-colors flex items-center gap-1.5 ${
                environment === 'LIVE_EXECUTION'
                  ? 'bg-rose-950 border border-rose-600 text-rose-300 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Lock className="w-3 h-3 text-rose-400" />
              <span>3. Live Execution</span>
            </button>
          </div>
        </div>

        {/* Live Execution Gatekeeper Alert */}
        {environment === 'LIVE_EXECUTION' && (
          <div className="p-3 bg-rose-950/40 border border-rose-800 rounded flex items-start gap-3 text-rose-300">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-sm">LIVE PRODUCTION EXECUTION HARD-LOCKED</div>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                As specified by institutional operating controls, live order routing is locked. Live execution requires
                an authorized broker FIX session, authenticated credentials, and pre-trade Risk Officer approval.
                Orders cannot be submitted to live venues from this demo terminal.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Two Column Layout: Staged Order Proposal & Pre-Trade Risk Gateway */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Staged Order Configuration */}
        <div className="lg:col-span-5 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Staged Order Proposal
            </h4>
            <p className="text-[11px] text-slate-400">
              Derived from: {currentStrategy.name}
            </p>
          </div>

          <div className="space-y-2.5">
            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Order ID:</span>
              <span className="font-bold text-cyan-400">{activeProposal.id}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Underlying:</span>
              <span className="text-slate-200">{currentStrategy.underlying.ticker}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Order Multi-Leg Type:</span>
              <select
                value={orderType}
                onChange={(e) => setOrderType(e.target.value as any)}
                className="bg-[#141d2e] border border-[#233045] px-2 py-0.5 rounded text-slate-200"
              >
                <option value="MULTI_LEG_NET_DEBIT">Multi-Leg Net Debit</option>
                <option value="MULTI_LEG_NET_CREDIT">Multi-Leg Net Credit</option>
                <option value="LIMIT">Limit Order</option>
                <option value="MARKET">Market Order</option>
              </select>
            </div>

            <div className="flex justify-between items-center py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Net Limit Price:</span>
              <div className="flex items-center gap-1">
                <span>$</span>
                <input
                  type="number"
                  step="0.05"
                  value={limitPrice}
                  onChange={(e) => setLimitPrice(parseFloat(e.target.value) || 0)}
                  className="w-24 px-2 py-0.5 bg-[#141d2e] border border-[#233045] rounded text-slate-100 text-right"
                />
              </div>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Gross Notional:</span>
              <span className="font-bold text-slate-200">
                ${activeProposal.totalNotional.toLocaleString()}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
              <span className="text-slate-400">Execution Venue:</span>
              <span className="text-slate-300">{activeProposal.executionVenue}</span>
            </div>
          </div>

          {/* Staged Legs List */}
          <div className="pt-2">
            <div className="text-[11px] text-slate-400 font-bold mb-1.5 uppercase">Contract Legs to Transmit:</div>
            <div className="space-y-1.5">
              {activeProposal.legs.map((l) => (
                <div
                  key={l.legId}
                  className="p-2 bg-[#121927] border border-[#1e293b] rounded flex justify-between items-center text-[11px]"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        l.side === 'BUY' ? 'bg-cyan-950 text-cyan-400' : 'bg-rose-950 text-rose-400'
                      }`}
                    >
                      {l.side}
                    </span>
                    <span className="text-slate-200">{l.description}</span>
                  </div>
                  <span className="text-slate-400 font-bold">{l.quantity}x</span>
                </div>
              ))}
            </div>
          </div>

          {/* Submit Proposal Button */}
          <div className="pt-2">
            <button
              onClick={handleCreateOrder}
              disabled={environment === 'LIVE_EXECUTION' || environment === 'RESEARCH'}
              className={`w-full py-2 px-3 rounded font-bold transition-colors ${
                environment === 'LIVE_EXECUTION'
                  ? 'bg-rose-950/60 border border-rose-800 text-rose-500 cursor-not-allowed'
                  : environment === 'RESEARCH'
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white'
              }`}
            >
              {environment === 'LIVE_EXECUTION'
                ? 'Live Order Submission Blocked'
                : environment === 'RESEARCH'
                ? 'Research Mode (Read-Only)'
                : 'Stage Proposal to Order Book'}
            </button>
          </div>
        </div>

        {/* Right Column: Pre-Trade Risk Check Gateway Audit */}
        <div className="lg:col-span-7 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Pre-Trade Institutional Risk Checks
            </h4>
            <p className="text-[11px] text-slate-400">
              Mandatory automated sanity filters evaluated prior to order entry
            </p>
          </div>

          <div className="space-y-2">
            {activeProposal.riskChecks.map((check, idx) => {
              const isPassed = check.status === 'PASSED';
              const isWarning = check.status === 'WARNING';
              return (
                <div
                  key={`risk-chk-${idx}`}
                  className={`p-2.5 rounded border ${
                    isPassed
                      ? 'bg-[#121927] border-[#1e293b]'
                      : isWarning
                      ? 'bg-amber-950/30 border-amber-800/60'
                      : 'bg-rose-950/30 border-rose-800/60'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      {isPassed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : isWarning ? (
                        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-500 shrink-0" />
                      )}
                      <span className="font-bold text-slate-200">{check.checkName}</span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isPassed
                          ? 'bg-emerald-950 text-emerald-400'
                          : isWarning
                          ? 'bg-amber-950 text-amber-400'
                          : 'bg-rose-950 text-rose-400'
                      }`}
                    >
                      {check.status}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 mt-1 pl-6">
                    {check.message}
                  </p>

                  <div className="flex justify-between text-[10px] text-slate-500 mt-1 pl-6">
                    <span>Limit: {check.limitValue}</span>
                    <span>Requested: {check.requestedValue}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Orders Book & Lifecycle State Table */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg">
        <div className="pb-2.5 border-b border-[#1e293b] flex justify-between items-center">
          <h4 className="font-bold uppercase tracking-wider text-slate-300">
            Order Book & Lifecycle Tracking ({orders.length} Orders)
          </h4>
          <span className="text-slate-400 text-[11px]">Matching Engine: RhinoQuant Paper ECN</span>
        </div>

        {orders.length === 0 ? (
          <div className="py-8 text-center text-slate-500">
            No orders staged yet. Click &quot;Stage Proposal to Order Book&quot; above to submit.
          </div>
        ) : (
          <div className="overflow-x-auto mt-2.5">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-[#1e293b] text-left">
                  <th className="py-1.5 px-2">Order ID</th>
                  <th className="py-1.5 px-2">Strategy</th>
                  <th className="py-1.5 px-2">Ticker</th>
                  <th className="py-1.5 px-2">Type</th>
                  <th className="py-1.5 px-2 text-right">Limit</th>
                  <th className="py-1.5 px-2 text-right">Notional</th>
                  <th className="py-1.5 px-2 text-center">Status</th>
                  <th className="py-1.5 px-2 text-right">Time</th>
                  <th className="py-1.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]/60">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-[#141d2e] transition-colors">
                    <td className="py-2 px-2 text-cyan-400 font-bold">{ord.id}</td>
                    <td className="py-2 px-2 text-slate-200">{ord.strategyName}</td>
                    <td className="py-2 px-2 text-slate-300">{ord.underlyingTicker}</td>
                    <td className="py-2 px-2 text-slate-400">{ord.orderType.replace(/_/g, ' ')}</td>
                    <td className="py-2 px-2 text-right text-slate-200">${ord.limitPrice?.toFixed(2)}</td>
                    <td className="py-2 px-2 text-right text-slate-200">${ord.totalNotional.toLocaleString()}</td>
                    <td className="py-2 px-2 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          ord.status === 'FILLED'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : ord.status === 'APPROVED'
                            ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                            : ord.status === 'REJECTED' || ord.status === 'CANCELLED'
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}
                      >
                        {ord.status}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right text-slate-400">{ord.createdTimestamp.slice(11, 19)}</td>
                    <td className="py-2 px-2 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {ord.status === 'APPROVED' && (
                          <button
                            onClick={() => handleExecutePaper(ord)}
                            className="px-2 py-0.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded font-bold text-[10px]"
                          >
                            Execute Fill
                          </button>
                        )}
                        {ord.status !== 'FILLED' && ord.status !== 'CANCELLED' && (
                          <button
                            onClick={() => handleCancelOrder(ord)}
                            className="text-slate-500 hover:text-rose-400 text-[10px]"
                          >
                            Cancel
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedAuditOrder(ord)}
                          className="text-cyan-400 hover:text-cyan-300 text-[10px] underline"
                        >
                          Audit Trail
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Audit Trail Modal */}
      {selectedAuditOrder && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4">
          <div className="bg-[#0e1420] border border-[#233045] rounded-lg max-w-xl w-full p-4 space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-[#1e293b]">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span className="font-bold text-white">Order Audit Trail: {selectedAuditOrder.id}</span>
              </div>
              <button
                onClick={() => setSelectedAuditOrder(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <div className="text-[11px] text-slate-400">
                State Transitions & Verification Log:
              </div>
              <div className="space-y-1.5 max-h-60 overflow-y-auto">
                {selectedAuditOrder.auditTrail.map((entry, idx) => (
                  <div key={`trail-${idx}`} className="p-2 bg-[#121927] border border-[#1e293b] rounded">
                    <div className="flex justify-between text-slate-300">
                      <span className="text-cyan-400 font-semibold">{entry.fromState} ➔ {entry.toState}</span>
                      <span className="text-[10px] text-slate-500">{entry.timestamp}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">{entry.note}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">Operator: {entry.operator}</div>
                  </div>
                ))}
              </div>
            </div>

            {selectedAuditOrder.fillDetails && (
              <div className="p-2.5 bg-[#141d2e] border border-[#233045] rounded space-y-1 text-[11px]">
                <div className="font-bold text-emerald-400">Execution Fill Report</div>
                <div className="flex justify-between text-slate-300">
                  <span>Contracts Filled:</span>
                  <span>{selectedAuditOrder.fillDetails.filledQuantity}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Avg Fill Price:</span>
                  <span>${selectedAuditOrder.fillDetails.avgFillPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Total Commission:</span>
                  <span>${selectedAuditOrder.fillDetails.totalCommission.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Settlement:</span>
                  <span>{selectedAuditOrder.fillDetails.settlementDate} (T+2)</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
