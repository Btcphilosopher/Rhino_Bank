/**
 * RhinoQuant Synthetic Shorts - Scenario Engine & Stress Matrix Terminal
 * 2D Spot-Vol Full Revaluation Heatmap, Historical Crises Replay, and Greek Factor Decomposition
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState, useMemo } from 'react';
import { StrategyDefinition } from '../quant/instruments';
import {
  PREDEFINED_STRESS_SCENARIOS,
  ScenarioDefinition,
  runScenarioRevaluation,
  generateSpotVolMatrix,
} from '../quant/scenarios';
import { Activity, Flame, ShieldAlert, Zap } from 'lucide-react';

interface ScenarioEngineViewProps {
  strategies: StrategyDefinition[];
}

export const ScenarioEngineView: React.FC<ScenarioEngineViewProps> = ({ strategies }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(PREDEFINED_STRESS_SCENARIOS[0].id);

  // Custom scenario overrides
  const [customSpotPct, setCustomSpotPct] = useState<number>(-20);
  const [customVolPts, setCustomVolPts] = useState<number>(15);
  const [customRateBps, setCustomRateBps] = useState<number>(-50);
  const [customBorrowBps, setCustomBorrowBps] = useState<number>(200);
  const [customDays, setCustomDays] = useState<number>(5);

  const activeScenario: ScenarioDefinition = useMemo(() => {
    if (selectedScenarioId === 'CUSTOM') {
      return {
        id: 'CUSTOM',
        name: 'Desk Custom Stress Scenario',
        category: 'DESK_CUSTOM',
        spotShockPct: customSpotPct / 100.0,
        volShockPctPoints: customVolPts / 100.0,
        rateShockBps: customRateBps,
        borrowShockBps: customBorrowBps,
        timeElapsedDays: customDays,
        description: 'Trader interactive parameter stress test',
      };
    }
    return (
      PREDEFINED_STRESS_SCENARIOS.find((s) => s.id === selectedScenarioId) ?? PREDEFINED_STRESS_SCENARIOS[0]
    );
  }, [selectedScenarioId, customSpotPct, customVolPts, customRateBps, customBorrowBps, customDays]);

  const scenarioResult = useMemo(() => {
    return runScenarioRevaluation(strategies, activeScenario);
  }, [strategies, activeScenario]);

  const stressMatrix = useMemo(() => {
    return generateSpotVolMatrix(strategies);
  }, [strategies]);

  const decomp = scenarioResult.factorDecomposition;

  return (
    <div className="space-y-4 font-mono">
      {/* Historical Crisis Selector */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-2">
        <div className="flex justify-between items-center pb-2 border-b border-[#1e293b]">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Historical Stress Scenarios & Crisis Replay
          </h4>
          <span className="text-xs text-slate-400">Full Non-Linear Revaluation Engine</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 pt-1 text-xs">
          {PREDEFINED_STRESS_SCENARIOS.map((scen) => (
            <button
              key={scen.id}
              onClick={() => setSelectedScenarioId(scen.id)}
              className={`p-2 rounded border text-left transition-all ${
                selectedScenarioId === scen.id
                  ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 font-bold'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
              }`}
            >
              <div className="truncate font-semibold">{scen.name}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                Spot {(scen.spotShockPct * 100).toFixed(0)}% · Vol +{(scen.volShockPctPoints * 100).toFixed(0)}%
              </div>
            </button>
          ))}

          <button
            onClick={() => setSelectedScenarioId('CUSTOM')}
            className={`p-2 rounded border text-left transition-all ${
              selectedScenarioId === 'CUSTOM'
                ? 'bg-amber-950/70 border-amber-500 text-amber-300 font-bold'
                : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
            }`}
          >
            <div className="truncate font-semibold">Custom Stress</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Interactive Parameters</div>
          </button>
        </div>

        {/* Custom Controls (if Custom Selected) */}
        {selectedScenarioId === 'CUSTOM' && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 pt-3 mt-2 border-t border-[#1e293b] text-xs">
            <div>
              <div className="flex justify-between text-slate-400">
                <span>Spot Shock:</span>
                <span className="text-white font-bold">{customSpotPct}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={customSpotPct}
                onChange={(e) => setCustomSpotPct(parseInt(e.target.value))}
                className="w-full accent-cyan-400 h-1 bg-[#1e293b] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400">
                <span>Vol Shift:</span>
                <span className="text-white font-bold">+{customVolPts}% pts</span>
              </div>
              <input
                type="range"
                min="-15"
                max="60"
                value={customVolPts}
                onChange={(e) => setCustomVolPts(parseInt(e.target.value))}
                className="w-full accent-amber-400 h-1 bg-[#1e293b] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400">
                <span>Rate Shock:</span>
                <span className="text-white font-bold">{customRateBps} bps</span>
              </div>
              <input
                type="range"
                min="-200"
                max="400"
                step="25"
                value={customRateBps}
                onChange={(e) => setCustomRateBps(parseInt(e.target.value))}
                className="w-full accent-indigo-400 h-1 bg-[#1e293b] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400">
                <span>Borrow Squeeze:</span>
                <span className="text-white font-bold">+{customBorrowBps} bps</span>
              </div>
              <input
                type="range"
                min="0"
                max="3000"
                step="100"
                value={customBorrowBps}
                onChange={(e) => setCustomBorrowBps(parseInt(e.target.value))}
                className="w-full accent-rose-400 h-1 bg-[#1e293b] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400">
                <span>Time Elapsed:</span>
                <span className="text-white font-bold">{customDays} Days</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={customDays}
                onChange={(e) => setCustomDays(parseInt(e.target.value))}
                className="w-full accent-slate-400 h-1 bg-[#1e293b] rounded cursor-pointer"
              />
            </div>
          </div>
        )}
      </div>

      {/* Scenario Evaluation & Factor Attribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Full Revaluation P&L and Risk Breakdown */}
        <div className="lg:col-span-5 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b] flex justify-between items-center">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Scenario Revaluation Result
            </h4>
            <span className="text-[10px] text-cyan-400 font-semibold">{activeScenario.name}</span>
          </div>

          <div className="p-3 bg-[#121927] border border-[#1e293b] rounded text-center">
            <div className="text-[10px] text-slate-400 uppercase">Total Portfolio Stressed P&L</div>
            <div
              className={`text-2xl font-bold my-1 ${
                scenarioResult.fullRevaluationPnl >= 0 ? 'text-cyan-400' : 'text-rose-500'
              }`}
            >
              {scenarioResult.fullRevaluationPnl >= 0 ? '+' : '-'}$
              {Math.abs(scenarioResult.fullRevaluationPnl).toFixed(2)}
            </div>
            <div className="text-[11px] text-slate-400">
              {activeScenario.description}
            </div>
          </div>

          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between py-1 border-b border-[#1e293b]/40">
              <span className="text-slate-400">Full Non-Linear Repricing:</span>
              <span className="font-bold text-white">
                ${scenarioResult.fullRevaluationPnl.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1e293b]/40">
              <span className="text-slate-400">Delta-Linear Approximation:</span>
              <span className="text-slate-300">
                ${scenarioResult.deltaLinearApproximationPnl.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1e293b]/40">
              <span className="text-slate-400">Delta-Gamma Approximation:</span>
              <span className="text-slate-300">
                ${scenarioResult.deltaGammaApproximationPnl.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1e293b]/40">
              <span className="text-slate-400">Non-Linear Higher-Order Residual:</span>
              <span className="font-bold text-amber-400">
                ${scenarioResult.unexplainedNonlinearResidual.toFixed(2)}
              </span>
            </div>
          </div>

          {scenarioResult.isMarginDeficitTriggered && (
            <div className="p-2.5 bg-rose-950/40 border border-rose-800 rounded flex items-center gap-2 text-rose-300 text-xs">
              <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
              <span>Critical Warning: Stressed loss breaches collateral threshold! Margin call triggered.</span>
            </div>
          )}
        </div>

        {/* Greek Factor Attribution Breakdown */}
        <div className="lg:col-span-7 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Greek & Factor Attribution Breakdown
            </h4>
            <p className="text-[11px] text-slate-400">
              Dissecting total P&L into Delta, Gamma, Vega, Theta, Borrow Drag and Cross-Terms
            </p>
          </div>

          <div className="space-y-2 text-xs">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Delta Contribution (Directional):</span>
                <span className={decomp.deltaContribution >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {decomp.deltaContribution >= 0 ? '+' : '-'}${Math.abs(decomp.deltaContribution).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-[#1e293b] h-1.5 rounded overflow-hidden">
                <div
                  className={`h-full ${decomp.deltaContribution >= 0 ? 'bg-emerald-400' : 'bg-rose-500'}`}
                  style={{ width: `${Math.min(100, (Math.abs(decomp.deltaContribution) / (Math.abs(scenarioResult.fullRevaluationPnl) + 1)) * 100)}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Gamma Contribution (Convexity):</span>
                <span className={decomp.gammaContribution >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {decomp.gammaContribution >= 0 ? '+' : '-'}${Math.abs(decomp.gammaContribution).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-[#1e293b] h-1.5 rounded overflow-hidden">
                <div
                  className={`h-full ${decomp.gammaContribution >= 0 ? 'bg-emerald-400' : 'bg-rose-500'}`}
                  style={{ width: `${Math.min(100, (Math.abs(decomp.gammaContribution) / (Math.abs(scenarioResult.fullRevaluationPnl) + 1)) * 100)}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Vega Contribution (Implied Vol Expansion):</span>
                <span className={decomp.vegaContribution >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {decomp.vegaContribution >= 0 ? '+' : '-'}${Math.abs(decomp.vegaContribution).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-[#1e293b] h-1.5 rounded overflow-hidden">
                <div
                  className={`h-full ${decomp.vegaContribution >= 0 ? 'bg-emerald-400' : 'bg-rose-500'}`}
                  style={{ width: `${Math.min(100, (Math.abs(decomp.vegaContribution) / (Math.abs(scenarioResult.fullRevaluationPnl) + 1)) * 100)}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Theta Contribution (Time Decay):</span>
                <span className={decomp.thetaContribution >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {decomp.thetaContribution >= 0 ? '+' : '-'}${Math.abs(decomp.thetaContribution).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-[#1e293b] h-1.5 rounded overflow-hidden">
                <div
                  className={`h-full ${decomp.thetaContribution >= 0 ? 'bg-emerald-400' : 'bg-rose-500'}`}
                  style={{ width: `${Math.min(100, (Math.abs(decomp.thetaContribution) / (Math.abs(scenarioResult.fullRevaluationPnl) + 1)) * 100)}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Borrow & Financing Squeeze Drag:</span>
                <span className={decomp.borrowContribution >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {decomp.borrowContribution >= 0 ? '+' : '-'}${Math.abs(decomp.borrowContribution).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-[#1e293b] h-1.5 rounded overflow-hidden">
                <div
                  className="h-full bg-rose-500"
                  style={{ width: `${Math.min(100, (Math.abs(decomp.borrowContribution) / (Math.abs(scenarioResult.fullRevaluationPnl) + 1)) * 100)}%` }}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Non-linear Cross-Greeks (Vanna/Volga):</span>
                <span className={decomp.higherOrderCrossTerms >= 0 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                  {decomp.higherOrderCrossTerms >= 0 ? '+' : '-'}${Math.abs(decomp.higherOrderCrossTerms).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-[#1e293b] h-1.5 rounded overflow-hidden">
                <div
                  className="h-full bg-amber-400"
                  style={{ width: `${Math.min(100, (Math.abs(decomp.higherOrderCrossTerms) / (Math.abs(scenarioResult.fullRevaluationPnl) + 1)) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2D Spot vs Volatility Stress Matrix Heatmap */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg">
        <div className="pb-3 border-b border-[#1e293b] flex justify-between items-center text-xs">
          <div>
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Joint Spot vs Volatility Stress Matrix (Heatmap)
            </h4>
            <p className="text-[11px] text-slate-400">
              Full revaluation P&L at each (Spot Shock, Volatility Shift) coordinate
            </p>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="text-cyan-400">Worst Case: ${stressMatrix.worstCaseCell.revaluedPnl.toFixed(0)}</span>
            <span className="text-slate-500">|</span>
            <span className="text-emerald-400">Best Case: +${stressMatrix.bestCaseCell.revaluedPnl.toFixed(0)}</span>
          </div>
        </div>

        <div className="overflow-x-auto mt-3">
          <table className="w-full text-xs text-center border-collapse">
            <thead>
              <tr>
                <th className="py-1 px-2 text-slate-400 font-semibold bg-[#121927] border border-[#1e293b]">
                  Vol \ Spot
                </th>
                {stressMatrix.spotLabels.map((sLabel) => (
                  <th
                    key={`spot-${sLabel}`}
                    className="py-1 px-2 text-slate-300 font-semibold bg-[#141d2e] border border-[#1e293b]"
                  >
                    {sLabel >= 0 ? `+${sLabel}%` : `${sLabel}%`}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stressMatrix.cells.map((row, rIdx) => {
                const volLabel = stressMatrix.volLabels[rIdx];
                return (
                  <tr key={`vol-row-${volLabel}`}>
                    <td className="py-1 px-2 font-semibold text-slate-300 bg-[#141d2e] border border-[#1e293b]">
                      {volLabel >= 0 ? `+${volLabel}%` : `${volLabel}%`}
                    </td>
                    {row.map((cell, cIdx) => {
                      const pnl = cell.revaluedPnl;
                      const isProfit = pnl >= 0;
                      // Color intensity based on scale
                      let bgStyle = 'bg-[#121927]';
                      if (isProfit) {
                        bgStyle = pnl > 10000 ? 'bg-cyan-950/90 text-cyan-200 font-bold' : 'bg-cyan-950/40 text-cyan-300';
                      } else {
                        bgStyle = pnl < -10000 ? 'bg-rose-950/90 text-rose-200 font-bold' : 'bg-rose-950/40 text-rose-300';
                      }

                      return (
                        <td
                          key={`cell-${rIdx}-${cIdx}`}
                          className={`py-1.5 px-2 text-[11px] font-mono border border-[#1e293b]/70 ${bgStyle}`}
                          title={`Spot: ${cell.spotShockPct}%, Vol: ${cell.volShockPctPoints}%, Reval P&L: $${pnl.toFixed(2)}`}
                        >
                          {pnl >= 0 ? `+${(pnl / 1000).toFixed(1)}k` : `-${(Math.abs(pnl) / 1000).toFixed(1)}k`}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
