/**
 * RhinoQuant Synthetic Shorts - Synthetic Position Lab Workspace
 * Core Workbench for Multi-Asset Bearish Derivative Strategy Construction, Valuation, Greeks, and Boundedness Verification
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState, useMemo } from 'react';
import {
  UnderlyingAsset,
  StrategyDefinition,
  StrategyLeg,
  createStrategyTemplate,
} from '../quant/instruments';
import { INSTITUTIONAL_INSTRUMENT_MASTER } from '../quant/market-data';
import { analyzeStrategyPayoff } from '../quant/payoff';
import { calculateBSM } from '../quant/math';
import { PayoffChart } from './PayoffChart';
import {
  Sliders,
  Plus,
  Trash2,
  BookmarkPlus,
  TrendingDown,
  Layers,
  ArrowRight,
  Info,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';

interface SyntheticPositionLabProps {
  onSaveStrategy: (strategy: StrategyDefinition) => void;
  onAddToPortfolio: (strategy: StrategyDefinition) => void;
  onProposeOrder: (strategy: StrategyDefinition) => void;
}

export const SyntheticPositionLab: React.FC<SyntheticPositionLabProps> = ({
  onSaveStrategy,
  onAddToPortfolio,
  onProposeOrder,
}) => {
  // Current selected asset
  const [selectedAssetId, setSelectedAssetId] = useState<string>(INSTITUTIONAL_INSTRUMENT_MASTER[0].id);

  const underlying = useMemo(() => {
    return INSTITUTIONAL_INSTRUMENT_MASTER.find((a) => a.id === selectedAssetId) ?? INSTITUTIONAL_INSTRUMENT_MASTER[0];
  }, [selectedAssetId]);

  // Strategy template selection
  const [templateType, setTemplateType] = useState<StrategyDefinition['templateType']>('SYNTHETIC_SHORT_STOCK');

  // Active strategy state
  const [strategy, setStrategy] = useState<StrategyDefinition>(() =>
    createStrategyTemplate('SYNTHETIC_SHORT_STOCK', INSTITUTIONAL_INSTRUMENT_MASTER[0])
  );

  // Simulation adjustments
  const [spotPriceAdj, setSpotPriceAdj] = useState<number>(underlying.spotPrice);
  const [ivAdj, setIvAdj] = useState<number>(underlying.impliedVol);
  const [rfRateAdj, setRfRateAdj] = useState<number>(underlying.riskFreeRate);
  const [borrowRateAdj, setBorrowRateAdj] = useState<number>(underlying.borrowRate);

  // Update strategy when asset or template changes
  const handleSelectAsset = (assetId: string) => {
    const newAsset = INSTITUTIONAL_INSTRUMENT_MASTER.find((a) => a.id === assetId) ?? INSTITUTIONAL_INSTRUMENT_MASTER[0];
    setSelectedAssetId(assetId);
    setSpotPriceAdj(newAsset.spotPrice);
    setIvAdj(newAsset.impliedVol);
    setRfRateAdj(newAsset.riskFreeRate);
    setBorrowRateAdj(newAsset.borrowRate);
    const newStrat = createStrategyTemplate(templateType, {
      ...newAsset,
      spotPrice: newAsset.spotPrice,
      impliedVol: newAsset.impliedVol,
    });
    setStrategy(newStrat);
  };

  const handleSelectTemplate = (type: StrategyDefinition['templateType']) => {
    setTemplateType(type);
    const updatedAsset: UnderlyingAsset = {
      ...underlying,
      spotPrice: spotPriceAdj,
      impliedVol: ivAdj,
      riskFreeRate: rfRateAdj,
      borrowRate: borrowRateAdj,
    };
    const newStrat = createStrategyTemplate(type, updatedAsset);
    setStrategy(newStrat);
  };

  // Re-price legs when spot or IV sliders move
  const liveStrategy = useMemo(() => {
    const updatedUnderlying: UnderlyingAsset = {
      ...underlying,
      spotPrice: spotPriceAdj,
      impliedVol: ivAdj,
      riskFreeRate: rfRateAdj,
      borrowRate: borrowRateAdj,
    };

    const updatedLegs = strategy.legs.map((leg) => {
      if (leg.instrumentType === 'VANILLA_OPTION') {
        const bsm = calculateBSM({
          spot: spotPriceAdj,
          strike: leg.strike ?? spotPriceAdj,
          timeToExpiry: leg.timeToExpiryYears,
          riskFreeRate: rfRateAdj,
          dividendYield: updatedUnderlying.dividendYield,
          volatility: ivAdj,
          optionType: leg.optionType ?? 'put',
        });
        return {
          ...leg,
          currentTheoreticalPrice: bsm.price,
          greeks: bsm.greeks,
        };
      }
      return leg;
    });

    return {
      ...strategy,
      underlying: updatedUnderlying,
      legs: updatedLegs,
    };
  }, [strategy, underlying, spotPriceAdj, ivAdj, rfRateAdj, borrowRateAdj]);

  // Compute comprehensive payoff and parity analysis
  const payoffAnalysis = useMemo(() => {
    return analyzeStrategyPayoff(liveStrategy, 65, 0.6, 1.4);
  }, [liveStrategy]);

  // Leg table modifications
  const handleUpdateLeg = (legId: string, updates: Partial<StrategyLeg>) => {
    setStrategy((prev) => {
      const newLegs = prev.legs.map((leg) => {
        if (leg.id === legId) {
          const merged = { ...leg, ...updates };
          if (merged.instrumentType === 'VANILLA_OPTION') {
            const bsm = calculateBSM({
              spot: spotPriceAdj,
              strike: merged.strike ?? spotPriceAdj,
              timeToExpiry: merged.timeToExpiryYears,
              riskFreeRate: rfRateAdj,
              dividendYield: underlying.dividendYield,
              volatility: merged.impliedVol,
              optionType: merged.optionType ?? 'put',
            });
            merged.currentTheoreticalPrice = bsm.price;
            merged.greeks = bsm.greeks;
          }
          return merged;
        }
        return leg;
      });
      return {
        ...prev,
        templateType: 'CUSTOM_MULTI_LEG',
        legs: newLegs,
      };
    });
  };

  const handleDeleteLeg = (legId: string) => {
    setStrategy((prev) => ({
      ...prev,
      templateType: 'CUSTOM_MULTI_LEG',
      legs: prev.legs.filter((l) => l.id !== legId),
    }));
  };

  const handleAddLeg = () => {
    const strike = Math.round(spotPriceAdj);
    const T = 45 / 365;
    const bsm = calculateBSM({
      spot: spotPriceAdj,
      strike,
      timeToExpiry: T,
      riskFreeRate: rfRateAdj,
      dividendYield: underlying.dividendYield,
      volatility: ivAdj,
      optionType: 'put',
    });

    const newLeg: StrategyLeg = {
      id: `leg-custom-${Date.now()}`,
      instrumentType: 'VANILLA_OPTION',
      side: 'BUY',
      quantity: 1,
      multiplier: underlying.multiplier,
      strike,
      timeToExpiryYears: T,
      expiryDateStr: new Date(Date.now() + 45 * 24 * 3600 * 1000).toISOString().split('T')[0],
      optionType: 'put',
      exerciseStyle: 'EUROPEAN',
      entryPremium: bsm.price,
      currentTheoreticalPrice: bsm.price,
      currentBid: Math.max(0.01, bsm.price - 0.05),
      currentAsk: bsm.price + 0.05,
      impliedVol: ivAdj,
      greeks: bsm.greeks,
      contractNotional: strike * underlying.multiplier,
      description: `Custom Put K=${strike}`,
      isBorrowRequired: false,
    };

    setStrategy((prev) => ({
      ...prev,
      templateType: 'CUSTOM_MULTI_LEG',
      legs: [...prev.legs, newLeg],
    }));
  };

  // Aggregated Position Greeks
  const positionGreeks = useMemo(() => {
    let delta = 0;
    let gamma = 0;
    let vega1pct = 0;
    let theta1Day = 0;
    let rho1pct = 0;

    for (const leg of liveStrategy.legs) {
      const sign = leg.side === 'BUY' ? 1 : -1;
      const mult = leg.multiplier * leg.quantity;
      delta += sign * leg.greeks.delta * mult;
      gamma += sign * leg.greeks.gamma * mult;
      vega1pct += sign * leg.greeks.vega1pct * mult;
      theta1Day += sign * leg.greeks.theta1Day * mult;
      rho1pct += sign * leg.greeks.rho1pct * mult;
    }

    return { delta, gamma, vega1pct, theta1Day, rho1pct };
  }, [liveStrategy]);

  return (
    <div className="space-y-4">
      {/* Top Controls: Asset Selection & Strategy Templates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg">
        {/* Underlying Selector */}
        <div className="lg:col-span-4 space-y-1.5">
          <label className="text-[11px] font-mono uppercase text-slate-400 font-semibold tracking-wider">
            Reference Asset Master
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {INSTITUTIONAL_INSTRUMENT_MASTER.map((asset) => {
              const isSelected = asset.id === selectedAssetId;
              return (
                <button
                  key={asset.id}
                  onClick={() => handleSelectAsset(asset.id)}
                  className={`px-2 py-1.5 text-xs font-mono font-medium rounded border transition-all text-center ${
                    isSelected
                      ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 font-bold shadow-xs'
                      : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:border-[#334155]'
                  }`}
                >
                  <div className="truncate font-bold">{asset.ticker}</div>
                  <div className="text-[10px] text-slate-400 font-normal">
                    ${asset.spotPrice.toFixed(1)}
                  </div>
                </button>
              );
            })}
          </div>
          {underlying.hardToBorrow && (
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-amber-400 bg-amber-950/30 border border-amber-800/60 px-2 py-1 rounded">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>Hard-to-Borrow Notice: Locate fee {(underlying.borrowRate * 100).toFixed(1)}% p.a.</span>
            </div>
          )}
        </div>

        {/* Strategy Template Carousel */}
        <div className="lg:col-span-8 space-y-1.5">
          <label className="text-[11px] font-mono uppercase text-slate-400 font-semibold tracking-wider">
            Bearish Strategy Templates
          </label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5">
            <button
              onClick={() => handleSelectTemplate('SYNTHETIC_SHORT_STOCK')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'SYNTHETIC_SHORT_STOCK'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Synthetic Short Stock</div>
              <div className="text-[10px] text-slate-400 font-mono">Long Put + Short Call</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('LONG_PUT')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'LONG_PUT'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Long Put</div>
              <div className="text-[10px] text-slate-400 font-mono">Pure Defined Risk</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('BEAR_PUT_SPREAD')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'BEAR_PUT_SPREAD'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Bear Put Spread</div>
              <div className="text-[10px] text-slate-400 font-mono">Vertical Debit Spread</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('BEAR_CALL_SPREAD')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'BEAR_CALL_SPREAD'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Bear Call Spread</div>
              <div className="text-[10px] text-slate-400 font-mono">Net Credit Spread</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('PUT_BACKSPREAD')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'PUT_BACKSPREAD'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Put Backspread</div>
              <div className="text-[10px] text-slate-400 font-mono">1x2 Crash Convexity</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('SHORT_FUTURES')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'SHORT_FUTURES'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Short Futures</div>
              <div className="text-[10px] text-slate-400 font-mono">Exchange Linear Short</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('TOTAL_RETURN_SWAP_SHORT')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'TOTAL_RETURN_SWAP_SHORT'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Total Return Swap</div>
              <div className="text-[10px] text-slate-400 font-mono">Synthetic PB Receiver</div>
            </button>

            <button
              onClick={() => handleSelectTemplate('CUSTOM_MULTI_LEG')}
              className={`p-2 text-left rounded border transition-all ${
                templateType === 'CUSTOM_MULTI_LEG'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300'
                  : 'bg-[#141d2e] border-[#1e293b] text-slate-300 hover:border-[#334155]'
              }`}
            >
              <div className="text-xs font-bold font-sans">Custom Multi-Leg</div>
              <div className="text-[10px] text-slate-400 font-mono">User-Defined Structure</div>
            </button>
          </div>
        </div>
      </div>

      {/* Main Analysis Split: Payoff Engine & Mathematical Readouts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Interactive Payoff Chart & Parameter Sliders */}
        <div className="lg:col-span-8 space-y-3">
          <div className="bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg">
            <div className="flex items-center justify-between pb-3 border-b border-[#1e293b]">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2 font-sans">
                  <span>Payoff & Valuation Profile</span>
                  <span className="text-xs font-mono font-normal text-slate-400">({liveStrategy.name})</span>
                </h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Black-Scholes-Merton (1973) continuous carry model with multi-horizon time decay
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setSpotPriceAdj(underlying.spotPrice);
                    setIvAdj(underlying.impliedVol);
                  }}
                  className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-slate-200 bg-[#141d2e] border border-[#1e293b] px-2 py-1 rounded"
                  title="Reset market adjustments to baseline"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Inputs</span>
                </button>
              </div>
            </div>

            {/* Payoff Chart */}
            <div className="mt-3">
              <PayoffChart
                points={payoffAnalysis.points}
                underlyingSpot={spotPriceAdj}
                breakEvens={payoffAnalysis.breakEvens}
                currency={underlying.currency}
                height={330}
                showBenchmark={true}
                showHalfHorizon={true}
                showVolShifts={true}
              />
            </div>

            {/* Interactive Model Input Sliders */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-3 border-t border-[#1e293b] text-xs font-mono">
              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Spot Price (S):</span>
                  <span className="font-semibold text-white">${spotPriceAdj.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={underlying.spotPrice * 0.7}
                  max={underlying.spotPrice * 1.3}
                  step={0.1}
                  value={spotPriceAdj}
                  onChange={(e) => setSpotPriceAdj(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1 bg-[#1e293b] rounded cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Implied Vol (IV):</span>
                  <span className="font-semibold text-white">{(ivAdj * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min={0.05}
                  max={1.20}
                  step={0.01}
                  value={ivAdj}
                  onChange={(e) => setIvAdj(parseFloat(e.target.value))}
                  className="w-full accent-amber-400 h-1 bg-[#1e293b] rounded cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Discount Rate (r):</span>
                  <span className="font-semibold text-white">{(rfRateAdj * 100).toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min={0.0}
                  max={0.10}
                  step={0.0025}
                  value={rfRateAdj}
                  onChange={(e) => setRfRateAdj(parseFloat(e.target.value))}
                  className="w-full accent-indigo-400 h-1 bg-[#1e293b] rounded cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Borrow Fee (q):</span>
                  <span className="font-semibold text-white">{(borrowRateAdj * 100).toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min={0.0}
                  max={0.25}
                  step={0.005}
                  value={borrowRateAdj}
                  onChange={(e) => setBorrowRateAdj(parseFloat(e.target.value))}
                  className="w-full accent-rose-400 h-1 bg-[#1e293b] rounded cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Strategy Legs Configuration Table */}
          <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg">
            <div className="flex items-center justify-between pb-2.5 border-b border-[#1e293b]">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono">
                  Strategy Legs & Contract Terms ({liveStrategy.legs.length} Active Legs)
                </h4>
              </div>
              <button
                onClick={handleAddLeg}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-medium text-cyan-300 bg-cyan-950/60 border border-cyan-800 rounded hover:bg-cyan-900/60 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Leg</span>
              </button>
            </div>

            <div className="overflow-x-auto mt-2.5">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="text-slate-400 border-b border-[#1e293b] text-left">
                    <th className="py-1.5 px-2 font-semibold">Side</th>
                    <th className="py-1.5 px-2 font-semibold">Qty</th>
                    <th className="py-1.5 px-2 font-semibold">Type</th>
                    <th className="py-1.5 px-2 font-semibold">Strike</th>
                    <th className="py-1.5 px-2 font-semibold">Expiry</th>
                    <th className="py-1.5 px-2 font-semibold text-right">Entry Prem.</th>
                    <th className="py-1.5 px-2 font-semibold text-right">Model Price</th>
                    <th className="py-1.5 px-2 font-semibold text-right">Delta</th>
                    <th className="py-1.5 px-2 font-semibold text-right">Vega (1%)</th>
                    <th className="py-1.5 px-2 font-semibold text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e293b]/60">
                  {liveStrategy.legs.map((leg) => {
                    return (
                      <tr key={leg.id} className="hover:bg-[#141d2e] transition-colors">
                        <td className="py-2 px-2">
                          <button
                            onClick={() =>
                              handleUpdateLeg(leg.id, { side: leg.side === 'BUY' ? 'SELL' : 'BUY' })
                            }
                            className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                              leg.side === 'BUY'
                                ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                                : 'bg-rose-950 text-rose-400 border border-rose-800'
                            }`}
                          >
                            {leg.side}
                          </button>
                        </td>
                        <td className="py-2 px-2">
                          <input
                            type="number"
                            min="1"
                            max="1000"
                            value={leg.quantity}
                            onChange={(e) =>
                              handleUpdateLeg(leg.id, { quantity: Math.max(1, parseInt(e.target.value) || 1) })
                            }
                            className="w-14 px-1.5 py-0.5 bg-[#121927] border border-[#233045] rounded text-slate-100 text-center"
                          />
                        </td>
                        <td className="py-2 px-2 text-slate-300 font-semibold">
                          {leg.instrumentType === 'VANILLA_OPTION'
                            ? leg.optionType?.toUpperCase()
                            : leg.instrumentType.replace('_', ' ')}
                        </td>
                        <td className="py-2 px-2">
                          {leg.strike !== undefined ? (
                            <input
                              type="number"
                              step="0.5"
                              value={leg.strike}
                              onChange={(e) =>
                                handleUpdateLeg(leg.id, { strike: parseFloat(e.target.value) || 0 })
                              }
                              className="w-20 px-1.5 py-0.5 bg-[#121927] border border-[#233045] rounded text-slate-100"
                            />
                          ) : (
                            <span className="text-slate-500">—</span>
                          )}
                        </td>
                        <td className="py-2 px-2 text-slate-300">
                          {leg.expiryDateStr}
                          <span className="text-slate-400 text-[10px] ml-1">
                            ({Math.round(leg.timeToExpiryYears * 365)}d)
                          </span>
                        </td>
                        <td className="py-2 px-2 text-right text-slate-300">
                          ${leg.entryPremium.toFixed(2)}
                        </td>
                        <td className="py-2 px-2 text-right text-cyan-300 font-bold">
                          ${leg.currentTheoreticalPrice.toFixed(2)}
                        </td>
                        <td className="py-2 px-2 text-right text-slate-300">
                          {(leg.greeks.delta * (leg.side === 'BUY' ? 1 : -1)).toFixed(3)}
                        </td>
                        <td className="py-2 px-2 text-right text-slate-300">
                          ${(leg.greeks.vega1pct * (leg.side === 'BUY' ? 1 : -1) * leg.multiplier).toFixed(2)}
                        </td>
                        <td className="py-2 px-2 text-center">
                          <button
                            onClick={() => handleDeleteLeg(leg.id)}
                            className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                            title="Remove leg"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Quantitative Risk, Parity Proof & Actions */}
        <div className="lg:col-span-4 space-y-3">
          {/* Economic Metrics Strip */}
          <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-3 font-mono text-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 pb-2 border-b border-[#1e293b]">
              Position Economics & Capital
            </h4>

            <div className="space-y-2">
              <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
                <span className="text-slate-400">Net Initial Premium:</span>
                <span
                  className={`font-bold ${
                    payoffAnalysis.netInitialPremium >= 0 ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {payoffAnalysis.netInitialPremium >= 0
                    ? `Debit Paid: $${payoffAnalysis.netInitialPremium.toFixed(2)}`
                    : `Credit Recv: $${Math.abs(payoffAnalysis.netInitialPremium).toFixed(2)}`}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
                <span className="text-slate-400">Expiry Break-Even:</span>
                <span className="font-bold text-amber-400">
                  {payoffAnalysis.breakEvens.length > 0
                    ? `$${payoffAnalysis.breakEvens[0].price.toFixed(2)} (${payoffAnalysis.breakEvens[0].distancePct >= 0 ? '+' : ''}${payoffAnalysis.breakEvens[0].distancePct.toFixed(2)}%)`
                    : 'No Expiry Zero-Crossing'}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
                <span className="text-slate-400">Maximum Profit:</span>
                <span className="font-bold text-emerald-400">
                  {payoffAnalysis.maxProfit.isUnbounded
                    ? 'Unbounded'
                    : typeof payoffAnalysis.maxProfit.value === 'number'
                    ? `$${payoffAnalysis.maxProfit.value.toFixed(2)}`
                    : 'Unbounded'}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-[#1e293b]/50">
                <span className="text-slate-400">Maximum Loss:</span>
                <span
                  className={`font-bold ${
                    payoffAnalysis.maxLoss.isUnbounded ? 'text-rose-500 underline' : 'text-rose-400'
                  }`}
                >
                  {payoffAnalysis.maxLoss.isUnbounded
                    ? 'UNBOUNDED RISK'
                    : typeof payoffAnalysis.maxLoss.value === 'number'
                    ? `-$${Math.abs(payoffAnalysis.maxLoss.value).toFixed(2)}`
                    : 'UNBOUNDED'}
                </span>
              </div>
            </div>

            {/* Boundedness Risk Disclosure */}
            <div className="p-2.5 bg-[#141d2e] border border-[#233045] rounded text-[11px] text-slate-300 space-y-1">
              <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Boundedness & Risk Classification</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                {payoffAnalysis.maxLoss.description}
              </p>
            </div>
          </div>

          {/* Position Greeks Summary */}
          <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-3 font-mono text-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 pb-2 border-b border-[#1e293b]">
              Position Greeks (1st & 2nd Order)
            </h4>

            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 bg-[#121927] border border-[#1e293b] rounded">
                <div className="text-[10px] text-slate-400">Net Delta (Units)</div>
                <div
                  className={`text-sm font-bold ${
                    positionGreeks.delta < 0 ? 'text-cyan-400' : 'text-slate-200'
                  }`}
                >
                  {positionGreeks.delta.toFixed(2)} shs
                </div>
                <div className="text-[10px] text-slate-500">
                  ${(positionGreeks.delta * spotPriceAdj).toFixed(0)} delta-notional
                </div>
              </div>

              <div className="p-2 bg-[#121927] border border-[#1e293b] rounded">
                <div className="text-[10px] text-slate-400">Net Gamma</div>
                <div className="text-sm font-bold text-slate-200">
                  {positionGreeks.gamma.toFixed(4)}
                </div>
                <div className="text-[10px] text-slate-500">dDelta / dS</div>
              </div>

              <div className="p-2 bg-[#121927] border border-[#1e293b] rounded">
                <div className="text-[10px] text-slate-400">Net Vega (1%)</div>
                <div
                  className={`text-sm font-bold ${
                    positionGreeks.vega1pct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {positionGreeks.vega1pct >= 0 ? '+' : '-'}${Math.abs(positionGreeks.vega1pct).toFixed(2)}
                </div>
                <div className="text-[10px] text-slate-500">per 1% IV shift</div>
              </div>

              <div className="p-2 bg-[#121927] border border-[#1e293b] rounded">
                <div className="text-[10px] text-slate-400">Net Theta (1-Day)</div>
                <div
                  className={`text-sm font-bold ${
                    positionGreeks.theta1Day >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {positionGreeks.theta1Day >= 0 ? '+' : '-'}${Math.abs(positionGreeks.theta1Day).toFixed(2)}
                </div>
                <div className="text-[10px] text-slate-500">decay per calendar day</div>
              </div>
            </div>
          </div>

          {/* Put-Call Parity Audit */}
          <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-2 font-mono text-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 pb-1 border-b border-[#1e293b]">
              Put-Call Parity Verification
            </h4>
            <div className="text-[11px] text-slate-400 space-y-1">
              <div>Identity: <code className="text-cyan-300">C - P = S*e^(-qT) - K*e^(-rT)</code></div>
              <div className="flex justify-between items-center pt-1">
                <span>Parity Residual (|Δ|):</span>
                <span className="font-bold text-emerald-400">
                  {payoffAnalysis.putCallParityResidual.toExponential(4)}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 pt-1 leading-normal">
                {payoffAnalysis.shortForwardEquivalenceNote}
              </p>
            </div>
          </div>

          {/* Action Triggers */}
          <div className="space-y-2 pt-1 font-mono">
            <button
              onClick={() => onProposeOrder(liveStrategy)}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded transition-colors text-xs"
            >
              <TrendingDown className="w-4 h-4" />
              <span>Generate Order Proposal & Risk Checks</span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onAddToPortfolio(liveStrategy)}
                className="flex items-center justify-center gap-1.5 py-1.5 px-3 bg-[#1e293b] hover:bg-[#28384f] text-slate-200 border border-[#334155] rounded transition-colors text-xs"
              >
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>Add to Portfolio</span>
              </button>

              <button
                onClick={() => onSaveStrategy(liveStrategy)}
                className="flex items-center justify-center gap-1.5 py-1.5 px-3 bg-[#1e293b] hover:bg-[#28384f] text-slate-200 border border-[#334155] rounded transition-colors text-xs"
              >
                <BookmarkPlus className="w-3.5 h-3.5 text-amber-400" />
                <span>Save Version</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
