/**
 * RhinoQuant Synthetic Shorts - Institutional Payoff & Valuation Chart
 * Interactive SVG Vector Engine for Multi-Horizon Expiry, Theoretical Curves & Benchmarks
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState, useMemo } from 'react';
import { PayoffPoint, BreakEvenResult } from '../quant/payoff';

interface PayoffChartProps {
  points: PayoffPoint[];
  underlyingSpot: number;
  breakEvens: BreakEvenResult[];
  currency?: string;
  height?: number;
  showBenchmark?: boolean;
  showHalfHorizon?: boolean;
  showVolShifts?: boolean;
}

export const PayoffChart: React.FC<PayoffChartProps> = ({
  points,
  underlyingSpot,
  breakEvens,
  currency = 'USD',
  height = 360,
  showBenchmark = true,
  showHalfHorizon = true,
  showVolShifts = true,
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // Layout boundaries
  const padding = { top: 24, right: 36, bottom: 44, left: 72 };
  const width = 800; // viewBox width

  const { minSpot, maxSpot, minPnl, maxPnl } = useMemo(() => {
    if (!points || points.length === 0) {
      return { minSpot: 0, maxSpot: 100, minPnl: -100, maxPnl: 100 };
    }

    const spots = points.map((p) => p.spot);
    const minS = Math.min(...spots);
    const maxS = Math.max(...spots);

    let minVal = 0;
    let maxVal = 0;

    for (const p of points) {
      minVal = Math.min(minVal, p.expiryPayoff, p.currentTheoreticalPnl);
      maxVal = Math.max(maxVal, p.expiryPayoff, p.currentTheoreticalPnl);
      if (showBenchmark) {
        minVal = Math.min(minVal, p.forwardBenchmarkPnl);
        maxVal = Math.max(maxVal, p.forwardBenchmarkPnl);
      }
    }

    // Add 15% headroom
    const pnlRange = Math.max(50, maxVal - minVal);
    const paddedMin = minVal - pnlRange * 0.12;
    const paddedMax = maxVal + pnlRange * 0.12;

    return { minSpot: minS, maxSpot: maxS, minPnl: paddedMin, maxPnl: paddedMax };
  }, [points, showBenchmark]);

  // Coordinate mappers
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const getX = (spot: number) => {
    if (maxSpot === minSpot) return padding.left;
    return padding.left + ((spot - minSpot) / (maxSpot - minSpot)) * chartWidth;
  };

  const getY = (pnl: number) => {
    if (maxPnl === minPnl) return padding.top + chartHeight / 2;
    return padding.top + (1.0 - (pnl - minPnl) / (maxPnl - minPnl)) * chartHeight;
  };

  const zeroY = getY(0);
  const currentSpotX = getX(underlyingSpot);

  // SVG path builders
  const expiryPath = useMemo(() => {
    if (!points || points.length === 0) return '';
    return points.reduce((acc, p, i) => {
      const x = getX(p.spot);
      const y = getY(p.expiryPayoff);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points, minSpot, maxSpot, minPnl, maxPnl]);

  const theoreticalPath = useMemo(() => {
    if (!points || points.length === 0) return '';
    return points.reduce((acc, p, i) => {
      const x = getX(p.spot);
      const y = getY(p.currentTheoreticalPnl);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points, minSpot, maxSpot, minPnl, maxPnl]);

  const halfHorizonPath = useMemo(() => {
    if (!showHalfHorizon || !points || points.length === 0) return '';
    return points.reduce((acc, p, i) => {
      const x = getX(p.spot);
      const y = getY(p.halfHorizonPnl);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points, showHalfHorizon, minSpot, maxSpot, minPnl, maxPnl]);

  const benchmarkPath = useMemo(() => {
    if (!showBenchmark || !points || points.length === 0) return '';
    return points.reduce((acc, p, i) => {
      const x = getX(p.spot);
      const y = getY(p.forwardBenchmarkPnl);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points, showBenchmark, minSpot, maxSpot, minPnl, maxPnl]);

  const volUpPath = useMemo(() => {
    if (!showVolShifts || !points || points.length === 0) return '';
    return points.reduce((acc, p, i) => {
      const x = getX(p.spot);
      const y = getY(p.volUpPnl);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points, showVolShifts, minSpot, maxSpot, minPnl, maxPnl]);

  const volDownPath = useMemo(() => {
    if (!showVolShifts || !points || points.length === 0) return '';
    return points.reduce((acc, p, i) => {
      const x = getX(p.spot);
      const y = getY(p.volDownPnl);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points, showVolShifts, minSpot, maxSpot, minPnl, maxPnl]);

  // Y-axis tick values (5-6 intervals)
  const yTicks = useMemo(() => {
    const ticks: number[] = [];
    const count = 5;
    const step = (maxPnl - minPnl) / count;
    for (let i = 0; i <= count; i++) {
      ticks.push(minPnl + i * step);
    }
    return ticks;
  }, [minPnl, maxPnl]);

  // X-axis tick values
  const xTicks = useMemo(() => {
    const ticks: number[] = [];
    const count = 6;
    const step = (maxSpot - minSpot) / count;
    for (let i = 0; i <= count; i++) {
      ticks.push(minSpot + i * step);
    }
    return ticks;
  }, [minSpot, maxSpot]);

  const activePoint = hoverIndex !== null && points[hoverIndex] ? points[hoverIndex] : null;

  return (
    <div className="relative w-full overflow-hidden select-none bg-[#0e1420] border border-[#1e293b] rounded-md p-2">
      {/* Legend & Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-2 pb-2 text-xs font-mono border-b border-[#1e293b]/70">
        <div className="flex items-center gap-4 text-slate-300">
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-0.5 bg-cyan-400 inline-block"></span>
            <span className="text-slate-200 font-semibold">Expiry Payoff (T=0)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-0.5 bg-amber-400 border-dashed inline-block border-t-2 border-amber-400"></span>
            <span className="text-slate-300">Theoretical (Today)</span>
          </div>
          {showHalfHorizon && (
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-0.5 bg-indigo-400 opacity-80 inline-block"></span>
              <span className="text-slate-400">Mid-Horizon (T/2)</span>
            </div>
          )}
          {showBenchmark && (
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-0.5 bg-slate-500 opacity-60 inline-block"></span>
              <span className="text-slate-400">Short Forward Benchmark</span>
            </div>
          )}
        </div>

        {/* Spot Indicator */}
        <div className="flex items-center gap-3 text-slate-400">
          <span>Ref Spot: <span className="font-semibold text-slate-100">${underlyingSpot.toFixed(2)}</span></span>
          {breakEvens.length > 0 && (
            <span>
              Break-Even: <span className="text-amber-400 font-semibold">${breakEvens[0].price.toFixed(2)}</span>
            </span>
          )}
        </div>
      </div>

      {/* SVG Canvas */}
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto cursor-crosshair"
        onMouseLeave={() => setHoverIndex(null)}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const mouseX = ((e.clientX - rect.left) / rect.width) * width;
          const chartX = mouseX - padding.left;
          const ratio = Math.max(0, Math.min(1, chartX / chartWidth));
          const index = Math.round(ratio * (points.length - 1));
          setHoverIndex(index);
        }}
      >
        <defs>
          <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
          </linearGradient>
          <linearGradient id="lossGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="0.0" />
            <stop offset="100%" stopColor="#ef4444" stopOpacity="0.25" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {yTicks.map((tick, i) => {
          const y = getY(tick);
          return (
            <g key={`ytick-${i}`}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="2,3"
              />
              <text
                x={padding.left - 8}
                y={y + 4}
                textAnchor="end"
                className="text-[10px] fill-slate-400 font-mono"
              >
                {tick >= 0 ? `+$${tick.toFixed(0)}` : `-$${Math.abs(tick).toFixed(0)}`}
              </text>
            </g>
          );
        })}

        {xTicks.map((tick, i) => {
          const x = getX(tick);
          return (
            <g key={`xtick-${i}`}>
              <line
                x1={x}
                y1={padding.top}
                x2={x}
                y2={height - padding.bottom}
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="2,3"
              />
              <text
                x={x}
                y={height - padding.bottom + 16}
                textAnchor="middle"
                className="text-[10px] fill-slate-400 font-mono"
              >
                ${tick.toFixed(1)}
              </text>
            </g>
          );
        })}

        {/* Zero P&L reference line */}
        <line
          x1={padding.left}
          y1={zeroY}
          x2={width - padding.right}
          y2={zeroY}
          stroke="#475569"
          strokeWidth="1.5"
        />
        <text
          x={width - padding.right + 6}
          y={zeroY + 3}
          textAnchor="start"
          className="text-[9px] fill-slate-400 font-mono font-semibold"
        >
          $0.00
        </text>

        {/* Current Underlying Spot Price line */}
        <line
          x1={currentSpotX}
          y1={padding.top}
          x2={currentSpotX}
          y2={height - padding.bottom}
          stroke="#64748b"
          strokeWidth="1.5"
          strokeDasharray="4,4"
        />
        <text
          x={currentSpotX}
          y={padding.top - 8}
          textAnchor="middle"
          className="text-[10px] fill-slate-300 font-mono font-semibold"
        >
          Spot ${underlyingSpot.toFixed(2)}
        </text>

        {/* Break-Even Vertical Markers */}
        {breakEvens.map((be, idx) => {
          const beX = getX(be.price);
          return (
            <g key={`be-${idx}`}>
              <line
                x1={beX}
                y1={padding.top}
                x2={beX}
                y2={height - padding.bottom}
                stroke="#f59e0b"
                strokeWidth="1"
                strokeDasharray="3,3"
              />
              <circle cx={beX} cy={zeroY} r="3.5" fill="#f59e0b" />
              <text
                x={beX}
                y={zeroY - 8}
                textAnchor="middle"
                className="text-[9px] fill-amber-300 font-mono font-bold"
              >
                BE ${be.price.toFixed(2)}
              </text>
            </g>
          );
        })}

        {/* Short Forward Benchmark curve */}
        {showBenchmark && (
          <path
            d={benchmarkPath}
            fill="none"
            stroke="#64748b"
            strokeWidth="1.5"
            strokeDasharray="3,4"
            opacity="0.7"
          />
        )}

        {/* Vol Shift Curves */}
        {showVolShifts && (
          <>
            <path
              d={volUpPath}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="1"
              strokeDasharray="2,3"
              opacity="0.45"
            />
            <path
              d={volDownPath}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="1"
              strokeDasharray="2,3"
              opacity="0.45"
            />
          </>
        )}

        {/* Mid-Horizon (T/2) */}
        {showHalfHorizon && (
          <path
            d={halfHorizonPath}
            fill="none"
            stroke="#818cf8"
            strokeWidth="1.5"
            opacity="0.8"
          />
        )}

        {/* Current Theoretical Curve (T) */}
        <path
          d={theoreticalPath}
          fill="none"
          stroke="#f59e0b"
          strokeWidth="2"
          strokeDasharray="6,4"
        />

        {/* Expiry Payoff (T=0) Solid Primary Line */}
        <path
          d={expiryPath}
          fill="none"
          stroke="#22d3ee"
          strokeWidth="2.5"
        />

        {/* Active Hover Crosshair & Data Indicator */}
        {activePoint && hoverIndex !== null && (
          <g>
            {/* Vertical crosshair */}
            <line
              x1={getX(activePoint.spot)}
              y1={padding.top}
              x2={getX(activePoint.spot)}
              y2={height - padding.bottom}
              stroke="#94a3b8"
              strokeWidth="1"
              strokeDasharray="2,2"
            />
            {/* Marker on Expiry Line */}
            <circle
              cx={getX(activePoint.spot)}
              cy={getY(activePoint.expiryPayoff)}
              r="4.5"
              fill="#22d3ee"
              stroke="#0e1420"
              strokeWidth="1.5"
            />
            {/* Marker on Theoretical Line */}
            <circle
              cx={getX(activePoint.spot)}
              cy={getY(activePoint.currentTheoreticalPnl)}
              r="4.5"
              fill="#f59e0b"
              stroke="#0e1420"
              strokeWidth="1.5"
            />
          </g>
        )}
      </svg>

      {/* Floating Readout Tooltip */}
      {activePoint && (
        <div className="mt-2 flex flex-wrap items-center justify-between gap-3 px-3 py-1.5 bg-[#141d2e] border border-[#233045] rounded text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Underlying:</span>
            <span className="font-semibold text-white">${activePoint.spot.toFixed(2)}</span>
            <span className={`text-[11px] ${activePoint.pctChange >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              ({activePoint.pctChange >= 0 ? '+' : ''}{activePoint.pctChange.toFixed(2)}%)
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div>
              <span className="text-slate-400 mr-1.5">Expiry P&L:</span>
              <span className={`font-semibold ${activePoint.expiryPayoff >= 0 ? 'text-cyan-400' : 'text-rose-400'}`}>
                {activePoint.expiryPayoff >= 0 ? '+' : '-'}${Math.abs(activePoint.expiryPayoff).toFixed(2)}
              </span>
            </div>

            <div>
              <span className="text-slate-400 mr-1.5">Theoretical P&L:</span>
              <span className={`font-semibold ${activePoint.currentTheoreticalPnl >= 0 ? 'text-amber-400' : 'text-rose-400'}`}>
                {activePoint.currentTheoreticalPnl >= 0 ? '+' : '-'}${Math.abs(activePoint.currentTheoreticalPnl).toFixed(2)}
              </span>
            </div>

            {showBenchmark && (
              <div>
                <span className="text-slate-400 mr-1.5">Short Forward:</span>
                <span className="text-slate-300">
                  {activePoint.forwardBenchmarkPnl >= 0 ? '+' : '-'}${Math.abs(activePoint.forwardBenchmarkPnl).toFixed(2)}
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
