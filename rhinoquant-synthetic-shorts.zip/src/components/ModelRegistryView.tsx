/**
 * RhinoQuant Synthetic Shorts - Model Registry & Immutable Audit Ledger Terminal
 * Regulatory Model Inventory, Known Limitations, Numerical Tolerances, and Append-Only Event Trail
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState } from 'react';
import {
  REGISTERED_QUANT_MODELS,
  ModelMetadata,
  AuditEventRecord,
} from '../quant/models-registry';
import { BookOpen, ShieldCheck, FileCheck, Download, CheckCircle2, AlertTriangle, Key } from 'lucide-react';

interface ModelRegistryViewProps {
  auditEvents: AuditEventRecord[];
}

export const ModelRegistryView: React.FC<ModelRegistryViewProps> = ({ auditEvents }) => {
  const [selectedModelId, setSelectedModelId] = useState<string>(REGISTERED_QUANT_MODELS[0].id);

  const selectedModel =
    REGISTERED_QUANT_MODELS.find((m) => m.id === selectedModelId) ?? REGISTERED_QUANT_MODELS[0];

  const handleExportAuditLog = () => {
    const jsonStr = JSON.stringify(auditEvents, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rhinoquant-audit-ledger-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Models Carousel */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {REGISTERED_QUANT_MODELS.map((mod) => {
          const isSelected = mod.id === selectedModelId;
          return (
            <button
              key={mod.id}
              onClick={() => setSelectedModelId(mod.id)}
              className={`p-3 rounded-lg border text-left transition-all ${
                isSelected
                  ? 'bg-cyan-950/70 border-cyan-500 shadow-xs'
                  : 'bg-[#0e1420] border-[#1e293b] hover:border-[#334155]'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="font-bold text-slate-100 truncate">{mod.id}</span>
                <span className="text-[10px] text-cyan-400 font-bold">{mod.category}</span>
              </div>
              <div className="text-[11px] text-slate-300 font-sans mt-1 line-clamp-1">
                {mod.name}
              </div>
              <div className="text-[10px] text-emerald-400 mt-1 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>{mod.governanceStatus.replace(/_/g, ' ')}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Model Specification & Governance Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Mathematical Specification */}
        <div className="lg:col-span-7 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b] flex justify-between items-center">
            <div>
              <h4 className="font-bold uppercase tracking-wider text-slate-200">
                Model Specification & Formulation
              </h4>
              <p className="text-[11px] text-slate-400">{selectedModel.name} ({selectedModel.version})</p>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800">
              {selectedModel.governanceStatus}
            </span>
          </div>

          <div className="space-y-2">
            <div className="p-2.5 bg-[#121927] border border-[#1e293b] rounded space-y-1">
              <span className="text-slate-400 font-bold uppercase text-[10px]">Mathematical Basis:</span>
              <p className="text-cyan-300 font-mono text-[11px] leading-relaxed">
                {selectedModel.mathematicalBasis}
              </p>
            </div>

            <div>
              <span className="text-slate-400 font-bold uppercase text-[10px]">Key Economic & Pricing Assumptions:</span>
              <ul className="list-disc list-inside mt-1 space-y-1 text-slate-300 text-[11px]">
                {selectedModel.keyAssumptions.map((assump, i) => (
                  <li key={`assump-${i}`}>{assump}</li>
                ))}
              </ul>
            </div>

            <div className="pt-1">
              <span className="text-slate-400 font-bold uppercase text-[10px]">Numerical Constraints & Tolerances:</span>
              <p className="text-slate-300 text-[11px] mt-0.5">{selectedModel.numericalLimits}</p>
            </div>

            <div className="pt-1">
              <span className="text-slate-400 font-bold uppercase text-[10px]">Independent Validation Sign-off:</span>
              <p className="text-slate-300 text-[11px] mt-0.5">
                {selectedModel.validatedBy} · Verified {selectedModel.lastValidationDate}
              </p>
            </div>
          </div>
        </div>

        {/* Known Regulatory & Mathematical Limitations */}
        <div className="lg:col-span-5 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg space-y-3">
          <div className="pb-2 border-b border-[#1e293b]">
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Known Limitations & Boundary Alerts
            </h4>
            <p className="text-[11px] text-slate-400">
              Mandatory Rule #14: Report known limitations honestly
            </p>
          </div>

          <div className="space-y-2">
            {selectedModel.knownLimitations.map((limit, idx) => (
              <div
                key={`limit-${idx}`}
                className="p-2.5 bg-[#141d2e] border border-amber-900/50 rounded flex items-start gap-2 text-slate-300 text-[11px]"
              >
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{limit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Append-Only Immutable Audit Log */}
      <div className="bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg space-y-2.5">
        <div className="pb-2 border-b border-[#1e293b] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-cyan-400" />
            <h4 className="font-bold uppercase tracking-wider text-slate-200">
              Tamper-Evident Audit Ledger ({auditEvents.length} Verified Events)
            </h4>
          </div>

          <button
            onClick={handleExportAuditLog}
            className="flex items-center gap-1.5 px-3 py-1 bg-[#1e293b] hover:bg-[#28384f] text-slate-200 rounded border border-[#334155] transition-colors text-xs"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export Audit Trail (JSON)</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-[#1e293b] text-left">
                <th className="py-1.5 px-2">Event ID</th>
                <th className="py-1.5 px-2">Timestamp</th>
                <th className="py-1.5 px-2">Action / Category</th>
                <th className="py-1.5 px-2">Operator</th>
                <th className="py-1.5 px-2">Details</th>
                <th className="py-1.5 px-2 text-right">Cryptographic Checksum</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/60">
              {auditEvents.slice(0, 15).map((evt) => (
                <tr key={evt.id} className="hover:bg-[#141d2e] transition-colors">
                  <td className="py-2 px-2 text-cyan-400 font-bold">{evt.id}</td>
                  <td className="py-2 px-2 text-slate-400">{evt.timestamp.replace('T', ' ').slice(0, 19)}</td>
                  <td className="py-2 px-2 text-slate-200 font-semibold">{evt.eventType.replace(/_/g, ' ')}</td>
                  <td className="py-2 px-2 text-slate-300">{evt.operator}</td>
                  <td className="py-2 px-2 text-slate-400 max-w-xs truncate">{evt.details}</td>
                  <td className="py-2 px-2 text-right text-slate-500 font-mono text-[10px]">
                    {evt.checksum}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
