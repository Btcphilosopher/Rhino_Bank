/**
 * RhinoQuant Synthetic Shorts - Options Analytics & Volatility Surface
 * Interactive Option Chains, Volatility Skew / Smile Visualizer, and Term Structure Analysis
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState, useMemo } from 'react';
import { UnderlyingAsset } from '../quant/instruments';
import { INSTITUTIONAL_INSTRUMENT_MASTER, generateOptionChain } from '../quant/market-data';

interface OptionsAnalyticsProps {
  onSelectOptionForLab?: (underlying: UnderlyingAsset, strike: number, optionType: 'call' | 'put', expiryDays: number) => void;
}

export const OptionsAnalytics: React.FC<OptionsAnalyticsProps> = ({ onSelectOptionForLab }) => {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(INSTITUTIONAL_INSTRUMENT_MASTER[0].id);

  const underlying = useMemo(() => {
    return INSTITUTIONAL_INSTRUMENT_MASTER.find((a) => a.id === selectedAssetId) ?? INSTITUTIONAL_INSTRUMENT_MASTER[0];
  }, [selectedAssetId]);

  const optionChains = useMemo(() => {
    return generateOptionChain(underlying);
  }, [underlying]);

  const [selectedExpiryIndex, setSelectedExpiryIndex] = useState<number>(2); // 45d default
  const activeChain = optionChains[selectedExpiryIndex] ?? optionChains[0];

  return (
    <div className="space-y-4">
      {/* Asset Header & Expiry Tenor Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0e1420] border border-[#1e293b] p-3.5 rounded-lg">
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-400 font-semibold uppercase">Underlying:</span>
          <div className="flex gap-1.5">
            {INSTITUTIONAL_INSTRUMENT_MASTER.map((asset) => (
              <button
                key={asset.id}
                onClick={() => setSelectedAssetId(asset.id)}
                className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors ${
                  asset.id === selectedAssetId
                    ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 font-bold'
                    : 'bg-[#141d2e] border-[#1e293b] text-slate-400 hover:text-slate-200'
                }`}
              >
                {asset.ticker} (${asset.spotPrice.toFixed(2)})
              </button>
            ))}
          </div>
        </div>

        {/* Expiry Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400 font-semibold uppercase">Expiry Tenor:</span>
          <div className="flex gap-1 bg-[#141d2e] p-1 rounded border border-[#1e293b]">
            {optionChains.map((chain, idx) => (
              <button
                key={chain.expiryDateStr}
                onClick={() => setSelectedExpiryIndex(idx)}
                className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                  idx === selectedExpiryIndex
                    ? 'bg-[#1e293b] text-cyan-400 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {chain.daysToExpiry}d ({chain.expiryDateStr.slice(5)})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Volatility Smile Visualizer & Summary Strip */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Volatility Smile Chart */}
        <div className="lg:col-span-8 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg">
          <div className="flex justify-between items-center pb-2 border-b border-[#1e293b]">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-mono">
                Implied Volatility Smile & Skew Curve ({activeChain.daysToExpiry}d Expiry)
              </h4>
              <p className="text-[11px] text-slate-400 font-mono">
                Put wing skew reflects market down-crash insurance premium
              </p>
            </div>
            <span className="text-xs font-mono text-cyan-400">ATM IV: {(underlying.impliedVol * 100).toFixed(1)}%</span>
          </div>

          {/* SVG Smile Curve */}
          <div className="mt-3">
            <svg viewBox="0 0 700 160" className="w-full h-40">
              {/* Axes and grid */}
              <line x1="40" y1="130" x2="680" y2="130" stroke="#334155" strokeWidth="1" />
              <line x1="40" y1="20" x2="40" y2="130" stroke="#334155" strokeWidth="1" />

              {/* Grid lines */}
              {[40, 70, 100].map((yVal, i) => (
                <line
                  key={`smile-grid-${i}`}
                  x1="40"
                  y1={yVal}
                  x2="680"
                  y2={yVal}
                  stroke="#1e293b"
                  strokeDasharray="2,3"
                />
              ))}

              {/* Plot points and path */}
              {(() => {
                const strikes = activeChain.strikes;
                const minK = strikes[0].strike;
                const maxK = strikes[strikes.length - 1].strike;
                const ivs = strikes.map((s) => s.callIV);
                const minIV = Math.min(...ivs) * 0.85;
                const maxIV = Math.max(...ivs) * 1.15;

                const getX = (k: number) => 40 + ((k - minK) / (maxK - minK)) * 640;
                const getY = (iv: number) => 130 - ((iv - minIV) / (maxIV - minIV)) * 105;

                const pathD = strikes.reduce((acc, s, idx) => {
                  const x = getX(s.strike);
                  const y = getY(s.callIV);
                  return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
                }, '');

                const atmX = getX(underlying.spotPrice);

                return (
                  <g>
                    {/* Underlying spot line */}
                    <line x1={atmX} y1="20" x2={atmX} y2="130" stroke="#64748b" strokeDasharray="3,3" />
                    <text x={atmX} y="15" textAnchor="middle" className="text-[10px] fill-slate-300 font-mono">
                      ATM ${underlying.spotPrice.toFixed(1)}
                    </text>

                    {/* Skew curve */}
                    <path d={pathD} fill="none" stroke="#22d3ee" strokeWidth="2.5" />

                    {/* Dots on strikes */}
                    {strikes.map((s) => (
                      <circle
                        key={s.strike}
                        cx={getX(s.strike)}
                        cy={getY(s.callIV)}
                        r="3.5"
                        fill="#0e1420"
                        stroke="#22d3ee"
                        strokeWidth="2"
                      />
                    ))}
                  </g>
                );
              })()}
            </svg>
          </div>
        </div>

        {/* Market Data Provenance Card */}
        <div className="lg:col-span-4 bg-[#0e1420] border border-[#1e293b] p-4 rounded-lg font-mono text-xs space-y-2.5">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 pb-2 border-b border-[#1e293b]">
            Data Quality & Provenance
          </h4>

          <div className="space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">Exchange Venue:</span>
              <span className="text-slate-200">{underlying.exchange}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Feed Quality:</span>
              <span className="text-cyan-400 font-bold">{underlying.dataQuality.replace('_', ' ')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Multiplier:</span>
              <span className="text-slate-200">{underlying.multiplier}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Hard-To-Borrow:</span>
              <span className={underlying.hardToBorrow ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                {underlying.hardToBorrow ? 'YES (High Fee)' : 'NO (General Collateral)'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Borrow Rate p.a.:</span>
              <span className="text-slate-200">{(underlying.borrowRate * 100).toFixed(2)}%</span>
            </div>
          </div>

          <div className="p-2.5 bg-[#141d2e] border border-[#233045] rounded text-[11px] text-slate-400 mt-2">
            Click any Put or Call strike in the chain below to inspect or stage directly into the Synthetic Position Lab.
          </div>
        </div>
      </div>

      {/* Institutional Dual-Wing Option Chain Table */}
      <div className="bg-[#0e1420] border border-[#1e293b] rounded-lg p-3.5">
        <div className="pb-2.5 border-b border-[#1e293b] flex justify-between items-center text-xs font-mono">
          <span className="font-bold uppercase tracking-wider text-slate-300">
            Institutional Option Chain — {underlying.ticker} ({activeChain.expiryDateStr})
          </span>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-cyan-400 font-semibold">◀ CALLS (Left Wing)</span>
            <span className="text-amber-400 font-semibold">STRIKES (Center)</span>
            <span className="text-rose-400 font-semibold">PUTS (Right Wing) ▶</span>
          </div>
        </div>

        <div className="overflow-x-auto mt-2">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="text-slate-400 border-b border-[#1e293b] text-center">
                {/* Calls */}
                <th className="py-1 px-2 text-left">Call Delta</th>
                <th className="py-1 px-2 text-right">Call IV</th>
                <th className="py-1 px-2 text-right">Call Bid</th>
                <th className="py-1 px-2 text-right">Call Ask</th>

                {/* Strike */}
                <th className="py-1 px-4 bg-[#141d2e] text-slate-100 font-bold border-x border-[#1e293b]">
                  STRIKE
                </th>

                {/* Puts */}
                <th className="py-1 px-2 text-left">Put Bid</th>
                <th className="py-1 px-2 text-left">Put Ask</th>
                <th className="py-1 px-2 text-left">Put IV</th>
                <th className="py-1 px-2 text-right">Put Delta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/60">
              {activeChain.strikes.map((s) => {
                const isATM = Math.abs(s.strike - underlying.spotPrice) < 3.0;
                return (
                  <tr
                    key={s.strike}
                    className={`hover:bg-[#141d2e] transition-colors cursor-pointer ${
                      isATM ? 'bg-[#162033]/60' : ''
                    }`}
                    onClick={() => {
                      if (onSelectOptionForLab) {
                        onSelectOptionForLab(underlying, s.strike, 'put', activeChain.daysToExpiry);
                      }
                    }}
                  >
                    {/* Call wing */}
                    <td className="py-1.5 px-2 text-left text-slate-400">{s.callDelta.toFixed(3)}</td>
                    <td className="py-1.5 px-2 text-right text-slate-400">{(s.callIV * 100).toFixed(1)}%</td>
                    <td className="py-1.5 px-2 text-right text-slate-300 font-semibold">${s.callBid.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-cyan-300 font-bold">${s.callAsk.toFixed(2)}</td>

                    {/* Strike */}
                    <td
                      className={`py-1.5 px-4 text-center font-bold font-mono border-x border-[#1e293b] ${
                        isATM ? 'bg-cyan-950/80 text-cyan-300' : 'bg-[#141d2e] text-amber-300'
                      }`}
                    >
                      ${s.strike.toFixed(2)}
                      {isATM && <span className="text-[9px] text-cyan-400 ml-1">ATM</span>}
                    </td>

                    {/* Put wing */}
                    <td className="py-1.5 px-2 text-left text-rose-300 font-bold">${s.putBid.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-left text-slate-300 font-semibold">${s.putAsk.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-left text-slate-400">{(s.putIV * 100).toFixed(1)}%</td>
                    <td className="py-1.5 px-2 text-right text-slate-400">{s.putDelta.toFixed(3)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
