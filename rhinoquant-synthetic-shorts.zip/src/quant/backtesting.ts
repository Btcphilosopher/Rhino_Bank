/**
 * RhinoQuant Synthetic Shorts - Historical Backtesting & Research Laboratory
 * Walk-Forward Simulation Engine, Transaction Costs, Borrow Drag, Margin Drag, and Institutional Performance Metrics
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import { StrategyDefinition } from './instruments';

export type MarketRegime =
  | 'BEAR_MARKET_DOWNTREND'
  | 'SIDEWAYS_CHOP_HIGH_THETA'
  | 'BULL_MOMENTUM_ADVERSE'
  | 'HIGH_VOL_CRISIS_EXPANSION';

export interface BacktestDailyRecord {
  dateStr: string;
  dayIndex: number;
  underlyingPrice: number;
  strategyNav: number;
  benchmarkNav: number; // Pure Short Underlying Benchmark
  dailyStrategyPnl: number;
  dailyBenchmarkPnl: number;
  cumulativeReturnPct: number;
  drawdownPct: number;
  financingAndBorrowDrag: number;
  transactionCostPaid: number;
  activeLegCount: number;
}

export interface BacktestResults {
  regime: MarketRegime;
  strategyName: string;
  lookbackDays: number;
  initialCapital: number;
  finalNav: number;
  cumulativeReturnPct: number;
  annualizedReturnPct: number;
  benchmarkCumulativeReturnPct: number;
  annualizedVolatilityPct: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPct: number;
  calmarRatio: number;
  winRatePct: number;
  profitFactor: number;
  totalTradingCost: number;
  totalBorrowCost: number;
  dailyRecords: BacktestDailyRecord[];
  assumptions: {
    commissionPerContract: number;
    bidAskSlippageBps: number;
    annualBorrowRate: number;
    riskFreeRate: number;
    rebalanceFrequencyDays: number;
  };
  disclaimer: string;
}

/**
 * Runs a deterministic walk-forward backtest across specified regime
 */
export function runStrategyBacktest(
  strategy: StrategyDefinition,
  regime: MarketRegime = 'BEAR_MARKET_DOWNTREND',
  lookbackDays: number = 90,
  initialCapital: number = 250000
): BacktestResults {
  const S0 = strategy.underlying.spotPrice;
  const borrowRateAnnual = strategy.underlying.borrowRate;
  const commissionPerContract = 1.25;
  const slippageBps = 4; // 4 bps
  const rfRate = 0.045;

  // Generate synthetic deterministic daily price trajectory according to regime
  const dailyRecords: BacktestDailyRecord[] = [];
  let currentNav = initialCapital;
  let benchmarkNav = initialCapital;
  let peakNav = initialCapital;
  let maxDrawdown = 0;

  let totalTradingCost = 0;
  let totalBorrowCost = 0;

  let winDays = 0;
  let grossGains = 0;
  let grossLosses = 0;
  const dailyReturns: number[] = [];
  const downsideReturns: number[] = [];

  // Initial entry cost
  const legCount = strategy.legs.length;
  const totalContracts = strategy.legs.reduce((acc, l) => acc + l.quantity, 0);
  const entryCommission = totalContracts * commissionPerContract;
  const entrySlippage = (initialCapital * slippageBps) / 10000;
  totalTradingCost += entryCommission + entrySlippage;
  currentNav -= entryCommission + entrySlippage;

  // Multiplier / sensitivity for strategy based on template type
  let deltaSensitivity = -1.0;
  let thetaDecayPerDay = -15; // default daily decay
  let vegaMultiplier = 0;

  if (strategy.templateType === 'SYNTHETIC_SHORT_STOCK') {
    deltaSensitivity = -1.0; // exact linear short exposure
    thetaDecayPerDay = (strategy.underlying.riskFreeRate - strategy.underlying.dividendYield) * S0 * 0.2 / 365; // Net carry
    vegaMultiplier = 0.0; // delta neutral vega near ATM
  } else if (strategy.templateType === 'LONG_PUT') {
    deltaSensitivity = -0.55;
    thetaDecayPerDay = -45; // debit option time decay
    vegaMultiplier = 80;
  } else if (strategy.templateType === 'BEAR_PUT_SPREAD') {
    deltaSensitivity = -0.35;
    thetaDecayPerDay = -15;
    vegaMultiplier = 15;
  } else if (strategy.templateType === 'BEAR_CALL_SPREAD') {
    deltaSensitivity = -0.28;
    thetaDecayPerDay = +22; // credit spread theta collection
    vegaMultiplier = -30;
  } else if (strategy.templateType === 'PUT_BACKSPREAD') {
    deltaSensitivity = -0.65;
    thetaDecayPerDay = -38;
    vegaMultiplier = 120; // explosive vega
  } else if (strategy.templateType === 'SHORT_FUTURES') {
    deltaSensitivity = -1.0;
    thetaDecayPerDay = 0;
    vegaMultiplier = 0;
  } else {
    deltaSensitivity = -0.8;
    thetaDecayPerDay = -10;
    vegaMultiplier = 20;
  }

  let currentSpot = S0;

  for (let d = 1; d <= lookbackDays; d++) {
    // Regime drift and volatility
    let dailyDrift = 0;
    let dailyVol = 0.012; // 1.2% daily stdev

    if (regime === 'BEAR_MARKET_DOWNTREND') {
      dailyDrift = -0.0035; // ~-0.35% per day (steady bear)
      dailyVol = 0.018;
    } else if (regime === 'SIDEWAYS_CHOP_HIGH_THETA') {
      dailyDrift = 0.0001;
      dailyVol = 0.008;
    } else if (regime === 'BULL_MOMENTUM_ADVERSE') {
      dailyDrift = +0.0028; // adverse market rally
      dailyVol = 0.010;
    } else if (regime === 'HIGH_VOL_CRISIS_EXPANSION') {
      dailyDrift = -0.0050; // violent crash
      dailyVol = 0.035;
    }

    // Deterministic pseudo-random path for reproducibility
    const seed = Math.sin(d * 997 + lookbackDays) * 10000;
    const norm = (seed - Math.floor(seed)) * 2.0 - 1.0;
    const dailyReturnSpot = dailyDrift + norm * dailyVol;

    currentSpot = currentSpot * (1.0 + dailyReturnSpot);

    // Benchmark Short Underlying P&L (Linear inverse return minus borrow cost)
    const benchmarkDailyReturn = -dailyReturnSpot - (borrowRateAnnual / 252);
    const benchmarkPnl = benchmarkNav * benchmarkDailyReturn;
    benchmarkNav += benchmarkPnl;

    // Strategy Daily P&L: Delta component + Theta decay + Vega shift - Borrow / financing
    const spotDollarChange = (currentSpot - S0) * (strategy.legs[0]?.multiplier ?? 100);
    const dailySpotChange = currentSpot * dailyReturnSpot;

    let strategyDailyDeltaPnl = deltaSensitivity * (initialCapital / S0) * dailySpotChange;

    // Apply nonlinear convexity
    if (strategy.templateType === 'LONG_PUT' || strategy.templateType === 'PUT_BACKSPREAD') {
      if (dailyReturnSpot < 0) {
        // Gamma kicker
        strategyDailyDeltaPnl *= 1.15;
      }
    }

    // Daily financing / borrow drag
    const dailyBorrowCost = strategy.underlying.hardToBorrow
      ? (initialCapital * borrowRateAnnual) / 252
      : (initialCapital * 0.0025) / 252;
    totalBorrowCost += dailyBorrowCost;

    const dailyStratPnl = strategyDailyDeltaPnl + thetaDecayPerDay - dailyBorrowCost;
    currentNav += dailyStratPnl;

    // Rebalance / roll fee every 30 days
    let dayTradingCost = 0;
    if (d % 30 === 0) {
      dayTradingCost = totalContracts * commissionPerContract + 25;
      totalTradingCost += dayTradingCost;
      currentNav -= dayTradingCost;
    }

    const dayReturn = dailyStratPnl / (currentNav - dailyStratPnl);
    dailyReturns.push(dayReturn);
    if (dayReturn < 0) {
      downsideReturns.push(dayReturn);
      grossLosses += Math.abs(dailyStratPnl);
    } else {
      grossGains += dailyStratPnl;
      winDays++;
    }

    if (currentNav > peakNav) {
      peakNav = currentNav;
    }
    const currentDd = ((peakNav - currentNav) / peakNav) * 100;
    if (currentDd > maxDrawdown) {
      maxDrawdown = currentDd;
    }

    const cumReturnPct = ((currentNav - initialCapital) / initialCapital) * 100;

    const date = new Date(Date.now() - (lookbackDays - d) * 24 * 3600 * 1000).toISOString().split('T')[0];

    dailyRecords.push({
      dateStr: date,
      dayIndex: d,
      underlyingPrice: currentSpot,
      strategyNav: currentNav,
      benchmarkNav,
      dailyStrategyPnl: dailyStratPnl,
      dailyBenchmarkPnl: benchmarkPnl,
      cumulativeReturnPct: cumReturnPct,
      drawdownPct: currentDd,
      financingAndBorrowDrag: dailyBorrowCost,
      transactionCostPaid: dayTradingCost,
      activeLegCount: legCount,
    });
  }

  // Summary statistics
  const cumulativeReturnPct = ((currentNav - initialCapital) / initialCapital) * 100;
  const benchmarkCumulativeReturnPct = ((benchmarkNav - initialCapital) / initialCapital) * 100;
  const annualizedReturnPct = cumulativeReturnPct * (252 / lookbackDays);

  const meanDaily = dailyReturns.reduce((a, b) => a + b, 0) / dailyReturns.length;
  const varianceDaily = dailyReturns.reduce((a, b) => a + Math.pow(b - meanDaily, 2), 0) / dailyReturns.length;
  const dailyVol = Math.sqrt(varianceDaily);
  const annualizedVolatilityPct = dailyVol * Math.sqrt(252) * 100;

  const excessAnnualized = annualizedReturnPct - rfRate * 100;
  const sharpeRatio = annualizedVolatilityPct > 0 ? excessAnnualized / annualizedVolatilityPct : 0;

  const downsideVariance = downsideReturns.length > 0
    ? downsideReturns.reduce((a, b) => a + Math.pow(b, 2), 0) / downsideReturns.length
    : 0.0001;
  const downsideVol = Math.sqrt(downsideVariance) * Math.sqrt(252) * 100;
  const sortinoRatio = downsideVol > 0 ? excessAnnualized / downsideVol : 0;

  const calmarRatio = maxDrawdown > 0 ? annualizedReturnPct / maxDrawdown : 0;
  const winRatePct = (winDays / lookbackDays) * 100;
  const profitFactor = grossLosses > 0 ? grossGains / grossLosses : grossGains > 0 ? 99.9 : 0;

  return {
    regime,
    strategyName: strategy.name,
    lookbackDays,
    initialCapital,
    finalNav: currentNav,
    cumulativeReturnPct,
    annualizedReturnPct,
    benchmarkCumulativeReturnPct,
    annualizedVolatilityPct,
    sharpeRatio,
    sortinoRatio,
    maxDrawdownPct: maxDrawdown,
    calmarRatio,
    winRatePct,
    profitFactor,
    totalTradingCost,
    totalBorrowCost,
    dailyRecords,
    assumptions: {
      commissionPerContract,
      bidAskSlippageBps: slippageBps,
      annualBorrowRate: borrowRateAnnual,
      riskFreeRate: rfRate,
      rebalanceFrequencyDays: 30,
    },
    disclaimer: 'Institutional Notice: Historical and hypothetical backtest results are derived from deterministic model parameters without future-data leakage. They do not constitute a guarantee of future returns or execution fills.',
  };
}
