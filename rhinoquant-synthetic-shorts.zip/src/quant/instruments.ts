/**
 * RhinoQuant Synthetic Shorts - Instrument Master & Strategy Definitions
 * Institutional Multi-Asset Class Models (Options, Futures, Forwards, Swaps, Fixed Income)
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import { calculateBSM, AnalyticalGreeks } from './math';

export type AssetClass = 'EQUITY' | 'INDEX' | 'COMMODITY' | 'FX' | 'RATES' | 'CREDIT';

export type InstrumentType =
  | 'VANILLA_OPTION'
  | 'EQUITY_STOCK'
  | 'EQUITY_FUTURE'
  | 'FX_FORWARD'
  | 'TOTAL_RETURN_SWAP'
  | 'BOND_FUTURE'
  | 'CREDIT_DEFAULT_SWAP';

export type PositionSide = 'BUY' | 'SELL';

export type SettlementMethod = 'PHYSICAL' | 'CASH';

export interface UnderlyingAsset {
  id: string;
  ticker: string;
  name: string;
  assetClass: AssetClass;
  currency: string;
  spotPrice: number;
  impliedVol: number; // e.g. 0.22 for 22%
  riskFreeRate: number; // e.g. 0.045
  dividendYield: number; // e.g. 0.015
  borrowRate: number; // e.g. 0.0035 (35 bps)
  hardToBorrow: boolean;
  multiplier: number;
  exchange: string;
  dataQuality: 'VERIFIED_LIVE' | 'CALIBRATED_SIMULATION' | 'HISTORICAL_REPLAY';
  lastUpdated: string;
}

export interface StrategyLeg {
  id: string;
  instrumentType: InstrumentType;
  side: PositionSide;
  quantity: number; // positive number of contracts/lots
  multiplier: number; // e.g. 100 for equity options, 1000 for crude oil
  strike?: number;
  timeToExpiryYears: number; // in years
  expiryDateStr: string; // YYYY-MM-DD
  optionType?: 'call' | 'put';
  exerciseStyle?: 'EUROPEAN' | 'AMERICAN';
  entryPremium: number; // per unit premium paid/received (absolute)
  currentTheoreticalPrice: number;
  currentBid: number;
  currentAsk: number;
  impliedVol: number;
  greeks: AnalyticalGreeks;
  contractNotional: number;
  description: string;
  isBorrowRequired: boolean;
}

export interface StrategyDefinition {
  id: string;
  name: string;
  templateType:
    | 'SYNTHETIC_SHORT_STOCK'
    | 'LONG_PUT'
    | 'BEAR_PUT_SPREAD'
    | 'BEAR_CALL_SPREAD'
    | 'PUT_BACKSPREAD'
    | 'SHORT_FUTURES'
    | 'SHORT_FX_FORWARD'
    | 'TOTAL_RETURN_SWAP_SHORT'
    | 'CREDIT_SPREAD_WIDENING'
    | 'BOND_DURATION_SHORT'
    | 'CUSTOM_MULTI_LEG';
  underlying: UnderlyingAsset;
  legs: StrategyLeg[];
  createdTimestamp: string;
  version: number;
  currency: string;
  deskOwner: string;
  settlementConvention: SettlementMethod;
  notes: string;
}

/**
 * Factory to create pristine strategy templates
 */
export function createStrategyTemplate(
  templateType: StrategyDefinition['templateType'],
  underlying: UnderlyingAsset
): StrategyDefinition {
  const S = underlying.spotPrice;
  const T = 45 / 365; // standard 45 days
  const expiryDate = new Date(Date.now() + 45 * 24 * 3600 * 1000).toISOString().split('T')[0];
  const iv = underlying.impliedVol;
  const r = underlying.riskFreeRate;
  const q = underlying.dividendYield;

  const nowStr = new Date().toISOString();

  switch (templateType) {
    case 'SYNTHETIC_SHORT_STOCK': {
      // Long Put + Short Call at matched ATM strike and expiry
      // ATM Strike rounded to nearest dollar or sensible interval
      const strike = Math.round(S);

      const putPricing = calculateBSM({
        spot: S,
        strike,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv,
        optionType: 'put',
      });

      const callPricing = calculateBSM({
        spot: S,
        strike,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv,
        optionType: 'call',
      });

      const leg1: StrategyLeg = {
        id: 'leg-put-1',
        instrumentType: 'VANILLA_OPTION',
        side: 'BUY',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'put',
        exerciseStyle: 'EUROPEAN',
        entryPremium: putPricing.price,
        currentTheoreticalPrice: putPricing.price,
        currentBid: Math.max(0, putPricing.price - 0.05),
        currentAsk: putPricing.price + 0.05,
        impliedVol: iv,
        greeks: putPricing.greeks,
        contractNotional: strike * underlying.multiplier,
        description: `Long Put K=${strike.toFixed(2)} (Expiry: ${expiryDate})`,
        isBorrowRequired: false,
      };

      const leg2: StrategyLeg = {
        id: 'leg-call-1',
        instrumentType: 'VANILLA_OPTION',
        side: 'SELL',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'call',
        exerciseStyle: 'EUROPEAN',
        entryPremium: callPricing.price,
        currentTheoreticalPrice: callPricing.price,
        currentBid: Math.max(0, callPricing.price - 0.05),
        currentAsk: callPricing.price + 0.05,
        impliedVol: iv,
        greeks: callPricing.greeks,
        contractNotional: strike * underlying.multiplier,
        description: `Short Call K=${strike.toFixed(2)} (Expiry: ${expiryDate})`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Synthetic Short Stock: ${underlying.ticker} (K=${strike})`,
        templateType: 'SYNTHETIC_SHORT_STOCK',
        underlying,
        legs: [leg1, leg2],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Institutional Derivatives',
        settlementConvention: 'CASH',
        notes: 'Classic synthetic short forward exposure via Long Put + Short Call at matched strike and maturity. Put-Call Parity relates this to Short Forward + Present Value of Strike.',
      };
    }

    case 'LONG_PUT': {
      const strike = Math.round(S * 0.98); // slightly OTM
      const putPricing = calculateBSM({
        spot: S,
        strike,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv,
        optionType: 'put',
      });

      const leg: StrategyLeg = {
        id: 'leg-put-single',
        instrumentType: 'VANILLA_OPTION',
        side: 'BUY',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'put',
        exerciseStyle: 'EUROPEAN',
        entryPremium: putPricing.price,
        currentTheoreticalPrice: putPricing.price,
        currentBid: Math.max(0, putPricing.price - 0.05),
        currentAsk: putPricing.price + 0.05,
        impliedVol: iv,
        greeks: putPricing.greeks,
        contractNotional: strike * underlying.multiplier,
        description: `Long Put K=${strike.toFixed(2)} (Defined Risk Bearish)`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Long Put: ${underlying.ticker} (K=${strike})`,
        templateType: 'LONG_PUT',
        underlying,
        legs: [leg],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Institutional Derivatives',
        settlementConvention: 'CASH',
        notes: 'Pure defined-risk bearish exposure. Maximum loss strictly bounded by premium paid.',
      };
    }

    case 'BEAR_PUT_SPREAD': {
      // Long higher strike put, short lower strike put
      const kHigh = Math.round(S * 1.0);
      const kLow = Math.round(S * 0.92);

      const highPut = calculateBSM({
        spot: S,
        strike: kHigh,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv,
        optionType: 'put',
      });

      const lowPut = calculateBSM({
        spot: S,
        strike: kLow,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv * 1.05, // skew
        optionType: 'put',
      });

      const leg1: StrategyLeg = {
        id: 'leg-bput-long',
        instrumentType: 'VANILLA_OPTION',
        side: 'BUY',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike: kHigh,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'put',
        exerciseStyle: 'EUROPEAN',
        entryPremium: highPut.price,
        currentTheoreticalPrice: highPut.price,
        currentBid: Math.max(0, highPut.price - 0.05),
        currentAsk: highPut.price + 0.05,
        impliedVol: iv,
        greeks: highPut.greeks,
        contractNotional: kHigh * underlying.multiplier,
        description: `Long Put K=${kHigh.toFixed(2)}`,
        isBorrowRequired: false,
      };

      const leg2: StrategyLeg = {
        id: 'leg-bput-short',
        instrumentType: 'VANILLA_OPTION',
        side: 'SELL',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike: kLow,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'put',
        exerciseStyle: 'EUROPEAN',
        entryPremium: lowPut.price,
        currentTheoreticalPrice: lowPut.price,
        currentBid: Math.max(0, lowPut.price - 0.05),
        currentAsk: lowPut.price + 0.05,
        impliedVol: iv * 1.05,
        greeks: lowPut.greeks,
        contractNotional: kLow * underlying.multiplier,
        description: `Short Put K=${kLow.toFixed(2)}`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Bear Put Debit Spread: ${underlying.ticker} (${kHigh}/${kLow})`,
        templateType: 'BEAR_PUT_SPREAD',
        underlying,
        legs: [leg1, leg2],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Institutional Derivatives',
        settlementConvention: 'CASH',
        notes: 'Vertical debit spread. Defined maximum gain (spread width - net debit) and defined maximum risk (net debit).',
      };
    }

    case 'BEAR_CALL_SPREAD': {
      // Short lower strike call, long higher strike call (Credit Spread)
      const kShort = Math.round(S * 1.02);
      const kLong = Math.round(S * 1.10);

      const shortCall = calculateBSM({
        spot: S,
        strike: kShort,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv,
        optionType: 'call',
      });

      const longCall = calculateBSM({
        spot: S,
        strike: kLong,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv * 0.98,
        optionType: 'call',
      });

      const leg1: StrategyLeg = {
        id: 'leg-bcall-short',
        instrumentType: 'VANILLA_OPTION',
        side: 'SELL',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike: kShort,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'call',
        exerciseStyle: 'EUROPEAN',
        entryPremium: shortCall.price,
        currentTheoreticalPrice: shortCall.price,
        currentBid: Math.max(0, shortCall.price - 0.05),
        currentAsk: shortCall.price + 0.05,
        impliedVol: iv,
        greeks: shortCall.greeks,
        contractNotional: kShort * underlying.multiplier,
        description: `Short Call K=${kShort.toFixed(2)}`,
        isBorrowRequired: false,
      };

      const leg2: StrategyLeg = {
        id: 'leg-bcall-long',
        instrumentType: 'VANILLA_OPTION',
        side: 'BUY',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike: kLong,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'call',
        exerciseStyle: 'EUROPEAN',
        entryPremium: longCall.price,
        currentTheoreticalPrice: longCall.price,
        currentBid: Math.max(0, longCall.price - 0.05),
        currentAsk: longCall.price + 0.05,
        impliedVol: iv * 0.98,
        greeks: longCall.greeks,
        contractNotional: kLong * underlying.multiplier,
        description: `Long Call K=${kLong.toFixed(2)} (Cap Risk)`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Bear Call Credit Spread: ${underlying.ticker} (${kShort}/${kLong})`,
        templateType: 'BEAR_CALL_SPREAD',
        underlying,
        legs: [leg1, leg2],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Institutional Derivatives',
        settlementConvention: 'CASH',
        notes: 'Vertical credit spread. Collects net credit upfront, profitable if underlying closes below short strike at expiry.',
      };
    }

    case 'PUT_BACKSPREAD': {
      // Short 1 ATM Put, Long 2 OTM Puts (Volatility Expansion + Deep Downside)
      const kATM = Math.round(S);
      const kOTM = Math.round(S * 0.92);

      const atmPut = calculateBSM({
        spot: S,
        strike: kATM,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv,
        optionType: 'put',
      });

      const otmPut = calculateBSM({
        spot: S,
        strike: kOTM,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: iv * 1.08,
        optionType: 'put',
      });

      const leg1: StrategyLeg = {
        id: 'leg-ratio-short',
        instrumentType: 'VANILLA_OPTION',
        side: 'SELL',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike: kATM,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'put',
        exerciseStyle: 'EUROPEAN',
        entryPremium: atmPut.price,
        currentTheoreticalPrice: atmPut.price,
        currentBid: Math.max(0, atmPut.price - 0.05),
        currentAsk: atmPut.price + 0.05,
        impliedVol: iv,
        greeks: atmPut.greeks,
        contractNotional: kATM * underlying.multiplier,
        description: `Short 1x Put K=${kATM.toFixed(2)} (Financing)`,
        isBorrowRequired: false,
      };

      const leg2: StrategyLeg = {
        id: 'leg-ratio-long',
        instrumentType: 'VANILLA_OPTION',
        side: 'BUY',
        quantity: 2,
        multiplier: underlying.multiplier,
        strike: kOTM,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        optionType: 'put',
        exerciseStyle: 'EUROPEAN',
        entryPremium: otmPut.price,
        currentTheoreticalPrice: otmPut.price,
        currentBid: Math.max(0, otmPut.price - 0.05),
        currentAsk: otmPut.price + 0.05,
        impliedVol: iv * 1.08,
        greeks: otmPut.greeks,
        contractNotional: kOTM * underlying.multiplier * 2,
        description: `Long 2x Put K=${kOTM.toFixed(2)} (Crash Convexity)`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Put Ratio Backspread 1x2: ${underlying.ticker}`,
        templateType: 'PUT_BACKSPREAD',
        underlying,
        legs: [leg1, leg2],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Institutional Derivatives',
        settlementConvention: 'CASH',
        notes: 'Net long vega and net long gamma on severe market downturns with reduced upfront debit.',
      };
    }

    case 'SHORT_FUTURES': {
      // Linear short future contract
      const basis = S * (r - q) * T;
      const futurePrice = S + basis;

      const leg: StrategyLeg = {
        id: 'leg-fut-short',
        instrumentType: 'EQUITY_FUTURE',
        side: 'SELL',
        quantity: 1,
        multiplier: underlying.multiplier,
        strike: futurePrice,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        entryPremium: 0,
        currentTheoreticalPrice: futurePrice,
        currentBid: futurePrice - 0.02,
        currentAsk: futurePrice + 0.02,
        impliedVol: 0,
        greeks: {
          delta: -1.0,
          gamma: 0,
          vegaRaw: 0,
          vega1pct: 0,
          thetaAnnual: -(r - q) * S,
          theta1Day: -((r - q) * S) / 365,
          rho1pct: -T * S * 0.01,
          dividendSens1pct: T * S * 0.01,
          vanna: 0,
          volga: 0,
          charm1Day: 0,
        },
        contractNotional: futurePrice * underlying.multiplier,
        description: `Short Future @ ${futurePrice.toFixed(2)} (Basis: ${basis.toFixed(2)})`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Short Futures: ${underlying.ticker}`,
        templateType: 'SHORT_FUTURES',
        underlying,
        legs: [leg],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Institutional Derivatives',
        settlementConvention: 'CASH',
        notes: 'Exchange-traded derivative with daily variation margin settlement and zero borrow dependency.',
      };
    }

    case 'SHORT_FX_FORWARD': {
      // Forward points model: F = S * (1 + r_d * T) / (1 + r_f * T)
      const rDomestic = 0.045; // USD
      const rForeign = 0.035; // EUR
      const fwdRate = S * Math.exp((rDomestic - rForeign) * T);

      const leg: StrategyLeg = {
        id: 'leg-fx-fwd',
        instrumentType: 'FX_FORWARD',
        side: 'SELL',
        quantity: 10,
        multiplier: 10000,
        strike: fwdRate,
        timeToExpiryYears: T,
        expiryDateStr: expiryDate,
        entryPremium: 0,
        currentTheoreticalPrice: fwdRate,
        currentBid: fwdRate - 0.0001,
        currentAsk: fwdRate + 0.0001,
        impliedVol: 0.08,
        greeks: {
          delta: -1.0,
          gamma: 0,
          vegaRaw: 0,
          vega1pct: 0,
          thetaAnnual: -(rDomestic - rForeign) * S,
          theta1Day: -((rDomestic - rForeign) * S) / 365,
          rho1pct: -T * S * 0.01,
          dividendSens1pct: 0,
          vanna: 0,
          volga: 0,
          charm1Day: 0,
        },
        contractNotional: fwdRate * 100000,
        description: `Short FX Forward @ ${fwdRate.toFixed(4)}`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Short FX Forward: ${underlying.ticker}`,
        templateType: 'SHORT_FX_FORWARD',
        underlying,
        legs: [leg],
        createdTimestamp: nowStr,
        version: 1,
        currency: 'USD',
        deskOwner: 'RhinoQuant Macro & FX',
        settlementConvention: 'PHYSICAL',
        notes: 'Bilateral OTC forward contract locking in forward currency exchange rate with carry decomposition.',
      };
    }

    case 'TOTAL_RETURN_SWAP_SHORT': {
      // Equity TRS: Short Receiver (pays equity return, receives SOFR + spread)
      const leg: StrategyLeg = {
        id: 'leg-trs-short',
        instrumentType: 'TOTAL_RETURN_SWAP',
        side: 'SELL',
        quantity: 1,
        multiplier: 1000,
        strike: S,
        timeToExpiryYears: 0.5,
        expiryDateStr: new Date(Date.now() + 180 * 24 * 3600 * 1000).toISOString().split('T')[0],
        entryPremium: 0,
        currentTheoreticalPrice: S,
        currentBid: S,
        currentAsk: S,
        impliedVol: 0,
        greeks: {
          delta: -1.0,
          gamma: 0,
          vegaRaw: 0,
          vega1pct: 0,
          thetaAnnual: 0.052 * S, // receives SOFR 5.2%
          theta1Day: (0.052 * S) / 365,
          rho1pct: 0.5 * S * 0.01,
          dividendSens1pct: -0.5 * S * 0.01,
          vanna: 0,
          volga: 0,
          charm1Day: 0,
        },
        contractNotional: S * 1000,
        description: `TRS Short Receiver: Pays ${underlying.ticker} Total Return, Receives SOFR+45bps`,
        isBorrowRequired: false,
      };

      return {
        id: `strat-${Date.now()}`,
        name: `Total Return Swap (Short Receiver): ${underlying.ticker}`,
        templateType: 'TOTAL_RETURN_SWAP_SHORT',
        underlying,
        legs: [leg],
        createdTimestamp: nowStr,
        version: 1,
        currency: underlying.currency,
        deskOwner: 'RhinoQuant Prime & Financing',
        settlementConvention: 'CASH',
        notes: 'Bilateral OTC total return swap. Eliminates operational physical short borrow constraints while transferring economic short return under ISDA/CSA.',
      };
    }

    default:
      return createStrategyTemplate('SYNTHETIC_SHORT_STOCK', underlying);
  }
}
