/**
 * RhinoQuant Synthetic Shorts - CLI Automated Quantitative Test Runner
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import { runQuantitativeValidationSuite } from './validation-suite';

console.log('================================================================');
console.log('RHINOQUANT SYNTHETIC SHORTS — MANDATORY QUANT VALIDATION SUITE');
console.log('RhinoBank Institutional Derivatives & Quantitative Risk Kernel');
console.log('================================================================\n');

const report = runQuantitativeValidationSuite();

console.log(`Timestamp: ${report.timestamp}`);
console.log(`Total Assertions Evaluated: ${report.totalTests}`);
console.log(`Passed: ${report.passedTests} | Failed: ${report.failedTests}`);
console.log(`Execution Duration: ${report.executionDurationMs.toFixed(3)} ms\n`);

report.assertions.forEach((a, idx) => {
  const statusMark = a.passed ? '✓ [PASS]' : '✗ [FAIL]';
  console.log(`${idx + 1}. ${statusMark} ${a.testId}: ${a.name}`);
  console.log(`   Expected:   ${a.expectedDescription}`);
  console.log(`   Calculated: ${a.actualDescription}`);
  console.log(`   Tolerance:  ${a.tolerance} (Difference: ${a.difference})`);
  if (a.notes) {
    console.log(`   Note:       ${a.notes}`);
  }
  console.log('');
});

if (report.allPassed) {
  console.log('================================================================');
  console.log('ALL MATHEMATICAL & NO-ARBITRAGE ASSERTIONS PASSED SUCCESSFULLY.');
  console.log('================================================================');
  process.exit(0);
} else {
  console.error('================================================================');
  console.error('CRITICAL: QUANTITATIVE ASSERTIONS FAILED.');
  console.error('================================================================');
  process.exit(1);
}
