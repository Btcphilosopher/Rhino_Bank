/**
 * RhinoQuant Synthetic Shorts - Institutional Market Data & Provenance Service
 * Multi-Asset Class Instrument Master, Option Chains, Volatility Surfaces, and Staleness Auditing
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import { UnderlyingAsset } from './instruments';
import { calculateBSM } from './math';

export interface OptionChainStrike {
  strike: number;
  callBid: number;
  callAsk: number;
  callMid: number;
  callIV: number;
  callDelta: number;
  callVolume: number;
  callOpenInterest: number;
  putBid: number;
  putAsk: number;
  putMid: number;
  putIV: number;
  putDelta: number;
  putVolume: number;
  putOpenInterest: number;
}

export interface OptionChainExpiry {
  expiryDateStr: string;
  daysToExpiry: number;
  timeToExpiryYears: number;
  strikes: OptionChainStrike[];
}

export const INSTITUTIONAL_INSTRUMENT_MASTER: UnderlyingAsset[] = [
  {
    id: 'SEC-SPY-EQUITY',
    ticker: 'SPY',
    name: 'SPDR S&P 500 ETF Trust',
    assetClass: 'INDEX',
    currency: 'USD',
    spotPrice: 512.40,
    impliedVol: 0.162,
    riskFreeRate: 0.045,
    dividendYield: 0.0135,
    borrowRate: 0.0025, // 25 bps borrow fee
    hardToBorrow: false,
    multiplier: 100,
    exchange: 'NYSE Arca / Cboe Options',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SEC-QQQ-EQUITY',
    ticker: 'QQQ',
    name: 'Invesco QQQ Trust (Nasdaq 100)',
    assetClass: 'INDEX',
    currency: 'USD',
    spotPrice: 446.80,
    impliedVol: 0.208,
    riskFreeRate: 0.045,
    dividendYield: 0.0062,
    borrowRate: 0.0030,
    hardToBorrow: false,
    multiplier: 100,
    exchange: 'Nasdaq / Cboe Options',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SEC-SMH-EQUITY',
    ticker: 'SMH',
    name: 'VanEck Semiconductor ETF',
    assetClass: 'EQUITY',
    currency: 'USD',
    spotPrice: 234.15,
    impliedVol: 0.325,
    riskFreeRate: 0.045,
    dividendYield: 0.0045,
    borrowRate: 0.0085,
    hardToBorrow: false,
    multiplier: 100,
    exchange: 'Nasdaq / Cboe Options',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SEC-HYPR-EQUITY',
    ticker: 'HYPR',
    name: 'HyperScale AI Cloud (High-Beta Target)',
    assetClass: 'EQUITY',
    currency: 'USD',
    spotPrice: 84.50,
    impliedVol: 0.584,
    riskFreeRate: 0.045,
    dividendYield: 0.0,
    borrowRate: 0.0850, // 8.5% hard-to-borrow borrow fee!
    hardToBorrow: true,
    multiplier: 100,
    exchange: 'NYSE / Cboe Options',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SEC-TLT-EQUITY',
    ticker: 'TLT',
    name: 'iShares 20+ Year Treasury Bond ETF',
    assetClass: 'RATES',
    currency: 'USD',
    spotPrice: 91.20,
    impliedVol: 0.145,
    riskFreeRate: 0.045,
    dividendYield: 0.0385,
    borrowRate: 0.0015,
    hardToBorrow: false,
    multiplier: 100,
    exchange: 'Nasdaq / Cboe Options',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SEC-CL-FUTURES',
    ticker: 'CL1!',
    name: 'WTI Crude Oil Front Futures',
    assetClass: 'COMMODITY',
    currency: 'USD',
    spotPrice: 78.60,
    impliedVol: 0.285,
    riskFreeRate: 0.045,
    dividendYield: 0.0,
    borrowRate: 0.0,
    hardToBorrow: false,
    multiplier: 1000,
    exchange: 'NYMEX / CME Globex',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SEC-EURUSD-FX',
    ticker: 'EURUSD',
    name: 'EUR / USD Institutional Spot & Forward',
    assetClass: 'FX',
    currency: 'USD',
    spotPrice: 1.0845,
    impliedVol: 0.078,
    riskFreeRate: 0.045,
    dividendYield: 0.035, // EUR deposit rate
    borrowRate: 0.0,
    hardToBorrow: false,
    multiplier: 100000,
    exchange: 'RhinoBank Prime FX ECN',
    dataQuality: 'CALIBRATED_SIMULATION',
    lastUpdated: new Date().toISOString(),
  },
];

/**
 * Generates calibrated options chains with volatility smiles and skew for an underlying
 */
export function generateOptionChain(underlying: UnderlyingAsset): OptionChainExpiry[] {
  const S = underlying.spotPrice;
  const baseIV = underlying.impliedVol;
  const r = underlying.riskFreeRate;
  const q = underlying.dividendYield;

  const tenors = [
    { days: 15, label: '15d' },
    { days: 30, label: '30d' },
    { days: 45, label: '45d' },
    { days: 60, label: '60d' },
    { days: 90, label: '90d' },
  ];

  // Round spot to sensible strike increment
  const strikeIncrement = S > 200 ? 5 : S > 50 ? 2.5 : 1;
  const atmRounded = Math.round(S / strikeIncrement) * strikeIncrement;

  // Generate strikes around ATM (-15% to +15%)
  const strikeCount = 13;
  const halfStrikes = Math.floor(strikeCount / 2);
  const strikeValues: number[] = [];

  for (let i = -halfStrikes; i <= halfStrikes; i++) {
    const k = Number((atmRounded + i * strikeIncrement).toFixed(2));
    if (k > 0) strikeValues.push(k);
  }

  const expiries: OptionChainExpiry[] = [];

  for (const tenor of tenors) {
    const T = tenor.days / 365.0;
    const expiryDate = new Date(Date.now() + tenor.days * 24 * 3600 * 1000).toISOString().split('T')[0];

    const chainStrikes: OptionChainStrike[] = [];

    for (const K of strikeValues) {
      // Calibrate volatility skew: Put wing higher IV, Call wing flatter
      const moneyness = Math.log(K / S);
      // Volatility skew model: IV(K) = baseIV - 0.25 * moneyness + 0.15 * moneyness^2
      const ivSkew = Math.max(0.05, baseIV - 0.25 * moneyness + 0.18 * moneyness * moneyness);

      const callBsm = calculateBSM({
        spot: S,
        strike: K,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: ivSkew,
        optionType: 'call',
      });

      const putBsm = calculateBSM({
        spot: S,
        strike: K,
        timeToExpiry: T,
        riskFreeRate: r,
        dividendYield: q,
        volatility: ivSkew,
        optionType: 'put',
      });

      const halfSpread = Math.max(0.02, Math.min(0.20, callBsm.price * 0.015));

      chainStrikes.push({
        strike: K,
        callBid: Math.max(0.01, Number((callBsm.price - halfSpread).toFixed(2))),
        callAsk: Number((callBsm.price + halfSpread).toFixed(2)),
        callMid: Number(callBsm.price.toFixed(2)),
        callIV: ivSkew,
        callDelta: Number(callBsm.greeks.delta.toFixed(3)),
        callVolume: Math.floor(1200 + Math.random() * 5000 * Math.exp(-Math.abs(moneyness) * 4)),
        callOpenInterest: Math.floor(4500 + Math.random() * 12000),

        putBid: Math.max(0.01, Number((putBsm.price - halfSpread).toFixed(2))),
        putAsk: Number((putBsm.price + halfSpread).toFixed(2)),
        putMid: Number(putBsm.price.toFixed(2)),
        putIV: ivSkew,
        putDelta: Number(putBsm.greeks.delta.toFixed(3)),
        putVolume: Math.floor(1500 + Math.random() * 6500 * Math.exp(-Math.abs(moneyness) * 3)),
        putOpenInterest: Math.floor(6200 + Math.random() * 18000),
      });
    }

    expiries.push({
      expiryDateStr: expiryDate,
      daysToExpiry: tenor.days,
      timeToExpiryYears: T,
      strikes: chainStrikes,
    });
  }

  return expiries;
}
