/**
 * RhinoQuant Synthetic Shorts - Counterparty & Collateral Risk Engine
 * ISDA / CSA Bilateral Netting, Potential Future Exposure (PFE), and Credit Valuation Exposure
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

export interface CounterpartyEntity {
  id: string;
  legalName: string;
  lei: string;
  jurisdiction: string;
  creditRating: 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'BBB+';
  csaAgreementType: '1994_ISDA_NY' | '1995_ISDA_ENGLISH' | '2016_VM_CSA';
  isNettingEnforceable: boolean;
  thresholdAmount: number;
  minimumTransferAmount: number;
  independentAmount: number; // Initial Margin
  collateralPostedByUs: number;
  collateralHeldFromCounterparty: number;
  eligibleCollateralCurrency: string[];
  wrongWayRiskStatus: 'LOW' | 'MODERATE' | 'ELEVATED';
  openPositionsCount: number;
  grossPositiveExposure: number; // MTM > 0
  grossNegativeExposure: number; // MTM < 0
  netCurrentExposure: number;
  potentialFutureExposure95: number; // 95% PFE 1-year
  settlementExposureLimit: number;
  limitUtilizationPct: number;
}

export const INSTITUTIONAL_COUNTERPARTIES: CounterpartyEntity[] = [
  {
    id: 'cp-rhinobank-prime',
    legalName: 'RhinoBank Prime Financing & Clearing Ltd',
    lei: '549300RHINOBANK001',
    jurisdiction: 'United Kingdom (English Law)',
    creditRating: 'AA',
    csaAgreementType: '2016_VM_CSA',
    isNettingEnforceable: true,
    thresholdAmount: 0,
    minimumTransferAmount: 50000,
    independentAmount: 350000,
    collateralPostedByUs: 520000,
    collateralHeldFromCounterparty: 0,
    eligibleCollateralCurrency: ['USD', 'EUR', 'GBP', 'US_TREASURIES'],
    wrongWayRiskStatus: 'LOW',
    openPositionsCount: 6,
    grossPositiveExposure: 340000,
    grossNegativeExposure: -185000,
    netCurrentExposure: 155000,
    potentialFutureExposure95: 220000,
    settlementExposureLimit: 2500000,
    limitUtilizationPct: 15.0,
  },
  {
    id: 'cp-goldman-prime',
    legalName: 'Goldman Sachs International PB',
    lei: 'W22LROWP2IHZNBB6K528',
    jurisdiction: 'United States (NY Law)',
    creditRating: 'A+',
    csaAgreementType: '2016_VM_CSA',
    isNettingEnforceable: true,
    thresholdAmount: 0,
    minimumTransferAmount: 50000,
    independentAmount: 500000,
    collateralPostedByUs: 680000,
    collateralHeldFromCounterparty: 0,
    eligibleCollateralCurrency: ['USD', 'US_TREASURIES'],
    wrongWayRiskStatus: 'LOW',
    openPositionsCount: 4,
    grossPositiveExposure: 410000,
    grossNegativeExposure: -290000,
    netCurrentExposure: 120000,
    potentialFutureExposure95: 310000,
    settlementExposureLimit: 3000000,
    limitUtilizationPct: 14.3,
  },
  {
    id: 'cp-morgan-stanley',
    legalName: 'Morgan Stanley & Co. International plc',
    lei: '4PQUHN3JPFGFNF3BB653',
    jurisdiction: 'United Kingdom (English Law)',
    creditRating: 'A+',
    csaAgreementType: '1995_ISDA_ENGLISH',
    isNettingEnforceable: true,
    thresholdAmount: 0,
    minimumTransferAmount: 50000,
    independentAmount: 250000,
    collateralPostedByUs: 310000,
    collateralHeldFromCounterparty: 0,
    eligibleCollateralCurrency: ['USD', 'EUR'],
    wrongWayRiskStatus: 'MODERATE',
    openPositionsCount: 3,
    grossPositiveExposure: 195000,
    grossNegativeExposure: -140000,
    netCurrentExposure: 55000,
    potentialFutureExposure95: 180000,
    settlementExposureLimit: 2000000,
    limitUtilizationPct: 11.75,
  },
  {
    id: 'cp-bnp-paribas',
    legalName: 'BNP Paribas Arbitrage SNC',
    lei: '6EWKUOFDV573JTXHJ444',
    jurisdiction: 'France (French / EMIR Law)',
    creditRating: 'AA-',
    csaAgreementType: '2016_VM_CSA',
    isNettingEnforceable: true,
    thresholdAmount: 0,
    minimumTransferAmount: 50000,
    independentAmount: 400000,
    collateralPostedByUs: 450000,
    collateralHeldFromCounterparty: 0,
    eligibleCollateralCurrency: ['EUR', 'USD', 'BUNDS'],
    wrongWayRiskStatus: 'LOW',
    openPositionsCount: 2,
    grossPositiveExposure: 125000,
    grossNegativeExposure: -80000,
    netCurrentExposure: 45000,
    potentialFutureExposure95: 130000,
    settlementExposureLimit: 1500000,
    limitUtilizationPct: 11.6,
  },
];

/**
 * Calculates bilateral netting, Net Current Exposure, and Margin Call deficit under CSA
 */
export function evaluateCounterpartyNetting(
  counterparty: CounterpartyEntity,
  incrementalMtM: number = 0
): {
  netMtM: number;
  netCurrentExposure: number;
  variationMarginCallRequired: number;
  callDirection: 'POST_COLLATERAL' | 'RECEIVE_COLLATERAL' | 'WITHIN_THRESHOLD';
} {
  const adjustedGrossPos = incrementalMtM > 0
    ? counterparty.grossPositiveExposure + incrementalMtM
    : counterparty.grossPositiveExposure;
  const adjustedGrossNeg = incrementalMtM < 0
    ? counterparty.grossNegativeExposure + incrementalMtM
    : counterparty.grossNegativeExposure;

  let netMtM = 0;
  if (counterparty.isNettingEnforceable) {
    netMtM = adjustedGrossPos + adjustedGrossNeg;
  } else {
    // Without legally enforceable netting, cannot offset positive and negative exposures
    netMtM = adjustedGrossPos;
  }

  const netCurrentExposure = Math.max(0, netMtM);

  // Variation margin call calculation against collateral held / posted
  const netCollateralHeldByUs = counterparty.collateralHeldFromCounterparty - counterparty.collateralPostedByUs;
  const exposureAfterCollateral = netMtM - netCollateralHeldByUs;

  let variationMarginCallRequired = 0;
  let callDirection: 'POST_COLLATERAL' | 'RECEIVE_COLLATERAL' | 'WITHIN_THRESHOLD' = 'WITHIN_THRESHOLD';

  if (exposureAfterCollateral > counterparty.thresholdAmount + counterparty.minimumTransferAmount) {
    variationMarginCallRequired = exposureAfterCollateral - counterparty.thresholdAmount;
    callDirection = 'RECEIVE_COLLATERAL';
  } else if (exposureAfterCollateral < -(counterparty.thresholdAmount + counterparty.minimumTransferAmount)) {
    variationMarginCallRequired = Math.abs(exposureAfterCollateral) - counterparty.thresholdAmount;
    callDirection = 'POST_COLLATERAL';
  }

  return {
    netMtM,
    netCurrentExposure,
    variationMarginCallRequired,
    callDirection,
  };
}
