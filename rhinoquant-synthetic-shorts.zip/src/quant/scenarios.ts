/**
 * RhinoQuant Synthetic Shorts - Scenario Engine & Stress Testing
 * Full-Revaluation Shock Grids, Joint Spot-Vol Heatmaps, Historical Crisis Replay, and Greek Decomposition
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import { StrategyDefinition } from './instruments';
import { evaluateLegTheoreticalPnl } from './payoff';

export interface ScenarioDefinition {
  id: string;
  name: string;
  category: 'HISTORICAL_CRISIS' | 'FACTOR_SHOCK' | 'DESK_CUSTOM';
  spotShockPct: number; // e.g. -0.20 for -20%
  volShockPctPoints: number; // e.g. +0.15 for +15% pts IV
  rateShockBps: number; // e.g. -100 for -100 bps
  borrowShockBps: number; // e.g. +500 for +500 bps borrow cost
  timeElapsedDays: number; // e.g. 5 days elapsed
  description: string;
}

export interface ScenarioResult {
  scenario: ScenarioDefinition;
  fullRevaluationPnl: number;
  deltaLinearApproximationPnl: number;
  deltaGammaApproximationPnl: number;
  unexplainedNonlinearResidual: number;
  factorDecomposition: {
    deltaContribution: number;
    gammaContribution: number;
    vegaContribution: number;
    thetaContribution: number;
    rhoContribution: number;
    borrowContribution: number;
    higherOrderCrossTerms: number;
  };
  marginAfterShock: number;
  isMarginDeficitTriggered: boolean;
}

export interface SpotVolMatrixCell {
  spotShockPct: number;
  volShockPctPoints: number;
  revaluedPnl: number;
  isPositive: boolean;
}

export interface SpotVolStressMatrix {
  spotLabels: number[]; // e.g. [-30, -20, -10, -5, 0, 5, 10, 20, 30]
  volLabels: number[]; // e.g. [-10, -5, 0, 5, 10, 20]
  cells: SpotVolMatrixCell[][];
  worstCaseCell: SpotVolMatrixCell;
  bestCaseCell: SpotVolMatrixCell;
}

export const PREDEFINED_STRESS_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'scen-lehman-2008',
    name: '2008 Lehman Liquidity Dislocation',
    category: 'HISTORICAL_CRISIS',
    spotShockPct: -0.25,
    volShockPctPoints: 0.25,
    rateShockBps: -75,
    borrowShockBps: 250,
    timeElapsedDays: 5,
    description: 'Systemic liquidity collapse, sharp equity plunge, credit freeze, and implied volatility spike.',
  },
  {
    id: 'scen-covid-2020',
    name: '2020 COVID Flash Crash',
    category: 'HISTORICAL_CRISIS',
    spotShockPct: -0.34,
    volShockPctPoints: 0.45,
    rateShockBps: -125,
    borrowShockBps: 150,
    timeElapsedDays: 10,
    description: 'Violent cascade sell-off with VIX surging to 82, emergency central bank rate cuts.',
  },
  {
    id: 'scen-squeeze-2021',
    name: '2021 Meme / Biotech Short Squeeze',
    category: 'HISTORICAL_CRISIS',
    spotShockPct: 0.85,
    volShockPctPoints: 0.60,
    rateShockBps: 0,
    borrowShockBps: 3500, // +35% annual borrow rate spike
    timeElapsedDays: 3,
    description: 'Violent multi-standard-deviation rally targeting short books, extreme borrow recalls and locate fee surge.',
  },
  {
    id: 'scen-rates-2022',
    name: '2022 Aggressive Central Bank Tightening',
    category: 'HISTORICAL_CRISIS',
    spotShockPct: -0.22,
    volShockPctPoints: 0.12,
    rateShockBps: 300,
    borrowShockBps: 75,
    timeElapsedDays: 30,
    description: 'Persistent duration unwind, multiple 75bps rate hikes, multiple compression.',
  },
  {
    id: 'scen-svb-2023',
    name: '2023 Regional Bank Liquidity Run',
    category: 'HISTORICAL_CRISIS',
    spotShockPct: -0.18,
    volShockPctPoints: 0.28,
    rateShockBps: -50,
    borrowShockBps: 400,
    timeElapsedDays: 4,
    description: 'Run on regional depository institutions, deposit flight, contagion discount.',
  },
];

/**
 * Executes full revaluation of all strategy legs under a defined scenario
 */
export function runScenarioRevaluation(
  strategies: StrategyDefinition[],
  scenario: ScenarioDefinition
): ScenarioResult {
  let fullRevalPnl = 0;
  let deltaLinearPnl = 0;
  let gammaPnl = 0;
  let vegaPnl = 0;
  let thetaPnl = 0;
  let rhoPnl = 0;
  let borrowPnl = 0;

  const dtYears = scenario.timeElapsedDays / 365.0;

  for (const strat of strategies) {
    const S0 = strat.underlying.spotPrice;
    const r0 = strat.underlying.riskFreeRate;
    const q0 = strat.underlying.dividendYield;
    const borrow0 = strat.underlying.borrowRate;

    // Stressed market inputs
    const S_shocked = S0 * (1.0 + scenario.spotShockPct);
    const r_shocked = r0 + scenario.rateShockBps / 10000;
    const borrow_shocked = borrow0 + scenario.borrowShockBps / 10000;
    const q_effective = q0 + borrow_shocked;

    const deltaS = S_shocked - S0;
    const deltaVolPct = scenario.volShockPctPoints * 100; // in percentage points

    for (const leg of strat.legs) {
      const sign = leg.side === 'BUY' ? 1 : -1;
      const mult = leg.multiplier * leg.quantity;
      const remainingT = Math.max(0.0001, leg.timeToExpiryYears - dtYears);

      // 1. Full non-linear revaluation
      const legPnl = evaluateLegTheoreticalPnl(
        leg,
        S_shocked,
        r_shocked,
        q_effective,
        remainingT,
        scenario.volShockPctPoints
      );
      fullRevalPnl += legPnl;

      // 2. Greek component breakdown
      const legDelta = sign * leg.greeks.delta * mult;
      const legGamma = sign * leg.greeks.gamma * mult;
      const legVega1pct = sign * leg.greeks.vega1pct * mult;
      const legTheta1Day = sign * leg.greeks.theta1Day * mult;
      const legRho1pct = sign * leg.greeks.rho1pct * mult;

      deltaLinearPnl += legDelta * deltaS;
      gammaPnl += 0.5 * legGamma * deltaS * deltaS;
      vegaPnl += legVega1pct * deltaVolPct;
      thetaPnl += legTheta1Day * scenario.timeElapsedDays;
      rhoPnl += legRho1pct * (scenario.rateShockBps / 100);

      // Borrow drag
      if (leg.isBorrowRequired || (leg.instrumentType === 'EQUITY_STOCK' && leg.side === 'SELL')) {
        const avgSpot = (S0 + S_shocked) / 2;
        const borrowCost = avgSpot * mult * borrow_shocked * dtYears;
        borrowPnl -= borrowCost;
      }
    }
  }

  const deltaGammaApprox = deltaLinearPnl + gammaPnl;
  const greekTotal = deltaLinearPnl + gammaPnl + vegaPnl + thetaPnl + rhoPnl + borrowPnl;
  const higherOrderResidual = fullRevalPnl - greekTotal;

  // Stressed margin requirement proxy
  const baseMargin = 150000;
  const stressedMargin = Math.max(50000, baseMargin * (1 + Math.abs(scenario.spotShockPct) * 1.5));
  const isMarginDeficit = fullRevalPnl < -200000;

  return {
    scenario,
    fullRevaluationPnl: fullRevalPnl,
    deltaLinearApproximationPnl: deltaLinearPnl,
    deltaGammaApproximationPnl: deltaGammaApprox,
    unexplainedNonlinearResidual: higherOrderResidual,
    factorDecomposition: {
      deltaContribution: deltaLinearPnl,
      gammaContribution: gammaPnl,
      vegaContribution: vegaPnl,
      thetaContribution: thetaPnl,
      rhoContribution: rhoPnl,
      borrowContribution: borrowPnl,
      higherOrderCrossTerms: higherOrderResidual,
    },
    marginAfterShock: stressedMargin,
    isMarginDeficitTriggered: isMarginDeficit,
  };
}

/**
 * Builds a 2D Spot vs Volatility Stress Heatmap Matrix
 */
export function generateSpotVolMatrix(strategies: StrategyDefinition[]): SpotVolStressMatrix {
  const spotShocks = [-30, -20, -15, -10, -5, 0, 5, 10, 15, 20, 30];
  const volShocks = [-10, -5, 0, 5, 10, 20];

  const cells: SpotVolMatrixCell[][] = [];
  let worstCell: SpotVolMatrixCell = { spotShockPct: 0, volShockPctPoints: 0, revaluedPnl: Infinity, isPositive: true };
  let bestCell: SpotVolMatrixCell = { spotShockPct: 0, volShockPctPoints: 0, revaluedPnl: -Infinity, isPositive: false };

  for (let r = 0; r < volShocks.length; r++) {
    const volShiftPts = volShocks[r];
    const row: SpotVolMatrixCell[] = [];

    for (let c = 0; c < spotShocks.length; c++) {
      const spotShiftPct = spotShocks[c];

      const scenario: ScenarioDefinition = {
        id: `grid-${spotShiftPct}-${volShiftPts}`,
        name: `Spot ${spotShiftPct}%, Vol ${volShiftPts}%`,
        category: 'FACTOR_SHOCK',
        spotShockPct: spotShiftPct / 100.0,
        volShockPctPoints: volShiftPts / 100.0,
        rateShockBps: 0,
        borrowShockBps: 0,
        timeElapsedDays: 0,
        description: 'Matrix cell full revaluation',
      };

      const result = runScenarioRevaluation(strategies, scenario);
      const cell: SpotVolMatrixCell = {
        spotShockPct: spotShiftPct,
        volShockPctPoints: volShiftPts,
        revaluedPnl: result.fullRevaluationPnl,
        isPositive: result.fullRevaluationPnl >= 0,
      };

      row.push(cell);

      if (cell.revaluedPnl < worstCell.revaluedPnl) {
        worstCell = cell;
      }
      if (cell.revaluedPnl > bestCell.revaluedPnl) {
        bestCell = cell;
      }
    }
    cells.push(row);
  }

  return {
    spotLabels: spotShocks,
    volLabels: volShocks,
    cells,
    worstCaseCell: worstCell,
    bestCaseCell: bestCell,
  };
}
