/**
 * RhinoQuant Synthetic Shorts - Deterministic Mathematical Core
 * Financial Mathematics, Pricing Models, Analytical Greeks, and Normal Distributions
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

/**
 * Standard Normal Probability Density Function: phi(x) = (1 / sqrt(2 * pi)) * exp(-x^2 / 2)
 */
export function stdNormalPdf(x: number): number {
  return (1.0 / Math.sqrt(2.0 * Math.PI)) * Math.exp(-0.5 * x * x);
}

/**
 * Cumulative Standard Normal Distribution Function: Phi(x)
 * Accurate numerical approximation (Hart / Abramowitz & Stegun polynomial, error < 7.5e-8)
 */
export function stdNormalCdf(x: number): number {
  if (isNaN(x)) return NaN;
  if (x > 37.0) return 1.0;
  if (x < -37.0) return 0.0;

  // Use symmetry
  const isNegative = x < 0;
  const absX = Math.abs(x);

  // Abramowitz & Stegun 26.2.17 polynomial approximation
  const p = 0.2316419;
  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;

  const t = 1.0 / (1.0 + p * absX);
  const poly = ((((b5 * t + b4) * t + b3) * t + b2) * t + b1) * t;
  const phi = stdNormalPdf(absX);
  const cdf = 1.0 - phi * poly;

  return isNegative ? 1.0 - cdf : cdf;
}

/**
 * Inverse Standard Normal Cumulative Distribution Function (Probit function)
 * Peter J. Acklam's rational approximation (precision ~ 1.15e-9)
 */
export function inverseStdNormalCdf(p: number): number {
  if (p <= 0.0) return -Infinity;
  if (p >= 1.0) return Infinity;

  // Coefficients in rational approximations
  const a = [
    -3.969683028665376e+01,
     2.209460984245205e+02,
    -2.759285104469687e+02,
     1.383577518672690e+02,
    -3.066479806614716e+01,
     2.506628277459239e+00
  ];

  const b = [
    -5.447609879822406e+01,
     1.615858368580409e+02,
    -1.556989798598866e+02,
     6.680131188771972e+01,
    -1.328068155288572e+01
  ];

  const c = [
    -7.784894002430293e-03,
    -3.223964580411365e-01,
    -2.400758277161838e+00,
    -2.549732539343734e+00,
     4.374664141464968e+00,
     2.938163982698783e+00
  ];

  const d = [
     7.784695709041462e-03,
     3.224671290700398e-01,
     2.445134137142996e+00,
     3.754408661907416e+00
  ];

  const pLow = 0.02425;
  const pHigh = 1.0 - pLow;

  if (p < pLow) {
    // Rational approximation for lower region
    const q = Math.sqrt(-2.0 * Math.log(p));
    return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) /
           ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1.0);
  } else if (p <= pHigh) {
    // Rational approximation for central region
    const q = p - 0.5;
    const r = q * q;
    return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q /
           (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1.0);
  } else {
    // Rational approximation for upper region
    const q = Math.sqrt(-2.0 * Math.log(1.0 - p));
    return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) /
            ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1.0);
  }
}

export interface BSMInputs {
  /** Underlying Spot Price S */
  spot: number;
  /** Strike Price K */
  strike: number;
  /** Time to Expiry T in years (e.g. 30/365 = 0.08219) */
  timeToExpiry: number;
  /** Risk-free discount rate r (annualized, continuous) e.g. 0.045 */
  riskFreeRate: number;
  /** Continuous dividend yield / borrow fee q e.g. 0.015 */
  dividendYield: number;
  /** Implied Volatility sigma (annualized decimal) e.g. 0.22 */
  volatility: number;
  /** Option Type */
  optionType: 'call' | 'put';
}

export interface AnalyticalGreeks {
  /** Delta: dV/dS */
  delta: number;
  /** Gamma: d^2V/dS^2 */
  gamma: number;
  /** Vega (raw): dV/dsigma (per 1.00 vol unit) */
  vegaRaw: number;
  /** Vega (1%): dV/dsigma * 0.01 (dollar change per 1 percentage point move in IV) */
  vega1pct: number;
  /** Theta (annualized): dV/dt */
  thetaAnnual: number;
  /** Theta (1-day calendar decay): dV/dt / 365 (in dollars/day) */
  theta1Day: number;
  /** Rho (1%): dV/dr * 0.01 (dollar change per 100 bps move in interest rate) */
  rho1pct: number;
  /** Dividend Sensitivity (1%): dV/dq * 0.01 */
  dividendSens1pct: number;
  /** Vanna: dDelta/dsigma = dVega/dS */
  vanna: number;
  /** Volga / Vomma: d^2V/dsigma^2 */
  volga: number;
  /** Charm: -dDelta/dt */
  charm1Day: number;
}

export interface PricingResult {
  /** Theoretical option price per share */
  price: number;
  /** Intrinsic value */
  intrinsicValue: number;
  /** Time value (extrinsic value) */
  timeValue: number;
  /** d1 in Black-Scholes formula */
  d1: number;
  /** d2 in Black-Scholes formula */
  d2: number;
  /** Greeks */
  greeks: AnalyticalGreeks;
  /** Forward price of underlying asset to expiry F = S * exp((r - q)*T) */
  forwardPrice: number;
  /** Put-Call parity counterpart theoretical price */
  parityCounterpartPrice: number;
  /** Model assumption note */
  model: string;
}

/**
 * Black-Scholes-Merton (1973) European Option Analytical Engine
 * Handles continuous dividend yield / cost-of-carry (Merton 1973 extension)
 */
export function calculateBSM(inputs: BSMInputs): PricingResult {
  const { spot, strike, timeToExpiry: T, riskFreeRate: r, dividendYield: q, volatility: sigma, optionType } = inputs;

  // Forward price under continuous cost of carry
  const forwardPrice = spot * Math.exp((r - q) * Math.max(0, T));

  // Boundary condition 1: Expiry reached (T <= 0)
  if (T <= 0.000001) {
    const intrinsic = optionType === 'call' 
      ? Math.max(0, spot - strike) 
      : Math.max(0, strike - spot);
    const parityCounterpart = optionType === 'call'
      ? Math.max(0, strike - spot)
      : Math.max(0, spot - strike);

    return {
      price: intrinsic,
      intrinsicValue: intrinsic,
      timeValue: 0,
      d1: spot > strike ? Infinity : (spot < strike ? -Infinity : 0),
      d2: spot > strike ? Infinity : (spot < strike ? -Infinity : 0),
      greeks: {
        delta: optionType === 'call' ? (spot > strike ? 1 : 0) : (spot < strike ? -1 : 0),
        gamma: 0,
        vegaRaw: 0,
        vega1pct: 0,
        thetaAnnual: 0,
        theta1Day: 0,
        rho1pct: 0,
        dividendSens1pct: 0,
        vanna: 0,
        volga: 0,
        charm1Day: 0,
      },
      forwardPrice: spot,
      parityCounterpartPrice: parityCounterpart,
      model: 'BSM-Merton-Boundary-T0',
    };
  }

  // Boundary condition 2: Zero volatility (deterministic payoff discounted)
  if (sigma <= 0.000001) {
    const discountedForward = forwardPrice * Math.exp(-r * T);
    const discountedStrike = strike * Math.exp(-r * T);
    const intrinsic = optionType === 'call' 
      ? Math.max(0, discountedForward - discountedStrike)
      : Math.max(0, discountedStrike - discountedForward);
    return {
      price: intrinsic,
      intrinsicValue: intrinsic,
      timeValue: 0,
      d1: 0,
      d2: 0,
      greeks: {
        delta: optionType === 'call' ? (forwardPrice > strike ? Math.exp(-q * T) : 0) : (forwardPrice < strike ? -Math.exp(-q * T) : 0),
        gamma: 0,
        vegaRaw: 0,
        vega1pct: 0,
        thetaAnnual: 0,
        theta1Day: 0,
        rho1pct: 0,
        dividendSens1pct: 0,
        vanna: 0,
        volga: 0,
        charm1Day: 0,
      },
      forwardPrice,
      parityCounterpartPrice: 0,
      model: 'BSM-Merton-Boundary-Vol0',
    };
  }

  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(spot / strike) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;

  const expNegQT = Math.exp(-q * T);
  const expNegRT = Math.exp(-r * T);

  const Nd1 = stdNormalCdf(d1);
  const Nd2 = stdNormalCdf(d2);
  const NNegD1 = stdNormalCdf(-d1);
  const NNegD2 = stdNormalCdf(-d2);
  const nd1 = stdNormalPdf(d1);

  let price: number;
  let delta: number;
  let parityCounterpartPrice: number;

  if (optionType === 'call') {
    price = spot * expNegQT * Nd1 - strike * expNegRT * Nd2;
    delta = expNegQT * Nd1;
    // Put-Call Parity: P = C - S*e^(-q*T) + K*e^(-r*T)
    parityCounterpartPrice = price - spot * expNegQT + strike * expNegRT;
  } else {
    price = strike * expNegRT * NNegD2 - spot * expNegQT * NNegD1;
    delta = -expNegQT * NNegD1;
    // Put-Call Parity: C = P + S*e^(-q*T) - K*e^(-r*T)
    parityCounterpartPrice = price + spot * expNegQT - strike * expNegRT;
  }

  const intrinsic = optionType === 'call'
    ? Math.max(0, spot - strike)
    : Math.max(0, strike - spot);
  const timeValue = Math.max(0, price - intrinsic);

  // Common Greeks
  const gamma = (expNegQT * nd1) / (spot * sigma * sqrtT);
  const vegaRaw = spot * expNegQT * nd1 * sqrtT;
  const vega1pct = vegaRaw * 0.01;

  // Theta formulas (annualized)
  let thetaAnnual: number;
  if (optionType === 'call') {
    const term1 = -(spot * expNegQT * nd1 * sigma) / (2.0 * sqrtT);
    const term2 = q * spot * expNegQT * Nd1;
    const term3 = -r * strike * expNegRT * Nd2;
    thetaAnnual = term1 + term2 + term3;
  } else {
    const term1 = -(spot * expNegQT * nd1 * sigma) / (2.0 * sqrtT);
    const term2 = -q * spot * expNegQT * NNegD1;
    const term3 = r * strike * expNegRT * NNegD2;
    thetaAnnual = term1 + term2 + term3;
  }
  const theta1Day = thetaAnnual / 365.0;

  // Rho (per 1% = 0.01 rate move)
  let rho1pct: number;
  if (optionType === 'call') {
    rho1pct = (strike * T * expNegRT * Nd2) * 0.01;
  } else {
    rho1pct = (-strike * T * expNegRT * NNegD2) * 0.01;
  }

  // Dividend sensitivity (per 1% = 0.01 move in q)
  let dividendSens1pct: number;
  if (optionType === 'call') {
    dividendSens1pct = (-T * spot * expNegQT * Nd1) * 0.01;
  } else {
    dividendSens1pct = (T * spot * expNegQT * NNegD1) * 0.01;
  }

  // Higher-order Cross-Greeks
  // Vanna = dDelta/dsigma = -exp(-q*T) * nd1 * (d2 / sigma)
  const vanna = -expNegQT * nd1 * (d2 / sigma);
  // Volga / Vomma = dVega/dsigma = vegaRaw * (d1 * d2) / sigma
  const volga = vegaRaw * (d1 * d2) / sigma;
  // Charm = -dDelta/dt
  const charmAnnual = q * expNegQT * (optionType === 'call' ? Nd1 : -NNegD1) -
    expNegQT * nd1 * (2 * (r - q) * T - d2 * sigma * sqrtT) / (2 * T * sigma * sqrtT);
  const charm1Day = charmAnnual / 365.0;

  return {
    price: Math.max(0, price),
    intrinsicValue: intrinsic,
    timeValue,
    d1,
    d2,
    greeks: {
      delta,
      gamma,
      vegaRaw,
      vega1pct,
      thetaAnnual,
      theta1Day,
      rho1pct,
      dividendSens1pct,
      vanna,
      volga,
      charm1Day,
    },
    forwardPrice,
    parityCounterpartPrice: Math.max(0, parityCounterpartPrice),
    model: 'BSM-Merton-1973',
  };
}

/**
 * Binomial Tree (Cox-Ross-Rubinstein) for European & American Style Options
 * Allows validation and pricing of American early-exercise premium on puts/calls
 */
export function calculateBinomialCRR(
  inputs: BSMInputs,
  steps: number = 100,
  isAmerican: boolean = false
): { price: number; earlyExercisePremium: number } {
  const { spot: S, strike: K, timeToExpiry: T, riskFreeRate: r, dividendYield: q, volatility: sigma, optionType } = inputs;
  if (T <= 0.0001) {
    const val = optionType === 'call' ? Math.max(0, S - K) : Math.max(0, K - S);
    return { price: val, earlyExercisePremium: 0 };
  }

  const dt = T / steps;
  const u = Math.exp(sigma * Math.sqrt(dt));
  const d = 1.0 / u;
  const a = Math.exp((r - q) * dt);
  const p = (a - d) / (u - d);
  const disc = Math.exp(-r * dt);

  // Asset prices at expiry step
  const prices: number[] = new Array(steps + 1);
  for (let i = 0; i <= steps; i++) {
    prices[i] = S * Math.pow(u, steps - i) * Math.pow(d, i);
  }

  // Option terminal payoffs
  const values: number[] = new Array(steps + 1);
  for (let i = 0; i <= steps; i++) {
    values[i] = optionType === 'call' ? Math.max(0, prices[i] - K) : Math.max(0, K - prices[i]);
  }

  // Backward induction
  for (let step = steps - 1; step >= 0; step--) {
    for (let i = 0; i <= step; i++) {
      const continuation = disc * (p * values[i] + (1.0 - p) * values[i + 1]);
      if (isAmerican) {
        const currentSpot = S * Math.pow(u, step - i) * Math.pow(d, i);
        const exercise = optionType === 'call' ? Math.max(0, currentSpot - K) : Math.max(0, K - currentSpot);
        values[i] = Math.max(continuation, exercise);
      } else {
        values[i] = continuation;
      }
    }
  }

  const price = values[0];
  let earlyExercisePremium = 0;
  if (isAmerican) {
    const europeanResult = calculateBSM(inputs);
    earlyExercisePremium = Math.max(0, price - europeanResult.price);
  }

  return { price, earlyExercisePremium };
}

/**
 * Implied Volatility Solver using Brent-Dekker / Newton-Raphson hybrid
 */
export function solveImpliedVolatility(
  targetPrice: number,
  inputs: Omit<BSMInputs, 'volatility'>,
  initialGuess: number = 0.25,
  maxIterations: number = 60,
  tolerance: number = 1e-6
): { impliedVol: number; converged: boolean; iterations: number } {
  let vol = Math.max(0.01, Math.min(3.0, initialGuess));

  for (let iter = 0; iter < maxIterations; iter++) {
    const res = calculateBSM({ ...inputs, volatility: vol });
    const diff = res.price - targetPrice;

    if (Math.abs(diff) < tolerance) {
      return { impliedVol: vol, converged: true, iterations: iter + 1 };
    }

    // Vega derivative
    const vega = res.greeks.vegaRaw;
    if (Math.abs(vega) < 1e-8) {
      break;
    }

    const step = diff / vega;
    vol = vol - step;

    // Constrain to positive domain
    if (vol <= 0.001) vol = 0.001;
    if (vol > 5.0) vol = 5.0;
  }

  return { impliedVol: vol, converged: false, iterations: maxIterations };
}
