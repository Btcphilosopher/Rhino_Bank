/**
 * RhinoQuant Synthetic Shorts - Payoff & Valuation Engine
 * Multi-horizon expiry payoffs, theoretical curves, break-even root-finding, and boundedness verification
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import { calculateBSM } from './math';
import { StrategyDefinition, StrategyLeg } from './instruments';

export interface PayoffPoint {
  spot: number;
  pctChange: number;
  expiryPayoff: number; // P&L at T=0
  currentTheoreticalPnl: number; // P&L today under current market IV
  halfHorizonPnl: number; // P&L at T/2
  volUpPnl: number; // P&L today if IV + 5%
  volDownPnl: number; // P&L today if IV - 5%
  forwardBenchmarkPnl: number; // P&L of pure short forward benchmark for reference
}

export interface BreakEvenResult {
  price: number;
  distancePct: number;
  type: 'LOWER' | 'UPPER' | 'EXACT';
}

export interface PayoffAnalysis {
  strategyId: string;
  underlyingSpot: number;
  netInitialPremium: number; // positive = debit paid, negative = credit received
  points: PayoffPoint[];
  breakEvens: BreakEvenResult[];
  maxProfit: {
    value: number | 'UNBOUNDED';
    atSpot?: number;
    isUnbounded: boolean;
    description: string;
  };
  maxLoss: {
    value: number | 'UNBOUNDED';
    atSpot?: number;
    isUnbounded: boolean;
    description: string;
  };
  putCallParityResidual: number;
  shortForwardEquivalenceNote: string;
}

/**
 * Calculates terminal payoff for a single leg at expiry price S_T
 */
export function evaluateLegExpiryPnl(leg: StrategyLeg, spotAtExpiry: number): number {
  const sign = leg.side === 'BUY' ? 1 : -1;
  const mult = leg.multiplier * leg.quantity;

  if (leg.instrumentType === 'VANILLA_OPTION') {
    const strike = leg.strike ?? spotAtExpiry;
    const terminalValue = leg.optionType === 'call'
      ? Math.max(0, spotAtExpiry - strike)
      : Math.max(0, strike - spotAtExpiry);

    // Net P&L = (Terminal Value - Entry Premium) * Sign * Multiplier
    return sign * (terminalValue - leg.entryPremium) * mult;
  }

  if (leg.instrumentType === 'EQUITY_STOCK') {
    // Short stock or long stock
    const entryPrice = leg.strike ?? leg.entryPremium;
    return sign * (spotAtExpiry - entryPrice) * mult;
  }

  if (leg.instrumentType === 'EQUITY_FUTURE' || leg.instrumentType === 'FX_FORWARD') {
    const strike = leg.strike ?? leg.entryPremium;
    return sign * (spotAtExpiry - strike) * mult;
  }

  if (leg.instrumentType === 'TOTAL_RETURN_SWAP') {
    const initialSpot = leg.strike ?? spotAtExpiry;
    // Short TRS pays spot return: sign is negative for short receiver
    return sign * (spotAtExpiry - initialSpot) * mult;
  }

  return 0;
}

/**
 * Calculates current theoretical P&L for a single leg under alternative spot and volatility
 */
export function evaluateLegTheoreticalPnl(
  leg: StrategyLeg,
  simSpot: number,
  r: number,
  q: number,
  timeToExpiryYears: number,
  volShift: number = 0
): number {
  const sign = leg.side === 'BUY' ? 1 : -1;
  const mult = leg.multiplier * leg.quantity;

  if (leg.instrumentType === 'VANILLA_OPTION') {
    const strike = leg.strike ?? simSpot;
    const effVol = Math.max(0.001, leg.impliedVol + volShift);

    const bsm = calculateBSM({
      spot: simSpot,
      strike,
      timeToExpiry: timeToExpiryYears,
      riskFreeRate: r,
      dividendYield: q,
      volatility: effVol,
      optionType: leg.optionType ?? 'put',
    });

    const currentVal = bsm.price;
    return sign * (currentVal - leg.entryPremium) * mult;
  }

  if (leg.instrumentType === 'EQUITY_FUTURE') {
    const strike = leg.strike ?? simSpot;
    return sign * (simSpot - strike) * mult;
  }

  if (leg.instrumentType === 'FX_FORWARD') {
    const strike = leg.strike ?? simSpot;
    return sign * (simSpot - strike) * mult;
  }

  if (leg.instrumentType === 'TOTAL_RETURN_SWAP') {
    const initialSpot = leg.strike ?? simSpot;
    return sign * (simSpot - initialSpot) * mult;
  }

  return evaluateLegExpiryPnl(leg, simSpot);
}

/**
 * Analyzes full multi-horizon payoff and valuation grid for a strategy
 */
export function analyzeStrategyPayoff(
  strategy: StrategyDefinition,
  gridPoints: number = 65,
  minRangePct: number = 0.5, // -50%
  maxRangePct: number = 1.5  // +50%
): PayoffAnalysis {
  const S0 = strategy.underlying.spotPrice;
  const r = strategy.underlying.riskFreeRate;
  const q = strategy.underlying.dividendYield;

  // Compute net initial premium
  let netInitialPremium = 0;
  for (const leg of strategy.legs) {
    const mult = leg.multiplier * leg.quantity;
    if (leg.side === 'BUY') {
      netInitialPremium += leg.entryPremium * mult; // Debit
    } else {
      netInitialPremium -= leg.entryPremium * mult; // Credit
    }
  }

  // Representative max expiry in years across legs
  const maxExpiry = Math.max(0.0001, ...strategy.legs.map((l) => l.timeToExpiryYears));
  const halfExpiry = maxExpiry * 0.5;

  const minSpot = S0 * minRangePct;
  const maxSpot = S0 * maxRangePct;
  const step = (maxSpot - minSpot) / (gridPoints - 1);

  const points: PayoffPoint[] = [];

  // Strike reference for benchmark
  const primaryStrike = strategy.legs.find((l) => l.strike !== undefined)?.strike ?? S0;
  const primaryMult = strategy.legs[0]?.multiplier ?? 100;

  for (let i = 0; i < gridPoints; i++) {
    const spot = minSpot + i * step;
    const pctChange = ((spot - S0) / S0) * 100;

    let expiryPnl = 0;
    let currentTheoPnl = 0;
    let halfPnl = 0;
    let volUpPnl = 0;
    let volDownPnl = 0;

    for (const leg of strategy.legs) {
      expiryPnl += evaluateLegExpiryPnl(leg, spot);
      currentTheoPnl += evaluateLegTheoreticalPnl(leg, spot, r, q, leg.timeToExpiryYears, 0);
      halfPnl += evaluateLegTheoreticalPnl(leg, spot, r, q, Math.max(0, leg.timeToExpiryYears * 0.5), 0);
      volUpPnl += evaluateLegTheoreticalPnl(leg, spot, r, q, leg.timeToExpiryYears, 0.05);
      volDownPnl += evaluateLegTheoreticalPnl(leg, spot, r, q, leg.timeToExpiryYears, -0.05);
    }

    // Benchmark: pure Short Forward P&L = (K - S_T) * mult
    const forwardBenchmarkPnl = (primaryStrike - spot) * primaryMult;

    points.push({
      spot,
      pctChange,
      expiryPayoff: expiryPnl,
      currentTheoreticalPnl: currentTheoPnl,
      halfHorizonPnl: halfPnl,
      volUpPnl,
      volDownPnl,
      forwardBenchmarkPnl,
    });
  }

  // Find break-even points on expiry payoff
  const breakEvens: BreakEvenResult[] = [];
  for (let i = 0; i < points.length - 1; i++) {
    const p1 = points[i];
    const p2 = points[i + 1];

    if ((p1.expiryPayoff <= 0 && p2.expiryPayoff >= 0) || (p1.expiryPayoff >= 0 && p2.expiryPayoff <= 0)) {
      // Linear interpolation root approximation
      const t = Math.abs(p1.expiryPayoff) / (Math.abs(p1.expiryPayoff) + Math.abs(p2.expiryPayoff) + 1e-9);
      const rootSpot = p1.spot + t * (p2.spot - p1.spot);
      breakEvens.push({
        price: rootSpot,
        distancePct: ((rootSpot - S0) / S0) * 100,
        type: rootSpot < S0 ? 'LOWER' : 'UPPER',
      });
    }
  }

  // Assess boundedness of Max Loss and Max Profit
  let maxProfitVal = -Infinity;
  let maxLossVal = Infinity;
  let maxProfitSpot = S0;
  let maxLossSpot = S0;

  for (const p of points) {
    if (p.expiryPayoff > maxProfitVal) {
      maxProfitVal = p.expiryPayoff;
      maxProfitSpot = p.spot;
    }
    if (p.expiryPayoff < maxLossVal) {
      maxLossVal = p.expiryPayoff;
      maxLossSpot = p.spot;
    }
  }

  // Check strategy template specific mathematical limits
  let isLossUnbounded = false;
  let isProfitUnbounded = false;
  let maxProfitDesc = '';
  let maxLossDesc = '';

  if (strategy.templateType === 'SYNTHETIC_SHORT_STOCK') {
    // Loss is mathematically unbounded as Spot -> +Infinity (short call has unlimited upside liability)
    isLossUnbounded = true;
    maxLossDesc = 'Unbounded (Unlimited liability as Spot price increases)';
    // Profit is capped at S=0 (spot cannot fall below 0)
    isProfitUnbounded = false;
    maxProfitDesc = `Max profit capped at $0 spot: $${Math.max(0, maxProfitVal).toFixed(2)}`;
  } else if (strategy.templateType === 'LONG_PUT') {
    isLossUnbounded = false;
    maxLossVal = -netInitialPremium;
    maxLossDesc = `Strictly bounded by net debit paid: $${Math.abs(netInitialPremium).toFixed(2)}`;
    isProfitUnbounded = false;
    maxProfitDesc = `Max profit capped at $0 spot: $${maxProfitVal.toFixed(2)}`;
  } else if (strategy.templateType === 'BEAR_PUT_SPREAD') {
    isLossUnbounded = false;
    maxLossVal = -Math.abs(netInitialPremium);
    maxLossDesc = `Strictly bounded by net debit paid: $${Math.abs(netInitialPremium).toFixed(2)}`;
    isProfitUnbounded = false;
    maxProfitDesc = `Bounded by spread width minus net debit: $${maxProfitVal.toFixed(2)}`;
  } else if (strategy.templateType === 'BEAR_CALL_SPREAD') {
    isLossUnbounded = false;
    maxProfitVal = Math.abs(netInitialPremium);
    maxProfitDesc = `Strictly bounded by net credit collected: $${Math.abs(netInitialPremium).toFixed(2)}`;
    isLossUnbounded = false;
    maxLossDesc = `Bounded by spread width minus net credit: $${Math.abs(maxLossVal).toFixed(2)}`;
  } else if (strategy.templateType === 'SHORT_FUTURES' || strategy.templateType === 'SHORT_FX_FORWARD') {
    isLossUnbounded = true;
    maxLossDesc = 'Unbounded linear upside liability';
    isProfitUnbounded = false;
    maxProfitDesc = `Capped at zero underlying value: $${maxProfitVal.toFixed(2)}`;
  } else {
    // Custom or backspread
    // If slope at upper boundary is negative, loss is unbounded
    const lastP = points[points.length - 1];
    const prevP = points[points.length - 2];
    if (lastP.expiryPayoff < prevP.expiryPayoff - 10) {
      isLossUnbounded = true;
      maxLossDesc = 'Potentially Unbounded at upper spot boundary';
    } else {
      maxLossDesc = `Approx. max loss in modeled range: $${Math.abs(maxLossVal).toFixed(2)}`;
    }
    maxProfitDesc = `Approx. max profit in modeled range: $${maxProfitVal.toFixed(2)}`;
  }

  // Put-Call parity residual on primary strike
  // C - P = S*e^(-q*T) - K*e^(-r*T)
  const T = strategy.legs[0]?.timeToExpiryYears ?? 45 / 365;
  const K = primaryStrike;
  const callPricing = calculateBSM({
    spot: S0,
    strike: K,
    timeToExpiry: T,
    riskFreeRate: r,
    dividendYield: q,
    volatility: strategy.underlying.impliedVol,
    optionType: 'call',
  });
  const putPricing = calculateBSM({
    spot: S0,
    strike: K,
    timeToExpiry: T,
    riskFreeRate: r,
    dividendYield: q,
    volatility: strategy.underlying.impliedVol,
    optionType: 'put',
  });

  const parityLeft = callPricing.price - putPricing.price;
  const parityRight = S0 * Math.exp(-q * T) - K * Math.exp(-r * T);
  const putCallParityResidual = Math.abs(parityLeft - parityRight);

  return {
    strategyId: strategy.id,
    underlyingSpot: S0,
    netInitialPremium,
    points,
    breakEvens,
    maxProfit: {
      value: isProfitUnbounded ? 'UNBOUNDED' : maxProfitVal,
      atSpot: maxProfitSpot,
      isUnbounded: isProfitUnbounded,
      description: maxProfitDesc,
    },
    maxLoss: {
      value: isLossUnbounded ? 'UNBOUNDED' : maxLossVal,
      atSpot: maxLossSpot,
      isUnbounded: isLossUnbounded,
      description: maxLossDesc,
    },
    putCallParityResidual,
    shortForwardEquivalenceNote: `Under European assumptions, Long Put(K) + Short Call(K) delivers payoff (K - S_T). Parity confirms C - P = S*e^(-qT) - K*e^(-rT). Residual = ${putCallParityResidual.toExponential(4)}.`,
  };
}
