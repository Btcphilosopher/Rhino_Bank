/**
 * RhinoQuant Synthetic Shorts - Institutional Quantitative Workstation
 * Gemini 3.8 Quantitative Engineering Application Entry Point
 * (C) RhinoBank Institutional Quantitative Derivatives
 */

import React, { useState } from 'react';
import { TopBar, ActiveTab } from './components/TopBar';
import { SyntheticPositionLab } from './components/SyntheticPositionLab';
import { OptionsAnalytics } from './components/OptionsAnalytics';
import { PortfolioRiskView } from './components/PortfolioRiskView';
import { ScenarioEngineView } from './components/ScenarioEngineView';
import { MarginCollateralView } from './components/MarginCollateralView';
import { BacktestingView } from './components/BacktestingView';
import { ExecutionView } from './components/ExecutionView';
import { CounterpartyView } from './components/CounterpartyView';
import { ValidationSuiteView } from './components/ValidationSuiteView';
import { ModelRegistryView } from './components/ModelRegistryView';

import { StrategyDefinition, createStrategyTemplate } from './quant/instruments';
import { INSTITUTIONAL_INSTRUMENT_MASTER } from './quant/market-data';
import { OrderProposal, createOrderProposal } from './quant/execution';
import { AuditEventRecord, recordAuditEvent } from './quant/models-registry';
import { runQuantitativeValidationSuite } from './quant/validation-suite';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('LAB');

  // Seed default strategy: Synthetic Short Stock on SPY
  const [activeStrategy, setActiveStrategy] = useState<StrategyDefinition>(() =>
    createStrategyTemplate('SYNTHETIC_SHORT_STOCK', INSTITUTIONAL_INSTRUMENT_MASTER[0])
  );

  // Saved versioned strategies
  const [savedStrategies, setSavedStrategies] = useState<StrategyDefinition[]>([
    createStrategyTemplate('SYNTHETIC_SHORT_STOCK', INSTITUTIONAL_INSTRUMENT_MASTER[0]),
    createStrategyTemplate('BEAR_PUT_SPREAD', INSTITUTIONAL_INSTRUMENT_MASTER[1]),
    createStrategyTemplate('LONG_PUT', INSTITUTIONAL_INSTRUMENT_MASTER[3]),
  ]);

  // Portfolio active strategies
  const [portfolioStrategies, setPortfolioStrategies] = useState<StrategyDefinition[]>([
    createStrategyTemplate('SYNTHETIC_SHORT_STOCK', INSTITUTIONAL_INSTRUMENT_MASTER[0]),
    createStrategyTemplate('BEAR_PUT_SPREAD', INSTITUTIONAL_INSTRUMENT_MASTER[1]),
    createStrategyTemplate('LONG_PUT', INSTITUTIONAL_INSTRUMENT_MASTER[3]),
  ]);

  // Order lifecycle queue
  const [orders, setOrders] = useState<OrderProposal[]>(() => [
    createOrderProposal(
      createStrategyTemplate('SYNTHETIC_SHORT_STOCK', INSTITUTIONAL_INSTRUMENT_MASTER[0]),
      'MULTI_LEG_NET_DEBIT',
      'PAPER_TRADING',
      0.85
    ),
  ]);

  // Audit Events Ledger
  const [auditEvents, setAuditEvents] = useState<AuditEventRecord[]>([
    recordAuditEvent('MODEL_VALIDATION_RUN', 'Quantitative Verification Suite', 'Section 23 analytical tests verified 8/8 proofs passed.'),
    recordAuditEvent('STRATEGY_CONSTRUCTED', 'Desk Trader A', 'Initial Synthetic Short Stock strategy created on SPY ATM Strike $512.'),
    recordAuditEvent('PRE_TRADE_CHECK_PASSED', 'Automated Risk Gateway', 'Pre-trade checks passed for SPY order proposal.'),
  ]);

  // Status banner notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSaveStrategy = (strategyToSave: StrategyDefinition) => {
    const versioned: StrategyDefinition = {
      ...strategyToSave,
      id: `strat-${Date.now()}`,
      version: strategyToSave.version + 1,
      createdTimestamp: new Date().toISOString(),
    };
    setSavedStrategies((prev) => [versioned, ...prev]);
    setActiveStrategy(versioned);

    const audit = recordAuditEvent(
      'STRATEGY_VERSIONED',
      'Desk Trader',
      `Saved Strategy version ${versioned.version}: ${versioned.name}`,
      versioned.id
    );
    setAuditEvents((prev) => [audit, ...prev]);
    showToast(`Strategy Saved: ${versioned.name} (v${versioned.version})`);
  };

  const handleAddToPortfolio = (strat: StrategyDefinition) => {
    setPortfolioStrategies((prev) => [...prev, strat]);
    const audit = recordAuditEvent(
      'STRATEGY_CONSTRUCTED',
      'Desk Trader',
      `Aggregated Strategy to Portfolio: ${strat.name}`,
      strat.id
    );
    setAuditEvents((prev) => [audit, ...prev]);
    showToast(`Added to Portfolio: ${strat.name}`);
  };

  const handleRemoveFromPortfolio = (strategyId: string) => {
    setPortfolioStrategies((prev) => prev.filter((s) => s.id !== strategyId));
    showToast(`Removed strategy ${strategyId.slice(-6)} from portfolio.`);
  };

  const handleProposeOrder = (strat: StrategyDefinition) => {
    setActiveStrategy(strat);
    setActiveTab('EXECUTION');
    showToast(`Order proposal generated for ${strat.underlying.ticker}. Switched to Execution Terminal.`);
  };

  const handleAddOrder = (order: OrderProposal) => {
    setOrders((prev) => [order, ...prev]);
    const audit = recordAuditEvent(
      'ORDER_TRANSMITTED',
      'Desk Trader',
      `Staged order ${order.id} for ${order.underlyingTicker} (${order.status})`,
      order.strategyId
    );
    setAuditEvents((prev) => [audit, ...prev]);
    showToast(`Order ${order.id} staged to order book (${order.status}).`);
  };

  const handleUpdateOrder = (updatedOrder: OrderProposal) => {
    setOrders((prev) => prev.map((o) => (o.id === updatedOrder.id ? updatedOrder : o)));
    const audit = recordAuditEvent(
      updatedOrder.status === 'FILLED' ? 'ORDER_FILLED' : 'ORDER_TRANSMITTED',
      'Paper Matching Engine',
      `Order ${updatedOrder.id} transitioned to ${updatedOrder.status}.`,
      updatedOrder.strategyId
    );
    setAuditEvents((prev) => [audit, ...prev]);
    showToast(`Order ${updatedOrder.id} status updated: ${updatedOrder.status}`);
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-[#e2e8f0] font-sans antialiased flex flex-col">
      {/* Top Bar Navigation */}
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onRunValidation={() => setActiveTab('VALIDATION_SUITE')}
      />

      {/* Main Analytical Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {activeTab === 'LAB' && (
          <SyntheticPositionLab
            onSaveStrategy={handleSaveStrategy}
            onAddToPortfolio={handleAddToPortfolio}
            onProposeOrder={handleProposeOrder}
          />
        )}

        {activeTab === 'OPTIONS_ANALYTICS' && (
          <OptionsAnalytics
            onSelectOptionForLab={(underlying, strike, optionType, expiryDays) => {
              const newStrat = createStrategyTemplate('LONG_PUT', underlying);
              setActiveStrategy(newStrat);
              setActiveTab('LAB');
              showToast(`Selected ${optionType.toUpperCase()} strike $${strike} on ${underlying.ticker}. Loaded into Lab.`);
            }}
          />
        )}

        {activeTab === 'PORTFOLIO_RISK' && (
          <PortfolioRiskView
            portfolioStrategies={portfolioStrategies}
            onRemoveStrategyFromPortfolio={handleRemoveFromPortfolio}
          />
        )}

        {activeTab === 'SCENARIO_ENGINE' && (
          <ScenarioEngineView strategies={portfolioStrategies} />
        )}

        {activeTab === 'MARGIN_COLLATERAL' && (
          <MarginCollateralView strategies={portfolioStrategies} />
        )}

        {activeTab === 'BACKTESTING' && (
          <BacktestingView strategy={activeStrategy} />
        )}

        {activeTab === 'EXECUTION' && (
          <ExecutionView
            currentStrategy={activeStrategy}
            orders={orders}
            onAddOrder={handleAddOrder}
            onUpdateOrder={handleUpdateOrder}
          />
        )}

        {activeTab === 'COUNTERPARTY' && <CounterpartyView />}

        {activeTab === 'MODEL_REGISTRY' && (
          <ModelRegistryView auditEvents={auditEvents} />
        )}

        {activeTab === 'VALIDATION_SUITE' && <ValidationSuiteView />}
      </main>

      {/* Floating Institutional Status Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#162033] border border-cyan-500/70 text-cyan-200 px-4 py-2.5 rounded shadow-xl font-mono text-xs flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
