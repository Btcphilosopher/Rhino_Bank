package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CredentialType {
    CONTACTLESS_CARD,
    MOBILE_WALLET,
    SMARTWATCH,
    WEARABLE,
    TRANSPORT_SMARTCARD,
    VIRTUAL_TRAVEL_CARD,
    TOKENISED_DEVICE,
    ACCOUNT_LINKED_CREDENTIAL
}

enum class CredentialStatus {
    ACTIVE,
    SUSPENDED,
    REVOKED,
    FLAGGED
}

@Entity(tableName = "credentials")
data class Credential(
    @PrimaryKey val credentialId: String,
    val tokenId: String,
    val deviceId: String,
    val credentialType: CredentialType,
    val status: CredentialStatus,
    val holderName: String,
    val lastFour: String,
    val createdAt: Long = System.currentTimeMillis(),
    val riskScore: Int = 0
)

enum class TransportMode {
    RAIL,
    UNDERGROUND,
    METRO,
    BUS,
    TRAM,
    FERRY
}

enum class TapDirection {
    ENTRY,
    EXIT,
    VALIDATION_ONLY
}

enum class NetworkState {
    ONLINE,
    DEGRADED,
    OFFLINE,
    RECOVERING
}

enum class TapResult {
    ACCEPTED,
    REJECTED,
    QUEUED_OFFLINE
}

@Entity(tableName = "tap_events")
data class TapEvent(
    @PrimaryKey val tapId: String,
    val credentialId: String,
    val readerId: String,
    val operatorId: String,
    val stationId: String,
    val stationName: String,
    val mode: TransportMode,
    val direction: TapDirection,
    val timestamp: Long = System.currentTimeMillis(),
    val networkState: NetworkState = NetworkState.ONLINE,
    val result: TapResult = TapResult.ACCEPTED,
    val rawPayloadToken: String = ""
)

enum class JourneyStatus {
    NO_JOURNEY,
    TAPPED_IN,
    IN_JOURNEY,
    TRANSFER,
    TAPPED_OUT,
    FARE_CALCULATED,
    PAYMENT_PENDING,
    PAID,
    SETTLED,
    EXCEPTION,
    REFUND_PENDING,
    REFUNDED
}

@Entity(tableName = "journeys")
data class Journey(
    @PrimaryKey val journeyId: String,
    val credentialId: String,
    val status: JourneyStatus,
    val startTime: Long,
    val endTime: Long? = null,
    val originStationId: String,
    val originStationName: String,
    val destinationStationId: String? = null,
    val destinationStationName: String? = null,
    val rawFareMinor: Long = 0,
    val discountMinor: Long = 0,
    val capAdjustmentMinor: Long = 0,
    val finalFareMinor: Long = 0,
    val currency: String = "GBP",
    val legsCount: Int = 1
)

@Entity(tableName = "journey_legs")
data class JourneyLeg(
    @PrimaryKey val legId: String,
    val journeyId: String,
    val operatorId: String,
    val mode: TransportMode,
    val originStationName: String,
    val destinationStationName: String,
    val entryTapId: String,
    val exitTapId: String? = null,
    val fareShareMinor: Long = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "readers")
data class Reader(
    @PrimaryKey val readerId: String,
    val operatorId: String,
    val operatorName: String,
    val stationId: String,
    val stationName: String,
    val gateId: String,
    val platform: String,
    val mode: TransportMode,
    val status: NetworkState = NetworkState.ONLINE,
    val firmwareVersion: String = "v3.7.2-a1",
    val queueDepth: Int = 0,
    val latencyMs: Long = 12,
    val tapCount: Long = 0,
    val lastHeartbeat: Long = System.currentTimeMillis()
)

@Entity(tableName = "fare_rules")
data class FareRule(
    @PrimaryKey val ruleId: String,
    val operatorId: String,
    val mode: TransportMode,
    val fromZone: Int,
    val toZone: Int,
    val isPeak: Boolean,
    val fareMinorUnits: Long
)

@Entity(tableName = "ledger_entries")
data class LedgerEntry(
    @PrimaryKey val entryId: String,
    val transactionId: String,
    val debitAccount: String,
    val creditAccount: String,
    val amountMinor: Long,
    val currency: String = "GBP",
    val timestamp: Long = System.currentTimeMillis(),
    val reference: String
)

@Entity(tableName = "settlements")
data class Settlement(
    @PrimaryKey val settlementId: String,
    val operatorId: String,
    val operatorName: String,
    val grossAmountMinor: Long,
    val feeAmountMinor: Long,
    val netSettledMinor: Long,
    val currency: String = "GBP",
    val status: String = "SETTLED",
    val timestamp: Long = System.currentTimeMillis(),
    val transactionCount: Int = 1
)

@Entity(tableName = "reconciliation_exceptions")
data class ReconciliationException(
    @PrimaryKey val exceptionId: String,
    val tapId: String?,
    val journeyId: String?,
    val issueType: String,
    val description: String,
    val status: String = "OPEN",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "risk_events")
data class RiskEvent(
    @PrimaryKey val eventId: String,
    val credentialId: String,
    val scenario: String,
    val riskScore: Int,
    val actionTaken: String,
    val timestamp: Long = System.currentTimeMillis()
)
