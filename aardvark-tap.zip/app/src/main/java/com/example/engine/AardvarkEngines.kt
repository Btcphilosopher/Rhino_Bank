package com.example.engine

import com.example.model.Credential
import com.example.model.CredentialType
import com.example.model.Journey
import com.example.model.JourneyLeg
import com.example.model.JourneyStatus
import com.example.model.LedgerEntry
import com.example.model.NetworkState
import com.example.model.Reader
import com.example.model.ReconciliationException
import com.example.model.Settlement
import com.example.model.TapDirection
import com.example.model.TapEvent
import com.example.model.TapResult
import com.example.model.TransportMode
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

object MoneyUtils {
    fun formatGbp(minorUnits: Long): String {
        val pounds = minorUnits / 100.0
        val formatter = NumberFormat.getCurrencyInstance(Locale.UK)
        return formatter.format(pounds)
    }
}

class FareEngine {
    // Calculates fare in minor units (pence)
    fun calculateFare(
        mode: TransportMode,
        fromZone: Int,
        toZone: Int,
        isPeak: Boolean,
        hasTransfer: Boolean = false
    ): Long {
        if (mode == TransportMode.BUS || mode == TransportMode.TRAM) {
            return if (hasTransfer) 0L else 175L // Hopper fare: £1.75
        }

        val zoneDiff = kotlin.math.abs(fromZone - toZone)
        val baseFarePence = when (zoneDiff) {
            0 -> 280L // Same zone e.g. £2.80
            1 -> 340L // 1 zone diff e.g. £3.40
            2 -> 420L // 2 zones diff e.g. £4.20
            3 -> 560L // 3 zones diff e.g. £5.60
            else -> 720L // 4+ zones diff e.g. £7.20
        }

        val peakMultiplier = if (isPeak) 1.25 else 1.0
        var fare = (baseFarePence * peakMultiplier).toLong()

        if (mode == TransportMode.FERRY) {
            fare += 150L // Ferry surcharge
        }

        return fare
    }

    fun getIncompleteJourneyPenalty(): Long = 850L // £8.50 max fare
}

class CappingEngine {
    private val DAILY_CAP_Z1_3 = 1000L // £10.00
    private val WEEKLY_CAP_Z1_3 = 4500L // £45.00

    data class CappingResult(
        val rawFare: Long,
        val discount: Long,
        val finalFare: Long,
        val capProgressBefore: Long,
        val capProgressAfter: Long,
        val capReached: Boolean
    )

    fun applyDailyCap(accumulatedToday: Long, proposedFare: Long): CappingResult {
        val capLimit = DAILY_CAP_Z1_3
        val remainingCapSpace = max(0L, capLimit - accumulatedToday)

        val finalFare = min(proposedFare, remainingCapSpace)
        val discount = proposedFare - finalFare
        val accumulatedAfter = accumulatedToday + finalFare

        return CappingResult(
            rawFare = proposedFare,
            discount = discount,
            finalFare = finalFare,
            capProgressBefore = accumulatedToday,
            capProgressAfter = accumulatedAfter,
            capReached = accumulatedAfter >= capLimit
        )
    }
}

class PaymentEngine {
    data class AuthResponse(
        val isAuthorised: Boolean,
        val authCode: String,
        val declineReason: String? = null,
        val acquirerRef: String
    )

    fun authorisePayment(
        credentialId: String,
        amountMinor: Long,
        forceDecline: Boolean = false
    ): AuthResponse {
        val ref = "ACQ-${UUID.randomUUID().toString().take(8).uppercase()}"
        if (forceDecline) {
            return AuthResponse(
                isAuthorised = false,
                authCode = "DECLINED_INSUFFICIENT_FUNDS",
                declineReason = "Issuer status: 51 Insufficient Funds",
                acquirerRef = ref
            )
        }
        val authCode = "AUTH-${(100000..999999).random()}"
        return AuthResponse(
            isAuthorised = true,
            authCode = authCode,
            declineReason = null,
            acquirerRef = ref
        )
    }
}

class DoubleEntryLedgerEngine {
    fun createTransactionEntries(
        transactionId: String,
        amountMinor: Long,
        operatorId: String,
        reference: String
    ): List<LedgerEntry> {
        val feeMinor = (amountMinor * 0.025).toLong() // 2.5% Aardvark Tap processing fee
        val operatorShareMinor = amountMinor - feeMinor

        val now = System.currentTimeMillis()

        return listOf(
            // Debit Passenger Receivable, Credit Clearing
            LedgerEntry(
                entryId = "LED-${UUID.randomUUID().toString().take(8)}",
                transactionId = transactionId,
                debitAccount = "ACC_PASSENGER_RECEIVABLE",
                creditAccount = "ACC_CLEARING_HOUSE",
                amountMinor = amountMinor,
                timestamp = now,
                reference = reference
            ),
            // Debit Clearing, Credit Operator Revenue
            LedgerEntry(
                entryId = "LED-${UUID.randomUUID().toString().take(8)}",
                transactionId = transactionId,
                debitAccount = "ACC_CLEARING_HOUSE",
                creditAccount = "ACC_OPERATOR_REV_$operatorId",
                amountMinor = operatorShareMinor,
                timestamp = now + 1,
                reference = "Revenue Split to $operatorId"
            ),
            // Debit Clearing, Credit Aardvark Fee Account
            LedgerEntry(
                entryId = "LED-${UUID.randomUUID().toString().take(8)}",
                transactionId = transactionId,
                debitAccount = "ACC_CLEARING_HOUSE",
                creditAccount = "ACC_AARDVARK_FEE",
                amountMinor = feeMinor,
                timestamp = now + 2,
                reference = "Aardvark Tap Processing Fee (2.5%)"
            )
        )
    }
}
