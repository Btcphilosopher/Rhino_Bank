package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AardvarkHeader
import com.example.ui.components.AardvarkNavigationBar
import com.example.ui.screens.ClearingScreen
import com.example.ui.screens.DeveloperConsoleScreen
import com.example.ui.screens.FailureLabScreen
import com.example.ui.screens.GateSimulatorScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PassengerAppScreen
import com.example.ui.screens.ReaderControlScreen
import com.example.ui.screens.SignatureDemoScreen
import com.example.ui.theme.AardvarkTapTheme
import com.example.viewmodel.AardvarkViewModel
import com.example.viewmodel.AppScreen

class MainActivity : ComponentActivity() {
    private val viewModel: AardvarkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AardvarkTapTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val selectedTap by viewModel.selectedTap.collectAsStateWithLifecycle()

                val allTaps by viewModel.allTaps.collectAsStateWithLifecycle()
                val allJourneys by viewModel.allJourneys.collectAsStateWithLifecycle()
                val allReaders by viewModel.allReaders.collectAsStateWithLifecycle()
                val allCredentials by viewModel.allCredentials.collectAsStateWithLifecycle()
                val allLedgerEntries by viewModel.allLedgerEntries.collectAsStateWithLifecycle()
                val allSettlements by viewModel.allSettlements.collectAsStateWithLifecycle()
                val allExceptions by viewModel.allExceptions.collectAsStateWithLifecycle()
                val allRiskEvents by viewModel.allRiskEvents.collectAsStateWithLifecycle()

                val gateState by viewModel.gateState.collectAsStateWithLifecycle()
                val gateMessage by viewModel.gateMessage.collectAsStateWithLifecycle()

                val demoSteps by viewModel.demoSteps.collectAsStateWithLifecycle()
                val demoRunning by viewModel.demoRunning.collectAsStateWithLifecycle()

                val isSimRunning by viewModel.isSimRunning.collectAsStateWithLifecycle()
                val simSpeed by viewModel.simSpeed.collectAsStateWithLifecycle()
                val tps by viewModel.tps.collectAsStateWithLifecycle()
                val p95LatencyMs by viewModel.p95LatencyMs.collectAsStateWithLifecycle()
                val activeJourneysCount by viewModel.activeJourneysCount.collectAsStateWithLifecycle()
                val offlineQueueDepth by viewModel.offlineQueueDepth.collectAsStateWithLifecycle()

                // BackHandler for secondary screens
                if (currentScreen != AppScreen.OVERVIEW) {
                    BackHandler {
                        viewModel.navigateTo(AppScreen.OVERVIEW)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        Column {
                            AardvarkHeader(
                                tps = tps,
                                activeJourneys = activeJourneysCount,
                                p95Latency = p95LatencyMs,
                                offlineQueue = offlineQueueDepth
                            )
                            AardvarkNavigationBar(
                                currentScreen = currentScreen,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            AppScreen.OVERVIEW -> OverviewScreen(
                                taps = allTaps,
                                selectedTap = selectedTap,
                                isSimRunning = isSimRunning,
                                simSpeed = simSpeed,
                                activeJourneys = activeJourneysCount,
                                onSelectTap = { viewModel.selectTap(it) },
                                onToggleSim = { viewModel.toggleSim() },
                                onSetSpeed = { viewModel.setSpeed(it) }
                            )
                            AppScreen.JOURNEY_DEMO -> SignatureDemoScreen(
                                demoSteps = demoSteps,
                                demoRunning = demoRunning,
                                onRunDemo = { viewModel.runSignatureDemo() }
                            )
                            AppScreen.GATE_SIMULATOR -> GateSimulatorScreen(
                                gateState = gateState,
                                gateMessage = gateMessage,
                                credentials = allCredentials,
                                readers = allReaders,
                                onTriggerTap = { credId, readerId -> viewModel.triggerGateTap(credId, readerId) }
                            )
                            AppScreen.CLEARING -> ClearingScreen(
                                ledgerEntries = allLedgerEntries,
                                settlements = allSettlements
                            )
                            AppScreen.FAILURE_LAB -> FailureLabScreen(
                                repository = viewModel.repository,
                                exceptions = allExceptions,
                                riskEvents = allRiskEvents,
                                offlineQueueDepth = offlineQueueDepth,
                                onSyncOfflineQueue = { viewModel.syncOfflineQueue() }
                            )
                            AppScreen.READERS -> ReaderControlScreen(readers = allReaders)
                            AppScreen.DEVELOPER -> DeveloperConsoleScreen(credentials = allCredentials)
                            AppScreen.PASSENGER -> PassengerAppScreen(
                                journeys = allJourneys,
                                onTriggerDemoTap = {
                                    viewModel.triggerGateTap("CRED-4421", "LON-KGX-GATE-01")
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
