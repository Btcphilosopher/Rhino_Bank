package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.model.Credential
import com.example.model.Journey
import com.example.model.LedgerEntry
import com.example.model.Reader
import com.example.model.ReconciliationException
import com.example.model.RiskEvent
import com.example.model.Settlement
import com.example.model.TapEvent
import com.example.repository.AardvarkRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    OVERVIEW,
    JOURNEY_DEMO,
    GATE_SIMULATOR,
    CLEARING,
    FAILURE_LAB,
    READERS,
    DEVELOPER,
    PASSENGER
}

enum class GateState {
    READY,
    TAP_DETECTED,
    AUTHENTICATING,
    ACCEPTED,
    OPEN,
    REJECTED
}

data class DemoTraceStep(
    val timeLabel: String,
    val title: String,
    val detail: String,
    val isCompleted: Boolean = false,
    val isCurrent: Boolean = false
)

class AardvarkViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    val repository = AardvarkRepository(db)

    private val _currentScreen = MutableStateFlow(AppScreen.OVERVIEW)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedTap = MutableStateFlow<TapEvent?>(null)
    val selectedTap: StateFlow<TapEvent?> = _selectedTap.asStateFlow()

    // Interactive Gate State
    private val _gateState = MutableStateFlow(GateState.READY)
    val gateState: StateFlow<GateState> = _gateState.asStateFlow()

    private val _gateMessage = MutableStateFlow("TOUCH CARD OR PHONE TO GATE")
    val gateMessage: StateFlow<String> = _gateMessage.asStateFlow()

    // Signature Demo State
    private val _demoRunning = MutableStateFlow(false)
    val demoRunning: StateFlow<Boolean> = _demoRunning.asStateFlow()

    private val _demoSteps = MutableStateFlow<List<DemoTraceStep>>(emptyList())
    val demoSteps: StateFlow<List<DemoTraceStep>> = _demoSteps.asStateFlow()

    // Reactive streams from Room via Repository
    val allTaps: StateFlow<List<TapEvent>> = repository.allTaps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allJourneys: StateFlow<List<Journey>> = repository.allJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReaders: StateFlow<List<Reader>> = repository.allReaders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCredentials: StateFlow<List<Credential>> = repository.allCredentials
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLedgerEntries: StateFlow<List<LedgerEntry>> = repository.allLedgerEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSettlements: StateFlow<List<Settlement>> = repository.allSettlements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExceptions: StateFlow<List<ReconciliationException>> = repository.allExceptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRiskEvents: StateFlow<List<RiskEvent>> = repository.allRiskEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val simSpeed = repository.simSpeed
    val isSimRunning = repository.isSimRunning
    val tps = repository.tps
    val p95LatencyMs = repository.p95LatencyMs
    val activeJourneysCount = repository.activeJourneysCount
    val offlineQueueDepth = repository.offlineQueueDepth

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectTap(tap: TapEvent?) {
        _selectedTap.value = tap
    }

    fun triggerGateTap(credentialId: String, readerId: String) {
        viewModelScope.launch {
            _gateState.value = GateState.TAP_DETECTED
            _gateMessage.value = "NFC SIGNAL DETECTED..."
            delay(400)

            _gateState.value = GateState.AUTHENTICATING
            _gateMessage.value = "AUTHENTICATING CREDENTIAL..."
            delay(500)

            val tapRes = repository.processTap(credentialId, readerId)

            if (tapRes.result == com.example.model.TapResult.ACCEPTED) {
                _gateState.value = GateState.ACCEPTED
                _gateMessage.value = "ACCEPTED • ${tapRes.direction.name}"
                delay(300)
                _gateState.value = GateState.OPEN
                _gateMessage.value = "GATE OPEN • SEEK CLEARANCE"
                delay(1800)
                _gateState.value = GateState.READY
                _gateMessage.value = "READY FOR NEXT PASSENGER"
            } else {
                _gateState.value = GateState.REJECTED
                _gateMessage.value = "NOT AUTHORISED • QUEUED OFFLINE"
                delay(2000)
                _gateState.value = GateState.READY
                _gateMessage.value = "READY FOR NEXT PASSENGER"
            }
        }
    }

    fun runSignatureDemo() {
        if (_demoRunning.value) return
        viewModelScope.launch {
            _demoRunning.value = true

            val initialSteps = listOf(
                DemoTraceStep("08:41:58", "APPROACH GATE", "Passenger approaches Gate 01 at London King's Cross"),
                DemoTraceStep("08:42:01", "NFC DETECTED", "13.56 MHz ISO/IEC 14443 field collision & payload exchange"),
                DemoTraceStep("08:42:02", "CREDENTIAL VERIFIED", "Token CRED-4421 resolved to Mobile Wallet (iPhone 16 Pro)"),
                DemoTraceStep("08:42:02", "JOURNEY OPENED", "Tap Gateway created Journey JRN-839201 in state TAPPED_IN"),
                DemoTraceStep("08:42:03", "GATE OPENED", "Physical barrier retracted (Latency: 11ms)"),
                DemoTraceStep("08:58:21", "TRANSFER EVENT", "In-station interchange at Moorgate (Zone 1)"),
                DemoTraceStep("09:03:42", "DESTINATION REACHED", "Tap out at London Bridge Gate 02"),
                DemoTraceStep("09:03:44", "FARE CALCULATED", "FareEngine evaluated Z1-Z1 Peak fare: £3.40"),
                DemoTraceStep("09:03:45", "DAILY CAP APPLIED", "CappingEngine applied £10.00 daily cap adjustment"),
                DemoTraceStep("09:03:45", "PAYMENT AUTHORISED", "Acquirer authorised £3.40 (AuthCode: AUTH-918231)"),
                DemoTraceStep("09:03:46", "LEDGER POSTED", "Double-Entry Ledger recorded 3 balanced entries"),
                DemoTraceStep("09:03:47", "SETTLEMENT ALLOCATED", "Revenue split: 80% TFL, 20% Rail, 2.5% Aardvark Fee")
            )

            _demoSteps.value = initialSteps

            for (i in initialSteps.indices) {
                _demoSteps.value = _demoSteps.value.mapIndexed { index, step ->
                    when {
                        index < i -> step.copy(isCompleted = true, isCurrent = false)
                        index == i -> step.copy(isCompleted = false, isCurrent = true)
                        else -> step.copy(isCompleted = false, isCurrent = false)
                    }
                }
                delay(800)
            }

            _demoSteps.value = _demoSteps.value.map { it.copy(isCompleted = true, isCurrent = false) }

            // Trigger actual tap in repository
            repository.processTap("CRED-4421", "LON-KGX-GATE-01")
            delay(500)
            repository.processTap("CRED-4421", "LON-LBG-GATE-01", isExitOverride = true)

            _demoRunning.value = false
        }
    }

    fun syncOfflineQueue() {
        viewModelScope.launch {
            repository.syncOfflineEvents()
        }
    }

    fun setSpeed(speed: Int) {
        repository.setSimSpeed(speed)
    }

    fun toggleSim() {
        repository.toggleSimulation()
    }
}
