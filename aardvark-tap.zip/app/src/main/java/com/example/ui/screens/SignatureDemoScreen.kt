package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BritishRailNavy
import com.example.ui.theme.CardBorder
import com.example.ui.theme.ControlledGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepRailBlue
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.DemoTraceStep

@Composable
fun SignatureDemoScreen(
    demoSteps: List<DemoTraceStep>,
    demoRunning: Boolean,
    onRunDemo: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Banner Header
        Card(
            colors = CardDefaults.cardColors(containerColor = BritishRailNavy),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentCyan))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Route,
                            contentDescription = "Signature Demo",
                            tint = AccentCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SIGNATURE DEMONSTRATION",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "LONDON KING'S CROSS → LONDON BRIDGE (MULTI-MODAL JOURNEY GRAPH)",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = onRunDemo,
                    enabled = !demoRunning,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("run_signature_demo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Run Demo",
                        tint = DarkBackground
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (demoRunning) "EXECUTING TRACE..." else "RUN KING'S CROSS → LONDON BRIDGE DEMO",
                        fontWeight = FontWeight.Bold,
                        color = DarkBackground,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Left Column: Step-by-step Trace
            Card(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "EXECUTION TRACE CHRONOLOGY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (demoSteps.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Press 'RUN KING'S CROSS → LONDON BRIDGE DEMO' to trigger full hardware-to-clearing sequence.",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(demoSteps) { step ->
                                TraceStepRow(step = step)
                            }
                        }
                    }
                }
            }

            // Right Column: Multi-modal Journey Breakdown & Revenue Allocation
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "MULTI-MODAL TRANSACTION GRAPH",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    GraphStage("PASSENGER PERSPECTIVE", "1 Tap • 1 Journey • 1 Daily Cap Fare", "£3.40", ControlledGreen)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "UNDERNEATH THE INFRASTRUCTURE:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    GraphStage("Leg 1: London Bus #73", "Entry Gate: BUS-VAL-101 • Operator: London Buses", "£1.75 (Hopper Free)", TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    GraphStage("Leg 2: King's Cross Rail", "Entry Gate: LON-KGX-GATE-01 • Operator: National Rail UK", "£2.10 Share", TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    GraphStage("Leg 3: Northern Line Tube", "Exit Gate: LON-LBG-GATE-02 • Operator: TfL Underground", "£1.30 Share", TextSecondary)

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "OPERATOR REVENUE ALLOCATION MATRIX",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    AllocationRow("TfL Underground", "£1.30", "38.2%")
                    AllocationRow("National Rail UK", "£2.02", "59.3%")
                    AllocationRow("Aardvark Tap Fee (2.5%)", "£0.08", "2.5%")
                }
            }
        }
    }
}

@Composable
private fun TraceStepRow(step: DemoTraceStep) {
    val bg = when {
        step.isCurrent -> SignalAmber.copy(alpha = 0.2f)
        step.isCompleted -> ControlledGreen.copy(alpha = 0.15f)
        else -> DarkSurfaceVariant
    }
    val borderColor = when {
        step.isCurrent -> SignalAmber
        step.isCompleted -> ControlledGreen
        else -> CardBorder
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (step.isCompleted) ControlledGreen else if (step.isCurrent) SignalAmber else CardBorder),
            contentAlignment = Alignment.Center
        ) {
            if (step.isCompleted) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Completed",
                    tint = DarkBackground,
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Text(
                    text = step.timeLabel.takeLast(2),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = step.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (step.isCurrent) SignalAmber else TextPrimary
                )
                Text(
                    text = step.timeLabel,
                    fontSize = 10.sp,
                    color = TextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = step.detail,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun GraphStage(title: String, subtitle: String, value: String, accent: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = subtitle, fontSize = 10.sp, color = TextMuted)
        }
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = accent,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun AllocationRow(operator: String, amount: String, percentage: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = operator, fontSize = 11.sp, color = TextSecondary)
        Row {
            Text(text = amount, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "($percentage)", fontSize = 11.sp, color = AccentCyan)
        }
    }
}
