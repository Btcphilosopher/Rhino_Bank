package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsRailway
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MoneyUtils
import com.example.model.TapDirection
import com.example.model.TapEvent
import com.example.model.TransportMode
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BritishRailNavy
import com.example.ui.theme.CardBorder
import com.example.ui.theme.ControlledGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepRailBlue
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OverviewScreen(
    taps: List<TapEvent>,
    selectedTap: TapEvent?,
    isSimRunning: Boolean,
    simSpeed: Int,
    activeJourneys: Int,
    onSelectTap: (TapEvent) -> Unit,
    onToggleSim: () -> Unit,
    onSetSpeed: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Left Column: Live Metrics & Controls
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE NETWORK STATUS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    BigMetric("18,421", "Active Journeys Open", AccentCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    BigMetric("4,821", "Taps / min", ControlledGreen)
                    Spacer(modifier = Modifier.height(8.dp))
                    BigMetric("99.98%", "Reader Network Availability", SignalAmber)

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "SIMULATION ENGINE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = onToggleSim,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSimRunning) SignalAmber else ControlledGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("toggle_sim_button")
                        ) {
                            Icon(
                                imageVector = if (isSimRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Sim Toggle",
                                tint = DarkBackground,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isSimRunning) "PAUSE SIM" else "RUN SIM",
                                fontWeight = FontWeight.Bold,
                                color = DarkBackground,
                                fontSize = 12.sp
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(1, 10, 100).forEach { speed ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (simSpeed == speed) AccentCyan else DeepRailBlue)
                                        .clickable { onSetSpeed(speed) }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "${speed}x",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (simSpeed == speed) DarkBackground else TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Station Nodes Summary
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "TOP TRANSPORT NODES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val nodes = listOf(
                        Triple("London King's Cross", "Rail & Underground", "1,820 taps/m"),
                        Triple("London Bridge", "Underground & Rail", "2,100 taps/m"),
                        Triple("Victoria Station", "Bus & Rail", "1,240 taps/m"),
                        Triple("Manchester Piccadilly", "Tram & Rail", "890 taps/m"),
                        Triple("Edinburgh Waverley", "ScotRail Express", "520 taps/m")
                    )

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(nodes) { (name, type, rate) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DarkSurfaceVariant)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(text = type, fontSize = 10.sp, color = TextMuted)
                                }
                                Text(
                                    text = rate,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentCyan,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Centre Column: Interactive Network Stream
        Card(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE PHYSICAL TAP FEED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${taps.size} EVENTS RECORDED",
                        fontSize = 10.sp,
                        color = AccentCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(taps) { tap ->
                        val isSelected = selectedTap?.tapId == tap.tapId
                        TapEventRow(tap = tap, isSelected = isSelected, onClick = { onSelectTap(tap) })
                    }
                }
            }
        }

        // Right Column: Transaction Inspector
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "TRANSACTION PROVENANCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                val tap = selectedTap ?: taps.firstOrNull()

                if (tap != null) {
                    Text(
                        text = tap.tapId,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "IMMUTABLE AUDIT TRAIL RECORD",
                        fontSize = 9.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ProvenanceItem("Credential Token", tap.credentialId)
                    ProvenanceItem("Reader ID", tap.readerId)
                    ProvenanceItem("Operator", tap.operatorId)
                    ProvenanceItem("Station", tap.stationName)
                    ProvenanceItem("Mode", tap.mode.name)
                    ProvenanceItem("Direction", tap.direction.name)
                    ProvenanceItem("Timestamp", SimpleDateFormat("HH:mm:ss.SSS", Locale.UK).format(Date(tap.timestamp)))
                    ProvenanceItem("Network State", tap.networkState.name)
                    ProvenanceItem("Gate Result", tap.result.name)

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BritishRailNavy)
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "AARDVARK CLEARING PIPELINE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentCyan
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "CREDENTIAL → JOURNEY → FARE → PAYMENT → LEDGER → SETTLEMENT",
                                fontSize = 9.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "Select a tap event to inspect", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BigMetric(value: String, label: String, valueColor: Color) {
    Column {
        Text(
            text = value,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = valueColor,
            fontFamily = FontFamily.Monospace
        )
        Text(text = label, fontSize = 11.sp, color = TextMuted)
    }
}

@Composable
private fun TapEventRow(tap: TapEvent, isSelected: Boolean, onClick: () -> Unit) {
    val modeIcon = when (tap.mode) {
        TransportMode.RAIL -> Icons.Default.DirectionsRailway
        TransportMode.UNDERGROUND -> Icons.Default.DirectionsSubway
        TransportMode.BUS -> Icons.Default.DirectionsBus
        TransportMode.TRAM -> Icons.Default.DirectionsTransit
        TransportMode.FERRY -> Icons.Default.DirectionsBoat
        else -> Icons.Default.DirectionsRailway
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) DeepRailBlue else DarkSurfaceVariant)
            .border(1.dp, if (isSelected) AccentCyan else CardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = modeIcon,
                contentDescription = tap.mode.name,
                tint = if (tap.direction == TapDirection.ENTRY) ControlledGreen else SignalAmber,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = tap.stationName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "${tap.credentialId} • ${tap.direction.name}",
                    fontSize = 10.sp,
                    color = TextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(tap.timestamp)),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = AccentCyan,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = tap.result.name,
                fontSize = 9.sp,
                color = if (tap.result == com.example.model.TapResult.ACCEPTED) ControlledGreen else SignalAmber,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun ProvenanceItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = TextMuted)
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            fontFamily = FontFamily.Monospace
        )
    }
}
