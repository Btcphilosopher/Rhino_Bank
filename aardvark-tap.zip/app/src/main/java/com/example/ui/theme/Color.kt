package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aardvark Tap Palette: British Rail & Financial Infrastructure
val BritishRailNavy = Color(0xFF0B2545)
val DeepRailBlue = Color(0xFF134074)
val MetalSlate = Color(0xFF1B263B)
val DarkBackground = Color(0xFF0A0E14)
val DarkSurface = Color(0xFF111823)
val DarkSurfaceVariant = Color(0xFF1E293B)

val SignalAmber = Color(0xFFF59E0B)
val ControlledGreen = Color(0xFF10B981)
val RailRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardBorder = Color(0xFF334155)
val AccentCyan = Color(0xFF38BDF8)

