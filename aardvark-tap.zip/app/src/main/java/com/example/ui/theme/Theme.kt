package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    onPrimary = DarkBackground,
    primaryContainer = DeepRailBlue,
    onPrimaryContainer = TextPrimary,
    secondary = SignalAmber,
    onSecondary = DarkBackground,
    tertiary = ControlledGreen,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    error = RailRed,
    onError = TextPrimary
)

private val LightColorScheme = darkColorScheme( // Default to dark enterprise theme
    primary = AccentCyan,
    onPrimary = DarkBackground,
    primaryContainer = DeepRailBlue,
    onPrimaryContainer = TextPrimary,
    secondary = SignalAmber,
    onSecondary = DarkBackground,
    tertiary = ControlledGreen,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    error = RailRed,
    onError = TextPrimary
)

@Composable
fun AardvarkTapTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

