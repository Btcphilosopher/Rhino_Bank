package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.DoorSliding
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DeepRailBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.AppScreen

data class NavItem(
    val screen: AppScreen,
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

val navItems = listOf(
    NavItem(AppScreen.OVERVIEW, "Live Network", Icons.Default.Map, "nav_overview"),
    NavItem(AppScreen.JOURNEY_DEMO, "Journey Demo", Icons.Default.Route, "nav_demo"),
    NavItem(AppScreen.GATE_SIMULATOR, "Gate Hardware", Icons.Default.DoorSliding, "nav_gate"),
    NavItem(AppScreen.CLEARING, "Financial Clearing", Icons.Default.AccountBalance, "nav_clearing"),
    NavItem(AppScreen.FAILURE_LAB, "Failure Lab", Icons.Default.Warning, "nav_failure_lab"),
    NavItem(AppScreen.READERS, "Reader Control", Icons.Default.DeveloperBoard, "nav_readers"),
    NavItem(AppScreen.DEVELOPER, "Developer API", Icons.Default.Code, "nav_developer"),
    NavItem(AppScreen.PASSENGER, "Passenger App", Icons.Default.PhoneIphone, "nav_passenger")
)

@Composable
fun AardvarkNavigationBar(
    currentScreen: AppScreen,
    onNavigate: (AppScreen) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = navItems.indexOfFirst { it.screen == currentScreen }.coerceAtLeast(0),
        containerColor = DarkSurface,
        contentColor = AccentCyan,
        edgePadding = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        navItems.forEach { item ->
            val isSelected = currentScreen == item.screen
            Tab(
                selected = isSelected,
                onClick = { onNavigate(item.screen) },
                modifier = Modifier
                    .testTag(item.testTag)
                    .padding(vertical = 4.dp, horizontal = 2.dp),
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) DeepRailBlue else DarkSurface)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = if (isSelected) AccentCyan else TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item.title,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) TextPrimary else TextMuted
                        )
                    }
                }
            )
        }
    }
}
