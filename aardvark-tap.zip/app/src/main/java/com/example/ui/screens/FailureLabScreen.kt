package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ReconciliationException
import com.example.model.RiskEvent
import com.example.repository.AardvarkRepository
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BritishRailNavy
import com.example.ui.theme.CardBorder
import com.example.ui.theme.ControlledGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.RailRed
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FailureLabScreen(
    repository: AardvarkRepository,
    exceptions: List<ReconciliationException>,
    riskEvents: List<RiskEvent>,
    offlineQueueDepth: Int,
    onSyncOfflineQueue: () -> Unit
) {
    var readerOffline by remember { mutableStateOf(repository.forceReaderOffline) }
    var paymentDecline by remember { mutableStateOf(repository.forcePaymentDecline) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Left Column: Fault Injector Panel
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = SignalAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "FAULT INJECTION CONTROLS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                FaultToggleRow(
                    title = "Force Gate Reader Offline",
                    subtitle = "Simulates cellular/network drop. Taps store in bounded offline queue.",
                    checked = readerOffline,
                    onCheckedChange = {
                        readerOffline = it
                        repository.forceReaderOffline = it
                    },
                    testTag = "toggle_reader_offline"
                )

                Spacer(modifier = Modifier.height(10.dp))

                FaultToggleRow(
                    title = "Force Payment Auth Decline",
                    subtitle = "Simulates issuer decline at tap-out. Generates Reconciliation Exception.",
                    checked = paymentDecline,
                    onCheckedChange = {
                        paymentDecline = it
                        repository.forcePaymentDecline = it
                    },
                    testTag = "toggle_payment_decline"
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "OFFLINE QUEUE & AUTO-RECOVERY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BritishRailNavy)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Bounded Queue Depth", fontSize = 11.sp, color = TextMuted)
                        Text(text = "$offlineQueueDepth pending events", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SignalAmber)
                    }

                    Button(
                        onClick = onSyncOfflineQueue,
                        enabled = offlineQueueDepth > 0 || readerOffline,
                        colors = ButtonDefaults.buttonColors(containerColor = ControlledGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("sync_offline_queue_button")
                    ) {
                        Icon(imageVector = Icons.Default.Sync, contentDescription = null, tint = DarkBackground, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "RESTORE & SYNC", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DarkBackground)
                    }
                }
            }
        }

        // Right Column: Reconciliation Exceptions & Risk Events
        Card(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "RECONCILIATION EXCEPTIONS & RISK LOGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(exceptions) { exc ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceVariant)
                                .border(1.dp, RailRed, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = exc.issueType, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RailRed)
                                Text(text = exc.status, fontSize = 10.sp, color = SignalAmber, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = exc.description, fontSize = 11.sp, color = TextPrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FaultToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = subtitle, fontSize = 10.sp, color = TextMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = SignalAmber, checkedTrackColor = BritishRailNavy),
            modifier = Modifier.testTag(testTag)
        )
    }
}
