package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.Credential
import com.example.model.FareRule
import com.example.model.Journey
import com.example.model.JourneyLeg
import com.example.model.LedgerEntry
import com.example.model.Reader
import com.example.model.ReconciliationException
import com.example.model.RiskEvent
import com.example.model.Settlement
import com.example.model.TapEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface TapDao {
    @Query("SELECT * FROM tap_events ORDER BY timestamp DESC LIMIT 200")
    fun getAllTaps(): Flow<List<TapEvent>>

    @Query("SELECT * FROM tap_events WHERE credentialId = :credentialId ORDER BY timestamp DESC")
    fun getTapsByCredential(credentialId: String): Flow<List<TapEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTap(tap: TapEvent)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTaps(taps: List<TapEvent>)

    @Query("SELECT COUNT(*) FROM tap_events")
    fun getTapCount(): Flow<Int>
}

@Dao
interface JourneyDao {
    @Query("SELECT * FROM journeys ORDER BY startTime DESC LIMIT 200")
    fun getAllJourneys(): Flow<List<Journey>>

    @Query("SELECT * FROM journeys WHERE credentialId = :credentialId ORDER BY startTime DESC")
    fun getJourneysByCredential(credentialId: String): Flow<List<Journey>>

    @Query("SELECT * FROM journeys WHERE credentialId = :credentialId AND status IN ('TAPPED_IN', 'IN_JOURNEY', 'TRANSFER') LIMIT 1")
    suspend fun getActiveJourney(credentialId: String): Journey?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: Journey)

    @Update
    suspend fun updateJourney(journey: Journey)

    @Query("SELECT * FROM journey_legs WHERE journeyId = :journeyId ORDER BY timestamp ASC")
    fun getLegsForJourney(journeyId: String): Flow<List<JourneyLeg>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeg(leg: JourneyLeg)
}

@Dao
interface ReaderDao {
    @Query("SELECT * FROM readers ORDER BY stationName ASC")
    fun getAllReaders(): Flow<List<Reader>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReader(reader: Reader)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReaders(readers: List<Reader>)

    @Update
    suspend fun updateReader(reader: Reader)
}

@Dao
interface CredentialDao {
    @Query("SELECT * FROM credentials ORDER BY createdAt DESC")
    fun getAllCredentials(): Flow<List<Credential>>

    @Query("SELECT * FROM credentials WHERE credentialId = :credentialId LIMIT 1")
    suspend fun getCredential(credentialId: String): Credential?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCredential(credential: Credential)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCredentials(credentials: List<Credential>)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC LIMIT 200")
    fun getAllLedgerEntries(): Flow<List<LedgerEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: LedgerEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntries(entries: List<LedgerEntry>)

    @Query("SELECT SUM(amountMinor) FROM ledger_entries WHERE creditAccount = :account")
    fun getTotalCreditForAccount(account: String): Flow<Long?>
}

@Dao
interface SettlementDao {
    @Query("SELECT * FROM settlements ORDER BY timestamp DESC")
    fun getAllSettlements(): Flow<List<Settlement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlement(settlement: Settlement)
}

@Dao
interface ReconciliationDao {
    @Query("SELECT * FROM reconciliation_exceptions ORDER BY timestamp DESC")
    fun getAllExceptions(): Flow<List<ReconciliationException>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertException(exception: ReconciliationException)
}

@Dao
interface RiskDao {
    @Query("SELECT * FROM risk_events ORDER BY timestamp DESC")
    fun getAllRiskEvents(): Flow<List<RiskEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRiskEvent(event: RiskEvent)
}
