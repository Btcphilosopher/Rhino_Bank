package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.Credential
import com.example.model.FareRule
import com.example.model.Journey
import com.example.model.JourneyLeg
import com.example.model.LedgerEntry
import com.example.model.Reader
import com.example.model.ReconciliationException
import com.example.model.RiskEvent
import com.example.model.Settlement
import com.example.model.TapEvent

@Database(
    entities = [
        Credential::class,
        TapEvent::class,
        Journey::class,
        JourneyLeg::class,
        Reader::class,
        FareRule::class,
        LedgerEntry::class,
        Settlement::class,
        ReconciliationException::class,
        RiskEvent::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tapDao(): TapDao
    abstract fun journeyDao(): JourneyDao
    abstract fun readerDao(): ReaderDao
    abstract fun credentialDao(): CredentialDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun settlementDao(): SettlementDao
    abstract fun reconciliationDao(): ReconciliationDao
    abstract fun riskDao(): RiskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aardvark_tap_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
