package com.example.repository

import com.example.data.AppDatabase
import com.example.engine.CappingEngine
import com.example.engine.DoubleEntryLedgerEngine
import com.example.engine.FareEngine
import com.example.engine.PaymentEngine
import com.example.model.Credential
import com.example.model.CredentialStatus
import com.example.model.CredentialType
import com.example.model.Journey
import com.example.model.JourneyLeg
import com.example.model.JourneyStatus
import com.example.model.LedgerEntry
import com.example.model.NetworkState
import com.example.model.Reader
import com.example.model.ReconciliationException
import com.example.model.RiskEvent
import com.example.model.Settlement
import com.example.model.TapDirection
import com.example.model.TapEvent
import com.example.model.TapResult
import com.example.model.TransportMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class AardvarkRepository(private val db: AppDatabase) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val fareEngine = FareEngine()
    private val cappingEngine = CappingEngine()
    private val paymentEngine = PaymentEngine()
    private val ledgerEngine = DoubleEntryLedgerEngine()

    // Simulation metrics
    private val _simSpeed = MutableStateFlow(1)
    val simSpeed: StateFlow<Int> = _simSpeed.asStateFlow()

    private val _isSimRunning = MutableStateFlow(false)
    val isSimRunning: StateFlow<Boolean> = _isSimRunning.asStateFlow()

    private val _tps = MutableStateFlow(80.0)
    val tps: StateFlow<Double> = _tps.asStateFlow()

    private val _p95LatencyMs = MutableStateFlow(14L)
    val p95LatencyMs: StateFlow<Long> = _p95LatencyMs.asStateFlow()

    private val _activeJourneysCount = MutableStateFlow(4821)
    val activeJourneysCount: StateFlow<Int> = _activeJourneysCount.asStateFlow()

    private val _offlineQueueDepth = MutableStateFlow(0)
    val offlineQueueDepth: StateFlow<Int> = _offlineQueueDepth.asStateFlow()

    // Failure Lab injection flags
    var forceReaderOffline: Boolean = false
    var forcePaymentDecline: Boolean = false
    var forceDuplicateTap: Boolean = false

    init {
        scope.launch {
            seedDatabaseIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        val existingReaders = db.readerDao().getAllReaders().first()
        if (existingReaders.isNotEmpty()) return

        // Seed synthetic credentials
        val demoCredentials = listOf(
            Credential("CRED-4421", "tok_demo_8f72a1", "IPHONE-DEMO-019", CredentialType.MOBILE_WALLET, CredentialStatus.ACTIVE, "Alexander Wright", "8821"),
            Credential("CRED-8902", "tok_demo_9c12b4", "WATCH-DEMO-044", CredentialType.SMARTWATCH, CredentialStatus.ACTIVE, "Eleanor Vance", "3091"),
            Credential("CRED-1105", "tok_demo_11a99d", "CARD-DEMO-901", CredentialType.CONTACTLESS_CARD, CredentialStatus.ACTIVE, "Arthur Pendelton", "4520"),
            Credential("CRED-7733", "tok_demo_77c88e", "SMARTCARD-DEMO-02", CredentialType.TRANSPORT_SMARTCARD, CredentialStatus.ACTIVE, "TfL Oyster Demo", "1029")
        )
        db.credentialDao().insertCredentials(demoCredentials)

        // Seed readers
        val demoReaders = listOf(
            Reader("LON-KGX-GATE-01", "DEMO-RAIL", "National Rail UK", "KINGSCROSS", "London King's Cross", "GATE-01", "Plat 1-4", TransportMode.RAIL, NetworkState.ONLINE, "v3.7.2", 0, 11, 1420),
            Reader("LON-KGX-GATE-02", "DEMO-RAIL", "National Rail UK", "KINGSCROSS", "London King's Cross", "GATE-02", "Plat 5-8", TransportMode.RAIL, NetworkState.ONLINE, "v3.7.2", 0, 12, 1890),
            Reader("LON-LBG-GATE-01", "TFL-UNDERGROUND", "Transport for London", "LONBRIDGE", "London Bridge", "GATE-01", "Concourse", TransportMode.UNDERGROUND, NetworkState.ONLINE, "v3.7.2", 0, 9, 3120),
            Reader("LON-LBG-GATE-02", "TFL-UNDERGROUND", "Transport for London", "LONBRIDGE", "London Bridge", "GATE-02", "Jubilee Line", TransportMode.UNDERGROUND, NetworkState.ONLINE, "v3.7.2", 0, 10, 2980),
            Reader("LON-VIC-GATE-01", "TFL-BUS", "London Buses", "VICTORIA", "Victoria Station", "BUS-VAL-101", "Front Door", TransportMode.BUS, NetworkState.ONLINE, "v3.7.2", 0, 14, 840),
            Reader("MCR-PIC-GATE-01", "MCR-TRAM", "Manchester Metrolink", "MAN_PIC", "Manchester Piccadilly", "TRAM-01", "Platform A", TransportMode.TRAM, NetworkState.ONLINE, "v3.7.2", 0, 15, 620),
            Reader("EDI-WAV-GATE-01", "SCOT-RAIL", "ScotRail Express", "EDINBURGH", "Edinburgh Waverley", "GATE-03", "Main Concourse", TransportMode.RAIL, NetworkState.ONLINE, "v3.7.2", 0, 18, 510),
            Reader("LON-RIV-FERRY-01", "THAMES-FERRY", "Uber Boat by Thames Clippers", "TOWER_PIER", "Tower Pier", "PIER-VAL-01", "Boarding Gate", TransportMode.FERRY, NetworkState.ONLINE, "v3.7.2", 0, 13, 340)
        )
        db.readerDao().insertReaders(demoReaders)

        // Seed initial completed journeys & settlements for live enterprise dashboard display
        seedInitialJourneys()
    }

    private suspend fun seedInitialJourneys() {
        val now = System.currentTimeMillis()
        val journeyId1 = "JRN-${UUID.randomUUID().toString().take(8).uppercase()}"
        val j1 = Journey(
            journeyId = journeyId1,
            credentialId = "CRED-4421",
            status = JourneyStatus.SETTLED,
            startTime = now - 3600000,
            endTime = now - 1800000,
            originStationId = "KINGSCROSS",
            originStationName = "London King's Cross",
            destinationStationId = "LONBRIDGE",
            destinationStationName = "London Bridge",
            rawFareMinor = 420,
            discountMinor = 0,
            capAdjustmentMinor = 0,
            finalFareMinor = 420,
            currency = "GBP",
            legsCount = 1
        )
        db.journeyDao().insertJourney(j1)

        val tap1 = TapEvent("TAP-00091821", "CRED-4421", "LON-KGX-GATE-01", "DEMO-RAIL", "KINGSCROSS", "London King's Cross", TransportMode.RAIL, TapDirection.ENTRY, now - 3600000)
        val tap2 = TapEvent("TAP-00091822", "CRED-4421", "LON-LBG-GATE-01", "TFL-UNDERGROUND", "LONBRIDGE", "London Bridge", TransportMode.UNDERGROUND, TapDirection.EXIT, now - 1800000)
        db.tapDao().insertTaps(listOf(tap1, tap2))

        val entries = ledgerEngine.createTransactionEntries(journeyId1, 420, "DEMO-RAIL", "King's Cross to London Bridge")
        db.ledgerDao().insertLedgerEntries(entries)

        val s1 = Settlement("SET-882101", "DEMO-RAIL", "National Rail UK", 128492100, 3212300, 125279800, "GBP", "SETTLED", now - 86400000, 4120)
        val s2 = Settlement("SET-882102", "TFL-UNDERGROUND", "Transport for London", 245100200, 6127500, 238972700, "GBP", "SETTLED", now - 86400000, 9810)
        db.settlementDao().insertSettlement(s1)
        db.settlementDao().insertSettlement(s2)
    }

    // Process physical Tap
    suspend fun processTap(
        credentialId: String,
        readerId: String,
        isExitOverride: Boolean = false
    ): TapEvent {
        val readers = db.readerDao().getAllReaders().first()
        val reader = readers.find { it.readerId == readerId } ?: readers.first()

        val now = System.currentTimeMillis()
        val isOffline = forceReaderOffline || reader.status == NetworkState.OFFLINE

        val networkState = if (isOffline) NetworkState.OFFLINE else NetworkState.ONLINE
        val tapResult = if (isOffline) TapResult.QUEUED_OFFLINE else TapResult.ACCEPTED

        val tapId = "TAP-${(100000..999999).random()}"

        // Determine direction based on existing active journey
        val activeJourney = db.journeyDao().getActiveJourney(credentialId)
        val direction = when {
            isExitOverride -> TapDirection.EXIT
            activeJourney != null -> TapDirection.EXIT
            reader.mode == TransportMode.BUS || reader.mode == TransportMode.TRAM -> TapDirection.VALIDATION_ONLY
            else -> TapDirection.ENTRY
        }

        val tapEvent = TapEvent(
            tapId = tapId,
            credentialId = credentialId,
            readerId = reader.readerId,
            operatorId = reader.operatorId,
            stationId = reader.stationId,
            stationName = reader.stationName,
            mode = reader.mode,
            direction = direction,
            timestamp = now,
            networkState = networkState,
            result = tapResult
        )

        db.tapDao().insertTap(tapEvent)

        if (isOffline) {
            _offlineQueueDepth.value += 1
            return tapEvent
        }

        // Online processing state machine
        if (direction == TapDirection.ENTRY) {
            val newJourneyId = "JRN-${UUID.randomUUID().toString().take(8).uppercase()}"
            val newJourney = Journey(
                journeyId = newJourneyId,
                credentialId = credentialId,
                status = JourneyStatus.TAPPED_IN,
                startTime = now,
                originStationId = reader.stationId,
                originStationName = reader.stationName,
                legsCount = 1
            )
            db.journeyDao().insertJourney(newJourney)
        } else if (direction == TapDirection.EXIT && activeJourney != null) {
            // Tap Out - Calculate fare, apply caps, process payment, update ledger
            val rawFare = fareEngine.calculateFare(reader.mode, 1, 3, isPeak = true)
            val capResult = cappingEngine.applyDailyCap(380L, rawFare) // e.g. £3.80 already spent today

            val paymentRes = paymentEngine.authorisePayment(credentialId, capResult.finalFare, forceDecline = forcePaymentDecline)

            val journeyStatus = if (paymentRes.isAuthorised) JourneyStatus.PAID else JourneyStatus.EXCEPTION

            val updatedJourney = activeJourney.copy(
                status = journeyStatus,
                endTime = now,
                destinationStationId = reader.stationId,
                destinationStationName = reader.stationName,
                rawFareMinor = capResult.rawFare,
                discountMinor = capResult.discount,
                finalFareMinor = capResult.finalFare
            )
            db.journeyDao().updateJourney(updatedJourney)

            if (paymentRes.isAuthorised) {
                val ledgerEntries = ledgerEngine.createTransactionEntries(
                    transactionId = updatedJourney.journeyId,
                    amountMinor = capResult.finalFare,
                    operatorId = reader.operatorId,
                    reference = "${activeJourney.originStationName} to ${reader.stationName}"
                )
                db.ledgerDao().insertLedgerEntries(ledgerEntries)
            } else {
                db.reconciliationDao().insertException(
                    ReconciliationException(
                        exceptionId = "EXC-${UUID.randomUUID().toString().take(6).uppercase()}",
                        tapId = tapId,
                        journeyId = activeJourney.journeyId,
                        issueType = "PAYMENT_DECLINED",
                        description = paymentRes.declineReason ?: "Card declined at exit gate"
                    )
                )
            }
        }

        return tapEvent
    }

    suspend fun syncOfflineEvents() {
        _offlineQueueDepth.value = 0
        forceReaderOffline = false
    }

    fun setSimSpeed(speed: Int) {
        _simSpeed.value = speed
    }

    fun toggleSimulation() {
        _isSimRunning.value = !_isSimRunning.value
        if (_isSimRunning.value) {
            startSimulationLoop()
        }
    }

    private fun startSimulationLoop() {
        scope.launch {
            while (_isSimRunning.value) {
                val multiplier = _simSpeed.value
                val delayMs = (1000 / multiplier).coerceAtLeast(100).toLong()
                delay(delayMs)

                _tps.value = (75 + (0..17).random()) * multiplier.toDouble()
                _activeJourneysCount.value += (-5..8).random() * multiplier

                // Simulate random tap
                val mockCred = "CRED-${(1000..9999).random()}"
                val mockStations = listOf(
                    "London King's Cross", "London Bridge", "Victoria Station", "Manchester Piccadilly", "Edinburgh Waverley", "Birmingham New Street"
                )
                val randomStation = mockStations.random()
                val tap = TapEvent(
                    tapId = "TAP-${(100000..999999).random()}",
                    credentialId = mockCred,
                    readerId = "LON-KGX-GATE-0${(1..4).random()}",
                    operatorId = if (randomStation.contains("London")) "TFL-UNDERGROUND" else "DEMO-RAIL",
                    stationId = randomStation.take(8).uppercase(),
                    stationName = randomStation,
                    mode = TransportMode.values().toList().random(),
                    direction = if ((0..1).random() == 0) TapDirection.ENTRY else TapDirection.EXIT,
                    timestamp = System.currentTimeMillis()
                )
                db.tapDao().insertTap(tap)
            }
        }
    }

    // Flows for UI
    val allTaps: Flow<List<TapEvent>> = db.tapDao().getAllTaps()
    val allJourneys: Flow<List<Journey>> = db.journeyDao().getAllJourneys()
    val allReaders: Flow<List<Reader>> = db.readerDao().getAllReaders()
    val allCredentials: Flow<List<Credential>> = db.credentialDao().getAllCredentials()
    val allLedgerEntries: Flow<List<LedgerEntry>> = db.ledgerDao().getAllLedgerEntries()
    val allSettlements: Flow<List<Settlement>> = db.settlementDao().getAllSettlements()
    val allExceptions: Flow<List<ReconciliationException>> = db.reconciliationDao().getAllExceptions()
    val allRiskEvents: Flow<List<RiskEvent>> = db.riskDao().getAllRiskEvents()
}
