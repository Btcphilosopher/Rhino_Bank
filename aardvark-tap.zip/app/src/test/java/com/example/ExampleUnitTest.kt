package com.example

import com.example.engine.CappingEngine
import com.example.engine.FareEngine
import com.example.model.TransportMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  private val fareEngine = FareEngine()
  private val cappingEngine = CappingEngine()

  @Test
  fun testBusHopperFare() {
    val fare = fareEngine.calculateFare(TransportMode.BUS, 1, 1, isPeak = false)
    assertEquals(175L, fare) // £1.75
  }

  @Test
  fun testRailPeakZoneFare() {
    val fare = fareEngine.calculateFare(TransportMode.RAIL, 1, 3, isPeak = true)
    assertEquals(525L, fare) // £4.20 * 1.25 = £5.25
  }

  @Test
  fun testDailyCappingEngine() {
    val capRes = cappingEngine.applyDailyCap(accumulatedToday = 840L, proposedFare = 320L)
    assertEquals(320L, capRes.rawFare)
    assertEquals(160L, capRes.finalFare) // £10.00 cap reached: charge £1.60 instead of £3.20
    assertEquals(160L, capRes.discount)
    assertTrue(capRes.capReached)
  }
}
