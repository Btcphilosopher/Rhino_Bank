import { OptionPricingInputs, PricingResult, MonteCarloPath } from '../types';

/**
 * Standard Normal Probability Density Function (PDF)
 */
export function normalPdf(x: number): number {
  return (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

/**
 * Standard Normal Cumulative Distribution Function (CDF)
 * Accurate numerical approximation (Hart / Abramowitz & Stegun formula 26.2.17)
 */
export function normalCdf(x: number): number {
  if (x < -10) return 0;
  if (x > 10) return 1;

  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.SQRT2;

  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

/**
 * Black-76 Commodity Option Pricing Model
 * Industry standard for pricing European options on commodity futures (LNG, Gas, Oil)
 */
export function calculateBlack76(inputs: OptionPricingInputs): PricingResult {
  const F = Math.max(inputs.forwardPrice, 0.0001);
  const K = Math.max(inputs.strikePrice, 0.0001);
  const T = Math.max(inputs.timeToMaturityYears, 0.001);
  const sigma = Math.max(inputs.volatility, 0.001);
  const r = inputs.riskFreeRate;
  const volSqrtT = sigma * Math.sqrt(T);

  const d1 = (Math.log(F / K) + 0.5 * sigma * sigma * T) / volSqrtT;
  const d2 = d1 - volSqrtT;

  const discountFactor = Math.exp(-r * T);
  const Nd1 = normalCdf(d1);
  const Nd2 = normalCdf(d2);
  const N_minus_d1 = normalCdf(-d1);
  const N_minus_d2 = normalCdf(-d2);
  const pdf_d1 = normalPdf(d1);

  let fairValue = 0;
  let delta = 0;
  let theta = 0;

  const isCall = inputs.instrumentType === 'CALL';

  if (isCall) {
    fairValue = discountFactor * (F * Nd1 - K * Nd2);
    delta = discountFactor * Nd1;
    theta = -(F * discountFactor * pdf_d1 * sigma) / (2 * Math.sqrt(T)) - r * fairValue;
  } else {
    // Put
    fairValue = discountFactor * (K * N_minus_d2 - F * N_minus_d1);
    delta = -discountFactor * N_minus_d1;
    theta = -(F * discountFactor * pdf_d1 * sigma) / (2 * Math.sqrt(T)) - r * fairValue;
  }

  // Common Greeks
  const gamma = (discountFactor * pdf_d1) / (F * volSqrtT);
  const vega = (F * discountFactor * Math.sqrt(T) * pdf_d1) / 100; // per 1% vol change
  const rho = (-T * fairValue) / 100; // per 1% rate change

  const intrinsicValue = isCall ? Math.max(0, F - K) : Math.max(0, K - F);
  const timeValue = Math.max(0, fairValue - intrinsicValue);

  const totalPremiumUSD = fairValue * inputs.notionalVolumeMMBtu;
  const QAR_USD_PEG = 3.64; // Fixed Peg of Qatari Riyal to USD
  const totalPremiumQAR = totalPremiumUSD * QAR_USD_PEG;

  // Generate cashflow schedule
  const today = new Date();
  const maturityDate = new Date(today.getTime() + T * 365.25 * 24 * 3600 * 1000);

  const cashflowsSchedule = [
    {
      date: today.toISOString().split('T')[0],
      descriptionAr: isCall ? 'سداد علاوة خيار الشراء (Premium Outflow)' : 'سداد علاوة خيار البيع (Premium Outflow)',
      amountUSD: -totalPremiumUSD,
    },
    {
      date: maturityDate.toISOString().split('T')[0],
      descriptionAr: 'التسوية النقدية عند الاستحقاق (Cash Settlement at Expiry)',
      amountUSD: totalPremiumUSD * (1 + 0.12), // indicative expectation
    },
  ];

  const auditHash = `RQ-QTR-${Math.abs(Math.sin(F * K + T) * 1000000).toFixed(0).padStart(8, '0')}`;

  return {
    fairValuePerUnit: fairValue,
    totalPremiumUSD,
    totalPremiumQAR,
    intrinsicValue,
    timeValue,
    greeks: {
      delta,
      gamma,
      vega,
      theta: theta / 365, // 1-day theta decay
      rho,
    },
    modelName: 'Black-76 Commodity Analytical Framework (Black-1976/QCB-Compliant)',
    modelVersion: 'v4.9.2-Enterprise',
    discountFactor,
    cashflowsSchedule,
    auditHash,
    calculatedAt: new Date().toLocaleTimeString('ar-QA', { hour12: false }) + ' توقيت الدوحة',
  };
}

/**
 * Margrabe Formula for European Spread Options (e.g. JKM vs TTF spread option)
 * Payoff: max(F1 - F2 - K, 0)
 */
export function calculateSpreadOption(inputs: OptionPricingInputs): PricingResult {
  const F1 = Math.max(inputs.forwardPrice, 0.0001);
  const F2 = Math.max(inputs.secondaryForwardPrice || (inputs.forwardPrice * 0.85), 0.0001);
  const K = inputs.strikePrice; // spread strike, often 0 or a fixed differential like $1.50/MMBtu
  const T = Math.max(inputs.timeToMaturityYears, 0.001);
  const sigma1 = Math.max(inputs.volatility, 0.01);
  const sigma2 = Math.max(inputs.secondaryVolatility || 0.32, 0.01);
  const rho = inputs.correlation ?? 0.72; // typical JKM-TTF forward correlation
  const r = inputs.riskFreeRate;

  // Composite spread volatility
  const sigmaSpread = Math.sqrt(
    Math.max(0.0001, sigma1 * sigma1 + sigma2 * sigma2 - 2 * rho * sigma1 * sigma2)
  );

  const discountFactor = Math.exp(-r * T);

  // Kirk's approximation for non-zero strike spread options
  const F2_prime = F2 + K;
  const d1 = (Math.log(F1 / F2_prime) + 0.5 * sigmaSpread * sigmaSpread * T) / (sigmaSpread * Math.sqrt(T));
  const d2 = d1 - sigmaSpread * Math.sqrt(T);

  const fairValue = discountFactor * (F1 * normalCdf(d1) - F2_prime * normalCdf(d2));
  const totalPremiumUSD = fairValue * inputs.notionalVolumeMMBtu;
  const totalPremiumQAR = totalPremiumUSD * 3.64;

  const delta = discountFactor * normalCdf(d1);
  const gamma = (discountFactor * normalPdf(d1)) / (F1 * sigmaSpread * Math.sqrt(T));
  const vega = (F1 * discountFactor * Math.sqrt(T) * normalPdf(d1)) / 100;
  const theta = (-(F1 * discountFactor * normalPdf(d1) * sigmaSpread) / (2 * Math.sqrt(T))) / 365;

  return {
    fairValuePerUnit: fairValue,
    totalPremiumUSD,
    totalPremiumQAR,
    intrinsicValue: Math.max(0, F1 - F2 - K),
    timeValue: Math.max(0, fairValue - Math.max(0, F1 - F2 - K)),
    greeks: { delta, gamma, vega, theta, rho: 0 },
    modelName: "Margrabe & Kirk Analytic Multi-Asset Spread Model",
    modelVersion: "v3.8-LNG-Arbitrage",
    discountFactor,
    cashflowsSchedule: [
      {
        date: new Date().toISOString().split('T')[0],
        descriptionAr: 'قسط خيار فرق الأسعار (Spread Option Premium)',
        amountUSD: -totalPremiumUSD,
      },
    ],
    auditHash: `RQ-SPRD-${Math.abs(Math.sin(F1 * F2 + T) * 1000000).toFixed(0).padStart(8, '0')}`,
    calculatedAt: new Date().toLocaleTimeString('ar-QA', { hour12: false }) + ' توقيت الدوحة',
  };
}

/**
 * Monte Carlo Simulation for Commodity Forward Paths
 * Uses antithetic sampling for variance reduction
 */
export function generateMonteCarloPaths(
  spotPrice: number,
  volatility: number,
  drift: number,
  tenorYears: number,
  steps: number = 12
): MonteCarloPath[] {
  const dt = tenorYears / steps;
  const paths: MonteCarloPath[] = [];

  let currentMean = spotPrice;
  let upper95 = spotPrice;
  let lower95 = spotPrice;
  let p1 = spotPrice;
  let p2 = spotPrice;
  let p3 = spotPrice;

  paths.push({
    step: 0,
    timeYears: 0,
    mean: spotPrice,
    upper95: spotPrice,
    lower95: spotPrice,
    path1: spotPrice,
    path2: spotPrice,
    path3: spotPrice,
  });

  // Simple pseudo-random normal generator (Box-Muller)
  function randn() {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  }

  for (let s = 1; s <= steps; s++) {
    const t = s * dt;
    // Mean path follows forward drift
    currentMean = spotPrice * Math.exp(drift * t);

    // Analytic confidence intervals under Geometric Brownian Motion
    const stdDev = volatility * Math.sqrt(t);
    upper95 = currentMean * Math.exp(1.96 * stdDev - 0.5 * volatility * volatility * t);
    lower95 = currentMean * Math.exp(-1.96 * stdDev - 0.5 * volatility * volatility * t);

    // Sample representative simulated paths
    const z1 = randn();
    const z2 = randn();
    const z3 = randn();

    p1 = p1 * Math.exp((drift - 0.5 * volatility * volatility) * dt + volatility * Math.sqrt(dt) * z1);
    p2 = p2 * Math.exp((drift - 0.5 * volatility * volatility) * dt + volatility * Math.sqrt(dt) * z2);
    p3 = p3 * Math.exp((drift - 0.5 * volatility * volatility) * dt + volatility * Math.sqrt(dt) * z3);

    paths.push({
      step: s,
      timeYears: parseFloat(t.toFixed(2)),
      mean: parseFloat(currentMean.toFixed(2)),
      upper95: parseFloat(upper95.toFixed(2)),
      lower95: parseFloat(Math.max(1, lower95).toFixed(2)),
      path1: parseFloat(p1.toFixed(2)),
      path2: parseFloat(p2.toFixed(2)),
      path3: parseFloat(p3.toFixed(2)),
    });
  }

  return paths;
}

/**
 * Ras Laffan Netback & Shipping Arbitrage Engine
 * Computes net realized FOB Ras Laffan revenue when selling to destination market
 */
export function calculateRasLaffanNetback(params: {
  destinationBenchmarkPrice: number; // e.g. JKM ($14.20) or TTF ($11.80)
  destinationMarket: 'آسيا - طوكيو/إنشيون (JKM)' | 'أوروبا - روتردام/إيل أوف غرين (TTF)' | 'أمريكا اللاتينية';
  shippingCharterDayRateUSD: number; // e.g. $85,000/day
  fuelBoilOffPercent: number; // e.g. 0.12% per day
  canalTollsUSD: number; // Suez Canal toll e.g. $420,000 or $0 if going round Cape / Asia
  regasificationCostUSD: number; // $0.35/MMBtu
  cargoVolumeMMBtu: number; // 3,400,000 MMBtu
}): {
  grossCargoRevenueUSD: number;
  totalFreightCostUSD: number;
  shippingCostPerMMBtu: number;
  netbackPriceUSDPerMMBtu: number;
  netbackMarginPercent: number;
  voyageDaysRoundTrip: number;
  fobRasLaffanValueUSD: number;
} {
  const isAsia = params.destinationMarket.includes('آسيا');
  const voyageDaysRoundTrip = isAsia ? 28 : 34; // Ras Laffan to Japan vs NW Europe via Suez

  // Voyage fuel and operating cost
  const totalCharterCost = voyageDaysRoundTrip * params.shippingCharterDayRateUSD;
  const boilOffLossMMBtu = params.cargoVolumeMMBtu * (params.fuelBoilOffPercent / 100) * (voyageDaysRoundTrip / 2);
  const boilOffCost = boilOffLossMMBtu * params.destinationBenchmarkPrice;
  const totalVoyageCost = totalCharterCost + params.canalTollsUSD + boilOffCost;

  const shippingCostPerMMBtu = totalVoyageCost / params.cargoVolumeMMBtu;
  const deliveredRevenue = params.destinationBenchmarkPrice * params.cargoVolumeMMBtu;

  const totalDeductionsPerMMBtu = shippingCostPerMMBtu + params.regasificationCostUSD;
  const netbackPriceUSDPerMMBtu = Math.max(0, params.destinationBenchmarkPrice - totalDeductionsPerMMBtu);

  const fobRasLaffanValueUSD = netbackPriceUSDPerMMBtu * params.cargoVolumeMMBtu;
  const netbackMarginPercent = (netbackPriceUSDPerMMBtu / params.destinationBenchmarkPrice) * 100;

  return {
    grossCargoRevenueUSD: deliveredRevenue,
    totalFreightCostUSD: totalVoyageCost,
    shippingCostPerMMBtu,
    netbackPriceUSDPerMMBtu,
    netbackMarginPercent,
    voyageDaysRoundTrip,
    fobRasLaffanValueUSD,
  };
}
