import React, { useState } from 'react';
import { X, Send, PlusCircle, Building2, Flame, Clock } from 'lucide-react';
import { InstitutionalClient, BenchmarkQuote, RFQItem } from '../types';

interface NewRfqModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: InstitutionalClient[];
  benchmarks: BenchmarkQuote[];
  onSubmitRfq: (rfq: RFQItem) => void;
}

export const NewRfqModal: React.FC<NewRfqModalProps> = ({
  isOpen,
  onClose,
  clients,
  benchmarks,
  onSubmitRfq,
}) => {
  if (!isOpen) return null;

  const [clientId, setClientId] = useState<string>(clients[0].id);
  const [benchmarkId, setBenchmarkId] = useState<string>('JKM');
  const [instrumentType, setInstrumentType] = useState<string>('مبادلة أسعار غاز (Commodity Swap)');
  const [volumeCargoes, setVolumeCargoes] = useState<number>(1);
  const [tenor, setTenor] = useState<string>('نوفمبر 2026 (شتاء Q4)');
  const [bidPrice, setBidPrice] = useState<number>(14.50);
  const [askPrice, setAskPrice] = useState<number>(14.65);

  const selectedClient = clients.find(c => c.id === clientId) || clients[0];
  const volumeMMBtu = volumeCargoes * 3400000;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newRfq: RFQItem = {
      id: `RFQ-2026-${Date.now().toString().slice(-3)}`,
      clientId,
      clientName: selectedClient.nameAr,
      benchmark: benchmarkId as any,
      instrumentType,
      volumeMMBtu,
      tenor,
      bidPriceUSD: bidPrice,
      askPriceUSD: askPrice,
      bankSpreadUSD: parseFloat((askPrice - bidPrice).toFixed(2)),
      submittedAt: new Date().toLocaleTimeString('ar-QA', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      expiresAt: '16:00:00 بتوقيت الدوحة',
      status: 'طلب جديد (Pending)',
    };

    onSubmitRfq(newRfq);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-[#0b1120] border border-[#C5A059]/40 rounded-lg w-full max-w-lg shadow-2xl overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#080d19]">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-[#C5A059]" />
            <h3 className="text-sm font-bold text-white">إصدار طلب تسعير مؤسسي جديد (New RFQ Ticket)</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">العميل المؤسسي المستهدف</label>
            <select
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white text-xs"
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nameAr} ({c.creditRating}) — الحد المتاح: ${(c.creditLimitUSD / 1000000).toFixed(0)}M
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 mb-1">المؤشر السلعي الأساسي</label>
              <select
                value={benchmarkId}
                onChange={(e) => setBenchmarkId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono text-xs"
              >
                <option value="JKM">Platts JKM ($/MMBtu)</option>
                <option value="TTF">Dutch TTF ($/MMBtu)</option>
                <option value="HENRY_HUB">US Henry Hub ($/MMBtu)</option>
                <option value="BRENT">خام برنت المؤرخ ($/bbl)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">فترة التسليم والاستحقاق</label>
              <input
                type="text"
                value={tenor}
                onChange={(e) => setTenor(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">نوع المشتق والأداة</label>
            <select
              value={instrumentType}
              onChange={(e) => setInstrumentType(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white text-xs"
            >
              <option value="مبادلة أسعار غاز (Commodity Swap)">مبادلة أسعار غاز ثابت مقابل عائم (Swap)</option>
              <option value="خيار شراء أوروبي (Vanilla Call)">خيار شراء أوروبي (Call Option)</option>
              <option value="خيار بيع أوروبي (Vanilla Put)">خيار بيع أوروبي (Put Option)</option>
              <option value="خيار فارق أسعار (JKM - TTF Spread Option)">خيار فارق أسعار (Spread Option)</option>
              <option value="طوق تحوط منعدم التكلفة (Zero-Cost Collar)">طوق تحوط منعدم التكلفة (Collar)</option>
            </select>
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-1">
              <span>حجم الشحنات:</span>
              <span className="font-mono text-white font-bold">{volumeCargoes} شحنة ({volumeMMBtu.toLocaleString()} MMBtu)</span>
            </div>
            <input
              type="range"
              min="1"
              max="6"
              step="1"
              value={volumeCargoes}
              onChange={(e) => setVolumeCargoes(Number(e.target.value))}
              className="w-full accent-[#8A1538]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 font-mono">
            <div>
              <label className="block text-slate-400 mb-1 font-sans">سعر الشراء المقترح (Bid USD)</label>
              <input
                type="number"
                step="0.05"
                value={bidPrice}
                onChange={(e) => setBidPrice(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sky-400 font-bold text-xs"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-sans">سعر البيع المقترح (Ask USD)</label>
              <input
                type="number"
                step="0.05"
                value={askPrice}
                onChange={(e) => setAskPrice(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-amber-400 font-bold text-xs"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-slate-400 hover:text-white bg-slate-800 text-xs"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#590e24] border border-[#C5A059]/40 hover:brightness-110 text-xs flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>إرسال طلب التسعير للدفتر (Submit RFQ)</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
