import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  Download, 
  Filter, 
  Search, 
  Clock, 
  Layers, 
  Send,
  FileCheck,
  ShieldCheck,
  RotateCw
} from 'lucide-react';
import { TradeBlotterItem } from '../types';

interface TradeLifecycleBlotterProps {
  trades: TradeBlotterItem[];
  onUpdateTradeStatus: (tradeId: string, newStatus: TradeBlotterItem['status']) => void;
}

export const TradeLifecycleBlotter: React.FC<TradeLifecycleBlotterProps> = ({
  trades,
  onUpdateTradeStatus,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedTrade, setSelectedTrade] = useState<TradeBlotterItem | null>(trades[0] || null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const filteredTrades = trades.filter((t) => {
    const matchesStatus = filterStatus === 'ALL' || t.status.includes(filterStatus);
    const matchesSearch = 
      t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.counterpartyName.includes(searchTerm) ||
      t.instrumentNameAr.includes(searchTerm);
    return matchesStatus && matchesSearch;
  });

  const totalGrossNotionalUSD = trades.reduce((acc, t) => acc + (t.volumeMMBtu * t.fixedPriceUSD), 0);
  const totalMtmUSD = trades.reduce((acc, t) => acc + t.currentMtmUSD, 0);
  const totalUnrealizedPnlUSD = trades.reduce((acc, t) => acc + t.unrealizedPnlUSD, 0);

  const handleAction = (actionName: string, trade: TradeBlotterItem) => {
    if (actionName === 'MARGIN_CALL') {
      onUpdateTradeStatus(trade.id, 'مطلوب هامش إضافي (Margin Call)');
      setActionNotice(`تم إرسال إشعار طلب هامش إضافي (Margin Call Notice) للطرف المقابل ${trade.counterpartyName}.`);
    } else if (actionName === 'SETTLE') {
      onUpdateTradeStatus(trade.id, 'تمت التسوية (Settled)');
      setActionNotice(`تم تسوية العقد ${trade.id} وإصدار إشعار المطابقة والتسوية النهائية.`);
    } else if (actionName === 'FIX') {
      setActionNotice(`تم تثبيت سعر التسوية الدوري (Fixing Processed) للعقد ${trade.id}.`);
    }
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleExportCSV = () => {
    const headers = ['Trade_ID', 'Counterparty', 'Instrument', 'Direction', 'Volume_MMBtu', 'Price_USD', 'MTM_USD', 'Status'];
    const rows = filteredTrades.map(t => [
      t.id,
      t.counterpartyName,
      t.instrumentType,
      t.direction,
      t.volumeMMBtu,
      t.fixedPriceUSD,
      t.currentMtmUSD,
      t.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `trade_blotter_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div>
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-[#C5A059]" />
            <h2 className="text-base font-bold text-white">
              إدارة دورة حياة الصفقات ودفتر التداول (Trade Lifecycle & Blotter)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            متابعة الصفقات النشطة، والتأكيدات الإلكترونية ISDA، وتثبيت الأسعار، وطلبات الهامش الإضافي والتسويات النقدية النهائية.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-3.5 py-2 rounded text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors text-xs flex items-center gap-2 font-mono shrink-0"
        >
          <Download className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>تصدير الدفتر (Export CSV)</span>
        </button>
      </div>

      {actionNotice && (
        <div className="bg-emerald-950/40 border border-emerald-600/50 p-4 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Portfolio Totals Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">إجمالي القيمة الاسمية المفتوحة (Open Notional)</div>
          <div className="text-xl font-bold text-white mt-1 tabular-nums">
            ${(totalGrossNotionalUSD / 1000000).toFixed(1)}M USD
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">القيمة السوقية العادلة الحالية (Current MTM)</div>
          <div className="text-xl font-bold text-emerald-400 mt-1 tabular-nums">
            +${(totalMtmUSD / 1000000).toFixed(2)}M USD
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">الأرباح والخسائر غير المحققة (Unrealized P&L)</div>
          <div className="text-xl font-bold text-emerald-400 mt-1 tabular-nums">
            +${(totalUnrealizedPnlUSD / 1000000).toFixed(2)}M USD
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#0b1120] border border-slate-800 p-3 rounded text-xs">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Search className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <input
            type="text"
            placeholder="البحث برقم الصفقة، الطرف المقابل، أو المشتق..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-white text-xs w-full sm:w-80 focus:outline-none focus:border-[#C5A059]"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
          {['ALL', 'Confirmed', 'Active', 'Margin Call', 'Settled'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1 rounded text-xs font-mono transition-colors whitespace-nowrap ${
                filterStatus === st
                  ? 'bg-[#8A1538] text-white font-bold'
                  : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
              }`}
            >
              {st === 'ALL' ? 'الكل' : st}
            </button>
          ))}
        </div>
      </div>

      {/* Blotter Data Table */}
      <div className="bg-[#0b1120] border border-slate-800 rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-right tabular-nums">
            <thead>
              <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-sans text-[11px]">
                <th className="py-2.5 px-3 text-right">رقم الصفقة</th>
                <th className="py-2.5 px-3 text-right">الطرف المقابل</th>
                <th className="py-2.5 px-3 text-right">الأداة / العقد</th>
                <th className="py-2.5 px-3 text-right">الاتجاه</th>
                <th className="py-2.5 px-3 text-right">الحجم (MMBtu)</th>
                <th className="py-2.5 px-3 text-right">سعر التنفيذ</th>
                <th className="py-2.5 px-3 text-right">القيمة السوقية (MTM)</th>
                <th className="py-2.5 px-3 text-right">حالة دورة الحياة</th>
                <th className="py-2.5 px-3 text-center">إجراءات مصرفية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {filteredTrades.map((trade) => {
                const isSelected = selectedTrade?.id === trade.id;
                const isMarginCall = trade.status.includes('Margin Call');
                return (
                  <tr
                    key={trade.id}
                    onClick={() => setSelectedTrade(trade)}
                    className={`hover:bg-slate-800/40 transition-colors cursor-pointer ${
                      isSelected ? 'bg-slate-800/60' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 font-bold text-white">{trade.id}</td>
                    <td className="py-2.5 px-3 font-sans text-slate-300">{trade.counterpartyName}</td>
                    <td className="py-2.5 px-3 text-slate-300 font-sans">{trade.instrumentNameAr}</td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        trade.direction.includes('شراء') ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'
                      }`}>
                        {trade.direction}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">{trade.volumeMMBtu.toLocaleString()}</td>
                    <td className="py-2.5 px-3 font-bold text-[#C5A059]">${trade.fixedPriceUSD.toFixed(2)}</td>
                    <td className={`py-2.5 px-3 font-bold ${trade.currentMtmUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {trade.currentMtmUSD >= 0 ? '+' : ''}${(trade.currentMtmUSD / 1000).toFixed(0)}k
                    </td>
                    <td className="py-2.5 px-3 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        isMarginCall
                          ? 'bg-rose-950/80 text-rose-400 border border-rose-800 font-bold'
                          : 'bg-slate-800 text-slate-300'
                      }`}>
                        {trade.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleAction('MARGIN_CALL', trade)}
                          title="طلب هامش إضافي"
                          className="p-1 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 transition-colors"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleAction('FIX', trade)}
                          title="تثبيت السعر الدوري (Fixing)"
                          className="p-1 rounded bg-slate-800 hover:bg-sky-950 text-slate-400 hover:text-sky-300 transition-colors"
                        >
                          <RotateCw className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleAction('SETTLE', trade)}
                          title="تسوية العقد نهائياً"
                          className="p-1 rounded bg-slate-800 hover:bg-emerald-950 text-slate-400 hover:text-emerald-300 transition-colors"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed Trade Ticket Modal / Panel */}
      {selectedTrade && (
        <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">
                تفاصيل عقد المشتق المصرفي: {selectedTrade.id} ({selectedTrade.counterpartyName})
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">
              المتداول المسؤول: {selectedTrade.traderId}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 font-sans">تاريخ التداول (Deal Date)</div>
              <div className="text-white font-bold mt-1">{selectedTrade.dealDate}</div>
            </div>
            <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 font-sans">تاريخ التسوية (Value Date)</div>
              <div className="text-white font-bold mt-1">{selectedTrade.valueDate}</div>
            </div>
            <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 font-sans">تاريخ الاستحقاق (Maturity)</div>
              <div className="text-white font-bold mt-1">{selectedTrade.maturityDate}</div>
            </div>
            <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400 font-sans">معتمد من إدارة المخاطر</div>
              <div className="text-emerald-400 font-bold mt-1">{selectedTrade.riskApprovedBy}</div>
            </div>
          </div>

          <div className="bg-slate-900/60 p-3 rounded border border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>الهامش المطلوب: <strong className="text-white font-mono">${(selectedTrade.marginRequiredUSD / 1000).toFixed(0)}k</strong></span>
            <span>الضمانات المودعة: <strong className="text-emerald-400 font-mono">${(selectedTrade.collateralPostedUSD / 1000).toFixed(0)}k</strong></span>
            <span>التوثيق القانوني: <strong className="text-slate-200">ISDA 2002 Master Agreement & CSA</strong></span>
          </div>
        </div>
      )}

    </div>
  );
};
