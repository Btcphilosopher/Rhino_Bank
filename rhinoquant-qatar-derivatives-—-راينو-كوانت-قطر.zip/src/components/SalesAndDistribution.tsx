import React, { useState } from 'react';
import { 
  Users, 
  Building2, 
  ShieldCheck, 
  DollarSign, 
  Clock, 
  Send, 
  CheckCircle2, 
  PlusCircle, 
  Filter, 
  Search,
  ArrowUpRight,
  ArrowDownLeft,
  AlertTriangle
} from 'lucide-react';
import { InstitutionalClient, RFQItem, TradeBlotterItem } from '../types';

interface SalesAndDistributionProps {
  clients: InstitutionalClient[];
  rfqs: RFQItem[];
  onQuoteRfq: (rfqId: string, bid: number, ask: number) => void;
  onExecuteRfq: (rfq: RFQItem) => void;
  onOpenNewRfqModal: () => void;
}

export const SalesAndDistribution: React.FC<SalesAndDistributionProps> = ({
  clients,
  rfqs,
  onQuoteRfq,
  onExecuteRfq,
  onOpenNewRfqModal,
}) => {
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0].id);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [quotedSuccessMessage, setQuotedSuccessMessage] = useState<string | null>(null);

  const selectedClient = clients.find(c => c.id === selectedClientId) || clients[0];

  const filteredClients = clients.filter(c => 
    c.nameAr.includes(searchTerm) || c.nameEn.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleQuickQuote = (rfq: RFQItem) => {
    onQuoteRfq(rfq.id, rfq.bidPriceUSD, rfq.askPriceUSD);
    setQuotedSuccessMessage(`تم تسعير طلب العميل (${rfq.clientName}) وإرسال العرض التجاري المعتمد.`);
    setTimeout(() => setQuotedSuccessMessage(null), 4000);
  };

  const handleExecuteDeal = (rfq: RFQItem) => {
    onExecuteRfq(rfq);
    setQuotedSuccessMessage(`تم تنفيذ الصفقة للعميل (${rfq.clientName}) بنجاح وتحويلها إلى سجل الصفقات (Blotter).`);
    setTimeout(() => setQuotedSuccessMessage(null), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Sales Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#C5A059]" />
            <h2 className="text-base font-bold text-white">
              المبيعات والتوزيع المؤسسي وإدارة العملاء (Sales & Distribution CRM)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            إدارة علاقات كبار المستهلكين والمشترين العالميين للغاز الطبيعي المسال، ومراقبة الحدود الائتمانية لمصرف قطر المركزي، وإصدار عروض الأسعار (RFQ).
          </p>
        </div>

        <button
          onClick={onOpenNewRfqModal}
          className="px-4 py-2 rounded font-bold text-xs text-white bg-gradient-to-r from-[#8A1538] to-[#590e24] border border-[#C5A059]/40 hover:brightness-110 flex items-center gap-2 shrink-0"
        >
          <PlusCircle className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>إنشاء طلب تسعير مؤسسي جديد (New RFQ)</span>
        </button>
      </div>

      {quotedSuccessMessage && (
        <div className="bg-emerald-950/40 border border-emerald-600/50 p-4 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{quotedSuccessMessage}</span>
        </div>
      )}

      {/* Main CRM Grid: Client Directory + Active RFQ Workflow */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 Cols): Institutional Client Directory */}
        <div className="lg:col-span-5 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#C5A059]" />
              <span>دليل الشركات والمشترين المؤسسيين</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">{clients.length} عملاء معتمدين</span>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute right-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="البحث بالاسم أو الدولة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded pr-9 pl-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#C5A059]"
            />
          </div>

          {/* Client List */}
          <div className="space-y-2 max-h-[460px] overflow-y-auto">
            {filteredClients.map((client) => {
              const isSelected = client.id === selectedClientId;
              const usedPercent = (client.creditUsedUSD / client.creditLimitUSD) * 100;
              return (
                <div
                  key={client.id}
                  onClick={() => setSelectedClientId(client.id)}
                  className={`p-3.5 rounded border transition-all cursor-pointer text-xs ${
                    isSelected
                      ? 'bg-slate-800/80 border-[#C5A059]'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-white">{client.nameAr}</div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">{client.jurisdiction}</div>
                    </div>
                    <span className="font-mono font-bold text-xs px-1.5 py-0.5 rounded bg-slate-800 text-[#C5A059] border border-slate-700">
                      {client.creditRating}
                    </span>
                  </div>

                  {/* Credit Bar */}
                  <div className="mt-2.5 space-y-1">
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                      <span>استخدام الحد الائتماني:</span>
                      <span>${(client.creditUsedUSD / 1000000).toFixed(0)}M / ${(client.creditLimitUSD / 1000000).toFixed(0)}M ({usedPercent.toFixed(0)}%)</span>
                    </div>
                    <div className="w-full bg-slate-950 h-1.5 rounded overflow-hidden">
                      <div
                        className={`h-full rounded ${usedPercent > 80 ? 'bg-rose-500' : usedPercent > 50 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                        style={{ width: `${Math.min(100, usedPercent)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (7 Cols): Selected Client Profile & RFQ Negotiation Board */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Detailed Client Dossier */}
          {selectedClient && (
            <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white">{selectedClient.nameAr}</h3>
                    <span className="text-[10px] text-emerald-400 font-mono px-2 py-0.5 rounded bg-emerald-950/40 border border-emerald-800/40">
                      {selectedClient.kycAmlStatus}
                    </span>
                  </div>
                  <div className="text-xs text-[#C5A059] font-mono mt-0.5">{selectedClient.nameEn}</div>
                </div>

                <div className="text-left font-mono text-xs">
                  <div className="text-slate-400">التصنيف الرقابي:</div>
                  <div className="text-white font-sans font-semibold">{selectedClient.qcbRegulatoryTier}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">الحد الائتماني الإجمالي</div>
                  <div className="text-sm font-bold text-white mt-1">
                    ${(selectedClient.creditLimitUSD / 1000000).toFixed(0)}M USD
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">الرصيد المتاح للتعاقد</div>
                  <div className="text-sm font-bold text-emerald-400 mt-1">
                    ${((selectedClient.creditLimitUSD - selectedClient.creditUsedUSD) / 1000000).toFixed(0)}M USD
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">فائض الهامش المتاح</div>
                  <div className="text-sm font-bold text-sky-400 mt-1">
                    ${(selectedClient.marginAvailableUSD / 1000000).toFixed(0)}M USD
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">عملة التسوية</div>
                  <div className="text-sm font-bold text-[#C5A059] mt-1 font-mono">
                    {selectedClient.settlementCurrency}
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-400 flex items-center justify-between pt-1">
                <span>المقر الرئيسي: <strong className="text-slate-200 font-sans">{selectedClient.headquarters}</strong></span>
                <span>جهة الاتصال: <strong className="text-slate-200 font-sans">{selectedClient.primaryContact}</strong></span>
              </div>
            </div>
          )}

          {/* Institutional RFQ Management Table */}
          <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#C5A059]" />
                <span>طلبات عروض الأسعار النشطة (Institutional RFQ Desk)</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">جلسة تداول الدوحة</span>
            </div>

            <div className="space-y-3">
              {rfqs.map((rfq) => (
                <div key={rfq.id} className="bg-slate-900/90 border border-slate-800 p-4 rounded text-xs space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-300">{rfq.id}</span>
                        <span className="font-semibold text-white">· {rfq.clientName}</span>
                      </div>
                      <div className="text-slate-400 font-mono text-[11px] mt-0.5">
                        {rfq.instrumentType} · {rfq.tenor}
                      </div>
                    </div>

                    <div className="text-left font-mono">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-[#C5A059] border border-slate-700">
                        {rfq.status}
                      </span>
                      <div className="text-[10px] text-slate-500 mt-1">تنتهي: {rfq.expiresAt}</div>
                    </div>
                  </div>

                  {/* Pricing Details */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px] bg-slate-950 p-2.5 rounded border border-slate-800/80">
                    <div>
                      <span className="text-slate-500 font-sans">الحجم الاسمي:</span>
                      <div className="text-slate-200 font-bold">{rfq.volumeMMBtu.toLocaleString()} MMBtu</div>
                    </div>
                    <div>
                      <span className="text-slate-500 font-sans">سعر الشراء (Bid):</span>
                      <div className="text-sky-400 font-bold">${rfq.bidPriceUSD.toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-slate-500 font-sans">سعر البيع (Ask):</span>
                      <div className="text-amber-400 font-bold">${rfq.askPriceUSD.toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-slate-500 font-sans">هامش البنك:</span>
                      <div className="text-emerald-400 font-bold">+${rfq.bankSpreadUSD.toFixed(2)}</div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex justify-end gap-2 pt-1">
                    {rfq.status !== 'معتمد ومُنفذ (Executed)' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => handleQuickQuote(rfq)}
                          className="px-3 py-1.5 rounded font-bold text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors text-xs flex items-center gap-1.5 font-mono"
                        >
                          <Send className="w-3 h-3 text-[#C5A059]" />
                          <span>إرسال تسعير العرض (Quote Bid/Ask)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleExecuteDeal(rfq)}
                          className="px-3.5 py-1.5 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#590e24] hover:brightness-110 transition-all text-xs flex items-center gap-1.5 border border-[#C5A059]/40"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#C5A059]" />
                          <span>اعتماد وتنفيذ الصفقة (Execute)</span>
                        </button>
                      </>
                    ) : (
                      <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تم تنفيذ وتأكيد الصفقة إلكترونياً</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
