import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Clock, 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  ShieldCheck, 
  Search, 
  PlusCircle,
  FileCheck,
  ChevronDown
} from 'lucide-react';
import { BenchmarkQuote } from '../types';

interface HeaderProps {
  benchmarks: BenchmarkQuote[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  onOpenNewRfq: () => void;
  onOpenScenarioModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  benchmarks,
  activeTab,
  onTabChange,
  onOpenNewRfq,
  onOpenScenarioModal,
}) => {
  const [dohaTime, setDohaTime] = useState('');
  const [londonTime, setLondonTime] = useState('');
  const [singaporeTime, setSingaporeTime] = useState('');
  const [marketStatus, setMarketStatus] = useState('الجلسة نشطة (Active)');

  useEffect(() => {
    const updateTimes = () => {
      const now = new Date();
      setDohaTime(now.toLocaleTimeString('en-GB', { timeZone: 'Asia/Qatar', hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setLondonTime(now.toLocaleTimeString('en-GB', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit' }));
      setSingaporeTime(now.toLocaleTimeString('en-GB', { timeZone: 'Asia/Singapore', hour: '2-digit', minute: '2-digit' }));
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-[#070b14] border-b border-slate-800 text-slate-100 shadow-md">
      {/* Zone 1-2-3 Top Bar Contract */}
      <div className="flex items-center justify-between gap-6 px-6 py-3 border-b border-slate-800/80">
        
        {/* Zone 1: Single Brand Lockup with Qatar Maroon & Gold Accents */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded bg-gradient-to-br from-[#8A1538] via-[#5c0d24] to-[#0d131f] border border-[#C5A059]/40 flex items-center justify-center shadow-sm">
            <span className="text-[#C5A059] font-bold text-sm tracking-wider">RQ</span>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-white font-['Plus_Jakarta_Sans',sans-serif]">
                RhinoQuant Qatar
              </span>
              <span className="text-xs font-semibold text-[#C5A059] px-1.5 py-0.5 rounded bg-[#C5A059]/10 border border-[#C5A059]/20">
                راينو كوانت قطر
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              المنصة المصرفية المؤسسية للمشتقات والغاز الطبيعي المسال
            </span>
          </div>
        </div>

        {/* Global Clocks & Market Connectivity Strip */}
        <div className="hidden lg:flex items-center gap-4 text-xs font-mono text-slate-400 bg-slate-900/60 px-3 py-1.5 rounded border border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">الدوحة:</span>
            <span className="text-white font-semibold tabular-nums">{dohaTime}</span>
            <span className="text-[10px] text-slate-500">AST</span>
          </div>
          <span className="text-slate-700">·</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">لندن:</span>
            <span className="text-slate-300 tabular-nums">{londonTime}</span>
            <span className="text-[10px] text-slate-500">BST</span>
          </div>
          <span className="text-slate-700">·</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">سنغافورة:</span>
            <span className="text-slate-300 tabular-nums">{singaporeTime}</span>
            <span className="text-[10px] text-slate-500">SGT</span>
          </div>
          <span className="text-slate-700">·</span>
          <div className="flex items-center gap-1.5">
            <span className="text-emerald-400 font-sans text-[11px]">{marketStatus}</span>
          </div>
        </div>

        {/* Zone 3: Primary Action & Quick Scenarios */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenScenarioModal}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-[#C5A059] bg-[#C5A059]/10 border border-[#C5A059]/30 rounded hover:bg-[#C5A059]/20 transition-colors whitespace-nowrap"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>سيناريوهات الاعتماد (Scenarios 1-4)</span>
          </button>

          <button
            onClick={onOpenNewRfq}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-[#8A1538] to-[#a31a43] rounded hover:brightness-110 transition-all shadow-sm border border-rose-900/40 whitespace-nowrap"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>طلب تسعير مؤسسي (RFQ)</span>
          </button>
        </div>
      </div>

      {/* Real-time Benchmark Ticker Ribbon */}
      <div className="bg-[#0b101c] px-6 py-1.5 border-b border-slate-800/60 overflow-x-auto flex items-center gap-6 text-xs whitespace-nowrap text-slate-300">
        <div className="flex items-center gap-2 text-slate-400 font-medium shrink-0">
          <Activity className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>مؤشرات الطاقة والغاز:</span>
        </div>

        <div className="flex items-center gap-5">
          {benchmarks.map((b) => {
            const isPositive = b.changePercent >= 0;
            return (
              <div key={b.id} className="flex items-center gap-2 font-mono text-[11px] tabular-nums">
                <span className="font-semibold text-slate-200">{b.symbol}</span>
                <span className="text-white font-medium">
                  {b.category === 'SHIPPING' 
                    ? `$${b.spotPrice.toLocaleString()}` 
                    : b.category === 'RATES' 
                    ? `${b.spotPrice.toFixed(2)}%`
                    : `$${b.spotPrice.toFixed(2)}`}
                </span>
                <span className={`flex items-center gap-0.5 text-[10px] ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {isPositive ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
                  {isPositive ? '+' : ''}{b.changePercent.toFixed(2)}%
                </span>
                <span className="text-slate-700">|</span>
              </div>
            );
          })}
        </div>

        <div className="mr-auto flex items-center gap-3 text-[11px] text-slate-400 font-sans shrink-0">
          <span>المركزي القطري: <strong className="text-slate-200 font-mono">QCB 5.75%</strong></span>
          <span className="text-slate-700">·</span>
          <span>ربط الريال بالدولار: <strong className="text-slate-200 font-mono">3.64 QAR</strong></span>
        </div>
      </div>
    </header>
  );
};
