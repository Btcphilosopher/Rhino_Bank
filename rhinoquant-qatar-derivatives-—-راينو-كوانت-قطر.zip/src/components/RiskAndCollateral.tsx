import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Activity, 
  TrendingDown, 
  AlertTriangle, 
  Scale, 
  CheckCircle2, 
  PieChart, 
  DollarSign, 
  Sliders,
  Flame,
  FileCheck
} from 'lucide-react';
import { StressScenario, CollateralItem } from '../types';

interface RiskAndCollateralProps {
  scenarios: StressScenario[];
  collateralList: CollateralItem[];
}

export const RiskAndCollateral: React.FC<RiskAndCollateralProps> = ({
  scenarios,
  collateralList,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(scenarios[0].id);
  const [activeTab, setActiveTab] = useState<'STRESS_TESTS' | 'COLLATERAL_MARGIN'>('STRESS_TESTS');

  const activeScenario = scenarios.find(s => s.id === selectedScenarioId) || scenarios[0];

  const totalCollateralEligibleUSD = collateralList.reduce((acc, c) => acc + c.eligibleCollateralValueUSD, 0);
  const totalNominalCollateralUSD = collateralList.reduce((acc, c) => acc + c.nominalValueUSD, 0);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-500" />
            <h2 className="text-base font-bold text-white">
              إدارة المخاطر المصرفية والضمانات (RhinoQuant Risk Intelligence & Collateral)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            مراقبة القيمة المعرضة للمخاطر (VaR 99%)، وحساسيات اليونانيات المجمعة، ومحاكاة اختبارات الضغط القصوى (Stress Testing)، وإدارة الهامش والخصومات المصرفية (Haircuts) على الضمانات السيادية.
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded text-xs shrink-0 font-mono">
          <button
            onClick={() => setActiveTab('STRESS_TESTS')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'STRESS_TESTS' ? 'bg-[#8A1538] text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            اختبارات الضغط (Stress Tests)
          </button>
          <button
            onClick={() => setActiveTab('COLLATERAL_MARGIN')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'COLLATERAL_MARGIN' ? 'bg-[#8A1538] text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            إدارة الضمانات والهامش (Collateral)
          </button>
        </div>
      </div>

      {/* Portfolio Risk Core Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">القيمة المعرضة للمخاطر (1-Day VaR 99%)</div>
          <div className="text-xl font-bold text-amber-400 mt-1 tabular-nums">
            $4,820,000 USD
          </div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">المنهجية البارامترية مع أوزان تاريخية</div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">العجز المتوقع في الذيل (Expected Shortfall / CVaR)</div>
          <div className="text-xl font-bold text-rose-400 mt-1 tabular-nums">
            $6,740,000 USD
          </div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">متوسط الخسارة في أسوأ 1% من الأيام</div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">إجمالي الضمانات المؤهلة (Eligible Collateral)</div>
          <div className="text-xl font-bold text-emerald-400 mt-1 tabular-nums">
            ${(totalCollateralEligibleUSD / 1000000).toFixed(1)}M USD
          </div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">بعد تطبيق نسب الحسم (Haircuts)</div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-sans">نسبة تغطية الهامش الإجمالية (Margin Coverage)</div>
          <div className="text-xl font-bold text-white mt-1 tabular-nums">
            126.8%
          </div>
          <div className="text-[10px] text-emerald-400 font-sans mt-1">فائض أمان ائتماني +26.8% فوق متطلب بازل</div>
        </div>
      </div>

      {activeTab === 'STRESS_TESTS' ? (
        /* Stress Testing View */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column (5 Cols): Scenario Selector */}
          <div className="lg:col-span-5 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#C5A059]" />
                <span>سيناريوهات الأزمات والضغط المعتمدة</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">QCB Macro Stress</span>
            </div>

            <div className="space-y-2">
              {scenarios.map((sc) => {
                const isSelected = sc.id === selectedScenarioId;
                return (
                  <div
                    key={sc.id}
                    onClick={() => setSelectedScenarioId(sc.id)}
                    className={`p-3.5 rounded border transition-all cursor-pointer text-xs ${
                      isSelected
                        ? 'bg-slate-800/90 border-[#C5A059] shadow-sm'
                        : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-bold text-white leading-snug">{sc.nameAr}</div>
                        <div className="text-[11px] text-[#C5A059] font-mono mt-0.5">{sc.nameEn}</div>
                      </div>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                        sc.probabilityScore === 'مرتفعة' ? 'bg-rose-950 text-rose-400' : 'bg-slate-800 text-slate-300'
                      }`}>
                        احتمالية {sc.probabilityScore}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800/60 font-mono text-[11px]">
                      <span className="text-slate-400 font-sans">الأثر الصافي على المحفظة:</span>
                      <span className={`font-bold ${sc.portfolioImpactUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {sc.portfolioImpactUSD >= 0 ? '+' : ''}${(sc.portfolioImpactUSD / 1000000).toFixed(1)}M USD
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column (7 Cols): Scenario Deep Dive & Factor Shocks */}
          <div className="lg:col-span-7 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">{activeScenario.nameAr}</h3>
                <div className="text-xs text-[#C5A059] font-mono mt-0.5">{activeScenario.nameEn}</div>
              </div>
              <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/40">
                {activeScenario.id}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3.5 rounded border border-slate-800">
              {activeScenario.descriptionAr}
            </p>

            {/* Shock Factor Table */}
            <div>
              <div className="text-xs font-bold text-slate-300 mb-2 font-sans">
                صدمات عوامل السوق المفترضة (Applied Market Shocks):
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 font-mono text-xs">
                
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">مؤشر آسيا (JKM Shock)</div>
                  <div className={`text-base font-bold mt-1 ${activeScenario.jkmShockPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {activeScenario.jkmShockPercent >= 0 ? '+' : ''}{activeScenario.jkmShockPercent}%
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">مؤشر أوروبا (TTF Shock)</div>
                  <div className={`text-base font-bold mt-1 ${activeScenario.ttfShockPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {activeScenario.ttfShockPercent >= 0 ? '+' : ''}{activeScenario.ttfShockPercent}%
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">أجور الشحن (Freight Shock)</div>
                  <div className={`text-base font-bold mt-1 ${activeScenario.freightShockPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {activeScenario.freightShockPercent >= 0 ? '+' : ''}{activeScenario.freightShockPercent}%
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">خام برنت (Oil Shock)</div>
                  <div className={`text-base font-bold mt-1 ${activeScenario.oilShockPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {activeScenario.oilShockPercent >= 0 ? '+' : ''}{activeScenario.oilShockPercent}%
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">غاز أمريكا (Henry Hub)</div>
                  <div className={`text-base font-bold mt-1 ${activeScenario.henryHubShockPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {activeScenario.henryHubShockPercent >= 0 ? '+' : ''}{activeScenario.henryHubShockPercent}%
                  </div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">سعر صرف USD/EUR</div>
                  <div className="text-base font-bold mt-1 text-slate-200">
                    {activeScenario.fxShockUsdEurPercent >= 0 ? '+' : ''}{activeScenario.fxShockUsdEurPercent}%
                  </div>
                </div>

              </div>
            </div>

            {/* Impact Output Summary */}
            <div className="bg-slate-900/90 border border-slate-800 p-4 rounded space-y-2 font-mono">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-sans">الأثر المالي المتوقع على ربحية المحفظة:</span>
                <span className={`text-base font-bold ${activeScenario.portfolioImpactUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {activeScenario.portfolioImpactUSD >= 0 ? '+' : ''}${(activeScenario.portfolioImpactUSD / 1000000).toFixed(2)}M USD
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-sans">طلبات الهامش الإضافي المتوقعة (Margin Calls):</span>
                <span className="text-amber-400 font-bold">
                  ${(activeScenario.marginCallRequiredUSD / 1000000).toFixed(2)}M USD
                </span>
              </div>
              <div className="flex justify-between items-center text-xs border-t border-slate-800/80 pt-2 text-slate-400 font-sans">
                <span>توصية إدارة المخاطر:</span>
                <span className="text-white font-semibold">
                  {activeScenario.portfolioImpactUSD < -10000000 
                    ? 'زيادة نسبة التحوط على عقود الشحن بنسبة 25% فوراً'
                    : 'الوضع تحت السيطرة ضمن حدود رأس المال التنظيمي المعتمد'}
                </span>
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* Collateral & Margin Management View */
        <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Scale className="w-4 h-4 text-[#C5A059]" />
                <span>إدارة الضمانات المؤهلة وحسابات هوامش المشتقات (Eligible Collateral)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                تطبيق نسب الخصم الرسمية (Haircuts) وفقاً لمعايير مصرف قطر المركزي وبنك التسويات الدولية (BIS/IOSCO).
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-right tabular-nums">
              <thead>
                <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-sans text-[11px]">
                  <th className="py-2.5 px-3 text-right">رقم الضمان</th>
                  <th className="py-2.5 px-3 text-right">الطرف المقابل</th>
                  <th className="py-2.5 px-3 text-right">نوع الأصل المرهون</th>
                  <th className="py-2.5 px-3 text-right">القيمة الاسمية</th>
                  <th className="py-2.5 px-3 text-right">نسبة الخصم (Haircut)</th>
                  <th className="py-2.5 px-3 text-right">القيمة المؤهلة الصافية</th>
                  <th className="py-2.5 px-3 text-right">نسبة تغطية الهامش</th>
                  <th className="py-2.5 px-3 text-right">حالة التغطية</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {collateralList.map((col) => {
                  const isDeficit = col.status.includes('Deficit');
                  return (
                    <tr key={col.id} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-3 font-bold text-white">{col.id}</td>
                      <td className="py-2.5 px-3 font-sans text-slate-300">{col.counterparty}</td>
                      <td className="py-2.5 px-3 font-sans">
                        {col.assetType === 'QATAR_GOV_BOND' && 'سندات سيادية قطرية 10 سنوات'}
                        {col.assetType === 'CASH_USD' && 'نقد بالدولار الأمريكي (Cash USD)'}
                        {col.assetType === 'CASH_QAR' && 'نقد بالريال القطري (Cash QAR)'}
                        {col.assetType === 'LETTER_OF_CREDIT' && 'خطاب ضمان مصرفي معتمد (LC)'}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-white">${(col.nominalValueUSD / 1000000).toFixed(1)}M</td>
                      <td className="py-2.5 px-3 text-amber-400 font-bold">{col.haircutPercent.toFixed(1)}%</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-400">${(col.eligibleCollateralValueUSD / 1000000).toFixed(2)}M</td>
                      <td className="py-2.5 px-3 font-bold">{col.marginCoverageRatioPercent.toFixed(1)}%</td>
                      <td className="py-2.5 px-3 font-sans">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          isDeficit ? 'bg-rose-950 text-rose-400 border border-rose-800 font-bold' : 'bg-emerald-950 text-emerald-400'
                        }`}>
                          {col.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
