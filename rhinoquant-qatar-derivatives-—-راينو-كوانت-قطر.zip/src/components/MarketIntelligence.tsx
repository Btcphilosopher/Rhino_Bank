import React, { useState } from 'react';
import { 
  Globe2, 
  Flame, 
  Ship, 
  TrendingUp, 
  CheckCircle2, 
  Filter, 
  Activity, 
  Building2, 
  Compass,
  FileText
} from 'lucide-react';
import { MarketNewsItem } from '../types';

interface MarketIntelligenceProps {
  news: MarketNewsItem[];
}

export const MarketIntelligence: React.FC<MarketIntelligenceProps> = ({ news }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const filteredNews = selectedCategory === 'ALL'
    ? news
    : news.filter(n => n.category.includes(selectedCategory));

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div>
          <div className="flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-[#C5A059]" />
            <h2 className="text-base font-bold text-white">
              استخبارات الطاقة وأخبار الأسواق العالمية (RhinoQuant Market Intelligence)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            متابعة فورية وموثقة لتطورات توسعة حقل الشمال القطري، وحركة أساطيل شحن الغاز، ومعدلات امتلاء الخزانات الأوروبية، ومؤشرات الطلب الفوري في آسيا.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">تحديث المصادر:</span>
          <span className="text-emerald-400 font-bold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
            مباشر وموثق
          </span>
        </div>
      </div>

      {/* Strategic Energy Capacity Dashboard (Qatar Expansion Progress) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-sans">طاقة إنتاج الغاز المسال الحالية (قطر)</span>
            <span className="text-[10px] text-emerald-400 font-mono">الأساس التشغيلي</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            77.0 <span className="text-xs text-slate-400 font-sans">مليون طن سنوياً (MTPA)</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            14 خط إسالة عملاق تعمل بأقصى كفاءة في مدينة رأس لفان الصناعية
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-sans">هدف توسعة حقل الشمال (NFE & NFS)</span>
            <span className="text-[10px] text-[#C5A059] font-mono">قيد التنفيذ 2026</span>
          </div>
          <div className="text-2xl font-bold font-mono text-[#C5A059] mt-1 tabular-nums">
            126.0 <span className="text-xs text-slate-400 font-sans">مليون طن سنوياً (MTPA)</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            زيادة بنسبة +64% في إجمالي الطاقة التصديرية مع عقود بيع طويلة الأجل
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-sans">الهدف النهائي الشامل (حقل الشمال الغربي NFW)</span>
            <span className="text-[10px] text-sky-400 font-mono">أفق 2030</span>
          </div>
          <div className="text-2xl font-bold font-mono text-sky-400 mt-1 tabular-nums">
            142.0 <span className="text-xs text-slate-400 font-sans">مليون طن سنوياً (MTPA)</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            ترسيخ موقع دولة قطر كأكبر مصدر وأكثرهم موثوقية للطاقة النظيفة عالمياً
          </div>
        </div>

      </div>

      {/* Main Content Grid: Intelligence Feed + Asset Correlations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (8 Cols): Verified Energy News Feed */}
        <div className="lg:col-span-8 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#C5A059]" />
              <span>شريط النشرات والبيانات الصحفية الموثقة</span>
            </h3>

            {/* Filter tags */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              {['ALL', 'قطر وتوسعة الشمال', 'الأسواق الآسيوية', 'الأسواق الأوروبية', 'الشحن'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap text-[11px] ${
                    selectedCategory === cat
                      ? 'bg-[#8A1538] text-white font-semibold'
                      : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {cat === 'ALL' ? 'الكل' : cat}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredNews.map((item) => (
              <div key={item.id} className="bg-slate-900/80 border border-slate-800/80 p-4 rounded text-xs space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-[#C5A059] px-2 py-0.5 rounded bg-[#C5A059]/10 border border-[#C5A059]/20">
                      {item.category}
                    </span>
                    <span className="text-slate-500 font-mono text-[11px]">{item.timeAr}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-sans ${
                      item.impact.includes('إيجابي') 
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' 
                        : item.impact.includes('تقلب')
                        ? 'bg-amber-950 text-amber-400 border border-amber-800/40'
                        : 'bg-slate-800 text-slate-300'
                    }`}>
                      {item.impact}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>موثق</span>
                    </span>
                  </div>
                </div>

                <h4 className="text-sm font-bold text-white leading-snug">
                  {item.titleAr}
                </h4>

                <p className="text-slate-300 leading-relaxed text-xs">
                  {item.summaryAr}
                </p>

                <div className="text-[10px] text-slate-500 font-mono border-t border-slate-800/60 pt-2 flex justify-between">
                  <span>المصدر المرجعي: <strong className="text-slate-400 font-sans">{item.source}</strong></span>
                  <span>رقم الإيداع: {item.id}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column (4 Cols): Asset Correlation Matrix & Shipping Radar */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Correlation Matrix */}
          <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5 font-sans">
                <TrendingUp className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>مصفوفة الارتباط الإحصائي (Cross-Correlation)</span>
              </h3>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800/60">
                <span className="text-slate-300">JKM (آسيا) ↔ TTF (أوروبا)</span>
                <span className="font-bold text-emerald-400">+0.74</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800/60">
                <span className="text-slate-300">JKM (آسيا) ↔ أجور الشحن TFDE</span>
                <span className="font-bold text-[#C5A059]">+0.81</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800/60">
                <span className="text-slate-300">JKM (آسيا) ↔ خام برنت (Oil)</span>
                <span className="font-bold text-sky-400">+0.62</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800/60">
                <span className="text-slate-300">TTF (أوروبا) ↔ Henry Hub (أمريكا)</span>
                <span className="font-bold text-slate-300">+0.41</span>
              </div>
            </div>

            <div className="text-[10px] text-slate-500 font-sans leading-relaxed pt-1">
              * الارتباط المرتفع (+0.81) بين أسعار JKM وشحن الغاز المسال يعكس الطلب الموسمي المكثف لنقل الشحنات إلى شمال شرق آسيا قبل موسم الشتاء.
            </div>
          </div>

          {/* European Gas Storage Radar */}
          <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5 font-sans">
                <Compass className="w-3.5 h-3.5 text-sky-400" />
                <span>مستوى مخزونات الغاز الأوروبية (AGSI)</span>
              </h3>
              <span className="text-emerald-400 font-bold">74.2%</span>
            </div>

            <div className="space-y-1.5">
              <div className="w-full bg-slate-950 h-2.5 rounded overflow-hidden">
                <div className="bg-gradient-to-r from-emerald-500 to-[#C5A059] h-full" style={{ width: '74.2%' }}></div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0% فارغ</span>
                <span>الهدف الإلزامي للاتحاد الأوروبي (90%)</span>
                <span>100% ممتلئ</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-300 font-sans leading-relaxed pt-1">
              مخزونات الغاز في هولندا وألمانيا وإيطاليا تتجاوز المتوسط التاريخي لـ 5 سنوات، مما يحد من احتمالات حدوث قفزات حادة في مؤشر TTF إلا في حال حدوث اضطراب ملاحي طويل الأمد.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
