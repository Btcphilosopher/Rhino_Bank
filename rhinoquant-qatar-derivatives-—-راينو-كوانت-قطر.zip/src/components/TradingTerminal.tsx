import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Flame, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Sliders, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  BarChart2, 
  ShieldCheck,
  Send,
  RefreshCw
} from 'lucide-react';
import { BenchmarkQuote, ForwardCurvePoint, TradeBlotterItem, RFQItem } from '../types';

interface TradingTerminalProps {
  benchmarks: BenchmarkQuote[];
  forwardCurve: ForwardCurvePoint[];
  trades: TradeBlotterItem[];
  rfqs: RFQItem[];
  onExecuteQuickTrade: (trade: Partial<TradeBlotterItem>) => void;
  onNavigateToTab: (tabId: string) => void;
}

export const TradingTerminal: React.FC<TradingTerminalProps> = ({
  benchmarks,
  forwardCurve,
  trades,
  rfqs,
  onExecuteQuickTrade,
  onNavigateToTab,
}) => {
  const [selectedBenchmark, setSelectedBenchmark] = useState<string>('JKM');
  const [quickDirection, setQuickDirection] = useState<'شراء (BUY)' | 'بيع (SELL)'>('شراء (BUY)');
  const [quickVolumeCargoes, setQuickVolumeCargoes] = useState<number>(1); // 1 cargo = 3.4M MMBtu
  const [quickTenor, setQuickTenor] = useState<string>('نوفمبر 2026 (شتاء Q4)');
  const [ticketExecuted, setTicketExecuted] = useState<string | null>(null);

  const activeQuote = benchmarks.find(b => b.id === selectedBenchmark) || benchmarks[0];
  const selectedCurvePoint = forwardCurve.find(c => c.tenor === quickTenor) || forwardCurve[5];

  const targetPrice = selectedBenchmark === 'JKM' 
    ? selectedCurvePoint.jkmPrice 
    : selectedBenchmark === 'TTF' 
    ? selectedCurvePoint.ttfPrice 
    : selectedCurvePoint.henryHubPrice;

  const totalVolumeMMBtu = quickVolumeCargoes * 3400000;
  const totalNotionalUSD = totalVolumeMMBtu * targetPrice;

  const handleExecuteTicket = (e: React.FormEvent) => {
    e.preventDefault();
    const tradeId = `TRD-${Date.now().toString().slice(-4)}`;
    onExecuteQuickTrade({
      id: tradeId,
      dealDate: new Date().toISOString().split('T')[0],
      valueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      maturityDate: '2026-12-31',
      counterpartyId: 'CLT-QE-TRADING',
      counterpartyName: 'قطر للطاقة للتجارة (QatarEnergy Trading)',
      instrumentType: 'COMMODITY_SWAP',
      instrumentNameAr: `مبادلة غاز ${activeQuote.symbol} - ${quickTenor}`,
      underlying: activeQuote.symbol,
      direction: quickDirection,
      volumeMMBtu: totalVolumeMMBtu,
      fixedPriceUSD: targetPrice,
      currentMtmUSD: 0,
      unrealizedPnlUSD: 0,
      marginRequiredUSD: totalNotionalUSD * 0.08,
      collateralPostedUSD: totalNotionalUSD * 0.10,
      status: 'تأكيد إلكتروني (Confirmed)',
      traderId: 'TRD-DOH-01 (المكتب المؤسسي)',
      riskApprovedBy: 'RISK-AUTO-APPROVED',
    });

    setTicketExecuted(`تم تنفيذ الصفقة بنجاح برقم مرجعي: ${tradeId}`);
    setTimeout(() => setTicketExecuted(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Institutional Hero Banner */}
      <div className="relative rounded-lg overflow-hidden border border-slate-800 bg-[#090e1a] shadow-lg">
        <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[140px]">
          <div className="lg:col-span-8 p-6 flex flex-col justify-between z-10 bg-gradient-to-l from-transparent via-[#090e1a]/90 to-[#090e1a]">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#C5A059]"></span>
                <span className="text-xs font-bold text-[#C5A059] uppercase tracking-wider font-mono">
                  Doha Institutional Energy Trading Desk
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white mt-1 leading-snug">
                RhinoQuant Qatar — راينو كوانت قطر
              </h1>
              <p className="text-xs text-slate-300 mt-1.5 max-w-2xl leading-relaxed">
                المنصة المصرفية المتخصصة في تسعير المشتقات المالية المدرجة وخارج البورصة (OTC)، وعقود الغاز الطبيعي المسال (LNG)، وهيكلة المنتجات المالية المحمية لرأس المال وإدارة المخاطر والضمانات المصرفية وفق متطلبات مصرف قطر المركزي.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4 mt-4 pt-3 border-t border-slate-800/80 text-xs">
              <span className="text-slate-400">
                الهوية الاستراتيجية: <strong className="text-white font-sans">هندسة رأس المال. ذكاء الطاقة. دقة الأسواق.</strong>
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400">
                مركز العمليات: <strong className="text-[#C5A059] font-sans">الدوحة - الخليج الغربي ورأس لفان</strong>
              </span>
            </div>
          </div>

          <div className="hidden lg:block lg:col-span-4 relative overflow-hidden">
            <img
              src="/src/assets/images/hero_qatar_lng_terminal_1792575462878.jpg"
              alt="Ras Laffan LNG Terminal Qatar"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-center opacity-70"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#090e1a] via-transparent to-transparent"></div>
          </div>
        </div>
      </div>

      {/* Top Metric Strip: Desk P&L and Risk Utilization */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-medium">إجمالي القيمة الاسمية المفتوحة (Gross Notional)</div>
          <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
            $468,540,000 <span className="text-xs text-slate-400 font-sans">USD</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
            <span>يعادل بالريال:</span>
            <span className="font-mono text-[#C5A059] tabular-nums">1,705,485,600 QAR</span>
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-medium">صافي تعرض دلتا الغاز (Net LNG Delta)</div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            +13,600,000 <span className="text-xs text-slate-300 font-sans">MMBtu</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
            <span>حجم مكافئ بالشحنات:</span>
            <span className="font-mono text-slate-200">4.0 شحنات Q-Flex</span>
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-medium">القيمة المعرضة للمخاطر (1-Day VaR 99%)</div>
          <div className="text-xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            $4,820,000 <span className="text-xs text-slate-400 font-sans">USD</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
            <span>نسبة استغلال الحد المعتمد:</span>
            <span className="font-mono text-amber-300">48.2% من 10M$</span>
          </div>
        </div>

        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="text-[11px] text-slate-400 font-medium">الأرباح والخسائر اليومية للمكتب (Daily MTM P&L)</div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            +$1,450,200 <span className="text-xs text-emerald-300 font-sans">USD</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
            <span>عائد اليوم:</span>
            <span className="font-mono text-emerald-400">+1.84% صافي</span>
          </div>
        </div>
      </div>

      {/* Main Terminal Grid: Order Execution + Forward Curves */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 Cols): Fast Execution Desk Ticket */}
        <div className="lg:col-span-5 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#C5A059]" />
              <h3 className="text-sm font-bold text-white">تذكرة تداول فوري ومبادلات الغاز (Execution Ticket)</h3>
            </div>
            <span className="text-xs font-mono text-slate-400">توقيت الدوحة: نشط</span>
          </div>

          {ticketExecuted && (
            <div className="bg-emerald-950/40 border border-emerald-600/50 p-3 rounded text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{ticketExecuted}</span>
            </div>
          )}

          <form onSubmit={handleExecuteTicket} className="space-y-4 text-xs">
            {/* Direction Toggle */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setQuickDirection('شراء (BUY)')}
                className={`py-2 rounded font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                  quickDirection === 'شراء (BUY)'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>شراء / أخذ المركز (BUY)</span>
              </button>
              <button
                type="button"
                onClick={() => setQuickDirection('بيع (SELL)')}
                className={`py-2 rounded font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                  quickDirection === 'بيع (SELL)'
                    ? 'bg-[#8A1538] text-white shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                <span>بيع / تثبيت السعر (SELL)</span>
              </button>
            </div>

            {/* Benchmark Selector */}
            <div>
              <label className="block text-slate-400 mb-1">المؤشر المرجعي (Underlying Benchmark)</label>
              <div className="grid grid-cols-3 gap-2">
                {benchmarks.slice(0, 3).map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setSelectedBenchmark(b.id)}
                    className={`py-2 px-2 rounded text-center border font-mono transition-all ${
                      selectedBenchmark === b.id
                        ? 'bg-slate-800 border-[#C5A059] text-white font-bold'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div>{b.id}</div>
                    <div className="text-[10px] text-slate-400">${b.spotPrice.toFixed(2)}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Delivery Tenor */}
            <div>
              <label className="block text-slate-400 mb-1">فترة التسليم والاستحقاق (Delivery Tenor)</label>
              <select
                value={quickTenor}
                onChange={(e) => setQuickTenor(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
              >
                {forwardCurve.map((c) => (
                  <option key={c.tenor} value={c.tenor}>
                    {c.tenor} — JKM: ${c.jkmPrice.toFixed(2)} | TTF: ${c.ttfPrice.toFixed(2)}
                  </option>
                ))}
              </select>
            </div>

            {/* Volume in Cargoes */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>حجم الصفقة بالشحنات (Standard Cargoes):</span>
                <span className="font-mono text-white font-semibold">{quickVolumeCargoes} شحنة ({totalVolumeMMBtu.toLocaleString()} MMBtu)</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                step="1"
                value={quickVolumeCargoes}
                onChange={(e) => setQuickVolumeCargoes(Number(e.target.value))}
                className="w-full accent-[#8A1538]"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>1 شحنة (3.4M)</span>
                <span>5 شحنات (17M)</span>
                <span>10 شحنات (34M)</span>
              </div>
            </div>

            {/* Ticket Calculation Summary */}
            <div className="bg-slate-900/90 border border-slate-800 rounded p-3 space-y-1.5 font-mono">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>سعر التنفيذ التقديري:</span>
                <span className="text-white font-bold">${targetPrice.toFixed(2)} / MMBtu</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>إجمالي القيمة الاسمية (Notional USD):</span>
                <span className="text-[#C5A059] font-bold">${totalNotionalUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>الهامش المبدئي المطلوب (Initial Margin 8%):</span>
                <span className="text-slate-300">${(totalNotionalUSD * 0.08).toLocaleString()}</span>
              </div>
            </div>

            {/* Execution Action Button */}
            <button
              type="submit"
              className="w-full py-2.5 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#600e27] hover:brightness-110 transition-all border border-[#C5A059]/40 flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>تأكيد وتنفيذ الصفقة المصرفية (Execute Deal)</span>
            </button>
          </form>
        </div>

        {/* Right Column (7 Cols): Forward Curve Visualizer & Regional Spreads */}
        <div className="lg:col-span-7 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-[#C5A059]" />
              <h3 className="text-sm font-bold text-white">منحنى الأسعار الآجلة وفروق الأسعار (Forward Curves & Spreads)</h3>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span className="text-sky-400">■ Platts JKM</span>
              <span className="text-amber-400">■ Dutch TTF</span>
              <span className="text-emerald-400">■ Henry Hub</span>
            </div>
          </div>

          {/* Forward Curve Interactive Data Grid */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-right tabular-nums">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-sans text-[11px]">
                  <th className="py-2 text-right">الفترة (Tenor)</th>
                  <th className="py-2 text-right">JKM ($/MMBtu)</th>
                  <th className="py-2 text-right">TTF ($/MMBtu)</th>
                  <th className="py-2 text-right">Henry Hub ($)</th>
                  <th className="py-2 text-right">فرق JKM - TTF</th>
                  <th className="py-2 text-right">أجور الشحن ($/يوم)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {forwardCurve.map((row) => (
                  <tr key={row.tenor} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2 font-sans font-medium text-slate-300">{row.tenor}</td>
                    <td className="py-2 font-bold text-sky-400">${row.jkmPrice.toFixed(2)}</td>
                    <td className="py-2 text-amber-400">${row.ttfPrice.toFixed(2)}</td>
                    <td className="py-2 text-emerald-400">${row.henryHubPrice.toFixed(2)}</td>
                    <td className="py-2 font-semibold text-[#C5A059]">+${row.spreadJkmTtf.toFixed(2)}</td>
                    <td className="py-2 text-slate-300">${row.freightRate.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-900/60 p-3 rounded border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>ملاحظة تسعيرية: فروق الأسعار بين آسيا وأوروبا (JKM - TTF) تتسع في شهور الشتاء لتصل إلى 3.00 $/MMBtu لتغطية أجور الشحن الإضافية.</span>
            <button
              onClick={() => onNavigateToTab('lng')}
              className="text-[#C5A059] hover:underline font-sans font-semibold shrink-0"
            >
              تحليل المراجحة وشحن رأس لفان ←
            </button>
          </div>
        </div>
      </div>

      {/* Lower Section: Live Blotter Preview & Pending RFQs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* RFQ Requests Waiting for Pricing */}
        <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>طلبات التسعير الواردة من العملاء (Incoming RFQs)</span>
            </h3>
            <button 
              onClick={() => onNavigateToTab('sales')}
              className="text-[11px] text-[#C5A059] hover:underline"
            >
              عرض الكل في وحدة المبيعات ←
            </button>
          </div>

          <div className="space-y-2">
            {rfqs.map((rfq) => (
              <div key={rfq.id} className="bg-slate-900/80 border border-slate-800/80 p-3 rounded flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-white">{rfq.clientName}</div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    {rfq.instrumentType} · {rfq.tenor}
                  </div>
                </div>
                <div className="text-left font-mono">
                  <div className="text-slate-200 tabular-nums">
                    {rfq.volumeMMBtu.toLocaleString()} MMBtu
                  </div>
                  <div className="text-[10px] text-emerald-400 font-sans mt-0.5">
                    {rfq.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Deals Blotter Preview */}
        <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>أحدث الصفقات المسجلة في الدفتر (Recent Blotter Deals)</span>
            </h3>
            <button 
              onClick={() => onNavigateToTab('lifecycle')}
              className="text-[11px] text-[#C5A059] hover:underline"
            >
              دورة حياة الصفقات الكاملة ←
            </button>
          </div>

          <div className="space-y-2">
            {trades.slice(0, 3).map((tr) => (
              <div key={tr.id} className="bg-slate-900/80 border border-slate-800/80 p-3 rounded flex items-center justify-between text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-200">{tr.id}</span>
                    <span className="text-[10px] text-slate-400">· {tr.counterpartyName}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {tr.instrumentNameAr}
                  </div>
                </div>
                <div className="text-left font-mono">
                  <div className="text-emerald-400 font-bold tabular-nums">
                    MTM: +${(tr.currentMtmUSD / 1000).toFixed(0)}k
                  </div>
                  <div className="text-[10px] text-slate-400 font-sans mt-0.5">
                    {tr.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
