import React, { useState } from 'react';
import { 
  Flame, 
  Ship, 
  Compass, 
  Scale, 
  ArrowRightLeft, 
  TrendingUp, 
  TrendingDown, 
  Calculator, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Sliders
} from 'lucide-react';
import { BenchmarkQuote, ForwardCurvePoint } from '../types';
import { calculateRasLaffanNetback } from '../services/quantEngine';

interface LNGDerivativesModuleProps {
  benchmarks: BenchmarkQuote[];
  forwardCurve: ForwardCurvePoint[];
  onOpenNewRfq: () => void;
}

export const LNGDerivativesModule: React.FC<LNGDerivativesModuleProps> = ({
  benchmarks,
  forwardCurve,
  onOpenNewRfq,
}) => {
  // Netback State
  const [destinationMarket, setDestinationMarket] = useState<'آسيا - طوكيو/إنشيون (JKM)' | 'أوروبا - روتردام/إيل أوف غرين (TTF)' | 'أمريكا اللاتينية'>('آسيا - طوكيو/إنشيون (JKM)');
  const [charterDayRate, setCharterDayRate] = useState<number>(78500);
  const [cargoVolumeMMBtu, setCargoVolumeMMBtu] = useState<number>(3400000); // 1 cargo
  const [canalRoute, setCanalRoute] = useState<'سويس (Suez Canal)' | 'رأس الرجاء الصالح (Cape of Good Hope)' | 'مباشر إلى آسيا'>('مباشر إلى آسيا');
  const [boilOffPercent, setBoilOffPercent] = useState<number>(0.10);

  // Hedging Simulator State
  const [hedgeDirection, setHedgeDirection] = useState<'PRODUCER' | 'CONSUMER'>('PRODUCER');
  const [hedgeVolumeCargoes, setHedgeVolumeCargoes] = useState<number>(2);
  const [hedgeBenchmark, setHedgeBenchmark] = useState<'JKM' | 'TTF'>('JKM');
  const [hedgeStrategy, setHedgeStrategy] = useState<'COLLAR' | 'SWAP' | 'SPREAD_OPTION'>('COLLAR');
  const [hedgeFloorStrike, setHedgeFloorStrike] = useState<number>(13.50);
  const [hedgeCapStrike, setHedgeCapStrike] = useState<number>(18.00);
  const [hedgeSubmitted, setHedgeSubmitted] = useState<boolean>(false);

  const jkmQuote = benchmarks.find(b => b.id === 'JKM') || benchmarks[0];
  const ttfQuote = benchmarks.find(b => b.id === 'TTF') || benchmarks[1];
  const brentQuote = benchmarks.find(b => b.id === 'BRENT') || benchmarks[3];

  // Oil Slope Equivalent
  // Traditional long term LNG formula: P = Slope% * Brent + Constant
  const slopePercent = 12.8;
  const constantUSD = 0.50;
  const oilIndexedPrice = (slopePercent / 100) * brentQuote.spotPrice + constantUSD;

  // Calculate Netback
  const currentDestPrice = destinationMarket.includes('آسيا') ? jkmQuote.spotPrice : ttfQuote.spotPrice;
  const canalToll = canalRoute.includes('سويس') ? 420000 : 0;

  const netbackResult = calculateRasLaffanNetback({
    destinationBenchmarkPrice: currentDestPrice,
    destinationMarket,
    shippingCharterDayRateUSD: charterDayRate,
    fuelBoilOffPercent: boilOffPercent,
    canalTollsUSD: canalToll,
    regasificationCostUSD: 0.35,
    cargoVolumeMMBtu,
  });

  // Calculate Netback for Alternative (for comparison)
  const netbackAsia = calculateRasLaffanNetback({
    destinationBenchmarkPrice: jkmQuote.spotPrice,
    destinationMarket: 'آسيا - طوكيو/إنشيون (JKM)',
    shippingCharterDayRateUSD: charterDayRate,
    fuelBoilOffPercent: boilOffPercent,
    canalTollsUSD: 0,
    regasificationCostUSD: 0.35,
    cargoVolumeMMBtu,
  });

  const netbackEurope = calculateRasLaffanNetback({
    destinationBenchmarkPrice: ttfQuote.spotPrice,
    destinationMarket: 'أوروبا - روتردام/إيل أوف غرين (TTF)',
    shippingCharterDayRateUSD: charterDayRate,
    fuelBoilOffPercent: boilOffPercent,
    canalTollsUSD: 420000,
    regasificationCostUSD: 0.35,
    cargoVolumeMMBtu,
  });

  const asiaArbitragePremium = netbackAsia.netbackPriceUSDPerMMBtu - netbackEurope.netbackPriceUSDPerMMBtu;

  // Hedging Calculations
  const hedgeTotalMMBtu = hedgeVolumeCargoes * 3400000;
  const currentHedgeSpot = hedgeBenchmark === 'JKM' ? jkmQuote.spotPrice : ttfQuote.spotPrice;
  const hedgeGrossExposureUSD = hedgeTotalMMBtu * currentHedgeSpot;

  const handleSubmitHedge = (e: React.FormEvent) => {
    e.preventDefault();
    setHedgeSubmitted(true);
    setTimeout(() => setHedgeSubmitted(false), 5000);
  };

  return (
    <div className="space-y-6">
      
      {/* Strategic Header Banner */}
      <div className="bg-gradient-to-r from-[#0c1322] via-[#131d33] to-[#1c0f1c] border border-slate-800 p-6 rounded relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded bg-[#8A1538] text-white">
                <Flame className="w-4 h-4" />
              </span>
              <h2 className="text-lg font-bold text-white">
                مركز استخبارات ومشتقات الغاز الطبيعي المسال (RhinoQuant LNG Intelligence)
              </h2>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
              محور التداول الاستراتيجي للطاقة القطرية: تحليل التسليم الحر على ظهر السفينة (FOB Ras Laffan Netback)، ومقارنة مؤشرات آسيا وأوروبا وأمريكا، وتسعير مشتقات الشحن والتحوط المؤسسي للشحنات.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenNewRfq}
              className="px-4 py-2 text-xs font-bold text-white bg-[#8A1538] hover:bg-[#a31a43] rounded transition-colors border border-rose-900/50"
            >
              تسعير شحنة فورية (Price Cargo)
            </button>
          </div>
        </div>
      </div>

      {/* Global LNG Benchmark Comparator & Oil Slope Equivalency */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        {/* Platts JKM */}
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-start text-xs">
            <span className="text-slate-400 font-medium">مؤشر آسيا (Platts JKM)</span>
            <span className="text-[10px] text-sky-400 font-mono">طوكيو / سيول</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            ${jkmQuote.spotPrice.toFixed(2)} <span className="text-xs text-slate-400 font-sans">$/MMBtu</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>التقلب الضمني:</span>
            <span className="font-mono text-white">{jkmQuote.impliedVol}%</span>
          </div>
        </div>

        {/* Dutch TTF */}
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-start text-xs">
            <span className="text-slate-400 font-medium">مؤشر أوروبا (Dutch TTF)</span>
            <span className="text-[10px] text-amber-400 font-mono">روتردام / زيبورغ</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            ${ttfQuote.spotPrice.toFixed(2)} <span className="text-xs text-slate-400 font-sans">$/MMBtu</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>مكافئ الطاقة باليورو:</span>
            <span className="font-mono text-amber-400">37.15 €/MWh</span>
          </div>
        </div>

        {/* JKM - TTF Regional Spread */}
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-start text-xs">
            <span className="text-slate-400 font-medium">فارق السعر (JKM - TTF Spread)</span>
            <span className="text-[10px] text-[#C5A059] font-mono">علاوة آسيا</span>
          </div>
          <div className="text-2xl font-bold font-mono text-[#C5A059] mt-1 tabular-nums">
            +${(jkmQuote.spotPrice - ttfQuote.spotPrice).toFixed(2)} <span className="text-xs text-slate-400 font-sans">$/MMBtu</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>فارق تسليم الشتاء Q4:</span>
            <span className="font-mono text-white">+${(forwardCurve[5].spreadJkmTtf).toFixed(2)}</span>
          </div>
        </div>

        {/* Oil-Indexed Slope Price */}
        <div className="bg-[#0b1120] border border-slate-800 p-4 rounded">
          <div className="flex justify-between items-start text-xs">
            <span className="text-slate-400 font-medium">عقد مرتبط بالنفط (12.8% Brent)</span>
            <span className="text-[10px] text-slate-400 font-mono">صيغة تقليدية</span>
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            ${oilIndexedPrice.toFixed(2)} <span className="text-xs text-slate-400 font-sans">$/MMBtu</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>سعر برنت الحالي:</span>
            <span className="font-mono text-slate-200">${brentQuote.spotPrice.toFixed(2)} / bbl</span>
          </div>
        </div>

      </div>

      {/* Ras Laffan FOB Netback & Logistics Arbitrage Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Inputs (5 Cols) */}
        <div className="lg:col-span-5 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Ship className="w-4 h-4 text-[#C5A059]" />
              <h3 className="text-sm font-bold text-white">محاكي صافي عائد رأس لفان (FOB Netback Calculator)</h3>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">قطر للطاقة / ناقلات</span>
          </div>

          <div className="space-y-3 text-xs">
            {/* Destination Selector */}
            <div>
              <label className="block text-slate-400 mb-1">ميناء المقصد والتسليم (Destination Market)</label>
              <select
                value={destinationMarket}
                onChange={(e) => {
                  const val = e.target.value as any;
                  setDestinationMarket(val);
                  if (val.includes('آسيا')) {
                    setCanalRoute('مباشر إلى آسيا');
                  } else {
                    setCanalRoute('سويس (Suez Canal)');
                  }
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white text-xs font-mono focus:border-[#C5A059]"
              >
                <option value="آسيا - طوكيو/إنشيون (JKM)">آسيا - طوكيو/إنشيون (Platts JKM) — $14.35</option>
                <option value="أوروبا - روتردام/إيل أوف غرين (TTF)">أوروبا - روتردام/المملكة المتحدة (TTF) — $11.82</option>
                <option value="أمريكا اللاتينية">أمريكا اللاتينية - البرازيل/الأرجنتين — $13.10</option>
              </select>
            </div>

            {/* Vessel Charter Day Rate Slider */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>أجرة الشحن اليومية للناقلة (TFDE Day Rate):</span>
                <span className="font-mono text-white font-bold">${charterDayRate.toLocaleString()} / يوم</span>
              </div>
              <input
                type="range"
                min="40000"
                max="180000"
                step="2500"
                value={charterDayRate}
                onChange={(e) => setCharterDayRate(Number(e.target.value))}
                className="w-full accent-[#8A1538]"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>ركود صيفي ($40k)</span>
                <span>متوسط ($80k)</span>
                <span>ذروة شتوية ($180k)</span>
              </div>
            </div>

            {/* Canal Tolls / Route */}
            <div>
              <label className="block text-slate-400 mb-1">المسار البحري والرسوم الملاحية</label>
              <select
                value={canalRoute}
                onChange={(e) => setCanalRoute(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white text-xs focus:border-[#C5A059]"
              >
                <option value="مباشر إلى آسيا">مباشر عبر بحر العرب ومضيق ملقا (بدون رسوم قناة) — 28 يوماً</option>
                <option value="سويس (Suez Canal)">عبر البحر الأحمر وقناة السويس (رسوم $420k) — 34 يوماً</option>
                <option value="رأس الرجاء الصالح (Cape of Good Hope)">دوران حول رأس الرجاء الصالح (بدون رسوم ولكن مدة أطول) — 52 يوماً</option>
              </select>
            </div>

            {/* Natural Boil-off % */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>نسبة التبخر الطبيعي للغاز (Boil-off %/day):</span>
                <span className="font-mono text-white font-bold">{boilOffPercent}% يومياً</span>
              </div>
              <input
                type="range"
                min="0.06"
                max="0.18"
                step="0.01"
                value={boilOffPercent}
                onChange={(e) => setBoilOffPercent(Number(e.target.value))}
                className="w-full accent-[#C5A059]"
              />
            </div>
          </div>
        </div>

        {/* Right Netback Calculation Results (7 Cols) */}
        <div className="lg:col-span-7 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#C5A059]" />
              <span>تحليل عوائد الشحنة الصافية بميناء رأس لفان</span>
            </h3>
            <span className="text-xs font-mono text-[#C5A059] font-bold">
              حجم الشحنة: {(cargoVolumeMMBtu / 1000000).toFixed(1)}M MMBtu
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-slate-900/80 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">إجمالي إيراد التسليم المقصد</div>
              <div className="text-base font-bold font-mono text-white mt-1">
                ${(netbackResult.grossCargoRevenueUSD / 1000000).toFixed(2)}M
              </div>
              <div className="text-[10px] text-slate-500 font-mono mt-0.5">${currentDestPrice.toFixed(2)} / MMBtu</div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">تكلفة الشحن والتأمين والملاحة</div>
              <div className="text-base font-bold font-mono text-rose-400 mt-1">
                -${(netbackResult.totalFreightCostUSD / 1000000).toFixed(2)}M
              </div>
              <div className="text-[10px] text-slate-500 font-mono mt-0.5">-${netbackResult.shippingCostPerMMBtu.toFixed(2)} / MMBtu</div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">صافي عائد رأس لفان (FOB Netback)</div>
              <div className="text-base font-bold font-mono text-emerald-400 mt-1">
                ${netbackResult.netbackPriceUSDPerMMBtu.toFixed(2)}
              </div>
              <div className="text-[10px] text-slate-500 font-mono mt-0.5">$/MMBtu على ظهر السفينة</div>
            </div>
          </div>

          {/* Arbitrage Advantage Box */}
          <div className="bg-gradient-to-r from-slate-900 to-[#181122] border border-[#C5A059]/30 rounded p-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <ArrowRightLeft className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>مفاضلة المراجحة الجغرافية (Asia vs Europe Arbitrage):</span>
              </span>
              <span className="font-mono text-xs font-bold text-[#C5A059]">
                {asiaArbitragePremium >= 0 ? `آسيا تتفوق بفارق +$${asiaArbitragePremium.toFixed(2)}/MMBtu` : `أوروبا تتفوق بفارق +$${Math.abs(asiaArbitragePremium).toFixed(2)}/MMBtu`}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              تحقق الشحنة المتجهة إلى طوكيو/سيول صافي عائد FOB قدره <strong className="text-emerald-400">${netbackAsia.netbackPriceUSDPerMMBtu.toFixed(2)}</strong> مقابل <strong className="text-amber-400">${netbackEurope.netbackPriceUSDPerMMBtu.toFixed(2)}</strong> لأوروبا (بعد خصم رسوم السويس وأيام الشحن الإضافية). هذا يمنح فرق إيراد صافٍ إضافي قدره <strong className="text-[#C5A059]">+${(Math.abs(asiaArbitragePremium) * cargoVolumeMMBtu / 1000000).toFixed(2)} مليون دولار</strong> للشحنة الواحدة لصالح الوجهة الآسيوية.
            </p>
          </div>
        </div>
      </div>

      {/* LNG Hedging Simulator */}
      <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-[#C5A059]" />
            <h3 className="text-sm font-bold text-white">
              محرك استراتيجيات التحوط للغاز الطبيعي المسال (LNG Hedging Engine)
            </h3>
          </div>
          <span className="text-xs text-slate-400">إدارة التعرض السعري لشركات الطاقة والمستهلكين</span>
        </div>

        {hedgeSubmitted && (
          <div className="bg-emerald-950/40 border border-emerald-600/50 p-3 rounded text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>تم تسجيل استراتيجية التحوط بنجاح وتحويلها لمدير المخاطر لاعتماد نسب التغطية التعاقدية.</span>
          </div>
        )}

        <form onSubmit={handleSubmitHedge} className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          
          {/* Col 1: Exposure Definition */}
          <div className="space-y-3">
            <div className="font-semibold text-slate-200 border-b border-slate-800/80 pb-1">
              ١. تحديد حجم وطبيعة التعرض
            </div>
            
            <div>
              <label className="block text-slate-400 mb-1">نوع الكيان المتعرض للمخاطر</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setHedgeDirection('PRODUCER')}
                  className={`py-2 px-2 rounded font-semibold text-center border ${
                    hedgeDirection === 'PRODUCER'
                      ? 'bg-[#8A1538] border-rose-900 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  منتج ومصدر (Long)
                </button>
                <button
                  type="button"
                  onClick={() => setHedgeDirection('CONSUMER')}
                  className={`py-2 px-2 rounded font-semibold text-center border ${
                    hedgeDirection === 'CONSUMER'
                      ? 'bg-sky-700 border-sky-600 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  مستهلك صناعي (Short)
                </button>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>حجم الشحنات المراد تحوطها:</span>
                <span className="font-mono text-white font-bold">{hedgeVolumeCargoes} شحنة ({hedgeTotalMMBtu.toLocaleString()} MMBtu)</span>
              </div>
              <input
                type="range"
                min="1"
                max="8"
                step="1"
                value={hedgeVolumeCargoes}
                onChange={(e) => setHedgeVolumeCargoes(Number(e.target.value))}
                className="w-full accent-[#8A1538]"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">المؤشر الأساسي للتعرض</label>
              <select
                value={hedgeBenchmark}
                onChange={(e) => setHedgeBenchmark(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono"
              >
                <option value="JKM">Platts JKM (آسيا) — $14.35</option>
                <option value="TTF">Dutch TTF (أوروبا) — $11.82</option>
              </select>
            </div>
          </div>

          {/* Col 2: Hedge Instrument Structure */}
          <div className="space-y-3">
            <div className="font-semibold text-slate-200 border-b border-slate-800/80 pb-1">
              ٢. هيكل أداة التحوط
            </div>

            <div>
              <label className="block text-slate-400 mb-1">استراتيجية التحوط المقترحة</label>
              <select
                value={hedgeStrategy}
                onChange={(e) => setHedgeStrategy(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono"
              >
                <option value="COLLAR">طوق سعري منعدم التكلفة (Zero-Cost Collar)</option>
                <option value="SWAP">مبادلة أسعار ثابتة (Commodity Swap)</option>
                <option value="SPREAD_OPTION">خيار حماية فارق الأسعار (Spread Protection)</option>
              </select>
            </div>

            {hedgeStrategy === 'COLLAR' && (
              <>
                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>الحد الأدنى المحمي (Floor Put Strike):</span>
                    <span className="font-mono text-emerald-400 font-bold">${hedgeFloorStrike.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="15"
                    step="0.25"
                    value={hedgeFloorStrike}
                    onChange={(e) => setHedgeFloorStrike(Number(e.target.value))}
                    className="w-full accent-emerald-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>سقف المشاركة المبيع (Cap Call Strike):</span>
                    <span className="font-mono text-amber-400 font-bold">${hedgeCapStrike.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="16"
                    max="22"
                    step="0.50"
                    value={hedgeCapStrike}
                    onChange={(e) => setHedgeCapStrike(Number(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>
              </>
            )}

            <div className="bg-slate-900 p-3 rounded border border-slate-800 text-[11px] text-slate-400">
              {hedgeStrategy === 'COLLAR' 
                ? 'استراتيجية الطوق تضمن حداً أدنى لسعر البيع دون دفع علاوة نقدية مسبقة، عبر تمويل شراء خيار البيع (Put) من خلال بيع خيار شراء (Call) عند مستوى أعلى.'
                : 'مبادلة الأسعار تثبت التدفق النقدي تماماً عند السعر التعاقدي وتحمي من أي تقلبات صعوداً أو هبوطاً.'}
            </div>
          </div>

          {/* Col 3: Hedge Outcome & Submit */}
          <div className="space-y-3">
            <div className="font-semibold text-slate-200 border-b border-slate-800/80 pb-1">
              ٣. مخرجات التحوط والاعتماد
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded p-3 space-y-2 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>إجمالي التعرض الاسمي:</span>
                <span className="text-white font-bold">${(hedgeGrossExposureUSD / 1000000).toFixed(2)}M USD</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>نسبة التحوط الموصى بها:</span>
                <span className="text-emerald-400 font-bold">85% من إجمالي الحجم</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>أقصى خسارة سعرية محتملة:</span>
                <span className="text-slate-300 font-bold">
                  -${((currentHedgeSpot - hedgeFloorStrike) * hedgeTotalMMBtu / 1000000).toFixed(2)}M
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>صافي التكلفة المبدئية للأداة:</span>
                <span className="text-[#C5A059] font-bold">$0.00 (Zero-Cost)</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#590e24] hover:brightness-110 transition-all border border-[#C5A059]/40 flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-[#C5A059]" />
              <span>تقديم خطة التحوط لموافقة إدارة المخاطر</span>
            </button>
          </div>

        </form>
      </div>

    </div>
  );
};
