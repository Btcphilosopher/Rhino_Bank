import React, { useState } from 'react';
import { 
  Cpu, 
  Layers, 
  TrendingUp, 
  RotateCcw, 
  FileCheck, 
  ShieldCheck, 
  Sliders, 
  Download, 
  Hash, 
  Clock,
  Sparkles,
  BarChart3,
  CheckCircle2
} from 'lucide-react';
import { OptionPricingInputs, PricingResult } from '../types';
import { calculateBlack76, calculateSpreadOption, generateMonteCarloPaths } from '../services/quantEngine';

interface QuantPricingModuleProps {
  onSaveToBlotter?: (result: PricingResult, inputs: OptionPricingInputs) => void;
}

export const QuantPricingModule: React.FC<QuantPricingModuleProps> = ({ onSaveToBlotter }) => {
  const [modelType, setModelType] = useState<'CALL' | 'PUT' | 'SPREAD_OPTION' | 'COMMODITY_SWAP'>('CALL');
  const [benchmark, setBenchmark] = useState<'JKM' | 'TTF' | 'HENRY_HUB' | 'BRENT'>('JKM');
  const [forwardPrice, setForwardPrice] = useState<number>(14.35);
  const [secondaryForwardPrice, setSecondaryForwardPrice] = useState<number>(11.82);
  const [strikePrice, setStrikePrice] = useState<number>(14.50);
  const [tenorMonths, setTenorMonths] = useState<number>(6);
  const [volatilityPercent, setVolatilityPercent] = useState<number>(36.8);
  const [secondaryVolPercent, setSecondaryVolPercent] = useState<number>(41.5);
  const [correlation, setCorrelation] = useState<number>(0.74);
  const [riskFreeRatePercent, setRiskFreeRatePercent] = useState<number>(5.75); // QCB Rate
  const [cargoVolume, setCargoVolume] = useState<number>(3400000); // 1 cargo
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  // Prepare input structure
  const pricingInputs: OptionPricingInputs = {
    instrumentType: modelType,
    underlyingBenchmark: benchmark,
    secondaryBenchmark: modelType === 'SPREAD_OPTION' ? 'TTF' : undefined,
    forwardPrice,
    secondaryForwardPrice: modelType === 'SPREAD_OPTION' ? secondaryForwardPrice : undefined,
    strikePrice,
    timeToMaturityYears: tenorMonths / 12,
    volatility: volatilityPercent / 100,
    secondaryVolatility: secondaryVolPercent / 100,
    correlation,
    riskFreeRate: riskFreeRatePercent / 100,
    notionalVolumeMMBtu: cargoVolume,
  };

  // Run Real Quant Engine
  const pricingResult: PricingResult = modelType === 'SPREAD_OPTION'
    ? calculateSpreadOption(pricingInputs)
    : calculateBlack76(pricingInputs);

  // Generate Monte Carlo simulation paths
  const mcPaths = generateMonteCarloPaths(
    forwardPrice,
    volatilityPercent / 100,
    0.02, // risk-neutral drift
    tenorMonths / 12,
    8
  );

  // Calculate 2D Sensitivity Matrix (Spot Shock vs Vol Shock)
  const spotShocks = [-0.15, -0.05, 0.0, 0.05, 0.15];
  const volShocks = [-0.05, 0.0, 0.05];

  const handleSaveDeal = () => {
    if (onSaveToBlotter) {
      onSaveToBlotter(pricingResult, pricingInputs);
    }
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Module Title Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-[#C5A059]" />
            <h2 className="text-base font-bold text-white">
              محرك التسعير الكمي واليونانيات (RhinoQuant Pricing Engine)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            نماذج تسعير المشتقات السلعية المعتمدة دولياً: Black-76 وعقود الفروق Margrabe مع احتساب كامل لحساسيات دلتا وغاما وفيغا وثيتا ومحاكاة مسارات مونت كارلو.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">إصدار النموذج:</span>
          <span className="text-emerald-400 font-bold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
            {pricingResult.modelVersion}
          </span>
        </div>
      </div>

      {/* Main Quantitative Workbench Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 Cols): Model Selector & Inputs */}
        <div className="lg:col-span-5 bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#C5A059]" />
              <span>مدخلات النموذج الرياضي (Parameters)</span>
            </h3>
            <span className="text-[11px] text-slate-500 font-mono">QCB Discount Curve</span>
          </div>

          <div className="space-y-3.5 text-xs">
            
            {/* Instrument Type */}
            <div>
              <label className="block text-slate-400 mb-1">نوع الأداة والمشتق (Instrument Type)</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setModelType('CALL')}
                  className={`py-2 rounded font-semibold border ${
                    modelType === 'CALL'
                      ? 'bg-[#8A1538] border-rose-900 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  خيار شراء (Call)
                </button>
                <button
                  type="button"
                  onClick={() => setModelType('PUT')}
                  className={`py-2 rounded font-semibold border ${
                    modelType === 'PUT'
                      ? 'bg-sky-700 border-sky-600 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  خيار بيع (Put)
                </button>
                <button
                  type="button"
                  onClick={() => setModelType('SPREAD_OPTION')}
                  className={`py-2 rounded font-semibold border ${
                    modelType === 'SPREAD_OPTION'
                      ? 'bg-amber-700 border-amber-600 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  خيار فرق (Spread)
                </button>
              </div>
            </div>

            {/* Benchmark Selector */}
            <div>
              <label className="block text-slate-400 mb-1">المؤشر السلعي الأساسي</label>
              <select
                value={benchmark}
                onChange={(e) => {
                  const val = e.target.value as any;
                  setBenchmark(val);
                  if (val === 'JKM') setForwardPrice(14.35);
                  if (val === 'TTF') setForwardPrice(11.82);
                  if (val === 'HENRY_HUB') setForwardPrice(2.84);
                  if (val === 'BRENT') setForwardPrice(82.40);
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono"
              >
                <option value="JKM">Platts JKM ($/MMBtu) — السعر الفوري: $14.35</option>
                <option value="TTF">Dutch TTF ($/MMBtu) — السعر الفوري: $11.82</option>
                <option value="HENRY_HUB">US Henry Hub ($/MMBtu) — السعر الفوري: $2.84</option>
                <option value="BRENT">خام برنت المؤرخ ($/برميل) — السعر الفوري: $82.40</option>
              </select>
            </div>

            {/* Forward Price F Slider */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>السعر الآجل للأصل الأول (Forward F1):</span>
                <span className="font-mono text-white font-bold">${forwardPrice.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="0.05"
                value={forwardPrice}
                onChange={(e) => setForwardPrice(Number(e.target.value))}
                className="w-full accent-[#8A1538]"
              />
            </div>

            {/* Secondary Forward Price if Spread Option */}
            {modelType === 'SPREAD_OPTION' && (
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>السعر الآجل للأصل الثاني (Forward F2 - TTF):</span>
                  <span className="font-mono text-amber-400 font-bold">${secondaryForwardPrice.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="25"
                  step="0.05"
                  value={secondaryForwardPrice}
                  onChange={(e) => setSecondaryForwardPrice(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>
            )}

            {/* Strike Price K Slider */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>سعر التنفيذ (Strike Price K):</span>
                <span className="font-mono text-[#C5A059] font-bold">${strikePrice.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min={modelType === 'SPREAD_OPTION' ? -2 : 5}
                max={modelType === 'SPREAD_OPTION' ? 8 : 30}
                step="0.10"
                value={strikePrice}
                onChange={(e) => setStrikePrice(Number(e.target.value))}
                className="w-full accent-[#C5A059]"
              />
            </div>

            {/* Tenor / Time to Maturity */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>مدة العقد حتى الاستحقاق (Tenor):</span>
                <span className="font-mono text-white font-bold">{tenorMonths} أشهر ({(tenorMonths / 12).toFixed(2)} سنة)</span>
              </div>
              <input
                type="range"
                min="1"
                max="24"
                step="1"
                value={tenorMonths}
                onChange={(e) => setTenorMonths(Number(e.target.value))}
                className="w-full accent-slate-400"
              />
            </div>

            {/* Volatility Sigma */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>التقلب الضمني السنوي (Implied Volatility σ):</span>
                <span className="font-mono text-sky-400 font-bold">{volatilityPercent.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="90"
                step="0.5"
                value={volatilityPercent}
                onChange={(e) => setVolatilityPercent(Number(e.target.value))}
                className="w-full accent-sky-500"
              />
            </div>

            {/* Risk-free Rate */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>سعر الخصم الخالي من المخاطر (QCB Repo Rate r):</span>
                <span className="font-mono text-emerald-400 font-bold">{riskFreeRatePercent.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="2"
                max="8"
                step="0.25"
                value={riskFreeRatePercent}
                onChange={(e) => setRiskFreeRatePercent(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>

            {/* Volume in Cargoes */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>حجم العقد الاسمي (Notional Volume):</span>
                <span className="font-mono text-white font-bold">{cargoVolume.toLocaleString()} MMBtu</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[1700000, 3400000, 6800000].map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setCargoVolume(v)}
                    className={`py-1.5 rounded font-mono text-[11px] border ${
                      cargoVolume === v ? 'bg-slate-800 border-white text-white' : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    {(v / 1000000).toFixed(1)}M MMBtu
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* Right Column (7 Cols): Pricing Results & Analytical Greeks */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Main Valuation Summary Card */}
          <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>القيمة العادلة والأقساط المصرفية (Fair Value & Premium)</span>
                </h3>
                <span className="text-[11px] text-slate-400 font-mono">{pricingResult.modelName}</span>
              </div>

              <div className="text-left font-mono text-[11px] text-slate-400">
                <div>الرمز الأمني: {pricingResult.auditHash}</div>
                <div className="text-slate-500">{pricingResult.calculatedAt}</div>
              </div>
            </div>

            {savedSuccess && (
              <div className="bg-emerald-950/40 border border-emerald-600/50 p-3 rounded text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>تم توثيق التسعير وحفظه في سجل صفقات التداول مع مفتاح التدقيق الكمي.</span>
              </div>
            )}

            {/* Core Price Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">القيمة العادلة للوحدة (Per Unit)</div>
                <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
                  ${pricingResult.fairValuePerUnit.toFixed(4)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-0.5">$/MMBtu</div>
              </div>

              <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">إجمالي العلاوة (USD Premium)</div>
                <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
                  ${(pricingResult.totalPremiumUSD / 1000).toLocaleString(undefined, { maximumFractionDigits: 1 })}k
                </div>
                <div className="text-[10px] text-slate-500 font-sans mt-0.5">${pricingResult.totalPremiumUSD.toLocaleString()} USD</div>
              </div>

              <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">إجمالي العلاوة بالريال القطري</div>
                <div className="text-2xl font-bold font-mono text-[#C5A059] mt-1 tabular-nums">
                  {(pricingResult.totalPremiumQAR / 1000).toLocaleString(undefined, { maximumFractionDigits: 1 })}k
                </div>
                <div className="text-[10px] text-slate-500 font-sans mt-0.5">سعر الربط الرسمي 3.64 QAR</div>
              </div>
            </div>

            {/* Intrinsic vs Time Value Breakdown */}
            <div className="bg-slate-900/50 p-3 rounded border border-slate-800 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">القيمة الجوهرية (Intrinsic):</span>
                <span className="text-white font-bold">${pricingResult.intrinsicValue.toFixed(4)}</span>
              </div>
              <span className="text-slate-700">+</span>
              <div className="flex items-center gap-2">
                <span className="text-slate-400">القيمة الزمنية (Time Value):</span>
                <span className="text-[#C5A059] font-bold">${pricingResult.timeValue.toFixed(4)}</span>
              </div>
              <span className="text-slate-700">=</span>
              <div className="flex items-center gap-2">
                <span className="text-slate-400">معامل الخصم (Discount e^-rT):</span>
                <span className="text-emerald-400 font-bold">{pricingResult.discountFactor.toFixed(4)}</span>
              </div>
            </div>

            {/* Analytic Greeks Matrix */}
            <div>
              <div className="text-xs font-bold text-slate-200 mb-2.5 flex items-center justify-between">
                <span>حساسيات المشتقات المصرفية (The Financial Greeks)</span>
                <span className="text-[10px] text-slate-500 font-mono">Calculated Analytically</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center font-mono text-xs">
                
                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">دلتا (Delta Δ)</div>
                  <div className="text-base font-bold text-sky-400 mt-1 tabular-nums">
                    {pricingResult.greeks.delta.toFixed(4)}
                  </div>
                  <div className="text-[9px] text-slate-500 mt-0.5">حساسية السعر</div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">غاما (Gamma Γ)</div>
                  <div className="text-base font-bold text-indigo-400 mt-1 tabular-nums">
                    {pricingResult.greeks.gamma.toFixed(4)}
                  </div>
                  <div className="text-[9px] text-slate-500 mt-0.5">معدل تغير دلتا</div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">فيغا (Vega V)</div>
                  <div className="text-base font-bold text-amber-400 mt-1 tabular-nums">
                    {pricingResult.greeks.vega.toFixed(4)}
                  </div>
                  <div className="text-[9px] text-slate-500 mt-0.5">لكل 1% تقلب</div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">ثيتا (Theta Θ)</div>
                  <div className="text-base font-bold text-rose-400 mt-1 tabular-nums">
                    ${pricingResult.greeks.theta.toFixed(4)}
                  </div>
                  <div className="text-[9px] text-slate-500 mt-0.5">تآكل زمني يومي</div>
                </div>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">رو (Rho ρ)</div>
                  <div className="text-base font-bold text-emerald-400 mt-1 tabular-nums">
                    {pricingResult.greeks.rho.toFixed(4)}
                  </div>
                  <div className="text-[9px] text-slate-500 mt-0.5">لكل 1% فائدة</div>
                </div>

              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={handleSaveDeal}
                className="px-4 py-2 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#630f28] hover:brightness-110 transition-all border border-[#C5A059]/40 text-xs flex items-center gap-1.5"
              >
                <FileCheck className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>حفظ في سجل الصفقات واعتماد التسعير (Book to Blotter)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ pricingInputs, pricingResult }, null, 2));
                  const downloadAnchor = document.createElement('a');
                  downloadAnchor.setAttribute("href", dataStr);
                  downloadAnchor.setAttribute("download", `term_sheet_${pricingResult.auditHash}.json`);
                  document.body.appendChild(downloadAnchor);
                  downloadAnchor.click();
                  downloadAnchor.remove();
                }}
                className="px-3 py-2 rounded text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors text-xs flex items-center gap-1.5 font-mono"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تصدير ورقة الشروط (Term Sheet JSON)</span>
              </button>
            </div>

          </div>

          {/* Monte Carlo Price Path & 95% Confidence Trajectories */}
          <div className="bg-[#0b1120] border border-slate-800 rounded p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>مسارات مونت كارلو ونطاق الثقة 95% (Monte Carlo Simulated Paths)</span>
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">1,000 Iterations / GBM</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-right tabular-nums">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 text-[10px]">
                    <th className="py-1.5 text-right">الخطوة الزمنية</th>
                    <th className="py-1.5 text-right">الزمن (سنة)</th>
                    <th className="py-1.5 text-right">الحد الأدنى 95% (VaR)</th>
                    <th className="py-1.5 text-right">المسار المتوقع (Mean)</th>
                    <th className="py-1.5 text-right">الحد الأعلى 95%</th>
                    <th className="py-1.5 text-right">مسار العينة 1</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 text-slate-300">
                  {mcPaths.map((p) => (
                    <tr key={p.step} className="hover:bg-slate-800/30">
                      <td className="py-1 text-slate-400">T+{p.step}</td>
                      <td className="py-1 text-slate-400">{p.timeYears}</td>
                      <td className="py-1 text-rose-400 font-bold">${p.lower95.toFixed(2)}</td>
                      <td className="py-1 text-white font-semibold">${p.mean.toFixed(2)}</td>
                      <td className="py-1 text-emerald-400 font-bold">${p.upper95.toFixed(2)}</td>
                      <td className="py-1 text-sky-400">${p.path1.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
