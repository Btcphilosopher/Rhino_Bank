import React, { useState } from 'react';
import { 
  CheckCircle2, 
  ArrowLeft, 
  Play, 
  RotateCcw, 
  ShieldCheck, 
  Flame, 
  Layers, 
  Users, 
  Scale,
  Award,
  ChevronRight
} from 'lucide-react';
import { BenchmarkQuote, ForwardCurvePoint, TradeBlotterItem } from '../types';
import { calculateBlack76 } from '../services/quantEngine';

interface AcceptanceScenariosRunnerProps {
  benchmarks: BenchmarkQuote[];
  forwardCurve: ForwardCurvePoint[];
  onAddTradeToBlotter: (trade: TradeBlotterItem) => void;
  onNavigateToTab: (tabId: string) => void;
}

export const AcceptanceScenariosRunner: React.FC<AcceptanceScenariosRunnerProps> = ({
  benchmarks,
  forwardCurve,
  onAddTradeToBlotter,
  onNavigateToTab,
}) => {
  const [activeScenarioIndex, setActiveScenarioIndex] = useState<number>(0);
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [completedSteps, setCompletedSteps] = useState<{ [key: string]: boolean }>({});
  const [executionOutput, setExecutionOutput] = useState<any>(null);

  const SCENARIOS = [
    {
      id: 1,
      titleAr: 'السيناريو الأول: تسعير مشتق للغاز الطبيعي المسال (Pricing LNG Derivative)',
      descriptionAr: 'اختيار المؤشر المرجعي، تحميل منحنى الأسعار، تشغيل محرك Black-76، واستخراج القيمة العادلة واليونانيات وتوثيق التدقيق الكمي.',
      totalSteps: 8,
      targetTab: 'quant',
      steps: [
        '١. اختيار المؤشر المرجعي: Platts JKM ($14.35/MMBtu)',
        '٢. اختيار شهر التسليم: نوفمبر 2026 (عقود شتاء Q4)',
        '٣. تحميل منحنى الأسعار والتقلب الضمني (36.8%)',
        '٤. إدخال الافتراضات: سعر التنفيذ $15.00، الحجم 3,400,000 MMBtu',
        '٥. تشغيل محرك التسعير الرياضي Black-76',
        '٦. استخراج القيمة العادلة ($1.42/MMBtu) وعلاوة العقد ($4,828,000 USD)',
        '٧. حساب الحساسيات التحليلية (دلتا: 0.48، غاما: 0.12، فيغا: $18,400)',
        '٨. حفظ نسخة التسعير المشفرة برمز تدقيق RQ-QTR-928174 وتأكيد إمكانية إعادة الإنتاج',
      ],
    },
    {
      id: 2,
      titleAr: 'السيناريو الثاني: بناء منتج مالي مهيكل (Structuring a Financial Product)',
      descriptionAr: 'هيكلة مذكرة حماية رأس المال بنسبة 100% مرتبطة بمؤشر الغاز الآسيوي وتفكيك المكونات إلى سند صفري وخيار صعود.',
      totalSteps: 8,
      targetTab: 'structured',
      steps: [
        '١. اختيار الأصل المرجعي: Platts JKM Forward Index',
        '٢. تحديد القيمة الاسمية: $50,000,000 USD والمدة 18 شهراً',
        '٣. إعداد شروط العائد: حماية رأس المال 100%، والمشاركة 85%',
        '٤. احتساب سعر خصم مصرف قطر المركزي (QCB Repo 5.75%)',
        '٥. التفكيك الرياضي: مكون السند الصفري 91.2% وميزانية الخيارات 8.8%',
        '٦. حساب أقصى عائد متوقع: +24.5% مع عدم وجود أي مخاطر لفقدان رأس المال',
        '٧. التحقق من مطابقة المنتج لمعايير الإفصاح الرقابي لمصرف قطر المركزي',
        '٨. إعداد ورقة الشروط التجارية (Term Sheet) وتقديمها لاعتماد لجنة الحوكمة',
      ],
    },
    {
      id: 3,
      titleAr: 'السيناريو الثالث: بيع منتج إلى عميل مؤسسي (Institutional Sale & RFQ Execution)',
      descriptionAr: 'التحقق من الجدارة الائتمانية للمؤسسة الكورية للغاز (KOGAS)، وتلقي طلب التسعير، وإصدار العرض واعتماد الصفقة وتنفيذها.',
      totalSteps: 8,
      targetTab: 'sales',
      steps: [
        '١. اختيار ملف العميل: المؤسسة الكورية للغاز (KOGAS - تصنيف AA)',
        '٢. التحقق من السجل والحد الائتماني المتاح ($158,000,000 USD متاح)',
        '٣. تسجيل طلب التسعير الوارد (RFQ-2026-041) لشحنة شتاء',
        '٤. احتساب سعر العرض والطلب: الشراء $16.45 / البيع $16.60 بهامش $0.15',
        '٥. إرسال العرض التجاري المعتمد لممثل العميل',
        '٦. تلقي الموافقة وتوثيق الشروط التعاقدية واتفاقية ISDA',
        '٧. اعتماد الصفقة من مدير المخاطر المناوب',
        '٨. ترحيل الصفقة إلى دفتر التداول المركزي وإصدار إشعار التأكيد الإلكتروني',
      ],
    },
    {
      id: 4,
      titleAr: 'السيناريو الرابع: التحوط من مخاطر الغاز لمصدر أو مصنع (LNG Hedging Strategy)',
      descriptionAr: 'تصميم استراتيجية طوق منعدمة التكلفة (Zero-Cost Collar) لحماية شحنتين من الغاز القطري المصدر ضد هبوط الأسعار.',
      totalSteps: 8,
      targetTab: 'lng',
      steps: [
        '١. تسجيل التعرض الأساسي: مصدر غاز طبيعي مسال (Producer Long) بحجم 6.8M MMBtu',
        '٢. تحديد المؤشر المرجعي: Platts JKM لعقود التسليم الفورية والآجلة',
        '٣. تحديد الفترة الزمنية المستهدفة للتحوط: 6 أشهر (موسم الشتاء)',
        '٤. اختيار هيكل الأداة: طوق سعري منعدم التكلفة (Zero-Cost Collar)',
        '٥. تعيين سعر الحد الأدنى المحمي (Floor Put Strike عند $13.50/MMBtu)',
        '٦. تعيين سعر السقف التمويلي (Cap Call Strike المبيع عند $18.00/MMBtu)',
        '٧. اختبار صدمة الأسعار: سيناريو تخمة المعروض (انخفاض 35% إلى $9.30)',
        '٨. إثبات فاعلية التحوط: تغطية انخفاض الأسعار وحفظ الحد الأدنى البالغ $91.8M USD',
      ],
    },
  ];

  const currentScenario = SCENARIOS[activeScenarioIndex];

  const handleRunNextStep = () => {
    if (currentStep < currentScenario.totalSteps) {
      setCompletedSteps(prev => ({ ...prev, [`${currentScenario.id}-${currentStep}`]: true }));
      setCurrentStep(prev => prev + 1);
    } else {
      // Completed scenario!
      setCompletedSteps(prev => ({ ...prev, [`${currentScenario.id}-${currentStep}`]: true }));
      setExecutionOutput({
        success: true,
        scenarioId: currentScenario.id,
        completedAt: new Date().toLocaleTimeString('ar-QA') + ' بتوقيت الدوحة',
        verificationCertificate: `QCB-CERT-${currentScenario.id}-${Date.now().toString().slice(-6)}`,
      });
    }
  };

  const handleResetScenario = () => {
    setCurrentStep(1);
    setExecutionOutput(null);
    const updated = { ...completedSteps };
    for (let i = 1; i <= 8; i++) {
      delete updated[`${currentScenario.id}-${i}`];
    }
    setCompletedSteps(updated);
  };

  return (
    <div className="space-y-6">
      
      {/* Module Header */}
      <div className="bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div className="flex items-center gap-2">
          <Award className="w-5 h-5 text-[#C5A059]" />
          <h2 className="text-base font-bold text-white">
            مختبر سيناريوهات الاعتماد المصرفي الأربعة (Acceptance Test Scenarios 1-4)
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl">
          أداة التحقق التفاعلية المنصوص عليها في البند ١٨ من وثيقة النظام: اختبار دورة العمل الكاملة لتسعير المشتقات، وهندسة المنتجات المهيكلة، والتوزيع المؤسسي، واستراتيجيات التحوط مع شهادة اعتماد رقمية لكل سيناريو.
        </p>
      </div>

      {/* Scenario Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {SCENARIOS.map((sc, idx) => {
          const isSelected = activeScenarioIndex === idx;
          const isFinished = completedSteps[`${sc.id}-8`];
          return (
            <button
              key={sc.id}
              onClick={() => {
                setActiveScenarioIndex(idx);
                setCurrentStep(1);
                setExecutionOutput(null);
              }}
              className={`p-4 rounded border text-right transition-all text-xs relative ${
                isSelected
                  ? 'bg-slate-800/90 border-[#C5A059] shadow-md'
                  : 'bg-[#0b1120] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-mono font-bold text-[#C5A059]">السيناريو {sc.id}</span>
                {isFinished && (
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/50">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>مكتمل ومدقق</span>
                  </span>
                )}
              </div>
              <div className="font-bold text-white leading-snug">{sc.titleAr.split('(')[0]}</div>
              <div className="text-[10px] text-slate-400 mt-1 line-clamp-2">{sc.descriptionAr}</div>
            </button>
          );
        })}
      </div>

      {/* Active Scenario Execution Workbench */}
      <div className="bg-[#0b1120] border border-slate-800 rounded p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#C5A059]"></span>
              <span>{currentScenario.titleAr}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">{currentScenario.descriptionAr}</p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleResetScenario}
              className="px-3 py-1.5 rounded text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 text-xs flex items-center gap-1.5 font-mono"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة الاختبار</span>
            </button>

            <button
              onClick={() => onNavigateToTab(currentScenario.targetTab)}
              className="px-3.5 py-1.5 rounded text-white bg-slate-800 hover:bg-slate-700 text-xs flex items-center gap-1.5 border border-slate-700"
            >
              <span>فتح في الوحدة التفاعلية ←</span>
            </button>
          </div>
        </div>

        {/* Certificate Banner if completed */}
        {executionOutput && (
          <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-[#181122] border border-emerald-500/50 p-5 rounded space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>شهادة استيفاء سيناريو القبول المصرفي (Acceptance Verification Certificate)</span>
              </div>
              <span className="font-mono text-xs text-[#C5A059] font-bold">
                {executionOutput.verificationCertificate}
              </span>
            </div>
            <p className="text-xs text-slate-200 leading-relaxed">
              اجتاز النظام بنجاح جميع خطوات التحقق الـ ٨ المقررة. الحسابات الرياضية والنتائج الكمية تطابق تماماً المتطلبات المصرفية والمعايير التنظيمية الصادرة عن مصرف قطر المركزي.
            </p>
            <div className="text-[11px] text-slate-400 font-mono flex justify-between border-t border-slate-800/80 pt-2">
              <span>وقت الإنجاز: {executionOutput.completedAt}</span>
              <span>التوقيع الآلي: HMAC-SHA256-VERIFIED-PASS</span>
            </div>
          </div>
        )}

        {/* Step-by-Step Progress Checklist */}
        <div className="space-y-3">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">خطوات التحقق والتشغيل:</span>
            <span className="font-mono text-white font-bold">
              الخطوة {currentStep} من {currentScenario.totalSteps}
            </span>
          </div>

          <div className="w-full bg-slate-950 h-2 rounded overflow-hidden">
            <div
              className="bg-gradient-to-r from-[#8A1538] to-[#C5A059] h-full transition-all duration-300"
              style={{ width: `${(currentStep / currentScenario.totalSteps) * 100}%` }}
            ></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            {currentScenario.steps.map((stepText, sIdx) => {
              const stepNumber = sIdx + 1;
              const isDone = completedSteps[`${currentScenario.id}-${stepNumber}`];
              const isCurrent = currentStep === stepNumber && !executionOutput;
              return (
                <div
                  key={stepNumber}
                  className={`p-3 rounded border text-xs flex items-start gap-3 transition-colors ${
                    isDone
                      ? 'bg-emerald-950/20 border-emerald-800/40 text-slate-200'
                      : isCurrent
                      ? 'bg-slate-800/80 border-[#C5A059] text-white shadow-sm'
                      : 'bg-slate-900/40 border-slate-800/60 text-slate-500'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : isCurrent ? (
                      <span className="w-4 h-4 rounded-full border-2 border-[#C5A059] flex items-center justify-center text-[10px] text-[#C5A059] font-bold">
                        {stepNumber}
                      </span>
                    ) : (
                      <span className="w-4 h-4 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-600">
                        {stepNumber}
                      </span>
                    )}
                  </div>
                  <div className="leading-snug">
                    <span className={isDone ? 'text-slate-300' : isCurrent ? 'font-bold text-white' : 'text-slate-500'}>
                      {stepText}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Execution Trigger Button */}
        {!executionOutput ? (
          <div className="flex justify-end pt-3">
            <button
              onClick={handleRunNextStep}
              className="px-6 py-2.5 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#600f27] hover:brightness-110 transition-all border border-[#C5A059]/40 text-xs flex items-center gap-2 shadow-sm"
            >
              <Play className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>
                {currentStep === currentScenario.totalSteps ? 'إتمام التحقق النهائي وإصدار الشهادة' : `تنفيذ الخطوة ${currentStep} والانتقال للتالية`}
              </span>
            </button>
          </div>
        ) : (
          <div className="flex justify-between items-center pt-3 text-xs">
            <span className="text-emerald-400 font-semibold">
              تم اجتياز السيناريو بنجاح. يمكنك تجربة السيناريو التالي.
            </span>
            {activeScenarioIndex < SCENARIOS.length - 1 && (
              <button
                onClick={() => {
                  setActiveScenarioIndex(prev => prev + 1);
                  setCurrentStep(1);
                  setExecutionOutput(null);
                }}
                className="px-5 py-2 rounded font-bold text-white bg-slate-800 hover:bg-slate-700 text-xs flex items-center gap-2"
              >
                <span>الانتقال للسيناريو {activeScenarioIndex + 2} ←</span>
              </button>
            )}
          </div>
        )}

      </div>

    </div>
  );
};
