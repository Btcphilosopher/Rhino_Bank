import React from 'react';
import { 
  BarChart3, 
  Flame, 
  Cpu, 
  Layers, 
  Users, 
  FileSpreadsheet, 
  ShieldAlert, 
  Globe2, 
  FileText,
  CheckCircle2
} from 'lucide-react';

export interface TabItem {
  id: string;
  labelAr: string;
  labelEn: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

export const TABS: TabItem[] = [
  { id: 'terminal', labelAr: 'محطة التداول', labelEn: 'Trading Terminal', icon: BarChart3 },
  { id: 'lng', labelAr: 'مشتقات الغاز LNG', labelEn: 'LNG Intelligence & Derivatives', icon: Flame, badge: 'رئيسي' },
  { id: 'quant', labelAr: 'محرك التسعير الكمي', labelEn: 'Quant Pricing Engine', icon: Cpu },
  { id: 'structured', labelAr: 'استوديو المنتجات المهيكلة', labelEn: 'Structured Products Studio', icon: Layers },
  { id: 'sales', labelAr: 'المبيعات وتوزيع المؤسسات', labelEn: 'Sales & RFQ', icon: Users },
  { id: 'lifecycle', labelAr: 'دورة حياة الصفقات', labelEn: 'Trade Lifecycle', icon: FileSpreadsheet },
  { id: 'risk', labelAr: 'إدارة المخاطر والضمانات', labelEn: 'Risk & Collateral', icon: ShieldAlert },
  { id: 'intelligence', labelAr: 'استخبارات السوق والأخبار', labelEn: 'Market Intelligence', icon: Globe2 },
  { id: 'reports', labelAr: 'التقارير المصرفية والرقابية', labelEn: 'QCB & Banking Reports', icon: FileText },
  { id: 'scenarios', labelAr: 'سيناريوهات الاعتماد الأربعة', labelEn: 'Acceptance Scenarios (1-4)', icon: CheckCircle2, badge: 'مهمة' },
];

interface NavigationTabsProps {
  activeTab: string;
  onTabChange: (id: string) => void;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="bg-[#090e1a] border-b border-slate-800 px-6 py-2 overflow-x-auto">
      <div className="flex items-center gap-1.5 min-w-max">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded transition-all whitespace-nowrap shrink-0 border ${
                isActive
                  ? 'bg-gradient-to-r from-[#8A1538]/20 to-[#8A1538]/40 text-white border-[#8A1538] shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border-transparent'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#C5A059]' : 'text-slate-500'}`} />
              <span>{tab.labelAr}</span>
              <span className="text-[10px] text-slate-500 font-mono hidden md:inline">({tab.labelEn})</span>
              {tab.badge && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-sans ${
                  tab.id === 'lng' ? 'bg-[#8A1538] text-white' : 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
