import React, { useState } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  Calendar,
  AlertCircle
} from 'lucide-react';
import { TradeBlotterItem, BenchmarkQuote } from '../types';

interface BankingReportsProps {
  trades: TradeBlotterItem[];
  benchmarks: BenchmarkQuote[];
}

export const BankingReports: React.FC<BankingReportsProps> = ({ trades, benchmarks }) => {
  const [selectedReport, setSelectedReport] = useState<'QCB_COMPLIANCE' | 'DAILY_PNL' | 'COLLATERAL_AUDIT'>('QCB_COMPLIANCE');

  const totalNotionalUSD = trades.reduce((acc, t) => acc + (t.volumeMMBtu * t.fixedPriceUSD), 0);
  const totalMtmUSD = trades.reduce((acc, t) => acc + t.currentMtmUSD, 0);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadReportJSON = () => {
    const reportData = {
      reportType: selectedReport,
      generatedAt: new Date().toISOString(),
      institution: "RhinoQuant Qatar — راينو كوانت قطر",
      regulator: "مصرف قطر المركزي (Qatar Central Bank - QCB)",
      portfolioNotionalUSD: totalNotionalUSD,
      portfolioMtmUSD: totalMtmUSD,
      tradesCount: trades.length,
      trades: trades,
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(reportData, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `qcb_report_${selectedReport}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded no-print">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#C5A059]" />
            <h2 className="text-base font-bold text-white">
              التقارير المصرفية والرقابية لمصرف قطر المركزي (Banking & QCB Reports)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            تقارير كفاية رأس المال، وإفصاحات المشتقات المالية، وتقييم القيمة العادلة المعتمدة وفقاً لمعايير IFRS 9 وتعاميم مصرف قطر المركزي.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadReportJSON}
            className="px-3.5 py-2 rounded text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors text-xs flex items-center gap-1.5 font-mono"
          >
            <Download className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>تصدير JSON</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded font-bold text-xs text-white bg-gradient-to-r from-[#8A1538] to-[#590e24] hover:brightness-110 flex items-center gap-1.5 border border-[#C5A059]/40"
          >
            <Printer className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>طباعة التقرير الرسمي (Print PDF)</span>
          </button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="flex items-center gap-2 bg-[#0b1120] border border-slate-800 p-2 rounded text-xs font-mono no-print">
        <button
          onClick={() => setSelectedReport('QCB_COMPLIANCE')}
          className={`px-4 py-2 rounded transition-colors ${
            selectedReport === 'QCB_COMPLIANCE' ? 'bg-[#8A1538] text-white font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          تقرير امتثال مصرف قطر المركزي (QCB Circular 2024/09)
        </button>
        <button
          onClick={() => setSelectedReport('DAILY_PNL')}
          className={`px-4 py-2 rounded transition-colors ${
            selectedReport === 'DAILY_PNL' ? 'bg-[#8A1538] text-white font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          تقرير الأرباح والخسائر اليومي وتقييم السوق (Daily P&L MTM)
        </button>
        <button
          onClick={() => setSelectedReport('COLLATERAL_AUDIT')}
          className={`px-4 py-2 rounded transition-colors ${
            selectedReport === 'COLLATERAL_AUDIT' ? 'bg-[#8A1538] text-white font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          تقرير تدقيق الضمانات والهامش (Collateral Audit)
        </button>
      </div>

      {/* Official Printable Bank Report Sheet */}
      <div className="bg-[#0b1120] print:bg-white print:text-black border border-slate-800 rounded p-8 space-y-6 shadow-xl">
        
        {/* Report Official Letterhead */}
        <div className="border-b border-slate-800 print:border-black pb-5 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-[#8A1538] border border-[#C5A059] flex items-center justify-center text-[#C5A059] font-bold text-lg print:border-black">
              RQ
            </div>
            <div>
              <h1 className="text-lg font-bold text-white print:text-black">
                بنك راينو كوانت قطر — الإدارة المصرفية للمشتقات وأسواق الطاقة
              </h1>
              <div className="text-xs text-[#C5A059] print:text-gray-700 font-mono">
                RhinoQuant Qatar Institutional Banking & Energy Derivatives Desk
              </div>
              <div className="text-[11px] text-slate-400 print:text-gray-600 mt-0.5">
                الدوحة، دولة قطر · ص.ب 28919 · مرخص وخاضع لرقابة مصرف قطر المركزي
              </div>
            </div>
          </div>

          <div className="text-left font-mono text-xs text-slate-400 print:text-black">
            <div>التاريخ: {new Date().toLocaleDateString('ar-QA')}</div>
            <div>رقم المرجع: QCB-REP-2026-092</div>
            <div className="text-emerald-400 print:text-green-800 font-bold">الحالة: معتمد ومدقق</div>
          </div>
        </div>

        {/* Report Title */}
        <div className="text-center py-2">
          <h2 className="text-base font-bold text-white print:text-black">
            {selectedReport === 'QCB_COMPLIANCE' && 'تقرير الإفصاح الرقابي الدوري لمشتقات الطاقة والغاز الطبيعي المسال'}
            {selectedReport === 'DAILY_PNL' && 'تقرير تقييم المراكز السوقية والأرباح والخسائر اليومية للمحفظة'}
            {selectedReport === 'COLLATERAL_AUDIT' && 'تقرير كفاية الضمانات والالتزام بمتطلبات هوامش المشتقات غير المسواة'}
          </h2>
          <div className="text-xs text-slate-400 print:text-gray-600 font-mono mt-1">
            وفقاً لمعايير المحاسبة الدولية IFRS 9 وتوجيهات لجنة بازل ومصرف قطر المركزي
          </div>
        </div>

        {/* Executive Summary Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="bg-slate-900/90 print:bg-gray-100 p-3 rounded border border-slate-800 print:border-gray-300">
            <div className="text-[10px] text-slate-400 print:text-gray-600 font-sans">إجمالي القيمة الاسمية (Gross)</div>
            <div className="text-sm font-bold text-white print:text-black mt-1">
              ${(totalNotionalUSD / 1000000).toFixed(1)}M USD
            </div>
          </div>

          <div className="bg-slate-900/90 print:bg-gray-100 p-3 rounded border border-slate-800 print:border-gray-300">
            <div className="text-[10px] text-slate-400 print:text-gray-600 font-sans">صافي القيمة السوقية (MTM)</div>
            <div className="text-sm font-bold text-emerald-400 print:text-green-700 mt-1">
              +${(totalMtmUSD / 1000000).toFixed(2)}M USD
            </div>
          </div>

          <div className="bg-slate-900/90 print:bg-gray-100 p-3 rounded border border-slate-800 print:border-gray-300">
            <div className="text-[10px] text-slate-400 print:text-gray-600 font-sans">عدد العقود النشطة</div>
            <div className="text-sm font-bold text-white print:text-black mt-1">
              {trades.length} عقود
            </div>
          </div>

          <div className="bg-slate-900/90 print:bg-gray-100 p-3 rounded border border-slate-800 print:border-gray-300">
            <div className="text-[10px] text-slate-400 print:text-gray-600 font-sans">نسبة كفاية رأس المال</div>
            <div className="text-sm font-bold text-[#C5A059] print:text-black mt-1">
              18.4% (الحد الأدنى 12.5%)
            </div>
          </div>
        </div>

        {/* Detailed Breakdown Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-right tabular-nums">
            <thead>
              <tr className="border-b border-slate-800 print:border-black text-slate-400 print:text-black font-sans text-[11px]">
                <th className="py-2 px-2 text-right">رقم الصفقة</th>
                <th className="py-2 px-2 text-right">الطرف المقابل</th>
                <th className="py-2 px-2 text-right">نوع الأداة</th>
                <th className="py-2 px-2 text-right">الحجم (MMBtu)</th>
                <th className="py-2 px-2 text-right">سعر التنفيذ</th>
                <th className="py-2 px-2 text-right">القيمة السوقية العادلة</th>
                <th className="py-2 px-2 text-right">الهامش المودع</th>
                <th className="py-2 px-2 text-right">الحالة الرقابية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 print:divide-gray-300 text-slate-200 print:text-black">
              {trades.map((t) => (
                <tr key={t.id}>
                  <td className="py-2 px-2 font-bold">{t.id}</td>
                  <td className="py-2 px-2 font-sans">{t.counterpartyName}</td>
                  <td className="py-2 px-2 font-sans">{t.instrumentNameAr}</td>
                  <td className="py-2 px-2">{t.volumeMMBtu.toLocaleString()}</td>
                  <td className="py-2 px-2 font-bold">${t.fixedPriceUSD.toFixed(2)}</td>
                  <td className="py-2 px-2 font-bold text-emerald-400 print:text-green-800">
                    +${(t.currentMtmUSD / 1000).toFixed(0)}k
                  </td>
                  <td className="py-2 px-2">${(t.collateralPostedUSD / 1000).toFixed(0)}k</td>
                  <td className="py-2 px-2 font-sans text-[11px]">{t.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Regulatory Attestation Sign-off */}
        <div className="border-t border-slate-800 print:border-black pt-6 grid grid-cols-2 gap-8 text-xs text-slate-400 print:text-black font-sans">
          <div>
            <div className="font-bold text-white print:text-black mb-1">
              مدير إدارة المخاطر المالية:
            </div>
            <div>د. عبد الله الهاجري (PhD, Financial Engineering)</div>
            <div className="text-[10px] text-slate-500 print:text-gray-600 mt-1">
              التوقيع الرقمي: SHA256-QCB-RISK-VERIFIED-98210
            </div>
          </div>

          <div className="text-left">
            <div className="font-bold text-white print:text-black mb-1">
              رئيس إدارة الالتزام والرقابة المصرفية:
            </div>
            <div>محمد بن ناصر الأنصاري</div>
            <div className="text-[10px] text-slate-500 print:text-gray-600 mt-1">
              ختم الاعتماد المؤسسي · بنك راينو كوانت قطر
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
