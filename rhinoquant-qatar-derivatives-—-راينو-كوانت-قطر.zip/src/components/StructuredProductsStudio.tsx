import React, { useState } from 'react';
import { 
  Layers, 
  ShieldCheck, 
  Percent, 
  Sliders, 
  CheckCircle2, 
  ArrowUpRight, 
  FileCheck, 
  HelpCircle,
  Clock,
  Sparkles,
  DollarSign
} from 'lucide-react';
import { StructuredProduct } from '../types';

interface StructuredProductsStudioProps {
  products: StructuredProduct[];
  onAddNewProduct: (prod: StructuredProduct) => void;
}

export const StructuredProductsStudio: React.FC<StructuredProductsStudioProps> = ({
  products,
  onAddNewProduct,
}) => {
  const [selectedProduct, setSelectedProduct] = useState<StructuredProduct>(products[0]);
  const [isBuilderOpen, setIsBuilderOpen] = useState<boolean>(false);

  // Custom Builder State
  const [customNameAr, setCustomNameAr] = useState<string>('مذكرة حماية رأس المال المرتبطة بالغاز المسال - إصدار الدوحة');
  const [customUnderlying, setCustomUnderlying] = useState<string>('Platts JKM Forward Index');
  const [customNotionalUSD, setCustomNotionalUSD] = useState<number>(50000000);
  const [customTenorMonths, setCustomTenorMonths] = useState<number>(18);
  const [customProtectionPercent, setCustomProtectionPercent] = useState<number>(100);
  const [customParticipationPercent, setCustomParticipationPercent] = useState<number>(85);
  const [customCouponPercent, setCustomCouponPercent] = useState<number>(4.5);
  const [customBankMarginBps, setCustomBankMarginBps] = useState<number>(65);
  const [submittedForApproval, setSubmittedForApproval] = useState<boolean>(false);

  // Financial decomposition calculation:
  // Bond component = Notional * Protection% / (1 + r)^T
  const discountRate = 0.0575; // QCB Repo Rate 5.75%
  const tenorYears = customTenorMonths / 12;
  const bondDiscountFactor = 1 / Math.pow(1 + discountRate, tenorYears);
  const bondComponentPercent = (customProtectionPercent * bondDiscountFactor);
  const derivativeBudgetPercent = Math.max(0, 100 - bondComponentPercent - (customBankMarginBps / 100));

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const newProd: StructuredProduct = {
      id: `STR-QTR-CUSTOM-${Date.now().toString().slice(-3)}`,
      nameAr: customNameAr,
      nameEn: 'Qatar Energy Bespoke Structured Note',
      category: customProtectionPercent >= 95 ? 'CAPITAL_PROTECTED' : 'SPREAD_OPTIMIZER',
      targetAudienceAr: 'صناديق الثروة السيادية والمؤسسات المالية والمستهلكين المؤهلين',
      underlyingBenchmark: customUnderlying,
      notionalUSD: customNotionalUSD,
      tenorMonths: customTenorMonths,
      participationRatePercent: customParticipationPercent,
      capitalProtectionPercent: customProtectionPercent,
      couponYieldAnnualPercent: customCouponPercent,
      bankMarginBasisPoints: customBankMarginBps,
      estimatedFairValuePercent: 100.8,
      maxPotentialReturnPercent: customParticipationPercent * 0.35 + customCouponPercent * tenorYears,
      maxLossPercent: 100 - customProtectionPercent,
      status: 'بانتظار موافقة المخاطر',
      descriptionAr: `منتج مهيكل مخصص بقيمة اسمية $${(customNotionalUSD / 1000000).toFixed(1)}M مع حماية رأس المال بنسبة ${customProtectionPercent}% والمشاركة بنسبة ${customParticipationPercent}% في أداء المؤشر.`,
      bondComponentPercent: parseFloat(bondComponentPercent.toFixed(1)),
      derivativeComponentPercent: parseFloat(derivativeBudgetPercent.toFixed(1)),
      qcbEligibility: true,
      breakevenPriceUSD: 14.35,
    };

    onAddNewProduct(newProd);
    setSelectedProduct(newProd);
    setSubmittedForApproval(true);
    setIsBuilderOpen(false);
    setTimeout(() => setSubmittedForApproval(false), 5000);
  };

  return (
    <div className="space-y-6">
      
      {/* Studio Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0b1120] border border-slate-800 p-5 rounded">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#C5A059]" />
            <h2 className="text-base font-bold text-white">
              استوديو هندسة وتغليف المنتجات المالية (Structured Products Studio)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            تصميم وهيكلة المذكرات المحمية لرأس المال (Capital-Protected Notes)، ومبادلات الأسقف السعرية للمستهلكين، واستراتيجيات مراجحة الفروق الجغرافية بين آسيا وأوروبا، مع التفكيك الرياضي لمكونات السندات الصفرية والمشتقات.
          </p>
        </div>

        <button
          onClick={() => setIsBuilderOpen(!isBuilderOpen)}
          className="px-4 py-2 rounded font-bold text-xs text-white bg-gradient-to-r from-[#8A1538] to-[#5e0f26] border border-[#C5A059]/40 hover:brightness-110 transition-all flex items-center gap-2 shrink-0"
        >
          <Sliders className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>{isBuilderOpen ? 'إغلاق نافذة الهيكلة' : 'بناء منتج مهيكل مخصص (Create Product)'}</span>
        </button>
      </div>

      {submittedForApproval && (
        <div className="bg-emerald-950/40 border border-emerald-600/50 p-4 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>تم إرسال المنتج المهيكل بنجاح إلى لجنة حوكمة المنتجات المصرفية ومراجعة المخاطر والامتثال بمصرف قطر المركزي.</span>
        </div>
      )}

      {/* Interactive Bespoke Builder Drawer (Collapsible) */}
      {isBuilderOpen && (
        <form onSubmit={handleCreateProduct} className="bg-[#0e1628] border border-[#C5A059]/40 rounded p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#C5A059]" />
              <span>منشئ المنتجات المهيكلة المخصصة (Bespoke Structuring Studio)</span>
            </h3>
            <span className="text-xs font-mono text-emerald-400">معتمد لمعايير QCB Basel III</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
            {/* Column 1: Core Parameters */}
            <div className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">اسم المنتج التجاري المؤسسي</label>
                <input
                  type="text"
                  value={customNameAr}
                  onChange={(e) => setCustomNameAr(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">الأصل المرجعي (Underlying Asset)</label>
                <select
                  value={customUnderlying}
                  onChange={(e) => setCustomUnderlying(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-white font-mono text-xs"
                >
                  <option value="Platts JKM Forward Index">Platts JKM Asian LNG Forward Strip</option>
                  <option value="Dutch TTF European Gas Strip">Dutch TTF European Natural Gas</option>
                  <option value="JKM - TTF Regional Spread">JKM vs TTF Trans-Oceanic Spread Differential</option>
                  <option value="Brent / LNG Slope Hybrid Index">Brent Oil Indexed Slope (12.8% Formula)</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>القيمة الاسمية المستهدفة (Notional USD):</span>
                  <span className="font-mono text-white font-bold">${(customNotionalUSD / 1000000).toFixed(0)}M USD</span>
                </div>
                <input
                  type="range"
                  min="10000000"
                  max="200000000"
                  step="5000000"
                  value={customNotionalUSD}
                  onChange={(e) => setCustomNotionalUSD(Number(e.target.value))}
                  className="w-full accent-[#8A1538]"
                />
              </div>
            </div>

            {/* Column 2: Protection & Payoff Engine */}
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>مستوى حماية رأس المال عند الاستحقاق:</span>
                  <span className="font-mono text-emerald-400 font-bold">{customProtectionPercent}%</span>
                </div>
                <input
                  type="range"
                  min="80"
                  max="100"
                  step="5"
                  value={customProtectionPercent}
                  onChange={(e) => setCustomProtectionPercent(Number(e.target.value))}
                  className="w-full accent-emerald-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                  <span>حماية مشروطة (80%)</span>
                  <span>حماية 95%</span>
                  <span>حماية كاملة 100%</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>نسبة المشاركة في صعود المؤشر (Participation Rate):</span>
                  <span className="font-mono text-sky-400 font-bold">{customParticipationPercent}%</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="140"
                  step="5"
                  value={customParticipationPercent}
                  onChange={(e) => setCustomParticipationPercent(Number(e.target.value))}
                  className="w-full accent-sky-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>مدة المنتج (Tenor):</span>
                  <span className="font-mono text-white font-bold">{customTenorMonths} شهراً ({tenorYears.toFixed(1)} سنة)</span>
                </div>
                <input
                  type="range"
                  min="6"
                  max="36"
                  step="6"
                  value={customTenorMonths}
                  onChange={(e) => setCustomTenorMonths(Number(e.target.value))}
                  className="w-full accent-[#C5A059]"
                />
              </div>
            </div>

            {/* Column 3: Quantitative Decomposition & Margins */}
            <div className="space-y-3 bg-slate-900/90 border border-slate-800 p-4 rounded font-mono">
              <div className="text-[11px] font-bold text-slate-300 font-sans border-b border-slate-800 pb-1">
                تفكيك هيكل التكلفة الاستثمارية:
              </div>

              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>مكون السند الصفري (Zero-Coupon Bond):</span>
                <span className="text-emerald-400 font-bold">{bondComponentPercent.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>ميزانية شراء الخيارات (Option Budget):</span>
                <span className="text-sky-400 font-bold">{derivativeBudgetPercent.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>هامش البنك المصرفي (Structuring Margin):</span>
                <span className="text-[#C5A059] font-bold">{customBankMarginBps} bps</span>
              </div>

              <div className="border-t border-slate-800 pt-2 flex justify-between text-slate-300 text-[11px] font-sans">
                <span>أقصى عائد متوقع:</span>
                <span className="text-emerald-400 font-bold font-mono">
                  +{(customParticipationPercent * 0.35 + customCouponPercent * tenorYears).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsBuilderOpen(false)}
              className="px-4 py-2 rounded text-slate-400 hover:text-white bg-slate-800 text-xs"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded font-bold text-white bg-gradient-to-r from-[#8A1538] to-[#6b112c] border border-[#C5A059]/40 hover:brightness-110 text-xs flex items-center gap-1.5"
            >
              <FileCheck className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>إرسال المنتج للجنة الموافقات (Submit for Approval)</span>
            </button>
          </div>
        </form>
      )}

      {/* Catalog of Institutional Products */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {products.map((prod) => {
          const isSelected = selectedProduct.id === prod.id;
          return (
            <div
              key={prod.id}
              onClick={() => setSelectedProduct(prod)}
              className={`p-5 rounded border transition-all cursor-pointer relative ${
                isSelected
                  ? 'bg-[#0f172a] border-[#C5A059] shadow-md'
                  : 'bg-[#0b1120] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-slate-400">{prod.id}</span>
                    <span className="text-[10px] text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-950/40 border border-emerald-800/40 font-mono">
                      {prod.status}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white mt-1 leading-snug">{prod.nameAr}</h3>
                  <div className="text-[11px] text-[#C5A059] font-mono mt-0.5">{prod.nameEn}</div>
                </div>

                <div className="text-left font-mono shrink-0">
                  <div className="text-base font-bold text-white tabular-nums">
                    ${(prod.notionalUSD / 1000000).toFixed(0)}M
                  </div>
                  <div className="text-[10px] text-slate-400 font-sans">القيمة الاسمية</div>
                </div>
              </div>

              <p className="text-xs text-slate-300 mt-2.5 leading-relaxed line-clamp-2">
                {prod.descriptionAr}
              </p>

              {/* Metrics Strip */}
              <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800/80 text-center font-mono text-xs">
                <div>
                  <div className="text-[10px] text-slate-500 font-sans">حماية رأس المال</div>
                  <div className="text-emerald-400 font-bold mt-0.5">{prod.capitalProtectionPercent}%</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 font-sans">نسبة المشاركة</div>
                  <div className="text-sky-400 font-bold mt-0.5">{prod.participationRatePercent}%</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 font-sans">المدة الزمنية</div>
                  <div className="text-white font-bold mt-0.5">{prod.tenorMonths} شهر</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Product Detailed Institutional Breakdown */}
      {selectedProduct && (
        <div className="bg-[#0b1120] border border-slate-800 rounded p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span>التحليل المالي التفكيكي للمنتج: {selectedProduct.nameAr}</span>
              </h3>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                الفئة المستهدفة: {selectedProduct.targetAudienceAr}
              </div>
            </div>

            <div className="text-left font-mono text-xs text-slate-400">
              <span>القيمة العادلة المقدرة: </span>
              <strong className="text-emerald-400 font-bold">{selectedProduct.estimatedFairValuePercent}%</strong>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
              <div className="text-[11px] text-slate-400">مكون السندات الصفرية (Zero-Bond)</div>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                {selectedProduct.bondComponentPercent}%
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">خصم عوائد مصرف قطر المركزي</div>
            </div>

            <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
              <div className="text-[11px] text-slate-400">مكون المشتقات والخيارات (Options)</div>
              <div className="text-xl font-bold font-mono text-sky-400 mt-1">
                {selectedProduct.derivativeComponentPercent}%
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">لشراء خيارات الصعود والانتشار</div>
            </div>

            <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
              <div className="text-[11px] text-slate-400">هامش البنك المصرفي (Structuring Margin)</div>
              <div className="text-xl font-bold font-mono text-[#C5A059] mt-1">
                {selectedProduct.bankMarginBasisPoints} bps
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">صافي ربحية البنك عند الإصدار</div>
            </div>

            <div className="bg-slate-900/90 p-4 rounded border border-slate-800">
              <div className="text-[11px] text-slate-400">أقصى خسارة تعاقدية محتملة</div>
              <div className="text-xl font-bold font-mono text-rose-400 mt-1">
                {selectedProduct.maxLossPercent}%
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                {selectedProduct.maxLossPercent === 0 ? 'رأس المال محمي 100%' : 'مشروط بمستوى الحاجز'}
              </div>
            </div>
          </div>

          <div className="bg-slate-900/60 p-4 rounded border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>
                مطابقة المتطلبات التنظيمية: متوافق مع إرشادات مصرف قطر المركزي (QCB Circular 2024/09) للمنتجات المهيكلة ذات الأغراض التحوطية والاستثمارية المؤسسية.
              </span>
            </div>
            <span className="text-slate-400 font-mono text-[11px] shrink-0">ISIN: QA0928371928</span>
          </div>
        </div>
      )}

    </div>
  );
};
