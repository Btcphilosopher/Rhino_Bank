export type MarketBenchmark = 
  | 'JKM'       // Platts Japan Korea Marker ($/MMBtu)
  | 'TTF'       // Dutch Title Transfer Facility ($/MMBtu & €/MWh)
  | 'HENRY_HUB' // US Henry Hub ($/MMBtu)
  | 'BRENT'     // Brent Crude Oil ($/bbl)
  | 'NBP'       // UK National Balancing Point (p/therm)
  | 'FREIGHT'   // LNG Shipping Charter Rate ($/day)
  | 'QCB_RATE'; // Qatar Central Bank Policy Rate (%)

export interface BenchmarkQuote {
  id: string;
  nameAr: string;
  nameEn: string;
  symbol: string;
  category: 'LNG' | 'GAS' | 'OIL' | 'SHIPPING' | 'RATES';
  spotPrice: number;
  currency: string;
  unit: string;
  change24h: number;
  changePercent: number;
  high24h: number;
  low24h: number;
  impliedVol: number; // in percent, e.g. 38.5%
  historicalVol: number;
  liquidityTier: 'عالية جداً (Tier 1)' | 'عالية (Tier 2)' | 'متوسطة (Tier 3)';
  source: string;
  lastUpdated: string;
  isSimulated?: boolean;
}

export interface ForwardCurvePoint {
  tenor: string; // e.g. "يونيو 2026 (M1)", "يوليو 2026 (M2)", ...
  monthCode: string; // "M1", "M2", "Q3-26", "Cal27"
  daysToMaturity: number;
  jkmPrice: number;
  ttfPrice: number;
  henryHubPrice: number;
  brentPrice: number;
  freightRate: number; // $/day
  spreadJkmTtf: number; // JKM - TTF
}

export interface OptionPricingInputs {
  instrumentType: 'CALL' | 'PUT' | 'SPREAD_OPTION' | 'COMMODITY_SWAP';
  underlyingBenchmark: MarketBenchmark;
  secondaryBenchmark?: MarketBenchmark; // for spread options
  forwardPrice: number; // F
  secondaryForwardPrice?: number; // F2
  strikePrice: number;  // K
  timeToMaturityYears: number; // T
  volatility: number;   // sigma (e.g. 0.35)
  secondaryVolatility?: number; // sigma2
  correlation?: number; // rho between asset 1 and 2
  riskFreeRate: number; // r (e.g. 0.0525)
  notionalVolumeMMBtu: number; // e.g. 3,400,000 MMBtu (approx 1 cargo)
}

export interface GreeksResult {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
}

export interface PricingResult {
  fairValuePerUnit: number;
  totalPremiumUSD: number;
  totalPremiumQAR: number;
  intrinsicValue: number;
  timeValue: number;
  greeks: GreeksResult;
  modelName: string;
  modelVersion: string;
  discountFactor: number;
  cashflowsSchedule: { date: string; descriptionAr: string; amountUSD: number }[];
  auditHash: string;
  calculatedAt: string;
}

export interface MonteCarloPath {
  step: number;
  timeYears: number;
  mean: number;
  upper95: number;
  lower95: number;
  path1: number;
  path2: number;
  path3: number;
}

export interface StructuredProduct {
  id: string;
  nameAr: string;
  nameEn: string;
  category: 'CAPITAL_PROTECTED' | 'RANGE_ACCRUAL' | 'SPREAD_OPTIMIZER' | 'COLLAR' | 'CAPPED_SWAP';
  targetAudienceAr: string;
  underlyingBenchmark: string;
  notionalUSD: number;
  tenorMonths: number;
  participationRatePercent: number;
  capitalProtectionPercent: number;
  barrierLevelPercent?: number;
  couponYieldAnnualPercent: number;
  bankMarginBasisPoints: number;
  estimatedFairValuePercent: number;
  maxPotentialReturnPercent: number;
  maxLossPercent: number;
  status: 'مسودة (Draft)' | 'قيد المراجعة الكمية' | 'بانتظار موافقة المخاطر' | 'معتمد ومتاح للتوزيع' | 'تم الإصدار بنجاح';
  descriptionAr: string;
  bondComponentPercent: number;
  derivativeComponentPercent: number;
  qcbEligibility: boolean;
  breakevenPriceUSD: number;
}

export interface InstitutionalClient {
  id: string;
  nameAr: string;
  nameEn: string;
  type: 'PRODUCER_EXPORTER' | 'IMPORTER_OFFTAKER' | 'SHIPPING_LOGISTICS' | 'INDUSTRIAL_CONSUMER' | 'FINANCIAL_INSTITUTION';
  jurisdiction: string;
  creditRating: 'AAA' | 'AA+' | 'AA' | 'A+' | 'A' | 'BBB+';
  kycAmlStatus: 'معتمد بالكامل (Verified)' | 'قيد التحديث الدوري' | 'مطلوب مستندات إضافية';
  qcbRegulatoryTier: 'عميل مؤسسي مؤهل (Tier 1)' | 'مؤسسة مالية مرخصة' | 'مستهلك صناعي كبير';
  creditLimitUSD: number;
  creditUsedUSD: number;
  marginAvailableUSD: number;
  settlementCurrency: 'USD' | 'QAR' | 'EUR';
  allowedInstruments: string[];
  openTradesCount: number;
  primaryContact: string;
  headquarters: string;
}

export interface TradeBlotterItem {
  id: string;
  dealDate: string;
  valueDate: string;
  maturityDate: string;
  counterpartyId: string;
  counterpartyName: string;
  instrumentType: string;
  instrumentNameAr: string;
  underlying: string;
  direction: 'شراء (BUY)' | 'بيع (SELL)';
  volumeMMBtu: number;
  fixedPriceUSD: number;
  currentMtmUSD: number;
  unrealizedPnlUSD: number;
  marginRequiredUSD: number;
  collateralPostedUSD: number;
  status: 'تأكيد إلكتروني (Confirmed)' | 'نشط ومستمر (Active)' | 'مطلوب هامش إضافي (Margin Call)' | 'قريب الاستحقاق (Maturing)' | 'تمت التسوية (Settled)';
  traderId: string;
  riskApprovedBy: string;
}

export interface RFQItem {
  id: string;
  clientId: string;
  clientName: string;
  benchmark: MarketBenchmark;
  instrumentType: string;
  volumeMMBtu: number;
  tenor: string;
  bidPriceUSD: number;
  askPriceUSD: number;
  bankSpreadUSD: number;
  submittedAt: string;
  expiresAt: string;
  status: 'طلب جديد (Pending)' | 'تم التسعير (Quoted)' | 'قيد التفاوض (Negotiating)' | 'معتمد ومُنفذ (Executed)' | 'منتهي الصلاحية (Expired)';
}

export interface StressScenario {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  jkmShockPercent: number;
  ttfShockPercent: number;
  henryHubShockPercent: number;
  freightShockPercent: number;
  oilShockPercent: number;
  fxShockUsdEurPercent: number;
  portfolioImpactUSD: number;
  marginCallRequiredUSD: number;
  probabilityScore: 'منخفضة' | 'متوسطة' | 'مرتفعة';
}

export interface CollateralItem {
  id: string;
  counterparty: string;
  assetType: 'CASH_USD' | 'CASH_QAR' | 'QATAR_GOV_BOND' | 'GCC_SOVEREIGN_BOND' | 'LETTER_OF_CREDIT';
  nominalValueUSD: number;
  haircutPercent: number;
  eligibleCollateralValueUSD: number;
  marginCoverageRatioPercent: number;
  lastValuationDate: string;
  status: 'فائض ضمانات (Surplus)' | 'كفاية تامة (Adequate)' | 'نقص في التغطية (Deficit)';
}

export interface MarketNewsItem {
  id: string;
  timeAr: string;
  titleAr: string;
  summaryAr: string;
  category: 'قطر وتوسعة الشمال' | 'الأسواق الآسيوية JKM' | 'الأسواق الأوروبية TTF' | 'الشحن والخدمات اللوجستية' | 'السياسات النقدية والمصرفية';
  impact: 'إيجابي للغاز' | 'سلبي للأسعار' | 'حيادي / هيكلي' | 'عالي التقلب';
  source: string;
  verified: boolean;
}
