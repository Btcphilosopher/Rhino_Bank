import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { NavigationTabs } from './components/NavigationTabs';
import { TradingTerminal } from './components/TradingTerminal';
import { LNGDerivativesModule } from './components/LNGDerivativesModule';
import { QuantPricingModule } from './components/QuantPricingModule';
import { StructuredProductsStudio } from './components/StructuredProductsStudio';
import { SalesAndDistribution } from './components/SalesAndDistribution';
import { TradeLifecycleBlotter } from './components/TradeLifecycleBlotter';
import { RiskAndCollateral } from './components/RiskAndCollateral';
import { MarketIntelligence } from './components/MarketIntelligence';
import { BankingReports } from './components/BankingReports';
import { AcceptanceScenariosRunner } from './components/AcceptanceScenariosRunner';
import { NewRfqModal } from './components/NewRfqModal';

import { 
  INITIAL_BENCHMARKS, 
  INITIAL_FORWARD_CURVE, 
  INITIAL_CLIENTS, 
  INITIAL_STRUCTURED_PRODUCTS, 
  INITIAL_TRADES_BLOTTER, 
  INITIAL_RFQS, 
  INITIAL_STRESS_SCENARIOS, 
  INITIAL_COLLATERAL, 
  INITIAL_MARKET_NEWS 
} from './data/mockMarketData';

import { 
  BenchmarkQuote, 
  ForwardCurvePoint, 
  StructuredProduct, 
  InstitutionalClient, 
  TradeBlotterItem, 
  RFQItem,
  OptionPricingInputs,
  PricingResult
} from './types';

// Asset Paths
const HERO_LNG_TERMINAL = '/src/assets/images/hero_qatar_lng_terminal_1792575462878.jpg';
const EXECUTIVE_SEAL = '/src/assets/images/executive_seal_qatar_1792575462698.jpg';
const TRADING_FLOOR = '/src/assets/images/trading_floor_doha_1792575463246.jpg';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('terminal');
  const [benchmarks, setBenchmarks] = useState<BenchmarkQuote[]>(INITIAL_BENCHMARKS);
  const [forwardCurve, setForwardCurve] = useState<ForwardCurvePoint[]>(INITIAL_FORWARD_CURVE);
  const [clients, setClients] = useState<InstitutionalClient[]>(INITIAL_CLIENTS);
  const [products, setProducts] = useState<StructuredProduct[]>(INITIAL_STRUCTURED_PRODUCTS);
  const [trades, setTrades] = useState<TradeBlotterItem[]>(INITIAL_TRADES_BLOTTER);
  const [rfqs, setRfqs] = useState<RFQItem[]>(INITIAL_RFQS);
  const [isNewRfqModalOpen, setIsNewRfqModalOpen] = useState<boolean>(false);

  // Gentle live market ticker simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setBenchmarks((prev) =>
        prev.map((b) => {
          if (b.category === 'RATES') return b;
          const fluctuation = (Math.random() - 0.49) * 0.04;
          const newPrice = Math.max(0.1, parseFloat((b.spotPrice + fluctuation).toFixed(2)));
          const change24h = parseFloat((newPrice - (b.spotPrice - b.change24h)).toFixed(2));
          const changePercent = parseFloat(((change24h / (newPrice - change24h)) * 100).toFixed(2));
          return {
            ...b,
            spotPrice: newPrice,
            change24h,
            changePercent,
            lastUpdated: new Date().toLocaleTimeString('ar-QA') + ' بتوقيت الدوحة',
          };
        })
      );
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleExecuteQuickTrade = (tradeData: Partial<TradeBlotterItem>) => {
    const newTrade: TradeBlotterItem = {
      id: tradeData.id || `TRD-${Date.now().toString().slice(-4)}`,
      dealDate: tradeData.dealDate || new Date().toISOString().split('T')[0],
      valueDate: tradeData.valueDate || new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      maturityDate: tradeData.maturityDate || '2026-12-31',
      counterpartyId: tradeData.counterpartyId || 'CLT-QE-TRADING',
      counterpartyName: tradeData.counterpartyName || 'قطر للطاقة للتجارة',
      instrumentType: tradeData.instrumentType || 'COMMODITY_SWAP',
      instrumentNameAr: tradeData.instrumentNameAr || 'مبادلة أسعار الغاز المسال',
      underlying: tradeData.underlying || 'JKM-LNG',
      direction: tradeData.direction || 'شراء (BUY)',
      volumeMMBtu: tradeData.volumeMMBtu || 3400000,
      fixedPriceUSD: tradeData.fixedPriceUSD || 14.35,
      currentMtmUSD: 0,
      unrealizedPnlUSD: 0,
      marginRequiredUSD: tradeData.marginRequiredUSD || 1500000,
      collateralPostedUSD: tradeData.collateralPostedUSD || 1800000,
      status: 'تأكيد إلكتروني (Confirmed)',
      traderId: 'TRD-DOH-01 (مكتب الدوحة المؤسسي)',
      riskApprovedBy: 'RISK-DIR-01 (د. عبد الله الهاجري)',
    };

    setTrades((prev) => [newTrade, ...prev]);

    // Update Client credit limit
    setClients((prev) =>
      prev.map((c) =>
        c.id === newTrade.counterpartyId
          ? {
              ...c,
              creditUsedUSD: c.creditUsedUSD + (newTrade.volumeMMBtu * newTrade.fixedPriceUSD * 0.1),
              openTradesCount: c.openTradesCount + 1,
            }
          : c
      )
    );
  };

  const handleSaveToBlotterFromQuant = (result: PricingResult, inputs: OptionPricingInputs) => {
    const newTrade: TradeBlotterItem = {
      id: `TRD-${Date.now().toString().slice(-4)}`,
      dealDate: new Date().toISOString().split('T')[0],
      valueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      maturityDate: new Date(Date.now() + inputs.timeToMaturityYears * 365 * 86400000).toISOString().split('T')[0],
      counterpartyId: 'CLT-JERA-JAPAN',
      counterpartyName: 'جيرا اليابانية للطاقة (JERA)',
      instrumentType: inputs.instrumentType,
      instrumentNameAr: `عقد ${inputs.instrumentType} على ${inputs.underlyingBenchmark} بسعر تنفيذ $${inputs.strikePrice.toFixed(2)}`,
      underlying: inputs.underlyingBenchmark,
      direction: inputs.instrumentType === 'CALL' ? 'شراء (BUY)' : 'بيع (SELL)',
      volumeMMBtu: inputs.notionalVolumeMMBtu,
      fixedPriceUSD: result.fairValuePerUnit,
      currentMtmUSD: result.totalPremiumUSD * 0.05,
      unrealizedPnlUSD: result.totalPremiumUSD * 0.05,
      marginRequiredUSD: result.totalPremiumUSD * 0.15,
      collateralPostedUSD: result.totalPremiumUSD * 0.20,
      status: 'تأكيد إلكتروني (Confirmed)',
      traderId: 'TRD-DOH-02 (المكتب الكمي)',
      riskApprovedBy: 'RISK-AUTO-ALGO-V4',
    };

    setTrades((prev) => [newTrade, ...prev]);
  };

  const handleAddNewProduct = (prod: StructuredProduct) => {
    setProducts((prev) => [prod, ...prev]);
  };

  const handleQuoteRfq = (rfqId: string, bid: number, ask: number) => {
    setRfqs((prev) =>
      prev.map((r) =>
        r.id === rfqId
          ? { ...r, bidPriceUSD: bid, askPriceUSD: ask, status: 'تم التسعير (Quoted)' }
          : r
      )
    );
  };

  const handleExecuteRfq = (rfq: RFQItem) => {
    setRfqs((prev) =>
      prev.map((r) => (r.id === rfq.id ? { ...r, status: 'معتمد ومُنفذ (Executed)' } : r))
    );

    // Book deal into blotter
    handleExecuteQuickTrade({
      counterpartyId: rfq.clientId,
      counterpartyName: rfq.clientName,
      instrumentType: 'COMMODITY_SWAP',
      instrumentNameAr: `${rfq.instrumentType} (${rfq.tenor})`,
      underlying: rfq.benchmark,
      direction: 'بيع (SELL)',
      volumeMMBtu: rfq.volumeMMBtu,
      fixedPriceUSD: rfq.askPriceUSD,
      marginRequiredUSD: rfq.volumeMMBtu * rfq.askPriceUSD * 0.08,
      collateralPostedUSD: rfq.volumeMMBtu * rfq.askPriceUSD * 0.10,
    });
  };

  const handleUpdateTradeStatus = (tradeId: string, newStatus: TradeBlotterItem['status']) => {
    setTrades((prev) =>
      prev.map((t) => (t.id === tradeId ? { ...t, status: newStatus } : t))
    );
  };

  return (
    <div className="min-h-screen bg-[#060913] text-slate-100 flex flex-col selection:bg-[#8A1538] selection:text-white">
      
      {/* Institutional Top Bar Contract */}
      <Header
        benchmarks={benchmarks}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenNewRfq={() => setIsNewRfqModalOpen(true)}
        onOpenScenarioModal={() => setActiveTab('scenarios')}
      />

      {/* Institutional Navigation Ribbon */}
      <NavigationTabs activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Viewport Content */}
      <main className="flex-1 p-6 max-w-[1600px] w-full mx-auto space-y-6">
        
        {/* Module Content Switcher */}
        {activeTab === 'terminal' && (
          <TradingTerminal
            benchmarks={benchmarks}
            forwardCurve={forwardCurve}
            trades={trades}
            rfqs={rfqs}
            onExecuteQuickTrade={handleExecuteQuickTrade}
            onNavigateToTab={setActiveTab}
          />
        )}

        {activeTab === 'lng' && (
          <LNGDerivativesModule
            benchmarks={benchmarks}
            forwardCurve={forwardCurve}
            onOpenNewRfq={() => setIsNewRfqModalOpen(true)}
          />
        )}

        {activeTab === 'quant' && (
          <QuantPricingModule onSaveToBlotter={handleSaveToBlotterFromQuant} />
        )}

        {activeTab === 'structured' && (
          <StructuredProductsStudio
            products={products}
            onAddNewProduct={handleAddNewProduct}
          />
        )}

        {activeTab === 'sales' && (
          <SalesAndDistribution
            clients={clients}
            rfqs={rfqs}
            onQuoteRfq={handleQuoteRfq}
            onExecuteRfq={handleExecuteRfq}
            onOpenNewRfqModal={() => setIsNewRfqModalOpen(true)}
          />
        )}

        {activeTab === 'lifecycle' && (
          <TradeLifecycleBlotter
            trades={trades}
            onUpdateTradeStatus={handleUpdateTradeStatus}
          />
        )}

        {activeTab === 'risk' && (
          <RiskAndCollateral
            scenarios={INITIAL_STRESS_SCENARIOS}
            collateralList={INITIAL_COLLATERAL}
          />
        )}

        {activeTab === 'intelligence' && (
          <MarketIntelligence news={INITIAL_MARKET_NEWS} />
        )}

        {activeTab === 'reports' && (
          <BankingReports trades={trades} benchmarks={benchmarks} />
        )}

        {activeTab === 'scenarios' && (
          <AcceptanceScenariosRunner
            benchmarks={benchmarks}
            forwardCurve={forwardCurve}
            onAddTradeToBlotter={handleExecuteQuickTrade}
            onNavigateToTab={setActiveTab}
          />
        )}

      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-slate-800 bg-[#070b14] px-6 py-4 text-xs text-slate-500 no-print">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">RhinoQuant Qatar — راينو كوانت قطر</span>
            <span>·</span>
            <span>هندسة رأس المال. ذكاء الطاقة. دقة الأسواق.</span>
          </div>

          <div className="flex items-center gap-4 font-mono text-[11px] text-slate-400">
            <span>الدوحة AST (GMT+3)</span>
            <span>·</span>
            <span>خاضع لرقابة مصرف قطر المركزي (QCB)</span>
            <span>·</span>
            <span>سعر ربط الريال: 3.64 QAR/USD</span>
          </div>
        </div>
      </footer>

      {/* New RFQ Drawer/Modal */}
      <NewRfqModal
        isOpen={isNewRfqModalOpen}
        onClose={() => setIsNewRfqModalOpen(false)}
        clients={clients}
        benchmarks={benchmarks}
        onSubmitRfq={(newRfq) => setRfqs((prev) => [newRfq, ...prev])}
      />

    </div>
  );
}
