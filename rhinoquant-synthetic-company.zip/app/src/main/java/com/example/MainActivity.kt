package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RqBackground
import com.example.ui.viewmodel.RhinoQuantViewModel
import com.example.ui.viewmodel.TerminalTab

class MainActivity : ComponentActivity() {

    private val viewModel: RhinoQuantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val state by viewModel.uiState.collectAsState()

                // Back handling: If on secondary tab, back button returns to OVERVIEW
                BackHandler(enabled = state.activeTab != TerminalTab.OVERVIEW) {
                    viewModel.selectTab(TerminalTab.OVERVIEW)
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("terminal_main_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing,
                    containerColor = RqBackground
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(RqBackground)
                    ) {
                        // Top Terminal Header with Entity Selector and Consolidated Toggle
                        TerminalHeader(
                            companies = state.companies,
                            selectedEntityId = state.selectedEntityId,
                            isConsolidated = state.isConsolidatedView,
                            onSelectEntity = { viewModel.selectEntity(it) },
                            onToggleConsolidated = { viewModel.toggleConsolidatedView(it) }
                        )

                        // High Density Tab Navigation Bar
                        TerminalTabBar(
                            selectedTab = state.activeTab,
                            onTabSelected = { viewModel.selectTab(it) }
                        )

                        // Main Content Screen Area
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            when (state.activeTab) {
                                TerminalTab.OVERVIEW -> {
                                    OverviewScreen(
                                        state = state,
                                        onOpenTrade = { viewModel.openTradeDialog() },
                                        onOpenCreateCompany = { viewModel.openCreateCompanyDialog() },
                                        onNavigateTab = { viewModel.selectTab(it) },
                                        onVerifyLedger = {
                                            viewModel.runLedgerReconciliation()
                                            viewModel.selectTab(TerminalTab.AUDIT)
                                        }
                                    )
                                }
                                TerminalTab.INVESTMENT_BOOK -> {
                                    InvestmentBookScreen(
                                        state = state,
                                        onOpenTrade = { viewModel.openTradeDialog() }
                                    )
                                }
                                TerminalTab.DERIVATIVES -> {
                                    DerivativesScreen(
                                        state = state,
                                        onOpenTrade = { viewModel.openTradeDialog() }
                                    )
                                }
                                TerminalTab.DIGITAL_VAULT -> {
                                    DigitalVaultScreen(
                                        state = state,
                                        onOpenTrade = { viewModel.openTradeDialog() }
                                    )
                                }
                                TerminalTab.TREASURY -> {
                                    TreasuryScreen(state = state)
                                }
                                TerminalTab.FINANCIALS -> {
                                    FinancialsScreen(state = state)
                                }
                                TerminalTab.RISK_SCENARIOS -> {
                                    RiskScreen(
                                        state = state,
                                        onUpdateScenario = { eq, r, v, fx ->
                                            viewModel.updateScenarioParameters(eq, r, v, fx)
                                        }
                                    )
                                }
                                TerminalTab.REGISTRY -> {
                                    RegistryScreen(
                                        state = state,
                                        onOpenCreateCompany = { viewModel.openCreateCompanyDialog() },
                                        onSelectEntity = { viewModel.selectEntity(it) }
                                    )
                                }
                                TerminalTab.AUDIT -> {
                                    AuditScreen(
                                        state = state,
                                        onVerifyLedger = { viewModel.runLedgerReconciliation() }
                                    )
                                }
                            }
                        }
                    }

                    // Dialogs
                    if (state.showTradeDialog) {
                        TradeExecutionDialog(
                            instruments = state.instruments,
                            onDismiss = { viewModel.closeTradeDialog() },
                            onExecute = { instId, type, qty, price, useVaultKey ->
                                viewModel.executeTrade(instId, type, qty, price, useVaultKey)
                            }
                        )
                    }

                    if (state.showCreateCompanyDialog) {
                        CreateCompanyDialog(
                            onDismiss = { viewModel.closeCreateCompanyDialog() },
                            onCreate = { name, legalForm, curr, basis, cap, mandate ->
                                viewModel.createCompany(name, legalForm, curr, basis, cap, mandate)
                            }
                        )
                    }

                    state.latestSignedExecution?.let { signedPayload ->
                        if (state.showVaultSignerDialog) {
                            VaultSignerDialog(
                                payload = signedPayload,
                                onDismiss = { viewModel.dismissVaultSignerDialog() }
                            )
                        }
                    }
                }
            }
        }
    }
}
