package com.example.domain.models

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Synthetic Company definition inside RhinoQuant.
 */
@Entity(tableName = "synthetic_companies")
data class SyntheticCompany(
    @PrimaryKey val id: String,
    val name: String,
    val legalForm: String = "Simulated Exempt Holding Corp (RQ-SYNCO)",
    val functionalCurrency: String = "USD",
    val reportingCurrency: String = "USD",
    val accountingBasis: String = "IFRS Modelled / FVTPL",
    val fiscalYearEnd: String = "12-31",
    val inceptionDate: String = "2024-01-01",
    val initialCapital: Double = 100_000_000.0,
    val shareClasses: String = "Class A Voting (80%), Class B Preferred (20%)",
    val parentEntityId: String? = null,
    val ownershipPct: Double = 100.0,
    val investmentMandate: String = "Multi-Asset Absolute Return & Quantitative Capital Preservation",
    val maxGrossLeverage: Double = 3.5,
    val maxVar95Daily: Double = 5_000_000.0,
    val status: String = "ACTIVE",
    val isSimulated: Boolean = true
)

enum class InstrumentType {
    EQUITY,
    FIXED_INCOME,
    FUND_ALTERNATIVE,
    CASH_MONEY_MARKET,
    OPTION,
    FUTURE_FORWARD,
    SWAP,
    CREDIT_DEFAULT_SWAP,
    STRUCTURED_NOTE,
    DIGITAL_ASSET
}

enum class ValuationProvenance {
    SIMULATED,
    VERIFIED_MARKET,
    MODELLED,
    DELAYED,
    HISTORICAL,
    STALE
}

enum class OptionType {
    CALL,
    PUT
}

/**
 * Canonical instrument record
 */
@Entity(tableName = "instruments")
data class Instrument(
    @PrimaryKey val id: String,
    val symbol: String,
    val name: String,
    val type: InstrumentType,
    val subtype: String = "",
    val currency: String = "USD",
    val underlying: String = "",
    val notionalOrQty: Double = 1.0,
    val tradeDate: String = "2024-01-15",
    val maturityDate: String? = null,
    // Fixed Income
    val couponRate: Double = 0.0,
    val couponFrequency: Int = 2,
    val dayCount: String = "30/360",
    val cleanPrice: Double = 100.0,
    val dirtyPrice: Double = 100.0,
    val durationYears: Double = 0.0,
    val convexity: Double = 0.0,
    // Derivatives / Options
    val strike: Double = 0.0,
    val optionType: OptionType? = null,
    val expiryDate: String? = null,
    val contractMultiplier: Double = 100.0,
    val impliedVol: Double = 0.20,
    // Swaps / CDS / Structured
    val swapFixedRate: Double = 0.0,
    val swapFloatingIndex: String = "SOFR 3M",
    val cdsSpreadBps: Double = 0.0,
    val structuredPayoffDesc: String = "",
    // Valuation & Audit
    val valuationMethod: String = "Mark-to-Market",
    val riskRating: String = "AAA",
    val provenance: ValuationProvenance = ValuationProvenance.SIMULATED,
    val reviewerNotes: String = "Seeded institutional model data"
)

/**
 * Position record for a company
 */
@Entity(tableName = "positions")
data class Position(
    @PrimaryKey val positionId: String,
    val entityId: String,
    val instrumentId: String,
    val quantity: Double,
    val costBasis: Double,
    val currentPrice: Double,
    val marketValue: Double,
    val unrealizedPnl: Double,
    val realizedPnl: Double = 0.0,
    val currency: String = "USD",
    val accountingBook: String = "TRADING_BOOK",
    val lastValuationDate: String = "2024-10-10"
)

enum class TransactionType {
    CAPITAL_INJECTION,
    BUY,
    SELL,
    DIVIDEND_RECEIVED,
    COUPON_RECEIVED,
    DEBT_DRAWDOWN,
    DEBT_REPAYMENT,
    OPTION_ENTER,
    SWAP_ENTER,
    MARGIN_POSTED,
    FEE_EXPENSE,
    MTM_REVALUATION
}

/**
 * Transaction history
 */
@Entity(tableName = "transactions")
data class FinancialTransaction(
    @PrimaryKey val txId: String,
    val entityId: String,
    val instrumentId: String,
    val type: TransactionType,
    val quantity: Double,
    val unitPrice: Double,
    val totalAmount: Double,
    val currency: String = "USD",
    val timestamp: Long = System.currentTimeMillis(),
    val effectiveDate: String = "2024-10-10",
    val status: String = "POSTED",
    val referenceId: String = "",
    val auditNotes: String = "Executed via RhinoQuant synthetic execution core"
)

/**
 * Double-entry Journal Entry
 */
@Entity(tableName = "journal_entries")
data class JournalEntry(
    @PrimaryKey val id: String,
    val entityId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val effectiveDate: String = "2024-10-10",
    val description: String,
    val sourceEventId: String,
    val debitAccountCode: String,
    val debitAccountName: String,
    val creditAccountCode: String,
    val creditAccountName: String,
    val amount: Double,
    val currency: String = "USD",
    val functionalAmount: Double = amount,
    val status: String = "POSTED",
    val auditHash: String = ""
)

/**
 * Financing Facility & Liabilities
 */
@Entity(tableName = "financing_facilities")
data class FinancingFacility(
    @PrimaryKey val id: String,
    val entityId: String,
    val facilityType: String,
    val lenderOrCounterparty: String,
    val principalAmount: Double,
    val currency: String = "USD",
    val interestRatePct: Double,
    val startDate: String = "2024-01-01",
    val maturityDate: String = "2026-12-31",
    val accruedInterest: Double = 0.0,
    val collateralAllocated: String = "US Treasury 10Y $20M Pledge",
    val status: String = "ACTIVE"
)

/**
 * Collateral & Margin Agreement
 */
@Entity(tableName = "collateral_agreements")
data class CollateralAgreement(
    @PrimaryKey val id: String,
    val entityId: String,
    val counterparty: String,
    val agreementType: String = "ISDA 2016 VM CSA",
    val currency: String = "USD",
    val initialMarginRequired: Double = 2_000_000.0,
    val variationMarginRequired: Double = 500_000.0,
    val postedCollateralValue: Double = 2_500_000.0,
    val threshold: Double = 0.0,
    val minimumTransferAmount: Double = 250_000.0,
    val marginCallStatus: String = "SATISFIED"
)
