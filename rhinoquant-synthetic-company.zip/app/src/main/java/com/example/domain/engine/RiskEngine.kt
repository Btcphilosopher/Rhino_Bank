package com.example.domain.engine

import com.example.domain.models.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Quantitative portfolio risk, exposures, Greeks aggregation and stress testing engine.
 */
object RiskEngine {

    data class PortfolioRiskSummary(
        val grossMarketValue: Double,
        val netAssetValue: Double,
        val longExposure: Double,
        val shortExposure: Double,
        val grossLeverage: Double,
        val netLeverage: Double,
        // Options Greeks
        val netDeltaNotional: Double,
        val portfolioGamma: Double,
        val portfolioVega: Double,
        val portfolioThetaDaily: Double,
        // Fixed Income Risk
        val weightedDuration: Double,
        val portfolioDv01: Double,
        // Value at Risk
        val var95Daily: Double,
        val var99Daily: Double,
        val expectedShortfall975: Double
    )

    data class StressTestResult(
        val scenarioName: String,
        val scenarioDescription: String,
        val baseNav: Double,
        val stressedNav: Double,
        val navChangeAmount: Double,
        val navChangePct: Double,
        val pnlImpact: Double,
        val marginImpact: Double,
        val requiresMarginCall: Boolean,
        val primaryDriver: String
    )

    /**
     * Calculates comprehensive portfolio risk across all positions and instruments.
     */
    fun calculatePortfolioRisk(
        positions: List<Position>,
        instrumentsMap: Map<String, Instrument>,
        cashBalance: Double,
        totalDebt: Double
    ): PortfolioRiskSummary {
        var longVal = 0.0
        var shortVal = 0.0
        var netDelta = 0.0
        var gammaSum = 0.0
        var vegaSum = 0.0
        var thetaSum = 0.0
        var weightedDurSum = 0.0
        var dv01Sum = 0.0
        var bondTotalValue = 0.0

        for (p in positions) {
            val inst = instrumentsMap[p.instrumentId]
            val mv = p.marketValue
            if (mv >= 0) {
                longVal += mv
            } else {
                shortVal += abs(mv)
            }

            if (inst != null) {
                when (inst.type) {
                    InstrumentType.OPTION -> {
                        val isCall = inst.optionType == OptionType.CALL
                        val s = inst.cleanPrice.coerceAtLeast(10.0)
                        val k = inst.strike.coerceAtLeast(10.0)
                        val greeks = BlackScholes.calculate(s, k, 0.25, 0.045, inst.impliedVol, isCall)
                        val notionalMultiplier = p.quantity * inst.contractMultiplier
                        netDelta += greeks.delta * notionalMultiplier * s
                        gammaSum += greeks.gamma * notionalMultiplier
                        vegaSum += greeks.vega * notionalMultiplier
                        thetaSum += greeks.theta * notionalMultiplier
                    }
                    InstrumentType.FIXED_INCOME -> {
                        val dur = inst.durationYears.coerceAtLeast(1.0)
                        val bondDv01 = (dur * abs(mv) * 0.0001)
                        weightedDurSum += dur * abs(mv)
                        dv01Sum += bondDv01
                        bondTotalValue += abs(mv)
                    }
                    InstrumentType.EQUITY, InstrumentType.DIGITAL_ASSET -> {
                        // Delta equivalent is 1.0 * market value
                        netDelta += mv
                    }
                    else -> {}
                }
            }
        }

        val totalInvestments = longVal - shortVal
        val grossMarketValue = longVal + shortVal
        val nav = totalInvestments + cashBalance - totalDebt

        val grossLeverage = if (nav > 0) (grossMarketValue + totalDebt) / nav else 1.0
        val netLeverage = if (nav > 0) (longVal - shortVal) / nav else 1.0

        val weightedDuration = if (bondTotalValue > 0) weightedDurSum / bondTotalValue else 0.0

        // Parametric VaR approximation based on 1.645 (95%) and 2.326 (99%) daily volatility (1.2% assumed daily vol)
        val dailyVolatility = 0.012
        val var95 = abs(nav) * dailyVolatility * 1.645
        val var99 = abs(nav) * dailyVolatility * 2.326
        val cVar = abs(nav) * dailyVolatility * 2.06 // Expected shortfall at 97.5%

        return PortfolioRiskSummary(
            grossMarketValue = grossMarketValue,
            netAssetValue = nav,
            longExposure = longVal,
            shortExposure = shortVal,
            grossLeverage = grossLeverage,
            netLeverage = netLeverage,
            netDeltaNotional = netDelta,
            portfolioGamma = gammaSum,
            portfolioVega = vegaSum,
            portfolioThetaDaily = thetaSum,
            weightedDuration = weightedDuration,
            portfolioDv01 = dv01Sum,
            var95Daily = var95,
            var99Daily = var99,
            expectedShortfall975 = cVar
        )
    }

    /**
     * Executes scenario shock stress testing.
     */
    fun evaluateScenario(
        scenarioName: String,
        scenarioDescription: String,
        equityShockPct: Double,       // e.g. -0.20 for -20%
        ratesShockBps: Double,        // e.g. +150 for +1.50%
        volShockPct: Double,          // e.g. +0.30 for +30% vol
        fxShockPct: Double,           // e.g. -0.10 for -10% non-USD
        positions: List<Position>,
        instrumentsMap: Map<String, Instrument>,
        cashBalance: Double,
        totalDebt: Double
    ): StressTestResult {
        var baseNav = cashBalance - totalDebt
        var stressedInvestments = 0.0

        var equityPnl = 0.0
        var bondPnl = 0.0
        var optionPnl = 0.0
        var cryptoPnl = 0.0

        for (p in positions) {
            val inst = instrumentsMap[p.instrumentId]
            val origMv = p.marketValue
            baseNav += origMv

            if (inst == null) {
                stressedInvestments += origMv
                continue
            }

            when (inst.type) {
                InstrumentType.EQUITY -> {
                    val change = origMv * equityShockPct
                    equityPnl += change
                    stressedInvestments += (origMv + change)
                }
                InstrumentType.DIGITAL_ASSET -> {
                    // Crypto usually correlates with equity shock with 2x beta
                    val change = origMv * (equityShockPct * 2.0).coerceIn(-0.95, 2.0)
                    cryptoPnl += change
                    stressedInvestments += (origMv + change)
                }
                InstrumentType.FIXED_INCOME -> {
                    // Price change ~ -Duration * deltaY + 0.5 * Convexity * deltaY^2
                    val deltaY = ratesShockBps / 10000.0
                    val dur = inst.durationYears.coerceAtLeast(1.0)
                    val conv = inst.convexity.coerceAtLeast(0.0)
                    val pricePctChange = -dur * deltaY + 0.5 * conv * deltaY * deltaY
                    val change = origMv * pricePctChange
                    bondPnl += change
                    stressedInvestments += (origMv + change)
                }
                InstrumentType.OPTION -> {
                    val isCall = inst.optionType == OptionType.CALL
                    val baseS = inst.cleanPrice.coerceAtLeast(10.0)
                    val stressedS = baseS * (1.0 + equityShockPct)
                    val stressedVol = inst.impliedVol * (1.0 + volShockPct)
                    val stressedGreeks = BlackScholes.calculate(stressedS, inst.strike, 0.25, 0.045, stressedVol, isCall)
                    val newContractPrice = stressedGreeks.price
                    val newMv = p.quantity * inst.contractMultiplier * newContractPrice
                    val change = newMv - origMv
                    optionPnl += change
                    stressedInvestments += newMv
                }
                InstrumentType.SWAP, InstrumentType.CREDIT_DEFAULT_SWAP -> {
                    val change = origMv * (1.0 - (ratesShockBps / 5000.0)) - origMv
                    stressedInvestments += (origMv + change)
                }
                else -> {
                    val fxEffect = if (inst.currency != "USD") origMv * fxShockPct else 0.0
                    stressedInvestments += (origMv + fxEffect)
                }
            }
        }

        val stressedNav = stressedInvestments + cashBalance - totalDebt
        val navChange = stressedNav - baseNav
        val navChangePct = if (baseNav != 0.0) (navChange / baseNav) * 100.0 else 0.0

        val maxLossCategory = listOf(
            "Equities" to abs(equityPnl),
            "Fixed Income Rates" to abs(bondPnl),
            "Options & Greeks" to abs(optionPnl),
            "Digital Vault Assets" to abs(cryptoPnl)
        ).maxByOrNull { it.second }?.first ?: "Market Spread"

        val marginImpact = if (navChange < 0) abs(navChange) * 0.15 else 0.0
        val requiresMarginCall = marginImpact > 1_500_000.0

        return StressTestResult(
            scenarioName = scenarioName,
            scenarioDescription = scenarioDescription,
            baseNav = baseNav,
            stressedNav = stressedNav,
            navChangeAmount = navChange,
            navChangePct = navChangePct,
            pnlImpact = navChange,
            marginImpact = marginImpact,
            requiresMarginCall = requiresMarginCall,
            primaryDriver = maxLossCategory
        )
    }
}
