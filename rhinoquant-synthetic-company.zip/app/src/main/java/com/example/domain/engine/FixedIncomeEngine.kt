package com.example.domain.engine

import kotlin.math.pow

/**
 * Fixed income pricing, accrued interest, duration and convexity analytics.
 */
object FixedIncomeEngine {

    data class BondAnalytics(
        val cleanPrice: Double,
        val accruedInterest: Double,
        val dirtyPrice: Double,
        val yieldToMaturity: Double,
        val modifiedDuration: Double,
        val macaulayDuration: Double,
        val convexity: Double,
        val dv01: Double // Dollar value of a 1 basis point change per 100 face value
    )

    /**
     * Calculates bond metrics for an annual or semi-annual coupon bond.
     * faceValue: typically 100 or 1,000
     * couponRate: e.g. 0.045 for 4.5%
     * yearsToMaturity: e.g. 7.5
     * ytm: Yield to maturity (e.g. 0.042 for 4.2%)
     * frequency: 2 for semi-annual, 1 for annual
     * daysSinceCoupon: days since last coupon
     * daysInPeriod: total days in coupon period (e.g. 180 or 182.5)
     */
    fun calculate(
        faceValue: Double = 100.0,
        couponRate: Double = 0.045,
        yearsToMaturity: Double = 5.0,
        ytm: Double = 0.045,
        frequency: Int = 2,
        daysSinceCoupon: Double = 45.0,
        daysInPeriod: Double = 180.0
    ): BondAnalytics {
        val n = (yearsToMaturity * frequency).toInt().coerceAtLeast(1)
        val couponPayment = (faceValue * couponRate) / frequency
        val periodRate = (ytm / frequency).coerceAtLeast(0.0001)

        // Discounted cash flows
        var pvCoupons = 0.0
        var macaulaySum = 0.0
        var convexitySum = 0.0

        for (t in 1..n) {
            val df = (1.0 + periodRate).pow(-t)
            pvCoupons += couponPayment * df
            val cf = if (t == n) couponPayment + faceValue else couponPayment
            macaulaySum += (t.toDouble() / frequency) * cf * df
            convexitySum += (t.toDouble() * (t + 1.0) / (frequency * frequency)) * cf * df
        }

        val pvPrincipal = faceValue * (1.0 + periodRate).pow(-n)
        val cleanPrice = pvCoupons + pvPrincipal

        val fraction = (daysSinceCoupon / daysInPeriod).coerceIn(0.0, 1.0)
        val accruedInterest = couponPayment * fraction
        val dirtyPrice = cleanPrice + accruedInterest

        val macaulayDuration = if (dirtyPrice > 0) macaulaySum / dirtyPrice else yearsToMaturity
        val modifiedDuration = macaulayDuration / (1.0 + periodRate)
        val convexity = if (dirtyPrice > 0) convexitySum / (dirtyPrice * (1.0 + periodRate).pow(2)) else 0.0

        // DV01 = Modified Duration * Dirty Price * 0.0001
        val dv01 = modifiedDuration * dirtyPrice * 0.0001

        return BondAnalytics(
            cleanPrice = cleanPrice,
            accruedInterest = accruedInterest,
            dirtyPrice = dirtyPrice,
            yieldToMaturity = ytm,
            modifiedDuration = modifiedDuration,
            macaulayDuration = macaulayDuration,
            convexity = convexity,
            dv01 = dv01
        )
    }
}
