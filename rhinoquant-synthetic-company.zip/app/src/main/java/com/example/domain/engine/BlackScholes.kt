package com.example.domain.engine

import kotlin.math.*

/**
 * Institutional Black-Scholes-Merton option pricing and Greeks engine.
 */
object BlackScholes {

    data class OptionGreeks(
        val price: Double,
        val delta: Double,
        val gamma: Double,
        val vega: Double,     // Per 1% change in vol
        val theta: Double,    // Per day decay
        val rho: Double       // Per 1% change in interest rate
    )

    // Standard Normal Cumulative Distribution Function (Abramowitz & Stegun approximation)
    fun cnd(x: Double): Double {
        val a1 = 0.319381530
        val a2 = -0.356563782
        val a3 = 1.781477937
        val a4 = -1.821255978
        val a5 = 1.330274429
        val p = 0.2316419

        val sign = if (x < 0) -1 else 1
        val absX = abs(x)
        val t = 1.0 / (1.0 + p * absX)
        val poly = t * (a1 + t * (a2 + t * (a3 + t * (a4 + t * a5))))
        val pdf = (1.0 / sqrt(2.0 * PI)) * exp(-0.5 * absX * absX)
        val cdf = 1.0 - pdf * poly

        return if (sign < 0) 1.0 - cdf else cdf
    }

    private fun normalPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * PI)) * exp(-0.5 * x * x)
    }

    /**
     * Prices a European option and computes analytical Greeks.
     * S: Underlying spot price
     * K: Strike price
     * T: Time to maturity in years
     * r: Risk-free rate (e.g. 0.045 for 4.5%)
     * sigma: Implied volatility (e.g. 0.22 for 22%)
     * isCall: true for Call, false for Put
     */
    fun calculate(
        s: Double,
        k: Double,
        t: Double,
        r: Double = 0.045,
        sigma: Double = 0.20,
        isCall: Boolean = true
    ): OptionGreeks {
        if (s <= 0.0 || k <= 0.0 || sigma <= 0.0) {
            val intrinsic = if (isCall) max(0.0, s - k) else max(0.0, k - s)
            return OptionGreeks(price = intrinsic, delta = if (isCall) 1.0 else -1.0, gamma = 0.0, vega = 0.0, theta = 0.0, rho = 0.0)
        }

        val timeToExpiry = max(0.001, t)
        val sqrtT = sqrt(timeToExpiry)

        val d1 = (ln(s / k) + (r + 0.5 * sigma * sigma) * timeToExpiry) / (sigma * sqrtT)
        val d2 = d1 - sigma * sqrtT

        val pdfD1 = normalPdf(d1)
        val expRt = exp(-r * timeToExpiry)

        val price: Double
        val delta: Double
        val gamma = pdfD1 / (s * sigma * sqrtT)
        val vega = (s * sqrtT * pdfD1) / 100.0 // Per 1% vol
        val theta: Double
        val rho: Double

        if (isCall) {
            price = s * cnd(d1) - k * expRt * cnd(d2)
            delta = cnd(d1)
            theta = (-((s * pdfD1 * sigma) / (2.0 * sqrtT)) - (r * k * expRt * cnd(d2))) / 365.0
            rho = (k * timeToExpiry * expRt * cnd(d2)) / 100.0
        } else {
            price = k * expRt * cnd(-d2) - s * cnd(-d1)
            delta = cnd(d1) - 1.0
            theta = (-((s * pdfD1 * sigma) / (2.0 * sqrtT)) + (r * k * expRt * cnd(-d2))) / 365.0
            rho = (-k * timeToExpiry * expRt * cnd(-d2)) / 100.0
        }

        return OptionGreeks(
            price = max(0.0, price),
            delta = delta,
            gamma = gamma,
            vega = vega,
            theta = theta,
            rho = rho
        )
    }
}
