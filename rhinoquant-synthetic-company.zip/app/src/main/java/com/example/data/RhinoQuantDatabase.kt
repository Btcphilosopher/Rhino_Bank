package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.domain.models.*

@Database(
    entities = [
        SyntheticCompany::class,
        Instrument::class,
        Position::class,
        FinancialTransaction::class,
        JournalEntry::class,
        FinancingFacility::class,
        CollateralAgreement::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class RhinoQuantDatabase : RoomDatabase() {
    abstract fun entityDao(): EntityDao
    abstract fun instrumentDao(): InstrumentDao
    abstract fun positionDao(): PositionDao
    abstract fun transactionDao(): TransactionDao
    abstract fun journalDao(): JournalDao
    abstract fun financingDao(): FinancingDao
    abstract fun collateralDao(): CollateralDao

    companion object {
        @Volatile
        private var INSTANCE: RhinoQuantDatabase? = null

        fun getDatabase(context: Context): RhinoQuantDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RhinoQuantDatabase::class.java,
                    "rhinoquant_synthetic_company.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
