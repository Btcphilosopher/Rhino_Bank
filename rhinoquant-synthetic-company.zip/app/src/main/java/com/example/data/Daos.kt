package com.example.data

import androidx.room.*
import com.example.domain.models.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EntityDao {
    @Query("SELECT * FROM synthetic_companies")
    fun getAllCompanies(): Flow<List<SyntheticCompany>>

    @Query("SELECT * FROM synthetic_companies WHERE id = :id")
    suspend fun getCompanyById(id: String): SyntheticCompany?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompany(company: SyntheticCompany)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanies(companies: List<SyntheticCompany>)
}

@Dao
interface InstrumentDao {
    @Query("SELECT * FROM instruments")
    fun getAllInstruments(): Flow<List<Instrument>>

    @Query("SELECT * FROM instruments WHERE id = :id")
    suspend fun getInstrumentById(id: String): Instrument?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstrument(instrument: Instrument)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstruments(instruments: List<Instrument>)
}

@Dao
interface PositionDao {
    @Query("SELECT * FROM positions WHERE entityId = :entityId")
    fun getPositionsForEntity(entityId: String): Flow<List<Position>>

    @Query("SELECT * FROM positions")
    fun getAllPositions(): Flow<List<Position>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosition(position: Position)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPositions(positions: List<Position>)

    @Query("DELETE FROM positions WHERE positionId = :id")
    suspend fun deletePosition(id: String)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE entityId = :entityId ORDER BY timestamp DESC")
    fun getTransactionsForEntity(entityId: String): Flow<List<FinancialTransaction>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<FinancialTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FinancialTransaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<FinancialTransaction>)
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries WHERE entityId = :entityId ORDER BY timestamp DESC")
    fun getJournalsForEntity(entityId: String): Flow<List<JournalEntry>>

    @Query("SELECT * FROM journal_entries ORDER BY timestamp DESC")
    fun getAllJournals(): Flow<List<JournalEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournal(journal: JournalEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournals(journals: List<JournalEntry>)
}

@Dao
interface FinancingDao {
    @Query("SELECT * FROM financing_facilities WHERE entityId = :entityId")
    fun getFinancingForEntity(entityId: String): Flow<List<FinancingFacility>>

    @Query("SELECT * FROM financing_facilities")
    fun getAllFinancing(): Flow<List<FinancingFacility>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFinancing(facility: FinancingFacility)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFinancings(facilities: List<FinancingFacility>)
}

@Dao
interface CollateralDao {
    @Query("SELECT * FROM collateral_agreements WHERE entityId = :entityId")
    fun getCollateralForEntity(entityId: String): Flow<List<CollateralAgreement>>

    @Query("SELECT * FROM collateral_agreements")
    fun getAllCollateral(): Flow<List<CollateralAgreement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollateral(agreement: CollateralAgreement)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollaterals(agreements: List<CollateralAgreement>)
}
