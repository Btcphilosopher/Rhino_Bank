package com.example.data

import androidx.room.TypeConverter
import com.example.domain.models.InstrumentType
import com.example.domain.models.OptionType
import com.example.domain.models.TransactionType
import com.example.domain.models.ValuationProvenance

class Converters {
    @TypeConverter
    fun fromInstrumentType(value: InstrumentType?): String? = value?.name

    @TypeConverter
    fun toInstrumentType(value: String?): InstrumentType? = value?.let { InstrumentType.valueOf(it) }

    @TypeConverter
    fun fromProvenance(value: ValuationProvenance?): String? = value?.name

    @TypeConverter
    fun toProvenance(value: String?): ValuationProvenance? = value?.let { ValuationProvenance.valueOf(it) }

    @TypeConverter
    fun fromOptionType(value: OptionType?): String? = value?.name

    @TypeConverter
    fun toOptionType(value: String?): OptionType? = value?.let { OptionType.valueOf(it) }

    @TypeConverter
    fun fromTransactionType(value: TransactionType?): String? = value?.name

    @TypeConverter
    fun toTransactionType(value: String?): TransactionType? = value?.let { TransactionType.valueOf(it) }
}
