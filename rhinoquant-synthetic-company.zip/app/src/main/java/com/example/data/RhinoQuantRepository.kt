package com.example.data

import com.example.domain.engine.VaultKeyEngine
import com.example.domain.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.UUID

class RhinoQuantRepository(private val database: RhinoQuantDatabase) {

    val allCompanies: Flow<List<SyntheticCompany>> = database.entityDao().getAllCompanies()
    val allInstruments: Flow<List<Instrument>> = database.instrumentDao().getAllInstruments()

    fun getPositionsForEntity(entityId: String): Flow<List<Position>> =
        database.positionDao().getPositionsForEntity(entityId)

    fun getAllPositions(): Flow<List<Position>> =
        database.positionDao().getAllPositions()

    fun getTransactionsForEntity(entityId: String): Flow<List<FinancialTransaction>> =
        database.transactionDao().getTransactionsForEntity(entityId)

    fun getAllTransactions(): Flow<List<FinancialTransaction>> =
        database.transactionDao().getAllTransactions()

    fun getJournalsForEntity(entityId: String): Flow<List<JournalEntry>> =
        database.journalDao().getJournalsForEntity(entityId)

    fun getAllJournals(): Flow<List<JournalEntry>> =
        database.journalDao().getAllJournals()

    fun getFinancingForEntity(entityId: String): Flow<List<FinancingFacility>> =
        database.financingDao().getFinancingForEntity(entityId)

    fun getAllFinancing(): Flow<List<FinancingFacility>> =
        database.financingDao().getAllFinancing()

    fun getCollateralForEntity(entityId: String): Flow<List<CollateralAgreement>> =
        database.collateralDao().getCollateralForEntity(entityId)

    /**
     * Seeds initial institutional entities, multi-asset instruments, positions,
     * and double-entry journals if database is fresh.
     */
    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        val existing = database.entityDao().getAllCompanies().first()
        if (existing.isNotEmpty()) return@withContext

        // 1. Entities
        val entity1 = SyntheticCompany(
            id = "ENT-RSH-001",
            name = "Rhino Synthetic Holdings Ltd.",
            legalForm = "Simulated Exempt Holding Corp (RQ-SYNCO)",
            functionalCurrency = "USD",
            reportingCurrency = "USD",
            accountingBasis = "IFRS Modelled / FVTPL",
            initialCapital = 100_000_000.0,
            investmentMandate = "Multi-Asset Absolute Return & Quantitative Capital Preservation",
            maxGrossLeverage = 3.0,
            status = "ACTIVE"
        )

        val entity2 = SyntheticCompany(
            id = "ENT-RAA-002",
            name = "Rhino Alpha Arbitrage Vehicle",
            legalForm = "Simulated Cayman Feeder Fund (RQ-SYNCO)",
            functionalCurrency = "USD",
            reportingCurrency = "USD",
            accountingBasis = "FVTPL Fair Value Subledger",
            initialCapital = 35_000_000.0,
            parentEntityId = "ENT-RSH-001",
            ownershipPct = 80.0,
            investmentMandate = "Systematic Long/Short Equities & Derivatives Dispersion",
            maxGrossLeverage = 4.5,
            status = "ACTIVE"
        )

        val entity3 = SyntheticCompany(
            id = "ENT-RGT-003",
            name = "Rhino Global Treasury & Macro Ltd.",
            legalForm = "Simulated Luxembourg Treasury S.à r.l.",
            functionalCurrency = "USD",
            reportingCurrency = "USD",
            accountingBasis = "Amortised Cost & Fair Value Hedge Accounting",
            initialCapital = 50_000_000.0,
            parentEntityId = "ENT-RSH-001",
            ownershipPct = 100.0,
            investmentMandate = "Global Sovereign Liquidity, FX Hedging & Cold Vault Reserves",
            maxGrossLeverage = 2.0,
            status = "ACTIVE"
        )

        database.entityDao().insertCompanies(listOf(entity1, entity2, entity3))

        // 2. Canonical Instruments
        val instruments = listOf(
            // Equities
            Instrument(
                id = "INST-AAPL",
                symbol = "AAPL",
                name = "Apple Inc. Common Stock",
                type = InstrumentType.EQUITY,
                currency = "USD",
                cleanPrice = 228.50,
                dirtyPrice = 228.50,
                provenance = ValuationProvenance.VERIFIED_MARKET,
                reviewerNotes = "Consolidated feed quote"
            ),
            Instrument(
                id = "INST-NVDA",
                symbol = "NVDA",
                name = "NVIDIA Corporation",
                type = InstrumentType.EQUITY,
                currency = "USD",
                cleanPrice = 132.80,
                dirtyPrice = 132.80,
                provenance = ValuationProvenance.VERIFIED_MARKET
            ),
            Instrument(
                id = "INST-MSFT",
                symbol = "MSFT",
                name = "Microsoft Corporation",
                type = InstrumentType.EQUITY,
                currency = "USD",
                cleanPrice = 416.20,
                dirtyPrice = 416.20,
                provenance = ValuationProvenance.VERIFIED_MARKET
            ),
            Instrument(
                id = "INST-SPY",
                symbol = "SPY",
                name = "SPDR S&P 500 ETF Trust",
                type = InstrumentType.EQUITY,
                currency = "USD",
                cleanPrice = 575.40,
                dirtyPrice = 575.40,
                provenance = ValuationProvenance.VERIFIED_MARKET
            ),
            // Fixed Income
            Instrument(
                id = "INST-UST10Y",
                symbol = "UST-10Y-2034",
                name = "United States Treasury 4.25% 15-Aug-2034",
                type = InstrumentType.FIXED_INCOME,
                currency = "USD",
                couponRate = 0.0425,
                couponFrequency = 2,
                cleanPrice = 99.40,
                dirtyPrice = 100.15,
                durationYears = 7.82,
                convexity = 72.4,
                maturityDate = "2034-08-15",
                provenance = ValuationProvenance.MODELLED
            ),
            Instrument(
                id = "INST-BUND10Y",
                symbol = "BUND-10Y-2034",
                name = "Federal Republic of Germany 2.40% 15-Nov-2034",
                type = InstrumentType.FIXED_INCOME,
                currency = "EUR",
                couponRate = 0.0240,
                couponFrequency = 1,
                cleanPrice = 98.70,
                dirtyPrice = 99.30,
                durationYears = 8.45,
                convexity = 81.2,
                maturityDate = "2034-11-15",
                provenance = ValuationProvenance.MODELLED
            ),
            // Options
            Instrument(
                id = "INST-OPT-SPX-CALL",
                symbol = "OPT-SPX-5800C",
                name = "S&P 500 European Call Strike 5800 Dec-2024",
                type = InstrumentType.OPTION,
                underlying = "SPX",
                cleanPrice = 5754.0, // Index spot
                strike = 5800.0,
                optionType = OptionType.CALL,
                expiryDate = "2024-12-20",
                contractMultiplier = 100.0,
                impliedVol = 0.165,
                valuationMethod = "Black-Scholes-Merton",
                provenance = ValuationProvenance.MODELLED
            ),
            Instrument(
                id = "INST-OPT-NVDA-PUT",
                symbol = "OPT-NVDA-125P",
                name = "NVIDIA European Protective Put Strike 125 Nov-2024",
                type = InstrumentType.OPTION,
                underlying = "NVDA",
                cleanPrice = 132.8,
                strike = 125.0,
                optionType = OptionType.PUT,
                expiryDate = "2024-11-15",
                contractMultiplier = 100.0,
                impliedVol = 0.38,
                valuationMethod = "Black-Scholes-Merton",
                provenance = ValuationProvenance.MODELLED
            ),
            // Swaps
            Instrument(
                id = "INST-SWP-SOFR",
                symbol = "SWP-SOFR-5Y",
                name = "5Y Interest Rate Swap (Receive Fixed 3.65% vs SOFR 3M)",
                type = InstrumentType.SWAP,
                currency = "USD",
                cleanPrice = 100.0,
                dirtyPrice = 100.0,
                swapFixedRate = 0.0365,
                swapFloatingIndex = "SOFR 3M Compounded",
                notionalOrQty = 25_000_000.0,
                valuationMethod = "Discounted Dual-Curve NPV",
                provenance = ValuationProvenance.MODELLED
            ),
            // Digital Asset / Vault
            Instrument(
                id = "INST-BTC-VAULT",
                symbol = "BTC-VAULT",
                name = "Bitcoin Institutional MPC Cold Vault Holding",
                type = InstrumentType.DIGITAL_ASSET,
                currency = "USD",
                cleanPrice = 64_850.0,
                dirtyPrice = 64_850.0,
                provenance = ValuationProvenance.VERIFIED_MARKET,
                reviewerNotes = "Simulated institutional on-chain reserve holding"
            ),
            // Alternatives
            Instrument(
                id = "INST-ALT-REIT",
                symbol = "ALT-LOGISTICS",
                name = "Prime Pan-European Logistics Infrastructure Fund",
                type = InstrumentType.FUND_ALTERNATIVE,
                currency = "EUR",
                cleanPrice = 1250.0,
                dirtyPrice = 1250.0,
                provenance = ValuationProvenance.HISTORICAL
            )
        )

        database.instrumentDao().insertInstruments(instruments)

        // 3. Positions for Entity 1 (Rhino Synthetic Holdings Ltd.)
        val positions = listOf(
            Position("POS-101", "ENT-RSH-001", "INST-AAPL", 35_000.0, 210.0, 228.50, 35_000.0 * 228.50, 35_000.0 * 18.50),
            Position("POS-102", "ENT-RSH-001", "INST-MSFT", 20_000.0, 400.0, 416.20, 20_000.0 * 416.20, 20_000.0 * 16.20),
            Position("POS-103", "ENT-RSH-001", "INST-UST10Y", 250_000.0, 99.0, 100.15, 250_000.0 * 100.15, 250_000.0 * 1.15),
            Position("POS-104", "ENT-RSH-001", "INST-OPT-SPX-CALL", 50.0, 75.0, 92.40, 50.0 * 100.0 * 92.40, 50.0 * 100.0 * 17.40),
            Position("POS-105", "ENT-RSH-001", "INST-SWP-SOFR", 1.0, 0.0, 420_000.0, 420_000.0, 420_000.0),
            Position("POS-106", "ENT-RSH-001", "INST-BTC-VAULT", 185.0, 58_000.0, 64_850.0, 185.0 * 64_850.0, 185.0 * 6_850.0),
            Position("POS-107", "ENT-RSH-001", "INST-ALT-REIT", 8_000.0, 1200.0, 1250.0, 8_000.0 * 1250.0, 8_000.0 * 50.0)
        )
        database.positionDao().insertPositions(positions)

        // Positions for Entity 2 (Rhino Alpha Arbitrage Vehicle)
        val posEntity2 = listOf(
            Position("POS-201", "ENT-RAA-002", "INST-NVDA", 85_000.0, 120.0, 132.80, 85_000.0 * 132.80, 85_000.0 * 12.80),
            Position("POS-202", "ENT-RAA-002", "INST-OPT-NVDA-PUT", 200.0, 4.5, 3.20, 200.0 * 100.0 * 3.20, -200.0 * 100.0 * 1.30),
            Position("POS-203", "ENT-RAA-002", "INST-SPY", -15_000.0, 560.0, 575.40, -15_000.0 * 575.40, -15_000.0 * 15.40) // Short hedge
        )
        database.positionDao().insertPositions(posEntity2)

        // Positions for Entity 3 (Rhino Global Treasury & Macro)
        val posEntity3 = listOf(
            Position("POS-301", "ENT-RGT-003", "INST-UST10Y", 300_000.0, 98.50, 100.15, 300_000.0 * 100.15, 300_000.0 * 1.65),
            Position("POS-302", "ENT-RGT-003", "INST-BUND10Y", 150_000.0, 97.80, 99.30, 150_000.0 * 99.30, 150_000.0 * 1.50),
            Position("POS-303", "ENT-RGT-003", "INST-BTC-VAULT", 250.0, 60_000.0, 64_850.0, 250.0 * 64_850.0, 250.0 * 4_850.0)
        )
        database.positionDao().insertPositions(posEntity3)

        // 4. Financing Facilities
        val financings = listOf(
            FinancingFacility(
                id = "FIN-001",
                entityId = "ENT-RSH-001",
                facilityType = "Senior Term Loan Facility",
                lenderOrCounterparty = "J.P. Morgan Chase Bank N.A.",
                principalAmount = 20_000_000.0,
                interestRatePct = 5.25,
                startDate = "2024-01-10",
                maturityDate = "2027-01-10",
                accruedInterest = 262_500.0,
                collateralAllocated = "Pledge on US Treasury 10Y Holdings ($25M)"
            ),
            FinancingFacility(
                id = "FIN-002",
                entityId = "ENT-RSH-001",
                facilityType = "Tri-Party Repo Financing",
                lenderOrCounterparty = "BNP Paribas Fixed Income Repo Desk",
                principalAmount = 15_000_000.0,
                interestRatePct = 4.85,
                startDate = "2024-09-01",
                maturityDate = "2024-12-01",
                accruedInterest = 60_625.0,
                collateralAllocated = "US Treasury 10Y (102% haircut margin)"
            ),
            FinancingFacility(
                id = "FIN-003",
                entityId = "ENT-RAA-002",
                facilityType = "Prime Brokerage Margin Facility",
                lenderOrCounterparty = "Goldman Sachs Prime Services",
                principalAmount = 12_000_000.0,
                interestRatePct = 5.60,
                startDate = "2024-06-01",
                maturityDate = "2025-06-01",
                accruedInterest = 112_000.0,
                collateralAllocated = "Cross-collateralized equity long book"
            )
        )
        database.financingDao().insertFinancings(financings)

        // 5. Collateral Agreements
        val collaterals = listOf(
            CollateralAgreement(
                id = "COL-001",
                entityId = "ENT-RSH-001",
                counterparty = "BNP Paribas Arbitrage SNC",
                agreementType = "ISDA 2016 Variation Margin CSA",
                initialMarginRequired = 2_000_000.0,
                variationMarginRequired = 500_000.0,
                postedCollateralValue = 2_500_000.0,
                threshold = 0.0,
                marginCallStatus = "SATISFIED"
            ),
            CollateralAgreement(
                id = "COL-002",
                entityId = "ENT-RSH-001",
                counterparty = "J.P. Morgan Securities LLC",
                agreementType = "GMRA 2011 Global Master Repurchase Agreement",
                initialMarginRequired = 1_500_000.0,
                variationMarginRequired = 250_000.0,
                postedCollateralValue = 1_750_000.0,
                threshold = 0.0,
                marginCallStatus = "OK"
            )
        )
        database.collateralDao().insertCollaterals(collaterals)

        // 6. Double-Entry Balanced Journal Entries
        val journals = listOf(
            JournalEntry(
                id = "JRN-001",
                entityId = "ENT-RSH-001",
                description = "Initial Share Capital Contribution (Class A & B)",
                sourceEventId = "EVT-CAP-001",
                debitAccountCode = "1000",
                debitAccountName = "Cash & Bank Balances",
                creditAccountCode = "3000",
                creditAccountName = "Contributed Share Capital",
                amount = 100_000_000.0
            ),
            JournalEntry(
                id = "JRN-002",
                entityId = "ENT-RSH-001",
                description = "Drawdown Senior Secured Bank Facility ($20M)",
                sourceEventId = "EVT-FIN-001",
                debitAccountCode = "1000",
                debitAccountName = "Cash & Bank Balances",
                creditAccountCode = "2000",
                creditAccountName = "Bank Borrowings Payable",
                amount = 20_000_000.0
            ),
            JournalEntry(
                id = "JRN-003",
                entityId = "ENT-RSH-001",
                description = "Purchase US Treasury 10Y Bond Book ($25M Notional)",
                sourceEventId = "EVT-SEC-001",
                debitAccountCode = "1200",
                debitAccountName = "Sovereign Bonds (HTM/AFS)",
                creditAccountCode = "1000",
                creditAccountName = "Cash & Bank Balances",
                amount = 24_750_000.0
            ),
            JournalEntry(
                id = "JRN-004",
                entityId = "ENT-RSH-001",
                description = "Purchase Listed Equities (AAPL & MSFT Allocation)",
                sourceEventId = "EVT-SEC-002",
                debitAccountCode = "1100",
                debitAccountName = "Public Equities (FVTPL)",
                creditAccountCode = "1000",
                creditAccountName = "Cash & Bank Balances",
                amount = 15_350_000.0
            ),
            JournalEntry(
                id = "JRN-005",
                entityId = "ENT-RSH-001",
                description = "Establish Bitcoin Institutional MPC Cold Vault Holding",
                sourceEventId = "EVT-CRY-001",
                debitAccountCode = "1350",
                debitAccountName = "Digital Asset Vault (BTC)",
                creditAccountCode = "1000",
                creditAccountName = "Cash & Bank Balances",
                amount = 10_730_000.0
            ),
            JournalEntry(
                id = "JRN-006",
                entityId = "ENT-RSH-001",
                description = "Premium Paid for S&P 500 Call Options (FVTPL)",
                sourceEventId = "EVT-OPT-001",
                debitAccountCode = "1400",
                debitAccountName = "Derivative Financial Assets",
                creditAccountCode = "1000",
                creditAccountName = "Cash & Bank Balances",
                amount = 375_000.0
            ),
            JournalEntry(
                id = "JRN-007",
                entityId = "ENT-RSH-001",
                description = "Tri-Party Repo Financing Execution",
                sourceEventId = "EVT-RPO-001",
                debitAccountCode = "1000",
                debitAccountName = "Cash & Bank Balances",
                creditAccountCode = "2100",
                creditAccountName = "Repo Financing Payable",
                amount = 15_000_000.0
            )
        )
        database.journalDao().insertJournals(journals)

        // 7. Initial Transactions
        val transactions = listOf(
            FinancialTransaction(
                txId = "TX-001",
                entityId = "ENT-RSH-001",
                instrumentId = "CASH",
                type = TransactionType.CAPITAL_INJECTION,
                quantity = 1.0,
                unitPrice = 100_000_000.0,
                totalAmount = 100_000_000.0,
                auditNotes = "Equity issuance authorised by Board of Directors"
            ),
            FinancialTransaction(
                txId = "TX-002",
                entityId = "ENT-RSH-001",
                instrumentId = "INST-AAPL",
                type = TransactionType.BUY,
                quantity = 35_000.0,
                unitPrice = 210.0,
                totalAmount = 7_350_000.0,
                auditNotes = "Executed on NASDAQ via Electronic Subledger"
            ),
            FinancialTransaction(
                txId = "TX-003",
                entityId = "ENT-RSH-001",
                instrumentId = "INST-BTC-VAULT",
                type = TransactionType.BUY,
                quantity = 185.0,
                unitPrice = 58_000.0,
                totalAmount = 10_730_000.0,
                auditNotes = "Signed via Institutional Vault Key (2-of-3 MPC Quorum)"
            ),
            FinancialTransaction(
                txId = "TX-004",
                entityId = "ENT-RSH-001",
                instrumentId = "INST-OPT-SPX-CALL",
                type = TransactionType.OPTION_ENTER,
                quantity = 50.0,
                unitPrice = 75.0,
                totalAmount = 375_000.0,
                auditNotes = "CBOE European Call Option Execution"
            )
        )
        database.transactionDao().insertTransactions(transactions)
    }

    /**
     * Executes a new trade or contract execution, posts double-entry journal,
     * signs cryptographically if digital vault asset, and updates position.
     */
    suspend fun executeTrade(
        entityId: String,
        instrument: Instrument,
        type: TransactionType,
        quantity: Double,
        unitPrice: Double,
        vaultSigningKey: VaultKeyEngine.InstitutionalVaultKey? = null
    ) = withContext(Dispatchers.IO) {
        val totalAmount = quantity * unitPrice
        val txId = "TX-${UUID.randomUUID().toString().take(8).uppercase()}"

        val auditNote = if (vaultSigningKey != null && instrument.type == InstrumentType.DIGITAL_ASSET) {
            val signed = VaultKeyEngine.signExecution(vaultSigningKey, instrument.symbol, quantity, type.name)
            "Signed by ${vaultSigningKey.keyName} | TxHash: ${signed.transactionHash.take(16)}... | Sig: ${signed.signatureHex.take(20)}..."
        } else {
            "Executed on RhinoQuant Subledger | Ref: $txId"
        }

        val tx = FinancialTransaction(
            txId = txId,
            entityId = entityId,
            instrumentId = instrument.id,
            type = type,
            quantity = quantity,
            unitPrice = unitPrice,
            totalAmount = totalAmount,
            currency = instrument.currency,
            auditNotes = auditNote
        )
        database.transactionDao().insertTransaction(tx)

        // Double-entry journal posting
        val isBuy = type == TransactionType.BUY || type == TransactionType.OPTION_ENTER
        val debitCode = if (isBuy) {
            when (instrument.type) {
                InstrumentType.EQUITY -> "1100"
                InstrumentType.FIXED_INCOME -> "1200"
                InstrumentType.OPTION, InstrumentType.SWAP -> "1400"
                InstrumentType.DIGITAL_ASSET -> "1350"
                else -> "1300"
            }
        } else "1000"

        val creditCode = if (isBuy) "1000" else {
            when (instrument.type) {
                InstrumentType.EQUITY -> "1100"
                InstrumentType.FIXED_INCOME -> "1200"
                InstrumentType.OPTION, InstrumentType.SWAP -> "1400"
                InstrumentType.DIGITAL_ASSET -> "1350"
                else -> "1300"
            }
        }

        val journal = JournalEntry(
            id = "JRN-${UUID.randomUUID().toString().take(8).uppercase()}",
            entityId = entityId,
            description = "${type.name} ${quantity} ${instrument.symbol} @ $unitPrice",
            sourceEventId = txId,
            debitAccountCode = debitCode,
            debitAccountName = if (debitCode == "1000") "Cash & Bank Balances" else "${instrument.type.name} Subledger",
            creditAccountCode = creditCode,
            creditAccountName = if (creditCode == "1000") "Cash & Bank Balances" else "${instrument.type.name} Subledger",
            amount = totalAmount,
            currency = instrument.currency
        )
        database.journalDao().insertJournal(journal)

        // Update position
        val existingPositions = database.positionDao().getPositionsForEntity(entityId).first()
        val existing = existingPositions.find { it.instrumentId == instrument.id }

        if (existing == null) {
            val newPos = Position(
                positionId = "POS-${UUID.randomUUID().toString().take(8).uppercase()}",
                entityId = entityId,
                instrumentId = instrument.id,
                quantity = if (isBuy) quantity else -quantity,
                costBasis = unitPrice,
                currentPrice = unitPrice,
                marketValue = totalAmount,
                unrealizedPnl = 0.0,
                currency = instrument.currency
            )
            database.positionDao().insertPosition(newPos)
        } else {
            val updatedQty = if (isBuy) existing.quantity + quantity else existing.quantity - quantity
            val updatedMv = updatedQty * unitPrice
            val updatedPnl = updatedMv - (updatedQty * existing.costBasis)
            val updatedPos = existing.copy(
                quantity = updatedQty,
                currentPrice = unitPrice,
                marketValue = updatedMv,
                unrealizedPnl = updatedPnl
            )
            database.positionDao().insertPosition(updatedPos)
        }
    }

    /**
     * Creates a new synthetic company entity with initial capital and journal.
     */
    suspend fun createCompany(
        name: String,
        legalForm: String,
        currency: String,
        accountingBasis: String,
        initialCapital: Double,
        mandate: String
    ) = withContext(Dispatchers.IO) {
        val entityId = "ENT-${UUID.randomUUID().toString().take(6).uppercase()}"
        val company = SyntheticCompany(
            id = entityId,
            name = name,
            legalForm = legalForm,
            functionalCurrency = currency,
            reportingCurrency = currency,
            accountingBasis = accountingBasis,
            initialCapital = initialCapital,
            investmentMandate = mandate
        )
        database.entityDao().insertCompany(company)

        // Initial capital journal
        val journal = JournalEntry(
            id = "JRN-${UUID.randomUUID().toString().take(8).uppercase()}",
            entityId = entityId,
            description = "Initial Share Capital Incorporation Posting",
            sourceEventId = "EVT-INC-$entityId",
            debitAccountCode = "1000",
            debitAccountName = "Cash & Bank Balances",
            creditAccountCode = "3000",
            creditAccountName = "Contributed Share Capital",
            amount = initialCapital,
            currency = currency
        )
        database.journalDao().insertJournal(journal)
    }
}
