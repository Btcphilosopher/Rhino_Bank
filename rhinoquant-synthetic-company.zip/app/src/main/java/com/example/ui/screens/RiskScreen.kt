package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalMetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun RiskScreen(
    state: UiState,
    onUpdateScenario: (equity: Double, rates: Double, vol: Double, fx: Double) -> Unit
) {
    val risk = state.riskSummary
    val stress = state.activeStressResult

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "QUANTITATIVE RISK & SCENARIO LABORATORY",
                subtitle = "Parametric VaR, Expected Shortfall, duration sensitivity & multi-factor stress tests"
            )

            // VaR Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TerminalMetricCard(
                    title = "1-Day VaR (95%)",
                    value = FinancialFormatter.formatCurrency(risk?.var95Daily ?: 0.0),
                    subtitle = "Parametric Model",
                    badgeText = "95% CONF",
                    isPositiveBadge = true,
                    modifier = Modifier.weight(1f)
                )

                TerminalMetricCard(
                    title = "1-Day VaR (99%)",
                    value = FinancialFormatter.formatCurrency(risk?.var99Daily ?: 0.0),
                    subtitle = "Extreme Tail",
                    badgeText = "99% CONF",
                    isPositiveBadge = false,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TerminalMetricCard(
                    title = "Expected Shortfall (CVaR)",
                    value = FinancialFormatter.formatCurrency(risk?.expectedShortfall975 ?: 0.0),
                    subtitle = "Avg Loss Beyond 97.5%",
                    badgeText = "CVAR",
                    isPositiveBadge = false,
                    modifier = Modifier.weight(1f)
                )

                TerminalMetricCard(
                    title = "Fixed Income DV01",
                    value = FinancialFormatter.formatCurrency(risk?.portfolioDv01 ?: 0.0),
                    subtitle = "Per 1 bp Rate Shift",
                    badgeText = "RATES",
                    isPositiveBadge = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section: Interactive Scenario Laboratory
        item {
            Text(
                text = "INTERACTIVE SCENARIO STRESS LABORATORY",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        // Preset Shocks
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(RqSurface)
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text("HISTORICAL & CRISIS SHOCK PRESETS", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(
                        Quadruple("2008 GFC", -0.30, 0.0, 0.60, -0.15),
                        Quadruple("TECH CRASH", -0.20, 0.0, 0.35, 0.0),
                        Quadruple("FED HAWK", -0.10, 250.0, 0.15, 0.05),
                        Quadruple("STAGFLATION", -0.15, 150.0, 0.25, -0.10)
                    )

                    presets.forEach { preset ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(RqSurfaceVariant)
                                .border(1.dp, RqBorderBright, RoundedCornerShape(4.dp))
                                .clickable {
                                    onUpdateScenario(preset.first, preset.second, preset.third, preset.fourth)
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = preset.name,
                                color = RqPrimary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Slider: Equity Shock
                Text("EQUITY MARKET SHOCK: ${(state.scenarioEquityShockPct * 100).toInt()}%", color = RqTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Slider(
                    value = state.scenarioEquityShockPct.toFloat(),
                    onValueChange = { onUpdateScenario(it.toDouble(), state.scenarioRatesShockBps, state.scenarioVolShockPct, state.scenarioFxShockPct) },
                    valueRange = -0.40f..0.20f,
                    colors = SliderDefaults.colors(thumbColor = RqPrimary, activeTrackColor = RqPrimary)
                )

                // Slider: Yield Curve Shock
                Text("YIELD CURVE SHOCK: +${state.scenarioRatesShockBps.toInt()} BPS", color = RqTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Slider(
                    value = state.scenarioRatesShockBps.toFloat(),
                    onValueChange = { onUpdateScenario(state.scenarioEquityShockPct, it.toDouble(), state.scenarioVolShockPct, state.scenarioFxShockPct) },
                    valueRange = 0f..350f,
                    colors = SliderDefaults.colors(thumbColor = RqWarning, activeTrackColor = RqWarning)
                )

                // Slider: Volatility Shock
                Text("IMPLIED VOLATILITY SHOCK: +${(state.scenarioVolShockPct * 100).toInt()}%", color = RqTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Slider(
                    value = state.scenarioVolShockPct.toFloat(),
                    onValueChange = { onUpdateScenario(state.scenarioEquityShockPct, state.scenarioRatesShockBps, it.toDouble(), state.scenarioFxShockPct) },
                    valueRange = 0f..0.80f,
                    colors = SliderDefaults.colors(thumbColor = RqPurple, activeTrackColor = RqPurple)
                )
            }
        }

        // Real-Time Stress Test Revaluation Card
        if (stress != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (stress.navChangeAmount < 0) RqLoss else RqProfit, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = RqSurfaceVariant),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(stress.scenarioName.uppercase(), color = RqTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (stress.requiresMarginCall) RqLossBg else RqProfitBg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (stress.requiresMarginCall) "MARGIN CALL TRIGGERED" else "MARGIN ADEQUATE",
                                    color = if (stress.requiresMarginCall) RqLoss else RqProfit,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Text(stress.scenarioDescription, color = RqTextSecondary, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Baseline NAV", color = RqTextSecondary, fontSize = 10.sp)
                                Text(FinancialFormatter.formatCurrency(stress.baseNav), color = RqTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Stressed NAV", color = RqTextSecondary, fontSize = 10.sp)
                                Text(FinancialFormatter.formatCurrency(stress.stressedNav), color = RqWarning, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("P&L Drawdown", color = RqTextSecondary, fontSize = 10.sp)
                                val chgColor = if (stress.navChangeAmount >= 0) RqProfit else RqLoss
                                Text(
                                    text = "${FinancialFormatter.formatCurrency(stress.navChangeAmount)} (${String.format("%.2f", stress.navChangePct)}%)",
                                    color = chgColor,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = RqBorder)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Primary Loss Attribution Driver:", color = RqTextSecondary, fontSize = 10.sp)
                            Text(stress.primaryDriver, color = RqPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Estimated Variation Margin Call:", color = RqTextSecondary, fontSize = 10.sp)
                            Text(FinancialFormatter.formatCurrency(stress.marginImpact), color = RqWarning, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

data class Quadruple(val name: String, val first: Double, val second: Double, val third: Double, val fourth: Double)
