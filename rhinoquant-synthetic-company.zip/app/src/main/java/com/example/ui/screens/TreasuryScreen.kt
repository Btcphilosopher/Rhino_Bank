package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalMetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun TreasuryScreen(state: UiState) {
    val totalDebt = state.financings.sumOf { it.principalAmount }
    val cashDebit = state.journals.filter { it.debitAccountCode == "1000" }.sumOf { it.amount }
    val cashCredit = state.journals.filter { it.creditAccountCode == "1000" }.sumOf { it.amount }
    val cashBalance = (cashDebit - cashCredit).coerceAtLeast(5_000_000.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "CORPORATE TREASURY, FINANCING & COLLATERAL",
                subtitle = "Multi-currency liquidity, credit facilities, repo lines & ISDA margin"
            )

            // Treasury HUD Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TerminalMetricCard(
                    title = "Unrestricted Cash",
                    value = FinancialFormatter.formatCurrency(cashBalance),
                    subtitle = "Central Bank & Deposits",
                    badgeText = "LIQUID",
                    modifier = Modifier.weight(1f)
                )

                TerminalMetricCard(
                    title = "Total Borrowing Debt",
                    value = FinancialFormatter.formatCurrency(totalDebt),
                    subtitle = "Term Loans & Repos",
                    badgeText = "FINANCED",
                    isPositiveBadge = false,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section: Multi-Currency Balances
        item {
            Text(
                text = "MULTI-CURRENCY LIQUIDITY ACCOUNTS",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val currencies = listOf(
                        Triple("USD", cashBalance * 0.70, "1.0000"),
                        Triple("EUR", cashBalance * 0.15, "1.0945"),
                        Triple("GBP", cashBalance * 0.10, "1.3080"),
                        Triple("CHF", cashBalance * 0.05, "1.1620")
                    )

                    currencies.forEachIndexed { idx, (curr, amt, fx) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(RqSurfaceVariant)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(curr, color = RqPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Spot FX: $fx", color = RqTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }

                            Text(
                                text = FinancialFormatter.formatCurrency(amt),
                                color = RqTextPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (idx < currencies.size - 1) Divider(color = RqBorder, modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }

        // Section: Financing Liabilities & Repo
        item {
            Text(
                text = "FINANCING FACILITIES & REPO LIABILITIES",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(state.financings.size) { idx ->
            val fin = state.financings[idx]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(fin.facilityType, color = RqTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(RqWarningBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${fin.interestRatePct}% P.A.",
                                color = RqWarning,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Text("Counterparty: ${fin.lenderOrCounterparty}", color = RqTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Principal: ${FinancialFormatter.formatCurrency(fin.principalAmount)}", color = RqTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text("Matures: ${fin.maturityDate}", color = RqTextSecondary, fontSize = 10.sp)
                    }

                    Text("Collateral: ${fin.collateralAllocated}", color = RqTextTertiary, fontSize = 10.sp)
                }
            }
        }

        // Section: Collateral & Margin Agreements
        item {
            Text(
                text = "COLLATERAL & MARGIN AGREEMENTS (ISDA / CSA)",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(state.collaterals.size) { idx ->
            val col = state.collaterals[idx]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(col.agreementType, color = RqTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(RqProfitBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(col.marginCallStatus, color = RqProfit, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Text("Counterparty: ${col.counterparty}", color = RqTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Initial Margin: ${FinancialFormatter.formatCurrency(col.initialMarginRequired)}", color = RqTextSecondary, fontSize = 10.sp)
                        Text("Variation Margin: ${FinancialFormatter.formatCurrency(col.variationMarginRequired)}", color = RqTextSecondary, fontSize = 10.sp)
                    }
                    Text("Posted Collateral Value: ${FinancialFormatter.formatCurrency(col.postedCollateralValue)}", color = RqProfit, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
