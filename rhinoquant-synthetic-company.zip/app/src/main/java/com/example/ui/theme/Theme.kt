package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = RqPrimary,
    onPrimary = RqBackground,
    primaryContainer = RqSurfaceVariant,
    onPrimaryContainer = RqTextPrimary,
    secondary = RqSecondary,
    onSecondary = RqBackground,
    secondaryContainer = RqSurfaceVariant,
    onSecondaryContainer = RqTextPrimary,
    tertiary = RqWarning,
    onTertiary = RqBackground,
    background = RqBackground,
    onBackground = RqTextPrimary,
    surface = RqSurface,
    onSurface = RqTextPrimary,
    surfaceVariant = RqSurfaceVariant,
    onSurfaceVariant = RqTextSecondary,
    outline = RqBorder,
    outlineVariant = RqBorderBright
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
