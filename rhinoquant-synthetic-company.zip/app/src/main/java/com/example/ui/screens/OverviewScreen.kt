package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.models.Instrument
import com.example.domain.models.Position
import com.example.domain.models.SyntheticCompany
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.ProvenancePill
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalMetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab
import com.example.ui.viewmodel.UiState

@Composable
fun OverviewScreen(
    state: UiState,
    onOpenTrade: () -> Unit,
    onOpenCreateCompany: () -> Unit,
    onNavigateTab: (TerminalTab) -> Unit,
    onVerifyLedger: () -> Unit
) {
    val activeCompany = state.companies.find { it.id == state.selectedEntityId }
    val risk = state.riskSummary
    val bs = state.balanceSheet
    val pnl = state.pnlStatement

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Terminal Hero Header Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorderBright, RoundedCornerShape(10.dp)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(110.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.rq_terminal_hero),
                        contentDescription = "Terminal Hero",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(RqBackground.copy(alpha = 0.55f))
                    )
                    Column(
                        modifier = Modifier
                            .padding(14.dp)
                            .align(Alignment.BottomStart)
                    ) {
                        Text(
                            text = if (state.isConsolidatedView) "CONSOLIDATED GROUP TREASURY & INVESTMENT BOOK" else (activeCompany?.name ?: "SYNTHETIC ENTITY").uppercase(),
                            color = RqTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = if (state.isConsolidatedView) "3 Synthetic Entities • Intercompany Eliminations Active" else "${activeCompany?.legalForm} • ${activeCompany?.accountingBasis}",
                            color = RqPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Quick Institutional Action Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenTrade,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("EXECUTE TRADE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onOpenCreateCompany,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RqTextPrimary),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(RqBorderBright)),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Text("+ NEW ENTITY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onVerifyLedger,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RqSurfaceVariant, contentColor = RqProfit),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AUDIT LEDGER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Key Terminal HUD Metrics Grid
        item {
            val navVal = risk?.netAssetValue ?: 100_000_000.0
            val leverage = risk?.grossLeverage ?: 1.0
            val varVal = risk?.var95Daily ?: 2_500_000.0
            val netIncome = pnl?.netIncome ?: 4_250_000.0

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TerminalMetricCard(
                    title = "Net Asset Value",
                    value = FinancialFormatter.formatCurrency(navVal),
                    subtitle = "Audited Total Equity",
                    badgeText = "AAA RATED",
                    modifier = Modifier.weight(1f)
                )

                TerminalMetricCard(
                    title = "Gross Leverage",
                    value = String.format("%.2fx", leverage),
                    subtitle = "Max Limit: 3.50x",
                    badgeText = if (leverage < 3.5) "WITHIN LIMIT" else "LIMIT EXCEEDED",
                    isPositiveBadge = leverage < 3.5,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TerminalMetricCard(
                    title = "Daily VaR (95%)",
                    value = FinancialFormatter.formatCurrency(varVal),
                    subtitle = "1-Day Parametric",
                    badgeText = "95% CONF",
                    isPositiveBadge = true,
                    modifier = Modifier.weight(1f)
                )

                TerminalMetricCard(
                    title = "YTD Net Income",
                    value = FinancialFormatter.formatCurrency(netIncome),
                    subtitle = "Dividends + MTM + P&L",
                    badgeText = if (netIncome >= 0) "+PROFIT" else "-LOSS",
                    isPositiveBadge = netIncome >= 0,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Balance Sheet Quick Banner
        item {
            val totalAssets = bs?.totalAssets ?: 140_000_000.0
            val totalLiab = bs?.totalLiabilities ?: 35_000_000.0
            val totalEq = bs?.totalEquity ?: 105_000_000.0

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqProfit, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DOUBLE-ENTRY BALANCE SHEET STATUS",
                            color = RqProfit,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(RqProfitBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "ASSETS = LIAB + EQUITY ($0.00 VAR)",
                                color = RqProfit,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Assets", color = RqTextSecondary, fontSize = 10.sp)
                            Text(FinancialFormatter.formatCurrency(totalAssets), color = RqTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Text("=", color = RqPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Column {
                            Text("Total Liabilities", color = RqTextSecondary, fontSize = 10.sp)
                            Text(FinancialFormatter.formatCurrency(totalLiab), color = RqWarning, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Text("+", color = RqPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Column {
                            Text("Shareholder Equity", color = RqTextSecondary, fontSize = 10.sp)
                            Text(FinancialFormatter.formatCurrency(totalEq), color = RqProfit, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Holdings Snapshot
        item {
            SectionHeader(
                title = "Current Holdings & Subledger Positions",
                subtitle = "Multi-asset book across equities, sovereign debt, derivatives and digital vault"
            )
        }

        val instMap = state.instruments.associateBy { it.id }
        items(state.positions.size) { idx ->
            val pos = state.positions[idx]
            val inst = instMap[pos.instrumentId]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(6.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inst?.symbol ?: pos.instrumentId,
                                color = RqTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            if (inst != null) {
                                ProvenancePill(inst.provenance)
                            }
                        }
                        Text(
                            text = inst?.name ?: "Instrument ${pos.instrumentId}",
                            color = RqTextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "Qty: ${FinancialFormatter.formatNumber(pos.quantity)} @ $${pos.costBasis}",
                            color = RqTextTertiary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = FinancialFormatter.formatCurrency(pos.marketValue),
                            color = RqTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        val pnl = pos.unrealizedPnl
                        val pnlColor = if (pnl >= 0) RqProfit else RqLoss
                        Text(
                            text = "${if (pnl >= 0) "+" else ""}${FinancialFormatter.formatCurrency(pnl)}",
                            color = pnlColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
