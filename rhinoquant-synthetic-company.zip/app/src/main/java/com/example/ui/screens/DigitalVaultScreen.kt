package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.VaultKeyEngine
import com.example.domain.models.InstrumentType
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.ProvenancePill
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun DigitalVaultScreen(
    state: UiState,
    onOpenTrade: () -> Unit
) {
    val instMap = state.instruments.associateBy { it.id }
    val digitalPositions = state.positions.filter {
        val inst = instMap[it.instrumentId]
        inst?.type == InstrumentType.DIGITAL_ASSET
    }

    val totalDigitalValue = digitalPositions.sumOf { it.marketValue }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "INSTITUTIONAL DIGITAL VAULT & CRYPTOGRAPHIC KEYS",
                subtitle = "Cold storage MPC key management, Bitcoin reserves & smart contract execution"
            )

            // Vault Reserve Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorderBright, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = RqPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("TOTAL DIGITAL RESERVE VALUE", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = FinancialFormatter.formatCurrency(totalDigitalValue),
                            color = RqTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RqProfitBg)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "AIR-GAPPED HSM ACTIVE",
                            color = RqProfit,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Section: Active Institutional Vault Keys
        item {
            Text(
                text = "COMPANY INSTITUTIONAL VAULT KEYS & QUORUM",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(state.vaultKeys.size) { idx ->
            val key = state.vaultKeys[idx]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Key, contentDescription = null, tint = RqWarning, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(key.keyName, color = RqTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(RqProfitBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(key.status, color = RqProfit, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("KEY ID: ${key.keyId} • ALGORITHM: ${key.algorithm}", color = RqTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("QUORUM: ${key.quorumRequired}", color = RqTextTertiary, fontSize = 10.sp)

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("PUBLIC VAULT ON-CHAIN ADDRESS:", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = key.publicAddress,
                        color = RqPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("FINGERPRINT SHA-256: ${key.fingerprintsSha256.take(28)}...", color = RqTextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Section: On-Chain Vault Holdings
        item {
            Text(
                text = "ON-CHAIN DIGITAL RESERVE HOLDINGS",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(digitalPositions.size) { idx ->
            val pos = digitalPositions[idx]
            val inst = instMap[pos.instrumentId]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(inst?.symbol ?: "BTC", color = RqTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            if (inst != null) ProvenancePill(inst.provenance)
                        }
                        Text(inst?.name ?: "Bitcoin Holding", color = RqTextSecondary, fontSize = 11.sp)
                        Text(
                            text = "Reserve: ${FinancialFormatter.formatNumber(pos.quantity)} BTC @ $${FinancialFormatter.formatNumber(pos.costBasis)} cost",
                            color = RqTextTertiary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = FinancialFormatter.formatCurrency(pos.marketValue),
                            color = RqTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        val pnl = pos.unrealizedPnl
                        val pnlColor = if (pnl >= 0) RqProfit else RqLoss
                        Text(
                            text = "${if (pnl >= 0) "+" else ""}${FinancialFormatter.formatCurrency(pnl)}",
                            color = pnlColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = onOpenTrade,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("EXECUTE CRYPTOGRAPHICALLY SIGNED VAULT TRADE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
