package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.BlackScholes
import com.example.domain.models.InstrumentType
import com.example.domain.models.OptionType
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.ProvenancePill
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun DerivativesScreen(state: UiState, onOpenTrade: () -> Unit) {
    val instMap = state.instruments.associateBy { it.id }
    val derivativePositions = state.positions.filter {
        val inst = instMap[it.instrumentId]
        inst?.type == InstrumentType.OPTION || inst?.type == InstrumentType.SWAP || inst?.type == InstrumentType.CREDIT_DEFAULT_SWAP
    }

    val risk = state.riskSummary

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "DERIVATIVES SUBLEDGER & QUANTITATIVE GREEKS",
                subtitle = "Black-Scholes-Merton options pricing, swaps NPV and dual-curve discounting"
            )

            // Portfolio Greeks Dashboard
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorderBright, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("AGGREGATE PORTFOLIO GREEKS", color = RqPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("NET DELTA ($)", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = FinancialFormatter.formatCurrency(risk?.netDeltaNotional ?: 0.0),
                                color = RqTextPrimary,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column {
                            Text("GAMMA", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = String.format("%.4f", risk?.portfolioGamma ?: 0.0),
                                color = RqTextPrimary,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column {
                            Text("VEGA ($/1% VOL)", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = FinancialFormatter.formatCurrency(risk?.portfolioVega ?: 0.0),
                                color = RqWarning,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column {
                            Text("THETA ($/DAY)", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = FinancialFormatter.formatCurrency(risk?.portfolioThetaDaily ?: 0.0),
                                color = RqLoss,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Options Subledger
        item {
            Text(
                text = "EQUITY & INDEX OPTIONS (ANALYTICAL BLACK-SCHOLES)",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        val optionPositions = derivativePositions.filter { instMap[it.instrumentId]?.type == InstrumentType.OPTION }

        items(optionPositions.size) { idx ->
            val pos = optionPositions[idx]
            val inst = instMap[pos.instrumentId]

            if (inst != null) {
                val isCall = inst.optionType == OptionType.CALL
                val greeks = BlackScholes.calculate(
                    s = inst.cleanPrice,
                    k = inst.strike,
                    t = 0.25,
                    r = 0.045,
                    sigma = inst.impliedVol,
                    isCall = isCall
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = RqSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isCall) RqProfitBg else RqLossBg)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isCall) "CALL" else "PUT",
                                        color = if (isCall) RqProfit else RqLoss,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(inst.symbol, color = RqTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            ProvenancePill(inst.provenance)
                        }

                        Text(inst.name, color = RqTextSecondary, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Strike: $${inst.strike}", color = RqTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Spot: $${inst.cleanPrice}", color = RqTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Vol: ${FinancialFormatter.formatPct(inst.impliedVol * 100)}", color = RqPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Contracts: ${pos.quantity}", color = RqTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Divider(color = RqBorder)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Greeks row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Δ: ${String.format("%.3f", greeks.delta)}", color = RqTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text("Γ: ${String.format("%.4f", greeks.gamma)}", color = RqTextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("Vega: $${String.format("%.2f", greeks.vega)}", color = RqWarning, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("Theta: $${String.format("%.2f", greeks.theta)}/d", color = RqLoss, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Position Fair Value:", color = RqTextSecondary, fontSize = 10.sp)
                            Text(FinancialFormatter.formatCurrency(pos.marketValue), color = RqTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section Title: Swaps & Exotics
        item {
            Text(
                text = "INTEREST RATE SWAPS & STRUCTURED CONTRACTS",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        val swapPositions = derivativePositions.filter { instMap[it.instrumentId]?.type == InstrumentType.SWAP }

        items(swapPositions.size) { idx ->
            val pos = swapPositions[idx]
            val inst = instMap[pos.instrumentId]

            if (inst != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = RqSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(inst.symbol, color = RqTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            ProvenancePill(inst.provenance)
                        }
                        Text(inst.name, color = RqTextSecondary, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Notional: $25,000,000", color = RqTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Fixed: ${FinancialFormatter.formatPct(inst.swapFixedRate * 100)}", color = RqPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Floating: ${inst.swapFloatingIndex}", color = RqTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Discounted Net Present Value (NPV):", color = RqTextSecondary, fontSize = 10.sp)
                            Text(FinancialFormatter.formatCurrency(pos.marketValue), color = RqProfit, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = onOpenTrade,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("+ ENTER NEW DERIVATIVE CONTRACT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
