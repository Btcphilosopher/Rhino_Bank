package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.SyntheticCompany
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun RegistryScreen(
    state: UiState,
    onOpenCreateCompany: () -> Unit,
    onSelectEntity: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "COMPANY REGISTRY & CORPORATE HIERARCHY",
                subtitle = "Multi-entity capital structure, ownership percentages & consolidation rules"
            )
        }

        // Entity Cards
        items(state.companies.size) { idx ->
            val comp = state.companies[idx]
            val isSelected = comp.id == state.selectedEntityId

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (isSelected) RqPrimary else RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Business, contentDescription = null, tint = RqPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(comp.name, color = RqTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(RqSurfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(comp.id, color = RqPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(comp.legalForm, color = RqTextSecondary, fontSize = 11.sp)
                    Text("Mandate: ${comp.investmentMandate}", color = RqTextTertiary, fontSize = 10.sp)

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = RqBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Initial Share Capital", color = RqTextSecondary, fontSize = 9.sp)
                            Text(FinancialFormatter.formatCurrency(comp.initialCapital), color = RqTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Max Gross Leverage", color = RqTextSecondary, fontSize = 9.sp)
                            Text("${comp.maxGrossLeverage}x Limit", color = RqWarning, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Ownership %", color = RqTextSecondary, fontSize = 9.sp)
                            Text("${comp.ownershipPct.toInt()}%", color = RqProfit, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Share Classes: ${comp.shareClasses}", color = RqTextTertiary, fontSize = 9.sp)

                    if (!isSelected) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { onSelectEntity(comp.id) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("SWITCH ACTIVE ENTITY BOOK", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = onOpenCreateCompany,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("+ INCORPORATE NEW SYNTHETIC ENTITY", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
