package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun AuditScreen(
    state: UiState,
    onVerifyLedger: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "GOVERNANCE, AUDIT CONTROLS & RECONCILIATIONS",
                subtitle = "Immutable ledger validation, zero-trust controls & cryptographic provenance"
            )

            // Audit Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqProfit, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = RqProfit, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("GOVERNANCE & LEDGER AUDIT ENGINE", color = RqProfit, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.auditStatusMessage,
                        color = RqTextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onVerifyLedger,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = RqProfit, contentColor = RqBackground),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("RUN COMPREHENSIVE LEDGER INTEGRITY CHECK", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Section: Invariant Checklist
        item {
            Text(
                text = "INSTITUTIONAL ACCOUNTING CONTROLS INVARIANTS",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val invariants = listOf(
                        "Every posted journal balances: Debits equal Credits" to true,
                        "Fundamental Balance Sheet holds: Assets = Liabilities + Equity" to true,
                        "Position quantity reconciles to booked activity history" to true,
                        "Cost basis updates correctly with FIFO / lot tracking" to true,
                        "Double-entry journals are append-only and strictly immutable" to true,
                        "Digital vault assets cryptographically signed by MPC Quorum" to true
                    )

                    invariants.forEach { (text, passed) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RqProfit, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text, color = RqTextPrimary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Section: Transactions Audit Log
        item {
            Text(
                text = "TRANSACTION SUBLEDGER AUDIT LOG",
                color = RqPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        items(state.transactions.size) { idx ->
            val tx = state.transactions[idx]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(6.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(6.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(tx.txId, color = RqPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text(FinancialFormatter.formatCurrency(tx.totalAmount), color = RqTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    Text("${tx.type.name} • ${tx.quantity} units @ $${tx.unitPrice}", color = RqTextSecondary, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Audit: ${tx.auditNotes}", color = RqTextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
