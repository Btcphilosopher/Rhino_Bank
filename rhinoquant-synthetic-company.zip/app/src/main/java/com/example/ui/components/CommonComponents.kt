package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.ValuationProvenance
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

object FinancialFormatter {
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale.US).apply {
        maximumFractionDigits = 2
        minimumFractionDigits = 2
    }

    private val numberFormat = NumberFormat.getNumberInstance(Locale.US).apply {
        maximumFractionDigits = 2
    }

    fun formatCurrency(amount: Double): String = currencyFormat.format(amount)
    fun formatNumber(amount: Double): String = numberFormat.format(amount)
    fun formatPct(pct: Double): String = String.format(Locale.US, "%.2f%%", pct)
    fun formatBps(bps: Double): String = String.format(Locale.US, "+%.0f bps", bps)
}

@Composable
fun TerminalMetricCard(
    title: String,
    value: String,
    subtitle: String? = null,
    badgeText: String? = null,
    isPositiveBadge: Boolean = true,
    accentColor: Color = RqPrimary,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = RqSurface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    color = RqTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
                if (badgeText != null) {
                    val badgeBg = if (isPositiveBadge) RqProfitBg else RqLossBg
                    val badgeColor = if (isPositiveBadge) RqProfit else RqLoss
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(badgeBg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badgeText,
                            color = badgeColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                color = RqTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            if (subtitle != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    color = RqTextTertiary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun ProvenancePill(provenance: ValuationProvenance) {
    val (bg, text) = when (provenance) {
        ValuationProvenance.VERIFIED_MARKET -> Pair(Color(0x2210B981), Color(0xFF10B981))
        ValuationProvenance.MODELLED -> Pair(Color(0x2238BDF8), Color(0xFF38BDF8))
        ValuationProvenance.HISTORICAL -> Pair(Color(0x22F59E0B), Color(0xFFF59E0B))
        ValuationProvenance.DELAYED -> Pair(Color(0x2294A3B8), Color(0xFF94A3B8))
        ValuationProvenance.STALE -> Pair(Color(0x22EF4444), Color(0xFFEF4444))
        ValuationProvenance.SIMULATED -> Pair(Color(0x22A855F7), Color(0xFFA855F7))
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = provenance.name,
            color = text,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String? = null) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            text = title.uppercase(),
            color = RqPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        if (subtitle != null) {
            Text(
                text = subtitle,
                color = RqTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}
