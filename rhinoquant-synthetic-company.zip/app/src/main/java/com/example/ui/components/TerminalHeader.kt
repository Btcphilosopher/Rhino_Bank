package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.models.SyntheticCompany
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab

@Composable
fun TerminalHeader(
    companies: List<SyntheticCompany>,
    selectedEntityId: String,
    isConsolidated: Boolean,
    onSelectEntity: (String) -> Unit,
    onToggleConsolidated: (Boolean) -> Unit
) {
    var expandedDropdown by remember { mutableStateOf(false) }
    val activeCompany = companies.find { it.id == selectedEntityId }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(RqBackground)
            .border(1.dp, RqBorder)
    ) {
        // Top status ticker bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RqSurfaceVariant)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(RqProfit)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RQ-SYNCO ENGINE v3.6 • SIMULATED DOUBLE-ENTRY SUBLEDGER",
                    color = RqTextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(RqWarningBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "SIMULATED ENTITY",
                        color = RqWarning,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "USD / FVTPL",
                    color = RqPrimary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Main Institutional Entity Selector Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.rq_launcher_icon),
                    contentDescription = "RhinoQuant Icon",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .border(1.dp, RqBorderBright, RoundedCornerShape(6.dp))
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "RHINOQUANT",
                            color = RqTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SYNTHETIC COMPANY",
                            color = RqPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Entity Selector Trigger
                    Box {
                        Row(
                            modifier = Modifier
                                .clickable { expandedDropdown = true }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isConsolidated) "CONSOLIDATED GROUP VIEW (3 Entities)" else (activeCompany?.name ?: "Select Entity"),
                                color = if (isConsolidated) RqPrimary else RqTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Dropdown",
                                tint = RqPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = expandedDropdown,
                            onDismissRequest = { expandedDropdown = false },
                            modifier = Modifier.background(RqSurfaceVariant)
                        ) {
                            companies.forEach { comp ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = comp.name,
                                                color = RqTextPrimary,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${comp.id} • ${comp.legalForm}",
                                                color = RqTextSecondary,
                                                fontSize = 10.sp
                                            )
                                        }
                                    },
                                    onClick = {
                                        onToggleConsolidated(false)
                                        onSelectEntity(comp.id)
                                        expandedDropdown = false
                                    }
                                )
                            }
                            Divider(color = RqBorder)
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Layers,
                                            contentDescription = "Consolidated",
                                            tint = RqPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Consolidated Group (With Eliminations)",
                                            color = RqPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                },
                                onClick = {
                                    onToggleConsolidated(true)
                                    expandedDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            // Consolidated Toggle Pill
            FilterChip(
                selected = isConsolidated,
                onClick = { onToggleConsolidated(!isConsolidated) },
                label = {
                    Text(
                        text = if (isConsolidated) "Consolidated" else "Entity Book",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = RqPrimary.copy(alpha = 0.2f),
                    selectedLabelColor = RqPrimary,
                    containerColor = RqSurface,
                    labelColor = RqTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    borderColor = if (isConsolidated) RqPrimary else RqBorder,
                    enabled = true,
                    selected = isConsolidated
                )
            )
        }
    }
}

@Composable
fun TerminalTabBar(
    selectedTab: TerminalTab,
    onTabSelected: (TerminalTab) -> Unit
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(RqSurface)
            .border(1.dp, RqBorder)
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        TerminalTab.values().forEach { tab ->
            val isSelected = tab == selectedTab
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) RqPrimary else Color.Transparent)
                    .border(
                        1.dp,
                        if (isSelected) RqPrimary else RqBorder,
                        RoundedCornerShape(6.dp)
                    )
                    .clickable { onTabSelected(tab) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = tab.label.uppercase(),
                    color = if (isSelected) RqBackground else RqTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}
