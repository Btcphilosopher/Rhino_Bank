package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.engine.VaultKeyEngine
import com.example.domain.models.Instrument
import com.example.domain.models.InstrumentType
import com.example.domain.models.TransactionType
import com.example.ui.theme.*

@Composable
fun TradeExecutionDialog(
    instruments: List<Instrument>,
    onDismiss: () -> Unit,
    onExecute: (instrumentId: String, type: TransactionType, quantity: Double, unitPrice: Double, useVaultKey: Boolean) -> Unit
) {
    var selectedInstrumentId by remember { mutableStateOf(instruments.firstOrNull()?.id ?: "") }
    var actionType by remember { mutableStateOf(TransactionType.BUY) }
    var quantityText by remember { mutableStateOf("100") }
    var useVaultKey by remember { mutableStateOf(true) }

    val selectedInstrument = instruments.find { it.id == selectedInstrumentId }
    var priceText by remember { mutableStateOf(selectedInstrument?.cleanPrice?.toString() ?: "100.0") }

    LaunchedEffect(selectedInstrumentId) {
        selectedInstrument?.cleanPrice?.let {
            priceText = it.toString()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, RqBorderBright, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = RqSurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "EXECUTE CONTRACT / TRADE",
                            color = RqPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Subledger Double-Entry Posting",
                            color = RqTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = RqTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Type Selector (BUY / SELL / OPTION_ENTER)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(TransactionType.BUY, TransactionType.SELL, TransactionType.OPTION_ENTER).forEach { t ->
                        val isSelected = actionType == t
                        Button(
                            onClick = { actionType = t },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) {
                                    if (t == TransactionType.BUY) RqProfit else if (t == TransactionType.SELL) RqLoss else RqPrimary
                                } else RqSurface,
                                contentColor = if (isSelected) RqBackground else RqTextSecondary
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text(
                                text = t.name.replace("_", " "),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Instrument Selector
                Text("SELECT ASSET OR CONTRACT", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(RqSurface)
                        .padding(8.dp)
                ) {
                    instruments.take(7).forEach { inst ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = selectedInstrumentId == inst.id,
                                    onClick = { selectedInstrumentId = inst.id },
                                    colors = RadioButtonDefaults.colors(selectedColor = RqPrimary)
                                )
                                Column {
                                    Text(
                                        text = "${inst.symbol} (${inst.type.name})",
                                        color = RqTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = inst.name, color = RqTextTertiary, fontSize = 10.sp)
                                }
                            }
                            Text(
                                text = "$${inst.cleanPrice}",
                                color = RqPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quantity Input
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Quantity / Contracts", color = RqTextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqPrimary,
                        unfocusedBorderColor = RqBorder,
                        focusedTextColor = RqTextPrimary,
                        unfocusedTextColor = RqTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Price Input
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Execution Unit Price ($)", color = RqTextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqPrimary,
                        unfocusedBorderColor = RqBorder,
                        focusedTextColor = RqTextPrimary,
                        unfocusedTextColor = RqTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Vault Key Signing Checkbox
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(RqSurface)
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = useVaultKey,
                        onCheckedChange = { useVaultKey = it },
                        colors = CheckboxDefaults.colors(checkedColor = RqPrimary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = RqPrimary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Institutional Vault Key Signing",
                                color = RqTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "SECP256K1 ECDSA with 2-of-3 MPC Quorum",
                            color = RqTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Submit Button
                Button(
                    onClick = {
                        val q = quantityText.toDoubleOrNull() ?: 1.0
                        val p = priceText.toDoubleOrNull() ?: (selectedInstrument?.cleanPrice ?: 100.0)
                        onExecute(selectedInstrumentId, actionType, q, p, useVaultKey)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "EXECUTE & POST TO SUBLEDGER",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun CreateCompanyDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, legalForm: String, currency: String, accountingBasis: String, capital: Double, mandate: String) -> Unit
) {
    var name by remember { mutableStateOf("Rhino Quantitative Ventures Ltd.") }
    var legalForm by remember { mutableStateOf("Simulated Exempt Special Purpose Vehicle (RQ-SYNCO)") }
    var capitalText by remember { mutableStateOf("50000000") }
    var mandate by remember { mutableStateOf("Systematic Macro & Multi-Asset Absolute Return") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, RqBorderBright, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = RqSurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "NEW SYNTHETIC COMPANY",
                        color = RqPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = RqTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display Entity Name", color = RqTextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqPrimary,
                        unfocusedBorderColor = RqBorder,
                        focusedTextColor = RqTextPrimary,
                        unfocusedTextColor = RqTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = legalForm,
                    onValueChange = { legalForm = it },
                    label = { Text("Legal Form Classification", color = RqTextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqPrimary,
                        unfocusedBorderColor = RqBorder,
                        focusedTextColor = RqTextPrimary,
                        unfocusedTextColor = RqTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = capitalText,
                    onValueChange = { capitalText = it },
                    label = { Text("Initial Contributed Capital ($ USD)", color = RqTextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqPrimary,
                        unfocusedBorderColor = RqBorder,
                        focusedTextColor = RqTextPrimary,
                        unfocusedTextColor = RqTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = mandate,
                    onValueChange = { mandate = it },
                    label = { Text("Investment Mandate & Risk Strategy", color = RqTextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RqPrimary,
                        unfocusedBorderColor = RqBorder,
                        focusedTextColor = RqTextPrimary,
                        unfocusedTextColor = RqTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        val cap = capitalText.toDoubleOrNull() ?: 50_000_000.0
                        onCreate(name, legalForm, "USD", "IFRS Modelled / FVTPL", cap, mandate)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "INCORPORATE SYNTHETIC ENTITY",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun VaultSignerDialog(
    payload: VaultKeyEngine.SignedExecutionPayload,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, RqProfit, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = RqSurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Key, contentDescription = null, tint = RqProfit, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CRYPTOGRAPHIC EXECUTION PROOF",
                            color = RqProfit,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = RqTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(RqSurface)
                        .padding(12.dp)
                ) {
                    Column {
                        Text("EXECUTION ID", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(payload.executionId, color = RqTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("PUBLIC VAULT ADDRESS", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(payload.publicAddress, color = RqPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("TRANSACTION SHA-256 HASH", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(payload.transactionHash, color = RqTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("ECDSA SIGNATURE (DER HEX)", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(payload.signatureHex, color = RqWarning, fontSize = 9.sp, fontFamily = FontFamily.Monospace)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(RqProfit)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = payload.verificationStatus,
                                color = RqProfit,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = RqSurface, contentColor = RqTextPrimary),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("CLOSE RECEIPT")
                }
            }
        }
    }
}
