package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional RhinoQuant Terminal Colors
// Dark Navy & Graphite Surfaces
val RqBackground = Color(0xFF090D16)      // Deepest background
val RqSurface = Color(0xFF0E1422)         // Main card surface
val RqSurfaceVariant = Color(0xFF151E32)  // Elevated panel / grid header
val RqSurfaceHover = Color(0xFF1B2740)    // Active/hover surface
val RqBorder = Color(0xFF22314E)          // Subtle thin divider
val RqBorderBright = Color(0xFF2D4066)    // Emphasized border

// Restrained Steel-Blue & Slate Accents
val RqPrimary = Color(0xFF38BDF8)         // Electric steel blue
val RqPrimaryVariant = Color(0xFF0284C7)  // Deep cyan
val RqSecondary = Color(0xFF94A3B8)       // Cool slate
val RqSecondaryVariant = Color(0xFF64748B)

// Institutional Financial Semantics
val RqProfit = Color(0xFF10B981)          // Emerald gain
val RqProfitBg = Color(0x2210B981)        // Transparent green pill
val RqLoss = Color(0xFFEF4444)            // Crimson loss
val RqLossBg = Color(0x22EF4444)          // Transparent red pill
val RqWarning = Color(0xFFF59E0B)         // Muted amber status
val RqWarningBg = Color(0x22F59E0B)
val RqInfo = Color(0xFF3B82F6)            // Blue indicator
val RqPurple = Color(0xFFA855F7)          // Derivative / structured note accent

// Text & Monospace Numerals
val RqTextPrimary = Color(0xFFF8FAFC)     // Crisp white/slate
val RqTextSecondary = Color(0xFF94A3B8)   // Muted slate
val RqTextTertiary = Color(0xFF64748B)    // Dim label
val RqTextCode = Color(0xFF38BDF8)        // Monospace accent
