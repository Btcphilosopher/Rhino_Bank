package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.AccountingEngine
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun FinancialsScreen(state: UiState) {
    var selectedSubtab by remember { mutableStateOf("BALANCE_SHEET") }

    val bs = state.balanceSheet
    val pnl = state.pnlStatement
    val tb = state.trialBalance

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "DOUBLE-ENTRY ACCOUNTING & FINANCIAL STATEMENTS",
                subtitle = "Subledger reconciliation, trial balance verification & general ledger audit"
            )

            // Subtab Switcher (Balance Sheet, P&L, Trial Balance, Journal Ledger)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "BALANCE_SHEET" to "BALANCE SHEET",
                    "PNL" to "PROFIT & LOSS",
                    "TRIAL_BALANCE" to "TRIAL BALANCE",
                    "JOURNAL" to "JOURNAL LEDGER"
                ).forEach { (key, label) ->
                    val isSelected = selectedSubtab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) RqPrimary else RqSurface)
                            .border(1.dp, if (isSelected) RqPrimary else RqBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedSubtab = key }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) RqBackground else RqTextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Subtab: BALANCE SHEET
        if (selectedSubtab == "BALANCE_SHEET" && bs != null) {
            item {
                // Invariant verification banner
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RqProfit, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = RqSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RqProfit, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("ACCOUNTING INVARIANT VERIFIED", color = RqProfit, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Assets = Liabilities + Equity", color = RqTextSecondary, fontSize = 10.sp)
                            }
                        }
                        Text(
                            text = "VARIANCE: $0.00",
                            color = RqProfit,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            item {
                // ASSETS SECTION
                StatementSectionCard(section = bs.currentAssets)
            }
            item {
                StatementSectionCard(section = bs.nonCurrentAssets)
            }
            item {
                TotalRowCard(label = "TOTAL RECOGNISED ASSETS", amount = bs.totalAssets, color = RqTextPrimary)
            }

            item {
                // LIABILITIES SECTION
                StatementSectionCard(section = bs.currentLiabilities)
            }
            item {
                StatementSectionCard(section = bs.longTermLiabilities)
            }
            item {
                TotalRowCard(label = "TOTAL LIABILITIES", amount = bs.totalLiabilities, color = RqWarning)
            }

            item {
                // EQUITY SECTION
                StatementSectionCard(section = bs.equitySection)
            }
            item {
                TotalRowCard(label = "TOTAL SHAREHOLDERS' EQUITY", amount = bs.totalEquity, color = RqProfit)
            }
            item {
                TotalRowCard(label = "TOTAL LIABILITIES & EQUITY", amount = bs.totalLiabilities + bs.totalEquity, color = RqPrimary)
            }
        }

        // Subtab: PROFIT & LOSS
        if (selectedSubtab == "PNL" && pnl != null) {
            item {
                IncomeSectionCard(section = pnl.operatingRevenue)
            }
            item {
                IncomeSectionCard(section = pnl.financialIncome)
            }
            item {
                TotalRowCard(label = "TOTAL GROSS REVENUE", amount = pnl.grossIncome, color = RqTextPrimary)
            }
            item {
                IncomeSectionCard(section = pnl.operatingExpenses)
            }
            item {
                IncomeSectionCard(section = pnl.financingCosts)
            }
            item {
                TotalRowCard(label = "TOTAL EXPENSES & FINANCING", amount = pnl.totalExpenses, color = RqWarning)
            }
            item {
                val netColor = if (pnl.netIncome >= 0) RqProfit else RqLoss
                TotalRowCard(label = "NET COMPREHENSIVE INCOME (P&L)", amount = pnl.netIncome, color = netColor)
            }
        }

        // Subtab: TRIAL BALANCE
        if (selectedSubtab == "TRIAL_BALANCE" && tb != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = RqSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(RqSurfaceVariant)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("CODE / ACCOUNT", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                            Text("DEBIT ($)", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("CREDIT ($)", color = RqTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        }

                        tb.rows.forEach { row ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.5f)) {
                                    Text(row.accountCode, color = RqPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    Text(row.accountName, color = RqTextSecondary, fontSize = 10.sp, maxLines = 1)
                                }
                                Text(
                                    text = if (row.debitAmount > 0) FinancialFormatter.formatCurrency(row.debitAmount) else "-",
                                    color = RqTextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = if (row.creditAmount > 0) FinancialFormatter.formatCurrency(row.creditAmount) else "-",
                                    color = RqTextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Divider(color = RqBorder)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TOTALS", color = RqTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(FinancialFormatter.formatCurrency(tb.totalDebits), color = RqProfit, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(FinancialFormatter.formatCurrency(tb.totalCredits), color = RqProfit, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Subtab: JOURNAL LEDGER
        if (selectedSubtab == "JOURNAL") {
            items(state.journals.size) { idx ->
                val j = state.journals[idx]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RqBorder, RoundedCornerShape(6.dp)),
                    colors = CardDefaults.cardColors(containerColor = RqSurface),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(j.id, color = RqPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(FinancialFormatter.formatCurrency(j.amount), color = RqTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Text(j.description, color = RqTextSecondary, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("DR ${j.debitAccountCode} (${j.debitAccountName})", color = RqProfit, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("CR ${j.creditAccountCode} (${j.creditAccountName})", color = RqWarning, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun StatementSectionCard(section: AccountingEngine.BalanceSheetSection) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = RqSurface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(section.title.uppercase(), color = RqPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            Spacer(modifier = Modifier.height(6.dp))

            section.items.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row {
                        Text(item.code, color = RqTextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(item.name, color = RqTextSecondary, fontSize = 11.sp)
                    }
                    Text(
                        text = FinancialFormatter.formatCurrency(item.amount),
                        color = RqTextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Divider(color = RqBorder, modifier = Modifier.padding(vertical = 4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SUBTOTAL", color = RqTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = FinancialFormatter.formatCurrency(section.subtotal),
                    color = RqTextPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun IncomeSectionCard(section: AccountingEngine.IncomeStatementSection) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = RqSurface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(section.title.uppercase(), color = RqPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            Spacer(modifier = Modifier.height(6.dp))

            section.items.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row {
                        Text(item.code, color = RqTextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(item.name, color = RqTextSecondary, fontSize = 11.sp)
                    }
                    Text(
                        text = FinancialFormatter.formatCurrency(item.amount),
                        color = RqTextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Divider(color = RqBorder, modifier = Modifier.padding(vertical = 4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SUBTOTAL", color = RqTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = FinancialFormatter.formatCurrency(section.subtotal),
                    color = RqTextPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun TotalRowCard(label: String, amount: Double, color: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp)),
        colors = CardDefaults.cardColors(containerColor = RqSurfaceVariant),
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Text(
                text = FinancialFormatter.formatCurrency(amount),
                color = color,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black
            )
        }
    }
}
