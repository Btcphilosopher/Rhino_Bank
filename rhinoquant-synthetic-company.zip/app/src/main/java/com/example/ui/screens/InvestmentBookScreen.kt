package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.InstrumentType
import com.example.ui.components.FinancialFormatter
import com.example.ui.components.ProvenancePill
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState

@Composable
fun InvestmentBookScreen(state: UiState, onOpenTrade: () -> Unit) {
    var selectedFilter by remember { mutableStateOf<InstrumentType?>(null) }
    val instMap = state.instruments.associateBy { it.id }

    val filteredPositions = state.positions.filter { pos ->
        val inst = instMap[pos.instrumentId]
        if (selectedFilter == null) true else inst?.type == selectedFilter
    }

    val totalBookValue = state.positions.sumOf { it.marketValue }
    val totalUnrealized = state.positions.sumOf { it.unrealizedPnl }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RqBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeader(
                title = "MULTI-ASSET INVESTMENT BOOK & SECURITIES SUBLEDGER",
                subtitle = "Lot-level accounting with traceable valuation provenance"
            )

            // Summary Header Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL INVESTMENT BOOK VALUE", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = FinancialFormatter.formatCurrency(totalBookValue),
                            color = RqTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("TOTAL UNREALIZED P&L", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        val pnlColor = if (totalUnrealized >= 0) RqProfit else RqLoss
                        Text(
                            text = "${if (totalUnrealized >= 0) "+" else ""}${FinancialFormatter.formatCurrency(totalUnrealized)}",
                            color = pnlColor,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Filter Pills
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val filters = listOf(
                    null to "ALL (${state.positions.size})",
                    InstrumentType.EQUITY to "EQUITY",
                    InstrumentType.FIXED_INCOME to "BONDS",
                    InstrumentType.DIGITAL_ASSET to "VAULT/BTC",
                    InstrumentType.OPTION to "OPTIONS"
                )

                filters.forEach { (type, label) ->
                    val isSelected = selectedFilter == type
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) RqPrimary else RqSurface)
                            .border(1.dp, if (isSelected) RqPrimary else RqBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedFilter = type }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) RqBackground else RqTextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RqSurfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("INSTRUMENT / LOT", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                Text("QTY / COST BASIS", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                Text("MTM VALUE / P&L", color = RqTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
            }
        }

        // Positions
        items(filteredPositions.size) { idx ->
            val pos = filteredPositions[idx]
            val inst = instMap[pos.instrumentId]

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RqBorder, RoundedCornerShape(6.dp)),
                colors = CardDefaults.cardColors(containerColor = RqSurface),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inst?.symbol ?: pos.instrumentId,
                                color = RqTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            if (inst != null) {
                                ProvenancePill(inst.provenance)
                            }
                        }
                        Text(text = inst?.name ?: "", color = RqTextSecondary, fontSize = 10.sp, maxLines = 1)
                        Text(text = "Book: ${pos.accountingBook}", color = RqTextTertiary, fontSize = 9.sp)
                    }

                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = "${FinancialFormatter.formatNumber(pos.quantity)} units",
                            color = RqTextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Cost: $${FinancialFormatter.formatNumber(pos.costBasis)}",
                            color = RqTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Px: $${FinancialFormatter.formatNumber(pos.currentPrice)}",
                            color = RqPrimary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Text(
                            text = FinancialFormatter.formatCurrency(pos.marketValue),
                            color = RqTextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        val pnl = pos.unrealizedPnl
                        val pnlColor = if (pnl >= 0) RqProfit else RqLoss
                        Text(
                            text = "${if (pnl >= 0) "+" else ""}${FinancialFormatter.formatCurrency(pnl)}",
                            color = pnlColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = onOpenTrade,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RqPrimary, contentColor = RqBackground),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("+ BOOK NEW SECURITY ACQUISITION / DISPOSAL", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
