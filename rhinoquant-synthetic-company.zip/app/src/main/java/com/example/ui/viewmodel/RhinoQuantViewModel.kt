package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RhinoQuantDatabase
import com.example.data.RhinoQuantRepository
import com.example.domain.engine.AccountingEngine
import com.example.domain.engine.RiskEngine
import com.example.domain.engine.VaultKeyEngine
import com.example.domain.models.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class TerminalTab(val label: String) {
    OVERVIEW("Overview"),
    INVESTMENT_BOOK("Investment Book"),
    DERIVATIVES("Derivatives"),
    DIGITAL_VAULT("Digital Vault & Keys"),
    TREASURY("Treasury & Financing"),
    FINANCIALS("Financial Statements"),
    RISK_SCENARIOS("Risk & Scenarios"),
    REGISTRY("Entity Registry"),
    AUDIT("Audit & Controls")
}

data class UiState(
    val companies: List<SyntheticCompany> = emptyList(),
    val selectedEntityId: String = "ENT-RSH-001",
    val isConsolidatedView: Boolean = false,
    val activeTab: TerminalTab = TerminalTab.OVERVIEW,
    val instruments: List<Instrument> = emptyList(),
    val positions: List<Position> = emptyList(),
    val transactions: List<FinancialTransaction> = emptyList(),
    val journals: List<JournalEntry> = emptyList(),
    val financings: List<FinancingFacility> = emptyList(),
    val collaterals: List<CollateralAgreement> = emptyList(),
    val vaultKeys: List<VaultKeyEngine.InstitutionalVaultKey> = emptyList(),
    val riskSummary: RiskEngine.PortfolioRiskSummary? = null,
    val balanceSheet: AccountingEngine.BalanceSheet? = null,
    val pnlStatement: AccountingEngine.ProfitAndLossStatement? = null,
    val trialBalance: AccountingEngine.TrialBalance? = null,
    val activeStressResult: RiskEngine.StressTestResult? = null,
    // Scenario shock parameters
    val scenarioEquityShockPct: Double = -0.20,
    val scenarioRatesShockBps: Double = 150.0,
    val scenarioVolShockPct: Double = 0.30,
    val scenarioFxShockPct: Double = -0.10,
    // Modals
    val showTradeDialog: Boolean = false,
    val showCreateCompanyDialog: Boolean = false,
    val showVaultSignerDialog: Boolean = false,
    val latestSignedExecution: VaultKeyEngine.SignedExecutionPayload? = null,
    val auditStatusMessage: String = "Double-Entry Ledger Verified: Invariants intact."
)

class RhinoQuantViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RhinoQuantRepository

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        val db = RhinoQuantDatabase.getDatabase(application)
        repository = RhinoQuantRepository(db)

        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            observeData()
        }
    }

    private fun observeData() {
        viewModelScope.launch {
            combine(
                repository.allCompanies,
                repository.allInstruments,
                _uiState.map { it.selectedEntityId }.distinctUntilChanged(),
                _uiState.map { it.isConsolidatedView }.distinctUntilChanged()
            ) { companies, instruments, selectedId, isConsolidated ->
                val entityIdToQuery = if (isConsolidated) "ENT-RSH-001" else selectedId
                val effectiveId = if (companies.any { it.id == entityIdToQuery }) entityIdToQuery else companies.firstOrNull()?.id ?: "ENT-RSH-001"
                Triple(companies, instruments, effectiveId)
            }.collect { (companies, instruments, effectiveId) ->
                val isConsolidated = _uiState.value.isConsolidatedView

                val positionsFlow = if (isConsolidated) repository.getAllPositions() else repository.getPositionsForEntity(effectiveId)
                val txsFlow = if (isConsolidated) repository.getAllTransactions() else repository.getTransactionsForEntity(effectiveId)
                val journalsFlow = if (isConsolidated) repository.getAllJournals() else repository.getJournalsForEntity(effectiveId)
                val financingsFlow = if (isConsolidated) repository.getAllFinancing() else repository.getFinancingForEntity(effectiveId)
                val collateralsFlow = repository.getCollateralForEntity(effectiveId)

                combine(
                    positionsFlow,
                    txsFlow,
                    journalsFlow,
                    financingsFlow,
                    collateralsFlow
                ) { pos, txs, journals, financings, collaterals ->
                    val instMap = instruments.associateBy { it.id }

                    // Calculate total debt and cash from journals/positions
                    val totalDebt = financings.sumOf { it.principalAmount }
                    // Derive cash balance
                    val cashDebit = journals.filter { it.debitAccountCode == "1000" }.sumOf { it.amount }
                    val cashCredit = journals.filter { it.creditAccountCode == "1000" }.sumOf { it.amount }
                    val cashBalance = (cashDebit - cashCredit).coerceAtLeast(5_000_000.0)

                    val activeCompany = companies.find { it.id == effectiveId }
                    val initialCapital = activeCompany?.initialCapital ?: 100_000_000.0

                    // Calculate Risk
                    val risk = RiskEngine.calculatePortfolioRisk(pos, instMap, cashBalance, totalDebt)

                    // Calculate Financial Statements
                    val bankDebt = financings.filter { it.facilityType.contains("Loan", true) || it.facilityType.contains("Credit", true) }.sumOf { it.principalAmount }
                    val repoDebt = financings.filter { it.facilityType.contains("Repo", true) }.sumOf { it.principalAmount }
                    val (bs, pnl) = AccountingEngine.generateFinancialStatements(
                        entityId = effectiveId,
                        positions = pos,
                        cashBalance = cashBalance,
                        bankDebt = bankDebt,
                        repoDebt = repoDebt,
                        initialCapital = initialCapital
                    )

                    // Calculate Trial Balance
                    val tb = AccountingEngine.calculateTrialBalance(journals)

                    // Generate vault keys for this entity
                    val btcKey = VaultKeyEngine.generateVaultKey(effectiveId, "BTC")
                    val ethKey = VaultKeyEngine.generateVaultKey(effectiveId, "ETH")

                    // Run initial stress test
                    val stress = RiskEngine.evaluateScenario(
                        scenarioName = "Global Stagflation & Rates Spike",
                        scenarioDescription = "Equity markets drop 20%, yield curve rises 150 bps, vol jumps 30%, USD surges.",
                        equityShockPct = _uiState.value.scenarioEquityShockPct,
                        ratesShockBps = _uiState.value.scenarioRatesShockBps,
                        volShockPct = _uiState.value.scenarioVolShockPct,
                        fxShockPct = _uiState.value.scenarioFxShockPct,
                        positions = pos,
                        instrumentsMap = instMap,
                        cashBalance = cashBalance,
                        totalDebt = totalDebt
                    )

                    _uiState.update { current ->
                        current.copy(
                            companies = companies,
                            selectedEntityId = effectiveId,
                            instruments = instruments,
                            positions = pos,
                            transactions = txs,
                            journals = journals,
                            financings = financings,
                            collaterals = collaterals,
                            vaultKeys = listOf(btcKey, ethKey),
                            riskSummary = risk,
                            balanceSheet = bs,
                            pnlStatement = pnl,
                            trialBalance = tb,
                            activeStressResult = stress
                        )
                    }
                }.collect()
            }
        }
    }

    fun selectEntity(entityId: String) {
        _uiState.update { it.copy(selectedEntityId = entityId, isConsolidatedView = false) }
    }

    fun toggleConsolidatedView(enabled: Boolean) {
        _uiState.update { it.copy(isConsolidatedView = enabled) }
    }

    fun selectTab(tab: TerminalTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun updateScenarioParameters(
        equityShockPct: Double = _uiState.value.scenarioEquityShockPct,
        ratesShockBps: Double = _uiState.value.scenarioRatesShockBps,
        volShockPct: Double = _uiState.value.scenarioVolShockPct,
        fxShockPct: Double = _uiState.value.scenarioFxShockPct
    ) {
        val s = _uiState.value
        val instMap = s.instruments.associateBy { it.id }
        val totalDebt = s.financings.sumOf { it.principalAmount }
        val cashDebit = s.journals.filter { it.debitAccountCode == "1000" }.sumOf { it.amount }
        val cashCredit = s.journals.filter { it.creditAccountCode == "1000" }.sumOf { it.amount }
        val cashBalance = (cashDebit - cashCredit).coerceAtLeast(5_000_000.0)

        val stress = RiskEngine.evaluateScenario(
            scenarioName = "Custom Stress Environment",
            scenarioDescription = "Equity: ${(equityShockPct * 100).toInt()}%, Rates: +${ratesShockBps.toInt()}bps, Vol: +${(volShockPct * 100).toInt()}%, FX: ${(fxShockPct * 100).toInt()}%",
            equityShockPct = equityShockPct,
            ratesShockBps = ratesShockBps,
            volShockPct = volShockPct,
            fxShockPct = fxShockPct,
            positions = s.positions,
            instrumentsMap = instMap,
            cashBalance = cashBalance,
            totalDebt = totalDebt
        )

        _uiState.update {
            it.copy(
                scenarioEquityShockPct = equityShockPct,
                scenarioRatesShockBps = ratesShockBps,
                scenarioVolShockPct = volShockPct,
                scenarioFxShockPct = fxShockPct,
                activeStressResult = stress
            )
        }
    }

    fun openTradeDialog() = _uiState.update { it.copy(showTradeDialog = true) }
    fun closeTradeDialog() = _uiState.update { it.copy(showTradeDialog = false) }

    fun openCreateCompanyDialog() = _uiState.update { it.copy(showCreateCompanyDialog = true) }
    fun closeCreateCompanyDialog() = _uiState.update { it.copy(showCreateCompanyDialog = false) }

    fun executeTrade(
        instrumentId: String,
        type: TransactionType,
        quantity: Double,
        unitPrice: Double,
        useVaultKey: Boolean = false
    ) {
        val s = _uiState.value
        val inst = s.instruments.find { it.id == instrumentId } ?: return
        val key = if (useVaultKey) s.vaultKeys.firstOrNull { it.keyName.contains(inst.symbol, true) } ?: s.vaultKeys.firstOrNull() else null

        viewModelScope.launch {
            repository.executeTrade(
                entityId = s.selectedEntityId,
                instrument = inst,
                type = type,
                quantity = quantity,
                unitPrice = unitPrice,
                vaultSigningKey = key
            )
            val signed = key?.let { VaultKeyEngine.signExecution(it, inst.symbol, quantity, type.name) }
            _uiState.update {
                it.copy(
                    showTradeDialog = false,
                    latestSignedExecution = signed,
                    showVaultSignerDialog = signed != null
                )
            }
        }
    }

    fun createCompany(
        name: String,
        legalForm: String,
        currency: String,
        accountingBasis: String,
        initialCapital: Double,
        mandate: String
    ) {
        viewModelScope.launch {
            repository.createCompany(name, legalForm, currency, accountingBasis, initialCapital, mandate)
            _uiState.update { it.copy(showCreateCompanyDialog = false) }
        }
    }

    fun dismissVaultSignerDialog() = _uiState.update { it.copy(showVaultSignerDialog = false) }

    fun runLedgerReconciliation() {
        val s = _uiState.value
        val tb = s.trialBalance
        val bs = s.balanceSheet

        val msg = if ((tb?.isBalanced == true) && (bs?.isBalanced == true)) {
            "✓ AUDIT SUCCESS: Double-entry ledger balanced to $0.00 variance. All ${s.journals.size} journals immutable and validated."
        } else {
            "⚠ AUDIT WARNING: Variance detected in trial balance."
        }
        _uiState.update { it.copy(auditStatusMessage = msg) }
    }
}
