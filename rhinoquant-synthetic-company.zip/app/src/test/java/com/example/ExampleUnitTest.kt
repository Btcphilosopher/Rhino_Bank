package com.example

import com.example.domain.engine.AccountingEngine
import com.example.domain.engine.BlackScholes
import com.example.domain.engine.FixedIncomeEngine
import com.example.domain.engine.VaultKeyEngine
import com.example.domain.models.JournalEntry
import com.example.domain.models.Position
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs

class ExampleUnitTest {

    @Test
    fun testBlackScholesPutCallParity() {
        val spot = 100.0
        val strike = 100.0
        val time = 1.0
        val rate = 0.05
        val vol = 0.20

        val callGreeks = BlackScholes.calculate(spot, strike, time, rate, vol, isCall = true)
        val putGreeks = BlackScholes.calculate(spot, strike, time, rate, vol, isCall = false)

        // Put-Call Parity: C - P = S - K * exp(-r * T)
        val discountK = strike * kotlin.math.exp(-rate * time)
        val parityDiff = (callGreeks.price - putGreeks.price) - (spot - discountK)

        assertTrue("Put-Call Parity should hold within 0.05 tolerance", abs(parityDiff) < 0.05)
        assertTrue("Call Delta should be between 0 and 1", callGreeks.delta in 0.0..1.0)
        assertTrue("Put Delta should be between -1 and 0", putGreeks.delta in -1.0..0.0)
        assertTrue("Vega should be strictly positive", callGreeks.vega > 0.0)
        assertTrue("Gamma should be positive", callGreeks.gamma > 0.0)
    }

    @Test
    fun testFixedIncomeAnalytics() {
        val bond = FixedIncomeEngine.calculate(
            faceValue = 100.0,
            couponRate = 0.045,
            yearsToMaturity = 5.0,
            ytm = 0.045,
            frequency = 2,
            daysSinceCoupon = 45.0,
            daysInPeriod = 180.0
        )

        assertEquals("Clean price should be approximately 100 at par", 100.0, bond.cleanPrice, 0.5)
        assertEquals("Dirty price must equal clean price + accrued interest", bond.cleanPrice + bond.accruedInterest, bond.dirtyPrice, 0.001)
        assertTrue("Modified duration should be between 3 and 5 years", bond.modifiedDuration in 3.0..5.0)
        assertTrue("Convexity should be positive", bond.convexity > 0.0)
        assertTrue("DV01 should be positive", bond.dv01 > 0.0)
    }

    @Test
    fun testAccountingBalanceSheetInvariant() {
        val positions = listOf(
            Position("P1", "ENT1", "AAPL", 100.0, 150.0, 200.0, 20_000.0, 5_000.0),
            Position("P2", "ENT1", "BND", 100.0, 100.0, 100.0, 10_000.0, 0.0)
        )

        val (bs, pnl) = AccountingEngine.generateFinancialStatements(
            entityId = "ENT1",
            positions = positions,
            cashBalance = 70_000.0,
            bankDebt = 20_000.0,
            repoDebt = 10_000.0,
            initialCapital = 70_000.0
        )

        assertTrue("Balance sheet MUST balance: Assets == Liabilities + Equity", bs.isBalanced)
        assertEquals("Imbalance should be $0.00", 0.0, bs.imbalanceAmount, 0.01)
        assertEquals(bs.totalAssets, bs.totalLiabilities + bs.totalEquity, 0.01)
    }

    @Test
    fun testTrialBalanceDebitsEqualCredits() {
        val journals = listOf(
            JournalEntry("J1", "ENT1", description = "Capital Contribution", sourceEventId = "E1", debitAccountCode = "1000", debitAccountName = "Cash", creditAccountCode = "3000", creditAccountName = "Capital", amount = 1_000_000.0),
            JournalEntry("J2", "ENT1", description = "Stock Purchase", sourceEventId = "E2", debitAccountCode = "1100", debitAccountName = "Stock", creditAccountCode = "1000", creditAccountName = "Cash", amount = 400_000.0)
        )

        val tb = AccountingEngine.calculateTrialBalance(journals)
        assertTrue("Trial balance debits must equal credits", tb.isBalanced)
        assertEquals("Total debits must match total credits", tb.totalDebits, tb.totalCredits, 0.01)
        assertEquals("Variance must be zero", 0.0, tb.variance, 0.01)
    }

    @Test
    fun testVaultKeyGenerationAndSigning() {
        val key = VaultKeyEngine.generateVaultKey("ENT-RSH-001", "BTC")
        assertTrue("Bitcoin public address should start with bc1q", key.publicAddress.startsWith("bc1q"))
        assertEquals("Algorithm must be SECP256K1 / ECDSA", "SECP256K1 / ECDSA", key.algorithm)

        val signed = VaultKeyEngine.signExecution(key, "BTC-VAULT", 10.0, "BUY")
        assertNotNull(signed.transactionHash)
        assertNotNull(signed.signatureHex)
        assertTrue("Signature hex must start with ASN.1 DER sequence 3044", signed.signatureHex.startsWith("3044"))
        assertEquals("Verification status must be valid", "CRYPTOGRAPHICALLY_VERIFIED", signed.verificationStatus)
    }
}
