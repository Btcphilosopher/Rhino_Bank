import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

import { 
  generateHistoricalData, 
  calculateYMI, 
  calculatePCAWeights, 
  runSeasonalDecomposition, 
  calculateCorrelationMatrix, 
  generateForecast,
  getSectorPerformances,
  getBankingExposureData,
  SUBREGIONS,
  INDICATORS
} from "./server/simulation";
import { ForecastScenario, County } from "./src/types";

// Cached historical data
const HISTORICAL_DATA = generateHistoricalData();
const PCA_WEIGHTS_YORKSHIRE = calculatePCAWeights(HISTORICAL_DATA);
const CORRELATION_MATRIX = calculateCorrelationMatrix(HISTORICAL_DATA);

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === "MY_GEMINI_API_KEY") {
      console.log("GEMINI_API_KEY is not defined. The reporting engine will fall back to local rule-based generation.");
      return null;
    }
    try {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
      console.log("Successfully initialized Gemini client.");
    } catch (err) {
      console.error("Failed to initialize Gemini client:", err);
      return null;
    }
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser
  app.use(express.json({ limit: "5mb" }));

  // API Endpoints
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // 1. Metadata: counties, subregions, indicators, default config
  app.get("/api/metadata", (req, res) => {
    res.json({
      counties: Object.values(County),
      subregions: SUBREGIONS,
      indicators: INDICATORS,
      pcaWeights: PCA_WEIGHTS_YORKSHIRE
    });
  });

  // 2. Raw Historical Data (highly cached)
  app.get("/api/historical-data", (req, res) => {
    res.json(HISTORICAL_DATA);
  });

  // 3. Composite Index computation with custom weights
  app.post("/api/index/calculate", (req, res) => {
    try {
      const { weights, county } = req.body;
      const targetCounty = county || "Yorkshire-wide";
      
      if (!weights || typeof weights !== "object") {
        return res.status(400).json({ error: "Missing weights map in request body" });
      }

      // Calculate Custom Weighted Index
      const customIndex = calculateYMI(HISTORICAL_DATA, weights, targetCounty);
      
      // Calculate Equally Weighted Index (benchmark)
      const equalWeights: { [id: string]: number } = {};
      INDICATORS.forEach(ind => {
        equalWeights[ind.id] = 100 / INDICATORS.length;
      });
      const equalIndex = calculateYMI(HISTORICAL_DATA, equalWeights, targetCounty);

      // Calculate PCA-loaded Optimal Index (benchmark)
      const pcaWeightsMap: { [id: string]: number } = {};
      PCA_WEIGHTS_YORKSHIRE.forEach(p => {
        pcaWeightsMap[p.indicatorId] = p.loading;
      });
      const pcaIndex = calculateYMI(HISTORICAL_DATA, pcaWeightsMap, targetCounty);

      // Perform seasonal decomposition on the Custom Weighted index
      const decomposition = runSeasonalDecomposition(HISTORICAL_DATA, customIndex);

      res.json({
        county: targetCounty,
        customIndex,
        equalIndex,
        pcaIndex,
        decomposition,
        correlationMatrix: CORRELATION_MATRIX
      });
    } catch (error: any) {
      console.error("Index calculation failed:", error);
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  // 4. Forecast engine
  app.post("/api/forecast", (req, res) => {
    try {
      const { ymiPoints, scenario } = req.body;
      if (!ymiPoints || !Array.isArray(ymiPoints)) {
        return res.status(400).json({ error: "Missing ymiPoints array" });
      }
      
      const selectedScenario = scenario || ForecastScenario.BASELINE;
      const forecastTimeline = generateForecast(ymiPoints, selectedScenario, 24);

      res.json({
        scenario: selectedScenario,
        timeline: forecastTimeline
      });
    } catch (error: any) {
      console.error("Forecast failed:", error);
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  // 5. Sectors and Banking Portfolio Data
  app.get("/api/banking-and-sectors", (req, res) => {
    res.json({
      sectors: getSectorPerformances(),
      bankingExposure: getBankingExposureData()
    });
  });

  // 6. AI Generative Econometric Report writer (using gemini-3.6-flash)
  app.post("/api/report/generate", async (req, res) => {
    const { 
      title, 
      author, 
      county, 
      weights, 
      scenario, 
      currentYmiValue, 
      forecastYmiValue, 
      subregionsSummary 
    } = req.body;

    const targetTitle = title || "Yorkshire Manufacturing Index Monthly Intelligence Report";
    const targetAuthor = author || "RhinoQuant Economic Intelligence Desk";
    const targetCounty = county || "Yorkshire-wide";
    const activeScenario = scenario || ForecastScenario.BASELINE;

    // Create fallbacks if Gemini fails or is missing
    const getFallbackReport = () => {
      const dateStr = new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long" });
      const trendDir = currentYmiValue > 100 ? "expansionary cycle" : "contractionary cycle";
      const forecastDir = forecastYmiValue > currentYmiValue ? "expansionary trajectory" : "downward correction";

      return {
        id: `rep_${Date.now()}`,
        title: targetTitle,
        date: dateStr,
        author: targetAuthor,
        executiveSummary: `This report offers a quantitative macro-econometric review of the Yorkshire and Humber manufacturing sector for ${dateStr}. Currently, the composite Yorkshire Manufacturing Index (YMI) stands at ${currentYmiValue} (normalized base 100 in 2018), reflecting an active ${trendDir}. This state is primarily governed by regional structural weights across industrial subregions including Leeds, Sheffield, and Hull.`,
        economicOutlook: `Applying our Autoregressive Forecasting model with a 24-month horizon under the '${activeScenario}' scenario, the index is projected to reach ${forecastYmiValue} by 2028. This represents a ${forecastDir}. Key triggers for this forecast include shifting supply chain bottlenecks, capital investment indexes, and energy-consumption indices across major counties.`,
        riskAssessment: `Portfolio exposure at Rhino Bank highlights localized credit sensitivities within chemical refining and metal casting sub-sectors. Rising energy costs represent a high-priority risk factor. Structural breaks are evident in the historical database, particularly around capital expenditure triggers and logistics indexes.`,
        creditRecommendations: `We advise the Rhino Bank Credit Committee to adopt a selective credit expansion policy. High-performing green advanced manufacturing structures in South Yorkshire (Sheffield/Rotherham AMRC corridor) should receive priority capital allocation, while refinancing facilities for carbon-intensive polymer and chemical processing clusters in the Humber Corridor should require elevated stress-testing margins.`,
        htmlContent: `
          <div class="space-y-4 text-slate-300">
            <h4 class="text-lg font-bold text-amber-500">1. Macro-Econometric Positioning</h4>
            <p>The composite Yorkshire Manufacturing Index (YMI) registered a value of <strong>${currentYmiValue}</strong>, indicating resilient capacity utilization and strong factory floor logistics output. Subregional data highlights extreme industrial clustering, particularly in advanced aerostructures and advanced mechanical engineering.</p>
            <h4 class="text-lg font-bold text-amber-500">2. Econometric Scenario Modeling</h4>
            <p>Our quantitative forecasting model projects the index moving to <strong>${forecastYmiValue}</strong> over the next 24 months under the <em>${activeScenario}</em> scenario. This scenario encapsulates supply-chain logistics metrics and industrial credit lending parameters.</p>
            <h4 class="text-lg font-bold text-amber-500">3. Credit Risk and Capital Allocation Recommendations</h4>
            <p>Based on our sector concentration calculations, Rhino Bank's commercial portfolio shows a concentration in heavy steel castings and automotive precision forgings. We suggest tightening debt-service-coverage ratios (DSCR) for carbon-intensive lines while offering capital bonuses for zero-carbon logistics grids.</p>
          </div>
        `
      };
    };

    const client = getGeminiClient();
    if (!client) {
      return res.json(getFallbackReport());
    }

    try {
      const dateStr = new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long" });
      const prompt = `
        You are a distinguished Senior Manufacturing Economist, Econometrician, and Quantitative Credit Analyst at Rhino Bank.
        Draft an elite, executive-level Economic Intelligence Bulletin on the Yorkshire & Humber manufacturing economy.

        --- PARAMETRIC DATA INPUTS ---
        Report Title: ${targetTitle}
        Economic Region: ${targetCounty}
        Author: ${targetAuthor}
        Current Date: ${dateStr}
        Current Yorkshire Manufacturing Index (YMI) Value: ${currentYmiValue} (Base: 100 in Jan 2018)
        24-Month Forecasted YMI Value: ${forecastYmiValue}
        Active Forecasting Scenario: ${activeScenario}
        Configured Indicator Weights: ${JSON.stringify(weights)}
        Regional Subregion Context: ${JSON.stringify(subregionsSummary)}
        --------------------------------

        Write a sophisticated, statistically rigorous briefing. Avoid any friendly AI chatter or generic phrases (such as "supercharge" or "delve"). Keep the tone formal, highly academic, and precise.

        Return your output in strict JSON format matching this schema:
        {
          "id": "rep_generated",
          "title": "${targetTitle}",
          "date": "${dateStr}",
          "author": "${targetAuthor}",
          "executiveSummary": "A concise executive summary paragraph detailing the macro index state and key industrial takeaways.",
          "economicOutlook": "An econometric forecasting outlook paragraph describing the 24-month scenario projections and macroeconomic drivers.",
          "riskAssessment": "An industrial and credit risk assessment paragraph evaluating capital expenditure trends and regional concentration risks.",
          "creditRecommendations": "A credit and lending guidelines paragraph with clear capital instructions for Rhino Bank's lending committee.",
          "htmlContent": "An elegant HTML string (enclosed in a single <div> element, containing tags like <h4>, <p>, <ul>, and <li>) that expands upon the econometric trends, subregional hotspots, and sector PMIs in granular detail, formatted nicely for an academic research dashboard."
        }
      `;

      const response = await client.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });

      const responseText = response.text?.trim();
      if (!responseText) {
        throw new Error("Empty response from Gemini");
      }

      const generatedJSON = JSON.parse(responseText);
      // Ensure id is unique
      generatedJSON.id = `rep_${Date.now()}`;
      res.json(generatedJSON);

    } catch (err) {
      console.error("Gemini report generation failed, falling back:", err);
      res.json(getFallbackReport());
    }
  });

  // Serve Vite app or Static files
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RhinoQuant Server running on http://localhost:${PORT} in ${process.env.NODE_ENV || "development"} mode.`);
  });
}

startServer();
