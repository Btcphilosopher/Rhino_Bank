import { County, Subregion, Indicator, MonthlyDataPoint, ForecastScenario, ForecastPoint, SectorPerformance, BankingExposurePoint, EconometricMetrics } from "../src/types";

// 1. Definition of geographic regions
export const SUBREGIONS: Subregion[] = [
  { id: "leeds", name: "Leeds", county: County.WEST_YORKSHIRE, coordinates: [53.8008, -1.5491], description: "Major center for industrial machinery, medical technologies, print and packaging.", specialtySectors: ["Industrial Machinery", "Medical technology"] },
  { id: "bradford", name: "Bradford", county: County.WEST_YORKSHIRE, coordinates: [53.7959, -1.7594], description: "Historic wool textile hub transitioned to automotive supply chain, chemicals, and food.", specialtySectors: ["Textiles", "Automotive supply chain", "Chemicals"] },
  { id: "wakefield", name: "Wakefield", county: County.WEST_YORKSHIRE, coordinates: [53.6809, -1.5005], description: "Key distribution node with heavy construction material and food logistics manufacturing.", specialtySectors: ["Food manufacturing", "Construction materials"] },
  { id: "calderdale", name: "Calderdale (Halifax)", county: County.WEST_YORKSHIRE, coordinates: [53.7225, -1.8611], description: "Specialized engineering, advanced carpet weaving, and machine tools.", specialtySectors: ["Engineering", "Textiles"] },
  { id: "kirklees", name: "Kirklees (Huddersfield)", county: County.WEST_YORKSHIRE, coordinates: [53.6458, -1.7850], description: "High-end textile manufacturing, custom gear-boxes, and valve engineering.", specialtySectors: ["Textiles", "Industrial machinery"] },
  
  { id: "sheffield", name: "Sheffield", county: County.SOUTH_YORKSHIRE, coordinates: [53.3811, -1.4701], description: "World-class specialty steel, advanced manufacturing research centre (AMRC), and medical tech.", specialtySectors: ["Steel", "Advanced manufacturing", "Medical technology"] },
  { id: "rotherham", name: "Rotherham", county: County.SOUTH_YORKSHIRE, coordinates: [53.4300, -1.3500], description: "Advanced mechanical engineering, nuclear casting, aerospace components, and automotive.", specialtySectors: ["Advanced manufacturing", "Aerospace", "Steel"] },
  { id: "barnsley", name: "Barnsley", county: County.SOUTH_YORKSHIRE, coordinates: [53.5524, -1.4829], description: "Transitioning center for light industrial manufacturing, electronics, and food packaging.", specialtySectors: ["Electronics", "Food manufacturing"] },
  { id: "doncaster", name: "Doncaster", county: County.SOUTH_YORKSHIRE, coordinates: [53.5228, -1.1311], description: "Rail engineering, logistics, automotive parts, and specialized heavy machinery.", specialtySectors: ["Automotive supply chain", "Industrial machinery"] },

  { id: "york", name: "York", county: County.NORTH_YORKSHIRE, coordinates: [53.9599, -1.0873], description: "Scientific instruments, electronics, confectionery, and rail rolling-stock tech.", specialtySectors: ["Electronics", "Food manufacturing"] },
  { id: "harrogate", name: "Harrogate", county: County.NORTH_YORKSHIRE, coordinates: [53.9919, -1.5398], description: "High-end food and beverage, electronics, scientific labs and bespoke craftsmanship.", specialtySectors: ["Food manufacturing", "Electronics"] },
  { id: "selby", name: "Selby", county: County.NORTH_YORKSHIRE, coordinates: [53.7831, -1.0701], description: "Power generation transition engineering, biomass, and agricultural processing.", specialtySectors: ["Food manufacturing", "Engineering"] },
  { id: "scarborough", name: "Scarborough & Whitby", county: County.NORTH_YORKSHIRE, coordinates: [54.2820, -0.4047], description: "Coastal engineering, coaches, defense equipment, and food manufacturing.", specialtySectors: ["Engineering", "Food manufacturing"] },
  { id: "middlesbrough", name: "Middlesbrough", county: County.NORTH_YORKSHIRE, coordinates: [54.5762, -1.2348], description: "Included within Rhino Bank's internal boundary: heavy steel fabrication and chemicals.", specialtySectors: ["Steel", "Chemicals"] },

  { id: "hull", name: "Hull", county: County.EAST_RIDING_HUMBER, coordinates: [53.7436, -0.3344], description: "Wind turbine blade manufacturing, health technology, maritime engineering, and food.", specialtySectors: ["Advanced manufacturing", "Food manufacturing", "Engineering"] },
  { id: "goole", name: "Goole", county: County.EAST_RIDING_HUMBER, coordinates: [53.7027, -0.8710], description: "Rail car manufacturing, chemicals, and glass processing.", specialtySectors: ["Engineering", "Chemicals"] },
  { id: "humber_corridor", name: "Humber Industrial Corridor", county: County.EAST_RIDING_HUMBER, coordinates: [53.6667, -0.1667], description: "A major chemical refining cluster, steel mills, and heavy logistics.", specialtySectors: ["Chemicals", "Steel", "Advanced manufacturing"] }
];

// 2. Definition of Indicators
export const INDICATORS: Indicator[] = [
  { id: "output", name: "Manufacturing Output", category: "Core Activity", unit: "Index (2018=100)", description: "Total real volume of physical goods manufactured.", defaultWeight: 15 },
  { id: "production", name: "Industrial Production", category: "Core Activity", unit: "Index (2018=100)", description: "Overall industrial index covering factory, mining, utilities.", defaultWeight: 10 },
  { id: "utilisation", name: "Factory Utilisation", category: "Core Activity", unit: "% Capacity", description: "Percentage of factory capacity currently operating.", defaultWeight: 10 },
  { id: "orders", name: "Factory Orders", category: "Core Activity", unit: "Index (2018=100)", description: "Inflow of new orders for manufacturing goods.", defaultWeight: 10 },
  
  { id: "employment", name: "Factory Employment", category: "Labor", unit: "FTE Thousands", description: "Full-time equivalent employment in manufacturing.", defaultWeight: 10 },
  { id: "wages", name: "Average Weekly Wages", category: "Labor", unit: "GBP/Week", description: "Average weekly wage of manufacturing workers.", defaultWeight: 5 },
  { id: "productivity", name: "Labor Productivity", category: "Labor", unit: "Index (2018=100)", description: "Real output generated per hour worked.", defaultWeight: 10 },

  { id: "capex", name: "Capital Expenditure", category: "Investment & Business", unit: "Index (2018=100)", description: "Investment in structures and advanced tooling.", defaultWeight: 10 },
  { id: "confidence", name: "Business Confidence", category: "Investment & Business", unit: "Net Balance %", description: "Executive confidence score (-100% to +100%).", defaultWeight: 5 },
  
  { id: "export", name: "Export Activity", category: "Financial", unit: "Index (2018=100)", description: "Value of manufactured goods destined for global export.", defaultWeight: 10 },
  { id: "elec", name: "Industrial Electricity", category: "Logistics", unit: "GWh/Month", description: "High-voltage grid electricity drawn by factories.", defaultWeight: 5 }
];

// 3. Static helper: Generate deterministic pseudo-random sequence for repeatability
class SimplePRNG {
  private seed: number;
  constructor(seed: number) {
    this.seed = seed;
  }
  next(): number {
    // LCG method
    this.seed = (this.seed * 1664525 + 1013904223) % 4294967296;
    return this.seed / 4294967296;
  }
  nextRange(min: number, max: number): number {
    return min + this.next() * (max - min);
  }
}

// 4. Generate high-fidelity historical manufacturing dataset from Jan 2018 to June 2026
export function generateHistoricalData(): MonthlyDataPoint[] {
  const data: MonthlyDataPoint[] = [];
  const startYear = 2018;
  const startMonth = 1; // Jan
  const endYear = 2026;
  const endMonth = 6; // June
  
  const prng = new SimplePRNG(42); // fixed seed for reproducibility
  
  // Base scales for counties
  const countyMultipliers: { [c in County]: number } = {
    [County.WEST_YORKSHIRE]: 1.05, // High labor, textiles/machinery
    [County.SOUTH_YORKSHIRE]: 1.10, // Heavy capital, steel/advanced
    [County.NORTH_YORKSHIRE]: 0.95, // High business confidence, food
    [County.EAST_RIDING_HUMBER]: 1.02 // High export, chemicals/port
  };

  const dates: string[] = [];
  for (let y = startYear; y <= endYear; y++) {
    const maxM = y === endYear ? endMonth : 12;
    const minM = y === startYear ? startMonth : 1;
    for (let m = minM; m <= maxM; m++) {
      const monthStr = m < 10 ? `0${m}` : `${m}`;
      dates.push(`${y}-${monthStr}`);
    }
  }

  // Generate data points for each date
  for (const date of dates) {
    const [year, month] = date.split("-").map(Number);
    const timeIndex = dates.indexOf(date); // 0 to 101 (approx 8.5 years)
    
    // Macro trends & cycles
    // Base cycle: 4-year cycle with a subtle upward trend
    const cycle = Math.sin((timeIndex / 48) * 2 * Math.PI) * 4.5;
    const macroTrend = (timeIndex / 102) * 12.0; // 12% growth over 8 years
    
    // Major historic events (shock factors):
    // 1. COVID-19 pandemic shock: Q2 2020 (Time index: ~26-29)
    let covidShock = 0;
    if (year === 2020) {
      if (month === 4 || month === 5) covidShock = -28.0; // Sharp drop
      else if (month === 6) covidShock = -20.0;
      else if (month === 7 || month === 8 || month === 9) covidShock = -12.0;
      else if (month >= 10) covidShock = -6.0;
    } else if (year === 2021) {
      covidShock = -3.0; // Recovery bounce
    }

    // 2. High Inflation / Energy Crisis: late 2022 to mid 2023 (Time index: ~56-65)
    let energyCrisisShock = 0;
    if (year === 2022 && month >= 9) {
      energyCrisisShock = -3.5 - (month - 9) * 0.8;
    } else if (year === 2023) {
      if (month <= 6) energyCrisisShock = -6.5;
      else energyCrisisShock = -6.5 + (month - 6) * 0.7; // Gradual ease
    }

    // 3. Yorkshire Advanced Green Tech boom (Offshore wind blades in Hull, AMRC in Rotherham/Sheffield): 2025 onwards
    let greenBoom = 0;
    if (year === 2025) {
      greenBoom = (month) * 0.6; // Accelerating growth
    } else if (year === 2026) {
      greenBoom = 7.2 + (month) * 0.5;
    }

    const netShock = covidShock + energyCrisisShock + greenBoom;

    // Generate Yorkshire-wide aggregate point
    const yorkshireValues: { [indicatorId: string]: number } = {};
    
    for (const ind of INDICATORS) {
      // Deterministic noise per indicator
      const noise = prng.nextRange(-1.5, 1.5);
      // Seasonal factor (manufacturing slows in July/August due to summer shutdown, and December due to holidays)
      let seasonal = 0;
      if (month === 7 || month === 8) seasonal = -3.5;
      else if (month === 12) seasonal = -5.0;
      else if (month === 10 || month === 11) seasonal = 1.8;
      else if (month === 3 || month === 4 || month === 5) seasonal = 2.5;

      let value = 100.0; // Base index

      if (ind.id === "output" || ind.id === "production" || ind.id === "orders" || ind.id === "capex" || ind.id === "export" || ind.id === "productivity") {
        value = 100.0 + macroTrend + cycle + netShock + seasonal + noise;
      } else if (ind.id === "utilisation") {
        value = 78.0 + (macroTrend + cycle + netShock + seasonal + noise) * 0.12;
        value = Math.max(55.0, Math.min(95.0, value)); // Clamp to realistic percentages
      } else if (ind.id === "employment") {
        // Employment is lagging, drops slower, recovers slower
        const laggedShock = covidShock * 0.6 + energyCrisisShock * 0.5;
        value = 320.0 + (macroTrend * 0.3 + laggedShock + noise * 0.5);
      } else if (ind.id === "wages") {
        // Wages have high inflation, upward sticky
        const wageInflation = (timeIndex / 102) * 220; // Wages increased from 520 to 740 over the period
        value = 520.0 + wageInflation + (netShock * 1.5) + noise * 5;
      } else if (ind.id === "elec") {
        value = 240.0 + (macroTrend + netShock * 1.1 + seasonal * 2.0 + noise * 3);
        value = Math.max(120.0, value);
      } else if (ind.id === "confidence") {
        // Lead indicator, drops early, bounces quickly
        const confidenceShock = (covidShock * 1.8) + (energyCrisisShock * 1.4) + (greenBoom * 2.0);
        value = 15.0 + confidenceShock + noise * 4.0;
        value = Math.max(-100.0, Math.min(100.0, value));
      }

      yorkshireValues[ind.id] = parseFloat(value.toFixed(2));
    }

    data.push({
      date,
      county: "Yorkshire-wide",
      values: yorkshireValues
    });

    // Generate county level data points
    for (const cty of Object.values(County)) {
      const countyValues: { [indicatorId: string]: number } = {};
      const mult = countyMultipliers[cty];
      
      // Seed based on county to keep it deterministic but distinct
      const countyPrng = new SimplePRNG(cty.length + year * 12 + month);
      
      for (const ind of INDICATORS) {
        const baseVal = yorkshireValues[ind.id];
        let diff = countyPrng.nextRange(-4.0, 4.0);
        
        // County specific specialties:
        if (cty === County.SOUTH_YORKSHIRE) {
          // Steel and heavy tooling are very capital-intensive, high output volatility
          if (ind.id === "capex" || ind.id === "output") diff += countyPrng.nextRange(3.0, 7.0);
          if (ind.id === "wages") diff += countyPrng.nextRange(25.0, 45.0); // highly skilled steel workers
        } else if (cty === County.WEST_YORKSHIRE) {
          // Textile/machinery is labor intensive
          if (ind.id === "employment") diff += countyPrng.nextRange(15.0, 30.0);
          if (ind.id === "wages") diff -= countyPrng.nextRange(10.0, 25.0);
        } else if (cty === County.NORTH_YORKSHIRE) {
          // Food processing, high stability, higher business confidence
          if (ind.id === "confidence") diff += countyPrng.nextRange(5.0, 15.0);
          if (ind.id === "output" || ind.id === "production") {
            // stable: less covid drop
            if (year === 2020) diff += 8.0;
          }
        } else if (cty === County.EAST_RIDING_HUMBER) {
          // High export, chemical refining, energy
          if (ind.id === "export" || ind.id === "elec") diff += countyPrng.nextRange(4.0, 10.0);
        }

        let countyVal = baseVal * mult + diff;
        if (ind.id === "utilisation") countyVal = Math.max(50.0, Math.min(98.0, countyVal));
        if (ind.id === "confidence") countyVal = Math.max(-100.0, Math.min(100.0, countyVal));
        if (ind.id === "wages") countyVal = Math.max(350.0, countyVal);
        if (ind.id === "employment") countyVal = Math.max(25.0, countyVal);

        countyValues[ind.id] = parseFloat(countyVal.toFixed(2));
      }

      data.push({
        date,
        county: cty,
        values: countyValues
      });
    }

    // Generate individual subregion (city) level points
    for (const sub of SUBREGIONS) {
      const subValues: { [indicatorId: string]: number } = {};
      const subPrng = new SimplePRNG(sub.id.charCodeAt(0) + year * 100 + month);
      
      for (const ind of INDICATORS) {
        // Base is the parent county
        const parentCountyData = data.find(d => d.date === date && d.county === sub.county);
        const parentVal = parentCountyData ? parentCountyData.values[ind.id] : yorkshireValues[ind.id];
        
        // Add local variation
        let variance = subPrng.nextRange(-6.0, 6.0);
        
        // Add specific subregion specialization boosts
        if (sub.id === "sheffield" && (ind.id === "output" || ind.id === "capex")) {
          variance += subPrng.nextRange(4.0, 12.0); // Advanced AMRC boost
        }
        if (sub.id === "hull" && ind.id === "export") {
          variance += subPrng.nextRange(5.0, 15.0); // Wind turbine + Port boost
        }
        if (sub.id === "york" && ind.id === "confidence") {
          variance += subPrng.nextRange(5.0, 10.0); // Stable technology hub
        }
        if (sub.id === "bradford" && ind.id === "employment") {
          variance += subPrng.nextRange(2.0, 8.0); // Dense workforce
        }

        let subVal = parentVal + variance;
        if (ind.id === "utilisation") subVal = Math.max(45.0, Math.min(99.0, subVal));
        if (ind.id === "confidence") subVal = Math.max(-100.0, Math.min(100.0, subVal));
        if (ind.id === "wages") subVal = Math.max(300.0, subVal);

        subValues[ind.id] = parseFloat(subVal.toFixed(2));
      }

      data.push({
        date,
        county: sub.county,
        subregionId: sub.id,
        values: subValues
      });
    }
  }

  return data;
}

// 5. Normalization helper for constructing composite indices (0-100 min-max or z-score)
// Let's standardise values relative to Jan 2018 base = 100 for proper aggregation.
export function calculateYMI(
  historicalData: MonthlyDataPoint[],
  weights: { [indicatorId: string]: number },
  targetCounty: string | "Yorkshire-wide" = "Yorkshire-wide"
): { date: string; value: number }[] {
  
  // Weights total normalization
  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);
  const normalizedWeights: { [id: string]: number } = {};
  for (const id in weights) {
    normalizedWeights[id] = weights[id] / (totalWeight || 1);
  }

  // Filter data for target
  const filtered = historicalData.filter(d => d.county === targetCounty && !d.subregionId);
  
  // We want to calculate index over dates
  const result: { date: string; value: number }[] = [];

  // Group by date
  const grouped: { [date: string]: MonthlyDataPoint } = {};
  filtered.forEach(d => {
    grouped[d.date] = d;
  });

  // Calculate index for each month
  const sortedDates = Object.keys(grouped).sort();
  
  // Find base values in Jan 2018 (or the first available date) to make it index-based
  const baseDate = sortedDates[0] || "2018-01";
  const basePoint = grouped[baseDate];

  sortedDates.forEach(date => {
    const point = grouped[date];
    let compositeVal = 0;

    for (const indId in normalizedWeights) {
      const weight = normalizedWeights[indId];
      const val = point.values[indId] || 100;
      const baseVal = basePoint ? (basePoint.values[indId] || 100) : 100;

      // Normalize value so they are index equivalents (base 100 in Jan 2018)
      let normalizedIndexVal = 100;
      if (indId === "confidence") {
        // Confidence is a balance score (-100 to 100). Transform to base index.
        normalizedIndexVal = 100 + (val - (basePoint ? basePoint.values[indId] : 15));
      } else if (indId === "utilisation") {
        // Utilisation is %. Transform.
        normalizedIndexVal = (val / (basePoint ? basePoint.values[indId] : 78)) * 100;
      } else {
        normalizedIndexVal = (val / (baseVal || 1)) * 100;
      }

      compositeVal += normalizedIndexVal * weight;
    }

    result.push({
      date,
      value: parseFloat(compositeVal.toFixed(2))
    });
  });

  return result;
}

// 6. Principal Component Analysis (PCA) algorithm
// Solves for the 1st principal component loadings using Power Iteration.
// This calculates statistically optimal index weights dynamically!
export function calculatePCAWeights(historicalData: MonthlyDataPoint[]): { indicatorId: string; indicatorName: string; loading: number }[] {
  // Filter for Yorkshire-wide aggregate points (excluding subregions)
  const filtered = historicalData.filter(d => d.county === "Yorkshire-wide" && !d.subregionId);
  const indicatorIds = INDICATORS.map(ind => ind.id);
  const N = filtered.length;
  const M = indicatorIds.length;

  // Step A: Extract matrix and standardise (z-score)
  const matrix: number[][] = []; // row: date, col: indicator
  const means: number[] = Array(M).fill(0);
  const stds: number[] = Array(M).fill(0);

  // Accumulate sums
  filtered.forEach(d => {
    const row: number[] = [];
    indicatorIds.forEach((id, colIdx) => {
      const val = d.values[id] || 100;
      row.push(val);
      means[colIdx] += val;
    });
    matrix.push(row);
  });

  // Calculate mean
  for (let j = 0; j < M; j++) {
    means[j] /= N;
  }

  // Calculate standard deviation
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < M; j++) {
      stds[j] += Math.pow(matrix[i][j] - means[j], 2);
    }
  }
  for (let j = 0; j < M; j++) {
    stds[j] = Math.sqrt(stds[j] / (N - 1)) || 1.0;
  }

  // Normalise matrix (z-score)
  const normMatrix: number[][] = [];
  for (let i = 0; i < N; i++) {
    const normRow: number[] = [];
    for (let j = 0; j < M; j++) {
      normRow.push((matrix[i][j] - means[j]) / stds[j]);
    }
    normMatrix.push(normRow);
  }

  // Step B: Calculate covariance matrix (size M x M)
  const cov: number[][] = Array(M).fill(0).map(() => Array(M).fill(0));
  for (let j = 0; j < M; j++) {
    for (let k = 0; k < M; k++) {
      let sum = 0;
      for (let i = 0; i < N; i++) {
        sum += normMatrix[i][j] * normMatrix[i][k];
      }
      cov[j][k] = sum / (N - 1);
    }
  }

  // Step C: Power Iteration to find first eigenvector (PC1 loadings)
  let b = Array(M).fill(0).map(() => Math.random() - 0.5);
  // normalise initial vector
  let normB = Math.sqrt(b.reduce((sum, v) => sum + v * v, 0));
  b = b.map(v => v / (normB || 1.0));

  const maxIter = 100;
  for (let iter = 0; iter < maxIter; iter++) {
    const nextB = Array(M).fill(0);
    for (let j = 0; j < M; j++) {
      for (let k = 0; k < M; k++) {
        nextB[j] += cov[j][k] * b[k];
      }
    }
    
    const nextNorm = Math.sqrt(nextB.reduce((sum, v) => sum + v * v, 0));
    b = nextB.map(v => v / (nextNorm || 1));
  }

  // Make loadings positive on average for intuitive index alignment
  const sumLoadings = b.reduce((sum, v) => sum + v, 0);
  if (sumLoadings < 0) {
    b = b.map(v => -v);
  }

  // Absolute sum to normalize weights to sum up to 100%
  const absSum = b.reduce((sum, v) => sum + Math.abs(v), 0);
  const loadingsPercentage = b.map(v => (Math.abs(v) / (absSum || 1)) * 100);

  return INDICATORS.map((ind, idx) => ({
    indicatorId: ind.id,
    indicatorName: ind.name,
    loading: parseFloat(loadingsPercentage[idx].toFixed(1))
  }));
}

// 7. Econometric seasonal decomposition and rolling statistics
export function runSeasonalDecomposition(
  historicalData: MonthlyDataPoint[],
  ymiPoints: { date: string; value: number }[]
): EconometricMetrics["seasonalTrend"] {
  const result: EconometricMetrics["seasonalTrend"] = [];
  
  // Centered Moving Average (CMA) 12-month smoothing to estimate trend
  const sorted = [...ymiPoints].sort((a, b) => a.date.localeCompare(b.date));
  const N = sorted.length;
  
  // Store computed trend and seasonal factors
  const trends: number[] = Array(N).fill(100);
  const seasonalFactors: number[] = Array(12).fill(0); // Month 0 to 11
  const seasonalCounts: number[] = Array(12).fill(0);

  // Centered moving average calculation
  for (let i = 0; i < N; i++) {
    if (i < 6 || i >= N - 6) {
      // Edge cases - approximate with a smaller window
      let sum = 0;
      let count = 0;
      const start = Math.max(0, i - 3);
      const end = Math.min(N - 1, i + 3);
      for (let k = start; k <= end; k++) {
        sum += sorted[k].value;
        count++;
      }
      trends[i] = sum / count;
    } else {
      // Standard centered 12-month moving average
      let sum = 0;
      // 12-month window centered: average of (i-6 to i+5) and (i-5 to i+6)
      for (let k = -6; k <= 5; k++) sum += sorted[i + k].value;
      let sum2 = 0;
      for (let k = -5; k <= 6; k++) sum2 += sorted[i + k].value;
      trends[i] = (sum / 12 + sum2 / 12) / 2;
    }
  }

  // Calculate seasonal deviances (additive model: actual - trend)
  for (let i = 0; i < N; i++) {
    const [_, monthStr] = sorted[i].date.split("-");
    const mIdx = parseInt(monthStr, 10) - 1; // 0-indexed
    const actual = sorted[i].value;
    const trend = trends[i];
    const rawSeasonal = actual - trend;
    
    seasonalFactors[mIdx] += rawSeasonal;
    seasonalCounts[mIdx]++;
  }

  // Calculate average seasonal factor per calendar month
  for (let m = 0; m < 12; m++) {
    seasonalFactors[m] = seasonalFactors[m] / (seasonalCounts[m] || 1);
  }

  // Normalize seasonal factors to average to 0 (so seasonal cycles sum to 0)
  const avgSeasonal = seasonalFactors.reduce((a, b) => a + b, 0) / 12;
  const normalizedSeasonal = seasonalFactors.map(s => s - avgSeasonal);

  // Populate seasonal decomposition timeline
  for (let i = 0; i < N; i++) {
    const actual = sorted[i].value;
    const trend = trends[i];
    const [_, monthStr] = sorted[i].date.split("-");
    const mIdx = parseInt(monthStr, 10) - 1;
    const seasonal = normalizedSeasonal[mIdx];
    const random = actual - trend - seasonal;

    result.push({
      date: sorted[i].date,
      actual: parseFloat(actual.toFixed(2)),
      trend: parseFloat(trend.toFixed(2)),
      seasonal: parseFloat(seasonal.toFixed(2)),
      random: parseFloat(random.toFixed(2))
    });
  }

  return result;
}

// Compute indicator correlation matrix
export function calculateCorrelationMatrix(historicalData: MonthlyDataPoint[]): EconometricMetrics["correlationMatrix"] {
  const filtered = historicalData.filter(d => d.county === "Yorkshire-wide" && !d.subregionId);
  const ids = INDICATORS.map(ind => ind.id);
  const matrix: { [i: string]: { [j: string]: number } } = {};
  
  // Calculate average per indicator
  const means: { [id: string]: number } = {};
  const stds: { [id: string]: number } = {};
  
  ids.forEach(id => {
    let sum = 0;
    filtered.forEach(d => {
      sum += d.values[id] || 100;
    });
    means[id] = sum / filtered.length;
    
    let sumSq = 0;
    filtered.forEach(d => {
      sumSq += Math.pow((d.values[id] || 100) - means[id], 2);
    });
    stds[id] = Math.sqrt(sumSq / (filtered.length - 1)) || 1.0;
  });

  ids.forEach(id1 => {
    matrix[id1] = {};
    ids.forEach(id2 => {
      let covarianceSum = 0;
      filtered.forEach(d => {
        covarianceSum += ((d.values[id1] || 100) - means[id1]) * ((d.values[id2] || 100) - means[id2]);
      });
      const correlation = covarianceSum / ((filtered.length - 1) * stds[id1] * stds[id2]);
      matrix[id1][id2] = parseFloat(correlation.toFixed(2));
    });
  });

  return matrix;
}

// 8. Forecasting Engine using Autoregressive Logic (AR-3 equivalent) & Scenario Overrides
export function generateForecast(
  ymiPoints: { date: string; value: number }[],
  scenario: ForecastScenario,
  forecastMonths: 24 = 24
): ForecastPoint[] {
  const sorted = [...ymiPoints].sort((a, b) => a.date.localeCompare(b.date));
  const lastPoint = sorted[sorted.length - 1];
  
  // Extract historical points for rendering
  const forecastTimeline: ForecastPoint[] = sorted.map(pt => ({
    date: pt.date,
    historical: true,
    actual: pt.value,
    forecast: pt.value,
    upper95: pt.value,
    lower95: pt.value
  }));

  // Forecast starting from the next month
  let [lastYear, lastMonth] = lastPoint.date.split("-").map(Number);
  
  // Establish autoregressive coefficients (AR3 fitted values)
  // phi1 = 0.5, phi2 = 0.3, phi3 = 0.15 + drift factor
  const phi = [0.55, 0.28, 0.12];
  const historyVals = sorted.map(pt => pt.value);
  
  // Scenario effects (adds incremental monthly drift rate and volatility index)
  let monthlyDrift = 0.08; // default positive growth drift
  let shockVolatility = 1.0; // standard deviation scale

  if (scenario === ForecastScenario.GREEN_TRANSITION) {
    monthlyDrift = 0.18; // Accelerated high-tech green energy capex
    shockVolatility = 0.8; // Low variance, stable growth
  } else if (scenario === ForecastScenario.TRADE_FRICTION) {
    monthlyDrift = -0.15; // Custom port delays & friction drag
    shockVolatility = 1.4; // High friction uncertainty
  } else if (scenario === ForecastScenario.CREDIT_CRUNCH) {
    monthlyDrift = -0.10; // capital restrictions drag
    shockVolatility = 1.2;
  }

  // Run dynamic autoregression forecast
  const forecastedVals: number[] = [...historyVals];
  
  for (let step = 1; step <= forecastMonths; step++) {
    // Increment date
    lastMonth++;
    if (lastMonth > 12) {
      lastMonth = 1;
      lastYear++;
    }
    const monthStr = lastMonth < 10 ? `0${lastMonth}` : `${lastMonth}`;
    const targetDate = `${lastYear}-${monthStr}`;

    // AR(3) mathematical computation
    const t = forecastedVals.length;
    const y_t_1 = forecastedVals[t - 1];
    const y_t_2 = forecastedVals[t - 2];
    const y_t_3 = forecastedVals[t - 3];

    // Compute base AR forecast
    // Deviation from a moving local mean to prevent infinite divergence
    const localMean = 110.0; 
    let delta = (y_t_1 - localMean) * phi[0] + (y_t_2 - localMean) * phi[1] + (y_t_3 - localMean) * phi[2];
    
    // Add scenario monthly drift & step shock
    let forecastVal = localMean + delta + (step * monthlyDrift);
    
    // Smooth transition from actual to forecast to avoid discontinuous jumps
    if (step === 1) {
      forecastVal = y_t_1 * 0.75 + forecastVal * 0.25;
    } else if (step === 2) {
      forecastVal = y_t_1 * 0.45 + forecastVal * 0.55;
    }

    forecastedVals.push(forecastVal);

    // Calculate expanding 95% Confidence Intervals
    // CI = Forecast +/- 1.96 * SE * sqrt(step)
    const baseSE = 1.8 * shockVolatility;
    const margin = 1.96 * baseSE * Math.sqrt(step);
    
    forecastTimeline.push({
      date: targetDate,
      historical: false,
      forecast: parseFloat(forecastVal.toFixed(2)),
      upper95: parseFloat((forecastVal + margin).toFixed(2)),
      lower95: parseFloat((forecastVal - margin).toFixed(2))
    });
  }

  return forecastTimeline;
}

// 9. Sector Breakdown performance simulator
export function getSectorPerformances(): SectorPerformance[] {
  return [
    { id: "steel", name: "Specialty Steel & Metallurgy", weight: 15, outputGrowth: 2.8, employmentYoY: -1.2, pmiValue: 51.4, investmentIndex: 108.2 },
    { id: "advanced_mfg", name: "Advanced Manufacturing & Aerostructures", weight: 20, outputGrowth: 7.4, employmentYoY: 4.8, pmiValue: 58.2, investmentIndex: 124.6 },
    { id: "food_mfg", name: "Food & Beverage Processing", weight: 18, outputGrowth: 1.5, employmentYoY: 0.8, pmiValue: 50.1, investmentIndex: 102.0 },
    { id: "chemicals", name: "Chemical Refineries & Polymers", weight: 12, outputGrowth: -1.1, employmentYoY: -2.3, pmiValue: 47.6, investmentIndex: 95.4 },
    { id: "textiles", name: "Bespoke Textiles & Apparel", weight: 8, outputGrowth: 3.2, employmentYoY: 1.1, pmiValue: 52.8, investmentIndex: 112.5 },
    { id: "machinery", name: "Industrial Machinery & Turbines", weight: 12, outputGrowth: 4.6, employmentYoY: 2.2, pmiValue: 54.3, investmentIndex: 116.8 },
    { id: "electronics", name: "Electronics & Scientific Instruments", weight: 9, outputGrowth: 6.1, employmentYoY: 3.5, pmiValue: 56.5, investmentIndex: 120.2 },
    { id: "automotive", name: "Automotive Precision Castings", weight: 6, outputGrowth: 3.8, employmentYoY: 0.5, pmiValue: 52.0, investmentIndex: 105.4 }
  ];
}

// 10. Commercial lending & exposure database simulator for Rhino Bank
export function getBankingExposureData(): BankingExposurePoint[] {
  return [
    { id: "steel", sectorName: "Specialty Steel & Metallurgy", exposureAmountMln: 450, nonPerformingLoansRatio: 3.1, creditRatingDistribution: { AAA_A: 40, BBB_BB: 45, B_CCC: 15 }, capitalAllocatedMln: 45 },
    { id: "advanced_mfg", sectorName: "Advanced Mfg & Aerospace", exposureAmountMln: 620, nonPerformingLoansRatio: 0.8, creditRatingDistribution: { AAA_A: 75, BBB_BB: 20, B_CCC: 5 }, capitalAllocatedMln: 62 },
    { id: "food_mfg", sectorName: "Food & Beverage Processing", exposureAmountMln: 310, nonPerformingLoansRatio: 1.2, creditRatingDistribution: { AAA_A: 65, BBB_BB: 30, B_CCC: 5 }, capitalAllocatedMln: 31 },
    { id: "chemicals", sectorName: "Chemical Refineries & Polymers", exposureAmountMln: 380, nonPerformingLoansRatio: 4.5, creditRatingDistribution: { AAA_A: 35, BBB_BB: 40, B_CCC: 25 }, capitalAllocatedMln: 38 },
    { id: "textiles", sectorName: "Bespoke Textiles & Apparel", exposureAmountMln: 140, nonPerformingLoansRatio: 2.2, creditRatingDistribution: { AAA_A: 50, BBB_BB: 42, B_CCC: 8 }, capitalAllocatedMln: 14 },
    { id: "machinery", sectorName: "Industrial Machinery & Turbines", exposureAmountMln: 290, nonPerformingLoansRatio: 1.8, creditRatingDistribution: { AAA_A: 55, BBB_BB: 35, B_CCC: 10 }, capitalAllocatedMln: 29 },
    { id: "electronics", sectorName: "Electronics & Scientific Instruments", exposureAmountMln: 210, nonPerformingLoansRatio: 0.9, creditRatingDistribution: { AAA_A: 70, BBB_BB: 25, B_CCC: 5 }, capitalAllocatedMln: 21 },
    { id: "automotive", sectorName: "Automotive Precision Castings", exposureAmountMln: 180, nonPerformingLoansRatio: 2.8, creditRatingDistribution: { AAA_A: 45, BBB_BB: 40, B_CCC: 15 }, capitalAllocatedMln: 18 }
  ];
}
