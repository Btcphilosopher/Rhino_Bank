import React, { useState, useEffect, useCallback } from "react";
import { 
  County, 
  Subregion, 
  Indicator, 
  MonthlyDataPoint, 
  ForecastScenario, 
  ForecastPoint, 
  SectorPerformance, 
  BankingExposurePoint 
} from "./types";
import YorkshireGISMap from "./components/YorkshireGISMap";
import AnalyticsEngine from "./components/AnalyticsEngine";
import ForecastingEngine from "./components/ForecastingEngine";
import BankingExposure from "./components/BankingExposure";
import ReportGenerator from "./components/ReportGenerator";

import { 
  Compass, 
  Sliders, 
  Calendar, 
  Landmark, 
  FileText, 
  RefreshCw, 
  TrendingUp, 
  Layers, 
  MapPin, 
  Activity,
  Award,
  BookOpen
} from "lucide-react";

export default function App() {
  // 1. Core State
  const [activeTab, setActiveTab] = useState<"overview" | "analytics" | "forecast" | "credit" | "reporting">("overview");
  const [counties, setCounties] = useState<County[]>([]);
  const [subregions, setSubregions] = useState<Subregion[]>([]);
  const [indicators, setIndicators] = useState<Indicator[]>([]);
  const [pcaWeights, setPcaWeights] = useState<{ indicatorId: string; indicatorName: string; loading: number }[]>([]);
  
  const [selectedCounty, setSelectedCounty] = useState<County | "Yorkshire-wide">("Yorkshire-wide");
  const [selectedSubregion, setSelectedSubregion] = useState<Subregion | null>(null);
  
  const [activeWeights, setActiveWeights] = useState<{ [id: string]: number }>({});
  const [historicalData, setHistoricalData] = useState<MonthlyDataPoint[]>([]);
  
  // Computed index state
  const [customIndex, setCustomIndex] = useState<{ date: string; value: number }[]>([]);
  const [equalIndex, setEqualIndex] = useState<{ date: string; value: number }[]>([]);
  const [pcaIndex, setPcaIndex] = useState<{ date: string; value: number }[]>([]);
  const [decomposition, setDecomposition] = useState<any[]>([]);
  const [correlationMatrix, setCorrelationMatrix] = useState<{ [i: string]: { [j: string]: number } }>({});
  
  // Forecast scenario state
  const [activeScenario, setActiveScenario] = useState<ForecastScenario>(ForecastScenario.BASELINE);
  const [forecastTimeline, setForecastTimeline] = useState<ForecastPoint[]>([]);
  
  // Banking Exposure and Sector Performance state
  const [sectors, setSectors] = useState<SectorPerformance[]>([]);
  const [bankingExposure, setBankingExposure] = useState<BankingExposurePoint[]>([]);

  const [loading, setLoading] = useState<boolean>(true);
  const [recalculating, setRecalculating] = useState<boolean>(false);

  // 2. Initial Metadata & Simulation Data Loading
  useEffect(() => {
    async function initPlatform() {
      try {
        setLoading(true);
        
        // Fetch metadata
        const metaRes = await fetch("/api/metadata");
        const meta = await metaRes.json();
        setCounties(meta.counties);
        setSubregions(meta.subregions);
        setIndicators(meta.indicators);
        setPcaWeights(meta.pcaWeights);

        // Establish default weights
        const defaults: { [id: string]: number } = {};
        meta.indicators.forEach((ind: Indicator) => {
          defaults[ind.id] = ind.defaultWeight;
        });
        setActiveWeights(defaults);

        // Fetch historical data
        const dataRes = await fetch("/api/historical-data");
        const hist = await dataRes.json();
        setHistoricalData(hist);

        // Fetch banking exposure & sectors
        const bankRes = await fetch("/api/banking-and-sectors");
        const bank = await bankRes.json();
        setSectors(bank.sectors);
        setBankingExposure(bank.bankingExposure);

        setLoading(false);
      } catch (err) {
        console.error("Platform initialization failed:", err);
        setLoading(false);
      }
    }
    initPlatform();
  }, []);

  // 3. Callback: Calculate YMI composite index based on weights and region
  const calculateIndex = useCallback(async (weights: { [id: string]: number }, county: County | "Yorkshire-wide") => {
    if (Object.keys(weights).length === 0) return;
    setRecalculating(true);
    try {
      const res = await fetch("/api/index/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ weights, county })
      });
      const indexResult = await res.json();
      setCustomIndex(indexResult.customIndex);
      setEqualIndex(indexResult.equalIndex);
      setPcaIndex(indexResult.pcaIndex);
      setDecomposition(indexResult.decomposition);
      setCorrelationMatrix(indexResult.correlationMatrix);
    } catch (err) {
      console.error("Index calculation API error:", err);
    } finally {
      setRecalculating(false);
    }
  }, []);

  // Re-trigger calculations when weights or region changes
  useEffect(() => {
    if (historicalData.length > 0 && Object.keys(activeWeights).length > 0) {
      calculateIndex(activeWeights, selectedCounty);
    }
  }, [activeWeights, selectedCounty, historicalData, calculateIndex]);

  // 4. Callback: Forecast handler
  const handleTriggerForecast = useCallback(async (scenario: ForecastScenario): Promise<ForecastPoint[]> => {
    if (customIndex.length === 0) return [];
    try {
      const res = await fetch("/api/forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ymiPoints: customIndex, scenario })
      });
      const forecastResult = await res.json();
      setActiveScenario(scenario);
      setForecastTimeline(forecastResult.timeline);
      return forecastResult.timeline;
    } catch (err) {
      console.error("Forecast API error:", err);
      return [];
    }
  }, [customIndex]);

  // Sync subregion selection with county context
  const handleSelectSubregion = (sub: Subregion | null) => {
    setSelectedSubregion(sub);
    if (sub) {
      setSelectedCounty(sub.county);
    }
  };

  // 5. Exporter pipeline: Compile and download YMI database CSV
  const handleExportCSV = () => {
    if (customIndex.length === 0) return;
    
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Date,Custom_YMI_Index,Equally_Weighted_Index,PCA_Optimal_Index\n";
    
    customIndex.forEach((point, idx) => {
      const eqVal = equalIndex[idx]?.value || 100;
      const pcaVal = pcaIndex[idx]?.value || 100;
      csvContent += `${point.date},${point.value},${eqVal},${pcaVal}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `RhinoQuant_YMI_${selectedCounty.replace(/\s+/g, "_")}_Database.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Render scorecards based on active values in June 2026
  const getScorecardMetrics = () => {
    if (customIndex.length === 0) return { ymiVal: 110.0, trend: 1.2, isPos: true };
    const latest = customIndex[customIndex.length - 1].value;
    const previous = customIndex[customIndex.length - 2].value;
    const diff = latest - previous;
    return {
      ymiVal: parseFloat(latest.toFixed(1)),
      trend: parseFloat(Math.abs(diff).toFixed(2)),
      isPos: diff >= 0
    };
  };

  const scorecards = getScorecardMetrics();

  // Helper values for Report synthesis
  const getSubregionsSummaryList = () => {
    return subregions
      .filter(s => selectedCounty === "Yorkshire-wide" || s.county === selectedCounty)
      .map(s => `${s.name} (${s.specialtySectors.join(", ")})`);
  };

  const activeForecastVal = forecastTimeline.length > 0 
    ? forecastTimeline[forecastTimeline.length - 1].forecast 
    : scorecards.ymiVal * 1.05;

  if (loading) {
    return (
      <div id="loading-screen" className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-4 text-slate-300">
        <div className="relative w-12 h-12 flex items-center justify-center">
          <div className="absolute inset-0 border-4 border-copper/15 rounded-full" />
          <div className="absolute inset-0 border-4 border-t-copper rounded-full animate-spin" />
          <Compass className="w-5 h-5 text-copper animate-pulse" />
        </div>
        <div className="text-center space-y-1 font-mono">
          <h4 className="text-xs font-bold text-slate-100 uppercase tracking-widest animate-pulse">Initializing RhinoQuant Platform</h4>
          <p className="text-[10px] text-slate-500">Loading Yorkshire macroeconomic datasets...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      
      {/* 1. FUTURIST YORKSHIRE HEADER BLOCK */}
      <header id="platform-header" className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md px-4 py-4 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="bg-copper/10 border border-copper/35 p-2 rounded-lg flex items-center justify-center text-copper animate-spin-slow">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif text-xl md:text-2xl font-black tracking-wider text-slate-100">
                RhinoQuant Manufacturing
              </h1>
              <span className="bg-copper/10 border border-copper/20 text-[9px] text-copper font-mono font-extrabold px-1.5 py-0.5 rounded">R.1</span>
            </div>
            <p className="text-[11px] md:text-xs text-slate-400 font-mono tracking-wider font-medium uppercase">
              Yorkshire & Humber Regional Manufacturing Intelligence Platform
            </p>
          </div>
        </div>

        {/* Global Connection/Recalculating indicator */}
        <div className="flex items-center gap-3">
          {recalculating && (
            <div className="flex items-center gap-1.5 text-[10px] text-copper font-mono bg-copper/10 px-2.5 py-1 rounded border border-copper/20 animate-pulse">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Recalculating YMI...</span>
            </div>
          )}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-[10px] text-slate-300">Internal Economic Engine Live</span>
          </div>
        </div>
      </header>

      {/* 2. REGION FILTER & SCORECARD BAR */}
      <section id="region-filter-scorecard-bar" className="bg-slate-950 border-b border-slate-900 px-4 py-4 md:px-8 space-y-4">
        
        {/* Interactive Filters row */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-900 pb-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-copper" />
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">Active Audit Region:</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => { setSelectedCounty("Yorkshire-wide"); setSelectedSubregion(null); }}
              className={`px-3 py-1.5 rounded text-xs font-mono border transition-all ${selectedCounty === "Yorkshire-wide" ? "bg-copper text-slate-950 font-bold border-copper/60 hover:bg-copper/95" : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"}`}
            >
              Yorkshire-wide
            </button>
            {counties.map((cty) => (
              <button
                key={cty}
                onClick={() => { setSelectedCounty(cty); setSelectedSubregion(null); }}
                className={`px-3 py-1.5 rounded text-xs font-mono border transition-all ${selectedCounty === cty ? "bg-copper text-slate-950 font-bold border-copper/60 hover:bg-copper/95" : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"}`}
              >
                {cty}
              </button>
            ))}
          </div>
        </div>

        {/* Aggregate KPI Scorecard Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
          <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">Composite Index (YMI)</span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-serif font-extrabold text-slate-100">{scorecards.ymiVal}</span>
                <span className={`text-[11px] font-mono font-bold flex items-center ${scorecards.isPos ? "text-emerald-500" : "text-rose-500"}`}>
                  {scorecards.isPos ? "▲" : "▼"} {scorecards.trend}
                </span>
              </div>
            </div>
            <Activity className="w-8 h-8 text-copper/20" />
          </div>

          <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">Factory Utilisation</span>
              <span className="text-2xl font-serif font-extrabold text-slate-100">81.4%</span>
              <span className="text-[9px] text-emerald-500 font-mono block">+0.8% capacity expansion</span>
            </div>
            <TrendingUp className="w-8 h-8 text-emerald-500/20" />
          </div>

          <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">Capital Investment Index</span>
              <span className="text-2xl font-serif font-extrabold text-slate-100">114.2</span>
              <span className="text-[9px] text-slate-500 font-mono block">Base Jan 2018 = 100</span>
            </div>
            <Sliders className="w-8 h-8 text-blue-500/20" />
          </div>

          <div className="bg-slate-900/40 border border-slate-850 p-4 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">Portfolio Exposure</span>
              <span className="text-2xl font-serif font-extrabold text-slate-100">£2.58B</span>
              <span className="text-[9px] text-slate-500 font-mono block">Rhino Bank Comm. Assets</span>
            </div>
            <Landmark className="w-8 h-8 text-cyan-500/20" />
          </div>
        </div>
      </section>

      {/* 3. MAIN TERMINAL TABS & VIEWPORTS */}
      <main id="main-terminal-viewport" className="flex-1 px-4 py-6 md:px-8 max-w-7xl mx-auto w-full space-y-6">
        
        {/* Terminal Level Navigation Tabs */}
        <div className="flex border-b border-slate-800/80 gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${activeTab === "overview" ? "border-copper text-copper bg-slate-900/10" : "border-transparent text-slate-400 hover:text-slate-200"}`}
          >
            <Compass className="w-4 h-4" />
            <span>GIS & Regional Control</span>
          </button>
          <button
            onClick={() => setActiveTab("analytics")}
            className={`px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${activeTab === "analytics" ? "border-copper text-copper bg-slate-900/10" : "border-transparent text-slate-400 hover:text-slate-200"}`}
          >
            <Sliders className="w-4 h-4" />
            <span>Composite index Lab</span>
          </button>
          <button
            onClick={() => setActiveTab("forecast")}
            className={`px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${activeTab === "forecast" ? "border-copper text-copper bg-slate-900/10" : "border-transparent text-slate-400 hover:text-slate-200"}`}
          >
            <Calendar className="w-4 h-4" />
            <span>Econometric Forecasting</span>
          </button>
          <button
            onClick={() => setActiveTab("credit")}
            className={`px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${activeTab === "credit" ? "border-copper text-copper bg-slate-900/10" : "border-transparent text-slate-400 hover:text-slate-200"}`}
          >
            <Landmark className="w-4 h-4" />
            <span>Rhino Credit Exposure</span>
          </button>
          <button
            onClick={() => setActiveTab("reporting")}
            className={`px-4 py-3 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${activeTab === "reporting" ? "border-copper text-copper bg-slate-900/10" : "border-transparent text-slate-400 hover:text-slate-200"}`}
          >
            <FileText className="w-4 h-4" />
            <span>AI report synthesis</span>
          </button>
        </div>

        {/* View Switcher */}
        <div id="terminal-tab-viewports" className="space-y-6">
          
          {/* OVERVIEW TAB */}
          {activeTab === "overview" && (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
              
              {/* GIS map container (8 cols) */}
              <div className="xl:col-span-8">
                <YorkshireGISMap
                  subregions={subregions}
                  selectedSubregion={selectedSubregion}
                  onSelectSubregion={handleSelectSubregion}
                  selectedCounty={selectedCounty}
                  onSelectCounty={setSelectedCounty}
                />
              </div>

              {/* County scorecard & details (4 cols) */}
              <div className="xl:col-span-4 bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 md:p-6 backdrop-blur-md space-y-4">
                <div className="border-b border-slate-850 pb-3">
                  <div className="flex items-center gap-2 text-copper mb-1">
                    <MapPin className="w-4 h-4" />
                    <span className="text-[10px] font-mono uppercase tracking-wider">County Context Overview</span>
                  </div>
                  <h4 className="font-serif text-xl font-bold text-slate-100">{selectedCounty}</h4>
                </div>

                <div className="space-y-3.5">
                  <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-850 space-y-1">
                    <span className="text-[9px] text-slate-400 font-mono block">Audited Industrial Footprint</span>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {selectedCounty === "Yorkshire-wide" ? 
                        "Comprehensive analysis of all Yorkshire and the Humber microclusters, incorporating Leeds machinery, Sheffield steel, Humber chemicals, and York tech labs." :
                        selectedCounty === County.WEST_YORKSHIRE ?
                        "West Yorkshire is Yorkshire's most populous subregion. Houses strong clusters in textiles, industrial engineering, custom machinery, print, and food processing." :
                        selectedCounty === County.SOUTH_YORKSHIRE ?
                        "The epicentre of precision materials. South Yorkshire leading clusters include advanced metallurgical steelworks, nuclear castings, and aerospace tooling." :
                        selectedCounty === County.NORTH_YORKSHIRE ?
                        "A massive geographical belt supporting confectionery, scientific instrumentation, medical manufacturing, coachworks, and advanced agricultural processing." :
                        "The primary maritime gateway. East Riding & Humber cluster focuses on advanced wind turbines, chemical refineries, polymers, and dock logistics."
                      }
                    </p>
                  </div>

                  {/* Quick indicators summary */}
                  <div className="space-y-2">
                    <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Local Subregion Industrial Clusters</span>
                    <div className="max-h-[140px] overflow-y-auto space-y-1.5 pr-1">
                      {subregions
                        .filter(s => selectedCounty === "Yorkshire-wide" || s.county === selectedCounty)
                        .map(s => (
                          <div 
                            key={s.id}
                            onClick={() => setSelectedSubregion(s)}
                            className={`flex items-center justify-between p-2 rounded text-xs cursor-pointer border transition-all ${selectedSubregion?.id === s.id ? "bg-copper/10 border-copper/40 text-copper font-bold" : "bg-slate-950/40 border-slate-900 text-slate-300 hover:bg-slate-950"}`}
                          >
                            <span>{s.name}</span>
                            <span className="text-[9px] font-mono text-slate-500 truncate max-w-[120px]">{s.specialtySectors[0]}</span>
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* Informational guide */}
                  <div className="bg-copper/5 border border-copper/10 p-3.5 rounded-lg flex gap-2">
                    <Award className="w-4 h-4 text-copper shrink-0 mt-0.5" />
                    <p className="text-[10px] text-slate-400 leading-normal">
                      **RhinoQuant Research**: Use the tab navigation above to access the *Composite Index Lab* to custom-weight industrial metrics, or the *Forecasting Suite* to stress-test regional loans against macroeconomic shocks.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ANALYTICS LAB TAB */}
          {activeTab === "analytics" && (
            <AnalyticsEngine
              indicators={indicators}
              pcaWeights={pcaWeights}
              activeWeights={activeWeights}
              onUpdateWeights={setActiveWeights}
              customIndex={customIndex}
              equalIndex={equalIndex}
              pcaIndex={pcaIndex}
              decomposition={decomposition}
              correlationMatrix={correlationMatrix}
            />
          )}

          {/* FORECASTING TAB */}
          {activeTab === "forecast" && (
            <ForecastingEngine
              customIndexPoints={customIndex}
              onTriggerForecast={handleTriggerForecast}
            />
          )}

          {/* BANKING CREDIT TAB */}
          {activeTab === "credit" && (
            <BankingExposure
              sectors={sectors}
              bankingExposure={bankingExposure}
            />
          )}

          {/* REPORT GENERATION TAB */}
          {activeTab === "reporting" && (
            <ReportGenerator
              currentCounty={selectedCounty}
              activeWeights={activeWeights}
              activeScenario={activeScenario}
              currentYmiValue={scorecards.ymiVal}
              forecastYmiValue={activeForecastVal}
              subregionsSummary={getSubregionsSummaryList()}
              onExportCSV={handleExportCSV}
            />
          )}

        </div>
      </main>

      {/* 4. PREMIUM INDUSTRIAL FOOTER */}
      <footer id="platform-footer" className="border-t border-slate-900/80 bg-slate-950/80 px-4 py-6 md:px-8 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-copper" />
            <span className="font-serif text-sm font-bold text-slate-300">RhinoQuant regional economic Intelligence Platform</span>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-[10px] font-mono text-slate-500">
            <span>AUDITED BY RHINO BANK CREDIT POLICY DESK</span>
            <span>DATA SOURCE: ONS / REGIONAL MUNICIPAL DATA</span>
            <span>MODEL VER: TS-AR3-V1.4</span>
            <span>REPRODUCIBILITY CODE: EN-CJS-3000</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
