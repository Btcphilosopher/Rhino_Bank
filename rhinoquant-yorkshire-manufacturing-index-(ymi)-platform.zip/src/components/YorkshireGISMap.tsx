import React, { useState } from "react";
import { Subregion, County } from "../types";
import { MapPin, Globe, Compass, Cpu, Anchor, Settings } from "lucide-react";

interface YorkshireGISMapProps {
  subregions: Subregion[];
  selectedSubregion: Subregion | null;
  onSelectSubregion: (subregion: Subregion | null) => void;
  selectedCounty: County | "Yorkshire-wide";
  onSelectCounty: (county: County | "Yorkshire-wide") => void;
}

export default function YorkshireGISMap({
  subregions,
  selectedSubregion,
  onSelectSubregion,
  selectedCounty,
  onSelectCounty
}: YorkshireGISMapProps) {
  const [hoveredSubregion, setHoveredSubregion] = useState<Subregion | null>(null);

  // Math helper to map lat/lng coordinates to standard SVG canvas (width: 600, height: 450)
  // Yorkshire boundaries: Lat: 53.3 to 54.6, Lng: -2.1 to -0.1
  const mapCoordinatesToSVG = (lat: number, lng: number): { x: number; y: number } => {
    const minLat = 53.3;
    const maxLat = 54.65;
    const minLng = -2.0;
    const maxLng = -0.15;

    // Invert Y because SVG coordinates start from top left
    const x = ((lng - minLng) / (maxLng - minLng)) * 520 + 40;
    const y = (1 - (lat - minLat) / (maxLat - minLat)) * 370 + 40;
    return { x, y };
  };

  // SVG representation of counties for premium background layers
  // County centroids/positions in SVG:
  // North Yorkshire: top half
  // West Yorkshire: bottom-left
  // South Yorkshire: bottom-middle
  // East Riding: bottom-right
  const getCountyColorClass = (countyName: County) => {
    const isActive = selectedCounty === "Yorkshire-wide" || selectedCounty === countyName;
    if (countyName === County.NORTH_YORKSHIRE) {
      return isActive ? "fill-slate-900/60 stroke-slate-700/80 hover:fill-slate-800/80" : "fill-slate-950/20 stroke-slate-900/40";
    }
    if (countyName === County.WEST_YORKSHIRE) {
      return isActive ? "fill-slate-900/70 stroke-slate-700/80 hover:fill-slate-800/90" : "fill-slate-950/20 stroke-slate-900/40";
    }
    if (countyName === County.SOUTH_YORKSHIRE) {
      return isActive ? "fill-slate-900/80 stroke-slate-700/80 hover:fill-slate-800/95" : "fill-slate-950/20 stroke-slate-900/40";
    }
    // East Riding
    return isActive ? "fill-slate-900/50 stroke-slate-700/80 hover:fill-slate-800/70" : "fill-slate-950/20 stroke-slate-900/40";
  };

  return (
    <div id="gis-map-container" className="relative bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 md:p-6 backdrop-blur-md overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Compass className="w-5 h-5 text-copper animate-spin-slow" />
          <h3 className="font-serif text-lg font-bold tracking-wide text-slate-100">
            GIS Spatial Intelligence Engine
          </h3>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono bg-slate-950/60 px-2.5 py-1 rounded border border-slate-800/40">
          <Globe className="w-3.5 h-3.5 text-copper" />
          <span>EPSG:4326 (WGS 84)</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* SVG Map Canvas */}
        <div className="lg:col-span-3 relative bg-slate-950/80 rounded-lg border border-slate-800/60 aspect-[4/3] flex items-center justify-center p-2">
          <svg
            id="yorkshire-svg-canvas"
            viewBox="0 0 600 450"
            className="w-full h-full select-none"
            style={{ filter: "drop-shadow(0 0 10px rgba(0,0,0,0.5))" }}
          >
            {/* 1. Coordinate Grids Background */}
            <g stroke="#334155" strokeWidth="0.25" strokeDasharray="3,3" opacity="0.3">
              <line x1="50" y1="0" x2="50" y2="450" />
              <line x1="150" y1="0" x2="150" y2="450" />
              <line x1="250" y1="0" x2="250" y2="450" />
              <line x1="350" y1="0" x2="350" y2="450" />
              <line x1="450" y1="0" x2="450" y2="450" />
              <line x1="550" y1="0" x2="550" y2="450" />
              
              <line x1="0" y1="50" x2="600" y2="50" />
              <line x1="0" y1="150" x2="600" y2="150" />
              <line x1="0" y1="250" x2="600" y2="250" />
              <line x1="0" y1="350" x2="600" y2="350" />
            </g>

            {/* 2. Abstract Stylized County Polygons (Yorkshire Boundaries) */}
            {/* North Yorkshire boundary (top) */}
            <polygon
              points="120,40 260,30 380,50 510,70 540,120 480,180 340,200 280,240 160,200 80,150"
              className={`transition-all duration-500 cursor-pointer ${getCountyColorClass(County.NORTH_YORKSHIRE)}`}
              onClick={() => onSelectCounty(County.NORTH_YORKSHIRE)}
            />
            
            {/* West Yorkshire boundary (bottom left) */}
            <polygon
              points="80,150 160,200 280,240 270,330 190,360 100,320 60,230"
              className={`transition-all duration-500 cursor-pointer ${getCountyColorClass(County.WEST_YORKSHIRE)}`}
              onClick={() => onSelectCounty(County.WEST_YORKSHIRE)}
            />

            {/* South Yorkshire boundary (bottom center) */}
            <polygon
              points="270,330 380,310 420,380 340,410 210,410 190,360"
              className={`transition-all duration-500 cursor-pointer ${getCountyColorClass(County.SOUTH_YORKSHIRE)}`}
              onClick={() => onSelectCounty(County.SOUTH_YORKSHIRE)}
            />

            {/* East Riding & Humber (bottom right) */}
            <polygon
              points="340,200 480,180 540,120 580,210 490,330 380,310 280,240"
              className={`transition-all duration-500 cursor-pointer ${getCountyColorClass(County.EAST_RIDING_HUMBER)}`}
              onClick={() => onSelectCounty(County.EAST_RIDING_HUMBER)}
            />

            {/* 3. Transport and Export Corridors */}
            {/* M62 Corridor (West to East: Bradford -> Leeds -> Goole -> Hull) */}
            <path
              d="M 60,250 Q 150,245 220,248 T 420,265 T 520,245"
              fill="none"
              stroke="#b45309"
              strokeWidth="2.5"
              strokeDasharray="6,4"
              opacity="0.6"
            />
            {/* East Coast Mainline (South to North: Doncaster -> Leeds/York -> Middlesbrough) */}
            <path
              d="M 330,410 Q 290,310 320,210 T 360,60"
              fill="none"
              stroke="#0f766e"
              strokeWidth="1.5"
              opacity="0.5"
            />

            {/* Corridor Labels */}
            <text x="70" y="240" fill="#b45309" fontSize="9" fontFamily="monospace" opacity="0.8">M62 Export Corridor</text>
            <text x="330" y="110" fill="#0f766e" fontSize="9" fontFamily="monospace" opacity="0.8" transform="rotate(78, 330, 110)">East Coast Spine</text>

            {/* 4. Industrial Cluster Highlights */}
            {/* Sheffield/Rotherham AMRC */}
            <circle cx="270" cy="365" r="30" fill="none" stroke="#D98324" strokeWidth="1" strokeDasharray="3,3" opacity="0.4" />
            <text x="270" y="390" fill="#D98324" fontSize="8" textAnchor="middle" fontFamily="monospace" opacity="0.7">AMP Advanced Mfg Zone</text>

            {/* Humber Energy Corridor */}
            <ellipse cx="490" cy="275" rx="35" ry="18" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4,2" opacity="0.4" />
            <text x="495" y="295" fill="#38bdf8" fontSize="8" textAnchor="middle" fontFamily="monospace" opacity="0.7">Humber Carbon Capture</text>

            {/* 5. Subregion Pins & Interactive Nodes */}
            {subregions.map(sub => {
              const { x, y } = mapCoordinatesToSVG(sub.coordinates[0], sub.coordinates[1]);
              const isSelected = selectedSubregion?.id === sub.id;
              const isHovered = hoveredSubregion?.id === sub.id;
              const isCountyActive = selectedCounty === "Yorkshire-wide" || selectedCounty === sub.county;

              if (!isCountyActive) return null;

              return (
                <g
                  key={sub.id}
                  className="cursor-pointer"
                  onClick={() => onSelectSubregion(isSelected ? null : sub)}
                  onMouseEnter={() => setHoveredSubregion(sub)}
                  onMouseLeave={() => setHoveredSubregion(null)}
                >
                  {/* Pulsing selection ring */}
                  {isSelected && (
                    <circle cx={x} cy={y} r="18" fill="none" stroke="#D98324" strokeWidth="1.5" className="animate-ping" opacity="0.7" />
                  )}

                  {/* Outer glow hover ring */}
                  {(isHovered || isSelected) && (
                    <circle cx={x} cy={y} r="12" fill="rgba(217, 131, 36, 0.2)" stroke="#D98324" strokeWidth="1" />
                  )}

                  {/* Core Pin Anchor */}
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 6 : 4}
                    fill={isSelected ? "#D98324" : "#4A4A4A"}
                    stroke="#1e293b"
                    strokeWidth="1.5"
                    className="transition-all duration-300"
                  />

                  {/* Label Text */}
                  <text
                    x={x}
                    y={y - (isSelected ? 10 : 8)}
                    fill={(isHovered || isSelected) ? "#D98324" : "#cbd5e1"}
                    fontSize={(isHovered || isSelected) ? "11" : "9"}
                    fontWeight={(isHovered || isSelected) ? "bold" : "normal"}
                    fontFamily="Plus Jakarta Sans"
                    textAnchor="middle"
                    className="transition-all duration-200"
                  >
                    {sub.name}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Map Compass Rose */}
          <div className="absolute bottom-3 right-3 flex flex-col items-center gap-1 p-2 bg-slate-950/90 border border-slate-800/80 rounded font-mono text-[9px] text-slate-400">
            <span className="font-bold text-copper">N</span>
            <div className="w-4 h-4 border border-slate-700 rounded-full flex items-center justify-center">
              <div className="w-0.5 h-2 bg-copper -translate-y-0.5" />
            </div>
            <span> Yorkshire </span>
          </div>
        </div>

        {/* Sidebar Info Card / GIS Legend */}
        <div className="flex flex-col gap-4">
          {/* Active selection info */}
          <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg flex-1">
            {selectedSubregion ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-copper">
                  <MapPin className="w-4 h-4" />
                  <span className="font-mono text-[11px] uppercase tracking-wider font-bold">Selected Subregion</span>
                </div>
                <h4 className="font-serif text-xl font-bold text-slate-100">{selectedSubregion.name}</h4>
                <div className="text-[11px] font-mono text-slate-400">
                  <span>County: </span>
                  <span className="text-slate-200">{selectedSubregion.county}</span>
                </div>
                <div className="text-[11px] font-mono text-slate-400">
                  <span>Coordinates: </span>
                  <span className="text-slate-200">{selectedSubregion.coordinates[0].toFixed(4)}°N, {selectedSubregion.coordinates[1].toFixed(4)}°W</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pt-1.5 border-t border-slate-800/60">
                  {selectedSubregion.description}
                </p>
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] text-copper font-mono block uppercase">Specialty Subsectors:</span>
                  <div className="flex flex-wrap gap-1">
                    {selectedSubregion.specialtySectors.map((sec, idx) => (
                      <span key={idx} className="bg-slate-900 border border-slate-800 text-[10px] text-slate-200 px-2 py-0.5 rounded">
                        {sec}
                      </span>
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => onSelectSubregion(null)}
                  className="w-full text-center mt-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 text-xs py-1.5 rounded transition-all"
                >
                  Clear Selection
                </button>
              </div>
            ) : hoveredSubregion ? (
              <div className="space-y-2">
                <div className="flex items-center gap-1 text-slate-400">
                  <MapPin className="w-3.5 h-3.5" />
                  <span className="font-mono text-[10px] uppercase">Hovering Hub</span>
                </div>
                <h4 className="font-serif text-lg font-bold text-slate-200">{hoveredSubregion.name}</h4>
                <span className="text-[11px] text-copper font-mono block">{hoveredSubregion.county}</span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {hoveredSubregion.description.substring(0, 80)}...
                </p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full py-8 text-center text-slate-400">
                <MapPin className="w-8 h-8 text-slate-700 mb-2 animate-bounce" />
                <p className="text-xs leading-relaxed max-w-[200px]">
                  Click an interactive point on the vector map to analyze local industrial capacity and clusters.
                </p>
              </div>
            )}
          </div>

          {/* GIS Legend card */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-3 rounded-lg text-xs space-y-2.5">
            <span className="font-mono text-[10px] text-slate-400 uppercase tracking-wider block">Intelligence Legend</span>
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-copper/20 border border-copper rounded-full" />
                <span className="text-slate-300 font-mono text-[10px]">Active Cluster Hub</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-0.5 bg-copper/80 border-t border-dashed" />
                <span className="text-slate-300 font-mono text-[10px]">M62 Logistics Corridor</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-0.5 bg-cyan-800" />
                <span className="text-slate-300 font-mono text-[10px]">East Coast Mainline</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 border border-copper border-dashed rounded-full" />
                <span className="text-slate-300 font-mono text-[10px]">Advanced Manufacturing Park</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-2 border border-cyan-500/50 rounded-full" />
                <span className="text-slate-300 font-mono text-[10px]">Refinery & Offshore Estuary</span>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/60">
              <span className="text-[9px] text-slate-500 leading-normal block">
                Rhino Bank's Yorkshire boundaries include Middlesbrough (Teesside Metals division) inside the North Yorkshire regional audit.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
