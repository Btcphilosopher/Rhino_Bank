import React, { useState } from "react";
import { ExecutiveReport, ForecastScenario } from "../types";
import { FileText, Cpu, Download, RefreshCw, Printer, AlertCircle, Sparkles, CheckCircle } from "lucide-react";

interface ReportGeneratorProps {
  currentCounty: string;
  activeWeights: { [id: string]: number };
  activeScenario: ForecastScenario;
  currentYmiValue: number;
  forecastYmiValue: number;
  subregionsSummary: string[];
  onExportCSV: () => void;
}

export default function ReportGenerator({
  currentCounty,
  activeWeights,
  activeScenario,
  currentYmiValue,
  forecastYmiValue,
  subregionsSummary,
  onExportCSV
}: ReportGeneratorProps) {
  const [reportTitle, setReportTitle] = useState<string>("Yorkshire Manufacturing Index — Economic Intelligence Report");
  const [reportAuthor, setReportAuthor] = useState<string>("RhinoQuant Quantitative Research Desk");
  const [reportType, setReportType] = useState<"monthly" | "quarterly" | "board">("monthly");
  const [generatedReport, setGeneratedReport] = useState<ExecutiveReport | null>(null);
  const [generating, setGenerating] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Trigger Gemini AI generation on the server
  const handleGenerateReport = async () => {
    setGenerating(true);
    setError(null);
    try {
      const typeLabel = 
        reportType === "monthly" ? "Monthly Industrial Index Report" : 
        reportType === "quarterly" ? "Quarterly Industrial Credit Outlook" : 
        "Board Risk Assessment Memo";

      const response = await fetch("/api/report/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `${typeLabel} — ${currentCounty}`,
          author: reportAuthor,
          county: currentCounty,
          weights: activeWeights,
          scenario: activeScenario,
          currentYmiValue,
          forecastYmiValue,
          subregionsSummary
        })
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with AI drafting endpoint");
      }

      const reportData: ExecutiveReport = await response.json();
      setGeneratedReport(reportData);
    } catch (err: any) {
      console.error("AI report draft failed:", err);
      setError(err.message || "An error occurred during economic synthesis");
    } finally {
      setGenerating(false);
    }
  };

  // Trigger browser print of the report
  const handlePrintReport = () => {
    if (!generatedReport) return;
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Please allow popups to export print drafts");
      return;
    }
    printWindow.document.write(`
      <html>
        <head>
          <title>${generatedReport.title}</title>
          <style>
            body { font-family: 'Times New Roman', Times, serif; padding: 40px; color: #111; line-height: 1.6; max-width: 800px; margin: 0 auto; }
            h1 { font-family: Georgia, serif; font-size: 26px; border-bottom: 2px solid #333; pb: 10px; margin-bottom: 5px; }
            .subtitle { font-style: italic; color: #555; margin-bottom: 30px; font-size: 13px; }
            h3 { font-family: Georgia, serif; font-size: 18px; color: #D98324; border-bottom: 1px solid #ccc; padding-bottom: 4px; margin-top: 30px; }
            h4 { font-family: Georgia, serif; font-size: 14px; margin-top: 20px; color: #1e3a8a; }
            p { font-size: 12pt; text-align: justify; }
            ul { font-size: 12pt; }
            .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; background: #f3f4f6; padding: 15px; border-radius: 4px; margin-bottom: 30px; border: 1px solid #e5e7eb; font-size: 11px; font-family: monospace; }
            .signature { margin-top: 50px; font-style: italic; border-top: 1px solid #eee; padding-top: 10px; }
          </style>
        </head>
        <body>
          <h1>${generatedReport.title}</h1>
          <div className="subtitle">RhinoQuant Yorkshire Manufacturing Intelligence Desk — Official Economic Briefing</div>
          
          <div className="meta-grid">
            <div><strong>AUTHORED BY:</strong> ${generatedReport.author}</div>
            <div><strong>AUDITED REGION:</strong> ${currentCounty}</div>
            <div><strong>DATE OF COMPILATION:</strong> ${generatedReport.date}</div>
            <div><strong>MODEL SCENARIO:</strong> ${activeScenario}</div>
          </div>

          <h3>I. Executive Macro-Economic Summary</h3>
          <p>${generatedReport.executiveSummary}</p>

          <h3>II. 24-Month Forecast & Econometric Path</h3>
          <p>${generatedReport.economicOutlook}</p>

          <h3>III. Portfolio Credit Quality & Risk Assessment</h3>
          <p>${generatedReport.riskAssessment}</p>

          <h3>IV. Strategic Capital Recommendations</h3>
          <p>${generatedReport.creditRecommendations}</p>

          <h3>V. Sector PMIs & Localized Hotspots</h3>
          <div style="font-size: 12pt;">
            ${generatedReport.htmlContent}
          </div>

          <div className="signature">
            Ref: RQ-YMI-${currentCounty.replace(/\s+/g, "").toUpperCase()}-${new Date().getFullYear()}<br>
            Signed for and on behalf of Rhino Bank Credit Policy Desk.
          </div>
          <script>window.print();</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div id="reporting-generator-panel" className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 md:p-6 backdrop-blur-md">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="w-5 h-5 text-copper" />
        <h3 className="font-serif text-lg font-bold tracking-wide text-slate-100">
          Executive Reporting & AI synthesis Desk
        </h3>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Controls Column (Left) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg space-y-4">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">Report Configuration</span>
            
            <div className="space-y-1">
              <label className="text-[10px] text-slate-400 font-mono block">BRIEFING TYPE</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:border-copper focus:outline-none"
              >
                <option value="monthly">Monthly Manufacturing Index (YMI)</option>
                <option value="quarterly">Quarterly Industrial Credit Outlook</option>
                <option value="board">Board Credit Risk Assessment</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-slate-400 font-mono block">SIGNATORY AUTHOR</label>
              <input
                type="text"
                value={reportAuthor}
                onChange={(e) => setReportAuthor(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:border-copper focus:outline-none"
                placeholder="e.g. RhinoQuant Research"
              />
            </div>

            <div className="space-y-1 pt-2">
              <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">Parametric Context</span>
              <div className="space-y-1 bg-slate-900/60 p-2.5 rounded border border-slate-800/60 text-[10px] font-mono text-slate-300">
                <div className="flex justify-between"><span>Audit Target:</span> <span className="text-copper font-bold">{currentCounty}</span></div>
                <div className="flex justify-between"><span>Active Index:</span> <span className="text-slate-100 font-bold">{currentYmiValue.toFixed(1)}</span></div>
                <div className="flex justify-between"><span>24M Forecast:</span> <span className="text-slate-100 font-bold">{forecastYmiValue.toFixed(1)}</span></div>
                <div className="flex justify-between"><span>Scenario:</span> <span className="text-slate-400 font-bold truncate max-w-[120px]" title={activeScenario}>{activeScenario.split(" (")[0]}</span></div>
              </div>
            </div>

            {/* Generate Trigger */}
            <button
              onClick={handleGenerateReport}
              disabled={generating}
              className="w-full bg-copper hover:bg-copper/90 disabled:bg-copper/20 disabled:text-slate-400 text-slate-950 text-xs font-mono font-bold py-2.5 rounded flex items-center justify-center gap-2 cursor-pointer transition-all border border-copper/30"
            >
              {generating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing via Gemini...</span>
                </>
              ) : (
                <>
                  <Cpu className="w-4 h-4" />
                  <span>Generate AI Report Draft</span>
                </>
              )}
            </button>
          </div>

          {/* Export Data Spreadsheets */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-lg space-y-3">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">Reproducibility Exports</span>
            <p className="text-[10px] text-slate-400 leading-normal">
              Rhino Bank's reproducibility mandate guarantees that all simulated YMI metrics and indices are fully exportable for auditing.
            </p>
            <button
              onClick={onExportCSV}
              className="w-full bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-slate-700 text-xs font-mono py-2 rounded flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export Historical CSV</span>
            </button>
          </div>
        </div>

        {/* Live Draft Viewer Column (Right) */}
        <div className="lg:col-span-8 flex flex-col min-h-[420px]">
          {generating ? (
            <div className="flex-1 bg-slate-950/80 rounded-lg border border-slate-800/60 p-8 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="absolute inset-0 border-4 border-copper/20 rounded-full" />
                <div className="absolute inset-0 border-4 border-t-copper rounded-full animate-spin" />
                <Sparkles className="w-6 h-6 text-copper animate-pulse" />
              </div>
              <div className="space-y-1">
                <h4 className="font-serif text-lg font-bold text-slate-200 animate-pulse">Running Econometric Analysis Pipeline</h4>
                <p className="text-xs text-slate-400 max-w-[320px] font-mono leading-normal">
                  Our econometric servers are proxying indicators to our **gemini-3.6-flash** drafting desk to compile professional banking recommendations...
                </p>
              </div>
            </div>
          ) : error ? (
            <div className="flex-1 bg-slate-950/80 rounded-lg border border-red-900/40 p-6 flex flex-col items-center justify-center text-center space-y-2 text-red-400">
              <AlertCircle className="w-8 h-8" />
              <h4 className="font-bold text-sm">Failed to generate AI commentary</h4>
              <p className="text-xs text-slate-400">{error}</p>
            </div>
          ) : generatedReport ? (
            <div className="flex-1 bg-slate-950/80 rounded-lg border border-slate-800/80 p-6 space-y-6 flex flex-col justify-between">
              
              {/* Draft contents */}
              <div className="space-y-6 overflow-y-auto max-h-[480px] pr-2">
                
                {/* Board Heading Header */}
                <div className="border-b-2 border-slate-800 pb-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono text-copper uppercase font-bold tracking-widest">RHINO BANK REGIONAL INTELLIGENCE BRIEFING</span>
                    <span className="text-[9px] font-mono text-slate-400">ID: {generatedReport.id}</span>
                  </div>
                  <h4 className="font-serif text-xl font-bold text-slate-100 mt-1">{generatedReport.title}</h4>
                  <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-2">
                    <span>AUTHORED BY: {generatedReport.author}</span>
                    <span>DATE: {generatedReport.date}</span>
                  </div>
                </div>

                {/* Summaries blocks */}
                <div className="space-y-4 text-xs leading-relaxed text-slate-300 text-justify">
                  <div className="space-y-1.5">
                    <h5 className="font-mono text-[10px] text-copper uppercase font-bold tracking-wider">I. Executive Summary</h5>
                    <p>{generatedReport.executiveSummary}</p>
                  </div>

                  <div className="space-y-1.5">
                    <h5 className="font-mono text-[10px] text-copper uppercase font-bold tracking-wider">II. Forecast & Macro Path</h5>
                    <p>{generatedReport.economicOutlook}</p>
                  </div>

                  <div className="space-y-1.5">
                    <h5 className="font-mono text-[10px] text-copper uppercase font-bold tracking-wider">III. Portfolio Exposure & Credit Risks</h5>
                    <p>{generatedReport.riskAssessment}</p>
                  </div>

                  <div className="space-y-1.5">
                    <h5 className="font-mono text-[10px] text-copper uppercase font-bold tracking-wider">IV. Strategic Credit Committee Recommendations</h5>
                    <p>{generatedReport.creditRecommendations}</p>
                  </div>

                  {/* HTML Content injected safely */}
                  <div className="space-y-1.5 pt-4 border-t border-slate-900">
                    <h5 className="font-mono text-[10px] text-copper uppercase font-bold tracking-wider">V. Quantitative Regional Analysis</h5>
                    <div 
                      className="generated-html-content prose prose-invert max-w-none text-xs text-slate-400 space-y-2 font-sans"
                      dangerouslySetInnerHTML={{ __html: generatedReport.htmlContent }} 
                    />
                  </div>
                </div>

              </div>

              {/* Action buttons */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] font-mono bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
                  <CheckCircle className="w-3.5 h-3.5 animate-pulse" />
                  <span>Briefing is PDF-Ready</span>
                </div>
                <button
                  onClick={handlePrintReport}
                  className="bg-copper hover:bg-copper/90 text-slate-950 font-mono text-xs font-bold px-4 py-2 rounded flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print / Save PDF Briefing</span>
                </button>
              </div>

            </div>
          ) : (
            <div className="flex-1 bg-slate-950/40 border border-slate-800/80 rounded-lg p-8 flex flex-col items-center justify-center text-center text-slate-400">
              <FileText className="w-12 h-12 text-slate-800 mb-2 animate-pulse" />
              <h4 className="font-serif text-base font-bold text-slate-300">No report draft synthesized</h4>
              <p className="text-xs max-w-[280px] leading-relaxed mt-1.5">
                Configure your economic metrics, click **Generate AI Report Draft**, and the system will run an econometric synthesis using Gemini.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
