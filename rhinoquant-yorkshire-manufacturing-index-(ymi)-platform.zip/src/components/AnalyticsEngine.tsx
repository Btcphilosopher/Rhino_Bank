import React, { useState } from "react";
import { Indicator, EconometricMetrics } from "../types";
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { Settings, RefreshCw, BarChart2, ShieldAlert, Award, TrendingUp, Sliders, Hash } from "lucide-react";

interface AnalyticsEngineProps {
  indicators: Indicator[];
  pcaWeights: { indicatorId: string; indicatorName: string; loading: number }[];
  activeWeights: { [id: string]: number };
  onUpdateWeights: (newWeights: { [id: string]: number }) => void;
  customIndex: { date: string; value: number }[];
  equalIndex: { date: string; value: number }[];
  pcaIndex: { date: string; value: number }[];
  decomposition: EconometricMetrics["seasonalTrend"];
  correlationMatrix: EconometricMetrics["correlationMatrix"];
}

const PRESETS = [
  {
    name: "Rhino Capital Standard",
    description: "Standard model emphasizing physical output, capex, and new orders.",
    weights: { output: 15, production: 10, utilisation: 10, orders: 10, employment: 10, wages: 5, productivity: 10, capex: 10, confidence: 5, export: 10, elec: 5 }
  },
  {
    name: "Equal Weight Benchmark",
    description: "Equally distributed weight across all 11 core economic indicators.",
    weights: { output: 9, production: 9, utilisation: 9, orders: 9, employment: 9, wages: 9, productivity: 9, capex: 9, confidence: 9, export: 9, elec: 10 }
  },
  {
    name: "Sovereign Supply Chain & Logistics",
    description: "Heavily weights logistics indicators, power consumption, and exports.",
    weights: { output: 5, production: 5, utilisation: 15, orders: 10, employment: 5, wages: 5, productivity: 5, capex: 10, confidence: 5, export: 20, elec: 15 }
  },
  {
    name: "Labor & Wage Dominant",
    description: "Prioritizes workforce employment levels, wage indexes, and productivity.",
    weights: { output: 5, production: 5, utilisation: 5, orders: 5, employment: 25, wages: 20, productivity: 20, capex: 5, confidence: 5, export: 5, elec: 0 }
  },
  {
    name: "Capital Expenditures & Confidence",
    description: "Focuses purely on capital expansion, capex investments, and executive outlook.",
    weights: { output: 5, production: 5, utilisation: 5, orders: 15, employment: 5, wages: 5, productivity: 5, capex: 30, confidence: 20, export: 5, elec: 0 }
  }
];

export default function AnalyticsEngine({
  indicators,
  pcaWeights,
  activeWeights,
  onUpdateWeights,
  customIndex,
  equalIndex,
  pcaIndex,
  decomposition,
  correlationMatrix
}: AnalyticsEngineProps) {
  const [activeTab, setActiveTab] = useState<"weight-builder" | "trend-decomposition" | "correlations">("weight-builder");
  const [hoveredCorr, setHoveredCorr] = useState<{ id1: string; id2: string; val: number } | null>(null);

  // Apply weight preset
  const handleApplyPreset = (presetWeights: { [id: string]: number }) => {
    onUpdateWeights({ ...presetWeights });
  };

  // Adjust singular slider weight
  const handleSliderChange = (id: string, value: number) => {
    const updated = { ...activeWeights, [id]: value };
    onUpdateWeights(updated);
  };

  // Equalize active weights
  const handleEqualize = () => {
    const equalVal = parseFloat((100 / indicators.length).toFixed(1));
    const equalWeights: { [id: string]: number } = {};
    indicators.forEach(ind => {
      equalWeights[ind.id] = equalVal;
    });
    onUpdateWeights(equalWeights);
  };

  // Set weights according to PCA Loading values
  const handleApplyPCAWeights = () => {
    const pcaWeightsMap: { [id: string]: number } = {};
    pcaWeights.forEach(p => {
      pcaWeightsMap[p.indicatorId] = p.loading;
    });
    onUpdateWeights(pcaWeightsMap);
  };

  // Format data for Recharts composite chart
  const compositeChartData = customIndex.map((point, idx) => ({
    date: point.date,
    "Custom YMI": point.value,
    "Equally Weighted YMI": equalIndex[idx]?.value || 100,
    "Statistically Optimal YMI (PCA)": pcaIndex[idx]?.value || 100
  }));

  // Total weight calculated helper
  const totalWeight = Object.values(activeWeights).reduce((a, b) => a + b, 0);

  return (
    <div id="analytics-engine-panel" className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 md:p-6 backdrop-blur-md">
      
      {/* Tab Navigation */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800/60 pb-4 mb-6 gap-4">
        <div className="flex items-center gap-3">
          <Sliders className="w-5 h-5 text-copper" />
          <h3 className="font-serif text-lg font-bold tracking-wide text-slate-100">
            Econometric Modelling Lab
          </h3>
        </div>
        <div className="flex bg-slate-950/80 p-1 rounded-lg border border-slate-800/80">
          <button
            onClick={() => setActiveTab("weight-builder")}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-all ${activeTab === "weight-builder" ? "bg-copper/10 text-copper font-bold border border-copper/20" : "text-slate-400 hover:text-slate-200"}`}
          >
            Composite Builder
          </button>
          <button
            onClick={() => setActiveTab("trend-decomposition")}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-all ${activeTab === "trend-decomposition" ? "bg-copper/10 text-copper font-bold border border-copper/20" : "text-slate-400 hover:text-slate-200"}`}
          >
            Seasonal Decomposition
          </button>
          <button
            onClick={() => setActiveTab("correlations")}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-all ${activeTab === "correlations" ? "bg-copper/10 text-copper font-bold border border-copper/20" : "text-slate-400 hover:text-slate-200"}`}
          >
            Correlation Heatmap
          </button>
        </div>
      </div>

      {activeTab === "weight-builder" && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          
          {/* Weights Customizer Sliders (Left) */}
          <div className="xl:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Indicator Allocation</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleEqualize}
                  className="text-[10px] bg-slate-950/80 border border-slate-800/80 text-slate-300 hover:bg-slate-900 px-2.5 py-1 rounded font-mono transition-all"
                >
                  Equalize
                </button>
                <button
                  onClick={handleApplyPCAWeights}
                  className="text-[10px] bg-copper/10 border border-copper/20 text-copper hover:bg-copper/20 px-2.5 py-1 rounded font-mono transition-all"
                >
                  Load PCA Weights
                </button>
              </div>
            </div>

            {/* Slider list wrapper */}
            <div className="space-y-3 bg-slate-950/40 border border-slate-800/60 p-4 rounded-lg max-h-[380px] overflow-y-auto">
              {indicators.map(ind => {
                const currentVal = activeWeights[ind.id] || 0;
                return (
                  <div key={ind.id} className="space-y-1.5 border-b border-slate-900/60 pb-2.5 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-200">{ind.name}</span>
                      <span className="font-mono text-copper font-semibold">{currentVal}%</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min="0"
                        max="50"
                        step="1"
                        value={currentVal}
                        onChange={(e) => handleSliderChange(ind.id, parseInt(e.target.value))}
                        className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-copper"
                      />
                      <span className="text-[9px] font-mono text-slate-500 w-12 text-right">{ind.unit}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Weight totals alert if not exactly 100% */}
            <div className={`flex items-center justify-between p-3 rounded-lg border text-xs font-mono ${Math.abs(totalWeight - 100) < 0.1 ? "bg-slate-950/60 border-emerald-500/30 text-emerald-400" : "bg-copper/10 border-copper/20 text-copper"}`}>
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4" />
                <span>Computed Model Weights:</span>
              </div>
              <span className="font-bold text-sm">{totalWeight}% / 100%</span>
            </div>

            {/* Model Presets Selector */}
            <div className="space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">Model Presets</span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleApplyPreset(preset.weights)}
                    className="bg-slate-950/40 hover:bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 p-2.5 rounded-lg text-left transition-all"
                  >
                    <span className="text-xs font-bold text-slate-200 block truncate">{preset.name}</span>
                    <span className="text-[10px] text-slate-400 line-clamp-1 leading-normal block">{preset.description}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Index Comparison Chart (Right) */}
          <div className="xl:col-span-7 flex flex-col justify-between space-y-4">
            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg flex-1">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="font-serif text-lg font-bold text-slate-100">Yorkshire Manufacturing Index (YMI) Trends</h4>
                  <p className="text-[11px] text-slate-400 font-mono">Comparing dynamic model configurations (2018 - 2026)</p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-copper bg-copper/10 px-2.5 py-1 rounded font-mono border border-copper/20">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Base: Jan 2018 = 100</span>
                </div>
              </div>

              {/* Line Chart */}
              <div className="h-[280px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={compositeChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis 
                      dataKey="date" 
                      stroke="#475569" 
                      fontSize={10} 
                      tickLine={false}
                      tickFormatter={(val) => {
                        const [y, m] = val.split("-");
                        return m === "01" ? `${y}` : "";
                      }}
                    />
                    <YAxis stroke="#475569" fontSize={10} tickLine={false} domain={["auto", "auto"]} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #334155", borderRadius: "8px" }}
                      labelStyle={{ color: "#94a3b8", fontFamily: "monospace", fontSize: "11px" }}
                      itemStyle={{ fontSize: "12px", color: "#f8fafc" }}
                    />
                    <Legend wrapperStyle={{ fontSize: "10px", marginTop: "10px" }} />
                    <Line 
                      type="monotone" 
                      dataKey="Custom YMI" 
                      stroke="#D98324" 
                      strokeWidth={2.5} 
                      dot={false}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="Equally Weighted YMI" 
                      stroke="#64748b" 
                      strokeWidth={1.5} 
                      strokeDasharray="5 5"
                      dot={false}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="Statistically Optimal YMI (PCA)" 
                      stroke="#0ea5e9" 
                      strokeWidth={1.5} 
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* PCA Math explanation box */}
            <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <div className="bg-blue-500/10 p-2 rounded text-blue-400 mt-0.5 border border-blue-500/20">
                  <Award className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <h5 className="text-xs font-bold text-slate-200">Statistical Optimization via PCA Solver</h5>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    The platform computes the **Statistically Optimal Index** dynamically by running a power-iteration solver to find the first principal component (PC1) of Yorkshire's industrial matrix. This explains maximum regional variance and assigns weights objectively based on co-movements of indicators.
                  </p>
                </div>
              </div>
            </div>
          </div>

        </div>
      )}

      {activeTab === "trend-decomposition" && (
        <div className="space-y-6">
          <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-serif text-lg font-bold text-slate-100">Classical Seasonal Trend Decomposition</h4>
                <p className="text-[11px] text-slate-400 font-mono">Additive moving-average decomposition of your Custom Weighted YMI index.</p>
              </div>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-900 border border-slate-800 px-2 py-1 rounded">
                Y(t) = Trend(t) + Seasonal(t) + Random(t)
              </span>
            </div>

            {/* Trend & Actual comparison */}
            <div className="h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={decomposition} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D98324" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#D98324" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="date" stroke="#475569" fontSize={10} tickLine={false} />
                  <YAxis stroke="#475569" fontSize={10} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #334155" }} />
                  <Legend wrapperStyle={{ fontSize: "10px" }} />
                  <Area type="monotone" dataKey="actual" name="Actual Raw Index" stroke="#D98324" fillOpacity={1} fill="url(#colorActual)" strokeWidth={2} />
                  <Line type="monotone" dataKey="trend" name="Smoothed Trend-Cycle" stroke="#0ea5e9" strokeWidth={2} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Seasonal and Irregular components */}
            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <h5 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">Estimated Seasonal Effect</h5>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={decomposition} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" stroke="#475569" fontSize={8} tickFormatter={(val) => val.split("-")[1] === "01" ? val.split("-")[0] : ""} />
                    <YAxis stroke="#475569" fontSize={8} />
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #334155" }} />
                    <Area type="monotone" dataKey="seasonal" name="Seasonality Cycle" stroke="#10b981" fill="#10b981" fillOpacity={0.1} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <h5 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">Irregular / Random Component (Noise)</h5>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={decomposition} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" stroke="#475569" fontSize={8} tickFormatter={(val) => val.split("-")[1] === "01" ? val.split("-")[0] : ""} />
                    <YAxis stroke="#475569" fontSize={8} />
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #334155" }} />
                    <Area type="monotone" dataKey="random" name="Random Deviations" stroke="#ef4444" fill="#ef4444" fillOpacity={0.05} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "correlations" && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          
          {/* Heatmap Matrix Grid */}
          <div className="xl:col-span-8 bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg overflow-x-auto">
            <h4 className="font-serif text-base font-bold text-slate-100 mb-4">Rolling Pearson Correlation Matrix</h4>
            
            <div className="min-w-[500px]">
              {/* Header Row */}
              <div className="grid grid-cols-12 gap-1 text-[9px] font-mono text-slate-400 border-b border-slate-900 pb-1 mb-1.5">
                <div className="col-span-2 truncate">Indicator</div>
                {indicators.map(ind => (
                  <div key={ind.id} className="text-center font-bold text-[8px] uppercase truncate" title={ind.name}>
                    {ind.id}
                  </div>
                ))}
              </div>

              {/* Rows */}
              <div className="space-y-1">
                {indicators.map(ind1 => (
                  <div key={ind1.id} className="grid grid-cols-12 gap-1 items-center">
                    <div className="col-span-2 text-[10px] font-medium text-slate-300 truncate" title={ind1.name}>
                      {ind1.name}
                    </div>
                    {indicators.map(ind2 => {
                      const corrVal = correlationMatrix[ind1.id]?.[ind2.id] ?? 1.0;
                      
                      // Calculate heat background color based on correlation strength
                      // +1 is bright copper-amber, -1 is bright teal/blue, 0 is dark slate
                      let bgStyle = "bg-slate-950 text-slate-500";
                      if (corrVal >= 0.8) bgStyle = "bg-copper text-white font-bold";
                      else if (corrVal >= 0.5) bgStyle = "bg-copper/60 text-slate-100";
                      else if (corrVal >= 0.2) bgStyle = "bg-copper/20 text-slate-300";
                      else if (corrVal <= -0.5) bgStyle = "bg-teal-700/60 text-slate-100";
                      else if (corrVal <= -0.2) bgStyle = "bg-teal-950/40 text-slate-300";
                      else bgStyle = "bg-slate-900 text-slate-500";

                      return (
                        <div
                          key={ind2.id}
                          className={`aspect-square text-[9px] font-mono flex items-center justify-center rounded-sm transition-all cursor-pointer ${bgStyle} hover:scale-110 hover:ring-1 hover:ring-white`}
                          onMouseEnter={() => setHoveredCorr({ id1: ind1.name, id2: ind2.name, val: corrVal })}
                          onMouseLeave={() => setHoveredCorr(null)}
                        >
                          {corrVal.toFixed(1)}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Hover Details Card & Econometric Guidance */}
          <div className="xl:col-span-4 flex flex-col justify-between space-y-4">
            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg flex-1">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block mb-3">Correlation Inspector</span>
              {hoveredCorr ? (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 block uppercase">Source Variable:</span>
                    <span className="text-xs font-bold text-slate-200">{hoveredCorr.id1}</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 block uppercase">Target Variable:</span>
                    <span className="text-xs font-bold text-slate-200">{hoveredCorr.id2}</span>
                  </div>
                  <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between">
                    <span className="text-xs text-slate-300 font-mono">Pearson Coefficient:</span>
                    <span className={`text-lg font-mono font-bold ${hoveredCorr.val >= 0.5 ? "text-copper" : hoveredCorr.val <= -0.5 ? "text-teal-400" : "text-slate-400"}`}>
                      {hoveredCorr.val.toFixed(2)}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 leading-normal">
                    {hoveredCorr.val >= 0.7 ? "Reflects an extremely strong positive co-movement. Indicates that these industrial factors scale tightly together in Yorkshire." : 
                     hoveredCorr.val >= 0.4 ? "Moderately strong positive coupling. Normal cyclical patterns link these elements closely." :
                     hoveredCorr.val <= -0.4 ? "Negative correlation suggests an inverse relationship. One factor expands while the other contracts." :
                     "Weak coupling. These two indicators behave largely independently within the Yorkshire econometric model."}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full py-8 text-center text-slate-400">
                  <Hash className="w-8 h-8 text-slate-700 mb-2" />
                  <p className="text-xs max-w-[200px]">
                    Hover over any cell in the correlation matrix grid to isolate co-movement coefficients.
                  </p>
                </div>
              )}
            </div>

            <div className="bg-slate-950/40 border border-slate-800/80 p-3.5 rounded-lg text-xs text-slate-400 space-y-1">
              <span className="font-bold text-slate-300">Interpretation Guidelines</span>
              <p className="leading-normal">
                - **Capex and Output** normally maintain strong positive correlations during expansionary cycles.
                - **Energy usage (Elec)** serves as a real-time proxy for heavy smelters (Steel) and chemicals.
                - **Wages** behave stickily, showing lag against raw business confidence.
              </p>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
