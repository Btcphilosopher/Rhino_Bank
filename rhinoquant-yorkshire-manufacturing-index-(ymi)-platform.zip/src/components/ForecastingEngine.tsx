import React, { useState, useEffect } from "react";
import { ForecastScenario, ForecastPoint } from "../types";
import { 
  AreaChart, 
  Area, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ReferenceLine
} from "recharts";
import { HelpCircle, TrendingUp, Sliders, Calendar, AlertTriangle, Cpu, ArrowUpRight, ArrowDownRight } from "lucide-react";

interface ForecastingEngineProps {
  customIndexPoints: { date: string; value: number }[];
  onTriggerForecast: (scenario: ForecastScenario) => Promise<ForecastPoint[]>;
}

export default function ForecastingEngine({
  customIndexPoints,
  onTriggerForecast
}: ForecastingEngineProps) {
  const [selectedScenario, setSelectedScenario] = useState<ForecastScenario>(ForecastScenario.BASELINE);
  const [forecastTimeline, setForecastTimeline] = useState<ForecastPoint[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [activeHorizon, setActiveHorizon] = useState<"all" | "3m" | "6m" | "12m" | "24m">("all");

  // Fetch forecast whenever scenario changes
  useEffect(() => {
    async function loadForecast() {
      setLoading(true);
      try {
        const data = await onTriggerForecast(selectedScenario);
        setForecastTimeline(data);
      } catch (err) {
        console.error("Forecast fetch failed:", err);
      } finally {
        setLoading(false);
      }
    }
    if (customIndexPoints.length > 0) {
      loadForecast();
    }
  }, [selectedScenario, customIndexPoints, onTriggerForecast]);

  // Extract milestones:
  // Historical index ends at June 2026.
  // 3 Month: Sept 2026. 12 Month: June 2027. 24 Month: June 2028.
  const getMilestoneValues = () => {
    if (forecastTimeline.length === 0) return null;
    const historicalPoints = forecastTimeline.filter(p => p.historical);
    const lastHistorical = historicalPoints[historicalPoints.length - 1];
    const baseVal = lastHistorical?.forecast || 110.0;

    const forecastOnly = forecastTimeline.filter(p => !p.historical);
    const p3m = forecastOnly[2]; // Index 2 is +3 Months (July, Aug, Sept)
    const p6m = forecastOnly[5]; // +6 Months (Dec)
    const p12m = forecastOnly[11]; // +12 Months
    const p24m = forecastOnly[23]; // +24 Months

    const getGrowth = (fVal: number) => {
      const pct = ((fVal - baseVal) / baseVal) * 100;
      return {
        pct: parseFloat(pct.toFixed(1)),
        isPositive: pct >= 0
      };
    };

    return {
      base: baseVal.toFixed(1),
      baseDate: lastHistorical?.date || "2026-06",
      "3m": { date: p3m?.date || "2026-09", val: p3m?.forecast.toFixed(1) || "111.0", growth: getGrowth(p3m?.forecast || 111.0), lower: p3m?.lower95.toFixed(1), upper: p3m?.upper95.toFixed(1) },
      "6m": { date: p6m?.date || "2026-12", val: p6m?.forecast.toFixed(1) || "112.5", growth: getGrowth(p6m?.forecast || 112.5), lower: p6m?.lower95.toFixed(1), upper: p6m?.upper95.toFixed(1) },
      "12m": { date: p12m?.date || "2027-06", val: p12m?.forecast.toFixed(1) || "114.2", growth: getGrowth(p12m?.forecast || 114.2), lower: p12m?.lower95.toFixed(1), upper: p12m?.upper95.toFixed(1) },
      "24m": { date: p24m?.date || "2028-06", val: p24m?.forecast.toFixed(1) || "116.8", growth: getGrowth(p24m?.forecast || 116.8), lower: p24m?.lower95.toFixed(1), upper: p24m?.upper95.toFixed(1) }
    };
  };

  const milestones = getMilestoneValues();

  // Filter chart based on active horizon zoom
  const getFilteredChartData = () => {
    if (forecastTimeline.length === 0) return [];
    
    const historicalPoints = forecastTimeline.filter(p => p.historical);
    const forecastPoints = forecastTimeline.filter(p => !p.historical);
    
    // Always show last 24 months of history to give context
    const recentHistory = historicalPoints.slice(-24);

    if (activeHorizon === "3m") {
      return [...recentHistory, ...forecastPoints.slice(0, 3)];
    }
    if (activeHorizon === "6m") {
      return [...recentHistory, ...forecastPoints.slice(0, 6)];
    }
    if (activeHorizon === "12m") {
      return [...recentHistory, ...forecastPoints.slice(0, 12)];
    }
    return [...recentHistory, ...forecastPoints]; // all (24m forecast)
  };

  const chartData = getFilteredChartData();

  // Scenario specific descriptions for educational/quantitative insight
  const getScenarioExplanation = () => {
    switch (selectedScenario) {
      case ForecastScenario.GREEN_TRANSITION:
        return {
          header: "Subsea Turbine & Clean Power Inflow",
          body: "Models the economic tailwinds of offshore wind blade manufacturing at Hull port corridors and steel casting upgrades in Sheffield. Reflects increased long-term business confidence and a 30% boost to private sector capital expenditure indicators.",
          severity: "high-positive",
          volatility: "Low Variance"
        };
      case ForecastScenario.TRADE_FRICTION:
        return {
          header: "Port Congestion & Tariff Threats",
          body: "Injects structural frictional drag representing maritime customs friction at Hull and Goole. Shrinks export performance index and shifts logistics metrics down, raising supply chain volatility. Forecast ranges exhibit wide, diverging uncertainty bounds.",
          severity: "high-negative",
          volatility: "High Variance"
        };
      case ForecastScenario.CREDIT_CRUNCH:
        return {
          header: "Central Bank Tightening & Liquidity Squeeze",
          body: "Simulates restrictive commercial lending rules from regional finance institutions. Depresses machinery purchase indices and slows down industrial construction starts. Factory utilisation levels decrease by 3.5% over the medium term.",
          severity: "medium-negative",
          volatility: "Moderate Variance"
        };
      default:
        return {
          header: "Baseline Econometric Trend",
          body: "A steady-state macroeconomic extrapolation of the historical 4-year industrial cycles, net of fresh geopolitical shocks. Represents standard cyclical amortization of current regional loans and business expansion trajectories.",
          severity: "neutral",
          volatility: "Standard Variance"
        };
    }
  };

  const explanation = getScenarioExplanation();

  return (
    <div id="forecast-engine-panel" className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 md:p-6 backdrop-blur-md">
      
      {/* Header section */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800/60 pb-4 mb-6 gap-4">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-copper" />
          <h3 className="font-serif text-lg font-bold tracking-wide text-slate-100">
            ARIMA-AR Predictive Forecasting Suite
          </h3>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {Object.values(ForecastScenario).map((scen) => (
            <button
              key={scen}
              onClick={() => setSelectedScenario(scen)}
              className={`px-3 py-1.5 rounded text-xs font-mono border transition-all ${selectedScenario === scen ? "bg-copper/10 text-copper font-bold border border-copper/40" : "bg-slate-950/40 border-slate-800/80 text-slate-400 hover:text-slate-200"}`}
            >
              {scen.split(" (")[0]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Forecast chart block (Left) */}
        <div className="xl:col-span-8 space-y-4">
          <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
            <div className="flex flex-wrap items-center justify-between mb-4 gap-2">
              <div>
                <h4 className="font-serif text-base font-bold text-slate-100">24-Month Projections (Jul 2026 - Jun 2028)</h4>
                <p className="text-[11px] text-slate-400 font-mono">Dotted line displays current forecast; shaded envelope shows 95% confidence interval</p>
              </div>
              <div className="flex bg-slate-900 p-0.5 rounded border border-slate-800 text-[10px] font-mono">
                {(["all", "3m", "6m", "12m"] as const).map(h => (
                  <button
                    key={h}
                    onClick={() => setActiveHorizon(h)}
                    className={`px-2 py-1 rounded transition-all ${activeHorizon === h ? "bg-slate-800 text-copper font-bold" : "text-slate-400 hover:text-slate-200"}`}
                  >
                    {h === "all" ? "24M" : h.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* Forecast Chart */}
            <div className="h-[280px] w-full relative">
              {loading && (
                <div className="absolute inset-0 bg-slate-950/75 z-10 flex items-center justify-center gap-2 text-xs font-mono text-copper">
                  <RefreshCwIcon className="w-4 h-4 animate-spin" />
                  <span>Calculating predictive matrices...</span>
                </div>
              )}
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#475569" 
                    fontSize={10} 
                    tickLine={false}
                    tickFormatter={(val) => {
                      const [y, m] = val.split("-");
                      return m === "01" ? `${y}` : "";
                    }}
                  />
                  <YAxis stroke="#475569" fontSize={10} tickLine={false} domain={["auto", "auto"]} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #334155", borderRadius: "8px" }}
                    labelStyle={{ color: "#94a3b8", fontFamily: "monospace", fontSize: "11px" }}
                  />
                  <Legend wrapperStyle={{ fontSize: "10px" }} />
                  
                  {/* Historical Shading */}
                  <Area 
                    type="monotone" 
                    dataKey="actual" 
                    name="Historic YMI" 
                    stroke="#D98324" 
                    strokeWidth={2}
                    fill="#D98324" 
                    fillOpacity={0.08}
                    dot={false}
                  />

                  {/* Shaded confidence bound area (Only populated for forecast period) */}
                  <Area
                    type="monotone"
                    dataKey="upper95"
                    stroke="none"
                    fill="#3b82f6"
                    fillOpacity={0.12}
                    name="Upper 95% Confidence Bound"
                  />
                  <Area
                    type="monotone"
                    dataKey="lower95"
                    stroke="none"
                    fill="#3b82f6"
                    fillOpacity={0.12}
                    name="Lower 95% Confidence Bound"
                  />

                  {/* Expected forecast path line */}
                  <Line 
                    type="monotone" 
                    dataKey="forecast" 
                    name="Predicted Path" 
                    stroke="#3b82f6" 
                    strokeWidth={2} 
                    strokeDasharray="4 4"
                    dot={false}
                  />

                  {/* Vertical demarcation of the historic vs forecast threshold */}
                  <ReferenceLine x="2026-06" stroke="#D98324" strokeWidth={1} strokeDasharray="3 3" label={{ value: "Forecast Launch", position: "top", fill: "#D98324", fontSize: 9, fontFamily: "monospace" }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Forecast Milestones Summary Row */}
          {milestones && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "3-Month Horizon", date: milestones["3m"].date, val: milestones["3m"].val, growth: milestones["3m"].growth, range: `[${milestones["3m"].lower} - ${milestones["3m"].upper}]` },
                { label: "6-Month Horizon", date: milestones["6m"].date, val: milestones["6m"].val, growth: milestones["6m"].growth, range: `[${milestones["6m"].lower} - ${milestones["6m"].upper}]` },
                { label: "12-Month Horizon", date: milestones["12m"].date, val: milestones["12m"].val, growth: milestones["12m"].growth, range: `[${milestones["12m"].lower} - ${milestones["12m"].upper}]` },
                { label: "24-Month Scenario", date: milestones["24m"].date, val: milestones["24m"].val, growth: milestones["24m"].growth, range: `[${milestones["24m"].lower} - ${milestones["24m"].upper}]` }
              ].map((m, idx) => (
                <div key={idx} className="bg-slate-950/40 border border-slate-800/80 p-3 rounded-lg text-left">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block">{m.label}</span>
                  <span className="text-[9px] text-slate-500 font-mono block mb-1">{m.date}</span>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-lg font-bold text-slate-100 font-mono">{m.val}</span>
                    <span className={`text-[10px] font-mono font-bold flex items-center ${m.growth.isPositive ? "text-emerald-500" : "text-rose-500"}`}>
                      {m.growth.isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                      {m.growth.pct}%
                    </span>
                  </div>
                  <span className="text-[8px] font-mono text-slate-500 block">Conf. Interval: {m.range}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Scenario Explanation and Risk Board (Right) */}
        <div className="xl:col-span-4 flex flex-col justify-between space-y-4">
          <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg flex-1 space-y-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-copper animate-pulse" />
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">Scenario Simulation Parameters</span>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-serif text-lg font-bold text-slate-200">
                {explanation.header}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {explanation.body}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Model Volatility:</span>
                <span className={`font-bold ${explanation.severity.includes("negative") ? "text-rose-400" : explanation.severity.includes("positive") ? "text-emerald-400" : "text-slate-400"}`}>
                  {explanation.volatility}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Cyclical Amortization:</span>
                <span className="text-slate-200 font-bold">Standard 4-Year</span>
              </div>
            </div>
          </div>

          {/* Risk stress warning */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-3.5 rounded-lg">
            <div className="flex gap-2.5">
              <AlertTriangle className="w-4 h-4 text-copper shrink-0 mt-0.5" />
              <p className="text-[10px] text-slate-400 leading-normal">
                **Disclaimer**: This forecasting model uses historical times-series regressions and macro multipliers calibrated to Rhino Bank's internal credit metrics. Values are simulated projections and should not be used as guaranteed trade instructions.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

// Icon helper components
function RefreshCwIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" /><path d="M16 16h5v5" /></svg>
  );
}
