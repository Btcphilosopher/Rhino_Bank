import React, { useState } from "react";
import { SectorPerformance, BankingExposurePoint } from "../types";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { Landmark, TrendingUp, AlertOctagon, Sparkles, ShieldAlert, BarChart2, Coins, ArrowUpRight } from "lucide-react";

interface BankingExposureProps {
  sectors: SectorPerformance[];
  bankingExposure: BankingExposurePoint[];
}

export default function BankingExposure({
  sectors,
  bankingExposure
}: BankingExposureProps) {
  const [activeView, setActiveView] = useState<"sectors" | "portfolio" | "opportunities">("portfolio");

  // Sum total bank exposure
  const totalExposure = bankingExposure.reduce((sum, pt) => sum + pt.exposureAmountMln, 0);
  const totalCapitalAllocated = bankingExposure.reduce((sum, pt) => sum + pt.capitalAllocatedMln, 0);
  
  // Calculate weighted average Non-performing Loan (NPL) ratio
  const weightedNPL = bankingExposure.reduce((sum, pt) => sum + (pt.nonPerformingLoansRatio * pt.exposureAmountMln), 0) / totalExposure;

  // Custom formatted dataset for recharts (combines exposure amount and NPLs)
  const chartData = bankingExposure.map(pt => ({
    name: pt.sectorName.substring(0, 16) + "..",
    "Exposure (£M)": pt.exposureAmountMln,
    "NPL Ratio (%)": pt.nonPerformingLoansRatio,
    "Capital Allocated (£M)": pt.capitalAllocatedMln
  }));

  return (
    <div id="banking-exposure-panel" className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 md:p-6 backdrop-blur-md">
      
      {/* Module Title & Tabs */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800/60 pb-4 mb-6 gap-4">
        <div className="flex items-center gap-3">
          <Landmark className="w-5 h-5 text-copper" />
          <h3 className="font-serif text-lg font-bold tracking-wide text-slate-100">
            Rhino Bank Credit Portfolio Risk Center
          </h3>
        </div>
        <div className="flex bg-slate-950/80 p-1 rounded-lg border border-slate-800/80">
          <button
            onClick={() => setActiveView("portfolio")}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-all ${activeView === "portfolio" ? "bg-copper/10 text-copper font-bold border border-copper/20" : "text-slate-400 hover:text-slate-200"}`}
          >
            Lending Book
          </button>
          <button
            onClick={() => setActiveView("sectors")}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-all ${activeView === "sectors" ? "bg-copper/10 text-copper font-bold border border-copper/20" : "text-slate-400 hover:text-slate-200"}`}
          >
            Sector PMIs
          </button>
          <button
            onClick={() => setActiveView("opportunities")}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-all ${activeView === "opportunities" ? "bg-copper/10 text-copper font-bold border border-copper/20" : "text-slate-400 hover:text-slate-200"}`}
          >
            Advisory & Opportunities
          </button>
        </div>
      </div>

      {activeView === "portfolio" && (
        <div className="space-y-6">
          
          {/* Key credit portfolio statistics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">Total Active Exposure</span>
              <span className="font-serif text-2xl font-bold text-slate-100">£{totalExposure}M</span>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono mt-1">
                <span>Rhino Core Balance Sheets</span>
              </div>
            </div>
            
            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">Portfolio NPL Ratio</span>
              <span className="font-serif text-2xl font-bold text-copper">{weightedNPL.toFixed(2)}%</span>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono mt-1">
                <span className="text-emerald-500 font-bold">Stable Range</span>
                <span>(Limit: 3.5%)</span>
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">Tier-1 Allocated Capital</span>
              <span className="font-serif text-2xl font-bold text-slate-100">£{totalCapitalAllocated}M</span>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono mt-1">
                <span>Basel III Capital Adequacy</span>
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">Prime AAA-A Rating Share</span>
              <span className="font-serif text-2xl font-bold text-slate-100">56.5%</span>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono mt-1">
                <span className="text-emerald-500 font-bold">+1.8%</span>
                <span>Year-over-Year improvement</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            
            {/* Visual breakdown chart (Left) */}
            <div className="xl:col-span-7 bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
              <h4 className="font-serif text-base font-bold text-slate-100 mb-4">Capital Commitment per Industrial Sector</h4>
              
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" stroke="#475569" fontSize={8} tickLine={false} />
                    <YAxis stroke="#475569" fontSize={8} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #334155" }} />
                    <Legend wrapperStyle={{ fontSize: "10px" }} />
                    <Bar dataKey="Exposure (£M)" fill="#D98324" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Capital Allocated (£M)" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Credit rating risk table (Right) */}
            <div className="xl:col-span-5 bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg flex flex-col justify-between">
              <div>
                <h4 className="font-serif text-base font-bold text-slate-100 mb-3">Portfolio Credit Grade Distribution</h4>
                <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                  {bankingExposure.map(pt => (
                    <div key={pt.id} className="space-y-1 pb-2 border-b border-slate-900 last:border-0 last:pb-0">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-200">{pt.sectorName}</span>
                        <span className="font-mono text-[10px] text-slate-400">NPL: <b className={pt.nonPerformingLoansRatio > 3.0 ? "text-rose-400" : "text-emerald-400"}>{pt.nonPerformingLoansRatio}%</b></span>
                      </div>
                      
                      {/* Grid representation of credit quality */}
                      <div className="flex h-1.5 w-full rounded overflow-hidden">
                        <div style={{ width: `${pt.creditRatingDistribution.AAA_A}%` }} className="bg-emerald-500" title="AAA to A Grade" />
                        <div style={{ width: `${pt.creditRatingDistribution.BBB_BB}%` }} className="bg-copper" title="BBB to BB Grade" />
                        <div style={{ width: `${pt.creditRatingDistribution.B_CCC}%` }} className="bg-rose-500" title="B to CCC Grade" />
                      </div>
                      <div className="flex justify-between text-[8px] font-mono text-slate-500">
                        <span>AAA-A: {pt.creditRatingDistribution.AAA_A}%</span>
                        <span>BBB-BB: {pt.creditRatingDistribution.BBB_BB}%</span>
                        <span>B-CCC: {pt.creditRatingDistribution.B_CCC}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Stress buffer warnings */}
              <div className="bg-rose-950/15 border border-rose-500/20 p-2.5 rounded text-[11px] text-rose-300 flex items-start gap-2 mt-3">
                <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <p>
                  **Portfolio Advisory**: Chemical Refineries register an elevated NPL rating of 4.5%, with 25% of debt classified as high-risk B-CCC. Capital reserves for the Humber Corridor lines have been increased by £5M.
                </p>
              </div>
            </div>

          </div>
        </div>
      )}

      {activeView === "sectors" && (
        <div className="space-y-4">
          <div className="bg-slate-950/60 border border-slate-800/60 p-4 rounded-lg">
            <h4 className="font-serif text-base font-bold text-slate-100 mb-4">Industrial Sector PMI Scorecard (YoY Growth Metrics)</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
              {sectors.map(sec => {
                const isExpanding = sec.pmiValue >= 50;
                return (
                  <div key={sec.id} className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
                    <div>
                      <span className="font-serif text-xs font-bold text-slate-300 block mb-1">{sec.name}</span>
                      <div className="flex items-baseline justify-between pt-1">
                        <span className="font-mono text-2xl font-bold text-slate-100">{sec.pmiValue.toFixed(1)}</span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${isExpanding ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"}`}>
                          {isExpanding ? "EXPANSION" : "CONTRACTION"}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1.5 pt-4 mt-4 border-t border-slate-800/60 text-[10px] font-mono text-slate-400">
                      <div className="flex items-center justify-between">
                        <span>Output YoY Growth:</span>
                        <span className={`font-bold ${sec.outputGrowth >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                          {sec.outputGrowth >= 0 ? "+" : ""}{sec.outputGrowth}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Workforce YoY:</span>
                        <span className={`font-bold ${sec.employmentYoY >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                          {sec.employmentYoY >= 0 ? "+" : ""}{sec.employmentYoY}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Investment Index:</span>
                        <span className="text-slate-200 font-bold">{sec.investmentIndex}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {activeView === "opportunities" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Option 1: Green energy */}
          <div className="bg-slate-950/60 border border-slate-800/60 p-5 rounded-lg flex flex-col justify-between">
            <div className="space-y-3">
              <div className="bg-emerald-500/15 border border-emerald-500/30 p-2.5 rounded-lg w-10 h-10 flex items-center justify-center text-emerald-400">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <h4 className="font-serif text-lg font-bold text-slate-100">Green Industrial Transition Credits</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Rhino Bank has earmarked **£120M** in specialized green bonds targeting Offshore Wind supply chain logistics in Hull port corridors, biomass energy conversions in Selby, and carbon-free advanced forging mills in Sheffield.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-900 text-[10px] font-mono flex items-center justify-between text-emerald-400">
              <span className="font-bold">Lending Bonification: -50bps</span>
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          {/* Option 2: Export finance */}
          <div className="bg-slate-950/60 border border-slate-800/60 p-5 rounded-lg flex flex-col justify-between">
            <div className="space-y-3">
              <div className="bg-copper/15 border border-copper/30 p-2.5 rounded-lg w-10 h-10 flex items-center justify-center text-copper">
                <Coins className="w-5 h-5" />
              </div>
              <h4 className="font-serif text-lg font-bold text-slate-100">Bespoke SME Export Credit Line</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Supporting Yorkshire high-value textiles and gear-box engineering exports to European and North American markets. Integrates with the Department for Business & Trade guarantees to reduce commercial debt-service-coverage thresholds.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-900 text-[10px] font-mono flex items-center justify-between text-copper">
              <span className="font-bold">Target Portfolio Size: £85M</span>
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          {/* Option 3: Infrastructure */}
          <div className="bg-slate-950/60 border border-slate-800/60 p-5 rounded-lg flex flex-col justify-between">
            <div className="space-y-3">
              <div className="bg-blue-500/15 border border-blue-500/30 p-2.5 rounded-lg w-10 h-10 flex items-center justify-center text-blue-400">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h4 className="font-serif text-lg font-bold text-slate-100">Humber Hydrogen Infrastructure</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Syndicated capital facilities for hydrogen distribution corridors and carbon-capture pipeline networks along the Humber corridor, in joint partnership with Yorkshire municipal combined authorities and private developers.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-900 text-[10px] font-mono flex items-center justify-between text-blue-400">
              <span className="font-bold">Syndicated Cap: £450M</span>
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
