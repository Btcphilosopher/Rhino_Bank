export enum County {
  WEST_YORKSHIRE = "West Yorkshire",
  SOUTH_YORKSHIRE = "South Yorkshire",
  NORTH_YORKSHIRE = "North Yorkshire",
  EAST_RIDING_HUMBER = "East Riding & Humber"
}

export interface Subregion {
  id: string;
  name: string;
  county: County;
  coordinates: [number, number]; // [lat, lng] for GIS plotting
  description: string;
  specialtySectors: string[];
}

export interface Indicator {
  id: string;
  name: string;
  category: "Core Activity" | "Labor" | "Investment & Business" | "Logistics" | "Financial";
  unit: string;
  description: string;
  defaultWeight: number; // Percentage (sum to 100)
}

export interface MonthlyDataPoint {
  date: string; // YYYY-MM
  county: string | "Yorkshire-wide";
  subregionId?: string;
  sectorId?: string;
  values: { [indicatorId: string]: number }; // Normalized indicator values (e.g., index base 100 in 2018 or percentage change)
}

export interface CompositeIndexConfig {
  weights: { [indicatorId: string]: number };
}

export interface EconometricMetrics {
  correlationMatrix: { [indicatorId: string]: { [indicatorId: string]: number } };
  seasonalTrend: {
    date: string;
    actual: number;
    trend: number;
    seasonal: number;
    random: number;
  }[];
  pcaWeights: { indicatorId: string; indicatorName: string; loading: number }[];
}

export enum ForecastScenario {
  BASELINE = "Baseline Trend",
  GREEN_TRANSITION = "Green Industrial Transition (+1.5% Peak)",
  TRADE_FRICTION = "High Trade Friction (-2.1% Impact)",
  CREDIT_CRUNCH = "Liquidity Squeeze (-1.8% Capital Impact)"
}

export interface ForecastPoint {
  date: string;
  historical: boolean;
  actual?: number;
  forecast: number;
  upper95: number;
  lower95: number;
}

export interface SectorPerformance {
  id: string;
  name: string;
  weight: number;
  outputGrowth: number; // YoY percentage change
  employmentYoY: number;
  pmiValue: number; // Purchasing Managers Index style
  investmentIndex: number;
}

export interface BankingExposurePoint {
  id: string;
  sectorName: string;
  exposureAmountMln: number; // in GBP Millions
  nonPerformingLoansRatio: number; // percentage
  creditRatingDistribution: {
    AAA_A: number; // percentage
    BBB_BB: number;
    B_CCC: number;
  };
  capitalAllocatedMln: number;
}

export interface ExecutiveReport {
  id: string;
  title: string;
  date: string;
  author: string;
  executiveSummary: string;
  economicOutlook: string;
  riskAssessment: string;
  creditRecommendations: string;
  htmlContent: string;
}
