"""
RhinoQuant Reference Implementation: Cox-Ross-Rubinstein Binomial Tree
Supports American early exercise and European baseline comparison.
"""

import math
from typing import Literal

def price_crr_binomial(
    spot: float,
    strike: float,
    expiry_years: float,
    rate: float,
    dividend_yield: float,
    volatility: float,
    option_type: Literal['CALL', 'PUT'],
    exercise_style: Literal['EUROPEAN', 'AMERICAN'] = 'AMERICAN',
    steps: int = 100
) -> float:
    if expiry_years <= 0:
        return max(0.0, spot - strike) if option_type == 'CALL' else max(0.0, strike - spot)

    dt = expiry_years / steps
    u = math.exp(volatility * math.sqrt(dt))
    d = 1.0 / u
    df = math.exp(-rate * dt)
    p = (math.exp((rate - dividend_yield) * dt) - d) / (u - d)

    # Terminal payoffs
    values = [0.0] * (steps + 1)
    for j in range(steps + 1):
        st = spot * (u ** j) * (d ** (steps - j))
        values[j] = max(0.0, st - strike) if option_type == 'CALL' else max(0.0, strike - st)

    # Backward induction
    for i in range(steps - 1, -1, -1):
        for j in range(i + 1):
            continuation = df * (p * values[j + 1] + (1.0 - p) * values[j])
            if exercise_style == 'AMERICAN':
                current_spot = spot * (u ** j) * (d ** (i - j))
                intrinsic = max(0.0, current_spot - strike) if option_type == 'CALL' else max(0.0, strike - current_spot)
                values[j] = max(continuation, intrinsic)
            else:
                values[j] = continuation

    return values[0]
