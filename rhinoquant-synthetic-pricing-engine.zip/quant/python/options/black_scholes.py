"""
RhinoQuant Reference Implementation: Black-Scholes-Merton and Greeks
Python 3.12+ Reference Model
"""

import math
from dataclasses import dataclass
from typing import Literal

@dataclass(frozen=True)
class OptionGreeks:
    delta: float
    gamma: float
    vega: float      # per 1% vol move (0.01 * raw vega)
    theta: float     # per calendar day (raw theta / 365.0)
    rho: float       # per 1% rate move (0.01 * raw rho)
    vanna: float
    volga: float

@dataclass(frozen=True)
class BsmPricingResult:
    price: float
    intrinsic: float
    time_value: float
    greeks: OptionGreeks

def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)

def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

def price_black_scholes_merton(
    spot: float,
    strike: float,
    expiry_years: float,
    rate: float,
    dividend_yield: float,
    volatility: float,
    option_type: Literal['CALL', 'PUT']
) -> BsmPricingResult:
    """
    Computes European option price and analytical Greeks under continuous dividend yield.
    """
    if spot <= 0 or strike <= 0 or volatility < 0 or expiry_years < 0:
        raise ValueError(f"Invalid inputs: S={spot}, K={strike}, vol={volatility}, T={expiry_years}")

    if expiry_years <= 1e-9:
        intr = max(0.0, spot - strike) if option_type == 'CALL' else max(0.0, strike - spot)
        return BsmPricingResult(
            price=intr,
            intrinsic=intr,
            time_value=0.0,
            greeks=OptionGreeks(
                delta=1.0 if (option_type == 'CALL' and spot > strike) else (
                    -1.0 if (option_type == 'PUT' and spot < strike) else 0.0
                ),
                gamma=0.0,
                vega=0.0,
                theta=0.0,
                rho=0.0,
                vanna=0.0,
                volga=0.0
            )
        )

    sqrt_t = math.sqrt(expiry_years)
    d1 = (math.log(spot / strike) + (rate - dividend_yield + 0.5 * volatility * volatility) * expiry_years) / (volatility * sqrt_t)
    d2 = d1 - volatility * sqrt_t

    df_r = math.exp(-rate * expiry_years)
    df_q = math.exp(-dividend_yield * expiry_years)

    if option_type == 'CALL':
        price = spot * df_q * _norm_cdf(d1) - strike * df_r * _norm_cdf(d2)
        delta = df_q * _norm_cdf(d1)
        raw_theta = -(spot * df_q * _norm_pdf(d1) * volatility) / (2.0 * sqrt_t) + dividend_yield * spot * df_q * _norm_cdf(d1) - rate * strike * df_r * _norm_cdf(d2)
        raw_rho = strike * expiry_years * df_r * _norm_cdf(d2)
        intrinsic = max(0.0, spot - strike)
    else:
        price = strike * df_r * _norm_cdf(-d2) - spot * df_q * _norm_cdf(-d1)
        delta = -df_q * _norm_cdf(-d1)
        raw_theta = -(spot * df_q * _norm_pdf(d1) * volatility) / (2.0 * sqrt_t) - dividend_yield * spot * df_q * _norm_cdf(-d1) + rate * strike * df_r * _norm_cdf(-d2)
        raw_rho = -strike * expiry_years * df_r * _norm_cdf(-d2)
        intrinsic = max(0.0, strike - spot)

    gamma = (df_q * _norm_pdf(d1)) / (spot * volatility * sqrt_t)
    raw_vega = spot * df_q * _norm_pdf(d1) * sqrt_t
    vega = 0.01 * raw_vega
    theta = raw_theta / 365.0
    rho = 0.01 * raw_rho
    vanna = -df_q * _norm_pdf(d1) * (d2 / volatility)
    volga = raw_vega * (d1 * d2 / volatility)

    return BsmPricingResult(
        price=price,
        intrinsic=intrinsic,
        time_value=max(0.0, price - intrinsic),
        greeks=OptionGreeks(
            delta=delta,
            gamma=gamma,
            vega=vega,
            theta=theta,
            rho=rho,
            vanna=vanna,
            volga=volga
        )
    )
