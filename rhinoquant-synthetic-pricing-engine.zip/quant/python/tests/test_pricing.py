"""
Pytest Verification Suite for RhinoQuant Python Reference Models
"""

import math
import pytest
from quant.python.options.black_scholes import price_black_scholes_merton
from quant.python.options.binomial import price_crr_binomial

def test_hull_atm_benchmark():
    # Hull 10th Ed Chapter 15: S=100, K=100, T=1, r=0.05, q=0, vol=0.20
    res = price_black_scholes_merton(100.0, 100.0, 1.0, 0.05, 0.0, 0.20, 'CALL')
    assert math.isclose(res.price, 10.45058, abs_tol=1e-4)
    assert math.isclose(res.greeks.delta, 0.63683, abs_tol=1e-4)

def test_put_call_parity():
    s, k, t, r, q, v = 150.0, 140.0, 0.5, 0.04, 0.015, 0.28
    c = price_black_scholes_merton(s, k, t, r, q, v, 'CALL').price
    p = price_black_scholes_merton(s, k, t, r, q, v, 'PUT').price
    lhs = c - p
    rhs = s * math.exp(-q * t) - k * math.exp(-r * t)
    assert math.isclose(lhs, rhs, abs_tol=1e-9)

def test_american_put_early_exercise():
    # Deep ITM Put: early exercise premium must be strictly positive
    eur = price_black_scholes_merton(80.0, 100.0, 1.0, 0.10, 0.0, 0.20, 'PUT').price
    am = price_crr_binomial(80.0, 100.0, 1.0, 0.10, 0.0, 0.20, 'PUT', exercise_style='AMERICAN', steps=150)
    assert am >= 20.0
    assert am > eur
