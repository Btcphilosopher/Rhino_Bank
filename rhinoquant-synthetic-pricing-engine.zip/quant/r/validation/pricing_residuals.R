# RhinoQuant Institutional Validation Layer
# Independent R script for pricing residual diagnostics, heteroskedasticity testing, and bootstrap

suppressPackageStartupMessages({
  # Standard statistical validation routines
})

analyze_pricing_residuals <- function(market_mid, model_price, bid_ask_spread) {
  residuals <- market_mid - model_price
  scaled_residuals <- residuals / (0.5 * bid_ask_spread)
  
  mean_res <- mean(residuals, na.rm = TRUE)
  sd_res <- sd(residuals, na.rm = TRUE)
  rmse <- sqrt(mean(residuals^2, na.rm = TRUE))
  
  # Shapiro-Wilk test for normality of pricing errors
  norm_test <- if(length(residuals) >= 3 && length(residuals) <= 5000) shapiro.test(residuals) else list(p.value = NA)
  
  # Quantiles
  q <- quantile(residuals, probs = c(0.01, 0.05, 0.50, 0.95, 0.99), na.rm = TRUE)
  
  cat("=== RhinoQuant Quantitative Residual Report ===\n")
  cat(sprintf("Count: %d\n", length(residuals)))
  cat(sprintf("Mean Residual: %0.6f\n", mean_res))
  cat(sprintf("Std Dev:       %0.6f\n", sd_res))
  cat(sprintf("RMSE:          %0.6f\n", rmse))
  cat(sprintf("95%% VaR Spread: %0.6f to %0.6f\n", q[2], q[4]))
  
  return(invisible(list(
    residuals = residuals,
    scaled_residuals = scaled_residuals,
    rmse = rmse,
    shapiro_p = norm_test$p.value
  )))
}
