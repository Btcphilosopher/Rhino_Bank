use std::f64::consts::PI;
use crate::types::{BsmPricingRequest, BsmPricingResponse, Greeks, OptionType};

const INV_SQRT_2PI: f64 = 0.3989422804014327;

#[inline]
pub fn normal_pdf(x: f64) -> f64 {
    INV_SQRT_2PI * (-0.5 * x * x).exp()
}

/// Abramowitz & Stegun high precision polynomial CDF approximation
pub fn normal_cdf(x: f64) -> f64 {
    if x < -8.0 {
        return 0.0;
    }
    if x > 8.0 {
        return 1.0;
    }

    let b1 = 0.319381530;
    let b2 = -0.356563782;
    let b3 = 1.781477937;
    let b4 = -1.821255978;
    let b5 = 1.330274429;
    let p = 0.2316419;

    let sign = if x < 0.0 { -1.0 } else { 1.0 };
    let abs_x = x.abs();
    let t = 1.0 / (1.0 + p * abs_x);
    let poly = ((((b5 * t + b4) * t + b3) * t + b2) * t + b1) * t;
    let cdf = 1.0 - normal_pdf(abs_x) * poly;

    if sign < 0.0 { 1.0 - cdf } else { cdf }
}

pub fn price_bsm_deterministic(req: &BsmPricingRequest) -> Result<BsmPricingResponse, &'static str> {
    if req.spot <= 0.0 || req.strike <= 0.0 || req.volatility < 0.0 || req.expiry_years < 0.0 {
        return Err("Invalid inputs: spot, strike, vol, and expiry must be non-negative");
    }

    let start = std::time::Instant::now();

    if req.expiry_years <= 1e-9 {
        let intrinsic = match req.option_type {
            OptionType::Call => (req.spot - req.strike).max(0.0),
            OptionType::Put => (req.strike - req.spot).max(0.0),
        };
        return Ok(BsmPricingResponse {
            theoretical_price: intrinsic,
            intrinsic_value: intrinsic,
            time_value: 0.0,
            greeks: Greeks {
                delta: if req.option_type == OptionType::Call && req.spot > req.strike { 1.0 } else { 0.0 },
                gamma: 0.0,
                vega: 0.0,
                theta: 0.0,
                rho: 0.0,
            },
            model_version: "Rust-BSM-1.0-Deterministic",
            execution_micros: start.elapsed().as_micros() as u64,
        });
    }

    let sqrt_t = req.expiry_years.sqrt();
    let d1 = ((req.spot / req.strike).ln() + (req.risk_free_rate - req.dividend_yield + 0.5 * req.volatility * req.volatility) * req.expiry_years) / (req.volatility * sqrt_t);
    let d2 = d1 - req.volatility * sqrt_t;

    let df_r = (-req.risk_free_rate * req.expiry_years).exp();
    let df_q = (-req.dividend_yield * req.expiry_years).exp();

    let (price, delta, raw_theta, raw_rho, intrinsic) = match req.option_type {
        OptionType::Call => {
            let p = req.spot * df_q * normal_cdf(d1) - req.strike * df_r * normal_cdf(d2);
            let d = df_q * normal_cdf(d1);
            let th = -(req.spot * df_q * normal_pdf(d1) * req.volatility) / (2.0 * sqrt_t)
                + req.dividend_yield * req.spot * df_q * normal_cdf(d1)
                - req.risk_free_rate * req.strike * df_r * normal_cdf(d2);
            let rh = req.strike * req.expiry_years * df_r * normal_cdf(d2);
            let intr = (req.spot - req.strike).max(0.0);
            (p, d, th, rh, intr)
        }
        OptionType::Put => {
            let p = req.strike * df_r * normal_cdf(-d2) - req.spot * df_q * normal_cdf(-d1);
            let d = -df_q * normal_cdf(-d1);
            let th = -(req.spot * df_q * normal_pdf(d1) * req.volatility) / (2.0 * sqrt_t)
                - req.dividend_yield * req.spot * df_q * normal_cdf(-d1)
                + req.risk_free_rate * req.strike * df_r * normal_cdf(-d2);
            let rh = -req.strike * req.expiry_years * df_r * normal_cdf(-d2);
            let intr = (req.strike - req.spot).max(0.0);
            (p, d, th, rh, intr)
        }
    };

    let gamma = (df_q * normal_pdf(d1)) / (req.spot * req.volatility * sqrt_t);
    let raw_vega = req.spot * df_q * normal_pdf(d1) * sqrt_t;

    Ok(BsmPricingResponse {
        theoretical_price: price,
        intrinsic_value: intrinsic,
        time_value: (price - intrinsic).max(0.0),
        greeks: Greeks {
            delta,
            gamma,
            vega: 0.01 * raw_vega,
            theta: raw_theta / 365.0,
            rho: 0.01 * raw_rho,
        },
        model_version: "Rust-BSM-1.0-Deterministic",
        execution_micros: start.elapsed().as_micros() as u64,
    })
}
