use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OptionType {
    Call,
    Put,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ExerciseStyle {
    European,
    American,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BsmPricingRequest {
    pub spot: f64,
    pub strike: f64,
    pub expiry_years: f64,
    pub risk_free_rate: f64,
    pub dividend_yield: f64,
    pub volatility: f64,
    pub option_type: OptionType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Greeks {
    pub delta: f64,
    pub gamma: f64,
    pub vega: f64,
    pub theta: f64,
    pub rho: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BsmPricingResponse {
    pub theoretical_price: f64,
    pub intrinsic_value: f64,
    pub time_value: f64,
    pub greeks: Greeks,
    pub model_version: &'static str,
    pub execution_micros: u64,
}
