# RhinoQuant Financial and Numerical Conventions

## 1. Units and Rates
- **Interest Rates & Yields**: All rates are expressed as continuous or simple annual decimals. 4.5% is represented internally strictly as `0.0450`. No ambiguous percentage strings in numerical calculations.
- **Volatilities**: Annualized standard deviation in decimal form (`0.20` represents 20% annualized volatility).
- **Time to Expiry**: Represented in ACT/365 or ACT/360 day-count years ($T = \text{days} / 365.0$).
- **Greeks Conventions**:
  - **Delta**: $\frac{\partial V}{\partial S}$ (Dimensionless, e.g., $+0.584$).
  - **Gamma**: $\frac{\partial^2 V}{\partial S^2}$ (Per dollar change in spot per share).
  - **Vega**: Reported **per 1% move** in annualized volatility ($0.01 \times \frac{\partial V}{\partial \sigma}$).
  - **Theta**: Reported **per calendar day** ($\frac{1}{365} \times \frac{\partial V}{\partial t}$, typically negative).
  - **Rho**: Reported **per 1% move** (100 basis points) in risk-free interest rate ($0.01 \times \frac{\partial V}{\partial r}$).
  - **Vanna**: $\frac{\partial^2 V}{\partial S \partial \sigma}$.
  - **Volga**: $\frac{\partial^2 V}{\partial \sigma^2}$.

## 2. Multipliers & Exposure
- Equity options carry an explicit contract multiplier (typically 100 shares per contract).
- Net Notional Exposure = $\sum |\text{Quantity} \times \text{Multiplier} \times \text{Underlying Spot / Strike}|$.
- Initial Cash Outlay = $\sum \text{Position Sign} \times \text{Quantity} \times \text{Multiplier} \times \text{Price}$.

## 3. Calculation Provenance
- Every calculation produces a unique SHA-256 equivalent hash of all normalized input parameters.
- Re-executing any historical run with identical inputs yields mathematically identical results within float64 precision.
