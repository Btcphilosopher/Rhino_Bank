# RhinoQuant API Specification (v1)

### Standard Headers
- `Content-Type: application/json`
- `X-Rhino-Request-ID: <uuid>`

### Endpoints
1. `POST /api/v1/pricing/options`
   - Request: `{ spot, strike, timeToExpiryYears, riskFreeRate, dividendYield, volatility, optionType, modelName, exerciseStyle }`
   - Response: `{ theoreticalPrice, intrinsicValue, timeValue, greeks: {...}, diagnostics: {...}, calculationId, inputHash }`

2. `POST /api/v1/pricing/forwards`
   - Request: `{ spot, timeToExpiryYears, riskFreeRate, dividendYield, borrowCost, storageCost, convenienceYield }`
   - Response: `{ theoreticalForward, netCarryRate, carryCashFlow, components: {...} }`

3. `POST /api/v1/pricing/swaps`
   - Request: `{ notional, maturityYears, fixedRate, paymentFrequencyPerYear, payerOrReceiver, curveDiscountRates }`
   - Response: `{ parSwapRate, npv, annuity, dv01, keyRateDv01s, cashFlowSchedule: [...] }`

4. `POST /api/v1/pricing/synthetic`
   - Request: `{ legs: [...], spot, riskFreeRate, dividendYield, borrowCostBps }`
   - Response: `{ aggregateModelValue, netCashOutlay, netGreeks, breakEvenPoints, payoffProfile: [...] }`

5. `POST /api/v1/volatility/implied`
   - Request: `{ targetPrice, spot, strike, timeToExpiryYears, riskFreeRate, dividendYield, optionType }`
   - Response: `{ impliedVol, converged, iterations, error }`

6. `POST /api/v1/calibration/run`
   - Request: `{ observations: [...], forward, timeToExpiryYears, initialGuess }`
   - Response: `{ surfaceId, parameters, rmse, maxResidual, converged, arbitrageChecks: {...} }`

7. `POST /api/v1/scenarios/run`
   - Request: `{ legs, baseSpot, baseRate, baseDividend, baseVol, shock: {...} }`
   - Response: `{ scenarioSpot, fullRevaluationPnL, taylorApproxPnL, decomposition: {...} }`

8. `GET /api/v1/calculations/{calculation_id}`
   - Response: Full calculation provenance record with input hash and verification payload.

9. `GET /api/v1/market-data/{instrument_id}`
   - Response: Market snapshot, timestamp, staleness age, bids/asks, curve fixtures.

10. `GET /api/v1/health`
    - Response: `{ status: "HEALTHY", buildId: "rhino-v2026.10", activeEngines: ["BSM", "CRR", "MC", "SVI", "DCF"] }`
