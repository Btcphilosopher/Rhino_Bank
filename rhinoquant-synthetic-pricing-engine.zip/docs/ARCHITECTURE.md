# RhinoQuant System Architecture

## Monorepo Layout
```
rhinoquant-synthetic-pricing/
├── apps/
│   └── terminal/                # React / TypeScript Institutional Terminal
├── services/
│   ├── pricing-rust/            # Deterministic, high-throughput Rust pricing library
│   └── api/                     # Express & TypeScript API orchestration
├── quant/
│   ├── python/                  # Reference mathematical models (BSM, Binomial, MC, SVI)
│   ├── r/                       # Statistical validation, residual diagnostics, bootstrap
│   └── typescript/              # In-browser & Node.js quantitative calculation core
├── fixtures/                    # Deterministic market data snapshots & historical chains
├── docs/                        # Complete technical and quantitative specifications
└── tests/                       # Unit, property, benchmark, and cross-validation suites
```

## Calculation Provenance Invariant
All pricing calculations execute deterministically:
1. Input parameters are normalized and hashed via SHA-256 equivalent.
2. The calculation is stamped with software build ID, market snapshot ID, and UTC timestamp.
3. Provenance records are stored immutably in the calculation ledger.
4. The calculation can be retrieved at any point and re-executed, proving bit-level reproducibility.
