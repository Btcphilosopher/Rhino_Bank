# RhinoQuant Supported Quantitative Models

## 1. Black-Scholes-Merton (1973, Merton 1973)
- **Applicability**: European vanilla equity and index options with continuous dividend yield $q$.
- **Formulas**:
  $$d_1 = \frac{\ln(S/K) + (r - q + \frac{1}{2}\sigma^2)T}{\sigma \sqrt{T}}, \quad d_2 = d_1 - \sigma \sqrt{T}$$
  $$\text{Call} = S e^{-qT} N(d_1) - K e^{-rT} N(d_2)$$
  $$\text{Put} = K e^{-rT} N(-d_2) - S e^{-qT} N(-d_1)$$
- **Assumptions**: Lognormal asset prices, continuous trading, constant volatility and interest rates, no transaction costs in theoretical formulation.

## 2. Black-76 (1976)
- **Applicability**: European options on commodity futures, index futures, and forward contracts.
- **Formulas**:
  $$\text{Call} = e^{-rT} [F N(d_1) - K N(d_2)], \quad \text{Put} = e^{-rT} [K N(-d_2) - F N(-d_1)]$$

## 3. Binomial Tree (Cox-Ross-Rubinstein 1979)
- **Applicability**: American equity options with early exercise.
- **Formulation**: $u = e^{\sigma \sqrt{\Delta t}}$, $d = 1/u$, $p = \frac{e^{(r-q)\Delta t} - d}{u - d}$.
- **Backward induction**: $V_{i,j} = \max(\text{Continuation}, \text{Intrinsic})$.

## 4. Monte Carlo Simulation with Antithetic Variates
- **Applicability**: Path simulation, confidence interval estimation, sampling error diagnostics.
- **Convergence**: $O(1/\sqrt{N})$. Antithetic variate reduces variance by $\approx 50-70\%$ for monotonic payoffs.

## 5. Stochastic Volatility Inspired (SVI - Gatheral 2004)
- **Raw Parameterization**:
  $$w(k) = a + b \left(\rho (k - m) + \sqrt{(k - m)^2 + \sigma^2}\right)$$
  where $k = \ln(K/F)$ is log-moneyness.
- **Arbitrage Bounds**: $b \ge 0$, $|\rho| < 1$, $\sigma > 0$, $a + b \sigma \sqrt{1 - \rho^2} \ge 0$, $b(1 + |\rho|) \le 2$.

## 6. Interest Rate Swap & Discount Curve (DCF)
- **Discount Factor**: $P(0, T) = \exp(-r(T) T)$.
- **Par Swap Rate**: $R_{\text{par}} = \frac{1 - P(0, T_n)}{\sum_{i=1}^n \Delta t_i P(0, T_i)}$.
- **DV01**: Dollar value of a 1 basis point (0.0001) parallel shift in the zero curve.
