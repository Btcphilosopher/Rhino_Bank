/**
 * RhinoQuant Synthetic Pricing Engine
 * Institutional Quantitative Pricing Software
 */

import React, { useState } from 'react';
import { FIXTURE_SNAPSHOTS } from './quant/fixtures';
import { MarketDataSnapshot } from './quant/types';
import { Header } from './components/Header';
import { MarketDataBar } from './components/MarketDataBar';
import { PricingOverviewTab } from './components/PricingOverviewTab';
import { SyntheticBuilderTab } from './components/SyntheticBuilderTab';
import { OptionsWorkbenchTab } from './components/OptionsWorkbenchTab';
import { ForwardCarryTab } from './components/ForwardCarryTab';
import { RatesWorkbenchTab } from './components/RatesWorkbenchTab';
import { CalibrationTab } from './components/CalibrationTab';
import { RelativeValueTab } from './components/RelativeValueTab';
import { ScenarioLabTab } from './components/ScenarioLabTab';
import { PortfolioRiskTab } from './components/PortfolioRiskTab';
import { CalculationExplorerTab } from './components/CalculationExplorerTab';
import { TestSuiteTab } from './components/TestSuiteTab';
import { ProvenanceLedger } from './quant/audit';

export default function App() {
  const [activeSnapshot, setActiveSnapshot] = useState<MarketDataSnapshot>(FIXTURE_SNAPSHOTS.SPX);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const handleExportProvenance = () => {
    const ledger = ProvenanceLedger.getInstance();
    const records = ledger.getAllRecords();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(records, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `rhinoquant-audit-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setExportNotice(`Exported ${records.length} calculation records with SHA-256 hashes`);
    setTimeout(() => setExportNotice(null), 4000);
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-[#e2e8f0] flex flex-col font-sans">
      {/* Strict 3-zone Header */}
      <Header
        activeSnapshot={activeSnapshot}
        onSelectSnapshot={setActiveSnapshot}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onRunAudit={handleExportProvenance}
      />

      {/* Sub-header Market Data Bar */}
      <MarketDataBar snapshot={activeSnapshot} />

      {/* Export notification if triggered */}
      {exportNotice && (
        <div className="bg-sky-950/80 border-b border-sky-800 text-sky-300 px-6 py-2 text-xs font-mono flex items-center justify-between">
          <span>{exportNotice}</span>
          <button onClick={() => setExportNotice(null)} className="text-sky-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Mobile/Narrow tab bar (visible on < xl screens) */}
      <div className="xl:hidden flex overflow-x-auto gap-4 px-6 py-2.5 bg-[#0e1422] border-b border-slate-800 text-xs font-medium text-slate-400">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'synthetic', label: 'Synthetic Builder' },
          { id: 'options', label: 'Options' },
          { id: 'forward', label: 'Forward & Carry' },
          { id: 'rates', label: 'Rates & Swaps' },
          { id: 'calibration', label: 'Calibration' },
          { id: 'parity', label: 'Relative Value' },
          { id: 'scenarios', label: 'Scenario Lab' },
          { id: 'portfolio', label: 'Portfolio Risk' },
          { id: 'explorer', label: 'Audit Ledger' },
          { id: 'tests', label: 'Verification Suite' }
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`whitespace-nowrap pb-1 border-b-2 transition-colors ${
              activeTab === item.id ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent hover:text-slate-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Main Quantitative Workstation Viewport */}
      <main className="flex-1 max-w-[1520px] w-full mx-auto px-6 py-6">
        {activeTab === 'overview' && (
          <PricingOverviewTab
            snapshot={activeSnapshot}
            onNavigateTab={setActiveTab}
          />
        )}
        {activeTab === 'synthetic' && (
          <SyntheticBuilderTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'options' && (
          <OptionsWorkbenchTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'forward' && (
          <ForwardCarryTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'rates' && (
          <RatesWorkbenchTab />
        )}
        {activeTab === 'calibration' && (
          <CalibrationTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'parity' && (
          <RelativeValueTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'scenarios' && (
          <ScenarioLabTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'portfolio' && (
          <PortfolioRiskTab
            snapshot={activeSnapshot}
          />
        )}
        {activeTab === 'explorer' && (
          <CalculationExplorerTab />
        )}
        {activeTab === 'tests' && (
          <TestSuiteTab />
        )}
      </main>

      {/* Institutional Legal & Provenance Footer */}
      <footer className="border-t border-slate-800 bg-[#080d16] px-6 py-4 text-xs text-slate-500">
        <div className="max-w-[1520px] mx-auto flex flex-wrap items-center justify-between gap-4 font-mono">
          <div className="flex flex-wrap items-center gap-3">
            <span>RhinoQuant Systems</span>
            <span aria-hidden="true">·</span>
            <span>Version 2026.10</span>
            <span aria-hidden="true">·</span>
            <span>Deterministic IEEE-754 Float64</span>
            <span aria-hidden="true">·</span>
            <span>ACT/365 & 30/360 Conforming</span>
          </div>
          <div className="text-[11px] text-slate-500">
            Theoretical valuation does not guarantee execution liquidity or zero-arbitrage fill.
          </div>
        </div>
      </footer>
    </div>
  );
}
