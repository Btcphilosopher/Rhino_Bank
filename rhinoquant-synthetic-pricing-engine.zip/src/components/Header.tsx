import React from 'react';
import { MarketDataSnapshot } from '../quant/types';
import { FIXTURE_SNAPSHOTS } from '../quant/fixtures';

interface HeaderProps {
  activeSnapshot: MarketDataSnapshot;
  onSelectSnapshot: (snap: MarketDataSnapshot) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onRunAudit: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSnapshot,
  onSelectSnapshot,
  activeTab,
  onSelectTab,
  onRunAudit
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-slate-800 bg-[#0e1422] select-none">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); onSelectTab('overview'); }}
          className="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap hover:text-sky-400 transition-colors"
        >
          RhinoQuant Synthetic Pricing
        </a>
      </div>

      {/* Zone 2: Concise single-line text navigation links */}
      <nav className="hidden xl:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => onSelectTab('overview')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'overview' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => onSelectTab('synthetic')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'synthetic' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Synthetic Builder
        </button>
        <button
          onClick={() => onSelectTab('options')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'options' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Options Workbench
        </button>
        <button
          onClick={() => onSelectTab('forward')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'forward' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Forward & Carry
        </button>
        <button
          onClick={() => onSelectTab('rates')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'rates' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Rates & Swaps
        </button>
        <button
          onClick={() => onSelectTab('calibration')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'calibration' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Calibration
        </button>
        <button
          onClick={() => onSelectTab('parity')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'parity' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Relative Value
        </button>
        <button
          onClick={() => onSelectTab('scenarios')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'scenarios' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Scenario Lab
        </button>
        <button
          onClick={() => onSelectTab('portfolio')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'portfolio' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Portfolio Risk
        </button>
        <button
          onClick={() => onSelectTab('explorer')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'explorer' ? 'text-sky-400 border-sky-400 font-semibold' : 'border-transparent'
          }`}
        >
          Audit Ledger
        </button>
        <button
          onClick={() => onSelectTab('tests')}
          className={`hover:text-slate-200 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
            activeTab === 'tests' ? 'text-emerald-400 border-emerald-400 font-semibold' : 'border-transparent'
          }`}
        >
          Verification Suite
        </button>
      </nav>

      {/* Zone 3: Market Snapshot selector and primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <label className="text-xs text-slate-400 hidden sm:inline">Feed Snapshot:</label>
        <select
          value={activeSnapshot.underlyingSymbol}
          onChange={(e) => {
            const sym = e.target.value;
            const target = FIXTURE_SNAPSHOTS[sym] || activeSnapshot;
            onSelectSnapshot(target);
          }}
          className="bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded px-2.5 py-1.5 focus:border-sky-500 focus:outline-none"
        >
          <option value="SPX">SPX (S&P 500 · 5820.50)</option>
          <option value="AAPL">AAPL (Equity · 232.40)</option>
          <option value="EURUSD">EUR/USD (FX · 1.0850)</option>
          <option value="WTI">WTI Crude (Stale Fixture · 78.40)</option>
        </select>
        
        <button
          onClick={onRunAudit}
          className="px-3 py-1.5 text-xs font-medium text-slate-900 bg-sky-400 rounded hover:bg-sky-300 transition-colors whitespace-nowrap shrink-0"
        >
          Export Provenance
        </button>
      </div>
    </header>
  );
};
