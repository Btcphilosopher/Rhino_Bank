import React, { useState } from 'react';
import { MarketDataSnapshot } from '../quant/types';
import { generateOptionsChain } from '../quant/fixtures';
import { analyzePutCallParity } from '../quant/engine';

interface RelativeValueTabProps {
  snapshot: MarketDataSnapshot;
}

export const RelativeValueTab: React.FC<RelativeValueTabProps> = ({ snapshot }) => {
  const [expiryDays, setExpiryDays] = useState<number>(45);
  const [borrowBps, setBorrowBps] = useState<number>(snapshot.borrowCostBps);
  const [txFee, setTxFee] = useState<number>(0.05); // $0.05 per contract

  const spot = snapshot.spotPrice;
  const r = snapshot.riskFreeRate;
  const q = snapshot.dividendYield;

  const chain = generateOptionsChain(snapshot.underlyingSymbol, spot, r, q, expiryDays);
  const strikes = Array.from(new Set(chain.map(c => c.strike))).sort((a, b) => a - b);
  const [selectedK, setSelectedK] = useState<number>(strikes[Math.floor(strikes.length / 2)]);

  const focusCall = chain.find(c => c.strike === selectedK && c.optionType === 'CALL') || chain[0];
  const focusPut = chain.find(c => c.strike === selectedK && c.optionType === 'PUT') || chain[1];

  const parityAnalysis = analyzePutCallParity({
    spot,
    strike: selectedK,
    timeToExpiryYears: expiryDays / 365.0,
    riskFreeRate: r,
    dividendYield: q,
    callBid: focusCall.marketBid,
    callAsk: focusCall.marketAsk,
    putBid: focusPut.marketBid,
    putAsk: focusPut.marketAsk,
    borrowCostBps: borrowBps,
    transactionFeePerLeg: txFee
  });

  return (
    <div className="space-y-6">
      {/* Parameter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Tenor Expiry:</label>
            <select
              value={expiryDays}
              onChange={(e) => setExpiryDays(parseInt(e.target.value))}
              className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-100"
            >
              <option value={14}>14 Days</option>
              <option value={30}>30 Days</option>
              <option value={45}>45 Days</option>
              <option value={90}>90 Days</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Focus Strike:</label>
            <select
              value={selectedK}
              onChange={(e) => setSelectedK(parseFloat(e.target.value))}
              className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-bold"
            >
              {strikes.map(k => (
                <option key={k} value={k}>Strike {k.toFixed(2)}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Borrow Cost (bps):</label>
            <input
              type="number"
              step="5"
              value={borrowBps}
              onChange={(e) => setBorrowBps(parseFloat(e.target.value) || 0)}
              className="w-24 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Transaction Fee / Leg ($):</label>
            <input
              type="number"
              step="0.01"
              value={txFee}
              onChange={(e) => setTxFee(parseFloat(e.target.value) || 0)}
              className="w-24 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100"
            />
          </div>
        </div>

        <div className="text-xs text-slate-400">
          Classification: <strong className="text-sky-400 font-semibold">{parityAnalysis.isExecutableArbitrage ? 'Executable Arbitrage Opportunity' : 'Parity Residual within Bid/Ask Friction'}</strong>
        </div>
      </div>

      {/* Main Parity Decomposition Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Diagnostic Metrics */}
        <div className="lg:col-span-6 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-semibold text-slate-200">Put-Call Parity Identity Breakdown</h2>
            <span className="text-xs font-mono text-slate-400">
              C - P = S·e^(-qT) - K·e^(-rT)
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Call Market Quote (Bid / Ask / Mid):</span>
              <span className="text-slate-200 font-semibold">
                ${parityAnalysis.callBid.toFixed(2)} / ${parityAnalysis.callAsk.toFixed(2)} (${parityAnalysis.callMid.toFixed(2)})
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Put Market Quote (Bid / Ask / Mid):</span>
              <span className="text-slate-200 font-semibold">
                ${parityAnalysis.putBid.toFixed(2)} / ${parityAnalysis.putAsk.toFixed(2)} (${parityAnalysis.putMid.toFixed(2)})
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Observed Option Differential (C - P):</span>
              <span className="text-slate-100 font-bold">
                ${(parityAnalysis.callMid - parityAnalysis.putMid).toFixed(4)}
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Discounted Strike K·e^(-rT):</span>
              <span className="text-slate-200 font-semibold">
                ${parityAnalysis.discountedStrike.toFixed(4)}
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Dividend-Discounted Spot S·e^(-qT):</span>
              <span className="text-slate-200 font-semibold">
                ${(spot * Math.exp(-q * (expiryDays / 365.0))).toFixed(4)}
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Theoretical Differential:</span>
              <span className="text-slate-200 font-semibold">
                ${(spot * Math.exp(-q * (expiryDays / 365.0)) - parityAnalysis.discountedStrike).toFixed(4)}
              </span>
            </div>

            <div className="flex justify-between py-1.5 pt-2">
              <span className="text-slate-300 font-semibold">Net Parity Residual:</span>
              <span className={`font-bold text-sm ${Math.abs(parityAnalysis.parityResidual) > 0.5 ? 'text-amber-400' : 'text-slate-100'}`}>
                {parityAnalysis.parityResidual >= 0 ? '+' : ''}${parityAnalysis.parityResidual.toFixed(4)}
              </span>
            </div>
          </div>
        </div>

        {/* Right Col: Executable Analysis with Bid/Ask and Frictions */}
        <div className="lg:col-span-6 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-semibold text-slate-200">Execution Realism & Frictions</h2>
            <span className={`text-xs font-mono font-semibold ${parityAnalysis.isExecutableArbitrage ? 'text-emerald-400' : 'text-slate-400'}`}>
              Arbitrage: {parityAnalysis.arbitrageDirection}
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Synthetic Forward Bid (Sell side):</span>
              <span className="text-slate-200">${parityAnalysis.syntheticForwardBid.toFixed(2)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Synthetic Forward Ask (Buy side):</span>
              <span className="text-slate-200">${parityAnalysis.syntheticForwardAsk.toFixed(2)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Theoretical Forward Price:</span>
              <span className="text-sky-400 font-semibold">${parityAnalysis.theoreticalForward.toFixed(2)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Implied Financing Rate:</span>
              <span className="text-slate-200">{(parityAnalysis.impliedFinancingRate * 100).toFixed(3)}% (vs SOFR {(r * 100).toFixed(2)}%)</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Borrow Cost Impact:</span>
              <span className="text-amber-400">-${parityAnalysis.borrowFeeImpact.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Transaction Fees (3 Legs):</span>
              <span className="text-amber-400">-${(3 * txFee).toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 pt-2">
              <span className="text-slate-300 font-semibold">Net Executable P&L After Frictions:</span>
              <span className={`font-bold text-sm ${parityAnalysis.netExecutableMarginAfterCosts > 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                {parityAnalysis.netExecutableMarginAfterCosts > 0 ? '+' : ''}${parityAnalysis.netExecutableMarginAfterCosts.toFixed(4)}
              </span>
            </div>
          </div>

          <div className="p-3 bg-[#080d16] rounded border border-slate-800 text-[11px] text-slate-400">
            <strong className="text-slate-200 block mb-1">Institutional Boundary Notice:</strong>
            Theoretical equivalence never guarantees executable arbitrage. An apparent mid-price discrepancy of ${(Math.abs(parityAnalysis.parityResidual)).toFixed(2)} is completely absorbed by bid-ask spreads, borrow financing drag (${parityAnalysis.borrowFeeImpact.toFixed(2)}), and execution fees.
          </div>
        </div>
      </div>
    </div>
  );
};
