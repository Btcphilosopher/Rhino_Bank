import React, { useState } from 'react';
import { MarketDataSnapshot, SVIParameters } from '../quant/types';
import { generateOptionsChain } from '../quant/fixtures';
import { calibrateSviSlice, rawSviImpliedVol, validateSviArbitrage } from '../quant/engine';

interface CalibrationTabProps {
  snapshot: MarketDataSnapshot;
}

export const CalibrationTab: React.FC<CalibrationTabProps> = ({ snapshot }) => {
  const spot = snapshot.spotPrice;
  const r = snapshot.riskFreeRate;
  const q = snapshot.dividendYield;
  const T = 45 / 365.0;
  const forward = spot * Math.exp((r - q) * T);

  // Observations from market options chain
  const chain = generateOptionsChain(snapshot.underlyingSymbol, spot, r, q, 45);
  const observations = chain
    .filter(c => c.optionType === 'CALL')
    .map(c => ({ strike: c.strike, marketIv: c.impliedVolMid }));

  // SVI Parameter inputs
  const [params, setParams] = useState<SVIParameters>({
    a: 0.04,
    b: 0.12,
    rho: -0.35,
    m: 0.0,
    sigma: 0.15
  });

  const [calibratedCalibration, setCalibratedCalibration] = useState<any>(null);
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);

  // Run SVI Calibration
  const runCalibration = () => {
    setIsCalibrating(true);
    setTimeout(() => {
      const calib = calibrateSviSlice(observations, forward, T, params);
      setParams(calib.parameters);
      setCalibratedCalibration(calib);
      setIsCalibrating(false);
    }, 150);
  };

  // Evaluate current SVI slice
  const testLogMoneyness = observations.map(o => Math.log(o.strike / forward));
  const arbCheck = validateSviArbitrage(params, testLogMoneyness);

  // SVG Chart: Fitted SVI Curve vs Market Observed Points
  const svgWidth = 640;
  const svgHeight = 220;
  const pad = { top: 20, right: 30, bottom: 40, left: 50 };
  const chartW = svgWidth - pad.left - pad.right;
  const chartH = svgHeight - pad.top - pad.bottom;

  const minK = observations[0].strike;
  const maxK = observations[observations.length - 1].strike;

  // Generate dense SVI curve points
  const densePointsCount = 50;
  const sviCurvePoints: { strike: number; iv: number }[] = [];
  for (let i = 0; i <= densePointsCount; i++) {
    const kStrike = minK + (i / densePointsCount) * (maxK - minK);
    const logM = Math.log(kStrike / forward);
    const modelVol = rawSviImpliedVol(logM, T, params);
    sviCurvePoints.push({ strike: kStrike, iv: modelVol * 100 });
  }

  const allVols = [...sviCurvePoints.map(p => p.iv), ...observations.map(o => o.marketIv * 100)];
  const minVol = Math.min(...allVols) * 0.9;
  const maxVol = Math.max(...allVols) * 1.1;

  const getX = (k: number) => pad.left + ((k - minK) / (maxK - minK)) * chartW;
  const getY = (v: number) => pad.top + chartH - ((v - minVol) / (maxVol - minVol)) * chartH;

  const fittedSvgPath = sviCurvePoints.map(p => `${getX(p.strike).toFixed(1)},${getY(p.iv).toFixed(1)}`).join(' ');

  return (
    <div className="space-y-6">
      {/* Calibration Header & Run Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div>
          <h2 className="text-sm font-semibold text-slate-200">
            Raw SVI (Stochastic Volatility Inspired) Smile Calibration
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
            <span>Model: Gatheral Raw SVI</span>
            <span aria-hidden="true">·</span>
            <span>Slice Expiry: 45 Days (T = {T.toFixed(3)}y)</span>
            <span aria-hidden="true">·</span>
            <span>Forward F: ${forward.toFixed(2)}</span>
          </div>
        </div>

        <button
          onClick={runCalibration}
          disabled={isCalibrating}
          className="px-4 py-2 text-xs font-semibold text-slate-950 bg-sky-400 hover:bg-sky-300 rounded transition-colors whitespace-nowrap disabled:opacity-50"
        >
          {isCalibrating ? 'Optimizing Parameters...' : 'Calibrate to Market Quotes'}
        </button>
      </div>

      {/* Main Grid: Parameters vs Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Parameter Tuning Form */}
        <div className="lg:col-span-4 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-semibold text-slate-200">SVI Slice Parameters</h3>
            <span className={`text-xs font-mono font-medium ${arbCheck.isValid ? 'text-emerald-400' : 'text-red-400'}`}>
              {arbCheck.isValid ? 'Arb-Free' : 'Arb Warning'}
            </span>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>a (base variance level)</span>
                <span className="text-slate-200">{params.a.toFixed(4)}</span>
              </div>
              <input
                type="number"
                step="0.005"
                value={params.a}
                onChange={(e) => setParams({ ...params, a: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>b (asymptote angle, b ≥ 0)</span>
                <span className="text-slate-200">{params.b.toFixed(4)}</span>
              </div>
              <input
                type="number"
                step="0.01"
                min="0"
                value={params.b}
                onChange={(e) => setParams({ ...params, b: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>ρ (skewness, |ρ| &lt; 1)</span>
                <span className="text-slate-200">{params.rho.toFixed(4)}</span>
              </div>
              <input
                type="number"
                step="0.02"
                min="-0.99"
                max="0.99"
                value={params.rho}
                onChange={(e) => setParams({ ...params, rho: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>m (translation/minimum moneyness)</span>
                <span className="text-slate-200">{params.m.toFixed(4)}</span>
              </div>
              <input
                type="number"
                step="0.01"
                value={params.m}
                onChange={(e) => setParams({ ...params, m: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>σ (smoothing parameter, σ &gt; 0)</span>
                <span className="text-slate-200">{params.sigma.toFixed(4)}</span>
              </div>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={params.sigma}
                onChange={(e) => setParams({ ...params, sigma: parseFloat(e.target.value) || 0.01 })}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Arbitrage Diagnostics List */}
          <div className="p-3 bg-[#080d16] rounded border border-slate-800 text-[11px] font-mono space-y-1">
            <span className="text-slate-400 block font-semibold mb-1">Arbitrage Invariants:</span>
            <div className="flex justify-between text-slate-300">
              <span>Positive Variance:</span>
              <span className={arbCheck.positiveVariance ? 'text-emerald-400' : 'text-red-400'}>
                {arbCheck.positiveVariance ? 'PASS' : 'FAIL'}
              </span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Roger Lee Slope Bound:</span>
              <span className={arbCheck.slopeBounds ? 'text-emerald-400' : 'text-red-400'}>
                {arbCheck.slopeBounds ? 'PASS' : 'FAIL'}
              </span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Parameter Bounds:</span>
              <span className={arbCheck.parameterBounds ? 'text-emerald-400' : 'text-red-400'}>
                {arbCheck.parameterBounds ? 'PASS' : 'FAIL'}
              </span>
            </div>
          </div>
        </div>

        {/* Right Col: Fitted Curve SVG and Residuals */}
        <div className="lg:col-span-8 space-y-6">
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">SVI Fit vs Market Observations</h3>
                <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span>
                    <span>Market Mid Quotes</span>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-3 h-0.5 bg-sky-400 inline-block"></span>
                    <span>Fitted SVI Curve</span>
                  </span>
                </div>
              </div>

              {calibratedCalibration && (
                <div className="text-right font-mono text-xs">
                  <span className="text-slate-400 block">Fit Quality (RMSE)</span>
                  <span className="text-slate-100 font-semibold text-sm">
                    {(calibratedCalibration.rmse * 100).toFixed(3)}%
                  </span>
                </div>
              )}
            </div>

            {/* SVG Plot */}
            <div className="w-full overflow-x-auto bg-[#080d16] p-2 rounded border border-slate-800">
              <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-48 font-mono text-[10px]">
                {/* Fitted SVI Polyline */}
                <polyline fill="none" stroke="#38bdf8" strokeWidth="2.2" points={fittedSvgPath} />

                {/* Market Quote Markers */}
                {observations.map((obs, idx) => (
                  <circle
                    key={idx}
                    cx={getX(obs.strike)}
                    cy={getY(obs.marketIv * 100)}
                    r="4"
                    fill="#f59e0b"
                  />
                ))}

                {/* Axes */}
                <text x={pad.left} y={svgHeight - pad.bottom + 16} fill="#64748b">{minK}</text>
                <text x={getX(forward)} y={svgHeight - pad.bottom + 16} fill="#94a3b8" textAnchor="middle">ATM {forward.toFixed(0)}</text>
                <text x={svgWidth - pad.right} y={svgHeight - pad.bottom + 16} fill="#64748b" textAnchor="end">{maxK}</text>
                <text x={pad.left - 6} y={pad.top + 8} fill="#64748b" textAnchor="end">{maxVol.toFixed(1)}%</text>
                <text x={pad.left - 6} y={svgHeight - pad.bottom} fill="#64748b" textAnchor="end">{minVol.toFixed(1)}%</text>
              </svg>
            </div>
          </div>

          {/* Calibration Residuals Table */}
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <h3 className="text-sm font-semibold text-slate-200 mb-3">Strike-by-Strike Residual Diagnostics</h3>
            <div className="overflow-x-auto max-h-52 overflow-y-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 sticky top-0 bg-[#0e1422]">
                    <th className="py-2 px-3">Strike</th>
                    <th className="py-2 px-3">Log-Moneyness ln(K/F)</th>
                    <th className="py-2 px-3 text-right">Market IV</th>
                    <th className="py-2 px-3 text-right">Model SVI IV</th>
                    <th className="py-2 px-3 text-right">Residual (bps)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {observations.map((obs) => {
                    const k = Math.log(obs.strike / forward);
                    const modelVol = rawSviImpliedVol(k, T, params);
                    const resBps = (modelVol - obs.marketIv) * 10000;
                    return (
                      <tr key={obs.strike} className="hover:bg-slate-900/40">
                        <td className="py-1.5 px-3 text-slate-200 font-semibold">{obs.strike.toFixed(2)}</td>
                        <td className="py-1.5 px-3 text-slate-400">{k.toFixed(4)}</td>
                        <td className="py-1.5 px-3 text-right text-amber-400">{(obs.marketIv * 100).toFixed(2)}%</td>
                        <td className="py-1.5 px-3 text-right text-sky-400">{(modelVol * 100).toFixed(2)}%</td>
                        <td className={`py-1.5 px-3 text-right font-medium ${Math.abs(resBps) < 50 ? 'text-emerald-400' : 'text-slate-300'}`}>
                          {resBps >= 0 ? '+' : ''}{resBps.toFixed(1)} bps
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
