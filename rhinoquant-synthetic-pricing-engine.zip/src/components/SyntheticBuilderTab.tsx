import React, { useState } from 'react';
import { MarketDataSnapshot, SyntheticLeg, PositionDirection, OptionType, InstrumentType } from '../quant/types';
import { calculateBsm, evaluateSyntheticPortfolio } from '../quant/engine';

interface SyntheticBuilderTabProps {
  snapshot: MarketDataSnapshot;
}

export const SyntheticBuilderTab: React.FC<SyntheticBuilderTabProps> = ({ snapshot }) => {
  const spot = snapshot.spotPrice;
  const r = snapshot.riskFreeRate;
  const q = snapshot.dividendYield;
  const borrowBps = snapshot.borrowCostBps;

  // Initialize with a Synthetic Long Stock structure: Long ATM Call + Short ATM Put
  const atmStrike = Math.round(spot / 10) * 10;
  const initCall = calculateBsm({ spot, strike: atmStrike, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: 0.18, optionType: 'CALL' });
  const initPut = calculateBsm({ spot, strike: atmStrike, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: 0.18, optionType: 'PUT' });

  const [legs, setLegs] = useState<SyntheticLeg[]>([
    {
      id: 'leg-1',
      instrumentType: 'VANILLA_OPTION',
      direction: 'LONG',
      quantity: 1,
      multiplier: 100,
      description: `${snapshot.underlyingSymbol} 90D ${atmStrike} Call`,
      strike: atmStrike,
      optionType: 'CALL',
      expiryYears: 0.25,
      modelPrice: initCall.theoreticalPrice,
      marketBid: Number((initCall.theoreticalPrice - 0.25).toFixed(2)),
      marketAsk: Number((initCall.theoreticalPrice + 0.25).toFixed(2)),
      greeks: initCall.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    },
    {
      id: 'leg-2',
      instrumentType: 'VANILLA_OPTION',
      direction: 'SHORT',
      quantity: 1,
      multiplier: 100,
      description: `${snapshot.underlyingSymbol} 90D ${atmStrike} Put`,
      strike: atmStrike,
      optionType: 'PUT',
      expiryYears: 0.25,
      modelPrice: initPut.theoreticalPrice,
      marketBid: Number((initPut.theoreticalPrice - 0.25).toFixed(2)),
      marketAsk: Number((initPut.theoreticalPrice + 0.25).toFixed(2)),
      greeks: initPut.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    }
  ]);

  // Compute portfolio metrics
  const analysis = evaluateSyntheticPortfolio(legs, spot, r, q, borrowBps);

  // Strategy Template Loader
  const loadTemplate = (templateName: string) => {
    const k = Math.round(spot / 10) * 10;
    const kLow = k - 20;
    const kHigh = k + 20;
    const t = 0.25;
    const vol = 0.18;

    const cMid = calculateBsm({ spot, strike: k, timeToExpiryYears: t, riskFreeRate: r, dividendYield: q, volatility: vol, optionType: 'CALL' });
    const pMid = calculateBsm({ spot, strike: k, timeToExpiryYears: t, riskFreeRate: r, dividendYield: q, volatility: vol, optionType: 'PUT' });
    const cHigh = calculateBsm({ spot, strike: kHigh, timeToExpiryYears: t, riskFreeRate: r, dividendYield: q, volatility: vol, optionType: 'CALL' });
    const pLow = calculateBsm({ spot, strike: kLow, timeToExpiryYears: t, riskFreeRate: r, dividendYield: q, volatility: vol, optionType: 'PUT' });

    if (templateName === 'SYNTHETIC_LONG') {
      setLegs([
        {
          id: 'leg-' + Date.now() + '-1',
          instrumentType: 'VANILLA_OPTION',
          direction: 'LONG',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${k} Call (Long)`,
          strike: k,
          optionType: 'CALL',
          expiryYears: t,
          modelPrice: cMid.theoreticalPrice,
          marketBid: cMid.theoreticalPrice - 0.2,
          marketAsk: cMid.theoreticalPrice + 0.2,
          greeks: cMid.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        },
        {
          id: 'leg-' + Date.now() + '-2',
          instrumentType: 'VANILLA_OPTION',
          direction: 'SHORT',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${k} Put (Short)`,
          strike: k,
          optionType: 'PUT',
          expiryYears: t,
          modelPrice: pMid.theoreticalPrice,
          marketBid: pMid.theoreticalPrice - 0.2,
          marketAsk: pMid.theoreticalPrice + 0.2,
          greeks: pMid.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        }
      ]);
    } else if (templateName === 'CONVERSION_BOX') {
      setLegs([
        {
          id: 'leg-' + Date.now() + '-1',
          instrumentType: 'EQUITY_SPOT',
          direction: 'LONG',
          quantity: 100,
          multiplier: 1,
          description: `${snapshot.underlyingSymbol} Physical Spot`,
          modelPrice: spot,
          marketBid: spot - 0.05,
          marketAsk: spot + 0.05,
          greeks: { delta: 1, gamma: 0, vega: 0, rawVega: 0, theta: 0, rawTheta: 0, rho: 0, rawRho: 0 },
          financingCostAnnual: spot * (r + borrowBps / 10000),
          carryYieldAnnual: spot * q
        },
        {
          id: 'leg-' + Date.now() + '-2',
          instrumentType: 'VANILLA_OPTION',
          direction: 'SHORT',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${k} Call (Short)`,
          strike: k,
          optionType: 'CALL',
          expiryYears: t,
          modelPrice: cMid.theoreticalPrice,
          marketBid: cMid.theoreticalPrice - 0.2,
          marketAsk: cMid.theoreticalPrice + 0.2,
          greeks: cMid.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        },
        {
          id: 'leg-' + Date.now() + '-3',
          instrumentType: 'VANILLA_OPTION',
          direction: 'LONG',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${k} Put (Long)`,
          strike: k,
          optionType: 'PUT',
          expiryYears: t,
          modelPrice: pMid.theoreticalPrice,
          marketBid: pMid.theoreticalPrice - 0.2,
          marketAsk: pMid.theoreticalPrice + 0.2,
          greeks: pMid.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        }
      ]);
    } else if (templateName === 'COLLAR') {
      setLegs([
        {
          id: 'leg-' + Date.now() + '-1',
          instrumentType: 'EQUITY_SPOT',
          direction: 'LONG',
          quantity: 100,
          multiplier: 1,
          description: `${snapshot.underlyingSymbol} Physical Spot`,
          modelPrice: spot,
          marketBid: spot - 0.05,
          marketAsk: spot + 0.05,
          greeks: { delta: 1, gamma: 0, vega: 0, rawVega: 0, theta: 0, rawTheta: 0, rho: 0, rawRho: 0 },
          financingCostAnnual: spot * (r + borrowBps / 10000),
          carryYieldAnnual: spot * q
        },
        {
          id: 'leg-' + Date.now() + '-2',
          instrumentType: 'VANILLA_OPTION',
          direction: 'SHORT',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${kHigh} OTM Call (Short)`,
          strike: kHigh,
          optionType: 'CALL',
          expiryYears: t,
          modelPrice: cHigh.theoreticalPrice,
          marketBid: cHigh.theoreticalPrice - 0.2,
          marketAsk: cHigh.theoreticalPrice + 0.2,
          greeks: cHigh.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        },
        {
          id: 'leg-' + Date.now() + '-3',
          instrumentType: 'VANILLA_OPTION',
          direction: 'LONG',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${kLow} OTM Put (Long)`,
          strike: kLow,
          optionType: 'PUT',
          expiryYears: t,
          modelPrice: pLow.theoreticalPrice,
          marketBid: pLow.theoreticalPrice - 0.2,
          marketAsk: pLow.theoreticalPrice + 0.2,
          greeks: pLow.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        }
      ]);
    } else if (templateName === 'IRON_CONDOR') {
      setLegs([
        {
          id: 'leg-' + Date.now() + '-1',
          instrumentType: 'VANILLA_OPTION',
          direction: 'LONG',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${kLow - 10} Put (Long)`,
          strike: kLow - 10,
          optionType: 'PUT',
          expiryYears: t,
          modelPrice: pLow.theoreticalPrice * 0.6,
          greeks: pLow.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        },
        {
          id: 'leg-' + Date.now() + '-2',
          instrumentType: 'VANILLA_OPTION',
          direction: 'SHORT',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${kLow} Put (Short)`,
          strike: kLow,
          optionType: 'PUT',
          expiryYears: t,
          modelPrice: pLow.theoreticalPrice,
          greeks: pLow.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        },
        {
          id: 'leg-' + Date.now() + '-3',
          instrumentType: 'VANILLA_OPTION',
          direction: 'SHORT',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${kHigh} Call (Short)`,
          strike: kHigh,
          optionType: 'CALL',
          expiryYears: t,
          modelPrice: cHigh.theoreticalPrice,
          greeks: cHigh.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        },
        {
          id: 'leg-' + Date.now() + '-4',
          instrumentType: 'VANILLA_OPTION',
          direction: 'LONG',
          quantity: 1,
          multiplier: 100,
          description: `${snapshot.underlyingSymbol} ${kHigh + 10} Call (Long)`,
          strike: kHigh + 10,
          optionType: 'CALL',
          expiryYears: t,
          modelPrice: cHigh.theoreticalPrice * 0.6,
          greeks: cHigh.greeks,
          financingCostAnnual: 0,
          carryYieldAnnual: 0
        }
      ]);
    }
  };

  // Add Leg
  const addLeg = (type: InstrumentType) => {
    const k = Math.round(spot / 10) * 10;
    const bsm = calculateBsm({ spot, strike: k, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: 0.20, optionType: 'CALL' });
    const newLeg: SyntheticLeg = {
      id: 'leg-' + Date.now(),
      instrumentType: type,
      direction: 'LONG',
      quantity: 1,
      multiplier: type === 'EQUITY_SPOT' ? 1 : 100,
      description: type === 'EQUITY_SPOT' ? `${snapshot.underlyingSymbol} Spot Cash` : `${snapshot.underlyingSymbol} ${k} Call`,
      strike: type === 'EQUITY_SPOT' ? undefined : k,
      optionType: type === 'EQUITY_SPOT' ? undefined : 'CALL',
      expiryYears: type === 'EQUITY_SPOT' ? undefined : 0.25,
      modelPrice: type === 'EQUITY_SPOT' ? spot : bsm.theoreticalPrice,
      greeks: type === 'EQUITY_SPOT' ? { delta: 1, gamma: 0, vega: 0, rawVega: 0, theta: 0, rawTheta: 0, rho: 0, rawRho: 0 } : bsm.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    };
    setLegs([...legs, newLeg]);
  };

  const removeLeg = (id: string) => {
    setLegs(legs.filter(l => l.id !== id));
  };

  const updateLegDirection = (id: string, dir: PositionDirection) => {
    setLegs(legs.map(l => l.id === id ? { ...l, direction: dir } : l));
  };

  const updateLegQuantity = (id: string, qty: number) => {
    setLegs(legs.map(l => l.id === id ? { ...l, quantity: Math.max(1, qty) } : l));
  };

  // Render SVG Payoff Chart Coordinates
  const svgWidth = 720;
  const svgHeight = 260;
  const padding = { top: 20, right: 30, bottom: 40, left: 60 };
  const chartW = svgWidth - padding.left - padding.right;
  const chartH = svgHeight - padding.top - padding.bottom;

  const minSpotVal = analysis.payoffProfile[0]?.spot || spot * 0.5;
  const maxSpotVal = analysis.payoffProfile[analysis.payoffProfile.length - 1]?.spot || spot * 1.5;

  let minPnL = Math.min(0, ...analysis.payoffProfile.map(p => Math.min(p.expiryPayoff, p.intermediateValue)));
  let maxPnL = Math.max(0, ...analysis.payoffProfile.map(p => Math.max(p.expiryPayoff, p.intermediateValue)));
  if (Math.abs(maxPnL - minPnL) < 1) {
    maxPnL = 10;
    minPnL = -10;
  }
  const pnlSpan = maxPnL - minPnL;

  const getX = (s: number) => padding.left + ((s - minSpotVal) / (maxSpotVal - minSpotVal)) * chartW;
  const getY = (pnl: number) => padding.top + chartH - ((pnl - minPnL) / pnlSpan) * chartH;
  const zeroY = getY(0);

  // Path data strings
  const expiryPoints = analysis.payoffProfile.map(p => `${getX(p.spot).toFixed(1)},${getY(p.expiryPayoff).toFixed(1)}`).join(' ');
  const intermediatePoints = analysis.payoffProfile.map(p => `${getX(p.spot).toFixed(1)},${getY(p.intermediateValue).toFixed(1)}`).join(' ');

  return (
    <div className="space-y-6">
      {/* Top Banner: Strategy Templates & Summary Strip */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Replication Presets:</span>
          <button
            onClick={() => loadTemplate('SYNTHETIC_LONG')}
            className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-700 hover:border-sky-500 text-slate-200 rounded transition-colors"
          >
            Synthetic Long Stock
          </button>
          <button
            onClick={() => loadTemplate('CONVERSION_BOX')}
            className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-700 hover:border-sky-500 text-slate-200 rounded transition-colors"
          >
            Conversion Box Parity
          </button>
          <button
            onClick={() => loadTemplate('COLLAR')}
            className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-700 hover:border-sky-500 text-slate-200 rounded transition-colors"
          >
            Collar Structure
          </button>
          <button
            onClick={() => loadTemplate('IRON_CONDOR')}
            className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-700 hover:border-sky-500 text-slate-200 rounded transition-colors"
          >
            Iron Condor Range
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => addLeg('VANILLA_OPTION')}
            className="px-3 py-1 text-xs font-medium text-slate-100 bg-slate-800 border border-slate-700 hover:border-slate-600 rounded transition-colors"
          >
            + Option Leg
          </button>
          <button
            onClick={() => addLeg('EQUITY_SPOT')}
            className="px-3 py-1 text-xs font-medium text-slate-100 bg-slate-800 border border-slate-700 hover:border-slate-600 rounded transition-colors"
          >
            + Cash Spot Leg
          </button>
        </div>
      </div>

      {/* Synthetic Structure Payoff Curve */}
      <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">Economic Payoff & Scenario Curve</h2>
            <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-sky-400 inline-block"></span>
                <span>Terminal Expiry Payoff</span>
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-amber-400 border-b border-dashed inline-block"></span>
                <span>Intermediate Value (T/2)</span>
              </span>
              <span aria-hidden="true">·</span>
              <span>Break-Evens: {analysis.breakEvenPoints.length > 0 ? analysis.breakEvenPoints.join(', ') : 'None'}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-4 text-xs font-mono">
            <div>
              <span className="text-slate-400 block">Initial Outlay</span>
              <span className="text-slate-100 font-semibold text-sm">
                ${analysis.netCashOutlay.toFixed(2)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block">Underlying Exposure</span>
              <span className="text-slate-100 font-semibold text-sm">
                ${analysis.netNotionalExposure.toFixed(2)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block">Estimated SPAN Margin</span>
              <span className="text-amber-400 font-semibold text-sm">
                ${analysis.estimatedMarginRequirement.toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* SVG Curve */}
        <div className="w-full overflow-x-auto">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-64 font-mono text-[10px]">
            {/* Background grid */}
            <line x1={padding.left} y1={zeroY} x2={svgWidth - padding.right} y2={zeroY} stroke="#334155" strokeWidth="1" strokeDasharray="3 3" />
            <line x1={getX(spot)} y1={padding.top} x2={getX(spot)} y2={svgHeight - padding.bottom} stroke="#1e293b" strokeWidth="1" />
            
            {/* Current Spot Indicator */}
            <text x={getX(spot)} y={padding.top + 10} fill="#94a3b8" textAnchor="middle">Current S ({spot})</text>

            {/* Zero PnL label */}
            <text x={padding.left - 8} y={zeroY + 3} fill="#64748b" textAnchor="end">$0.00</text>
            <text x={padding.left - 8} y={padding.top + 10} fill="#64748b" textAnchor="end">+${maxPnL.toFixed(0)}</text>
            <text x={padding.left - 8} y={svgHeight - padding.bottom} fill="#64748b" textAnchor="end">${minPnL.toFixed(0)}</text>

            {/* Payoff Polyline */}
            <polyline fill="none" stroke="#38bdf8" strokeWidth="2.2" points={expiryPoints} />
            <polyline fill="none" stroke="#f59e0b" strokeWidth="1.6" strokeDasharray="4 4" points={intermediatePoints} />

            {/* Break-even point markers */}
            {analysis.breakEvenPoints.map((be, idx) => (
              <g key={idx}>
                <circle cx={getX(be)} cy={zeroY} r="4" fill="#38bdf8" />
                <text x={getX(be)} y={zeroY - 8} fill="#38bdf8" textAnchor="middle" fontWeight="bold">BE {be}</text>
              </g>
            ))}

            {/* X-axis labels */}
            <text x={padding.left} y={svgHeight - padding.bottom + 16} fill="#64748b">{minSpotVal.toFixed(0)}</text>
            <text x={getX(spot)} y={svgHeight - padding.bottom + 16} fill="#94a3b8" textAnchor="middle">{spot.toFixed(0)}</text>
            <text x={svgWidth - padding.right} y={svgHeight - padding.bottom + 16} fill="#64748b" textAnchor="end">{maxSpotVal.toFixed(0)}</text>
          </svg>
        </div>
      </div>

      {/* Position Legs Table */}
      <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-sm font-semibold text-slate-200">Replication Portfolio Legs ({legs.length})</h2>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <span>Net Delta: <strong className="text-slate-100">{analysis.netGreeks.delta.toFixed(2)}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Net Gamma: <strong className="text-slate-100">{analysis.netGreeks.gamma.toFixed(4)}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Net Vega: <strong className="text-slate-100">{analysis.netGreeks.vega.toFixed(2)}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Net Carry/Yr: <strong className={analysis.netAnnualCarry >= 0 ? 'text-emerald-400' : 'text-red-400'}>${analysis.netAnnualCarry.toFixed(2)}</strong></span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 font-medium">Instrument Description</th>
                <th className="py-2.5 px-3 font-medium">Direction</th>
                <th className="py-2.5 px-3 font-medium text-right">Quantity</th>
                <th className="py-2.5 px-3 font-medium text-right">Multiplier</th>
                <th className="py-2.5 px-3 font-medium text-right">Model Price</th>
                <th className="py-2.5 px-3 font-medium text-right">Leg Value</th>
                <th className="py-2.5 px-3 font-medium text-right">Delta</th>
                <th className="py-2.5 px-3 font-medium text-right">Vega</th>
                <th className="py-2.5 px-3 font-medium text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {legs.map((leg) => {
                const sign = leg.direction === 'LONG' ? 1 : -1;
                const legVal = sign * leg.quantity * leg.multiplier * leg.modelPrice;
                return (
                  <tr key={leg.id} className="hover:bg-slate-900/40">
                    <td className="py-2.5 px-3 text-slate-200 font-medium">
                      {leg.description}
                    </td>
                    <td className="py-2.5 px-3">
                      <select
                        value={leg.direction}
                        onChange={(e) => updateLegDirection(leg.id, e.target.value as PositionDirection)}
                        className={`bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-xs font-semibold ${
                          leg.direction === 'LONG' ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        <option value="LONG">LONG</option>
                        <option value="SHORT">SHORT</option>
                      </select>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <input
                        type="number"
                        min="1"
                        value={leg.quantity}
                        onChange={(e) => updateLegQuantity(leg.id, parseInt(e.target.value) || 1)}
                        className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right font-mono text-slate-100"
                      />
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{leg.multiplier}</td>
                    <td className="py-2.5 px-3 text-right text-slate-200">${leg.modelPrice.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right font-semibold text-slate-100">
                      ${legVal.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {(sign * leg.quantity * leg.multiplier * leg.greeks.delta).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {(sign * leg.quantity * leg.multiplier * leg.greeks.vega).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={() => removeLeg(leg.id)}
                        className="text-slate-500 hover:text-red-400 transition-colors"
                        title="Remove Leg"
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
