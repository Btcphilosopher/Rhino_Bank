import React from 'react';
import { MarketDataSnapshot } from '../quant/types';

interface MarketDataBarProps {
  snapshot: MarketDataSnapshot;
}

export const MarketDataBar: React.FC<MarketDataBarProps> = ({ snapshot }) => {
  return (
    <div className="flex flex-wrap items-center justify-between gap-y-2 gap-x-6 px-6 py-2.5 bg-[#080d16] border-b border-slate-800/80 text-xs text-slate-400">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 font-mono">
        <span className="font-semibold text-slate-100">{snapshot.underlyingSymbol}</span>
        <span aria-hidden="true">·</span>
        <span>
          Spot: <strong className="text-slate-100">{snapshot.spotPrice.toFixed(2)}</strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          Bid/Ask: {snapshot.spotBid.toFixed(2)} / {snapshot.spotAsk.toFixed(2)}
        </span>
        <span aria-hidden="true">·</span>
        <span>
          Spread: {(snapshot.spotAsk - snapshot.spotBid).toFixed(2)}
        </span>
        <span aria-hidden="true">·</span>
        <span>
          SOFR Rate: {(snapshot.riskFreeRate * 100).toFixed(2)}%
        </span>
        <span aria-hidden="true">·</span>
        <span>
          Div Yield: {(snapshot.dividendYield * 100).toFixed(2)}%
        </span>
        <span aria-hidden="true">·</span>
        <span>
          Borrow: {snapshot.borrowCostBps} bps
        </span>
      </div>

      <div className="flex items-center gap-3 text-xs">
        <span className="text-slate-500 font-mono">ID: {snapshot.snapshotId}</span>
        <span aria-hidden="true" className="text-slate-700">·</span>
        {snapshot.isStale ? (
          <span className="text-amber-400 font-medium">Stale Data Warning ({snapshot.stalenessAgeSec}s age)</span>
        ) : (
          <span className="text-slate-400 font-mono">Snapshot verified ({snapshot.stalenessAgeSec}s ago)</span>
        )}
      </div>
    </div>
  );
};
