import React, { useState } from 'react';
import { SOFR_ZERO_CURVE } from '../quant/fixtures';
import { calculateVanillaSwap } from '../quant/engine';

export const RatesWorkbenchTab: React.FC = () => {
  const [notional, setNotional] = useState<number>(10000000); // $10M
  const [maturityYears, setMaturityYears] = useState<number>(5.0);
  const [fixedRatePct, setFixedRatePct] = useState<number>(3.85);
  const [paymentFreq, setPaymentFreq] = useState<number>(2); // semi-annual
  const [direction, setDirection] = useState<'PAY_FIXED' | 'RECEIVE_FIXED'>('PAY_FIXED');

  const fixedRate = fixedRatePct / 100.0;

  const swapResult = calculateVanillaSwap({
    notional,
    maturityYears,
    fixedRate,
    paymentFrequencyPerYear: paymentFreq,
    curveDiscountRates: SOFR_ZERO_CURVE,
    payerOrReceiver: direction
  });

  // SVG Curve Dimensions
  const svgWidth = 640;
  const svgHeight = 180;
  const pad = { top: 15, right: 25, bottom: 35, left: 50 };
  const chartW = svgWidth - pad.left - pad.right;
  const chartH = svgHeight - pad.top - pad.bottom;

  const maxTenor = 30;
  const minZero = 0.035;
  const maxZero = 0.050;

  const getCurveX = (t: number) => pad.left + (t / maxTenor) * chartW;
  const getCurveY = (r: number) => pad.top + chartH - ((r - minZero) / (maxZero - minZero)) * chartH;

  const curvePoints = SOFR_ZERO_CURVE.map(n => `${getCurveX(n.tenor).toFixed(1)},${getCurveY(n.zeroRate).toFixed(1)}`).join(' ');

  return (
    <div className="space-y-6">
      {/* Top Banner: SOFR Zero Curve & Term Structure */}
      <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">SOFR Benchmark Zero & Par Swap Curve</h2>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span>Day-Count: ACT/360 Money Market & 30/360 Swap</span>
              <span aria-hidden="true">·</span>
              <span>Interpolation: Monotone Piecewise Linear</span>
            </div>
          </div>
          <div className="text-xs font-mono text-slate-400">
            Source: <strong className="text-slate-200">OIS Fed Funds / SOFR Strip</strong>
          </div>
        </div>

        {/* SVG Zero Curve Display */}
        <div className="w-full overflow-x-auto bg-[#080d16] p-2 rounded border border-slate-800">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-36 font-mono text-[10px]">
            {/* Grid lines */}
            <line x1={pad.left} y1={getCurveY(0.040)} x2={svgWidth - pad.right} y2={getCurveY(0.040)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            <text x={pad.left - 6} y={getCurveY(0.040) + 3} fill="#64748b" textAnchor="end">4.00%</text>

            <line x1={pad.left} y1={getCurveY(0.045)} x2={svgWidth - pad.right} y2={getCurveY(0.045)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            <text x={pad.left - 6} y={getCurveY(0.045) + 3} fill="#64748b" textAnchor="end">4.50%</text>

            {/* Zero Curve Line */}
            <polyline fill="none" stroke="#38bdf8" strokeWidth="2.2" points={curvePoints} />

            {/* Curve Nodes */}
            {SOFR_ZERO_CURVE.map((node, i) => (
              <circle
                key={i}
                cx={getCurveX(node.tenor)}
                cy={getCurveY(node.zeroRate)}
                r="3"
                fill="#38bdf8"
              />
            ))}

            {/* X Axis */}
            <text x={pad.left} y={svgHeight - pad.bottom + 14} fill="#64748b">0Y</text>
            <text x={getCurveX(5)} y={svgHeight - pad.bottom + 14} fill="#94a3b8" textAnchor="middle">5Y</text>
            <text x={getCurveX(10)} y={svgHeight - pad.bottom + 14} fill="#94a3b8" textAnchor="middle">10Y</text>
            <text x={getCurveX(20)} y={svgHeight - pad.bottom + 14} fill="#94a3b8" textAnchor="middle">20Y</text>
            <text x={svgWidth - pad.right} y={svgHeight - pad.bottom + 14} fill="#64748b" textAnchor="end">30Y</text>
          </svg>
        </div>
      </div>

      {/* Vanilla Interest Rate Swap Config & Valuation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Swap Definition */}
        <div className="lg:col-span-5 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-3">
            Vanilla Interest Rate Swap Specification
          </h2>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Swap Notional (USD)</label>
              <input
                type="number"
                step="500000"
                value={notional}
                onChange={(e) => setNotional(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Maturity (Years)</label>
                <select
                  value={maturityYears}
                  onChange={(e) => setMaturityYears(parseFloat(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100"
                >
                  <option value={1.0}>1 Year</option>
                  <option value={2.0}>2 Years</option>
                  <option value={3.0}>3 Years</option>
                  <option value={5.0}>5 Years</option>
                  <option value={7.0}>7 Years</option>
                  <option value={10.0}>10 Years</option>
                  <option value={30.0}>30 Years</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Payment Frequency</label>
                <select
                  value={paymentFreq}
                  onChange={(e) => setPaymentFreq(parseInt(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100"
                >
                  <option value={2}>Semi-Annual (2/yr)</option>
                  <option value={4}>Quarterly (4/yr)</option>
                  <option value={1}>Annual (1/yr)</option>
                </select>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Fixed Leg Coupon (%)</span>
                <button
                  onClick={() => setFixedRatePct(Number((swapResult.parSwapRate * 100).toFixed(4)))}
                  className="text-sky-400 hover:underline"
                >
                  Set to Par Rate ({(swapResult.parSwapRate * 100).toFixed(3)}%)
                </button>
              </div>
              <input
                type="number"
                step="0.01"
                value={fixedRatePct}
                onChange={(e) => setFixedRatePct(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Position Direction</label>
              <div className="flex bg-slate-900 border border-slate-700 rounded p-0.5">
                <button
                  onClick={() => setDirection('PAY_FIXED')}
                  className={`flex-1 py-1 font-medium transition-colors rounded ${
                    direction === 'PAY_FIXED' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Pay Fixed / Receive Float
                </button>
                <button
                  onClick={() => setDirection('RECEIVE_FIXED')}
                  className={`flex-1 py-1 font-medium transition-colors rounded ${
                    direction === 'RECEIVE_FIXED' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Receive Fixed / Pay Float
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Valuation & Sensitivities */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">DCF Swap Mark-to-Market Valuation</h3>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                  <span>Par Swap Rate: {(swapResult.parSwapRate * 100).toFixed(4)}%</span>
                  <span aria-hidden="true">·</span>
                  <span>Annuity: {swapResult.annuity.toFixed(4)}</span>
                </div>
              </div>
              <div className="text-right font-mono">
                <span className="text-xs text-slate-400">Swap Net Present Value (NPV)</span>
                <p className={`text-2xl font-bold ${swapResult.npv >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {swapResult.npv >= 0 ? '+' : ''}${swapResult.npv.toFixed(2)}
                </p>
              </div>
            </div>

            {/* DV01 Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 font-mono text-xs">
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Total DV01 (1bp)</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  ${swapResult.dv01.toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500">Parallel shift</span>
              </div>
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Key-Rate 2Y DV01</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  ${(swapResult.keyRateDv01s[2] || 0).toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500">Short tenor</span>
              </div>
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Key-Rate 5Y DV01</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  ${(swapResult.keyRateDv01s[5] || 0).toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500">Mid tenor</span>
              </div>
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Key-Rate 10Y DV01</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  ${(swapResult.keyRateDv01s[10] || 0).toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500">Long tenor</span>
              </div>
            </div>
          </div>

          {/* Cash Flow Schedule Table */}
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <h3 className="text-sm font-semibold text-slate-200 mb-3">Projected Cash Flow Schedule</h3>
            <div className="overflow-x-auto max-h-56 overflow-y-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 sticky top-0 bg-[#0e1422]">
                    <th className="py-2 px-2.5">Period</th>
                    <th className="py-2 px-2.5">Time (Y)</th>
                    <th className="py-2 px-2.5 text-right">Discount Factor</th>
                    <th className="py-2 px-2.5 text-right">Fixed Cash Flow</th>
                    <th className="py-2 px-2.5 text-right">Forward Rate</th>
                    <th className="py-2 px-2.5 text-right">Floating Cash Flow</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {swapResult.cashFlowSchedule.map((cf) => (
                    <tr key={cf.period} className="hover:bg-slate-900/40">
                      <td className="py-1.5 px-2.5 text-slate-300 font-semibold">#{cf.period}</td>
                      <td className="py-1.5 px-2.5 text-slate-400">{cf.paymentTime.toFixed(2)}y</td>
                      <td className="py-1.5 px-2.5 text-right text-slate-200">{cf.discountFactor.toFixed(5)}</td>
                      <td className="py-1.5 px-2.5 text-right text-slate-300">${cf.fixedCashFlow.toFixed(2)}</td>
                      <td className="py-1.5 px-2.5 text-right text-sky-400">{(cf.impliedForwardRate * 100).toFixed(3)}%</td>
                      <td className="py-1.5 px-2.5 text-right text-slate-300">${cf.floatingCashFlow.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
