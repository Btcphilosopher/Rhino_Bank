import React, { useState } from 'react';
import { MarketDataSnapshot, OptionType, PricingResult } from '../quant/types';
import { calculateBsm, calculateBinomialTree, calculateMonteCarlo } from '../quant/engine';
import { computeInputHash, ProvenanceLedger } from '../quant/audit';

interface PricingOverviewTabProps {
  snapshot: MarketDataSnapshot;
  onNavigateTab: (tab: string) => void;
}

export const PricingOverviewTab: React.FC<PricingOverviewTabProps> = ({ snapshot, onNavigateTab }) => {
  const [spot, setSpot] = useState<number>(snapshot.spotPrice);
  const [strike, setStrike] = useState<number>(Math.round(snapshot.spotPrice));
  const [expiryDays, setExpiryDays] = useState<number>(45);
  const [volatilityPct, setVolatilityPct] = useState<number>(18.5);
  const [ratePct, setRatePct] = useState<number>(snapshot.riskFreeRate * 100);
  const [divPct, setDivPct] = useState<number>(snapshot.dividendYield * 100);
  const [optionType, setOptionType] = useState<OptionType>('CALL');
  const [modelType, setModelType] = useState<'BSM' | 'CRR' | 'MC'>('BSM');

  const T = Math.max(0.0001, expiryDays / 365.0);
  const r = ratePct / 100.0;
  const q = divPct / 100.0;
  const sigma = volatilityPct / 100.0;

  // Run selected model
  let pricingRes: PricingResult;
  if (modelType === 'CRR') {
    pricingRes = calculateBinomialTree({
      spot,
      strike,
      timeToExpiryYears: T,
      riskFreeRate: r,
      dividendYield: q,
      volatility: sigma,
      optionType,
      exerciseStyle: 'AMERICAN',
      steps: 100
    });
  } else if (modelType === 'MC') {
    pricingRes = calculateMonteCarlo({
      spot,
      strike,
      timeToExpiryYears: T,
      riskFreeRate: r,
      dividendYield: q,
      volatility: sigma,
      optionType,
      numSimulations: 25000
    });
  } else {
    pricingRes = calculateBsm({
      spot,
      strike,
      timeToExpiryYears: T,
      riskFreeRate: r,
      dividendYield: q,
      volatility: sigma,
      optionType
    });
  }

  // Cross-model evaluation for comparison table
  const bsmComp = calculateBsm({ spot, strike, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: sigma, optionType });
  const crrComp = calculateBinomialTree({ spot, strike, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: sigma, optionType, exerciseStyle: 'EUROPEAN', steps: 100 });
  const mcComp = calculateMonteCarlo({ spot, strike, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: sigma, optionType, numSimulations: 25000 });

  // Record into provenance ledger
  const inputPayload = { spot, strike, T, r, q, sigma, optionType, modelType };
  const inputHash = computeInputHash(inputPayload);

  return (
    <div className="space-y-6">
      {/* Platform Executive Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div>
          <span className="text-xs text-slate-400">Calculation Engine</span>
          <p className="text-sm font-semibold text-slate-100 mt-1">RhinoQuant Core v3.12</p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono">Build ID: 0x8f4c2e · Deterministic</p>
        </div>
        <div>
          <span className="text-xs text-slate-400">Active Market Snapshot</span>
          <p className="text-sm font-semibold text-slate-100 mt-1">{snapshot.underlyingSymbol} · {snapshot.currency}</p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono">{snapshot.snapshotId}</p>
        </div>
        <div>
          <span className="text-xs text-slate-400">Valuation Precision</span>
          <p className="text-sm font-semibold text-slate-100 mt-1">Float64 Analytic & CRR</p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono">Tolerance: 1.0e-10</p>
        </div>
        <div>
          <span className="text-xs text-slate-400">Audit Status</span>
          <p className="text-sm font-semibold text-emerald-400 mt-1">Verified Invariant Hash</p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono">{inputHash}</p>
        </div>
      </div>

      {/* Main Single Contract Pricer & Cross Model Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Parameter Input Controls */}
        <div className="lg:col-span-4 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-semibold text-slate-200">Contract Valuation Inputs</h2>
            <div className="flex bg-slate-900 p-0.5 rounded border border-slate-700">
              <button
                onClick={() => setOptionType('CALL')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                  optionType === 'CALL' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Call
              </button>
              <button
                onClick={() => setOptionType('PUT')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                  optionType === 'PUT' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Put
              </button>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Spot Price (S)</span>
                <span className="font-mono text-slate-200">{spot.toFixed(2)}</span>
              </div>
              <input
                type="number"
                step="0.5"
                value={spot}
                onChange={(e) => setSpot(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Strike Price (K)</span>
                <span className="font-mono text-slate-200">{strike.toFixed(2)}</span>
              </div>
              <input
                type="number"
                step="1.0"
                value={strike}
                onChange={(e) => setStrike(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Expiry (Days)</label>
                <input
                  type="number"
                  min="1"
                  max="730"
                  value={expiryDays}
                  onChange={(e) => setExpiryDays(parseInt(e.target.value) || 1)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Volatility (%)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.5"
                  max="200"
                  value={volatilityPct}
                  onChange={(e) => setVolatilityPct(parseFloat(e.target.value) || 0.1)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Risk-Free Rate (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={ratePct}
                  onChange={(e) => setRatePct(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Dividend Yield (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={divPct}
                  onChange={(e) => setDivPct(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Pricing Model Architecture</label>
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:border-sky-500 focus:outline-none"
              >
                <option value="BSM">Black-Scholes-Merton (Analytic Closed-Form)</option>
                <option value="CRR">Cox-Ross-Rubinstein Binomial (100 Steps American)</option>
                <option value="MC">Monte Carlo (25,000 Paths Antithetic)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Right Col: Valuation Output & Greeks Grid */}
        <div className="lg:col-span-8 space-y-6">
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-200">Theoretical Valuation & Decomposition</h2>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                  <span>Model: {pricingRes.modelName}</span>
                  <span aria-hidden="true">·</span>
                  <span>Execution: {pricingRes.diagnostics.executionTimeMs.toFixed(3)} ms</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400">Theoretical Price</span>
                <p className="text-2xl font-bold font-mono text-slate-100">
                  ${pricingRes.theoreticalPrice.toFixed(4)}
                </p>
              </div>
            </div>

            {/* Value Breakdown */}
            <div className="grid grid-cols-3 gap-4 mt-4 pt-1 border-b border-slate-800/60 pb-4 font-mono text-xs">
              <div>
                <span className="text-slate-400 block">Intrinsic Value</span>
                <span className="text-slate-200 font-semibold text-sm">${pricingRes.intrinsicValue.toFixed(4)}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Time Value</span>
                <span className="text-slate-200 font-semibold text-sm">${pricingRes.timeValue.toFixed(4)}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Moneyness (K/S)</span>
                <span className="text-slate-200 font-semibold text-sm">{(strike / spot).toFixed(4)}</span>
              </div>
            </div>

            {/* Greeks Display */}
            <div className="mt-4">
              <span className="text-xs font-semibold text-slate-300 block mb-3">Analytical Sensitivities (Greeks)</span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono text-xs">
                <div className="bg-[#080d16] p-3 rounded border border-slate-800/80">
                  <span className="text-slate-400 block">Delta (dV/dS)</span>
                  <span className="text-slate-100 font-semibold text-sm mt-0.5 block">{pricingRes.greeks.delta.toFixed(4)}</span>
                  <span className="text-[10px] text-slate-500">Per $1.00 move</span>
                </div>
                <div className="bg-[#080d16] p-3 rounded border border-slate-800/80">
                  <span className="text-slate-400 block">Gamma (d²V/dS²)</span>
                  <span className="text-slate-100 font-semibold text-sm mt-0.5 block">{pricingRes.greeks.gamma.toFixed(5)}</span>
                  <span className="text-[10px] text-slate-500">Curvature</span>
                </div>
                <div className="bg-[#080d16] p-3 rounded border border-slate-800/80">
                  <span className="text-slate-400 block">Vega (dV/dσ)</span>
                  <span className="text-slate-100 font-semibold text-sm mt-0.5 block">{pricingRes.greeks.vega.toFixed(4)}</span>
                  <span className="text-[10px] text-slate-500">Per 1% vol change</span>
                </div>
                <div className="bg-[#080d16] p-3 rounded border border-slate-800/80">
                  <span className="text-slate-400 block">Theta (dV/dt)</span>
                  <span className={`font-semibold text-sm mt-0.5 block ${pricingRes.greeks.theta < 0 ? 'text-red-400' : 'text-slate-100'}`}>
                    {pricingRes.greeks.theta.toFixed(4)}
                  </span>
                  <span className="text-[10px] text-slate-500">Per calendar day</span>
                </div>
                <div className="bg-[#080d16] p-3 rounded border border-slate-800/80">
                  <span className="text-slate-400 block">Rho (dV/dr)</span>
                  <span className="text-slate-100 font-semibold text-sm mt-0.5 block">{pricingRes.greeks.rho.toFixed(4)}</span>
                  <span className="text-[10px] text-slate-500">Per 100 bps shift</span>
                </div>
              </div>
            </div>
          </div>

          {/* Model Comparison Table */}
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <h3 className="text-sm font-semibold text-slate-200 mb-3">Model Cross-Validation & Benchmark Comparison</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2 px-3 font-medium">Model Architecture</th>
                    <th className="py-2 px-3 font-medium text-right">Price</th>
                    <th className="py-2 px-3 font-medium text-right">Delta</th>
                    <th className="py-2 px-3 font-medium text-right">Vega (1%)</th>
                    <th className="py-2 px-3 font-medium text-right">Delta vs BSM</th>
                    <th className="py-2 px-3 font-medium text-right">Runtime</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  <tr className="hover:bg-slate-900/40">
                    <td className="py-2 px-3 text-slate-200">Black-Scholes-Merton (Analytic)</td>
                    <td className="py-2 px-3 text-right text-slate-100 font-semibold">${bsmComp.theoreticalPrice.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{bsmComp.greeks.delta.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{bsmComp.greeks.vega.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-500">Reference</td>
                    <td className="py-2 px-3 text-right text-slate-400">{bsmComp.diagnostics.executionTimeMs.toFixed(3)} ms</td>
                  </tr>
                  <tr className="hover:bg-slate-900/40">
                    <td className="py-2 px-3 text-slate-200">Cox-Ross-Rubinstein Tree (N=100)</td>
                    <td className="py-2 px-3 text-right text-slate-100 font-semibold">${crrComp.theoreticalPrice.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{crrComp.greeks.delta.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{crrComp.greeks.vega.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-400">
                      {(crrComp.theoreticalPrice - bsmComp.theoreticalPrice).toFixed(4)}
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400">{crrComp.diagnostics.executionTimeMs.toFixed(3)} ms</td>
                  </tr>
                  <tr className="hover:bg-slate-900/40">
                    <td className="py-2 px-3 text-slate-200">Monte Carlo Antithetic (M=25,000)</td>
                    <td className="py-2 px-3 text-right text-slate-100 font-semibold">${mcComp.theoreticalPrice.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{mcComp.greeks.delta.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-300">{mcComp.greeks.vega.toFixed(4)}</td>
                    <td className="py-2 px-3 text-right text-slate-400">
                      {(mcComp.theoreticalPrice - bsmComp.theoreticalPrice).toFixed(4)} (SE: {mcComp.diagnostics.standardError?.toFixed(4)})
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400">{mcComp.diagnostics.executionTimeMs.toFixed(3)} ms</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
