import React, { useState } from 'react';
import { runQuantitativeTestSuite, TestResultItem } from '../quant/tests';

export const TestSuiteTab: React.FC = () => {
  const [suiteResult, setSuiteResult] = useState(() => runQuantitativeTestSuite());
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const reRunSuite = () => {
    setIsRunning(true);
    setTimeout(() => {
      setSuiteResult(runQuantitativeTestSuite());
      setIsRunning(false);
    }, 150);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Execution Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div>
          <h2 className="text-sm font-semibold text-slate-200">
            Independent Mathematical Verification & Benchmark Suite
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 font-mono">
            <span>Tests: {suiteResult.totalCount} Cases</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-semibold">{suiteResult.passCount} Passed</span>
            <span aria-hidden="true">·</span>
            <span className={suiteResult.failCount === 0 ? 'text-slate-400' : 'text-red-400 font-semibold'}>
              {suiteResult.failCount} Failed
            </span>
            <span aria-hidden="true">·</span>
            <span>Total Runtime: {suiteResult.totalDurationMs.toFixed(3)} ms</span>
          </div>
        </div>

        <button
          onClick={reRunSuite}
          disabled={isRunning}
          className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors whitespace-nowrap disabled:opacity-50"
        >
          {isRunning ? 'Executing Test Kernels...' : 'Re-Run All Verification Tests'}
        </button>
      </div>

      {/* Test Results Table */}
      <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">Execution Test Ledger</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3">Test Case ID</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Benchmark Name & Specification</th>
                <th className="py-2.5 px-3 text-right">Actual Calculated</th>
                <th className="py-2.5 px-3 text-right">Expected Benchmark</th>
                <th className="py-2.5 px-3 text-right">Tolerance</th>
                <th className="py-2.5 px-3 text-right">Runtime</th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {suiteResult.results.map((tc: TestResultItem) => (
                <tr key={tc.id} className="hover:bg-slate-900/40">
                  <td className="py-3 px-3 text-slate-200 font-bold">{tc.id}</td>
                  <td className="py-3 px-3 text-slate-400">{tc.category}</td>
                  <td className="py-3 px-3">
                    <span className="text-slate-200 font-semibold block">{tc.name}</span>
                    <span className="text-[11px] text-slate-500 block">{tc.description}</span>
                  </td>
                  <td className="py-3 px-3 text-right text-slate-100 font-semibold">{tc.actualValue}</td>
                  <td className="py-3 px-3 text-right text-slate-400">{tc.expectedValue}</td>
                  <td className="py-3 px-3 text-right text-slate-400">{tc.tolerance}</td>
                  <td className="py-3 px-3 text-right text-slate-400">{tc.durationMs.toFixed(3)} ms</td>
                  <td className="py-3 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      tc.passed ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' : 'bg-red-950/80 text-red-400 border border-red-800'
                    }`}>
                      {tc.passed ? 'PASS' : 'FAIL'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
