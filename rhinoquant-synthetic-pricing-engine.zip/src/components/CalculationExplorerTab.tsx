import React, { useState } from 'react';
import { CalculationRecord } from '../quant/types';
import { ProvenanceLedger } from '../quant/audit';
import { calculateBsm, calculateBinomialTree, calculateMonteCarlo } from '../quant/engine';

export const CalculationExplorerTab: React.FC = () => {
  const ledger = ProvenanceLedger.getInstance();
  const records = ledger.getAllRecords();

  const [selectedRecordId, setSelectedRecordId] = useState<string>(records[0]?.calculationId || '');
  const [reproductionStatus, setReproductionStatus] = useState<{
    tested: boolean;
    exactMatch: boolean;
    reproducedPrice?: number;
    delta?: number;
    message?: string;
  }>({ tested: false, exactMatch: false });

  const activeRecord = records.find(r => r.calculationId === selectedRecordId) || records[0];

  const handleReproduce = (record: CalculationRecord) => {
    try {
      const inputs = record.inputs;
      let reprPrice = 0;

      if (record.modelIdentifier.includes('Binomial')) {
        const res = calculateBinomialTree({
          spot: inputs.spot,
          strike: inputs.strike,
          timeToExpiryYears: inputs.T || inputs.timeToExpiryYears,
          riskFreeRate: inputs.r || inputs.riskFreeRate,
          dividendYield: inputs.q || inputs.dividendYield,
          volatility: inputs.sigma || inputs.volatility,
          optionType: inputs.optionType,
          exerciseStyle: inputs.exerciseStyle || 'EUROPEAN'
        });
        reprPrice = res.theoreticalPrice;
      } else {
        const res = calculateBsm({
          spot: inputs.spot,
          strike: inputs.strike,
          timeToExpiryYears: inputs.T || inputs.timeToExpiryYears,
          riskFreeRate: inputs.r || inputs.riskFreeRate,
          dividendYield: inputs.q || inputs.dividendYield,
          volatility: inputs.sigma || inputs.volatility,
          optionType: inputs.optionType
        });
        reprPrice = res.theoreticalPrice;
      }

      const recordedPrice = record.outputs.theoreticalPrice;
      const delta = Math.abs(reprPrice - recordedPrice);
      const exactMatch = delta < 1e-8;

      setReproductionStatus({
        tested: true,
        exactMatch,
        reproducedPrice: reprPrice,
        delta,
        message: exactMatch
          ? `Reproduced with bit-level floating point equivalence (delta: ${delta.toExponential(2)})`
          : `Discrepancy detected: delta ${delta.toFixed(6)}`
      });
    } catch (err: any) {
      setReproductionStatus({
        tested: true,
        exactMatch: false,
        message: `Reproduction error: ${err.message}`
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div>
          <h2 className="text-sm font-semibold text-slate-200">
            Immutable Calculation Provenance & Reproducibility Ledger
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
            <span>Total Logged Calculations: {records.length}</span>
            <span aria-hidden="true">·</span>
            <span>Ledger Integrity: Sealed SHA-256 Hashes</span>
          </div>
        </div>

        {activeRecord && (
          <button
            onClick={() => handleReproduce(activeRecord)}
            className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors whitespace-nowrap"
          >
            Re-run Exact Reproduction
          </button>
        )}
      </div>

      {/* Reproduction Status Alert */}
      {reproductionStatus.tested && (
        <div className={`p-4 rounded border text-xs font-mono ${
          reproductionStatus.exactMatch ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300' : 'bg-red-950/40 border-red-800 text-red-300'
        }`}>
          <div className="flex items-center justify-between">
            <span className="font-semibold">
              {reproductionStatus.exactMatch ? 'PROVENANCE VERIFIED: EXACT BIT-FOR-BIT MATCH' : 'VERIFICATION WARNING'}
            </span>
            <span>Delta: {reproductionStatus.delta?.toExponential(3)}</span>
          </div>
          <p className="mt-1 text-slate-300">{reproductionStatus.message}</p>
        </div>
      )}

      {/* Records Split: List on Left, JSON Inspector on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Records List */}
        <div className="lg:col-span-5 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-3">
          <h3 className="text-sm font-semibold text-slate-200">Audit Trail Entries</h3>
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {records.map((r) => {
              const isSelected = r.calculationId === (activeRecord?.calculationId || '');
              return (
                <div
                  key={r.calculationId}
                  onClick={() => { setSelectedRecordId(r.calculationId); setReproductionStatus({ tested: false, exactMatch: false }); }}
                  className={`p-3 rounded border cursor-pointer font-mono text-xs transition-colors ${
                    isSelected ? 'bg-sky-950/40 border-sky-600 text-slate-100' : 'bg-[#080d16] border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">{r.calculationId}</span>
                    <span className="text-[10px] text-slate-500">{r.inputHash}</span>
                  </div>
                  <div className="flex items-center justify-between mt-1 text-[11px]">
                    <span>{r.modelIdentifier}</span>
                    <span className="text-slate-300">${r.outputs.theoreticalPrice?.toFixed(4) || 'N/A'}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {r.requestTimestamp}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Deep JSON Provenance Inspector */}
        <div className="lg:col-span-7 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">
                Calculation Audit Record Inspector
              </h3>
              <p className="text-xs font-mono text-slate-400 mt-0.5">
                ID: {activeRecord?.calculationId} · Hash: {activeRecord?.inputHash}
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Runtime: {activeRecord?.numericalDiagnostics.runtimeMs.toFixed(3)} ms
            </span>
          </div>

          <div className="p-3 bg-[#080d16] rounded border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto max-h-[420px] overflow-y-auto">
            <pre>{JSON.stringify(activeRecord, null, 2)}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
