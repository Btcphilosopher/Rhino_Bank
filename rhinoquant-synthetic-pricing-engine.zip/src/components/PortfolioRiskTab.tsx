import React, { useState } from 'react';
import { MarketDataSnapshot, SyntheticLeg } from '../quant/types';
import { calculateBsm, calculatePortfolioRisk } from '../quant/engine';

interface PortfolioRiskTabProps {
  snapshot: MarketDataSnapshot;
}

export const PortfolioRiskTab: React.FC<PortfolioRiskTabProps> = ({ snapshot }) => {
  const spot = snapshot.spotPrice;
  const r = snapshot.riskFreeRate;
  const q = snapshot.dividendYield;
  const baseVol = 0.18;
  const atmK = Math.round(spot / 10) * 10;

  const c1 = calculateBsm({ spot, strike: atmK, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: baseVol, optionType: 'CALL' });
  const p1 = calculateBsm({ spot, strike: atmK - 20, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: baseVol, optionType: 'PUT' });

  // Institutional Multi-Asset Trading Book
  const [book] = useState<SyntheticLeg[]>([
    {
      id: 'book-1',
      instrumentType: 'EQUITY_SPOT',
      direction: 'LONG',
      quantity: 500,
      multiplier: 1,
      description: `${snapshot.underlyingSymbol} Cash Equities`,
      modelPrice: spot,
      greeks: { delta: 1, gamma: 0, vega: 0, rawVega: 0, theta: 0, rawTheta: 0, rho: 0, rawRho: 0 },
      financingCostAnnual: 500 * spot * (r + 0.0035),
      carryYieldAnnual: 500 * spot * q
    },
    {
      id: 'book-2',
      instrumentType: 'VANILLA_OPTION',
      direction: 'SHORT',
      quantity: 5,
      multiplier: 100,
      description: `${snapshot.underlyingSymbol} ${atmK} Call (Covered)`,
      strike: atmK,
      optionType: 'CALL',
      expiryYears: 0.25,
      modelPrice: c1.theoreticalPrice,
      greeks: c1.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    },
    {
      id: 'book-3',
      instrumentType: 'VANILLA_OPTION',
      direction: 'LONG',
      quantity: 5,
      multiplier: 100,
      description: `${snapshot.underlyingSymbol} ${atmK - 20} Put (Downside Hedge)`,
      strike: atmK - 20,
      optionType: 'PUT',
      expiryYears: 0.25,
      modelPrice: p1.theoreticalPrice,
      greeks: p1.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    }
  ]);

  const riskMetrics = calculatePortfolioRisk(book, spot, r, baseVol);

  return (
    <div className="space-y-6">
      {/* Risk Metrics KPI Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-5 bg-[#0e1422] border border-slate-800 rounded-lg font-mono">
        <div>
          <span className="text-xs text-slate-400">Total Book Market Value</span>
          <p className="text-xl font-bold text-slate-100 mt-1">
            ${riskMetrics.marketValue.toFixed(2)}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Notional: ${riskMetrics.totalNotional.toFixed(2)}</p>
        </div>

        <div>
          <span className="text-xs text-slate-400">1-Day 95% Parametric VaR</span>
          <p className="text-xl font-bold text-amber-400 mt-1">
            ${riskMetrics.parametricVaR95_1d.toFixed(2)}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">99% VaR: ${riskMetrics.parametricVaR99_1d.toFixed(2)}</p>
        </div>

        <div>
          <span className="text-xs text-slate-400">1-Day Historical Sim VaR (95%)</span>
          <p className="text-xl font-bold text-amber-400 mt-1">
            ${riskMetrics.historicalVaR95_1d.toFixed(2)}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">99% VaR: ${riskMetrics.historicalVaR99_1d.toFixed(2)}</p>
        </div>

        <div>
          <span className="text-xs text-slate-400">Expected Shortfall (CVaR 95%)</span>
          <p className="text-xl font-bold text-red-400 mt-1">
            ${riskMetrics.expectedShortfall95_1d.toFixed(2)}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Tail Avg Beyond 95% Cutoff</p>
        </div>
      </div>

      {/* Aggregate Greeks & Book Positions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Aggregated Greeks */}
        <div className="lg:col-span-5 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-3">
            Net Portfolio Greeks & Risk Sensitivities
          </h2>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Net Delta (Shares Eq):</span>
              <span className="text-slate-100 font-bold">{riskMetrics.netDelta.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Net Gamma:</span>
              <span className="text-slate-200">{riskMetrics.netGamma.toFixed(5)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Net Vega (1% vol move):</span>
              <span className="text-slate-200">${riskMetrics.netVega.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Daily Theta Decay:</span>
              <span className={riskMetrics.netTheta >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                ${riskMetrics.netTheta.toFixed(2)} / day
              </span>
            </div>
          </div>

          <div className="p-3 bg-[#080d16] rounded border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <strong className="text-slate-200 block mb-1">Methodology & Limits Specification:</strong>
            <p>• Parametric VaR assumes Delta-Normal distribution with zero mean daily drift.</p>
            <p>• Historical VaR evaluates fat-tailed return distributions with jump probability.</p>
            <p>• Calculated margin figures represent theoretical estimates, distinct from official DTCC/OCC clearinghouse requirements.</p>
          </div>
        </div>

        {/* Right Col: Active Positions in Book */}
        <div className="lg:col-span-7 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-3">
            Current Position Inventory ({book.length} Positions)
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 px-3">Position</th>
                  <th className="py-2.5 px-3">Dir</th>
                  <th className="py-2.5 px-3 text-right">Qty</th>
                  <th className="py-2.5 px-3 text-right">Price</th>
                  <th className="py-2.5 px-3 text-right">Market Val</th>
                  <th className="py-2.5 px-3 text-right">Delta</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {book.map((pos) => {
                  const sign = pos.direction === 'LONG' ? 1 : -1;
                  const posVal = sign * pos.quantity * pos.multiplier * pos.modelPrice;
                  return (
                    <tr key={pos.id} className="hover:bg-slate-900/40">
                      <td className="py-2 px-3 text-slate-200 font-medium">{pos.description}</td>
                      <td className={`py-2 px-3 font-semibold ${pos.direction === 'LONG' ? 'text-emerald-400' : 'text-red-400'}`}>
                        {pos.direction}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-300">{pos.quantity * pos.multiplier}</td>
                      <td className="py-2 px-3 text-right text-slate-200">${pos.modelPrice.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-semibold text-slate-100">${posVal.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right text-slate-300">
                        {(sign * pos.quantity * pos.multiplier * pos.greeks.delta).toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
