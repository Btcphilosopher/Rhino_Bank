import React, { useState } from 'react';
import { MarketDataSnapshot, SyntheticLeg } from '../quant/types';
import { calculateBsm, revalueUnderScenario, ScenarioShock } from '../quant/engine';

interface ScenarioLabTabProps {
  snapshot: MarketDataSnapshot;
}

export const ScenarioLabTab: React.FC<ScenarioLabTabProps> = ({ snapshot }) => {
  const spot = snapshot.spotPrice;
  const r = snapshot.riskFreeRate;
  const q = snapshot.dividendYield;
  const baseVol = 0.18;

  // Active portfolio legs to stress test
  const atmK = Math.round(spot / 10) * 10;
  const cCall = calculateBsm({ spot, strike: atmK, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: baseVol, optionType: 'CALL' });
  const cPut = calculateBsm({ spot, strike: atmK, timeToExpiryYears: 0.25, riskFreeRate: r, dividendYield: q, volatility: baseVol, optionType: 'PUT' });

  const [legs] = useState<SyntheticLeg[]>([
    {
      id: 'scen-leg-1',
      instrumentType: 'VANILLA_OPTION',
      direction: 'LONG',
      quantity: 10,
      multiplier: 100,
      description: `${snapshot.underlyingSymbol} ${atmK} Call`,
      strike: atmK,
      optionType: 'CALL',
      expiryYears: 0.25,
      modelPrice: cCall.theoreticalPrice,
      greeks: cCall.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    },
    {
      id: 'scen-leg-2',
      instrumentType: 'VANILLA_OPTION',
      direction: 'SHORT',
      quantity: 10,
      multiplier: 100,
      description: `${snapshot.underlyingSymbol} ${atmK} Put`,
      strike: atmK,
      optionType: 'PUT',
      expiryYears: 0.25,
      modelPrice: cPut.theoreticalPrice,
      greeks: cPut.greeks,
      financingCostAnnual: 0,
      carryYieldAnnual: 0
    }
  ]);

  // Historical Pre-set Stress Scenarios
  const HISTORICAL_SHOCKS: ScenarioShock[] = [
    { name: '1987 Black Monday Crash', spotShockPct: -0.226, volShockPct: 0.35, rateShockBps: -50, timeDecayDays: 1 },
    { name: '2008 Lehman Collapse', spotShockPct: -0.085, volShockPct: 0.22, rateShockBps: -75, timeDecayDays: 2 },
    { name: '2020 Covid Flash Crash', spotShockPct: -0.120, volShockPct: 0.28, rateShockBps: -100, timeDecayDays: 3 },
    { name: 'Fed Severe Rate Hike (+100bps)', spotShockPct: -0.035, volShockPct: 0.05, rateShockBps: 100, timeDecayDays: 7 },
    { name: 'Vol Crush & Time Decay (30d)', spotShockPct: 0.0, volShockPct: -0.08, rateShockBps: 0, timeDecayDays: 30 }
  ];

  const [activeShock, setActiveShock] = useState<ScenarioShock>(HISTORICAL_SHOCKS[0]);
  const [customSpotShockPct, setCustomSpotShockPct] = useState<number>(-10);
  const [customVolShockPct, setCustomVolShockPct] = useState<number>(5);
  const [customRateShockBps, setCustomRateShockBps] = useState<number>(0);
  const [customDays, setCustomDays] = useState<number>(7);

  const currentShock: ScenarioShock = activeShock.name === 'Custom Shock' ? {
    name: 'Custom Shock',
    spotShockPct: customSpotShockPct / 100.0,
    volShockPct: customVolShockPct / 100.0,
    rateShockBps: customRateShockBps,
    timeDecayDays: customDays
  } : activeShock;

  const result = revalueUnderScenario(legs, spot, r, q, baseVol, currentShock);

  // 2D Scenario Matrix: Spot Shocks (-15% to +15%) vs Volatility Shocks (-5% to +15%)
  const spotShocks = [-0.15, -0.10, -0.05, 0.0, 0.05, 0.10, 0.15];
  const volShocks = [-0.05, 0.0, 0.05, 0.10, 0.15];

  return (
    <div className="space-y-6">
      {/* Scenario Presets Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Historical Stress Events:</span>
          {HISTORICAL_SHOCKS.map(shock => (
            <button
              key={shock.name}
              onClick={() => setActiveShock(shock)}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                activeShock.name === shock.name ? 'bg-sky-500 text-slate-950 font-bold' : 'bg-slate-900 border border-slate-700 text-slate-300 hover:border-sky-500'
              }`}
            >
              {shock.name}
            </button>
          ))}
          <button
            onClick={() => setActiveShock({ name: 'Custom Shock', spotShockPct: customSpotShockPct / 100, volShockPct: customVolShockPct / 100, rateShockBps: customRateShockBps, timeDecayDays: customDays })}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              activeShock.name === 'Custom Shock' ? 'bg-sky-500 text-slate-950 font-bold' : 'bg-slate-900 border border-slate-700 text-slate-300 hover:border-sky-500'
            }`}
          >
            Custom Stress Shock
          </button>
        </div>

        <div className="text-xs font-mono text-slate-400">
          Book: <strong className="text-slate-200">10x Long Call / 10x Short Put (1000 Notional Multiplier)</strong>
        </div>
      </div>

      {/* Main Revaluation Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Revaluation Results & Taylor Decomposition */}
        <div className="lg:col-span-6 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-semibold text-slate-200">Full Revaluation vs Greek Decomposition</h2>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                <span>Spot Shock: {(currentShock.spotShockPct * 100).toFixed(1)}%</span>
                <span aria-hidden="true">·</span>
                <span>Vol Shock: {(currentShock.volShockPct * 100).toFixed(1)}%</span>
                <span aria-hidden="true">·</span>
                <span>Rate: {currentShock.rateShockBps} bps</span>
              </div>
            </div>

            <div className="text-right font-mono">
              <span className="text-xs text-slate-400 block">Total Full Revaluation P&L</span>
              <p className={`text-2xl font-bold ${result.fullRevaluationPnL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {result.fullRevaluationPnL >= 0 ? '+' : ''}${result.fullRevaluationPnL.toFixed(2)}
              </p>
            </div>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Base Portfolio Mark:</span>
              <span className="text-slate-200">${result.basePortfolioValue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Revalued Scenario Mark:</span>
              <span className="text-slate-100 font-bold">${result.revaluedPortfolioValue.toFixed(2)}</span>
            </div>

            {/* Decomposition components */}
            <div className="pt-2 text-slate-300 font-semibold">Taylor Series Greek Attribution:</div>
            
            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Delta Contribution (Δ · ΔS):</span>
              <span className={result.decomposition.deltaContribution >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {result.decomposition.deltaContribution >= 0 ? '+' : ''}${result.decomposition.deltaContribution.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Gamma Contribution (½ Γ · (ΔS)²):</span>
              <span className={result.decomposition.gammaContribution >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {result.decomposition.gammaContribution >= 0 ? '+' : ''}${result.decomposition.gammaContribution.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Vega Contribution (V · Δσ):</span>
              <span className={result.decomposition.vegaContribution >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {result.decomposition.vegaContribution >= 0 ? '+' : ''}${result.decomposition.vegaContribution.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Theta Contribution (Θ · Δt):</span>
              <span className={result.decomposition.thetaContribution >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {result.decomposition.thetaContribution >= 0 ? '+' : ''}${result.decomposition.thetaContribution.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-400">Rho Contribution (ρ · Δr):</span>
              <span className={result.decomposition.rhoContribution >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {result.decomposition.rhoContribution >= 0 ? '+' : ''}${result.decomposition.rhoContribution.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between py-1.5 pt-2">
              <span className="text-slate-300 font-semibold">Higher-Order Residual / Vanna-Volga:</span>
              <span className="font-bold text-slate-100">
                {result.decomposition.unexplainedHigherOrderResidual >= 0 ? '+' : ''}${result.decomposition.unexplainedHigherOrderResidual.toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Right Col: 2D Spot vs Volatility Revaluation Heatmap Grid */}
        <div className="lg:col-span-6 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-3">
            2D Shock Revaluation Matrix (Spot vs Volatility)
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-center">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 px-2 text-left">ΔVol \ ΔSpot</th>
                  {spotShocks.map(ss => (
                    <th key={ss} className="py-2 px-1 text-right">
                      {ss > 0 ? `+${(ss * 100).toFixed(0)}%` : `${(ss * 100).toFixed(0)}%`}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {volShocks.map(vs => (
                  <tr key={vs} className="hover:bg-slate-900/40">
                    <td className="py-2 px-2 text-left text-slate-300 font-semibold">
                      {vs > 0 ? `+${(vs * 100).toFixed(0)}%` : `${(vs * 100).toFixed(0)}%`}
                    </td>
                    {spotShocks.map(ss => {
                      const gridShock: ScenarioShock = {
                        name: 'Grid',
                        spotShockPct: ss,
                        volShockPct: vs,
                        rateShockBps: 0,
                        timeDecayDays: 0
                      };
                      const gridRes = revalueUnderScenario(legs, spot, r, q, baseVol, gridShock);
                      const pnl = gridRes.fullRevaluationPnL;
                      const isPositive = pnl >= 0;
                      return (
                        <td
                          key={ss}
                          className={`py-2 px-1 text-right font-medium ${
                            isPositive ? 'text-emerald-400' : 'text-red-400'
                          }`}
                        >
                          {isPositive ? '+' : ''}${pnl.toFixed(0)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
