import React, { useState } from 'react';
import { MarketDataSnapshot } from '../quant/types';
import { calculateForwardCarry } from '../quant/engine';

interface ForwardCarryTabProps {
  snapshot: MarketDataSnapshot;
}

export const ForwardCarryTab: React.FC<ForwardCarryTabProps> = ({ snapshot }) => {
  const [assetClass, setAssetClass] = useState<'EQUITY' | 'FX' | 'COMMODITY'>('EQUITY');
  const [spot, setSpot] = useState<number>(snapshot.spotPrice);
  const [tenorDays, setTenorDays] = useState<number>(90);
  const [ratePct, setRatePct] = useState<number>(snapshot.riskFreeRate * 100);
  const [divPct, setDivPct] = useState<number>(snapshot.dividendYield * 100);
  const [borrowBps, setBorrowBps] = useState<number>(snapshot.borrowCostBps);
  
  // Commodity specific
  const [storageCostPct, setStorageCostPct] = useState<number>(1.8);
  const [convenienceYieldPct, setConvenienceYieldPct] = useState<number>(3.2);

  // FX specific (Covered Interest Parity)
  const [domesticRatePct, setDomesticRatePct] = useState<number>(4.50); // USD
  const [foreignRatePct, setForeignRatePct] = useState<number>(3.25);    // EUR
  const [crossCurrencyBasisBps, setCrossCurrencyBasisBps] = useState<number>(-12); // basis in bps

  const T = tenorDays / 365.0;

  let r = ratePct / 100.0;
  let q = divPct / 100.0;
  let b = borrowBps / 10000.0;
  let u = 0;
  let y = 0;

  if (assetClass === 'COMMODITY') {
    u = storageCostPct / 100.0;
    y = convenienceYieldPct / 100.0;
    q = 0;
  } else if (assetClass === 'FX') {
    r = domesticRatePct / 100.0;
    q = foreignRatePct / 100.0;
    b = crossCurrencyBasisBps / 10000.0;
  }

  const carryResult = calculateForwardCarry({
    spot,
    timeToExpiryYears: T,
    riskFreeRate: r,
    dividendYield: q,
    borrowCost: b,
    storageCost: u,
    convenienceYield: y
  });

  // Tenor term structure table
  const tenors = [30, 60, 90, 180, 360, 720];
  const termStructure = tenors.map(days => {
    const tYears = days / 365.0;
    const res = calculateForwardCarry({
      spot,
      timeToExpiryYears: tYears,
      riskFreeRate: r,
      dividendYield: q,
      borrowCost: b,
      storageCost: u,
      convenienceYield: y
    });
    return {
      days,
      years: tYears,
      forward: res.theoreticalForward,
      carryDiff: res.carryCashFlow,
      annualizedBasis: res.annualizedBasisPct * 100
    };
  });

  return (
    <div className="space-y-6">
      {/* Asset Class Selector & Presets */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div className="flex items-center gap-3 text-xs">
          <span className="text-slate-400 font-medium">Forward Asset Class:</span>
          <div className="flex bg-slate-900 border border-slate-700 rounded p-0.5">
            <button
              onClick={() => { setAssetClass('EQUITY'); setSpot(snapshot.spotPrice); }}
              className={`px-3 py-1 font-medium transition-colors rounded ${
                assetClass === 'EQUITY' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Equity / Index Forward
            </button>
            <button
              onClick={() => { setAssetClass('FX'); setSpot(1.0850); }}
              className={`px-3 py-1 font-medium transition-colors rounded ${
                assetClass === 'FX' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              FX CIP Forward (EUR/USD)
            </button>
            <button
              onClick={() => { setAssetClass('COMMODITY'); setSpot(78.50); }}
              className={`px-3 py-1 font-medium transition-colors rounded ${
                assetClass === 'COMMODITY' ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Commodity Forward (WTI)
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Model: <span className="text-slate-200 font-semibold">Cost of Carry Exponential S·exp(c·T)</span>
        </div>
      </div>

      {/* Main Forward Calculation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Parameter Form */}
        <div className="lg:col-span-5 p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
          <h2 className="text-sm font-semibold text-slate-200 border-b border-slate-800 pb-3">
            Carry & Financing Parameters
          </h2>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Spot Price (S)</label>
              <input
                type="number"
                step="0.01"
                value={spot}
                onChange={(e) => setSpot(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Tenor to Expiry (Days)</label>
              <input
                type="number"
                min="1"
                max="1825"
                value={tenorDays}
                onChange={(e) => setTenorDays(parseInt(e.target.value) || 1)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
              />
            </div>

            {assetClass === 'EQUITY' && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">SOFR Rate r (%)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={ratePct}
                      onChange={(e) => setRatePct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Dividend Yield q (%)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={divPct}
                      onChange={(e) => setDivPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Borrow Fee Cost (bps)</label>
                  <input
                    type="number"
                    step="5"
                    value={borrowBps}
                    onChange={(e) => setBorrowBps(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </>
            )}

            {assetClass === 'FX' && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">USD Domestic Rate (%)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={domesticRatePct}
                      onChange={(e) => setDomesticRatePct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">EUR Foreign Rate (%)</label>
                    <input
                      type="number"
                      step="0.05"
                      value={foreignRatePct}
                      onChange={(e) => setForeignRatePct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Cross-Currency Basis (bps)</label>
                  <input
                    type="number"
                    step="1"
                    value={crossCurrencyBasisBps}
                    onChange={(e) => setCrossCurrencyBasisBps(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </>
            )}

            {assetClass === 'COMMODITY' && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">Storage Cost u (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={storageCostPct}
                      onChange={(e) => setStorageCostPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Convenience Yield y (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={convenienceYieldPct}
                      onChange={(e) => setConvenienceYieldPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-slate-100 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Right Col: Valuation Output & Component Breakdown */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Theoretical Forward Valuation</h3>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                  <span>Net Cost of Carry Rate: {(carryResult.netCarryRate * 100).toFixed(3)}%</span>
                  <span aria-hidden="true">·</span>
                  <span>Annualized Basis: {(carryResult.annualizedBasisPct * 100).toFixed(2)}%</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400">Theoretical Forward Price (F)</span>
                <p className="text-2xl font-bold font-mono text-sky-400">
                  ${carryResult.theoreticalForward.toFixed(4)}
                </p>
              </div>
            </div>

            {/* Carry Component Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 font-mono text-xs">
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Financing Expense</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  +${carryResult.components.financingCost.toFixed(3)}
                </span>
                <span className="text-[10px] text-slate-500">r + borrow cost</span>
              </div>
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Dividend/Foreign Drag</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  -${carryResult.components.dividendBenefit.toFixed(3)}
                </span>
                <span className="text-[10px] text-slate-500">Income received</span>
              </div>
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Storage Expense</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  +${carryResult.components.storageExpense.toFixed(3)}
                </span>
                <span className="text-[10px] text-slate-500">Physical holding</span>
              </div>
              <div className="bg-[#080d16] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block">Convenience Benefit</span>
                <span className="text-slate-100 font-semibold text-sm mt-0.5 block">
                  -${carryResult.components.convenienceBenefit.toFixed(3)}
                </span>
                <span className="text-[10px] text-slate-500">Inventory option</span>
              </div>
            </div>
          </div>

          {/* Forward Term Structure Table */}
          <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg">
            <h3 className="text-sm font-semibold text-slate-200 mb-3">Forward Curve Term Structure</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2 px-3">Tenor</th>
                    <th className="py-2 px-3 text-right">Forward Price</th>
                    <th className="py-2 px-3 text-right">Carry Cash Flow</th>
                    <th className="py-2 px-3 text-right">Annualized Basis</th>
                    <th className="py-2 px-3 text-right">Curve State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {termStructure.map((row) => (
                    <tr key={row.days} className="hover:bg-slate-900/40">
                      <td className="py-2 px-3 text-slate-200 font-medium">{row.days}d ({row.years.toFixed(2)}y)</td>
                      <td className="py-2 px-3 text-right text-slate-100 font-semibold">${row.forward.toFixed(4)}</td>
                      <td className={`py-2 px-3 text-right ${row.carryDiff >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {row.carryDiff >= 0 ? '+' : ''}${row.carryDiff.toFixed(4)}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-300">{row.annualizedBasis.toFixed(2)}%</td>
                      <td className="py-2 px-3 text-right text-slate-400">
                        {row.forward > spot ? 'Contango' : 'Backwardation'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
