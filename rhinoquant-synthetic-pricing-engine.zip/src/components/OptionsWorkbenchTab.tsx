import React, { useState } from 'react';
import { MarketDataSnapshot, OptionContractSpec, OptionType, ExerciseStyle } from '../quant/types';
import { generateOptionsChain } from '../quant/fixtures';
import { calculateBsm, calculateBinomialTree, solveImpliedVolatility } from '../quant/engine';

interface OptionsWorkbenchTabProps {
  snapshot: MarketDataSnapshot;
}

export const OptionsWorkbenchTab: React.FC<OptionsWorkbenchTabProps> = ({ snapshot }) => {
  const [expiryDays, setExpiryDays] = useState<number>(45);
  const [exerciseStyle, setExerciseStyle] = useState<ExerciseStyle>('EUROPEAN');
  const [selectedStrike, setSelectedStrike] = useState<number | null>(null);
  const [filterType, setFilterType] = useState<'ALL' | 'CALL' | 'PUT'>('ALL');

  const spot = snapshot.spotPrice;
  const r = snapshot.riskFreeRate;
  const q = snapshot.dividendYield;

  // Generate options chain for active underlying
  const chain = generateOptionsChain(snapshot.underlyingSymbol, spot, r, q, expiryDays);

  // Group by strike
  const strikes = Array.from(new Set(chain.map(c => c.strike))).sort((a, b) => a - b);
  const selectedK = selectedStrike ?? (Math.round(spot / 10) * 10);

  // Focus contract for inspector
  const focusCall = chain.find(c => c.strike === selectedK && c.optionType === 'CALL');
  const focusPut = chain.find(c => c.strike === selectedK && c.optionType === 'PUT');

  const T = expiryDays / 365.0;
  const ivCall = focusCall?.impliedVolMid || 0.18;
  const ivPut = focusPut?.impliedVolMid || 0.18;

  // Price with BSM and CRR Tree
  const bsmCall = calculateBsm({ spot, strike: selectedK, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: ivCall, optionType: 'CALL' });
  const bsmPut = calculateBsm({ spot, strike: selectedK, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: ivPut, optionType: 'PUT' });

  const crrCall = calculateBinomialTree({ spot, strike: selectedK, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: ivCall, optionType: 'CALL', exerciseStyle, steps: 100 });
  const crrPut = calculateBinomialTree({ spot, strike: selectedK, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: ivPut, optionType: 'PUT', exerciseStyle, steps: 100 });

  // Early exercise premium for American style
  const earlyCallPrem = Math.max(0, crrCall.theoreticalPrice - bsmCall.theoreticalPrice);
  const earlyPutPrem = Math.max(0, crrPut.theoreticalPrice - bsmPut.theoreticalPrice);

  // Brent IV solver verification on Call Market Mid
  const brentCall = focusCall ? solveImpliedVolatility(focusCall.marketMid, { spot, strike: selectedK, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, optionType: 'CALL' }) : null;

  // SVG Volatility Smile Chart Data
  const smileCalls = strikes.map(k => {
    const c = chain.find(item => item.strike === k && item.optionType === 'CALL');
    return { strike: k, iv: (c?.impliedVolMid || 0.2) * 100 };
  });

  const svgWidth = 640;
  const svgHeight = 180;
  const pad = { top: 15, right: 25, bottom: 35, left: 45 };
  const chartW = svgWidth - pad.left - pad.right;
  const chartH = svgHeight - pad.top - pad.bottom;

  const minK = strikes[0];
  const maxK = strikes[strikes.length - 1];
  const minIv = Math.min(...smileCalls.map(s => s.iv)) * 0.9;
  const maxIv = Math.max(...smileCalls.map(s => s.iv)) * 1.1;

  const getSmileX = (k: number) => pad.left + ((k - minK) / (maxK - minK)) * chartW;
  const getSmileY = (iv: number) => pad.top + chartH - ((iv - minIv) / (maxIv - minIv)) * chartH;
  const smilePoints = smileCalls.map(s => `${getSmileX(s.strike).toFixed(1)},${getSmileY(s.iv).toFixed(1)}`).join(' ');

  return (
    <div className="space-y-6">
      {/* Top Controls: Expiry & Exercise Style */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0e1422] border border-slate-800 rounded-lg">
        <div className="flex items-center gap-4 text-xs">
          <label className="text-slate-400">Tenor Expiry:</label>
          <div className="flex bg-slate-900 border border-slate-700 rounded p-0.5">
            {[14, 30, 45, 90, 180].map((days) => (
              <button
                key={days}
                onClick={() => setExpiryDays(days)}
                className={`px-3 py-1 font-mono transition-colors rounded ${
                  expiryDays === days ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {days}d
              </button>
            ))}
          </div>

          <label className="text-slate-400 ml-2">Exercise Style:</label>
          <div className="flex bg-slate-900 border border-slate-700 rounded p-0.5">
            {(['EUROPEAN', 'AMERICAN'] as ExerciseStyle[]).map((style) => (
              <button
                key={style}
                onClick={() => setExerciseStyle(style)}
                className={`px-3 py-1 font-mono transition-colors rounded ${
                  exerciseStyle === style ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {style}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Filter Chain:</span>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-200"
          >
            <option value="ALL">Calls & Puts Side-by-Side</option>
            <option value="CALL">Calls Only</option>
            <option value="PUT">Puts Only</option>
          </select>
        </div>
      </div>

      {/* Selected Strike Inspector Banner */}
      <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">
              Contract Analytical Inspector · Strike {selectedK.toFixed(2)} ({expiryDays} Days)
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
              <span>Moneyness: {(selectedK / spot).toFixed(4)}</span>
              <span aria-hidden="true">·</span>
              <span>Style: {exerciseStyle}</span>
              <span aria-hidden="true">·</span>
              <span>
                Brent IV Recovery: {brentCall?.converged ? `${(brentCall.impliedVol * 100).toFixed(2)}% (${brentCall.iterations} iters)` : 'N/A'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6 font-mono text-xs">
            <div>
              <span className="text-slate-400 block">Call Market / Model</span>
              <span className="text-slate-100 font-semibold text-sm">
                ${focusCall?.marketMid.toFixed(2)} / ${crrCall.theoreticalPrice.toFixed(2)}
              </span>
              {exerciseStyle === 'AMERICAN' && earlyCallPrem > 0.01 && (
                <span className="text-[10px] text-amber-400 block">Early Prem: +${earlyCallPrem.toFixed(2)}</span>
              )}
            </div>
            <div>
              <span className="text-slate-400 block">Put Market / Model</span>
              <span className="text-slate-100 font-semibold text-sm">
                ${focusPut?.marketMid.toFixed(2)} / ${crrPut.theoreticalPrice.toFixed(2)}
              </span>
              {exerciseStyle === 'AMERICAN' && earlyPutPrem > 0.01 && (
                <span className="text-[10px] text-amber-400 block">Early Prem: +${earlyPutPrem.toFixed(2)}</span>
              )}
            </div>
          </div>
        </div>

        {/* Volatility Smile Chart */}
        <div>
          <span className="text-xs text-slate-400 block mb-2 font-mono">Implied Volatility Smile (% vs Strike):</span>
          <div className="w-full overflow-x-auto bg-[#080d16] p-2 rounded border border-slate-800">
            <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-36 font-mono text-[10px]">
              {/* Reference grid line for spot */}
              <line x1={getSmileX(spot)} y1={pad.top} x2={getSmileX(spot)} y2={svgHeight - pad.bottom} stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
              <text x={getSmileX(spot)} y={pad.top + 10} fill="#94a3b8" textAnchor="middle">Spot {spot}</text>

              {/* Smile polyline */}
              <polyline fill="none" stroke="#38bdf8" strokeWidth="2" points={smilePoints} />

              {/* Data points */}
              {smileCalls.map((pt, i) => (
                <circle
                  key={i}
                  cx={getSmileX(pt.strike)}
                  cy={getSmileY(pt.iv)}
                  r={pt.strike === selectedK ? 4.5 : 2.5}
                  fill={pt.strike === selectedK ? '#f59e0b' : '#38bdf8'}
                  className="cursor-pointer"
                  onClick={() => setSelectedStrike(pt.strike)}
                />
              ))}

              {/* Axis labels */}
              <text x={pad.left} y={svgHeight - pad.bottom + 14} fill="#64748b">{minK}</text>
              <text x={getSmileX(selectedK)} y={svgHeight - pad.bottom + 14} fill="#f59e0b" textAnchor="middle">Selected {selectedK}</text>
              <text x={svgWidth - pad.right} y={svgHeight - pad.bottom + 14} fill="#64748b" textAnchor="end">{maxK}</text>
              <text x={pad.left - 6} y={pad.top + 8} fill="#64748b" textAnchor="end">{maxIv.toFixed(1)}%</text>
              <text x={pad.left - 6} y={svgHeight - pad.bottom} fill="#64748b" textAnchor="end">{minIv.toFixed(1)}%</text>
            </svg>
          </div>
        </div>
      </div>

      {/* High Density Options Chain Table */}
      <div className="p-5 bg-[#0e1422] border border-slate-800 rounded-lg space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">Institutional Options Chain ({chain.length / 2} Strikes)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                {/* Calls */}
                {(filterType === 'ALL' || filterType === 'CALL') && (
                  <>
                    <th className="py-2 px-2 text-right">Call Bid</th>
                    <th className="py-2 px-2 text-right">Call Ask</th>
                    <th className="py-2 px-2 text-right font-semibold text-slate-200">Call Mid</th>
                    <th className="py-2 px-2 text-right">Call IV</th>
                    <th className="py-2 px-2 text-right">Call Delta</th>
                  </>
                )}
                {/* Strike Center */}
                <th className="py-2 px-4 text-center bg-slate-900/80 font-bold text-sky-400">Strike</th>
                {/* Puts */}
                {(filterType === 'ALL' || filterType === 'PUT') && (
                  <>
                    <th className="py-2 px-2 text-left">Put Delta</th>
                    <th className="py-2 px-2 text-left">Put IV</th>
                    <th className="py-2 px-2 text-left font-semibold text-slate-200">Put Mid</th>
                    <th className="py-2 px-2 text-left">Put Bid</th>
                    <th className="py-2 px-2 text-left">Put Ask</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {strikes.map((k) => {
                const call = chain.find(c => c.strike === k && c.optionType === 'CALL');
                const put = chain.find(c => c.strike === k && c.optionType === 'PUT');
                const isAtm = Math.abs(k - spot) < 25;
                const isSelected = k === selectedK;

                // On-the-fly Greeks for table
                const callGreeks = calculateBsm({ spot, strike: k, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: call?.impliedVolMid || 0.18, optionType: 'CALL' }).greeks;
                const putGreeks = calculateBsm({ spot, strike: k, timeToExpiryYears: T, riskFreeRate: r, dividendYield: q, volatility: put?.impliedVolMid || 0.18, optionType: 'PUT' }).greeks;

                return (
                  <tr
                    key={k}
                    onClick={() => setSelectedStrike(k)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-sky-950/40 text-slate-100' : (isAtm ? 'bg-slate-900/30 hover:bg-slate-900/60' : 'hover:bg-slate-900/40')
                    }`}
                  >
                    {(filterType === 'ALL' || filterType === 'CALL') && (
                      <>
                        <td className="py-1.5 px-2 text-right text-slate-400">${call?.marketBid.toFixed(2)}</td>
                        <td className="py-1.5 px-2 text-right text-slate-400">${call?.marketAsk.toFixed(2)}</td>
                        <td className="py-1.5 px-2 text-right font-semibold text-slate-100">${call?.marketMid.toFixed(2)}</td>
                        <td className="py-1.5 px-2 text-right text-sky-400">{((call?.impliedVolMid || 0) * 100).toFixed(1)}%</td>
                        <td className="py-1.5 px-2 text-right text-slate-300">{callGreeks.delta.toFixed(3)}</td>
                      </>
                    )}

                    <td className={`py-1.5 px-4 text-center font-bold ${isAtm ? 'text-amber-400 bg-slate-900/90' : 'text-slate-200 bg-slate-900/40'}`}>
                      {k.toFixed(2)}
                    </td>

                    {(filterType === 'ALL' || filterType === 'PUT') && (
                      <>
                        <td className="py-1.5 px-2 text-left text-slate-300">{putGreeks.delta.toFixed(3)}</td>
                        <td className="py-1.5 px-2 text-left text-sky-400">{((put?.impliedVolMid || 0) * 100).toFixed(1)}%</td>
                        <td className="py-1.5 px-2 text-left font-semibold text-slate-100">${put?.marketMid.toFixed(2)}</td>
                        <td className="py-1.5 px-2 text-left text-slate-400">${put?.marketBid.toFixed(2)}</td>
                        <td className="py-1.5 px-2 text-left text-slate-400">${put?.marketAsk.toFixed(2)}</td>
                      </>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
