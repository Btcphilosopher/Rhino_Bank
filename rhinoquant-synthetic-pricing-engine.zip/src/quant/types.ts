/**
 * RhinoQuant Synthetic Pricing Engine - Financial & Numerical Types
 * Explicit conventions:
 * - Rates, yields, and volatilities are decimals (5% = 0.05).
 * - Timestamps are UTC ISO-8601 strings.
 * - Units and currencies are strictly defined.
 */

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF';

export type DayCountConvention = 'ACT_360' | 'ACT_365' | 'THIRTY_360';

export type ExerciseStyle = 'EUROPEAN' | 'AMERICAN';

export type OptionType = 'CALL' | 'PUT';

export type PositionDirection = 'LONG' | 'SHORT';

export type InstrumentType = 
  | 'EQUITY_SPOT' 
  | 'VANILLA_OPTION' 
  | 'FORWARD_FUTURE' 
  | 'VANILLA_SWAP' 
  | 'EQUITY_SWAP' 
  | 'CASH_BORROW';

export interface MarketDataSnapshot {
  snapshotId: string;
  source: 'FIXTURE_SPX' | 'FIXTURE_AAPL' | 'FIXTURE_EURUSD' | 'FIXTURE_SOFR' | 'SYNTHETIC_LIVE' | 'CUSTOM';
  timestamp: string;
  isStale: boolean;
  stalenessAgeSec: number;
  underlyingSymbol: string;
  currency: Currency;
  spotPrice: number;
  spotBid: number;
  spotAsk: number;
  riskFreeRate: number;      // e.g. 0.045 = 4.5%
  dividendYield: number;     // e.g. 0.015 = 1.5%
  borrowCostBps: number;     // e.g. 35 bps = 0.0035
  repoSpreadBps: number;     // e.g. 15 bps = 0.0015
  convenienceYield: number;  // For commodities
  storageCost: number;       // For commodities
  domesticRate?: number;     // For FX
  foreignRate?: number;      // For FX
}

export interface OptionContractSpec {
  symbol: string;
  underlying: string;
  optionType: OptionType;
  exerciseStyle: ExerciseStyle;
  strike: number;
  expiryDate: string;
  timeToExpiryYears: number;
  multiplier: number;        // e.g. 100 for equity options
  marketBid: number;
  marketAsk: number;
  marketMid: number;
  impliedVolMid: number;
  openInterest: number;
  volume: number;
}

export interface GreeksResult {
  delta: number;             // dV / dS
  gamma: number;             // d2V / dS2
  vega: number;              // dV / d(sigma), per 1% vol move (0.01 * raw)
  rawVega: number;           // raw dV / d(sigma)
  theta: number;             // dV / dt, per calendar day (raw / 365)
  rawTheta: number;          // raw dV / dt per year
  rho: number;               // dV / dr, per 1% rate move (0.01 * raw)
  rawRho: number;            // raw dV / dr
  vanna?: number;            // d2V / (dS d_sigma)
  volga?: number;            // d2V / d(sigma)^2
}

export interface PricingResult {
  modelName: 'Black-Scholes-Merton' | 'Black-76' | 'Binomial-CRR' | 'Monte-Carlo' | 'Cost-of-Carry' | 'Discounted-Cash-Flow';
  modelVersion: string;
  theoreticalPrice: number;
  intrinsicValue: number;
  timeValue: number;
  greeks: GreeksResult;
  diagnostics: {
    converged: boolean;
    iterations?: number;
    errorTolerance?: number;
    standardError?: number;  // for Monte Carlo
    confidenceInterval95?: [number, number];
    earlyExercisePremium?: number; // for American
    executionTimeMs: number;
  };
}

export interface SyntheticLeg {
  id: string;
  instrumentType: InstrumentType;
  direction: PositionDirection;
  quantity: number;
  multiplier: number;
  description: string;
  strike?: number;
  optionType?: OptionType;
  expiryYears?: number;
  modelPrice: number;
  marketBid?: number;
  marketAsk?: number;
  greeks: GreeksResult;
  financingCostAnnual: number;
  carryYieldAnnual: number;
}

export interface SyntheticPortfolioAnalysis {
  legs: SyntheticLeg[];
  aggregateModelValue: number;
  netMarketBid: number;
  netMarketAsk: number;
  netCashOutlay: number;
  netNotionalExposure: number;
  netGreeks: GreeksResult;
  annualFinancingExpense: number;
  annualDividendIncome: number;
  netAnnualCarry: number;
  breakEvenPoints: number[];
  maxGain: number | 'UNLIMITED';
  maxLoss: number | 'UNLIMITED';
  estimatedMarginRequirement: number;
  payoffProfile: {
    spot: number;
    expiryPayoff: number;
    intermediateValue: number;
  }[];
}

export interface ParityAnalysisResult {
  spot: number;
  strike: number;
  timeToExpiry: number;
  rate: number;
  dividendYield: number;
  callMid: number;
  callBid: number;
  callAsk: number;
  putMid: number;
  putBid: number;
  putAsk: number;
  theoreticalForward: number;
  discountedStrike: number;
  syntheticForwardMid: number;
  syntheticForwardBid: number;
  syntheticForwardAsk: number;
  parityResidual: number;      // (C - P) - (S e^(-qT) - K e^(-rT))
  impliedFinancingRate: number;
  borrowFeeImpact: number;
  transactionCostEstimate: number;
  isExecutableArbitrage: boolean;
  arbitrageDirection: 'NONE' | 'CONVERSION' | 'REVERSAL';
  netExecutableMarginAfterCosts: number;
}

export interface CalculationRecord {
  calculationId: string;
  inputHash: string;
  requestTimestamp: string;
  valuationTimestamp: string;
  modelIdentifier: string;
  modelVersion: string;
  softwareBuildId: string;
  marketSnapshotId: string;
  instrumentType: InstrumentType;
  inputs: Record<string, any>;
  outputs: Record<string, any>;
  warnings: string[];
  numericalDiagnostics: {
    runtimeMs: number;
    converged: boolean;
    precision: string;
  };
}

export interface SVIParameters {
  a: number;       // base variance level
  b: number;       // angle between asymptotes
  rho: number;     // skew (-1 < rho < 1)
  m: number;       // horizontal translation
  sigma: number;   // smoothing parameter (> 0)
}

export interface VolatilitySurfaceCalibration {
  surfaceId: string;
  symbol: string;
  calibratedAt: string;
  parameters: SVIParameters;
  rmse: number;
  maxResidual: number;
  iterations: number;
  converged: boolean;
  arbitrageChecks: {
    calendarArbitrageFree: boolean;
    butterflyArbitrageFree: boolean;
    positiveVariance: boolean;
  };
  grid: {
    strike: number;
    logMoneyness: number;
    expiryYears: number;
    marketIv: number;
    modelIv: number;
    residual: number;
  }[];
}
