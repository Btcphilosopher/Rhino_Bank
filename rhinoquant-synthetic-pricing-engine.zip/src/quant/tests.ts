/**
 * RhinoQuant Verification Test Suite
 * Independent mathematical verification, property tests, and numerical benchmarks
 */

import {
  calculateBsm,
  calculateBinomialTree,
  calculateMonteCarlo,
  solveImpliedVolatility,
  calculateVanillaSwap,
  validateSviArbitrage,
  rawSviTotalVariance
} from './engine';
import { SOFR_ZERO_CURVE } from './fixtures';

export interface TestResultItem {
  id: string;
  category: 'ANALYTICAL' | 'PROPERTY' | 'NUMERICAL_SOLVER' | 'EARLY_EXERCISE' | 'SWAP_DCF' | 'SVI_ARBITRAGE';
  name: string;
  description: string;
  passed: boolean;
  actualValue: string;
  expectedValue: string;
  tolerance: string;
  errorDelta: number;
  durationMs: number;
}

export function runQuantitativeTestSuite(): {
  results: TestResultItem[];
  totalCount: number;
  passCount: number;
  failCount: number;
  totalDurationMs: number;
} {
  const results: TestResultItem[] = [];
  const overallStart = performance.now();

  // 1. Hull Benchmark Case: S=100, K=100, T=1.0, r=0.05, q=0.0, sigma=0.20
  {
    const tStart = performance.now();
    const callRes = calculateBsm({
      spot: 100,
      strike: 100,
      timeToExpiryYears: 1.0,
      riskFreeRate: 0.05,
      dividendYield: 0.0,
      volatility: 0.20,
      optionType: 'CALL'
    });
    // Reference price from Hull / QuantLib = 10.45058
    const expected = 10.45058;
    const diff = Math.abs(callRes.theoreticalPrice - expected);
    const passed = diff < 1e-4;
    results.push({
      id: 'TC-01',
      category: 'ANALYTICAL',
      name: 'Hull ATM Benchmark European Call',
      description: 'BSM closed-form valuation against standard QuantLib/Hull benchmark case',
      passed,
      actualValue: callRes.theoreticalPrice.toFixed(5),
      expectedValue: expected.toFixed(5),
      tolerance: '< 1e-4',
      errorDelta: diff,
      durationMs: performance.now() - tStart
    });
  }

  // 2. Put-Call Parity: C - P = S - K * exp(-r*T) (q=0)
  {
    const tStart = performance.now();
    const callRes = calculateBsm({
      spot: 150,
      strike: 140,
      timeToExpiryYears: 0.5,
      riskFreeRate: 0.04,
      dividendYield: 0.015,
      volatility: 0.28,
      optionType: 'CALL'
    });
    const putRes = calculateBsm({
      spot: 150,
      strike: 140,
      timeToExpiryYears: 0.5,
      riskFreeRate: 0.04,
      dividendYield: 0.015,
      volatility: 0.28,
      optionType: 'PUT'
    });
    const lhs = callRes.theoreticalPrice - putRes.theoreticalPrice;
    const rhs = 150 * Math.exp(-0.015 * 0.5) - 140 * Math.exp(-0.04 * 0.5);
    const diff = Math.abs(lhs - rhs);
    const passed = diff < 1e-10;
    results.push({
      id: 'TC-02',
      category: 'PROPERTY',
      name: 'Continuous Dividend Put-Call Parity',
      description: 'Verifies (C - P) equals (S * exp(-qT) - K * exp(-rT)) within float64 epsilon',
      passed,
      actualValue: lhs.toFixed(8),
      expectedValue: rhs.toFixed(8),
      tolerance: '< 1e-10',
      errorDelta: diff,
      durationMs: performance.now() - tStart
    });
  }

  // 3. Greeks Consistency: Call Delta - Put Delta = exp(-q*T)
  {
    const tStart = performance.now();
    const callRes = calculateBsm({
      spot: 100,
      strike: 105,
      timeToExpiryYears: 0.75,
      riskFreeRate: 0.03,
      dividendYield: 0.02,
      volatility: 0.22,
      optionType: 'CALL'
    });
    const putRes = calculateBsm({
      spot: 100,
      strike: 105,
      timeToExpiryYears: 0.75,
      riskFreeRate: 0.03,
      dividendYield: 0.02,
      volatility: 0.22,
      optionType: 'PUT'
    });
    const deltaDiff = callRes.greeks.delta - putRes.greeks.delta;
    const expected = Math.exp(-0.02 * 0.75);
    const diff = Math.abs(deltaDiff - expected);
    results.push({
      id: 'TC-03',
      category: 'PROPERTY',
      name: 'Delta Identity Relationship',
      description: 'Delta_call - Delta_put must equal discount factor exp(-q*T)',
      passed: diff < 1e-9,
      actualValue: deltaDiff.toFixed(7),
      expectedValue: expected.toFixed(7),
      tolerance: '< 1e-9',
      errorDelta: diff,
      durationMs: performance.now() - tStart
    });
  }

  // 4. Implied Volatility Brent Solver Recovery
  {
    const tStart = performance.now();
    const trueVol = 0.3245;
    const synthPrice = calculateBsm({
      spot: 5820,
      strike: 5800,
      timeToExpiryYears: 0.25,
      riskFreeRate: 0.045,
      dividendYield: 0.015,
      volatility: trueVol,
      optionType: 'CALL'
    }).theoreticalPrice;

    const solver = solveImpliedVolatility(synthPrice, {
      spot: 5820,
      strike: 5800,
      timeToExpiryYears: 0.25,
      riskFreeRate: 0.045,
      dividendYield: 0.015,
      optionType: 'CALL'
    });

    const diff = Math.abs(solver.impliedVol - trueVol);
    results.push({
      id: 'TC-04',
      category: 'NUMERICAL_SOLVER',
      name: 'Brent IV Exact Root Recovery',
      description: 'Recovers exact volatility 32.45% from theoretical Black-Scholes price',
      passed: solver.converged && diff < 1e-5,
      actualValue: `${(solver.impliedVol * 100).toFixed(4)}%`,
      expectedValue: `${(trueVol * 100).toFixed(4)}%`,
      tolerance: '< 1e-5 (0.001% vol)',
      errorDelta: diff,
      durationMs: performance.now() - tStart
    });
  }

  // 5. American Put Early Exercise Premium in High-Rate Environment
  {
    const tStart = performance.now();
    // Deep ITM Put with S=80, K=100, r=0.10, T=1.0: American early exercise must exceed European value
    const eurPut = calculateBsm({
      spot: 80,
      strike: 100,
      timeToExpiryYears: 1.0,
      riskFreeRate: 0.10,
      dividendYield: 0.0,
      volatility: 0.20,
      optionType: 'PUT'
    }).theoreticalPrice;

    const amPut = calculateBinomialTree({
      spot: 80,
      strike: 100,
      timeToExpiryYears: 1.0,
      riskFreeRate: 0.10,
      dividendYield: 0.0,
      volatility: 0.20,
      optionType: 'PUT',
      exerciseStyle: 'AMERICAN',
      steps: 150
    }).theoreticalPrice;

    const premium = amPut - eurPut;
    // American put must be at least immediate intrinsic = 20.0, whereas European is discounted = ~16.5
    results.push({
      id: 'TC-05',
      category: 'EARLY_EXERCISE',
      name: 'American Put Early Exercise Premium',
      description: 'American put price must be >= intrinsic (20.0) and exceed European discounted value',
      passed: amPut >= 19.99 && premium > 3.0,
      actualValue: `Am=$${amPut.toFixed(2)} (Prem=$${premium.toFixed(2)})`,
      expectedValue: 'Am >= $20.00 (Prem > $3.00)',
      tolerance: 'Prem >= 0',
      errorDelta: Math.max(0, 20.0 - amPut),
      durationMs: performance.now() - tStart
    });
  }

  // 6. Vanilla Swap Par Rate & Zero NPV
  {
    const tStart = performance.now();
    const swapCalc = calculateVanillaSwap({
      notional: 10000000,
      maturityYears: 5.0,
      fixedRate: 0.0382, // will be evaluated against par rate
      paymentFrequencyPerYear: 2,
      curveDiscountRates: SOFR_ZERO_CURVE,
      payerOrReceiver: 'PAY_FIXED'
    });
    // Now price at the exact calculated parSwapRate
    const parSwap = calculateVanillaSwap({
      notional: 10000000,
      maturityYears: 5.0,
      fixedRate: swapCalc.parSwapRate,
      paymentFrequencyPerYear: 2,
      curveDiscountRates: SOFR_ZERO_CURVE,
      payerOrReceiver: 'PAY_FIXED'
    });
    const diff = Math.abs(parSwap.npv);
    results.push({
      id: 'TC-06',
      category: 'SWAP_DCF',
      name: 'Interest Rate Swap Par Rate NPV Balance',
      description: 'At the par swap rate, Pay-Fixed NPV must be identically 0.00',
      passed: diff < 0.01, // Less than 1 cent on $10M notional
      actualValue: `$${parSwap.npv.toFixed(4)}`,
      expectedValue: '$0.0000',
      tolerance: '< $0.01 on $10M notional',
      errorDelta: diff,
      durationMs: performance.now() - tStart
    });
  }

  // 7. SVI Volatility Smile Parameter Bounds & No-Arbitrage Check
  {
    const tStart = performance.now();
    const validParams = { a: 0.04, b: 0.10, rho: -0.4, m: 0.0, sigma: 0.12 };
    const check = validateSviArbitrage(validParams, [-0.5, -0.2, 0.0, 0.2, 0.5]);
    results.push({
      id: 'TC-07',
      category: 'SVI_ARBITRAGE',
      name: 'SVI Roger Lee Boundary Validation',
      description: 'Verifies positive total variance and absence of butterfly arbitrage',
      passed: check.isValid,
      actualValue: check.isValid ? 'NO ARBITRAGE DETECTED' : 'VIOLATION DETECTED',
      expectedValue: 'NO ARBITRAGE DETECTED',
      tolerance: 'Strict Invariant',
      errorDelta: check.isValid ? 0 : 1,
      durationMs: performance.now() - tStart
    });
  }

  const totalDurationMs = performance.now() - overallStart;
  const passCount = results.filter(r => r.passed).length;

  return {
    results,
    totalCount: results.length,
    passCount,
    failCount: results.length - passCount,
    totalDurationMs
  };
}
