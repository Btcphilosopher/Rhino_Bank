/**
 * RhinoQuant Deterministic Market Data Fixtures & Chains
 * All fixtures are timestamped, typed, and verifiable.
 */

import { MarketDataSnapshot, OptionContractSpec, SVIParameters } from './types';

export const FIXTURE_SNAPSHOTS: Record<string, MarketDataSnapshot> = {
  SPX: {
    snapshotId: 'SNAP-SPX-20261017-0930',
    source: 'FIXTURE_SPX',
    timestamp: '2026-10-17T09:30:00Z',
    isStale: false,
    stalenessAgeSec: 14,
    underlyingSymbol: 'SPX',
    currency: 'USD',
    spotPrice: 5820.50,
    spotBid: 5820.25,
    spotAsk: 5820.75,
    riskFreeRate: 0.0435,      // 4.35% SOFR-linked curve
    dividendYield: 0.0135,     // 1.35% continuous dividend yield
    borrowCostBps: 25,         // 25 bps general collateral
    repoSpreadBps: 12,
    convenienceYield: 0,
    storageCost: 0
  },
  AAPL: {
    snapshotId: 'SNAP-AAPL-20261017-0930',
    source: 'FIXTURE_AAPL',
    timestamp: '2026-10-17T09:30:00Z',
    isStale: false,
    stalenessAgeSec: 22,
    underlyingSymbol: 'AAPL',
    currency: 'USD',
    spotPrice: 232.40,
    spotBid: 232.35,
    spotAsk: 232.45,
    riskFreeRate: 0.0440,
    dividendYield: 0.0055,
    borrowCostBps: 35,
    repoSpreadBps: 15,
    convenienceYield: 0,
    storageCost: 0
  },
  EURUSD: {
    snapshotId: 'SNAP-EURUSD-20261017-0930',
    source: 'FIXTURE_EURUSD',
    timestamp: '2026-10-17T09:30:00Z',
    isStale: false,
    stalenessAgeSec: 8,
    underlyingSymbol: 'EURUSD',
    currency: 'USD',
    spotPrice: 1.0850,
    spotBid: 1.0849,
    spotAsk: 1.0851,
    riskFreeRate: 0.0450,
    dividendYield: 0,
    borrowCostBps: 0,
    repoSpreadBps: 5,
    convenienceYield: 0,
    storageCost: 0,
    domesticRate: 0.0450,      // USD rate
    foreignRate: 0.0325        // EUR rate
  },
  WTI: {
    snapshotId: 'SNAP-WTI-20261017-0930',
    source: 'CUSTOM',
    timestamp: '2026-10-17T09:30:00Z',
    isStale: true,
    stalenessAgeSec: 3600,     // 1 hour old - triggers staleness warning
    underlyingSymbol: 'CL',
    currency: 'USD',
    spotPrice: 78.40,
    spotBid: 78.35,
    spotAsk: 78.45,
    riskFreeRate: 0.0425,
    dividendYield: 0,
    borrowCostBps: 0,
    repoSpreadBps: 10,
    convenienceYield: 0.032,   // 3.2% convenience yield
    storageCost: 0.018         // 1.8% physical storage expense
  }
};

export const SOFR_ZERO_CURVE: { tenor: number; label: string; zeroRate: number; parSwapRate: number }[] = [
  { tenor: 0.25, label: '3M', zeroRate: 0.0475, parSwapRate: 0.0475 },
  { tenor: 0.50, label: '6M', zeroRate: 0.0465, parSwapRate: 0.0466 },
  { tenor: 1.0, label: '1Y', zeroRate: 0.0445, parSwapRate: 0.0447 },
  { tenor: 2.0, label: '2Y', zeroRate: 0.0415, parSwapRate: 0.0418 },
  { tenor: 3.0, label: '3Y', zeroRate: 0.0398, parSwapRate: 0.0401 },
  { tenor: 5.0, label: '5Y', zeroRate: 0.0382, parSwapRate: 0.0385 },
  { tenor: 7.0, label: '7Y', zeroRate: 0.0385, parSwapRate: 0.0388 },
  { tenor: 10.0, label: '10Y', zeroRate: 0.0392, parSwapRate: 0.0395 },
  { tenor: 20.0, label: '20Y', zeroRate: 0.0420, parSwapRate: 0.0422 },
  { tenor: 30.0, label: '30Y', zeroRate: 0.0435, parSwapRate: 0.0436 }
];

// Helper to generate options chains with realistic volatility skew
export function generateOptionsChain(
  underlying: string,
  spot: number,
  r: number,
  q: number,
  expiryDays = 45
): OptionContractSpec[] {
  const T = expiryDays / 365.0;
  const strikes: number[] = [];
  const baseStep = underlying === 'SPX' ? 50 : 2.5;
  const numStrikesEachSide = 8;
  const atmStrike = Math.round(spot / baseStep) * baseStep;

  for (let i = -numStrikesEachSide; i <= numStrikesEachSide; i++) {
    strikes.push(Number((atmStrike + i * baseStep).toFixed(2)));
  }

  const contracts: OptionContractSpec[] = [];
  const baseVol = underlying === 'SPX' ? 0.165 : 0.245;

  for (const strike of strikes) {
    const moneyness = strike / spot;
    // Volatility skew model: equity index negative skew (higher vol for OTM puts)
    const logM = Math.log(moneyness);
    const skew = -0.35 * logM + 0.55 * logM * logM;
    const iv = Math.max(0.08, baseVol + skew);

    // Call market price with bid-ask spread
    const d1 = (Math.log(spot / strike) + (r - q + 0.5 * iv * iv) * T) / (iv * Math.sqrt(T));
    const d2 = d1 - iv * Math.sqrt(T);
    // Rough normal CDF for market mock quote
    const nCdf = (x: number) => 0.5 * (1 + Math.tanh(x * 0.797885));
    const callTheo = Math.max(0.01, spot * Math.exp(-q * T) * nCdf(d1) - strike * Math.exp(-r * T) * nCdf(d2));
    const putTheo = Math.max(0.01, strike * Math.exp(-r * T) * nCdf(-d2) - spot * Math.exp(-q * T) * nCdf(-d1));

    const halfSpread = underlying === 'SPX' ? 0.40 : 0.08;

    // Call Contract
    contracts.push({
      symbol: `${underlying}-${expiryDays}D-${strike}C`,
      underlying,
      optionType: 'CALL',
      exerciseStyle: underlying === 'SPX' ? 'EUROPEAN' : 'AMERICAN',
      strike,
      expiryDate: new Date(Date.now() + expiryDays * 86400000).toISOString().split('T')[0],
      timeToExpiryYears: T,
      multiplier: 100,
      marketBid: Math.max(0.05, Number((callTheo - halfSpread).toFixed(2))),
      marketAsk: Number((callTheo + halfSpread).toFixed(2)),
      marketMid: Number(callTheo.toFixed(2)),
      impliedVolMid: Number(iv.toFixed(4)),
      openInterest: Math.floor(1200 + Math.random() * 4500),
      volume: Math.floor(250 + Math.random() * 1800)
    });

    // Put Contract
    contracts.push({
      symbol: `${underlying}-${expiryDays}D-${strike}P`,
      underlying,
      optionType: 'PUT',
      exerciseStyle: underlying === 'SPX' ? 'EUROPEAN' : 'AMERICAN',
      strike,
      expiryDate: new Date(Date.now() + expiryDays * 86400000).toISOString().split('T')[0],
      timeToExpiryYears: T,
      multiplier: 100,
      marketBid: Math.max(0.05, Number((putTheo - halfSpread).toFixed(2))),
      marketAsk: Number((putTheo + halfSpread).toFixed(2)),
      marketMid: Number(putTheo.toFixed(2)),
      impliedVolMid: Number(iv.toFixed(4)),
      openInterest: Math.floor(1500 + Math.random() * 5200),
      volume: Math.floor(300 + Math.random() * 2100)
    });
  }

  return contracts;
}

export const SPX_OPTIONS_CHAIN = generateOptionsChain('SPX', 5820.50, 0.0435, 0.0135, 45);
export const AAPL_OPTIONS_CHAIN = generateOptionsChain('AAPL', 232.40, 0.0440, 0.0055, 30);
