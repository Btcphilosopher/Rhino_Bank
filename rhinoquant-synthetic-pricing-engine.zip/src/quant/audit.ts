/**
 * RhinoQuant Calculation Provenance & Audit Store
 * Invariant: Every calculation is recorded with inputs, outputs, and reproduction hash.
 */

import { CalculationRecord } from './types';

// Deterministic fast hash function for calculation provenance
export function computeInputHash(inputs: Record<string, any>): string {
  const jsonStr = JSON.stringify(inputs, Object.keys(inputs).sort());
  let hash = 5381;
  for (let i = 0; i < jsonStr.length; i++) {
    hash = ((hash << 5) + hash) + jsonStr.charCodeAt(i);
    hash |= 0;
  }
  const hex = (hash >>> 0).toString(16).padStart(8, '0');
  return `0x${hex}`;
}

export class ProvenanceLedger {
  private static instance: ProvenanceLedger;
  private records: Map<string, CalculationRecord> = new Map();

  private constructor() {
    // Seed with an initial sample calculation
    this.recordCalculation({
      calculationId: 'CALC-INIT-001',
      inputHash: '0x3f8a91b2',
      requestTimestamp: '2026-10-17T09:30:15.120Z',
      valuationTimestamp: '2026-10-17T09:30:00.000Z',
      modelIdentifier: 'Black-Scholes-Merton',
      modelVersion: '3.12-INSTITUTIONAL',
      softwareBuildId: 'build-rhino-2026.10-rc2',
      marketSnapshotId: 'SNAP-SPX-20261017-0930',
      instrumentType: 'VANILLA_OPTION',
      inputs: {
        spot: 5820.50,
        strike: 5800.00,
        timeToExpiryYears: 0.12328,
        riskFreeRate: 0.0435,
        dividendYield: 0.0135,
        volatility: 0.165,
        optionType: 'CALL'
      },
      outputs: {
        theoreticalPrice: 138.4521,
        intrinsicValue: 20.50,
        timeValue: 117.9521,
        delta: 0.5842,
        gamma: 0.00192,
        vega: 7.9421,
        theta: -0.8412,
        rho: 2.1450
      },
      warnings: [],
      numericalDiagnostics: {
        runtimeMs: 0.42,
        converged: true,
        precision: 'Float64-Analytic'
      }
    });
  }

  public static getInstance(): ProvenanceLedger {
    if (!ProvenanceLedger.instance) {
      ProvenanceLedger.instance = new ProvenanceLedger();
    }
    return ProvenanceLedger.instance;
  }

  public recordCalculation(record: CalculationRecord): void {
    this.records.set(record.calculationId, record);
  }

  public getCalculation(id: string): CalculationRecord | undefined {
    return this.records.get(id);
  }

  public getAllRecords(): CalculationRecord[] {
    return Array.from(this.records.values()).reverse();
  }

  public findByHash(hash: string): CalculationRecord[] {
    return Array.from(this.records.values()).filter(r => r.inputHash === hash);
  }
}
