import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { 
  SpotInstrument, 
  CandlestickData, 
  OrderBook, 
  FuturesContract, 
  OptionContract, 
  ForwardCurvePoint, 
  PhysicalWarehouseInventory, 
  LogisticsMovement, 
  AgriculturalIntelligence,
  BasisPoint,
  Trade,
  Order,
  Position,
  PortfolioSummary,
  CommodityCategory,
  OrderSide,
  OrderType,
  TimeInForce,
  ActiveView,
  ToastNotification
} from '../types/market';
import {
  INITIAL_SPOT_INSTRUMENTS,
  VOLATILITY_INDICES,
  GENERATE_SAMPLE_CANDLESTICKS,
  INITIAL_ORDER_BOOK,
  INITIAL_TRADES,
  FUTURES_CONTRACTS,
  FORWARD_CURVE_DATA,
  OPTIONS_CHAIN_DEC26,
  PHYSICAL_INVENTORY,
  LOGISTICS_MOVEMENTS,
  AGRICULTURAL_INTELLIGENCE,
  UK_BASIS_REGIONS,
  INITIAL_POSITIONS,
  INITIAL_PORTFOLIO
} from '../services/mockMarketData';

export type { ActiveView };
export type ToastMessage = ToastNotification;

interface MarketContextType {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  selectedCategory: CommodityCategory;
  setSelectedCategory: (cat: CommodityCategory) => void;
  spotInstruments: SpotInstrument[];
  selectedInstrument: SpotInstrument;
  setSelectedInstrument: (inst: SpotInstrument) => void;
  chartData: CandlestickData[];
  chartTimeframe: string;
  setChartTimeframe: (tf: string) => void;
  chartType: 'CANDLE' | 'LINE' | 'AREA' | 'OHLC';
  setChartType: (ct: 'CANDLE' | 'LINE' | 'AREA' | 'OHLC') => void;
  showIndicators: { vwap: boolean; ma20: boolean; volume: boolean; bollinger: boolean };
  setShowIndicators: React.Dispatch<React.SetStateAction<{ vwap: boolean; ma20: boolean; volume: boolean; bollinger: boolean }>>;
  orderBook: OrderBook;
  recentTrades: Trade[];
  activeOrders: Order[];
  futuresContracts: FuturesContract[];
  selectedFuture: FuturesContract;
  setSelectedFuture: (f: FuturesContract) => void;
  forwardCurve: ForwardCurvePoint[];
  optionsChain: OptionContract[];
  physicalInventory: PhysicalWarehouseInventory[];
  logisticsMovements: LogisticsMovement[];
  intelligenceNews: AgriculturalIntelligence[];
  selectedNewsArticle: AgriculturalIntelligence | null;
  setSelectedNewsArticle: (news: AgriculturalIntelligence | null) => void;
  basisRegions: BasisPoint[];
  userPositions: Position[];
  portfolio: PortfolioSummary;
  volatilityIndices: typeof VOLATILITY_INDICES;
  placeOrder: (orderParams: {
    side: OrderSide;
    type: OrderType;
    quantity: number;
    price: number;
    grade: string;
    region: string;
    timeInForce?: TimeInForce;
    deliveryPeriod?: string;
    icebergVisibleQty?: number;
  }) => Order;
  cancelOrder: (orderId: string) => void;
  toasts: ToastMessage[];
  dismissToast: (id: string) => void;
  toastNotifications: ToastMessage[];
  removeToast: (id: string) => void;
  executePhysicalHedge: (params: {
    physicalQty: number;
    futuresQuantityContracts: number;
    hedgeInstrument: string;
    optionsProtectedStrike?: number;
  }) => void;
  orderPendingConfirmation: {
    isOpen: boolean;
    orderParams: any;
    instrument: SpotInstrument;
  } | null;
  setOrderPendingConfirmation: (val: any) => void;
  confirmPendingOrder: () => void;
}

const MarketContext = createContext<MarketContextType | undefined>(undefined);

export const MarketProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<ActiveView>('HOME');
  const [selectedCategory, setSelectedCategory] = useState<CommodityCategory>('GRAINS');
  const [spotInstruments, setSpotInstruments] = useState<SpotInstrument[]>(INITIAL_SPOT_INSTRUMENTS);
  const [selectedInstrument, setSelectedInstrument] = useState<SpotInstrument>(INITIAL_SPOT_INSTRUMENTS[0]);
  const [chartData, setChartData] = useState<CandlestickData[]>(() => GENERATE_SAMPLE_CANDLESTICKS(185.25, 40));
  const [chartTimeframe, setChartTimeframe] = useState<string>('1D');
  const [chartType, setChartType] = useState<'CANDLE' | 'LINE' | 'AREA' | 'OHLC'>('CANDLE');
  const [showIndicators, setShowIndicators] = useState({ vwap: true, ma20: true, volume: true, bollinger: false });
  const [orderBook, setOrderBook] = useState<OrderBook>(INITIAL_ORDER_BOOK);
  const [recentTrades, setRecentTrades] = useState<Trade[]>(INITIAL_TRADES);
  const [activeOrders, setActiveOrders] = useState<Order[]>([]);
  const [futuresContracts, setFuturesContracts] = useState<FuturesContract[]>(FUTURES_CONTRACTS);
  const [selectedFuture, setSelectedFuture] = useState<FuturesContract>(FUTURES_CONTRACTS[0]);
  const [forwardCurve] = useState<ForwardCurvePoint[]>(FORWARD_CURVE_DATA);
  const [optionsChain] = useState<OptionContract[]>(OPTIONS_CHAIN_DEC26);
  const [physicalInventory, setPhysicalInventory] = useState<PhysicalWarehouseInventory[]>(PHYSICAL_INVENTORY);
  const [logisticsMovements] = useState<LogisticsMovement[]>(LOGISTICS_MOVEMENTS);
  const [intelligenceNews] = useState<AgriculturalIntelligence[]>(AGRICULTURAL_INTELLIGENCE);
  const [selectedNewsArticle, setSelectedNewsArticle] = useState<AgriculturalIntelligence | null>(null);
  const [basisRegions] = useState<BasisPoint[]>(UK_BASIS_REGIONS);
  const [userPositions, setUserPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [portfolio, setPortfolio] = useState<PortfolioSummary>(INITIAL_PORTFOLIO);
  const [volatilityIndices, setVolatilityIndices] = useState(VOLATILITY_INDICES);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [orderPendingConfirmation, setOrderPendingConfirmation] = useState<{
    isOpen: boolean;
    orderParams: any;
    instrument: SpotInstrument;
  } | null>(null);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id' | 'timestamp'>) => {
    const newToast: ToastMessage = {
      ...toast,
      id: `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
    setToasts((prev) => [newToast, ...prev.slice(0, 4)]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 5000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // When selected instrument changes, reload matching chart data and initial order book
  useEffect(() => {
    setChartData(GENERATE_SAMPLE_CANDLESTICKS(selectedInstrument.last, 42));
    const base = selectedInstrument.last;
    setOrderBook({
      symbol: selectedInstrument.symbol,
      spread: Number((selectedInstrument.ask - selectedInstrument.bid).toFixed(2)),
      midPrice: Number(((selectedInstrument.ask + selectedInstrument.bid) / 2).toFixed(2)),
      vwap: selectedInstrument.vwap,
      totalBidVolume: 5800 + Math.floor(Math.random() * 800),
      totalAskVolume: 5900 + Math.floor(Math.random() * 800),
      bids: [
        { price: Number((base - 0.25).toFixed(2)), volume: 250 + Math.floor(Math.random() * 80), total: 250, orderCount: 3 },
        { price: Number((base - 0.75).toFixed(2)), volume: 520 + Math.floor(Math.random() * 100), total: 770, orderCount: 6 },
        { price: Number((base - 1.25).toFixed(2)), volume: 1100 + Math.floor(Math.random() * 150), total: 1870, orderCount: 12 },
        { price: Number((base - 1.75).toFixed(2)), volume: 1860 + Math.floor(Math.random() * 200), total: 3730, orderCount: 19 },
        { price: Number((base - 2.25).toFixed(2)), volume: 2320 + Math.floor(Math.random() * 250), total: 6050, orderCount: 29 },
      ],
      asks: [
        { price: Number((base + 0.25).toFixed(2)), volume: 300 + Math.floor(Math.random() * 90), total: 300, orderCount: 4 },
        { price: Number((base + 0.75).toFixed(2)), volume: 480 + Math.floor(Math.random() * 110), total: 780, orderCount: 7 },
        { price: Number((base + 1.25).toFixed(2)), volume: 920 + Math.floor(Math.random() * 140), total: 1700, orderCount: 14 },
        { price: Number((base + 1.75).toFixed(2)), volume: 1400 + Math.floor(Math.random() * 180), total: 3100, orderCount: 18 },
        { price: Number((base + 2.25).toFixed(2)), volume: 2100 + Math.floor(Math.random() * 240), total: 5200, orderCount: 26 },
      ]
    });
  }, [selectedInstrument.id]);

  // Subtle real-time market drift simulation (150-300ms responsive feel, smooth tick updates)
  useEffect(() => {
    const interval = setInterval(() => {
      // Small chance to update a random spot instrument price
      setSpotInstruments((prev) => {
        const indexToUpdate = Math.floor(Math.random() * prev.length);
        return prev.map((inst, idx) => {
          if (idx !== indexToUpdate) return inst;
          const tick = (Math.random() > 0.48 ? 1 : -1) * (0.10 + Math.random() * 0.15);
          const newLast = Math.max(1, Number((inst.last + tick).toFixed(2)));
          const spreadHalf = 0.50;
          const newBid = Number((newLast - spreadHalf).toFixed(2));
          const newAsk = Number((newLast + spreadHalf).toFixed(2));
          const newChange = Number((inst.change + tick).toFixed(2));
          const newChangePercent = Number(((newChange / (newLast - newChange)) * 100).toFixed(2));

          // If this is currently selected, update order book as well
          if (inst.id === selectedInstrument.id) {
            setSelectedInstrument((curr) => ({
              ...curr,
              last: newLast,
              bid: newBid,
              ask: newAsk,
              change: newChange,
              changePercent: newChangePercent
            }));
          }

          return {
            ...inst,
            last: newLast,
            bid: newBid,
            ask: newAsk,
            change: newChange,
            changePercent: newChangePercent
          };
        });
      });

      // Occasional trade tick
      if (Math.random() > 0.65) {
        const isSelected = Math.random() > 0.3;
        const targetInst = isSelected ? selectedInstrument : spotInstruments[Math.floor(Math.random() * spotInstruments.length)];
        const qty = [25, 50, 75, 100, 150, 200, 300][Math.floor(Math.random() * 7)];
        const side: OrderSide = Math.random() > 0.45 ? 'BUY' : 'SELL';
        const price = side === 'BUY' ? targetInst.ask : targetInst.bid;
        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

        const newTrade: Trade = {
          id: `TRD-${Date.now().toString().slice(-5)}`,
          time: timeStr,
          timestamp: Date.now(),
          instrumentName: `${targetInst.name} (${targetInst.region})`,
          grade: targetInst.grade,
          region: targetInst.region,
          side,
          quantity: qty,
          price,
          notional: Number((qty * price).toFixed(2)),
          unit: targetInst.unit === 'tonne' ? 't' : targetInst.unit
        };

        setRecentTrades((prev) => [newTrade, ...prev.slice(0, 15)]);

        // Push slight chart tick
        setChartData((prev) => {
          if (prev.length === 0) return prev;
          const lastPoint = { ...prev[prev.length - 1] };
          lastPoint.close = price;
          lastPoint.high = Math.max(lastPoint.high, price);
          lastPoint.low = Math.min(lastPoint.low, price);
          lastPoint.volume += qty;
          return [...prev.slice(0, -1), lastPoint];
        });
      }

      // Mild Volatility index fluctuation
      if (Math.random() > 0.8) {
        setVolatilityIndices((prev) => ({
          wheat: {
            ...prev.wheat,
            value: Number((prev.wheat.value + (Math.random() - 0.49) * 0.08).toFixed(2))
          },
          barley: {
            ...prev.barley,
            value: Number((prev.barley.value + (Math.random() - 0.49) * 0.06).toFixed(2))
          }
        }));
      }
    }, 3200);

    return () => clearInterval(interval);
  }, [selectedInstrument, spotInstruments]);

  const placeOrder = (orderParams: {
    side: OrderSide;
    type: OrderType;
    quantity: number;
    price: number;
    grade: string;
    region: string;
    timeInForce?: TimeInForce;
    deliveryPeriod?: string;
    icebergVisibleQty?: number;
  }): Order => {
    const notional = Number((orderParams.quantity * orderParams.price).toFixed(2));
    const feeRate = 0.0012; // 12 bps institutional exchange fee
    const fees = Number((notional * feeRate).toFixed(2));

    const newOrder: Order = {
      id: `ORD-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      instrumentId: selectedInstrument.id,
      instrumentName: selectedInstrument.name,
      side: orderParams.side,
      type: orderParams.type,
      grade: orderParams.grade,
      region: orderParams.region,
      quantity: orderParams.quantity,
      filledQuantity: orderParams.type === 'MARKET' ? orderParams.quantity : 0,
      price: orderParams.price,
      avgFillPrice: orderParams.type === 'MARKET' ? orderParams.price : undefined,
      timeInForce: orderParams.timeInForce || 'GTC',
      status: orderParams.type === 'MARKET' ? 'FILLED' : 'PENDING',
      notionalValue: notional,
      fees,
      deliveryPeriod: orderParams.deliveryPeriod || 'Spot Delivery (T+2)',
      icebergVisibleQty: orderParams.icebergVisibleQty
    };

    setActiveOrders((prev) => [newOrder, ...prev]);

    // If Market order or match, immediately create trade and update positions & portfolio
    if (orderParams.type === 'MARKET') {
      const execTrade: Trade = {
        id: `TRD-${Date.now().toString().slice(-5)}`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        timestamp: Date.now(),
        instrumentName: `${selectedInstrument.name} (${orderParams.region})`,
        grade: orderParams.grade,
        region: orderParams.region,
        side: orderParams.side,
        quantity: orderParams.quantity,
        price: orderParams.price,
        notional,
        unit: selectedInstrument.unit === 'tonne' ? 't' : selectedInstrument.unit
      };
      setRecentTrades((prev) => [execTrade, ...prev.slice(0, 15)]);

      // Update position or add new
      setUserPositions((prev) => {
        const existingIdx = prev.findIndex(p => p.instrumentId === selectedInstrument.id && p.type === 'SPOT');
        if (existingIdx >= 0) {
          const existing = prev[existingIdx];
          const newQty = orderParams.side === 'BUY' ? existing.quantity + orderParams.quantity : existing.quantity - orderParams.quantity;
          const updated = [...prev];
          if (newQty <= 0) {
            updated.splice(existingIdx, 1);
          } else {
            updated[existingIdx] = {
              ...existing,
              quantity: newQty,
              currentPrice: orderParams.price,
              unrealisedPnl: Number(((orderParams.price - existing.entryPrice) * newQty).toFixed(2))
            };
          }
          return updated;
        } else {
          return [
            ...prev,
            {
              id: `POS-${Date.now().toString().slice(-4)}`,
              instrumentId: selectedInstrument.id,
              symbol: selectedInstrument.symbol,
              name: `${selectedInstrument.name} (${selectedInstrument.region})`,
              type: 'SPOT',
              side: orderParams.side === 'BUY' ? 'LONG' : 'SHORT',
              quantity: orderParams.quantity,
              unit: 't',
              entryPrice: orderParams.price,
              currentPrice: orderParams.price,
              unrealisedPnl: 0,
              unrealisedPnlPercent: 0,
              realisedPnl: 0,
              marginLocked: 0,
              delta: orderParams.side === 'BUY' ? orderParams.quantity : -orderParams.quantity
            }
          ];
        }
      });

      // Update portfolio cash & NAV
      setPortfolio((prev) => ({
        ...prev,
        availableCashGbp: orderParams.side === 'BUY' ? prev.availableCashGbp - notional - fees : prev.availableCashGbp + notional - fees,
        spotExposureGbp: orderParams.side === 'BUY' ? prev.spotExposureGbp + notional : prev.spotExposureGbp - notional,
        dailyRealisedPnlGbp: prev.dailyRealisedPnlGbp + 450
      }));

      addToast({
        type: 'SUCCESS',
        title: 'Order Executed (Filled)',
        message: `${orderParams.side} ${orderParams.quantity}t ${selectedInstrument.name} @ £${orderParams.price.toFixed(2)} on LCH Settlement.`
      });
    } else {
      addToast({
        type: 'INFO',
        title: 'Order Placed on Book',
        message: `Limit ${orderParams.side} ${orderParams.quantity}t @ £${orderParams.price.toFixed(2)} (Ref: ${newOrder.id})`
      });
    }

    return newOrder;
  };

  const cancelOrder = (orderId: string) => {
    setActiveOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: 'CANCELLED' } : ord))
    );
    addToast({
      type: 'WARNING',
      title: 'Order Cancelled',
      message: `Order ${orderId} has been successfully withdrawn from the book.`
    });
  };

  const confirmPendingOrder = () => {
    if (orderPendingConfirmation) {
      placeOrder(orderPendingConfirmation.orderParams);
      setOrderPendingConfirmation(null);
    }
  };

  const executePhysicalHedge = ({
    physicalQty,
    futuresQuantityContracts,
    hedgeInstrument,
    optionsProtectedStrike
  }: {
    physicalQty: number;
    futuresQuantityContracts: number;
    hedgeInstrument: string;
    optionsProtectedStrike?: number;
  }) => {
    const notionalHedged = futuresQuantityContracts * 100 * 188.50; // £188.50 Nov 26 contract
    const marginReq = futuresQuantityContracts * 850;

    // Add hedge position
    const hedgePos: Position = {
      id: `POS-HDG-${Date.now().toString().slice(-4)}`,
      instrumentId: 'FUT-WHT-NOV26',
      symbol: 'UKW-NOV26',
      name: `${hedgeInstrument} (Short Hedge)`,
      type: 'FUTURES',
      side: 'SHORT',
      quantity: futuresQuantityContracts,
      unit: 'contracts',
      entryPrice: 188.50,
      currentPrice: 188.50,
      unrealisedPnl: 0,
      unrealisedPnlPercent: 0,
      realisedPnl: 0,
      marginLocked: marginReq,
      delta: -(futuresQuantityContracts * 100)
    };

    setUserPositions((prev) => [hedgePos, ...prev]);

    setPortfolio((prev) => ({
      ...prev,
      collateralLockedGbp: prev.collateralLockedGbp + marginReq,
      availableCashGbp: prev.availableCashGbp - marginReq,
      futuresExposureGbp: prev.futuresExposureGbp - notionalHedged,
      netDeltaGbp: prev.netDeltaGbp - (futuresQuantityContracts * 100)
    }));

    addToast({
      type: 'SUCCESS',
      title: 'Physical Hedge Established',
      message: `Hedged ${physicalQty.toLocaleString()} tonnes with ${futuresQuantityContracts}x ${hedgeInstrument} Short Contracts. Net Delta neutralised.`
    });
  };

  return (
    <MarketContext.Provider
      value={{
        activeView,
        setActiveView,
        selectedCategory,
        setSelectedCategory,
        spotInstruments,
        selectedInstrument,
        setSelectedInstrument,
        chartData,
        chartTimeframe,
        setChartTimeframe,
        chartType,
        setChartType,
        showIndicators,
        setShowIndicators,
        orderBook,
        recentTrades,
        activeOrders,
        futuresContracts,
        selectedFuture,
        setSelectedFuture,
        forwardCurve,
        optionsChain,
        physicalInventory,
        logisticsMovements,
        intelligenceNews,
        selectedNewsArticle,
        setSelectedNewsArticle,
        basisRegions,
        userPositions,
        portfolio,
        volatilityIndices,
        placeOrder,
        cancelOrder,
        toasts,
        dismissToast,
        toastNotifications: toasts,
        removeToast: dismissToast,
        executePhysicalHedge,
        orderPendingConfirmation,
        setOrderPendingConfirmation,
        confirmPendingOrder
      }}
    >
      {children}
    </MarketContext.Provider>
  );
};

export const useMarket = () => {
  const context = useContext(MarketContext);
  if (!context) {
    throw new Error('useMarket must be used within a MarketProvider');
  }
  return context;
};
