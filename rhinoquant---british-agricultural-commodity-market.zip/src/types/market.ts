export type CommodityCategory = 
  | 'GRAINS' 
  | 'OILSEEDS' 
  | 'LIVESTOCK' 
  | 'DAIRY' 
  | 'POTATOES' 
  | 'SUGAR' 
  | 'FERTILISER' 
  | 'BIOENERGY';

export interface SpotInstrument {
  id: string;
  name: string;
  symbol: string;
  category: CommodityCategory;
  grade: string;
  region: string;
  bid: number;
  ask: number;
  last: number;
  change: number;
  changePercent: number;
  volume: number; // Tonnes or head
  unit: string; // 'tonne', 'head', 'litre'
  high24h: number;
  low24h: number;
  vwap: number;
  openInterest?: number;
  settlementBasis: string;
  moistureSpec?: string;
  proteinSpec?: string;
  weightSpec?: string;
  iconName: string;
}

export interface CandlestickData {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ma20?: number;
  vwap?: number;
}

export interface OrderBookLevel {
  price: number;
  volume: number;
  total: number;
  orderCount: number;
}

export interface OrderBook {
  symbol: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  midPrice: number;
  totalBidVolume: number;
  totalAskVolume: number;
  vwap: number;
}

export type OrderType = 'LIMIT' | 'MARKET' | 'STOP' | 'STOP_LIMIT' | 'ICEBERG';
export type TimeInForce = 'GTC' | 'IOC' | 'FOK' | 'DAY';
export type OrderSide = 'BUY' | 'SELL';
export type OrderStatus = 'PENDING' | 'FILLED' | 'PARTIALLY_FILLED' | 'CANCELLED';

export interface Order {
  id: string;
  timestamp: string;
  instrumentId: string;
  instrumentName: string;
  side: OrderSide;
  type: OrderType;
  grade: string;
  region: string;
  quantity: number;
  filledQuantity: number;
  price: number;
  avgFillPrice?: number;
  timeInForce: TimeInForce;
  status: OrderStatus;
  notionalValue: number;
  fees: number;
  deliveryPeriod: string;
  icebergVisibleQty?: number;
}

export interface Trade {
  id: string;
  time: string;
  timestamp: number;
  instrumentName: string;
  grade: string;
  region: string;
  side: OrderSide;
  quantity: number;
  price: number;
  notional: number;
  unit: string;
}

export interface FuturesContract {
  id: string;
  symbol: string;
  name: string;
  category: CommodityCategory;
  contractMonth: string;
  expiryDate: string;
  bid: number;
  ask: number;
  last: number;
  change: number;
  changePercent: number;
  volume: number;
  openInterest: number;
  settlementPrice: number;
  initialMargin: number; // in £
  maintMargin: number;
  contractSize: string; // e.g. "100 Tonnes"
  deliveryMechanism: 'Physical Warehouse' | 'Cash Settled' | 'Terminal Elevator';
}

export interface OptionContract {
  strike: number;
  call: {
    bid: number;
    ask: number;
    last: number;
    volume: number;
    openInterest: number;
    iv: number; // Implied Vol %
    delta: number;
    gamma: number;
    theta: number;
    vega: number;
  };
  put: {
    bid: number;
    ask: number;
    last: number;
    volume: number;
    openInterest: number;
    iv: number;
    delta: number;
    gamma: number;
    theta: number;
    vega: number;
  };
}

export interface ForwardCurvePoint {
  month: string;
  price: number;
  changeVsSpot: number;
  isSpot?: boolean;
  spreadVsPrevious: number;
  structure: 'Contango' | 'Backwardation' | 'Flat';
}

export interface PhysicalWarehouseInventory {
  id: string;
  warehouseName: string;
  location: string;
  region: string;
  commodity: string;
  grade: string;
  quantityHeld: number; // tonnes
  capacity: number; // tonnes
  allocatedQty: number;
  availableQty: number;
  moisturePercent: number;
  proteinPercent: number;
  testWeight: number; // kg/hl
  hagbergFallingNo: number; // seconds
  certification: string; // e.g. "Red Tractor AIC / TASCC"
  receiptNumber: string;
  dailyStorageCostPerTonne: number;
}

export interface LogisticsMovement {
  id: string;
  reference: string;
  commodity: string;
  quantityTonnes: number;
  origin: string;
  destination: string;
  mode: 'ROAD_BULK' | 'RAIL_FREIGHT' | 'COASTAL_BARGE' | 'PORT_VESSEL';
  carrier: string;
  eta: string;
  status: 'LOADING' | 'IN_TRANSIT' | 'CUSTOMS_CLEAR' | 'DELIVERED' | 'DISCHARGING';
  costGbp: number;
  carbonIntensityKgPerT: number;
  coordinates: {
    from: [number, number];
    to: [number, number];
    current: [number, number];
  };
}

export interface Position {
  id: string;
  instrumentId: string;
  symbol: string;
  name: string;
  type: 'SPOT' | 'FUTURES' | 'OPTIONS' | 'PHYSICAL';
  side: 'LONG' | 'SHORT';
  quantity: number;
  unit: string;
  entryPrice: number;
  currentPrice: number;
  unrealisedPnl: number;
  unrealisedPnlPercent: number;
  realisedPnl: number;
  marginLocked: number;
  delta: number;
}

export interface PortfolioSummary {
  navGbp: number;
  availableCashGbp: number;
  collateralLockedGbp: number;
  physicalInventoryValueGbp: number;
  spotExposureGbp: number;
  futuresExposureGbp: number;
  optionsExposureGbp: number;
  netDeltaGbp: number;
  dailyUnrealisedPnlGbp: number;
  dailyRealisedPnlGbp: number;
  marginUtilisationPercent: number;
  var99_1dGbp: number;
}

export interface AgriculturalIntelligence {
  id: string;
  category: 'DEFRA' | 'WEATHER' | 'HARVEST' | 'EUROPE' | 'GLOBAL_GRAINS' | 'LOGISTICS' | 'ENERGY';
  title: string;
  summary: string;
  fullText: string;
  timestamp: string;
  impact: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  affectedCommodity: string;
  imageUrl?: string;
}

export interface BasisPoint {
  region: string;
  benchmarkPrice: number;
  basisDifferential: number; // e.g. +1.25
  effectivePrice: number;
  freightCostToPort: number;
  primaryBuyers: string[];
  siloStockPct: number;
}

export type ActiveView = 
  | 'HOME' 
  | 'DASHBOARD'
  | 'SPOT' 
  | 'DERIVATIVES' 
  | 'FUTURES'
  | 'OPTIONS'
  | 'ORDER_BOOKS' 
  | 'PORTFOLIO' 
  | 'POSITIONS' 
  | 'INVENTORY' 
  | 'LOGISTICS' 
  | 'MARKET_DATA' 
  | 'ANALYTICS' 
  | 'QUANT_LAB' 
  | 'RISK' 
  | 'REPORTS' 
  | 'SETTINGS'
  | 'HEDGE_PHYSICAL'
  | 'HEDGING'
  | 'BASIS_MARKET'
  | 'BASIS_MAP'
  | 'WAREHOUSES';

export interface ToastNotification {
  id: string;
  type: 'SUCCESS' | 'WARNING' | 'ERROR' | 'INFO';
  title: string;
  message: string;
  timestamp?: number | string;
}


