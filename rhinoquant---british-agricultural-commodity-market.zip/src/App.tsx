/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MarketProvider, useMarket } from './context/MarketContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { FooterBar } from './components/layout/FooterBar';
import { HomeDashboard } from './components/home/HomeDashboard';
import { DerivativesHub } from './components/derivatives/DerivativesHub';
import { HedgePhysicalWizard } from './components/hedging/HedgePhysicalWizard';
import { BasisMarketMap } from './components/basis/BasisMarketMap';
import { LogisticsTerminal } from './components/logistics/LogisticsTerminal';
import { QuantLab } from './components/quant/QuantLab';
import { RiskTerminal } from './components/risk/RiskTerminal';
import { PortfolioOverview } from './components/portfolio/PortfolioOverview';
import { WarehouseReceipts } from './components/reports/WarehouseReceipts';
import { OrderConfirmModal, NewsArticleModal } from './components/modals/Modals';
import { ToastContainer } from './components/common/ToastContainer';

const MainContent: React.FC = () => {
  const { activeView } = useMarket();

  const renderCurrentView = () => {
    switch (activeView) {
      case 'DASHBOARD':
      case 'SPOT':
      case 'ORDER_BOOKS':
        return <HomeDashboard />;
      case 'DERIVATIVES':
      case 'FUTURES':
      case 'OPTIONS':
        return <DerivativesHub />;
      case 'HEDGING':
        return <HedgePhysicalWizard />;
      case 'BASIS_MAP':
        return <BasisMarketMap />;
      case 'LOGISTICS':
        return <LogisticsTerminal />;
      case 'QUANT_LAB':
        return <QuantLab />;
      case 'RISK':
        return <RiskTerminal />;
      case 'PORTFOLIO':
        return <PortfolioOverview />;
      case 'WAREHOUSES':
        return <WarehouseReceipts />;
      default:
        return <HomeDashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#071114] text-[#E2ECE9] font-sans-ui antialiased">
      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Main Terminal Body */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header />

        <main className="flex-1 p-3 md:p-4 overflow-y-auto">
          <div className="max-w-[1720px] mx-auto">
            {renderCurrentView()}
          </div>
        </main>

        <FooterBar />
      </div>

      {/* Overlay Modals & Alerts */}
      <OrderConfirmModal />
      <NewsArticleModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <MarketProvider>
      <MainContent />
    </MarketProvider>
  );
}
