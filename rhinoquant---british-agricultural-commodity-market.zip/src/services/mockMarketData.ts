import { 
  SpotInstrument, 
  CandlestickData, 
  OrderBook, 
  FuturesContract, 
  OptionContract, 
  ForwardCurvePoint, 
  PhysicalWarehouseInventory, 
  LogisticsMovement, 
  AgriculturalIntelligence,
  BasisPoint,
  Trade,
  Order,
  Position,
  PortfolioSummary
} from '../types/market';

export const INITIAL_SPOT_INSTRUMENTS: SpotInstrument[] = [
  {
    id: 'WHEAT-EA-FEED',
    name: 'Wheat',
    symbol: 'WHT-EA',
    category: 'GRAINS',
    grade: 'Feed',
    region: 'East Anglia',
    bid: 184.50,
    ask: 186.00,
    last: 185.25,
    change: 2.20,
    changePercent: 1.2,
    volume: 14250,
    unit: 'tonne',
    high24h: 186.50,
    low24h: 182.80,
    vwap: 185.10,
    settlementBasis: 'Ex-Farm / Delivered Ipswich Port Silo',
    moistureSpec: 'Max 15.0%',
    proteinSpec: 'Min 10.5%',
    weightSpec: 'Min 72.0 kg/hl',
    iconName: 'Wheat'
  },
  {
    id: 'WHEAT-EA-MILL',
    name: 'Wheat',
    symbol: 'WHT-MILL-EA',
    category: 'GRAINS',
    grade: 'Milling',
    region: 'East Anglia',
    bid: 218.00,
    ask: 220.50,
    last: 219.75,
    change: 3.25,
    changePercent: 1.5,
    volume: 8400,
    unit: 'tonne',
    high24h: 221.00,
    low24h: 216.50,
    vwap: 219.20,
    settlementBasis: 'Delivered Flour Mill (Tilbury/Felixstowe)',
    moistureSpec: 'Max 14.5%',
    proteinSpec: 'Min 13.0%',
    weightSpec: 'Min 76.0 kg/hl (Hagberg 250+)',
    iconName: 'Wheat'
  },
  {
    id: 'WHEAT-YORK-FEED',
    name: 'Wheat',
    symbol: 'WHT-YORK',
    category: 'GRAINS',
    grade: 'Feed',
    region: 'Yorkshire',
    bid: 182.50,
    ask: 184.00,
    last: 183.25,
    change: 1.75,
    changePercent: 0.95,
    volume: 9800,
    unit: 'tonne',
    high24h: 184.50,
    low24h: 181.20,
    vwap: 183.05,
    settlementBasis: 'Delivered Hull Silos',
    moistureSpec: 'Max 15.0%',
    proteinSpec: 'Min 10.5%',
    weightSpec: 'Min 72.0 kg/hl',
    iconName: 'Wheat'
  },
  {
    id: 'BARLEY-YORK-FEED',
    name: 'Barley',
    symbol: 'BLY-YORK',
    category: 'GRAINS',
    grade: 'Feed',
    region: 'Yorkshire',
    bid: 162.00,
    ask: 164.50,
    last: 163.00,
    change: 1.30,
    changePercent: 0.8,
    volume: 7600,
    unit: 'tonne',
    high24h: 164.80,
    low24h: 161.50,
    vwap: 162.90,
    settlementBasis: 'Ex-Farm Humber Corridor',
    moistureSpec: 'Max 15.0%',
    proteinSpec: 'Std Feed Grade',
    weightSpec: 'Min 63.0 kg/hl',
    iconName: 'Barley'
  },
  {
    id: 'BARLEY-EM-MALT',
    name: 'Barley',
    symbol: 'BLY-MALT-EM',
    category: 'GRAINS',
    grade: 'Malting',
    region: 'East Midlands',
    bid: 196.50,
    ask: 199.00,
    last: 198.00,
    change: 2.10,
    changePercent: 1.1,
    volume: 6100,
    unit: 'tonne',
    high24h: 199.50,
    low24h: 195.00,
    vwap: 197.80,
    settlementBasis: 'Delivered Burton-on-Trent Maltings',
    moistureSpec: 'Max 14.5%',
    proteinSpec: 'Max 1.65% N (Low Nitrogen)',
    weightSpec: 'Min 65.0 kg/hl (Germination 98%)',
    iconName: 'Barley'
  },
  {
    id: 'RAPESEED-EM-CANOLA',
    name: 'Rapeseed',
    symbol: 'OSR-EM',
    category: 'OILSEEDS',
    grade: 'Canola 40/9/2',
    region: 'East Midlands',
    bid: 378.00,
    ask: 382.50,
    last: 381.00,
    change: 5.60,
    changePercent: 1.5,
    volume: 4800,
    unit: 'tonne',
    high24h: 384.00,
    low24h: 375.00,
    vwap: 380.40,
    settlementBasis: 'Delivered ADM Erith / Cargill Liverpool Crushing',
    moistureSpec: 'Basis 9.0% (Max 10%)',
    proteinSpec: 'Oil Content Basis 40.0%',
    weightSpec: 'Admixture Max 2.0%',
    iconName: 'Rapeseed'
  },
  {
    id: 'MAIZE-HUMBER-FEED',
    name: 'Maize',
    symbol: 'MAZ-HUMBER',
    category: 'GRAINS',
    grade: 'Feed',
    region: 'Humberside',
    bid: 158.00,
    ask: 161.50,
    last: 159.50,
    change: 0.95,
    changePercent: 0.6,
    volume: 5300,
    unit: 'tonne',
    high24h: 162.00,
    low24h: 157.50,
    vwap: 159.20,
    settlementBasis: 'Ex-Deepwater Quay Immingham',
    moistureSpec: 'Max 14.0%',
    proteinSpec: 'Min 8.5%',
    weightSpec: 'Min 70.0 kg/hl',
    iconName: 'Maize'
  },
  {
    id: 'OATS-SCOT-MILL',
    name: 'Oats',
    symbol: 'OAT-SCOT',
    category: 'GRAINS',
    grade: 'Milling',
    region: 'Scotland',
    bid: 132.00,
    ask: 135.00,
    last: 133.50,
    change: 1.20,
    changePercent: 0.9,
    volume: 3200,
    unit: 'tonne',
    high24h: 136.00,
    low24h: 131.50,
    vwap: 133.40,
    settlementBasis: 'Delivered Cupar / Aberdeen Millers',
    moistureSpec: 'Max 15.0%',
    proteinSpec: 'Min 11.0%',
    weightSpec: 'Min 50.0 kg/hl',
    iconName: 'Oats'
  },
  {
    id: 'POTATOES-LINCS-MAINCROP',
    name: 'Potatoes',
    symbol: 'POT-LINCS',
    category: 'POTATOES',
    grade: 'Maincrop Maris Piper',
    region: 'Lincolnshire',
    bid: 105.50,
    ask: 108.00,
    last: 107.00,
    change: 0.40,
    changePercent: 0.4,
    volume: 2900,
    unit: 'tonne',
    high24h: 109.00,
    low24h: 104.50,
    vwap: 106.80,
    settlementBasis: 'Boxed / Ex-Cold Store Spalding',
    moistureSpec: 'Dry Matter 21-23%',
    proteinSpec: 'Fry Colour Index Grade 1',
    weightSpec: 'Size 45-85mm graded',
    iconName: 'Potatoes'
  },
  {
    id: 'SUGARBEET-EA-FACTORY',
    name: 'Sugar Beet',
    symbol: 'SGR-EA',
    category: 'SUGAR',
    grade: 'Factory Adjusted',
    region: 'East Anglia',
    bid: 28.50,
    ask: 30.00,
    last: 29.25,
    change: 0.32,
    changePercent: 1.1,
    volume: 18500,
    unit: 'tonne',
    high24h: 30.20,
    low24h: 28.20,
    vwap: 29.10,
    settlementBasis: 'Delivered British Sugar Wissington / Bury St Edmunds',
    moistureSpec: 'Basis 16% Clean Beet Equivalent',
    proteinSpec: 'Sugar Content 17.2%',
    weightSpec: 'Dirt Tare < 6.0%',
    iconName: 'SugarBeet'
  },
  {
    id: 'CATTLE-SHROP-PRIME',
    name: 'Cattle',
    symbol: 'CTL-SHROP',
    category: 'LIVESTOCK',
    grade: 'Prime R4L Heifers',
    region: 'Shropshire',
    bid: 2480.00,
    ask: 2520.00,
    last: 2505.00,
    change: 17.50,
    changePercent: 0.7,
    volume: 420,
    unit: 'head',
    high24h: 2530.00,
    low24h: 2470.00,
    vwap: 2500.00,
    settlementBasis: 'Liveweight at Shrewsbury Livestock Centre',
    moistureSpec: 'N/A',
    proteinSpec: 'Europ Conf - R4L / Deadweight 340kg avg',
    weightSpec: 'Avg 560kg liveweight',
    iconName: 'Cattle'
  },
  {
    id: 'LAMB-WALES-PRIME',
    name: 'Lamb',
    symbol: 'LMB-WALES',
    category: 'LIVESTOCK',
    grade: 'Prime Standard Quality',
    region: 'Wales',
    bid: 3860.00,
    ask: 3920.00,
    last: 3890.00,
    change: 50.00,
    changePercent: 1.3,
    volume: 1200,
    unit: 'head',
    high24h: 3935.00,
    low24h: 3840.00,
    vwap: 3885.00,
    settlementBasis: 'Welshpool / Brecon Livestock Market',
    moistureSpec: 'N/A',
    proteinSpec: 'SQQ Carcass Weight 17-21kg',
    weightSpec: 'Avg 42kg liveweight',
    iconName: 'Lamb'
  },
  {
    id: 'MILK-MIDLANDS-CLASSA',
    name: 'Milk',
    symbol: 'MLK-MID',
    category: 'DAIRY',
    grade: 'Class A Farm Gate',
    region: 'Midlands',
    bid: 39.20,
    ask: 40.50,
    last: 40.10,
    change: 0.45,
    changePercent: 1.15,
    volume: 650000,
    unit: 'litre',
    high24h: 40.80,
    low24h: 39.00,
    vwap: 39.95,
    settlementBasis: 'Bulk Tanker Ex-Farm Staffordshire',
    moistureSpec: 'Bactoscan < 30k',
    proteinSpec: 'Protein 3.42%, Butterfat 4.25%',
    weightSpec: 'SCC < 180k',
    iconName: 'Milk'
  }
];

export const VOLATILITY_INDICES = {
  wheat: {
    symbol: 'RQ-WVIX',
    name: 'UK Wheat 30-Day Volatility Index',
    value: 18.42,
    change: 0.65,
    changePercent: 3.66,
    historicalVol30d: 16.80,
    impliedVolRatio: 1.096,
    regime: 'Moderate / Weather Risk Premium'
  },
  barley: {
    symbol: 'RQ-BVIX',
    name: 'UK Barley 30-Day Volatility Index',
    value: 16.18,
    change: -0.32,
    changePercent: -1.94,
    historicalVol30d: 15.40,
    impliedVolRatio: 1.050,
    regime: 'Stable / Export Window Open'
  }
};

export const GENERATE_SAMPLE_CANDLESTICKS = (basePrice = 185.25, points = 45): CandlestickData[] => {
  const data: CandlestickData[] = [];
  let currentPrice = basePrice * 0.94;
  const now = Date.now();
  const stepMs = 30 * 60 * 1000; // 30 min intervals

  for (let i = points; i >= 0; i--) {
    const timestamp = now - i * stepMs;
    const date = new Date(timestamp);
    const timeStr = `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
    
    const volatility = 0.008;
    const delta = (Math.random() - 0.47) * currentPrice * volatility;
    const open = Number((currentPrice).toFixed(2));
    const close = Number((currentPrice + delta).toFixed(2));
    const high = Number((Math.max(open, close) + Math.random() * 0.8).toFixed(2));
    const low = Number((Math.min(open, close) - Math.random() * 0.7).toFixed(2));
    const volume = Math.floor(180 + Math.random() * 650);

    currentPrice = close;
    data.push({
      time: timeStr,
      timestamp,
      open,
      high,
      low,
      close,
      volume,
      vwap: Number((low + (high - low) * 0.55).toFixed(2))
    });
  }

  // Calculate moving averages
  for (let i = 0; i < data.length; i++) {
    if (i >= 9) {
      const slice = data.slice(i - 9, i + 1);
      const avg = slice.reduce((sum, item) => sum + item.close, 0) / slice.length;
      data[i].ma20 = Number(avg.toFixed(2));
    }
  }

  return data;
};

export const INITIAL_ORDER_BOOK: OrderBook = {
  symbol: 'WHT-EA',
  spread: 0.50,
  midPrice: 185.25,
  vwap: 185.10,
  totalBidVolume: 6050,
  totalAskVolume: 6200,
  bids: [
    { price: 185.00, volume: 250, total: 250, orderCount: 3 },
    { price: 184.50, volume: 520, total: 770, orderCount: 5 },
    { price: 184.00, volume: 1100, total: 1870, orderCount: 11 },
    { price: 183.50, volume: 1860, total: 3730, orderCount: 19 },
    { price: 183.00, volume: 2320, total: 6050, orderCount: 28 },
  ],
  asks: [
    { price: 185.50, volume: 300, total: 300, orderCount: 4 },
    { price: 186.00, volume: 480, total: 780, orderCount: 6 },
    { price: 186.50, volume: 920, total: 1700, orderCount: 12 },
    { price: 187.00, volume: 1400, total: 3100, orderCount: 16 },
    { price: 187.50, volume: 2100, total: 5200, orderCount: 24 },
  ]
};

export const INITIAL_TRADES: Trade[] = [
  {
    id: 'TRD-98214',
    time: '14:32',
    timestamp: Date.now() - 3 * 60000,
    instrumentName: 'Wheat (East Anglia)',
    grade: 'Feed',
    region: 'East Anglia',
    side: 'BUY',
    quantity: 100,
    price: 185.50,
    notional: 18550,
    unit: 't'
  },
  {
    id: 'TRD-98213',
    time: '14:21',
    timestamp: Date.now() - 14 * 60000,
    instrumentName: 'Rapeseed (East Midlands)',
    grade: 'Canola',
    region: 'East Midlands',
    side: 'SELL',
    quantity: 50,
    price: 381.00,
    notional: 19050,
    unit: 't'
  },
  {
    id: 'TRD-98212',
    time: '13:58',
    timestamp: Date.now() - 37 * 60000,
    instrumentName: 'Barley (Yorkshire)',
    grade: 'Feed',
    region: 'Yorkshire',
    side: 'BUY',
    quantity: 200,
    price: 163.00,
    notional: 32600,
    unit: 't'
  },
  {
    id: 'TRD-98211',
    time: '12:47',
    timestamp: Date.now() - 108 * 60000,
    instrumentName: 'Maize (Humberside)',
    grade: 'Feed',
    region: 'Humberside',
    side: 'SELL',
    quantity: 100,
    price: 159.50,
    notional: 15950,
    unit: 't'
  },
  {
    id: 'TRD-98210',
    time: '11:32',
    timestamp: Date.now() - 183 * 60000,
    instrumentName: 'Oats (Scotland)',
    grade: 'Feed',
    region: 'Scotland',
    side: 'BUY',
    quantity: 150,
    price: 133.50,
    notional: 20025,
    unit: 't'
  },
  {
    id: 'TRD-98209',
    time: '10:14',
    timestamp: Date.now() - 261 * 60000,
    instrumentName: 'Potatoes (Lincolnshire)',
    grade: 'Maincrop',
    region: 'Lincolnshire',
    side: 'SELL',
    quantity: 75,
    price: 107.00,
    notional: 8025,
    unit: 't'
  }
];

export const FUTURES_CONTRACTS: FuturesContract[] = [
  {
    id: 'FUT-WHT-NOV26',
    symbol: 'UKW-NOV26',
    name: 'UK Feed Wheat Future (Nov 26)',
    category: 'GRAINS',
    contractMonth: 'Nov 2026',
    expiryDate: '2026-11-23',
    bid: 188.20,
    ask: 188.80,
    last: 188.50,
    change: 2.10,
    changePercent: 1.13,
    volume: 3840,
    openInterest: 14200,
    settlementPrice: 186.40,
    initialMargin: 850,
    maintMargin: 650,
    contractSize: '100 Tonnes',
    deliveryMechanism: 'Physical Warehouse'
  },
  {
    id: 'FUT-WHT-JAN27',
    symbol: 'UKW-JAN27',
    name: 'UK Feed Wheat Future (Jan 27)',
    category: 'GRAINS',
    contractMonth: 'Jan 2027',
    expiryDate: '2027-01-23',
    bid: 191.00,
    ask: 191.60,
    last: 191.25,
    change: 2.40,
    changePercent: 1.27,
    volume: 2950,
    openInterest: 18900,
    settlementPrice: 188.85,
    initialMargin: 850,
    maintMargin: 650,
    contractSize: '100 Tonnes',
    deliveryMechanism: 'Physical Warehouse'
  },
  {
    id: 'FUT-WHT-MAY27',
    symbol: 'UKW-MAY27',
    name: 'UK Feed Wheat Future (May 27)',
    category: 'GRAINS',
    contractMonth: 'May 2027',
    expiryDate: '2027-05-23',
    bid: 195.50,
    ask: 196.20,
    last: 195.80,
    change: 1.90,
    changePercent: 0.98,
    volume: 1850,
    openInterest: 22400,
    settlementPrice: 193.90,
    initialMargin: 850,
    maintMargin: 650,
    contractSize: '100 Tonnes',
    deliveryMechanism: 'Physical Warehouse'
  },
  {
    id: 'FUT-BLY-NOV26',
    symbol: 'UKB-NOV26',
    name: 'UK Feed Barley Future (Nov 26)',
    category: 'GRAINS',
    contractMonth: 'Nov 2026',
    expiryDate: '2026-11-20',
    bid: 165.20,
    ask: 166.00,
    last: 165.60,
    change: 1.10,
    changePercent: 0.67,
    volume: 1200,
    openInterest: 6800,
    settlementPrice: 164.50,
    initialMargin: 700,
    maintMargin: 550,
    contractSize: '100 Tonnes',
    deliveryMechanism: 'Physical Warehouse'
  },
  {
    id: 'FUT-OSR-FEB27',
    symbol: 'UKOSR-FEB27',
    name: 'UK Rapeseed Future (Feb 27)',
    category: 'OILSEEDS',
    contractMonth: 'Feb 2027',
    expiryDate: '2027-02-15',
    bid: 388.50,
    ask: 390.00,
    last: 389.25,
    change: 4.80,
    changePercent: 1.25,
    volume: 980,
    openInterest: 4500,
    settlementPrice: 384.45,
    initialMargin: 1500,
    maintMargin: 1100,
    contractSize: '50 Tonnes',
    deliveryMechanism: 'Physical Warehouse'
  }
];

export const FORWARD_CURVE_DATA: ForwardCurvePoint[] = [
  { month: 'Spot', price: 185.25, changeVsSpot: 0.00, isSpot: true, spreadVsPrevious: 0, structure: 'Flat' },
  { month: 'Oct 26', price: 186.80, changeVsSpot: 1.55, spreadVsPrevious: 1.55, structure: 'Contango' },
  { month: 'Nov 26', price: 188.50, changeVsSpot: 3.25, spreadVsPrevious: 1.70, structure: 'Contango' },
  { month: 'Dec 26', price: 190.10, changeVsSpot: 4.85, spreadVsPrevious: 1.60, structure: 'Contango' },
  { month: 'Jan 27', price: 191.25, changeVsSpot: 6.00, spreadVsPrevious: 1.15, structure: 'Contango' },
  { month: 'Feb 27', price: 192.80, changeVsSpot: 7.55, spreadVsPrevious: 1.55, structure: 'Contango' },
  { month: 'Mar 27', price: 194.10, changeVsSpot: 8.85, spreadVsPrevious: 1.30, structure: 'Contango' },
  { month: 'Apr 27', price: 195.00, changeVsSpot: 9.75, spreadVsPrevious: 0.90, structure: 'Contango' },
  { month: 'May 27', price: 195.80, changeVsSpot: 10.55, spreadVsPrevious: 0.80, structure: 'Contango' },
  { month: 'Jun 27', price: 194.20, changeVsSpot: 8.95, spreadVsPrevious: -1.60, structure: 'Backwardation' },
  { month: 'Jul 27', price: 189.50, changeVsSpot: 4.25, spreadVsPrevious: -4.70, structure: 'Backwardation' },
  { month: 'Aug 27', price: 182.00, changeVsSpot: -3.25, spreadVsPrevious: -7.50, structure: 'Backwardation' },
  { month: 'Sep 27', price: 183.50, changeVsSpot: -1.75, spreadVsPrevious: 1.50, structure: 'Contango' },
];

export const OPTIONS_CHAIN_DEC26: OptionContract[] = [
  {
    strike: 160,
    call: { bid: 28.50, ask: 29.80, last: 29.00, volume: 120, openInterest: 850, iv: 19.8, delta: 0.94, gamma: 0.008, theta: -0.012, vega: 0.08 },
    put: { bid: 0.40, ask: 0.80, last: 0.60, volume: 45, openInterest: 1400, iv: 21.2, delta: -0.06, gamma: 0.008, theta: -0.008, vega: 0.08 }
  },
  {
    strike: 170,
    call: { bid: 19.80, ask: 21.00, last: 20.40, volume: 340, openInterest: 1950, iv: 18.9, delta: 0.86, gamma: 0.015, theta: -0.024, vega: 0.16 },
    put: { bid: 1.20, ask: 1.70, last: 1.45, volume: 180, openInterest: 2600, iv: 19.8, delta: -0.14, gamma: 0.015, theta: -0.018, vega: 0.16 }
  },
  {
    strike: 180,
    call: { bid: 12.40, ask: 13.50, last: 13.00, volume: 820, openInterest: 4200, iv: 18.2, delta: 0.70, gamma: 0.024, theta: -0.038, vega: 0.25 },
    put: { bid: 3.40, ask: 4.10, last: 3.75, volume: 640, openInterest: 5100, iv: 18.8, delta: -0.30, gamma: 0.024, theta: -0.031, vega: 0.25 }
  },
  {
    strike: 185,
    call: { bid: 9.10, ask: 10.00, last: 9.50, volume: 1450, openInterest: 6800, iv: 18.0, delta: 0.58, gamma: 0.028, theta: -0.044, vega: 0.29 },
    put: { bid: 5.20, ask: 6.00, last: 5.60, volume: 1200, openInterest: 7200, iv: 18.4, delta: -0.42, gamma: 0.028, theta: -0.039, vega: 0.29 }
  },
  {
    strike: 190,
    call: { bid: 6.40, ask: 7.20, last: 6.80, volume: 2100, openInterest: 9400, iv: 18.1, delta: 0.45, gamma: 0.027, theta: -0.046, vega: 0.30 },
    put: { bid: 7.60, ask: 8.50, last: 8.00, volume: 980, openInterest: 5800, iv: 18.2, delta: -0.55, gamma: 0.027, theta: -0.042, vega: 0.30 }
  },
  {
    strike: 195,
    call: { bid: 4.20, ask: 5.00, last: 4.60, volume: 1650, openInterest: 7100, iv: 18.3, delta: 0.33, gamma: 0.023, theta: -0.041, vega: 0.27 },
    put: { bid: 10.80, ask: 11.90, last: 11.40, volume: 540, openInterest: 3900, iv: 18.5, delta: -0.67, gamma: 0.023, theta: -0.038, vega: 0.27 }
  },
  {
    strike: 200,
    call: { bid: 2.60, ask: 3.30, last: 2.95, volume: 1120, openInterest: 8900, iv: 18.6, delta: 0.22, gamma: 0.018, theta: -0.033, vega: 0.22 },
    put: { bid: 14.50, ask: 15.80, last: 15.10, volume: 310, openInterest: 2100, iv: 18.9, delta: -0.78, gamma: 0.018, theta: -0.031, vega: 0.22 }
  },
  {
    strike: 210,
    call: { bid: 1.00, ask: 1.50, last: 1.25, volume: 460, openInterest: 4300, iv: 19.4, delta: 0.10, gamma: 0.010, theta: -0.019, vega: 0.13 },
    put: { bid: 23.00, ask: 24.50, last: 23.80, volume: 90, openInterest: 1100, iv: 20.1, delta: -0.90, gamma: 0.010, theta: -0.018, vega: 0.13 }
  }
];

export const PHYSICAL_INVENTORY: PhysicalWarehouseInventory[] = [
  {
    id: 'WH-IPS-01',
    warehouseName: 'Ipswich Deepwater Grain Terminal',
    location: 'Cliff Quay, Port of Ipswich',
    region: 'East Anglia',
    commodity: 'Feed Wheat',
    grade: 'Grade 2 Feed',
    quantityHeld: 4200,
    capacity: 15000,
    allocatedQty: 1200,
    availableQty: 3000,
    moisturePercent: 14.2,
    proteinPercent: 10.8,
    testWeight: 74.2,
    hagbergFallingNo: 210,
    certification: 'TASCC / Red Tractor Farm Assured (UK-88392)',
    receiptNumber: 'RQ-WR-2026-004812',
    dailyStorageCostPerTonne: 0.045
  },
  {
    id: 'WH-HULL-02',
    warehouseName: 'King George Dock Silo Complex',
    location: 'Port of Hull',
    region: 'Yorkshire',
    commodity: 'Feed Barley',
    grade: 'Two-Row Winter Feed',
    quantityHeld: 2800,
    capacity: 12000,
    allocatedQty: 500,
    availableQty: 2300,
    moisturePercent: 14.6,
    proteinPercent: 10.1,
    testWeight: 64.5,
    hagbergFallingNo: 180,
    certification: 'TASCC Certified / AIC Code of Practice',
    receiptNumber: 'RQ-WR-2026-004819',
    dailyStorageCostPerTonne: 0.042
  },
  {
    id: 'WH-TILB-03',
    warehouseName: 'Tilbury Agri-Bulk Central Silos',
    location: 'Port of Tilbury, Essex',
    region: 'South East',
    commodity: 'Milling Wheat',
    grade: 'Group 1 Milling (Skyfall)',
    quantityHeld: 3500,
    capacity: 20000,
    allocatedQty: 2000,
    availableQty: 1500,
    moisturePercent: 13.8,
    proteinPercent: 13.4,
    testWeight: 78.6,
    hagbergFallingNo: 295,
    certification: 'NABIM Group 1 Certified / Red Tractor',
    receiptNumber: 'RQ-WR-2026-004825',
    dailyStorageCostPerTonne: 0.052
  },
  {
    id: 'WH-BRIST-04',
    warehouseName: 'Avonmouth Grain Terminal',
    location: 'Port of Bristol',
    region: 'South West',
    commodity: 'Rapeseed',
    grade: 'Canola Low Erucic',
    quantityHeld: 1650,
    capacity: 8000,
    allocatedQty: 400,
    availableQty: 1250,
    moisturePercent: 8.8,
    proteinPercent: 41.2,
    testWeight: 68.0,
    hagbergFallingNo: 0,
    certification: 'ISCC RED II Sustainability Certified',
    receiptNumber: 'RQ-WR-2026-004830',
    dailyStorageCostPerTonne: 0.060
  }
];

export const LOGISTICS_MOVEMENTS: LogisticsMovement[] = [
  {
    id: 'LOG-UK-8841',
    reference: 'FLT-BULK-019',
    commodity: 'Feed Wheat',
    quantityTonnes: 120,
    origin: 'Bury St Edmunds (Barton Silo)',
    destination: 'Ipswich Deepwater Terminal',
    mode: 'ROAD_BULK',
    carrier: 'Turners of Soham Bulk Logistics',
    eta: 'Today, 16:45',
    status: 'IN_TRANSIT',
    costGbp: 1080,
    carbonIntensityKgPerT: 4.8,
    coordinates: {
      from: [52.247, 0.718],
      to: [52.059, 1.155],
      current: [52.165, 0.942]
    }
  },
  {
    id: 'LOG-UK-8842',
    reference: 'GBRF-AGRI-402',
    commodity: 'Milling Wheat',
    quantityTonnes: 1400,
    origin: 'Peterborough Railhead',
    destination: 'Tilbury Flour Mills',
    mode: 'RAIL_FREIGHT',
    carrier: 'GB Railfreight Agri',
    eta: 'Tomorrow, 06:30',
    status: 'LOADING',
    costGbp: 8960,
    carbonIntensityKgPerT: 1.4,
    coordinates: {
      from: [52.572, -0.247],
      to: [51.462, 0.358],
      current: [52.572, -0.247]
    }
  },
  {
    id: 'LOG-UK-8843',
    reference: 'BRG-HUMBER-11',
    commodity: 'Feed Barley',
    quantityTonnes: 650,
    origin: 'Gainsborough Inland Depot',
    destination: 'Hull Animal Feed Mill',
    mode: 'COASTAL_BARGE',
    carrier: 'Humber Marine Bulk Services',
    eta: 'Tomorrow, 14:00',
    status: 'IN_TRANSIT',
    costGbp: 2275,
    carbonIntensityKgPerT: 2.1,
    coordinates: {
      from: [53.398, -0.776],
      to: [53.745, -0.336],
      current: [53.582, -0.560]
    }
  }
];

export const AGRICULTURAL_INTELLIGENCE: AgriculturalIntelligence[] = [
  {
    id: 'NEWS-01',
    category: 'DEFRA',
    title: 'UK Harvest Forecast Improves',
    summary: 'Latest DEFRA data suggests a stronger than expected wheat yield for 2026/27, supporting spot market liquidity across East Anglia and Yorkshire.',
    fullText: 'DEFRA’s late-September crop monitor indicates UK wheat production tracking at 14.35 million tonnes, up 4.2% versus prior year projections. Specific weights have tested resilient at 74.5 kg/hl average across eastern counties. Port silo intake in Ipswich and Tilbury reports robust milling quality with Hagberg Falling Numbers comfortably above 250s, easing supply tightness for domestic flour millers.',
    timestamp: '24 Sep 2026 14:15',
    impact: 'BEARISH',
    affectedCommodity: 'Wheat'
  },
  {
    id: 'NEWS-02',
    category: 'WEATHER',
    title: 'Autumn Drilling Window Closes Under Dry High Pressure',
    summary: 'Met Office outlook confirms favorable dry conditions across the East Midlands and South East, accelerating winter barley and wheat establishment.',
    fullText: 'A dominant ridge of high pressure over the British Isles will maintain optimal soil moisture profiles across commercial arable hubs. Soil temperatures remain supportive for rapid germination. Early emergence rates for winter oilseed rape are exceeding 92%, mitigating flea beetle pressure in Lincolnshire.',
    timestamp: '24 Sep 2026 11:30',
    impact: 'NEUTRAL',
    affectedCommodity: 'Barley & Rapeseed'
  },
  {
    id: 'NEWS-03',
    category: 'GLOBAL_GRAINS',
    title: 'Black Sea Freight Premiums Lift Western European Export Competitiveness',
    summary: 'Higher maritime insurance rates in the eastern Mediterranean are diverting North African milling tenders toward UK and French Atlantic loading ports.',
    fullText: 'Tunisian and Algerian state grain boards (OAIC) have issued fresh tenders for 200,000t milling wheat. UK feed and milling wheat FOB export parity prices out of Immingham and Ipswich have moved into competitive discount territory against Romanian and Ukrainian origin grain.',
    timestamp: '24 Sep 2026 09:45',
    impact: 'BULLISH',
    affectedCommodity: 'Wheat & Feed Grains'
  }
];

export const UK_BASIS_REGIONS: BasisPoint[] = [
  {
    region: 'East Anglia',
    benchmarkPrice: 185.25,
    basisDifferential: 1.25,
    effectivePrice: 186.50,
    freightCostToPort: 6.50,
    primaryBuyers: ['Ipswich Port Silos', 'Bury Maltings', 'Suffolk Feed Mills'],
    siloStockPct: 68
  },
  {
    region: 'Yorkshire',
    benchmarkPrice: 185.25,
    basisDifferential: -2.00,
    effectivePrice: 183.25,
    freightCostToPort: 8.20,
    primaryBuyers: ['Hull Docks', 'Vivergo Fuels', 'Yorkshire Feed Co-op'],
    siloStockPct: 74
  },
  {
    region: 'Humberside',
    benchmarkPrice: 185.25,
    basisDifferential: -0.75,
    effectivePrice: 184.50,
    freightCostToPort: 4.80,
    primaryBuyers: ['Immingham Terminal', 'Grimsby Animal Feeds'],
    siloStockPct: 82
  },
  {
    region: 'East Midlands',
    benchmarkPrice: 185.25,
    basisDifferential: 0.50,
    effectivePrice: 185.75,
    freightCostToPort: 9.40,
    primaryBuyers: ['Burton Maltsters', 'Nottingham Grain Silos'],
    siloStockPct: 61
  },
  {
    region: 'Lincolnshire',
    benchmarkPrice: 185.25,
    basisDifferential: 0.00,
    effectivePrice: 185.25,
    freightCostToPort: 7.10,
    primaryBuyers: ['Boston Silos', 'Spalding Logistics Hub'],
    siloStockPct: 79
  },
  {
    region: 'Scotland',
    benchmarkPrice: 185.25,
    basisDifferential: 4.50,
    effectivePrice: 189.75,
    freightCostToPort: 12.00,
    primaryBuyers: ['Speyside Distillers Group', 'Inverness Feed Complex'],
    siloStockPct: 54
  },
  {
    region: 'South West',
    benchmarkPrice: 185.25,
    basisDifferential: 3.20,
    effectivePrice: 188.45,
    freightCostToPort: 10.50,
    primaryBuyers: ['Avonmouth Port', 'Devon Dairy Co-operatives'],
    siloStockPct: 58
  }
];

export const INITIAL_POSITIONS: Position[] = [
  {
    id: 'POS-001',
    instrumentId: 'WHEAT-EA-FEED',
    symbol: 'WHT-EA',
    name: 'Feed Wheat (East Anglia)',
    type: 'PHYSICAL',
    side: 'LONG',
    quantity: 10000,
    unit: 't',
    entryPrice: 181.50,
    currentPrice: 185.25,
    unrealisedPnl: 37500,
    unrealisedPnlPercent: 2.07,
    realisedPnl: 14200,
    marginLocked: 0,
    delta: 10000
  },
  {
    id: 'POS-002',
    instrumentId: 'FUT-WHT-NOV26',
    symbol: 'UKW-NOV26',
    name: 'UK Feed Wheat Futures Nov 26',
    type: 'FUTURES',
    side: 'SHORT',
    quantity: 80, // 8,000t equivalent (80 contracts)
    unit: 'contracts',
    entryPrice: 189.40,
    currentPrice: 188.50,
    unrealisedPnl: 7200,
    unrealisedPnlPercent: 0.48,
    realisedPnl: 8600,
    marginLocked: 68000,
    delta: -8000
  },
  {
    id: 'POS-003',
    instrumentId: 'OPT-WHT-190C-DEC26',
    symbol: 'UKW-190C-DEC26',
    name: 'UK Wheat Dec 26 190 Call',
    type: 'OPTIONS',
    side: 'LONG',
    quantity: 20, // 2,000t
    unit: 'contracts',
    entryPrice: 6.10,
    currentPrice: 6.80,
    unrealisedPnl: 1400,
    unrealisedPnlPercent: 11.48,
    realisedPnl: 0,
    marginLocked: 12200,
    delta: 900
  }
];

export const INITIAL_PORTFOLIO: PortfolioSummary = {
  navGbp: 4850600,
  availableCashGbp: 2140000,
  collateralLockedGbp: 80200,
  physicalInventoryValueGbp: 1852500,
  spotExposureGbp: 1852500,
  futuresExposureGbp: -1508000,
  optionsExposureGbp: 136000,
  netDeltaGbp: 2900, // Delta-hedged portfolio!
  dailyUnrealisedPnlGbp: 46100,
  dailyRealisedPnlGbp: 22800,
  marginUtilisationPercent: 3.75,
  var99_1dGbp: 38400
};
