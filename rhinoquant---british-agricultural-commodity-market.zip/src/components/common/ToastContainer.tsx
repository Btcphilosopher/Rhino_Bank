import React from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const ToastContainer: React.FC = () => {
  const { toastNotifications, removeToast } = useMarket();

  if (toastNotifications.length === 0) return null;

  return (
    <div className="fixed bottom-10 right-6 z-50 flex flex-col gap-2 max-w-sm pointer-events-none select-none">
      {toastNotifications.map((t) => {
        return (
          <div
            key={t.id}
            className="pointer-events-auto p-3.5 bg-[#0B171A]/95 border border-[#23474F] shadow-2xl rounded-sm flex items-start gap-3 backdrop-blur-md animate-in slide-in-from-right-5 duration-200"
          >
            <div className="shrink-0 mt-0.5">
              {t.type === 'SUCCESS' && <CheckCircle2 className="w-4 h-4 text-[#10B981]" />}
              {t.type === 'WARNING' && <AlertTriangle className="w-4 h-4 text-[#C5A059]" />}
              {t.type === 'ERROR' && <AlertTriangle className="w-4 h-4 text-[#EF4444]" />}
              {t.type === 'INFO' && <Info className="w-4 h-4 text-[#38BDF8]" />}
            </div>

            <div className="flex-1 space-y-0.5">
              <div className="text-xs font-cinzel font-bold text-[#F3F7F6]">
                {t.title}
              </div>
              <div className="text-[11px] font-mono-numbers text-[#8EA7A8]">
                {t.message}
              </div>
            </div>

            <button
              onClick={() => removeToast(t.id)}
              className="text-[#567274] hover:text-[#E2ECE9] transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
