import React, { useState } from 'react';
import { Cpu, Play, BarChart3, TrendingUp, Sliders, CheckCircle2, RotateCcw, ShieldCheck } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const QuantLab: React.FC = () => {
  const [selectedStrategy, setSelectedStrategy] = useState<'SPREAD_MR' | 'SEASONAL_CARRY' | 'CRUSH_ARB' | 'BASIS_MOMENTUM'>('SPREAD_MR');
  const [lookbackDays, setLookbackDays] = useState<number>(30);
  const [entryZScore, setEntryZScore] = useState<number>(1.75);
  const [stopLossPct, setStopLossPct] = useState<number>(2.5);
  const [isRunningBacktest, setIsRunningBacktest] = useState<boolean>(false);
  const [backtestCompleted, setBacktestCompleted] = useState<boolean>(true);

  const runBacktest = () => {
    setIsRunningBacktest(true);
    setTimeout(() => {
      setIsRunningBacktest(false);
      setBacktestCompleted(true);
    }, 800);
  };

  // Synthetic equity curve points
  const equityPoints = [
    { day: 'Day 1', nav: 1000000 },
    { day: 'Day 15', nav: 1024000 },
    { day: 'Day 30', nav: 1058000 },
    { day: 'Day 45', nav: 1042000 },
    { day: 'Day 60', nav: 1095000 },
    { day: 'Day 75', nav: 1120000 },
    { day: 'Day 90', nav: 1165000 },
    { day: 'Day 105', nav: 1148000 },
    { day: 'Day 120', nav: 1214000 }
  ];

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Header Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              QUANTITATIVE RESEARCH LAB &amp; ALPHA STUDIO
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#C5A059] border border-[#23474F] rounded">
              STATISTICAL ARBITRAGE ENGINE
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Formulate, backtest and deploy automated algorithmic strategies across UK agricultural spot, futures curves and spreads.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Strategy Selector & Parameter Controls */}
        <div className="lg:col-span-4 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg flex flex-col justify-between">
          <div className="space-y-3 font-mono-numbers text-xs">
            <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase border-b border-[#183338] pb-2">
              ALGORITHMIC MODEL SELECTOR
            </h3>

            <div className="space-y-1.5">
              {[
                { id: 'SPREAD_MR', name: 'Wheat / Barley Feed Spread', desc: 'Mean reversion on historical spread z-score ratio' },
                { id: 'SEASONAL_CARRY', name: 'Harvest Seasonal Carry & Roll', desc: 'Exploit autumn harvest pressure vs spring contango' },
                { id: 'CRUSH_ARB', name: 'Rapeseed Crushing Margin Arb', desc: 'Synthetic processing margin vs Rotterdam meal/oil' },
                { id: 'BASIS_MOMENTUM', name: 'Regional Port Basis Momentum', desc: 'Cross-port elevator arbitrage (Ipswich vs Hull)' }
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedStrategy(s.id as any)}
                  className={`w-full text-left p-2.5 rounded border transition-colors ${
                    selectedStrategy === s.id
                      ? 'bg-[#10292E] text-[#10B981] border-[#1F4A4F]'
                      : 'bg-[#071114] text-[#8EA7A8] border-[#183338] hover:bg-[#0E2024]'
                  }`}
                >
                  <div className="font-bold text-xs text-[#E2ECE9]">{s.name}</div>
                  <div className="text-[10px] text-[#567274] mt-0.5">{s.desc}</div>
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-[#183338] space-y-3">
              <div>
                <div className="flex justify-between text-[10px] text-[#8EA7A8]">
                  <span>LOOKBACK WINDOW (DAYS)</span>
                  <span className="text-[#C5A059] font-bold">{lookbackDays}d</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  value={lookbackDays}
                  onChange={(e) => setLookbackDays(Number(e.target.value))}
                  className="w-full accent-[#10B981]"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-[#8EA7A8]">
                  <span>ENTRY THRESHOLD (Z-SCORE)</span>
                  <span className="text-[#10B981] font-bold">{entryZScore.toFixed(2)} &sigma;</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.25"
                  value={entryZScore}
                  onChange={(e) => setEntryZScore(Number(e.target.value))}
                  className="w-full accent-[#10B981]"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-[#8EA7A8]">
                  <span>STOP LOSS THRESHOLD</span>
                  <span className="text-[#EF4444] font-bold">{stopLossPct}%</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="5.0"
                  step="0.5"
                  value={stopLossPct}
                  onChange={(e) => setStopLossPct(Number(e.target.value))}
                  className="w-full accent-[#EF4444]"
                />
              </div>
            </div>
          </div>

          <button
            onClick={runBacktest}
            disabled={isRunningBacktest}
            className="w-full py-3 bg-[#10B981] hover:bg-[#059669] text-[#05241C] font-mono-numbers font-bold rounded uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            {isRunningBacktest ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isRunningBacktest ? 'SIMULATING EXECUTION...' : 'RUN MONTE CARLO BACKTEST'}</span>
          </button>
        </div>

        {/* Right: Backtest Results & Equity Curve */}
        <div className="lg:col-span-8 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#183338] pb-2">
              <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase">
                HISTORICAL PERFORMANCE &amp; RISK PROFILE
              </h3>
              <span className="text-[10px] font-mono-numbers text-[#10B981] flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                OUT-OF-SAMPLE VERIFIED (2023–2026)
              </span>
            </div>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 my-3 font-mono-numbers text-xs">
              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8]">SHARPE RATIO</div>
                <div className="text-lg font-bold text-[#10B981] mt-0.5">1.84</div>
                <div className="text-[9px] text-[#567274]">Annualized / Rf 4.5%</div>
              </div>

              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8]">ANNUALISED RETURN</div>
                <div className="text-lg font-bold text-[#10B981] mt-0.5">+21.4%</div>
                <div className="text-[9px] text-[#567274]">Net of slippage &amp; LCH fees</div>
              </div>

              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8]">MAX DRAWDOWN</div>
                <div className="text-lg font-bold text-[#EF4444] mt-0.5">-6.20%</div>
                <div className="text-[9px] text-[#567274]">Peak to trough duration: 18d</div>
              </div>

              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8]">WIN RATE &bull; PROFIT FACTOR</div>
                <div className="text-lg font-bold text-[#C5A059] mt-0.5">68.2% &bull; 2.14</div>
                <div className="text-[9px] text-[#567274]">142 Simulated Trades</div>
              </div>
            </div>

            {/* Equity Curve SVG */}
            <div className="h-56 w-full bg-[#071114] rounded border border-[#142629] p-3 relative">
              <svg viewBox="0 0 650 180" className="w-full h-full">
                {/* Grid */}
                {[1000000, 1100000, 1200000].map((v, i) => {
                  const y = 160 - ((v - 1000000) / 250000) * 140;
                  return (
                    <g key={i}>
                      <line x1="40" y1={y} x2="630" y2={y} stroke="#122428" strokeDasharray="3 3" />
                      <text x="5" y={y + 3} fill="#567274" fontSize="8.5" fontFamily="JetBrains Mono">&pound;{(v/1000).toFixed(0)}k</text>
                    </g>
                  );
                })}

                {/* Fill */}
                <polygon
                  points={`50,160 ${equityPoints.map((pt, idx) => `${50 + idx * 70},${160 - ((pt.nav - 1000000) / 250000) * 140}`).join(' ')} ${50 + (equityPoints.length - 1) * 70},160`}
                  fill="#10B981"
                  opacity="0.1"
                />

                {/* Line */}
                <polyline
                  fill="none"
                  stroke="#10B981"
                  strokeWidth="2.5"
                  points={equityPoints.map((pt, idx) => `${50 + idx * 70},${160 - ((pt.nav - 1000000) / 250000) * 140}`).join(' ')}
                />

                {equityPoints.map((pt, idx) => (
                  <circle
                    key={idx}
                    cx={50 + idx * 70}
                    cy={160 - ((pt.nav - 1000000) / 250000) * 140}
                    r="3.5"
                    fill="#071114"
                    stroke="#10B981"
                    strokeWidth="2"
                  />
                ))}
              </svg>
            </div>
          </div>

          <div className="p-3 bg-[#071114] border border-[#142629] rounded text-[11px] font-mono-numbers text-[#8EA7A8] flex items-center justify-between">
            <span>Notice: Analytical simulations are quantitative research outputs and do not guarantee future returns.</span>
            <span className="text-[#C5A059] font-bold">API KEY: ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
