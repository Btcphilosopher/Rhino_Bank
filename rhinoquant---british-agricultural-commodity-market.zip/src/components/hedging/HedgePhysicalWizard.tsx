import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, CheckCircle2, TrendingDown, Scale, Info, AlertTriangle } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const HedgePhysicalWizard: React.FC = () => {
  const { executePhysicalHedge, portfolio, setActiveView } = useMarket();

  const [physicalTonnes, setPhysicalTonnes] = useState<number>(10000);
  const [commodity, setCommodity] = useState<string>('UK Feed Wheat');
  const [region, setRegion] = useState<string>('East Anglia');
  const [benchmarkPrice, setBenchmarkPrice] = useState<number>(185.25);
  const [basisPremium, setBasisPremium] = useState<number>(1.25);
  const [selectedHedgeInstrument, setSelectedHedgeInstrument] = useState<'FUTURES' | 'PUTS' | 'COLLAR'>('FUTURES');
  const [hedgeTargetPct, setHedgeTargetPct] = useState<number>(80);

  const physicalValue = physicalTonnes * (benchmarkPrice + basisPremium);
  const hedgedTonnes = (physicalTonnes * (hedgeTargetPct / 100));
  const futuresContractsNeeded = Math.round(hedgedTonnes / 100); // 100t per contract
  const marginRequired = futuresContractsNeeded * 850; // £850 initial margin per lot
  const basisRiskGbp = physicalTonnes * Math.abs(basisPremium);

  const handleEstablishHedge = () => {
    executePhysicalHedge({
      physicalQty: physicalTonnes,
      futuresQuantityContracts: futuresContractsNeeded,
      hedgeInstrument: 'UK Feed Wheat Nov 26 Futures'
    });
  };

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Top Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              PHYSICAL GRAIN HEDGING WORKFLOW
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#091D1B] text-[#10B981] border border-[#124238] rounded">
              INSTITUTIONAL RISK DESK
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Protect physical farm & silo inventory against cash market depreciation using LCH cleared agricultural futures.
          </p>
        </div>

        <button
          onClick={() => setActiveView('RISK')}
          className="px-3 py-1.5 bg-[#10292E] hover:bg-[#15383E] text-[#C5A059] border border-[#1F4A4F] rounded text-xs font-mono-numbers transition-colors"
        >
          View Risk & Greek Dashboard &rarr;
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Input Inventory Parameters */}
        <div className="lg:col-span-5 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg">
          <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase border-b border-[#183338] pb-2">
            1. PHYSICAL EXPOSURE SPECIFICATION
          </h3>

          <div className="space-y-3 font-mono-numbers text-xs">
            <div>
              <label className="text-[10px] text-[#8EA7A8] uppercase">PHYSICAL COMMODITY & LOCATION</label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <input
                  type="text"
                  value={commodity}
                  disabled
                  className="bg-[#071114] border border-[#183338] rounded px-3 py-2 text-[#E2ECE9] font-bold"
                />
                <input
                  type="text"
                  value={region}
                  disabled
                  className="bg-[#071114] border border-[#183338] rounded px-3 py-2 text-[#E2ECE9] font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] text-[#8EA7A8] uppercase">INVENTORY QUANTITY (TONNES)</label>
              <input
                type="number"
                step="500"
                value={physicalTonnes}
                onChange={(e) => setPhysicalTonnes(Math.max(100, Number(e.target.value)))}
                className="w-full mt-1 bg-[#071114] border border-[#183338] focus:border-[#C5A059] rounded px-3 py-2 text-base text-[#E2ECE9] font-bold outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-[#8EA7A8] uppercase">BENCHMARK PRICE</label>
                <div className="mt-1 bg-[#071114] border border-[#183338] rounded px-3 py-2 text-[#E2ECE9] font-bold">
                  &pound;{benchmarkPrice.toFixed(2)} / t
                </div>
              </div>
              <div>
                <label className="text-[10px] text-[#8EA7A8] uppercase">REGIONAL BASIS</label>
                <div className="mt-1 bg-[#071114] border border-[#183338] rounded px-3 py-2 text-[#10B981] font-bold">
                  +&pound;{basisPremium.toFixed(2)} / t
                </div>
              </div>
            </div>

            {/* Target Hedge Ratio Slider */}
            <div>
              <div className="flex justify-between items-center text-[10px] text-[#8EA7A8] uppercase">
                <span>TARGET HEDGE RATIO</span>
                <span className="text-[#10B981] font-bold text-xs">{hedgeTargetPct}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={hedgeTargetPct}
                onChange={(e) => setHedgeTargetPct(Number(e.target.value))}
                className="w-full mt-2 accent-[#10B981] cursor-pointer"
              />
            </div>

            {/* Hedge Instrument Selection */}
            <div>
              <label className="text-[10px] text-[#8EA7A8] uppercase">HEDGE INSTRUMENT</label>
              <div className="grid grid-cols-3 gap-1.5 mt-1">
                {[
                  { id: 'FUTURES', label: 'Short Futures' },
                  { id: 'PUTS', label: 'Floor Puts' },
                  { id: 'COLLAR', label: 'Zero Collar' }
                ].map((inst) => (
                  <button
                    key={inst.id}
                    onClick={() => setSelectedHedgeInstrument(inst.id as any)}
                    className={`py-2 px-1 text-center rounded border text-xs font-semibold ${
                      selectedHedgeInstrument === inst.id
                        ? 'bg-[#10292E] text-[#10B981] border-[#1F4A4F]'
                        : 'bg-[#071114] text-[#8EA7A8] border-[#183338]'
                    }`}
                  >
                    {inst.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Analytical Output & Execution Ticket */}
        <div className="lg:col-span-7 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase border-b border-[#183338] pb-2">
              2. HEDGE STRUCTURE & NOTIONAL RISK ANALYSIS
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-3">
              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8] uppercase font-mono-numbers">Total Physical Value</div>
                <div className="text-base font-mono-numbers font-bold text-[#E2ECE9] mt-0.5">
                  &pound;{physicalValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[9px] text-[#567274] font-mono-numbers">10,000t @ &pound;186.50/t delivered</div>
              </div>

              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8] uppercase font-mono-numbers">Recommended Contracts</div>
                <div className="text-base font-mono-numbers font-bold text-[#10B981] mt-0.5">
                  {futuresContractsNeeded} Lots (UKW-NOV26)
                </div>
                <div className="text-[9px] text-[#567274] font-mono-numbers">{hedgedTonnes.toLocaleString()}t hedge equivalent</div>
              </div>

              <div className="p-3 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[10px] text-[#8EA7A8] uppercase font-mono-numbers">Initial Margin Lock</div>
                <div className="text-base font-mono-numbers font-bold text-[#C5A059] mt-0.5">
                  &pound;{marginRequired.toLocaleString()}
                </div>
                <div className="text-[9px] text-[#567274] font-mono-numbers">&pound;850/lot LCH Clearing</div>
              </div>
            </div>

            <div className="bg-[#071114] border border-[#142629] p-3.5 rounded space-y-2 font-mono-numbers text-xs">
              <div className="flex justify-between">
                <span className="text-[#8EA7A8]">Hedge Efficiency Rating:</span>
                <span className="text-[#10B981] font-bold">98.4% (Strong R² Correlation)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8EA7A8]">Residual Basis Risk:</span>
                <span className="text-[#C5A059]">&pound;{basisRiskGbp.toLocaleString()} (&plusmn;&pound;1.25/t differential)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8EA7A8]">Post-Hedge Net Delta Exposure:</span>
                <span className="text-[#38BDF8] font-bold">+{(physicalTonnes - hedgedTonnes).toLocaleString()} tonnes</span>
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-3 border-t border-[#183338]">
            <div className="flex items-center gap-2 text-xs text-[#8EA7A8]">
              <Info className="w-4 h-4 text-[#C5A059]" />
              <span>Orders are routed directly to London Clearing House (LCH) Agricultural OMS.</span>
            </div>

            <button
              onClick={handleEstablishHedge}
              className="w-full py-3.5 bg-[#10B981] hover:bg-[#059669] text-[#05241C] text-sm font-mono-numbers font-bold rounded uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>ESTABLISH {futuresContractsNeeded}X SHORT FUTURES HEDGE</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
