import React from 'react';
import { X, CheckCircle2, ShieldCheck, AlertCircle, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const OrderConfirmModal: React.FC = () => {
  const { orderPendingConfirmation, setOrderPendingConfirmation, confirmPendingOrder } = useMarket();

  if (!orderPendingConfirmation || !orderPendingConfirmation.isOpen) return null;

  const { orderParams, instrument } = orderPendingConfirmation;
  const isBuy = orderParams.side === 'BUY';
  const notional = orderParams.quantity * orderParams.price;
  const fees = notional * 0.0012;
  const total = isBuy ? notional + fees : notional - fees;

  return (
    <div className="fixed inset-0 bg-[#000000]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0B171A] border border-[#23474F] rounded-sm w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-4 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] via-[#0E2125] to-[#0B171A] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded ${isBuy ? 'bg-[#091D1B] text-[#10B981]' : 'bg-[#1F1414] text-[#EF4444]'}`}>
              {isBuy ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-cinzel text-base font-bold text-[#F3F7F6] uppercase tracking-wider">
                CONFIRM {orderParams.side} ORDER
              </h3>
              <div className="text-[10px] font-mono-numbers text-[#8EA7A8]">
                RHINOQUANT ORDER ROUTING PROTOCOL
              </div>
            </div>
          </div>
          <button
            onClick={() => setOrderPendingConfirmation(null)}
            className="text-[#8EA7A8] hover:text-[#E2ECE9] p-1 rounded hover:bg-[#12282C] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 font-mono-numbers text-xs">
          {/* Order Summary Box */}
          <div className="bg-[#071114] border border-[#183338] rounded p-4 space-y-2.5">
            <div className="flex justify-between items-center text-sm font-bold text-[#E2ECE9] border-b border-[#142629] pb-2">
              <span>{instrument.name} ({orderParams.grade})</span>
              <span className={isBuy ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                {orderParams.side} {orderParams.quantity} {instrument.unit.toUpperCase()}S
              </span>
            </div>

            <div className="flex justify-between text-[#8EA7A8]">
              <span>Delivery Hub:</span>
              <span className="text-[#E2ECE9] font-medium">{orderParams.region}</span>
            </div>

            <div className="flex justify-between text-[#8EA7A8]">
              <span>Order Execution Type:</span>
              <span className="text-[#C5A059] font-semibold">{orderParams.type}</span>
            </div>

            <div className="flex justify-between text-[#8EA7A8]">
              <span>Unit Price (GBP / {instrument.unit.toUpperCase()}):</span>
              <span className="text-[#E2ECE9] font-bold">&pound;{orderParams.price.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-[#8EA7A8]">
              <span>Settlement Window:</span>
              <span className="text-[#10B981]">{orderParams.deliveryPeriod || 'Spot Delivery (T+2)'}</span>
            </div>

            <div className="flex justify-between text-[#8EA7A8]">
              <span>Estimated Notional:</span>
              <span className="text-[#E2ECE9] font-semibold">&pound;{notional.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>

            <div className="flex justify-between text-[#8EA7A8]">
              <span>LCH Clearing &amp; Port Fee (0.12%):</span>
              <span className="text-[#567274]">&pound;{fees.toFixed(2)}</span>
            </div>

            <div className="flex justify-between pt-2 border-t border-[#183338] text-sm">
              <span className="font-bold text-[#F3F7F6]">Net Settlement Value:</span>
              <span className="font-bold text-[#10B981] text-base">&pound;{total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
          </div>

          {/* Regulatory Clearance Notice */}
          <div className="flex items-start gap-2 text-[11px] text-[#8EA7A8] bg-[#091D1B] border border-[#124238] p-2.5 rounded">
            <ShieldCheck className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
            <span>
              By confirming, this order will be routed to the matching engine and cleared via London Clearing House under UK Agricultural Exchange Rules.
            </span>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 bg-[#071114] border-t border-[#183338] flex gap-3">
          <button
            onClick={() => setOrderPendingConfirmation(null)}
            className="flex-1 py-2.5 bg-[#0F2226] hover:bg-[#15343A] text-[#8EA7A8] hover:text-[#E2ECE9] font-mono-numbers text-xs font-semibold rounded transition-colors"
          >
            DISCARD
          </button>
          <button
            onClick={confirmPendingOrder}
            className={`flex-1 py-2.5 font-mono-numbers text-xs font-bold rounded uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 ${
              isBuy
                ? 'bg-[#10B981] hover:bg-[#059669] text-[#05241C]'
                : 'bg-[#EF4444] hover:bg-[#DC2626] text-[#FFFFFF]'
            }`}
          >
            <span>CONFIRM &amp; TRANSMIT</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export const NewsArticleModal: React.FC = () => {
  const { selectedNewsArticle, setSelectedNewsArticle } = useMarket();

  if (!selectedNewsArticle) return null;

  return (
    <div className="fixed inset-0 bg-[#000000]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0B171A] border border-[#23474F] rounded-sm w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-4 border-b border-[#183338] flex justify-between items-center bg-[#071114]">
          <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#10292E] text-[#C5A059] border border-[#1F4A4F] rounded uppercase">
            {selectedNewsArticle.category} INTELLIGENCE REPORT
          </span>
          <button
            onClick={() => setSelectedNewsArticle(null)}
            className="text-[#8EA7A8] hover:text-[#E2ECE9] p-1 rounded hover:bg-[#12282C] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="space-y-1">
            <h2 className="font-cinzel text-xl md:text-2xl font-bold text-[#F3F7F6]">
              {selectedNewsArticle.title}
            </h2>
            <div className="flex items-center gap-3 text-xs font-mono-numbers text-[#8EA7A8]">
              <span>Published: {selectedNewsArticle.timestamp}</span>
              <span>&bull;</span>
              <span>Commodity Impact: <strong className="text-[#10B981]">{selectedNewsArticle.affectedCommodity}</strong></span>
            </div>
          </div>

          <p className="text-sm text-[#D8E6E7] font-sans-ui leading-relaxed bg-[#071114] p-4 rounded border border-[#183338]">
            {selectedNewsArticle.fullText}
          </p>
        </div>

        <div className="p-4 bg-[#071114] border-t border-[#183338] text-right">
          <button
            onClick={() => setSelectedNewsArticle(null)}
            className="px-4 py-2 bg-[#10292E] hover:bg-[#15383E] text-[#10B981] text-xs font-mono-numbers font-bold rounded"
          >
            CLOSE REPORT
          </button>
        </div>
      </div>
    </div>
  );
};
