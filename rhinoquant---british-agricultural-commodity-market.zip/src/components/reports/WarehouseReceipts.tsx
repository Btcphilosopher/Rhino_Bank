import React, { useState } from 'react';
import { FileText, ShieldCheck, CheckCircle2, Download, ExternalLink, QrCode, Search } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { PhysicalWarehouseInventory } from '../../types/market';

export const WarehouseReceipts: React.FC = () => {
  const { physicalInventory } = useMarket();
  const [selectedReceipt, setSelectedReceipt] = useState<PhysicalWarehouseInventory>(physicalInventory[0]);

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Header Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              ELECTRONIC WAREHOUSE RECEIPTS (E-WR) &amp; DEFRA PASSPORTS
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              AIC / TASCC CERTIFIED TITLE
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Cryptographically signed title documents for physical grain stored in verified UK deepwater port terminals and commercial silos.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Receipts Table */}
        <div className="lg:col-span-7 bg-[#0B171A] border border-[#183338] rounded-sm overflow-hidden shadow-lg">
          <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex justify-between items-center">
            <h3 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] uppercase tracking-wider">
              ISSUED TITLE RECEIPTS
            </h3>
            <span className="text-[10px] font-mono-numbers text-[#C5A059]">
              {physicalInventory.length} ACTIVE CERTIFICATES
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono-numbers text-xs">
              <thead>
                <tr className="border-b border-[#142629] text-[10px] text-[#668486] uppercase bg-[#081417]">
                  <th className="py-2.5 px-3">RECEIPT NO</th>
                  <th className="py-2.5 px-2">WAREHOUSE &bull; PORT</th>
                  <th className="py-2.5 px-2">COMMODITY</th>
                  <th className="py-2.5 px-2 text-right">QUANTITY</th>
                  <th className="py-2.5 px-3 text-right">ASSURANCE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#102226]">
                {physicalInventory.map((wh) => {
                  const isSelected = selectedReceipt.id === wh.id;
                  return (
                    <tr
                      key={wh.id}
                      onClick={() => setSelectedReceipt(wh)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-[#10292E] text-[#F3F7F6] font-semibold border-l-2 border-[#10B981]' : 'hover:bg-[#0E2024] text-[#C6D8D9]'
                      }`}
                    >
                      <td className="py-3 px-3">
                        <div className="font-bold text-[#E2ECE9]">{wh.receiptNumber}</div>
                        <div className="text-[9px] text-[#567274]">{wh.id}</div>
                      </td>
                      <td className="py-3 px-2">
                        <div className="font-medium text-[#E2ECE9]">{wh.warehouseName}</div>
                        <div className="text-[9px] text-[#8EA7A8]">{wh.location}</div>
                      </td>
                      <td className="py-3 px-2">
                        <div className="text-xs text-[#E2ECE9]">{wh.commodity}</div>
                        <div className="text-[9px] text-[#8EA7A8]">{wh.grade}</div>
                      </td>
                      <td className="py-3 px-2 text-right font-bold text-[#10B981]">
                        {wh.quantityHeld.toLocaleString()}t
                      </td>
                      <td className="py-3 px-3 text-right">
                        <span className="text-[9px] font-mono-numbers px-2 py-0.5 bg-[#091D1B] text-[#10B981] border border-[#124238] rounded">
                          RED TRACTOR
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Electronic Warehouse Certificate Document Preview */}
        <div className="lg:col-span-5 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-xl flex flex-col justify-between">
          <div className="border border-[#23474F] bg-[#071114] p-4 rounded space-y-3 font-mono-numbers text-xs">
            {/* Header Document */}
            <div className="flex justify-between items-start border-b border-[#183338] pb-3">
              <div>
                <div className="font-cinzel text-base font-bold text-[#C5A059] tracking-wider">
                  RHINOQUANT REPOSITORY
                </div>
                <div className="text-[10px] text-[#8EA7A8]">UK Grain Passport Certificate</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-[#567274]">DOCUMENT REF:</div>
                <div className="text-xs font-bold text-[#E2ECE9]">{selectedReceipt.receiptNumber}</div>
              </div>
            </div>

            {/* Quality Specs Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs py-1">
              <div className="p-2 bg-[#0B171A] border border-[#142629] rounded">
                <div className="text-[9px] text-[#8EA7A8]">MOISTURE CONTENT</div>
                <div className="font-bold text-[#10B981] text-sm">{selectedReceipt.moisturePercent}% (Basis 15.0%)</div>
              </div>

              <div className="p-2 bg-[#0B171A] border border-[#142629] rounded">
                <div className="text-[9px] text-[#8EA7A8]">PROTEIN / DRY MATTER</div>
                <div className="font-bold text-[#E2ECE9] text-sm">{selectedReceipt.proteinPercent}%</div>
              </div>

              <div className="p-2 bg-[#0B171A] border border-[#142629] rounded">
                <div className="text-[9px] text-[#8EA7A8]">TEST WEIGHT</div>
                <div className="font-bold text-[#E2ECE9] text-sm">{selectedReceipt.testWeight} kg / hl</div>
              </div>

              <div className="p-2 bg-[#0B171A] border border-[#142629] rounded">
                <div className="text-[9px] text-[#8EA7A8]">HAGBERG FALLING NO.</div>
                <div className="font-bold text-[#10B981] text-sm">{selectedReceipt.hagbergFallingNo}s</div>
              </div>
            </div>

            <div className="space-y-1 text-[11px] text-[#8EA7A8] border-t border-[#183338] pt-2">
              <div className="flex justify-between">
                <span>Storage Facility:</span>
                <span className="text-[#E2ECE9] font-medium">{selectedReceipt.warehouseName}</span>
              </div>
              <div className="flex justify-between">
                <span>Certification Standard:</span>
                <span className="text-[#10B981]">{selectedReceipt.certification}</span>
              </div>
              <div className="flex justify-between">
                <span>Daily Storage Tariff:</span>
                <span className="text-[#E2ECE9]">&pound;{selectedReceipt.dailyStorageCostPerTonne}/t per day</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => alert(`Certificate ${selectedReceipt.receiptNumber} exported to PDF.`)}
              className="w-full py-2.5 bg-[#10292E] hover:bg-[#15383E] text-[#10B981] border border-[#1F4A4F] rounded text-xs font-mono-numbers font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>DOWNLOAD CRYPTOGRAPHIC GRAIN PASSPORT (PDF)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
