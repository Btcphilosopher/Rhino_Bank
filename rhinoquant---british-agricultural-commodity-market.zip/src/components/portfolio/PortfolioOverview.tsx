import React, { useState } from 'react';
import { Briefcase, ArrowUpRight, ArrowDownRight, Layers, ShieldCheck, DollarSign, PieChart, CheckCircle2 } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { Position } from '../../types/market';

export const PortfolioOverview: React.FC = () => {
  const { portfolio, userPositions, physicalInventory, setActiveView } = useMarket();
  const [activeTab, setActiveTab] = useState<'ALL' | 'PHYSICAL' | 'DERIVATIVES' | 'CASH'>('ALL');

  const filteredPositions = userPositions.filter(p => {
    if (activeTab === 'PHYSICAL') return p.type === 'PHYSICAL';
    if (activeTab === 'DERIVATIVES') return p.type === 'FUTURES' || p.type === 'OPTIONS';
    return true;
  });

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Header Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              INSTITUTIONAL PORTFOLIO &amp; MULTI-ASSET OMS
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              LCH CLEARING SETTLED
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Consolidated view of physical grain inventory across UK silos, spot commitments, futures contracts and cash balances.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono-numbers text-xs">
          <button
            onClick={() => setActiveTab('ALL')}
            className={`px-3 py-1.5 rounded uppercase font-semibold ${
              activeTab === 'ALL' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            All Holdings ({userPositions.length})
          </button>
          <button
            onClick={() => setActiveTab('PHYSICAL')}
            className={`px-3 py-1.5 rounded uppercase font-semibold ${
              activeTab === 'PHYSICAL' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            Physical Silos ({physicalInventory.length})
          </button>
          <button
            onClick={() => setActiveTab('DERIVATIVES')}
            className={`px-3 py-1.5 rounded uppercase font-semibold ${
              activeTab === 'DERIVATIVES' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            Derivatives (Futures/Options)
          </button>
        </div>
      </div>

      {/* Main NAV Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 font-mono-numbers text-xs">
        <div className="p-4 bg-[#0B171A] border border-[#183338] rounded shadow-lg">
          <div className="text-[10px] text-[#8EA7A8] uppercase">TOTAL NET ASSET VALUE (NAV)</div>
          <div className="text-2xl font-bold text-[#F3F7F6] mt-1">
            &pound;{portfolio.navGbp.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-[#10B981] mt-1 flex items-center gap-1 font-semibold">
            <span>▲ +&pound;{portfolio.dailyUnrealisedPnlGbp.toLocaleString()} (+0.95%) Today</span>
          </div>
        </div>

        <div className="p-4 bg-[#0B171A] border border-[#183338] rounded shadow-lg">
          <div className="text-[10px] text-[#8EA7A8] uppercase">AVAILABLE CASH &amp; COLLATERAL</div>
          <div className="text-2xl font-bold text-[#E2ECE9] mt-1">
            &pound;{portfolio.availableCashGbp.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-[#567274] mt-1">
            &pound;{portfolio.collateralLockedGbp.toLocaleString()} Locked in LCH Margins
          </div>
        </div>

        <div className="p-4 bg-[#0B171A] border border-[#183338] rounded shadow-lg">
          <div className="text-[10px] text-[#8EA7A8] uppercase">PHYSICAL INVENTORY HELD</div>
          <div className="text-2xl font-bold text-[#C5A059] mt-1">
            &pound;{portfolio.physicalInventoryValueGbp.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-[#8EA7A8] mt-1">
            10,000 Tonnes Wheat in East Anglia &amp; Humber
          </div>
        </div>

        <div className="p-4 bg-[#0B171A] border border-[#183338] rounded shadow-lg">
          <div className="text-[10px] text-[#8EA7A8] uppercase">NET HEDGED DELTA</div>
          <div className="text-2xl font-bold text-[#38BDF8] mt-1">
            +{portfolio.netDeltaGbp.toLocaleString()}t &Delta;
          </div>
          <div className="text-[10px] text-[#10B981] mt-1">
            Delta Neutral Risk Ratio: 97.1% Hedged
          </div>
        </div>
      </div>

      {/* Positions Table */}
      <div className="bg-[#0B171A] border border-[#183338] rounded-sm overflow-hidden shadow-lg">
        <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex justify-between items-center">
          <h3 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] uppercase tracking-wider">
            OPEN POSITIONS &amp; CONTRACTS
          </h3>
          <span className="text-[10px] font-mono-numbers text-[#10B981]">
            MARK-TO-MARKET LIVE
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono-numbers text-xs">
            <thead>
              <tr className="border-b border-[#142629] text-[10px] text-[#668486] uppercase bg-[#081417]">
                <th className="py-2.5 px-3">INSTRUMENT</th>
                <th className="py-2.5 px-2">TYPE</th>
                <th className="py-2.5 px-2">SIDE &bull; QTY</th>
                <th className="py-2.5 px-2 text-right">ENTRY PRICE</th>
                <th className="py-2.5 px-2 text-right">CURRENT</th>
                <th className="py-2.5 px-2 text-right">MARGIN LOCKED</th>
                <th className="py-2.5 px-3 text-right">UNREALISED P&amp;L</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102226]">
              {filteredPositions.map((pos) => {
                const isPositive = pos.unrealisedPnl >= 0;
                return (
                  <tr key={pos.id} className="hover:bg-[#0E2024] transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-bold text-[#E2ECE9]">{pos.name}</div>
                      <div className="text-[9px] text-[#567274]">{pos.symbol} &bull; Ref: {pos.id}</div>
                    </td>
                    <td className="py-3 px-2">
                      <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#071114] border border-[#183338] rounded text-[#8EA7A8]">
                        {pos.type}
                      </span>
                    </td>
                    <td className="py-3 px-2 font-semibold text-[#E2ECE9]">
                      <span className={pos.side === 'LONG' ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                        {pos.side}
                      </span>{' '}
                      {pos.quantity.toLocaleString()} {pos.unit}
                    </td>
                    <td className="py-3 px-2 text-right text-[#8EA7A8]">&pound;{pos.entryPrice.toFixed(2)}</td>
                    <td className="py-3 px-2 text-right font-bold text-[#E2ECE9]">&pound;{pos.currentPrice.toFixed(2)}</td>
                    <td className="py-3 px-2 text-right text-[#C5A059]">
                      {pos.marginLocked > 0 ? `£${pos.marginLocked.toLocaleString()}` : '— (Ex-Farm)'}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className={`font-bold ${isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                        {isPositive ? '+' : ''}&pound;{pos.unrealisedPnl.toLocaleString()}
                      </div>
                      <div className={`text-[10px] ${isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                        ({isPositive ? '+' : ''}{pos.unrealisedPnlPercent}%)
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
