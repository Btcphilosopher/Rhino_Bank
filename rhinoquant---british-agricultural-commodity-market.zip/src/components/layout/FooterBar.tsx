import React, { useState, useEffect } from 'react';
import { ShieldCheck, CheckCircle2, Server, Globe2 } from 'lucide-react';

export const FooterBar: React.FC = () => {
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      const day = now.getDate().toString().padStart(2, '0');
      const month = now.toLocaleString('en-GB', { month: 'short' }).toUpperCase();
      const year = now.getFullYear();
      const hours = now.getHours().toString().padStart(2, '0');
      const mins = now.getMinutes().toString().padStart(2, '0');
      const secs = now.getSeconds().toString().padStart(2, '0');
      setTimeStr(`${day} ${month} ${year} ${hours}:${mins}:${secs} BST`);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer className="h-7 bg-[#050C0E] border-t border-[#142629] px-4 flex items-center justify-between text-[11px] font-mono-numbers text-[#7E999A] select-none z-20">
      {/* Left branding & regulatory tag */}
      <div className="flex items-center gap-3">
        <span className="font-cinzel text-xs font-bold text-[#C5A059] tracking-wider">
          RHINOQUANT
        </span>
        <span className="text-[#1F3D45]">|</span>
        <span className="text-[#8EA7A8] tracking-wider">SECURE</span>
        <span className="text-[#1F3D45]">/</span>
        <span className="text-[#8EA7A8] tracking-wider">REGULATED</span>
        <span className="text-[#1F3D45]">/</span>
        <span className="text-[#D8E6E7] tracking-wider">UK BASED</span>
      </div>

      {/* Center status */}
      <div className="hidden md:flex items-center gap-5 text-[10px]">
        <div className="flex items-center gap-1.5 text-[#10B981]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-ping"></span>
          <span>CLEARING: LCH REPO / COMMODITIES NODE ACTIVE</span>
        </div>
        <div className="text-[#1F3D45]">&bull;</div>
        <div className="text-[#8EA7A8]">
          DEFRA GRAIN PASSPORT PROTOCOL v3.2
        </div>
      </div>

      {/* Right system online & clock */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-[#10B981]">
          <span className="w-2 h-2 rounded-full bg-[#10B981]"></span>
          <span className="uppercase text-[10px] tracking-wider">SYSTEM ONLINE</span>
        </div>
        <span className="text-[#1F3D45]">|</span>
        <div className="text-[#D8E6E7]">
          {timeStr || '24 SEP 2026 14:35:00 BST'}
        </div>
      </div>
    </footer>
  );
};
