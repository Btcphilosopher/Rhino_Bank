import React from 'react';
import { 
  Home, 
  Sprout, 
  Layers, 
  ListTree, 
  ShieldAlert, 
  Map, 
  Truck, 
  Briefcase, 
  Cpu, 
  Scale, 
  FileText, 
  Settings,
  Flame,
  Wheat,
  Activity
} from 'lucide-react';
import { useMarket, ActiveView } from '../../context/MarketContext';

interface NavItem {
  id: ActiveView;
  label: string;
  icon: React.ReactNode;
  badge?: string;
}

export const Sidebar: React.FC = () => {
  const { activeView, setActiveView } = useMarket();

  const navItems: NavItem[] = [
    { id: 'HOME', label: 'Home', icon: <Home className="w-4 h-4" /> },
    { id: 'SPOT', label: 'Spot Market', icon: <Wheat className="w-4 h-4" /> },
    { id: 'DERIVATIVES', label: 'Derivatives', icon: <Layers className="w-4 h-4" />, badge: 'FUT/OPT' },
    { id: 'ORDER_BOOKS', label: 'Orders & Depth', icon: <ListTree className="w-4 h-4" /> },
    { id: 'HEDGE_PHYSICAL', label: 'Hedge Physical', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'BASIS_MARKET', label: 'Basis Market & Map', icon: <Map className="w-4 h-4" /> },
    { id: 'LOGISTICS', label: 'Logistics & Fleet', icon: <Truck className="w-4 h-4" /> },
    { id: 'PORTFOLIO', label: 'Portfolio', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'QUANT_LAB', label: 'Quant Lab', icon: <Cpu className="w-4 h-4" />, badge: 'ALPHA' },
    { id: 'RISK', label: 'Risk Terminal', icon: <Scale className="w-4 h-4" /> },
    { id: 'REPORTS', label: 'Warehouse Receipts', icon: <FileText className="w-4 h-4" /> },
    { id: 'SETTINGS', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <aside className="w-60 bg-[#071114] border-r border-[#183338] flex flex-col justify-between select-none z-20 shrink-0 h-[calc(100vh-4rem)]">
      {/* Navigation List */}
      <div className="py-4 flex-1 overflow-y-auto">
        <div className="px-4 pb-2 text-[10px] font-mono-numbers uppercase tracking-widest text-[#567274]">
          MARKET NAVIGATION
        </div>
        <nav className="space-y-1 px-2">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-[#0E2628] text-[#E8F5E9] border-l-2 border-[#10B981] font-semibold'
                    : 'text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0B1A1E]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={`${isActive ? 'text-[#10B981]' : 'text-[#567274]'}`}>
                    {item.icon}
                  </span>
                  <span className="tracking-wide">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono-numbers px-1.5 py-0.5 rounded bg-[#10292B] text-[#C5A059] border border-[#1D4047]">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Photographic Artwork & Motto Section (Matching exact screenshot reference) */}
      <div className="p-3 border-t border-[#183338] bg-gradient-to-b from-[#071114] to-[#040C0E]">
        {/* Silo Imagery Card */}
        <div className="relative rounded-sm overflow-hidden border border-[#183338] bg-[#0A171A] group">
          <div className="h-28 relative overflow-hidden bg-[#0A1A1E]">
            {/* SVG Illustration of Grain Silos and British Wheat Field at Sunset */}
            <svg viewBox="0 0 200 120" className="w-full h-full object-cover">
              <defs>
                <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#1E3A3A" />
                  <stop offset="60%" stopColor="#4A3B22" />
                  <stop offset="100%" stopColor="#6E4F1F" />
                </linearGradient>
                <linearGradient id="siloGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#2A3D40" />
                  <stop offset="50%" stopColor="#556E73" />
                  <stop offset="100%" stopColor="#182729" />
                </linearGradient>
              </defs>
              {/* Sky */}
              <rect x="0" y="0" width="200" height="120" fill="url(#skyGrad)" />
              {/* Sun Glow */}
              <circle cx="160" cy="50" r="28" fill="#E5C17B" opacity="0.35" />
              {/* Far trees */}
              <path d="M0,80 Q50,75 100,78 T200,75 L200,120 L0,120 Z" fill="#15261F" opacity="0.8" />
              {/* Grain Silos */}
              <rect x="15" y="35" width="28" height="60" rx="3" fill="url(#siloGrad)" />
              <path d="M13,35 Q29,20 45,35 Z" fill="#3D5357" />
              <rect x="47" y="25" width="34" height="70" rx="3" fill="url(#siloGrad)" />
              <path d="M45,25 Q64,8 83,25 Z" fill="#4B666B" />
              <rect x="85" y="40" width="26" height="55" rx="3" fill="url(#siloGrad)" />
              <path d="M83,40 Q98,28 113,40 Z" fill="#3D5357" />
              {/* Silo ladder & catwalks */}
              <line x1="15" y1="50" x2="111" y2="50" stroke="#102125" strokeWidth="1.2" />
              <line x1="47" y1="38" x2="81" y2="38" stroke="#102125" strokeWidth="1.2" />
              {/* Wheat crop foreground */}
              <path d="M0,85 Q60,78 120,84 T200,82 L200,120 L0,120 Z" fill="#8C631B" />
              <path d="M0,95 Q70,90 140,94 T200,90 L200,120 L0,120 Z" fill="#B38024" opacity="0.9" />
              {/* Grain stalks */}
              {[...Array(20)].map((_, i) => (
                <line 
                  key={i} 
                  x1={i * 10 + 4} 
                  y1={120} 
                  x2={i * 10 + 6} 
                  y2={90 + (i % 4) * 4} 
                  stroke="#E5B246" 
                  strokeWidth="1" 
                  opacity="0.75" 
                />
              ))}
            </svg>
            <div className="absolute inset-0 bg-gradient-to-t from-[#071114] via-transparent to-transparent opacity-80" />
          </div>

          <div className="p-2.5 text-center bg-[#071114]">
            <div className="text-[10px] font-mono-numbers tracking-[0.2em] uppercase text-[#C5A059] font-semibold leading-tight">
              FROM
            </div>
            <div className="text-[11px] font-cinzel tracking-[0.25em] font-bold text-[#F3F7F6] leading-tight">
              OUR FIELDS
            </div>
            <div className="text-[10px] font-mono-numbers tracking-[0.2em] uppercase text-[#C5A059] font-semibold leading-tight">
              TO YOUR
            </div>
            <div className="text-[11px] font-cinzel tracking-[0.25em] font-bold text-[#F3F7F6] leading-tight">
              MARKETS
            </div>

            {/* British Flag Emblem */}
            <div className="mt-2.5 flex items-center justify-center gap-1.5">
              <span className="text-sm">🇬🇧</span>
              <span className="text-[9px] font-mono-numbers uppercase text-[#7E999A] tracking-wider">
                UK ASSURED (AIC/TASCC)
              </span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
