import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  ShieldCheck, 
  ChevronDown, 
  User, 
  Activity, 
  Bell, 
  Search,
  Globe,
  RefreshCw
} from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const Header: React.FC = () => {
  const { volatilityIndices, setActiveView } = useMarket();
  const [currency, setCurrency] = useState<'GBP' | 'EUR' | 'USD'>('GBP');
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <header className="h-16 bg-[#071114] border-b border-[#183338] px-4 md:px-6 flex items-center justify-between z-30 select-none">
      {/* Left: Brand & Motto */}
      <div className="flex items-center gap-6">
        <div 
          onClick={() => setActiveView('HOME')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          {/* Rhino Horn / Geometric Monogram Icon */}
          <div className="w-10 h-10 rounded-sm bg-gradient-to-br from-[#10292B] to-[#0A1A1C] border border-[#23474F] flex items-center justify-center p-1.5 shadow-sm group-hover:border-[#C5A059] transition-colors">
            <svg viewBox="0 0 32 32" className="w-full h-full fill-none">
              <path 
                d="M6 24L10 10L17 7C22 7 26 11 26 16C26 21 21 24 16 24L6 24Z" 
                stroke="#C5A059" 
                strokeWidth="1.8" 
                strokeLinejoin="round"
                className="group-hover:stroke-[#E5C17B] transition-colors"
              />
              <path 
                d="M17 7L21 2L24 9" 
                stroke="#10B981" 
                strokeWidth="1.8" 
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="14" cy="14" r="1.5" fill="#E2ECE9" />
              <path d="M10 24L10 21" stroke="#8EA7A8" strokeWidth="1.5" strokeLinecap="round" />
              <path d="M19 24L19 21" stroke="#8EA7A8" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-cinzel text-lg md:text-xl font-bold tracking-[0.2em] text-[#F3F7F6]">
                RHINOQUANT
              </span>
              <span className="text-[10px] uppercase font-mono-numbers px-1.5 py-0.5 bg-[#0F262A] text-[#C5A059] border border-[#23474F] rounded">
                EXCHANGE
              </span>
            </div>
            <div className="text-[10px] tracking-wider text-[#7E999A] uppercase hidden sm:block">
              British Agricultural Markets &bull; Derivatives OMS
            </div>
          </div>
        </div>

        {/* Top Tagline from image */}
        <div className="hidden xl:flex items-center pl-6 border-l border-[#183338] text-[11px] text-[#8EA7A8] tracking-widest font-mono-numbers">
          <span className="text-[#C5A059]">REAL COMMODITIES.</span>
          <span className="mx-2 text-[#23474F]">&bull;</span>
          <span>REAL VALUE.</span>
          <span className="mx-2 text-[#23474F]">&bull;</span>
          <span className="text-[#D8E6E7]">A STRONGER BRITAIN.</span>
        </div>
      </div>

      {/* Middle: Volatility Indices Bar */}
      <div className="hidden lg:flex items-center gap-4 bg-[#0A171A] border border-[#183338] px-3.5 py-1.5 rounded-sm text-xs font-mono-numbers">
        {/* Wheat Volatility Index */}
        <div className="flex items-center gap-2">
          <span className="text-[#8EA7A8] font-semibold">RQ-WVIX</span>
          <span className="text-[#E2ECE9] font-medium">{volatilityIndices.wheat.value.toFixed(2)}%</span>
          <span className={`flex items-center text-[11px] ${volatilityIndices.wheat.change >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
            {volatilityIndices.wheat.change >= 0 ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
            +{volatilityIndices.wheat.changePercent}%
          </span>
        </div>

        <div className="h-3 w-px bg-[#183338]" />

        {/* Barley Volatility Index */}
        <div className="flex items-center gap-2">
          <span className="text-[#8EA7A8] font-semibold">RQ-BVIX</span>
          <span className="text-[#E2ECE9] font-medium">{volatilityIndices.barley.value.toFixed(2)}%</span>
          <span className={`flex items-center text-[11px] ${volatilityIndices.barley.change >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
            {volatilityIndices.barley.change >= 0 ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
            {volatilityIndices.barley.changePercent}%
          </span>
        </div>
      </div>

      {/* Right Controls: Currency, Status, Profile */}
      <div className="flex items-center gap-3 md:gap-5">
        {/* Currency Switcher */}
        <div className="relative">
          <button 
            onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-[#0A171A] hover:bg-[#102226] border border-[#183338] rounded-sm text-xs text-[#E2ECE9] font-mono-numbers transition-colors"
          >
            <span>🇬🇧</span>
            <span>{currency}</span>
            <ChevronDown className="w-3 h-3 text-[#8EA7A8]" />
          </button>

          {currencyDropdownOpen && (
            <div className="absolute right-0 mt-1 w-28 bg-[#0B1A1E] border border-[#23474F] rounded shadow-xl py-1 z-50 text-xs font-mono-numbers">
              <button 
                onClick={() => { setCurrency('GBP'); setCurrencyDropdownOpen(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#152E33] flex items-center justify-between text-[#E2ECE9]"
              >
                <span>🇬🇧 GBP (£)</span>
                {currency === 'GBP' && <span className="text-[#10B981]">&bull;</span>}
              </button>
              <button 
                onClick={() => { setCurrency('EUR'); setCurrencyDropdownOpen(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#152E33] flex items-center justify-between text-[#8EA7A8]"
              >
                <span>🇪🇺 EUR (&euro;)</span>
                {currency === 'EUR' && <span className="text-[#10B981]">&bull;</span>}
              </button>
              <button 
                onClick={() => { setCurrency('USD'); setCurrencyDropdownOpen(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#152E33] flex items-center justify-between text-[#8EA7A8]"
              >
                <span>🇺🇸 USD ($)</span>
                {currency === 'USD' && <span className="text-[#10B981]">&bull;</span>}
              </button>
            </div>
          )}
        </div>

        {/* Markets Open indicator matching screenshot */}
        <div className="flex items-center gap-2 px-3 py-1 bg-[#091D1B] border border-[#124238] rounded-sm text-xs font-mono-numbers text-[#10B981]">
          <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse"></span>
          <span className="font-semibold tracking-wide uppercase text-[11px]">MARKETS OPEN</span>
        </div>

        {/* Trader Profile badge matching screenshot */}
        <div 
          onClick={() => setActiveView('SETTINGS')}
          className="flex items-center gap-2.5 pl-2 pr-3 py-1 bg-[#0A171A] hover:bg-[#102226] border border-[#183338] rounded-sm cursor-pointer transition-colors"
        >
          <div className="w-7 h-7 rounded-full bg-[#152E33] border border-[#23474F] flex items-center justify-center text-[#C5A059]">
            <User className="w-3.5 h-3.5" />
          </div>
          <div className="text-left hidden md:block">
            <div className="text-xs font-semibold text-[#E2ECE9] tracking-wide leading-none">T. FORD</div>
            <div className="text-[9px] uppercase tracking-wider text-[#8EA7A8] font-mono-numbers leading-tight mt-0.5">TRADER</div>
          </div>
        </div>
      </div>
    </header>
  );
};
