import React, { useState } from 'react';
import { Scale, AlertTriangle, ShieldCheck, Activity, TrendingUp, TrendingDown, Gauge } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const RiskTerminal: React.FC = () => {
  const { portfolio, userPositions } = useMarket();
  const [selectedStressScenario, setSelectedStressScenario] = useState<string>('WHEAT_UP_10');

  const stressScenarios = [
    { id: 'WHEAT_UP_10', name: 'UK Wheat +10% Rally', pnlImpact: 12400, desc: 'Spot rises to £203.78/t. Short hedges mitigate physical surplus.' },
    { id: 'WHEAT_DOWN_10', name: 'UK Wheat -10% Slump', pnlImpact: -8200, desc: 'Spot falls to £166.72/t. Futures gains offset 91% of physical inventory drop.' },
    { id: 'FUEL_SHOCK_15', name: 'Bulk Road & Rail Fuel +15%', pnlImpact: -14500, desc: 'Haulage rates surge across East Anglia & Humber corridor.' },
    { id: 'FROST_YIELD_SHOCK', name: 'Agronomic Frost / Yield Deficit', pnlImpact: 45200, desc: 'Domestic milling premiums widen by £25/t over feed wheat.' },
    { id: 'GBP_USD_DROP_5', name: 'GBP/USD -5% Devaluation', pnlImpact: 28000, desc: 'Import parity prices lift UK FOB export competitiveness.' }
  ];

  const currentScenario = stressScenarios.find(s => s.id === selectedStressScenario) || stressScenarios[0];

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Header Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              ENTERPRISE RISK &amp; GREEK EXPOSURE TERMINAL
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              BASEL III / EMIR COMPLIANT
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Real-time portfolio Greeks, Value at Risk (VaR), collateral margin requirements and multi-asset stress testing.
          </p>
        </div>
      </div>

      {/* Greek Badges Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 font-mono-numbers text-xs">
        <div className="p-3 bg-[#0B171A] border border-[#183338] rounded shadow">
          <div className="text-[10px] text-[#8EA7A8]">NET DELTA (&Delta;)</div>
          <div className="text-base font-bold text-[#10B981] mt-0.5">+2,900t</div>
          <div className="text-[9px] text-[#567274]">Delta Hedged (97.1%)</div>
        </div>

        <div className="p-3 bg-[#0B171A] border border-[#183338] rounded shadow">
          <div className="text-[10px] text-[#8EA7A8]">NET GAMMA (&Gamma;)</div>
          <div className="text-base font-bold text-[#38BDF8] mt-0.5">+0.042 / &pound;</div>
          <div className="text-[9px] text-[#567274]">Convexity Positive</div>
        </div>

        <div className="p-3 bg-[#0B171A] border border-[#183338] rounded shadow">
          <div className="text-[10px] text-[#8EA7A8]">NET VEGA (&nu;)</div>
          <div className="text-base font-bold text-[#C5A059] mt-0.5">+&pound;1,850 / 1% IV</div>
          <div className="text-[9px] text-[#567274]">Long Volatility</div>
        </div>

        <div className="p-3 bg-[#0B171A] border border-[#183338] rounded shadow">
          <div className="text-[10px] text-[#8EA7A8]">DAILY THETA (&Theta;)</div>
          <div className="text-base font-bold text-[#EF4444] mt-0.5">-&pound;245 / day</div>
          <div className="text-[9px] text-[#567274]">Time Decay</div>
        </div>

        <div className="p-3 bg-[#0B171A] border border-[#183338] rounded shadow">
          <div className="text-[10px] text-[#8EA7A8]">1-DAY VaR (99%)</div>
          <div className="text-base font-bold text-[#EF4444] mt-0.5">&pound;{portfolio.var99_1dGbp.toLocaleString()}</div>
          <div className="text-[9px] text-[#567274]">Parametric Monte Carlo</div>
        </div>

        <div className="p-3 bg-[#0B171A] border border-[#183338] rounded shadow">
          <div className="text-[10px] text-[#8EA7A8]">MARGIN UTILISATION</div>
          <div className="text-base font-bold text-[#10B981] mt-0.5">{portfolio.marginUtilisationPercent}%</div>
          <div className="text-[9px] text-[#567274]">&pound;80,200 of &pound;2.14m cash</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Stress Testing Engine */}
        <div className="lg:col-span-6 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg">
          <div className="flex justify-between items-center border-b border-[#183338] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase">
              MACRO &amp; AGRONOMIC STRESS TEST ENGINE
            </h3>
            <span className="text-[10px] font-mono-numbers text-[#C5A059]">
              5 SCENARIOS CONFIGURED
            </span>
          </div>

          <div className="space-y-2 font-mono-numbers text-xs">
            {stressScenarios.map((sc) => {
              const isSelected = selectedStressScenario === sc.id;
              const isPositive = sc.pnlImpact >= 0;
              return (
                <div
                  key={sc.id}
                  onClick={() => setSelectedStressScenario(sc.id)}
                  className={`p-3 rounded border cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#10292E] border-[#1F4A4F]' : 'bg-[#071114] border-[#183338] hover:bg-[#0E2024]'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-[#E2ECE9]">{sc.name}</span>
                    <span className={`font-bold text-sm ${isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                      {isPositive ? '+' : ''}&pound;{sc.pnlImpact.toLocaleString()}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#8EA7A8] mt-1 font-sans-ui">
                    {sc.desc}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Positions Delta Ladder */}
        <div className="lg:col-span-6 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#183338] pb-2">
              <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase">
                ACTIVE POSITION DELTA CONTRIBUTION
              </h3>
              <span className="text-[10px] font-mono-numbers text-[#10B981]">
                {userPositions.length} EXPOSURE LEGS
              </span>
            </div>

            <div className="space-y-2 mt-3 font-mono-numbers text-xs">
              {userPositions.map((pos) => (
                <div key={pos.id} className="p-2.5 bg-[#071114] border border-[#183338] rounded flex justify-between items-center">
                  <div>
                    <div className="font-bold text-[#E2ECE9]">{pos.name}</div>
                    <div className="text-[10px] text-[#567274]">{pos.type} &bull; {pos.side} {pos.quantity} {pos.unit}</div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${pos.delta >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                      {pos.delta >= 0 ? '+' : ''}{pos.delta.toLocaleString()}t &Delta;
                    </div>
                    <div className="text-[10px] text-[#8EA7A8]">&pound;{pos.unrealisedPnl.toLocaleString()} P&amp;L</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-3 bg-[#071114] border border-[#142629] rounded text-xs font-mono-numbers text-[#8EA7A8] flex justify-between items-center">
            <span>Portfolio Margin Safety Cushion:</span>
            <span className="text-[#10B981] font-bold">&pound;2,059,800 Excess Liquidity</span>
          </div>
        </div>
      </div>
    </div>
  );
};
