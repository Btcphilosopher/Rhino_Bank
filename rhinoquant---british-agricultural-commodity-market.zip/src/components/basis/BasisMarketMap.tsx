import React, { useState } from 'react';
import { MapPin, Navigation, TrendingUp, TrendingDown, Layers, ArrowUpRight } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { BasisPoint } from '../../types/market';

export const BasisMarketMap: React.FC = () => {
  const { basisRegions, setSelectedInstrument, spotInstruments, setActiveView } = useMarket();
  const [selectedRegion, setSelectedRegion] = useState<BasisPoint>(basisRegions[0]);

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Top Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              UK AGRICULTURAL BASIS MARKET &amp; REGIONAL FLOWS
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              NATIONAL BENCHMARK: &pound;185.25 / t
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Regional physical price differentials relative to the London/East Anglian benchmark, freight parity and port intake silos.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Regional Basis Table */}
        <div className="lg:col-span-6 bg-[#0B171A] border border-[#183338] rounded-sm overflow-hidden shadow-lg flex flex-col justify-between">
          <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex justify-between items-center">
            <h3 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] uppercase tracking-wider">
              REGIONAL BASIS SPREAD MATRIX
            </h3>
            <span className="text-[10px] font-mono-numbers text-[#C5A059]">
              BASIS = CASH PRICE &minus; BENCHMARK
            </span>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left font-mono-numbers text-xs">
              <thead>
                <tr className="border-b border-[#142629] text-[10px] text-[#668486] uppercase bg-[#081417]">
                  <th className="py-2.5 px-3">REGION</th>
                  <th className="py-2.5 px-2 text-right">BENCHMARK</th>
                  <th className="py-2.5 px-2 text-right">BASIS DIFF</th>
                  <th className="py-2.5 px-2 text-right">DELIVERED CASH</th>
                  <th className="py-2.5 px-2 text-right">FREIGHT</th>
                  <th className="py-2.5 px-3 text-right">SILO STOCK</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#102226]">
                {basisRegions.map((region) => {
                  const isSelected = selectedRegion.region === region.region;
                  const isPositive = region.basisDifferential >= 0;

                  return (
                    <tr
                      key={region.region}
                      onClick={() => setSelectedRegion(region)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-[#10292E] text-[#F3F7F6] font-semibold border-l-2 border-[#10B981]'
                          : 'hover:bg-[#0E2024] text-[#C6D8D9]'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-medium text-[#E2ECE9] flex items-center gap-1.5">
                        <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-[#10B981]' : 'text-[#567274]'}`} />
                        {region.region}
                      </td>
                      <td className="py-2.5 px-2 text-right text-[#8EA7A8]">&pound;{region.benchmarkPrice.toFixed(2)}</td>
                      <td className={`py-2.5 px-2 text-right font-bold ${isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                        {isPositive ? '+' : ''}&pound;{region.basisDifferential.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-2 text-right font-bold text-[#E2ECE9]">
                        &pound;{region.effectivePrice.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-2 text-right text-[#7E999A]">
                        &pound;{region.freightCostToPort.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="inline-flex items-center gap-1 text-[11px]">
                          <span className="w-10 bg-[#183338] h-1.5 rounded-full overflow-hidden inline-block">
                            <span 
                              className="bg-[#C5A059] h-full block rounded-full" 
                              style={{ width: `${region.siloStockPct}%` }}
                            />
                          </span>
                          <span>{region.siloStockPct}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Selected Region Detailed Card */}
          <div className="p-3 bg-[#071114] border-t border-[#183338] space-y-2">
            <div className="flex justify-between items-center text-xs font-mono-numbers">
              <span className="text-[#8EA7A8]">Primary Off-takers &amp; Destination Elevators:</span>
              <span className="text-[#C5A059] font-bold">{selectedRegion.region}</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {selectedRegion.primaryBuyers.map((b, i) => (
                <span key={i} className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#0D2124] text-[#8EA7A8] border border-[#1B3E45] rounded">
                  {b}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Interactive UK Map with Flow Lines */}
        <div className="lg:col-span-6 bg-[#0B171A] border border-[#183338] rounded-sm p-4 shadow-lg flex flex-col justify-between">
          <div className="flex justify-between items-center border-b border-[#183338] pb-2">
            <h3 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] uppercase">
              GEOGRAPHIC BASIS MAP OF GREAT BRITAIN
            </h3>
            <span className="text-[10px] font-mono-numbers text-[#10B981] flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-ping"></span>
              7 COMMERCIAL ARABLE HUBS
            </span>
          </div>

          {/* SVG Map of the UK */}
          <div className="h-80 w-full bg-[#071114] rounded border border-[#142629] relative p-2 my-2 overflow-hidden">
            <svg viewBox="0 0 400 450" className="w-full h-full">
              <defs>
                <linearGradient id="ukGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0B2326" />
                  <stop offset="100%" stopColor="#0F3338" />
                </linearGradient>
              </defs>

              {/* Simplified stylized outline of Great Britain */}
              <path
                d="M 180,20 L 210,40 L 230,80 L 210,120 L 240,150 L 270,190 L 260,230 L 290,260 L 310,290 L 280,330 L 250,370 L 190,400 L 130,410 L 90,390 L 120,350 L 140,310 L 110,280 L 130,240 L 160,200 L 150,150 L 130,100 L 160,50 Z"
                fill="url(#ukGrad)"
                stroke="#1B4249"
                strokeWidth="1.5"
              />

              {/* Flow Arrows between Regions & Ports */}
              {/* East Anglia to Tilbury */}
              <path d="M 280,310 Q 275,340 260,355" fill="none" stroke="#10B981" strokeWidth="1.5" strokeDasharray="4 2" className="animate-pulse" />
              {/* Yorkshire to Hull */}
              <path d="M 230,210 Q 250,225 265,235" fill="none" stroke="#C5A059" strokeWidth="1.5" strokeDasharray="4 2" />
              {/* Scotland to Distilleries */}
              <path d="M 180,80 Q 210,95 205,120" fill="none" stroke="#38BDF8" strokeWidth="1.5" strokeDasharray="4 2" />

              {/* Regional Node Circles */}
              {[
                { name: 'Scotland', x: 190, y: 90, diff: '+£4.50' },
                { name: 'Yorkshire', x: 235, y: 215, diff: '-£2.00' },
                { name: 'Humberside', x: 260, y: 240, diff: '-£0.75' },
                { name: 'Lincolnshire', x: 265, y: 275, diff: '£0.00' },
                { name: 'East Midlands', x: 225, y: 285, diff: '+£0.50' },
                { name: 'East Anglia', x: 285, y: 315, diff: '+£1.25' },
                { name: 'South West', x: 140, y: 380, diff: '+£3.20' }
              ].map((node) => {
                const isSelected = selectedRegion.region === node.name;
                return (
                  <g 
                    key={node.name} 
                    className="cursor-pointer group"
                    onClick={() => {
                      const match = basisRegions.find(r => r.region === node.name);
                      if (match) setSelectedRegion(match);
                    }}
                  >
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={isSelected ? 8 : 5}
                      fill={isSelected ? '#10B981' : '#0A1D20'}
                      stroke={isSelected ? '#E8F5E9' : '#C5A059'}
                      strokeWidth="2"
                    />
                    <text
                      x={node.x + 10}
                      y={node.y + 3}
                      fill={isSelected ? '#F3F7F6' : '#8EA7A8'}
                      fontSize="9"
                      fontFamily="JetBrains Mono"
                      fontWeight="bold"
                    >
                      {node.name} ({node.diff})
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="flex justify-between items-center text-xs font-mono-numbers">
            <span className="text-[#8EA7A8]">Selected: <strong className="text-[#E2ECE9]">{selectedRegion.region}</strong></span>
            <button
              onClick={() => {
                const match = spotInstruments.find(i => i.region === selectedRegion.region);
                if (match) {
                  setSelectedInstrument(match);
                  setActiveView('SPOT');
                }
              }}
              className="text-[#10B981] hover:underline flex items-center gap-1 font-bold"
            >
              <span>Trade {selectedRegion.region} Spot</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
