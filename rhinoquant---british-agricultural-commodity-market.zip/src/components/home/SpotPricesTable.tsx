import React from 'react';
import { 
  Wheat, 
  Sprout, 
  Flame, 
  Layers, 
  CircleDot, 
  Milk, 
  Beef, 
  Check, 
  TrendingUp, 
  TrendingDown 
} from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { SpotInstrument } from '../../types/market';

export const SpotPricesTable: React.FC = () => {
  const { 
    spotInstruments, 
    selectedInstrument, 
    setSelectedInstrument,
    selectedCategory 
  } = useMarket();

  const filteredInstruments = spotInstruments.filter(inst => {
    if (selectedCategory === 'GRAINS') return inst.category === 'GRAINS';
    if (selectedCategory === 'OILSEEDS') return inst.category === 'OILSEEDS';
    if (selectedCategory === 'LIVESTOCK') return inst.category === 'LIVESTOCK';
    if (selectedCategory === 'DAIRY') return inst.category === 'DAIRY';
    if (selectedCategory === 'POTATOES') return inst.category === 'POTATOES';
    if (selectedCategory === 'SUGAR') return inst.category === 'SUGAR';
    return true;
  });

  const getCommodityIcon = (iconName: string) => {
    switch (iconName) {
      case 'Wheat':
        return <Wheat className="w-4 h-4 text-[#C5A059]" />;
      case 'Barley':
        return <Wheat className="w-4 h-4 text-[#D4AF37]" />;
      case 'Rapeseed':
        return <Sprout className="w-4 h-4 text-[#10B981]" />;
      case 'Maize':
        return <CircleDot className="w-4 h-4 text-[#F59E0B]" />;
      case 'Oats':
        return <Wheat className="w-4 h-4 text-[#E2ECE9]" />;
      case 'Potatoes':
        return <CircleDot className="w-4 h-4 text-[#D97706]" />;
      case 'SugarBeet':
        return <Sprout className="w-4 h-4 text-[#10B981]" />;
      case 'Cattle':
        return <Beef className="w-4 h-4 text-[#EF4444]" />;
      case 'Lamb':
        return <Beef className="w-4 h-4 text-[#F43F5E]" />;
      case 'Milk':
        return <Milk className="w-4 h-4 text-[#38BDF8]" />;
      default:
        return <Wheat className="w-4 h-4 text-[#C5A059]" />;
    }
  };

  return (
    <div className="bg-[#0B171A] border border-[#183338] rounded-sm flex flex-col justify-between overflow-hidden shadow-lg select-none">
      {/* Table Header Title */}
      <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex items-center justify-between">
        <h3 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] tracking-wider uppercase">
          LIVE SPOT PRICES
        </h3>
        <div className="text-[10px] font-mono-numbers text-[#7E999A]">
          {filteredInstruments.length} INSTRUMENTS ACTIVE
        </div>
      </div>

      {/* Main Table */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left font-mono-numbers text-xs">
          <thead>
            <tr className="border-b border-[#142629] text-[10px] text-[#668486] uppercase bg-[#081417]">
              <th className="py-2.5 px-3">COMMODITY</th>
              <th className="py-2.5 px-2">GRADE</th>
              <th className="py-2.5 px-2">LOCATION</th>
              <th className="py-2.5 px-2 text-right">BID</th>
              <th className="py-2.5 px-2 text-right">ASK</th>
              <th className="py-2.5 px-3 text-right">CHANGE</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#102226]">
            {filteredInstruments.map((inst) => {
              const isSelected = selectedInstrument.id === inst.id;
              const isPositive = inst.change >= 0;

              return (
                <tr
                  key={inst.id}
                  onClick={() => setSelectedInstrument(inst)}
                  className={`cursor-pointer transition-all duration-150 ${
                    isSelected
                      ? 'bg-[#10292E] text-[#F3F7F6] font-semibold border-l-2 border-[#10B981]'
                      : 'hover:bg-[#0E2024] text-[#C6D8D9]'
                  }`}
                >
                  {/* Commodity Name + Icon */}
                  <td className="py-2 px-3 flex items-center gap-2">
                    <div className="p-1 rounded bg-[#0A171A] border border-[#183338]">
                      {getCommodityIcon(inst.iconName)}
                    </div>
                    <div>
                      <div className="text-xs font-medium text-[#E2ECE9]">{inst.name}</div>
                      <div className="text-[9px] text-[#567274] uppercase">{inst.symbol}</div>
                    </div>
                  </td>

                  {/* Grade */}
                  <td className="py-2 px-2 text-xs text-[#8EA7A8]">
                    {inst.grade}
                  </td>

                  {/* Location */}
                  <td className="py-2 px-2 text-xs text-[#8EA7A8]">
                    {inst.region}
                  </td>

                  {/* Bid */}
                  <td className="py-2 px-2 text-right text-xs font-bold text-[#D8E6E7]">
                    &pound;{inst.bid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>

                  {/* Ask */}
                  <td className="py-2 px-2 text-right text-xs font-bold text-[#D8E6E7]">
                    &pound;{inst.ask.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>

                  {/* Change */}
                  <td className="py-2 px-3 text-right">
                    <span
                      className={`inline-flex items-center gap-0.5 text-xs font-semibold ${
                        isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'
                      }`}
                    >
                      {isPositive ? '+' : ''}{inst.changePercent.toFixed(1)}%
                      <span className="text-[10px]">{isPositive ? '▲' : '▼'}</span>
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
