import React, { useState } from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Plus, 
  Minus, 
  ChevronDown, 
  ShieldCheck, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { OrderSide, OrderType, TimeInForce } from '../../types/market';

export const OrderEntryPanel: React.FC = () => {
  const { 
    selectedInstrument, 
    spotInstruments, 
    setSelectedInstrument, 
    placeOrder,
    setOrderPendingConfirmation 
  } = useMarket();

  const [side, setSide] = useState<OrderSide>('BUY');
  const [orderType, setOrderType] = useState<OrderType>('LIMIT');
  const [quantity, setQuantity] = useState<number>(100);
  const [price, setPrice] = useState<number>(selectedInstrument.ask || 185.50);
  const [grade, setGrade] = useState<string>(selectedInstrument.grade);
  const [region, setRegion] = useState<string>(selectedInstrument.region);
  const [timeInForce, setTimeInForce] = useState<TimeInForce>('GTC');
  const [deliveryPeriod, setDeliveryPeriod] = useState<string>('Spot (T+2 Days)');

  // Sync price when instrument or side changes
  const handleSideChange = (newSide: OrderSide) => {
    setSide(newSide);
    if (orderType === 'MARKET') {
      setPrice(newSide === 'BUY' ? selectedInstrument.ask : selectedInstrument.bid);
    }
  };

  const handleCommodityChange = (instId: string) => {
    const inst = spotInstruments.find(i => i.id === instId);
    if (inst) {
      setSelectedInstrument(inst);
      setGrade(inst.grade);
      setRegion(inst.region);
      setPrice(side === 'BUY' ? inst.ask : inst.bid);
    }
  };

  const stepQuantity = (delta: number) => {
    setQuantity(prev => Math.max(10, prev + delta));
  };

  const stepPrice = (delta: number) => {
    setPrice(prev => Number(Math.max(0.1, prev + delta).toFixed(2)));
  };

  const notionalValue = quantity * price;
  const exchangeFee = notionalValue * 0.0012; // 0.12% exchange fee
  const totalValue = side === 'BUY' ? notionalValue + exchangeFee : notionalValue - exchangeFee;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const orderParams = {
      side,
      type: orderType,
      quantity,
      price: orderType === 'MARKET' ? (side === 'BUY' ? selectedInstrument.ask : selectedInstrument.bid) : price,
      grade,
      region,
      timeInForce,
      deliveryPeriod
    };

    // Open institutional confirmation ticket
    setOrderPendingConfirmation({
      isOpen: true,
      orderParams,
      instrument: selectedInstrument
    });
  };

  const gradeOptions = ['Feed', 'Milling', 'Malting', 'Canola', 'Class A', 'Prime'];
  const regionOptions = ['East Anglia', 'Yorkshire', 'East Midlands', 'Humberside', 'Lincolnshire', 'Scotland', 'Wales', 'South West'];

  return (
    <div className="bg-[#0B171A] border border-[#183338] rounded-sm flex flex-col justify-between shadow-xl select-none">
      {/* Title */}
      <div className="p-3.5 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125]">
        <div className="flex items-center justify-between">
          <h3 className="font-cinzel text-sm md:text-base font-bold text-[#F3F7F6] tracking-wider uppercase">
            PLACE ORDER
          </h3>
          <span className="text-[10px] font-mono-numbers px-1.5 py-0.5 bg-[#091D1B] text-[#10B981] border border-[#124238] rounded">
            LCH DIRECT
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmitOrder} className="p-4 space-y-3.5 flex-1 flex flex-col justify-between">
        {/* BUY / SELL Switch (matching image screenshot) */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#071114] border border-[#183338] rounded">
          <button
            type="button"
            onClick={() => handleSideChange('BUY')}
            className={`py-2 text-xs font-mono-numbers font-bold rounded transition-all uppercase tracking-wider ${
              side === 'BUY'
                ? 'bg-[#10B981] text-[#05241C] shadow-md'
                : 'text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0E2024]'
            }`}
          >
            BUY
          </button>
          <button
            type="button"
            onClick={() => handleSideChange('SELL')}
            className={`py-2 text-xs font-mono-numbers font-bold rounded transition-all uppercase tracking-wider ${
              side === 'SELL'
                ? 'bg-[#EF4444] text-[#FFFFFF] shadow-md'
                : 'text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0E2024]'
            }`}
          >
            SELL
          </button>
        </div>

        {/* Commodity dropdown */}
        <div className="space-y-1">
          <label className="text-[10px] font-mono-numbers uppercase tracking-wider text-[#8EA7A8]">
            COMMODITY
          </label>
          <div className="relative">
            <select
              value={selectedInstrument.id}
              onChange={(e) => handleCommodityChange(e.target.value)}
              className="w-full bg-[#071114] border border-[#183338] focus:border-[#C5A059] rounded px-3 py-2 text-xs text-[#E2ECE9] font-medium appearance-none cursor-pointer outline-none"
            >
              {spotInstruments.map((inst) => (
                <option key={inst.id} value={inst.id}>
                  {inst.name} ({inst.region} &bull; {inst.grade})
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-[#8EA7A8] absolute right-3 top-2.5 pointer-events-none" />
          </div>
        </div>

        {/* Grade & Location Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="space-y-1">
            <label className="text-[10px] font-mono-numbers uppercase tracking-wider text-[#8EA7A8]">
              GRADE
            </label>
            <div className="relative">
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="w-full bg-[#071114] border border-[#183338] focus:border-[#C5A059] rounded px-2.5 py-1.5 text-xs text-[#E2ECE9] appearance-none cursor-pointer outline-none"
              >
                {gradeOptions.map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
              <ChevronDown className="w-3 h-3 text-[#8EA7A8] absolute right-2.5 top-2.5 pointer-events-none" />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-mono-numbers uppercase tracking-wider text-[#8EA7A8]">
              LOCATION
            </label>
            <div className="relative">
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="w-full bg-[#071114] border border-[#183338] focus:border-[#C5A059] rounded px-2.5 py-1.5 text-xs text-[#E2ECE9] appearance-none cursor-pointer outline-none"
              >
                {regionOptions.map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
              <ChevronDown className="w-3 h-3 text-[#8EA7A8] absolute right-2.5 top-2.5 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Quantity (Tonnes) Stepper */}
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-[10px] font-mono-numbers uppercase tracking-wider text-[#8EA7A8]">
              QUANTITY ({selectedInstrument.unit.toUpperCase()}S)
            </label>
            <span className="text-[10px] font-mono-numbers text-[#567274]">LOT: 25t</span>
          </div>
          <div className="flex items-center bg-[#071114] border border-[#183338] rounded overflow-hidden">
            <button
              type="button"
              onClick={() => stepQuantity(-25)}
              className="px-3 py-2 text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0E2024] transition-colors"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
              className="w-full bg-transparent text-center font-mono-numbers text-sm font-bold text-[#E2ECE9] outline-none"
            />
            <button
              type="button"
              onClick={() => stepQuantity(25)}
              className="px-3 py-2 text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0E2024] transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Price (GBP / Tonne) Stepper */}
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-[10px] font-mono-numbers uppercase tracking-wider text-[#8EA7A8]">
              PRICE (GBP / {selectedInstrument.unit.toUpperCase()})
            </label>
            {orderType === 'MARKET' ? (
              <span className="text-[10px] font-mono-numbers text-[#10B981]">MARKET EXEC</span>
            ) : (
              <span className="text-[10px] font-mono-numbers text-[#C5A059]">
                MID: &pound;{selectedInstrument.last.toFixed(2)}
              </span>
            )}
          </div>
          <div className="flex items-center bg-[#071114] border border-[#183338] rounded overflow-hidden">
            <button
              type="button"
              disabled={orderType === 'MARKET'}
              onClick={() => stepPrice(-0.50)}
              className="px-3 py-2 text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0E2024] transition-colors disabled:opacity-30"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <input
              type="number"
              step="0.25"
              disabled={orderType === 'MARKET'}
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="w-full bg-transparent text-center font-mono-numbers text-sm font-bold text-[#E2ECE9] outline-none disabled:opacity-50"
            />
            <button
              type="button"
              disabled={orderType === 'MARKET'}
              onClick={() => stepPrice(0.50)}
              className="px-3 py-2 text-[#8EA7A8] hover:text-[#E2ECE9] hover:bg-[#0E2024] transition-colors disabled:opacity-30"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Order Type Selector */}
        <div className="space-y-1">
          <label className="text-[10px] font-mono-numbers uppercase tracking-wider text-[#8EA7A8]">
            ORDER TYPE
          </label>
          <div className="relative">
            <select
              value={orderType}
              onChange={(e) => {
                const val = e.target.value as OrderType;
                setOrderType(val);
                if (val === 'MARKET') {
                  setPrice(side === 'BUY' ? selectedInstrument.ask : selectedInstrument.bid);
                }
              }}
              className="w-full bg-[#071114] border border-[#183338] focus:border-[#C5A059] rounded px-3 py-1.5 text-xs text-[#E2ECE9] appearance-none cursor-pointer outline-none font-mono-numbers"
            >
              <option value="LIMIT">Limit Order</option>
              <option value="MARKET">Market Order (Immediate Fill)</option>
              <option value="STOP">Stop Loss</option>
              <option value="STOP_LIMIT">Stop Limit</option>
              <option value="ICEBERG">Iceberg Order (Disclosed 20%)</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-[#8EA7A8] absolute right-3 top-2.5 pointer-events-none" />
          </div>
        </div>

        {/* Financial Breakdown Box */}
        <div className="bg-[#071114] border border-[#142629] p-2.5 rounded space-y-1 text-[11px] font-mono-numbers text-[#8EA7A8]">
          <div className="flex justify-between">
            <span>Estimated Notional:</span>
            <span className="text-[#E2ECE9] font-semibold">&pound;{notionalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div className="flex justify-between">
            <span>Exchange & Port Fee (0.12%):</span>
            <span className="text-[#567274]">&pound;{exchangeFee.toFixed(2)}</span>
          </div>
          <div className="flex justify-between pt-1 border-t border-[#142629] text-xs">
            <span className="font-semibold text-[#D8E6E7]">Total Settlement Value:</span>
            <span className="font-bold text-[#10B981]">&pound;{totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>

        {/* Big Action Submit Button */}
        <button
          type="submit"
          className={`w-full py-3 rounded text-xs font-mono-numbers font-bold tracking-wider uppercase transition-all shadow-lg flex items-center justify-center gap-2 ${
            side === 'BUY'
              ? 'bg-[#10B981] hover:bg-[#059669] text-[#05241C]'
              : 'bg-[#EF4444] hover:bg-[#DC2626] text-[#FFFFFF]'
          }`}
        >
          {side === 'BUY' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
          <span>PLACE {side} ORDER</span>
        </button>
      </form>
    </div>
  );
};
