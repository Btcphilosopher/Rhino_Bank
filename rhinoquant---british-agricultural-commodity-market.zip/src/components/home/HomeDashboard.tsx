import React from 'react';
import { useMarket } from '../../context/MarketContext';
import { CommodityCategory } from '../../types/market';
import { SpotPricesTable } from './SpotPricesTable';
import { MarketChart } from './MarketChart';
import { OrderEntryPanel } from './OrderEntryPanel';
import { MarketDepthPanel } from './MarketDepthPanel';
import { RecentActivityPanel, AgriIntelligenceCard } from './RecentActivityAndNews';

export const HomeDashboard: React.FC = () => {
  const { selectedCategory, setSelectedCategory, setActiveView } = useMarket();

  const categories: { id: CommodityCategory; label: string }[] = [
    { id: 'GRAINS', label: 'GRAINS' },
    { id: 'OILSEEDS', label: 'OILSEEDS' },
    { id: 'LIVESTOCK', label: 'LIVESTOCK' },
    { id: 'DAIRY', label: 'DAIRY' },
    { id: 'SUGAR', label: 'SUGAR' },
    { id: 'POTATOES', label: 'POTATOES' },
    { id: 'FERTILISER', label: 'FERTILISER' },
    { id: 'BIOENERGY', label: 'BIOENERGY' },
  ];

  return (
    <div className="space-y-3.5 pb-6">
      {/* 1. Institutional Hero Banner (Matching exact screenshot reference) */}
      <div className="relative rounded-sm overflow-hidden border border-[#183338] bg-[#0A171A] shadow-2xl">
        {/* Panoramic Landscape SVG Illustration of British Farmland at Sunrise / Sunset */}
        <div className="h-44 md:h-52 w-full relative overflow-hidden bg-[#071518]">
          <svg viewBox="0 0 1200 240" preserveAspectRatio="xMidYMid slice" className="w-full h-full object-cover">
            <defs>
              <linearGradient id="heroSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0B2326" />
                <stop offset="35%" stopColor="#1E3E38" />
                <stop offset="70%" stopColor="#664D1D" />
                <stop offset="100%" stopColor="#9C6B1B" />
              </linearGradient>
              <linearGradient id="sunBloom" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFE082" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#FFB300" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#FF8F00" stopOpacity="0" />
              </linearGradient>
              <radialGradient id="sunGlow" cx="40%" cy="35%" r="45%">
                <stop offset="0%" stopColor="#FFF8E1" stopOpacity="0.75" />
                <stop offset="25%" stopColor="#FFD54F" stopOpacity="0.45" />
                <stop offset="60%" stopColor="#FFB300" stopOpacity="0.15" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Sky */}
            <rect width="1200" height="240" fill="url(#heroSky)" />
            
            {/* Sun Glow */}
            <ellipse cx="480" cy="90" rx="360" ry="120" fill="url(#sunGlow)" />

            {/* Distant Rolling Hills of Yorkshire & East Anglia */}
            <path d="M0,130 Q300,105 600,120 T1200,110 L1200,240 L0,240 Z" fill="#173426" opacity="0.6" />
            <path d="M0,145 Q240,125 550,140 T1200,130 L1200,240 L0,240 Z" fill="#20422B" opacity="0.8" />
            <path d="M0,165 Q380,145 780,160 T1200,150 L1200,240 L0,240 Z" fill="#2D522F" opacity="0.9" />

            {/* Combine Harvester and Tractor Silhouette at Right (exact as picture) */}
            <g transform="translate(760, 95) scale(0.85)">
              {/* Combine main body */}
              <rect x="60" y="30" width="75" height="35" rx="3" fill="#1C4732" stroke="#2D6E4E" strokeWidth="1" />
              {/* Cab */}
              <path d="M60,35 L42,35 L48,50 L60,50 Z" fill="#3D6B6E" />
              {/* Large header cutter bar */}
              <ellipse cx="25" cy="58" rx="16" ry="10" fill="#2A3835" stroke="#C5A059" strokeWidth="1.5" />
              {/* Grain auger pipe */}
              <path d="M100,32 L150,15" stroke="#1C4732" strokeWidth="4" strokeLinecap="round" />
              {/* Heavy track / wheels */}
              <rect x="52" y="55" width="42" height="15" rx="4" fill="#0D181A" stroke="#3D5357" strokeWidth="1" />
              <circle cx="118" cy="62" r="10" fill="#0D181A" stroke="#3D5357" strokeWidth="1.5" />

              {/* Accompanying Chaser Bin Tractor */}
              <g transform="translate(90, 8)">
                <rect x="50" y="30" width="30" height="20" fill="#155E38" />
                <circle cx="56" cy="52" r="8" fill="#0D181A" />
                <circle cx="74" cy="52" r="8" fill="#0D181A" />
                {/* Grain trailer */}
                <rect x="85" y="24" width="45" height="24" rx="3" fill="#214A38" stroke="#346F54" strokeWidth="1" />
                <circle cx="98" cy="52" r="7" fill="#0D181A" />
                <circle cx="118" cy="52" r="7" fill="#0D181A" />
              </g>
            </g>

            {/* Golden Wheat Field Foreground */}
            <path d="M0,180 Q300,165 650,180 T1200,172 L1200,240 L0,240 Z" fill="#996C1B" />
            <path d="M0,195 Q250,185 600,195 T1200,188 L1200,240 L0,240 Z" fill="#B88523" opacity="0.95" />
            <path d="M0,215 Q400,205 800,212 T1200,208 L1200,240 L0,240 Z" fill="#D49E31" opacity="0.95" />

            {/* Stylized wheat stalks texture */}
            {[...Array(60)].map((_, i) => (
              <line 
                key={i} 
                x1={i * 20 + 5} 
                y1={240} 
                x2={i * 20 + 8} 
                y2={205 + (i % 5) * 5} 
                stroke="#E5B246" 
                strokeWidth="1.2" 
                opacity="0.8" 
              />
            ))}
          </svg>

          {/* Gradient Overlay for Text Readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#071114]/90 via-[#071114]/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#071114] via-transparent to-transparent opacity-90" />

          {/* Left Text Overlay matching screenshot */}
          <div className="absolute left-6 top-8 md:top-10 max-w-xl z-10">
            <h1 className="font-cinzel text-2xl md:text-3xl font-extrabold text-[#F8FAFC] tracking-wider drop-shadow-md">
              Spot Market
            </h1>
            <p className="text-xs md:text-sm text-[#D1E3E2] font-sans-ui mt-1 font-medium drop-shadow">
              Trade physical agri-commodities. Delivered across the UK and beyond.
            </p>
          </div>

          {/* Right Text Overlay matching screenshot */}
          <div className="absolute right-6 top-7 md:top-9 text-right z-10 hidden sm:block">
            <div className="font-cinzel text-sm md:text-base font-bold text-[#F8FAFC] tracking-[0.2em] uppercase drop-shadow-md">
              BRITISH AGRICULTURE.
            </div>
            <div className="font-cinzel text-sm md:text-base font-bold text-[#C5A059] tracking-[0.2em] uppercase drop-shadow-md">
              GLOBAL MARKETS.
            </div>
            <div className="text-[10px] font-mono-numbers text-[#A0BABA] tracking-widest uppercase mt-1">
              LIQUIDITY / TRANSPARENCY / SUSTAINABILITY
            </div>
          </div>
        </div>

        {/* 2. Commodity Category Filter Tabs (Matching exact screenshot reference) */}
        <div className="flex items-center gap-1 px-4 py-2 bg-[#081417] border-t border-[#183338] overflow-x-auto select-none">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-sm text-xs font-mono-numbers uppercase tracking-wider font-semibold transition-all whitespace-nowrap ${
                  isSelected
                    ? 'bg-[#10292E] text-[#10B981] border-b-2 border-[#10B981] shadow-sm'
                    : 'text-[#6F8E90] hover:text-[#D8E6E7] hover:bg-[#0E2024]'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Main Operational Trading Grid (Exact Proportions & Layout from Screenshot) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5">
        {/* Left Column (5 Cols on large screens): Live Spot Prices */}
        <div className="lg:col-span-5 flex flex-col gap-3.5">
          <SpotPricesTable />
        </div>

        {/* Center Column (4 Cols on large screens): Interactive Chart */}
        <div className="lg:col-span-4 flex flex-col gap-3.5">
          <MarketChart />
        </div>

        {/* Right Column (3 Cols on large screens): Place Order Terminal */}
        <div className="lg:col-span-3 flex flex-col gap-3.5">
          <OrderEntryPanel />
        </div>
      </div>

      {/* 4. Lower Operational Row (Market Depth, Recent Activity, Intelligence) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
        {/* Market Depth (5 Cols) */}
        <div className="md:col-span-5">
          <MarketDepthPanel />
        </div>

        {/* Recent Activity (4 Cols) */}
        <div className="md:col-span-4">
          <RecentActivityPanel />
        </div>

        {/* Agricultural Intelligence Report (3 Cols) */}
        <div className="md:col-span-3">
          <AgriIntelligenceCard />
        </div>
      </div>
    </div>
  );
};
