import React from 'react';
import { useMarket } from '../../context/MarketContext';

export const MarketDepthPanel: React.FC = () => {
  const { orderBook, selectedInstrument } = useMarket();

  const maxVolume = Math.max(
    ...orderBook.bids.map(b => b.volume),
    ...orderBook.asks.map(a => a.volume),
    2000
  );

  const totalVol = orderBook.totalBidVolume + orderBook.totalAskVolume || 1;
  const buyPct = ((orderBook.totalBidVolume / totalVol) * 100).toFixed(1);
  const sellPct = ((orderBook.totalAskVolume / totalVol) * 100).toFixed(1);

  return (
    <div className="bg-[#0B171A] border border-[#183338] rounded-sm flex flex-col justify-between overflow-hidden shadow-lg select-none">
      {/* Title */}
      <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex items-center justify-between">
        <h4 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] tracking-wider uppercase">
          MARKET DEPTH &mdash; {selectedInstrument.name.toUpperCase()} ({selectedInstrument.region.toUpperCase()})
        </h4>
        <div className="text-[10px] font-mono-numbers text-[#8EA7A8] flex items-center gap-2">
          <span>SPREAD: <strong className="text-[#C5A059]">&pound;{orderBook.spread.toFixed(2)}</strong></span>
          <span className="text-[#23474F]">&bull;</span>
          <span>MID: <strong className="text-[#E2ECE9]">&pound;{orderBook.midPrice.toFixed(2)}</strong></span>
        </div>
      </div>

      {/* Main Depth Ladder Table */}
      <div className="p-3 space-y-1.5 font-mono-numbers text-xs">
        {/* Table Header */}
        <div className="grid grid-cols-4 text-[10px] uppercase text-[#668486] font-semibold pb-1 border-b border-[#142629]">
          <div className="text-left">BUY VOLUME</div>
          <div className="text-right pr-3 text-[#10B981]">BID</div>
          <div className="text-left pl-3 text-[#EF4444]">ASK</div>
          <div className="text-right">SELL VOLUME</div>
        </div>

        {/* 5 Levels Rows matching screenshot */}
        {orderBook.bids.slice(0, 5).map((bid, idx) => {
          const ask = orderBook.asks[idx] || { price: 0, volume: 0 };
          const bidFillPct = Math.min(100, (bid.volume / maxVolume) * 100);
          const askFillPct = Math.min(100, (ask.volume / maxVolume) * 100);

          return (
            <div key={idx} className="grid grid-cols-4 items-center py-1 relative text-xs hover:bg-[#0E2024] rounded px-1 transition-colors">
              {/* Left Bid Fill Bar */}
              <div
                className="absolute left-0 top-0 bottom-0 bg-[#0E342B] opacity-40 rounded-l"
                style={{ width: `${bidFillPct * 0.48}%` }}
              />
              {/* Right Ask Fill Bar */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-[#3D1416] opacity-40 rounded-r"
                style={{ width: `${askFillPct * 0.48}%` }}
              />

              {/* Bid Volume */}
              <div className="text-left z-10 font-medium text-[#D8E6E7]">
                {bid.volume.toLocaleString()}
              </div>

              {/* Bid Price */}
              <div className="text-right pr-3 z-10 font-bold text-[#10B981]">
                &pound;{bid.price.toFixed(2)}
              </div>

              {/* Ask Price */}
              <div className="text-left pl-3 z-10 font-bold text-[#EF4444]">
                &pound;{ask.price.toFixed(2)}
              </div>

              {/* Ask Volume */}
              <div className="text-right z-10 font-medium text-[#D8E6E7]">
                {ask.volume.toLocaleString()}
              </div>
            </div>
          );
        })}
      </div>

      {/* Proportional Depth Bar & Totals at Bottom matching screenshot */}
      <div className="p-3 bg-[#071114] border-t border-[#142629] space-y-2">
        {/* Dynamic Dual Color Bar */}
        <div className="h-1.5 w-full bg-[#183338] rounded-full overflow-hidden flex">
          <div 
            className="h-full bg-[#10B981] transition-all duration-500" 
            style={{ width: `${buyPct}%` }}
          />
          <div 
            className="h-full bg-[#EF4444] transition-all duration-500" 
            style={{ width: `${sellPct}%` }}
          />
        </div>

        {/* Totals display */}
        <div className="flex justify-between items-center text-[10px] font-mono-numbers text-[#8EA7A8]">
          <div>
            TOTAL BUY <strong className="text-[#10B981] text-xs font-bold ml-1">{orderBook.totalBidVolume.toLocaleString()}</strong> ({buyPct}%)
          </div>
          <div>
            TOTAL SELL <strong className="text-[#EF4444] text-xs font-bold ml-1">{orderBook.totalAskVolume.toLocaleString()}</strong> ({sellPct}%)
          </div>
        </div>
      </div>
    </div>
  );
};
