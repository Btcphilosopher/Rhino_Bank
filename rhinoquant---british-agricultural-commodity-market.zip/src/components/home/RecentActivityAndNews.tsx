import React from 'react';
import { ArrowUpRight, ArrowDownRight, ArrowRight, ExternalLink, Newspaper, ShieldAlert } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';

export const RecentActivityPanel: React.FC = () => {
  const { recentTrades, setActiveView } = useMarket();

  return (
    <div className="bg-[#0B171A] border border-[#183338] rounded-sm flex flex-col justify-between overflow-hidden shadow-lg select-none">
      {/* Title */}
      <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex items-center justify-between">
        <h4 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] tracking-wider uppercase">
          RECENT ACTIVITY
        </h4>
        <span className="text-[10px] font-mono-numbers text-[#10B981] flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-ping"></span>
          LIVE FEED
        </span>
      </div>

      {/* Trade list */}
      <div className="p-2 space-y-1 overflow-y-auto max-h-[175px] font-mono-numbers text-xs">
        {recentTrades.slice(0, 6).map((trd) => {
          const isBuy = trd.side === 'BUY';
          return (
            <div
              key={trd.id}
              className="flex items-center justify-between py-1 px-2 rounded hover:bg-[#0E2024] transition-colors"
            >
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[#567274] w-10">{trd.time}</span>
                <span className={`text-xs ${isBuy ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                  {isBuy ? '▲' : '▼'}
                </span>
                <span className="text-[#D8E6E7] text-[11px]">
                  {isBuy ? 'Bought' : 'Sold'} <strong className="text-[#E2ECE9]">{trd.quantity}{trd.unit}</strong>{' '}
                  <span className="underline decoration-[#23474F] underline-offset-2">{trd.instrumentName}</span>
                </span>
              </div>

              <div className="font-bold text-[#E2ECE9] text-[11px]">
                @{` `}&pound;{trd.price.toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Link */}
      <div className="p-2.5 bg-[#071114] border-t border-[#142629]">
        <button
          onClick={() => setActiveView('ORDER_BOOKS')}
          className="text-xs text-[#8EA7A8] hover:text-[#10B981] font-medium flex items-center gap-1.5 transition-colors group"
        >
          <span>View all orders</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};

export const AgriIntelligenceCard: React.FC = () => {
  const { intelligenceNews, setSelectedNewsArticle } = useMarket();
  const featuredArticle = intelligenceNews[0];

  return (
    <div className="bg-[#0B171A] border border-[#183338] rounded-sm flex flex-col justify-between overflow-hidden shadow-lg select-none">
      {/* Agricultural Image Header */}
      <div className="relative h-24 overflow-hidden bg-[#0A1A1E]">
        {/* SVG illustration of modern British combine harvester & tractor in wheat field */}
        <svg viewBox="0 0 320 100" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="fieldSky" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1C3835" />
              <stop offset="60%" stopColor="#4D3B1C" />
              <stop offset="100%" stopColor="#785317" />
            </linearGradient>
          </defs>
          <rect width="320" height="100" fill="url(#fieldSky)" />
          {/* Distant Hills */}
          <path d="M0,55 Q80,45 160,52 T320,48 L320,100 L0,100 Z" fill="#1B3322" opacity="0.85" />
          {/* Tractor / Tanker silhouette */}
          <g transform="translate(200, 28) scale(0.65)">
            {/* Green Body */}
            <rect x="20" y="30" width="45" height="25" rx="3" fill="#155E38" stroke="#258552" strokeWidth="1" />
            {/* Cab glass */}
            <path d="M35,15 L55,15 L62,30 L35,30 Z" fill="#4B777A" opacity="0.8" />
            {/* Big wheels */}
            <circle cx="28" cy="56" r="14" fill="#182522" stroke="#485B57" strokeWidth="3" />
            <circle cx="60" cy="58" r="11" fill="#182522" stroke="#485B57" strokeWidth="3" />
            {/* Grain tank trailer */}
            <rect x="75" y="24" width="70" height="32" rx="6" fill="#1A4A3E" stroke="#2B6B59" strokeWidth="1" />
            <circle cx="95" cy="58" r="10" fill="#182522" stroke="#485B57" strokeWidth="2" />
            <circle cx="125" cy="58" r="10" fill="#182522" stroke="#485B57" strokeWidth="2" />
          </g>
          {/* Wheat foreground */}
          <path d="M0,68 Q100,62 200,66 T320,64 L320,100 L0,100 Z" fill="#A87720" />
          <path d="M0,78 Q90,74 180,78 T320,74 L320,100 L0,100 Z" fill="#C9942B" opacity="0.95" />
        </svg>
        <div className="absolute top-2 left-2 px-2 py-0.5 bg-[#071114]/85 border border-[#183338] text-[9px] font-mono-numbers uppercase text-[#C5A059] rounded">
          DEFRA INTELLIGENCE
        </div>
      </div>

      {/* Content */}
      <div className="p-3 space-y-1.5 flex-1">
        <h5 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] leading-snug">
          {featuredArticle.title}
        </h5>
        <p className="text-[11px] text-[#8EA7A8] line-clamp-2 leading-relaxed font-sans-ui">
          {featuredArticle.summary}
        </p>
      </div>

      {/* Footer CTA */}
      <div className="p-2.5 bg-[#071114] border-t border-[#142629]">
        <button
          onClick={() => setSelectedNewsArticle(featuredArticle)}
          className="text-xs text-[#C5A059] hover:text-[#E5C17B] font-medium flex items-center gap-1.5 transition-colors group font-mono-numbers"
        >
          <span>Read full report</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
