import React, { useState, useRef, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart2, 
  Activity, 
  Layers, 
  Maximize2, 
  Sliders, 
  ChevronRight,
  Eye,
  EyeOff
} from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { CandlestickData } from '../../types/market';

export const MarketChart: React.FC = () => {
  const { 
    selectedInstrument, 
    chartData, 
    chartTimeframe, 
    setChartTimeframe,
    chartType,
    setChartType,
    showIndicators,
    setShowIndicators,
    volatilityIndices
  } = useMarket();

  const [hoveredData, setHoveredData] = useState<CandlestickData | null>(null);
  const [hoverX, setHoverX] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 620, height: 320 });

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth || 620,
          height: 320
        });
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const timeframes = ['1D', '1W', '1M', '3M', '6M', '1Y', '5Y'];

  // Min and max for chart scaling
  const allPrices = chartData.flatMap(d => [d.high, d.low]);
  const minPrice = allPrices.length > 0 ? Math.min(...allPrices) * 0.992 : 170;
  const maxPrice = allPrices.length > 0 ? Math.max(...allPrices) * 1.008 : 195;
  const priceRange = maxPrice - minPrice || 1;

  const maxVolume = Math.max(...chartData.map(d => d.volume), 100);

  const padding = { top: 20, right: 55, bottom: 45, left: 15 };
  const plotWidth = dimensions.width - padding.left - padding.right;
  const plotHeight = dimensions.height - padding.top - padding.bottom;
  const volumeHeight = 50;
  const candlePlotHeight = plotHeight - volumeHeight - 10;

  const getX = (index: number) => {
    return padding.left + (index / (chartData.length - 1 || 1)) * plotWidth;
  };

  const getY = (price: number) => {
    return padding.top + candlePlotHeight - ((price - minPrice) / priceRange) * candlePlotHeight;
  };

  const getVolY = (volume: number) => {
    const volRatio = volume / maxVolume;
    return padding.top + candlePlotHeight + 10 + (volumeHeight - volRatio * volumeHeight);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current || chartData.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    if (mouseX >= padding.left && mouseX <= dimensions.width - padding.right) {
      const relX = mouseX - padding.left;
      const index = Math.min(
        chartData.length - 1,
        Math.max(0, Math.round((relX / plotWidth) * (chartData.length - 1)))
      );
      setHoveredData(chartData[index]);
      setHoverX(getX(index));
    }
  };

  const handleMouseLeave = () => {
    setHoveredData(null);
    setHoverX(null);
  };

  // Generate SVG path for line / area
  const linePoints = chartData.map((d, i) => `${getX(i)},${getY(d.close)}`).join(' ');
  const areaPath = chartData.length > 0 
    ? `M ${getX(0)},${padding.top + candlePlotHeight} ${chartData.map((d, i) => `L ${getX(i)},${getY(d.close)}`).join(' ')} L ${getX(chartData.length - 1)},${padding.top + candlePlotHeight} Z`
    : '';

  // Generate VWAP curve
  const vwapPoints = chartData
    .filter(d => d.vwap !== undefined)
    .map((d, i) => `${getX(i)},${getY(d.vwap!)}`)
    .join(' ');

  // Generate MA20 curve
  const maPoints = chartData
    .map((d, i) => d.ma20 ? `${getX(i)},${getY(d.ma20)}` : null)
    .filter(Boolean)
    .join(' ');

  // Y-axis grid levels (5 steps)
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(pct => {
    const val = minPrice + pct * priceRange;
    return {
      price: val,
      y: getY(val)
    };
  });

  const displayData = hoveredData || chartData[chartData.length - 1] || {
    time: '14:30',
    open: selectedInstrument.last,
    high: selectedInstrument.last,
    low: selectedInstrument.last,
    close: selectedInstrument.last,
    volume: 350,
    vwap: selectedInstrument.vwap
  };

  const isWheat = selectedInstrument.name.toLowerCase().includes('wheat');
  const relevantVol = isWheat ? volatilityIndices.wheat : volatilityIndices.barley;

  return (
    <div className="bg-[#0B171A] border border-[#183338] rounded-sm flex flex-col justify-between overflow-hidden shadow-lg select-none">
      {/* Chart Header matching British Agri Spot */}
      <div className="p-3.5 border-b border-[#183338] flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-[#0B171A] via-[#0E2125] to-[#0B171A]">
        <div>
          <div className="flex items-center gap-2.5">
            <h3 className="font-cinzel text-base md:text-lg font-bold text-[#F3F7F6] tracking-wider uppercase">
              {selectedInstrument.name} &mdash; {selectedInstrument.region} (SPOT)
            </h3>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              {selectedInstrument.grade}
            </span>
          </div>

          <div className="flex items-center gap-4 mt-1 text-xs font-mono-numbers text-[#8EA7A8]">
            <span>O: <strong className="text-[#E2ECE9]">&pound;{displayData.open?.toFixed(2)}</strong></span>
            <span>H: <strong className="text-[#10B981]">&pound;{displayData.high?.toFixed(2)}</strong></span>
            <span>L: <strong className="text-[#EF4444]">&pound;{displayData.low?.toFixed(2)}</strong></span>
            <span>C: <strong className="text-[#E2ECE9]">&pound;{displayData.close?.toFixed(2)}</strong></span>
            <span>VOL: <strong className="text-[#C5A059]">{displayData.volume}t</strong></span>
          </div>
        </div>

        {/* Right price summary & timeframes */}
        <div className="flex flex-col items-end gap-1.5">
          <div className="flex items-center gap-3">
            {/* Volatility index badge */}
            <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 bg-[#091F22] border border-[#194045] rounded text-[11px] font-mono-numbers">
              <span className="text-[#7E999A]">{relevantVol.symbol}:</span>
              <span className="text-[#C5A059] font-bold">{relevantVol.value.toFixed(2)}%</span>
            </div>

            <div className="text-right">
              <div className="font-mono-numbers text-lg md:text-xl font-bold text-[#F3F7F6] tracking-tight">
                &pound;{selectedInstrument.last.toFixed(2)}
              </div>
              <div className={`text-xs font-mono-numbers font-medium flex items-center justify-end ${selectedInstrument.change >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                {selectedInstrument.change >= 0 ? '+' : ''}{selectedInstrument.changePercent}% 
                <span className="ml-1">{selectedInstrument.change >= 0 ? '▲' : '▼'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chart Toolbar Controls: Timeframes & Type Selector */}
      <div className="px-3.5 py-2 bg-[#081316] border-b border-[#142629] flex items-center justify-between gap-2 text-xs font-mono-numbers">
        {/* Timeframe selector */}
        <div className="flex items-center gap-1">
          {timeframes.map((tf) => (
            <button
              key={tf}
              onClick={() => setChartTimeframe(tf)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                chartTimeframe === tf
                  ? 'bg-[#153438] text-[#E8F5E9] border border-[#23585F] font-bold shadow-sm'
                  : 'text-[#6F8E90] hover:text-[#D8E6E7] hover:bg-[#0E2024]'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Chart View Mode & Indicator Toggles */}
        <div className="flex items-center gap-2">
          {/* Chart Type */}
          <div className="flex items-center bg-[#0C1B1F] border border-[#183338] rounded p-0.5">
            <button
              onClick={() => setChartType('CANDLE')}
              className={`px-2 py-0.5 text-[10px] rounded ${chartType === 'CANDLE' ? 'bg-[#1A3F45] text-[#E2ECE9]' : 'text-[#6F8E90]'}`}
            >
              Candle
            </button>
            <button
              onClick={() => setChartType('LINE')}
              className={`px-2 py-0.5 text-[10px] rounded ${chartType === 'LINE' ? 'bg-[#1A3F45] text-[#E2ECE9]' : 'text-[#6F8E90]'}`}
            >
              Line
            </button>
            <button
              onClick={() => setChartType('AREA')}
              className={`px-2 py-0.5 text-[10px] rounded ${chartType === 'AREA' ? 'bg-[#1A3F45] text-[#E2ECE9]' : 'text-[#6F8E90]'}`}
            >
              Area
            </button>
          </div>

          {/* Indicator toggles */}
          <button
            onClick={() => setShowIndicators(prev => ({ ...prev, vwap: !prev.vwap }))}
            className={`px-2 py-0.5 rounded text-[10px] border flex items-center gap-1 ${
              showIndicators.vwap 
                ? 'bg-[#172E27] text-[#C5A059] border-[#2A5C4E]' 
                : 'bg-transparent text-[#567274] border-[#183338]'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]"></span>
            VWAP
          </button>

          <button
            onClick={() => setShowIndicators(prev => ({ ...prev, ma20: !prev.ma20 }))}
            className={`px-2 py-0.5 rounded text-[10px] border flex items-center gap-1 ${
              showIndicators.ma20 
                ? 'bg-[#122830] text-[#38BDF8] border-[#1F4A5E]' 
                : 'bg-transparent text-[#567274] border-[#183338]'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#38BDF8]"></span>
            MA20
          </button>
        </div>
      </div>

      {/* Main SVG Interactive Chart Area */}
      <div 
        ref={containerRef} 
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="relative w-full h-[320px] bg-[#071114] cursor-crosshair overflow-hidden"
      >
        <svg width={dimensions.width} height={dimensions.height} className="w-full h-full">
          <defs>
            <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#10B981" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Background Grid Lines */}
          {yTicks.map((tick, i) => (
            <g key={i}>
              <line
                x1={padding.left}
                y1={tick.y}
                x2={dimensions.width - padding.right}
                y2={tick.y}
                stroke="#122428"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
              {/* Y Axis Price Labels */}
              <text
                x={dimensions.width - padding.right + 6}
                y={tick.y + 4}
                fill="#668486"
                fontSize="10"
                fontFamily="JetBrains Mono"
                textAnchor="start"
              >
                &pound;{tick.price.toFixed(2)}
              </text>
            </g>
          ))}

          {/* Volume Section Separator */}
          <line
            x1={padding.left}
            y1={padding.top + candlePlotHeight + 8}
            x2={dimensions.width - padding.right}
            y2={padding.top + candlePlotHeight + 8}
            stroke="#183338"
            strokeWidth="1"
          />

          {/* Volume Bars */}
          {chartData.map((d, i) => {
            const x = getX(i);
            const barWidth = Math.max(2, (plotWidth / chartData.length) * 0.7);
            const y = getVolY(d.volume);
            const height = padding.top + candlePlotHeight + 10 + volumeHeight - y;
            const isBullish = d.close >= d.open;

            return (
              <rect
                key={`vol-${i}`}
                x={x - barWidth / 2}
                y={y}
                width={barWidth}
                height={Math.max(2, height)}
                fill={isBullish ? '#10B981' : '#EF4444'}
                opacity={0.35}
              />
            );
          })}

          {/* Area Chart Mode */}
          {chartType === 'AREA' && (
            <>
              <path d={areaPath} fill="url(#areaGradient)" />
              <polyline
                fill="none"
                stroke="#10B981"
                strokeWidth="2"
                points={linePoints}
              />
            </>
          )}

          {/* Line Chart Mode */}
          {chartType === 'LINE' && (
            <polyline
              fill="none"
              stroke="#10B981"
              strokeWidth="2"
              points={linePoints}
            />
          )}

          {/* Candlestick / OHLC Mode */}
          {chartType === 'CANDLE' && chartData.map((d, i) => {
            const x = getX(i);
            const openY = getY(d.open);
            const closeY = getY(d.close);
            const highY = getY(d.high);
            const lowY = getY(d.low);
            const isBullish = d.close >= d.open;
            const candleTop = Math.min(openY, closeY);
            const candleHeight = Math.max(2, Math.abs(closeY - openY));
            const candleWidth = Math.max(3, (plotWidth / chartData.length) * 0.65);

            return (
              <g key={`candle-${i}`}>
                {/* Wick */}
                <line
                  x1={x}
                  y1={highY}
                  x2={x}
                  y2={lowY}
                  stroke={isBullish ? '#10B981' : '#EF4444'}
                  strokeWidth="1.2"
                />
                {/* Body */}
                <rect
                  x={x - candleWidth / 2}
                  y={candleTop}
                  width={candleWidth}
                  height={candleHeight}
                  fill={isBullish ? '#10B981' : '#EF4444'}
                  stroke={isBullish ? '#059669' : '#DC2626'}
                  strokeWidth="0.5"
                  rx="0.5"
                />
              </g>
            );
          })}

          {/* VWAP Overlay Line */}
          {showIndicators.vwap && vwapPoints && (
            <polyline
              fill="none"
              stroke="#C5A059"
              strokeWidth="1.5"
              strokeDasharray="4 2"
              points={vwapPoints}
              opacity="0.85"
            />
          )}

          {/* MA20 Overlay Line */}
          {showIndicators.ma20 && maPoints && (
            <polyline
              fill="none"
              stroke="#38BDF8"
              strokeWidth="1.5"
              points={maPoints}
              opacity="0.85"
            />
          )}

          {/* X Axis Time Labels */}
          {chartData.filter((_, idx) => idx % 8 === 0).map((d, i) => {
            const origIdx = chartData.indexOf(d);
            return (
              <text
                key={`time-${i}`}
                x={getX(origIdx)}
                y={dimensions.height - 12}
                fill="#567274"
                fontSize="9"
                fontFamily="JetBrains Mono"
                textAnchor="middle"
              >
                {d.time}
              </text>
            );
          })}

          {/* Crosshair Cursor */}
          {hoverX !== null && hoveredData && (
            <g>
              {/* Vertical line */}
              <line
                x1={hoverX}
                y1={padding.top}
                x2={hoverX}
                y2={dimensions.height - padding.bottom + 15}
                stroke="#668486"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              {/* Horizontal line */}
              <line
                x1={padding.left}
                y1={getY(hoveredData.close)}
                x2={dimensions.width - padding.right}
                y2={getY(hoveredData.close)}
                stroke="#668486"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              {/* Axis badge */}
              <rect
                x={dimensions.width - padding.right + 2}
                y={getY(hoveredData.close) - 8}
                width={50}
                height={16}
                fill="#153438"
                stroke="#2A646E"
                rx="2"
              />
              <text
                x={dimensions.width - padding.right + 6}
                y={getY(hoveredData.close) + 4}
                fill="#E8F5E9"
                fontSize="9.5"
                fontFamily="JetBrains Mono"
                fontWeight="bold"
              >
                &pound;{hoveredData.close.toFixed(2)}
              </text>
            </g>
          )}
        </svg>
      </div>
    </div>
  );
};
