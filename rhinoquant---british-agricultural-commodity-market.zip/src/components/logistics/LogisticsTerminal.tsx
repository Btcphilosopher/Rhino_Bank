import React, { useState } from 'react';
import { Truck, Train, Ship, CheckCircle2, Clock, MapPin, Leaf, ShieldCheck, AlertCircle } from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { LogisticsMovement } from '../../types/market';

export const LogisticsTerminal: React.FC = () => {
  const { logisticsMovements } = useMarket();
  const [selectedMovement, setSelectedMovement] = useState<LogisticsMovement>(logisticsMovements[0]);

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'ROAD_BULK':
        return <Truck className="w-4 h-4 text-[#C5A059]" />;
      case 'RAIL_FREIGHT':
        return <Train className="w-4 h-4 text-[#38BDF8]" />;
      case 'COASTAL_BARGE':
        return <Ship className="w-4 h-4 text-[#10B981]" />;
      default:
        return <Truck className="w-4 h-4 text-[#C5A059]" />;
    }
  };

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Header Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl font-bold text-[#F3F7F6] uppercase tracking-wider">
              PHYSICAL LOGISTICS &amp; FLEET MONITOR
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              DEFRA E-PASSPORT CONNECTED
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Real-time bulk tipper tracking, rail freight scheduling, port berth allocation and carbon intensity certification.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono-numbers">
          <div className="text-right">
            <span className="text-[#8EA7A8]">ACTIVE TONNES IN TRANSIT:</span>
            <span className="text-[#10B981] font-bold ml-1.5">2,170t</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Movements Table */}
        <div className="lg:col-span-8 bg-[#0B171A] border border-[#183338] rounded-sm overflow-hidden shadow-lg">
          <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex justify-between items-center">
            <h3 className="font-cinzel text-xs md:text-sm font-bold text-[#F3F7F6] uppercase tracking-wider">
              ACTIVE GRAIN SHIPMENTS &amp; TRANSIT
            </h3>
            <span className="text-[10px] font-mono-numbers text-[#C5A059]">
              {logisticsMovements.length} FLEET MOVEMENTS
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono-numbers text-xs">
              <thead>
                <tr className="border-b border-[#142629] text-[10px] text-[#668486] uppercase bg-[#081417]">
                  <th className="py-2.5 px-3">CONSIGNMENT</th>
                  <th className="py-2.5 px-2">COMMODITY</th>
                  <th className="py-2.5 px-2 text-right">TONNES</th>
                  <th className="py-2.5 px-2">ORIGIN &rarr; DESTINATION</th>
                  <th className="py-2.5 px-2">ETA</th>
                  <th className="py-2.5 px-3 text-right">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#102226]">
                {logisticsMovements.map((mov) => {
                  const isSelected = selectedMovement.id === mov.id;
                  return (
                    <tr
                      key={mov.id}
                      onClick={() => setSelectedMovement(mov)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-[#10292E] text-[#F3F7F6] font-semibold border-l-2 border-[#10B981]'
                          : 'hover:bg-[#0E2024] text-[#C6D8D9]'
                      }`}
                    >
                      <td className="py-2.5 px-3 flex items-center gap-2">
                        <div className="p-1 bg-[#0A171A] border border-[#183338] rounded">
                          {getModeIcon(mov.mode)}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#E2ECE9]">{mov.reference}</div>
                          <div className="text-[9px] text-[#567274]">{mov.carrier}</div>
                        </div>
                      </td>

                      <td className="py-2.5 px-2 text-[#8EA7A8]">{mov.commodity}</td>
                      <td className="py-2.5 px-2 text-right font-bold text-[#E2ECE9]">{mov.quantityTonnes}t</td>
                      <td className="py-2.5 px-2 text-[11px] text-[#8EA7A8]">
                        <span>{mov.origin}</span> &rarr; <strong className="text-[#E2ECE9]">{mov.destination}</strong>
                      </td>
                      <td className="py-2.5 px-2 text-[#C5A059] font-medium">{mov.eta}</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className="text-[10px] px-2 py-0.5 bg-[#091D1B] text-[#10B981] border border-[#124238] rounded font-bold">
                          {mov.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Consignment Detail & Carbon Footprint */}
        <div className="lg:col-span-4 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#183338] pb-2">
              <h4 className="font-cinzel text-sm font-bold text-[#F3F7F6]">
                {selectedMovement.reference}
              </h4>
              <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#0A1D20] text-[#38BDF8] rounded">
                {selectedMovement.mode}
              </span>
            </div>

            <div className="mt-3 space-y-2.5 font-mono-numbers text-xs text-[#8EA7A8]">
              <div className="flex justify-between py-1 border-b border-[#102226]">
                <span>Logistics Operator:</span>
                <span className="text-[#E2ECE9] font-semibold">{selectedMovement.carrier}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#102226]">
                <span>Origin Terminal:</span>
                <span className="text-[#E2ECE9]">{selectedMovement.origin}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#102226]">
                <span>Destination Quay/Mill:</span>
                <span className="text-[#10B981] font-semibold">{selectedMovement.destination}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#102226]">
                <span>Freight Tariff:</span>
                <span className="text-[#E2ECE9]">&pound;{selectedMovement.costGbp.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#102226]">
                <span className="flex items-center gap-1 text-[#10B981]">
                  <Leaf className="w-3.5 h-3.5" />
                  Carbon Intensity:
                </span>
                <span className="text-[#10B981] font-bold">{selectedMovement.carbonIntensityKgPerT} kg CO₂ / t</span>
              </div>
              <div className="flex justify-between py-1">
                <span>TASCC Passport Status:</span>
                <span className="text-[#10B981] font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  VERIFIED CLEAN
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-[#071114] border border-[#183338] rounded space-y-1.5 text-xs font-mono-numbers">
            <div className="text-[10px] text-[#567274] uppercase">REAL-TIME TELEMETRY</div>
            <div className="flex items-center justify-between text-[#E2ECE9]">
              <span>Sample Moisture at Intake:</span>
              <span className="text-[#10B981] font-bold">14.1% (Within Spec)</span>
            </div>
            <div className="flex items-center justify-between text-[#E2ECE9]">
              <span>Gross Weight:</span>
              <span className="font-bold">44.20 Tonnes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
