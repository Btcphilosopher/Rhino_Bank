import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Layers, 
  Activity, 
  Sliders, 
  Plus, 
  ShieldCheck, 
  ArrowUpRight, 
  ArrowDownRight,
  Info,
  Calendar
} from 'lucide-react';
import { useMarket } from '../../context/MarketContext';
import { FuturesContract, OptionContract, ForwardCurvePoint } from '../../types/market';

export const DerivativesHub: React.FC = () => {
  const { 
    futuresContracts, 
    selectedFuture, 
    setSelectedFuture, 
    forwardCurve, 
    optionsChain, 
    volatilityIndices,
    placeOrder,
    setOrderPendingConfirmation,
    selectedInstrument
  } = useMarket();

  const [activeSubTab, setActiveSubTab] = useState<'FUTURES' | 'CURVE' | 'OPTIONS' | 'STRATEGY' | 'SPREADS'>('FUTURES');
  const [selectedExpiry, setSelectedExpiry] = useState<string>('DEC 2026');
  const [strategyType, setStrategyType] = useState<'CALL_SPREAD' | 'COLLAR' | 'STRADDLE' | 'COVERED_CALL'>('COLLAR');
  const [strategyTonnes, setStrategyTonnes] = useState<number>(1000);

  // Strategy payoff calculations
  const spotPrice = 185.25;
  const generatePayoffPoints = () => {
    const points = [];
    for (let p = 150; p <= 220; p += 2.5) {
      let pnl = 0;
      if (strategyType === 'COLLAR') {
        // Long Underlying + Buy 180 Put (£3.75) - Sell 195 Call (£4.60) -> Net credit £0.85
        const stockPnl = p - spotPrice;
        const putPnl = Math.max(0, 180 - p) - 3.75;
        const callPnl = -(Math.max(0, p - 195)) + 4.60;
        pnl = (stockPnl + putPnl + callPnl) * strategyTonnes;
      } else if (strategyType === 'CALL_SPREAD') {
        // Buy 185 Call (£9.50) - Sell 195 Call (£4.60) -> Net debit £4.90
        const longCall = Math.max(0, p - 185) - 9.50;
        const shortCall = -(Math.max(0, p - 195)) + 4.60;
        pnl = (longCall + shortCall) * strategyTonnes;
      } else if (strategyType === 'STRADDLE') {
        // Buy 185 Call (£9.50) + Buy 185 Put (£5.60) -> Net debit £15.10
        const longCall = Math.max(0, p - 185) - 9.50;
        const longPut = Math.max(0, 185 - p) - 5.60;
        pnl = (longCall + longPut) * strategyTonnes;
      } else if (strategyType === 'COVERED_CALL') {
        // Long Underlying - Sell 195 Call (£4.60)
        const stockPnl = p - spotPrice;
        const shortCall = -(Math.max(0, p - 195)) + 4.60;
        pnl = (stockPnl + shortCall) * strategyTonnes;
      }
      points.push({ price: p, pnl });
    }
    return points;
  };

  const payoffPoints = generatePayoffPoints();
  const minPnl = Math.min(...payoffPoints.map(pt => pt.pnl));
  const maxPnl = Math.max(...payoffPoints.map(pt => pt.pnl));

  return (
    <div className="space-y-4 select-none pb-8">
      {/* Header Banner */}
      <div className="bg-[#0B171A] border border-[#183338] p-4 rounded-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-cinzel text-xl md:text-2xl font-bold text-[#F3F7F6] tracking-wider uppercase">
              RHINOQUANT DERIVATIVES
            </h2>
            <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#122A2E] text-[#10B981] border border-[#1F4A4F] rounded">
              ICE / LCH CLEARED
            </span>
          </div>
          <p className="text-xs text-[#8EA7A8] font-sans-ui mt-0.5">
            Hedge price risk. Trade agricultural forward curves, futures contracts and options volatility.
          </p>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="flex items-center bg-[#071114] border border-[#183338] p-1 rounded font-mono-numbers text-xs">
          <button
            onClick={() => setActiveSubTab('FUTURES')}
            className={`px-3 py-1.5 rounded text-xs font-semibold uppercase transition-all ${
              activeSubTab === 'FUTURES' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            Futures ({futuresContracts.length})
          </button>
          <button
            onClick={() => setActiveSubTab('CURVE')}
            className={`px-3 py-1.5 rounded text-xs font-semibold uppercase transition-all ${
              activeSubTab === 'CURVE' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            Forward Curves
          </button>
          <button
            onClick={() => setActiveSubTab('OPTIONS')}
            className={`px-3 py-1.5 rounded text-xs font-semibold uppercase transition-all ${
              activeSubTab === 'OPTIONS' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            Options Chain
          </button>
          <button
            onClick={() => setActiveSubTab('STRATEGY')}
            className={`px-3 py-1.5 rounded text-xs font-semibold uppercase transition-all ${
              activeSubTab === 'STRATEGY' ? 'bg-[#10292E] text-[#10B981] border border-[#1F4A4F]' : 'text-[#8EA7A8] hover:text-[#E2ECE9]'
            }`}
          >
            Multi-Leg Strategy Ticket
          </button>
        </div>
      </div>

      {/* SUB-VIEW 1: FUTURES TABLE & DETAILS */}
      {activeSubTab === 'FUTURES' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-8 bg-[#0B171A] border border-[#183338] rounded-sm overflow-hidden shadow-lg">
            <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex justify-between items-center">
              <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase tracking-wider">
                ACTIVE UK AGRICULTURAL FUTURES
              </h3>
              <span className="text-[10px] font-mono-numbers text-[#C5A059]">
                SETTLEMENT: LCH BULK DELIVERABLE
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono-numbers text-xs">
                <thead>
                  <tr className="border-b border-[#142629] text-[10px] text-[#668486] uppercase bg-[#081417]">
                    <th className="py-2.5 px-3">CONTRACT</th>
                    <th className="py-2.5 px-2">MONTH</th>
                    <th className="py-2.5 px-2 text-right">LAST</th>
                    <th className="py-2.5 px-2 text-right">BID</th>
                    <th className="py-2.5 px-2 text-right">ASK</th>
                    <th className="py-2.5 px-2 text-right">VOLUME</th>
                    <th className="py-2.5 px-2 text-right">OPEN INT</th>
                    <th className="py-2.5 px-3 text-right">CHANGE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#102226]">
                  {futuresContracts.map((fut) => {
                    const isSelected = selectedFuture.id === fut.id;
                    return (
                      <tr
                        key={fut.id}
                        onClick={() => setSelectedFuture(fut)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-[#10292E] text-[#F3F7F6] font-semibold border-l-2 border-[#10B981]' : 'hover:bg-[#0E2024] text-[#C6D8D9]'
                        }`}
                      >
                        <td className="py-2.5 px-3">
                          <div className="text-xs font-bold text-[#E2ECE9]">{fut.name}</div>
                          <div className="text-[9px] text-[#567274]">{fut.symbol} &bull; {fut.contractSize}</div>
                        </td>
                        <td className="py-2.5 px-2 text-xs text-[#8EA7A8]">{fut.contractMonth}</td>
                        <td className="py-2.5 px-2 text-right text-xs font-bold text-[#E2ECE9]">&pound;{fut.last.toFixed(2)}</td>
                        <td className="py-2.5 px-2 text-right text-xs text-[#10B981]">&pound;{fut.bid.toFixed(2)}</td>
                        <td className="py-2.5 px-2 text-right text-xs text-[#EF4444]">&pound;{fut.ask.toFixed(2)}</td>
                        <td className="py-2.5 px-2 text-right text-xs text-[#C5A059]">{fut.volume.toLocaleString()}</td>
                        <td className="py-2.5 px-2 text-right text-xs text-[#8EA7A8]">{fut.openInterest.toLocaleString()}</td>
                        <td className={`py-2.5 px-3 text-right text-xs font-semibold ${fut.change >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {fut.change >= 0 ? '+' : ''}{fut.changePercent}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Contract Specs & Execution Panel */}
          <div className="lg:col-span-4 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#183338] pb-2">
                <h4 className="font-cinzel text-sm font-bold text-[#F3F7F6]">
                  {selectedFuture.name}
                </h4>
                <span className="text-[10px] font-mono-numbers px-2 py-0.5 bg-[#091D1B] text-[#10B981] rounded">
                  {selectedFuture.symbol}
                </span>
              </div>

              <div className="mt-3 space-y-2 font-mono-numbers text-xs text-[#8EA7A8]">
                <div className="flex justify-between py-1 border-b border-[#102226]">
                  <span>Contract Expiry:</span>
                  <span className="text-[#E2ECE9] font-semibold">{selectedFuture.expiryDate}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#102226]">
                  <span>Contract Multiplier:</span>
                  <span className="text-[#E2ECE9]">{selectedFuture.contractSize}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#102226]">
                  <span>Initial Margin:</span>
                  <span className="text-[#C5A059] font-bold">&pound;{selectedFuture.initialMargin} / lot</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#102226]">
                  <span>Maintenance Margin:</span>
                  <span className="text-[#E2ECE9]">&pound;{selectedFuture.maintMargin} / lot</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#102226]">
                  <span>Settlement Mechanism:</span>
                  <span className="text-[#10B981]">{selectedFuture.deliveryMechanism}</span>
                </div>
                <div className="flex justify-between py-1 text-xs">
                  <span>Settlement Price (Prior Day):</span>
                  <span className="text-[#E2ECE9] font-bold">&pound;{selectedFuture.settlementPrice.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Direct Quick Trade */}
            <div className="space-y-2 pt-2 border-t border-[#183338]">
              <div className="text-[10px] font-mono-numbers text-[#567274] uppercase">
                QUICK FUTURES ORDER (1 LOT = 100t)
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => placeOrder({
                    side: 'BUY',
                    type: 'LIMIT',
                    quantity: 100,
                    price: selectedFuture.ask,
                    grade: 'Futures Contract (1 Lot)',
                    region: 'LCH Warehouse',
                    deliveryPeriod: selectedFuture.contractMonth
                  })}
                  className="py-2.5 bg-[#10B981] hover:bg-[#059669] text-[#05241C] text-xs font-mono-numbers font-bold rounded flex items-center justify-center gap-1 shadow"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  BUY 1 LOT (&pound;{selectedFuture.ask.toFixed(2)})
                </button>
                <button
                  onClick={() => placeOrder({
                    side: 'SELL',
                    type: 'LIMIT',
                    quantity: 100,
                    price: selectedFuture.bid,
                    grade: 'Futures Contract (1 Lot)',
                    region: 'LCH Warehouse',
                    deliveryPeriod: selectedFuture.contractMonth
                  })}
                  className="py-2.5 bg-[#EF4444] hover:bg-[#DC2626] text-[#FFFFFF] text-xs font-mono-numbers font-bold rounded flex items-center justify-center gap-1 shadow"
                >
                  <ArrowDownRight className="w-3.5 h-3.5" />
                  SELL 1 LOT (&pound;{selectedFuture.bid.toFixed(2)})
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: FORWARD CURVE & CONTANGO ANALYTICS */}
      {activeSubTab === 'CURVE' && (
        <div className="bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#183338] pb-3">
            <div>
              <h3 className="font-cinzel text-base font-bold text-[#F3F7F6] uppercase">
                UK FEED WHEAT &mdash; FORWARD TERM STRUCTURE CURVE
              </h3>
              <p className="text-xs text-[#8EA7A8] font-mono-numbers">
                Prompt Spot through September 2027 Expiry &bull; Seasonal Carry Analysis
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-mono-numbers">
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#091D1B] border border-[#124238] rounded text-[#10B981]">
                <span className="w-2 h-2 rounded-full bg-[#10B981]"></span>
                <span>WINTER CONTANGO (+&pound;10.55/t to May 27)</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#1F1414] border border-[#3D1E1E] rounded text-[#EF4444]">
                <span className="w-2 h-2 rounded-full bg-[#EF4444]"></span>
                <span>HARVEST BACKWARDATION (-&pound;13.80/t to Aug 27)</span>
              </div>
            </div>
          </div>

          {/* Interactive SVG Forward Curve Chart */}
          <div className="h-64 w-full bg-[#071114] rounded border border-[#142629] relative p-3">
            <svg viewBox="0 0 800 200" className="w-full h-full">
              {/* Grid Lines */}
              {[180, 185, 190, 195, 200].map((p, i) => {
                const y = 180 - ((p - 175) / 30) * 150;
                return (
                  <g key={i}>
                    <line x1="40" y1={y} x2="780" y2={y} stroke="#122428" strokeDasharray="3 3" />
                    <text x="5" y={y + 3} fill="#567274" fontSize="9" fontFamily="JetBrains Mono">&pound;{p}</text>
                  </g>
                );
              })}

              {/* Curve Line */}
              {forwardCurve.length > 0 && (
                <>
                  {/* Fill Area */}
                  <polygon
                    points={`60,180 ${forwardCurve.map((pt, idx) => `${60 + idx * 58},${180 - ((pt.price - 175) / 30) * 150}`).join(' ')} ${60 + (forwardCurve.length - 1) * 58},180`}
                    fill="#10B981"
                    opacity="0.12"
                  />
                  {/* Line */}
                  <polyline
                    fill="none"
                    stroke="#10B981"
                    strokeWidth="2.5"
                    points={forwardCurve.map((pt, idx) => `${60 + idx * 58},${180 - ((pt.price - 175) / 30) * 150}`).join(' ')}
                  />
                  {/* Data Points */}
                  {forwardCurve.map((pt, idx) => {
                    const x = 60 + idx * 58;
                    const y = 180 - ((pt.price - 175) / 30) * 150;
                    return (
                      <g key={idx}>
                        <circle cx={x} cy={y} r="4" fill="#071114" stroke={pt.structure === 'Backwardation' ? '#EF4444' : '#10B981'} strokeWidth="2" />
                        <text x={x} y={y - 8} fill="#E2ECE9" fontSize="8.5" fontFamily="JetBrains Mono" fontWeight="bold" textAnchor="middle">
                          &pound;{pt.price.toFixed(2)}
                        </text>
                        <text x={x} y="195" fill="#7E999A" fontSize="8.5" fontFamily="JetBrains Mono" textAnchor="middle">
                          {pt.month}
                        </text>
                      </g>
                    );
                  })}
                </>
              )}
            </svg>
          </div>

          {/* Month on Month Curve Table */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 font-mono-numbers text-xs">
            {forwardCurve.map((pt, i) => (
              <div key={i} className="p-2 bg-[#071114] border border-[#183338] rounded">
                <div className="text-[#8EA7A8] text-[10px] font-semibold">{pt.month}</div>
                <div className="text-[#E2ECE9] font-bold text-sm">&pound;{pt.price.toFixed(2)}</div>
                <div className={`text-[10px] mt-0.5 ${pt.spreadVsPrevious >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                  {pt.spreadVsPrevious >= 0 ? '+' : ''}&pound;{pt.spreadVsPrevious.toFixed(2)} ({pt.structure})
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: COMPLETE OPTIONS CHAIN WITH GREEKS */}
      {activeSubTab === 'OPTIONS' && (
        <div className="bg-[#0B171A] border border-[#183338] rounded-sm overflow-hidden shadow-lg space-y-2">
          {/* Options Chain Header */}
          <div className="p-3 border-b border-[#183338] bg-gradient-to-r from-[#0B171A] to-[#0E2125] flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-cinzel text-sm md:text-base font-bold text-[#F3F7F6] uppercase">
                UK WHEAT OPTIONS CHAIN ({selectedExpiry})
              </h3>
              <p className="text-xs text-[#8EA7A8] font-mono-numbers">
                Underlying: UK Feed Wheat Spot &pound;185.25 &bull; Implied Volatility: {volatilityIndices.wheat.value}%
              </p>
            </div>

            {/* Expiry Selector */}
            <div className="flex items-center gap-1 font-mono-numbers text-xs">
              {['DEC 2026', 'JAN 2027', 'MAR 2027', 'MAY 2027', 'JUL 2027'].map((exp) => (
                <button
                  key={exp}
                  onClick={() => setSelectedExpiry(exp)}
                  className={`px-2.5 py-1 rounded text-[11px] font-medium ${
                    selectedExpiry === exp ? 'bg-[#153438] text-[#10B981] border border-[#23585F]' : 'text-[#6F8E90] hover:text-[#E2ECE9]'
                  }`}
                >
                  {exp}
                </button>
              ))}
            </div>
          </div>

          {/* Options Ladder Table: CALLS (Left) | STRIKE (Center) | PUTS (Right) */}
          <div className="overflow-x-auto p-2">
            <table className="w-full text-center font-mono-numbers text-xs">
              <thead>
                <tr className="border-b border-[#183338] text-[9.5px] uppercase bg-[#081417]">
                  <th colSpan={7} className="py-1.5 text-[#10B981] border-r border-[#183338] tracking-widest font-bold">
                    CALLS
                  </th>
                  <th className="py-1.5 px-3 bg-[#0A1D20] text-[#C5A059] font-bold">
                    STRIKE
                  </th>
                  <th colSpan={7} className="py-1.5 text-[#EF4444] border-l border-[#183338] tracking-widest font-bold">
                    PUTS
                  </th>
                </tr>
                <tr className="border-b border-[#142629] text-[9px] text-[#668486] uppercase bg-[#071114]">
                  <th className="py-1 px-1.5">IV</th>
                  <th className="py-1 px-1.5">&Delta; Delta</th>
                  <th className="py-1 px-1.5">&Theta; Theta</th>
                  <th className="py-1 px-1.5">VOL</th>
                  <th className="py-1 px-1.5 text-right text-[#10B981]">BID</th>
                  <th className="py-1 px-1.5 text-right text-[#EF4444]">ASK</th>
                  <th className="py-1 px-2 text-right border-r border-[#183338]">LAST</th>

                  <th className="py-1 px-3 bg-[#0A1D20] text-[#E2ECE9] font-bold">&pound; / t</th>

                  <th className="py-1 px-2 text-left border-l border-[#183338]">LAST</th>
                  <th className="py-1 px-1.5 text-left text-[#10B981]">BID</th>
                  <th className="py-1 px-1.5 text-left text-[#EF4444]">ASK</th>
                  <th className="py-1 px-1.5">VOL</th>
                  <th className="py-1 px-1.5">&Delta; Delta</th>
                  <th className="py-1 px-1.5">&Theta; Theta</th>
                  <th className="py-1 px-1.5">IV</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#102226]">
                {optionsChain.map((opt) => {
                  const isAtm = opt.strike === 185;
                  return (
                    <tr
                      key={opt.strike}
                      className={`hover:bg-[#0E2024] transition-colors ${
                        isAtm ? 'bg-[#0E282E] font-semibold' : ''
                      }`}
                    >
                      {/* Call Greeks & Prices */}
                      <td className="py-2 px-1.5 text-[10px] text-[#7E999A]">{opt.call.iv}%</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#38BDF8]">{opt.call.delta.toFixed(2)}</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#EF4444]">{opt.call.theta.toFixed(3)}</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#C5A059]">{opt.call.volume}</td>
                      <td className="py-2 px-1.5 text-right font-bold text-[#10B981]">&pound;{opt.call.bid.toFixed(2)}</td>
                      <td className="py-2 px-1.5 text-right font-bold text-[#EF4444]">&pound;{opt.call.ask.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right font-bold text-[#E2ECE9] border-r border-[#183338]">&pound;{opt.call.last.toFixed(2)}</td>

                      {/* Strike Price Center */}
                      <td className="py-2 px-3 bg-[#0A1D20] font-bold text-sm text-[#C5A059] shadow-inner">
                        &pound;{opt.strike}
                        {isAtm && <span className="ml-1 text-[8px] uppercase text-[#10B981] px-1 py-0.2 bg-[#091D1B] rounded">ATM</span>}
                      </td>

                      {/* Put Prices & Greeks */}
                      <td className="py-2 px-2 text-left font-bold text-[#E2ECE9] border-l border-[#183338]">&pound;{opt.put.last.toFixed(2)}</td>
                      <td className="py-2 px-1.5 text-left font-bold text-[#10B981]">&pound;{opt.put.bid.toFixed(2)}</td>
                      <td className="py-2 px-1.5 text-left font-bold text-[#EF4444]">&pound;{opt.put.ask.toFixed(2)}</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#C5A059]">{opt.put.volume}</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#38BDF8]">{opt.put.delta.toFixed(2)}</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#EF4444]">{opt.put.theta.toFixed(3)}</td>
                      <td className="py-2 px-1.5 text-[10px] text-[#7E999A]">{opt.put.iv}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: MULTI-LEG STRATEGY BUILDER */}
      {activeSubTab === 'STRATEGY' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-4 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-4 shadow-lg">
            <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase border-b border-[#183338] pb-2">
              AGRICULTURAL STRATEGY CONSTRUCTOR
            </h3>

            <div className="space-y-3 font-mono-numbers text-xs">
              <div>
                <label className="text-[10px] text-[#8EA7A8] uppercase">STRATEGY TEMPLATE</label>
                <div className="grid grid-cols-2 gap-1.5 mt-1">
                  {[
                    { id: 'COLLAR', label: 'Zero-Cost Collar' },
                    { id: 'CALL_SPREAD', label: 'Bull Call Spread' },
                    { id: 'STRADDLE', label: 'Volatility Straddle' },
                    { id: 'COVERED_CALL', label: 'Covered Call' }
                  ].map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setStrategyType(s.id as any)}
                      className={`p-2 rounded text-left border text-xs font-semibold ${
                        strategyType === s.id ? 'bg-[#10292E] text-[#10B981] border-[#1F4A4F]' : 'bg-[#071114] text-[#8EA7A8] border-[#183338]'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] text-[#8EA7A8] uppercase">PHYSICAL / GRAIN TONNES</label>
                <input
                  type="number"
                  step="100"
                  value={strategyTonnes}
                  onChange={(e) => setStrategyTonnes(Number(e.target.value))}
                  className="w-full mt-1 bg-[#071114] border border-[#183338] rounded px-3 py-2 text-[#E2ECE9] font-bold"
                />
              </div>

              <div className="bg-[#071114] border border-[#142629] p-3 rounded space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#8EA7A8]">Strategy Cost / Premium:</span>
                  <span className="text-[#10B981] font-bold">
                    {strategyType === 'COLLAR' ? '+£0.85/t (Net Credit)' : strategyType === 'CALL_SPREAD' ? '-£4.90/t (Net Debit)' : '-£15.10/t'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8EA7A8]">Max Downside Floor:</span>
                  <span className="text-[#E2ECE9] font-semibold">&pound;180.00 / t</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8EA7A8]">Max Upside Ceiling:</span>
                  <span className="text-[#E2ECE9] font-semibold">&pound;195.00 / t</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8EA7A8]">Net Delta Position:</span>
                  <span className="text-[#38BDF8] font-bold">+0.12 (Delta Neutral)</span>
                </div>
              </div>

              <button
                onClick={() => {
                  placeOrder({
                    side: 'BUY',
                    type: 'LIMIT',
                    quantity: strategyTonnes,
                    price: 185.25,
                    grade: `Multi-Leg ${strategyType}`,
                    region: 'LCH Option Clearing',
                    deliveryPeriod: 'Dec 2026'
                  });
                }}
                className="w-full py-3 bg-[#10B981] hover:bg-[#059669] text-[#05241C] font-bold rounded uppercase tracking-wider shadow-lg"
              >
                EXECUTE STRATEGY LEGS
              </button>
            </div>
          </div>

          {/* Strategy Payoff Diagram */}
          <div className="lg:col-span-8 bg-[#0B171A] border border-[#183338] rounded-sm p-4 space-y-3 shadow-lg">
            <div className="flex justify-between items-center border-b border-[#183338] pb-2">
              <h3 className="font-cinzel text-sm font-bold text-[#F3F7F6] uppercase">
                STRATEGY PAYOFF DIAGRAM AT EXPIRATION
              </h3>
              <span className="text-xs font-mono-numbers text-[#C5A059]">
                SPOT: &pound;{spotPrice.toFixed(2)}
              </span>
            </div>

            <div className="h-72 w-full bg-[#071114] rounded border border-[#142629] relative p-3">
              <svg viewBox="0 0 700 240" className="w-full h-full">
                {/* Zero Line */}
                <line x1="40" y1="120" x2="680" y2="120" stroke="#23474F" strokeWidth="1.5" />
                <text x="5" y="123" fill="#8EA7A8" fontSize="9" fontFamily="JetBrains Mono">&pound;0</text>

                {/* Vertical Spot Line */}
                <line x1="390" y1="20" x2="390" y2="210" stroke="#C5A059" strokeWidth="1" strokeDasharray="3 3" />
                <text x="390" y="15" fill="#C5A059" fontSize="9" fontFamily="JetBrains Mono" textAnchor="middle">SPOT &pound;185.25</text>

                {/* Payoff Curve */}
                <polyline
                  fill="none"
                  stroke="#10B981"
                  strokeWidth="3"
                  points={payoffPoints.map((pt, idx) => {
                    const x = 50 + (idx / (payoffPoints.length - 1)) * 620;
                    const y = 120 - (pt.pnl / 40000) * 80;
                    return `${x},${Math.max(20, Math.min(220, y))}`;
                  }).join(' ')}
                />
              </svg>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
