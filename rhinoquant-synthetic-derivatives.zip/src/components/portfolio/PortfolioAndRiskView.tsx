/**
 * RhinoQuant Portfolio & Factor Risk View
 */

import React from 'react';
import { PortfolioSummary } from '../../types';
import { Briefcase, Layers, AlertCircle } from 'lucide-react';

interface PortfolioAndRiskViewProps {
  portfolioSummary: PortfolioSummary;
}

export const PortfolioAndRiskView: React.FC<PortfolioAndRiskViewProps> = ({ portfolioSummary }) => {
  const {
    totalNotional,
    totalMarketValue,
    totalUnrealizedPnL,
    consolidatedGreeks,
    factorExposures,
    positions,
  } = portfolioSummary;

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Portfolio Header Metrics */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide mb-4 flex items-center space-x-2">
          <Briefcase className="w-4 h-4 text-amber-400" />
          <span>CONSOLIDATED PORTFOLIO RISK & FACTOR DECOMPOSITION</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">TOTAL NOTIONAL</span>
            <strong className="text-xl font-bold text-slate-100">${totalNotional.toLocaleString()}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">MARKET VALUE</span>
            <strong className="text-xl font-bold text-amber-400">${totalMarketValue.toLocaleString()}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">UNREALIZED P&L</span>
            <strong className="text-xl font-bold text-emerald-400">+${totalUnrealizedPnL.toLocaleString()}</strong>
          </div>
        </div>

        {/* Factor Risk Breakdown */}
        <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-3">
          <h3 className="font-bold text-slate-200 border-b border-slate-800 pb-2">
            FACTOR RISK MAPPING (COMMODITY, ENERGY, FREIGHT, VOLATILITY)
          </h3>
          <div className="space-y-2">
            {factorExposures.map(factor => (
              <div key={factor.factorName} className="space-y-1">
                <div className="flex justify-between text-slate-300 text-[11px]">
                  <span>{factor.factorName} ({factor.assetClass})</span>
                  <span className="font-bold text-amber-400">{factor.percentageOfRisk}% (${(factor.exposureValue / 1_000_000).toFixed(1)}M)</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-500 to-cyan-400 h-full transition-all"
                    style={{ width: `${factor.percentageOfRisk}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Position Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="font-bold text-slate-200 text-xs mb-3 uppercase tracking-wide">
          ACTIVE PORTFOLIO POSITIONS
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="p-2">INSTRUMENT CODE</th>
                <th className="p-2">NAME</th>
                <th className="p-2 text-right">QTY</th>
                <th className="p-2 text-right">CURRENT VALUE</th>
                <th className="p-2 text-right">UNREALIZED P&L</th>
              </tr>
            </thead>
            <tbody>
              {positions.map((pos, idx) => (
                <tr key={idx} className="border-b border-slate-800/40">
                  <td className="p-2 font-bold text-amber-400">{pos.derivative.code}</td>
                  <td className="p-2 text-slate-200">{pos.derivative.name}</td>
                  <td className="p-2 text-right text-slate-300">{pos.quantity}x</td>
                  <td className="p-2 text-right text-slate-100 font-bold">${pos.currentValue.toLocaleString()}</td>
                  <td className="p-2 text-right text-emerald-400 font-bold">+${pos.unrealizedPnL.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
