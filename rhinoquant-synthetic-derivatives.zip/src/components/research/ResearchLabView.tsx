/**
 * RhinoQuant Research Lab - Model Validation & Comparative Benchmark Suite
 */

import React from 'react';
import { SIGNATURE_DERIVATIVES } from '../../data/seedData';
import { runModelComparisonSuite } from '../../engine/research/modelValidation';
import { FlaskConical, Cpu, CheckCircle } from 'lucide-react';

export const ResearchLabView: React.FC = () => {
  const activeDerivative = SIGNATURE_DERIVATIVES[0];
  const comparisonRows = runModelComparisonSuite(activeDerivative);

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide flex items-center space-x-2">
              <FlaskConical className="w-4 h-4 text-amber-400" />
              <span>QUANTITATIVE RESEARCH LAB — MODEL COMPARISON BENCHMARK</span>
            </h2>
            <p className="text-slate-400 font-sans text-xs">
              Compare Black-Scholes vs Cox-Ross-Rubinstein Binomial Tree vs Heston Stochastic Volatility vs Quasi-Monte Carlo vs Surrogate Neural Approximation.
            </p>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-3">MODEL NAME</th>
                <th className="p-3">CATEGORY</th>
                <th className="p-3 text-right">VALUATION PRICE</th>
                <th className="p-3 text-right">DELTA (Δ)</th>
                <th className="p-3 text-right">VEGA (ν)</th>
                <th className="p-3 text-right">RUNTIME (MS)</th>
                <th className="p-3">NUMERICAL ERROR / STATS</th>
              </tr>
            </thead>
            <tbody>
              {comparisonRows.map((row, idx) => (
                <tr key={idx} className="border-b border-slate-800/40 hover:bg-slate-800/30">
                  <td className="p-3 font-bold text-slate-100">{row.modelName}</td>
                  <td className="p-3 text-slate-400">{row.category}</td>
                  <td className="p-3 text-right font-bold text-amber-400">${row.price.toLocaleString()}</td>
                  <td className="p-3 text-right text-slate-200">{row.delta}</td>
                  <td className="p-3 text-right text-cyan-400">${row.vega.toLocaleString()}</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">{row.runtimeMs} ms</td>
                  <td className="p-3 text-slate-300 text-[11px]">{row.numericalError}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Model Assumptions Overview */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="font-bold text-slate-200 text-xs mb-3 uppercase tracking-wide">
          MODEL VALIDATION ASSUMPTIONS & BENCHMARKS
        </h3>
        <div className="space-y-3 font-sans text-slate-300">
          {comparisonRows.map((row, idx) => (
            <div key={idx} className="p-3 bg-slate-950 rounded border border-slate-800">
              <div className="font-mono font-bold text-amber-400 text-xs mb-1">{row.modelName}</div>
              <p className="text-xs text-slate-400">{row.assumptions}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
