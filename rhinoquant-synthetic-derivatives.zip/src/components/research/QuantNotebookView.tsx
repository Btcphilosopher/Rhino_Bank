/**
 * RhinoQuant Quantitative Research Notebook REPL Terminal
 */

import React, { useState } from 'react';
import { QuantNotebookInterpreter, NotebookOutput } from '../../engine/research/notebookEngine';
import { Terminal, Play, RotateCcw } from 'lucide-react';

export const QuantNotebookView: React.FC = () => {
  const [commandInput, setCommandInput] = useState('rq.price("RQ-SYN-001")');
  const [history, setHistory] = useState<NotebookOutput[]>([
    {
      command: 'rq.load_market("industrial_2027")',
      timestamp: '00:01:12',
      status: 'SUCCESS',
      resultText: 'Loaded Synthetic Market Snapshot "INDUSTRIAL_2027_V1" (Seed: 20260926)\nSpot Assets: COPPER ($9,850), ALUMINIUM ($2,450), NICKEL ($17,200), STEEL ($780)',
    },
  ]);

  const interpreter = new QuantNotebookInterpreter();

  const handleRun = () => {
    if (!commandInput.trim()) return;
    const output = interpreter.executeCommand(commandInput);
    setHistory([output, ...history]);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              <span>QUANTITATIVE RESEARCH REPL NOTEBOOK (`rq` ENGINE)</span>
            </h2>
            <p className="text-slate-400 font-sans text-xs">
              Execute reproducible quantitative finance scripts (`rq.load_market`, `rq.build_curve`, `rq.create_synthetic`, `rq.price`, `rq.risk`, `rq.stress`).
            </p>
          </div>

          <button
            onClick={() => setHistory([])}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] flex items-center space-x-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>CLEAR TERMINAL</span>
          </button>
        </div>

        {/* Command Input Box */}
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRun()}
            placeholder='e.g. rq.price("RQ-SYN-001")'
            className="flex-1 bg-slate-950 border border-slate-800 rounded p-2.5 text-cyan-300 font-mono text-xs focus:outline-none focus:border-amber-500"
          />
          <button
            onClick={handleRun}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center space-x-1.5 transition"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>EXECUTE</span>
          </button>
        </div>

        {/* Execution Output History */}
        <div className="space-y-3 mt-4">
          {history.map((item, idx) => (
            <div key={idx} className="bg-slate-950 rounded border border-slate-800 p-3 space-y-1">
              <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/60 pb-1">
                <span className="text-amber-400 font-bold">&gt; {item.command}</span>
                <span>{item.timestamp}</span>
              </div>
              <pre className="text-slate-200 text-xs font-mono whitespace-pre-wrap leading-relaxed pt-1">
                {item.resultText}
              </pre>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
