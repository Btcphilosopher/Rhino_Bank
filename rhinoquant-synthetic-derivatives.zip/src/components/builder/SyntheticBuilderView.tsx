/**
 * RhinoQuant Synthetic Builder & Payoff Composer
 */

import React, { useState } from 'react';
import { SyntheticDerivative, PayoffType, MarketAsset } from '../../types';
import { DSLParser, validateAST } from '../../engine/payoff/ast';
import { PayoffChart } from '../visualization/PayoffChart';
import { Code, Cpu, Play } from 'lucide-react';

interface SyntheticBuilderViewProps {
  assets: MarketAsset[];
  onCreateDerivative: (deriv: SyntheticDerivative) => void;
}

export const SyntheticBuilderView: React.FC<SyntheticBuilderViewProps> = ({
  assets,
  onCreateDerivative,
}) => {
  const [code, setCode] = useState('RQ-SYN-NEW');
  const [name, setName] = useState('Custom Synthetic Payoff Derivative');
  const [notional, setNotional] = useState(10000000);
  const [selectedAssetId, setSelectedAssetId] = useState('COPPER');
  const [payoffType, setPayoffType] = useState<PayoffType>('CUSTOM_DSL');
  const [strike, setStrike] = useState(9850);
  const [barrier, setBarrier] = useState(12000);
  const [dslExpression, setDslExpression] = useState('max(S - K, 0) + if(S > B, 0.5 * (S - K), 0)');

  // DSL Validation state
  let dslError: string | null = null;
  let usedVariables: string[] = [];

  try {
    const parser = new DSLParser();
    const ast = parser.parse(dslExpression);
    const val = validateAST(ast);
    if (!val.isValid) {
      dslError = val.error || 'Invalid AST Expression';
    } else {
      usedVariables = val.variablesUsed;
    }
  } catch (err: any) {
    dslError = err.message;
  }

  const currentAsset = assets.find(a => a.id === selectedAssetId) || assets[0];

  const handleCompileAndBuild = () => {
    const newDeriv: SyntheticDerivative = {
      id: `RQ-SYN-${Date.now()}`,
      code,
      name,
      category: 'CUSTOM SYNTHETIC BUILD',
      currency: 'USD',
      notional,
      underlying: {
        id: `UND_${selectedAssetId}`,
        code: selectedAssetId,
        name: currentAsset.name,
        description: 'Custom Synthetic Underlying',
        weightingMethod: 'CUSTOM',
        baseCurrency: 'USD',
        components: [{ assetId: selectedAssetId, weight: 1.0 }],
      },
      payoff: {
        type: payoffType,
        strike,
        barrier,
        dslExpression,
      },
      schedule: {
        issueDate: new Date().toISOString().split('T')[0],
        valuationDate: new Date().toISOString().split('T')[0],
        maturityDate: '2027-12-20',
        timeToMaturityYears: 1.0,
        paymentFrequency: 'AT_MATURITY',
      },
      marketModel: 'GBM',
      pricingModel: 'MONTE_CARLO',
      discountCurveId: 'USD_SOFR_CURVE',
      volatilitySurfaceId: 'VOL_COPPER_2026',
      settlementType: 'CASH',
      status: 'ACTIVE',
      auditVersion: '2026.09.28-RQ3.6',
    };

    onCreateDerivative(newDeriv);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide mb-4 flex items-center space-x-2">
          <Cpu className="w-4 h-4 text-amber-400" />
          <span>SYNTHETIC INSTRUMENT DSL COMPOSER</span>
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Form Builder & DSL IDE */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">INSTRUMENT CODE</label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">NOTIONAL ($)</label>
                <input
                  type="number"
                  value={notional}
                  onChange={(e) => setNotional(parseFloat(e.target.value) || 1000000)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">DERIVATIVE NAME</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">UNDERLYING ASSET</label>
                <select
                  value={selectedAssetId}
                  onChange={(e) => setSelectedAssetId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
                >
                  {assets.map(a => (
                    <option key={a.id} value={a.id}>{a.name} (${a.spotPrice})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">PAYOFF TYPE</label>
                <select
                  value={payoffType}
                  onChange={(e) => setPayoffType(e.target.value as PayoffType)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
                >
                  <option value="CUSTOM_DSL">SAFE AST DSL EXPRESSION</option>
                  <option value="VANILLA_CALL">VANILLA CALL OPTION</option>
                  <option value="VANILLA_PUT">VANILLA PUT OPTION</option>
                  <option value="BARRIER_KNOCK_OUT">BARRIER KNOCK-OUT</option>
                  <option value="ASIAN_ARITHMETIC">ASIAN ARITHMETIC</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">STRIKE (K)</label>
                <input
                  type="number"
                  value={strike}
                  onChange={(e) => setStrike(parseFloat(e.target.value) || 100)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">BARRIER LEVEL (B)</label>
                <input
                  type="number"
                  value={barrier}
                  onChange={(e) => setBarrier(parseFloat(e.target.value) || 120)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
                />
              </div>
            </div>

            {/* Payoff DSL IDE */}
            <div>
              <label className="text-slate-400 block mb-1 flex items-center justify-between">
                <span>PAYOFF AST EXPRESSION DSL</span>
                <Code className="w-3.5 h-3.5 text-amber-400" />
              </label>
              <textarea
                value={dslExpression}
                onChange={(e) => setDslExpression(e.target.value)}
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 font-mono text-cyan-300 text-xs focus:outline-none focus:border-amber-500"
              />

              {dslError ? (
                <div className="mt-1 p-2 bg-red-950/80 border border-red-500/50 rounded text-red-300 text-[11px]">
                  <strong>AST PARSE ERROR:</strong> {dslError}
                </div>
              ) : (
                <div className="mt-1 p-2 bg-emerald-950/50 border border-emerald-500/30 rounded text-emerald-300 text-[11px]">
                  <strong>AST VALIDATED:</strong> Variables Identified: [{usedVariables.join(', ')}]
                </div>
              )}
            </div>

            <button
              onClick={handleCompileAndBuild}
              disabled={!!dslError}
              className={`w-full py-2.5 rounded font-bold text-xs flex items-center justify-center space-x-2 transition ${
                dslError
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md'
              }`}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>COMPILE & REGISTER SYNTHETIC INSTRUMENT</span>
            </button>
          </div>

          {/* Right Column: Live Payoff Graph Preview */}
          <div>
            <PayoffChart
              payoff={{ type: payoffType, strike, barrier, dslExpression }}
              currentSpot={currentAsset.spotPrice}
              strike={strike}
              barrier={barrier}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
