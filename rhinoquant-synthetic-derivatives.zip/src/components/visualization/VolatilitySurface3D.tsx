/**
 * RhinoQuant Volatility Surface 3D / Contour Visualization
 */

import React, { useState } from 'react';
import { VolatilitySurfaceData } from '../../types';

interface VolatilitySurface3DProps {
  volSurface: VolatilitySurfaceData;
}

export const VolatilitySurface3D: React.FC<VolatilitySurface3DProps> = ({ volSurface }) => {
  const [viewMode, setViewMode] = useState<'CONTOUR' | 'SURFACE_GRID'>('CONTOUR');

  const { expiries, strikes, matrix } = volSurface;

  // Find min and max vol for color scaling
  let minVol = 1.0;
  let maxVol = 0.0;
  matrix.forEach(row => {
    row.forEach(v => {
      if (v < minVol) minVol = v;
      if (v > maxVol) maxVol = v;
    });
  });

  const getVolColor = (vol: number) => {
    // Restrained color ramp: Steel blue (low vol) to Muted Amber (high vol)
    const norm = (vol - minVol) / (maxVol - minVol || 1);
    if (norm < 0.33) {
      return `rgb(30, 58, 138)`; // Dark Navy
    } else if (norm < 0.66) {
      return `rgb(14, 116, 144)`; // Cyan Steel
    } else {
      return `rgb(217, 119, 6)`; // Amber
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
      <div className="flex items-center justify-between mb-3">
        <div>
          <span className="font-semibold text-amber-400 uppercase tracking-wide">
            VOLATILITY SURFACE (EXPIRY × STRIKE)
          </span>
          <p className="text-[11px] text-slate-400 font-sans">
            Implied Volatility Term Structure & Skew Surface
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setViewMode('CONTOUR')}
            className={`px-2.5 py-1 rounded text-[11px] font-mono ${
              viewMode === 'CONTOUR' ? 'bg-slate-700 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-400'
            }`}
          >
            CONTOUR MATRIX
          </button>
          <button
            onClick={() => setViewMode('SURFACE_GRID')}
            className={`px-2.5 py-1 rounded text-[11px] font-mono ${
              viewMode === 'SURFACE_GRID' ? 'bg-slate-700 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-400'
            }`}
          >
            SABR SKEW GRID
          </button>
        </div>
      </div>

      {viewMode === 'CONTOUR' ? (
        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="p-2 text-left bg-slate-950/50 font-normal">Expiry \ Strike</th>
                {strikes.map(k => (
                  <th key={k} className="p-2 font-normal bg-slate-950/50">${k}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {expiries.map((exp, rowIdx) => (
                <tr key={exp} className="border-b border-slate-800/50">
                  <td className="p-2 text-left text-slate-300 bg-slate-950/30 font-medium">
                    {exp}Y ({Math.round(exp * 12)}M)
                  </td>
                  {strikes.map((_k, colIdx) => {
                    const volVal = matrix[rowIdx]?.[colIdx] ?? 0.20;
                    return (
                      <td
                        key={colIdx}
                        className="p-2 text-slate-100 transition hover:scale-105"
                        style={{ backgroundColor: getVolColor(volVal) }}
                      >
                        {(volVal * 100).toFixed(1)}%
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="p-4 bg-slate-950 rounded border border-slate-800 space-y-3">
          <div className="text-slate-300 text-[11px]">SABR Parameterization Fit (Hagan et al.):</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">ALPHA (α)</span>
              <strong className="text-amber-400">{volSurface.sabrParams?.alpha ?? 0.22}</strong>
            </div>
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">BETA (β)</span>
              <strong className="text-slate-200">{volSurface.sabrParams?.beta ?? 0.50}</strong>
            </div>
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">RHO (ρ)</span>
              <strong className="text-cyan-400">{volSurface.sabrParams?.rho ?? -0.35}</strong>
            </div>
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">NU (ν)</span>
              <strong className="text-emerald-400">{volSurface.sabrParams?.nu ?? 0.48}</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
