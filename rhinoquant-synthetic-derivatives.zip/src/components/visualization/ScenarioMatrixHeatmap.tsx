/**
 * RhinoQuant Risk Scenario Matrix Heatmap (Spot x Volatility)
 */

import React from 'react';

interface ScenarioMatrixHeatmapProps {
  grid: number[][];
  spotShifts: number[];
  volShifts: number[];
}

export const ScenarioMatrixHeatmap: React.FC<ScenarioMatrixHeatmapProps> = ({
  grid,
  spotShifts,
  volShifts,
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
      <div className="flex items-center justify-between mb-3">
        <span className="font-semibold text-amber-400 uppercase tracking-wide">
          2D SCENARIO RISK MATRIX (SPOT × VOLATILITY SHIFT P&L)
        </span>
        <div className="flex items-center space-x-3 text-[11px] text-slate-400">
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-emerald-900 border border-emerald-500 inline-block"></span>
            <span>Gain</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-red-950 border border-red-500 inline-block"></span>
            <span>Loss</span>
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-center border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="p-2 text-left bg-slate-950 font-normal">Vol \ Spot</th>
              {spotShifts.map(s => (
                <th key={s} className="p-2 font-normal bg-slate-950">
                  {s > 0 ? `+${(s * 100).toFixed(0)}%` : `${(s * 100).toFixed(0)}%`}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {volShifts.map((v, rowIdx) => (
              <tr key={v} className="border-b border-slate-800/40">
                <td className="p-2 text-left text-slate-300 bg-slate-950/60 font-medium">
                  Vol {v > 0 ? `+${(v * 100).toFixed(0)}%` : `${(v * 100).toFixed(0)}%`}
                </td>
                {spotShifts.map((_s, colIdx) => {
                  const pnl = grid[rowIdx]?.[colIdx] ?? 0;
                  const isPositive = pnl >= 0;
                  return (
                    <td
                      key={colIdx}
                      className={`p-2 font-mono font-medium border border-slate-800/50 ${
                        isPositive
                          ? 'bg-emerald-950/70 text-emerald-300'
                          : 'bg-red-950/70 text-red-300'
                      }`}
                    >
                      {pnl > 0 ? `+$${pnl.toLocaleString()}` : `-$${Math.abs(pnl).toLocaleString()}`}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
