/**
 * RhinoQuant Payoff Visualization Chart
 */

import React, { useState } from 'react';
import { PayoffDefinition } from '../../types';
import { evaluatePayoff } from '../../engine/payoff/primitives';

interface PayoffChartProps {
  payoff: PayoffDefinition;
  currentSpot: number;
  strike?: number;
  barrier?: number;
}

export const PayoffChart: React.FC<PayoffChartProps> = ({
  payoff,
  currentSpot,
  strike = 9850,
  barrier,
}) => {
  const [hoveredSpot, setHoveredSpot] = useState<number | null>(null);

  const minSpot = currentSpot * 0.6;
  const maxSpot = currentSpot * 1.4;
  const pointsCount = 100;

  const points: { spot: number; payout: number }[] = [];
  let maxPayout = 0;
  let minPayout = 0;

  for (let i = 0; i <= pointsCount; i++) {
    const spotVal = minSpot + (i / pointsCount) * (maxSpot - minSpot);
    const payoutVal = evaluatePayoff(payoff, spotVal, 1.0);
    points.push({ spot: spotVal, payout: payoutVal });
    if (payoutVal > maxPayout) maxPayout = payoutVal;
    if (payoutVal < minPayout) minPayout = payoutVal;
  }

  const padding = 40;
  const width = 650;
  const height = 280;

  const effectiveMaxPayout = Math.max(maxPayout, 1000);

  const getX = (spotVal: number) => {
    return padding + ((spotVal - minSpot) / (maxSpot - minSpot)) * (width - 2 * padding);
  };

  const getY = (payoutVal: number) => {
    return height - padding - ((payoutVal - minPayout) / (effectiveMaxPayout - minPayout || 1)) * (height - 2 * padding);
  };

  const pathD = points
    .map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(p.spot).toFixed(1)} ${getY(p.payout).toFixed(1)}`)
    .join(' ');

  const spotX = getX(currentSpot);
  const strikeX = getX(strike);
  const barrierX = barrier ? getX(barrier) : null;
  const zeroY = getY(0);

  const hoveredPoint = hoveredSpot !== null ? points.reduce((prev, curr) => Math.abs(curr.spot - hoveredSpot) < Math.abs(prev.spot - hoveredSpot) ? curr : prev) : null;

  return {
    render() {
      return (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
          <div className="flex items-center justify-between mb-3 text-slate-300">
            <span className="font-semibold tracking-wide text-amber-400 uppercase">
              PAYOFF PROFILE GRAPH
            </span>
            <div className="flex items-center space-x-4 text-[11px] text-slate-400">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-0.5 bg-cyan-400 inline-block"></span>
                <span>Payoff</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-amber-400 inline-block"></span>
                <span>Spot (${currentSpot.toLocaleString()})</span>
              </span>
            </div>
          </div>

          <div className="relative">
            <svg
              viewBox={`0 0 ${width} ${height}`}
              className="w-full h-auto bg-slate-950/70 rounded border border-slate-800/80 cursor-crosshair"
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const mouseX = e.clientX - rect.left;
                const spotVal = minSpot + ((mouseX - padding) / (width - 2 * padding)) * (maxSpot - minSpot);
                setHoveredSpot(Math.max(minSpot, Math.min(maxSpot, spotVal)));
              }}
              onMouseLeave={() => setHoveredSpot(null)}
            >
              {/* Zero Line */}
              <line
                x1={padding}
                y1={zeroY}
                x2={width - padding}
                y2={zeroY}
                stroke="#334155"
                strokeWidth="1"
                strokeDasharray="4 4"
              />

              {/* Current Spot Vertical Line */}
              <line
                x1={spotX}
                y1={padding}
                x2={spotX}
                y2={height - padding}
                stroke="#f59e0b"
                strokeWidth="1.5"
                strokeDasharray="2 2"
              />

              {/* Strike Vertical Line */}
              <line
                x1={strikeX}
                y1={padding}
                x2={strikeX}
                y2={height - padding}
                stroke="#64748b"
                strokeWidth="1"
              />

              {/* Barrier Line if exists */}
              {barrierX && (
                <line
                  x1={barrierX}
                  y1={padding}
                  x2={barrierX}
                  y2={height - padding}
                  stroke="#ef4444"
                  strokeWidth="1.5"
                  strokeDasharray="3 3"
                />
              )}

              {/* Payoff Curve Path */}
              <path d={pathD} fill="none" stroke="#22d3ee" strokeWidth="2.5" />

              {/* Spot Marker */}
              <circle cx={spotX} cy={getY(evaluatePayoff(payoff, currentSpot, 1.0))} r="4" fill="#f59e0b" />

              {/* Hover Cursor Line */}
              {hoveredPoint && (
                <g>
                  <line
                    x1={getX(hoveredPoint.spot)}
                    y1={padding}
                    x2={getX(hoveredPoint.spot)}
                    y2={height - padding}
                    stroke="#94a3b8"
                    strokeWidth="1"
                  />
                  <circle cx={getX(hoveredPoint.spot)} cy={getY(hoveredPoint.payout)} r="5" fill="#38bdf8" />
                </g>
              )}

              {/* Axis Labels */}
              <text x={padding} y={height - 10} fill="#64748b" fontSize="10">
                ${minSpot.toFixed(0)}
              </text>
              <text x={width - padding - 40} y={height - 10} fill="#64748b" fontSize="10">
                ${maxSpot.toFixed(0)}
              </text>
              <text x={strikeX - 15} y={padding + 15} fill="#94a3b8" fontSize="10">
                K=${strike}
              </text>
              {barrier && (
                <text x={barrierX! - 15} y={padding + 30} fill="#ef4444" fontSize="10">
                  B=${barrier}
                </text>
              )}
            </svg>

            {/* Hover Tooltip Overlay */}
            {hoveredPoint && (
              <div className="absolute top-3 right-3 bg-slate-800/90 border border-slate-700 px-3 py-1.5 rounded shadow text-slate-200 text-[11px] font-mono">
                <div>Spot State: <strong>${hoveredPoint.spot.toFixed(2)}</strong></div>
                <div>Payout Value: <strong className="text-cyan-400">${hoveredPoint.payout.toFixed(2)}</strong></div>
              </div>
            )}
          </div>
        </div>
      );
    }
  }.render();
};
