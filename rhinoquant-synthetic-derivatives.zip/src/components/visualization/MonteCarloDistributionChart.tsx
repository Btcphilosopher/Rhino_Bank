/**
 * RhinoQuant Monte Carlo P&L Distribution Chart
 */

import React from 'react';
import { MonteCarloResult } from '../../types';

interface MonteCarloDistributionChartProps {
  details: MonteCarloResult;
}

export const MonteCarloDistributionChart: React.FC<MonteCarloDistributionChartProps> = ({ details }) => {
  const { paths, price, standardError, confidenceInterval95, distribution, executionTimeMs } = details;

  const maxCount = Math.max(...distribution.histogramBins.map(b => b.count), 1);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <span className="font-semibold text-amber-400 uppercase tracking-wide">
            MONTE CARLO P&L DISTRIBUTION ({paths.toLocaleString()} PATHS)
          </span>
          <p className="text-[11px] text-slate-400 font-sans">
            Quasi-Random Sobol Simulation • Execution Time: {executionTimeMs} ms
          </p>
        </div>

        <div className="text-right">
          <span className="text-slate-400 block text-[10px]">VALUATION PRICE</span>
          <strong className="text-emerald-400 text-sm">${price.toLocaleString()}</strong>
        </div>
      </div>

      {/* Numerical Metrics Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
        <div className="p-2 bg-slate-950 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">95% CONFIDENCE INTERVAL</span>
          <strong className="text-slate-200">${confidenceInterval95[0].toLocaleString()} – ${confidenceInterval95[1].toLocaleString()}</strong>
        </div>
        <div className="p-2 bg-slate-950 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">STANDARD ERROR</span>
          <strong className="text-amber-400">±${standardError.toLocaleString()}</strong>
        </div>
        <div className="p-2 bg-slate-950 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">VALUE AT RISK (95% VaR)</span>
          <strong className="text-red-400">${distribution.var95.toLocaleString()}</strong>
        </div>
        <div className="p-2 bg-slate-950 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">EXPECTED SHORTFALL (95% ES)</span>
          <strong className="text-red-400">${distribution.expectedShortfall95.toLocaleString()}</strong>
        </div>
      </div>

      {/* Histogram SVG */}
      <div className="bg-slate-950 p-3 rounded border border-slate-800">
        <div className="text-[10px] text-slate-400 mb-2 flex items-center justify-between">
          <span>Histogram Frequency</span>
          <span>Payoff Outome ($)</span>
        </div>

        <div className="flex items-end space-x-1 h-36 pt-2">
          {distribution.histogramBins.map((b, idx) => {
            const heightPercent = (b.count / maxCount) * 100;
            const isTail = b.bin <= distribution.var95;
            return (
              <div
                key={idx}
                className="flex-1 group relative flex flex-col items-center h-full justify-end"
              >
                <div
                  className={`w-full rounded-t transition-all ${
                    isTail ? 'bg-red-500/80 hover:bg-red-400' : 'bg-cyan-600/70 hover:bg-cyan-400'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                ></div>

                {/* Tooltip */}
                <div className="absolute bottom-full mb-1 hidden group-hover:block bg-slate-800 text-slate-100 text-[10px] p-1.5 rounded border border-slate-700 z-10 whitespace-nowrap">
                  Bin: ${b.bin} | Count: {b.count}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
