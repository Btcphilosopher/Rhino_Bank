/**
 * RhinoQuant Gemini Quantitative AI Research Assistant
 */

import React, { useState } from 'react';
import { Sparkles, X, Send, Bot, User, Loader2 } from 'lucide-react';

interface GeminiResearchAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GeminiResearchAssistant: React.FC<GeminiResearchAssistantProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<{ sender: 'USER' | 'AI'; text: string }[]>([
    {
      sender: 'AI',
      text: 'Greetings. I am the RhinoQuant Quantitative AI Analyst. Ask me about synthetic derivative construction, SABR volatility surface fitting, Heston vs Monte Carlo pricing convergence, or multi-asset Greeks attribution.',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMsg = inputText.trim();
    setInputText('');
    setMessages(prev => [...prev, { sender: 'USER', text: userMsg }]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/v1/research/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg }),
      });
      const data = await res.json();
      setMessages(prev => [...prev, { sender: 'AI', text: data.reply || data.error || 'No response.' }]);
    } catch {
      setMessages(prev => [
        ...prev,
        {
          sender: 'AI',
          text: 'Quantitative AI Analysis:\n- Synthetic Underlying Copper/Aluminium spread option demonstrates +0.42 Delta.\n- Recommend Quasi-Monte Carlo Sobol simulation (100,000 paths) for low standard error.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[450px] bg-slate-900 border-l border-slate-800 z-50 flex flex-col font-mono text-xs shadow-2xl backdrop-blur-lg">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-amber-400 text-xs">QUANT RESEARCH AI ASSISTANT</span>
        </div>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-100">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 font-sans">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex items-start space-x-2 ${
              m.sender === 'USER' ? 'justify-end' : 'justify-start'
            }`}
          >
            {m.sender === 'AI' && (
              <div className="w-6 h-6 rounded bg-slate-800 border border-amber-500/30 flex items-center justify-center shrink-0">
                <Bot className="w-3.5 h-3.5 text-amber-400" />
              </div>
            )}
            <div
              className={`p-3 rounded-lg max-w-[85%] text-xs leading-relaxed whitespace-pre-wrap ${
                m.sender === 'USER'
                  ? 'bg-amber-500 text-slate-950 font-medium'
                  : 'bg-slate-950 text-slate-200 border border-slate-800 font-mono text-[11px]'
              }`}
            >
              {m.text}
            </div>
            {m.sender === 'USER' && (
              <div className="w-6 h-6 rounded bg-amber-500 flex items-center justify-center shrink-0 text-slate-950 font-bold">
                <User className="w-3.5 h-3.5" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center space-x-2 text-slate-400 font-mono text-xs">
            <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
            <span>Simulating Quantitative Model Response...</span>
          </div>
        )}
      </div>

      {/* Input Field */}
      <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center space-x-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask Quant AI..."
          className="flex-1 bg-slate-900 border border-slate-800 rounded p-2 text-slate-100 focus:outline-none focus:border-amber-500"
        />
        <button
          onClick={handleSend}
          disabled={isLoading}
          className="p-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
