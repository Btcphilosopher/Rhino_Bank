/**
 * RhinoQuant Terminal Dashboard
 */

import React from 'react';
import { MarketAsset, SyntheticDerivative, PortfolioSummary } from '../../types';
import { ArrowUpRight, ArrowDownRight, Layers, ShieldCheck, Zap, Activity } from 'lucide-react';

interface DashboardViewProps {
  assets: MarketAsset[];
  derivatives: SyntheticDerivative[];
  portfolioSummary: PortfolioSummary;
  onSelectDerivative: (derivative: SyntheticDerivative) => void;
  setActiveTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  assets,
  derivatives,
  portfolioSummary,
  onSelectDerivative,
  setActiveTab,
}) => {
  return (
    <div className="space-y-6">
      {/* Top Banner Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
          <div className="text-slate-400 font-mono text-xs mb-1">TOTAL NOTIONAL RISK</div>
          <div className="text-2xl font-mono font-bold text-slate-100">
            ${(portfolioSummary.totalNotional / 1_000_000).toFixed(1)}M
          </div>
          <div className="text-[11px] text-emerald-400 mt-1 font-mono flex items-center space-x-1">
            <ArrowUpRight className="w-3 h-3" />
            <span>Active Institutional Exposure</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
          <div className="text-slate-400 font-mono text-xs mb-1">PORTFOLIO MARKET VALUE</div>
          <div className="text-2xl font-mono font-bold text-amber-400">
            ${(portfolioSummary.totalMarketValue / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-[11px] text-emerald-400 mt-1 font-mono">
            Unrealized P&L: +${(portfolioSummary.totalUnrealizedPnL / 1_000).toFixed(0)}k
          </div>
        </div>

        <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
          <div className="text-slate-400 font-mono text-xs mb-1">AGGREGATED DELTA / VEGA</div>
          <div className="text-xl font-mono font-bold text-slate-100">
            Δ {portfolioSummary.consolidatedGreeks.delta} | ν ${Math.round(portfolioSummary.consolidatedGreeks.vega / 1000)}k
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Theta: -${Math.abs(portfolioSummary.consolidatedGreeks.theta).toLocaleString()}/day
          </div>
        </div>

        <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
          <div className="text-slate-400 font-mono text-xs mb-1">VALUE AT RISK (95% VaR)</div>
          <div className="text-2xl font-mono font-bold text-red-400">
            ${(portfolioSummary.var95 / 1_000).toFixed(0)}k
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Expected Shortfall: ${(portfolioSummary.expectedShortfall95 / 1_000).toFixed(0)}k
          </div>
        </div>
      </div>

      {/* Main Grid: Synthetic Instruments Terminal Table & Market Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Synthetic Instruments Terminal List (2 Columns) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide">
                ACTIVE SYNTHETIC DERIVATIVES
              </h2>
              <p className="text-xs text-slate-400 font-sans">
                Constructed Synthetic Instruments & Live Valuation Runs
              </p>
            </div>

            <button
              onClick={() => setActiveTab('SYNTHETIC_BUILDER')}
              className="px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition"
            >
              + CONSTRUCT SYNTHETIC
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="p-2">ID</th>
                  <th className="p-2">NAME</th>
                  <th className="p-2">UNDERLYING</th>
                  <th className="p-2">MODEL</th>
                  <th className="p-2 text-right">NOTIONAL</th>
                  <th className="p-2 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody>
                {derivatives.map(deriv => (
                  <tr
                    key={deriv.id}
                    className="border-b border-slate-800/50 hover:bg-slate-800/40 transition cursor-pointer"
                    onClick={() => onSelectDerivative(deriv)}
                  >
                    <td className="p-2 font-bold text-amber-400">{deriv.code}</td>
                    <td className="p-2 text-slate-100 font-medium">{deriv.name}</td>
                    <td className="p-2 text-slate-300">{deriv.underlying.name}</td>
                    <td className="p-2 text-slate-400">{deriv.pricingModel}</td>
                    <td className="p-2 text-right text-slate-200">
                      ${(deriv.notional / 1_000_000).toFixed(1)}M
                    </td>
                    <td className="p-2 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectDerivative(deriv);
                          setActiveTab('PRICING_ANALYTICS');
                        }}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 rounded text-[11px]"
                      >
                        ANALYSE
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Spot Asset Overview */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
              UNDERLYING MARKET ASSETS
            </h2>
            <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
          </div>

          <div className="space-y-3">
            {assets.map(asset => (
              <div
                key={asset.id}
                className="p-2.5 bg-slate-950/80 rounded border border-slate-800/80 flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-200">{asset.name}</div>
                  <div className="text-[10px] text-slate-400">{asset.symbol} • Vol: {(asset.historicalVol * 100).toFixed(0)}%</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-amber-400">
                    ${asset.spotPrice.toLocaleString()} {asset.unit}
                  </div>
                  <div className="text-[10px] text-emerald-400">
                    +{ (asset.drift * 100).toFixed(1) }% Annual
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
