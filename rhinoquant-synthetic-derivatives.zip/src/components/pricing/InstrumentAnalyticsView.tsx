/**
 * RhinoQuant Instrument Deep Analytics & Pricing Terminal Page
 */

import React, { useState } from 'react';
import { SyntheticDerivative, PricingModelType, MonteCarloResult, Greeks } from '../../types';
import { runMonteCarloSimulation } from '../../engine/pricing/monteCarlo';
import { priceBlackScholes } from '../../engine/pricing/blackScholes';
import { priceHeston } from '../../engine/pricing/stochasticVol';
import { priceBinomialTree } from '../../engine/pricing/treeModels';
import { runSurrogatePricer } from '../../engine/pricing/surrogatePricer';
import { PayoffChart } from '../visualization/PayoffChart';
import { MonteCarloDistributionChart } from '../visualization/MonteCarloDistributionChart';
import { ShieldCheck, Play, Cpu, Info } from 'lucide-react';

interface InstrumentAnalyticsViewProps {
  derivative: SyntheticDerivative;
  spotPrice?: number;
}

export const InstrumentAnalyticsView: React.FC<InstrumentAnalyticsViewProps> = ({
  derivative,
  spotPrice = 9850,
}) => {
  const [selectedModel, setSelectedModel] = useState<PricingModelType>(derivative.pricingModel);
  const [paths, setPaths] = useState(100000);
  const [showAuditModal, setShowAuditModal] = useState(false);

  // Compute live valuation based on model selection
  let price = 0;
  let greeks: Greeks;
  let mcDetails: MonteCarloResult | undefined;
  let isSurrogate = false;
  let surrogateRMSE = 0;

  if (selectedModel === 'MONTE_CARLO') {
    const mc = runMonteCarloSimulation(derivative, spotPrice, 0.24, 0.0425, paths, 52, 20260926);
    price = mc.price;
    greeks = mc.greeks;
    mcDetails = mc.details;
  } else if (selectedModel === 'ANALYTICAL') {
    const bs = priceBlackScholes(spotPrice, derivative.payoff.strike ?? spotPrice, 1.22, 0.0425, 0.24, true);
    price = parseFloat((bs.price * (derivative.notional / spotPrice)).toFixed(2));
    greeks = bs;
  } else if (selectedModel === 'BINOMIAL_TREE') {
    const tree = priceBinomialTree(spotPrice, derivative.payoff.strike ?? spotPrice, 1.22, 0.0425, 0.24, 200, true);
    price = parseFloat((tree.price * (derivative.notional / spotPrice)).toFixed(2));
    greeks = tree;
  } else if (selectedModel === 'SURROGATE') {
    const surr = runSurrogatePricer(derivative, spotPrice, 0.24, 0.0425);
    price = surr.price;
    greeks = surr.greeks;
    isSurrogate = true;
    surrogateRMSE = surr.rmse;
  } else {
    const mc = runMonteCarloSimulation(derivative, spotPrice, 0.24, 0.0425, 50000, 52, 20260926);
    price = mc.price;
    greeks = mc.greeks;
    mcDetails = mc.details;
  }

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner: Instrument Code & Primary Metrics */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 mb-4 gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-amber-400 text-lg">{derivative.code}</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] border border-slate-700">
                {derivative.category}
              </span>
              {isSurrogate && (
                <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 text-[10px] border border-purple-500/30">
                  SURROGATE MODEL (RMSE: {surrogateRMSE})
                </span>
              )}
            </div>
            <h1 className="text-base font-bold text-slate-100 font-sans mt-0.5">
              {derivative.name}
            </h1>
            <p className="text-slate-400 font-sans text-xs">
              Underlying: {derivative.underlying.name} • Notional: ${derivative.notional.toLocaleString()}
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowAuditModal(true)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>INSPECT AUDIT TRAIL</span>
            </button>
          </div>
        </div>

        {/* Greeks Dashboard Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-center">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">CURRENT VALUATION</span>
            <strong className="text-emerald-400 text-base">${price.toLocaleString()}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">DELTA (Δ)</span>
            <strong className="text-amber-400 text-base">{greeks.delta}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">GAMMA (Γ)</span>
            <strong className="text-slate-200 text-base">{greeks.gamma}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">VEGA (ν) / 1% VOL</span>
            <strong className="text-cyan-400 text-base">${greeks.vega.toLocaleString()}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">THETA (θ) / DAY</span>
            <strong className="text-red-400 text-base">-${Math.abs(greeks.theta).toLocaleString()}</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">RHO (ρ) / 100BP</span>
            <strong className="text-slate-300 text-base">${greeks.rho.toLocaleString()}</strong>
          </div>
        </div>
      </div>

      {/* Model Selector Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-bold">PRICING MODEL:</span>
          {(['MONTE_CARLO', 'ANALYTICAL', 'BINOMIAL_TREE', 'SURROGATE'] as PricingModelType[]).map(m => (
            <button
              key={m}
              onClick={() => setSelectedModel(m)}
              className={`px-3 py-1 rounded font-bold ${
                selectedModel === m
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {m.replace('_', ' ')}
            </button>
          ))}
        </div>

        {selectedModel === 'MONTE_CARLO' && (
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">PATHS:</span>
            <select
              value={paths}
              onChange={(e) => setPaths(parseInt(e.target.value))}
              className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-200"
            >
              <option value={10000}>10,000 Paths</option>
              <option value={50000}>50,000 Paths</option>
              <option value={100000}>100,000 Paths</option>
              <option value={250000}>250,000 Paths</option>
            </select>
          </div>
        )}
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PayoffChart
          payoff={derivative.payoff}
          currentSpot={spotPrice}
          strike={derivative.payoff.strike}
          barrier={derivative.payoff.barrier}
        />

        {mcDetails ? (
          <MonteCarloDistributionChart details={mcDetails} />
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-center text-slate-400">
            <div className="text-center space-y-2">
              <Info className="w-8 h-8 text-amber-400 mx-auto" />
              <p>Analytical Closed-Form Valuation Selected.</p>
              <p className="text-[10px]">Switch to MONTE_CARLO model to view path distributions.</p>
            </div>
          </div>
        )}
      </div>

      {/* Audit Modal */}
      {showAuditModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-xl w-full p-5 space-y-4 font-mono text-xs shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-bold text-amber-400 text-sm flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>VALUATION AUDIT SNAPSHOT</span>
              </span>
              <button
                onClick={() => setShowAuditModal(false)}
                className="text-slate-400 hover:text-slate-100 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-slate-300 font-mono bg-slate-950 p-3 rounded border border-slate-800">
              <div><strong>Valuation ID:</strong> VAL-20260928-8421-RQ</div>
              <div><strong>Timestamp:</strong> {new Date().toUTCString()}</div>
              <div><strong>Market Snapshot ID:</strong> INDUSTRIAL_2027_V1</div>
              <div><strong>Pricing Model:</strong> {selectedModel}</div>
              <div><strong>Discount Curve Version:</strong> USD_SOFR_CURVE_v2</div>
              <div><strong>Vol Surface Version:</strong> VOL_COPPER_2026_v1</div>
              <div><strong>Random Seed:</strong> 20260926 (Reproducibility Locked)</div>
              <div><strong>Engine Hash:</strong> sha256:8f41e0a291b...</div>
            </div>

            <button
              onClick={() => setShowAuditModal(false)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded"
            >
              CLOSE AUDIT SNAPSHOT
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
