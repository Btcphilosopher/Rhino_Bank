/**
 * RhinoQuant Markets & Curves View
 */

import React, { useState } from 'react';
import { MarketAsset, MarketCurve } from '../../types';
import { interpolateMonotonicCubic, interpolateLogLinear } from '../../engine/math/interpolation';

interface MarketsAndCurvesViewProps {
  assets: MarketAsset[];
  curves: MarketCurve[];
}

export const MarketsAndCurvesView: React.FC<MarketsAndCurvesViewProps> = ({ assets, curves }) => {
  const [selectedCurve, setSelectedCurve] = useState<MarketCurve>(curves[0]);

  // Compute curve visualization points
  const curvePoints = selectedCurve.points;
  const xs = curvePoints.map(p => p.days);
  const ys = curvePoints.map(p => p.rate);

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Curves Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide">
              INSTITUTIONAL CURVE & TERM STRUCTURE ENGINE
            </h2>
            <p className="text-slate-400 font-sans text-xs">
              Discount Curves, SOFR OIS, Zero Rates & Commodity Forward Backwardation Curves
            </p>
          </div>

          <div className="flex items-center space-x-2">
            {curves.map(c => (
              <button
                key={c.id}
                onClick={() => setSelectedCurve(c)}
                className={`px-3 py-1.5 rounded font-mono ${
                  selectedCurve.id === c.id
                    ? 'bg-slate-800 text-amber-300 border border-amber-500/30 font-bold'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Curve Table & Interpolation Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-950 p-4 rounded border border-slate-800">
            <h3 className="text-slate-200 font-bold mb-3 border-b border-slate-800 pb-2">
              CURVE TENOR POINTS ({selectedCurve.type})
            </h3>
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800">
                  <th className="p-2">TENOR</th>
                  <th className="p-2">DAYS</th>
                  <th className="p-2">RATE / LEVEL</th>
                  <th className="p-2 text-right">DISCOUNT FACTOR</th>
                </tr>
              </thead>
              <tbody>
                {selectedCurve.points.map(pt => (
                  <tr key={pt.tenor} className="border-b border-slate-800/40">
                    <td className="p-2 font-bold text-amber-400">{pt.tenor}</td>
                    <td className="p-2 text-slate-300">{pt.days}d</td>
                    <td className="p-2 text-slate-100 font-semibold">
                      {selectedCurve.type === 'COMMODITY_FORWARD'
                        ? `$${pt.rate.toLocaleString()}`
                        : `${(pt.rate * 100).toFixed(2)}%`}
                    </td>
                    <td className="p-2 text-right text-cyan-400 font-mono">
                      {pt.discountFactor.toFixed(4)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-3">
            <h3 className="text-slate-200 font-bold border-b border-slate-800 pb-2">
              INTERPOLATION METHODOLOGY
            </h3>
            <div className="space-y-2 text-slate-300 font-sans">
              <div>
                <strong>Interpolation Engine:</strong>{' '}
                <span className="font-mono text-amber-400">{selectedCurve.interpolation}</span>
              </div>
              <p className="text-slate-400 text-xs">
                Monotonic Cubic Spline guarantees smoothness without artificial oscillation between tenor pillars. Discount factors are reconstructed via log-linear continuous compounding $DF(t) = \exp(-r(t) \cdot t)$.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Spot Asset Catalog */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wide mb-4">
          PRIMARY UNDERLYING ASSET CATALOG
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {assets.map(asset => (
            <div key={asset.id} className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex items-center justify-between font-bold text-slate-100">
                <span>{asset.name}</span>
                <span className="text-amber-400">${asset.spotPrice.toLocaleString()}</span>
              </div>
              <div className="text-[11px] text-slate-400 flex justify-between">
                <span>Class: {asset.assetClass}</span>
                <span>Historical Vol: {(asset.historicalVol * 100).toFixed(1)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
