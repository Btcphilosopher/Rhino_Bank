/**
 * RhinoQuant Navigation Bar
 */

import React from 'react';
import {
  LayoutDashboard,
  Globe2,
  TrendingUp,
  Cpu,
  BarChart3,
  Briefcase,
  Zap,
  FlaskConical,
  Target,
  Terminal,
} from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'DASHBOARD', label: 'DASHBOARD', icon: LayoutDashboard },
    { id: 'MARKETS_CURVES', label: 'MARKETS & CURVES', icon: Globe2 },
    { id: 'VOL_CORRELATION', label: 'VOL & CORRELATION', icon: TrendingUp },
    { id: 'SYNTHETIC_BUILDER', label: 'SYNTHETIC BUILDER', icon: Cpu },
    { id: 'PRICING_ANALYTICS', label: 'PRICING & ANALYTICS', icon: BarChart3 },
    { id: 'PORTFOLIO_RISK', label: 'PORTFOLIO & RISK', icon: Briefcase },
    { id: 'STRESS_TESTING', label: 'STRESS & SCENARIOS', icon: Zap },
    { id: 'RESEARCH_LAB', label: 'RESEARCH & MODELS', icon: FlaskConical },
    { id: 'REVERSE_ENGINEERING', label: 'REVERSE SYNTHESIS', icon: Target },
    { id: 'QUANT_NOTEBOOK', label: 'QUANT NOTEBOOK', icon: Terminal },
  ];

  return (
    <nav className="bg-slate-900 border-b border-slate-800 px-4 overflow-x-auto scrollbar-none">
      <div className="max-w-7xl mx-auto flex items-center space-x-1 py-1 font-mono text-xs">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-3 py-2 rounded transition whitespace-nowrap font-medium ${
                isActive
                  ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
