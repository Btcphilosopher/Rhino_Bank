/**
 * RhinoQuant Header - Institutional Navigation Bar
 */

import React from 'react';
import { Activity, ShieldCheck, Database, Cpu, Sparkles, Sliders } from 'lucide-react';

interface InstitutionalHeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  toggleAiAssistant: () => void;
}

export const InstitutionalHeader: React.FC<InstitutionalHeaderProps> = ({
  activeTab,
  setActiveTab,
  toggleAiAssistant,
}) => {
  return (
    <header className="bg-slate-900/90 border-b border-slate-800 text-slate-200 sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Brand Badge */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('DASHBOARD')}>
          <div className="w-8 h-8 rounded bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 border border-slate-700 flex items-center justify-center font-mono font-bold text-amber-400 text-sm shadow-inner">
            RQ
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-mono font-bold tracking-tight text-white text-base">
                RHINOQUANT
              </span>
              <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-800 text-amber-400 font-mono border border-amber-500/20">
                SYNTHETICS
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-none">
              Institutional Derivative Laboratory
            </p>
          </div>
        </div>

        {/* Status Indicators */}
        <div className="hidden lg:flex items-center space-x-6 text-xs font-mono text-slate-400">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-slate-300">SEED: 20260926</span>
          </div>

          <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-4">
            <Cpu className="w-3.5 h-3.5 text-slate-400" />
            <span>ENGINE: <strong className="text-slate-200">v3.6-RQ</strong></span>
          </div>

          <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-4">
            <Database className="w-3.5 h-3.5 text-slate-400" />
            <span>SNAPSHOT: <strong className="text-slate-200">IMMUTABLE_2027</strong></span>
          </div>

          <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-4">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-amber-400 font-medium">AUDIT SIGNED</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={toggleAiAssistant}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-mono font-medium border border-amber-500/30 transition shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>QUANT AI ASSIST</span>
          </button>
        </div>
      </div>
    </header>
  );
};
