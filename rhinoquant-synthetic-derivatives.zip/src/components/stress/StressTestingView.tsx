/**
 * RhinoQuant Stress Testing & Scenario View
 */

import React, { useState } from 'react';
import { PRESET_STRESS_SCENARIOS, runStressTest, generateScenarioMatrixGrid } from '../../engine/stress/stressEngine';
import { priceBlackScholes } from '../../engine/pricing/blackScholes';
import { ScenarioMatrixHeatmap } from '../visualization/ScenarioMatrixHeatmap';
import { Zap, AlertTriangle } from 'lucide-react';

export const StressTestingView: React.FC = () => {
  const [selectedScenario, setSelectedScenario] = useState(PRESET_STRESS_SCENARIOS[0]);

  const baseBS = priceBlackScholes(9850, 9850, 1.0, 0.0425, 0.24, true);
  const basePrice = baseBS.price * 1000;
  const stressResult = runStressTest(basePrice, baseBS, selectedScenario);

  const scenarioGrid = generateScenarioMatrixGrid(basePrice, baseBS);

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Preset Macro Scenarios */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide flex items-center space-x-2">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>MACRO & HISTORICAL STRESS TESTING ENGINE</span>
            </h2>
            <p className="text-slate-400 font-sans text-xs">
              Simulate extreme market dislocations, volatility spikes, and correlation breakdowns.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {PRESET_STRESS_SCENARIOS.map(scen => (
            <button
              key={scen.id}
              onClick={() => setSelectedScenario(scen)}
              className={`p-3 rounded text-left border transition ${
                selectedScenario.id === scen.id
                  ? 'bg-slate-800 border-amber-500/50 shadow'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="font-bold text-slate-100 mb-1">{scen.name}</div>
              <div className="text-[10px] text-slate-400 font-sans">{scen.description}</div>
              <div className="mt-2 text-[10px] text-amber-400">
                Spot: {scen.spotShiftPercent}% | Vol: +{scen.volShiftPercent}%
              </div>
            </button>
          ))}
        </div>

        {/* Selected Scenario Impact Banner */}
        <div className="p-4 bg-slate-950 rounded border border-slate-800 grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
          <div>
            <span className="text-slate-400 block text-[10px]">BASE VALUATION</span>
            <strong className="text-slate-200 text-sm">${stressResult.baseValue.toLocaleString()}</strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">STRESSED VALUATION</span>
            <strong className="text-red-400 text-sm">${stressResult.stressedValue.toLocaleString()}</strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">STRESS P&L IMPACT</span>
            <strong className="text-red-400 text-sm">
              -${Math.abs(stressResult.pnlImpact).toLocaleString()} ({stressResult.percentageChange}%)
            </strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">STRESSED DELTA</span>
            <strong className="text-amber-400 text-sm">{stressResult.greeksImpact.delta}</strong>
          </div>
        </div>
      </div>

      {/* 2D Scenario Matrix Heatmap */}
      <ScenarioMatrixHeatmap
        grid={scenarioGrid.grid}
        spotShifts={scenarioGrid.spotShifts}
        volShifts={scenarioGrid.volShifts}
      />
    </div>
  );
};
