/**
 * RhinoQuant Reverse Engineering & Goal-Seeking Synthesizer
 */

import React, { useState } from 'react';
import { ReverseEngineeringTarget, ReverseEngineeringCandidate } from '../../types';
import { synthesizeDerivativeFromTarget } from '../../engine/synthesis/reverseEngineering';
import { Target, Cpu, Sparkles, Check } from 'lucide-react';

export const ReverseEngineeringView: React.FC = () => {
  const [maxDownside, setMaxDownside] = useState(2000000);
  const [desiredUpside, setDesiredUpside] = useState<'UNCAPPED' | 'CAPPED' | 'TARGET_PERCENT'>('UNCAPPED');
  const [maturity, setMaturity] = useState(2);
  const [primaryExposure, setPrimaryExposure] = useState('Industrial Growth (Copper + Power)');
  const [secondaryExposure, setSecondaryExposure] = useState('Volatility');

  const [candidates, setCandidates] = useState<ReverseEngineeringCandidate[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = () => {
    const target: ReverseEngineeringTarget = {
      targetPayoffType: 'CUSTOM_DSL',
      maxDownside,
      desiredUpside,
      targetMaturityYears: maturity,
      primaryExposure,
      secondaryExposure,
    };

    const results = synthesizeDerivativeFromTarget(target, 9850);
    setCandidates(results);
    setHasSearched(true);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide flex items-center space-x-2">
            <Target className="w-4 h-4 text-amber-400" />
            <span>GOAL-SEEKING REVERSE ENGINEERING & SYNTHESIS SOLVER</span>
          </h2>
          <p className="text-slate-400 font-sans text-xs">
            Specify desired payoff constraints (max downside, upside profile, factor exposures), and the engine will search its primitive library to construct candidate derivatives.
          </p>
        </div>

        {/* Input Constraints Form */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-slate-400 block mb-1">MAXIMUM DOWNSIDE ($)</label>
            <input
              type="number"
              value={maxDownside}
              onChange={(e) => setMaxDownside(parseFloat(e.target.value) || 1000000)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">DESIRED UPSIDE</label>
            <select
              value={desiredUpside}
              onChange={(e) => setDesiredUpside(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
            >
              <option value="UNCAPPED">UNCAPPED UPSIDE</option>
              <option value="CAPPED">CAPPED UPSIDE CAP</option>
              <option value="TARGET_PERCENT">TARGET 15% RETURN</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">MATURITY (YEARS)</label>
            <input
              type="number"
              value={maturity}
              onChange={(e) => setMaturity(parseFloat(e.target.value) || 1)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-bold"
            />
          </div>
        </div>

        <button
          onClick={handleSearch}
          className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition shadow flex items-center justify-center space-x-2"
        >
          <Sparkles className="w-4 h-4 fill-current" />
          <span>SEARCH PRIMITIVE LIBRARY & SYNTHESIZE CANDIDATES</span>
        </button>
      </div>

      {/* Synthesis Candidates Output */}
      {hasSearched && (
        <div className="space-y-4">
          <h3 className="font-bold text-slate-200 text-xs uppercase tracking-wide">
            OPTIMIZED SYNTHETIC DERIVATIVE CANDIDATES ({candidates.length} FOUND)
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {candidates.map(cand => (
              <div key={cand.id} className="p-4 bg-slate-900 rounded-lg border border-slate-800 space-y-3">
                <div className="font-bold text-amber-400 text-sm border-b border-slate-800 pb-2">
                  {cand.title}
                </div>
                <div className="text-slate-300 font-sans text-xs">
                  <strong>Construction:</strong> {cand.construction}
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 space-y-1 text-[11px]">
                  <div>Est. Price: <strong className="text-emerald-400">${cand.estimatedPrice.toLocaleString()}</strong></div>
                  <div>Residual Error: <strong className="text-cyan-400">{cand.residualFitError}</strong></div>
                  <div>Max Loss: <strong className="text-red-400">${cand.maxLoss.toLocaleString()}</strong></div>
                  <div>Max Gain: <strong className="text-slate-100">{cand.maxGain}</strong></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
