/**
 * RhinoQuant Volatility & Correlation Engine View
 */

import React from 'react';
import { VolatilitySurfaceData, CorrelationMatrixData } from '../../types';
import { VolatilitySurface3D } from '../visualization/VolatilitySurface3D';
import { ShieldCheck, CheckCircle2, AlertTriangle } from 'lucide-react';

interface VolatilityAndCorrelationViewProps {
  volSurface: VolatilitySurfaceData;
  correlationMatrix: CorrelationMatrixData;
}

export const VolatilityAndCorrelationView: React.FC<VolatilityAndCorrelationViewProps> = ({
  volSurface,
  correlationMatrix,
}) => {
  const { assetIds, matrix, isPositiveDefinite, eigenvalues } = correlationMatrix;

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Volatility Surface Component */}
      <VolatilitySurface3D volSurface={volSurface} />

      {/* Multi-Asset Correlation Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wide">
              MULTI-ASSET CORRELATION ENGINE
            </h2>
            <p className="text-slate-400 font-sans text-xs">
              Symmetric Positive-Definite Check & Eigenvalue Decomposition
            </p>
          </div>

          <div className="flex items-center space-x-2">
            {isPositiveDefinite ? (
              <span className="flex items-center space-x-1 px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>POSITIVE DEFINITE (λ_min &gt; 0)</span>
              </span>
            ) : (
              <span className="flex items-center space-x-1 px-2.5 py-1 rounded bg-red-950 text-red-400 border border-red-500/30 font-bold">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>PSD CORRECTION APPLIED</span>
              </span>
            )}
          </div>
        </div>

        {/* Matrix Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="p-2 text-left bg-slate-950 font-normal">ASSET</th>
                {assetIds.map(id => (
                  <th key={id} className="p-2 font-normal bg-slate-950">{id}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {assetIds.map((rowId, i) => (
                <tr key={rowId} className="border-b border-slate-800/40">
                  <td className="p-2 text-left text-slate-200 bg-slate-950/60 font-bold">{rowId}</td>
                  {assetIds.map((_colId, j) => {
                    const corr = matrix[i]?.[j] ?? (i === j ? 1 : 0);
                    return (
                      <td
                        key={j}
                        className={`p-2 font-mono font-medium ${
                          i === j
                            ? 'bg-slate-800 text-amber-400 font-bold'
                            : corr > 0.6
                            ? 'bg-amber-950/40 text-amber-300'
                            : 'bg-slate-950 text-slate-300'
                        }`}
                      >
                        {corr.toFixed(2)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Eigenvalue Spectrum */}
        <div className="p-4 bg-slate-950 rounded border border-slate-800">
          <div className="text-slate-300 font-bold mb-2">EIGENVALUE SPECTRUM (FACTOR DECOMPOSITION)</div>
          <div className="flex items-center space-x-3 overflow-x-auto">
            {eigenvalues.map((lambda, idx) => (
              <div key={idx} className="p-2 bg-slate-900 rounded border border-slate-800 text-center min-w-[100px]">
                <span className="text-slate-400 block text-[10px]">FACTOR λ_{idx + 1}</span>
                <strong className={lambda > 0 ? 'text-emerald-400' : 'text-red-400'}>{lambda.toFixed(4)}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
