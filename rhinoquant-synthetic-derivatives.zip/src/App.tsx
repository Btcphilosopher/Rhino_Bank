/**
 * RhinoQuant Synthetic Derivatives - Main Terminal Application
 */

import React, { useState } from 'react';
import { InstitutionalHeader } from './components/layout/InstitutionalHeader';
import { Navigation } from './components/layout/Navigation';
import { DashboardView } from './components/dashboard/DashboardView';
import { MarketsAndCurvesView } from './components/markets/MarketsAndCurvesView';
import { VolatilityAndCorrelationView } from './components/volatility/VolatilityAndCorrelationView';
import { SyntheticBuilderView } from './components/builder/SyntheticBuilderView';
import { InstrumentAnalyticsView } from './components/pricing/InstrumentAnalyticsView';
import { PortfolioAndRiskView } from './components/portfolio/PortfolioAndRiskView';
import { StressTestingView } from './components/stress/StressTestingView';
import { ResearchLabView } from './components/research/ResearchLabView';
import { ReverseEngineeringView } from './components/generator/ReverseEngineeringView';
import { QuantNotebookView } from './components/research/QuantNotebookView';
import { GeminiResearchAssistant } from './components/ai/GeminiResearchAssistant';

import { SyntheticMarketSimulator } from './engine/market/marketData';
import { SIGNATURE_DERIVATIVES, INITIAL_PORTFOLIO_POSITIONS } from './data/seedData';
import { calculatePortfolioSummary } from './engine/portfolio/portfolioEngine';
import { SyntheticDerivative } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState('DASHBOARD');
  const [isAiOpen, setIsAiOpen] = useState(false);

  // Initialized market state
  const marketSim = new SyntheticMarketSimulator(20260926);
  const assets = marketSim.getMarketAssets();
  const curves = marketSim.getCurves();
  const volSurface = marketSim.getVolatilitySurface('COPPER');
  const correlationMatrix = marketSim.getCorrelationMatrix();

  const [derivatives, setDerivatives] = useState<SyntheticDerivative[]>(SIGNATURE_DERIVATIVES);
  const [selectedDerivative, setSelectedDerivative] = useState<SyntheticDerivative>(SIGNATURE_DERIVATIVES[0]);

  const portfolioSummary = calculatePortfolioSummary(INITIAL_PORTFOLIO_POSITIONS);

  const handleCreateDerivative = (newDeriv: SyntheticDerivative) => {
    setDerivatives([newDeriv, ...derivatives]);
    setSelectedDerivative(newDeriv);
    setActiveTab('PRICING_ANALYTICS');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      <InstitutionalHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        toggleAiAssistant={() => setIsAiOpen(!isAiOpen)}
      />

      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6">
        {activeTab === 'DASHBOARD' && (
          <DashboardView
            assets={assets}
            derivatives={derivatives}
            portfolioSummary={portfolioSummary}
            onSelectDerivative={(d) => {
              setSelectedDerivative(d);
              setActiveTab('PRICING_ANALYTICS');
            }}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'MARKETS_CURVES' && (
          <MarketsAndCurvesView assets={assets} curves={curves} />
        )}

        {activeTab === 'VOL_CORRELATION' && (
          <VolatilityAndCorrelationView
            volSurface={volSurface}
            correlationMatrix={correlationMatrix}
          />
        )}

        {activeTab === 'SYNTHETIC_BUILDER' && (
          <SyntheticBuilderView
            assets={assets}
            onCreateDerivative={handleCreateDerivative}
          />
        )}

        {activeTab === 'PRICING_ANALYTICS' && (
          <InstrumentAnalyticsView
            derivative={selectedDerivative}
            spotPrice={9850}
          />
        )}

        {activeTab === 'PORTFOLIO_RISK' && (
          <PortfolioAndRiskView portfolioSummary={portfolioSummary} />
        )}

        {activeTab === 'STRESS_TESTING' && <StressTestingView />}

        {activeTab === 'RESEARCH_LAB' && <ResearchLabView />}

        {activeTab === 'REVERSE_ENGINEERING' && <ReverseEngineeringView />}

        {activeTab === 'QUANT_NOTEBOOK' && <QuantNotebookView />}
      </main>

      {/* Gemini AI Research Assistant Drawer */}
      <GeminiResearchAssistant isOpen={isAiOpen} onClose={() => setIsAiOpen(false)} />
    </div>
  );
}
