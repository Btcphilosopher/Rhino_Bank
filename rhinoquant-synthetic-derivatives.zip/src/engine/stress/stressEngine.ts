/**
 * RhinoQuant Stress Testing Engine - Historical & Macro Stress Scenarios
 */

import { StressScenario, StressTestResult, SyntheticDerivative, Greeks } from '../../types';

export const PRESET_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'SCEN_2008_CREDIT',
    name: '2008 Global Credit & Commodity Crash',
    description: 'Severe commodity selloff, liquidity crunch, volatility doubling, credit spread blow-out.',
    spotShiftPercent: -35.0,
    volShiftPercent: +40.0,
    rateShiftBp: -150,
    correlationShiftPercent: +25.0,
    fxShiftPercent: -8.0,
    isHistorical: true,
  },
  {
    id: 'SCEN_2020_LIQUIDITY',
    name: '2020 COVID Liquidity Shock',
    description: 'Rapid asset drawdown, historic volatility spike, cross-asset correlation convergence to 1.0.',
    spotShiftPercent: -25.0,
    volShiftPercent: +60.0,
    rateShiftBp: -100,
    correlationShiftPercent: +40.0,
    fxShiftPercent: -5.0,
    isHistorical: true,
  },
  {
    id: 'SCEN_COMMODITY_SPIKE',
    name: 'Supply Chain & Commodity Super-Spike',
    description: 'Geopolitical energy/metal supply shock, hyper-backwardation in forward curves.',
    spotShiftPercent: +45.0,
    volShiftPercent: +25.0,
    rateShiftBp: +75,
    correlationShiftPercent: -15.0,
    fxShiftPercent: +4.0,
    isHistorical: false,
  },
  {
    id: 'SCEN_CORRELATION_BREAKDOWN',
    name: 'Correlation Breakdown & Dislocation',
    description: 'Historical correlations shatter; spread derivatives suffer massive basis risk.',
    spotShiftPercent: 0.0,
    volShiftPercent: +15.0,
    rateShiftBp: +25,
    correlationShiftPercent: -60.0,
    fxShiftPercent: 0.0,
    isHistorical: false,
  },
];

export function runStressTest(
  basePrice: number,
  baseGreeks: Greeks,
  scenario: StressScenario
): StressTestResult {
  const spotFactor = 1 + scenario.spotShiftPercent / 100;
  const volFactor = 1 + scenario.volShiftPercent / 100;

  // Taylor expansion approximation for stressed price:
  // P_stressed ≈ P_base + Delta * ΔS + 0.5 * Gamma * (ΔS)^2 + Vega * ΔVol + Rho * Δr
  const deltaImpact = baseGreeks.delta * (basePrice * (scenario.spotShiftPercent / 100));
  const gammaImpact = 0.5 * baseGreeks.gamma * Math.pow(basePrice * (scenario.spotShiftPercent / 100), 2);
  const vegaImpact = baseGreeks.vega * scenario.volShiftPercent;
  const rhoImpact = baseGreeks.rho * (scenario.rateShiftBp / 100);
  const corrImpact = baseGreeks.correlationSensitivity * scenario.correlationShiftPercent * 100;

  const pnlImpact = deltaImpact + gammaImpact + vegaImpact + rhoImpact + corrImpact;
  const stressedValue = Math.max(0, basePrice + pnlImpact);
  const percentageChange = basePrice > 0 ? (pnlImpact / basePrice) * 100 : 0;

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    baseValue: parseFloat(basePrice.toFixed(2)),
    stressedValue: parseFloat(stressedValue.toFixed(2)),
    pnlImpact: parseFloat(pnlImpact.toFixed(2)),
    percentageChange: parseFloat(percentageChange.toFixed(2)),
    greeksImpact: {
      delta: parseFloat((baseGreeks.delta * spotFactor).toFixed(4)),
      vega: parseFloat((baseGreeks.vega * volFactor).toFixed(2)),
    },
  };
}

export function generateScenarioMatrixGrid(
  basePrice: number,
  baseGreeks: Greeks,
  spotShifts: number[] = [-0.20, -0.10, 0, 0.10, 0.20],
  volShifts: number[] = [-0.20, -0.10, 0, 0.10, 0.20]
): { grid: number[][]; spotShifts: number[]; volShifts: number[] } {
  const grid: number[][] = [];

  for (let i = 0; i < volShifts.length; i++) {
    const row: number[] = [];
    const volShift = volShifts[i];
    for (let j = 0; j < spotShifts.length; j++) {
      const spotShift = spotShifts[j];
      const dS = basePrice * spotShift;
      const dVol = volShift * 100;

      const pnl = baseGreeks.delta * dS + 0.5 * baseGreeks.gamma * dS * dS + baseGreeks.vega * dVol;
      row.push(parseFloat(pnl.toFixed(2)));
    }
    grid.push(row);
  }

  return { grid, spotShifts, volShifts };
}
