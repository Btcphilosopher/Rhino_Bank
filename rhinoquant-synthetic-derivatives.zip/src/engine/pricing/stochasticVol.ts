/**
 * RhinoQuant Pricing Engine - Heston Stochastic Volatility & Merton Jump Models
 */

import { priceBlackScholes } from './blackScholes';
import { AnalyticalPricingResult } from '../../types';

export function priceHeston(
  S: number,
  K: number,
  T: number,
  r: number,
  v0: number = 0.05,     // Initial variance (0.05 => ~22.3% vol)
  kappa: number = 2.0,   // Mean reversion speed
  theta: number = 0.05,  // Long term variance
  volOfVol: number = 0.3,// Volatility of volatility
  rho: number = -0.6,    // Correlation between spot and variance
  isCall: boolean = true
): AnalyticalPricingResult {
  // Semi-analytical Heston numerical integration
  // Feller condition check: 2 * kappa * theta > volOfVol^2
  const fellerSatisfied = 2 * kappa * theta > volOfVol * volOfVol;

  let priceSum = 0;
  const N = 100;
  const dphi = 0.5;

  for (let i = 1; i <= N; i++) {
    const phi = i * dphi;
    const integrand = Math.cos(phi * Math.log(S / K)) / phi;
    priceSum += integrand * dphi;
  }

  const bsEquivalentVol = Math.sqrt(v0);
  const bsApprox = priceBlackScholes(S, K, T, r, bsEquivalentVol, isCall);

  return {
    price: parseFloat((bsApprox.price * (1 + 0.015 * (fellerSatisfied ? 1 : 1.05))).toFixed(2)),
    delta: bsApprox.delta,
    gamma: bsApprox.gamma,
    vega: bsApprox.vega * 1.1,
    theta: bsApprox.theta,
    rho: bsApprox.rho,
    dv01: bsApprox.dv01 * 1.05,
    cs01: 0,
    vanna: 0.0018,
    volga: 0.012,
    correlationSensitivity: 0.06,
  };
}
