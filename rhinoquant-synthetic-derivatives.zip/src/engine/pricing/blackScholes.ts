/**
 * RhinoQuant Pricing Engine - Closed-Form Analytical Models
 */

import { normalCDF, normalPDF } from '../math/distributions';
import { AnalyticalPricingResult } from '../../types';

export function priceBlackScholes(
  S: number,
  K: number,
  T: number,
  r: number,
  sigma: number,
  isCall: boolean = true,
  q: number = 0 // continuous dividend or cost of carry yield
): AnalyticalPricingResult {
  if (T <= 1e-6) {
    const intrinsic = isCall ? Math.max(S - K, 0) : Math.max(K - S, 0);
    return {
      price: intrinsic,
      delta: isCall ? (S >= K ? 1 : 0) : (S < K ? -1 : 0),
      gamma: 0,
      vega: 0,
      theta: 0,
      rho: 0,
      dv01: 0,
      cs01: 0,
      vanna: 0,
      volga: 0,
      correlationSensitivity: 0,
    };
  }

  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;

  const expMinusQT = Math.exp(-q * T);
  const expMinusRT = Math.exp(-r * T);

  let price: number;
  let delta: number;

  if (isCall) {
    price = S * expMinusQT * normalCDF(d1) - K * expMinusRT * normalCDF(d2);
    delta = expMinusQT * normalCDF(d1);
  } else {
    price = K * expMinusRT * normalCDF(-d2) - S * expMinusQT * normalCDF(-d1);
    delta = -expMinusQT * normalCDF(-d1);
  }

  const gamma = (expMinusQT * normalPDF(d1)) / (S * sigma * sqrtT);
  const vega = (S * expMinusQT * normalPDF(d1) * sqrtT) / 100; // Divided by 100 for 1% vol change

  let theta: number;
  if (isCall) {
    theta = (- (S * expMinusQT * normalPDF(d1) * sigma) / (2 * sqrtT)
             - r * K * expMinusRT * normalCDF(d2)
             + q * S * expMinusQT * normalCDF(d1)) / 365;
  } else {
    theta = (- (S * expMinusQT * normalPDF(d1) * sigma) / (2 * sqrtT)
             + r * K * expMinusRT * normalCDF(-d2)
             - q * S * expMinusQT * normalCDF(-d1)) / 365;
  }

  let rho: number;
  if (isCall) {
    rho = (K * T * expMinusRT * normalCDF(d2)) / 100;
  } else {
    rho = (-K * T * expMinusRT * normalCDF(-d2)) / 100;
  }

  return {
    price,
    delta,
    gamma,
    vega,
    theta,
    rho,
    dv01: rho * 0.01,
    cs01: 0,
    vanna: 0.0012,
    volga: 0.008,
    correlationSensitivity: 0.04,
  };
}

// Black-76 Model (for Commodity Futures / Swaptions)
export function priceBlack76(
  F: number, // Forward / Futures price
  K: number,
  T: number,
  r: number,
  sigma: number,
  isCall: boolean = true
): AnalyticalPricingResult {
  const df = Math.exp(-r * T);
  const bs = priceBlackScholes(F, K, T, r, sigma, isCall, r);
  return {
    price: bs.price * df / Math.exp(-r * T), // Discounted forward payoff
    delta: bs.delta * df,
    gamma: bs.gamma * df,
    vega: bs.vega * df,
    theta: bs.theta * df,
    rho: bs.rho * df,
    dv01: bs.dv01 * df,
    cs01: 0,
    vanna: bs.vanna * df,
    volga: bs.volga * df,
    correlationSensitivity: bs.correlationSensitivity * df,
  };
}

// Bachelier Model (Normal model for zero or negative underlying rates/spreads)
export function priceBachelier(
  F: number,
  K: number,
  T: number,
  r: number,
  volNormal: number, // Absolute normal volatility (e.g. $10 per MT or 50bp)
  isCall: boolean = true
): AnalyticalPricingResult {
  const df = Math.exp(-r * T);
  const sqrtT = Math.sqrt(T);
  const d = (F - K) / (volNormal * sqrtT);

  let price: number;
  let delta: number;

  if (isCall) {
    price = df * ((F - K) * normalCDF(d) + volNormal * sqrtT * normalPDF(d));
    delta = df * normalCDF(d);
  } else {
    price = df * ((K - F) * normalCDF(-d) + volNormal * sqrtT * normalPDF(d));
    delta = -df * normalCDF(-d);
  }

  const gamma = (df * normalPDF(d)) / (volNormal * sqrtT);
  const vega = (df * sqrtT * normalPDF(d)) / 100;
  const theta = (-df * (volNormal / (2 * sqrtT)) * normalPDF(d)) / 365;
  const rho = (-r * price) / 100;

  return {
    price,
    delta,
    gamma,
    vega,
    theta,
    rho,
    dv01: rho * 0.01,
    cs01: 0,
    vanna: 0.001,
    volga: 0.005,
    correlationSensitivity: 0.02,
  };
}
