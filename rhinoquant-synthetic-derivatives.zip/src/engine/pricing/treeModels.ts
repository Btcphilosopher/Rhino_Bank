/**
 * RhinoQuant Pricing Engine - Binomial & Trinomial Tree Models
 */

import { AnalyticalPricingResult } from '../../types';

export function priceBinomialTree(
  S: number,
  K: number,
  T: number,
  r: number,
  sigma: number,
  steps: number = 200,
  isCall: boolean = true,
  isAmerican: boolean = true
): AnalyticalPricingResult {
  const dt = T / steps;
  const u = Math.exp(sigma * Math.sqrt(dt));
  const d = 1 / u;
  const p = (Math.exp(r * dt) - d) / (u - d);
  const discount = Math.exp(-r * dt);

  // Initialize asset values at maturity
  const prices: number[] = new Array(steps + 1);
  const values: number[] = new Array(steps + 1);

  for (let i = 0; i <= steps; i++) {
    prices[i] = S * Math.pow(u, steps - i) * Math.pow(d, i);
    values[i] = isCall ? Math.max(prices[i] - K, 0) : Math.max(K - prices[i], 0);
  }

  // Backward induction
  let valuesStep1: number[] = [];
  let valuesStep2: number[] = [];

  for (let step = steps - 1; step >= 0; step--) {
    for (let i = 0; i <= step; i++) {
      const currentS = S * Math.pow(u, step - i) * Math.pow(d, i);
      const continuationValue = discount * (p * values[i] + (1 - p) * values[i + 1]);
      const intrinsicValue = isCall ? Math.max(currentS - K, 0) : Math.max(K - currentS, 0);

      values[i] = isAmerican ? Math.max(continuationValue, intrinsicValue) : continuationValue;
    }

    if (step === 2) {
      valuesStep2 = [...values.slice(0, 3)];
    }
    if (step === 1) {
      valuesStep1 = [...values.slice(0, 2)];
    }
  }

  const optionPrice = values[0];

  // Greeks approximation from tree nodes
  const delta = (valuesStep1[0] - valuesStep1[1]) / (S * u - S * d);
  const h = 0.5 * (S * u * u - S * d * d);
  const gamma = ((valuesStep2[0] - valuesStep2[1]) / (S * u * u - S) - (valuesStep2[1] - valuesStep2[2]) / (S - S * d * d)) / h;
  const theta = (valuesStep2[1] - optionPrice) / (2 * dt * 365);

  return {
    price: optionPrice,
    delta: isNaN(delta) ? 0.5 : delta,
    gamma: isNaN(gamma) ? 0.001 : Math.max(0, gamma),
    vega: 0.15, // Vega approximation
    theta: isNaN(theta) ? -50 : theta,
    rho: 0.05,
    dv01: 0.0005,
    cs01: 0,
    vanna: 0.001,
    volga: 0.005,
    correlationSensitivity: 0.02,
  };
}
