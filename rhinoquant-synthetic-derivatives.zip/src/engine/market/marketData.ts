/**
 * RhinoQuant Market Engine - Deterministic Synthetic Market Generator
 */

import { MarketAsset, MarketCurve, VolatilitySurfaceData, CorrelationMatrixData } from '../../types';
import { SeededRandom } from '../math/distributions';
import { isPositiveDefinite, makePSDCorrelationMatrix } from '../math/linearAlgebra';

export class SyntheticMarketSimulator {
  private seed: number;
  private rng: SeededRandom;

  constructor(seed: number = 20260926) {
    this.seed = seed;
    this.rng = new SeededRandom(seed);
  }

  public getMarketAssets(): MarketAsset[] {
    return [
      { id: 'COPPER', symbol: 'HG1!', name: 'Grade A LME Copper', assetClass: 'COMMODITY', spotPrice: 9850.0, currency: 'USD', historicalVol: 0.24, drift: 0.05, unit: 'USD/MT', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'ALUMINIUM', symbol: 'ALI1!', name: 'Primary Aluminium', assetClass: 'COMMODITY', spotPrice: 2450.0, currency: 'USD', historicalVol: 0.21, drift: 0.03, unit: 'USD/MT', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'NICKEL', symbol: 'NIC1!', name: 'Refined Nickel Class 1', assetClass: 'COMMODITY', spotPrice: 17200.0, currency: 'USD', historicalVol: 0.32, drift: 0.02, unit: 'USD/MT', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'STEEL', symbol: 'STL1!', name: 'Hot Rolled Coil Steel', assetClass: 'COMMODITY', spotPrice: 780.0, currency: 'USD', historicalVol: 0.28, drift: 0.04, unit: 'USD/MT', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'POWER_UK', symbol: 'UKPWR1!', name: 'UK Baseload Power 1Y', assetClass: 'ENERGY', spotPrice: 88.5, currency: 'GBP', historicalVol: 0.38, drift: 0.06, unit: 'GBP/MWh', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'FREIGHT_C3', symbol: 'BALTIC_C3', name: 'Baltic Capesize C3 Route', assetClass: 'FREIGHT', spotPrice: 24.5, currency: 'USD', historicalVol: 0.45, drift: 0.08, unit: 'USD/MT', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'BRENT', symbol: 'CO1!', name: 'Brent Crude Oil', assetClass: 'ENERGY', spotPrice: 79.2, currency: 'USD', historicalVol: 0.26, drift: 0.02, unit: 'USD/bbl', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'USD_SOFR', symbol: 'SOFR10Y', name: 'US Treasury 10Y Yield', assetClass: 'RATES', spotPrice: 0.0425, currency: 'USD', historicalVol: 0.15, drift: 0.01, unit: 'Rate', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'EUR_USD', symbol: 'EURUSD', name: 'Euro / US Dollar Spot', assetClass: 'FX', spotPrice: 1.0850, currency: 'USD', historicalVol: 0.08, drift: -0.01, unit: 'FX', lastUpdated: '2026-09-28 00:00 UTC' },
      { id: 'GBP_USD', symbol: 'GBPUSD', name: 'British Pound / USD Spot', assetClass: 'FX', spotPrice: 1.2950, currency: 'USD', historicalVol: 0.09, drift: 0.01, unit: 'FX', lastUpdated: '2026-09-28 00:00 UTC' },
    ];
  }

  public getCurves(): MarketCurve[] {
    return [
      {
        id: 'USD_SOFR_CURVE',
        name: 'USD SOFR OIS Discount Curve',
        currency: 'USD',
        type: 'DISCOUNT',
        interpolation: 'LOG_LINEAR',
        points: [
          { tenor: '1M', days: 30, rate: 0.0485, discountFactor: 0.9959 },
          { tenor: '3M', days: 90, rate: 0.0470, discountFactor: 0.9883 },
          { tenor: '6M', days: 180, rate: 0.0450, discountFactor: 0.9778 },
          { tenor: '1Y', days: 365, rate: 0.0425, discountFactor: 0.9584 },
          { tenor: '2Y', days: 730, rate: 0.0400, discountFactor: 0.9231 },
          { tenor: '5Y', days: 1825, rate: 0.0385, discountFactor: 0.8249 },
          { tenor: '10Y', days: 3650, rate: 0.0410, discountFactor: 0.6636 },
        ]
      },
      {
        id: 'COPPER_FORWARD_CURVE',
        name: 'LME Copper Forward Curve (Backwardation)',
        currency: 'USD',
        type: 'COMMODITY_FORWARD',
        interpolation: 'MONOTONIC_CUBIC',
        points: [
          { tenor: 'SPOT', days: 0, rate: 9850, discountFactor: 1.0, forwardRate: 9850 },
          { tenor: '1M', days: 30, rate: 9820, discountFactor: 0.996, forwardRate: 9820 },
          { tenor: '3M', days: 90, rate: 9780, discountFactor: 0.988, forwardRate: 9780 },
          { tenor: '6M', days: 180, rate: 9710, discountFactor: 0.978, forwardRate: 9710 },
          { tenor: '1Y', days: 365, rate: 9600, discountFactor: 0.958, forwardRate: 9600 },
          { tenor: '2Y', days: 730, rate: 9450, discountFactor: 0.923, forwardRate: 9450 },
        ]
      }
    ];
  }

  public getVolatilitySurface(underlyingId: string = 'COPPER'): VolatilitySurfaceData {
    const expiries = [0.25, 0.5, 1.0, 2.0, 3.0];
    const strikes = [8000, 9000, 9850, 10500, 11500, 12500];

    // Build volatility smile and skew surface
    const matrix: number[][] = [];
    for (let i = 0; i < expiries.length; i++) {
      const row: number[] = [];
      const T = expiries[i];
      for (let j = 0; j < strikes.length; j++) {
        const K = strikes[j];
        const logMoneyness = Math.log(K / 9850);
        // SABR-like smile: baseVol + skew * logMoneyness + curvature * logMoneyness^2
        const baseVol = 0.24 - 0.02 * Math.sqrt(T);
        const skew = -0.15;
        const curvature = 0.45;
        const vol = Math.max(0.08, baseVol + skew * logMoneyness + curvature * logMoneyness * logMoneyness);
        row.push(parseFloat(vol.toFixed(4)));
      }
      matrix.push(row);
    }

    return {
      id: `VOL_${underlyingId}_2026`,
      underlyingId,
      expiries,
      strikes,
      matrix,
      sabrParams: {
        alpha: 0.22,
        beta: 0.5,
        rho: -0.35,
        nu: 0.48,
      }
    };
  }

  public getCorrelationMatrix(): CorrelationMatrixData {
    const assetIds = ['COPPER', 'ALUMINIUM', 'NICKEL', 'STEEL', 'POWER_UK', 'FREIGHT_C3', 'BRENT'];

    // Realistic correlation structure between industrial metals, energy, and freight
    const rawMatrix: number[][] = [
      [1.00, 0.78, 0.65, 0.58, 0.42, 0.35, 0.52], // COPPER
      [0.78, 1.00, 0.60, 0.62, 0.40, 0.30, 0.48], // ALUMINIUM
      [0.65, 0.60, 1.00, 0.50, 0.35, 0.28, 0.45], // NICKEL
      [0.58, 0.62, 0.50, 1.00, 0.48, 0.42, 0.40], // STEEL
      [0.42, 0.40, 0.35, 0.48, 1.00, 0.55, 0.68], // POWER_UK
      [0.35, 0.30, 0.28, 0.42, 0.55, 1.00, 0.60], // FREIGHT_C3
      [0.52, 0.48, 0.45, 0.40, 0.68, 0.60, 1.00], // BRENT
    ];

    const pdCheck = isPositiveDefinite(rawMatrix);
    const safeMatrix = pdCheck.isPD ? rawMatrix : makePSDCorrelationMatrix(rawMatrix);

    return {
      id: 'CORR_INDUSTRIAL_METALS_2026',
      assetIds,
      matrix: safeMatrix,
      isPositiveDefinite: true,
      eigenvalues: pdCheck.eigenvalues,
      timestamp: '2026-09-28 00:00:00 UTC'
    };
  }
}
