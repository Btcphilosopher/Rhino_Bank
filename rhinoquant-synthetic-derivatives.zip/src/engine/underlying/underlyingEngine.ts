/**
 * RhinoQuant Synthetic Underlying & Basket Engine
 */

import { SyntheticUnderlying, MarketAsset, WeightingMethod, ComponentWeight } from '../../types';

export function calculateSyntheticSpot(
  underlying: SyntheticUnderlying,
  marketAssets: Record<string, MarketAsset>
): number {
  let spotSum = 0;
  for (const comp of underlying.components) {
    const asset = marketAssets[comp.assetId];
    if (asset) {
      spotSum += comp.weight * asset.spotPrice;
    }
  }
  return spotSum;
}

export function calculateSyntheticVolatility(
  underlying: SyntheticUnderlying,
  marketAssets: Record<string, MarketAsset>,
  corrMatrix: number[][],
  assetIds: string[]
): number {
  const n = underlying.components.length;
  if (n === 0) return 0.20;

  let variance = 0;

  for (let i = 0; i < n; i++) {
    const compI = underlying.components[i];
    const assetI = marketAssets[compI.assetId];
    const volI = assetI ? assetI.historicalVol : 0.20;
    const wI = compI.weight;

    for (let j = 0; j < n; j++) {
      const compJ = underlying.components[j];
      const assetJ = marketAssets[compJ.assetId];
      const volJ = assetJ ? assetJ.historicalVol : 0.20;
      const wJ = compJ.weight;

      const idxI = assetIds.indexOf(compI.assetId);
      const idxJ = assetIds.indexOf(compJ.assetId);
      const rho = (idxI >= 0 && idxJ >= 0 && corrMatrix[idxI] && corrMatrix[idxI][idxJ] !== undefined)
        ? corrMatrix[idxI][idxJ]
        : (i === j ? 1.0 : 0.40);

      variance += wI * wJ * volI * volJ * rho;
    }
  }

  return Math.sqrt(Math.max(variance, 1e-6));
}

export function rebalanceWeights(
  method: WeightingMethod,
  components: { assetId: string; rawWeight?: number }[],
  marketAssets: Record<string, MarketAsset>
): ComponentWeight[] {
  const n = components.length;
  if (n === 0) return [];

  if (method === 'EQUAL') {
    const w = 1 / n;
    return components.map(c => ({ assetId: c.assetId, weight: w }));
  }

  if (method === 'INVERSE_VOLATILITY') {
    let sumInvVol = 0;
    const invVols: { assetId: string; invVol: number }[] = [];

    for (const c of components) {
      const asset = marketAssets[c.assetId];
      const vol = asset ? asset.historicalVol : 0.20;
      const inv = 1 / Math.max(vol, 0.01);
      invVols.push({ assetId: c.assetId, invVol: inv });
      sumInvVol += inv;
    }

    return invVols.map(iv => ({
      assetId: iv.assetId,
      weight: parseFloat((iv.invVol / sumInvVol).toFixed(4)),
    }));
  }

  // Fallback / CUSTOM / MARKET
  const rawSum = components.reduce((acc, c) => acc + (c.rawWeight ?? 1), 0);
  return components.map(c => ({
    assetId: c.assetId,
    weight: parseFloat(((c.rawWeight ?? 1) / (rawSum > 0 ? rawSum : 1)).toFixed(4)),
  }));
}
