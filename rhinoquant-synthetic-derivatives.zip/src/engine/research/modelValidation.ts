/**
 * RhinoQuant Research Lab - Model Validation & Comparative Benchmark Suite
 */

import { SyntheticDerivative } from '../../types';
import { priceBlackScholes } from '../pricing/blackScholes';
import { priceBinomialTree } from '../pricing/treeModels';
import { priceHeston } from '../pricing/stochasticVol';
import { runMonteCarloSimulation } from '../pricing/monteCarlo';
import { runSurrogatePricer } from '../pricing/surrogatePricer';

export interface ModelComparisonRow {
  modelName: string;
  category: string;
  price: number;
  delta: number;
  vega: number;
  runtimeMs: number;
  numericalError: string;
  assumptions: string;
}

export function runModelComparisonSuite(
  derivative: SyntheticDerivative,
  spot: number = 9850,
  vol: number = 0.24,
  rate: number = 0.0425
): ModelComparisonRow[] {
  const K = derivative.payoff.strike ?? spot;
  const T = derivative.schedule.timeToMaturityYears || 1.0;

  // 1. Black-Scholes Analytical
  const t0 = performance.now();
  const bs = priceBlackScholes(spot, K, T, rate, vol, true);
  const t1 = performance.now();

  // 2. Binomial CRR Tree
  const t2 = performance.now();
  const tree = priceBinomialTree(spot, K, T, rate, vol, 300, true, true);
  const t3 = performance.now();

  // 3. Heston Stochastic Vol
  const t4 = performance.now();
  const heston = priceHeston(spot, K, T, rate, 0.0576, 2.0, 0.05, 0.3, -0.6, true);
  const t5 = performance.now();

  // 4. Monte Carlo (100,000 paths)
  const mc = runMonteCarloSimulation(derivative, spot, vol, rate, 100000, 52, 20260926);

  // 5. Fast Surrogate Pricer
  const surrogate = runSurrogatePricer(derivative, spot, vol, rate);

  return [
    {
      modelName: 'Black-Scholes (1973)',
      category: 'Closed-Form Analytical',
      price: parseFloat(bs.price.toFixed(2)),
      delta: parseFloat(bs.delta.toFixed(4)),
      vega: parseFloat(bs.vega.toFixed(2)),
      runtimeMs: parseFloat((t1 - t0).toFixed(3)),
      numericalError: 'Exact Analytical Benchmark',
      assumptions: 'Constant volatility, lognormal returns, continuous trading, no jump risk',
    },
    {
      modelName: 'Cox-Ross-Rubinstein Binomial Tree (300 Steps)',
      category: 'Lattice / Numerical',
      price: parseFloat(tree.price.toFixed(2)),
      delta: parseFloat(tree.delta.toFixed(4)),
      vega: parseFloat(tree.vega.toFixed(2)),
      runtimeMs: parseFloat((t3 - t2).toFixed(3)),
      numericalError: `O(Δt) ≈ $${(Math.abs(tree.price - bs.price)).toFixed(2)}`,
      assumptions: 'Discrete time binomial random walk, early American exercise support',
    },
    {
      modelName: 'Heston Stochastic Volatility Model',
      category: 'Semi-Analytical Integration',
      price: parseFloat(heston.price.toFixed(2)),
      delta: parseFloat(heston.delta.toFixed(4)),
      vega: parseFloat(heston.vega.toFixed(2)),
      runtimeMs: parseFloat((t5 - t4).toFixed(3)),
      numericalError: 'Quadrature Integration ~0.001%',
      assumptions: 'Mean-reverting CIR variance process correlated with spot drift',
    },
    {
      modelName: 'Quasi-Monte Carlo (100,000 Paths, Antithetic)',
      category: 'Stochastic Simulation',
      price: parseFloat(mc.price.toFixed(2)),
      delta: parseFloat(mc.greeks.delta.toFixed(4)),
      vega: parseFloat(mc.greeks.vega.toFixed(2)),
      runtimeMs: mc.details.executionTimeMs,
      numericalError: `Standard Error: ±$${mc.details.standardError}`,
      assumptions: 'Discrete path simulation, arbitrary payoff functions, empirical variance',
    },
    {
      modelName: 'Surrogate Polynomial Pricer (Offline RBF Grid)',
      category: 'Surrogate Approximation',
      price: parseFloat(surrogate.price.toFixed(2)),
      delta: parseFloat(surrogate.greeks.delta.toFixed(4)),
      vega: parseFloat(surrogate.greeks.vega.toFixed(2)),
      runtimeMs: surrogate.executionTimeMs,
      numericalError: `RMSE: ${surrogate.rmse}`,
      assumptions: 'Pre-computed offline grid representation for instant real-time risk',
    },
  ];
}
