/**
 * RhinoQuant Payoff Engine - Derivative Primitives & Payoff Evaluator
 */

import { PayoffDefinition } from '../../types';
import { DSLParser, ASTNode, evaluateAST } from './ast';

export function evaluatePayoff(
  payoff: PayoffDefinition,
  spot: number, // or primary state variable
  timeYears: number = 1.0,
  extraState: Record<string, number> = {}
): number {
  const K = payoff.strike ?? 100;
  const B = payoff.barrier ?? 120;
  const R = payoff.rebate ?? 0;
  const payout = payoff.digitalPayout ?? 1.0;

  const stateEnv: Record<string, number> = {
    S: spot,
    K: K,
    B: B,
    R: R,
    payout: payout,
    t: timeYears,
    ...extraState,
  };

  switch (payoff.type) {
    case 'VANILLA_CALL':
      return Math.max(spot - K, 0);

    case 'VANILLA_PUT':
      return Math.max(K - spot, 0);

    case 'DIGITAL_DIGIT':
      return spot >= K ? payout : 0;

    case 'BARRIER_KNOCK_OUT': {
      // Up and out or Down and out
      if (payoff.barrierType === 'UP_AND_OUT') {
        return spot >= B ? R : Math.max(spot - K, 0);
      } else {
        return spot <= B ? R : Math.max(spot - K, 0);
      }
    }

    case 'BARRIER_KNOCK_IN': {
      if (payoff.barrierType === 'UP_AND_IN') {
        return spot >= B ? Math.max(spot - K, 0) : R;
      } else {
        return spot <= B ? Math.max(spot - K, 0) : R;
      }
    }

    case 'ASIAN_ARITHMETIC': {
      const avgSpot = extraState.avgSpot ?? spot;
      return Math.max(avgSpot - K, 0);
    }

    case 'SPREAD_BASKET': {
      const S1 = extraState.S1 ?? spot;
      const S2 = extraState.S2 ?? spot;
      const spread = S1 - S2;
      return Math.max(spread - K, 0);
    }

    case 'CUSTOM_DSL': {
      if (!payoff.dslExpression) return Math.max(spot - K, 0);
      try {
        const parser = new DSLParser();
        const ast = parser.parse(payoff.dslExpression);
        return evaluateAST(ast, stateEnv);
      } catch {
        return Math.max(spot - K, 0);
      }
    }

    default:
      return Math.max(spot - K, 0);
  }
}
