/**
 * RhinoQuant Payoff Engine - Safe AST Expression Parser & Evaluator
 */

export type ASTNode =
  | { type: 'NUMBER'; value: number }
  | { type: 'VARIABLE'; name: string }
  | { type: 'BINARY_OP'; operator: '+' | '-' | '*' | '/' | '^' | '>' | '<' | '>=' | '<=' | '=='; left: ASTNode; right: ASTNode }
  | { type: 'FUNCTION_CALL'; functionName: 'max' | 'min' | 'abs' | 'if' | 'indicator' | 'average'; args: ASTNode[] };

export interface ValidationResult {
  isValid: boolean;
  error?: string;
  variablesUsed: string[];
}

export class DSLParser {
  private tokens: string[] = [];
  private current: number = 0;

  private tokenize(expression: string): string[] {
    const regex = /\s*([(),\+\-\*\/\^\>\<\=]+|[a-zA-Z_][a-zA-Z0-9_]*|[0-9]+(?:\.[0-9]+)?)\s*/g;
    const tokens: string[] = [];
    let match: RegExpExecArray | null;

    while ((match = regex.exec(expression)) !== null) {
      if (match[1]) {
        tokens.push(match[1]);
      }
    }
    return tokens;
  }

  public parse(expression: string): ASTNode {
    this.tokens = this.tokenize(expression);
    this.current = 0;
    if (this.tokens.length === 0) {
      return { type: 'NUMBER', value: 0 };
    }
    const node = this.parseExpression();
    if (this.current < this.tokens.length) {
      throw new Error(`Unexpected token '${this.tokens[this.current]}' at position ${this.current}`);
    }
    return node;
  }

  private parseExpression(): ASTNode {
    return this.parseConditional();
  }

  private parseConditional(): ASTNode {
    let left = this.parseAdditive();

    if (this.match('>', '<', '>=', '<=', '==')) {
      const operator = this.previous() as '+' | '-' | '*' | '/' | '^' | '>' | '<' | '>=' | '<=' | '==';
      const right = this.parseAdditive();
      left = { type: 'BINARY_OP', operator, left, right };
    }
    return left;
  }

  private parseAdditive(): ASTNode {
    let left = this.parseMultiplicative();

    while (this.match('+', '-')) {
      const operator = this.previous() as '+' | '-';
      const right = this.parseMultiplicative();
      left = { type: 'BINARY_OP', operator, left, right };
    }
    return left;
  }

  private parseMultiplicative(): ASTNode {
    let left = this.parsePower();

    while (this.match('*', '/')) {
      const operator = this.previous() as '*' | '/';
      const right = this.parsePower();
      left = { type: 'BINARY_OP', operator, left, right };
    }
    return left;
  }

  private parsePower(): ASTNode {
    let left = this.parsePrimary();

    if (this.match('^')) {
      const right = this.parsePower();
      left = { type: 'BINARY_OP', operator: '^', left, right };
    }
    return left;
  }

  private parsePrimary(): ASTNode {
    if (this.match('(')) {
      const expr = this.parseExpression();
      this.consume(')', "Expected ')' after expression.");
      return expr;
    }

    const token = this.peek();

    if (!token) {
      throw new Error("Unexpected end of expression.");
    }

    if (/^[0-9]+(?:\.[0-9]+)?$/.test(token)) {
      this.advance();
      return { type: 'NUMBER', value: parseFloat(token) };
    }

    if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(token)) {
      const name = token;
      this.advance();

      // Check if it's a function call like max(...)
      if (this.match('(')) {
        const args: ASTNode[] = [];
        if (!this.check(')')) {
          do {
            args.push(this.parseExpression());
          } while (this.match(','));
        }
        this.consume(')', "Expected ')' after function arguments.");

        const funcLower = name.toLowerCase();
        if (['max', 'min', 'abs', 'if', 'indicator', 'average'].includes(funcLower)) {
          return {
            type: 'FUNCTION_CALL',
            functionName: funcLower as any,
            args,
          };
        } else {
          throw new Error(`Unsupported function '${name}'. Supported: max, min, abs, if, indicator, average`);
        }
      }

      return { type: 'VARIABLE', name };
    }

    throw new Error(`Unexpected token '${token}'`);
  }

  private match(...types: string[]): boolean {
    for (const type of types) {
      if (this.check(type)) {
        this.advance();
        return true;
      }
    }
    return false;
  }

  private check(type: string): boolean {
    if (this.isAtEnd()) return false;
    return this.peek() === type;
  }

  private advance(): string {
    if (!this.isAtEnd()) this.current++;
    return this.previous();
  }

  private isAtEnd(): boolean {
    return this.current >= this.tokens.length;
  }

  private peek(): string {
    return this.tokens[this.current];
  }

  private previous(): string {
    return this.tokens[this.current - 1];
  }

  private consume(type: string, message: string): string {
    if (this.check(type)) return this.advance();
    throw new Error(message);
  }
}

// AST Validator
export function validateAST(ast: ASTNode): ValidationResult {
  const variablesUsed = new Set<string>();

  function traverse(node: ASTNode) {
    if (node.type === 'VARIABLE') {
      variablesUsed.add(node.name);
    } else if (node.type === 'BINARY_OP') {
      traverse(node.left);
      traverse(node.right);
    } else if (node.type === 'FUNCTION_CALL') {
      for (const arg of node.args) {
        traverse(arg);
      }
    }
  }

  try {
    traverse(ast);
    return {
      isValid: true,
      variablesUsed: Array.from(variablesUsed),
    };
  } catch (err: any) {
    return {
      isValid: false,
      error: err.message,
      variablesUsed: [],
    };
  }
}

// AST Evaluator with state environment variable dictionary (e.g. { S: 105, K: 100, B: 120, A: 1.5, S1: 100, S2: 95 })
export function evaluateAST(ast: ASTNode, env: Record<string, number>): number {
  switch (ast.type) {
    case 'NUMBER':
      return ast.value;

    case 'VARIABLE':
      if (ast.name in env) {
        return env[ast.name];
      }
      // Default fallback if variable missing
      return 0;

    case 'BINARY_OP': {
      const leftVal = evaluateAST(ast.left, env);
      const rightVal = evaluateAST(ast.right, env);
      switch (ast.operator) {
        case '+': return leftVal + rightVal;
        case '-': return leftVal - rightVal;
        case '*': return leftVal * rightVal;
        case '/': return rightVal !== 0 ? leftVal / rightVal : 0;
        case '^': return Math.pow(leftVal, rightVal);
        case '>': return leftVal > rightVal ? 1 : 0;
        case '<': return leftVal < rightVal ? 1 : 0;
        case '>=': return leftVal >= rightVal ? 1 : 0;
        case '<=': return leftVal <= rightVal ? 1 : 0;
        case '==': return Math.abs(leftVal - rightVal) < 1e-9 ? 1 : 0;
      }
      break;
    }

    case 'FUNCTION_CALL': {
      const evaluatedArgs = ast.args.map(arg => evaluateAST(arg, env));
      switch (ast.functionName) {
        case 'max':
          return Math.max(...evaluatedArgs);
        case 'min':
          return Math.min(...evaluatedArgs);
        case 'abs':
          return Math.abs(evaluatedArgs[0] || 0);
        case 'if':
          // if(condition, valIfTrue, valIfFalse)
          return (evaluatedArgs[0] || 0) > 0 ? (evaluatedArgs[1] || 0) : (evaluatedArgs[2] || 0);
        case 'indicator':
          return (evaluatedArgs[0] || 0) > 0 ? 1 : 0;
        case 'average':
          return evaluatedArgs.length > 0
            ? evaluatedArgs.reduce((acc, v) => acc + v, 0) / evaluatedArgs.length
            : 0;
      }
      break;
    }
  }
  return 0;
}
