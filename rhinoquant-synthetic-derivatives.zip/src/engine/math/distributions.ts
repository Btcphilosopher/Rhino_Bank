/**
 * RhinoQuant Math Engine - Statistical Distributions & Quasi-Random Sequences
 */

// Cumulative Normal Distribution (Abramowitz & Stegun approximation)
export function normalCDF(x: number): number {
  if (x < -10) return 0;
  if (x > 10) return 1;

  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.SQRT2;

  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t) * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

const SQRT2PI = Math.sqrt(2 * Math.PI);

// Probability Density Function of Standard Normal
export function normalPDF(x: number): number {
  return Math.exp(-0.5 * x * x) / SQRT2PI;
}

// Inverse Standard Normal CDF (Acklam's algorithm)
export function inverseNormalCDF(p: number): number {
  if (p <= 0 || p >= 1) {
    if (p <= 0) return -8.0;
    if (p >= 1) return 8.0;
  }

  // Coefficients in rational approximations
  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.383577518672690e2, -3.066479806614716e1, 2.506628277459239e0];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838e0, -2.549732539343734e0, 4.374664141464968e0, 2.938163982698783e0];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996e0, 3.754408661907416e0];

  const pLow = 0.02425;
  const pHigh = 1 - pLow;

  let q: number, r: number;

  if (p < pLow) {
    // Rational approximation for lower region
    q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  } else if (p <= pHigh) {
    // Rational approximation for central region
    q = p - 0.5;
    r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  } else {
    // Rational approximation for upper region
    q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
}

// Pseudo-random linear congruential generator for reproducible seeds
export class SeededRandom {
  private state: number;

  constructor(seed: number = 20260926) {
    this.state = seed % 2147483647;
    if (this.state <= 0) this.state += 2147483646;
  }

  public nextFloat(): number {
    this.state = (this.state * 16807) % 2147483647;
    return (this.state - 1) / 2147483646;
  }

  // Box-Muller transform for standard normal variate N(0, 1)
  public nextNormal(): number {
    let u1 = this.nextFloat();
    let u2 = this.nextFloat();
    while (u1 <= 1e-12) u1 = this.nextFloat();
    return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  }
}

// Sobol Quasi-Random Generator (1D / low discrepancy)
export class SobolSequence1D {
  private count: number = 0;

  public next(): number {
    this.count++;
    let v = 0;
    let mask = 1;
    let i = this.count;
    let bit = 1;

    while (i > 0) {
      if (i & 1) {
        v ^= 1 / (1 << bit);
      }
      i >>= 1;
      bit++;
    }
    return (v + 0.5) / 2; // Returns low-discrepancy value in (0, 1)
  }
}
