/**
 * RhinoQuant Math Engine - Linear Algebra & Matrix Operations
 */

import { matrix, multiply, transpose, eigs } from 'mathjs';

// Matrix multiplication
export function multiplyMatrices(A: number[][], B: number[][]): number[][] {
  const m = A.length;
  const n = A[0].length;
  const p = B[0].length;
  const C: number[][] = Array.from({ length: m }, () => Array(p).fill(0));

  for (let i = 0; i < m; i++) {
    for (let k = 0; k < n; k++) {
      for (let j = 0; j < p; j++) {
        C[i][j] += A[i][k] * B[k][j];
      }
    }
  }
  return C;
}

// Compute Eigenvalues of a Symmetric Matrix (using Jacobi algorithm for robustness)
export function computeSymmetricEigenvalues(mat: number[][]): { values: number[]; vectors: number[][] } {
  const n = mat.length;
  let A = mat.map(row => [...row]);
  let V: number[][] = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))
  );

  const maxIter = 100;
  const eps = 1e-10;

  for (let iter = 0; iter < maxIter; iter++) {
    let maxOff = 0;
    let p = 0;
    let q = 1;

    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        if (Math.abs(A[i][j]) > maxOff) {
          maxOff = Math.abs(A[i][j]);
          p = i;
          q = j;
        }
      }
    }

    if (maxOff < eps) break;

    const diff = A[q][q] - A[p][p];
    let t: number;
    if (Math.abs(A[p][q]) < eps) {
      t = 0;
    } else {
      const phi = diff / (2 * A[p][q]);
      t = 1 / (Math.abs(phi) + Math.sqrt(phi * phi + 1));
      if (phi < 0) t = -t;
    }

    const c = 1 / Math.sqrt(t * t + 1);
    const s = t * c;
    const tau = s / (1 + c);

    const temp = A[p][q];
    A[p][q] = 0;
    A[q][p] = 0;
    A[p][p] -= t * temp;
    A[q][q] += t * temp;

    for (let i = 0; i < n; i++) {
      if (i !== p && i !== q) {
        const g = A[i][p];
        const h = A[i][q];
        A[i][p] = g - s * (h + g * tau);
        A[p][i] = A[i][p];
        A[i][q] = h + s * (g - h * tau);
        A[q][i] = A[i][q];
      }
    }

    for (let i = 0; i < n; i++) {
      const g = V[i][p];
      const h = V[i][q];
      V[i][p] = g - s * (h + g * tau);
      V[i][q] = h + s * (g - h * tau);
    }
  }

  const values = Array.from({ length: n }, (_, i) => A[i][i]);
  return { values, vectors: V };
}

// Check if a symmetric matrix is positive-definite (all eigenvalues > 0)
export function isPositiveDefinite(mat: number[][]): { isPD: boolean; minEigenvalue: number; eigenvalues: number[] } {
  const { values } = computeSymmetricEigenvalues(mat);
  const minVal = Math.min(...values);
  return {
    isPD: minVal > 1e-8,
    minEigenvalue: minVal,
    eigenvalues: values.sort((a, b) => b - a),
  };
}

// Project matrix to nearest Positive Semi-Definite (PSD) correlation matrix (Clipping negative eigenvalues & re-scaling diagonal)
export function makePSDCorrelationMatrix(mat: number[][]): number[][] {
  const n = mat.length;
  const { values, vectors } = computeSymmetricEigenvalues(mat);

  // Clip negative eigenvalues to small positive epsilon
  const clippedValues = values.map(val => Math.max(val, 1e-6));

  // Reconstruct matrix: V * D_clipped * V^T
  const reconstructed: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      let sum = 0;
      for (let k = 0; k < n; k++) {
        sum += vectors[i][k] * clippedValues[k] * vectors[j][k];
      }
      reconstructed[i][j] = sum;
    }
  }

  // Normalize diagonal to exactly 1.0 (correlation matrix property)
  const result: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i === j) {
        result[i][j] = 1.0;
      } else {
        const denom = Math.sqrt(reconstructed[i][i] * reconstructed[j][j]);
        result[i][j] = denom > 0 ? Math.min(1.0, Math.max(-1.0, reconstructed[i][j] / denom)) : 0;
      }
    }
  }

  return result;
}

// Cholesky Decomposition for correlated Gaussian random variable sampling
export function choleskyDecomposition(mat: number[][]): number[][] {
  const n = mat.length;
  const L: number[][] = Array.from({ length: n }, () => Array(n).fill(0));

  for (let i = 0; i < n; i++) {
    for (let j = 0; j <= i; j++) {
      let sum = 0;
      for (let k = 0; k < j; k++) {
        sum += L[i][k] * L[j][k];
      }

      if (i === j) {
        const val = mat[i][i] - sum;
        L[i][j] = val > 0 ? Math.sqrt(val) : 1e-6;
      } else {
        L[i][j] = L[j][j] > 0 ? (mat[i][j] - sum) / L[j][j] : 0;
      }
    }
  }

  return L;
}
