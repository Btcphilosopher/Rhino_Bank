/**
 * RhinoQuant Math Engine - Curve & Term Structure Interpolation
 */

export function interpolateLinear(xs: number[], ys: number[], x: number): number {
  if (xs.length === 0) return 0;
  if (x <= xs[0]) return ys[0];
  if (x >= xs[xs.length - 1]) return ys[ys.length - 1];

  for (let i = 0; i < xs.length - 1; i++) {
    if (x >= xs[i] && x <= xs[i + 1]) {
      const t = (x - xs[i]) / (xs[i + 1] - xs[i]);
      return ys[i] + t * (ys[i + 1] - ys[i]);
    }
  }
  return ys[ys.length - 1];
}

export function interpolateLogLinear(xs: number[], ys: number[], x: number): number {
  // Useful for discount factor curves DF(t) = exp(-r*t)
  if (xs.length === 0) return 1;
  if (x <= xs[0]) return ys[0];
  if (x >= xs[xs.length - 1]) return ys[ys.length - 1];

  const logYs = ys.map(y => Math.log(Math.max(y, 1e-10)));
  const logVal = interpolateLinear(xs, logYs, x);
  return Math.exp(logVal);
}

// Monotonic Cubic Hermite Spline (Fritsch-Carlson)
export function interpolateMonotonicCubic(xs: number[], ys: number[], x: number): number {
  const n = xs.length;
  if (n === 0) return 0;
  if (n === 1) return ys[0];
  if (x <= xs[0]) return ys[0];
  if (x >= xs[n - 1]) return ys[n - 1];

  // Secant slopes
  const dxs: number[] = [];
  const dys: number[] = [];
  const ms: number[] = [];

  for (let i = 0; i < n - 1; i++) {
    const dx = xs[i + 1] - xs[i];
    const dy = ys[i + 1] - ys[i];
    dxs.push(dx);
    dys.push(dy);
    ms.push(dy / dx);
  }

  // Tangents
  const c1s: number[] = [ms[0]];
  for (let i = 0; i < n - 2; i++) {
    const m = ms[i];
    const mNext = ms[i + 1];
    if (m * mNext <= 0) {
      c1s.push(0);
    } else {
      const dx_sum = dxs[i] + dxs[i + 1];
      c1s.push((3 * dx_sum) / ((dx_sum + dxs[i + 1]) / m + (dx_sum + dxs[i]) / mNext));
    }
  }
  c1s.push(ms[ms.length - 1]);

  // Find interval
  let idx = 0;
  for (let i = 0; i < n - 1; i++) {
    if (x >= xs[i] && x <= xs[i + 1]) {
      idx = i;
      break;
    }
  }

  const h = dxs[idx];
  const t = (x - xs[idx]) / h;
  const t2 = t * t;
  const t3 = t2 * t;

  const h00 = 2 * t3 - 3 * t2 + 1;
  const h10 = t3 - 2 * t2 + t;
  const h01 = -2 * t3 + 3 * t2;
  const h11 = t3 - t2;

  return h00 * ys[idx] + h10 * h * c1s[idx] + h01 * ys[idx + 1] + h11 * h * c1s[idx + 1];
}
