/**
 * RhinoQuant Synthetic Derivatives - Institutional Domain Types
 */

export type AssetClass = 'COMMODITY' | 'FX' | 'RATES' | 'EQUITY' | 'CREDIT' | 'FREIGHT' | 'ENERGY';

export interface MarketAsset {
  id: string;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  spotPrice: number;
  currency: string;
  historicalVol: number; // Annualized
  drift: number;
  unit: string;
  lastUpdated: string;
}

export type WeightingMethod =
  | 'EQUAL'
  | 'MARKET'
  | 'VOLATILITY'
  | 'INVERSE_VOLATILITY'
  | 'RISK'
  | 'CUSTOM';

export interface ComponentWeight {
  assetId: string;
  weight: number;
}

export interface SyntheticUnderlying {
  id: string;
  name: string;
  code: string;
  description: string;
  weightingMethod: WeightingMethod;
  components: ComponentWeight[];
  baseCurrency: string;
}

export interface CurvePoint {
  tenor: string; // e.g., '1M', '3M', '6M', '1Y', '2Y', '5Y', '10Y'
  days: number;
  rate: number; // e.g. 0.0425 for 4.25%
  discountFactor: number;
  forwardRate?: number;
}

export type CurveInterpolation = 'LINEAR' | 'LOG_LINEAR' | 'CUBIC_SPLINE' | 'HERMITE' | 'MONOTONIC_CUBIC';

export interface MarketCurve {
  id: string;
  name: string;
  currency: string;
  type: 'DISCOUNT' | 'ZERO_YIELD' | 'COMMODITY_FORWARD' | 'FX_FORWARD' | 'CREDIT_SPREAD';
  interpolation: CurveInterpolation;
  points: CurvePoint[];
}

export interface VolatilityPoint {
  expiry: number; // Years, e.g. 0.25, 0.5, 1.0, 2.0
  strike: number;
  impliedVol: number; // e.g. 0.25 for 25%
  delta?: number;
}

export interface VolatilitySurfaceData {
  id: string;
  underlyingId: string;
  expiries: number[];
  strikes: number[];
  matrix: number[][]; // [expiryIndex][strikeIndex] = impliedVol
  sabrParams?: {
    alpha: number;
    beta: number;
    rho: number;
    nu: number;
  };
}

export interface CorrelationMatrixData {
  id: string;
  assetIds: string[];
  matrix: number[][];
  isPositiveDefinite: boolean;
  eigenvalues: number[];
  timestamp: string;
}

export type PrimitiveType =
  | 'SPOT'
  | 'FORWARD'
  | 'FUTURE'
  | 'SWAP'
  | 'OPTION_CALL'
  | 'OPTION_PUT'
  | 'DIGITAL_CALL'
  | 'DIGITAL_PUT'
  | 'BARRIER'
  | 'ASIAN'
  | 'SPREAD'
  | 'SWAPTION'
  | 'CAP'
  | 'FLOOR'
  | 'COLLAR';

export type PayoffType =
  | 'VANILLA_CALL'
  | 'VANILLA_PUT'
  | 'DIGITAL_DIGIT'
  | 'BARRIER_KNOCK_OUT'
  | 'BARRIER_KNOCK_IN'
  | 'ASIAN_ARITHMETIC'
  | 'SPREAD_BASKET'
  | 'CUSTOM_DSL';

export interface PayoffDefinition {
  type: PayoffType;
  strike?: number;
  barrier?: number;
  barrierType?: 'UP_AND_OUT' | 'DOWN_AND_OUT' | 'UP_AND_IN' | 'DOWN_AND_IN';
  rebate?: number;
  dslExpression?: string; // e.g. "max(S - K, 0)"
  floorStrike?: number;
  capStrike?: number;
  digitalPayout?: number;
  asianAveragingDays?: number;
}

export interface ScheduleDefinition {
  issueDate: string;
  valuationDate: string;
  maturityDate: string;
  timeToMaturityYears: number;
  paymentFrequency: 'AT_MATURITY' | 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL';
}

export type MarketModelType =
  | 'GBM'
  | 'BLACK_76'
  | 'BACHELIER'
  | 'LOCAL_VOL'
  | 'STOCHASTIC_VOL_HESTON'
  | 'HULL_WHITE'
  | 'MERTON_JUMP';

export type PricingModelType =
  | 'ANALYTICAL'
  | 'BINOMIAL_TREE'
  | 'TRINOMIAL_TREE'
  | 'MONTE_CARLO'
  | 'SURROGATE';

export interface SyntheticDerivative {
  id: string;
  code: string;
  name: string;
  category: string;
  currency: string;
  notional: number;
  underlying: SyntheticUnderlying;
  payoff: PayoffDefinition;
  schedule: ScheduleDefinition;
  marketModel: MarketModelType;
  pricingModel: PricingModelType;
  discountCurveId: string;
  volatilitySurfaceId: string;
  correlationMatrixId?: string;
  settlementType: 'CASH' | 'PHYSICAL';
  status: 'ACTIVE' | 'DRAFT' | 'EXPIRED';
  auditVersion: string;
}

export interface Greeks {
  delta: number;
  gamma: number;
  vega: number; // per 1% vol change
  theta: number; // per calendar day
  rho: number; // per 1% interest rate change
  dv01: number;
  cs01: number;
  vanna: number;
  volga: number;
  correlationSensitivity: number;
}

export type AnalyticalPricingResult = Greeks & { price: number };

export interface MonteCarloResult {
  paths: number;
  steps: number;
  price: number;
  standardError: number;
  confidenceInterval95: [number, number];
  distribution: {
    mean: number;
    median: number;
    stdDev: number;
    var95: number;
    expectedShortfall95: number;
    skewness: number;
    kurtosis: number;
    min: number;
    max: number;
    histogramBins: { bin: number; count: number }[];
  };
  seed: number;
  executionTimeMs: number;
}

export interface PricingResult {
  valuationId: string;
  derivativeId: string;
  timestamp: string;
  price: number;
  unitPrice: number; // Percentage or price per notional
  modelUsed: PricingModelType;
  marketModelUsed: MarketModelType;
  greeks: Greeks;
  monteCarloDetails?: MonteCarloResult;
  isSurrogate: boolean;
  surrogateErrorMsE?: number;
  auditTrail: PricingAuditTrail;
}

export interface PricingAuditTrail {
  valuationId: string;
  timestamp: string;
  marketSnapshotId: string;
  derivativeCode: string;
  model: PricingModelType;
  marketModel: MarketModelType;
  parameters: Record<string, number | string | boolean>;
  discountCurveVersion: string;
  volatilitySurfaceVersion: string;
  correlationMatrixVersion?: string;
  randomSeed: number;
  engineVersion: string;
}

export interface PnLAttribution {
  derivativeId: string;
  valuationDate: string;
  totalPnL: number;
  deltaPnL: number;
  gammaPnL: number;
  vegaPnL: number;
  thetaCarryPnL: number;
  curvePnL: number;
  fxPnL: number;
  correlationPnL: number;
  residualPnL: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  spotShiftPercent: number;
  volShiftPercent: number;
  rateShiftBp: number;
  correlationShiftPercent: number;
  fxShiftPercent: number;
  isHistorical: boolean;
}

export interface StressTestResult {
  scenarioId: string;
  scenarioName: string;
  baseValue: number;
  stressedValue: number;
  pnlImpact: number;
  percentageChange: number;
  greeksImpact: Partial<Greeks>;
}

export interface PortfolioPosition {
  derivative: SyntheticDerivative;
  quantity: number;
  entryPrice: number;
  currentValue: number;
  unrealizedPnL: number;
}

export interface FactorExposure {
  factorName: string;
  assetClass: AssetClass;
  exposureValue: number;
  percentageOfRisk: number;
}

export interface PortfolioSummary {
  portfolioId: string;
  name: string;
  totalNotional: number;
  totalMarketValue: number;
  totalUnrealizedPnL: number;
  consolidatedGreeks: Greeks;
  var95: number;
  expectedShortfall95: number;
  factorExposures: FactorExposure[];
  positions: PortfolioPosition[];
}

export interface ReverseEngineeringTarget {
  targetPayoffType: PayoffType;
  maxDownside: number;
  desiredUpside: 'UNCAPPED' | 'CAPPED' | 'TARGET_PERCENT';
  targetMaturityYears: number;
  primaryExposure: string;
  secondaryExposure: string;
}

export interface ReverseEngineeringCandidate {
  id: string;
  title: string;
  construction: string;
  primitives: { type: PrimitiveType; weight: number; strike?: number }[];
  residualFitError: number;
  estimatedPrice: number;
  maxLoss: number;
  maxGain: string;
  greeks: Greeks;
}
