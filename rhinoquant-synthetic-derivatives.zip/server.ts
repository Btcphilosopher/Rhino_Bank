/**
 * RhinoQuant Express Full-Stack Server
 */

import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { SyntheticMarketSimulator } from './src/engine/market/marketData';
import { SIGNATURE_DERIVATIVES, INITIAL_PORTFOLIO_POSITIONS } from './src/data/seedData';
import { calculatePortfolioSummary } from './src/engine/portfolio/portfolioEngine';
import { runMonteCarloSimulation } from './src/engine/pricing/monteCarlo';
import { priceBlackScholes } from './src/engine/pricing/blackScholes';
import { runStressTest, PRESET_STRESS_SCENARIOS, generateScenarioMatrixGrid } from './src/engine/stress/stressEngine';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const marketSim = new SyntheticMarketSimulator(20260926);

// Initialize Gemini Client if API Key exists
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  aiClient = new GoogleGenAI({ apiKey });
}

// REST API v1 Routes
app.get('/api/v1/health', (_req, res) => {
  res.json({ status: 'OK', engineVersion: 'RhinoQuant-v3.6-RQ', timestamp: new Date().toISOString() });
});

app.get('/api/v1/markets', (_req, res) => {
  res.json({ assets: marketSim.getMarketAssets() });
});

app.get('/api/v1/curves', (_req, res) => {
  res.json({ curves: marketSim.getCurves() });
});

app.get('/api/v1/volatility', (req, res) => {
  const assetId = (req.query.underlyingId as string) || 'COPPER';
  res.json({ volSurface: marketSim.getVolatilitySurface(assetId) });
});

app.get('/api/v1/correlation', (_req, res) => {
  res.json({ correlationMatrix: marketSim.getCorrelationMatrix() });
});

app.get('/api/v1/synthetics', (_req, res) => {
  res.json({ derivatives: SIGNATURE_DERIVATIVES });
});

app.post('/api/v1/pricing', (req, res) => {
  const { derivativeId, model, paths } = req.body;
  const derivative = SIGNATURE_DERIVATIVES.find(d => d.id === derivativeId) || SIGNATURE_DERIVATIVES[0];

  const mcResult = runMonteCarloSimulation(derivative, 9850, 0.24, 0.0425, paths || 50000, 52, 20260926);
  res.json({
    valuationId: `VAL-${Date.now()}`,
    derivativeCode: derivative.code,
    price: mcResult.price,
    greeks: mcResult.greeks,
    details: mcResult.details,
  });
});

app.post('/api/v1/stress', (req, res) => {
  const { scenarioId } = req.body;
  const scenario = PRESET_STRESS_SCENARIOS.find(s => s.id === scenarioId) || PRESET_STRESS_SCENARIOS[0];

  const bs = priceBlackScholes(9850, 9850, 1.0, 0.0425, 0.24, true);
  const result = runStressTest(bs.price, bs, scenario);
  res.json({ stressTestResult: result });
});

app.get('/api/v1/portfolios', (_req, res) => {
  const summary = calculatePortfolioSummary(INITIAL_PORTFOLIO_POSITIONS);
  res.json({ portfolio: summary });
});

// Gemini Quantitative AI Assistant Route
app.post('/api/v1/research/ai', async (req, res) => {
  const { prompt, context } = req.body;

  if (!aiClient) {
    // Fallback response if GEMINI_API_KEY is placeholder
    return res.json({
      reply: `[RhinoQuant Research Assistant - Offline Mode]\nAnalysis of your derivative question "${prompt}":\n- Constructing synthetic instrument with strike K=$9,850.\n- Recommended Market Model: Heston Stochastic Volatility or Multi-Asset Monte Carlo.\n- Sensitivity: Vega risk is highest around 1.0Y maturity expiration.`,
    });
  }

  try {
    const response = await aiClient.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are the lead Quantitative Finance AI Research Assistant for RhinoQuant Synthetic Derivatives platform.
Context: ${JSON.stringify(context || {})}
User Query: ${prompt}

Provide precise, quantitative, institutional-grade feedback covering payoff structure, pricing model selection, Greeks decomposition, and stress scenario recommendations. Keep formatting clear and compact.`,
    });

    res.json({ reply: response.text });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Gemini API Error' });
  }
});

// Vite Middleware for Dev / Production Static File Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
