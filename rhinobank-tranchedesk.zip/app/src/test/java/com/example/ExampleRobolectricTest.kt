package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AccountBalances
import com.example.data.model.InstrumentType
import com.example.data.model.QuantityBasis
import com.example.data.model.RatingTier
import com.example.data.model.RfqSide
import com.example.data.model.TradeState
import com.example.data.model.TradeType
import com.example.data.repository.TrancheDeskRepository
import com.example.engine.CheckStatus
import com.example.engine.PreTradeControls
import com.example.engine.TrancheWorksAdapter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RhinoBank TrancheDesk", appName)
    }

    @Test
    fun `verify consideration arithmetic prevents double factor application`() {
        val factor = 0.9700
        val price = 96.42
        val originalFace = 5_000_000.0

        // Consideration = originalFace * factor * (price / 100)
        val considerationOrigBasis = TrancheWorksAdapter.calculateConsideration(
            enteredFace = originalFace,
            principalFactor = factor,
            pricePer100 = price,
            basis = QuantityBasis.ORIGINAL_FACE
        )

        val currentFace = originalFace * factor // 4,850,000.0
        val considerationCurrBasis = TrancheWorksAdapter.calculateConsideration(
            enteredFace = currentFace,
            principalFactor = factor,
            pricePer100 = price,
            basis = QuantityBasis.CURRENT_FACE
        )

        assertEquals(considerationOrigBasis, considerationCurrBasis, 0.001)
        assertEquals(4_676_370.0, considerationOrigBasis, 1.0)
    }

    @Test
    fun `verify RFQ quote expiry and execution constraints`() {
        val repository = TrancheDeskRepository()
        val rfq = repository.broadcastRfq(
            instrumentId = "RHN-24-1-C",
            instrumentType = InstrumentType.CASH_CDO_NOTE,
            side = RfqSide.OFFER_WANTED,
            requestedQuantity = 10_000_000.0,
            quantityBasis = QuantityBasis.ORIGINAL_FACE,
            permittedDealers = listOf("Goldman Sachs", "Rhino Securities")
        )

        assertEquals(2, rfq.quotes.size)
        val quote = rfq.quotes.first()

        // Partial execute 5,000,000
        val trade = repository.acceptAndExecuteQuote(
            rfqId = rfq.id,
            quoteId = quote.id,
            executedQuantity = 5_000_000.0,
            riskOfficerSignoff = true
        )
        assertNotNull(trade)
        assertEquals(TradeState.EXECUTED, trade?.state)

        // Prevent duplicate execution on already filled RFQ
        val duplicateTrade = repository.acceptAndExecuteQuote(
            rfqId = rfq.id,
            quoteId = quote.id,
            executedQuantity = 5_000_000.0
        )
        assertTrue(duplicateTrade == null)
    }

    @Test
    fun `verify settlement DVP state machine and cash clearing`() {
        val repository = TrancheDeskRepository()
        val initialCash = repository.accountBalances.value.cashBalance

        val rfq = repository.broadcastRfq(
            instrumentId = "RHN-24-1-C",
            instrumentType = InstrumentType.CASH_CDO_NOTE,
            side = RfqSide.OFFER_WANTED,
            requestedQuantity = 2_000_000.0,
            quantityBasis = QuantityBasis.ORIGINAL_FACE,
            permittedDealers = listOf("Goldman Sachs")
        )
        val quote = rfq.quotes.first()
        val trade = repository.acceptAndExecuteQuote(rfq.id, quote.id, 2_000_000.0, true)
        assertNotNull(trade)

        // Trade is in EXECUTED state
        assertEquals(TradeState.EXECUTED, trade!!.state)

        // Electronic confirmation affirmation
        val affirmed = repository.affirmTrade(trade.tradeId)
        assertTrue(affirmed)
        val confirmedTrade = repository.trades.value.find { it.tradeId == trade.tradeId }
        assertEquals(TradeState.CONFIRMED, confirmedTrade?.state)

        // Settle DVP
        val settled = repository.settleTrade(trade.tradeId)
        assertTrue(settled)
        val settledTrade = repository.trades.value.find { it.tradeId == trade.tradeId }
        assertEquals(TradeState.SETTLED, settledTrade?.state)

        // Cash was deducted
        val cashAfter = repository.accountBalances.value.cashBalance
        assertTrue(cashAfter < initialCash)
    }

    @Test
    fun `verify tripartite novation consent workflow`() {
        val repository = TrancheDeskRepository()
        val nov = repository.createNovationRequest(
            tradeRef = "TRD-001",
            transferee = "Rhino Apex Credit Fund II",
            remainingParty = "Morgan Stanley"
        )
        assertFalse(nov.allContractualConsentsSatisfied)

        repository.grantNovationDealerConsent(nov.novationId)
        var updated = repository.novations.value.find { it.novationId == nov.novationId }
        assertTrue(updated!!.dealerConsentGranted)
        assertFalse(updated.allContractualConsentsSatisfied)

        repository.grantNovationCalcAgentConsent(nov.novationId)
        updated = repository.novations.value.find { it.novationId == nov.novationId }
        assertTrue(updated!!.allContractualConsentsSatisfied)

        val finalized = repository.finalizeNovationTransfer(nov.novationId)
        assertTrue(finalized)
    }
}
