package com.example.engine

import com.example.data.model.AccountBalances
import com.example.data.model.CashNote
import com.example.data.model.CounterpartyExposure
import com.example.data.model.PositionRecord
import com.example.data.model.SyntheticTranche
import com.example.data.model.TradeType
import com.example.data.model.TransferRestriction

enum class CheckStatus {
    PASSED,
    WARNING,
    FAILED,
    REQUIRES_APPROVAL
}

data class ControlCheck(
    val id: String,
    val name: String,
    val description: String,
    val status: CheckStatus,
    val detailValue: String
)

data class PreTradeValidationResult(
    val canExecute: Boolean,
    val requiresRiskOfficerApproval: Boolean,
    val checks: List<ControlCheck>,
    val projectedCashAfter: Double,
    val projectedDealerExposureAfter: Double,
    val projectedTrancheExposureAfter: Double,
    val projectedConcentrationPct: Double
)

object PreTradeControls {

    private const val MAX_TRANCHE_LIMIT = 25_000_000.0
    private const val MAX_DEALER_LIMIT = 100_000_000.0
    private const val MAX_CONCENTRATION_PCT = 25.0
    private const val RISK_OFFICER_APPROVAL_THRESHOLD = 10_000_000.0

    fun validateCashTrade(
        note: CashNote,
        tradeType: TradeType,
        tradedCurrentFace: Double,
        totalConsideration: Double,
        counterparty: String,
        accountBalances: AccountBalances,
        existingPositions: List<PositionRecord>,
        existingDealerExposures: List<CounterpartyExposure>,
        userIsQibCertified: Boolean = true,
        riskOfficerSignedOff: Boolean = false
    ): PreTradeValidationResult {
        val checks = mutableListOf<ControlCheck>()

        // 1. Account Permissions
        checks.add(
            ControlCheck(
                id = "CHK_ACCT_PERM",
                name = "Account Trading Permissions",
                description = "Institutional Mandate Tier-1 Secondary Trading Authorization",
                status = CheckStatus.PASSED,
                detailValue = "Authorized (Account: ${accountBalances.accountId})"
            )
        )

        // 2. Instrument Eligibility
        val isEligible = !note.isDistressed || note.rating.name.contains("MEZZ") || note.rating.name.contains("A")
        checks.add(
            ControlCheck(
                id = "CHK_ELIGIBILITY",
                name = "Instrument Eligibility",
                description = "Fund Mandate Eligible Structured Credit Instrument",
                status = if (isEligible) CheckStatus.PASSED else CheckStatus.WARNING,
                detailValue = if (isEligible) "Eligible (Sec Type: ${note.rating})" else "Restricted (OC Breach Warning)"
            )
        )

        // 3. Transfer Restrictions (Rule 144A QIB)
        val has144A = note.transferRestrictions.contains(TransferRestriction.RULE_144A_QIB)
        val qibPassed = !has144A || userIsQibCertified
        checks.add(
            ControlCheck(
                id = "CHK_144A_QIB",
                name = "Transfer Restrictions",
                description = "Rule 144A Qualified Institutional Buyer Verification",
                status = if (qibPassed) CheckStatus.PASSED else CheckStatus.FAILED,
                detailValue = if (qibPassed) "Verified QIB Entity Active" else "Fails QIB Institutional Requirement"
            )
        )

        // 4. Available Cash / Available Holdings
        var cashOrHoldingPassed = true
        var projectedCash = accountBalances.availableCash
        if (tradeType == TradeType.CASH_BUY) {
            projectedCash -= totalConsideration
            cashOrHoldingPassed = projectedCash >= 0
            checks.add(
                ControlCheck(
                    id = "CHK_CASH_AVAIL",
                    name = "Available Cash Balance",
                    description = "Sufficient settled unencumbered cash for DVP settlement",
                    status = if (cashOrHoldingPassed) CheckStatus.PASSED else CheckStatus.FAILED,
                    detailValue = "Req: $${formatAmount(totalConsideration)} | Avail: $${formatAmount(accountBalances.availableCash)}"
                )
            )
        } else {
            // Sell check
            val existingHolding = existingPositions.find { it.instrumentId == note.trancheId }?.settledCurrentFace ?: 0.0
            val hasHolding = existingHolding >= tradedCurrentFace
            cashOrHoldingPassed = hasHolding
            checks.add(
                ControlCheck(
                    id = "CHK_HOLDING_AVAIL",
                    name = "Available Holdings Check",
                    description = "Holding verification for delivery (No unborrowed shorts)",
                    status = if (hasHolding) CheckStatus.PASSED else CheckStatus.FAILED,
                    detailValue = "Sell Req: $${formatAmount(tradedCurrentFace)} | Position: $${formatAmount(existingHolding)}"
                )
            )
        }

        // 5. Position & Tranche Limit
        val currentTranchePosition = existingPositions.find { it.instrumentId == note.trancheId }?.settledCurrentFace ?: 0.0
        val projectedTrancheExposure = if (tradeType == TradeType.CASH_BUY) currentTranchePosition + tradedCurrentFace else (currentTranchePosition - tradedCurrentFace).coerceAtLeast(0.0)
        val trancheLimitPassed = projectedTrancheExposure <= MAX_TRANCHE_LIMIT
        checks.add(
            ControlCheck(
                id = "CHK_TRANCHE_LIMIT",
                name = "Tranche Position Limit",
                description = "Maximum $25M notional exposure per individual CDO tranche",
                status = if (trancheLimitPassed) CheckStatus.PASSED else CheckStatus.FAILED,
                detailValue = "Projected: $${formatAmount(projectedTrancheExposure)} / $25M Limit"
            )
        )

        // 6. Counterparty Limit ($100M)
        val existingDealerExp = existingDealerExposures.find { it.counterparty == counterparty }?.netExposure ?: 0.0
        val projectedDealerExp = existingDealerExp + totalConsideration
        val dealerLimitPassed = projectedDealerExp <= MAX_DEALER_LIMIT
        checks.add(
            ControlCheck(
                id = "CHK_CPTY_LIMIT",
                name = "Counterparty Limit ($counterparty)",
                description = "Maximum $100M aggregate exposure per dealer",
                status = if (dealerLimitPassed) CheckStatus.PASSED else CheckStatus.FAILED,
                detailValue = "Projected: $${formatAmount(projectedDealerExp)} / $100M Limit"
            )
        )

        // 7. Concentration Check (<= 25% of Portfolio NAV)
        val projectedNav = accountBalances.totalNav
        val projectedConcentration = if (projectedNav > 0) (projectedTrancheExposure / projectedNav) * 100.0 else 0.0
        val concentrationPassed = projectedConcentration <= MAX_CONCENTRATION_PCT
        checks.add(
            ControlCheck(
                id = "CHK_CONCENTRATION",
                name = "Portfolio Concentration",
                description = "Single-tranche concentration capped at 25% of Fund NAV",
                status = if (concentrationPassed) CheckStatus.PASSED else CheckStatus.WARNING,
                detailValue = "Projected: ${String.format("%.1f", projectedConcentration)}% (Max 25.0%)"
            )
        )

        // 8. Settlement Readiness (SSI)
        checks.add(
            ControlCheck(
                id = "CHK_SSI_READINESS",
                name = "Settlement Instructions (SSI)",
                description = "Euroclear / DTC standard settlement instructions validated",
                status = CheckStatus.PASSED,
                detailValue = "SSI Active (RHINO-SEC-BRU-9402)"
            )
        )

        // 9. Required Approvals (> $10M requires Risk Officer signoff)
        val requiresApproval = totalConsideration >= RISK_OFFICER_APPROVAL_THRESHOLD
        val approvalPassed = !requiresApproval || riskOfficerSignedOff
        checks.add(
            ControlCheck(
                id = "CHK_RISK_APPROVAL",
                name = "Institutional Risk Officer Sign-off",
                description = "Mandatory sign-off for single-ticket consideration exceeding $10M",
                status = when {
                    !requiresApproval -> CheckStatus.PASSED
                    riskOfficerSignedOff -> CheckStatus.PASSED
                    else -> CheckStatus.REQUIRES_APPROVAL
                },
                detailValue = when {
                    !requiresApproval -> "Not required (< $10M threshold)"
                    riskOfficerSignedOff -> "Approved by Chief Risk Officer"
                    else -> "PENDING SIGN-OFF (Consideration: $${formatAmount(totalConsideration)})"
                }
            )
        )

        val anyFailed = checks.any { it.status == CheckStatus.FAILED }
        val canExecute = !anyFailed && approvalPassed

        return PreTradeValidationResult(
            canExecute = canExecute,
            requiresRiskOfficerApproval = requiresApproval && !riskOfficerSignedOff,
            checks = checks,
            projectedCashAfter = projectedCash,
            projectedDealerExposureAfter = projectedDealerExp,
            projectedTrancheExposureAfter = projectedTrancheExposure,
            projectedConcentrationPct = projectedConcentration
        )
    }

    fun validateSyntheticTrade(
        tranche: SyntheticTranche,
        tradeType: TradeType,
        tradedNotional: Double,
        counterparty: String,
        accountBalances: AccountBalances,
        existingDealerExposures: List<CounterpartyExposure>,
        riskOfficerSignedOff: Boolean = false
    ): PreTradeValidationResult {
        val checks = mutableListOf<ControlCheck>()

        // 1. Account Permissions for Derivatives
        checks.add(
            ControlCheck(
                id = "CHK_SYN_PERM",
                name = "Derivative Authority",
                description = "ISDA Master Agreement & Schedule active with $counterparty",
                status = CheckStatus.PASSED,
                detailValue = "ISDA 2002 Bilateral Active"
            )
        )

        // 2. Collateral / Margin Check
        val initialMargin = TrancheWorksAdapter.calculateInitialMargin(tradedNotional, tranche.initialMarginPct)
        val marginAvailable = accountBalances.availableCash >= initialMargin
        checks.add(
            ControlCheck(
                id = "CHK_SYN_MARGIN",
                name = "Initial Margin Requirement (CSA)",
                description = "Cash collateral posting for ${tranche.initialMarginPct}% initial margin",
                status = if (marginAvailable) CheckStatus.PASSED else CheckStatus.FAILED,
                detailValue = "Req Margin: $${formatAmount(initialMargin)} | Avail: $${formatAmount(accountBalances.availableCash)}"
            )
        )

        // 3. Counterparty Exposure & Limits
        val existingDealerExp = existingDealerExposures.find { it.counterparty == counterparty }?.netExposure ?: 0.0
        val maxPotentialLoss = TrancheWorksAdapter.calculateMaxLossObligation(tranche, tradedNotional)
        val projectedExp = existingDealerExp + if (tradeType == TradeType.SYNTHETIC_SELL_PROTECTION) maxPotentialLoss else initialMargin
        val limitPassed = projectedExp <= MAX_DEALER_LIMIT
        checks.add(
            ControlCheck(
                id = "CHK_SYN_CPTY_LIMIT",
                name = "Dealer Credit Limit ($counterparty)",
                description = "Maximum $100M derivative notional/loss exposure",
                status = if (limitPassed) CheckStatus.PASSED else CheckStatus.FAILED,
                detailValue = "Projected Exp: $${formatAmount(projectedExp)} / $100M Limit"
            )
        )

        // 4. Required Approvals
        val requiresApproval = tradedNotional >= RISK_OFFICER_APPROVAL_THRESHOLD
        val approvalPassed = !requiresApproval || riskOfficerSignedOff
        checks.add(
            ControlCheck(
                id = "CHK_SYN_APPROVAL",
                name = "Risk Officer Approval",
                description = "Sign-off for derivative notional >= $10M",
                status = if (approvalPassed) CheckStatus.PASSED else CheckStatus.REQUIRES_APPROVAL,
                detailValue = if (approvalPassed) "Approved" else "Awaiting Risk Sign-Off"
            )
        )

        val anyFailed = checks.any { it.status == CheckStatus.FAILED }
        val canExecute = !anyFailed && approvalPassed

        return PreTradeValidationResult(
            canExecute = canExecute,
            requiresRiskOfficerApproval = requiresApproval && !riskOfficerSignedOff,
            checks = checks,
            projectedCashAfter = accountBalances.availableCash - initialMargin,
            projectedDealerExposureAfter = projectedExp,
            projectedTrancheExposureAfter = tradedNotional,
            projectedConcentrationPct = 12.5
        )
    }

    private fun formatAmount(amount: Double): String {
        return if (amount >= 1_000_000) {
            String.format("%.2fM", amount / 1_000_000.0)
        } else if (amount >= 1_000) {
            String.format("%.1fK", amount / 1_000.0)
        } else {
            String.format("%.2f", amount)
        }
    }
}
