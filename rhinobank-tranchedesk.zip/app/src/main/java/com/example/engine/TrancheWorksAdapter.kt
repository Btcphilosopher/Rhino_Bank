package com.example.engine

import com.example.data.model.CashNote
import com.example.data.model.QuantityBasis
import com.example.data.model.SettlementConvention
import com.example.data.model.SyntheticTranche
import kotlin.math.roundToInt

/**
 * RhinoBank TrancheWorks Adapter
 * Institutional engine for Collateral Analysis, Waterfall Priority, and Cash-flow Valuation.
 */
object TrancheWorksAdapter {

    /**
     * Accurately calculates cash note consideration before accrued interest and fees.
     * Prevents double application of the principal factor.
     *
     * Where a price is quoted per 100 of current principal:
     * - If original face is specified: original face * principal factor * price / 100
     * - If current face is specified: current face * price / 100
     */
    fun calculateConsideration(
        enteredFace: Double,
        principalFactor: Double,
        pricePer100: Double,
        basis: QuantityBasis
    ): Double {
        return when (basis) {
            QuantityBasis.ORIGINAL_FACE -> {
                enteredFace * principalFactor * (pricePer100 / 100.0)
            }
            QuantityBasis.CURRENT_FACE -> {
                enteredFace * (pricePer100 / 100.0)
            }
        }
    }

    /**
     * Converts entered quantity to original face and current face without ambiguity.
     */
    fun resolveFaces(
        enteredQuantity: Double,
        principalFactor: Double,
        basis: QuantityBasis
    ): Pair<Double, Double> {
        return when (basis) {
            QuantityBasis.ORIGINAL_FACE -> {
                val original = enteredQuantity
                val current = enteredQuantity * principalFactor
                Pair(original, current)
            }
            QuantityBasis.CURRENT_FACE -> {
                val current = enteredQuantity
                val original = if (principalFactor > 0) enteredQuantity / principalFactor else enteredQuantity
                Pair(original, current)
            }
        }
    }

    /**
     * Calculate accrued interest based on coupon terms and settlement convention.
     * e.g. Actual/360 for SOFR/Euribor floating benchmarks.
     */
    fun calculateAccruedInterest(
        currentFace: Double,
        couponSpreadBps: Int,
        benchmarkRatePct: Double = 5.25, // Current SOFR benchmark
        daysElapsed: Int = 45,
        convention: SettlementConvention = SettlementConvention.T_PLUS_2_ACT_360
    ): Double {
        val totalAnnualRatePct = benchmarkRatePct + (couponSpreadBps / 100.0)
        val dayCountDivisor = if (convention.dayCount.contains("360")) 360.0 else 365.0
        val accrued = currentFace * (totalAnnualRatePct / 100.0) * (daysElapsed / dayCountDivisor)
        return (accrued * 100.0).roundToInt() / 100.0
    }

    /**
     * Evaluates Discount Margin (DM) for a floating cash note.
     */
    fun calculateDiscountMargin(
        modelPrice: Double,
        couponSpreadBps: Int,
        walYears: Double
    ): Int {
        // Approximate discount margin: Spread + (100 - Price) / WAL * 100
        val priceDiff = 100.0 - modelPrice
        val annualAmortBps = if (walYears > 0) (priceDiff / walYears) * 100.0 else 0.0
        return (couponSpreadBps + annualAmortBps).roundToInt()
    }

    /**
     * Synthetic tranche quarterly running premium payment.
     * Premium = Notional * runningSpreadBps / 10,000 / 4
     */
    fun calculateQuarterlyPremium(
        notional: Double,
        runningSpreadBps: Int
    ): Double {
        return notional * (runningSpreadBps / 10_000.0) / 4.0
    }

    /**
     * Upfront cash calculation for synthetic tranche.
     */
    fun calculateUpfrontCash(
        notional: Double,
        upfrontPct: Double
    ): Double {
        return notional * (upfrontPct / 100.0)
    }

    /**
     * Potential loss obligation for synthetic tranche seller:
     * Max payout = Tranche width * Reference Notional
     */
    fun calculateMaxLossObligation(
        tranche: SyntheticTranche,
        tradedNotional: Double
    ): Double {
        val widthPct = tranche.detachmentPoint - tranche.attachmentPoint
        return (widthPct / 100.0) * tradedNotional
    }

    /**
     * Initial margin required for bilateral collateral under CSA.
     */
    fun calculateInitialMargin(
        notional: Double,
        initialMarginPct: Double = 8.0
    ): Double {
        return notional * (initialMarginPct / 100.0)
    }

    /**
     * Stress-testing simulation of collateral deterioration in TrancheWorks.
     * Increases CDR, causes credit losses, updates Overcollateralization (OC) ratios.
     */
    data class DeteriorationResult(
        val updatedNote: CashNote,
        val defaultsIncurred: Double,
        val seniorOcAfter: Double,
        val juniorOcAfter: Double,
        val ocTriggerBreached: Boolean,
        val equityWrittenDownPct: Double,
        val modelPriceShocked: Double
    )

    fun simulateCollateralDeterioration(
        note: CashNote,
        stressedCdrPct: Double = 4.8,
        portfolioLossAmount: Double = 12_500_000.0
    ): DeteriorationResult {
        val newCollateral = (note.collateralBalance - portfolioLossAmount).coerceAtLeast(0.0)
        // Senior tranches maintain coverage, Junior/Mezzanine OC drops
        val seniorOc = (note.seniorOvercollateralizationPct - 3.2).coerceAtLeast(100.0)
        val juniorOc = (note.juniorOvercollateralizationPct - 7.5).coerceAtLeast(90.0)
        val breached = juniorOc < note.overcollateralizationTriggerPct
        val equityLossPct = 68.0 // Equity suffers severe loss before mezzanine
        val priceShock = (note.modelPrice - 4.10).coerceAtLeast(80.0)

        val updated = note.copy(
            collateralBalance = newCollateral,
            constantDefaultRate = stressedCdrPct,
            seniorOvercollateralizationPct = seniorOc,
            juniorOvercollateralizationPct = juniorOc,
            modelPrice = (priceShock * 100.0).roundToInt() / 100.0,
            expectedLossPct = (note.expectedLossPct + 2.4)
        )

        return DeteriorationResult(
            updatedNote = updated,
            defaultsIncurred = portfolioLossAmount,
            seniorOcAfter = seniorOc,
            juniorOcAfter = juniorOc,
            ocTriggerBreached = breached,
            equityWrittenDownPct = equityLossPct,
            modelPriceShocked = priceShock
        )
    }

    /**
     * Simulates waterfall cash flow distribution to note holders.
     * Returns interest paid, principal amortized, and new principal factor.
     */
    data class DistributionResult(
        val noteId: String,
        val interestDistributed: Double,
        val principalAmortized: Double,
        val oldFactor: Double,
        val newFactor: Double,
        val totalCashToHolder: Double
    )

    fun calculateWaterfallDistribution(
        note: CashNote,
        holdingOriginalFace: Double,
        amortizationPctOfPool: Double = 2.0 // e.g. 2% pool principal paydown
    ): DistributionResult {
        val holdingCurrentFace = holdingOriginalFace * note.principalFactor
        val interest = calculateAccruedInterest(
            currentFace = holdingCurrentFace,
            couponSpreadBps = note.couponSpreadBps,
            daysElapsed = 90
        )
        val principalPaydown = holdingCurrentFace * (amortizationPctOfPool / 100.0)
        val newFactor = ((note.principalFactor - (note.principalFactor * (amortizationPctOfPool / 100.0))) * 10000.0).roundToInt() / 10000.0

        return DistributionResult(
            noteId = note.trancheId,
            interestDistributed = (interest * 100.0).roundToInt() / 100.0,
            principalAmortized = (principalPaydown * 100.0).roundToInt() / 100.0,
            oldFactor = note.principalFactor,
            newFactor = newFactor,
            totalCashToHolder = ((interest + principalPaydown) * 100.0).roundToInt() / 100.0
        )
    }
}
