package com.example.data.model

enum class LifecycleEventType(val displayName: String) {
    WATERFALL_DISTRIBUTION("Waterfall Distribution (Payment Event)"),
    COLLATERAL_DETERIORATION("Collateral Deterioration (Credit Shock)"),
    WRITE_DOWN("Principal Write-Down / Impairment"),
    RECOVERY("Asset Workout Recovery"),
    NOVATION_TRANSFER("Derivative Novation Transfer")
}

data class LifecycleEvent(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: LifecycleEventType,
    val title: String,
    val details: String,
    val financialImpact: String,
    val affectedDealOrTranche: String,
    val isApplied: Boolean = false,
    val executionRef: String = "EVT-${System.currentTimeMillis() % 100000}"
)

data class AuditEvent(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val userOrSystem: String = "DESK_USER_TOM",
    val action: String,
    val details: String,
    val entityId: String,
    val verificationHash: String = "SHA256-${(action + entityId).hashCode().toUInt().toString(16).uppercase()}"
)
