package com.example.data.model

enum class InstrumentType {
    CASH_CDO_NOTE,
    SYNTHETIC_TRANCHE
}

enum class RatingTier {
    AAA,
    AA,
    A,
    BBB_MEZZ,
    BB_MEZZ,
    SUBORDINATE_EQUITY
}

enum class TransferRestriction(val displayName: String) {
    RULE_144A_QIB("Rule 144A (QIB Only)"),
    REG_S("Regulation S (Non-US)"),
    ERISA_ELIGIBLE("ERISA Eligible"),
    RETAIL_PROHIBITED("Retail Investor Restriction (MIFID II/PRIIPs)")
}

enum class SettlementConvention(val displayName: String, val daysToSettle: Int, val dayCount: String) {
    T_PLUS_2_ACT_360("T+2 (Actual/360)", 2, "Actual/360"),
    T_PLUS_3_ACT_360("T+3 (Actual/360)", 3, "Actual/360"),
    T_PLUS_1_ACT_360("T+1 (Actual/360)", 1, "Actual/360")
}

enum class UpfrontDirection {
    BUYER_PAYS,
    SELLER_PAYS
}

data class CashNote(
    val dealId: String,
    val trancheId: String,
    val trancheName: String,
    val rating: RatingTier,
    val isin: String,
    val cusip: String,
    val currency: String = "USD",
    val originalPrincipal: Double,
    val currentPrincipal: Double,
    val principalFactor: Double,
    val factorEffectiveDate: String,
    val couponBenchmark: String = "SOFR",
    val couponSpreadBps: Int,
    val fixedCouponRatePct: Double? = null,
    val couponFrequency: String = "Quarterly",
    val maturityDate: String,
    val minDenomination: Double = 250_000.0,
    val tradingIncrement: Double = 1_000.0,
    val transferRestrictions: List<TransferRestriction>,
    val settlementConvention: SettlementConvention = SettlementConvention.T_PLUS_2_ACT_360,
    val waterfallVersion: String = "TrancheWorks-WF-v3.4",
    // Waterfall & Collateral Parameters
    val seniorOvercollateralizationPct: Double,
    val juniorOvercollateralizationPct: Double,
    val overcollateralizationTriggerPct: Double,
    val interestCoveragePct: Double,
    val expectedLossPct: Double,
    val walYears: Double,
    // Pricing & Market
    val modelPrice: Double, // Model Value from TrancheWorks
    val lastTradedPrice: Double? = null,
    val indicativeBid: Double? = null,
    val indicativeOffer: Double? = null,
    // Underlying Portfolio Stats
    val collateralBalance: Double,
    val diversityScore: Int,
    val warfRating: Int, // Weighted Average Rating Factor
    val constantPrepaymentRate: Double = 15.0, // CPR %
    val constantDefaultRate: Double = 1.8,    // CDR %
    val recoveryRate: Double = 65.0          // Recovery %
) {
    val currentFaceTraded: (Double) -> Double = { origFace -> origFace * principalFactor }
    val isMezzanine: Boolean get() = rating == RatingTier.BBB_MEZZ || rating == RatingTier.BB_MEZZ
    val isDistressed: Boolean get() = juniorOvercollateralizationPct < overcollateralizationTriggerPct
}

data class SyntheticTranche(
    val id: String,
    val referencePortfolio: String, // e.g. "CDX.NA.IG Series 42"
    val portfolioVersion: String,   // e.g. "v1.2024"
    val trancheName: String,       // e.g. "Mezzanine 3% - 7%"
    val attachmentPoint: Double,   // e.g. 3.0%
    val detachmentPoint: Double,   // e.g. 7.0%
    val referenceNotional: Double, // e.g. $25,000,000
    val runningPremiumBps: Int,    // Running spread in bps per annum
    val upfrontPct: Double,        // Upfront points
    val upfrontDirection: UpfrontDirection,
    val effectiveDate: String,
    val maturityDate: String,
    val creditEvents: List<String> = listOf("Failure to Pay", "Bankruptcy", "Restructuring (Mod-Mod R)"),
    val settlementMethod: String = "ISDA Auction Settlement",
    val csaAgreement: String = "ISDA 2002 / 2016 Bilateral VM CSA",
    val initialMarginPct: Double = 8.0,
    val modelSpreadBps: Int,       // Theoretical spread from TrancheWorks
    val lastTradedSpreadBps: Int? = null,
    val indicativeBidSpread: Int? = null,
    val indicativeOfferSpread: Int? = null,
    val underlyingEntitiesCount: Int = 125
) {
    val trancheWidthPct: Double get() = detachmentPoint - attachmentPoint
    val maxLossObligation: Double get() = (trancheWidthPct / 100.0) * referenceNotional
}
