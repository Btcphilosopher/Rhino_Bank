package com.example.data.model

enum class TradeType(val displayName: String, val isSynthetic: Boolean) {
    CASH_BUY("Buy Cash Note", false),
    CASH_SELL("Sell Cash Note", false),
    SYNTHETIC_BUY_PROTECTION("Buy Protection (Short Credit)", true),
    SYNTHETIC_SELL_PROTECTION("Sell Protection (Long Credit)", true),
    DERIVATIVE_NOVATION("Derivative Novation Transfer", true)
}

enum class QuantityBasis(val displayName: String) {
    ORIGINAL_FACE("Original Face"),
    CURRENT_FACE("Current Face (Factor-Adjusted)")
}

enum class TradeState(val displayName: String, val canAffirm: Boolean, val canSettle: Boolean) {
    DRAFT("Draft Ticket", false, false),
    QUOTED("Quote Received", false, false),
    ACCEPTED("Quote Accepted", false, false),
    EXECUTED("Executed", true, false),
    CONFIRMED("Confirmed & Affirmed", false, true),
    SETTLEMENT_PENDING("Settlement Pending (Clearing)", false, true),
    SETTLED("Settled (DVP Complete)", false, false),
    FAILED("Settlement Failed", true, false),
    DISPUTED("Disputed", false, false),
    CANCELLED("Cancelled", false, false),
    AMENDED("Amended", false, false)
}

data class SettlementInstruction(
    val depository: String = "Euroclear Bank SA/NV",
    val participantAccount: String = "RHINO-SEC-BRU-9402",
    val subAccount: String = "RHINO-CREDIT-MAIN",
    val status: String = "ACTIVE_VERIFIED",
    val bicSwift: String = "RHIOUS33XXX"
)

data class TradeRecord(
    val tradeId: String,
    val rfqId: String? = null,
    val instrumentId: String,
    val instrumentType: InstrumentType,
    val instrumentName: String,
    val isin: String,
    val tradeType: TradeType,
    val counterparty: String,
    val accountId: String = "RHINO-CREDIT-FUND-I",
    val quantityBasis: QuantityBasis,
    val originalFace: Double,
    val currentFace: Double,
    val principalFactorApplied: Double,
    val price: Double, // Price per 100 current principal or running spread bps
    val considerationBeforeAccrued: Double, // (originalFace * factor * price / 100)
    val accruedInterest: Double,
    val fees: Double,
    val totalSettlementAmount: Double,
    val currency: String = "USD",
    val tradeDate: String,
    val settlementDate: String,
    val settlementInstructions: SettlementInstruction = SettlementInstruction(),
    val state: TradeState = TradeState.DRAFT,
    val executionTimestamp: Long = System.currentTimeMillis(),
    val confirmedTimestamp: Long? = null,
    val settledTimestamp: Long? = null,
    val confirmationRef: String? = null,
    val failureReason: String? = null,
    // Synthetic fields
    val isSynthetic: Boolean = false,
    val syntheticNotional: Double? = null,
    val attachmentPoint: Double? = null,
    val detachmentPoint: Double? = null,
    val runningSpreadBps: Int? = null,
    val initialMarginRequired: Double? = null,
    // Pre-Trade Controls Sign-off
    val riskOfficerApprovalRequired: Boolean = false,
    val riskOfficerApproved: Boolean = false,
    val riskOfficerApprover: String? = null
)
