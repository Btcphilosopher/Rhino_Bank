package com.example.data.model

enum class ValuationSource(val displayName: String, val description: String) {
    MODEL_MARK("TrancheWorks Model Mark", "Waterfall pricing & projected cash-flows"),
    LAST_TRADED("Last Executed Trade", "Most recent verified trade execution"),
    MID_QUOTE("Composite Mid Quote", "Mean of prevailing dealer firm bids and offers")
}

data class PositionRecord(
    val instrumentId: String,
    val isin: String,
    val instrumentName: String,
    val instrumentType: InstrumentType,
    val settledOriginalFace: Double,
    val settledCurrentFace: Double,
    val unsettledFace: Double,
    val avgExecutionPrice: Double,
    val principalFactor: Double,
    val valuationPrice: Double, // Based on valuation source
    val marketValue: Double,
    val unrealizedPnl: Double,
    val realizedPnl: Double,
    val accruedInterestReceivable: Double,
    val valuationSource: ValuationSource = ValuationSource.MODEL_MARK,
    val currency: String = "USD",
    val isSynthetic: Boolean = false,
    val protectionDirection: String? = null // "Short Credit (Buyer)" or "Long Credit (Seller)"
) {
    val totalFace: Double get() = settledCurrentFace + unsettledFace
}

data class AccountBalances(
    val accountId: String = "RHINO-CREDIT-FUND-I",
    val cashBalance: Double = 45_000_000.0,
    val unsettledObligationsCash: Double = 0.0,
    val collateralPosted: Double = 2_000_000.0,
    val collateralHeld: Double = 0.0,
    val initialMarginThreshold: Double = 10_000_000.0,
    val totalSettledHoldingsValue: Double = 0.0,
    val totalUnrealizedPnl: Double = 0.0,
    val totalRealizedPnl: Double = 0.0
) {
    val availableCash: Double get() = cashBalance - unsettledObligationsCash
    val totalNav: Double get() = availableCash + collateralPosted + totalSettledHoldingsValue + totalUnrealizedPnl
}
