package com.example.data.repository

import com.example.data.model.AccountBalances
import com.example.data.model.AuditEvent
import com.example.data.model.CashNote
import com.example.data.model.CounterpartyExposure
import com.example.data.model.DealerQuote
import com.example.data.model.InstrumentType
import com.example.data.model.LifecycleEvent
import com.example.data.model.LifecycleEventType
import com.example.data.model.NovationRecord
import com.example.data.model.NovationStatus
import com.example.data.model.PositionRecord
import com.example.data.model.QuantityBasis
import com.example.data.model.QuotePerspective
import com.example.data.model.QuoteStatus
import com.example.data.model.QuoteType
import com.example.data.model.RatingTier
import com.example.data.model.RfqRequest
import com.example.data.model.RfqSide
import com.example.data.model.RfqStatus
import com.example.data.model.SettlementConvention
import com.example.data.model.SettlementInstruction
import com.example.data.model.SyntheticTranche
import com.example.data.model.TradeRecord
import com.example.data.model.TradeState
import com.example.data.model.TradeType
import com.example.data.model.TransferRestriction
import com.example.data.model.UpfrontDirection
import com.example.data.model.ValuationSource
import com.example.engine.TrancheWorksAdapter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class TrancheDeskRepository {

    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)

    // Preloaded Cash Notes
    private val initialCashNotes = listOf(
        CashNote(
            dealId = "RHINO-CLO-2024-1",
            trancheId = "RHN-24-1-A",
            trancheName = "Class A Senior Floating Note",
            rating = RatingTier.AAA,
            isin = "US76291AAA12",
            cusip = "76291AAA1",
            currency = "USD",
            originalPrincipal = 250_000_000.0,
            currentPrincipal = 227_500_000.0,
            principalFactor = 0.9100,
            factorEffectiveDate = "2024-10-15",
            couponBenchmark = "SOFR 3M",
            couponSpreadBps = 135,
            couponFrequency = "Quarterly",
            maturityDate = "2034-10-15",
            minDenomination = 250_000.0,
            tradingIncrement = 1_000.0,
            transferRestrictions = listOf(TransferRestriction.RULE_144A_QIB, TransferRestriction.REG_S),
            settlementConvention = SettlementConvention.T_PLUS_2_ACT_360,
            waterfallVersion = "TrancheWorks-WF-v3.4",
            seniorOvercollateralizationPct = 138.5,
            juniorOvercollateralizationPct = 124.0,
            overcollateralizationTriggerPct = 125.0,
            interestCoveragePct = 152.0,
            expectedLossPct = 0.05,
            walYears = 3.4,
            modelPrice = 99.85,
            lastTradedPrice = 99.82,
            indicativeBid = 99.75,
            indicativeOffer = 99.90,
            collateralBalance = 385_000_000.0,
            diversityScore = 74,
            warfRating = 2650,
            constantPrepaymentRate = 15.0,
            constantDefaultRate = 1.6,
            recoveryRate = 68.0
        ),
        CashNote(
            dealId = "RHINO-CLO-2024-1",
            trancheId = "RHN-24-1-B",
            trancheName = "Class B Senior Mezzanine Note",
            rating = RatingTier.AA,
            isin = "US76291AAB94",
            cusip = "76291AAB9",
            currency = "USD",
            originalPrincipal = 45_000_000.0,
            currentPrincipal = 42_300_000.0,
            principalFactor = 0.9400,
            factorEffectiveDate = "2024-10-15",
            couponBenchmark = "SOFR 3M",
            couponSpreadBps = 185,
            couponFrequency = "Quarterly",
            maturityDate = "2034-10-15",
            minDenomination = 250_000.0,
            tradingIncrement = 1_000.0,
            transferRestrictions = listOf(TransferRestriction.RULE_144A_QIB, TransferRestriction.REG_S),
            settlementConvention = SettlementConvention.T_PLUS_2_ACT_360,
            waterfallVersion = "TrancheWorks-WF-v3.4",
            seniorOvercollateralizationPct = 126.0,
            juniorOvercollateralizationPct = 118.5,
            overcollateralizationTriggerPct = 116.0,
            interestCoveragePct = 138.0,
            expectedLossPct = 0.45,
            walYears = 4.2,
            modelPrice = 98.40,
            lastTradedPrice = 98.35,
            indicativeBid = 98.20,
            indicativeOffer = 98.55,
            collateralBalance = 385_000_000.0,
            diversityScore = 74,
            warfRating = 2650,
            constantPrepaymentRate = 15.0,
            constantDefaultRate = 1.6,
            recoveryRate = 68.0
        ),
        CashNote(
            dealId = "RHINO-CLO-2024-1",
            trancheId = "RHN-24-1-C",
            trancheName = "Class C Mezzanine Note",
            rating = RatingTier.BBB_MEZZ,
            isin = "US76291AAC77",
            cusip = "76291AAC7",
            currency = "USD",
            originalPrincipal = 32_000_000.0,
            currentPrincipal = 31_040_000.0,
            principalFactor = 0.9700,
            factorEffectiveDate = "2024-10-15",
            couponBenchmark = "SOFR 3M",
            couponSpreadBps = 265,
            couponFrequency = "Quarterly",
            maturityDate = "2034-10-15",
            minDenomination = 250_000.0,
            tradingIncrement = 1_000.0,
            transferRestrictions = listOf(TransferRestriction.RULE_144A_QIB, TransferRestriction.REG_S),
            settlementConvention = SettlementConvention.T_PLUS_2_ACT_360,
            waterfallVersion = "TrancheWorks-WF-v3.4",
            seniorOvercollateralizationPct = 118.2,
            juniorOvercollateralizationPct = 112.4,
            overcollateralizationTriggerPct = 108.0,
            interestCoveragePct = 122.0,
            expectedLossPct = 1.45,
            walYears = 4.9,
            modelPrice = 96.42,
            lastTradedPrice = 96.15,
            indicativeBid = 96.20,
            indicativeOffer = 96.65,
            collateralBalance = 385_000_000.0,
            diversityScore = 74,
            warfRating = 2650,
            constantPrepaymentRate = 15.0,
            constantDefaultRate = 1.8,
            recoveryRate = 65.0
        ),
        CashNote(
            dealId = "RHINO-CLO-2024-1",
            trancheId = "RHN-24-1-D",
            trancheName = "Class D Junior Mezzanine Note",
            rating = RatingTier.BB_MEZZ,
            isin = "US76291AAD50",
            cusip = "76291AAD5",
            currency = "USD",
            originalPrincipal = 22_000_000.0,
            currentPrincipal = 22_000_000.0,
            principalFactor = 1.0000,
            factorEffectiveDate = "2024-10-15",
            couponBenchmark = "SOFR 3M",
            couponSpreadBps = 415,
            couponFrequency = "Quarterly",
            maturityDate = "2034-10-15",
            minDenomination = 250_000.0,
            tradingIncrement = 1_000.0,
            transferRestrictions = listOf(TransferRestriction.RULE_144A_QIB),
            settlementConvention = SettlementConvention.T_PLUS_2_ACT_360,
            waterfallVersion = "TrancheWorks-WF-v3.4",
            seniorOvercollateralizationPct = 111.5,
            juniorOvercollateralizationPct = 106.8,
            overcollateralizationTriggerPct = 104.5,
            interestCoveragePct = 111.0,
            expectedLossPct = 4.80,
            walYears = 5.6,
            modelPrice = 91.80,
            lastTradedPrice = 91.25,
            indicativeBid = 91.40,
            indicativeOffer = 92.10,
            collateralBalance = 385_000_000.0,
            diversityScore = 74,
            warfRating = 2650,
            constantPrepaymentRate = 15.0,
            constantDefaultRate = 2.1,
            recoveryRate = 60.0
        ),
        CashNote(
            dealId = "RHINO-CLO-2024-1",
            trancheId = "RHN-24-1-SUB",
            trancheName = "Subordinated Equity Notes",
            rating = RatingTier.SUBORDINATE_EQUITY,
            isin = "US76291AAE34",
            cusip = "76291AAE3",
            currency = "USD",
            originalPrincipal = 36_000_000.0,
            currentPrincipal = 36_000_000.0,
            principalFactor = 1.0000,
            factorEffectiveDate = "2024-10-15",
            couponBenchmark = "Residual Waterfall",
            couponSpreadBps = 850,
            couponFrequency = "Quarterly",
            maturityDate = "2036-10-15",
            minDenomination = 500_000.0,
            tradingIncrement = 10_000.0,
            transferRestrictions = listOf(TransferRestriction.RULE_144A_QIB),
            settlementConvention = SettlementConvention.T_PLUS_2_ACT_360,
            waterfallVersion = "TrancheWorks-WF-v3.4",
            seniorOvercollateralizationPct = 105.2,
            juniorOvercollateralizationPct = 102.8,
            overcollateralizationTriggerPct = 102.0,
            interestCoveragePct = 105.0,
            expectedLossPct = 18.20,
            walYears = 6.8,
            modelPrice = 78.50,
            lastTradedPrice = 77.90,
            indicativeBid = 77.00,
            indicativeOffer = 79.50,
            collateralBalance = 385_000_000.0,
            diversityScore = 74,
            warfRating = 2650,
            constantPrepaymentRate = 15.0,
            constantDefaultRate = 2.4,
            recoveryRate = 50.0
        )
    )

    // Preloaded Synthetic Tranches
    private val initialSyntheticTranches = listOf(
        SyntheticTranche(
            id = "SYN-CDX-42-MEZZ-3-7",
            referencePortfolio = "CDX.NA.IG Series 42",
            portfolioVersion = "v1.2024",
            trancheName = "Mezzanine Tranche 3.0% – 7.0%",
            attachmentPoint = 3.0,
            detachmentPoint = 7.0,
            referenceNotional = 25_000_000.0,
            runningPremiumBps = 340,
            upfrontPct = 2.15,
            upfrontDirection = UpfrontDirection.BUYER_PAYS,
            effectiveDate = "2024-09-20",
            maturityDate = "2029-12-20",
            creditEvents = listOf("Failure to Pay", "Bankruptcy", "Restructuring (Mod-Mod R)"),
            settlementMethod = "ISDA Auction Settlement",
            csaAgreement = "ISDA 2002 / 2016 Bilateral VM CSA",
            initialMarginPct = 8.0,
            modelSpreadBps = 332,
            lastTradedSpreadBps = 345,
            indicativeBidSpread = 338,
            indicativeOfferSpread = 342,
            underlyingEntitiesCount = 125
        ),
        SyntheticTranche(
            id = "SYN-ITX-41-SENMEZZ-7-15",
            referencePortfolio = "iTraxx Europe Crossover S41",
            portfolioVersion = "v2.2024",
            trancheName = "Senior Mezzanine 7.0% – 15.0%",
            attachmentPoint = 7.0,
            detachmentPoint = 15.0,
            referenceNotional = 20_000_000.0,
            runningPremiumBps = 225,
            upfrontPct = 1.10,
            upfrontDirection = UpfrontDirection.BUYER_PAYS,
            effectiveDate = "2024-09-20",
            maturityDate = "2029-12-20",
            creditEvents = listOf("Failure to Pay", "Bankruptcy", "Restructuring"),
            settlementMethod = "ISDA Auction Settlement",
            csaAgreement = "ISDA 2002 / 2016 Bilateral VM CSA",
            initialMarginPct = 6.0,
            modelSpreadBps = 218,
            lastTradedSpreadBps = 228,
            indicativeBidSpread = 222,
            indicativeOfferSpread = 227,
            underlyingEntitiesCount = 75
        ),
        SyntheticTranche(
            id = "SYN-CDX-42-EQUITY-0-3",
            referencePortfolio = "CDX.NA.IG Series 42",
            portfolioVersion = "v1.2024",
            trancheName = "First Loss Equity Tranche 0.0% – 3.0%",
            attachmentPoint = 0.0,
            detachmentPoint = 3.0,
            referenceNotional = 15_000_000.0,
            runningPremiumBps = 500,
            upfrontPct = 14.80,
            upfrontDirection = UpfrontDirection.BUYER_PAYS,
            effectiveDate = "2024-09-20",
            maturityDate = "2029-12-20",
            creditEvents = listOf("Failure to Pay", "Bankruptcy"),
            settlementMethod = "ISDA Auction Settlement",
            csaAgreement = "ISDA 2002 / 2016 Bilateral VM CSA",
            initialMarginPct = 15.0,
            modelSpreadBps = 512,
            lastTradedSpreadBps = 495,
            indicativeBidSpread = 490,
            indicativeOfferSpread = 510,
            underlyingEntitiesCount = 125
        )
    )

    // Preloaded Dealer Exposures
    private val initialDealerExposures = listOf(
        CounterpartyExposure("Goldman Sachs", 15_000_000.0, 10_000_000.0, 2_000_000.0, 23_000_000.0, 100_000_000.0, true, "ISDA-GS-2022-01"),
        CounterpartyExposure("J.P. Morgan", 8_500_000.0, 5_000_000.0, 1_000_000.0, 12_500_000.0, 100_000_000.0, true, "ISDA-JPM-2021-04"),
        CounterpartyExposure("Rhino Securities", 4_200_000.0, 0.0, 0.0, 4_200_000.0, 100_000_000.0, true, "ISDA-RHN-2023-01"),
        CounterpartyExposure("Morgan Stanley", 0.0, 12_000_000.0, 1_500_000.0, 10_500_000.0, 100_000_000.0, true, "ISDA-MS-2020-03"),
        CounterpartyExposure("Barclays", 6_000_000.0, 0.0, 0.0, 6_000_000.0, 100_000_000.0, false, null),
        CounterpartyExposure("BNP Paribas", 0.0, 0.0, 0.0, 0.0, 100_000_000.0, false, null)
    )

    // Preloaded Positions
    private val initialPositions = listOf(
        PositionRecord(
            instrumentId = "RHN-24-1-A",
            isin = "US76291AAA12",
            instrumentName = "Rhino CLO 2024-1 Class A",
            instrumentType = InstrumentType.CASH_CDO_NOTE,
            settledOriginalFace = 10_000_000.0,
            settledCurrentFace = 9_100_000.0,
            unsettledFace = 0.0,
            avgExecutionPrice = 99.80,
            principalFactor = 0.9100,
            valuationPrice = 99.85,
            marketValue = 9_100_000.0 * (99.85 / 100.0),
            unrealizedPnl = 4_550.0,
            realizedPnl = 0.0,
            accruedInterestReceivable = 78_240.0,
            valuationSource = ValuationSource.MODEL_MARK
        )
    )

    // State Flows
    private val _cashNotes = MutableStateFlow(initialCashNotes)
    val cashNotes: StateFlow<List<CashNote>> = _cashNotes.asStateFlow()

    private val _syntheticTranches = MutableStateFlow(initialSyntheticTranches)
    val syntheticTranches: StateFlow<List<SyntheticTranche>> = _syntheticTranches.asStateFlow()

    private val _rfqs = MutableStateFlow<List<RfqRequest>>(emptyList())
    val rfqs: StateFlow<List<RfqRequest>> = _rfqs.asStateFlow()

    private val _trades = MutableStateFlow<List<TradeRecord>>(emptyList())
    val trades: StateFlow<List<TradeRecord>> = _trades.asStateFlow()

    private val _positions = MutableStateFlow(initialPositions)
    val positions: StateFlow<List<PositionRecord>> = _positions.asStateFlow()

    private val _accountBalances = MutableStateFlow(
        AccountBalances(
            cashBalance = 45_000_000.0,
            totalSettledHoldingsValue = 9_086_350.0,
            totalUnrealizedPnl = 4_550.0
        )
    )
    val accountBalances: StateFlow<AccountBalances> = _accountBalances.asStateFlow()

    private val _dealerExposures = MutableStateFlow(initialDealerExposures)
    val dealerExposures: StateFlow<List<CounterpartyExposure>> = _dealerExposures.asStateFlow()

    private val _novations = MutableStateFlow<List<NovationRecord>>(emptyList())
    val novations: StateFlow<List<NovationRecord>> = _novations.asStateFlow()

    private val _lifecycleEvents = MutableStateFlow<List<LifecycleEvent>>(emptyList())
    val lifecycleEvents: StateFlow<List<LifecycleEvent>> = _lifecycleEvents.asStateFlow()

    private val _auditTrail = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditTrail: StateFlow<List<AuditEvent>> = _auditTrail.asStateFlow()

    init {
        addAuditEvent("SYSTEM_START", "RhinoBank TrancheDesk initialized. Connected to TrancheWorks v3.4.", "DESK-MAIN")
    }

    fun addAuditEvent(action: String, details: String, entityId: String) {
        val event = AuditEvent(
            id = "AUD-${UUID.randomUUID().toString().take(8).uppercase()}",
            timestamp = System.currentTimeMillis(),
            action = action,
            details = details,
            entityId = entityId
        )
        _auditTrail.update { listOf(event) + it }
    }

    /**
     * Broadcasts RFQ to chosen counterparties and generates time-limited dealer quotes.
     */
    fun broadcastRfq(
        instrumentId: String,
        instrumentType: InstrumentType,
        side: RfqSide,
        requestedQuantity: Double,
        quantityBasis: QuantityBasis,
        permittedDealers: List<String>
    ): RfqRequest {
        val rfqId = "RFQ-${UUID.randomUUID().toString().take(6).uppercase()}"
        val now = System.currentTimeMillis()
        val expiry = now + (60 * 1000) // 60 seconds validity
        val note = _cashNotes.value.find { it.trancheId == instrumentId }
        val syn = _syntheticTranches.value.find { it.id == instrumentId }
        val name = note?.trancheName ?: syn?.trancheName ?: instrumentId

        val generatedQuotes = mutableListOf<DealerQuote>()

        permittedDealers.forEachIndexed { index, dealer ->
            val quoteId = "QTE-${rfqId}-${index + 1}"
            val allowsPartial = index % 2 == 0 // Some dealers allow partial execution
            val isFirm = index != 2            // Dealer 3 is indicative
            val quoteType = if (isFirm) QuoteType.FIRM else QuoteType.INDICATIVE

            if (instrumentType == InstrumentType.CASH_CDO_NOTE && note != null) {
                // Determine quote perspective
                // User selects BID_WANTED -> User wants to sell -> Dealer BIDS (dealer buys)
                // User selects OFFER_WANTED -> User wants to buy -> Dealer OFFERS (dealer sells)
                val perspective = if (side == RfqSide.BID_WANTED) QuotePerspective.DEALER_BIDS_WE_SELL else QuotePerspective.DEALER_OFFERS_WE_BUY
                val basePrice = note.modelPrice
                // Spread: dealer bid is slightly lower, offer is slightly higher
                val priceOffset = when (dealer) {
                    "Goldman Sachs" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 0.15 else -0.18
                    "Rhino Securities" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 0.08 else -0.10
                    "J.P. Morgan" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 0.22 else -0.25
                    "Barclays" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 0.18 else -0.20
                    else -> 0.12
                }
                val quotePrice = ((basePrice + priceOffset) * 100.0).toInt() / 100.0
                val maxQty = if (allowsPartial) requestedQuantity * 1.5 else requestedQuantity
                val minQty = if (allowsPartial) 2_500_000.0 else requestedQuantity
                val consideration = TrancheWorksAdapter.calculateConsideration(
                    enteredFace = requestedQuantity,
                    principalFactor = note.principalFactor,
                    pricePer100 = quotePrice,
                    basis = quantityBasis
                )
                val dm = TrancheWorksAdapter.calculateDiscountMargin(quotePrice, note.couponSpreadBps, note.walYears)

                generatedQuotes.add(
                    DealerQuote(
                        id = quoteId,
                        rfqId = rfqId,
                        dealerName = dealer,
                        perspective = perspective,
                        quoteType = quoteType,
                        price = quotePrice,
                        maxQuantity = maxQty,
                        minQuantity = minQty,
                        allowsPartialExecution = allowsPartial,
                        validUntilEpochMillis = expiry,
                        discountMarginBps = dm,
                        allInConsiderationEstimated = consideration,
                        receivedTimestamp = now
                    )
                )
            } else if (instrumentType == InstrumentType.SYNTHETIC_TRANCHE && syn != null) {
                val perspective = if (side == RfqSide.BID_WANTED) QuotePerspective.DEALER_BIDS_WE_SELL else QuotePerspective.DEALER_OFFERS_WE_BUY
                val baseSpread = syn.modelSpreadBps
                val spreadOffset = when (dealer) {
                    "Goldman Sachs" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 5 else -6
                    "Rhino Securities" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 3 else -4
                    "J.P. Morgan" -> if (perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) 8 else -9
                    else -> 6
                }
                val quoteSpread = baseSpread + spreadOffset
                val upfrontCash = TrancheWorksAdapter.calculateUpfrontCash(requestedQuantity, syn.upfrontPct)

                generatedQuotes.add(
                    DealerQuote(
                        id = quoteId,
                        rfqId = rfqId,
                        dealerName = dealer,
                        perspective = perspective,
                        quoteType = quoteType,
                        spreadBps = quoteSpread,
                        maxQuantity = requestedQuantity,
                        minQuantity = requestedQuantity / 2.0,
                        allowsPartialExecution = allowsPartial,
                        validUntilEpochMillis = expiry,
                        discountMarginBps = quoteSpread,
                        allInConsiderationEstimated = upfrontCash,
                        receivedTimestamp = now
                    )
                )
            }
        }

        val rfq = RfqRequest(
            id = rfqId,
            instrumentId = instrumentId,
            instrumentType = instrumentType,
            instrumentName = name,
            side = side,
            requestedQuantity = requestedQuantity,
            quantityBasis = quantityBasis,
            permittedDealers = permittedDealers,
            createdTimestamp = now,
            expiresEpochMillis = expiry,
            status = RfqStatus.QUOTED,
            quotes = generatedQuotes
        )

        _rfqs.update { listOf(rfq) + it }
        addAuditEvent("RFQ_BROADCAST", "Broadcasted RFQ to ${permittedDealers.size} dealers for $name (Qty: $requestedQuantity)", rfqId)
        return rfq
    }

    /**
     * Executes trade from an accepted dealer quote.
     */
    fun acceptAndExecuteQuote(
        rfqId: String,
        quoteId: String,
        executedQuantity: Double,
        riskOfficerSignoff: Boolean = false
    ): TradeRecord? {
        val rfq = _rfqs.value.find { it.id == rfqId } ?: return null
        val quote = rfq.quotes.find { it.id == quoteId } ?: return null

        // Prevent expired quotes
        if (quote.isExpired()) {
            addAuditEvent("EXEC_REJECTED", "Quote $quoteId expired. Cannot execute.", rfqId)
            return null
        }
        // Prevent duplicate execution
        if (rfq.status == RfqStatus.FILLED) {
            addAuditEvent("EXEC_REJECTED", "RFQ $rfqId is already filled.", rfqId)
            return null
        }
        // Prevent execution beyond quoted size
        if (executedQuantity > quote.maxQuantity) {
            addAuditEvent("EXEC_REJECTED", "Executed quantity $executedQuantity exceeds quote max ${quote.maxQuantity}.", quoteId)
            return null
        }

        val note = _cashNotes.value.find { it.trancheId == rfq.instrumentId }
        val syn = _syntheticTranches.value.find { it.id == rfq.instrumentId }

        val tradeId = "TRD-${UUID.randomUUID().toString().take(7).uppercase()}"
        val todayStr = dateFormatter.format(Date())
        val settleDateStr = dateFormatter.format(Date(System.currentTimeMillis() + (2L * 86400000L))) // T+2

        val isBuy = quote.perspective == QuotePerspective.DEALER_OFFERS_WE_BUY

        val tradeRecord = if (rfq.instrumentType == InstrumentType.CASH_CDO_NOTE && note != null) {
            val factor = note.principalFactor
            val (origFace, currFace) = TrancheWorksAdapter.resolveFaces(executedQuantity, factor, rfq.quantityBasis)
            val price = quote.price ?: note.modelPrice
            val consideration = TrancheWorksAdapter.calculateConsideration(executedQuantity, factor, price, rfq.quantityBasis)
            val accrued = TrancheWorksAdapter.calculateAccruedInterest(currFace, note.couponSpreadBps)
            val fees = 1_500.0
            val totalAmount = if (isBuy) consideration + accrued + fees else consideration + accrued - fees

            TradeRecord(
                tradeId = tradeId,
                rfqId = rfqId,
                instrumentId = note.trancheId,
                instrumentType = InstrumentType.CASH_CDO_NOTE,
                instrumentName = note.trancheName,
                isin = note.isin,
                tradeType = if (isBuy) TradeType.CASH_BUY else TradeType.CASH_SELL,
                counterparty = quote.dealerName,
                quantityBasis = rfq.quantityBasis,
                originalFace = origFace,
                currentFace = currFace,
                principalFactorApplied = factor,
                price = price,
                considerationBeforeAccrued = consideration,
                accruedInterest = accrued,
                fees = fees,
                totalSettlementAmount = totalAmount,
                tradeDate = todayStr,
                settlementDate = settleDateStr,
                state = TradeState.EXECUTED,
                isSynthetic = false,
                riskOfficerApproved = riskOfficerSignoff
            )
        } else if (syn != null) {
            val notional = executedQuantity
            val spread = quote.spreadBps ?: syn.modelSpreadBps
            val upfront = TrancheWorksAdapter.calculateUpfrontCash(notional, syn.upfrontPct)
            val initialMargin = TrancheWorksAdapter.calculateInitialMargin(notional, syn.initialMarginPct)
            val fees = 2_500.0

            TradeRecord(
                tradeId = tradeId,
                rfqId = rfqId,
                instrumentId = syn.id,
                instrumentType = InstrumentType.SYNTHETIC_TRANCHE,
                instrumentName = syn.trancheName,
                isin = syn.id,
                tradeType = if (isBuy) TradeType.SYNTHETIC_BUY_PROTECTION else TradeType.SYNTHETIC_SELL_PROTECTION,
                counterparty = quote.dealerName,
                quantityBasis = QuantityBasis.ORIGINAL_FACE,
                originalFace = notional,
                currentFace = notional,
                principalFactorApplied = 1.0,
                price = spread.toDouble(),
                considerationBeforeAccrued = upfront,
                accruedInterest = 0.0,
                fees = fees,
                totalSettlementAmount = upfront + fees,
                tradeDate = todayStr,
                settlementDate = settleDateStr,
                state = TradeState.EXECUTED,
                isSynthetic = true,
                syntheticNotional = notional,
                attachmentPoint = syn.attachmentPoint,
                detachmentPoint = syn.detachmentPoint,
                runningSpreadBps = spread,
                initialMarginRequired = initialMargin,
                riskOfficerApproved = riskOfficerSignoff
            )
        } else null

        if (tradeRecord != null) {
            // Update RFQ status
            _rfqs.update { list ->
                list.map {
                    if (it.id == rfqId) {
                        it.copy(
                            status = RfqStatus.FILLED,
                            selectedQuoteId = quoteId,
                            quotes = it.quotes.map { q ->
                                if (q.id == quoteId) q.copy(status = QuoteStatus.ACCEPTED) else q
                            }
                        )
                    } else it
                }
            }

            // Record trade
            _trades.update { listOf(tradeRecord) + it }

            // Update unsettled cash obligations
            if (isBuy) {
                _accountBalances.update { bal ->
                    bal.copy(
                        unsettledObligationsCash = bal.unsettledObligationsCash + tradeRecord.totalSettlementAmount
                    )
                }
            }

            // Update unsettled position face
            updateUnsettledPosition(tradeRecord)

            addAuditEvent("TRADE_EXECUTED", "Executed ${tradeRecord.tradeType.displayName} with ${tradeRecord.counterparty} for $${formatNum(tradeRecord.currentFace)} at ${tradeRecord.price}", tradeId)
        }

        return tradeRecord
    }

    /**
     * Electronic Confirmation Affirmation (SWIFT MT300 / MT543 matching).
     */
    fun affirmTrade(tradeId: String): Boolean {
        val trade = _trades.value.find { it.tradeId == tradeId } ?: return false
        if (trade.state != TradeState.EXECUTED && trade.state != TradeState.FAILED) return false

        val confirmRef = "CNF-${UUID.randomUUID().toString().take(8).uppercase()}"
        _trades.update { list ->
            list.map {
                if (it.tradeId == tradeId) {
                    it.copy(
                        state = TradeState.CONFIRMED,
                        confirmedTimestamp = System.currentTimeMillis(),
                        confirmationRef = confirmRef
                    )
                } else it
            }
        }
        addAuditEvent("TRADE_AFFIRMED", "Electronic trade confirmation affirmed against broker matching feed ($confirmRef)", tradeId)
        return true
    }

    /**
     * DVP / Clearing Settlement: Moves cash and updates settled holdings.
     */
    fun settleTrade(tradeId: String): Boolean {
        val trade = _trades.value.find { it.tradeId == tradeId } ?: return false
        if (trade.state != TradeState.CONFIRMED && trade.state != TradeState.SETTLEMENT_PENDING) return false

        // Idempotent: check if already settled
        if (trade.state == TradeState.SETTLED) return true

        val isBuy = trade.tradeType == TradeType.CASH_BUY || trade.tradeType == TradeType.SYNTHETIC_BUY_PROTECTION

        // 1. Move Cash
        _accountBalances.update { bal ->
            if (isBuy) {
                bal.copy(
                    cashBalance = bal.cashBalance - trade.totalSettlementAmount,
                    unsettledObligationsCash = (bal.unsettledObligationsCash - trade.totalSettlementAmount).coerceAtLeast(0.0)
                )
            } else {
                bal.copy(
                    cashBalance = bal.cashBalance + trade.totalSettlementAmount
                )
            }
        }

        // 2. Update Settled Holdings
        _positions.update { currentPositions ->
            val existing = currentPositions.find { it.instrumentId == trade.instrumentId }
            if (existing != null) {
                currentPositions.map { pos ->
                    if (pos.instrumentId == trade.instrumentId) {
                        val newSettledOrig = if (isBuy) pos.settledOriginalFace + trade.originalFace else (pos.settledOriginalFace - trade.originalFace).coerceAtLeast(0.0)
                        val newSettledCurr = if (isBuy) pos.settledCurrentFace + trade.currentFace else (pos.settledCurrentFace - trade.currentFace).coerceAtLeast(0.0)
                        val newUnsettled = (pos.unsettledFace - trade.currentFace).coerceAtLeast(0.0)
                        val newMarketVal = newSettledCurr * (pos.valuationPrice / 100.0)
                        pos.copy(
                            settledOriginalFace = newSettledOrig,
                            settledCurrentFace = newSettledCurr,
                            unsettledFace = newUnsettled,
                            marketValue = newMarketVal
                        )
                    } else pos
                }
            } else {
                val newMarketVal = trade.currentFace * (trade.price / 100.0)
                currentPositions + PositionRecord(
                    instrumentId = trade.instrumentId,
                    isin = trade.isin,
                    instrumentName = trade.instrumentName,
                    instrumentType = trade.instrumentType,
                    settledOriginalFace = trade.originalFace,
                    settledCurrentFace = trade.currentFace,
                    unsettledFace = 0.0,
                    avgExecutionPrice = trade.price,
                    principalFactor = trade.principalFactorApplied,
                    valuationPrice = trade.price,
                    marketValue = newMarketVal,
                    unrealizedPnl = 0.0,
                    realizedPnl = 0.0,
                    accruedInterestReceivable = trade.accruedInterest,
                    isSynthetic = trade.isSynthetic,
                    protectionDirection = if (trade.isSynthetic) (if (isBuy) "Short Credit (Buyer)" else "Long Credit (Seller)") else null
                )
            }
        }

        // 3. Mark Trade Settled
        _trades.update { list ->
            list.map {
                if (it.tradeId == tradeId) {
                    it.copy(
                        state = TradeState.SETTLED,
                        settledTimestamp = System.currentTimeMillis()
                    )
                } else it
            }
        }

        // Recompute NAV & Holdings value
        recalculateNav()

        addAuditEvent("TRADE_SETTLED", "DVP Settlement finalized in Euroclear/DTC. Cash and holdings updated.", tradeId)
        return true
    }

    /**
     * Trigger Settlement Failure (e.g. counterparty failed delivery).
     */
    fun failSettlement(tradeId: String, reason: String = "Counterparty Euroclear securities delivery delayed (fail-to-deliver)"): Boolean {
        _trades.update { list ->
            list.map {
                if (it.tradeId == tradeId) {
                    it.copy(
                        state = TradeState.FAILED,
                        failureReason = reason
                    )
                } else it
            }
        }
        addAuditEvent("SETTLEMENT_FAILED", "Trade failed settlement: $reason", tradeId)
        return true
    }

    /**
     * Applies Collateral Deterioration Stress Scenario on a CDO Deal.
     */
    fun applyCollateralDeterioration(dealId: String): LifecycleEvent {
        val targetNotes = _cashNotes.value.filter { it.dealId == dealId }
        val updatedNotes = targetNotes.map { note ->
            val result = TrancheWorksAdapter.simulateCollateralDeterioration(note)
            result.updatedNote
        }

        _cashNotes.update { current ->
            current.map { note ->
                updatedNotes.find { it.trancheId == note.trancheId } ?: note
            }
        }

        // Update positions marked to new model price
        _positions.update { posList ->
            posList.map { pos ->
                val matchingNote = updatedNotes.find { it.trancheId == pos.instrumentId }
                if (matchingNote != null) {
                    val newPrice = matchingNote.modelPrice
                    val newMarketVal = pos.settledCurrentFace * (newPrice / 100.0)
                    val costBasis = pos.settledCurrentFace * (pos.avgExecutionPrice / 100.0)
                    val unPnl = newMarketVal - costBasis
                    pos.copy(
                        valuationPrice = newPrice,
                        marketValue = newMarketVal,
                        unrealizedPnl = unPnl
                    )
                } else pos
            }
        }

        recalculateNav()

        val event = LifecycleEvent(
            id = "EVT-STRESS-${UUID.randomUUID().toString().take(6).uppercase()}",
            eventType = LifecycleEventType.COLLATERAL_DETERIORATION,
            title = "Collateral Default Shock Applied ($dealId)",
            details = "CDR elevated to 4.8%. $12.5M defaults absorbed by pool. Subordinated equity principal written down 68%. Mezzanine C Junior OC dropped to 104.9% (Trigger 108.0% - BREACH).",
            financialImpact = "-$4.10/100 model mark shock across mezzanine notes",
            affectedDealOrTranche = dealId,
            isApplied = true
        )

        _lifecycleEvents.update { listOf(event) + it }
        addAuditEvent("LIFECYCLE_STRESS", "TrancheWorks applied collateral deterioration scenario to $dealId", event.id)
        return event
    }

    /**
     * Executes Waterfall Coupon and Principal Distribution Event.
     */
    fun applyWaterfallDistribution(dealId: String): LifecycleEvent {
        var totalCashDistributed = 0.0
        val affectedNotes = _cashNotes.value.filter { it.dealId == dealId }

        affectedNotes.forEach { note ->
            val holding = _positions.value.find { it.instrumentId == note.trancheId }
            if (holding != null && holding.settledOriginalFace > 0) {
                val dist = TrancheWorksAdapter.calculateWaterfallDistribution(note, holding.settledOriginalFace)
                totalCashDistributed += dist.totalCashToHolder

                // Update note factor
                _cashNotes.update { list ->
                    list.map {
                        if (it.trancheId == note.trancheId) {
                            it.copy(
                                principalFactor = dist.newFactor,
                                currentPrincipal = it.originalPrincipal * dist.newFactor
                            )
                        } else it
                    }
                }

                // Update position factor & settled current face
                _positions.update { list ->
                    list.map {
                        if (it.instrumentId == note.trancheId) {
                            val newCurrFace = it.settledOriginalFace * dist.newFactor
                            val newMktVal = newCurrFace * (it.valuationPrice / 100.0)
                            it.copy(
                                principalFactor = dist.newFactor,
                                settledCurrentFace = newCurrFace,
                                marketValue = newMktVal
                            )
                        } else it
                    }
                }
            }
        }

        // Credit cash account
        if (totalCashDistributed > 0) {
            _accountBalances.update { bal ->
                bal.copy(
                    cashBalance = bal.cashBalance + totalCashDistributed,
                    totalRealizedPnl = bal.totalRealizedPnl + totalCashDistributed
                )
            }
        }

        recalculateNav()

        val event = LifecycleEvent(
            id = "EVT-DIST-${UUID.randomUUID().toString().take(6).uppercase()}",
            eventType = LifecycleEventType.WATERFALL_DISTRIBUTION,
            title = "Waterfall Quarterly Distribution ($dealId)",
            details = "Processed senior & mezzanine interest distributions and 2% scheduled collateral paydown. Principal factors updated.",
            financialImpact = "+$${formatNum(totalCashDistributed)} received in cash account",
            affectedDealOrTranche = dealId,
            isApplied = true
        )

        _lifecycleEvents.update { listOf(event) + it }
        addAuditEvent("LIFECYCLE_PAYMENT", "Waterfall cash distributions credited to desk account", event.id)
        return event
    }

    /**
     * Novation Workflow: Transfers derivative position to new counterparty.
     */
    fun createNovationRequest(
        tradeRef: String,
        transferee: String,
        remainingParty: String
    ): NovationRecord {
        val trade = _trades.value.find { it.tradeId == tradeRef }
        val portfolio = trade?.instrumentName ?: "CDX.NA.IG Mezzanine 3-7%"
        val notional = trade?.syntheticNotional ?: 10_000_000.0
        val novId = "NOV-${UUID.randomUUID().toString().take(6).uppercase()}"

        val novation = NovationRecord(
            novationId = novId,
            tradeRef = tradeRef,
            referencePortfolio = portfolio,
            trancheDescription = trade?.instrumentName ?: "Synthetic Credit Tranche",
            transferor = "Rhino Institutional Credit Fund I",
            transferee = transferee,
            remainingParty = remainingParty,
            calculationAgent = "Rhino Securities London Ltd.",
            transferredNotional = notional,
            runningPremiumBps = trade?.runningSpreadBps ?: 340,
            agreementDate = dateFormatter.format(Date()),
            effectiveDate = dateFormatter.format(Date(System.currentTimeMillis() + 86400000L)),
            dealerConsentGranted = false,
            calculationAgentConsentGranted = false,
            isdaConfirmationSigned = false,
            status = NovationStatus.PENDING_DEALER_CONSENT
        )

        _novations.update { listOf(novation) + it }
        addAuditEvent("NOVATION_REQUESTED", "Novation request initiated to transfer $tradeRef to $transferee", novId)
        return novation
    }

    fun grantNovationDealerConsent(novationId: String): Boolean {
        _novations.update { list ->
            list.map {
                if (it.novationId == novationId) {
                    val updated = it.copy(
                        dealerConsentGranted = true,
                        status = if (it.calculationAgentConsentGranted) NovationStatus.CONSENTS_SATISFIED else NovationStatus.PENDING_CALC_AGENT
                    )
                    updated
                } else it
            }
        }
        addAuditEvent("NOVATION_DEALER_CONSENT", "Remaining dealer consent granted", novationId)
        return true
    }

    fun grantNovationCalcAgentConsent(novationId: String): Boolean {
        _novations.update { list ->
            list.map {
                if (it.novationId == novationId) {
                    val updated = it.copy(
                        calculationAgentConsentGranted = true,
                        isdaConfirmationSigned = true,
                        status = if (it.dealerConsentGranted) NovationStatus.CONSENTS_SATISFIED else NovationStatus.PENDING_DEALER_CONSENT
                    )
                    updated
                } else it
            }
        }
        addAuditEvent("NOVATION_CALC_AGENT_CONSENT", "Calculation agent consent & ISDA confirmation verified", novationId)
        return true
    }

    fun finalizeNovationTransfer(novationId: String): Boolean {
        val nov = _novations.value.find { it.novationId == novationId } ?: return false
        if (!nov.allContractualConsentsSatisfied) return false

        _novations.update { list ->
            list.map {
                if (it.novationId == novationId) {
                    it.copy(status = NovationStatus.COMPLETED_EFFECTIVE)
                } else it
            }
        }

        // Remove / reduce position
        _positions.update { list ->
            list.filterNot { it.instrumentId.contains("SYN") && it.settledCurrentFace <= nov.transferredNotional }
        }

        recalculateNav()

        addAuditEvent("NOVATION_COMPLETED", "Novation completed. Derivative transferred to ${nov.transferee}.", novationId)
        return true
    }

    private fun updateUnsettledPosition(trade: TradeRecord) {
        _positions.update { currentPositions ->
            val existing = currentPositions.find { it.instrumentId == trade.instrumentId }
            if (existing != null) {
                currentPositions.map { pos ->
                    if (pos.instrumentId == trade.instrumentId) {
                        pos.copy(unsettledFace = pos.unsettledFace + trade.currentFace)
                    } else pos
                }
            } else {
                currentPositions + PositionRecord(
                    instrumentId = trade.instrumentId,
                    isin = trade.isin,
                    instrumentName = trade.instrumentName,
                    instrumentType = trade.instrumentType,
                    settledOriginalFace = 0.0,
                    settledCurrentFace = 0.0,
                    unsettledFace = trade.currentFace,
                    avgExecutionPrice = trade.price,
                    principalFactor = trade.principalFactorApplied,
                    valuationPrice = trade.price,
                    marketValue = 0.0,
                    unrealizedPnl = 0.0,
                    realizedPnl = 0.0,
                    accruedInterestReceivable = 0.0,
                    isSynthetic = trade.isSynthetic
                )
            }
        }
    }

    fun setValuationSource(source: ValuationSource) {
        _positions.update { list ->
            list.map { pos ->
                val note = _cashNotes.value.find { it.trancheId == pos.instrumentId }
                val newPrice = when (source) {
                    ValuationSource.MODEL_MARK -> note?.modelPrice ?: pos.valuationPrice
                    ValuationSource.LAST_TRADED -> note?.lastTradedPrice ?: pos.avgExecutionPrice
                    ValuationSource.MID_QUOTE -> {
                        val bid = note?.indicativeBid ?: (pos.valuationPrice - 0.25)
                        val ask = note?.indicativeOffer ?: (pos.valuationPrice + 0.25)
                        (bid + ask) / 2.0
                    }
                }
                val newMktVal = pos.settledCurrentFace * (newPrice / 100.0)
                val cost = pos.settledCurrentFace * (pos.avgExecutionPrice / 100.0)
                pos.copy(
                    valuationSource = source,
                    valuationPrice = newPrice,
                    marketValue = newMktVal,
                    unrealizedPnl = newMktVal - cost
                )
            }
        }
        recalculateNav()
    }

    private fun recalculateNav() {
        val totalHoldings = _positions.value.sumOf { it.marketValue }
        val totalUnrealized = _positions.value.sumOf { it.unrealizedPnl }
        _accountBalances.update { bal ->
            bal.copy(
                totalSettledHoldingsValue = totalHoldings,
                totalUnrealizedPnl = totalUnrealized
            )
        }
    }

    private fun formatNum(n: Double): String {
        return if (n >= 1_000_000) String.format("%.2fM", n / 1_000_000.0)
        else if (n >= 1_000) String.format("%.1fK", n / 1_000.0)
        else String.format("%.2f", n)
    }
}
