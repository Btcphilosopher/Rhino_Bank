package com.example.data.model

enum class NovationStatus(val displayName: String) {
    DRAFT_REQUEST("Draft Transfer Request"),
    PENDING_DEALER_CONSENT("Awaiting Remaining Dealer Consent"),
    PENDING_CALC_AGENT("Awaiting Calculation Agent Approval"),
    CONSENTS_SATISFIED("Consents Satisfied & Ready"),
    CONFIRMED("Novation Confirmed"),
    COMPLETED_EFFECTIVE("Transfer Completed & Effective"),
    REJECTED("Consent Rejected")
}

data class NovationRecord(
    val novationId: String,
    val tradeRef: String,
    val referencePortfolio: String,
    val trancheDescription: String,
    val transferor: String,         // Original party assigning position
    val transferee: String,         // New party assuming position
    val remainingParty: String,     // Counterparty to original trade
    val calculationAgent: String = "Rhino Securities London Ltd.",
    val transferredNotional: Double,
    val runningPremiumBps: Int,
    val novationFee: Double = 12_500.0,
    val agreementDate: String,
    val effectiveDate: String,
    val dealerConsentGranted: Boolean = false,
    val calculationAgentConsentGranted: Boolean = false,
    val isdaConfirmationSigned: Boolean = false,
    val status: NovationStatus = NovationStatus.PENDING_DEALER_CONSENT
) {
    val allContractualConsentsSatisfied: Boolean
        get() = dealerConsentGranted && calculationAgentConsentGranted && isdaConfirmationSigned
}
