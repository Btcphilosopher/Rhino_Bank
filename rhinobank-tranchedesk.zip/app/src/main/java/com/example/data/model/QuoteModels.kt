package com.example.data.model

enum class QuotePerspective(val displayName: String, val userAction: String) {
    DEALER_BIDS_WE_SELL("Dealer Bids (User Sells)", "Sell to Dealer"),
    DEALER_OFFERS_WE_BUY("Dealer Offers (User Buys)", "Buy from Dealer")
}

enum class QuoteType(val displayName: String) {
    FIRM("Firm Executable"),
    INDICATIVE("Indicative Only")
}

enum class QuoteStatus {
    LIVE,
    EXPIRED,
    WITHDRAWN,
    ACCEPTED
}

enum class RfqSide(val displayName: String) {
    BID_WANTED("Bid Wanted (We want to Sell)"),
    OFFER_WANTED("Offer Wanted (We want to Buy)"),
    TWO_WAY("Two-Way (Bid & Offer)")
}

enum class RfqStatus {
    OPEN,
    QUOTED,
    NEGOTIATING,
    FILLED,
    EXPIRED,
    CANCELLED
}

data class DealerQuote(
    val id: String,
    val rfqId: String,
    val dealerName: String,
    val perspective: QuotePerspective,
    val quoteType: QuoteType,
    val status: QuoteStatus = QuoteStatus.LIVE,
    val price: Double? = null,             // For Cash Notes: e.g. 96.85 per 100
    val spreadBps: Int? = null,            // For Synthetic Tranches: e.g. 335 bps
    val maxQuantity: Double,               // Maximum available notional / face
    val minQuantity: Double,
    val allowsPartialExecution: Boolean = true,
    val validUntilEpochMillis: Long,
    val discountMarginBps: Int = 0,        // DM calculated against SOFR/Benchmark
    val allInConsiderationEstimated: Double,
    val receivedTimestamp: Long = System.currentTimeMillis()
) {
    val isFirm: Boolean get() = quoteType == QuoteType.FIRM
    fun isExpired(now: Long = System.currentTimeMillis()): Boolean =
        status == QuoteStatus.EXPIRED || now > validUntilEpochMillis
}

data class RfqRequest(
    val id: String,
    val instrumentId: String,
    val instrumentType: InstrumentType,
    val instrumentName: String,
    val side: RfqSide,
    val requestedQuantity: Double,
    val quantityBasis: QuantityBasis,
    val permittedDealers: List<String>,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val expiresEpochMillis: Long,
    val status: RfqStatus = RfqStatus.OPEN,
    val quotes: List<DealerQuote> = emptyList(),
    val selectedQuoteId: String? = null
)
