package com.example.data.model

data class PortfolioRisk(
    val portfolioDv01: Double,        // $ risk per 1 bp interest rate parallel shift
    val portfolioCs01: Double,        // $ risk per 1 bp credit spread widening
    val weightedAverageLife: Double,  // Years
    val portfolioExpectedLossPct: Double,
    val portfolioExpectedLossAmount: Double,
    val correlationSensitivity: Double, // Risk delta per 1% correlation shift
    val spreadDurationYears: Double
)

data class CounterpartyExposure(
    val counterparty: String,
    val grossFundedCashExposure: Double,
    val syntheticNotionalExposure: Double,
    val collateralHeldOrPosted: Double,
    val netExposure: Double,
    val limitAmount: Double = 100_000_000.0,
    val hasApprovedNettingAgreement: Boolean = false,
    val nettingAgreementRef: String? = null
) {
    val limitUtilizationPct: Double get() = if (limitAmount > 0) (grossFundedCashExposure + syntheticNotionalExposure) / limitAmount * 100.0 else 0.0
    val isNearLimit: Boolean get() = limitUtilizationPct >= 80.0
    val isBreached: Boolean get() = limitUtilizationPct > 100.0
}

data class StressScenarioResult(
    val scenarioName: String,
    val scenarioDescription: String,
    val cdrShockPct: Double,
    val cprShockPct: Double,
    val recoveryShockPct: Double,
    val projectedLossAmount: Double,
    val projectedReturnIrrPct: Double,
    val seniorOcImpactPct: Double,
    val mezzanineOcImpactPct: Double,
    val equityTrancheImpairmentPct: Double
)
