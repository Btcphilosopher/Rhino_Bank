package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountBalances
import com.example.data.model.AuditEvent
import com.example.data.model.CashNote
import com.example.data.model.CounterpartyExposure
import com.example.data.model.DealerQuote
import com.example.data.model.InstrumentType
import com.example.data.model.LifecycleEvent
import com.example.data.model.NovationRecord
import com.example.data.model.PositionRecord
import com.example.data.model.QuantityBasis
import com.example.data.model.RfqRequest
import com.example.data.model.RfqSide
import com.example.data.model.SyntheticTranche
import com.example.data.model.TradeRecord
import com.example.data.model.TradeType
import com.example.data.model.ValuationSource
import com.example.data.repository.TrancheDeskRepository
import com.example.engine.PreTradeControls
import com.example.engine.PreTradeValidationResult
import com.example.engine.TrancheWorksAdapter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Workspace(val displayName: String, val iconName: String) {
    MARKET("Market", "ShowChart"),
    RFQS("RFQs", "Forum"),
    TRADE_TICKET("Trade Ticket", "ReceiptLong"),
    POSITIONS("Positions", "AccountBalance"),
    RISK("Risk", "Shield"),
    SETTLEMENT("Settlement", "CheckCircle"),
    SURVEILLANCE("Surveillance", "Visibility")
}

data class DemoMilestone(
    val step: Int,
    val title: String,
    val description: String,
    val isCompleted: Boolean = false,
    val isActive: Boolean = false
)

class TrancheDeskViewModel(
    private val repository: TrancheDeskRepository = TrancheDeskRepository()
) : ViewModel() {

    // Repository flows
    val cashNotes = repository.cashNotes
    val syntheticTranches = repository.syntheticTranches
    val rfqs = repository.rfqs
    val trades = repository.trades
    val positions = repository.positions
    val accountBalances = repository.accountBalances
    val dealerExposures = repository.dealerExposures
    val novations = repository.novations
    val lifecycleEvents = repository.lifecycleEvents
    val auditTrail = repository.auditTrail

    // Current Active Workspace
    private val _currentWorkspace = MutableStateFlow(Workspace.MARKET)
    val currentWorkspace: StateFlow<Workspace> = _currentWorkspace.asStateFlow()

    // Selected Instrument
    private val _selectedInstrumentType = MutableStateFlow(InstrumentType.CASH_CDO_NOTE)
    val selectedInstrumentType: StateFlow<InstrumentType> = _selectedInstrumentType.asStateFlow()

    private val _selectedCashNote = MutableStateFlow<CashNote?>(null)
    val selectedCashNote: StateFlow<CashNote?> = _selectedCashNote.asStateFlow()

    private val _selectedSyntheticTranche = MutableStateFlow<SyntheticTranche?>(null)
    val selectedSyntheticTranche: StateFlow<SyntheticTranche?> = _selectedSyntheticTranche.asStateFlow()

    // Demonstration Lifecycle Milestones
    private val _demoMilestones = MutableStateFlow(
        listOf(
            DemoMilestone(1, "Import & Inspect CDO", "Inspect RHINO-CLO-2024-1 portfolio, collateral, and waterfall structure.", isCompleted = false, isActive = true),
            DemoMilestone(2, "Select Mezzanine Note", "Choose Class C Mezzanine Note (BBB, Factor 0.9700, DM +315 bps).", isCompleted = false, isActive = false),
            DemoMilestone(3, "Request 3 Dealer Quotes", "Broadcast time-limited RFQ to Goldman Sachs, Rhino Securities & J.P. Morgan.", isCompleted = false, isActive = false),
            DemoMilestone(4, "Compare Model vs Market", "Evaluate dealer bid/offer against TrancheWorks fair value mark 96.42.", isCompleted = false, isActive = false),
            DemoMilestone(5, "Partial Purchase Execution", "Accept Goldman quote for partial $5,000,000 face at 96.85.", isCompleted = false, isActive = false),
            DemoMilestone(6, "Affirm Trade Confirmation", "Electronic matching against dealer confirmation feed (SWIFT MT style).", isCompleted = false, isActive = false),
            DemoMilestone(7, "Settle via Euroclear DVP", "Clear cash consideration, factor adjustment, and update settled holdings.", isCompleted = false, isActive = false),
            DemoMilestone(8, "Collateral Deterioration Shock", "Run TrancheWorks stress scenario: CDR jumps to 4.8%, junior OC test breached.", isCompleted = false, isActive = false),
            DemoMilestone(9, "Waterfall Payment Event", "Execute scheduled quarterly waterfall interest and 2% principal amortization.", isCompleted = false, isActive = false),
            DemoMilestone(10, "Synthetic Protection & Novation", "Buy protection on CDX IG Mezzanine 3-7% and initiate novation transfer.", isCompleted = false, isActive = false)
        )
    )
    val demoMilestones: StateFlow<List<DemoMilestone>> = _demoMilestones.asStateFlow()

    // Pre-Trade Validation Results
    private val _preTradeResult = MutableStateFlow<PreTradeValidationResult?>(null)
    val preTradeResult: StateFlow<PreTradeValidationResult?> = _preTradeResult.asStateFlow()

    // Risk Officer Demo Sign-off Toggle
    private val _riskOfficerSignoff = MutableStateFlow(false)
    val riskOfficerSignoff: StateFlow<Boolean> = _riskOfficerSignoff.asStateFlow()

    // Banner Notification
    private val _systemNotification = MutableStateFlow<String?>(null)
    val systemNotification: StateFlow<String?> = _systemNotification.asStateFlow()

    init {
        viewModelScope.launch {
            // Default select the Mezzanine Note
            cashNotes.collect { notes ->
                if (_selectedCashNote.value == null && notes.isNotEmpty()) {
                    val mezz = notes.find { it.trancheId == "RHN-24-1-C" } ?: notes.first()
                    _selectedCashNote.value = mezz
                }
            }
        }
    }

    fun selectWorkspace(workspace: Workspace) {
        _currentWorkspace.value = workspace
    }

    fun selectInstrumentType(type: InstrumentType) {
        _selectedInstrumentType.value = type
    }

    fun selectCashNote(note: CashNote) {
        _selectedCashNote.value = note
        _selectedInstrumentType.value = InstrumentType.CASH_CDO_NOTE
        recalculatePreTrade()
    }

    fun selectSyntheticTranche(tranche: SyntheticTranche) {
        _selectedSyntheticTranche.value = tranche
        _selectedInstrumentType.value = InstrumentType.SYNTHETIC_TRANCHE
    }

    fun setValuationSource(source: ValuationSource) {
        repository.setValuationSource(source)
        _systemNotification.value = "Valuation Source changed to ${source.displayName}"
    }

    fun toggleRiskOfficerSignoff(signed: Boolean) {
        _riskOfficerSignoff.value = signed
        recalculatePreTrade()
    }

    fun clearNotification() {
        _systemNotification.value = null
    }

    fun broadcastRfq(
        instrumentId: String,
        instrumentType: InstrumentType,
        side: RfqSide,
        quantity: Double,
        basis: QuantityBasis,
        dealers: List<String>
    ): RfqRequest {
        val rfq = repository.broadcastRfq(
            instrumentId = instrumentId,
            instrumentType = instrumentType,
            side = side,
            requestedQuantity = quantity,
            quantityBasis = basis,
            permittedDealers = dealers
        )
        _systemNotification.value = "Broadcasted RFQ ${rfq.id} to ${dealers.size} dealers (60s countdown live)."
        _currentWorkspace.value = Workspace.RFQS
        return rfq
    }

    fun executeQuote(
        rfqId: String,
        quoteId: String,
        executedQuantity: Double
    ) {
        val trade = repository.acceptAndExecuteQuote(
            rfqId = rfqId,
            quoteId = quoteId,
            executedQuantity = executedQuantity,
            riskOfficerSignoff = _riskOfficerSignoff.value
        )
        if (trade != null) {
            _systemNotification.value = "Trade ${trade.tradeId} Executed with ${trade.counterparty}! Awaiting affirmation."
            _currentWorkspace.value = Workspace.SETTLEMENT
        } else {
            _systemNotification.value = "Execution failed: Please check quote validity and pre-trade limits."
        }
    }

    fun affirmTrade(tradeId: String) {
        val ok = repository.affirmTrade(tradeId)
        if (ok) {
            _systemNotification.value = "Trade $tradeId confirmed and affirmed. Ready for clearing settlement."
        }
    }

    fun settleTrade(tradeId: String) {
        val ok = repository.settleTrade(tradeId)
        if (ok) {
            _systemNotification.value = "Trade $tradeId SETTLED via DVP. Cash balance and holdings updated."
            _currentWorkspace.value = Workspace.POSITIONS
        }
    }

    fun failSettlement(tradeId: String, reason: String) {
        repository.failSettlement(tradeId, reason)
        _systemNotification.value = "Settlement failure recorded for trade $tradeId."
    }

    fun retrySettlement(tradeId: String) {
        repository.affirmTrade(tradeId)
        _systemNotification.value = "Trade $tradeId re-affirmed. Initiating re-clearing."
    }

    fun applyCollateralDeterioration(dealId: String) {
        val event = repository.applyCollateralDeterioration(dealId)
        _systemNotification.value = "Stress Event Applied: ${event.title}. Junior OC breached."
        _currentWorkspace.value = Workspace.SURVEILLANCE
    }

    fun applyWaterfallDistribution(dealId: String) {
        val event = repository.applyWaterfallDistribution(dealId)
        _systemNotification.value = "Distribution Applied: ${event.title}. Cash credited to account."
        _currentWorkspace.value = Workspace.SURVEILLANCE
    }

    fun createNovation(tradeRef: String, transferee: String, remainingParty: String) {
        val nov = repository.createNovationRequest(tradeRef, transferee, remainingParty)
        _systemNotification.value = "Novation ${nov.novationId} created. Awaiting remaining party consent."
    }

    fun grantNovationDealerConsent(novId: String) {
        repository.grantNovationDealerConsent(novId)
        _systemNotification.value = "Remaining dealer consent granted for $novId."
    }

    fun grantNovationCalcAgentConsent(novId: String) {
        repository.grantNovationCalcAgentConsent(novId)
        _systemNotification.value = "Calculation agent consent & ISDA confirmation verified for $novId."
    }

    fun finalizeNovation(novId: String) {
        val ok = repository.finalizeNovationTransfer(novId)
        if (ok) {
            _systemNotification.value = "Novation $novId transfer complete and legally effective."
        }
    }

    private fun recalculatePreTrade() {
        val note = _selectedCashNote.value ?: return
        val currentBalances = accountBalances.value
        val currentPositions = positions.value
        val dealerExps = dealerExposures.value

        val consideration = TrancheWorksAdapter.calculateConsideration(
            enteredFace = 5_000_000.0,
            principalFactor = note.principalFactor,
            pricePer100 = note.modelPrice,
            basis = QuantityBasis.ORIGINAL_FACE
        )

        val result = PreTradeControls.validateCashTrade(
            note = note,
            tradeType = TradeType.CASH_BUY,
            tradedCurrentFace = 5_000_000.0 * note.principalFactor,
            totalConsideration = consideration,
            counterparty = "Goldman Sachs",
            accountBalances = currentBalances,
            existingPositions = currentPositions,
            existingDealerExposures = dealerExps,
            userIsQibCertified = true,
            riskOfficerSignedOff = _riskOfficerSignoff.value
        )
        _preTradeResult.value = result
    }

    /**
     * Executable Demonstration Lifecycle: Runs each of the 10 steps automatically or on click!
     */
    fun runDemoMilestone(step: Int) {
        when (step) {
            1 -> {
                // Step 1: Inspect Fictional CDO
                _currentWorkspace.value = Workspace.MARKET
                _selectedCashNote.value = cashNotes.value.find { it.trancheId == "RHN-24-1-A" }
                _systemNotification.value = "Demo Step 1: Inspecting RHINO-CLO-2024-1 collateral, WARF 2650, diversity score 74."
                markMilestone(1)
            }
            2 -> {
                // Step 2: Select Mezzanine Note
                _currentWorkspace.value = Workspace.MARKET
                val mezz = cashNotes.value.find { it.trancheId == "RHN-24-1-C" }
                _selectedCashNote.value = mezz
                _systemNotification.value = "Demo Step 2: Selected Class C Mezzanine Note (BBB, Factor 0.9700, Model Price 96.42)."
                markMilestone(2)
            }
            3 -> {
                // Step 3: Broadcast 3 Dealer Quotes
                val mezz = cashNotes.value.find { it.trancheId == "RHN-24-1-C" } ?: return
                broadcastRfq(
                    instrumentId = mezz.trancheId,
                    instrumentType = InstrumentType.CASH_CDO_NOTE,
                    side = RfqSide.OFFER_WANTED, // We want to buy
                    quantity = 10_000_000.0,
                    basis = QuantityBasis.ORIGINAL_FACE,
                    dealers = listOf("Goldman Sachs", "Rhino Securities", "J.P. Morgan")
                )
                _systemNotification.value = "Demo Step 3: Broadcasted RFQ to 3 dealers. Live quotes received with countdown timer."
                markMilestone(3)
            }
            4 -> {
                // Step 4: Compare Model vs Market
                _currentWorkspace.value = Workspace.RFQS
                _systemNotification.value = "Demo Step 4: Comparing dealer executable economics against TrancheWorks fair value mark 96.42."
                markMilestone(4)
            }
            5 -> {
                // Step 5: Partial Purchase Execution
                val latestRfq = rfqs.value.firstOrNull() ?: return
                val gsQuote = latestRfq.quotes.find { it.dealerName == "Goldman Sachs" } ?: latestRfq.quotes.firstOrNull() ?: return
                // Execute partial $5,000,000 out of $10,000,000 quote
                executeQuote(latestRfq.id, gsQuote.id, 5_000_000.0)
                _systemNotification.value = "Demo Step 5: Executed partial purchase of $5,000,000 face at 96.85 with Goldman Sachs."
                markMilestone(5)
            }
            6 -> {
                // Step 6: Affirm Confirmation
                val latestTrade = trades.value.firstOrNull() ?: return
                affirmTrade(latestTrade.tradeId)
                _currentWorkspace.value = Workspace.SETTLEMENT
                _systemNotification.value = "Demo Step 6: Trade ${latestTrade.tradeId} affirmed against SWIFT broker matching feed."
                markMilestone(6)
            }
            7 -> {
                // Step 7: Clear & Settle DVP
                val latestTrade = trades.value.firstOrNull() ?: return
                settleTrade(latestTrade.tradeId)
                _currentWorkspace.value = Workspace.POSITIONS
                _systemNotification.value = "Demo Step 7: Trade settled in Euroclear. Holdings updated and cash deducted."
                markMilestone(7)
            }
            8 -> {
                // Step 8: Collateral Deterioration Stress Scenario
                applyCollateralDeterioration("RHINO-CLO-2024-1")
                _systemNotification.value = "Demo Step 8: Applied collateral deterioration. CDR jumped to 4.8%, junior OC test breached."
                markMilestone(8)
            }
            9 -> {
                // Step 9: Waterfall Distribution
                applyWaterfallDistribution("RHINO-CLO-2024-1")
                _systemNotification.value = "Demo Step 9: Waterfall payment event executed. Interest and amortization credited to cash."
                markMilestone(9)
            }
            10 -> {
                // Step 10: Synthetic Protection & Novation
                val syn = syntheticTranches.value.firstOrNull() ?: return
                val rfq = broadcastRfq(
                    instrumentId = syn.id,
                    instrumentType = InstrumentType.SYNTHETIC_TRANCHE,
                    side = RfqSide.OFFER_WANTED,
                    quantity = 15_000_000.0,
                    basis = QuantityBasis.ORIGINAL_FACE,
                    dealers = listOf("Morgan Stanley", "Rhino Securities")
                )
                val quote = rfq.quotes.firstOrNull()
                if (quote != null) {
                    val trade = repository.acceptAndExecuteQuote(rfq.id, quote.id, 15_000_000.0, true)
                    if (trade != null) {
                        repository.affirmTrade(trade.tradeId)
                        repository.settleTrade(trade.tradeId)
                        // Initiate novation transfer
                        val nov = repository.createNovationRequest(trade.tradeId, "Rhino Apex Credit Fund II", "Morgan Stanley")
                        repository.grantNovationDealerConsent(nov.novationId)
                        repository.grantNovationCalcAgentConsent(nov.novationId)
                        repository.finalizeNovationTransfer(nov.novationId)
                    }
                }
                _currentWorkspace.value = Workspace.SURVEILLANCE
                _systemNotification.value = "Demo Step 10: Synthetic protection trade executed and derivative novation transfer completed!"
                markMilestone(10)
            }
        }
    }

    private fun markMilestone(step: Int) {
        _demoMilestones.update { list ->
            list.map {
                if (it.step == step) {
                    it.copy(isCompleted = true, isActive = false)
                } else if (it.step == step + 1) {
                    it.copy(isActive = true)
                } else it
            }
        }
    }
}
