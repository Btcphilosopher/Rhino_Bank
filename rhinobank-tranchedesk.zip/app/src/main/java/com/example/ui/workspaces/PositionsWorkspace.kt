package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountBalances
import com.example.data.model.PositionRecord
import com.example.data.model.TradeRecord
import com.example.data.model.TradeState
import com.example.data.model.ValuationSource
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberLarge
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyLoss

@Composable
fun PositionsWorkspace(
    positions: List<PositionRecord>,
    trades: List<TradeRecord>,
    accountBalances: AccountBalances,
    onSelectValuationSource: (ValuationSource) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategoryIndex by remember { mutableStateOf(0) } // 0: Settled Holdings, 1: Unsettled Obligations, 2: Executed Trades, 3: Cash & Collateral
    var currentValuationSource by remember { mutableStateOf(ValuationSource.MODEL_MARK) }
    var showValuationMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("positions_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // NAV & Balance Strip
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PORTFOLIO NET ASSET VALUE (NAV)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
                            Text("$${formatMillions(accountBalances.totalNav)}", style = MonospaceNumberLarge, color = GoldPrimary)
                        }

                        // Valuation Source Selector Dropdown
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(GraphiteSurfaceRaised)
                                    .border(0.5.dp, GoldPrimary, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("VALUATION SOURCE", fontSize = 8.sp, color = IvoryDim)
                                    Text(currentValuationSource.displayName, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright)
                                }
                                IconButton(
                                    onClick = { showValuationMenu = true },
                                    modifier = Modifier.size(20.dp).testTag("valuation_source_dropdown")
                                ) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Source", tint = IvorySecondary)
                                }
                            }

                            DropdownMenu(
                                expanded = showValuationMenu,
                                onDismissRequest = { showValuationMenu = false },
                                modifier = Modifier.background(GraphiteSurface)
                            ) {
                                ValuationSource.values().forEach { source ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(source.displayName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                                                Text(source.description, fontSize = 9.sp, color = IvoryMuted)
                                            }
                                        },
                                        onClick = {
                                            currentValuationSource = source
                                            onSelectValuationSource(source)
                                            showValuationMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Key Ledger Breakdown
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GraphiteBase)
                            .clip(RoundedCornerShape(6.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LedgerCell("Settled Cash", "$${formatMillions(accountBalances.cashBalance)}", IvoryPrimary)
                        LedgerCell("Holdings Value", "$${formatMillions(accountBalances.totalSettledHoldingsValue)}", IvoryPrimary)
                        LedgerCell("Unrealized P&L", "${if (accountBalances.totalUnrealizedPnl >= 0) "+$" else "-$"}${formatThousands(Math.abs(accountBalances.totalUnrealizedPnl))}", if (accountBalances.totalUnrealizedPnl >= 0) EmeraldGain else RubyLoss)
                        LedgerCell("Collateral Posted", "$${formatMillions(accountBalances.collateralPosted)}", GoldBright)
                    }
                }
            }
        }

        // Segregated Records Tab Switcher
        item {
            TabRow(
                selectedTabIndex = selectedCategoryIndex,
                containerColor = GraphiteSurface,
                contentColor = IvoryPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp))
            ) {
                Tab(
                    selected = selectedCategoryIndex == 0,
                    onClick = { selectedCategoryIndex = 0 },
                    modifier = Modifier.testTag("tab_settled_holdings")
                ) {
                    Text("SETTLED HOLDINGS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (selectedCategoryIndex == 0) GoldPrimary else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
                Tab(
                    selected = selectedCategoryIndex == 1,
                    onClick = { selectedCategoryIndex = 1 },
                    modifier = Modifier.testTag("tab_unsettled_obligations")
                ) {
                    Text("UNSETTLED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (selectedCategoryIndex == 1) GoldPrimary else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
                Tab(
                    selected = selectedCategoryIndex == 2,
                    onClick = { selectedCategoryIndex = 2 },
                    modifier = Modifier.testTag("tab_executed_trades")
                ) {
                    Text("TRADE RECORDS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (selectedCategoryIndex == 2) GoldPrimary else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
                Tab(
                    selected = selectedCategoryIndex == 3,
                    onClick = { selectedCategoryIndex = 3 },
                    modifier = Modifier.testTag("tab_cash_collateral")
                ) {
                    Text("CASH / COLLATERAL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (selectedCategoryIndex == 3) GoldPrimary else IvoryMuted, modifier = Modifier.padding(vertical = 10.dp))
                }
            }
        }

        // Content
        when (selectedCategoryIndex) {
            0 -> {
                // Settled Holdings
                val settledList = positions.filter { it.settledCurrentFace > 0 }
                if (settledList.isEmpty()) {
                    item {
                        EmptyStateCard("No settled holdings in fund custody.")
                    }
                } else {
                    items(settledList) { pos ->
                        SettledPositionCard(pos)
                    }
                }
            }
            1 -> {
                // Unsettled Obligations
                val pendingTrades = trades.filter { it.state == TradeState.EXECUTED || it.state == TradeState.CONFIRMED || it.state == TradeState.SETTLEMENT_PENDING }
                if (pendingTrades.isEmpty()) {
                    item {
                        EmptyStateCard("No unsettled trading obligations pending.")
                    }
                } else {
                    items(pendingTrades) { trd ->
                        UnsettledTradeCard(trd)
                    }
                }
            }
            2 -> {
                // Full Trade Records
                if (trades.isEmpty()) {
                    item {
                        EmptyStateCard("No trade executions recorded yet.")
                    }
                } else {
                    items(trades) { trd ->
                        FullTradeRecordCard(trd)
                    }
                }
            }
            3 -> {
                // Cash & Collateral
                item {
                    CashAndCollateralLedger(accountBalances)
                }
            }
        }
    }
}

@Composable
private fun SettledPositionCard(pos: PositionRecord) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(pos.instrumentName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                    Text("ISIN: ${pos.isin} • Principal Factor: ${String.format("%.4f", pos.principalFactor)}", style = MonospaceNumberSmall, color = IvoryDim)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("MARKET VALUE", fontSize = 9.sp, color = IvoryMuted)
                    Text("$${formatMillions(pos.marketValue)}", style = MonospaceNumberMedium, color = GoldPrimary)
                }
            }

            // Metrics Row
            Row(
                modifier = Modifier.fillMaxWidth().background(GraphiteBase).clip(RoundedCornerShape(4.dp)).padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("SETTLED CURR FACE", fontSize = 8.sp, color = IvoryDim)
                    Text("$${formatMillions(pos.settledCurrentFace)}", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("ORIGINAL FACE", fontSize = 8.sp, color = IvoryDim)
                    Text("$${formatMillions(pos.settledOriginalFace)}", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("VALUATION MARK", fontSize = 8.sp, color = IvoryDim)
                    Text("${String.format("%.2f", pos.valuationPrice)}", style = MonospaceNumberSmall, color = IvoryPrimary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("UNREALIZED P&L", fontSize = 8.sp, color = IvoryDim)
                    Text(
                        text = "${if (pos.unrealizedPnl >= 0) "+$" else "-$"}${formatThousands(Math.abs(pos.unrealizedPnl))}",
                        style = MonospaceNumberSmall,
                        color = if (pos.unrealizedPnl >= 0) EmeraldGain else RubyLoss
                    )
                }
            }

            // Accrued Interest & Source
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Accrued Receivable: $${String.format("%,.2f", pos.accruedInterestReceivable)}", fontSize = 10.sp, color = IvorySecondary)
                Text("Valuation: ${pos.valuationSource.displayName}", fontSize = 9.sp, color = IvoryDim)
            }
        }
    }
}

@Composable
private fun UnsettledTradeCard(trade: TradeRecord) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(trade.tradeId, style = MonospaceNumberMedium, color = GoldPrimary)
                Text(trade.state.displayName, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright)
            }
            Text("${trade.tradeType.displayName} • ${trade.instrumentName}", fontSize = 11.sp, color = IvoryPrimary)
            Text("Counterparty: ${trade.counterparty} • Settle Date: ${trade.settlementDate}", fontSize = 10.sp, color = IvoryMuted)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Traded Face: $${formatMillions(trade.currentFace)}", style = MonospaceNumberSmall, color = IvorySecondary)
                Text("Settlement Cash: $${String.format("%,.2f", trade.totalSettlementAmount)}", style = MonospaceNumberSmall, color = GoldBright)
            }
        }
    }
}

@Composable
private fun FullTradeRecordCard(trade: TradeRecord) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(0.5.dp, GraphiteBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(trade.tradeId, style = MonospaceNumberSmall, color = GoldPrimary)
                Text(trade.state.displayName, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (trade.state == TradeState.SETTLED) EmeraldGain else IvorySecondary)
            }
            Text("${trade.tradeType.displayName}: ${trade.instrumentName}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
            Text("Counterparty: ${trade.counterparty} | Price: ${trade.price} | Trade Date: ${trade.tradeDate}", fontSize = 9.sp, color = IvoryDim)
            Text("Consideration: $${String.format("%,.2f", trade.considerationBeforeAccrued)} | Accrued: $${String.format("%,.2f", trade.accruedInterest)} | Total: $${String.format("%,.2f", trade.totalSettlementAmount)}", style = MonospaceNumberSmall, color = IvorySecondary)
        }
    }
}

@Composable
private fun CashAndCollateralLedger(balances: AccountBalances) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("DESK CASH & COLLATERAL (CSA) LEDGER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright)
            LedgerRow("Gross Settled Cash Balance", "$${String.format("%,.2f", balances.cashBalance)}")
            LedgerRow("Unsettled Cash Obligations (DVP Outflows)", "-$${String.format("%,.2f", balances.unsettledObligationsCash)}")
            LedgerRow("Available Unencumbered Cash", "$${String.format("%,.2f", balances.availableCash)}")
            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(GraphiteBorder))
            LedgerRow("Initial Margin Posted (ISDA CSA Bilateral)", "$${String.format("%,.2f", balances.collateralPosted)}")
            LedgerRow("Initial Margin Threshold Remaining", "$${String.format("%,.2f", balances.initialMarginThreshold - balances.collateralPosted)}")
            LedgerRow("Variation Margin (VM) Mark-to-Market Call", "$0.00 (Collateralized)")
        }
    }
}

@Composable
private fun LedgerCell(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color) {
    Column {
        Text(label, fontSize = 8.sp, color = IvoryDim)
        Text(value, style = MonospaceNumberSmall, color = valueColor)
    }
}

@Composable
private fun LedgerRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 10.sp, color = IvoryMuted)
        Text(value, style = MonospaceNumberSmall, color = IvorySecondary)
    }
}

@Composable
private fun EmptyStateCard(message: String) {
    Box(
        modifier = Modifier.fillMaxWidth().background(GraphiteSurface).border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(message, color = IvoryMuted, fontSize = 12.sp)
    }
}

private fun formatMillions(n: Double): String {
    return if (n >= 1_000_000) String.format("%.2fM", n / 1_000_000.0)
    else String.format("%,.0f", n)
}

private fun formatThousands(n: Double): String {
    return String.format("%,.0f", n)
}
