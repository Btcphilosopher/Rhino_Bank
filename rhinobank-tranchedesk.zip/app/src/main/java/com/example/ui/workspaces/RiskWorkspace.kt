package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CounterpartyExposure
import com.example.data.model.PortfolioRisk
import com.example.data.model.PositionRecord
import com.example.data.model.StressScenarioResult
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyContainer
import com.example.ui.theme.RubyLoss

@Composable
fun RiskWorkspace(
    dealerExposures: List<CounterpartyExposure>,
    positions: List<PositionRecord>,
    modifier: Modifier = Modifier
) {
    val totalNotional = positions.sumOf { it.settledCurrentFace }
    val cs01 = totalNotional * 0.00018 // approx $18k per bp
    val dv01 = totalNotional * 0.000045 // approx $4.5k per bp

    val stressScenarios = listOf(
        StressScenarioResult(
            scenarioName = "Base Case (TrancheWorks Model Assumptions)",
            scenarioDescription = "CDR 1.8%, CPR 15.0%, Recovery 65.0%. All waterfall OC tests satisfied.",
            cdrShockPct = 1.8,
            cprShockPct = 15.0,
            recoveryShockPct = 65.0,
            projectedLossAmount = 0.0,
            projectedReturnIrrPct = 7.42,
            seniorOcImpactPct = 0.0,
            mezzanineOcImpactPct = 0.0,
            equityTrancheImpairmentPct = 0.0
        ),
        StressScenarioResult(
            scenarioName = "Mild Spread Shock (+50 bps) & Modest CDR",
            scenarioDescription = "CDR 2.8%, CPR 10.0%, Recovery 60.0%. Junior OC buffer narrows by 3.4%.",
            cdrShockPct = 2.8,
            cprShockPct = 10.0,
            recoveryShockPct = 60.0,
            projectedLossAmount = 2_150_000.0,
            projectedReturnIrrPct = 4.15,
            seniorOcImpactPct = -1.2,
            mezzanineOcImpactPct = -3.4,
            equityTrancheImpairmentPct = 12.0
        ),
        StressScenarioResult(
            scenarioName = "Severe Credit Crunch / Default Spike",
            scenarioDescription = "CDR 4.8%, CPR 8.0%, Recovery 45.0%. Mezzanine C Junior OC breaches 108% trigger, cash diverted to senior notes.",
            cdrShockPct = 4.8,
            cprShockPct = 8.0,
            recoveryShockPct = 45.0,
            projectedLossAmount = 8_750_000.0,
            projectedReturnIrrPct = -3.80,
            seniorOcImpactPct = -4.1,
            mezzanineOcImpactPct = -9.8,
            equityTrancheImpairmentPct = 68.0
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("risk_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Portfolio Sensitivities Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("PORTFOLIO RISK SENSITIVITIES & DURATION METRICS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
                        Icon(Icons.Default.Shield, contentDescription = "Risk", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SensitivityBox("CS01 (Credit Spread 01)", "-$${formatThousands(cs01)}", "Dollar loss per 1 bp widening", RubyLoss, Modifier.weight(1f))
                        SensitivityBox("DV01 (Interest Rate 01)", "-$${formatThousands(dv01)}", "Dollar loss per 1 bp SOFR rise", RubyLoss, Modifier.weight(1f))
                        SensitivityBox("Spread Duration", "4.2 Years", "Weighted average duration", IvoryPrimary, Modifier.weight(1f))
                        SensitivityBox("Correlation Delta", "$9,400 / 1%", "Sensitivity to default correlation", GoldBright, Modifier.weight(1f))
                    }
                }
            }
        }

        // Stress Scenario Analysis
        item {
            Text("TRANCHEWORKS WATERFALL DEFAULT & RECOVERY STRESS SCENARIOS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
        }

        items(stressScenarios) { sc ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(0.5.dp, if (sc.projectedReturnIrrPct < 0) RubyLoss.copy(alpha = 0.5f) else GraphiteBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(sc.scenarioName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IvoryPrimary)
                        Text(
                            text = "PROJECTED IRR: ${String.format("%.2f", sc.projectedReturnIrrPct)}%",
                            style = MonospaceNumberSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (sc.projectedReturnIrrPct >= 0) EmeraldGain else RubyLoss
                        )
                    }
                    Text(sc.scenarioDescription, fontSize = 10.sp, color = IvoryMuted)
                    Row(
                        modifier = Modifier.fillMaxWidth().background(GraphiteBase).clip(RoundedCornerShape(4.dp)).padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("CDR: ${sc.cdrShockPct}%", style = MonospaceNumberSmall, color = IvorySecondary)
                        Text("CPR: ${sc.cprShockPct}%", style = MonospaceNumberSmall, color = IvorySecondary)
                        Text("Recovery: ${sc.recoveryShockPct}%", style = MonospaceNumberSmall, color = IvorySecondary)
                        Text("Mezz OC Shock: ${sc.mezzanineOcImpactPct}%", style = MonospaceNumberSmall, color = if (sc.mezzanineOcImpactPct < -5.0) RubyLoss else IvorySecondary)
                        Text("Equity Impairment: ${sc.equityTrancheImpairmentPct}%", style = MonospaceNumberSmall, color = if (sc.equityTrancheImpairmentPct > 0) RubyLoss else IvorySecondary)
                    }
                }
            }
        }

        // Counterparty Exposure & Limits (Rule 9: Do not net exposures across counterparties without explicit supported netting policy)
        item {
            Text("COUNTERPARTY EXPOSURE & CONCENTRATION LIMITS ($100M LIMIT)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
        }

        items(dealerExposures) { exp ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(0.5.dp, if (exp.isNearLimit) AmberPending else GraphiteBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(exp.counterparty, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IvoryPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            if (exp.hasApprovedNettingAgreement) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(EmeraldContainer)
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("APPROVED NETTING", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = EmeraldGain)
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(AmberContainer)
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("GROSS EXPOSURE (NO NETTING)", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = AmberPending)
                                }
                            }
                        }

                        Text(
                            text = "${String.format("%.1f", exp.limitUtilizationPct)}% Utilized",
                            style = MonospaceNumberSmall,
                            color = if (exp.isNearLimit) AmberPending else EmeraldGain
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().background(GraphiteBase).clip(RoundedCornerShape(4.dp)).padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("GROSS CASH EXP", fontSize = 8.sp, color = IvoryDim)
                            Text("$${formatMillions(exp.grossFundedCashExposure)}", style = MonospaceNumberSmall, color = IvorySecondary)
                        }
                        Column {
                            Text("SYNTHETIC NOTIONAL", fontSize = 8.sp, color = IvoryDim)
                            Text("$${formatMillions(exp.syntheticNotionalExposure)}", style = MonospaceNumberSmall, color = IvorySecondary)
                        }
                        Column {
                            Text("NET RISK EXPOSURE", fontSize = 8.sp, color = IvoryDim)
                            Text("$${formatMillions(exp.netExposure)}", style = MonospaceNumberSmall, color = IvoryPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("LIMIT CEILING", fontSize = 8.sp, color = IvoryDim)
                            Text("$${formatMillions(exp.limitAmount)}", style = MonospaceNumberSmall, color = GoldBright)
                        }
                    }

                    if (exp.nettingAgreementRef != null) {
                        Text("Documentation: ISDA Master Agreement Ref: ${exp.nettingAgreementRef}", fontSize = 9.sp, color = IvoryDim)
                    }
                }
            }
        }
    }
}

@Composable
private fun SensitivityBox(label: String, value: String, description: String, valueColor: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(GraphiteBase)
            .border(0.5.dp, GraphiteBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(label, fontSize = 8.sp, color = IvoryMuted)
            Text(value, style = MonospaceNumberMedium, color = valueColor)
            Text(description, fontSize = 7.sp, color = IvoryDim, lineHeight = 10.sp)
        }
    }
}

private fun formatMillions(n: Double): String {
    return if (n >= 1_000_000) String.format("%.1fM", n / 1_000_000.0)
    else String.format("%,.0f", n)
}

private fun formatThousands(n: Double): String {
    return String.format("%,.0f", n)
}
