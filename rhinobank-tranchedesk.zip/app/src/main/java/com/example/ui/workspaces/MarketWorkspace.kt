package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CashNote
import com.example.data.model.InstrumentType
import com.example.data.model.RatingTier
import com.example.data.model.SyntheticTranche
import com.example.ui.Workspace
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanSynthetic
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.PurpleMezzanine
import com.example.ui.theme.RubyContainer
import com.example.ui.theme.RubyLoss

@Composable
fun MarketWorkspace(
    cashNotes: List<CashNote>,
    syntheticTranches: List<SyntheticTranche>,
    selectedCashNote: CashNote?,
    selectedSyntheticTranche: SyntheticTranche?,
    selectedInstrumentType: InstrumentType,
    onSelectCashNote: (CashNote) -> Unit,
    onSelectSyntheticTranche: (SyntheticTranche) -> Unit,
    onSelectInstrumentType: (InstrumentType) -> Unit,
    onNavigateWorkspace: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("market_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Instrument Type Switcher & Search
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TabRow(
                        selectedTabIndex = if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE) 0 else 1,
                        containerColor = GraphiteSurface,
                        contentColor = IvoryPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp))
                    ) {
                        Tab(
                            selected = selectedInstrumentType == InstrumentType.CASH_CDO_NOTE,
                            onClick = { onSelectInstrumentType(InstrumentType.CASH_CDO_NOTE) },
                            modifier = Modifier.testTag("tab_cash_notes")
                        ) {
                            Text(
                                "FUNDED CASH CDO NOTES",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE) GoldPrimary else IvoryMuted,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                        Tab(
                            selected = selectedInstrumentType == InstrumentType.SYNTHETIC_TRANCHE,
                            onClick = { onSelectInstrumentType(InstrumentType.SYNTHETIC_TRANCHE) },
                            modifier = Modifier.testTag("tab_synthetic_tranches")
                        ) {
                            Text(
                                "SYNTHETIC CREDIT TRANCHES",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedInstrumentType == InstrumentType.SYNTHETIC_TRANCHE) CyanSynthetic else IvoryMuted,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    }
                }

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by Deal, ISIN, Tranche, CUSIP, Rating...", fontSize = 11.sp, color = IvoryMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = IvoryMuted, modifier = Modifier.size(16.dp)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = GraphiteSurface,
                        unfocusedContainerColor = GraphiteSurface,
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GraphiteBorder,
                        focusedTextColor = IvoryPrimary,
                        unfocusedTextColor = IvoryPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().height(46.dp).testTag("instrument_search_field")
                )
            }
        }

        // Instrument Master List
        item {
            Text(
                text = if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE) "CDO NOTE SECONDARY MARKET" else "SYNTHETIC TRANCHE MARKET",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = IvoryPrimary,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp
            )
        }

        if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE) {
            val filtered = cashNotes.filter {
                it.trancheName.contains(searchQuery, ignoreCase = true) ||
                it.dealId.contains(searchQuery, ignoreCase = true) ||
                it.isin.contains(searchQuery, ignoreCase = true) ||
                it.rating.name.contains(searchQuery, ignoreCase = true)
            }

            items(filtered) { note ->
                val isSelected = selectedCashNote?.trancheId == note.trancheId
                CashNoteCard(
                    note = note,
                    isSelected = isSelected,
                    onClick = { onSelectCashNote(note) }
                )
            }
        } else {
            val filtered = syntheticTranches.filter {
                it.trancheName.contains(searchQuery, ignoreCase = true) ||
                it.referencePortfolio.contains(searchQuery, ignoreCase = true)
            }

            items(filtered) { syn ->
                val isSelected = selectedSyntheticTranche?.id == syn.id
                SyntheticTrancheCard(
                    tranche = syn,
                    isSelected = isSelected,
                    onClick = { onSelectSyntheticTranche(syn) }
                )
            }
        }

        // Selected Tranche Deep-Dive Details
        item {
            Spacer(modifier = Modifier.height(6.dp))
            if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE && selectedCashNote != null) {
                CashNoteDetailPanel(
                    note = selectedCashNote,
                    onOpenRfq = { onNavigateWorkspace(Workspace.RFQS) },
                    onOpenTicket = { onNavigateWorkspace(Workspace.TRADE_TICKET) }
                )
            } else if (selectedSyntheticTranche != null) {
                SyntheticTrancheDetailPanel(
                    tranche = selectedSyntheticTranche,
                    onOpenRfq = { onNavigateWorkspace(Workspace.RFQS) },
                    onOpenTicket = { onNavigateWorkspace(Workspace.TRADE_TICKET) }
                )
            }
        }
    }
}

@Composable
private fun CashNoteCard(
    note: CashNote,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) GraphiteSurfaceRaised else GraphiteSurface
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (isSelected) GoldPrimary else GraphiteBorder,
                RoundedCornerShape(8.dp)
            )
            .testTag("cash_note_item_${note.trancheId}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RatingBadge(note.rating)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = note.trancheName,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) GoldBright else IvoryPrimary,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${note.dealId} • ISIN: ${note.isin}",
                            style = MonospaceNumberSmall,
                            color = IvoryDim,
                            fontSize = 10.sp
                        )
                    }
                }

                // TrancheWorks Model Price
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "MODEL MARK",
                        fontSize = 9.sp,
                        color = IvoryMuted
                    )
                    Text(
                        text = "${String.format("%.2f", note.modelPrice)}",
                        style = MonospaceNumberMedium,
                        color = GoldPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metrics Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("COUPON", fontSize = 8.sp, color = IvoryDim)
                    Text("${note.couponBenchmark} +${note.couponSpreadBps}", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("FACTOR", fontSize = 8.sp, color = IvoryDim)
                    Text(String.format("%.4f", note.principalFactor), style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("WAL", fontSize = 8.sp, color = IvoryDim)
                    Text("${note.walYears}y", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("JUNIOR OC", fontSize = 8.sp, color = IvoryDim)
                    val isPass = !note.isDistressed
                    Text(
                        "${String.format("%.1f", note.juniorOvercollateralizationPct)}%",
                        style = MonospaceNumberSmall,
                        color = if (isPass) EmeraldGain else RubyLoss
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("IND. BID/OFFER", fontSize = 8.sp, color = IvoryDim)
                    Text(
                        "${note.indicativeBid ?: "-"} / ${note.indicativeOffer ?: "-"}",
                        style = MonospaceNumberSmall,
                        color = IvoryPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun SyntheticTrancheCard(
    tranche: SyntheticTranche,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) GraphiteSurfaceRaised else GraphiteSurface
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (isSelected) CyanSynthetic else GraphiteBorder,
                RoundedCornerShape(8.dp)
            )
            .testTag("synthetic_tranche_item_${tranche.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyanContainer)
                                .border(0.5.dp, CyanSynthetic, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("SYNTHETIC", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = CyanSynthetic)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tranche.trancheName,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) CyanSynthetic else IvoryPrimary,
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        text = "${tranche.referencePortfolio} (${tranche.portfolioVersion}) • ${tranche.underlyingEntitiesCount} Names",
                        fontSize = 10.sp,
                        color = IvoryDim
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("RUNNING SPREAD", fontSize = 9.sp, color = IvoryMuted)
                    Text("${tranche.runningPremiumBps} bps", style = MonospaceNumberMedium, color = CyanSynthetic)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("ATTACH-DETACH", fontSize = 8.sp, color = IvoryDim)
                    Text("${tranche.attachmentPoint}% – ${tranche.detachmentPoint}%", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("UPFRONT", fontSize = 8.sp, color = IvoryDim)
                    Text("${tranche.upfrontPct}%", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("INITIAL MARGIN", fontSize = 8.sp, color = IvoryDim)
                    Text("${tranche.initialMarginPct}%", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("MODEL SPREAD", fontSize = 8.sp, color = IvoryDim)
                    Text("${tranche.modelSpreadBps} bps", style = MonospaceNumberSmall, color = GoldPrimary)
                }
            }
        }
    }
}

@Composable
private fun CashNoteDetailPanel(
    note: CashNote,
    onOpenRfq: () -> Unit,
    onOpenTicket: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
            .testTag("cash_note_detail_panel")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TRANCHEWORKS COLLATERAL & WATERFALL INSPECTION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
                    Text(note.trancheName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                }
                RatingBadge(note.rating)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Waterfall Coverage Tests
            Text("WATERFALL OVERCOLLATERALIZATION & COVERAGE TESTS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CoverageCard("Senior OC", "${note.seniorOvercollateralizationPct}%", "Trigger: 125.0%", isPassing = note.seniorOvercollateralizationPct >= 125.0, modifier = Modifier.weight(1f))
                CoverageCard("Junior/Mezz OC", "${note.juniorOvercollateralizationPct}%", "Trigger: ${note.overcollateralizationTriggerPct}%", isPassing = !note.isDistressed, modifier = Modifier.weight(1f))
                CoverageCard("Interest Coverage", "${note.interestCoveragePct}%", "Trigger: 110.0%", isPassing = note.interestCoveragePct >= 110.0, modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Underlying Portfolio Characteristics
            Text("COLLATERAL POOL CHARACTERISTICS (TrancheWorks Engine)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
            Spacer(modifier = Modifier.height(6.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DetailRow("Collateral Balance", "$${String.format("%,.0f", note.collateralBalance)}")
                DetailRow("Diversity Score / WARF", "${note.diversityScore} / WARF ${note.warfRating}")
                DetailRow("Assumptions (CPR / CDR / Recovery)", "${note.constantPrepaymentRate}% CPR • ${note.constantDefaultRate}% CDR • ${note.recoveryRate}% Rec")
                DetailRow("Expected Loss / WAL", "${note.expectedLossPct}% / ${note.walYears} Years")
                DetailRow("Transfer Restrictions", note.transferRestrictions.joinToString { it.displayName })
                DetailRow("Settlement Convention", note.settlementConvention.displayName)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenRfq,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = GraphiteBase),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(40.dp).testTag("detail_request_rfq_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "RFQ", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("REQUEST RFQ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenTicket,
                    colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurfaceRaised, contentColor = IvoryPrimary),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(40.dp).border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp)).testTag("detail_trade_ticket_button")
                ) {
                    Icon(Icons.Default.Receipt, contentDescription = "Ticket", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("TRADE TICKET", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SyntheticTrancheDetailPanel(
    tranche: SyntheticTranche,
    onOpenRfq: () -> Unit,
    onOpenTicket: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyanContainer, RoundedCornerShape(8.dp))
            .testTag("synthetic_tranche_detail_panel")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("SYNTHETIC TRANCHE CONTRACT SPECIFICATIONS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyanSynthetic, letterSpacing = 0.5.sp)
            Text(tranche.trancheName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = IvoryPrimary)

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteBase)
                    .clip(RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DetailRow("Reference Portfolio", "${tranche.referencePortfolio} (${tranche.portfolioVersion})")
                DetailRow("Attachment / Detachment", "${tranche.attachmentPoint}% / ${tranche.detachmentPoint}% (Width: ${tranche.trancheWidthPct}%)")
                DetailRow("Running Premium", "${tranche.runningPremiumBps} bps per annum")
                DetailRow("Upfront Payment", "${tranche.upfrontPct}% (${tranche.upfrontDirection})")
                DetailRow("CSA Bilateral Collateral", "${tranche.csaAgreement} (${tranche.initialMarginPct}% Initial Margin)")
                DetailRow("Credit Events", tranche.creditEvents.joinToString(", "))
                DetailRow("Settlement Method", tranche.settlementMethod)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onOpenRfq,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanSynthetic, contentColor = GraphiteBase),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(40.dp).testTag("detail_request_syn_rfq_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "RFQ", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("BROADCAST RFQ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenTicket,
                    colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurfaceRaised, contentColor = IvoryPrimary),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(40.dp).border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp)).testTag("detail_syn_ticket_button")
                ) {
                    Icon(Icons.Default.Receipt, contentDescription = "Ticket", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PROTECTION TICKET", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun CoverageCard(
    label: String,
    value: String,
    trigger: String,
    isPassing: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(if (isPassing) EmeraldContainer.copy(alpha = 0.3f) else RubyContainer.copy(alpha = 0.4f))
            .border(0.5.dp, if (isPassing) EmeraldGain else RubyLoss, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(label, fontSize = 9.sp, color = IvoryMuted)
            Text(value, style = MonospaceNumberMedium, color = if (isPassing) EmeraldGain else RubyLoss)
            Text(trigger, fontSize = 8.sp, color = IvoryDim)
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 10.sp, color = IvoryMuted)
        Text(value, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = IvorySecondary)
    }
}

@Composable
private fun RatingBadge(rating: RatingTier) {
    val (bg, fg) = when (rating) {
        RatingTier.AAA, RatingTier.AA, RatingTier.A -> Pair(EmeraldContainer, EmeraldGain)
        RatingTier.BBB_MEZZ, RatingTier.BB_MEZZ -> Pair(GoldContainer, GoldBright)
        RatingTier.SUBORDINATE_EQUITY -> Pair(RubyContainer, RubyLoss)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .border(0.5.dp, fg, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = rating.name.replace("_", " "),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}
