package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CashNote
import com.example.data.model.DealerQuote
import com.example.data.model.InstrumentType
import com.example.data.model.QuantityBasis
import com.example.data.model.QuotePerspective
import com.example.data.model.QuoteStatus
import com.example.data.model.QuoteType
import com.example.data.model.RfqRequest
import com.example.data.model.RfqSide
import com.example.data.model.RfqStatus
import com.example.data.model.SyntheticTranche
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanSynthetic
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyContainer
import com.example.ui.theme.RubyLoss
import kotlinx.coroutines.delay

@Composable
fun RfqWorkspace(
    selectedCashNote: CashNote?,
    selectedSyntheticTranche: SyntheticTranche?,
    selectedInstrumentType: InstrumentType,
    rfqs: List<RfqRequest>,
    onBroadcastRfq: (String, InstrumentType, RfqSide, Double, QuantityBasis, List<String>) -> Unit,
    onExecuteQuote: (String, String, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val availableDealers = listOf("Goldman Sachs", "Rhino Securities", "J.P. Morgan", "Morgan Stanley", "Barclays", "BNP Paribas")
    var selectedDealers by remember { mutableStateOf(listOf("Goldman Sachs", "Rhino Securities", "J.P. Morgan")) }
    var rfqSide by remember { mutableStateOf(RfqSide.OFFER_WANTED) } // We want to buy
    var sizeInput by remember { mutableStateOf("10000000") } // $10M default
    var quantityBasis by remember { mutableStateOf(QuantityBasis.ORIGINAL_FACE) }

    // Counteroffer modal state
    var counterofferQuoteId by remember { mutableStateOf<String?>(null) }
    var counterofferPrice by remember { mutableStateOf("") }

    val instrumentId = if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE) {
        selectedCashNote?.trancheId ?: "RHN-24-1-C"
    } else {
        selectedSyntheticTranche?.id ?: "SYN-CDX-42-MEZZ-3-7"
    }
    val instrumentName = if (selectedInstrumentType == InstrumentType.CASH_CDO_NOTE) {
        selectedCashNote?.trancheName ?: "Class C Mezzanine Note"
    } else {
        selectedSyntheticTranche?.trancheName ?: "CDX IG Mezzanine 3-7%"
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("rfq_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // RFQ Broadcast Creator Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                    .testTag("rfq_creator_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("MULTI-DEALER RFQ NEGOTIATION DESK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
                            Text(instrumentName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = IvoryPrimary)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(GraphiteSurfaceRaised)
                                .border(0.5.dp, GraphiteBorder, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(instrumentId, style = MonospaceNumberSmall, color = IvorySecondary)
                        }
                    }

                    // Side Selector Tabs
                    TabRow(
                        selectedTabIndex = rfqSide.ordinal,
                        containerColor = GraphiteBase,
                        contentColor = IvoryPrimary,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp))
                    ) {
                        RfqSide.values().forEach { side ->
                            Tab(
                                selected = rfqSide == side,
                                onClick = { rfqSide = side },
                                modifier = Modifier.testTag("rfq_side_${side.name.lowercase()}")
                            ) {
                                Text(
                                    text = when (side) {
                                        RfqSide.OFFER_WANTED -> "OFFER WANTED (BUY)"
                                        RfqSide.BID_WANTED -> "BID WANTED (SELL)"
                                        RfqSide.TWO_WAY -> "TWO-WAY (BID/OFFER)"
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (rfqSide == side) GoldPrimary else IvoryMuted,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                )
                            }
                        }
                    }

                    // Quantity and Basis
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = sizeInput,
                            onValueChange = { sizeInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Requested Size ($)", fontSize = 10.sp, color = IvoryMuted) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = GraphiteBase,
                                unfocusedContainerColor = GraphiteBase,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GraphiteBorder,
                                focusedTextColor = IvoryPrimary,
                                unfocusedTextColor = IvoryPrimary
                            ),
                            modifier = Modifier.weight(1f).testTag("rfq_size_input")
                        )

                        // Quantity Basis Toggle
                        Column(modifier = Modifier.weight(1f)) {
                            Text("QUANTITY BASIS", fontSize = 9.sp, color = IvoryMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(GraphiteBase)
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(1.dp, GraphiteBorder, RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(if (quantityBasis == QuantityBasis.ORIGINAL_FACE) GoldContainer else GraphiteBase)
                                        .clickable { quantityBasis = QuantityBasis.ORIGINAL_FACE }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("ORIG FACE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (quantityBasis == QuantityBasis.ORIGINAL_FACE) GoldBright else IvoryMuted)
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(if (quantityBasis == QuantityBasis.CURRENT_FACE) GoldContainer else GraphiteBase)
                                        .clickable { quantityBasis = QuantityBasis.CURRENT_FACE }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("CURR FACE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (quantityBasis == QuantityBasis.CURRENT_FACE) GoldBright else IvoryMuted)
                                }
                            }
                        }
                    }

                    // Dealer Selection
                    Column {
                        Text("SELECT PERMITTED COUNTERPARTIES (${selectedDealers.size} SELECTED)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableDealers.take(3).forEach { dealer ->
                                val isChecked = selectedDealers.contains(dealer)
                                DealerChip(
                                    dealer = dealer,
                                    isSelected = isChecked,
                                    onToggle = {
                                        selectedDealers = if (isChecked) selectedDealers - dealer else selectedDealers + dealer
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableDealers.drop(3).forEach { dealer ->
                                val isChecked = selectedDealers.contains(dealer)
                                DealerChip(
                                    dealer = dealer,
                                    isSelected = isChecked,
                                    onToggle = {
                                        selectedDealers = if (isChecked) selectedDealers - dealer else selectedDealers + dealer
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Broadcast Button
                    Button(
                        onClick = {
                            val qty = sizeInput.toDoubleOrNull() ?: 10_000_000.0
                            if (selectedDealers.isNotEmpty()) {
                                onBroadcastRfq(
                                    instrumentId,
                                    selectedInstrumentType,
                                    rfqSide,
                                    qty,
                                    quantityBasis,
                                    selectedDealers
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = GraphiteBase),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(42.dp).testTag("broadcast_rfq_button")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Broadcast", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BROADCAST RFQ TO ${selectedDealers.size} DEALERS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // Active RFQs & Quote Feeds
        item {
            Text(
                text = "ACTIVE RFQ STREAMS & DEALER QUOTE BOOKS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = IvoryPrimary,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp
            )
        }

        if (rfqs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GraphiteSurface)
                        .border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No active RFQs. Select an instrument and click 'Broadcast RFQ'.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(rfqs) { rfq ->
                RfqStreamCard(
                    rfq = rfq,
                    onExecuteQuote = onExecuteQuote,
                    onCounteroffer = { qId, currPrice ->
                        counterofferQuoteId = qId
                        counterofferPrice = currPrice.toString()
                    }
                )
            }
        }
    }
}

@Composable
private fun RfqStreamCard(
    rfq: RfqRequest,
    onExecuteQuote: (String, String, Double) -> Unit,
    onCounteroffer: (String, Double) -> Unit
) {
    // Dynamic countdown timer state
    var millisRemaining by remember(rfq.id) { mutableStateOf(rfq.expiresEpochMillis - System.currentTimeMillis()) }

    LaunchedEffect(rfq.id, rfq.status) {
        while (millisRemaining > 0 && rfq.status == RfqStatus.QUOTED) {
            delay(1000)
            millisRemaining = (rfq.expiresEpochMillis - System.currentTimeMillis()).coerceAtLeast(0)
        }
    }

    val secondsRemaining = (millisRemaining / 1000).coerceAtLeast(0)
    val isExpired = secondsRemaining <= 0 || rfq.status == RfqStatus.EXPIRED

    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (rfq.status == RfqStatus.FILLED) EmeraldGain.copy(alpha = 0.5f) else GraphiteBorder, RoundedCornerShape(8.dp))
            .testTag("rfq_stream_card_${rfq.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(rfq.id, style = MonospaceNumberMedium, color = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (rfq.status == RfqStatus.FILLED) EmeraldContainer else GraphiteSurfaceRaised)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = rfq.status.name,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (rfq.status == RfqStatus.FILLED) EmeraldGain else IvorySecondary
                            )
                        }
                    }
                    Text(
                        text = "${rfq.instrumentName} • Size: $${formatNumber(rfq.requestedQuantity)} (${rfq.quantityBasis.displayName})",
                        fontSize = 11.sp,
                        color = IvoryMuted
                    )
                }

                // Countdown Timer
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Timer",
                        tint = if (isExpired) RubyLoss else if (secondsRemaining < 15) AmberPending else EmeraldGain,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (rfq.status == RfqStatus.FILLED) "FILLED" else if (isExpired) "EXPIRED" else "${secondsRemaining}s",
                        style = MonospaceNumberMedium,
                        color = if (rfq.status == RfqStatus.FILLED) EmeraldGain else if (isExpired) RubyLoss else IvoryPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quotes List
            Text("DEALER EXECUTABLE ECONOMICS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rfq.quotes.forEach { quote ->
                    DealerQuoteItem(
                        quote = quote,
                        rfq = rfq,
                        isRfqExpired = isExpired,
                        onExecute = { partial ->
                            val qty = if (partial) (quote.maxQuantity / 2.0).coerceAtLeast(quote.minQuantity) else quote.maxQuantity
                            onExecuteQuote(rfq.id, quote.id, qty)
                        },
                        onCounteroffer = {
                            onCounteroffer(quote.id, quote.price ?: 0.0)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun DealerQuoteItem(
    quote: DealerQuote,
    rfq: RfqRequest,
    isRfqExpired: Boolean,
    onExecute: (Boolean) -> Unit,
    onCounteroffer: () -> Unit
) {
    val isAccepted = quote.status == QuoteStatus.ACCEPTED
    val canExecute = !isRfqExpired && quote.status == QuoteStatus.LIVE && rfq.status != RfqStatus.FILLED

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isAccepted) EmeraldContainer.copy(alpha = 0.2f) else GraphiteBase
        ),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                0.5.dp,
                if (isAccepted) EmeraldGain else if (quote.isFirm) GoldContainerBorder else GraphiteBorder,
                RoundedCornerShape(6.dp)
            )
            .testTag("quote_item_${quote.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Dealer Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(quote.dealerName, fontWeight = FontWeight.Bold, color = IvoryPrimary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (quote.isFirm) EmeraldContainer else AmberContainer)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = quote.quoteType.displayName,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (quote.isFirm) EmeraldGain else AmberPending
                        )
                    }
                }

                // Perspective label
                Text(
                    text = quote.perspective.displayName,
                    fontSize = 10.sp,
                    color = if (quote.perspective == QuotePerspective.DEALER_OFFERS_WE_BUY) EmeraldGain else RubyLoss,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Pricing & Economics Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("QUOTE PRICE / SPREAD", fontSize = 8.sp, color = IvoryDim)
                    Text(
                        text = if (quote.price != null) "${String.format("%.2f", quote.price)} (per 100)" else "${quote.spreadBps} bps",
                        style = MonospaceNumberMedium,
                        color = GoldBright
                    )
                }

                Column {
                    Text("AVAILABLE SIZE", fontSize = 8.sp, color = IvoryDim)
                    Text(
                        text = "$${formatNumber(quote.maxQuantity)}",
                        style = MonospaceNumberSmall,
                        color = IvorySecondary
                    )
                }

                Column {
                    Text("DISCOUNT MARGIN", fontSize = 8.sp, color = IvoryDim)
                    Text(
                        text = "+${quote.discountMarginBps} bps",
                        style = MonospaceNumberSmall,
                        color = IvorySecondary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("ALL-IN CASH EST.", fontSize = 8.sp, color = IvoryDim)
                    Text(
                        text = "$${formatNumber(quote.allInConsiderationEstimated)}",
                        style = MonospaceNumberSmall,
                        color = IvoryPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            if (isAccepted) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(EmeraldContainer)
                        .clip(RoundedCornerShape(4.dp))
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("QUOTE ACCEPTED & EXECUTED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldGain)
                }
            } else if (canExecute) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Full Exec
                    Button(
                        onClick = { onExecute(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGain, contentColor = GraphiteBase),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f).height(32.dp).testTag("accept_quote_full_${quote.id}")
                    ) {
                        Text("Accept Full ($${formatNumber(quote.maxQuantity)})", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    // Partial Exec if allowed
                    if (quote.allowsPartialExecution) {
                        Button(
                            onClick = { onExecute(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldContainer, contentColor = GoldBright),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .border(0.5.dp, GoldPrimary, RoundedCornerShape(4.dp))
                                .testTag("accept_quote_partial_${quote.id}")
                        ) {
                            Text("Partial ($5.0M)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Counteroffer
                    Button(
                        onClick = onCounteroffer,
                        colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurfaceRaised, contentColor = IvorySecondary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(32.dp).border(0.5.dp, GraphiteBorder, RoundedCornerShape(4.dp)).testTag("counteroffer_${quote.id}")
                    ) {
                        Text("Counter", fontSize = 10.sp)
                    }
                }
            } else if (isRfqExpired) {
                Text("QUOTE EXPIRED - RE-REQUEST RFQ TO RECEIVE FRESH QUOTES", fontSize = 9.sp, color = RubyLoss, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun DealerChip(
    dealer: String,
    isSelected: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) GoldContainer else GraphiteBase)
            .border(0.5.dp, if (isSelected) GoldPrimary else GraphiteBorder, RoundedCornerShape(4.dp))
            .clickable(onClick = onToggle)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = dealer,
            fontSize = 9.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) GoldBright else IvoryMuted
        )
    }
}

private fun formatNumber(n: Double): String {
    return if (n >= 1_000_000) String.format("%.1fM", n / 1_000_000.0)
    else if (n >= 1_000) String.format("%.0fK", n / 1_000.0)
    else String.format("%.0f", n)
}
