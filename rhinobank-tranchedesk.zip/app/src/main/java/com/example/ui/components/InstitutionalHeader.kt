package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountBalances
import com.example.ui.Workspace
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyLoss

@Composable
fun InstitutionalHeader(
    accountBalances: AccountBalances,
    currentWorkspace: Workspace,
    onSelectWorkspace: (Workspace) -> Unit,
    onOpenDemoDrawer: () -> Unit,
    notificationMessage: String?,
    onClearNotification: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(GraphiteBase)
    ) {
        // Top Brand & Account Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand & Desk Title
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(GoldContainer)
                        .border(1.dp, GoldPrimary, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "RB",
                        color = GoldBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "RHINOBANK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = IvoryPrimary,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "TRANCHEDESK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "TrancheWorks v3.4 Engine • Institutional Trading",
                        style = MaterialTheme.typography.labelSmall,
                        color = IvoryDim
                    )
                }
            }

            // Demo Engine Quick Button
            Button(
                onClick = onOpenDemoDrawer,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldContainer,
                    contentColor = GoldBright
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .height(34.dp)
                    .border(1.dp, GoldPrimary, RoundedCornerShape(6.dp))
                    .testTag("demo_engine_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Demo Engine",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "DEMO RUNNER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Account & Balance Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GraphiteSurface)
                .border(width = 0.5.dp, color = GraphiteBorder)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Account ID
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(EmeraldGain)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = accountBalances.accountId,
                    style = MonospaceNumberSmall,
                    color = IvorySecondary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(GraphiteSurfaceRaised)
                        .border(0.5.dp, GraphiteBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "QIB TIER-1",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldBright
                    )
                }
            }

            // Available Cash & NAV
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "AVAIL CASH",
                        style = MaterialTheme.typography.labelSmall,
                        color = IvoryMuted,
                        fontSize = 9.sp
                    )
                    Text(
                        text = "$${formatMillions(accountBalances.availableCash)}",
                        style = MonospaceNumberMedium,
                        color = IvoryPrimary
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "PORTFOLIO NAV",
                        style = MaterialTheme.typography.labelSmall,
                        color = IvoryMuted,
                        fontSize = 9.sp
                    )
                    Text(
                        text = "$${formatMillions(accountBalances.totalNav)}",
                        style = MonospaceNumberMedium,
                        color = GoldPrimary
                    )
                }
            }
        }

        // System Notification Banner
        if (!notificationMessage.isNullOrBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GoldContainer)
                    .border(0.5.dp, GoldContainerBorder)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Alert",
                        tint = GoldBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = notificationMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryPrimary,
                        fontSize = 11.sp
                    )
                }
                IconButton(
                    onClick = onClearNotification,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = IvoryMuted,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Workspace Tab Row (7 institutional workspaces)
        ScrollableTabRow(
            selectedTabIndex = currentWorkspace.ordinal,
            containerColor = GraphiteSurface,
            contentColor = IvoryPrimary,
            edgePadding = 8.dp,
            divider = { Box(modifier = Modifier.height(1.dp).background(GraphiteBorder)) },
            modifier = Modifier.fillMaxWidth().testTag("workspace_tab_row")
        ) {
            Workspace.values().forEach { ws ->
                val isSelected = currentWorkspace == ws
                Tab(
                    selected = isSelected,
                    onClick = { onSelectWorkspace(ws) },
                    modifier = Modifier.testTag("tab_${ws.name.lowercase()}"),
                    text = {
                        Text(
                            text = ws.displayName.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) GoldPrimary else IvoryMuted,
                            letterSpacing = 0.5.sp
                        )
                    }
                )
            }
        }
    }
}

private fun formatMillions(amount: Double): String {
    return if (amount >= 1_000_000) {
        String.format("%.2fM", amount / 1_000_000.0)
    } else {
        String.format("%,.0f", amount)
    }
}
