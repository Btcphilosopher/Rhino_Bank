package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.DemoLifecycleDialog
import com.example.ui.components.InstitutionalHeader
import com.example.ui.theme.GraphiteBase
import com.example.ui.workspaces.MarketWorkspace
import com.example.ui.workspaces.PositionsWorkspace
import com.example.ui.workspaces.RfqWorkspace
import com.example.ui.workspaces.RiskWorkspace
import com.example.ui.workspaces.SettlementWorkspace
import com.example.ui.workspaces.SurveillanceWorkspace
import com.example.ui.workspaces.TradeTicketWorkspace

@Composable
fun TrancheDeskApp(
    viewModel: TrancheDeskViewModel = viewModel()
) {
    val currentWorkspace by viewModel.currentWorkspace.collectAsStateWithLifecycle()
    val cashNotes by viewModel.cashNotes.collectAsStateWithLifecycle()
    val syntheticTranches by viewModel.syntheticTranches.collectAsStateWithLifecycle()
    val selectedCashNote by viewModel.selectedCashNote.collectAsStateWithLifecycle()
    val selectedSyntheticTranche by viewModel.selectedSyntheticTranche.collectAsStateWithLifecycle()
    val selectedInstrumentType by viewModel.selectedInstrumentType.collectAsStateWithLifecycle()
    val rfqs by viewModel.rfqs.collectAsStateWithLifecycle()
    val trades by viewModel.trades.collectAsStateWithLifecycle()
    val positions by viewModel.positions.collectAsStateWithLifecycle()
    val accountBalances by viewModel.accountBalances.collectAsStateWithLifecycle()
    val dealerExposures by viewModel.dealerExposures.collectAsStateWithLifecycle()
    val novations by viewModel.novations.collectAsStateWithLifecycle()
    val lifecycleEvents by viewModel.lifecycleEvents.collectAsStateWithLifecycle()
    val auditTrail by viewModel.auditTrail.collectAsStateWithLifecycle()
    val demoMilestones by viewModel.demoMilestones.collectAsStateWithLifecycle()
    val riskOfficerSigned by viewModel.riskOfficerSignoff.collectAsStateWithLifecycle()
    val notificationMessage by viewModel.systemNotification.collectAsStateWithLifecycle()

    var showDemoDialog by remember { mutableStateOf(false) }

    // BackHandler: Return to Market workspace if in another workspace
    BackHandler(enabled = currentWorkspace != Workspace.MARKET) {
        viewModel.selectWorkspace(Workspace.MARKET)
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            InstitutionalHeader(
                accountBalances = accountBalances,
                currentWorkspace = currentWorkspace,
                onSelectWorkspace = { viewModel.selectWorkspace(it) },
                onOpenDemoDrawer = { showDemoDialog = true },
                notificationMessage = notificationMessage,
                onClearNotification = { viewModel.clearNotification() }
            )
        },
        containerColor = GraphiteBase,
        modifier = Modifier.fillMaxSize().testTag("tranchedesk_root")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GraphiteBase)
        ) {
            when (currentWorkspace) {
                Workspace.MARKET -> {
                    MarketWorkspace(
                        cashNotes = cashNotes,
                        syntheticTranches = syntheticTranches,
                        selectedCashNote = selectedCashNote,
                        selectedSyntheticTranche = selectedSyntheticTranche,
                        selectedInstrumentType = selectedInstrumentType,
                        onSelectCashNote = { viewModel.selectCashNote(it) },
                        onSelectSyntheticTranche = { viewModel.selectSyntheticTranche(it) },
                        onSelectInstrumentType = { viewModel.selectInstrumentType(it) },
                        onNavigateWorkspace = { viewModel.selectWorkspace(it) }
                    )
                }
                Workspace.RFQS -> {
                    RfqWorkspace(
                        selectedCashNote = selectedCashNote,
                        selectedSyntheticTranche = selectedSyntheticTranche,
                        selectedInstrumentType = selectedInstrumentType,
                        rfqs = rfqs,
                        onBroadcastRfq = { instId, instType, side, qty, basis, dealers ->
                            viewModel.broadcastRfq(instId, instType, side, qty, basis, dealers)
                        },
                        onExecuteQuote = { rfqId, quoteId, qty ->
                            viewModel.executeQuote(rfqId, quoteId, qty)
                        }
                    )
                }
                Workspace.TRADE_TICKET -> {
                    TradeTicketWorkspace(
                        selectedCashNote = selectedCashNote,
                        selectedSyntheticTranche = selectedSyntheticTranche,
                        accountBalances = accountBalances,
                        positions = positions,
                        dealerExposures = dealerExposures,
                        novations = novations,
                        riskOfficerSigned = riskOfficerSigned,
                        onToggleRiskOfficerSignoff = { viewModel.toggleRiskOfficerSignoff(it) },
                        onExecuteCashTicket = { note, type, face, basis, price, cpty ->
                            viewModel.executeQuote("MANUAL-TICKET", "DIR-EXEC", face)
                        },
                        onExecuteSyntheticTicket = { syn, type, notional, cpty ->
                            viewModel.executeQuote("MANUAL-SYN-TICKET", "DIR-EXEC", notional)
                        },
                        onCreateNovation = { trdRef, transferee, remaining ->
                            viewModel.createNovation(trdRef, transferee, remaining)
                        },
                        onGrantDealerConsent = { viewModel.grantNovationDealerConsent(it) },
                        onGrantCalcAgentConsent = { viewModel.grantNovationCalcAgentConsent(it) },
                        onFinalizeNovation = { viewModel.finalizeNovation(it) }
                    )
                }
                Workspace.POSITIONS -> {
                    PositionsWorkspace(
                        positions = positions,
                        trades = trades,
                        accountBalances = accountBalances,
                        onSelectValuationSource = { viewModel.setValuationSource(it) }
                    )
                }
                Workspace.RISK -> {
                    RiskWorkspace(
                        dealerExposures = dealerExposures,
                        positions = positions
                    )
                }
                Workspace.SETTLEMENT -> {
                    SettlementWorkspace(
                        trades = trades,
                        onAffirmTrade = { viewModel.affirmTrade(it) },
                        onSettleTrade = { viewModel.settleTrade(it) },
                        onFailSettlement = { trdId, reason -> viewModel.failSettlement(trdId, reason) },
                        onRetrySettlement = { viewModel.retrySettlement(it) }
                    )
                }
                Workspace.SURVEILLANCE -> {
                    SurveillanceWorkspace(
                        lifecycleEvents = lifecycleEvents,
                        auditTrail = auditTrail,
                        onApplyDeterioration = { viewModel.applyCollateralDeterioration(it) },
                        onApplyWaterfallDistribution = { viewModel.applyWaterfallDistribution(it) }
                    )
                }
            }

            // Demo Milestone Dialog
            if (showDemoDialog) {
                DemoLifecycleDialog(
                    milestones = demoMilestones,
                    onRunStep = { step -> viewModel.runDemoMilestone(step) },
                    onDismiss = { showDemoDialog = false }
                )
            }
        }
    }
}
