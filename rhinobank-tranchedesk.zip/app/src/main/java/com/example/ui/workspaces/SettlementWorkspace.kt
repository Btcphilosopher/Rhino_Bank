package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TradeRecord
import com.example.data.model.TradeState
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberPending
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldContainerBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberMedium
import com.example.ui.theme.MonospaceNumberSmall
import com.example.ui.theme.RubyContainer
import com.example.ui.theme.RubyLoss

@Composable
fun SettlementWorkspace(
    trades: List<TradeRecord>,
    onAffirmTrade: (String) -> Unit,
    onSettleTrade: (String) -> Unit,
    onFailSettlement: (String, String) -> Unit,
    onRetrySettlement: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteBase)
            .padding(14.dp)
            .testTag("settlement_workspace"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Lifecycle State Machine Visual Pipeline
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, GoldContainerBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TRADE LIFECYCLE & STATE MACHINE TRANSITION PIPELINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldBright, letterSpacing = 0.5.sp)
                    Text("Deterministic trade state machine: Execution is decoupled from Confirmation and Settlement.", fontSize = 10.sp, color = IvoryDim)

                    // Pipeline Steps Visualizer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GraphiteBase)
                            .clip(RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PipelineStepBadge("1. EXECUTED", true)
                        PipelineArrow()
                        PipelineStepBadge("2. CONFIRMED", true)
                        PipelineArrow()
                        PipelineStepBadge("3. CLEARING", true)
                        PipelineArrow()
                        PipelineStepBadge("4. SETTLED", true)
                    }
                }
            }
        }

        // Active Trades Requiring Settlement Operations
        item {
            Text("SETTLEMENT OPERATIONS QUEUE & DVP RECONCILIATION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IvoryPrimary)
        }

        if (trades.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().background(GraphiteSurface).border(1.dp, GraphiteBorder, RoundedCornerShape(8.dp)).padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No trades in queue. Execute a trade in Market or RFQ workspace first.", color = IvoryMuted, fontSize = 12.sp)
                }
            }
        } else {
            items(trades) { trade ->
                SettlementTradeCard(
                    trade = trade,
                    onAffirm = { onAffirmTrade(trade.tradeId) },
                    onSettle = { onSettleTrade(trade.tradeId) },
                    onFail = { onFailSettlement(trade.tradeId, "Counterparty securities delivery delayed (fail-to-deliver in Euroclear)") },
                    onRetry = { onRetrySettlement(trade.tradeId) }
                )
            }
        }
    }
}

@Composable
private fun SettlementTradeCard(
    trade: TradeRecord,
    onAffirm: () -> Unit,
    onSettle: () -> Unit,
    onFail: () -> Unit,
    onRetry: () -> Unit
) {
    val isSettled = trade.state == TradeState.SETTLED
    val isFailed = trade.state == TradeState.FAILED
    val isConfirmed = trade.state == TradeState.CONFIRMED

    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                when {
                    isSettled -> EmeraldGain.copy(alpha = 0.5f)
                    isFailed -> RubyLoss
                    isConfirmed -> GoldPrimary
                    else -> GraphiteBorder
                },
                RoundedCornerShape(8.dp)
            )
            .testTag("settlement_card_${trade.tradeId}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(trade.tradeId, style = MonospaceNumberMedium, color = GoldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                when {
                                    isSettled -> EmeraldContainer
                                    isFailed -> RubyContainer
                                    isConfirmed -> GoldContainer
                                    else -> GraphiteSurfaceRaised
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = trade.state.displayName,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isSettled -> EmeraldGain
                                isFailed -> RubyLoss
                                isConfirmed -> GoldBright
                                else -> IvorySecondary
                            }
                        )
                    }
                }

                Text(
                    text = "Settle: ${trade.settlementDate} (T+2)",
                    fontSize = 10.sp,
                    color = IvoryDim
                )
            }

            Text("${trade.tradeType.displayName} • ${trade.instrumentName}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IvoryPrimary)

            // Settlement Economics
            Row(
                modifier = Modifier.fillMaxWidth().background(GraphiteBase).clip(RoundedCornerShape(4.dp)).padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TRADED FACE", fontSize = 8.sp, color = IvoryDim)
                    Text("$${formatMillions(trade.currentFace)}", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("EXECUTION PRICE", fontSize = 8.sp, color = IvoryDim)
                    Text("${trade.price}", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column {
                    Text("CONSIDERATION", fontSize = 8.sp, color = IvoryDim)
                    Text("$${String.format("%,.0f", trade.considerationBeforeAccrued)}", style = MonospaceNumberSmall, color = IvorySecondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("TOTAL DVP SETTLEMENT", fontSize = 8.sp, color = IvoryDim)
                    Text("$${String.format("%,.0f", trade.totalSettlementAmount)}", style = MonospaceNumberSmall, color = GoldBright)
                }
            }

            // SSI Instructions
            Column {
                Text("SETTLEMENT INSTRUCTIONS & ELECTRONIC MATCHING", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = IvoryMuted)
                Text("Depository: ${trade.settlementInstructions.depository} • Participant: ${trade.settlementInstructions.participantAccount}", fontSize = 9.sp, color = IvoryDim)
                if (trade.confirmationRef != null) {
                    Text("Electronic Match Ref: ${trade.confirmationRef} (SWIFT MT Affirmation Verified)", fontSize = 9.sp, color = EmeraldGain)
                }
                if (trade.failureReason != null) {
                    Text("Failure Detail: ${trade.failureReason}", fontSize = 9.sp, color = RubyLoss)
                }
            }

            // Interactive Actions based on trade state
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (trade.state == TradeState.EXECUTED) {
                    Button(
                        onClick = onAffirm,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = GraphiteBase),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f).height(34.dp).testTag("affirm_trade_button_${trade.tradeId}")
                    ) {
                        Text("Affirm Confirmation", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onFail,
                        colors = ButtonDefaults.buttonColors(containerColor = RubyContainer, contentColor = RubyLoss),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(34.dp).testTag("fail_trade_button_${trade.tradeId}")
                    ) {
                        Text("Simulate Fail", fontSize = 10.sp)
                    }
                } else if (trade.state == TradeState.CONFIRMED) {
                    Button(
                        onClick = onSettle,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGain, contentColor = GraphiteBase),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f).height(34.dp).testTag("settle_trade_button_${trade.tradeId}")
                    ) {
                        Text("Clear & Settle DVP", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onFail,
                        colors = ButtonDefaults.buttonColors(containerColor = RubyContainer, contentColor = RubyLoss),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(34.dp).testTag("fail_trade_button_${trade.tradeId}")
                    ) {
                        Text("Simulate Fail", fontSize = 10.sp)
                    }
                } else if (isFailed) {
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberPending, contentColor = GraphiteBase),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f).height(34.dp).testTag("retry_trade_button_${trade.tradeId}")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Retry Clearing Settlement", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (isSettled) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(EmeraldContainer.copy(alpha = 0.3f))
                            .clip(RoundedCornerShape(4.dp))
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Settled", tint = EmeraldGain, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("DVP SETTLEMENT FINALIZED IN EUROCLEAR", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldGain)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PipelineStepBadge(label: String, isActive: Boolean) {
    Text(
        text = label,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        color = if (isActive) GoldBright else IvoryDim
    )
}

@Composable
private fun PipelineArrow() {
    Text("→", fontSize = 10.sp, color = IvoryDim)
}

private fun formatMillions(n: Double): String {
    return if (n >= 1_000_000) String.format("%.2fM", n / 1_000_000.0)
    else String.format("%,.0f", n)
}
