package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.DemoMilestone
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGain
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GraphiteBase
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceRaised
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryPrimary
import com.example.ui.theme.IvorySecondary
import com.example.ui.theme.MonospaceNumberSmall

@Composable
fun DemoLifecycleDialog(
    milestones: List<DemoMilestone>,
    onRunStep: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = GraphiteSurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp))
                .testTag("demo_lifecycle_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "EXECUTABLE DEMO LIFECYCLE",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = IvoryPrimary,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Text(
                            text = "Institutional 10-Step Interactive Workflow",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IvoryMuted,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp).testTag("close_demo_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = IvorySecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Steps list
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(milestones) { item ->
                        MilestoneCard(
                            milestone = item,
                            onRun = {
                                onRunStep(item.step)
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GraphiteSurfaceRaised,
                        contentColor = IvoryPrimary
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GraphiteBorder, RoundedCornerShape(6.dp))
                ) {
                    Text("Close Demonstration Hub", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MilestoneCard(
    milestone: DemoMilestone,
    onRun: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (milestone.isActive) GoldContainer else GraphiteBase
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = when {
                    milestone.isCompleted -> EmeraldGain.copy(alpha = 0.5f)
                    milestone.isActive -> GoldPrimary
                    else -> GraphiteBorder
                },
                shape = RoundedCornerShape(8.dp)
            )
            .testTag("milestone_card_${milestone.step}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Step Number & Status Icon
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            milestone.isCompleted -> EmeraldContainer
                            milestone.isActive -> GoldPrimary
                            else -> GraphiteSurfaceRaised
                        }
                    )
                    .border(
                        1.dp,
                        if (milestone.isCompleted) EmeraldGain else GraphiteBorder,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (milestone.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Done",
                        tint = EmeraldGain,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Text(
                        text = "${milestone.step}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (milestone.isActive) GraphiteBase else IvorySecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Title & Description
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = milestone.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (milestone.isActive) GoldBright else IvoryPrimary,
                        fontSize = 12.sp
                    )
                    if (milestone.isCompleted) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "COMPLETED",
                            fontSize = 9.sp,
                            color = EmeraldGain,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = milestone.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IvoryMuted,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Action Button
            Button(
                onClick = onRun,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (milestone.isActive) GoldPrimary else GraphiteSurfaceRaised,
                    contentColor = if (milestone.isActive) GraphiteBase else IvoryPrimary
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .height(30.dp)
                    .border(
                        0.5.dp,
                        if (milestone.isActive) GoldBright else GraphiteBorder,
                        RoundedCornerShape(6.dp)
                    )
                    .testTag("run_step_${milestone.step}_button")
            ) {
                Text(
                    text = if (milestone.isCompleted) "Re-run" else "Execute",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
