package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TrancheDeskColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = GraphiteBase,
    primaryContainer = GoldContainer,
    onPrimaryContainer = GoldBright,
    secondary = IvorySecondary,
    onSecondary = GraphiteBase,
    secondaryContainer = GraphiteSurfaceRaised,
    onSecondaryContainer = IvoryPrimary,
    tertiary = CyanSynthetic,
    onTertiary = GraphiteBase,
    tertiaryContainer = CyanContainer,
    onTertiaryContainer = CyanSynthetic,
    background = GraphiteBase,
    onBackground = IvoryPrimary,
    surface = GraphiteSurface,
    onSurface = IvoryPrimary,
    surfaceVariant = GraphiteSurfaceRaised,
    onSurfaceVariant = IvorySecondary,
    outline = GraphiteBorder,
    outlineVariant = GraphiteBorderSubtle,
    error = RubyLoss,
    onError = IvoryPrimary,
    errorContainer = RubyContainer,
    onErrorContainer = RubyLoss
)

@Composable
fun TrancheDeskTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TrancheDeskColorScheme,
        typography = Typography,
        content = content
    )
}
