package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Graphite Surfaces
val GraphiteBase = Color(0xFF0D0F13)       // Deepest background
val GraphiteSurface = Color(0xFF14181F)    // Panel / Card background
val GraphiteSurfaceRaised = Color(0xFF1C222C) // Elevated surface
val GraphiteSurfaceElevated = Color(0xFF242C38) // Tooltips, modals
val GraphiteBorder = Color(0xFF2C3442)     // Hairline borders
val GraphiteBorderSubtle = Color(0xFF1F2633)

// Ivory Typography
val IvoryPrimary = Color(0xFFF4F5F7)      // Main header & high contrast figures
val IvorySecondary = Color(0xFFD2D6DC)    // Body text & labels
val IvoryMuted = Color(0xFF9CA3AF)        // Secondary descriptions
val IvoryDim = Color(0xFF6B7280)          // Watermarks, timestamps

// Restrained Institutional Gold Accents
val GoldPrimary = Color(0xFFD4AF37)       // RhinoBank signature gold
val GoldBright = Color(0xFFECCB65)        // Interactive hover / highlight
val GoldMuted = Color(0xFFA1852C)         // Subdued borders / tags
val GoldContainer = Color(0xFF2B2414)     // Gold badge background
val GoldContainerBorder = Color(0xFF5A481B)

// Operational & Financial Semantic Colors
val EmeraldGain = Color(0xFF10B981)       // Firm quote, Settled, Positive P&L, Buy Protection (Short Risk)
val EmeraldContainer = Color(0xFF064E3B)
val RubyLoss = Color(0xFFEF4444)          // Failed, Sell, Short risk trigger, Negative P&L
val RubyContainer = Color(0xFF450A0A)
val AmberPending = Color(0xFFF59E0B)      // Indicative quote, Pending settlement, Margin trigger
val AmberContainer = Color(0xFF451A03)
val CyanSynthetic = Color(0xFF38BDF8)     // Synthetic derivative badges
val CyanContainer = Color(0xFF082F49)
val PurpleMezzanine = Color(0xFFA78BFA)   // Mezzanine tranches
